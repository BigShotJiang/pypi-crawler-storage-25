"""Sync and async data resources: upload, query, and update rows via jobs."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from http import HTTPStatus
import time

import httpx

from ineepy._exceptions import JobFailedError, TimeoutError
from ineepy._models import (
    DataJobResponse,
    DataJobStatus,
    DatasetInfoResponse,
)
from ineepy._resources._base import AsyncBaseResource, BaseResource

_TABLES_URL = 'tables'
_DATA_URL = 'data'

_DEFAULT_POLL_INTERVAL = 2.0
_DEFAULT_TIMEOUT = 300.0

_FORMAT_CONTENT_TYPE = {
    'csv': 'text/csv',
    'parquet': 'application/vnd.apache.parquet',
    'json': 'application/json',
}


def _parse_filter(f: str) -> dict:
    field, operator, value = f.split(':', 2)
    return {'field': field, 'operator': operator, 'value': value}


class DataResource(BaseResource):
    """Synchronous access to the table data and job endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        super().__init__(client)

    def _poll_job(
        self,
        job_id: str,
        *,
        timeout: float,
        poll_interval: float,
    ) -> DataJobResponse:
        deadline = time.monotonic() + timeout
        while True:
            r = self._client.get(f'{_DATA_URL}/jobs/{job_id}')
            self._raise_for_status(r)
            job = DataJobResponse.model_validate(r.json())
            if job.status == DataJobStatus.COMPLETED:
                return job
            if job.status == DataJobStatus.FAILED:
                raise JobFailedError(job_id, job.error)
            if time.monotonic() >= deadline:
                raise TimeoutError(job_id)
            time.sleep(poll_interval)

    def info(self, table_id: str) -> DatasetInfoResponse:
        """Return snapshot statistics for a table (no data scan).

        Args:
            table_id: Unique identifier of the table to retrieve info for.

        Returns:
            :class:`~ineepy.DatasetInfoResponse` containing table statistics.
        """
        r = self._client.get(f'{_TABLES_URL}/{table_id}/data')
        self._raise_for_status(r)
        return DatasetInfoResponse.model_validate(r.json())

    def submit_upload(self, table_id: str, data: bytes, format: str) -> str:
        """Upload data and return the job ID without waiting for completion.

        Obtains a presigned S3 URL from the server, PUTs ``data`` to it,
        and returns the job ID for later polling with :meth:`get_job`.

        Args:
            table_id: Unique identifier of the target table.
            data: Raw bytes to upload.
            format: Format of the uploaded data (e.g. ``csv``, ``parquet``).

        Returns:
            Job ID string for later polling.
        """
        r = self._client.post(
            f'{_TABLES_URL}/{table_id}/data',
            headers={'Accept': _FORMAT_CONTENT_TYPE[format]},
        )
        self._raise_for_status(r)
        s3_url = r.headers['Location']
        job_id = r.headers['X-Job-Id']
        with httpx.Client() as s3:
            s3.put(s3_url, content=data)
        return job_id

    def upload(
        self,
        table_id: str,
        data: bytes,
        format: str,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> DataJobResponse:
        """Upload data and block until the ingestion job completes.

        Args:
            table_id: Unique identifier of the target table.
            data: Raw bytes to upload.
            format: Format of the uploaded data (e.g. ``csv``, ``parquet``).
            timeout: Maximum time in seconds to wait for job completion.
            poll_interval: Time in seconds between job status checks.

        Returns:
            :class:`~ineepy.DataJobResponse` containing the final job status.

        Raises:
            JobFailedError: Server-side processing failed.
            TimeoutError: Job did not complete within ``timeout`` seconds.
        """
        job_id = self.submit_upload(table_id, data, format)
        return self._poll_job(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    def submit_update(
        self,
        table_id: str,
        data: bytes,
        format: str,
        update_mode: str,
        key_columns: Sequence[str] | None = None,
    ) -> str:
        """Submit a merge/update job and return its ID without waiting.

        Args:
            table_id: Unique identifier of the target table.
            data: Raw bytes to upload.
            format: Format of the uploaded data (e.g. ``csv``, ``parquet``).
            update_mode: ``append``, ``overwrite``, or ``upsert``.
            key_columns: Match columns for upsert mode.

        Returns:
            Job ID string for later polling.
        """
        r = self._client.put(
            f'{_TABLES_URL}/{table_id}/data',
            json={
                'update_mode': update_mode,
                'key_columns': key_columns or [],
            },
            headers={'Accept': _FORMAT_CONTENT_TYPE[format]},
        )
        self._raise_for_status(r)
        s3_url = r.headers['Location']
        job_id = r.headers['X-Job-Id']
        with httpx.Client() as s3:
            s3.put(s3_url, content=data)
        return job_id

    def update(  # noqa: PLR0913
        self,
        table_id: str,
        data: bytes,
        format: str,
        update_mode: str,
        key_columns: Sequence[str] | None = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> DataJobResponse:
        """Merge/update data and block until the job completes.

        Args:
            table_id: Unique identifier of the target table.
            data: Raw bytes to upload.
            format: Format of the uploaded data (e.g. ``csv``, ``parquet``).
            update_mode: ``append``, ``overwrite``, or ``upsert``.
            key_columns: Match columns for upsert mode.
            timeout: Maximum time in seconds to wait for job completion.
            poll_interval: Time in seconds between job status checks.

        Returns:
            :class:`~ineepy.DataJobResponse` containing the final job status.

        Raises:
            JobFailedError: Server-side processing failed.
            TimeoutError: Job did not complete within ``timeout`` seconds.
        """
        job_id = self.submit_update(
            table_id, data, format, update_mode, key_columns
        )
        return self._poll_job(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    def submit_query(
        self,
        table_id: str,
        *,
        filters: Sequence[str] | None = None,
        format: str = 'parquet',
    ) -> str:
        """Submit an async query and return the job ID without waiting.

        Args:
            table_id: Table identifier.
            filters: Filter expressions in ``field:operator:value`` format.
            format: Output format (``parquet`` or ``csv``).

        Returns:
            Job ID string for later polling.
        """
        parsed_filters = [_parse_filter(f) for f in (filters or [])]
        headers = {}
        if format != 'json':
            headers['Accept'] = _FORMAT_CONTENT_TYPE[format]
        r = self._client.post(
            f'{_TABLES_URL}/{table_id}/data/query',
            json={'filters': parsed_filters},
            headers=headers if headers else None,
        )
        self._raise_for_status(r)
        return r.headers.get('X-Job-Id') or r.json()['job_id']

    def query(
        self,
        table_id: str,
        *,
        filters: Sequence[str] | None = None,
        format: str = 'json',
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> bytes | dict:
        """Query a table and return results.

        For ``format='json'`` the result is returned synchronously as a
        ``dict`` / ``list``. For ``parquet`` / ``csv`` an async job is
        submitted and polled; raw bytes are returned when complete.

        Args:
            table_id: Table identifier.
            filters: Filter expressions in ``field:operator:value`` format.
            format: Output format (``json``, ``parquet``, or ``csv``).
            timeout: Maximum time in seconds to wait for job completion.
            poll_interval: Time in seconds between job status checks.

        Returns:
            Query results as ``dict``/``list`` for JSON or ``bytes`` for
            binary formats.

        Raises:
            JobFailedError: Query job failed server-side.
            TimeoutError: Job did not complete within ``timeout`` seconds.
        """
        parsed_filters = [_parse_filter(f) for f in (filters or [])]
        headers = {}
        if format != 'json':
            headers['Accept'] = _FORMAT_CONTENT_TYPE[format]
        r = self._client.post(
            f'{_TABLES_URL}/{table_id}/data/query',
            json={'filters': parsed_filters},
            headers=headers if headers else None,
        )
        self._raise_for_status(r)
        if r.status_code == HTTPStatus.OK:
            return r.json()
        job_id = r.headers.get('X-Job-Id') or r.json()['job_id']
        return self.poll_download(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    def truncate(self, table_id: str) -> None:
        """Delete all rows in a table (schema is preserved).

        Args:
            table_id: Table identifier.
        """
        r = self._client.delete(f'{_TABLES_URL}/{table_id}/data')
        self._raise_for_status(r)

    def delete_rows(self, table_id: str, filters: Sequence[str]) -> None:
        """Delete rows matching all supplied filters (AND semantics).

        Args:
            table_id: Table identifier.
            filters: Filter expressions in ``field:operator:value`` format.
                At least one filter is required.
        """
        parsed_filters = [_parse_filter(f) for f in filters]
        r = self._client.put(
            f'{_TABLES_URL}/{table_id}/data/rows',
            json={'filters': parsed_filters},
        )
        self._raise_for_status(r)

    def get_job(self, job_id: str) -> DataJobResponse:
        """Return the current status of a data job.

        Args:
            job_id: Job identifier.

        Returns:
            :class:`~ineepy.DataJobResponse` with current job status.
        """
        r = self._client.get(f'{_DATA_URL}/jobs/{job_id}')
        self._raise_for_status(r)
        return DataJobResponse.model_validate(r.json())

    def poll_download(
        self,
        job_id: str,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> bytes:
        """Poll a query job until complete, then download and return bytes.

        Args:
            job_id: Job identifier.
            timeout: Maximum time in seconds to wait for job completion.
            poll_interval: Time in seconds between job status checks.

        Returns:
            Raw bytes downloaded from the query result.

        Raises:
            JobFailedError: Query job failed server-side.
            TimeoutError: Job did not complete within ``timeout`` seconds.
        """
        deadline = time.monotonic() + timeout
        while True:
            r = self._client.get(f'{_DATA_URL}/query/{job_id}')
            if r.status_code == HTTPStatus.TEMPORARY_REDIRECT:
                location = r.headers['Location']
                with httpx.Client() as s3:
                    return s3.get(location).content
            if r.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
                data = r.json()
                raise JobFailedError(
                    data.get('job_id', job_id), data.get('error')
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(job_id)
            time.sleep(poll_interval)


class AsyncDataResource(AsyncBaseResource):
    """Async access to the table data and job endpoints."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)

    async def _poll_job(
        self,
        job_id: str,
        *,
        timeout: float,
        poll_interval: float,
    ) -> DataJobResponse:
        deadline = time.monotonic() + timeout
        while True:
            r = await self._client.get(f'{_DATA_URL}/jobs/{job_id}')
            self._raise_for_status(r)
            job = DataJobResponse.model_validate(r.json())
            if job.status == DataJobStatus.COMPLETED:
                return job
            if job.status == DataJobStatus.FAILED:
                raise JobFailedError(job_id, job.error)
            if time.monotonic() >= deadline:
                raise TimeoutError(job_id)
            await asyncio.sleep(poll_interval)

    async def info(self, table_id: str) -> DatasetInfoResponse:
        """Return snapshot statistics for a table (no data scan)."""
        r = await self._client.get(f'{_TABLES_URL}/{table_id}/data')
        self._raise_for_status(r)
        return DatasetInfoResponse.model_validate(r.json())

    async def submit_upload(
        self, table_id: str, data: bytes, format: str
    ) -> str:
        """Upload data and return the job ID without waiting for completion."""
        r = await self._client.post(
            f'{_TABLES_URL}/{table_id}/data',
            headers={'Accept': _FORMAT_CONTENT_TYPE[format]},
        )
        self._raise_for_status(r)
        s3_url = r.headers['Location']
        job_id = r.headers['X-Job-Id']
        async with httpx.AsyncClient() as s3:
            await s3.put(s3_url, content=data)
        return job_id

    async def upload(
        self,
        table_id: str,
        data: bytes,
        format: str,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> DataJobResponse:
        """Upload data and block until the ingestion job completes."""
        job_id = await self.submit_upload(table_id, data, format)
        return await self._poll_job(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    async def submit_update(
        self,
        table_id: str,
        data: bytes,
        format: str,
        update_mode: str,
        key_columns: Sequence[str] | None = None,
    ) -> str:
        """Submit a merge/update job and return its ID without waiting."""
        r = await self._client.put(
            f'{_TABLES_URL}/{table_id}/data',
            json={
                'update_mode': update_mode,
                'key_columns': key_columns or [],
            },
            headers={'Accept': _FORMAT_CONTENT_TYPE[format]},
        )
        self._raise_for_status(r)
        s3_url = r.headers['Location']
        job_id = r.headers['X-Job-Id']
        async with httpx.AsyncClient() as s3:
            await s3.put(s3_url, content=data)
        return job_id

    async def update(  # noqa: PLR0913
        self,
        table_id: str,
        data: bytes,
        format: str,
        update_mode: str,
        key_columns: Sequence[str] | None = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> DataJobResponse:
        """Merge/update data and block until the job completes."""
        job_id = await self.submit_update(
            table_id, data, format, update_mode, key_columns
        )
        return await self._poll_job(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    async def submit_query(
        self,
        table_id: str,
        *,
        filters: Sequence[str] | None = None,
        format: str = 'parquet',
    ) -> str:
        """Submit an async query and return the job ID without waiting."""
        parsed_filters = [_parse_filter(f) for f in (filters or [])]
        headers = {}
        if format != 'json':
            headers['Accept'] = _FORMAT_CONTENT_TYPE[format]
        r = await self._client.post(
            f'{_TABLES_URL}/{table_id}/data/query',
            json={'filters': parsed_filters},
            headers=headers if headers else None,
        )
        self._raise_for_status(r)
        return r.headers.get('X-Job-Id') or r.json()['job_id']

    async def query(
        self,
        table_id: str,
        *,
        filters: Sequence[str] | None = None,
        format: str = 'json',
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> bytes | dict:
        """Query a table and return results.

        See :meth:`DataResource.query` for full documentation.
        """
        parsed_filters = [_parse_filter(f) for f in (filters or [])]
        headers = {}
        if format != 'json':
            headers['Accept'] = _FORMAT_CONTENT_TYPE[format]
        r = await self._client.post(
            f'{_TABLES_URL}/{table_id}/data/query',
            json={'filters': parsed_filters},
            headers=headers if headers else None,
        )
        self._raise_for_status(r)
        if r.status_code == HTTPStatus.OK:
            return r.json()
        job_id = r.headers.get('X-Job-Id') or r.json()['job_id']
        return await self.poll_download(
            job_id, timeout=timeout, poll_interval=poll_interval
        )

    async def truncate(self, table_id: str) -> None:
        """Delete all rows in a table (schema is preserved)."""
        r = await self._client.delete(f'{_TABLES_URL}/{table_id}/data')
        self._raise_for_status(r)

    async def delete_rows(self, table_id: str, filters: Sequence[str]) -> None:
        """Delete rows matching all supplied filters (AND semantics)."""
        parsed_filters = [_parse_filter(f) for f in filters]
        r = await self._client.put(
            f'{_TABLES_URL}/{table_id}/data/rows',
            json={'filters': parsed_filters},
        )
        self._raise_for_status(r)

    async def get_job(self, job_id: str) -> DataJobResponse:
        """Return the current status of a data job."""
        r = await self._client.get(f'{_DATA_URL}/jobs/{job_id}')
        self._raise_for_status(r)
        return DataJobResponse.model_validate(r.json())

    async def poll_download(
        self,
        job_id: str,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        poll_interval: float = _DEFAULT_POLL_INTERVAL,
    ) -> bytes:
        """Poll a query job until complete, then download and return bytes."""
        deadline = time.monotonic() + timeout
        while True:
            r = await self._client.get(f'{_DATA_URL}/query/{job_id}')
            if r.status_code == HTTPStatus.TEMPORARY_REDIRECT:
                location = r.headers['Location']
                async with httpx.AsyncClient() as s3:
                    s3_resp = await s3.get(location)
                return s3_resp.content
            if r.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
                data = r.json()
                raise JobFailedError(
                    data.get('job_id', job_id), data.get('error')
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(job_id)
            await asyncio.sleep(poll_interval)


AsyncDataResource.info.__doc__ = DataResource.info.__doc__
AsyncDataResource.submit_upload.__doc__ = DataResource.submit_upload.__doc__
AsyncDataResource.upload.__doc__ = DataResource.upload.__doc__
AsyncDataResource.submit_update.__doc__ = DataResource.submit_update.__doc__
AsyncDataResource.update.__doc__ = DataResource.update.__doc__
AsyncDataResource.submit_query.__doc__ = DataResource.submit_query.__doc__
AsyncDataResource.query.__doc__ = DataResource.query.__doc__
AsyncDataResource.truncate.__doc__ = DataResource.truncate.__doc__
AsyncDataResource.delete_rows.__doc__ = DataResource.delete_rows.__doc__
AsyncDataResource.get_job.__doc__ = DataResource.get_job.__doc__
AsyncDataResource.poll_download.__doc__ = DataResource.poll_download.__doc__
