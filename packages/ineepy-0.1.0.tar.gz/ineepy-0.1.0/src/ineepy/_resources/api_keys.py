"""Sync and async API key resources: create, list, revoke scoped tokens."""

from __future__ import annotations

from collections.abc import Collection, Sequence
from datetime import datetime
from pathlib import Path

import httpx

from ineepy._config import CONFIG_FILENAME, write_config
from ineepy._models import APIKeyResponse, APIKeysListResponse, Token
from ineepy._resources._base import AsyncBaseResource, BaseResource

_API_KEYS_URL = 'api-keys'


class APIKeysResource(BaseResource):
    """Synchronous access to the ``/api-keys`` endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        super().__init__(client)

    def create(
        self,
        name: str,
        scopes: Collection[str],
        *,
        expires_at: datetime | None = None,
        save_token: bool = True,
        config_file: Path | None = None,
    ) -> str | None:
        """Create a new API key.

        Args:
            name: Human-readable name for the key.
            scopes: Set of scopes to grant (``editor``, ``viewer``).
            expires_at: Expiry datetime; defaults to 2099-12-31 server-side.
            save_token: When ``True`` (default), writes the new API key to
                the config file and returns ``None``. When ``False``, skips
                writing and returns the token string.
            config_file: Path to the TOML config file. Defaults to
                ``ineepy.toml`` in the current working directory.

        Returns:
            ``None`` when ``save_token=True``; the raw JWT string when
            ``save_token=False``.
        """
        body: dict = {'name': name, 'scopes': list(scopes)}
        if expires_at is not None:
            body['expires_at'] = expires_at.isoformat()
        r = self._client.post(_API_KEYS_URL, json=body)
        self._raise_for_status(r)
        token = Token.model_validate(r.json())
        if save_token:
            cfg_path = config_file or Path.cwd() / CONFIG_FILENAME
            write_config(cfg_path, {'token': token.access_token})
            return None
        return token.access_token

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
    ) -> APIKeysListResponse:
        """Return a paginated list of API keys owned by the current user.

        Args:
            limit: Maximum number of items to return.
            offset: Number of items to skip.
            filters: Filter expressions in ``field:operator:value`` format.
            order_by: Sort expressions in ``field:direction`` format.

        Returns:
            :class:`~ineepy.APIKeysListResponse` containing metadata and
            a list of :class:`~ineepy.APIKeyResponse` items.
        """
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = self._client.get(_API_KEYS_URL, params=params)
        self._raise_for_status(r)
        return APIKeysListResponse.model_validate(r.json())

    def get(self, jti: str) -> APIKeyResponse:
        """Return an API key by its JWT ID.

        Args:
            jti: JWT ID of the API key to retrieve.

        Returns:
            :class:`~ineepy.APIKeyResponse` containing the API key details.
        """
        r = self._client.get(f'{_API_KEYS_URL}/{jti}')
        self._raise_for_status(r)
        return APIKeyResponse.model_validate(r.json())

    def revoke(self, jti: str) -> None:
        """Revoke an API key permanently.

        Args:
            jti: JWT ID of the API key to revoke.
        """
        r = self._client.delete(f'{_API_KEYS_URL}/{jti}')
        self._raise_for_status(r)


class AsyncAPIKeysResource(AsyncBaseResource):
    """Async access to the ``/api-keys`` endpoints."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)

    async def create(
        self,
        name: str,
        scopes: Collection[str],
        *,
        expires_at: datetime | None = None,
        save_token: bool = True,
        config_file: Path | None = None,
    ) -> str | None:
        """Create a new API key."""
        body: dict = {'name': name, 'scopes': list(scopes)}
        if expires_at is not None:
            body['expires_at'] = expires_at.isoformat()
        r = await self._client.post(_API_KEYS_URL, json=body)
        self._raise_for_status(r)
        token = Token.model_validate(r.json())
        if save_token:
            cfg_path = config_file or Path.cwd() / CONFIG_FILENAME
            write_config(cfg_path, {'token': token.access_token})
            return None
        return token.access_token

    async def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
    ) -> APIKeysListResponse:
        """Return a paginated list of API keys owned by the current user."""
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = await self._client.get(_API_KEYS_URL, params=params)
        self._raise_for_status(r)
        return APIKeysListResponse.model_validate(r.json())

    async def get(self, jti: str) -> APIKeyResponse:
        """Return an API key by its JWT ID."""
        r = await self._client.get(f'{_API_KEYS_URL}/{jti}')
        self._raise_for_status(r)
        return APIKeyResponse.model_validate(r.json())

    async def revoke(self, jti: str) -> None:
        """Revoke an API key permanently."""
        r = await self._client.delete(f'{_API_KEYS_URL}/{jti}')
        self._raise_for_status(r)


AsyncAPIKeysResource.create.__doc__ = APIKeysResource.create.__doc__
AsyncAPIKeysResource.list.__doc__ = APIKeysResource.list.__doc__
AsyncAPIKeysResource.get.__doc__ = APIKeysResource.get.__doc__
AsyncAPIKeysResource.revoke.__doc__ = APIKeysResource.revoke.__doc__
