"""Sync and async table resources: create, list, get, update, and delete."""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from typing import Any

import httpx
from pydantic import BaseModel

from ineepy._models import (
    ColumnPartitioning,
    ColumnSchema,
    ColumnSorting,
    ExternalSource,
    TableResponse,
    TablesListResponse,
)
from ineepy._resources._base import AsyncBaseResource, BaseResource

_TABLES_URL = 'tables'


def _meta_body(  # noqa: PLR0913, PLR0917
    title: str,
    description: str | None,
    tags: Collection[str] | None,
    sensitivity: str,
    refresh_frequency: str,
    license: str | None,
    sources: Sequence[str] | None,
    external_sources: Sequence[ExternalSource | Mapping[str, Any]] | None,
) -> dict:
    return {
        k: v
        for k, v in {
            'title': title,
            'description': description,
            'tags': list(tags) if tags is not None else None,
            'sensitivity': sensitivity,
            'refresh_frequency': refresh_frequency,
            'license': license,
            'sources': list(sources) if sources is not None else None,
            'external_sources': (
                [_dump(e) for e in external_sources]
                if external_sources is not None
                else None
            ),
        }.items()
        if v is not None
    }


def _dump(item: BaseModel | Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(item, BaseModel):
        return item.model_dump()
    return dict(item)


class TablesResource(BaseResource):
    """Synchronous access to the ``/tables`` endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        super().__init__(client)

    def list(  # noqa: PLR0913
        self,
        namespace_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
        prefer: str = 'model=table; format=minimal',
    ) -> TablesListResponse:
        """List tables in a namespace.

        Args:
            namespace_id: Namespace identifier (e.g. ``raw``).
            limit: Maximum number of items to return.
            offset: Number of items to skip.
            filters: Filter expressions in ``field:operator:value`` format.
            order_by: Sort expressions in ``field:direction`` format.
            prefer: ``Prefer`` header value controlling response verbosity.

        Returns:
            :class:`~ineepy.TablesListResponse` containing metadata and
            a list of :class:`~ineepy.TableResponse` items.
        """
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = self._client.get(
            f'{_TABLES_URL}/{namespace_id}',
            params=params,
            headers={'Prefer': prefer},
        )
        self._raise_for_status(r)
        return TablesListResponse.model_validate(r.json())

    def get_metadata(self, table_id: str) -> tuple[TableResponse, str]:
        """Return a table's metadata and its current ETag.

        Args:
            table_id: Table identifier.

        Returns:
            Tuple of :class:`~ineepy.TableResponse` and ETag string.
        """
        r = self._client.get(f'{_TABLES_URL}/{table_id}/metadata')
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def create(  # noqa: PLR0913
        self,
        table_id: str,
        columns: Sequence[ColumnSchema | Mapping[str, Any]],
        *,
        sort_by: Sequence[ColumnSorting | Mapping[str, Any]] | None = None,
        partition_by: Sequence[ColumnPartitioning | Mapping[str, Any]]
        | None = None,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
        sensitivity: str = 'internal',
        refresh_frequency: str = 'manual',
        license: str | None = None,
        sources: Sequence[str] | None = None,
        external_sources: (
            Sequence[ExternalSource | Mapping[str, Any]] | None
        ) = None,
    ) -> tuple[TableResponse, str]:
        """Create a new table with the given schema.

        Args:
            table_id: Table identifier.
            columns: List of :class:`~ineepy.ColumnSchema` objects.
            sort_by: Optional sorting specification.
            partition_by: Optional partitioning specification.
            title: Human-readable title.
            description: Optional description.
            tags: Optional tags.
            sensitivity: Data sensitivity level (default ``internal``).
            refresh_frequency: Refresh cadence (default ``manual``).
            license: Optional license identifier.
            sources: Source table IDs (dot-separated) for lineage tracking.
            external_sources: External data source references.

        Returns:
            Created :class:`~ineepy.TableResponse` and its ETag.

        Raises:
            ConflictError: Table already exists.
        """
        body = {
            'columns': [_dump(c) for c in columns],
            'sort_by': [_dump(s) for s in (sort_by or [])],
            'partition_by': [_dump(p) for p in (partition_by or [])],
            'metadata': _meta_body(
                title,
                description,
                tags,
                sensitivity,
                refresh_frequency,
                license,
                sources,
                external_sources,
            ),
        }
        r = self._client.post(f'{_TABLES_URL}/{table_id}', json=body)
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def update_metadata(  # noqa: PLR0913
        self,
        table_id: str,
        etag: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
        sensitivity: str = 'internal',
        refresh_frequency: str = 'manual',
        license: str | None = None,
        sources: Sequence[str] | None = None,
        external_sources: (
            Sequence[ExternalSource | Mapping[str, Any]] | None
        ) = None,
    ) -> tuple[TableResponse, str]:
        """Patch a table's metadata fields.

        Args:
            table_id: Table identifier.
            etag: Current ETag from :meth:`get_metadata`
                for optimistic locking.
            title: Human-readable title.
            description: Optional description.
            tags: Optional tags.
            sensitivity: Data sensitivity level (default ``internal``).
            refresh_frequency: Refresh cadence (default ``manual``).
            license: Optional license identifier.
            sources: Source table IDs (dot-separated) for lineage tracking.
            external_sources: External data source references.

        Returns:
            Updated :class:`~ineepy.TableResponse` and new ETag.

        Raises:
            PreconditionFailedError: ETag mismatch.
        """
        body = _meta_body(
            title,
            description,
            tags,
            sensitivity,
            refresh_frequency,
            license,
            sources,
            external_sources,
        )
        r = self._client.patch(
            f'{_TABLES_URL}/{table_id}',
            json=body,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def update_schema(
        self,
        table_id: str,
        etag: str,
        columns: Sequence[ColumnSchema | Mapping[str, Any]],
    ) -> tuple[TableResponse, str]:
        """Replace a table's column schema.

        Columns absent from ``columns`` will be dropped (data deleted).
        Rename, type changes, and reordering are not supported.

        Args:
            table_id: Table identifier.
            etag: Current ETag from :meth:`get_metadata`
                for optimistic locking.
            columns: New column schema specification.

        Returns:
            Updated :class:`~ineepy.TableResponse` and new ETag.

        Raises:
            PreconditionFailedError: ETag mismatch.
        """
        body = {'columns': [_dump(c) for c in columns]}
        r = self._client.put(
            f'{_TABLES_URL}/{table_id}/schema',
            json=body,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    def delete(self, table_id: str) -> None:
        """Delete a table and all its data.

        Args:
            table_id: Table identifier.
        """
        r = self._client.delete(f'{_TABLES_URL}/{table_id}')
        self._raise_for_status(r)


class AsyncTablesResource(AsyncBaseResource):
    """Async access to the ``/tables`` endpoints."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)

    async def list(  # noqa: PLR0913
        self,
        namespace_id: str,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
        prefer: str = 'model=table; format=minimal',
    ) -> TablesListResponse:
        """List tables in a namespace."""
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = await self._client.get(
            f'{_TABLES_URL}/{namespace_id}',
            params=params,
            headers={'Prefer': prefer},
        )
        self._raise_for_status(r)
        return TablesListResponse.model_validate(r.json())

    async def get_metadata(self, table_id: str) -> tuple[TableResponse, str]:
        """Return a table's metadata and its current ETag."""
        r = await self._client.get(f'{_TABLES_URL}/{table_id}/metadata')
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def create(  # noqa: PLR0913
        self,
        table_id: str,
        columns: Sequence[ColumnSchema | Mapping[str, Any]],
        *,
        sort_by: Sequence[ColumnSorting | Mapping[str, Any]] | None = None,
        partition_by: Sequence[ColumnPartitioning | Mapping[str, Any]]
        | None = None,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
        sensitivity: str = 'internal',
        refresh_frequency: str = 'manual',
        license: str | None = None,
        sources: Sequence[str] | None = None,
        external_sources: (
            Sequence[ExternalSource | Mapping[str, Any]] | None
        ) = None,
    ) -> tuple[TableResponse, str]:
        """Create a new table with the given schema."""
        body = {
            'columns': [_dump(c) for c in columns],
            'sort_by': [_dump(s) for s in (sort_by or [])],
            'partition_by': [_dump(p) for p in (partition_by or [])],
            'metadata': _meta_body(
                title,
                description,
                tags,
                sensitivity,
                refresh_frequency,
                license,
                sources,
                external_sources,
            ),
        }
        r = await self._client.post(f'{_TABLES_URL}/{table_id}', json=body)
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def update_metadata(  # noqa: PLR0913
        self,
        table_id: str,
        etag: str,
        *,
        title: str = '',
        description: str | None = None,
        tags: Collection[str] | None = None,
        sensitivity: str = 'internal',
        refresh_frequency: str = 'manual',
        license: str | None = None,
        sources: Sequence[str] | None = None,
        external_sources: (
            Sequence[ExternalSource | Mapping[str, Any]] | None
        ) = None,
    ) -> tuple[TableResponse, str]:
        """Patch a table's metadata fields."""
        body = _meta_body(
            title,
            description,
            tags,
            sensitivity,
            refresh_frequency,
            license,
            sources,
            external_sources,
        )
        r = await self._client.patch(
            f'{_TABLES_URL}/{table_id}',
            json=body,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def update_schema(
        self,
        table_id: str,
        etag: str,
        columns: Sequence[ColumnSchema | Mapping[str, Any]],
    ) -> tuple[TableResponse, str]:
        """Replace a table's column schema."""
        body = {'columns': [_dump(c) for c in columns]}
        r = await self._client.put(
            f'{_TABLES_URL}/{table_id}/schema',
            json=body,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return (
            TableResponse.model_validate(r.json()),
            self._extract_etag(r),
        )

    async def delete(self, table_id: str) -> None:
        """Delete a table and all its data."""
        r = await self._client.delete(f'{_TABLES_URL}/{table_id}')
        self._raise_for_status(r)


AsyncTablesResource.list.__doc__ = TablesResource.list.__doc__
AsyncTablesResource.get_metadata.__doc__ = TablesResource.get_metadata.__doc__
AsyncTablesResource.create.__doc__ = TablesResource.create.__doc__
AsyncTablesResource.update_metadata.__doc__ = (
    TablesResource.update_metadata.__doc__
)
AsyncTablesResource.update_schema.__doc__ = (
    TablesResource.update_schema.__doc__
)
AsyncTablesResource.delete.__doc__ = TablesResource.delete.__doc__
