"""Sync and async user resources: list, get, create, update, and delete."""

from __future__ import annotations

from collections.abc import Collection, Sequence
from typing import Literal

import httpx

from ineepy._models import UserResponse, UsersListResponse
from ineepy._resources._base import AsyncBaseResource, BaseResource

_USERS_URL = 'users'


def _patch_payload(
    password: str | None,
    username: str | None,
    scopes: Collection[str] | None,
    is_active: bool | None,
) -> dict:
    return {
        k: v
        for k, v in {
            'password': password,
            'username': username,
            'scopes': list(scopes) if scopes is not None else None,
            'is_active': is_active,
        }.items()
        if v is not None
    }


class UsersResource(BaseResource):
    """Synchronous access to the ``/users`` endpoints."""

    def __init__(self, client: httpx.Client) -> None:
        super().__init__(client)

    def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
    ) -> UsersListResponse:
        """Return a paginated list of users (admin only).

        Args:
            limit: Maximum number of items to return.
            offset: Number of items to skip.
            filters: Filter expressions in ``field:operator:value`` format.
            order_by: Sort expressions in ``field:direction`` format.

        Returns:
            :class:`~ineepy.UsersListResponse` containing metadata and
                a list of :class:`~ineepy.UserResponse` items.
        """
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = self._client.get(_USERS_URL, params=params)
        self._raise_for_status(r)
        return UsersListResponse.model_validate(r.json())

    def get(self, user_id: int | Literal['me']) -> tuple[UserResponse, str]:
        """Get a user and its current ETag.

        Args:
            user_id: User identifier (`int` for numeric ID, or `me`).

        Returns:
            Tuple of :class:`~ineepy.UserResponse` and ETag string.
        """
        r = self._client.get(f'{_USERS_URL}/{user_id}')
        self._raise_for_status(r)
        return UserResponse.model_validate(r.json()), self._extract_etag(r)

    def create(
        self,
        email: str,
        password: str,
        scopes: Sequence[str],
        username: str,
        *,
        is_active: bool = True,
    ) -> list[UserResponse]:
        """Create a new user (admin only).

        Args:
            email: User email address.
            password: User password.
            scopes: Set of scopes to grant (e.g. ``editor``, ``viewer``).
            username: Username.
            is_active: Whether the user is active. Defaults to ``True``.

        Returns:
            List containing the created :class:`~ineepy.UserResponse`.
        """
        body = {
            'username': username,
            'email': email,
            'password': password,
            'scopes': list(scopes),
            'is_active': is_active,
        }
        r = self._client.post(_USERS_URL, json=[body])
        self._raise_for_status(r)
        return [UserResponse.model_validate(u) for u in r.json()]

    def update(  # noqa: PLR0913
        self,
        user_id: int | Literal['me'],
        etag: str,
        *,
        password: str | None = None,
        username: str | None = None,
        scopes: Sequence[str] | None = None,
        is_active: bool | None = None,
    ) -> tuple[UserResponse, str]:
        """Update user's profile.

        Args:
            user_id: User identifier (`int` for numeric ID, or `me`).
            etag: Current ETag for optimistic locking.
            password: User password.
            username: Username.
            scopes: Set of scopes
                (e.g. ``editor``, ``viewer``).
            is_active (bool | None): Whether the user is active.

        Returns:
            Tuple of updated :class:`~ineepy.UserResponse` and new ETag.

        Raises:
            PreconditionFailedError: ETag mismatch (concurrent modification).
        """
        payload = _patch_payload(password, username, scopes, is_active)
        r = self._client.patch(
            f'{_USERS_URL}/{user_id}',
            json=payload,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return UserResponse.model_validate(r.json()), self._extract_etag(r)

    def delete(self, user_id: int | Literal['me']) -> None:
        """Delete a user.

        Args:
            user_id: User identifier (`int` for numeric ID, or `'me'`).
        """
        r = self._client.delete(f'{_USERS_URL}/{user_id}')
        self._raise_for_status(r)


class AsyncUsersResource(AsyncBaseResource):
    """Async version of :class:`~ineepy.UsersResource`."""

    def __init__(self, client: httpx.AsyncClient) -> None:
        super().__init__(client)

    async def list(
        self,
        *,
        limit: int | None = None,
        offset: int | None = None,
        filters: Sequence[str] | None = None,
        order_by: Sequence[str] | None = None,
    ) -> UsersListResponse:
        """Return a paginated list of users (admin only)."""
        params = {
            k: v
            for k, v in {
                'limit': limit,
                'offset': offset,
                'filters': filters,
                'order_by': order_by,
            }.items()
            if v is not None
        }
        r = await self._client.get(_USERS_URL, params=params)
        self._raise_for_status(r)
        return UsersListResponse.model_validate(r.json())

    async def get(
        self, user_id: int | Literal['me']
    ) -> tuple[UserResponse, str]:
        """Get a user and its current ETag."""
        r = await self._client.get(f'{_USERS_URL}/{user_id}')
        self._raise_for_status(r)
        return UserResponse.model_validate(r.json()), self._extract_etag(r)

    async def create(
        self,
        email: str,
        password: str,
        scopes: Collection[str],
        username: str,
        *,
        is_active: bool = True,
    ) -> list[UserResponse]:
        """Create a new user (admin only)."""
        body = {
            'username': username,
            'email': email,
            'password': password,
            'scopes': list(scopes),
            'is_active': is_active,
        }
        r = await self._client.post(_USERS_URL, json=[body])
        self._raise_for_status(r)
        return [UserResponse.model_validate(u) for u in r.json()]

    async def update(  # noqa: PLR0913
        self,
        user_id: int | Literal['me'],
        etag: str,
        *,
        password: str | None = None,
        username: str | None = None,
        scopes: Collection[str] | None = None,
        is_active: bool | None = None,
    ) -> tuple[UserResponse, str]:
        """Update user's profile."""
        payload = _patch_payload(password, username, scopes, is_active)
        r = await self._client.patch(
            f'{_USERS_URL}/{user_id}',
            json=payload,
            headers={'If-Match': etag},
        )
        self._raise_for_status(r)
        return UserResponse.model_validate(r.json()), self._extract_etag(r)

    async def delete(self, user_id: int | Literal['me']) -> None:
        r = await self._client.delete(f'{_USERS_URL}/{user_id}')
        self._raise_for_status(r)


AsyncUsersResource.list.__doc__ = UsersResource.list.__doc__
AsyncUsersResource.get.__doc__ = UsersResource.get.__doc__
AsyncUsersResource.create.__doc__ = UsersResource.create.__doc__
AsyncUsersResource.update.__doc__ = UsersResource.update.__doc__
AsyncUsersResource.delete.__doc__ = UsersResource.delete.__doc__
