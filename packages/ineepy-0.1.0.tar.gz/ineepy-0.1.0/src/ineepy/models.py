"""Public input models for ineepy.

Pydantic models used when constructing table schemas.
:class:`ColumnSchema`, :class:`ColumnSorting`, and :class:`ColumnPartitioning`
are the primary types callers pass to table resource methods.
"""

from ineepy._models import (
    ColumnPartitioning,
    ColumnSchema,
    ColumnSorting,
    ExternalSource,
    TableMetadata,
)

__all__ = [
    'ColumnSchema',
    'ColumnSorting',
    'ColumnPartitioning',
    'ExternalSource',
    'TableMetadata',
]
