"""Soup CLI — Fine-tune LLMs in one command."""

__version__ = "0.60.0"
