//! JSON configuration and report helpers for ChArUco detection.

use crate::{
    CharucoBoard, CharucoBoardError, CharucoBoardSpec, CharucoDetectError, CharucoDetectionResult,
    CharucoDetector, CharucoParams, MarkerLayout,
};
use calib_targets_aruco::{builtins, ArucoScanConfig, Dictionary, MarkerDetection};
use calib_targets_chessboard::DetectorParams;
use calib_targets_core::io::{self, IoError};
use calib_targets_core::{ChessConfig, Corner, GridAlignment, TargetDetection};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

pub type CharucoIoError = IoError;

#[non_exhaustive]
#[derive(thiserror::Error, Debug)]
pub enum CharucoConfigError {
    #[error(transparent)]
    Board(#[from] CharucoBoardError),
}

/// Errors from loading a board specification via [`load_board_spec_any`].
#[non_exhaustive]
#[derive(thiserror::Error, Debug)]
pub enum BoardSpecLoadError {
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error("parse error: {0}")]
    Parse(#[from] serde_json::Error),
    #[error("board JSON is missing required field '{0}'")]
    MissingField(&'static str),
    #[error("unknown dictionary '{0}' (tried '{0}' and 'DICT_{0}')")]
    UnknownDictionary(String),
}

/// Resolve a dictionary name tolerating both the prefixed (`DICT_4X4_1000`)
/// and un-prefixed (`4X4_1000`, `APRILTAG_36h10`) spellings used in
/// different tooling JSON files.
pub fn resolve_dictionary(name: &str) -> Option<Dictionary> {
    if let Some(d) = builtins::builtin_dictionary(name) {
        return Some(d);
    }
    let prefixed = format!("DICT_{name}");
    builtins::builtin_dictionary(&prefixed)
}

#[derive(Debug, Deserialize)]
struct RawBoardSpec {
    ncols: u32,
    nrows: u32,
    cellsize_mm: f32,
    marker_scale: f32,
    dict: String,
    #[serde(default)]
    layout: Option<MarkerLayout>,
}

impl RawBoardSpec {
    fn into_spec(self) -> Result<CharucoBoardSpec, BoardSpecLoadError> {
        let dict = resolve_dictionary(&self.dict)
            .ok_or_else(|| BoardSpecLoadError::UnknownDictionary(self.dict.clone()))?;
        Ok(CharucoBoardSpec {
            rows: self.nrows,
            cols: self.ncols,
            cell_size: self.cellsize_mm,
            marker_size_rel: self.marker_scale,
            dictionary: dict,
            marker_layout: self.layout.unwrap_or_default(),
        })
    }
}

/// Load a [`CharucoBoardSpec`] from JSON accepting either the flat
/// `board.json` layout (`{"ncols": ..., "dict": "..."}`) or the nested
/// `config.json` layout (`{"target": {"ncols": ..., "dict": "..."}}`).
///
/// Field names follow the printing-tool convention:
/// `ncols`, `nrows`, `cellsize_mm`, `marker_scale`, `dict`, optional `layout`.
pub fn load_board_spec_any(path: impl AsRef<Path>) -> Result<CharucoBoardSpec, BoardSpecLoadError> {
    let raw = std::fs::read_to_string(path.as_ref())?;
    let value: serde_json::Value = serde_json::from_str(&raw)?;

    let board_value = if let Some(inner) = value.get("target") {
        inner.clone()
    } else {
        value
    };

    let spec: RawBoardSpec = serde_json::from_value(board_value)?;
    spec.into_spec()
}

fn default_px_per_square() -> f32 {
    60.0
}

/// Configuration for the ChArUco detection example.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CharucoDetectConfig {
    pub image_path: String,
    pub board: CharucoBoardSpec,
    #[serde(default)]
    pub output_path: Option<String>,
    #[serde(default)]
    pub chess: ChessConfig,
    #[serde(default)]
    pub rectified_path: Option<String>,
    #[serde(default)]
    pub mesh_rectified_path: Option<String>,
    #[serde(default = "default_px_per_square")]
    pub px_per_square: f32,
    #[serde(default)]
    pub min_marker_inliers: Option<usize>,
    #[serde(default)]
    pub chessboard: Option<DetectorParams>,
    #[serde(default)]
    pub aruco: Option<ArucoScanConfig>,
}

impl CharucoDetectConfig {
    /// Load a JSON config from disk.
    pub fn load_json(path: impl AsRef<Path>) -> Result<Self, CharucoIoError> {
        io::load_json(path)
    }

    /// Write this config to disk as pretty JSON.
    pub fn write_json(&self, path: impl AsRef<Path>) -> Result<(), CharucoIoError> {
        io::write_json(self, path)
    }

    /// Resolve the output report path.
    pub fn output_path(&self) -> PathBuf {
        self.output_path
            .as_ref()
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("charuco_detect_report.json"))
    }

    /// Build a validated ChArUco board from the config.
    pub fn build_board(&self) -> Result<CharucoBoard, CharucoConfigError> {
        Ok(CharucoBoard::new(self.board)?)
    }

    /// Build detector parameters, applying overrides from the config.
    ///
    /// Note: the chessboard detector (`DetectorParams`) does not include a
    /// nested ChESS detector config — `cfg.chess` is consumed upstream by
    /// the corner-detection step (`calib_targets::detect_corners`), not by
    /// the chessboard stage itself.
    pub fn build_params(&self) -> CharucoParams {
        let mut params = CharucoParams::for_board(&self.board);
        params.px_per_square = self.px_per_square;
        if let Some(min_marker_inliers) = self.min_marker_inliers {
            params.min_marker_inliers = min_marker_inliers;
        }
        if let Some(chessboard) = self.chessboard.clone() {
            params.chessboard = chessboard;
        }
        if let Some(aruco) = self.aruco.as_ref() {
            if let Some(max_hamming) = aruco.max_hamming {
                params.max_hamming = max_hamming;
            }
            aruco.apply_to_scan(&mut params.scan);
        }
        params
    }

    /// Build a detector from this config.
    pub fn build_detector(&self) -> Result<CharucoDetector, CharucoConfigError> {
        let params = self.build_params();
        Ok(CharucoDetector::new(params)?)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CharucoDetectReport {
    pub image_path: String,
    pub config_path: String,
    pub board: CharucoBoardSpec,
    pub num_raw_corners: usize,
    pub raw_corners: Vec<Corner>,
    #[serde(default)]
    pub detection: Option<TargetDetection>,
    #[serde(default)]
    pub markers: Option<Vec<MarkerDetection>>,
    #[serde(default)]
    pub alignment: Option<GridAlignment>,
    #[serde(default)]
    pub error: Option<String>,
}

impl CharucoDetectReport {
    /// Build a base report from the input config and raw corners.
    pub fn new(cfg: &CharucoDetectConfig, config_path: &Path, raw_corners: Vec<Corner>) -> Self {
        Self {
            image_path: cfg.image_path.clone(),
            config_path: config_path.to_string_lossy().into_owned(),
            board: cfg.board,
            num_raw_corners: raw_corners.len(),
            raw_corners,
            detection: None,
            markers: None,
            alignment: None,
            error: None,
        }
    }

    /// Populate report fields from a successful detection.
    pub fn set_detection(&mut self, res: CharucoDetectionResult) {
        self.detection = Some(res.detection);
        self.markers = Some(res.markers);
        self.alignment = Some(res.alignment);
        self.error = None;
    }

    /// Record a detection error.
    pub fn set_error(&mut self, err: CharucoDetectError) {
        self.error = Some(err.to_string());
    }

    /// Load a report from JSON on disk.
    pub fn load_json(path: impl AsRef<Path>) -> Result<Self, CharucoIoError> {
        io::load_json(path)
    }

    /// Write this report to disk as pretty JSON.
    pub fn write_json(&self, path: impl AsRef<Path>) -> Result<(), CharucoIoError> {
        io::write_json(self, path)
    }
}
