from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Iterable

from .config import PuzzleBoardScoringMode
from .enums import CirclePolarity, TargetKind
from .results import (
    CellOffset,
    CharucoDetectionResult,
    ChessboardDebug,
    ChessboardDetectionResult,
    CircleCandidate,
    CircleMatch,
    GridAlignment,
    GridCoords,
    GridGraphDebug,
    GridGraphNeighbor,
    GridGraphNode,
    GridTransform,
    LabeledCorner,
    MarkerBoardDetectionResult,
    MarkerCircleExpectation,
    MarkerDetection,
    OrientationHistogram,
    PuzzleBoardObservedEdge,
    Point2,
    PuzzleBoardDecodeInfo,
    PuzzleBoardDetectionResult,
    TargetDetection,
)


def _ensure_mapping(value: Any, ctx: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise TypeError(f"{ctx} must be a mapping")
    out: dict[str, Any] = {}
    for key, item in value.items():
        if not isinstance(key, str):
            raise TypeError(f"{ctx} keys must be strings")
        out[key] = item
    return out


def _validate_keys(
    data: Mapping[str, Any],
    *,
    allowed: Iterable[str],
    required: Iterable[str] = (),
    ctx: str,
) -> None:
    allowed_set = set(allowed)
    required_set = set(required)
    keys = set(data.keys())

    unknown = sorted(keys - allowed_set)
    if unknown:
        valid = sorted(allowed_set)
        raise ValueError(f"{ctx}: unknown keys {unknown}; valid keys: {valid}")

    missing = sorted(required_set - keys)
    if missing:
        raise ValueError(f"{ctx}: missing required keys {missing}")


def _to_bool(value: Any, ctx: str) -> bool:
    if not isinstance(value, bool):
        raise TypeError(f"{ctx} must be bool")
    return value


def _to_int(value: Any, ctx: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{ctx} must be int")
    return int(value)


def _to_float(value: Any, ctx: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{ctx} must be float")
    return float(value)


def _to_sequence(value: Any, ctx: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        raise TypeError(f"{ctx} must be a sequence")
    return value


def _to_point2(value: Any, ctx: str) -> Point2:
    seq = _to_sequence(value, ctx)
    if len(seq) != 2:
        raise ValueError(f"{ctx} must have exactly 2 items")
    return (_to_float(seq[0], f"{ctx}[0]"), _to_float(seq[1], f"{ctx}[1]"))


def _to_corners4(value: Any, ctx: str) -> tuple[Point2, Point2, Point2, Point2]:
    seq = _to_sequence(value, ctx)
    if len(seq) != 4:
        raise ValueError(f"{ctx} must have exactly 4 points")
    return (
        _to_point2(seq[0], f"{ctx}[0]"),
        _to_point2(seq[1], f"{ctx}[1]"),
        _to_point2(seq[2], f"{ctx}[2]"),
        _to_point2(seq[3], f"{ctx}[3]"),
    )


def _to_int_list(value: Any, ctx: str) -> list[int]:
    seq = _to_sequence(value, ctx)
    return [_to_int(item, f"{ctx}[{idx}]") for idx, item in enumerate(seq)]


def _to_float_list(value: Any, ctx: str) -> list[float]:
    seq = _to_sequence(value, ctx)
    return [_to_float(item, f"{ctx}[{idx}]") for idx, item in enumerate(seq)]


def _to_target_kind(value: Any, ctx: str) -> TargetKind:
    if isinstance(value, TargetKind):
        return value
    if isinstance(value, str):
        try:
            return TargetKind(value)
        except ValueError as exc:
            valid = [member.value for member in TargetKind]
            raise ValueError(f"{ctx} must be one of {valid}") from exc
    raise TypeError(f"{ctx} must be TargetKind or str")


def _to_circle_polarity(value: Any, ctx: str) -> CirclePolarity:
    if isinstance(value, CirclePolarity):
        return value
    if isinstance(value, str):
        try:
            return CirclePolarity(value)
        except ValueError as exc:
            valid = [member.value for member in CirclePolarity]
            raise ValueError(f"{ctx} must be one of {valid}") from exc
    raise TypeError(f"{ctx} must be CirclePolarity or str")


def _to_edge_orientation(value: Any, ctx: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{ctx} must be str")
    if value not in {"horizontal", "vertical"}:
        raise ValueError(f"{ctx} must be 'horizontal' or 'vertical'")
    return value


def _point2_to_list(value: Point2) -> list[float]:
    return [float(value[0]), float(value[1])]


def _corners4_to_list(value: tuple[Point2, Point2, Point2, Point2]) -> list[list[float]]:
    return [_point2_to_list(value[0]), _point2_to_list(value[1]), _point2_to_list(value[2]), _point2_to_list(value[3])]


def _optional_point2(value: Any, ctx: str) -> Point2 | None:
    if value is None:
        return None
    return _to_point2(value, ctx)


# -------------------- basic structs --------------------


def grid_coords_to_dict(value: GridCoords) -> dict[str, Any]:
    return {"i": int(value.i), "j": int(value.j)}


def grid_coords_from_dict(data: Mapping[str, Any]) -> GridCoords:
    obj = _ensure_mapping(data, "GridCoords")
    _validate_keys(obj, allowed={"i", "j"}, required={"i", "j"}, ctx="GridCoords")
    return GridCoords(i=_to_int(obj["i"], "GridCoords.i"), j=_to_int(obj["j"], "GridCoords.j"))


def cell_offset_to_dict(value: CellOffset) -> dict[str, Any]:
    return {"di": int(value.di), "dj": int(value.dj)}


def cell_offset_from_dict(data: Mapping[str, Any]) -> CellOffset:
    obj = _ensure_mapping(data, "CellOffset")
    _validate_keys(obj, allowed={"di", "dj"}, required={"di", "dj"}, ctx="CellOffset")
    return CellOffset(
        di=_to_int(obj["di"], "CellOffset.di"),
        dj=_to_int(obj["dj"], "CellOffset.dj"),
    )


def grid_transform_to_dict(value: GridTransform) -> dict[str, Any]:
    return {
        "a": int(value.a),
        "b": int(value.b),
        "c": int(value.c),
        "d": int(value.d),
    }


def grid_transform_from_dict(data: Mapping[str, Any]) -> GridTransform:
    obj = _ensure_mapping(data, "GridTransform")
    _validate_keys(
        obj,
        allowed={"a", "b", "c", "d"},
        required={"a", "b", "c", "d"},
        ctx="GridTransform",
    )
    return GridTransform(
        a=_to_int(obj["a"], "GridTransform.a"),
        b=_to_int(obj["b"], "GridTransform.b"),
        c=_to_int(obj["c"], "GridTransform.c"),
        d=_to_int(obj["d"], "GridTransform.d"),
    )


def grid_alignment_to_dict(value: GridAlignment) -> dict[str, Any]:
    return {
        "transform": grid_transform_to_dict(value.transform),
        "translation": [int(value.translation[0]), int(value.translation[1])],
    }


def grid_alignment_from_dict(data: Mapping[str, Any]) -> GridAlignment:
    obj = _ensure_mapping(data, "GridAlignment")
    _validate_keys(
        obj,
        allowed={"transform", "translation"},
        required={"transform", "translation"},
        ctx="GridAlignment",
    )
    translation = _to_sequence(obj["translation"], "GridAlignment.translation")
    if len(translation) != 2:
        raise ValueError("GridAlignment.translation must have exactly 2 items")
    return GridAlignment(
        transform=grid_transform_from_dict(obj["transform"]),
        translation=(
            _to_int(translation[0], "GridAlignment.translation[0]"),
            _to_int(translation[1], "GridAlignment.translation[1]"),
        ),
    )


# -------------------- target detection --------------------


def labeled_corner_to_dict(value: LabeledCorner) -> dict[str, Any]:
    return {
        "position": _point2_to_list(value.position),
        "grid": grid_coords_to_dict(value.grid) if value.grid is not None else None,
        "id": int(value.id) if value.id is not None else None,
        "target_position": _point2_to_list(value.target_position)
        if value.target_position is not None
        else None,
        "score": float(value.score),
    }


def labeled_corner_from_dict(data: Mapping[str, Any]) -> LabeledCorner:
    obj = _ensure_mapping(data, "LabeledCorner")
    _validate_keys(
        obj,
        allowed={"position", "grid", "id", "target_position", "score"},
        required={"position", "grid", "id", "target_position", "score"},
        ctx="LabeledCorner",
    )
    grid_value = obj["grid"]
    id_value = obj["id"]
    return LabeledCorner(
        position=_to_point2(obj["position"], "LabeledCorner.position"),
        grid=grid_coords_from_dict(grid_value) if grid_value is not None else None,
        id=_to_int(id_value, "LabeledCorner.id") if id_value is not None else None,
        target_position=_optional_point2(
            obj["target_position"], "LabeledCorner.target_position"
        ),
        score=_to_float(obj["score"], "LabeledCorner.score"),
    )


def target_detection_to_dict(value: TargetDetection) -> dict[str, Any]:
    return {
        "kind": value.kind.value,
        "corners": [labeled_corner_to_dict(item) for item in value.corners],
    }


def target_detection_from_dict(data: Mapping[str, Any]) -> TargetDetection:
    obj = _ensure_mapping(data, "TargetDetection")
    _validate_keys(
        obj,
        allowed={"kind", "corners"},
        required={"kind", "corners"},
        ctx="TargetDetection",
    )
    corners = _to_sequence(obj["corners"], "TargetDetection.corners")
    return TargetDetection(
        kind=_to_target_kind(obj["kind"], "TargetDetection.kind"),
        corners=[labeled_corner_from_dict(item) for item in corners],
    )


def orientation_histogram_to_dict(value: OrientationHistogram) -> dict[str, Any]:
    return {
        "bin_centers": [float(item) for item in value.bin_centers],
        "values": [float(item) for item in value.values],
    }


def orientation_histogram_from_dict(data: Mapping[str, Any]) -> OrientationHistogram:
    obj = _ensure_mapping(data, "OrientationHistogram")
    _validate_keys(
        obj,
        allowed={"bin_centers", "values"},
        required={"bin_centers", "values"},
        ctx="OrientationHistogram",
    )
    return OrientationHistogram(
        bin_centers=_to_float_list(obj["bin_centers"], "OrientationHistogram.bin_centers"),
        values=_to_float_list(obj["values"], "OrientationHistogram.values"),
    )


# -------------------- chessboard debug/result --------------------


def grid_graph_neighbor_to_dict(value: GridGraphNeighbor) -> dict[str, Any]:
    return {
        "index": int(value.index),
        "direction": value.direction,
        "distance": float(value.distance),
    }


def grid_graph_neighbor_from_dict(data: Mapping[str, Any]) -> GridGraphNeighbor:
    obj = _ensure_mapping(data, "GridGraphNeighbor")
    _validate_keys(
        obj,
        allowed={"index", "direction", "distance"},
        required={"index", "direction", "distance"},
        ctx="GridGraphNeighbor",
    )
    direction = obj["direction"]
    if not isinstance(direction, str):
        raise TypeError("GridGraphNeighbor.direction must be str")
    return GridGraphNeighbor(
        index=_to_int(obj["index"], "GridGraphNeighbor.index"),
        direction=direction,
        distance=_to_float(obj["distance"], "GridGraphNeighbor.distance"),
    )


def grid_graph_node_to_dict(value: GridGraphNode) -> dict[str, Any]:
    return {
        "position": _point2_to_list(value.position),
        "neighbors": [grid_graph_neighbor_to_dict(item) for item in value.neighbors],
    }


def grid_graph_node_from_dict(data: Mapping[str, Any]) -> GridGraphNode:
    obj = _ensure_mapping(data, "GridGraphNode")
    _validate_keys(
        obj,
        allowed={"position", "neighbors"},
        required={"position", "neighbors"},
        ctx="GridGraphNode",
    )
    neighbors = _to_sequence(obj["neighbors"], "GridGraphNode.neighbors")
    return GridGraphNode(
        position=_to_point2(obj["position"], "GridGraphNode.position"),
        neighbors=[grid_graph_neighbor_from_dict(item) for item in neighbors],
    )


def grid_graph_debug_to_dict(value: GridGraphDebug) -> dict[str, Any]:
    return {"nodes": [grid_graph_node_to_dict(item) for item in value.nodes]}


def grid_graph_debug_from_dict(data: Mapping[str, Any]) -> GridGraphDebug:
    obj = _ensure_mapping(data, "GridGraphDebug")
    _validate_keys(obj, allowed={"nodes"}, required={"nodes"}, ctx="GridGraphDebug")
    nodes = _to_sequence(obj["nodes"], "GridGraphDebug.nodes")
    return GridGraphDebug(nodes=[grid_graph_node_from_dict(item) for item in nodes])


def chessboard_debug_to_dict(value: ChessboardDebug) -> dict[str, Any]:
    return {
        "orientation_histogram": orientation_histogram_to_dict(value.orientation_histogram)
        if value.orientation_histogram is not None
        else None,
        "graph": grid_graph_debug_to_dict(value.graph) if value.graph is not None else None,
    }


def chessboard_debug_from_dict(data: Mapping[str, Any]) -> ChessboardDebug:
    obj = _ensure_mapping(data, "ChessboardDebug")
    _validate_keys(
        obj,
        allowed={"orientation_histogram", "graph"},
        required={"orientation_histogram", "graph"},
        ctx="ChessboardDebug",
    )
    histogram = obj["orientation_histogram"]
    graph = obj["graph"]
    return ChessboardDebug(
        orientation_histogram=orientation_histogram_from_dict(histogram)
        if histogram is not None
        else None,
        graph=grid_graph_debug_from_dict(graph) if graph is not None else None,
    )


def chessboard_detection_result_to_dict(value: ChessboardDetectionResult) -> dict[str, Any]:
    return {
        "grid_directions": [
            float(value.grid_directions[0]),
            float(value.grid_directions[1]),
        ],
        "cell_size": float(value.cell_size),
        "target": target_detection_to_dict(value.detection),
        "strong_indices": [int(item) for item in value.strong_indices],
    }


def chessboard_detection_result_from_dict(
    data: Mapping[str, Any],
) -> ChessboardDetectionResult:
    # Rust shape: `{ grid_directions, cell_size, target,
    # strong_indices }`. Matches `serde_json::to_value(Detection)`
    # byte-for-byte.
    obj = _ensure_mapping(data, "ChessboardDetectionResult")
    _validate_keys(
        obj,
        allowed={"grid_directions", "cell_size", "target", "strong_indices"},
        required={"grid_directions", "cell_size", "target", "strong_indices"},
        ctx="ChessboardDetectionResult",
    )
    gd_seq = _to_sequence(obj["grid_directions"], "ChessboardDetectionResult.grid_directions")
    if len(gd_seq) != 2:
        raise ValueError("ChessboardDetectionResult.grid_directions must have 2 floats")
    grid_directions = (
        _to_float(gd_seq[0], "ChessboardDetectionResult.grid_directions[0]"),
        _to_float(gd_seq[1], "ChessboardDetectionResult.grid_directions[1]"),
    )
    return ChessboardDetectionResult(
        detection=target_detection_from_dict(obj["target"]),
        grid_directions=grid_directions,
        cell_size=_to_float(obj["cell_size"], "ChessboardDetectionResult.cell_size"),
        strong_indices=_to_int_list(
            obj["strong_indices"], "ChessboardDetectionResult.strong_indices"
        ),
    )


# -------------------- charuco/marker results --------------------


def marker_detection_to_dict(value: MarkerDetection) -> dict[str, Any]:
    return {
        "id": int(value.id),
        "gc": grid_coords_to_dict(value.gc),
        "rotation": int(value.rotation),
        "hamming": int(value.hamming),
        "score": float(value.score),
        "border_score": float(value.border_score),
        "code": int(value.code),
        "inverted": bool(value.inverted),
        "corners_rect": _corners4_to_list(value.corners_rect),
        "corners_img": _corners4_to_list(value.corners_img)
        if value.corners_img is not None
        else None,
    }


def marker_detection_from_dict(data: Mapping[str, Any]) -> MarkerDetection:
    obj = _ensure_mapping(data, "MarkerDetection")
    _validate_keys(
        obj,
        allowed={
            "id",
            "gc",
            "rotation",
            "hamming",
            "score",
            "border_score",
            "code",
            "inverted",
            "corners_rect",
            "corners_img",
        },
        required={
            "id",
            "gc",
            "rotation",
            "hamming",
            "score",
            "border_score",
            "code",
            "inverted",
            "corners_rect",
            "corners_img",
        },
        ctx="MarkerDetection",
    )
    corners_img_raw = obj["corners_img"]
    return MarkerDetection(
        id=_to_int(obj["id"], "MarkerDetection.id"),
        gc=grid_coords_from_dict(obj["gc"]),
        rotation=_to_int(obj["rotation"], "MarkerDetection.rotation"),
        hamming=_to_int(obj["hamming"], "MarkerDetection.hamming"),
        score=_to_float(obj["score"], "MarkerDetection.score"),
        border_score=_to_float(obj["border_score"], "MarkerDetection.border_score"),
        code=_to_int(obj["code"], "MarkerDetection.code"),
        inverted=_to_bool(obj["inverted"], "MarkerDetection.inverted"),
        corners_rect=_to_corners4(obj["corners_rect"], "MarkerDetection.corners_rect"),
        corners_img=_to_corners4(corners_img_raw, "MarkerDetection.corners_img")
        if corners_img_raw is not None
        else None,
    )


def circle_candidate_to_dict(value: CircleCandidate) -> dict[str, Any]:
    return {
        "center_img": _point2_to_list(value.center_img),
        "cell": grid_coords_to_dict(value.cell),
        "polarity": value.polarity.value,
        "score": float(value.score),
        "contrast": float(value.contrast),
    }


def circle_candidate_from_dict(data: Mapping[str, Any]) -> CircleCandidate:
    obj = _ensure_mapping(data, "CircleCandidate")
    _validate_keys(
        obj,
        allowed={"center_img", "cell", "polarity", "score", "contrast"},
        required={"center_img", "cell", "polarity", "score", "contrast"},
        ctx="CircleCandidate",
    )
    return CircleCandidate(
        center_img=_to_point2(obj["center_img"], "CircleCandidate.center_img"),
        cell=grid_coords_from_dict(obj["cell"]),
        polarity=_to_circle_polarity(obj["polarity"], "CircleCandidate.polarity"),
        score=_to_float(obj["score"], "CircleCandidate.score"),
        contrast=_to_float(obj["contrast"], "CircleCandidate.contrast"),
    )


def marker_circle_expectation_to_dict(value: MarkerCircleExpectation) -> dict[str, Any]:
    return {
        "cell": grid_coords_to_dict(value.cell),
        "polarity": value.polarity.value,
    }


def marker_circle_expectation_from_dict(data: Mapping[str, Any]) -> MarkerCircleExpectation:
    obj = _ensure_mapping(data, "MarkerCircleExpectation")
    _validate_keys(
        obj,
        allowed={"cell", "polarity"},
        required={"cell", "polarity"},
        ctx="MarkerCircleExpectation",
    )
    return MarkerCircleExpectation(
        cell=grid_coords_from_dict(obj["cell"]),
        polarity=_to_circle_polarity(obj["polarity"], "MarkerCircleExpectation.polarity"),
    )


def circle_match_to_dict(value: CircleMatch) -> dict[str, Any]:
    return {
        "expected": marker_circle_expectation_to_dict(value.expected),
        "matched_index": int(value.matched_index) if value.matched_index is not None else None,
        "distance_cells": float(value.distance_cells)
        if value.distance_cells is not None
        else None,
        "offset_cells": cell_offset_to_dict(value.offset_cells)
        if value.offset_cells is not None
        else None,
    }


def circle_match_from_dict(data: Mapping[str, Any]) -> CircleMatch:
    obj = _ensure_mapping(data, "CircleMatch")
    _validate_keys(
        obj,
        allowed={"expected", "matched_index", "distance_cells", "offset_cells"},
        required={"expected", "matched_index", "distance_cells", "offset_cells"},
        ctx="CircleMatch",
    )
    matched_index = obj["matched_index"]
    distance_cells = obj["distance_cells"]
    offset_cells = obj["offset_cells"]
    return CircleMatch(
        expected=marker_circle_expectation_from_dict(obj["expected"]),
        matched_index=_to_int(matched_index, "CircleMatch.matched_index")
        if matched_index is not None
        else None,
        distance_cells=_to_float(distance_cells, "CircleMatch.distance_cells")
        if distance_cells is not None
        else None,
        offset_cells=cell_offset_from_dict(offset_cells)
        if offset_cells is not None
        else None,
    )


def charuco_detection_result_to_dict(value: CharucoDetectionResult) -> dict[str, Any]:
    return {
        "detection": target_detection_to_dict(value.detection),
        "markers": [marker_detection_to_dict(item) for item in value.markers],
        "alignment": grid_alignment_to_dict(value.alignment),
        "raw_marker_count": int(value.raw_marker_count),
        "raw_marker_wrong_id_count": int(value.raw_marker_wrong_id_count),
    }


def charuco_detection_result_from_dict(data: Mapping[str, Any]) -> CharucoDetectionResult:
    obj = _ensure_mapping(data, "CharucoDetectionResult")
    _validate_keys(
        obj,
        allowed={
            "detection",
            "markers",
            "alignment",
            "raw_marker_count",
            "raw_marker_wrong_id_count",
        },
        required={"detection", "markers", "alignment"},
        ctx="CharucoDetectionResult",
    )
    markers = _to_sequence(obj["markers"], "CharucoDetectionResult.markers")
    return CharucoDetectionResult(
        detection=target_detection_from_dict(obj["detection"]),
        markers=[marker_detection_from_dict(item) for item in markers],
        alignment=grid_alignment_from_dict(obj["alignment"]),
        raw_marker_count=int(obj.get("raw_marker_count", 0)),
        raw_marker_wrong_id_count=int(obj.get("raw_marker_wrong_id_count", 0)),
    )


def marker_board_detection_result_to_dict(
    value: MarkerBoardDetectionResult,
) -> dict[str, Any]:
    return {
        "detection": target_detection_to_dict(value.detection),
        "inliers": [int(item) for item in value.inliers],
        "circle_candidates": [circle_candidate_to_dict(item) for item in value.circle_candidates],
        "circle_matches": [circle_match_to_dict(item) for item in value.circle_matches],
        "alignment": grid_alignment_to_dict(value.alignment)
        if value.alignment is not None
        else None,
        "alignment_inliers": int(value.alignment_inliers),
    }


def marker_board_detection_result_from_dict(
    data: Mapping[str, Any],
) -> MarkerBoardDetectionResult:
    obj = _ensure_mapping(data, "MarkerBoardDetectionResult")
    _validate_keys(
        obj,
        allowed={
            "detection",
            "inliers",
            "circle_candidates",
            "circle_matches",
            "alignment",
            "alignment_inliers",
        },
        required={
            "detection",
            "inliers",
            "circle_candidates",
            "circle_matches",
            "alignment",
            "alignment_inliers",
        },
        ctx="MarkerBoardDetectionResult",
    )
    circle_candidates = _to_sequence(
        obj["circle_candidates"], "MarkerBoardDetectionResult.circle_candidates"
    )
    circle_matches = _to_sequence(
        obj["circle_matches"], "MarkerBoardDetectionResult.circle_matches"
    )
    alignment = obj["alignment"]
    return MarkerBoardDetectionResult(
        detection=target_detection_from_dict(obj["detection"]),
        inliers=_to_int_list(obj["inliers"], "MarkerBoardDetectionResult.inliers"),
        circle_candidates=[circle_candidate_from_dict(item) for item in circle_candidates],
        circle_matches=[circle_match_from_dict(item) for item in circle_matches],
        alignment=grid_alignment_from_dict(alignment) if alignment is not None else None,
        alignment_inliers=_to_int(
            obj["alignment_inliers"], "MarkerBoardDetectionResult.alignment_inliers"
        ),
    )


# -------------------- puzzleboard results --------------------


def observed_edge_to_dict(value: PuzzleBoardObservedEdge) -> dict[str, Any]:
    return {
        "row": int(value.row),
        "col": int(value.col),
        "orientation": _to_edge_orientation(
            value.orientation, "PuzzleBoardObservedEdge.orientation"
        ),
        "bit": int(value.bit),
        "confidence": float(value.confidence),
    }


def observed_edge_from_dict(data: Mapping[str, Any]) -> PuzzleBoardObservedEdge:
    obj = _ensure_mapping(data, "PuzzleBoardObservedEdge")
    _validate_keys(
        obj,
        allowed={"row", "col", "orientation", "bit", "confidence"},
        required={"row", "col", "orientation", "bit", "confidence"},
        ctx="PuzzleBoardObservedEdge",
    )
    bit = _to_int(obj["bit"], "PuzzleBoardObservedEdge.bit")
    if bit not in (0, 1):
        raise ValueError("PuzzleBoardObservedEdge.bit must be 0 or 1")
    return PuzzleBoardObservedEdge(
        row=_to_int(obj["row"], "PuzzleBoardObservedEdge.row"),
        col=_to_int(obj["col"], "PuzzleBoardObservedEdge.col"),
        orientation=_to_edge_orientation(
            obj["orientation"], "PuzzleBoardObservedEdge.orientation"
        ),
        bit=bit,
        confidence=_to_float(obj["confidence"], "PuzzleBoardObservedEdge.confidence"),
    )


def puzzleboard_decode_info_to_dict(value: PuzzleBoardDecodeInfo) -> dict[str, Any]:
    out = {
        "edges_observed": int(value.edges_observed),
        "edges_matched": int(value.edges_matched),
        "mean_confidence": float(value.mean_confidence),
        "bit_error_rate": float(value.bit_error_rate),
        "master_origin_row": int(value.master_origin_row),
        "master_origin_col": int(value.master_origin_col),
    }
    if value.score_best is not None:
        out["score_best"] = float(value.score_best)
    if value.score_runner_up is not None:
        out["score_runner_up"] = float(value.score_runner_up)
    if value.score_margin is not None:
        out["score_margin"] = float(value.score_margin)
    if value.runner_up_origin_row is not None:
        out["runner_up_origin_row"] = int(value.runner_up_origin_row)
    if value.runner_up_origin_col is not None:
        out["runner_up_origin_col"] = int(value.runner_up_origin_col)
    if value.runner_up_transform is not None:
        out["runner_up_transform"] = grid_transform_to_dict(value.runner_up_transform)
    if value.scoring_mode is not None:
        out["scoring_mode"] = value.scoring_mode.to_dict()
    return out


def puzzleboard_decode_info_from_dict(data: Mapping[str, Any]) -> PuzzleBoardDecodeInfo:
    obj = _ensure_mapping(data, "PuzzleBoardDecodeInfo")
    _validate_keys(
        obj,
        allowed={
            "edges_observed",
            "edges_matched",
            "mean_confidence",
            "bit_error_rate",
            "master_origin_row",
            "master_origin_col",
            "score_best",
            "score_runner_up",
            "score_margin",
            "runner_up_origin_row",
            "runner_up_origin_col",
            "runner_up_transform",
            "scoring_mode",
        },
        required={
            "edges_observed",
            "edges_matched",
            "mean_confidence",
            "bit_error_rate",
            "master_origin_row",
            "master_origin_col",
        },
        ctx="PuzzleBoardDecodeInfo",
    )
    return PuzzleBoardDecodeInfo(
        edges_observed=_to_int(obj["edges_observed"], "PuzzleBoardDecodeInfo.edges_observed"),
        edges_matched=_to_int(obj["edges_matched"], "PuzzleBoardDecodeInfo.edges_matched"),
        mean_confidence=_to_float(
            obj["mean_confidence"], "PuzzleBoardDecodeInfo.mean_confidence"
        ),
        bit_error_rate=_to_float(obj["bit_error_rate"], "PuzzleBoardDecodeInfo.bit_error_rate"),
        master_origin_row=_to_int(
            obj["master_origin_row"], "PuzzleBoardDecodeInfo.master_origin_row"
        ),
        master_origin_col=_to_int(
            obj["master_origin_col"], "PuzzleBoardDecodeInfo.master_origin_col"
        ),
        score_best=(
            _to_float(obj["score_best"], "PuzzleBoardDecodeInfo.score_best")
            if "score_best" in obj
            else None
        ),
        score_runner_up=(
            _to_float(obj["score_runner_up"], "PuzzleBoardDecodeInfo.score_runner_up")
            if "score_runner_up" in obj
            else None
        ),
        score_margin=(
            _to_float(obj["score_margin"], "PuzzleBoardDecodeInfo.score_margin")
            if "score_margin" in obj
            else None
        ),
        runner_up_origin_row=(
            _to_int(
                obj["runner_up_origin_row"],
                "PuzzleBoardDecodeInfo.runner_up_origin_row",
            )
            if "runner_up_origin_row" in obj
            else None
        ),
        runner_up_origin_col=(
            _to_int(
                obj["runner_up_origin_col"],
                "PuzzleBoardDecodeInfo.runner_up_origin_col",
            )
            if "runner_up_origin_col" in obj
            else None
        ),
        runner_up_transform=(
            grid_transform_from_dict(
                _ensure_mapping(
                    obj["runner_up_transform"],
                    "PuzzleBoardDecodeInfo.runner_up_transform",
                )
            )
            if "runner_up_transform" in obj
            else None
        ),
        scoring_mode=(
            PuzzleBoardScoringMode.from_dict(
                _ensure_mapping(obj["scoring_mode"], "PuzzleBoardDecodeInfo.scoring_mode")
            )
            if "scoring_mode" in obj
            else None
        ),
    )


def puzzleboard_detection_result_to_dict(
    value: PuzzleBoardDetectionResult,
) -> dict[str, Any]:
    return {
        "detection": target_detection_to_dict(value.detection),
        "alignment": grid_alignment_to_dict(value.alignment),
        "decode": puzzleboard_decode_info_to_dict(value.decode),
        "observed_edges": [observed_edge_to_dict(item) for item in value.observed_edges],
    }


def puzzleboard_detection_result_from_dict(
    data: Mapping[str, Any],
) -> PuzzleBoardDetectionResult:
    obj = _ensure_mapping(data, "PuzzleBoardDetectionResult")
    _validate_keys(
        obj,
        allowed={"detection", "alignment", "decode", "observed_edges"},
        required={"detection", "alignment", "decode", "observed_edges"},
        ctx="PuzzleBoardDetectionResult",
    )
    observed_edges = _to_sequence(
        obj["observed_edges"], "PuzzleBoardDetectionResult.observed_edges"
    )
    return PuzzleBoardDetectionResult(
        detection=target_detection_from_dict(obj["detection"]),
        alignment=grid_alignment_from_dict(obj["alignment"]),
        decode=puzzleboard_decode_info_from_dict(obj["decode"]),
        observed_edges=[observed_edge_from_dict(item) for item in observed_edges],
    )


__all__ = [
    "grid_coords_to_dict",
    "grid_coords_from_dict",
    "cell_offset_to_dict",
    "cell_offset_from_dict",
    "grid_transform_to_dict",
    "grid_transform_from_dict",
    "grid_alignment_to_dict",
    "grid_alignment_from_dict",
    "labeled_corner_to_dict",
    "labeled_corner_from_dict",
    "target_detection_to_dict",
    "target_detection_from_dict",
    "orientation_histogram_to_dict",
    "orientation_histogram_from_dict",
    "grid_graph_neighbor_to_dict",
    "grid_graph_neighbor_from_dict",
    "grid_graph_node_to_dict",
    "grid_graph_node_from_dict",
    "grid_graph_debug_to_dict",
    "grid_graph_debug_from_dict",
    "chessboard_debug_to_dict",
    "chessboard_debug_from_dict",
    "chessboard_detection_result_to_dict",
    "chessboard_detection_result_from_dict",
    "marker_detection_to_dict",
    "marker_detection_from_dict",
    "circle_candidate_to_dict",
    "circle_candidate_from_dict",
    "marker_circle_expectation_to_dict",
    "marker_circle_expectation_from_dict",
    "circle_match_to_dict",
    "circle_match_from_dict",
    "charuco_detection_result_to_dict",
    "charuco_detection_result_from_dict",
    "marker_board_detection_result_to_dict",
    "marker_board_detection_result_from_dict",
    "observed_edge_to_dict",
    "observed_edge_from_dict",
    "puzzleboard_decode_info_to_dict",
    "puzzleboard_decode_info_from_dict",
    "puzzleboard_detection_result_to_dict",
    "puzzleboard_detection_result_from_dict",
]
