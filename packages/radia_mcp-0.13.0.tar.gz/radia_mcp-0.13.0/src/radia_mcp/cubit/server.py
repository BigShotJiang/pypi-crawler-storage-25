"""
Cubit Mesh Export MCP Server

Provides tools for:
- Export function documentation (Gmsh, Nastran, Netgen, Exodus)
- Netgen/NGSolve high-order curving workflows (SetGeomInfo, name-based)
- Cubit scripting patterns and best practices
- Cubit Python API reference (600+ functions, entity classes)
- Linting Python scripts for Cubit export convention violations

Usage:
    python server.py              # Start MCP server (stdio transport)
    python server.py --selftest   # Run self-test on examples/
"""

import json
import os
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

# Import knowledge bases and rules (relative imports for pip package)
from .rules import ALL_RULES
from .export_knowledge import get_export_documentation
from .netgen_workflow_knowledge import get_netgen_documentation
from .cubit_scripting_knowledge import get_cubit_documentation
from .cubit_forum_tips import get_forum_tips
from .cubit_api_reference import get_api_reference
from .panel_conventions_knowledge import PANEL_CONVENTIONS, LABEL_GUIDE
from ..common import failure_log as _fl
from ..common import web_docs as _wd
from ..common import examples as _ex

# Create MCP server
mcp = FastMCP("cubit-export")

# Project root (current working directory for pip-installed package)
PROJECT_ROOT = Path.cwd()


# ============================================================
# Lint helpers
# ============================================================

def _lint_file(filepath: str) -> list[dict]:
	"""Run all lint rules on a single file."""
	try:
		with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
			lines = f.readlines()
	except (OSError, IOError) as e:
		return [{'line': 0, 'severity': 'ERROR', 'rule': 'read-error',
		         'message': f'Cannot read file: {e}'}]

	findings = []
	for rule_fn in ALL_RULES:
		findings.extend(rule_fn(filepath, lines))

	# Sort by severity, then line number
	severity_order = {'CRITICAL': 0, 'HIGH': 1, 'MODERATE': 2, 'LOW': 3, 'ERROR': -1}
	findings.sort(key=lambda f: (severity_order.get(f['severity'], 9), f['line']))
	return findings


def _format_findings(filepath: str, findings: list[dict]) -> str:
	"""Format findings for display."""
	if not findings:
		return f"[OK] {filepath}: No issues found."

	lines = [f"[{len(findings)} issue(s)] {filepath}:"]
	for f in findings:
		lines.append(
			f"  L{f['line']:>4d} [{f['severity']}] {f['rule']}: {f['message']}"
		)
	return '\n'.join(lines)


# ============================================================
# Netgen code examples
# ============================================================

EXAMPLES = {}

EXAMPLES['cylinder'] = '''# Cylinder with radia_export netgen (high-order curving)
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF, BND
import cubit

R, H, ORDER = 0.5, 2.0, 3

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create cylinder height {H} radius {R}")

# Mesh
cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.15")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

# Export with curving via C++ APREPRO command
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

expected_vol = math.pi * R**2 * H
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['sphere'] = '''# Sphere with radia_export netgen
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

R, ORDER = 0.5, 3

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create sphere radius {R}")

cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.1")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

expected_vol = 4/3 * math.pi * R**3
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['torus'] = '''# Torus with radia_export netgen
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

R_MAJOR, R_MINOR, ORDER = 1.0, 0.3, 3

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create torus major {R_MAJOR} minor {R_MINOR}")

cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.08")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

expected_vol = 2 * math.pi**2 * R_MAJOR * R_MINOR**2
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['cone'] = '''# Cone with radia_export netgen
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

R_BASE, H, ORDER = 0.5, 2.0, 3

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create cone height {H} radius {R_BASE} top 0")

cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.1")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

expected_vol = 1/3 * math.pi * R_BASE**2 * H
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['hex_cylinder'] = '''# Hex-meshed Cylinder with radia_export netgen
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

R, H = 0.5, 2.0

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create cylinder height {H} radius {R}")

# Hex meshing requires webcut for cylinder
cubit.cmd("webcut volume all with plane xplane")
cubit.cmd("webcut volume all with plane yplane")
cubit.cmd("merge all")
cubit.cmd("volume all scheme auto")
cubit.cmd("volume all size 0.15")
cubit.cmd("mesh volume all")

cubit.cmd("block 1 add volume all")

vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order 3 overwrite')
mesh = Mesh(vol_path)

expected_vol = math.pi * R**2 * H
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['complex_named'] = '''# Complex Geometry with Boolean Operations (radia_export netgen)
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

BRICK_SIZE, R_HOLE, ORDER = 2.0, 0.3, 3

# Create geometry directly in Cubit (no OCC needed!)
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create brick x {BRICK_SIZE} y {BRICK_SIZE} z {BRICK_SIZE}")
cubit.cmd(f"create cylinder height {BRICK_SIZE*2} radius {R_HOLE}")
cubit.cmd("subtract volume 2 from volume 1")

# Mesh
cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.15")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

# Export with curving via C++ APREPRO command
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

expected_vol = BRICK_SIZE**3 - math.pi * R_HOLE**2 * BRICK_SIZE
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['vol_2nd_order'] = '''# Netgen .vol 2nd Order Export (Recommended Workflow)
import sys, os, math
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

R = 1.0

cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create sphere radius {R}")
cubit.cmd("volume 1 scheme tetmesh")
cubit.cmd("volume 1 size 0.2")
cubit.cmd("mesh volume 1")

# Register blocks
cubit.cmd("block 1 add volume 1")
cubit.cmd('block 1 name "sphere"')

# Export to Netgen .vol (order 2 with ACIS curving)
cubit.cmd('radia_export netgen "sphere.vol" order 2 overwrite')

# Read into NGSolve
mesh = Mesh("sphere.vol")

expected_vol = 4/3 * math.pi * R**3
vol = Integrate(CF(1), mesh)
print(f"Volume error: {abs(vol-expected_vol)/expected_vol*100:.4f}%")
'''

EXAMPLES['poisson_sphere'] = '''# Complete FEM Example: Poisson on Sphere
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import *
import cubit

R, ORDER = 1.0, 3

# --- Mesh generation ---
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
cubit.cmd(f"create sphere radius {R}")
cubit.cmd("volume all scheme tetmesh")
cubit.cmd("volume all size 0.2")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")
cubit.cmd('block 1 name "domain"')

# --- Export with curving via C++ APREPRO command ---
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {ORDER} overwrite')
mesh = Mesh(vol_path)

# --- Solve Poisson equation ---
fes = H1(mesh, order=ORDER, dirichlet="boundary")
u, v = fes.TnT()

a = BilinearForm(fes)
a += grad(u) * grad(v) * dx
a.Assemble()

f = LinearForm(fes)
f += 1 * v * dx
f.Assemble()

gfu = GridFunction(fes)
gfu.vec.data = a.mat.Inverse(fes.FreeDofs()) * f.vec

print(f"DOFs: {fes.ndof}")
print(f"Integral of solution: {Integrate(gfu, mesh):.6f}")
'''


# ============================================================
# Tools
# ============================================================

@mcp.tool()
def cubit_docs(topic: str = "all") -> str:
	"""
	Get Cubit documentation: export formats, scripting guide, and API reference.

	Unified documentation tool covering export functions, Python scripting
	patterns, and the Cubit API (600+ functions). Use topic prefixes to
	navigate: export_*, scripting_*, api_*.

	Args:
	    topic: Documentation topic. Options:
	        "all"                    - Overview of all categories
	        --- Export formats ---
	        "export_overview"        - All export commands overview
	        "gmsh_v2"               - Gmsh v4.1 format (radia_export gmsh)
	        "gmsh_v4"               - Gmsh v4.1 format policy
	        "netgen"                - Netgen .vol export (radia_export netgen)
	        "nastran"               - Nastran BDF (radia_export nastran)
	        "exodus"                - Exodus II (Cubit built-in)
	        "export_comparison"     - Format comparison and decision matrix
	        "export_decision_guide" - Decision tree for format selection
	        --- Scripting guide ---
	        "scripting_overview"     - Why Cubit, element types, workflow
	        "scripting_lab_policy"   - Role split vs build123d (hex vs tet), translation guidance
	        "scripting_build123d_crossref" - Cubit `.jou` ↔ build123d mapping table
	        "scripting_blocks"       - Block registration
	        "scripting_blocks_only_policy" - Why blocks only (no nodesets/sidesets)
	        "scripting_element_order"  - 1st/2nd order, connectivity APIs
	        "scripting_mesh_schemes"   - tetmesh, map, sweep, trimesh
	        "scripting_step_exchange"  - STEP import/export, heal vs noheal
	        "scripting_initialization" - Cubit Python init boilerplate
	        "scripting_mixed_elements" - Mixed element types and warnings
	        "scripting_common_mistakes" - Frequent Cubit API pitfalls
	        "scripting_hex_workflow"    - Hexahedral mesh generation
	        "scripting_tet_workflow"    - Tetrahedral mesh generation
	        "scripting_2d_mesh"         - 2D surface meshing and export
	        "scripting_troubleshooting" - Common problems and debugging
	        "scripting_design_philosophy" - Why module reads Python API
	        "scripting_aprepro_journal"  - Running scripts via play command
	        --- API reference ---
	        "api_core"               - cmd, parse_cubit_list, init, naming
	        "api_geometry_queries"   - center_point, bounding_box, normals
	        "api_mesh_access"        - connectivity, nodal_coordinates
	        "api_blocks_sets"        - block/nodeset/sideset/group functions
	        "api_mesh_settings"      - scheme, size, intervals, quality
	        "api_entity_classes"     - Volume, Surface, Curve, Vertex
	        "api_graphics_selection" - Graphics control, selection
	        "api_advanced"           - Merge detection, geometry analysis
	        --- Radia-NGSolve panels ---
	        "panel_conventions"      - Analysis window conventions (TITLE, LABELS, etc.)
	        "panel_labels"           - Label guide (blocks/sidesets -> .vol -> NGSolve)
	"""
	topic = topic.lower().strip()

	if topic == "all":
		return (
			"# Cubit Documentation\n\n"
			"Use topic prefixes to navigate:\n"
			"- `export_*` - Export format documentation (gmsh_v2, netgen, nastran, etc.)\n"
			"- `scripting_*` - Python scripting guide (blocks, mesh_schemes, etc.)\n"
			"- `api_*` - API reference (core, geometry_queries, mesh_access, etc.)\n"
			"- `panel_*` - Radia-NGSolve analysis window conventions\n\n"
			+ get_export_documentation("overview")
		)

	# Export topics: strip prefix
	if topic.startswith("export_"):
		return get_export_documentation(topic[7:])  # remove "export_"

	# Scripting topics: strip prefix
	if topic.startswith("scripting_"):
		return get_cubit_documentation(topic[10:])  # remove "scripting_"

	# API topics: strip prefix
	if topic.startswith("api_"):
		return get_api_reference(topic[4:])  # remove "api_"

	# Panel topics
	if topic == "panel_conventions":
		return PANEL_CONVENTIONS
	if topic == "panel_labels":
		return LABEL_GUIDE

	# Try without prefix (backward compat for simple names)
	result = get_export_documentation(topic)
	if not result.startswith("Unknown"):
		return result
	result = get_cubit_documentation(topic)
	if not result.startswith("Unknown"):
		return result
	result = get_api_reference(topic)
	if not result.startswith("Unknown"):
		return result

	return (
		f"Unknown topic: '{topic}'. Use prefixes: export_*, scripting_*, api_*. "
		f"Examples: export_overview, scripting_blocks, api_core"
	)


@mcp.tool()
def netgen_workflow_guide(workflow: str = "overview") -> str:
	"""
	Get step-by-step Netgen/NGSolve workflow documentation.

	The Netgen high-order curving workflow is complex, involving Cubit meshing,
	OCC geometry, STEP exchange, and SetGeomInfo UV parameters. This tool
	provides detailed guidance for each workflow variant.

	Args:
	    workflow: Workflow to document. Options:
	        "overview"          - Decision tree: which workflow to use
	        "radia_export netgen"     - radia_export netgen() API reference
	        "simple_cylinder"   - Cylinder example
	        "simple_sphere"     - Sphere example
	        "simple_torus"      - Torus example
	        "complex"           - Complex geometry (Boolean operations, any shape)
	        "accuracy"          - Accuracy guide: order selection and verification
	        "kelvin_auto"       - Kelvin auto-add (auto R, symmetry, mesh copy)
	        "gmsh_2nd_order"    - Alternative: Gmsh 2nd order (simplest)
	        "troubleshooting"   - Common errors and fixes
	        "deleted_apis"      - Migration guide from old APIs
	"""
	return get_netgen_documentation(workflow)


@mcp.tool()
def netgen_code_example(shape: str = "cylinder") -> str:
	"""
	Get a ready-to-run Netgen export code example.

	Returns a complete Python script for exporting Cubit mesh to Netgen
	with high-order curving. Each example follows the recommended workflow.

	Args:
	    shape: Geometry shape for the example. Options:
	        "cylinder"       - Cylinder with radia_export netgen
	        "sphere"         - Sphere with radia_export netgen
	        "torus"          - Torus with radia_export netgen
	        "cone"           - Cone with radia_export netgen
	        "hex_cylinder"   - Hex-meshed cylinder with radia_export netgen
	        "complex_named"  - Boolean geometry with radia_export netgen
	        "gmsh_2nd_order" - Gmsh 2nd order alternative (simplest)
	        "poisson_sphere" - Complete FEM: Poisson equation on sphere
	"""
	shape = shape.lower().strip()
	if shape in EXAMPLES:
		return EXAMPLES[shape]
	else:
		return (
			f"Unknown shape: '{shape}'. "
			f"Available: {', '.join(EXAMPLES.keys())}"
		)


@mcp.tool()
def cubit_forum_tips(topic: str = "all") -> str:
	"""
	Get practical Cubit meshing tips sourced from the Coreform forum.

	Real-world solutions to common meshing problems, collected from
	forum.coreform.com discussions with high view counts.

	Args:
	    topic: Tip category. Options:
	        "all"                  - All tips
	        "mesh_quality"         - Smoothing, Jacobian fixes, quality diagnostics
	        "biased_graded"        - Curve bias, circle scheme, auto factor, refinement
	        "hex_decomposition"    - Webcut patterns, torus meshing, embedded spheres
	        "sweep_tips"           - Transform translate, copy mesh, interval matching
	        "parallel_meshing"     - HPC tetmesher, multiprocessing pattern
	        "python_api"           - Entity names, connectivity, batch mode, STL engine
	        "export_tips"          - Abaqus parts, Exodus sizing, LS-DYNA
	        "geometry_healing"     - STEP/STL import, heal, stitch, bounding voids
	        "sculpt_workflow"      - Sculpt setup, command-line, capture, HEX27
	        "boundary_layer"       - BL setup, reversal nodes fix, composite surface
	        "python_performance"   - Performance settings, batch queries, entity tracking
	        "quality_diagnostics"  - Quality extraction, bad element selection, normals
	        "solver_workflows"     - FEniCS, VTK, CalculiX, OpenFOAM integration
	        "advanced_meshing"     - Void, crack, dome, hemisphere, topography, THex

	    For troubleshooting, use cubit_docs(topic="scripting_troubleshooting").
	"""
	return get_forum_tips(topic)


@mcp.tool()
def lint_cubit_script(filepath: str) -> str:
	"""
	Lint a Python script for Cubit mesh export convention violations.

	Checks for (16 rules):
	- Missing block registration before export (CRITICAL)
	- Missing mesh command before export (CRITICAL)
	- Geometry block with 2nd order conversion (HIGH)
	- Missing cubit.init() (HIGH)
	- get_connectivity instead of get_expanded_connectivity for 2nd order (HIGH)
	- Element type set before adding to block (HIGH)
	- Deleted SetGeomInfo API usage (CRITICAL)
	- nodeset/sideset usage with blocks-only export formats (HIGH)
	- Deleted API usage (export_netgen, set_*_geominfo, name_occ_faces) (CRITICAL)
	- Deleted STEP reimport / name-based workflow APIs (CRITICAL)
	- Hardcoded absolute paths (MODERATE)
	- Missing boundary element block for Netgen (MODERATE)
	- Wrong file extension for export format (MODERATE)
	- mesh.Curve() without radia_export netgen (MODERATE)
	- Blocks registered without names (LOW)

	Args:
	    filepath: Absolute or relative path to the Python file to check.
	"""
	p = Path(filepath)
	if not p.is_absolute():
		p = PROJECT_ROOT / p

	if not p.exists():
		return f"Error: File not found: {p}"
	if not p.suffix == '.py':
		return f"Error: Not a Python file: {p}"

	findings = _lint_file(str(p))
	return _format_findings(str(p), findings)


@mcp.tool()
def lint_cubit_directory(directory: str = "examples") -> str:
	"""
	Lint all Python scripts in a directory for Cubit export convention violations.

	Recursively scans .py files and reports findings grouped by file.

	Args:
	    directory: Directory path relative to project root (default: "examples").
	"""
	d = Path(directory)
	if not d.is_absolute():
		d = PROJECT_ROOT / d

	if not d.exists():
		return f"Error: Directory not found: {d}"

	# Collect all .py files
	py_files = sorted(d.rglob("*.py"))

	if not py_files:
		return f"No Python files found in {directory}."

	# Lint all files
	total_findings = 0
	file_results = []
	summary_by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MODERATE': 0, 'LOW': 0}

	for py_file in py_files:
		findings = _lint_file(str(py_file))
		if findings:
			total_findings += len(findings)
			rel_path = py_file.relative_to(PROJECT_ROOT) if py_file.is_relative_to(PROJECT_ROOT) else py_file
			file_results.append(_format_findings(str(rel_path), findings))
			for f in findings:
				sev = f['severity']
				if sev in summary_by_severity:
					summary_by_severity[sev] += 1

	# Build output
	output_parts = [
		f"Cubit Export Lint Report: {len(py_files)} files scanned, {total_findings} issues found.",
		"",
		f"Summary: {summary_by_severity['CRITICAL']} CRITICAL, "
		f"{summary_by_severity['HIGH']} HIGH, "
		f"{summary_by_severity['MODERATE']} MODERATE, "
		f"{summary_by_severity['LOW']} LOW",
		"",
	]

	if file_results:
		output_parts.append("=" * 70)
		output_parts.extend(file_results)
	else:
		output_parts.append("All files passed!")

	return '\n'.join(output_parts)


# ============================================================
# New tools: script generation and mesh quality
# ============================================================

SCRIPT_TEMPLATES = {}

SCRIPT_TEMPLATES['tet_netgen'] = '''# Cubit -> NGSolve: Tet mesh with high-order curving (radia_export netgen)
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF, BND
import cubit

# === PARAMETERS ===
MESH_SIZE = 0.15
CURVE_ORDER = 3

# === GEOMETRY ===
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
# TODO: Create your geometry here
# cubit.cmd("create cylinder height 2 radius 0.5")

# === MESH ===
cubit.cmd("volume all scheme tetmesh")
cubit.cmd(f"volume all size {MESH_SIZE}")
cubit.cmd("mesh volume all")

# === BLOCKS ===
cubit.cmd("block 1 add volume all")
cubit.cmd('block 1 name "domain"')

# === EXPORT WITH CURVING (C++ APREPRO command) ===
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {CURVE_ORDER} overwrite')
mesh = Mesh(vol_path)

# === VERIFY ===
vol = Integrate(CF(1), mesh)
area = Integrate(CF(1), mesh, VOL_or_BND=BND)
print(f"Volume: {vol:.6f}, Surface area: {area:.6f}")
'''

SCRIPT_TEMPLATES['tet_netgen_named'] = '''# Cubit -> NGSolve: Complex geometry with Boolean operations (radia_export netgen)
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF, BND
import cubit

MESH_SIZE = 0.15
CURVE_ORDER = 3

# === GEOMETRY (create directly in Cubit) ===
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
# TODO: Build your geometry using Cubit Boolean operations
# cubit.cmd("create brick x 2 y 2 z 2")
# cubit.cmd("create cylinder height 4 radius 0.3")
# cubit.cmd("subtract volume 2 from volume 1")

# === MESH ===
cubit.cmd("volume all scheme tetmesh")
cubit.cmd(f"volume all size {MESH_SIZE}")
cubit.cmd("mesh volume all")
cubit.cmd("block 1 add volume all")

# === EXPORT WITH CURVING (C++ APREPRO command) ===
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {CURVE_ORDER} overwrite')
mesh = Mesh(vol_path)

vol = Integrate(CF(1), mesh)
print(f"Volume: {vol:.6f}")
'''

SCRIPT_TEMPLATES['tet_vol'] = '''# Cubit -> Netgen .vol 2nd order (recommended workflow)
import sys, os
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

MESH_SIZE = 0.15

# === GEOMETRY AND MESH ===
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
# TODO: Create your geometry
# cubit.cmd("create sphere radius 1")
cubit.cmd("volume all scheme tetmesh")
cubit.cmd(f"volume all size {MESH_SIZE}")
cubit.cmd("mesh volume all")

# === BLOCKS ===
cubit.cmd("block 1 add volume all")

# === EXPORT (.vol with order 2 curving) ===
cubit.cmd('radia_export netgen "mesh.vol" order 2 overwrite')

# === IMPORT TO NGSOLVE ===
mesh = Mesh("mesh.vol")
vol = Integrate(CF(1), mesh)
print(f"Volume: {vol:.6f}")
'''

SCRIPT_TEMPLATES['hex_netgen'] = '''# Cubit -> NGSolve: Hex mesh with high-order curving (radia_export netgen)
import sys, os, math, tempfile
cubit_path = os.environ.get("CUBIT_PATH")
if cubit_path:
    sys.path.append(cubit_path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ngsolve import Mesh, Integrate, CF
import cubit

MESH_SIZE = 0.15
CURVE_ORDER = 3

# === GEOMETRY ===
cubit.init(['cubit', '-nojournal', '-batch'])
cubit.cmd("reset")
# TODO: Create your geometry
# cubit.cmd("create cylinder height 2 radius 0.5")

# === HEX MESH (may need webcut for non-sweepable geometries) ===
# cubit.cmd("webcut volume all with plane xplane")
# cubit.cmd("webcut volume all with plane yplane")
# cubit.cmd("merge all")
cubit.cmd("volume all scheme auto")
cubit.cmd(f"volume all size {MESH_SIZE}")
cubit.cmd("mesh volume all")

# === BLOCKS ===
cubit.cmd("block 1 add volume all")
cubit.cmd('block 1 name "domain"')

# === EXPORT WITH CURVING (C++ APREPRO command) ===
vol_path = tempfile.mktemp(suffix='.vol')
cubit.cmd(f'radia_export netgen "{vol_path}" order {CURVE_ORDER} overwrite')
mesh = Mesh(vol_path)

vol = Integrate(CF(1), mesh)
print(f"Volume: {vol:.6f}")
'''

MESH_QUALITY_KNOWLEDGE = """
# Mesh Quality Guide

## Quality Metrics in Cubit

```python
# Check overall mesh quality
cubit.cmd("quality volume all shape")        # Shape metric (0-1, higher=better)
cubit.cmd("quality volume all aspect ratio") # Aspect ratio (1=ideal)
cubit.cmd("quality volume all jacobian")     # Jacobian (must be >0)
cubit.cmd("quality volume all condition")    # Condition number
```

## Minimum Requirements by Application

| Application | Shape | Aspect Ratio | Jacobian |
|-------------|-------|-------------|----------|
| General FEM | > 0.2 | < 10 | > 0 |
| High-order curving | > 0.3 | < 5 | > 0 |
| Radia BEM (hex) | > 0.5 | < 3 | > 0 (convex) |
| CFD | > 0.3 | < 5 | > 0 |

## Improving Mesh Quality

### Tetrahedral Meshes
```python
# Reduce element size
cubit.cmd("volume 1 size 0.05")

# Use quality-based smoothing
cubit.cmd("volume 1 smooth scheme condition number beta 2 cpu 10")
cubit.cmd("smooth volume 1")

# Webcut for better element shapes
cubit.cmd("webcut volume 1 with plane xplane")
```

### Hexahedral Meshes
```python
# Interval control for uniformity
cubit.cmd("curve 1 interval 10")

# Auto scheme selection
cubit.cmd("volume 1 scheme auto")

# Smoothing after meshing
cubit.cmd("smooth volume 1")
```

## Element Count Guidelines

```python
# Check counts
n_tet = cubit.get_tet_count()
n_hex = cubit.get_hex_count()
n_tri = cubit.get_tri_count()
n_quad = cubit.get_quad_count()
print(f"3D: {n_tet} tet + {n_hex} hex, 2D: {n_tri} tri + {n_quad} quad")
```

| Element Count | Suitability |
|---------------|-------------|
| < 1,000 | Quick prototyping, coarse analysis |
| 1,000 - 10,000 | Standard analysis |
| 10,000 - 100,000 | Fine analysis, convergence studies |
| > 100,000 | Very fine, may need parallel solver |

## Common Quality Issues

### 1. Negative Jacobian (Invalid Elements)
- **Cause**: Collapsed or inverted elements
- **Fix**: Refine mesh, webcut complex regions, use tet instead of hex

### 2. High Aspect Ratio
- **Cause**: Non-uniform sizing, thin geometry features
- **Fix**: Local size control, bias on curves

### 3. Poor Shape Quality Near Curved Surfaces
- **Cause**: Mesh doesn't follow curvature well
- **Fix**: Smaller element size near curved surfaces
  ```python
  cubit.cmd("surface 1 size 0.02")  # Finer on specific surface
  ```

### 4. Transition Element Issues
- **Cause**: Size transition too abrupt
- **Fix**: Gradual size change
  ```python
  cubit.cmd("volume 1 sizing function type skeleton scale 1.5")
  ```
"""


@mcp.tool()
def generate_cubit_script(workflow: str = "tet_netgen") -> str:
	"""
	Generate a template Cubit Python script for common workflows.

	Returns a ready-to-customize script with TODO markers for
	geometry-specific sections. Follows all project conventions.

	Args:
	    workflow: Script template to generate. Options:
	        "tet_netgen"       - Tet mesh -> radia_export netgen with ACIS curving
	        "tet_netgen_named" - Complex geometry with radia_export netgen
	        "tet_gmsh"         - Tet mesh -> Netgen .vol 2nd order (simplest)
	        "hex_netgen"       - Hex mesh -> radia_export netgen with curving
	"""
	workflow = workflow.lower().strip()
	if workflow in SCRIPT_TEMPLATES:
		return SCRIPT_TEMPLATES[workflow]
	else:
		return (
			f"Unknown workflow: '{workflow}'. "
			f"Available: {', '.join(SCRIPT_TEMPLATES.keys())}"
		)


@mcp.tool()
def get_lint_rules() -> str:
	"""
	List all available Cubit export lint rules with descriptions.

	Returns a summary of each rule including its name, severity,
	description, and fix guidance. Useful for understanding what
	the linter checks before running lint_cubit_script.
	"""
	rules_info = [
		{
			'rule': 'missing-block-registration',
			'severity': 'CRITICAL',
			'description': 'Export function called but no block registration found.',
			'trigger': 'radia_export gmsh without any block/mesh',
			'fix': 'cubit.cmd("block 1 add tet all")',
		},
		{
			'rule': 'missing-mesh-command',
			'severity': 'CRITICAL',
			'description': 'Export function called but no mesh command found.',
			'trigger': 'radia_export without mesh volume/surface command',
			'fix': 'cubit.cmd("mesh volume all")',
		},
		{
			'rule': 'geometry-block-2nd-order',
			'severity': 'HIGH',
			'description': 'Geometry block (volume/surface) used with element type conversion. Has no effect.',
			'trigger': 'block 1 add volume 1 + block 1 element type tetra10',
			'fix': 'Use mesh elements: block 1 add tet all in volume 1',
		},
		{
			'rule': 'missing-cubit-init',
			'severity': 'HIGH',
			'description': 'Script imports cubit but does not call cubit.init().',
			'trigger': 'import cubit without cubit.init()',
			'fix': "cubit.init(['cubit', '-nojournal', '-batch'])",
		},
		{
			'rule': 'wrong-connectivity-2nd-order',
			'severity': 'HIGH',
			'description': 'get_connectivity() used with 2nd order elements. Returns only corner nodes.',
			'trigger': 'block 1 element type tetra10 + get_connectivity("tet", tid)',
			'fix': 'Use get_expanded_connectivity("tet", tid)',
		},
		{
			'rule': 'element-type-before-add',
			'severity': 'HIGH',
			'description': 'Element type set before elements added to block. Type gets reset.',
			'trigger': 'block 1 element type tetra10 before block 1 add tet all',
			'fix': 'Add elements first, then set element type',
		},
		{
			'rule': 'deleted-api-usage',
			'severity': 'CRITICAL',
			'description': 'Deleted API (export_netgen, set_*_geominfo, name_occ_faces) detected.',
			'trigger': 'Any usage of export_netgen, export_NetgenMesh, set_*_geominfo, name_occ_faces',
			'fix': 'Use radia_export netgen "f.vol" order N',
		},
		{
			'rule': 'nodeset-sideset-usage',
			'severity': 'HIGH',
			'description': 'nodeset/sideset commands found with non-Exodus export. Blocks-only policy.',
			'trigger': 'nodeset/sideset with non-Exodus export',
			'fix': 'Use blocks: cubit.cmd("block 2 add tri all in surface 1")',
		},
		{
			'rule': 'deleted-api-usage',
			'severity': 'CRITICAL',
			'description': '(See above) Catches all deleted API usage.',
			'trigger': 'export_netgen_with_names, name_occ_faces',
			'fix': 'Use radia_export netgen "f.vol" order N',
		},
		{
			'rule': 'deleted-api-usage',
			'severity': 'CRITICAL',
			'description': '(See above) Catches export_netgen and other deleted APIs.',
			'trigger': 'export_netgen(cubit, geometry=geo)',
			'fix': 'Use radia_export netgen "f.vol" order N',
		},
		{
			'rule': 'deleted-api-noheal',
			'severity': 'INFO',
			'description': 'Name-based workflow (name_occ_faces + noheal) is deleted. Use radia_export netgen.',
			'trigger': 'name_occ_faces(shape) + STEP import',
			'fix': 'Use radia_export netgen(cubit, order=N) - no STEP needed',
		},
		{
			'rule': 'hardcoded-absolute-path',
			'severity': 'MODERATE',
			'description': 'Hardcoded absolute paths in sys.path (except Coreform Cubit/NGSolve).',
			'trigger': 'sys.path.insert(0, "S:/Projects/mymodule")',
			'fix': 'sys.path.insert(0, os.path.dirname(__file__))',
		},
		{
			'rule': 'missing-boundary-block',
			'severity': 'MODERATE',
			'description': 'Volume element block found but no surface element block for Netgen export.',
			'trigger': 'block 1 add tet all + radia_export netgen(...) without tri block',
			'fix': 'cubit.cmd("block 2 add tri all")',
		},
		{
			'rule': 'wrong-file-extension',
			'severity': 'MODERATE',
			'description': 'Export file extension does not match the format.',
			'trigger': 'radia_export gmsh "mesh.vtk" (wrong extension)',
			'fix': 'Use correct extension: .msh, .bdf, .exo, .vol',
		},
		{
			'rule': 'curve-without-export-curved',
			'severity': 'MODERATE',
			'description': 'Manual mesh.Curve() is not needed. radia_export netgen embeds curving in .vol.',
			'trigger': 'mesh.Curve(3) without radia_export netgen',
			'fix': 'Use cubit.cmd(\'radia_export netgen "mesh.vol" order 3 overwrite\') then mesh = Mesh("mesh.vol")',
		},
		{
			'rule': 'missing-block-names',
			'severity': 'LOW',
			'description': 'Blocks registered without name command. Named blocks improve readability.',
			'trigger': 'block 1 add tet all without block 1 name "..."',
			'fix': 'cubit.cmd(\'block 1 name "domain"\')',
		},
		{
			'rule': 'non-ascii-byte',
			'severity': 'HIGH',
			'description': 'Non-ASCII byte in Python file. Cubit cp932 (Japanese Windows) will crash.',
			'trigger': 'Em dash, smart quotes, or any non-ASCII character in .py loaded by Cubit',
			'fix': 'Replace with ASCII equivalents: -- instead of em dash, straight quotes, etc.',
		},
		{
			'rule': 'missing-qt-import',
			'severity': 'HIGH',
			'description': 'Qt class used but not imported. Causes NameError at runtime in Cubit.',
			'trigger': 'QMenu(...) without "from PySide6.QtWidgets import QMenu"',
			'fix': 'Add the missing class to PySide6/PyQt5 import statement.',
		},
	]

	lines = ["# Cubit Export Lint Rules (16 rules)", ""]
	for r in rules_info:
		lines.append(f"## [{r['severity']}] {r['rule']}")
		lines.append(f"{r['description']}")
		lines.append(f"- **Trigger**: {r['trigger']}")
		lines.append(f"- **Fix**: `{r['fix']}`")
		lines.append("")

	return '\n'.join(lines)


# ============================================================
# Cubit GUI launcher (Cheap phase of LLM-driven Cubit loop)
# ============================================================
#
# Motivation (2026-04-19): in the collaborative workflow (student +
# Claude Code in VSCode), the student wants to drive mesh creation via
# LLM but watch the result in Cubit's own native window (not OCP).
# Phase split:
#   - Cheap (this tool): each call launches a fresh Cubit GUI process
#     with a wrapper .jou that either imports a file or executes a
#     list of commands. Cubit stays open; student inspects, closes,
#     or triggers another round.  Slow loop but zero dev cost.
#   - Medium (TODO): use Cubit's Python binding
#     (C:/Program Files/Coreform Cubit 2025.3/bin/python3/) to drive a
#     persistent Cubit process in-process — sub-second command cycles.
#     Requires binding mode that keeps GUI alive; experimental.


@mcp.tool()
def open_in_cubit(path: str = "",
                  commands: list = None,
                  cubit_exe: str = "",
                  detach: bool = True) -> str:
	"""
	Open a file, or execute a list of commands, in **Cubit GUI**.
	This is the "Cheap phase" of the LLM→Cubit loop: each invocation
	launches a fresh Cubit GUI process so the student can watch the
	result in Cubit's native window. Use for inspection / measurement
	after Claude generates a .jou.

	File-type dispatch (by extension):
	  .jou  → `playback "<path>"`
	  .step .stp → `import step "<path>"`
	  .brep .brp → `import acis "<path>"`  (Cubit uses ACIS for BREP)
	  .msh         → `import mesh "<path>"`
	  .vol         → `import mesh "<path>"`  (Netgen .vol passes through)
	  .g .e .exo   → `import mesh "<path>"`
	Any `commands` given are appended AFTER the file load (useful for
	"import this STEP then mesh it").

	Args:
	    path: file to open in Cubit. Leave empty to run only `commands`.
	    commands: extra Cubit commands to run after loading. Each item
	        is one line (no trailing newline).
	    cubit_exe: override Cubit binary path.
	    detach: if True (default), return immediately after launching
	        Cubit; student interacts with the GUI window. If False,
	        wait for Cubit to exit and return its output (useful for
	        smoke tests or headless CI).

	Returns:
	    JSON with launch status, pid (when detach=True), wrapper .jou
	    path (kept for the student to inspect/edit), exit code (when
	    detach=False), and a copy of the commands that were issued.
	"""
	import json as _json
	import subprocess as _sp
	import tempfile as _tf
	from pathlib import Path

	exe = cubit_exe or _DEFAULT_CUBIT_EXE
	if not Path(exe).exists():
		return _json.dumps({"status": "error", "stage": "cubit_binary",
		                    "error": f"Cubit exe not found: {exe}"})

	work = Path(_tf.mkdtemp(prefix="cubit_gui_"))
	wrapper = work / "wrapper.jou"
	lines = []

	if path:
		p = Path(path)
		if not p.is_absolute():
			p = PROJECT_ROOT / p
		if not p.exists():
			return _json.dumps({"status": "error", "stage": "input",
			                    "error": f"File not found: {p}"})
		abs_path = str(p.resolve()).replace("\\", "/")
		suffix = p.suffix.lower()
		if suffix == ".jou":
			lines.append(f'playback "{abs_path}"')
		elif suffix in (".step", ".stp"):
			lines.append(f'import step "{abs_path}"')
		elif suffix in (".brep", ".brp"):
			# Cubit imports BREP via the ACIS kernel.
			lines.append(f'import acis "{abs_path}"')
		elif suffix in (".msh", ".vol", ".g", ".e", ".exo"):
			lines.append(f'import mesh "{abs_path}"')
		else:
			return _json.dumps({"status": "error", "stage": "input",
			                    "error": f"Unsupported extension: {suffix}"})

	if commands:
		lines.extend(str(c).rstrip() for c in commands)

	if not lines:
		return _json.dumps({"status": "error", "stage": "input",
		                    "error": "Either `path` or `commands` is required."})

	wrapper.write_text("\n".join(lines) + "\n")

	# GUI mode: no -batch, no -nographics. -nojournal prevents auto-
	# journaling of the wrapper playback (keeps the directory clean).
	# -input <wrapper> plays our commands after GUI initialization.
	cmd = [exe, "-nojournal", "-input", str(wrapper)]

	try:
		if detach:
			proc = _sp.Popen(
				cmd,
				stdout=_sp.DEVNULL,
				stderr=_sp.DEVNULL,
				creationflags=getattr(_sp, "DETACHED_PROCESS", 0)
				             | getattr(_sp, "CREATE_NEW_PROCESS_GROUP", 0),
			)
			info = {
				"status": "ok",
				"mode": "gui_detached",
				"pid": proc.pid,
				"wrapper": str(wrapper),
				"commands": lines,
				"note": ("Cubit GUI launched. Student: inspect in the "
				         "Cubit window. Close the Cubit window when done."),
			}
		else:
			proc = _sp.run(cmd, capture_output=True, text=True, timeout=180)
			info = {
				"status": "ok",
				"mode": "gui_blocking",
				"exit": proc.returncode,
				"wrapper": str(wrapper),
				"commands": lines,
				"stdout_tail": proc.stdout[-400:] if proc.stdout else "",
				"stderr_tail": proc.stderr[-400:] if proc.stderr else "",
			}
	except _sp.TimeoutExpired:
		return _json.dumps({"status": "error", "stage": "timeout",
		                    "wrapper": str(wrapper)})
	except OSError as e:
		return _json.dumps({"status": "error", "stage": "launch",
		                    "error": str(e)})

	return _json.dumps(info, indent=2)


# ============================================================
# Cubit Viewer Session tools (OCP-inspired persistent daemon)
# ============================================================
#
# Design note (2026-04-19): these tools drive a long-lived Cubit GUI
# via a JSON-RPC daemon running under Cubit's bundled Python 3.10.
# Launch cost is paid once (~0.7s init); subsequent commands are
# <1 ms. The daemon is auto-discovered via `find_cubit_install()`
# (env > registry > glob), so there is no hardcoded version path.
#
# The design follows OCP CAD Viewer's architecture (stateless client
# calls + persistent viewer) transposed to Cubit: Cubit itself plays
# the role of OCP's WebView, and this mcp-server plays the role of
# OCP's Python client.

from . import cubit_session as _cs


def _cubit_session_or_error():
    """Lazy-init the singleton; return (session, None) or (None, err_json)."""
    try:
        sess = _cs.CubitSession.get()
        sess.ensure_started()
        return sess, None
    except _cs.CubitSessionError as e:
        err = {
            "status": "error",
            "stage": "session_init",
            "error": str(e),
            "hint": ("Ensure Coreform Cubit is installed. "
                     "Override path with `set_cubit_bin_dir(path)` or "
                     "`CUBIT_BIN_DIR` environment variable."),
        }
        return None, json.dumps(err, indent=2)


def _cubit_path_dispatch(path: Path) -> str:
    """Map a file extension to the matching Cubit import command."""
    suffix = path.suffix.lower()
    abs_path = str(path.resolve()).replace("\\", "/")
    if suffix == ".jou":
        return f'playback "{abs_path}"'
    if suffix in (".step", ".stp"):
        return f'import step "{abs_path}"'
    if suffix in (".brep", ".brp"):
        return f'import acis "{abs_path}"'
    if suffix in (".msh", ".vol", ".g", ".e", ".exo"):
        return f'import mesh "{abs_path}"'
    raise ValueError(f"Unsupported extension for Cubit viewer: {suffix}")


@mcp.tool()
def cubit_show(path: str = "", extra_commands: list = None) -> str:
	"""
	Load a file into the **persistent Cubit viewer** and optionally run
	follow-up commands. First call launches the daemon + Cubit GUI;
	subsequent calls reuse the session (sub-second command cycles).

	Supported inputs: .jou (playback), .step/.stp (import step), .brep
	(import acis), .msh/.vol/.g/.e/.exo (import mesh).

	Args:
	    path: file to load. Leave empty to run only `extra_commands`.
	    extra_commands: extra Cubit commands to run after loading.

	Returns JSON with the per-command results (line + ok + rc).
	"""
	from pathlib import Path as _P
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err

	cmds = []
	if path:
		p = _P(path)
		if not p.is_absolute():
			p = PROJECT_ROOT / p
		if not p.exists():
			return json.dumps({"status": "error", "stage": "input",
			                   "error": f"File not found: {p}"})
		try:
			cmds.append(_cubit_path_dispatch(p))
		except ValueError as e:
			return json.dumps({"status": "error", "stage": "input",
			                   "error": str(e)})
	if extra_commands:
		cmds.extend(str(c).rstrip() for c in extra_commands)
	if not cmds:
		return json.dumps({"status": "error", "stage": "input",
		                   "error": "Either `path` or `extra_commands` is required."})

	try:
		r = sess.call("cmd", cmds)
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc",
		                   "error": str(e)})
	return json.dumps(r, indent=2)


def _probe_summary_safe(sess) -> dict:
	"""Best-effort `probe summary`. Swallows RPC errors."""
	try:
		r = sess.call("probe", ["summary"], timeout_s=15)
	except Exception:
		return {}
	res = r.get("result") if isinstance(r, dict) else None
	return res if isinstance(res, dict) else {}


def _state_delta(before: dict, after: dict) -> dict:
	"""Per-key delta (after - before). Zero / missing keys omitted."""
	keys = set(before) | set(after)
	delta: dict = {}
	for k in keys:
		try:
			a = int(after.get(k, 0) or 0)
			b = int(before.get(k, 0) or 0)
			if a - b != 0:
				delta[k] = a - b
		except (TypeError, ValueError):
			continue
	return delta


@mcp.tool()
def cubit_exec(commands: list) -> str:
	"""
	Send arbitrary Cubit commands to the persistent viewer session.

	Use this for incremental modelling / meshing driven by the LLM:
	each call appends commands to the running Cubit session, which
	the student can watch live in Cubit's GUI window.

	Args:
	    commands: list of Cubit command strings (one per list item, no
	        trailing newline). Runs in order; stops at first failure.

	Returns JSON with:
	  - `result`: per-command {line, ok, rc|error}
	  - `state_before` / `state_after`: volume/surface/node/hex/tet counts
	  - `state_delta`: what changed (e.g., {"hexes": +4740, "nodes": +6210})
	  - `all_ok`: true iff every command reported ok
	  - `failed_at`: 1-based index of first failure (if any)
	  - `hint`: short advice on the failure (from heuristics + failure log)

	On a Cubit error, `ok=false` on the offending line and subsequent
	commands are NOT executed so the viewer's state stays inspectable.
	Failures are also appended to the persistent failure log so
	`cubit_lookup` and `cubit_recent_failures` can surface them later.
	"""
	if not commands:
		return json.dumps({"status": "error",
		                   "error": "commands list cannot be empty"})
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err

	cmd_list = [str(c).rstrip() for c in commands]
	before = _probe_summary_safe(sess)
	try:
		r = sess.call("cmd", cmd_list)
	except _cs.CubitSessionError as e:
		_fl.record_failure("cubit", {
			"input": cmd_list,
			"error": str(e),
			"stage": "rpc",
			"context": {"state_before": before},
		})
		return json.dumps({"status": "error", "stage": "rpc",
		                   "error": str(e),
		                   "hint": "Cubit daemon RPC failed. "
		                           "Session auto-restarts on next call "
		                           "(state lost). Consider cubit_checkpoint "
		                           "before risky ops."})
	after = _probe_summary_safe(sess)

	per_line = r.get("result") if isinstance(r, dict) else r
	if not isinstance(per_line, list):
		per_line = []
	all_ok = all(step.get("ok") for step in per_line) if per_line else False
	failed_at = None
	first_err = None
	for idx, step in enumerate(per_line, start=1):
		if not step.get("ok"):
			failed_at = idx
			first_err = step.get("error") or f"rc={step.get('rc')}"
			break

	payload: dict = {
		"status": "ok" if all_ok else "error",
		"all_ok": all_ok,
		"executed": len(per_line),
		"submitted": len(cmd_list),
		"result": per_line,
		"state_before": before,
		"state_after": after,
		"state_delta": _state_delta(before, after),
	}
	if failed_at is not None:
		payload["failed_at"] = failed_at
		payload["failed_cmd"] = cmd_list[failed_at - 1] if failed_at <= len(cmd_list) else None
		payload["error"] = (first_err or "").strip()[:600]
		payload["hint"] = _cubit_failure_hint(payload["failed_cmd"] or "",
		                                       payload["error"])
		_fl.record_failure("cubit", {
			"input": cmd_list,
			"failed_cmd": payload["failed_cmd"],
			"failed_at": failed_at,
			"error": payload["error"],
			"context": {"state_before": before, "state_after": after},
		})
	if isinstance(r, dict) and r.get("_recovered"):
		payload["_recovered"] = True
		payload["hint"] = ((payload.get("hint", "") or "")
		                   + " NOTE: Cubit session was auto-restarted; "
		                     "geometry/mesh state is lost.").strip()
	return json.dumps(payload, indent=2)


_CUBIT_ERROR_HEURISTICS: list[tuple[str, str]] = [
	("unknown command",  "Check Cubit reference via `cubit_docs(topic='syntax')` "
	                     "or `cubit_web_docs(source='cubit', query='<keyword>')`."),
	("parse",            "Command syntax issue. Try `cubit_lookup(query='<verb>')` for examples."),
	("no such",          "Entity (volume/surface/vertex) does not exist. Run `cubit_probe('summary')` first."),
	("cannot mesh",      "Try `cubit_mesh_diagnose()` to propose scheme alternatives per volume."),
	("scheme",           "Meshing scheme problem. `cubit_mesh_diagnose()` or set `volume all scheme tetmesh`."),
	("sweep",            "Sweep failed. Geometry is likely non-prismatic. Fall back to `scheme tetmesh`."),
	("import",           "Import failed. Verify the path exists and format matches "
	                     "(`import step`, `import acis`, `import mesh`)."),
	("export",           "Export failed. Check `cubit_docs(topic='export')` and that mesh exists."),
]


def _cubit_failure_hint(cmd: str, err: str) -> str:
	"""Pick a short hint from common Cubit error patterns."""
	blob = (cmd + " " + err).lower()
	for needle, advice in _CUBIT_ERROR_HEURISTICS:
		if needle in blob:
			return advice
	return ("No specific heuristic matched. Try `cubit_lookup(query=...)` "
	        "or `cubit_web_docs(source='cubit', query=...)` with keywords "
	        "from the error.")


@mcp.tool()
def cubit_probe(query: str = "summary") -> str:
	"""
	Query the Cubit session for geometry/mesh statistics.

	Valid queries:
	  "summary"  — {volumes, surfaces, curves, vertices, nodes, hexes, tets}
	  "volume_count", "surface_count", "curve_count", "vertex_count"
	  "node_count", "hex_count", "tet_count"

	Args:
	    query: probe name, see list above.
	"""
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	try:
		r = sess.call("probe", [query])
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc",
		                   "error": str(e)})
	return json.dumps(r, indent=2)


@mcp.tool()
def cubit_snapshot(out_path: str,
                   width: int = 800,
                   height: int = 600) -> str:
	"""
	Hardcopy the current Cubit view to a PNG file.

	Use for paper/slide figures from an LLM-driven session, or for
	a cheap "visual diff" after a command sequence.  GUI mode is
	strongly recommended; batch-mode screenshots may be empty.

	Args:
	    out_path: PNG output path (absolute or relative to project root).
	    width, height: pixel dimensions (defaults 800x600).
	"""
	from pathlib import Path as _P
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	p = _P(out_path)
	if not p.is_absolute():
		p = PROJECT_ROOT / p
	abs_path = str(p.resolve()).replace("\\", "/")
	try:
		r = sess.call("snapshot", [abs_path, int(width), int(height)])
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc",
		                   "error": str(e)})
	return json.dumps(r, indent=2)


@mcp.tool()
def cubit_session_status() -> str:
	"""Return diagnostic info about the Cubit session (pid, alive, bin_dir)."""
	status = {
		"bin_dir": str(_cs.get_cubit_bin_dir() or "<not found>"),
		"alive": False,
		"pid": None,
		"ready_info": None,
	}
	if _cs._SINGLETON is not None:
		status["alive"] = _cs._SINGLETON.is_alive()
		if _cs._SINGLETON._proc is not None:
			status["pid"] = _cs._SINGLETON._proc.pid
		status["ready_info"] = _cs._SINGLETON._ready_info
	return json.dumps(status, indent=2)


@mcp.tool()
def cubit_session_shutdown() -> str:
	"""Stop the persistent Cubit daemon. Next `cubit_show` relaunches."""
	if _cs._SINGLETON is None or not _cs._SINGLETON.is_alive():
		return json.dumps({"status": "ok", "note": "no session running"})
	_cs.CubitSession.reset()
	return json.dumps({"status": "ok", "note": "session stopped"})


# ============================================================
# Checkpoint / restore (Cubit .cub5 snapshot-based undo)
# ============================================================

def _checkpoints_dir() -> Path:
	"""Per-user directory for named Cubit state snapshots."""
	d = Path.home() / ".cubit_viewer" / "checkpoints"
	d.mkdir(parents=True, exist_ok=True)
	return d


def _sanitize_label(label: str) -> str:
	"""Keep only safe filename characters; reject empty."""
	import re
	s = re.sub(r"[^A-Za-z0-9._-]+", "_", label).strip("_")
	if not s:
		raise ValueError("checkpoint label must not be empty after sanitization")
	if len(s) > 64:
		s = s[:64]
	return s


@mcp.tool()
def cubit_checkpoint(label: str) -> str:
	"""Save the current Cubit session state as a named checkpoint.

	Creates `~/.cubit_viewer/checkpoints/<label>.cub5`. Overwrites if the
	label already exists. Use `cubit_restore(label)` to rewind.

	Lightweight undo pattern: save a checkpoint before risky operations
	(mesh, boolean, large imports), then restore if the result is bad.

	Args:
	    label: checkpoint name (alphanumeric, dot, dash, underscore only).
	"""
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	try:
		safe = _sanitize_label(label)
	except ValueError as e:
		return json.dumps({"status": "error", "error": str(e)})
	path = _checkpoints_dir() / f"{safe}.cub5"
	fwd = str(path).replace("\\", "/")
	try:
		r = sess.call("cmd", [f'save as "{fwd}" overwrite'], timeout_s=120)
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc", "error": str(e)})
	if not r.get("ok"):
		return json.dumps({"status": "error", "stage": "save", "detail": r})
	return json.dumps({
		"status": "ok",
		"label": safe,
		"path": str(path),
		"size_bytes": path.stat().st_size if path.exists() else 0,
	}, indent=2)


@mcp.tool()
def cubit_restore(label: str) -> str:
	"""Restore a previously-saved Cubit checkpoint by label.

	Loads `~/.cubit_viewer/checkpoints/<label>.cub5` via Cubit's `open`
	command. The current session state is replaced.

	Args:
	    label: name passed to a prior `cubit_checkpoint` call.
	"""
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	try:
		safe = _sanitize_label(label)
	except ValueError as e:
		return json.dumps({"status": "error", "error": str(e)})
	path = _checkpoints_dir() / f"{safe}.cub5"
	if not path.exists():
		return json.dumps({
			"status": "error",
			"error": f"checkpoint not found: {safe}",
			"looked_in": str(_checkpoints_dir()),
		})
	fwd = str(path).replace("\\", "/")
	try:
		r = sess.call("cmd", [f'open "{fwd}"'], timeout_s=120)
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc", "error": str(e)})
	if not r.get("ok"):
		return json.dumps({"status": "error", "stage": "open", "detail": r})
	return json.dumps({"status": "ok", "label": safe, "path": str(path)}, indent=2)


@mcp.tool()
def cubit_list_checkpoints() -> str:
	"""List all saved Cubit checkpoints with size + mtime."""
	import datetime
	d = _checkpoints_dir()
	entries = []
	for p in sorted(d.glob("*.cub5")):
		try:
			st = p.stat()
			entries.append({
				"label": p.stem,
				"path": str(p),
				"size_bytes": st.st_size,
				"mtime": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
			})
		except OSError:
			continue
	return json.dumps({"dir": str(d), "count": len(entries), "checkpoints": entries}, indent=2)


# ============================================================
# Meshing diagnostics
# ============================================================

# Suggested schemes by "why it failed" heuristics. Hex schemes first, tet
# fallback last.  Keyed on Cubit's get_volume_meshing_scheme returns that
# commonly indicate an unsuitable choice.
_SCHEME_ALTERNATIVES: dict = {
	"sweep": [
		"submap  # tight topology / brick-like volumes",
		"pave   # for 2D / degenerate sweep sources",
		"polyhedron  # robust hex for non-sweepable",
		"tetmesh  # fall back to tet",
	],
	"auto": [
		"sweep  # force sweep if prismatic",
		"polyhedron  # robust hex",
		"tetmesh  # fall back to tet",
	],
	"map": [
		"submap",
		"pave",
		"tetmesh",
	],
	"polyhedron": [
		"sweep  # if geometry is prismatic",
		"tetmesh",
	],
	None: [
		"Assign a scheme first: 'volume <id> scheme sweep' (or auto / tetmesh)",
	],
}


@mcp.tool()
def cubit_mesh_diagnose() -> str:
	"""Per-volume meshing diagnostic.

	Returns a table of every volume with: current meshing scheme, hex
	count, tet count, meshed / unmeshed flag. For unmeshed volumes,
	heuristic scheme alternatives are suggested (hex schemes first,
	tet fallback last).

	Use this after a `cubit_exec(["mesh volume all"])` that left some
	volumes unmeshed, to decide what to try next.
	"""
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	try:
		r = sess.call("probe", ["per_volume"], timeout_s=30)
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc", "error": str(e)})
	if not r.get("ok"):
		return json.dumps({"status": "error", "stage": "probe", "detail": r})
	rows = r.get("result", [])
	if not isinstance(rows, list):
		return json.dumps({"status": "error", "stage": "parse",
		                   "error": "per_volume did not return list",
		                   "raw": rows})

	meshed = [row for row in rows if row.get("meshed")]
	unmeshed = [row for row in rows if not row.get("meshed")]
	# Attach suggestions to unmeshed.
	for row in unmeshed:
		scheme = row.get("scheme")
		row["suggested_alternatives"] = _SCHEME_ALTERNATIVES.get(
			scheme, _SCHEME_ALTERNATIVES[None])

	hex_total = sum(row.get("hex", 0) for row in rows)
	tet_total = sum(row.get("tet", 0) for row in rows)

	return json.dumps({
		"status": "ok",
		"total_volumes": len(rows),
		"meshed_count": len(meshed),
		"unmeshed_count": len(unmeshed),
		"hex_total": hex_total,
		"tet_total": tet_total,
		"per_volume": rows,
		"hint": (
			"For each unmeshed volume, try the suggested scheme alternatives "
			"via `cubit_exec([\"volume <id> scheme <name>\", \"mesh volume <id>\"])`. "
			"Prefer hex schemes; fall back to tetmesh if all else fails."
		) if unmeshed else "All volumes meshed.",
	}, indent=2)


# ============================================================
# Tutorial / next-step suggestions
# ============================================================

@mcp.tool()
def cubit_suggest_next(goal: str = "mesh") -> str:
	"""Suggest concrete next Cubit commands based on the current state.

	Inspects the live session (via `probe summary` + per-volume info) and
	proposes 2–5 commands the LLM (or user) can execute next to progress
	toward the goal. Rule-based, not model-based — fast, predictable,
	and independent of external LLMs.

	Args:
	    goal: one of "import" / "mesh" / "hex" / "export" / "inspect" /
	        "refine" / "clean". Defaults to "mesh".

	Returns JSON with current state summary and a ranked list of
	suggested commands, each with a rationale.
	"""
	sess, err = _cubit_session_or_error()
	if err is not None:
		return err
	try:
		summary = sess.call("probe", ["summary"], timeout_s=30).get("result", {})
	except _cs.CubitSessionError as e:
		return json.dumps({"status": "error", "stage": "rpc", "error": str(e)})
	try:
		per_vol = sess.call("probe", ["per_volume"], timeout_s=30).get("result", [])
	except _cs.CubitSessionError:
		per_vol = []

	g = (goal or "mesh").strip().lower()
	suggestions: list[dict] = []
	state = {
		"volumes": summary.get("volumes", 0),
		"surfaces": summary.get("surfaces", 0),
		"hexes": summary.get("hexes", 0),
		"tets": summary.get("tets", 0),
		"nodes": summary.get("nodes", 0),
	}
	any_mesh = state["hexes"] + state["tets"] > 0
	unmeshed = [row for row in per_vol if not row.get("meshed")]

	def add(cmd: str, why: str) -> None:
		suggestions.append({"cmd": cmd, "why": why})

	if g == "import" or state["volumes"] == 0:
		add('import step "<path>"', "Load geometry from STEP (build123d output, CAD exchange).")
		add('import acis "<path>"', "Load ACIS .sat / .brep (native Cubit precision).")
		add('import mesh "<path>"', "Load existing mesh (.exo / .g / .msh / .vol).")
	elif g in ("mesh", "hex"):
		if unmeshed:
			# Most common next step after import
			if g == "hex":
				add("volume all scheme sweep", "Try hex via sweep (works if volumes are prismatic).")
				add("volume all size auto factor 5", "Moderately fine mesh size auto-chosen from geometry.")
				add("mesh volume all", "Execute the mesh.")
				add("volume all scheme polyhedron", "Robust hex when sweep fails (non-prismatic).")
			else:
				add("volume all scheme auto", "Let Cubit pick sweep/sub/map/tet per volume.")
				add("volume all size auto factor 5", "Moderately fine mesh size.")
				add("mesh volume all", "Execute the mesh.")
			add("volume all scheme tetmesh", "Tet fallback — always works, no topology constraints.")
		else:
			add("quality volume all", "Check mesh quality (aspect / skew / jacobian).")
			add("mesh volume all", "Already meshed; re-run only after mods.")
	elif g == "export":
		if not any_mesh:
			add("mesh volume all", "No mesh yet — create one before export.")
		add('export mesh "<path>.msh" overwrite', "Gmsh .msh (preferred lab format).")
		add('export abaqus "<path>.inp" overwrite', "Abaqus .inp for FEM.")
		add('export genesis "<path>.g" overwrite', "Exodus .g for Sierra / Netgen pipelines.")
		add('export step "<path>.step" overwrite', "Geometry-only STEP (for round-trip CAD).")
	elif g == "inspect":
		add("list volume all", "Print geometry summary.")
		add("list hex in volume all", "Print mesh counts per volume.")
		add("quality volume all", "Mesh quality metrics.")
		add("draw volume all", "Force a redraw if GUI out of sync.")
	elif g == "refine":
		add("refine volume all numsplit 1", "Uniform 1-level refine (~8× cells).")
		add("smooth volume all", "Laplace smoothing to improve quality.")
		add("quality volume all", "Re-check quality after refine.")
	elif g == "clean":
		add("delete mesh", "Drop the current mesh, keep geometry.")
		add("reset genesis", "Reset mesh numbering.")
		add("delete volume all", "Nuke geometry too.")
	else:
		add("# unknown goal; try: import / mesh / hex / export / inspect / refine / clean", "")

	return json.dumps({
		"status": "ok",
		"goal": g,
		"state": state,
		"unmeshed_volumes": len(unmeshed),
		"suggestions": suggestions,
	}, indent=2)


# ============================================================
# Knowledge lookup (retrieval-based)
# ============================================================

# Sources searched by `cubit_lookup`. Each entry is (name, accessor).
# The accessor is called with no args; returns the full knowledge body.
_KNOWLEDGE_SOURCES: list = [
	("export", lambda: get_export_documentation()),
	("cubit_api", lambda: get_api_reference()),
	("scripting", lambda: get_cubit_documentation()),
	("netgen_workflow", lambda: get_netgen_documentation()),
	("forum_tips", lambda: get_forum_tips()),
]


import math as _math
import re as _re


_STOP_WORDS = frozenset({
	"the", "a", "an", "of", "to", "in", "and", "or", "is", "are", "be",
	"on", "at", "for", "with", "as", "by", "from", "that", "this",
	"it", "its", "if", "so", "how", "what", "which", "when", "where",
})

_WORD_RE = _re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")


def _tokenize(s: str) -> list[str]:
	return [m.group(0).lower() for m in _WORD_RE.finditer(s)]


def _chunk_text(text: str, target_lines: int = 40) -> list[tuple[int, str]]:
	"""Split a knowledge string into heading-anchored chunks.

	Lines starting with "# ", "## ", "### " anchor chunks. Returns list
	of (starting_line, chunk_text). Chunks longer than 2× target_lines
	are hard-broken on line count.
	"""
	lines = text.splitlines()
	chunks: list[tuple[int, str]] = []
	cur_start = 0
	cur: list[str] = []
	for i, line in enumerate(lines):
		is_heading = line.startswith("# ") or line.startswith("## ") \
			or line.startswith("### ")
		if is_heading and cur and (i - cur_start) >= max(5, target_lines // 4):
			chunks.append((cur_start + 1, "\n".join(cur)))
			cur = []
			cur_start = i
		cur.append(line)
		# Hard break if chunk grows too large without a heading.
		if len(cur) >= target_lines * 2:
			chunks.append((cur_start + 1, "\n".join(cur)))
			cur = []
			cur_start = i + 1
	if cur:
		chunks.append((cur_start + 1, "\n".join(cur)))
	return chunks


def _heading_of(chunk: str) -> str:
	"""Return first non-blank line of a chunk (best heading proxy)."""
	for line in chunk.splitlines():
		s = line.strip()
		if s:
			return s
	return ""


def _build_corpus() -> list[dict]:
	"""Chunk every knowledge source + failure log once. Result is cached.

	Returns: list of {source, start_line, chunk, heading, tokens, token_set}.
	"""
	if getattr(_build_corpus, "_cache", None) is not None:
		return _build_corpus._cache  # type: ignore[attr-defined]

	sources = list(_KNOWLEDGE_SOURCES)
	# Include the failure log so past mistakes become searchable context.
	sources.append(("failures", lambda: _fl.failures_as_text("cubit", limit=50)))

	corpus: list[dict] = []
	for name, accessor in sources:
		try:
			text = accessor()
		except Exception:
			continue
		if not text:
			continue
		for start, chunk in _chunk_text(text, target_lines=40):
			tokens = _tokenize(chunk)
			if not tokens:
				continue
			corpus.append({
				"source": name,
				"start_line": start,
				"chunk": chunk,
				"heading": _heading_of(chunk),
				"tokens": tokens,
				"token_set": set(tokens),
			})
	_build_corpus._cache = corpus  # type: ignore[attr-defined]
	return corpus


def _invalidate_corpus_cache() -> None:
	"""Force re-chunking (after a new failure is logged, knowledge reloaded)."""
	if hasattr(_build_corpus, "_cache"):
		delattr(_build_corpus, "_cache")


def _score_tfidf(query_terms: list[str], doc: dict, idf: dict[str, float]) -> float:
	"""tf-idf-like score + heading boost. Zero if no term matches."""
	tokens = doc["tokens"]
	if not tokens:
		return 0.0
	tf: dict[str, int] = {}
	for tok in tokens:
		tf[tok] = tf.get(tok, 0) + 1
	inv_len = 1.0 / (1.0 + _math.log(1 + len(tokens)))
	score = 0.0
	hits = 0
	for term in query_terms:
		f = tf.get(term, 0)
		if f == 0:
			continue
		hits += 1
		score += (1.0 + _math.log(f)) * idf.get(term, 1.0) * inv_len
	if hits == 0:
		return 0.0
	# Boost chunks whose heading contains query terms
	head_lc = doc["heading"].lower()
	head_hits = sum(1 for t in query_terms if t in head_lc)
	if head_hits:
		score *= 1.0 + 0.75 * head_hits
	# Coverage bonus: matching many distinct query terms is better than one term many times
	score *= 1.0 + 0.25 * (hits / max(1, len(query_terms)))
	return score


def _compute_idf(corpus: list[dict], terms: list[str]) -> dict[str, float]:
	n = max(1, len(corpus))
	idf: dict[str, float] = {}
	for t in terms:
		df = sum(1 for doc in corpus if t in doc["token_set"])
		idf[t] = _math.log((n + 1) / (df + 1)) + 1.0
	return idf


@mcp.tool()
def cubit_lookup(query: str, max_results: int = 5, chunk_lines: int = 40) -> str:
	"""Retrieve relevant sections from the bundled Cubit knowledge base.

	Knowledge (~8000 lines: API reference, scripting patterns, forum
	tips, export rules, netgen workflows) is chunked by heading; the
	failure log (`cubit_recent_failures`) is mixed in as an extra
	source so past mistakes are searchable by the same query.

	Retrieval:
	  - tokenized lower-case word matching (not substring)
	  - tf-idf-style scoring (rare terms count more)
	  - ×1.75/term heading-title boost
	  - coverage bonus for hitting many distinct query terms

	Args:
	    query: keywords (e.g., "sweep scheme source", "radia_export netgen
	        high order", "quality metrics").
	    max_results: cap on returned chunks (default 5).
	    chunk_lines: target chunk size before heading-based re-anchoring
	        (reserved; corpus is built with 40 and cached).

	Returns JSON with top chunks annotated by source module and starting
	line number for traceability.
	"""
	del chunk_lines  # corpus is pre-chunked & cached; param kept for compat
	q = (query or "").strip()
	if not q:
		return json.dumps({"status": "error", "error": "empty query"})
	terms = [t for t in _tokenize(q) if t not in _STOP_WORDS]
	if not terms:
		return json.dumps({"status": "error",
		                   "error": "no searchable terms (all stop words?)"})

	# Refresh if failure log grew since cache build (cheap heuristic).
	corpus = _build_corpus()
	idf = _compute_idf(corpus, terms)

	scored: list[tuple[float, dict]] = []
	for doc in corpus:
		s = _score_tfidf(terms, doc, idf)
		if s > 0:
			scored.append((s, doc))

	scored.sort(key=lambda x: (-x[0], x[1]["source"], x[1]["start_line"]))
	top = scored[: max(1, int(max_results))]
	out = [
		{
			"source": doc["source"],
			"start_line": doc["start_line"],
			"heading": doc["heading"][:120],
			"score": round(score, 3),
			"chunk": doc["chunk"],
		}
		for score, doc in top
	]
	return json.dumps({
		"status": "ok",
		"query": q,
		"terms": terms,
		"candidates_total": len(scored),
		"returned": len(out),
		"results": out,
	}, indent=2)


@mcp.tool()
def cubit_recent_failures(limit: int = 10) -> str:
	"""Return the last N failed Cubit invocations (from persistent log).

	Use this after an error to remember what was tried recently, or at
	the start of a session to avoid repeating a known-bad command.
	"""
	recs = _fl.recent_failures("cubit", limit=limit)
	return json.dumps({
		"status": "ok",
		"count": len(recs),
		"log_path": str(_fl._log_path("cubit")),
		"entries": recs,
	}, indent=2)


@mcp.tool()
def cubit_web_docs(query: str, source: str = "cubit", max_hits: int = 5,
                   force_refresh: bool = False) -> str:
	"""Fetch live Cubit documentation and grep for `query`.

	Complements `cubit_lookup` (bundled static knowledge): when the
	bundled kb lacks context or an error references a newly-added
	command, hit the live docs. Results are cached on disk for 24 h.

	Args:
	    query: search terms (AND-matched, case-insensitive).
	    source: "cubit" (coreform.com/cubit_help) or
	        "cubit_forum" (forum.coreform.com).
	    max_hits: cap on returned matching lines across all pages.
	    force_refresh: bypass cache and re-fetch.

	Returns JSON with per-page hit excerpts (line + ±4 context lines).
	"""
	src = (source or "cubit").strip().lower()
	q = (query or "").strip()
	if not q:
		return json.dumps({"status": "error", "error": "empty query"})

	# Discourse-backed sources: use the JSON search API (richer + reliable).
	if src == "cubit_forum":
		hits = _wd.search_forum(q, max_hits=max_hits, force_refresh=force_refresh)
		return json.dumps({"status": "ok", "source": src, "query": q,
		                   "hits": hits}, indent=2)

	urls = _wd.DOCS_INDEX.get(src)
	if not urls:
		return json.dumps({"status": "error",
		                   "error": f"unknown source {source!r}",
		                   "known_sources": list(_wd.DOCS_INDEX.keys())})

	all_hits: list[dict] = []
	errors: list[dict] = []
	remaining = max(1, int(max_hits))
	for url in urls:
		if remaining <= 0:
			break
		data = _wd.fetch(url, force_refresh=force_refresh)
		if data.get("status") != "ok":
			errors.append({"url": url, "error": data.get("error")})
			continue
		hits = _wd.search_text(data["text"], q, max_hits=remaining)
		if hits:
			for h in hits:
				h["url"] = data["url"]
				h["from_cache"] = data.get("from_cache", False)
				all_hits.append(h)
			remaining -= len(hits)
	return json.dumps({
		"status": "ok",
		"source": src,
		"query": q,
		"hits": all_hits,
		"errors": errors,
	}, indent=2)


@mcp.tool()
def cubit_examples(query: str, limit: int = 3,
                    force_refresh: bool = False) -> str:
	"""Search Cubit journal examples from **multiple unioned sources**.

	Sources searched (all unioned, tf-idf ranked together):
	  1. **Coreform forum** (Discourse): 15 seed queries (tutorial,
	     hex meshing, sweep, boundary layer, thin shell, quality,
	     refinement, abaqus, high-order, polyhedron, multi-sweep,
	     imprint/merge, webcut, radia_export, journal)
	  2. **Local lab archive**: `S:\\CoreformCubit` (~145 .jou/.py
	     across years of research projects — twisted wire, claw-pole
	     alternator, kelvin transformation, TEAM problems, helical
	     coils, JMAG integration, Mesh AI, Nastran/VTU pipelines)
	     + `s:\\Radia\\01_GitHub\\examples` (~400 .jou/.py covering
	     build123d→Cubit, ngsolve, ih, electromagnet, peec, kelvin).
	     Lab-curated items get a small score boost.

	First call scrapes forum + walks local dirs; cache lives 7 days.
	Each hit returns: `source`, title, URL (`file:///…` for local),
	score, excerpt (first ~1.6 kB), absolute path.

	Args:
	    query: keywords (AND-scored, tokens + underscore-splits).
	    limit: cap on returned examples.
	    force_refresh: re-scrape / re-walk both sources.
	"""
	r = _ex.search_examples("cubit", query, limit=limit,
	                         force_refresh=force_refresh)
	return json.dumps(r, indent=2, ensure_ascii=False)


@mcp.tool()
def cubit_examples_refresh(limit_per_query: int = 5,
                           local_roots: list | None = None) -> str:
	"""Force-refresh both Cubit example sources (forum + local).

	Args:
	    limit_per_query: max forum posts per seed query.
	    local_roots: override default local roots
	        (`S:\\CoreformCubit`, `S:\\Radia\\01_GitHub\\examples`).
	"""
	forum = _ex.refresh_cubit_examples(limit_per_query=limit_per_query)
	local = _ex.refresh_cubit_local_examples(
		roots=[str(r) for r in local_roots] if local_roots else None,
	)
	return json.dumps({"forum": forum, "local": local}, indent=2,
	                  ensure_ascii=False)


# ============================================================
# Batch validation + mesh auto-fix (test-then-reflect pattern)
# ============================================================

def _run_batch(step_path: str | None, commands: list[str],
               timeout_s: int = 300) -> dict:
	"""Launch a FRESH, disposable batch Cubit (no GUI / no journal),
	optionally import a STEP, run `commands`, probe state, and tear
	down. Returns a structured dict.

	This is the building block for the "verify in batch, then commit
	to the live GUI session" pattern. The batch instance does NOT
	affect the persistent GUI singleton — it spins up its own
	coreform_cubit.exe subprocess (bundled Python 3.10 + cubit_daemon
	via stdio) and dies at the end.
	"""
	sess = _cs.CubitSession(mode="batch")
	try:
		try:
			sess.ensure_started()
		except _cs.CubitSessionError as e:
			return {"status": "error", "stage": "start",
			        "error": str(e), "commands": commands}
		per_line: list[dict] = []
		if step_path:
			step_fwd = str(step_path).replace("\\", "/")
			try:
				r = sess.call("cmd", [f'import step "{step_fwd}"'], timeout_s=timeout_s)
				imp_result = r.get("result", [])
				per_line.extend(imp_result)
				if not imp_result or not imp_result[0].get("ok"):
					return {"status": "error", "stage": "import",
					        "step_path": step_path, "per_line": per_line}
			except _cs.CubitSessionError as e:
				return {"status": "error", "stage": "import_rpc",
				        "step_path": step_path, "error": str(e)}
		try:
			r = sess.call("cmd", commands, timeout_s=timeout_s)
		except _cs.CubitSessionError as e:
			return {"status": "error", "stage": "rpc",
			        "error": str(e), "per_line": per_line}
		per_line.extend(r.get("result", []))
		try:
			smy = sess.call("probe", ["summary"], timeout_s=30).get("result", {})
		except _cs.CubitSessionError:
			smy = {}
		all_ok = all(step.get("ok") for step in per_line) if per_line else False
		failed_at = None
		first_err = None
		for i, step in enumerate(per_line, start=1):
			if not step.get("ok"):
				failed_at = i
				first_err = step.get("error") or f"rc={step.get('rc')}"
				break
		return {
			"status": "ok" if all_ok else "error",
			"all_ok": all_ok,
			"per_line": per_line,
			"summary": smy,
			"failed_at": failed_at,
			"error": (first_err or "").strip()[:400] if first_err else None,
		}
	finally:
		try:
			sess.shutdown()
		except Exception:
			pass


@mcp.tool()
def cubit_batch_try(commands: list, step_path: str = "",
                     timeout_s: int = 300) -> str:
	"""Dry-run a recipe in a fresh headless Cubit subprocess.

	Launches `coreform_cubit.exe` in batch / nographics / nojournal
	mode, optionally imports `step_path`, runs `commands` in order,
	probes final geometry/mesh counts, and tears down. Completely
	isolated from the live GUI session (`cubit_exec`).

	Intended flow:
	  1. AI proposes a recipe (e.g., `volume all scheme sweep` + `mesh ...`)
	  2. AI calls `cubit_batch_try(step, recipe)` to verify it actually
	     produces the expected element counts.
	  3. If it works, AI calls `cubit_exec(recipe)` to replay in the live
	     GUI window so the user can see the result.

	Args:
	    commands: list of Cubit command strings to run after import.
	    step_path: optional STEP file to import first. Empty = no import.
	    timeout_s: per-call RPC timeout.

	Returns JSON with status / per_line / summary (volumes, hexes, tets,
	nodes, ...) / failed_at / error.
	"""
	if not commands:
		return json.dumps({"status": "error",
		                   "error": "commands list cannot be empty"})
	cmd_list = [str(c).rstrip() for c in commands]
	result = _run_batch(step_path or None, cmd_list, timeout_s=timeout_s)
	if result.get("status") == "error":
		_fl.record_failure("cubit", {
			"input": cmd_list,
			"step_path": step_path,
			"stage": result.get("stage", "batch"),
			"error": result.get("error") or str(result)[:400],
			"context": {"summary": result.get("summary", {}),
			            "mode": "batch"},
		})
	return json.dumps(result, indent=2)


_MESH_LADDER: list[dict] = [
	{
		"name": "auto",
		"cmds": ["volume all scheme auto"],
		"why": "Let Cubit pick a per-volume scheme. Works for simple prismatic shapes.",
	},
	{
		"name": "sweep",
		"cmds": ["volume all scheme sweep"],
		"why": "Force sweep: pave source / sweep to target. Best hex yield when applicable.",
	},
	{
		"name": "polyhedron",
		"cmds": ["volume all scheme polyhedron"],
		"why": "Hex-dominant scheme tolerant of non-prismatic topology.",
	},
	{
		"name": "tetmesh",
		"cmds": ["volume all scheme tetmesh"],
		"why": "Always works; fallback giving tets rather than hex.",
	},
]


@mcp.tool()
def cubit_mesh_auto(step_path: str = "",
                    target_size: float = 1.0,
                    prefer: str = "hex",
                    commit_to_gui: bool = True,
                    timeout_s: int = 600) -> str:
	"""Find a working mesh recipe by trying a scheme ladder in batch,
	then optionally replay the winning recipe in the live GUI session.

	Ladder:
	  1. scheme auto       (hope for the best)
	  2. scheme sweep      (force sweep; pure hex if topology fits)
	  3. scheme polyhedron (hex-dominant for complex shapes)
	  4. scheme tetmesh    (guaranteed fallback, tet only)

	Each rung is executed in a fresh headless Cubit (no GUI pollution,
	no state entanglement with the live session). The first rung that
	produces >0 elements with the preferred family is the winner.
	When `commit_to_gui=True`, the winning recipe is replayed via the
	live GUI `CubitSession` so the user sees the mesh build live.

	Args:
	    step_path: STEP file to import in each batch. Empty → caller
	        has already imported into the GUI session, recipe is
	        validated against THAT state by rewinding with delete mesh
	        + new scheme. If step_path empty, `commit_to_gui` also
	        skips the re-import (just delete mesh + run winning recipe).
	    target_size: mesh size command target. Passed as
	        `volume all size <target_size>` before each scheme.
	    prefer: "hex" (require hex>0 to accept) or "any" (any element).
	    commit_to_gui: replay winning recipe in the live GUI session.
	    timeout_s: per-ladder-rung timeout.

	Returns structured report: which schemes tried, element counts per
	attempt, chosen recipe, and what the GUI session looks like after
	replay (if commit_to_gui).
	"""
	prefer = (prefer or "hex").strip().lower()
	if prefer not in ("hex", "any"):
		return json.dumps({"status": "error",
		                   "error": f"prefer must be 'hex' or 'any', got {prefer!r}"})

	attempts: list[dict] = []
	winner: dict | None = None

	for rung in _MESH_LADDER:
		recipe = [f"volume all size {float(target_size)}",
		          *rung["cmds"],
		          "mesh volume all"]
		r = _run_batch(step_path or None, recipe, timeout_s=timeout_s)
		smy = r.get("summary", {}) or {}
		h = int(smy.get("hexes", 0))
		t = int(smy.get("tets", 0))
		n = int(smy.get("nodes", 0))
		ok_elems = (h > 0) if prefer == "hex" else ((h + t) > 0)
		attempts.append({
			"scheme": rung["name"],
			"why": rung["why"],
			"status": r.get("status"),
			"hexes": h, "tets": t, "nodes": n,
			"failed_at": r.get("failed_at"),
			"error": r.get("error"),
		})
		if r.get("status") == "ok" and ok_elems:
			winner = {"scheme": rung["name"], "recipe": recipe,
			          "hexes": h, "tets": t, "nodes": n}
			break

	if winner is None:
		return json.dumps({
			"status": "error",
			"reason": "no scheme in the ladder produced the preferred element type",
			"prefer": prefer,
			"attempts": attempts,
			"suggest": ("Try geometric splits before meshing — e.g., "
			            "webcut cylinder axis z radius R, webcut with plane xplane, "
			            "or split helix/lead transitions. Consult "
			            "cubit_lookup(query='sweep multi source target') and "
			            "cubit_web_docs(query='sweep complex geometry', source='cubit_forum')."),
		}, indent=2)

	# Replay the winning recipe in the live GUI session
	gui_report: dict = {"skipped": True}
	if commit_to_gui:
		sess, err = _cubit_session_or_error()
		if err is not None:
			gui_report = {"status": "error", "note": "no live GUI session; caller must replay manually",
			              "detail": json.loads(err)}
		else:
			# If caller provided a step_path, import it so GUI mirrors batch state.
			gui_cmds: list[str] = []
			if step_path:
				step_fwd = str(step_path).replace("\\", "/")
				gui_cmds.append(f'reset')
				gui_cmds.append(f'import step "{step_fwd}"')
			gui_cmds.append("delete mesh")
			gui_cmds.extend(winner["recipe"])
			try:
				rr = sess.call("cmd", gui_cmds, timeout_s=timeout_s)
			except _cs.CubitSessionError as e:
				gui_report = {"status": "error", "stage": "gui_rpc", "error": str(e)}
			else:
				per_line = rr.get("result", [])
				try:
					smy = sess.call("probe", ["summary"], timeout_s=30).get("result", {})
				except _cs.CubitSessionError:
					smy = {}
				gui_report = {
					"status": "ok" if all(s.get("ok") for s in per_line) else "error",
					"summary": smy,
					"replayed": gui_cmds,
				}

	return json.dumps({
		"status": "ok",
		"winner": winner,
		"attempts": attempts,
		"gui": gui_report,
	}, indent=2)


# ============================================================
# MCP Prompts
# ============================================================

@mcp.prompt()
def new_cubit_mesh(geometry: str, element_type: str = "tet") -> str:
	"""Create a Cubit meshing script for the given geometry."""
	return (
		f"Create a Cubit meshing script for: {geometry}\n"
		f"Element type: {element_type}\n\n"
		"Follow these conventions:\n"
		"1. cubit.init(['cubit', '-nojournal', '-batch'])\n"
		"2. Register blocks with names: block N add {tet|hex} all; block N name '...'\n"
		"3. Add boundary block: block N add {tri|quad} all\n"
		"4. Use relative paths for imports\n"
		"5. For curved mesh: cubit.cmd('radia_export netgen \"mesh.vol\" order N overwrite')\n"
		"6. Verify volume after curving\n"
		"7. For Gmsh visualization: cubit.cmd('radia_export gmsh \"mesh.msh\" order N overwrite')\n"
	)


@mcp.prompt()
def cubit_to_ngsolve(mesh_file: str) -> str:
	"""Set up Cubit mesh -> NGSolve high-order FEM workflow."""
	return (
		f"Set up a Cubit -> NGSolve high-order workflow for: {mesh_file}\n\n"
		"Workflow:\n"
		"1. Create geometry and mesh in Cubit\n"
		"2. cubit.cmd('radia_export netgen \"mesh.vol\" order N overwrite')\n"
		"3. mesh = Mesh('mesh.vol')  # already curved, no mesh.Curve() needed\n"
	)


# ============================================================
# MCP Resources
# ============================================================

@mcp.resource("cubit://export-decision")
def cubit_export_decision_guide() -> str:
	"""Quick decision guide for choosing Cubit export format."""
	return (
		"# Cubit Export Format Decision Guide\n\n"
		"| Need | Command | Max Order |\n"
		"|------|---------|----------|\n"
		"| NGSolve FEM (recommended) | radia_export netgen \"f.vol\" order N | 1-5 |\n"
		"| GMSH visualization | radia_export gmsh \"f.msh\" order N | 1-3 |\n"
		"| Nastran / JMAG | radia_export nastran \"f.bdf\" order N | 1-2 |\n"
		"| ParaView | radia_export vtk \"f.vtk\" order N | 1-2 |\n"
		"| ELF/MAGIC | export meg \"f.meg\" | 1 |\n"
		"| Cubit-native archival | export mesh \"f.exo\" | all |\n"
	)


@mcp.resource("cubit://element-types")
def cubit_element_types_reference() -> str:
	"""Cubit element type reference for block registration."""
	return (
		"# Cubit Element Types\n\n"
		"## 3D Elements\n"
		"| Type | Nodes | 2nd Order | Cubit Name |\n"
		"|------|-------|-----------|------------|\n"
		"| Tetrahedron | 4 | 10 (tetra10) | tet |\n"
		"| Hexahedron | 8 | 20 (hex20) / 27 (hex27) | hex |\n"
		"| Wedge | 6 | 15 (wedge15) | wedge |\n"
		"| Pyramid | 5 | 13 (pyramid13) | pyramid |\n\n"
		"## 2D Elements\n"
		"| Type | Nodes | 2nd Order | Cubit Name |\n"
		"|------|-------|-----------|------------|\n"
		"| Triangle | 3 | 6 (tri6) | tri |\n"
		"| Quadrilateral | 4 | 8 (quad8) / 9 (quad9) | quad |\n\n"
		"## Block Registration Pattern\n"
		"```python\n"
		"cubit.cmd('block 1 add tet all')     # Add elements first\n"
		"cubit.cmd('block 1 element type tetra10')  # Then set type\n"
		"cubit.cmd('block 1 name \"domain\"')  # Then name\n"
		"```\n"
	)


# ============================================================
# Self-test
# ============================================================

def _selftest():
	"""Run lint on fixtures and optionally examples/."""
	print("=" * 70)
	print("Cubit Export Lint Self-Test")
	print("=" * 70)
	print()

	# --- Fixtures validation ---
	fixtures_dir = (
		Path(__file__).parent.parent.parent.parent.parent / "tests"
		/ "mcp_server" / "fixtures"
	)
	if not fixtures_dir.exists():
		fixtures_dir = Path(__file__).parent / "fixtures"

	if fixtures_dir.exists():
		bad_file = fixtures_dir / "bad_cubit_script.py"
		clean_file = fixtures_dir / "clean_cubit_script.py"
		if bad_file.exists():
			findings = _lint_file(str(bad_file))
			print(f"  bad_cubit_script.py: {len(findings)} finding(s)")
			if not findings:
				print("  WARNING: bad_cubit_script.py has no findings")
		if clean_file.exists():
			findings = _lint_file(str(clean_file))
			print(f"  clean_cubit_script.py: {len(findings)} finding(s)")
			if findings:
				for f in findings:
					print(f"    L{f['line']} [{f['severity']}] {f['rule']}: {f['message']}")
				print("  FAIL: clean script should have zero findings")
				sys.exit(1)
		print("  fixture validation: PASSED")
		print()

	# --- Examples scan ---
	examples_dir = PROJECT_ROOT / "examples"
	if not examples_dir.exists():
		if not fixtures_dir.exists():
			print(f"SKIP: No fixtures or examples/ found")
		return

	result = lint_cubit_directory("examples")
	print(result)


def main():
	"""Entry point for mcp-server-cubit command."""
	if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
		_selftest()
	else:
		mcp.run(transport="stdio")


if __name__ == '__main__':
	main()
