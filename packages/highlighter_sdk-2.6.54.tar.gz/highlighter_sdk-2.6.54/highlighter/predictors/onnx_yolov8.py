import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from uuid import UUID

import numpy as np

from highlighter.client.gql_client import HLClient
from highlighter.client.training_runs import (
    TrainingRunType,
    get_training_run,
    get_training_run_artefact,
)
from highlighter.core import LabeledUUID
from highlighter.core.const import OBJECT_CLASS_ATTRIBUTE_UUID
from highlighter.core.exceptions import OptionalPackageMissingError
from highlighter.core.geometry import polygon_from_mask

from .output_category_descriptor import (
    EnumDescriptorWithConfidenceThreshold,
    OutputCategoryDescriptor,
)
from .prediction import Prediction

try:
    import cv2
except ModuleNotFoundError as _:
    raise OptionalPackageMissingError("cv2", "cv2")

try:
    import torch
    import torch.nn.functional as F
except ModuleNotFoundError as _:
    raise OptionalPackageMissingError("torch", "torch")


from highlighter.client import TrainingRunArtefactType

from .onnx_predictor import OnnxPredictor

__all__ = ["OnnxYoloV8"]

LOG = logging.getLogger(__name__)
VERBOSE_LEVEL = logging.getLevelNamesMapping().get("VERBOSE", logging.DEBUG)


def mask_to_closed_polygon(mask: np.ndarray) -> List[Tuple[int, int]]:
    points = polygon_from_mask(mask)
    if points is None:
        raise ValueError("mask conversion resulted in zero points")

    points = [(x, y) for x, y in zip(points[:-1:2], points[1::2])]
    # Shapely expects a closing point
    points.append(points[0])
    return points


class OnnxYoloV8:
    def __init__(
        self,
        onnx_predictor: Union[OnnxPredictor, str, Path],
        num_classes: int,
        class_lookup: Optional[Dict[int | str, OutputCategoryDescriptor]] = None,
        conf_thresh: float = 0.1,
        nms_iou_thresh: float = 0.5,
        nms_class_agnostic: bool = False,
        is_absolute: bool = True,
        max_batch_size: Optional[int] = None,
        **kwargs,
    ):
        """
        Args:
            num_classes: The number of output classes of the predictor
            class_lookup: Optional. If set then only classes in the dict will be returned. If not set, the
              the Annotation's ObjectClass Observation value with be UUID(int=class_id) with no 'human readable' label.
              Set with one of:
                - [object_class_uuid, object_class_label]
                - [object_class_uuid, object_class_label, confidence_threshold]
                - [attribute_id, attribute_label, enum_id, enum_label]
                - [attribute_id, attribute_label, enum_id, enum_label, confidence_threshold]
            conf_thresh: Only return detections with confidence >= conf_thresh
            nms_iou_thresh: Detections with an IOU >= nms_iou_thresh and the same class_id will be considered the same entity and the
            one with the max confidence will be used
            is_absolute: True if the model returns detections in absolute pixel values, else set to false.
            max_batch_size: Optional cap on the batch size passed to the predictor for dynamic-batch ONNX models.
            kwargs: Optional args to pass to OnnxPredictor
        """

        if isinstance(onnx_predictor, OnnxPredictor):
            self._onnx_predictor = onnx_predictor
        else:
            self._onnx_predictor = OnnxPredictor(onnx_predictor, **kwargs)

        # Numpy dtype: support both FP32 and FP16 onnx model
        self.ndtype = (
            np.half if self._onnx_predictor.sess.get_inputs()[0].type == "tensor(float16)" else np.single
        )
        self.num_classes = num_classes

        if class_lookup is not None:
            # Ensure keys are int so that class lookup works.
            # JSON doesn't allow numbers as keys so we may receive strings.
            # And, while we're at it we also any per-class confidence thresholds
            # or default to conf_thresh
            self.class_lookup = {}
            for k, v in class_lookup.items():
                self.class_lookup[int(k)] = (
                    EnumDescriptorWithConfidenceThreshold.from_output_category_descriptor(
                        v, default_confidence_threshold=conf_thresh
                    )
                )
        else:
            self.class_lookup = {
                i: EnumDescriptorWithConfidenceThreshold(
                    attribute_id=OBJECT_CLASS_ATTRIBUTE_UUID,
                    attribute_label="object_class",
                    enum_id=UUID(int=i),
                    enum_label="",
                    confidence_threshold=conf_thresh,
                )
                for i in range(self.num_classes)
            }

        self.nms_box_conf = min([v.confidence_threshold for v in self.class_lookup.values()])
        # Boxes with iou < this will be filterd out during NMS
        self.nms_iou_thr = nms_iou_thresh
        self.nms_class_agnostic = nms_class_agnostic
        self.is_absolute = is_absolute
        if max_batch_size is not None and max_batch_size < 1:
            raise ValueError(f"max_batch_size must be >= 1, got {max_batch_size}")
        self.max_batch_size = max_batch_size

        # Get model width and height(YOLOv8-seg only has one input)
        input_shape = self._onnx_predictor.sess.get_inputs()[0].shape
        h_dim, w_dim = input_shape[-2], input_shape[-1]

        if isinstance(h_dim, int) and isinstance(w_dim, int):
            self.model_height, self.model_width = h_dim, w_dim
        else:
            # Dynamic spatial dims (e.g. exported with dynamic=True) — read from metadata
            metadata = self._onnx_predictor.sess.get_modelmeta().custom_metadata_map
            imgsz = metadata.get("imgsz")
            if imgsz is None:
                raise ValueError(
                    f"ONNX model has dynamic spatial dimensions {input_shape} "
                    "but no 'imgsz' metadata to resolve them."
                )
            import json

            imgsz = json.loads(imgsz)
            self.model_height, self.model_width = imgsz[0], imgsz[1]
        self.use_high_res_masks = False  # see:

        onnx_model_input_shape = self._onnx_predictor.sess.get_inputs()[0].shape

        if len(onnx_model_input_shape) != 4:
            raise NotImplementedError(
                f"{self.__class__.__name__} can only deal with onnx models "
                "with input shapes [batch, chan=3, h, w] "
                f"got: {onnx_model_input_shape}."
            )

    @classmethod
    def load_from_training_run(
        cls, training_run_id: int, artefact_id: Union[UUID, str], cache_dir: Optional[Path] = None, **kwargs
    ) -> "OnnxYoloV8":
        if cache_dir:
            onnx_file = cache_dir / f"{training_run_id}-{artefact_id}.onnx14"
            training_run_path = cache_dir / f"{training_run_id}-{artefact_id}.yaml"

            if not onnx_file.exists():
                get_training_run_artefact(
                    HLClient.get_client(),
                    str(artefact_id),
                    download_file_url=True,
                    file_url_save_path=str(onnx_file),
                )

            if not training_run_path.exists():
                training_run = get_training_run(HLClient.get_client(), training_run_id)
                training_run.dump_yaml(training_run_path)
            else:
                training_run = TrainingRunType.from_yaml(training_run_path)
        else:
            onnx_file = get_training_run_artefact(
                HLClient.get_client(),
                str(artefact_id),
                download_file_url=True,
            )
            training_run = get_training_run(HLClient.get_client(), training_run_id)

        class_lookup = {
            p.position: EnumDescriptorWithConfidenceThreshold(
                attribute_id=p.taxon[0].entity_attribute_id,
                attribute_label=p.taxon[0].entity_attribute_name,
                enum_id=p.taxon[0].entity_attribute_enum_id,
                enum_label=p.taxon[0].entity_attribute_enum_value,
                confidence_threshold=p.conf_thresh,
            )
            for p in training_run.input_output_schema.get_head_model_outputs(0)
        }

        return cls(OnnxPredictor(str(onnx_file)), len(class_lookup), class_lookup=class_lookup, **kwargs)

    @classmethod
    def load_from_artefact(cls, training_run_artefact: TrainingRunArtefactType) -> "OnnxYoloV8":
        onnx_predictor = OnnxPredictor(training_run_artefact.file_url)
        num_classes = len(training_run_artefact.inference_config["model_schema"]["model_outputs"])
        return cls(onnx_predictor, num_classes=num_classes)

    def predict(self, inputs: List[np.ndarray], **_) -> List[List[Prediction]]:
        if not inputs:
            return []

        # Preprocess all images
        preprocessed = []
        original_sizes = []
        for img in inputs:
            original_sizes.append(img.shape[:2])
            preprocessed.append(preprocess(img, self.model_height, self.model_width, self.ndtype))

        batch_size = len(inputs)
        preproc_hw = preprocessed[0].shape[-2:]
        supports_dynamic_batch = not isinstance(self._onnx_predictor.batch_size, int)

        if supports_dynamic_batch:
            # Dynamic-batch models: optionally run in chunks to cap peak memory usage.
            dynamic_batch_size = getattr(self, "max_batch_size", None) or batch_size
            batch_output: List[List[Prediction]] = []
            for start in range(0, batch_size, dynamic_batch_size):
                batch_preprocessed = preprocessed[start : start + dynamic_batch_size]
                batch_input = np.concatenate(batch_preprocessed, axis=0)
                raw_ort_output = self._onnx_predictor.predict_batch(batch_input)
                if len(raw_ort_output) == 1 and len(raw_ort_output[0].shape) == 2:
                    batch_output.extend(self._predict_classification_batch(raw_ort_output[0]))
                    continue
                # `raw_ort_output` is a list with one array per output head. Each array contains
                # predictions for the batch for the given output head. Downstream code expects one item per input image where each
                # item is a list of output-head arrays with batch dimension 1, so we split per image here.
                # Yolo segmentation has 2 heads, so a simple [0] is not enough here.
                for i in range(len(batch_preprocessed)):
                    batch_output.append(
                        self._postprocess(
                            [out[i : i + 1] for out in raw_ort_output],
                            preproc_hw,
                            original_sizes[start + i],
                            self.is_absolute,
                        )
                    )
        else:
            # Static batch-size models: run in fixed-size chunks and pad the final chunk.
            static_batch_size = int(self._onnx_predictor.batch_size)
            if static_batch_size < 1:
                raise ValueError(f"Invalid static batch size: {static_batch_size}")

            batch_output = []
            for start in range(0, batch_size, static_batch_size):
                batch_preprocessed = preprocessed[start : start + static_batch_size]
                valid_count = len(batch_preprocessed)

                if valid_count < static_batch_size:
                    batch_preprocessed = batch_preprocessed + [batch_preprocessed[-1]] * (
                        static_batch_size - valid_count
                    )

                batch_input = np.concatenate(batch_preprocessed, axis=0)
                raw_ort_output = self._onnx_predictor.predict_batch(batch_input)
                if len(raw_ort_output) == 1 and len(raw_ort_output[0].shape) == 2:
                    batch_output.extend(self._predict_classification_batch(raw_ort_output[0][:valid_count]))
                    continue
                for i in range(valid_count):
                    batch_output.append(
                        self._postprocess(
                            [out[i : i + 1] for out in raw_ort_output],
                            preproc_hw,
                            original_sizes[start + i],
                            self.is_absolute,
                        )
                    )

        return batch_output

    def _predict_classification_batch(self, raw_scores: np.ndarray) -> List[List[Prediction]]:
        class_indices = np.argmax(raw_scores, axis=1)
        confs = np.max(raw_scores, axis=1)
        if not hasattr(self, "class_lookup"):
            return [
                self._make_predictions(np.array([class_index]), np.array([conf]))
                for class_index, conf in zip(class_indices, confs)
            ]
        batch_predictions: List[List[Prediction]] = []
        for class_index, conf in zip(class_indices.tolist(), confs.tolist()):
            category_descriptor = self.class_lookup.get(class_index)
            if category_descriptor is None or conf < category_descriptor.confidence_threshold:
                batch_predictions.append([])
                continue
            batch_predictions.append(
                [
                    Prediction(
                        pixel_location=None,
                        attribute=LabeledUUID(
                            category_descriptor.attribute_id, label=category_descriptor.attribute_label
                        ),
                        value=LabeledUUID(category_descriptor.enum_id, label=category_descriptor.enum_label),
                        conf=conf,
                    )
                ]
            )
        return batch_predictions

    def _make_predictions(self, class_indices, confs, locations=None) -> List[Prediction]:
        verbose_enabled = LOG.isEnabledFor(VERBOSE_LEVEL)
        debug_enabled = LOG.isEnabledFor(logging.DEBUG)
        if verbose_enabled:
            LOG.verbose("%s confs: %s", self.__class__.__name__, confs)
            LOG.verbose("%s class_indices: %s", self.__class__.__name__, class_indices)
            LOG.verbose("%s locations: %s", self.__class__.__name__, locations)
        predictions: List[Prediction] = []
        dropped_counts = {"unknown_class": 0, "below_threshold": 0, "zero_area": 0}

        def _format_location(loc):
            if isinstance(loc, np.ndarray):
                if loc.ndim > 1:
                    return f"array shape={loc.shape}"
                loc = loc.tolist()
            if isinstance(loc, (list, tuple)) and len(loc) == 4:
                x0, y0, x1, y1 = loc
                return f"({x0:.2f},{y0:.2f})-({x1:.2f},{y1:.2f})"
            return str(loc)

        category_descriptors = [self.class_lookup.get(class_index, None) for class_index in class_indices]
        if locations is None:
            locations = [None] * len(confs)

        for category_descriptor, conf, loc in zip(category_descriptors, confs, locations):
            if category_descriptor is None:
                dropped_counts["unknown_class"] += 1
                if debug_enabled:
                    LOG.debug(
                        "Dropping detection with unknown category=%s, loc=%s",
                        category_descriptor,
                        _format_location(loc),
                    )
                continue

            if conf < category_descriptor.confidence_threshold:
                dropped_counts["below_threshold"] += 1
                if debug_enabled:
                    LOG.debug(
                        "Dropping detection below threshold (conf=%.3f < %.3f) category=%s, loc=%s",
                        conf,
                        category_descriptor.confidence_threshold,
                        category_descriptor,
                        _format_location(loc),
                    )
                continue

            # Drop degenerate boxes that would become invalid polygons
            if isinstance(loc, (list, tuple, np.ndarray)) and len(loc) == 4:
                x0, y0, x1, y1 = loc
                if (x1 - x0) <= 0 or (y1 - y0) <= 0:
                    dropped_counts["zero_area"] += 1
                    if debug_enabled:
                        LOG.debug(
                            "Dropping zero-area box loc=%s category=%s, conf=%.3f",
                            _format_location(loc),
                            category_descriptor,
                            conf,
                        )
                    continue

            prediction = Prediction(
                pixel_location=loc,
                attribute=LabeledUUID(
                    category_descriptor.attribute_id, label=category_descriptor.attribute_label
                ),
                value=LabeledUUID(category_descriptor.enum_id, label=category_descriptor.enum_label),
                conf=conf,
            )

            predictions.append(prediction)

        if verbose_enabled:
            LOG.verbose(
                "%s created %s annotations; dropped=%s locations=%s",
                self.__class__.__name__,
                len(predictions),
                dropped_counts,
                [_format_location(pred.pixel_location) for pred in predictions],
            )
        if debug_enabled:
            for pred in predictions:
                LOG.debug(
                    "Prediction: category=%s, conf=%.3f, loc=%s",
                    pred.value,
                    pred.conf,
                    _format_location(pred.pixel_location),
                )
        return predictions

    def _postprocess(
        self,
        batch_ort_output,
        preproc_img_hw: Tuple[int, int],
        orig_img_hw: Tuple[int, int],
        is_absolute: bool,
    ) -> List[Prediction]:
        predictions: List[Prediction] = []
        if len(batch_ort_output) == 1:  # detection output
            preds = non_max_suppression(
                torch.Tensor(batch_ort_output[0]),
                self.nms_box_conf,
                self.nms_iou_thr,
                nc=self.num_classes,
                agnostic=self.nms_class_agnostic,
            )[0]

            if not is_absolute:
                if LOG.isEnabledFor(VERBOSE_LEVEL):
                    LOG.verbose(
                        "%s scaling relative boxes (before): %s", self.__class__.__name__, preds[:, :4]
                    )
                preds[:, [0, 2]] = preds[:, [0, 2]] * preproc_img_hw[1]
                preds[:, [1, 3]] = preds[:, [1, 3]] * preproc_img_hw[0]

            if LOG.isEnabledFor(VERBOSE_LEVEL):
                LOG.verbose("%s preproc_img_hw: %s", self.__class__.__name__, preproc_img_hw)
                LOG.verbose("%s orig_img_hw: %s", self.__class__.__name__, orig_img_hw)
                LOG.verbose("%s preds (pre scale_boxes): %s", self.__class__.__name__, preds[:, :4])
            preds[:, :4] = scale_boxes(preproc_img_hw, preds[:, :4], orig_img_hw)
            preds = preds.numpy()
            trlb_boxes = preds[:, :4]
            confs = preds[:, 4]
            class_indices = preds[:, 5].astype(int)

            predictions = self._make_predictions(class_indices, confs, trlb_boxes)

        elif len(batch_ort_output) == 2:  # segmentation output
            preds = batch_ort_output
            p = non_max_suppression(
                torch.Tensor(preds[0]),
                self.nms_box_conf,
                self.nms_iou_thr,
                nc=self.num_classes,
                agnostic=self.nms_class_agnostic,
            )

            proto = (
                preds[1][-1] if isinstance(preds[1], tuple) else preds[1]
            )  # tuple if PyTorch model or array if exported

            pred = p[0]
            proto = proto[0]

            if len(pred):
                masks = apply_mask_prototypes(
                    torch.Tensor(proto), pred[:, 6:], pred[:, :4], preproc_img_hw, upsample=True
                )
                masks = resize_masks_from_letterbox(masks[None], orig_img_hw)[0].numpy()
                pred[:, :4] = scale_boxes(preproc_img_hw, pred[:, :4], orig_img_hw)

                confs = pred[:, 4].numpy()
                class_indices = pred[:, 5].numpy()

                polygons = [mask_to_closed_polygon(mask) for mask in masks]

                predictions = self._make_predictions(
                    class_indices,
                    confs,
                    polygons,
                )

        else:
            raise ValueError("Invalid batch_ort_output")

        return predictions


def preprocess(img, new_height, new_width, ndtype):
    """Letterbox-resize and normalize an image for ONNX model input.

    Letterboxing is a standard image preprocessing technique for object detection
    that preserves aspect ratio while fitting images to a target size. The image
    is resized to fit within the target dimensions, then padded to reach the
    exact size. This avoids distortion that would occur from naive resizing.

    See Also:
        - cv2.resize: https://docs.opencv.org/4.x/da/d54/group__imgproc__transform.html
        - cv2.copyMakeBorder: https://docs.opencv.org/4.x/d2/de8/group__core__array.html

    Args:
        img: Input image as HWC numpy array (uint8).
        new_height: Target height for the model.
        new_width: Target width for the model.
        ndtype: Numpy dtype for the output (e.g. np.float32 or np.float16).

    Returns:
        Preprocessed image as (1, C, H, W) numpy array.
    """
    h, w = img.shape[:2]
    scale = min(new_height / h, new_width / w)
    resized_w, resized_h = int(round(w * scale)), int(round(h * scale))

    if (w, h) != (resized_w, resized_h):
        img = cv2.resize(img, (resized_w, resized_h), interpolation=cv2.INTER_LINEAR)

    pad_w = (new_width - resized_w) / 2.0
    pad_h = (new_height - resized_h) / 2.0
    top, bottom = int(round(pad_h - 0.1)), int(round(pad_h + 0.1))
    left, right = int(round(pad_w - 0.1)), int(round(pad_w + 0.1))
    img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))

    img = np.ascontiguousarray(np.transpose(img, (2, 0, 1)), dtype=ndtype)
    img *= ndtype(1.0 / 255.0)

    if img.ndim == 3:
        img = img[None]
    return img


def _obb_covariance(boxes):
    """Compute covariance matrix elements for oriented bounding boxes.

    Models each OBB as a 2-D Gaussian and returns the three unique elements
    of the covariance matrix. This implements the Gaussian bounding box
    representation from the Probabilistic IoU paper.

    The covariance matrix for a rotated box with width w, height h, and
    rotation angle θ is derived from the standard formula for rotating
    a diagonal covariance matrix: Σ = R @ diag(w²/12, h²/12) @ R.T

    References:
        - Murrugarra-Llerena et al., "Gaussian Bounding Boxes and Probabilistic
          Intersection-over-Union for Object Detection", arXiv:2106.06072
          https://arxiv.org/abs/2106.06072

    Args:
        boxes: (N, 5) tensor in xywhr format (centre-x, centre-y, w, h, rotation).

    Returns:
        Tuple of three (N, 1) tensors: (sigma_xx, sigma_yy, sigma_xy).
    """
    wh_sq = boxes[:, 2:4].pow(2) / 12
    angle = boxes[:, 4:]
    cos_a, sin_a = angle.cos(), angle.sin()
    cos2, sin2 = cos_a.pow(2), sin_a.pow(2)
    a, b = wh_sq.split(1, dim=-1)
    return a * cos2 + b * sin2, a * sin2 + b * cos2, (a - b) * cos_a * sin_a


def batch_probiou(obb1, obb2, eps=1e-7):
    """Compute pairwise Probabilistic IoU between two sets of oriented bounding boxes.

    Implements the Bhattacharyya coefficient-based similarity measure for
    Gaussian distributions representing oriented bounding boxes. The similarity
    is computed as 1 - sqrt(1 - BC), where BC is the Bhattacharyya coefficient.

    This is a direct implementation of Equation 9 from the ProbIoU paper,
    which provides a differentiable IoU-like metric for rotated boxes.

    References:
        - Murrugarra-Llerena et al., "Gaussian Bounding Boxes and Probabilistic
          Intersection-over-Union for Object Detection", arXiv:2106.06072
          https://arxiv.org/abs/2106.06072
        - Bhattacharyya distance: https://en.wikipedia.org/wiki/Bhattacharyya_distance

    Args:
        obb1: (N, 5) tensor/array in xywhr format.
        obb2: (M, 5) tensor/array in xywhr format.
        eps: Small value for numerical stability.

    Returns:
        (N, M) similarity tensor in [0, 1].
    """
    if isinstance(obb1, np.ndarray):
        obb1 = torch.from_numpy(obb1)
    if isinstance(obb2, np.ndarray):
        obb2 = torch.from_numpy(obb2)

    cx1, cy1 = obb1[..., :2].split(1, dim=-1)
    cx2, cy2 = (v.squeeze(-1)[None] for v in obb2[..., :2].split(1, dim=-1))
    a1, b1, c1 = _obb_covariance(obb1)
    a2, b2, c2 = (v.squeeze(-1)[None] for v in _obb_covariance(obb2))

    det_sum = (a1 + a2) * (b1 + b2) - (c1 + c2).pow(2) + eps
    t1 = ((a1 + a2) * (cy1 - cy2).pow(2) + (b1 + b2) * (cx1 - cx2).pow(2)) / det_sum * 0.25
    t2 = ((c1 + c2) * (cx2 - cx1) * (cy1 - cy2)) / det_sum * 0.5
    det1 = (a1 * b1 - c1.pow(2)).clamp_(0)
    det2 = (a2 * b2 - c2.pow(2)).clamp_(0)
    t3 = (det_sum / (4 * (det1 * det2).sqrt() + eps) + eps).log() * 0.5

    bd = (t1 + t2 + t3).clamp(eps, 100.0)
    return 1 - (1.0 - (-bd).exp() + eps).sqrt()


def nms_rotated(boxes, scores, threshold=0.45):
    """Non-maximum suppression for oriented bounding boxes.

    Applies the standard greedy NMS algorithm using Probabilistic IoU as the
    overlap metric. Boxes are sorted by confidence, and lower-scoring boxes
    with IoU > threshold relative to higher-scoring boxes are suppressed.

    References:
        - NMS algorithm: Neubeck & Van Gool, "Efficient Non-Maximum Suppression", ICPR 2006
        - ProbIoU metric: arXiv:2106.06072

    Args:
        boxes: (N, 5) tensor in xywhr format.
        scores: (N,) confidence scores.
        threshold: IoU threshold for suppression.

    Returns:
        Indices of kept boxes.
    """
    if len(boxes) == 0:
        return np.empty((0,), dtype=np.int8)
    order = torch.argsort(scores, descending=True)
    sorted_boxes = boxes[order]
    iou_matrix = batch_probiou(sorted_boxes, sorted_boxes).triu_(diagonal=1)
    keep = torch.nonzero(iou_matrix.max(dim=0)[0] < threshold).squeeze_(-1)
    return order[keep]


def xywh2xyxy(x):
    """Convert boxes from centre-xywh to corner-xyxy format.

    For PyTorch tensors, delegates to torchvision.ops.box_convert which provides
    an optimized implementation. For numpy arrays, uses simple arithmetic.

    The conversion formula is standard:
        x1 = cx - w/2, y1 = cy - h/2, x2 = cx + w/2, y2 = cy + h/2

    References:
        - torchvision.ops.box_convert: https://pytorch.org/vision/main/generated/torchvision.ops.box_convert.html
        - Bounding box formats guide: https://albumentations.ai/docs/getting_started/bounding_boxes_augmentation/

    Args:
        x: (..., 4) tensor or array with (cx, cy, w, h) in the last dimension.

    Returns:
        Same-type array/tensor with (x1, y1, x2, y2) coordinates.
    """
    import torchvision

    if isinstance(x, torch.Tensor):
        return torchvision.ops.box_convert(x, "cxcywh", "xyxy")
    # For numpy: stack computation to avoid intermediate allocations
    cx, cy, w, h = x[..., 0], x[..., 1], x[..., 2], x[..., 3]
    return np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], axis=-1)


def non_max_suppression(
    prediction,
    conf_thres=0.25,
    iou_thres=0.45,
    classes=None,
    agnostic=False,
    multi_label=False,
    labels=(),
    max_det=300,
    nc=0,
    max_time_img=0.05,
    max_nms=30000,
    max_wh=7680,
    in_place=True,
    rotated=False,
):
    """Run NMS on YOLO-format model output using torchvision.ops.

    Non-Maximum Suppression is a standard post-processing step for object
    detection that removes duplicate detections by suppressing boxes with
    high overlap (IoU) with higher-confidence boxes.

    This implementation:
    1. Filters predictions by confidence threshold
    2. Converts boxes from cxcywh to xyxy format
    3. Applies per-class NMS using class offsets (or class-agnostic if specified)
    4. Uses torchvision.ops.nms for the core suppression algorithm

    References:
        - torchvision.ops.nms: https://pytorch.org/vision/main/generated/torchvision.ops.nms.html
        - NMS tutorial: https://learnopencv.com/non-maximum-suppression-theory-and-implementation-in-pytorch/
        - Neubeck & Van Gool, "Efficient Non-Maximum Suppression", ICPR 2006

    Args:
        prediction: Raw model output tensor.
        conf_thres: Minimum confidence to keep a detection.
        iou_thres: IoU threshold for NMS suppression.
        classes: Optional class indices to filter.
        agnostic: If True, run class-agnostic NMS.
        multi_label: Allow multiple labels per box.
        labels: Prior labels for auto-labelling.
        max_det: Maximum detections per image.
        nc: Number of classes (inferred if 0).
        max_time_img: Per-image time budget in seconds.
        max_nms: Cap on boxes fed into NMS.
        max_wh: Class-offset scale for per-class NMS.
        in_place: Modify prediction tensor in place.
        rotated: Use rotated-box NMS.

    Returns:
        List of (num_kept, 6+nm) tensors per batch image.
    """
    import torchvision

    if not (0 <= conf_thres <= 1):
        raise ValueError(f"conf_thres must be in [0, 1], got {conf_thres}")
    if not (0 <= iou_thres <= 1):
        raise ValueError(f"iou_thres must be in [0, 1], got {iou_thres}")

    # Handle tuple outputs (e.g., model returning (inference_out, loss_out))
    pred = prediction[0] if isinstance(prediction, (list, tuple)) else prediction
    batch_size = pred.shape[0]

    # Infer dimensions: prediction is (batch, 4+nc+nm, num_boxes)
    num_classes = nc if nc > 0 else pred.shape[1] - 4
    num_masks = pred.shape[1] - num_classes - 4
    class_end_idx = 4 + num_classes

    # Pre-filter: find boxes where max class score exceeds threshold
    conf_mask = pred[:, 4:class_end_idx].amax(dim=1) > conf_thres

    # Transpose to (batch, num_boxes, 4+nc+nm) for easier indexing
    pred = pred.transpose(-1, -2)

    # Convert boxes from xywh to xyxy if not rotated
    if not rotated:
        box_coords = xywh2xyxy(pred[..., :4])
        if in_place:
            pred[..., :4] = box_coords
        else:
            pred = torch.cat([box_coords, pred[..., 4:]], dim=-1)

    timeout = 2.0 + max_time_img * batch_size
    allow_multi = multi_label and num_classes > 1
    start_time = time.time()

    results = [torch.zeros((0, 6 + num_masks), device=pred.device) for _ in range(batch_size)]

    for batch_idx in range(batch_size):
        candidates = pred[batch_idx][conf_mask[batch_idx]]

        # Inject prior labels if provided
        if labels and len(labels[batch_idx]) > 0 and not rotated:
            prior = labels[batch_idx]
            prior_dets = torch.zeros((len(prior), num_classes + num_masks + 4), device=candidates.device)
            prior_dets[:, :4] = xywh2xyxy(prior[:, 1:5])
            prior_dets[torch.arange(len(prior)), prior[:, 0].long() + 4] = 1.0
            candidates = torch.cat([candidates, prior_dets], dim=0)

        if candidates.shape[0] == 0:
            continue

        # Split into boxes, class scores, and mask coefficients
        boxes = candidates[:, :4]
        class_scores = candidates[:, 4:class_end_idx]
        mask_coeffs = candidates[:, class_end_idx:]

        # Build detection tensor: (x1, y1, x2, y2, conf, class_id, [masks...])
        if allow_multi:
            # Multiple labels per box: expand all above-threshold class predictions
            above_thresh = class_scores > conf_thres
            row_idx, col_idx = torch.where(above_thresh)
            detections = torch.cat(
                [
                    boxes[row_idx],
                    class_scores[row_idx, col_idx, None],
                    col_idx[:, None].float(),
                    mask_coeffs[row_idx],
                ],
                dim=1,
            )
        else:
            # Single best class per box
            best_conf, best_cls = class_scores.max(dim=1, keepdim=True)
            valid = best_conf.squeeze(-1) > conf_thres
            detections = torch.cat([boxes, best_conf, best_cls.float(), mask_coeffs], dim=1)[valid]

        # Filter by class if specified
        if classes is not None:
            class_tensor = torch.tensor(classes, device=detections.device)
            keep_class = (detections[:, 5:6] == class_tensor).any(dim=1)
            detections = detections[keep_class]

        num_dets = detections.shape[0]
        if num_dets == 0:
            continue

        # Limit candidates before NMS for efficiency
        if num_dets > max_nms:
            top_k = detections[:, 4].argsort(descending=True)[:max_nms]
            detections = detections[top_k]

        # Apply NMS
        det_boxes = detections[:, :4]
        det_scores = detections[:, 4]

        if rotated:
            # Rotated NMS: boxes are (cx, cy, w, h, angle)
            class_offset = detections[:, 5:6] * (0 if agnostic else max_wh)
            obb = torch.cat([det_boxes[:, :2] + class_offset, det_boxes[:, 2:4], detections[:, -1:]], dim=-1)
            keep = nms_rotated(obb, det_scores, iou_thres)
        else:
            # Standard NMS with class offset for per-class behaviour
            class_offset = detections[:, 5:6] * (0 if agnostic else max_wh)
            offset_boxes = det_boxes + class_offset
            keep = torchvision.ops.nms(offset_boxes, det_scores, iou_thres)

        results[batch_idx] = detections[keep[:max_det]]

        if (time.time() - start_time) > timeout:
            LOG.warning(f"NMS time limit {timeout:.3f}s exceeded")
            break

    return results


def compute_letterbox_inverse(src_hw, dst_hw):
    """Compute the inverse transform parameters for letterbox rescaling.

    Letterboxing preserves aspect ratio by scaling to fit within target dimensions
    and centering with padding. This function computes the parameters needed to
    reverse that transform (map coordinates from letterboxed space back to original).

    Args:
        src_hw: (height, width) of the letterboxed image.
        dst_hw: (height, width) of the original image.

    Returns:
        Tuple of (scale_factor, (pad_x, pad_y)).
    """
    scale = min(src_hw[0] / dst_hw[0], src_hw[1] / dst_hw[1])
    pad_x = round((src_hw[1] - dst_hw[1] * scale) / 2 - 0.1)
    pad_y = round((src_hw[0] - dst_hw[0] * scale) / 2 - 0.1)
    return scale, (pad_x, pad_y)


def scale_boxes(img1_shape, boxes, img0_shape, ratio_pad=None, padding=True, xywh=False):
    """Rescale boxes from letterboxed image space to original image space.

    When an image is letterboxed for model input, detected box coordinates are
    in the letterboxed coordinate system. This function reverses the transform:
    1. Subtract the padding offset to shift coordinates to the resized image
    2. Divide by the scale factor to map to original image coordinates
    3. Clip to image boundaries to handle any numerical edge cases

    Args:
        img1_shape: (height, width) of the letterboxed image.
        boxes: (..., 4) tensor of bounding boxes.
        img0_shape: (height, width) of the original image.
        ratio_pad: Optional precomputed (ratio, pad); computed if None.
        padding: Whether letterbox padding was applied.
        xywh: Whether boxes are in xywh format (vs xyxy).

    Returns:
        Rescaled boxes clipped to original image bounds.
    """
    if ratio_pad is not None:
        scale, (pad_x, pad_y) = ratio_pad[0][0], ratio_pad[1]
    else:
        scale, (pad_x, pad_y) = compute_letterbox_inverse(img1_shape, img0_shape)

    # Remove padding offset
    if padding:
        boxes[..., 0] -= pad_x
        boxes[..., 1] -= pad_y
        if not xywh:
            boxes[..., 2] -= pad_x
            boxes[..., 3] -= pad_y

    # Scale back to original dimensions
    boxes[..., :4] /= scale

    return clip_boxes_to_image(boxes, img0_shape)


def clip_boxes_to_image(boxes, image_hw):
    """Constrain bounding boxes to lie within image boundaries.

    Clips x coordinates to [0, width] and y coordinates to [0, height].
    This is a standard operation to ensure valid box coordinates.

    See Also:
        - torch.clamp: https://pytorch.org/docs/stable/generated/torch.clamp.html
        - numpy.clip: https://numpy.org/doc/stable/reference/generated/numpy.clip.html

    Args:
        boxes: (..., 4) tensor or array in xyxy format.
        image_hw: (height, width) tuple.

    Returns:
        Clipped boxes (same object, modified in-place).
    """
    height, width = image_hw
    if isinstance(boxes, torch.Tensor):
        boxes[..., [0, 2]] = boxes[..., [0, 2]].clamp(min=0, max=width)
        boxes[..., [1, 3]] = boxes[..., [1, 3]].clamp(min=0, max=height)
    else:
        # Use assignment (fancy indexing creates a copy, so out= doesn't work)
        boxes[..., [0, 2]] = boxes[..., [0, 2]].clip(0, width)
        boxes[..., [1, 3]] = boxes[..., [1, 3]].clip(0, height)
    return boxes


# Keep old name as alias for compatibility
clip_boxes = clip_boxes_to_image


def apply_mask_prototypes(protos, coefficients, bboxes, target_hw, upsample=False):
    """Generate instance masks from prototype masks and per-detection coefficients.

    Implements the mask assembly step from YOLACT-style instance segmentation:
    1. Linear combination: mask = sigmoid(coefficients @ prototypes)
    2. Crop each mask to its bounding box
    3. Optionally upsample to target resolution

    This approach decouples mask generation from detection, enabling real-time
    instance segmentation by using a small set of shared prototype masks.

    References:
        - Bolya et al., "YOLACT: Real-time Instance Segmentation", ICCV 2019
          https://arxiv.org/abs/1904.02689

    See Also:
        - torch.nn.functional.interpolate: https://pytorch.org/docs/stable/generated/torch.nn.functional.interpolate.html

    Args:
        protos: (num_protos, proto_h, proto_w) prototype mask tensor.
        coefficients: (num_detections, num_protos) mask coefficients.
        bboxes: (num_detections, 4) detection boxes in xyxy format.
        target_hw: (height, width) of the input image (for upsampling).
        upsample: Whether to upsample masks to target_hw.

    Returns:
        (num_detections, h, w) binary mask tensor (h, w depend on upsample).
    """
    num_protos, proto_h, proto_w = protos.shape
    target_h, target_w = target_hw

    # Linear combination: (n, num_protos) @ (num_protos, h*w) -> (n, h*w) -> (n, h, w)
    flat_protos = protos.float().reshape(num_protos, -1)
    raw_masks = torch.mm(coefficients, flat_protos).reshape(-1, proto_h, proto_w)
    activated_masks = torch.sigmoid(raw_masks)

    # Scale bboxes to prototype resolution for cropping
    x_scale, y_scale = proto_w / target_w, proto_h / target_h
    proto_bboxes = bboxes.clone()
    proto_bboxes[:, [0, 2]] *= x_scale
    proto_bboxes[:, [1, 3]] *= y_scale

    cropped = mask_bbox_crop(activated_masks, proto_bboxes)

    if upsample:
        # Add batch dim for interpolate, then remove
        cropped = F.interpolate(
            cropped.unsqueeze(0), target_hw, mode="bilinear", align_corners=False
        ).squeeze(0)

    return cropped > 0.5


def mask_bbox_crop(masks, bboxes):
    """Crop masks to their corresponding bounding boxes using broadcasting.

    Zeroes out all pixels outside each mask's bounding box by constructing
    a boolean grid mask from the box coordinates. This is equivalent to
    applying a rectangular window function to each mask.

    The implementation uses NumPy-style broadcasting:
    - x_coords has shape (1, 1, w) to broadcast across batch and height
    - y_coords has shape (1, h, 1) to broadcast across batch and width
    - Box corners have shape (n, 1, 1) to broadcast across spatial dims

    See Also:
        - PyTorch broadcasting: https://pytorch.org/docs/stable/notes/broadcasting.html

    Args:
        masks: (n, h, w) tensor of mask values.
        bboxes: (n, 4) tensor of xyxy bounding boxes.

    Returns:
        (n, h, w) tensor with pixels outside boxes set to zero.
    """
    n, h, w = masks.shape
    device, dtype = masks.device, bboxes.dtype

    # Create coordinate grids: (1, 1, w) for x, (1, h, 1) for y
    x_coords = torch.arange(w, device=device, dtype=dtype).view(1, 1, w)
    y_coords = torch.arange(h, device=device, dtype=dtype).view(1, h, 1)

    # Extract box corners as (n, 1, 1) for broadcasting
    x1 = bboxes[:, 0].view(n, 1, 1)
    y1 = bboxes[:, 1].view(n, 1, 1)
    x2 = bboxes[:, 2].view(n, 1, 1)
    y2 = bboxes[:, 3].view(n, 1, 1)

    # Build boolean mask: True inside box, False outside
    inside_box = (x_coords >= x1) & (x_coords < x2) & (y_coords >= y1) & (y_coords < y2)

    return masks * inside_box


def resize_masks_from_letterbox(masks, target_hw, remove_padding=True):
    """Resize masks from letterboxed resolution to original image dimensions.

    When masks are generated in letterboxed coordinate space, this function
    maps them back to original image dimensions by:
    1. Cropping out the padding region (if remove_padding=True)
    2. Resizing to target dimensions using bilinear interpolation

    See Also:
        - torch.nn.functional.interpolate: https://pytorch.org/docs/stable/generated/torch.nn.functional.interpolate.html

    Args:
        masks: (N, C, H, W) mask tensor in letterboxed space.
        target_hw: (height, width) of the original image.
        remove_padding: Whether to crop out letterbox padding first.

    Returns:
        (N, C, target_h, target_w) resized mask tensor.
    """
    _, _, src_h, src_w = masks.shape
    dst_h, dst_w = target_hw

    if remove_padding:
        # Compute letterbox parameters
        scale = min(src_h / dst_h, src_w / dst_w)
        content_w = int(dst_w * scale)
        content_h = int(dst_h * scale)
        pad_x = (src_w - content_w) // 2
        pad_y = (src_h - content_h) // 2

        # Crop to content region (remove padding)
        masks = masks[..., pad_y : pad_y + content_h, pad_x : pad_x + content_w]

    return F.interpolate(masks, target_hw, mode="bilinear", align_corners=False)


# Aliases for backward compatibility with the previous API
process_mask = apply_mask_prototypes
crop_mask = mask_bbox_crop
scale_masks = resize_masks_from_letterbox
