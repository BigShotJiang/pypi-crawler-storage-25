from __future__ import annotations

from datetime import datetime
from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.page_info import PageInfo

__all__ = [
    "ConnectorListType",
    "ConnectorListTypeConnection",
    "iter_connectors",
]


class ConnectorListType(GQLBaseModel):
    id: int
    account_id: Optional[int] = None
    url: str
    subscribed_events: Optional[int] = None
    notify_types: Optional[int] = None
    notify_constructor: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class ConnectorListTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[ConnectorListType]


def iter_connectors(client, *, page_size: int = 200) -> Iterator[ConnectorListType]:
    """Iterate connector summaries."""
    return paginate(
        client.connectors,
        ConnectorListTypeConnection,
        page_size=page_size,
    )
