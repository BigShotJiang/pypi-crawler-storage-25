from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import DataSourceType
from .base_models.page_info import PageInfo

__all__ = [
    "DataSourceTypeConnection",
    "iter_data_sources",
]


class DataSourceTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[DataSourceType]


def iter_data_sources(
    client,
    *,
    is_device: Optional[bool] = None,
    serial_number: Optional[str] = None,
    device_serial_number: Optional[str] = None,
    mac_address: Optional[str] = None,
    page_size: int = 200,
) -> Iterator[DataSourceType]:
    kwargs = {
        "isDevice": is_device,
        "serialNumber": serial_number,
        "deviceSerialNumber": device_serial_number,
        "macAddress": mac_address,
    }
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.data_sources,
        DataSourceTypeConnection,
        page_size=page_size,
        **kwargs,
    )
