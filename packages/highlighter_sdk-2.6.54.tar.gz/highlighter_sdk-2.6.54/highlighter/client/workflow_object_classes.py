from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import WorkflowObjectClassType
from .base_models.page_info import PageInfo

__all__ = [
    "WorkflowObjectClassTypeConnection",
    "iter_workflow_object_classes",
]


class WorkflowObjectClassTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[WorkflowObjectClassType]


def iter_workflow_object_classes(
    client,
    *,
    workflow_id: object,
    page_size: int = 200,
):
    if workflow_id is None:
        raise TypeError("workflow_id is required")
    return paginate(
        client.workflow_object_classes,
        WorkflowObjectClassTypeConnection,
        page_size=page_size,
        workflowId=workflow_id,
    )
