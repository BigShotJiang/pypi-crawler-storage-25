from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.page_info import PageInfo

__all__ = [
    "ModelListType",
    "ModelListTypeConnection",
    "iter_models",
]


class ModelListType(GQLBaseModel):
    id: int
    name: str
    format: Optional[str] = None
    url: Optional[str] = None
    timeout: Optional[int] = None


class ModelListTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[ModelListType]


def iter_models(client, *, page_size: int = 200) -> Iterator[ModelListType]:
    """Iterate model summaries, not full model records."""
    return paginate(
        client.models,
        ModelListTypeConnection,
        page_size=page_size,
    )
