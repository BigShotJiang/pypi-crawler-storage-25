from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import WorkflowOrderType
from .base_models.page_info import PageInfo

__all__ = [
    "WorkflowOrderTypeConnection",
    "iter_workflow_orders",
]


class WorkflowOrderTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[WorkflowOrderType]


def iter_workflow_orders(
    client,
    *,
    workflow_id: object,
    page_size: int = 200,
):
    if workflow_id is None:
        raise TypeError("workflow_id is required")
    return paginate(
        client.workflow_orders,
        WorkflowOrderTypeConnection,
        page_size=page_size,
        workflowId=workflow_id,
    )
