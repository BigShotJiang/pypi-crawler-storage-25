from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import UserType
from .base_models.page_info import PageInfo

__all__ = [
    "UserTypeConnection",
    "iter_users",
]


class UserTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[UserType]


def iter_users(client, *, page_size: int = 200):
    return paginate(
        client.users,
        UserTypeConnection,
        page_size=page_size,
    )
