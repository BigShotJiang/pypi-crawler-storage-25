from __future__ import annotations

from typing import Iterator, List, Optional

from ..core import GQLBaseModel, paginate
from .base_models.base_models import TaskDefinitionType
from .base_models.page_info import PageInfo

__all__ = [
    "TaskDefinitionTypeConnection",
    "iter_task_definitions",
]


class TaskDefinitionTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[TaskDefinitionType]


def iter_task_definitions(
    client,
    *,
    task_type: Optional[str] = None,
    page_size: int = 200,
) -> Iterator[TaskDefinitionType]:
    kwargs = {}
    if task_type is not None:
        kwargs["taskType"] = task_type
    return paginate(
        client.task_definitions,
        TaskDefinitionTypeConnection,
        page_size=page_size,
        **kwargs,
    )
