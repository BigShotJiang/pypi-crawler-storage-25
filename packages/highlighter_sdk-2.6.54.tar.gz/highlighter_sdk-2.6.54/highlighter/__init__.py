# aiko_services will print logs to stdout if AIKO_LOG_MQTT=all or
# register its own logging.StreamHandler if AIKO_LOG_MQTT is unset,
# both causing duplication of logs with the StreamHandler created below
import os

os.environ["AIKO_LOG_MQTT"] = "true"

# Preserve the historical top-level API without eagerly importing the heavy
# subpackages that slow down CLI startup.
import importlib as _importlib

_SUBPACKAGES = ["cli", "client", "core", "processors", "version"]


def __getattr__(name):
    for pkg in _SUBPACKAGES:
        mod = _importlib.import_module(f".{pkg}", __name__)
        if hasattr(mod, name):
            val = getattr(mod, name)
            globals()[name] = val
            return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    for pkg in _SUBPACKAGES:
        mod = _importlib.import_module(f".{pkg}", __name__)
        for attr in getattr(mod, "__all__", [k for k in dir(mod) if not k.startswith("_")]):
            globals().setdefault(attr, getattr(mod, attr))
    return list(globals().keys())
