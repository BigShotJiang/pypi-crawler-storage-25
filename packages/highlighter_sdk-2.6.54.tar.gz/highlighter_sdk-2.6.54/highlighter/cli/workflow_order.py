import json
from itertools import islice
from typing import List, Optional

import click

from ..client import HLJSONEncoder, WorkflowOrderType, iter_workflow_orders
from ..core import GQLBaseModel


@click.group("workflow-order")
@click.pass_context
def workflow_order_group(ctx):
    pass


@workflow_order_group.command("list")
@click.option(
    "-w",
    "--workflow-id",
    type=str,
    required=True,
    help="Workflow ID to list orders for",
)
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Output format",
)
@click.option("--limit", type=int, default=100, show_default=True, help="Maximum number of results to return")
@click.pass_context
def list_command(ctx, workflow_id, format, limit):
    """List workflow orders for a workflow."""
    client = ctx.obj["client"]
    items_iter = iter_workflow_orders(client, workflow_id=workflow_id)
    items = list(islice(items_iter, limit))

    if format == "json":
        click.echo(json.dumps([item.model_dump(mode="json") for item in items], indent=2, cls=HLJSONEncoder))
        return

    if not items:
        click.echo("No workflow orders found.")
        return

    click.echo(f"Workflow orders ({len(items)} total):")
    click.echo()
    for item in items:
        state = item.state or "—"
        name = item.name or "—"
        total = item.cases_total if item.cases_total is not None else "?"
        pending = item.cases_pending if item.cases_pending is not None else "?"
        click.echo(f"  {item.id}  {name}  [{state}]  cases: {total} total, {pending} pending")
    click.echo()


@workflow_order_group.command("create")
@click.option("-n", "--name", type=str, required=True, help="Unique name for the order")
@click.option(
    "-w",
    "--workflow-id",
    type=str,
    required=True,
    help="Workflow ID to create the order in",
)
@click.option(
    "--state",
    type=click.Choice(["draft", "approved"]),
    default="approved",
    show_default=True,
    help="Initial state of the order",
)
@click.option(
    "--case-matching-strategy",
    type=click.Choice(["geolocation", "ingestion_path", "none"]),
    default=None,
    help="Strategy for matching files to cases",
)
@click.pass_context
def create_command(ctx, name, workflow_id, state, case_matching_strategy):
    """Create a new workflow order."""
    client = ctx.obj["client"]

    class CreateWorkflowOrderPayload(GQLBaseModel):
        errors: List[str]
        workflow_order: Optional[WorkflowOrderType] = None

    kwargs = dict(name=name, workflowId=workflow_id, state=state)
    if case_matching_strategy is not None:
        kwargs["caseMatchingStrategy"] = case_matching_strategy

    result = client.createWorkflowOrder(return_type=CreateWorkflowOrderPayload, **kwargs).gql_dict()

    if result.get("errors"):
        raise click.ClickException(f"Failed to create workflow order: {result['errors']}")
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@workflow_order_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the workflow order to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete a workflow order"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete workflow order {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class DeleteWorkflowOrderPayload(GQLBaseModel):
        errors: List[str]
        workflow_order: Optional[WorkflowOrderType] = None

    result = client.deleteWorkflowOrder(return_type=DeleteWorkflowOrderPayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
