import json
from typing import List, Optional

import click
import yaml

from ..client import HLJSONEncoder, ImageQueueType, StepType
from ..core import GQLBaseModel
from .common import _to_pathlib


@click.group("step")
@click.pass_context
def step_group(ctx):
    pass


@step_group.command("create")
@click.option(
    "-n",
    "--name",
    type=str,
    required=True,
)
@click.option(
    "-p",
    "--workflow-id",
    type=str,
    required=True,
)
@click.option(
    "-b",
    "--batch-size",
    type=int,
    required=False,
    default=10,
)
@click.option(
    "--consumable",
    is_flag=True,
)
@click.option(
    "--lockable",
    is_flag=True,
)
@click.option(
    "--capacity",
    type=int,
    required=False,
    default=None,
)
@click.option(
    "--user-ids",
    type=int,
    multiple=True,
)
@click.option(
    "-i",
    "--ids-txt",
    type=click.Path(file_okay=True, writable=False),
    required=True,
    callback=_to_pathlib,
)
@click.pass_context
def create(ctx, name, workflow_id, batch_size, consumable, lockable, capacity, user_ids, ids_txt):
    client = ctx.obj["client"]

    result = client.createImageQueue(return_type=TrainingRunType, id=id)

    result_str = yaml.dump(result.dict())
    print(f"{result_str}")


@step_group.command("create-machine-assessment")
@click.option("-n", "--name", type=str, required=True, help="Name for the step")
@click.option(
    "-w",
    "--workflow-id",
    type=str,
    required=True,
    help="Workflow ID to add the step to",
)
@click.option(
    "--task-definition-id",
    type=str,
    required=True,
    help="Task definition UUID — determines the machine agent to auto-assign",
)
@click.option(
    "--previous-step-id",
    type=str,
    default=None,
    help="ID of the step this step follows",
)
@click.pass_context
def create_machine_assessment(ctx, name, workflow_id, task_definition_id, previous_step_id):
    """Create a machine assessment step and auto-assign its agent."""
    client = ctx.obj["client"]

    class CreateWorkflowStepPayload(GQLBaseModel):
        errors: List[str]
        workflow_step: Optional[StepType] = None

    kwargs = dict(
        name=name,
        workflowId=workflow_id,
        stepType="machine_assessment",
        taskDefinitionId=task_definition_id,
    )
    if previous_step_id:
        kwargs["previousStepId"] = previous_step_id

    result = client.createWorkflowStep(return_type=CreateWorkflowStepPayload, **kwargs).gql_dict()

    if result.get("errors"):
        raise click.ClickException(f"Failed to create step: {result['errors']}")
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@step_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the step to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete a step"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete step {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class ImageQueueDeleteType(GQLBaseModel):
        id: Optional[str] = None

    class DeleteImageQueuePayload(GQLBaseModel):
        errors: List[str]
        image_queue: Optional[ImageQueueDeleteType] = None

    result = client.deleteImageQueue(return_type=DeleteImageQueuePayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
