import json
from itertools import islice
from typing import List, Optional

import click

from ..client import HLJSONEncoder, TaskDefinitionType, iter_task_definitions
from ..core import GQLBaseModel


@click.group("task-definition")
@click.pass_context
def task_definition_group(ctx):
    pass


@task_definition_group.command("list")
@click.option(
    "--task-type",
    type=str,
    default=None,
    help="Filter by task type (e.g. KmlToEntity::EntityDetection)",
)
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Output format",
)
@click.option("--limit", type=int, default=100, show_default=True, help="Maximum number of results to return")
@click.pass_context
def list_command(ctx, task_type, format, limit):
    """List task definitions for the account."""
    client = ctx.obj["client"]
    items_iter = iter_task_definitions(client, task_type=task_type)
    items = list(islice(items_iter, limit))

    if format == "json":
        click.echo(json.dumps([item.model_dump(mode="json") for item in items], indent=2, cls=HLJSONEncoder))
        return

    if not items:
        click.echo("No task definitions found.")
        return

    click.echo(f"Task definitions ({len(items)} total):")
    click.echo()
    for item in items:
        click.echo(f"  {item.id}  {item.name}  [{item.task_type}]")
        if item.entity_external_id_type:
            click.echo(f"    external_id_type: {item.entity_external_id_type}")
        if item.entity_external_id_node_name:
            click.echo(f"    external_id_field: {item.entity_external_id_node_name}")
    click.echo()


@task_definition_group.command("read")
@click.option("-i", "--id", "td_id", type=str, required=True, help="Task definition ID")
@click.pass_context
def read_command(ctx, td_id):
    """Read a single task definition by ID."""
    client = ctx.obj["client"]
    result = client.taskDefinition(return_type=TaskDefinitionType, id=td_id)
    if result is None:
        raise click.ClickException(f"Task definition {td_id} not found")
    click.echo(json.dumps(result.gql_dict(), cls=HLJSONEncoder))


@task_definition_group.command("create")
@click.option("-n", "--name", type=str, required=True, help="Name of the task definition")
@click.option(
    "--task-type",
    type=str,
    required=True,
    help="Task type (e.g. KmlToEntity::EntityDetection, DbfToEntity::EntityDetection, Review)",
)
@click.option("--object-class-id", type=str, default=None, help="Object class UUID")
@click.option(
    "--entity-external-id-type",
    type=str,
    default=None,
    help="External ID type for created entities (e.g. SYSTEM_ID)",
)
@click.option(
    "--entity-external-id-field-name",
    type=str,
    default=None,
    help="Field name in source file containing the external ID",
)
@click.pass_context
def create_command(
    ctx, name, task_type, object_class_id, entity_external_id_type, entity_external_id_field_name
):
    """Create a new task definition."""
    client = ctx.obj["client"]

    class CreateTaskDefinitionPayload(GQLBaseModel):
        errors: List[str]
        task_definition: Optional[TaskDefinitionType] = None

    result = client.createTaskDefinition(
        return_type=CreateTaskDefinitionPayload,
        name=name,
        taskType=task_type,
        objectClassId=object_class_id,
        entityExternalIdType=entity_external_id_type,
        entityExternalIdNodeName=entity_external_id_field_name,
    ).gql_dict()

    if result.get("errors"):
        raise click.ClickException(f"Failed to create task definition: {result['errors']}")
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@task_definition_group.command("delete")
@click.option("-i", "--id", "td_id", type=str, required=True, help="Task definition ID")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete_command(ctx, td_id, yes):
    """Delete a task definition."""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete task definition {td_id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class DeleteTaskDefinitionPayload(GQLBaseModel):
        errors: List[str]
        task_definition: Optional[TaskDefinitionType] = None

    result = client.deleteTaskDefinition(return_type=DeleteTaskDefinitionPayload, id=td_id).gql_dict()
    if result.get("errors"):
        raise click.ClickException(f"Failed to delete task definition: {result['errors']}")
    click.echo(json.dumps(result, cls=HLJSONEncoder))
