try:
    import paddle
except ModuleNotFoundError as _:
    raise ModuleNotFoundError(
        "The paddlepaddle package is not installed, use `pip install highlighter-sdk[paddle]`"
    )

from .trainer import PaddleClsTrainer

__all__ = ["PaddleClsTrainer"]
