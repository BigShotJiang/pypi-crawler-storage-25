import json
import logging
import os
import subprocess  # nosec B404 — used to invoke PADDLE_EXPORT_PYTHON for ONNX export
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

import numpy as np
import paddle
import yaml

from highlighter.client import TrainingRunType, json_tools
from highlighter.client.evaluation import (
    EvaluationMetric,
    EvaluationMetricCodeEnum,
    EvaluationMetricResult,
    find_or_create_evaluation_metric,
)
from highlighter.client.gql_client import HLClient
from highlighter.client.io import download_files
from highlighter.datasets.formats.yolo.writer import ImageFolderWriter
from highlighter.trainers.base_trainer import BaseTrainer

__all__ = ["PaddleClsTrainer"]

logger = logging.getLogger(__name__)

# ImageNet normalization constants
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]

# Model name -> paddle.vision.models constructor
_MODEL_REGISTRY = {
    "resnet18": paddle.vision.models.resnet18,
    "resnet34": paddle.vision.models.resnet34,
    "resnet50": paddle.vision.models.resnet50,
    "resnet101": paddle.vision.models.resnet101,
    "resnet152": paddle.vision.models.resnet152,
    "mobilenet_v2": paddle.vision.models.mobilenet_v2,
}


def _export_onnx_subprocess(
    model_name: str,
    num_classes: int,
    checkpoint: Path,
    onnx_filepath: Path,
    imgsz: int,
):
    """Export PaddlePaddle classification model to ONNX using PADDLE_EXPORT_PYTHON.

    Runs paddle.onnx.export() in the export Python environment which has
    paddle2onnx installed alongside PaddlePaddle.
    """
    export_python = os.environ.get("PADDLE_EXPORT_PYTHON", sys.executable)
    if not Path(export_python).is_file():
        raise RuntimeError(f"PADDLE_EXPORT_PYTHON not found: {export_python}")

    script = f"""\
import paddle
import paddle.vision.models as models

model_fn = getattr(models, {model_name!r})
model = model_fn(num_classes={num_classes})
state_dict = paddle.load({str(checkpoint)!r})
model.set_state_dict(state_dict)
model.eval()

export_model = paddle.nn.Sequential(model, paddle.nn.Softmax(axis=1))
input_spec = [paddle.static.InputSpec(
    shape=[None, 3, {imgsz}, {imgsz}], dtype="float32", name="image"
)]
paddle.onnx.export(export_model, {str(onnx_filepath.with_suffix(""))!r}, input_spec=input_spec)
"""

    env = os.environ.copy()
    env.pop("FLAGS_enable_pir_api", None)

    try:
        subprocess.run(  # nosec B603 — export_python is from trusted env var
            [export_python, "-c", script],
            capture_output=True,
            check=True,
            text=True,
            env=env,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"ONNX export failed.\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}") from e

    if not onnx_filepath.exists():
        raise RuntimeError(f"ONNX export produced no output at {onnx_filepath}")

    logger.info(f"Exported ONNX model to {onnx_filepath}")


class EvaluationCharts:
    PER_CLASS = "Per Class Metrics"
    AGG = "Aggregate Metrics"


class PaddleClsTrainer(BaseTrainer):
    def __init__(
        self,
        training_run_dir: Path,
        training_run: TrainingRunType,
    ):
        super().__init__(training_run_dir, training_run)

    def _combine_hl_datasets(self, datasets):
        combined_ds = super()._combine_hl_datasets(datasets)
        # Remap splits to match standard ML naming:
        #   HL "test" -> "val" (used for validation during training)
        #   HL "dev"  -> "test" (used for final evaluation)
        combined_ds.data_files_df.loc[combined_ds.data_files_df.split == "test", "split"] = "val"
        combined_ds.data_files_df.loc[combined_ds.data_files_df.split == "dev", "split"] = "test"
        return combined_ds

    @property
    def training_data_dir(self) -> Path:
        return self._training_run_dir / "datasets"

    def generate_trainer_specific_dataset(self, hl_dataset):
        if not (self.training_data_dir / "data.yaml").exists():
            self.training_data_dir.mkdir(exist_ok=True)
            filtered_hl_ds = self.filter_dataset(hl_dataset)

            image_cache_dir = self._training_run_dir / "images"
            unique_file_ids = list(filtered_hl_ds.data_files_df.data_file_id.unique())
            download_files(
                HLClient.get_client(),
                file_ids=unique_file_ids,
                output_dir=image_cache_dir,
                structure="uuid",
                check_cache=True,
            )

            writer = ImageFolderWriter(
                output_dir=self.training_data_dir,
                image_cache_dir=image_cache_dir,
                categories=self.get_categories(),
                task="classify",
                crop_args=self._training_run.crop_args,
            )
            writer.write(filtered_hl_ds)

    def _get_model(self, num_classes: int, pretrained: bool = None):
        model_name = self._training_run.trainer_config.get("model", "resnet50")
        model_fn = _MODEL_REGISTRY.get(model_name)
        if model_fn is None:
            raise ValueError(f"Unknown model '{model_name}', supported: {list(_MODEL_REGISTRY.keys())}")
        if pretrained is None:
            pretrained = self._training_run.trainer_config.get("pretrained", True)
        if pretrained and num_classes != 1000:
            # Load pretrained backbone, then replace the classification head
            model = model_fn(pretrained=True, num_classes=1000)
            if hasattr(model, "fc"):
                in_features = model.fc.weight.shape[0]
                model.fc = paddle.nn.Linear(in_features, num_classes)
            elif hasattr(model, "classifier"):
                in_features = model.classifier.weight.shape[0]
                model.classifier = paddle.nn.Linear(in_features, num_classes)
            else:
                raise ValueError(f"Cannot find classification head on {model_name}")
        else:
            model = model_fn(pretrained=pretrained, num_classes=num_classes)
        return model

    def _get_imgsz(self) -> int:
        return int(self._training_run.trainer_config.get("imgsz", 224))

    def _make_train_transforms(self, imgsz: int):
        return paddle.vision.transforms.Compose(
            [
                paddle.vision.transforms.Resize((imgsz, imgsz)),
                paddle.vision.transforms.RandomHorizontalFlip(),
                paddle.vision.transforms.ToTensor(),
                paddle.vision.transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
            ]
        )

    def _make_eval_transforms(self, imgsz: int):
        return paddle.vision.transforms.Compose(
            [
                paddle.vision.transforms.Resize((imgsz, imgsz)),
                paddle.vision.transforms.ToTensor(),
                paddle.vision.transforms.Normalize(mean=IMAGENET_MEAN, std=IMAGENET_STD),
            ]
        )

    def _count_classes_from_dataset_dir(self) -> int:
        train_dir = self.training_data_dir / "train"
        class_dirs = sorted([d for d in train_dir.iterdir() if d.is_dir()])
        return len(class_dirs)

    def _validate_on_split(self, model, split_dir: Path, imgsz: int, batch_size: int) -> float:
        if not split_dir.exists():
            return 0.0

        eval_transforms = self._make_eval_transforms(imgsz)
        val_dataset = paddle.vision.datasets.DatasetFolder(str(split_dir), transform=eval_transforms)
        if len(val_dataset) == 0:
            return 0.0

        val_loader = paddle.io.DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
        )

        model.eval()
        correct = 0
        total = 0
        with paddle.no_grad():
            for images, labels in val_loader:
                outputs = model(images)
                preds = paddle.argmax(outputs, axis=1)
                correct += int((preds == labels).sum())
                total += labels.shape[0]
        model.train()
        return correct / total if total > 0 else 0.0

    def train(self) -> Any:
        cfg = self._training_run.trainer_config
        imgsz = self._get_imgsz()
        batch_size = int(cfg.get("batch", 16))
        epochs = int(cfg.get("epochs", 100))
        lr0 = float(cfg.get("lr0", 0.01))
        momentum = float(cfg.get("momentum", 0.937))
        weight_decay = float(cfg.get("weight_decay", 0.0005))
        warmup_epochs = int(cfg.get("warmup_epochs", 3))
        use_amp = bool(cfg.get("amp", False))
        workers = int(cfg.get("workers", 4))

        # Device setup
        if paddle.device.is_compiled_with_cuda() and paddle.device.cuda.device_count() > 0:
            paddle.device.set_device("gpu:0")
            logger.info("Using GPU for training")
        else:
            paddle.device.set_device("cpu")
            logger.info("Using CPU for training")

        num_classes = self._count_classes_from_dataset_dir()
        model = self._get_model(num_classes)

        # Datasets
        train_transforms = self._make_train_transforms(imgsz)

        train_dataset = paddle.vision.datasets.DatasetFolder(
            str(self.training_data_dir / "train"), transform=train_transforms
        )
        val_dir = self.training_data_dir / "val"

        train_loader = paddle.io.DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=workers,
            drop_last=True,
        )

        # Optimizer with cosine annealing + warmup
        steps_per_epoch = max(len(train_loader), 1)
        total_steps = steps_per_epoch * epochs
        warmup_steps = steps_per_epoch * warmup_epochs

        scheduler = paddle.optimizer.lr.CosineAnnealingDecay(
            learning_rate=lr0,
            T_max=total_steps - warmup_steps,
        )
        if warmup_steps > 0:
            scheduler = paddle.optimizer.lr.LinearWarmup(
                learning_rate=scheduler,
                warmup_steps=warmup_steps,
                start_lr=lr0 / 100,
                end_lr=lr0,
            )

        optimizer = paddle.optimizer.Momentum(
            learning_rate=scheduler,
            momentum=momentum,
            weight_decay=weight_decay,
            parameters=model.parameters(),
        )

        loss_fn = paddle.nn.CrossEntropyLoss()
        scaler = paddle.amp.GradScaler(init_loss_scaling=1024) if use_amp else None

        # Training loop
        output_dir = self._training_run_dir / "output"
        output_dir.mkdir(exist_ok=True, parents=True)
        best_checkpoint = output_dir / "best_model.pdparams"
        best_acc = 0.0

        model.train()
        for epoch in range(epochs):
            running_loss = 0.0
            correct = 0
            total = 0

            for images, labels in train_loader:
                optimizer.clear_grad()

                if use_amp:
                    with paddle.amp.auto_cast():
                        outputs = model(images)
                        loss = loss_fn(outputs, labels)
                    scaled_loss = scaler.scale(loss)
                    scaled_loss.backward()
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    outputs = model(images)
                    loss = loss_fn(outputs, labels)
                    loss.backward()
                    optimizer.step()

                scheduler.step()

                running_loss += loss.item() * images.shape[0]
                preds = paddle.argmax(outputs, axis=1)
                correct += int((preds == labels).sum())
                total += labels.shape[0]

            train_acc = correct / total if total > 0 else 0.0
            avg_loss = running_loss / total if total > 0 else 0.0

            # Validation
            val_acc = self._validate_on_split(model, val_dir, imgsz, batch_size)

            logger.info(
                f"Epoch {epoch + 1}/{epochs} - loss: {avg_loss:.4f}, "
                f"train_acc: {train_acc:.4f}, val_acc: {val_acc:.4f}"
            )

            if val_acc >= best_acc:
                best_acc = val_acc
                paddle.save(model.state_dict(), str(best_checkpoint))
                logger.info(f"Saved best model (val_acc={val_acc:.4f})")

        # Always save final checkpoint
        final_checkpoint = output_dir / "last_model.pdparams"
        paddle.save(model.state_dict(), str(final_checkpoint))

        return best_checkpoint if best_checkpoint.exists() else final_checkpoint

    def export_onnx(self, checkpoint: Path) -> Path:
        num_classes = self._count_classes_from_dataset_dir()
        imgsz = self._get_imgsz()

        model_name = self._training_run.trainer_config.get("model", "resnet50")

        # Export to ONNX via PADDLE_EXPORT_PYTHON which has paddle2onnx installed.
        onnx_filepath = checkpoint.parent / "model.onnx"
        _export_onnx_subprocess(model_name, num_classes, checkpoint, onnx_filepath, imgsz)

        # Build artefact YAML
        if isinstance(self._training_run.crop_args, dict):
            crop_args_dict = self._training_run.crop_args
        elif self._training_run.crop_args is not None:
            crop_args_dict = self._training_run.crop_args.model_dump()
        else:
            crop_args_dict = None

        preprocessing_config = {
            "type": "torchvision",
            "ops": [
                {"type": "Resize", "kwargs": {"size": [imgsz, imgsz]}},
                {
                    "type": "Normalize",
                    "kwargs": {"mean": IMAGENET_MEAN, "std": IMAGENET_STD},
                },
            ],
        }

        d = dict(
            file_url=str(onnx_filepath.absolute()),
            type="OnnxOpset14",
            inference_config=dict(
                type="classifier",
                code="EntityClassifier",
                machine_agent_type_id="d4787671-3839-4af9-9b34-a686faafbfae",
                parameters=dict(
                    output_format="mmprev1",
                    cropper=crop_args_dict,
                    preprocessing_config=preprocessing_config,
                ),
            ),
        )

        artefact_path = checkpoint.parent / "artefact.yaml"
        with artefact_path.open("w") as f:
            yaml.dump(d, f)

        return artefact_path

    def evaluate(
        self, checkpoint: Path, cfg_path: Optional[Path] = None
    ) -> Dict[str, EvaluationMetricResult]:
        eval_metric_results: Dict[str, EvaluationMetricResult] = {}
        client = HLClient.get_client()

        num_classes = self._count_classes_from_dataset_dir()
        imgsz = self._get_imgsz()
        batch_size = int(self._training_run.trainer_config.get("batch", 16))

        model = self._get_model(num_classes, pretrained=False)
        state_dict = paddle.load(str(checkpoint))
        model.set_state_dict(state_dict)
        model.eval()

        # Run inference on validation set
        val_dir = self.training_data_dir / "val"
        if not val_dir.exists():
            val_dir = self.training_data_dir / "test"

        eval_transforms = self._make_eval_transforms(imgsz)
        val_dataset = paddle.vision.datasets.DatasetFolder(str(val_dir), transform=eval_transforms)
        val_loader = paddle.io.DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
        )

        all_preds = []
        all_labels = []
        all_top5_correct = 0
        total = 0

        with paddle.no_grad():
            for images, labels in val_loader:
                outputs = model(images)
                preds = paddle.argmax(outputs, axis=1)
                all_preds.extend(preds.numpy().tolist())
                all_labels.extend(labels.numpy().flatten().tolist())

                # Top-5 accuracy
                k = min(5, num_classes)
                _, top5_preds = paddle.topk(outputs, k=k, axis=1)
                for i, label in enumerate(labels.numpy().flatten()):
                    if int(label) in top5_preds[i].numpy().tolist():
                        all_top5_correct += 1
                total += labels.shape[0]

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)

        # Top-1 accuracy
        acc_top1 = float((all_preds == all_labels).sum()) / total if total > 0 else 0.0
        name = "Accuracy Top1"
        eval_metric_results[name] = self._get_hl_metric(
            client=client,
            code=EvaluationMetricCodeEnum.Other,
            chart=EvaluationCharts.AGG,
            desc="Top One Accuracy",
            name=name,
        ).result(acc_top1, self.training_run_id)

        # Top-5 accuracy
        acc_top5 = all_top5_correct / total if total > 0 else 0.0
        name = "Accuracy Top5"
        eval_metric_results[name] = self._get_hl_metric(
            client=client,
            code=EvaluationMetricCodeEnum.Other,
            chart=EvaluationCharts.AGG,
            desc="Top Five Accuracy",
            name=name,
        ).result(acc_top5, self.training_run_id)

        # Confusion matrix and per-class metrics
        cm = np.zeros((num_classes, num_classes), dtype=np.float64)
        for pred, label in zip(all_preds, all_labels):
            cm[int(label), int(pred)] += 1

        per_class_P, per_class_R = self._precision_recall_from_cm(cm, num_classes)

        categories = [c[1] for c in self.get_categories()]
        for idx, cat in enumerate(categories):
            name = f"Precision({cat.label})"
            eval_metric_results[name] = self._get_hl_metric(
                client=client,
                code=EvaluationMetricCodeEnum.Other,
                chart=EvaluationCharts.PER_CLASS,
                desc=f"One vs All Precision of ({cat.short_str()})",
                name=name,
                cat_uuid=cat,
            ).result(per_class_P[idx], self.training_run_id)

            name = f"Recall({cat.label})"
            eval_metric_results[name] = self._get_hl_metric(
                client=client,
                code=EvaluationMetricCodeEnum.Other,
                chart=EvaluationCharts.PER_CLASS,
                desc=f"One vs All Recall of ({cat.short_str()})",
                name=name,
                cat_uuid=cat,
            ).result(per_class_R[idx], self.training_run_id)

        # Average precision
        name = "Average Precision"
        ave_P = sum(per_class_P.values()) / len(per_class_P) if per_class_P else 0.0
        eval_metric_results[name] = self._get_hl_metric(
            client=client,
            code=EvaluationMetricCodeEnum.Other,
            chart=EvaluationCharts.AGG,
            desc="Average Precision",
            name=name,
        ).result(ave_P, self.training_run_id)

        # Save results
        with (Path(checkpoint).parent / "eval_metric_results.json").open("w") as f:
            json.dump(
                {k: e.model_dump() for k, e in eval_metric_results.items()},
                f,
                indent=2,
                cls=json_tools.HLJSONEncoder,
            )

        return eval_metric_results

    def _get_hl_metric(self, client, code, chart, desc, name, iou=None, cat_uuid=None):
        metric = EvaluationMetric(
            evaluation_id=self.evaluation_id,
            code=code,
            chart=chart,
            description=desc,
            name=name,
            object_class_uuid=cat_uuid,
            iou=iou,
        )
        return find_or_create_evaluation_metric(client, metric)[0]

    @staticmethod
    def _precision_recall_from_cm(cm, num_classes):
        precision = {}
        recall = {}
        for i in range(num_classes):
            TP = cm[i, i]
            FP = np.sum(cm[:, i]) - TP
            FN = np.sum(cm[i, :]) - TP
            precision[i] = float(TP / (TP + FP)) if (TP + FP) > 0 else 0.0
            recall[i] = float(TP / (TP + FN)) if (TP + FN) > 0 else 0.0
        return precision, recall
