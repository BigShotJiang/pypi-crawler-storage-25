"""RT-DETR ONNX detector capability.

Loads a PaddleDetection RT-DETR model exported to ONNX and runs object detection
inference. The ONNX model expects three inputs (image, im_shape, scale_factor)
so we use onnxruntime directly rather than OnnxPredictor (which requires single-input models).
"""

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import onnxruntime as ort
from PIL import Image
from shapely import geometry as geom

from highlighter.agent.capabilities.base_capability import Capability, StreamEvent
from highlighter.client import Annotation, DatumSource, Entity, Observation
from highlighter.core import OBJECT_CLASS_ATTRIBUTE_UUID
from highlighter.core.data_models import DataSample
from highlighter.predictors.ort.session import get_session

__all__ = ["OnnxRtdetr"]

logger = logging.getLogger(__name__)


class OnnxRtdetr(Capability):
    """Object detector capability using an RT-DETR ONNX model."""

    class InitParameters(Capability.InitParameters):
        onnx_file: str
        num_classes: int = 1
        conf_thresh: float = 0.1
        input_size: List[int] = [640, 640]
        object_class_id: Optional[str] = None

    def __init__(self, context):
        super().__init__(context)
        providers = ort.get_available_providers()
        provider_options = [{} for _ in providers]
        self._session = get_session(
            self.init_parameters.onnx_file,
            providers=providers,
            provider_options=provider_options,
        )
        self._input_names = [inp.name for inp in self._session.get_inputs()]
        self._output_names = [out.name for out in self._session.get_outputs()]
        self._input_size = self.init_parameters.input_size
        logger.info(
            "OnnxRtdetr loaded: inputs=%s outputs=%s",
            self._input_names,
            self._output_names,
        )

    def _preprocess(self, image: np.ndarray) -> dict:
        """Preprocess an image for RT-DETR inference."""
        h, w = image.shape[:2]
        target_h, target_w = self._input_size

        # Resize and normalize to [0, 1] float32
        pil_img = Image.fromarray(image).convert("RGB")
        pil_img = pil_img.resize((target_w, target_h), Image.Resampling.BILINEAR)
        img = np.array(pil_img, dtype=np.float32) / 255.0

        # HWC -> CHW, add batch dim
        img = np.transpose(img, (2, 0, 1))[np.newaxis, ...]

        im_shape = np.array([[float(target_h), float(target_w)]], dtype=np.float32)
        scale_factor = np.array([[float(target_h) / h, float(target_w) / w]], dtype=np.float32)
        return {"image": img, "im_shape": im_shape, "scale_factor": scale_factor}

    def _run_inference(self, preprocessed: dict) -> np.ndarray:
        """Run ONNX inference, mapping inputs by name."""
        feed = {}
        for name in self._input_names:
            # Match input names flexibly (may have prefixes like 'p2o.Div.0')
            if "image" in name or "img" in name:
                feed[name] = preprocessed["image"]
            elif "im_shape" in name or "shape" in name:
                feed[name] = preprocessed["im_shape"]
            elif "scale" in name:
                feed[name] = preprocessed["scale_factor"]
            else:
                raise ValueError(
                    f"Unsupported RT-DETR ONNX input {name!r}; expected image/im_shape/scale_factor"
                )

        outputs = self._session.run(self._output_names, feed)
        return outputs[0]  # Primary output: detections

    def process_frame(self, stream, data_samples: List[DataSample]) -> Tuple[StreamEvent, Dict]:
        entities = {}
        conf_thresh = self.init_parameters.conf_thresh
        object_class_id = self.init_parameters.object_class_id

        for data_sample in data_samples:
            if data_sample.content is None:
                continue

            image = data_sample.content
            preprocessed = self._preprocess(image)
            detections = self._run_inference(preprocessed)

            if detections is None or len(detections) == 0:
                continue

            h, w = image.shape[:2]
            for det in detections:
                if len(det) < 6:
                    continue
                class_id, score, x1, y1, x2, y2 = det[:6]
                if score < conf_thresh:
                    continue

                # Clamp to image bounds
                x1 = max(0, min(float(x1), w))
                y1 = max(0, min(float(y1), h))
                x2 = max(0, min(float(x2), w))
                y2 = max(0, min(float(y2), h))

                if x2 - x1 < 1 or y2 - y1 < 1:
                    continue

                location = geom.box(x1, y1, x2, y2)
                entity = Entity()
                entities[entity.id] = entity

                annotation = Annotation(
                    entity=entity,
                    location=location,
                    data_sample=data_sample,
                )

                if object_class_id:
                    observation_datum_source = DatumSource(
                        confidence=float(score),
                        frame_id=annotation.datum_source.frame_id,
                    )
                    Observation(
                        annotation=annotation,
                        attribute_id=OBJECT_CLASS_ATTRIBUTE_UUID,
                        value=object_class_id,
                        occurred_at=annotation.data_sample.recorded_at,
                        datum_source=observation_datum_source,
                    )

        return StreamEvent.OKAY, {"entities": entities}
