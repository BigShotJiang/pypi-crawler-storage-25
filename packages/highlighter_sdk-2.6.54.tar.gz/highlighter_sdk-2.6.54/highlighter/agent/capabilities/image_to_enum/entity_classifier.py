"""ONNX entity classifier capability.

Classifies existing entity bounding boxes using any ONNX classification model
(PaddlePaddle, PyTorch-exported, etc.). Crops each annotation, preprocesses,
runs ORT inference, and adds classification observations.
"""

import logging
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from uuid import UUID

import numpy as np
from PIL import Image
from pydantic import Field

from highlighter.agent.capabilities._crop_processor import CropProcessor
from highlighter.agent.capabilities.base_capability import Capability, StreamEvent
from highlighter.client.base_models.entities import Entities
from highlighter.client.base_models.entity import Entity
from highlighter.client.gql_client import HLClient
from highlighter.client.training_runs import TrainingRunArtefactType
from highlighter.core.data_models import DataSample
from highlighter.core.labeled_uuid import LabeledUUID
from highlighter.predictors.ort.session import get_session
from highlighter.predictors.output_category_descriptor import (
    EnumDescriptor,
    OutputCategoryDescriptor,
)
from highlighter.predictors.prediction import Prediction

__all__ = ["EntityClassifier"]

logger = logging.getLogger(__name__)

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)


class EntityClassifier(Capability):
    """Classify existing entity annotations using an ONNX classification model.

    Takes entities with bounding box annotations from an upstream detector,
    crops each annotation, runs classification via ONNX Runtime, and adds
    the predicted class as an observation on the annotation.
    """

    class InitParameters(Capability.InitParameters):
        onnx_file: Optional[str] = None
        training_run_artefact_id: Optional[UUID] = None
        num_classes: int
        class_lookup: Dict[int | str, OutputCategoryDescriptor]
        conf_thresh: float = 0.5
        input_size: List[int] = [224, 224]
        mean: List[float] = [0.485, 0.456, 0.406]
        std: List[float] = [0.229, 0.224, 0.225]
        crop_processor: CropProcessor = Field(default_factory=lambda: CropProcessor())

    def __init__(self, context):
        super().__init__(context)

        onnx_file = self.init_parameters.onnx_file
        if onnx_file is None:
            artefact_id = self.init_parameters.training_run_artefact_id
            if artefact_id is None:
                raise ValueError("Must provide `onnx_file` or `training_run_artefact_id`")
            artefact = HLClient.get_client().trainingRunArtefact(
                return_type=TrainingRunArtefactType, id=artefact_id
            )
            onnx_file = artefact.file_url

        import onnxruntime as ort

        providers = ort.get_available_providers()
        provider_options = [{} for _ in providers]
        self._session = get_session(onnx_file, providers=providers, provider_options=provider_options)
        self._input_name = self._session.get_inputs()[0].name
        self._input_size = self.init_parameters.input_size
        self._mean = np.array(self.init_parameters.mean, dtype=np.float32)
        self._std = np.array(self.init_parameters.std, dtype=np.float32)
        self._crop_processor = self.init_parameters.crop_processor

        # Build class index -> (attribute LabeledUUID, value LabeledUUID) mapping
        self._class_map: Dict[int, Tuple[LabeledUUID, LabeledUUID]] = {}
        for idx, desc in self.init_parameters.class_lookup.items():
            idx = int(idx)
            if isinstance(desc, EnumDescriptor):
                attr = LabeledUUID(desc.attribute_id, label=desc.attribute_label)
                value = LabeledUUID(desc.enum_id, label=desc.enum_label)
            else:
                from highlighter.core.const import OBJECT_CLASS_ATTRIBUTE_UUID

                attr = LabeledUUID(OBJECT_CLASS_ATTRIBUTE_UUID, label="object_class")
                value = LabeledUUID(desc.uuid, label=desc.label)
            self._class_map[idx] = (attr, value)

        logger.info(
            "EntityClassifier loaded: input=%s, classes=%d",
            self._input_name,
            len(self._class_map),
        )

    def _preprocess(self, crop: np.ndarray) -> np.ndarray:
        h, w = self._input_size
        pil_img = Image.fromarray(crop).convert("RGB").resize((w, h), Image.Resampling.BILINEAR)
        img = np.array(pil_img, dtype=np.float32) / 255.0
        img = (img - self._mean) / self._std
        return np.transpose(img, (2, 0, 1))

    def _classify_batch(self, crops: List[np.ndarray]) -> List[Prediction]:
        if not crops:
            return []

        batch = np.stack([self._preprocess(c) for c in crops], axis=0)
        outputs = self._session.run(None, {self._input_name: batch})
        probs = outputs[0]  # shape: [batch, num_classes]

        predictions = []
        for prob in probs:
            class_idx = int(np.argmax(prob))
            conf = float(prob[class_idx])

            if conf < self.init_parameters.conf_thresh:
                predictions.append(None)
                continue

            if class_idx not in self._class_map:
                logger.warning("Predicted class %d not in class_lookup, skipping", class_idx)
                predictions.append(None)
                continue

            attr, value = self._class_map[class_idx]
            predictions.append(
                Prediction(
                    pixel_location=None,
                    attribute=attr,
                    value=value,
                    conf=conf,
                )
            )

        return predictions

    def process_frame(
        self, stream, data_samples: List[DataSample], entities: Dict[UUID, Entity]
    ) -> Tuple[StreamEvent, Dict]:
        start = time.perf_counter()

        if isinstance(entities, dict):
            entities = Entities(entities)

        annotations = entities.all_annotations()
        crops = self._crop_processor.crop_annotations(annotations)
        predictions = self._classify_batch(crops)

        for prediction, annotation in zip(predictions, annotations):
            if prediction is not None:
                prediction.add_to_annotation(annotation)

        elapsed = time.perf_counter() - start
        self.logger.debug(f"EntityClassifier processed {len(crops)} crops in {elapsed:.3f}s")

        return StreamEvent.OKAY, {"entities": entities}
