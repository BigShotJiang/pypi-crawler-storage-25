from logging import getLogger
from typing import Dict, List, Optional, Tuple
from uuid import UUID, uuid4

from highlighter.core.exceptions import OptionalPackageMissingError

try:
    import cv2
except ModuleNotFoundError as _:
    raise OptionalPackageMissingError("cv2", "cv2")

import numpy as np
from pydantic import BaseModel

from highlighter.agent.capabilities.base_capability import Capability, StreamEvent
from highlighter.client.base_models.entity import Entity
from highlighter.client.io import read_image
from highlighter.core.const import OBJECT_CLASS_ATTRIBUTE_UUID
from highlighter.core.data_models import DataSample
from highlighter.core.labeled_uuid import LabeledUUID
from highlighter.predictors.prediction import Prediction

__all__ = ["MatchTemplate", "MatchTemplateCapability"]

logger = getLogger(__name__)


class _MatchTemplateCV2:
    def __init__(self, template: np.ndarray):
        self._t = template

        def fn(gray_frame, template):
            result = cv2.matchTemplate(gray_frame, template, cv2.TM_CCOEFF_NORMED)
            _, conf, _, max_loc = cv2.minMaxLoc(result)
            return max_loc[0], max_loc[1], conf

        self._fn = fn

    def __call__(self, gray_frame) -> Tuple[int, int, float]:
        return self._fn(gray_frame, self._t)


class MatchTemplate(BaseModel):
    """Match a template image to part of a large input image

    The template matching is done in grayscale color space, if an
    RGB or whatever image is passed in it will be converted to grayscale using
    cv2.cvtColor(..., cv2.COLOR_RGB2GRAY). The unmodified x,y coordinates
    returned by the matching functions corrispond to the top left of the template
    as it is passed over the input image. You can set .offset to augment the
    returned value. MatchTemplate.predict also return the confidence of the match
    which is the matching score for the matched patch.
    """

    template_path: str
    offset: Tuple[int, int] = (0, 0)
    conf_thresh: float = 0.0
    class_lookup: Optional[Dict[int, Tuple[UUID, str]]] = None

    def model_post_init(self, __context) -> None:
        self._template = self._load_template(self.template_path)
        self._match_template = _MatchTemplateCV2(self._template)

    def _load_template(self, template_path) -> np.ndarray:
        t = read_image(template_path)
        return self._rgb_to_gray(t)

    def _rgb_to_gray(self, image):
        if len(image.shape) == 2:
            return image
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    def _predict(self, image: np.ndarray) -> Tuple[int, int, int, int, float]:
        h, w = self._template.shape

        x, y, c = self._match_template(self._rgb_to_gray(image))
        x += self.offset[0]
        y += self.offset[1]
        return (int(x), int(y), int(x + w), int(y + h), c)

    def predict(self, data_samples: List[DataSample], **_) -> List[List[Prediction]]:
        predictions: List[List[Prediction]] = []
        for d in data_samples:
            x0, y0, x1, y1, c = self._predict(d.content)
            if c < self.conf_thresh:
                logger.debug(f"Dropped: {x0}, {y0}, {x1}, {y1}, {c} < {self.conf_thresh}")
                predictions.append([])
                continue

            obj_uuid, obj_value = (
                self.class_lookup[0] if self.class_lookup else (UUID(int=0), "Found Template")
            )
            prediction = Prediction(
                pixel_location=(x0, y0, x1, y1),
                attribute=OBJECT_CLASS_ATTRIBUTE_UUID,
                value=LabeledUUID(obj_uuid, label=obj_value),
                conf=c,
            )
            predictions.append([prediction])
        return predictions

    def draw_box(self, x, y, box_w, box_h, frame, t=2, color=[255, 0, 0]):
        # Draw red dot at match center
        processed_frame = frame.copy()
        c = np.array(color, dtype=np.uint8)
        processed_frame[y : y + t, x : x + box_w, ...] = c  # draw top of rect
        processed_frame[y + box_h : y + box_h + t, x : x + box_w, ...] = c  # draw bottom of rect
        processed_frame[y : y + box_h, x : x + t, ...] = c  # draw left of rect
        processed_frame[y : y + box_h, x + box_w : x + box_w + t, ...] = c  # draw left of rect

        return processed_frame


class MatchTemplateCapability(Capability):
    class InitParameters(Capability.InitParameters):
        template_path: str
        offset: Tuple[int, int] = (0, 0)
        conf_thresh: float = 0.0
        class_lookup: Optional[Dict[int, Tuple[UUID, str]]] = None

    def __init__(self, context):
        super().__init__(context)
        self._matcher = MatchTemplate(**self.init_parameters.dict())

    def process_frame(
        self, stream, data_samples: List[DataSample], entities: Dict[UUID, Entity] = {}
    ) -> Tuple[StreamEvent, dict]:
        predictions = self._matcher.predict(data_samples)
        annotations = []
        for preds, data_sample in zip(predictions, data_samples):
            for pred in preds:
                annotations.append(pred.to_annotation(data_sample, pipeline_element_name=self.name))
        entities = [a.get_or_create_entity() for a in annotations]
        return StreamEvent.OKAY, {"entities": {e.id: e for e in entities}}
