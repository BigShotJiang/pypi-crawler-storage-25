"""Backwards compatibility — delegates to python.pydantic_v2."""
from .python.pydantic_v2 import generate

__all__ = ["generate"]
