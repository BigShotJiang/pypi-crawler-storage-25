"""Generator registry — maps target names to generator modules."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import Callable

from ..ast import Schema


@dataclass
class GeneratorInfo:
    target: str
    module_path: str
    description: str
    version: str | None = None
    aliases: tuple[str, ...] = ()


# Registry of all available generators.
# Order matters for `generators list` output.
_GENERATORS: list[GeneratorInfo] = [
    GeneratorInfo(
        target="env-example",
        module_path="envschema.generators.env_example",
        description=".env.example with type hints and markers",
    ),
    GeneratorInfo(
        target="ts",
        module_path="envschema.generators.ts.interface",
        description="TypeScript interface (pure types, no runtime)",
        aliases=("typescript",),
    ),
    GeneratorInfo(
        target="zod",
        module_path="envschema.generators.ts.zod_v4",
        description="Zod v4 schema with inferred types",
        version="4",
        aliases=("zod@4",),
    ),
    GeneratorInfo(
        target="pydantic",
        module_path="envschema.generators.python.pydantic_v2",
        description="Pydantic v2 BaseSettings class",
        version="2",
        aliases=("pydantic@2", "python"),
    ),
    GeneratorInfo(
        target="dataclasses",
        module_path="envschema.generators.python.dataclasses_gen",
        description="Python dataclass with os.environ loader (stdlib, no deps)",
    ),
]


def _build_lookup() -> dict[str, GeneratorInfo]:
    lookup = {}
    for info in _GENERATORS:
        lookup[info.target] = info
        for alias in info.aliases:
            lookup[alias] = info
    return lookup


_LOOKUP = _build_lookup()


def get_targets() -> list[str]:
    """Return list of primary target names."""
    return [g.target for g in _GENERATORS]


def list_generators() -> list[GeneratorInfo]:
    """Return all registered generators."""
    return list(_GENERATORS)


def resolve(target: str) -> GeneratorInfo:
    """Resolve a target name (including aliases) to a GeneratorInfo."""
    info = _LOOKUP.get(target)
    if info is None:
        available = ", ".join(get_targets())
        raise ValueError(f"Unknown target: {target!r}. Available: {available}")
    return info


def load_generator(target: str) -> Callable[[Schema], str]:
    """Load and return the generate() function for a target."""
    info = resolve(target)
    mod = import_module(info.module_path)
    return mod.generate
