"""Backwards compatibility — delegates to ts.interface."""
from .ts.interface import generate

__all__ = ["generate"]
