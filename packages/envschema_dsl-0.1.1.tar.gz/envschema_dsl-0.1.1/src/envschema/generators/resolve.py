"""Shared utilities for resolving TypeRef in generators."""

from __future__ import annotations

from ..ast import EnumType, Schema, SimpleType, TypeRef, UnionType, Variable


def resolve_var_type(var: Variable, schema: Schema):
    """Resolve variable type, expanding TypeRef via schema type aliases."""
    t = var.type
    if isinstance(t, TypeRef):
        return resolve_type_ref(t, schema)
    return t


def resolve_type_ref(ref: TypeRef, schema: Schema):
    """Resolve a TypeRef to its underlying type."""
    resolved = schema.resolve_type(ref.name)
    if resolved is None:
        return ref  # Unresolved — leave as-is
    if isinstance(resolved, UnionType):
        return merge_union(resolved, schema)
    return resolved


def merge_union(union: UnionType, schema: Schema) -> EnumType:
    """Merge a UnionType into a single EnumType by combining all enum values."""
    all_values = []
    for t in union.types:
        if isinstance(t, EnumType):
            all_values.extend(t.values)
        elif isinstance(t, TypeRef):
            inner = resolve_type_ref(t, schema)
            if isinstance(inner, EnumType):
                all_values.extend(inner.values)
    if all_values:
        return EnumType(values=all_values)
    return union  # Can't merge — return as-is
