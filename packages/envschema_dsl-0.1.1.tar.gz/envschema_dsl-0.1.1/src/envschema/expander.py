"""Expand wildcard variables based on array source values."""

from __future__ import annotations

import re

from .ast import Expansion, Schema, Variable
from .env_file import EnvFile

# Built-in filters for expansion
_FILTERS = {
    "upper": str.upper,
    "lower": str.lower,
    "capitalize": str.capitalize,
    "strip": str.strip,
}


def expand_wildcards(schema: Schema, env: EnvFile | None = None) -> list[Variable]:
    """Expand wildcard variables into concrete variables.

    If env is provided, uses actual array values from .env.
    Otherwise, uses default values from the schema.
    """
    env_dict = env.as_dict() if env else {}
    result = []

    for var in schema.variables:
        if var.expansion is None:
            result.append(var)
            continue

        # Find source array variable
        source_values = _get_source_values(var.expansion, schema, env_dict)
        if not source_values:
            result.append(var)  # Keep unexpanded if source not found
            continue

        # Apply filter (default: upper, since env var names are UPPER_CASE)
        filter_name = var.expansion.filter or "upper"
        fn = _FILTERS.get(filter_name)
        if fn:
            source_values = [fn(v) for v in source_values]

        # Generate concrete variables
        for value in source_values:
            concrete_name = _apply_expansion(var.name, var.expansion, value)
            result.append(Variable(
                name=concrete_name,
                type=var.type,
                default=var.default,
                decorators=var.decorators,
                validation=var.validation,
                expansion=None,  # Expanded — no longer a wildcard
                line=var.line,
            ))

    return result


def _get_source_values(exp: Expansion, schema: Schema, env_dict: dict) -> list[str]:
    """Get the array values for expansion source."""
    # Try .env first
    raw = env_dict.get(exp.source)
    if raw:
        return [v.strip() for v in raw.split(",") if v.strip()]

    # Fall back to schema default
    for var in schema.variables:
        if var.name == exp.source and var.default:
            return [v.strip() for v in str(var.default).split(",") if v.strip()]

    return []


def _apply_expansion(pattern: str, exp: Expansion, value: str) -> str:
    """Replace {SOURCE} or {SOURCE|filter} in the pattern with the value."""
    if exp.filter:
        return pattern.replace(f"{{{exp.source}|{exp.filter}}}", value)
    return pattern.replace(f"{{{exp.source}}}", value)
