"""CLI for EnvSchema."""

import sys
from pathlib import Path

import click

from .parser import parse_file
from .ast import ArrayType, EnumType, SimpleType, TypeRef
from .env_file import parse_env_file
from .expander import expand_wildcards
from .validator import validate as run_validate, Level


@click.group()
@click.version_option()
def cli():
    """EnvSchema — DSL for typed .env files."""


@cli.command()
def lsp():
    """Start the Language Server Protocol server (stdio)."""
    from .lsp import start_lsp
    start_lsp()


@cli.command()
@click.argument("schema_file", type=click.Path(exists=True, path_type=Path))
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def parse(schema_file: Path, as_json: bool):
    """Parse a .env.schema file and display the AST."""
    schema = parse_file(schema_file)

    if as_json:
        import json
        click.echo(json.dumps(_schema_to_dict(schema), indent=2))
    else:
        _print_schema(schema)


def _type_str(t) -> str:
    if t is None:
        return "(inferred)"
    if isinstance(t, SimpleType):
        return t.value
    if isinstance(t, EnumType):
        return f"enum({', '.join(repr(v) for v in t.values)})"
    if isinstance(t, ArrayType):
        return f"{_type_str(t.element_type)}[]"
    if isinstance(t, TypeRef):
        return t.name
    return str(t)


def _print_schema(schema):
    click.echo(f"Variables: {len(schema.variables)}\n")
    for v in schema.variables:
        parts = [click.style(v.name, bold=True)]
        parts.append(click.style(_type_str(v.type), fg="cyan"))
        if v.default is not None:
            parts.append(f"= {v.default!r}")
        for d in v.decorators:
            deco = f"@{d.name}"
            if d.arg is not None:
                deco += f"({d.arg!r})"
            parts.append(click.style(deco, fg="yellow"))
        if v.validation:
            parts.append(click.style(f": {v.validation}", fg="green"))
        click.echo("  " + " ".join(parts))


@cli.command()
@click.argument("schema_file", type=click.Path(exists=True, path_type=Path))
@click.option("--env", "env_file", type=click.Path(exists=True, path_type=Path),
              default=".env", help="Path to .env file (default: .env)")
def validate(schema_file: Path, env_file: Path):
    """Validate a .env file against a .env.schema."""
    schema = parse_file(schema_file)
    env = parse_env_file(env_file)
    result = run_validate(schema, env)

    # Use expanded variables for display
    expanded_vars = expand_wildcards(schema, env)
    env_keys = set(env.keys())
    schema_keys = {v.name for v in expanded_vars}
    checked = env_keys & schema_keys
    issue_keys = {i.key for i in result.errors}
    ok_count = len(checked - issue_keys)

    click.echo(f"\nValidating {click.style(str(env_file), bold=True)} against {click.style(str(schema_file), bold=True)}\n")

    # Print OK variables
    for var in expanded_vars:
        if var.name in checked and var.name not in issue_keys:
            val = env.as_dict().get(var.name, "")
            display_val = "***" if var.is_secret else val
            click.echo(f"  {click.style('✓', fg='green')} {var.name} = {display_val}")

    # Print issues
    for issue in result.issues:
        if issue.level == Level.ERROR:
            symbol = click.style("✗", fg="red")
            msg = click.style(issue.message, fg="red")
        elif issue.level == Level.WARNING:
            symbol = click.style("⚠", fg="yellow")
            msg = click.style(issue.message, fg="yellow")
        else:
            symbol = click.style("ℹ", fg="blue")
            msg = click.style(issue.message, fg="blue")

        line_info = f" (line {issue.line})" if issue.line else ""
        click.echo(f"  {symbol} {issue.key}{line_info} — {msg}")

    # Summary
    click.echo()
    parts = []
    if ok_count:
        parts.append(click.style(f"{ok_count} OK", fg="green"))
    if result.errors:
        parts.append(click.style(f"{len(result.errors)} errors", fg="red"))
    if result.warnings:
        parts.append(click.style(f"{len(result.warnings)} warnings", fg="yellow"))
    if result.infos:
        parts.append(click.style(f"{len(result.infos)} info", fg="blue"))
    click.echo("Result: " + ", ".join(parts))

    if not result.ok:
        sys.exit(1)


@cli.command()
@click.argument("schema_file", type=click.Path(exists=True, path_type=Path))
@click.option("--target", "-t", required=True, help="Output target (use 'generators list' to see available)")
@click.option("--output", "-o", type=click.Path(path_type=Path),
              help="Output file (default: stdout)")
def generate(schema_file: Path, target: str, output: Path | None):
    """Generate code from a .env.schema file."""
    from .generators.registry import load_generator, resolve

    try:
        info = resolve(target)
    except ValueError as e:
        raise click.ClickException(str(e))

    schema = parse_file(schema_file)
    gen_fn = load_generator(target)
    content = gen_fn(schema)

    if output:
        output.write_text(content)
        ver = f" v{info.version}" if info.version else ""
        click.echo(f"Generated {click.style(str(output), bold=True)} ({info.target}{ver})")
    else:
        click.echo(content)


@cli.group()
def generators():
    """Manage code generators."""


@generators.command("list")
def generators_list():
    """List available code generation targets."""
    from .generators.registry import list_generators

    for info in list_generators():
        name = click.style(info.target, bold=True)
        ver = f" v{info.version}" if info.version else ""
        aliases = f"  (aliases: {', '.join(info.aliases)})" if info.aliases else ""
        click.echo(f"  {name}{ver} — {info.description}{aliases}")


@cli.group()
def presets():
    """Manage presets."""


@presets.command("list")
@click.option("--remote", is_flag=True, help="List remote presets from registry")
def presets_list(remote: bool):
    """List available presets."""
    from .presets_manager import list_builtin, list_local, list_remote

    builtin = list_builtin()
    local = list_local()

    if builtin:
        click.echo(click.style("Built-in:", bold=True))
        for name in builtin:
            click.echo(f"  {name}")

    if local:
        click.echo(click.style("\nProject-local (.envschema/presets/):", bold=True))
        for name in local:
            click.echo(f"  {name}")

    if not builtin and not local:
        click.echo("No presets found.")

    if remote:
        click.echo(click.style("\nRemote registry:", bold=True))
        items = list_remote()
        if items:
            for item in items:
                click.echo(f"  {item.get('name', '?')} — {item.get('description', '')}")
        else:
            click.echo("  (unavailable or empty)")


@presets.command("load")
@click.argument("name")
@click.option("--dir", "base_dir", type=click.Path(path_type=Path), default=None,
              help="Project directory (default: cwd)")
def presets_load(name: str, base_dir: Path | None):
    """Download a preset from the registry."""
    from .presets_manager import load_preset, PresetNotFoundError, PresetLoadError

    try:
        dest = load_preset(name, base_dir=base_dir)
        click.echo(f"Loaded {click.style(name, bold=True)} → {dest}")
    except PresetNotFoundError as e:
        raise click.ClickException(str(e))
    except PresetLoadError as e:
        raise click.ClickException(str(e))


def _schema_to_dict(schema) -> dict:
    return {
        "variables": [
            {
                "name": v.name,
                "type": _type_str(v.type),
                "default": v.default,
                "decorators": [
                    {"name": d.name, "arg": d.arg} for d in v.decorators
                ],
                "validation": v.validation,
                "line": v.line,
            }
            for v in schema.variables
        ],
    }
