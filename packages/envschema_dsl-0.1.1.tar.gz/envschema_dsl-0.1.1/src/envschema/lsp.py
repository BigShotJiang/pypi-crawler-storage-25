"""LSP server for EnvSchema — diagnostics, hover, completions."""

from __future__ import annotations

import logging
import re

from lsprotocol import types as lsp
from pygls.lsp.server import LanguageServer

from .ast import (
    ArrayType, Decorator, EnumType, Schema, SimpleType, TypeRef, Variable,
)
from .parser import parse

logger = logging.getLogger(__name__)

server = LanguageServer("envschema", "v0.1.0")

# Cache: uri → schema
_cache: dict[str, Schema | None] = {}


def _parse_document(uri: str, source: str) -> Schema | None:
    """Parse document and cache result."""
    try:
        schema = parse(source)
        _cache[uri] = schema
        return schema
    except Exception as e:
        logger.debug(f"Parse error for {uri}: {e}")
        _cache[uri] = None
        return None


# --- Diagnostics ---

@server.feature(lsp.TEXT_DOCUMENT_DID_OPEN)
def did_open(params: lsp.DidOpenTextDocumentParams):
    _validate_and_publish(params.text_document.uri, params.text_document.text)


@server.feature(lsp.TEXT_DOCUMENT_DID_CHANGE)
def did_change(params: lsp.DidChangeTextDocumentParams):
    doc = server.workspace.get_text_document(params.text_document.uri)
    _validate_and_publish(params.text_document.uri, doc.source)


@server.feature(lsp.TEXT_DOCUMENT_DID_SAVE)
def did_save(params: lsp.DidSaveTextDocumentParams):
    doc = server.workspace.get_text_document(params.text_document.uri)
    _validate_and_publish(params.text_document.uri, doc.source)


def _validate_and_publish(uri: str, source: str):
    """Parse the document, collect diagnostics, publish them."""
    diagnostics = []

    try:
        schema = parse(source)
        _cache[uri] = schema

        # Check for duplicate variable names
        seen: dict[str, int] = {}
        for var in schema.variables:
            if var.name in seen:
                diagnostics.append(lsp.Diagnostic(
                    range=_line_range(var.line or 1),
                    message=f"Duplicate variable: {var.name} (first defined on line {seen[var.name]})",
                    severity=lsp.DiagnosticSeverity.Warning,
                    source="envschema",
                ))
            else:
                seen[var.name] = var.line or 0

        # Check for unresolved TypeRefs
        known_types = {a.name for a in schema.type_aliases}
        known_types.update(t.value for t in SimpleType)
        for var in schema.variables:
            if isinstance(var.type, TypeRef) and var.type.name not in known_types:
                diagnostics.append(lsp.Diagnostic(
                    range=_line_range(var.line or 1),
                    message=f"Unknown type: {var.type.name}",
                    severity=lsp.DiagnosticSeverity.Error,
                    source="envschema",
                ))

    except Exception as e:
        # Parse error — extract line info if possible
        error_msg = str(e)
        line = _extract_error_line(error_msg)
        diagnostics.append(lsp.Diagnostic(
            range=_line_range(line),
            message=f"Parse error: {error_msg}",
            severity=lsp.DiagnosticSeverity.Error,
            source="envschema",
        ))
        _cache[uri] = None

    server.text_document_publish_diagnostics(
        lsp.PublishDiagnosticsParams(uri=uri, diagnostics=diagnostics)
    )


# --- Hover ---

@server.feature(lsp.TEXT_DOCUMENT_HOVER)
def hover(params: lsp.HoverParams) -> lsp.Hover | None:
    uri = params.text_document.uri
    schema = _cache.get(uri)
    if schema is None:
        return None

    line = params.position.line + 1  # LSP is 0-based
    doc = server.workspace.get_text_document(uri)
    source_line = doc.source.splitlines()[params.position.line] if params.position.line < len(doc.source.splitlines()) else ""

    # Find variable on this line
    var = next((v for v in schema.variables if v.line == line), None)
    if var:
        return lsp.Hover(contents=_var_hover(var, schema))

    # Find type alias on this line
    alias = next((a for a in schema.type_aliases if a.line == line), None)
    if alias:
        return lsp.Hover(contents=_type_hover(alias))

    return None


def _var_hover(var: Variable, schema: Schema) -> lsp.MarkupContent:
    parts = [f"**{var.name}**"]

    # Type
    t = var.type
    if isinstance(t, TypeRef):
        resolved = schema.resolve_type(t.name)
        if resolved:
            parts.append(f"Type: `{t.name}` → `{_type_display(resolved)}`")
        else:
            parts.append(f"Type: `{t.name}` (unresolved)")
    elif t:
        parts.append(f"Type: `{_type_display(t)}`")

    if var.default is not None:
        parts.append(f"Default: `{var.default!r}`")

    if var.is_required:
        parts.append("**Required**")
    if var.is_secret:
        parts.append("**Secret**")

    for d in var.decorators:
        if d.name == "description" and d.arg:
            parts.insert(1, str(d.arg))

    if var.validation:
        parts.append(f"Validation: `{var.validation}`")

    return lsp.MarkupContent(
        kind=lsp.MarkupKind.Markdown,
        value="\n\n".join(parts),
    )


def _type_hover(alias) -> lsp.MarkupContent:
    return lsp.MarkupContent(
        kind=lsp.MarkupKind.Markdown,
        value=f"**type {alias.name}**\n\n`{_type_display(alias.value)}`",
    )


# --- Completion ---

_TYPE_COMPLETIONS = [
    lsp.CompletionItem(label=t.value, kind=lsp.CompletionItemKind.TypeParameter, detail="built-in type")
    for t in SimpleType
]

_DECORATOR_COMPLETIONS = [
    lsp.CompletionItem(label=f"@{name}", kind=lsp.CompletionItemKind.Keyword, detail=desc)
    for name, desc in [
        ("required", "Variable must be set"),
        ("secret", "Hide value in output"),
        ("deprecated", "Mark as deprecated"),
        ("description", "Add description"),
        ("alias", "Create alias for wildcard"),
    ]
]


@server.feature(lsp.TEXT_DOCUMENT_COMPLETION, lsp.CompletionOptions(trigger_characters=["@"]))
def completions(params: lsp.CompletionParams) -> lsp.CompletionList:
    uri = params.text_document.uri
    doc = server.workspace.get_text_document(uri)
    lines = doc.source.splitlines()
    line_text = lines[params.position.line] if params.position.line < len(lines) else ""
    col = params.position.character

    items = []

    # After @ → decorator completions
    if col > 0 and line_text[col - 1:col] == "@":
        items.extend(_DECORATOR_COMPLETIONS)

    # After type keyword or at start of type position → type completions
    elif re.match(r"^[A-Z][A-Z0-9_]*\s+$", line_text[:col]):
        items.extend(_TYPE_COMPLETIONS)
        # Add type aliases from schema
        schema = _cache.get(uri)
        if schema:
            for alias in schema.type_aliases:
                items.append(lsp.CompletionItem(
                    label=alias.name,
                    kind=lsp.CompletionItemKind.TypeParameter,
                    detail=f"type alias → {_type_display(alias.value)}",
                ))

    return lsp.CompletionList(is_incomplete=False, items=items)


# --- Helpers ---

def _type_display(t) -> str:
    if isinstance(t, SimpleType):
        return t.value
    if isinstance(t, EnumType):
        return f"enum({', '.join(repr(v) for v in t.values)})"
    if isinstance(t, ArrayType):
        return f"{_type_display(t.element_type)}[]"
    if isinstance(t, TypeRef):
        return t.name
    return str(t)


def _line_range(line: int) -> lsp.Range:
    """Create a range covering an entire line (1-based line → 0-based LSP)."""
    ln = max(0, line - 1)
    return lsp.Range(
        start=lsp.Position(line=ln, character=0),
        end=lsp.Position(line=ln, character=1000),
    )


def _extract_error_line(error_msg: str) -> int:
    """Try to extract line number from Lark error message."""
    match = re.search(r"line (\d+)", error_msg)
    return int(match.group(1)) if match else 1


def start_lsp():
    """Start the LSP server on stdio."""
    server.start_io()
