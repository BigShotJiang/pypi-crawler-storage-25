"""Parser for EnvSchema DSL — Lark grammar → AST."""

from __future__ import annotations

import re
from pathlib import Path

from lark import Lark, Transformer, Token

from .ast import (
    ArrayType,
    Comment,
    Decorator,
    EnumType,
    Expansion,
    Include,
    Schema,
    SimpleType,
    TypeAlias,
    TypeRef,
    UnionType,
    Variable,
)

_GRAMMAR_PATH = Path(__file__).parent / "grammar.lark"
_PRESETS_PATH = Path(__file__).parent / "presets"

_parser = Lark(
    _GRAMMAR_PATH.read_text(),
    parser="lalr",
    propagate_positions=True,
)


class SchemaTransformer(Transformer):
    """Transforms Lark parse tree into EnvSchema AST nodes."""

    def start(self, items: list) -> Schema:
        variables = []
        comments = []
        includes = []
        type_aliases = []
        for item in items:
            if isinstance(item, Variable):
                variables.append(item)
            elif isinstance(item, Comment):
                comments.append(item)
            elif isinstance(item, Include):
                includes.append(item)
            elif isinstance(item, TypeAlias):
                type_aliases.append(item)
        return Schema(
            variables=variables,
            comments=comments,
            includes=includes,
            type_aliases=type_aliases,
        )

    def comment_line(self, items: list) -> Comment:
        token = items[0]
        return Comment(text=str(token).lstrip("# "), line=token.line)

    # --- Includes ---

    def include_stmt(self, items: list) -> Include:
        token = items[0]
        raw = str(token)
        if token.type == "INCLUDE_PRESET":
            # #include <name>
            match = re.search(r"<([^>]+)>", raw)
            return Include(target=match.group(1), is_local=False, line=token.line)
        else:
            # #include "path"
            match = re.search(r'"([^"]+)"', raw)
            return Include(target=match.group(1), is_local=True, line=token.line)

    # --- Type definitions ---

    def type_def(self, items: list) -> TypeAlias:
        name_token = items[0]
        value = items[1]
        return TypeAlias(name=str(name_token), value=value, line=name_token.line)

    def type_expr(self, items: list):
        return items[0]

    def type_union(self, items: list):
        if len(items) == 1:
            return items[0]
        return UnionType(types=items)

    def type_atom(self, items: list):
        return items[0]

    def type_ref(self, items: list) -> TypeRef:
        return TypeRef(name=str(items[0]))

    # --- Block variables ---

    def block_variable(self, items: list) -> Variable:
        name_token = items[0]
        name = str(name_token)

        var_type = None
        default = None
        decorators = []
        validation = None
        description = None

        for item in items[1:]:
            if isinstance(item, _Default):
                default = item.value
            elif isinstance(item, _BlockField):
                if item.key == "type":
                    var_type = _resolve_block_type(item.value)
                elif item.key == "default":
                    default = item.value.value if isinstance(item.value, _Default) else item.value
                elif item.key == "description":
                    description = item.value.value if isinstance(item.value, _Default) else str(item.value)
                elif item.key == "validate":
                    validation = item.value.value if isinstance(item.value, _Default) else str(item.value)
            elif isinstance(item, Decorator):
                decorators.append(item)

        if description:
            decorators.append(Decorator(name="description", arg=description))

        return Variable(
            name=name,
            type=var_type,
            default=default,
            decorators=decorators,
            validation=validation,
            line=name_token.line,
        )

    def block_field(self, items: list):
        if len(items) == 1 and isinstance(items[0], Decorator):
            return items[0]  # Pass through decorator
        key = str(items[0])
        value = items[1]
        return _BlockField(key, value)

    # --- Wildcard variables ---

    def wildcard_variable(self, items: list) -> Variable:
        name_token = items[0]
        raw_name = str(name_token)

        # Parse expansion: AUTH_{PROVIDERS|upper}_DRIVER
        expansion = _parse_expansion(raw_name)

        var_type = None
        default = None
        decorators = []
        validation = None

        for item in items[1:]:
            if isinstance(item, (SimpleType, EnumType, ArrayType, TypeRef)):
                var_type = item
            elif isinstance(item, Decorator):
                decorators.append(item)
            elif isinstance(item, _Default):
                default = item.value
            elif isinstance(item, _Validation):
                validation = item.expr

        return Variable(
            name=raw_name,
            type=var_type,
            default=default,
            decorators=decorators,
            validation=validation,
            expansion=expansion,
            line=name_token.line,
        )

    # --- Variables ---

    def variable(self, items: list) -> Variable:
        name_token = items[0]
        name = str(name_token)

        var_type = None
        default = None
        decorators = []
        validation = None

        for item in items[1:]:
            if isinstance(item, (SimpleType, EnumType, ArrayType, TypeRef)):
                var_type = item
            elif isinstance(item, Decorator):
                decorators.append(item)
            elif isinstance(item, _Default):
                default = item.value
            elif isinstance(item, _Validation):
                validation = item.expr

        return Variable(
            name=name,
            type=var_type,
            default=default,
            decorators=decorators,
            validation=validation,
            line=name_token.line,
        )

    # --- Types ---

    def simple_type(self, items: list) -> SimpleType:
        return SimpleType(str(items[0]))

    def enum_type(self, items: list) -> EnumType:
        raw = str(items[0])  # enum("a", "b", "c")
        inner = raw[len("enum("):-1]
        values = [v.strip().strip("\"'") for v in inner.split(",") if v.strip()]
        return EnumType(values=values)

    def array_type(self, items: list):
        base = items[0]
        return ArrayType(element_type=base)

    def type_spec(self, items: list):
        return items[0]

    # --- Default value ---

    def default_value(self, items: list) -> _Default:
        return items[0]

    def string_value(self, items: list) -> _Default:
        raw = str(items[0])
        return _Default(raw[1:-1])

    def number_value(self, items: list) -> _Default:
        raw = str(items[0])
        return _Default(float(raw) if "." in raw else int(raw))

    def bool_value(self, items: list) -> _Default:
        return _Default(str(items[0]) == "true")

    def bare_value(self, items: list) -> _Default:
        return _Default(str(items[0]))

    # --- Decorators ---

    def decorator(self, items: list) -> Decorator:
        name = str(items[0])
        arg = None
        if len(items) > 1:
            token = items[1]
            raw = str(token)
            if token.type == "DQ_STRING":
                arg = raw[1:-1]
            elif token.type == "NUMBER":
                arg = float(raw) if "." in raw else int(raw)
            else:
                arg = raw
        return Decorator(name=name, arg=arg)

    # --- Validation ---

    def validation(self, items: list) -> _Validation:
        return _Validation(str(items[0]).strip())


class _Default:
    """Wrapper to distinguish default values during tree transformation."""
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value


class _Validation:
    """Wrapper for validation expressions during tree transformation."""
    __slots__ = ("expr",)

    def __init__(self, expr: str):
        self.expr = expr


def _parse_expansion(name: str) -> Expansion:
    """Parse expansion from wildcard name like AUTH_{PROVIDERS|upper}_DRIVER."""
    match = re.search(r"\{([A-Z][A-Z0-9_]*)(?:\|([a-z_]+))?\}", name)
    if match:
        return Expansion(source=match.group(1), filter=match.group(2))
    raise ValueError(f"Invalid wildcard name: {name}")


class _BlockField:
    """Wrapper for block field key-value pairs."""
    __slots__ = ("key", "value")

    def __init__(self, key: str, value):
        self.key = key
        self.value = value


_SIMPLE_TYPE_NAMES = {t.value for t in SimpleType}


def _resolve_block_type(value):
    """Resolve a block 'type = ...' value to an AST type node."""
    if isinstance(value, (SimpleType, EnumType, TypeRef)):
        return value
    # Handle case where type name was parsed as _Default (bare word)
    if isinstance(value, _Default) and isinstance(value.value, str):
        s = value.value
        if s in _SIMPLE_TYPE_NAMES:
            return SimpleType(s)
        if s[0].isupper():
            return TypeRef(name=s)
    return value


def parse(source: str) -> Schema:
    """Parse an EnvSchema DSL string into a Schema AST."""
    tree = _parser.parse(source)
    return SchemaTransformer().transform(tree)


def parse_file(path: str | Path, resolve_includes: bool = True) -> Schema:
    """Parse an EnvSchema DSL file into a Schema AST.

    If resolve_includes is True, recursively parses #include directives
    and merges types/variables from included schemas.
    """
    path = Path(path)
    schema = parse(path.read_text())

    if resolve_includes and schema.includes:
        _resolve_includes(schema, base_dir=path.parent, seen=set())

    return schema


def _resolve_includes(schema: Schema, base_dir: Path, seen: set[str]):
    """Recursively resolve #include directives."""
    for inc in schema.includes:
        resolved_path = _resolve_include_path(inc, base_dir)
        if resolved_path is None:
            continue

        key = str(resolved_path.resolve())
        if key in seen:
            continue  # Avoid circular includes
        seen.add(key)

        if not resolved_path.exists():
            continue

        included = parse(resolved_path.read_text())

        # Recursively resolve nested includes
        if included.includes:
            _resolve_includes(included, base_dir=resolved_path.parent, seen=seen)

        # Merge type aliases (included first, so they're available)
        schema.type_aliases = included.type_aliases + schema.type_aliases

        # Merge variables (included variables come first, local override)
        local_names = {v.name for v in schema.variables}
        for var in included.variables:
            if var.name not in local_names:
                schema.variables.insert(0, var)


def _resolve_include_path(inc: Include, base_dir: Path) -> Path | None:
    """Resolve an include to a filesystem path."""
    if inc.is_local:
        # #include "relative/path.schema"
        return base_dir / inc.target

    # #include <preset_name>
    # 1. Check project-local .envschema/presets/
    local_presets = base_dir / ".envschema" / "presets"
    local_path = local_presets / f"{inc.target}.schema"
    if local_path.exists():
        return local_path

    # 2. Check built-in presets
    builtin_path = _PRESETS_PATH / f"{inc.target}.schema"
    if builtin_path.exists():
        return builtin_path

    return None
