"""Preset manager — load, list, and resolve presets."""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from pathlib import Path

# Default registry URL (GitHub raw content)
DEFAULT_REGISTRY = "https://raw.githubusercontent.com/envschema/presets/main"
BUILTIN_PRESETS_DIR = Path(__file__).parent / "presets"


def get_project_presets_dir(base_dir: Path | None = None) -> Path:
    """Get or create project-local presets directory."""
    base = base_dir or Path.cwd()
    presets_dir = base / ".envschema" / "presets"
    return presets_dir


def list_builtin() -> list[str]:
    """List built-in preset names."""
    if not BUILTIN_PRESETS_DIR.exists():
        return []
    return sorted(
        p.stem.removesuffix(".schema") if p.stem.endswith(".schema") else p.stem
        for p in BUILTIN_PRESETS_DIR.glob("*.schema")
    )


def list_local(base_dir: Path | None = None) -> list[str]:
    """List project-local preset names."""
    presets_dir = get_project_presets_dir(base_dir)
    if not presets_dir.exists():
        return []
    return sorted(
        p.stem.removesuffix(".schema") if p.stem.endswith(".schema") else p.stem
        for p in presets_dir.glob("*.schema")
    )


def load_preset(
    name: str,
    base_dir: Path | None = None,
    registry_url: str = DEFAULT_REGISTRY,
) -> Path:
    """Download a preset from the registry and save locally.

    Returns the path to the saved preset file.
    """
    presets_dir = get_project_presets_dir(base_dir)
    presets_dir.mkdir(parents=True, exist_ok=True)

    # Parse name and optional version: "node.js@22" → name="node.js", version="22"
    version = None
    if "@" in name:
        name, version = name.rsplit("@", 1)

    # Build URL
    if version:
        url = f"{registry_url}/{name}/{version}.schema"
    else:
        url = f"{registry_url}/{name}/latest.schema"

    # Download
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise PresetNotFoundError(f"Preset '{name}' not found in registry") from e
        raise PresetLoadError(f"HTTP error {e.code}: {e.reason}") from e
    except urllib.error.URLError as e:
        raise PresetLoadError(f"Network error: {e.reason}") from e

    # Save
    dest = presets_dir / f"{name}.schema"
    dest.write_text(content)
    return dest


def list_remote(registry_url: str = DEFAULT_REGISTRY) -> list[dict]:
    """List available presets from registry index.json."""
    url = f"{registry_url}/index.json"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return []


class PresetNotFoundError(Exception):
    pass


class PresetLoadError(Exception):
    pass
