"""Validator — checks .env files against an EnvSchema."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from .ast import ArrayType, EnumType, Schema, SimpleType, TypeRef, Variable
from .env_file import EnvFile
from .expander import expand_wildcards
from .generators.resolve import resolve_var_type


class Level(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Issue:
    level: Level
    key: str
    message: str
    line: int | None = None


@dataclass
class ValidationResult:
    issues: list[Issue] = field(default_factory=list)

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.level == Level.ERROR]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.level == Level.WARNING]

    @property
    def infos(self) -> list[Issue]:
        return [i for i in self.issues if i.level == Level.INFO]

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    @property
    def ok_count(self) -> int:
        schema_keys = {i.key for i in self.issues}
        # Count is tracked externally; this is just for issues
        return 0


def validate(schema: Schema, env: EnvFile) -> ValidationResult:
    """Validate an EnvFile against a Schema. Returns all issues found."""
    result = ValidationResult()
    # Expand wildcards before validation
    expanded_vars = expand_wildcards(schema, env)
    expanded_schema = Schema(
        variables=expanded_vars,
        comments=schema.comments,
        includes=schema.includes,
        type_aliases=schema.type_aliases,
    )

    env_dict = env.as_dict()
    schema_keys = {v.name for v in expanded_schema.variables}
    env_keys = set(env.keys())

    # Check duplicates in .env
    for key, lines in env.duplicates():
        result.issues.append(Issue(
            level=Level.WARNING,
            key=key,
            message=f"duplicate on lines {', '.join(str(l) for l in lines)}",
            line=lines[0],
        ))

    # Check unknown variables (in .env but not in schema)
    for key in sorted(env_keys - schema_keys):
        entry = next(e for e in env.entries if e.key == key)
        result.issues.append(Issue(
            level=Level.WARNING,
            key=key,
            message="not defined in schema",
            line=entry.line,
        ))

    # Check each schema variable
    for var in expanded_schema.variables:
        # Resolve TypeRef to actual type for validation
        resolved_type = resolve_var_type(var, expanded_schema)
        resolved_var = Variable(
            name=var.name, type=resolved_type, default=var.default,
            decorators=var.decorators, validation=var.validation, line=var.line,
        ) if resolved_type != var.type else var

        value = env_dict.get(var.name)

        if value is None or value == "":
            if var.is_required:
                result.issues.append(Issue(
                    level=Level.ERROR,
                    key=var.name,
                    message="missing required variable",
                    line=var.line,
                ))
            elif var.is_secret and var.name in env_keys:
                result.issues.append(Issue(
                    level=Level.INFO,
                    key=var.name,
                    message="secret variable is empty",
                ))
            continue

        # Type checking
        type_error = _check_type(resolved_var, value)
        if type_error:
            result.issues.append(Issue(
                level=Level.ERROR,
                key=var.name,
                message=type_error,
                line=next((e.line for e in env.entries if e.key == var.name), None),
            ))
            continue  # Skip validation if type is wrong

        # Inline validation
        if resolved_var.validation:
            val_error = _check_validation(resolved_var, value)
            if val_error:
                result.issues.append(Issue(
                    level=Level.ERROR,
                    key=var.name,
                    message=val_error,
                    line=next((e.line for e in env.entries if e.key == var.name), None),
                ))

    return result


def _coerce_value(var: Variable, raw: str):
    """Coerce a string value to the expected Python type for validation."""
    t = var.type
    if t is None:
        # Infer from default
        if isinstance(var.default, bool):
            return _parse_bool(raw)
        if isinstance(var.default, int):
            return int(raw)
        if isinstance(var.default, float):
            return float(raw)
        return raw

    if isinstance(t, SimpleType):
        return _COERCERS.get(t, lambda x: x)(raw)
    if isinstance(t, EnumType):
        return raw
    if isinstance(t, ArrayType):
        return raw  # Validated as string, split checked separately
    return raw


def _parse_bool(raw: str) -> bool:
    if raw.lower() in ("true", "1", "yes"):
        return True
    if raw.lower() in ("false", "0", "no"):
        return False
    raise ValueError(f"not a boolean: {raw!r}")


def _parse_int(raw: str) -> int:
    return int(raw)


def _parse_float(raw: str) -> float:
    return float(raw)


_COERCERS = {
    SimpleType.STR: lambda x: x,
    SimpleType.INT: _parse_int,
    SimpleType.FLOAT: _parse_float,
    SimpleType.BOOL: _parse_bool,
    SimpleType.PORT: _parse_int,
    SimpleType.URL: lambda x: x,
    SimpleType.EMAIL: lambda x: x,
    SimpleType.PATH: lambda x: x,
}


def _check_type(var: Variable, value: str) -> str | None:
    """Check if value matches the expected type. Returns error message or None."""
    t = var.type
    if t is None:
        # Infer from default
        if isinstance(var.default, bool):
            if value.lower() not in ("true", "false", "1", "0", "yes", "no"):
                return f"expected bool, got {value!r}"
        elif isinstance(var.default, int):
            try:
                int(value)
            except ValueError:
                return f"expected int, got {value!r}"
        elif isinstance(var.default, float):
            try:
                float(value)
            except ValueError:
                return f"expected float, got {value!r}"
        return None

    if isinstance(t, SimpleType):
        return _TYPE_CHECKERS.get(t, lambda v: None)(value)

    if isinstance(t, EnumType):
        if value not in t.values:
            return f"expected one of {t.values}, got {value!r}"
        return None

    if isinstance(t, ArrayType):
        if isinstance(t.element_type, SimpleType):
            checker = _TYPE_CHECKERS.get(t.element_type)
            if checker:
                for i, item in enumerate(value.split(",")):
                    item = item.strip()
                    if item:
                        err = checker(item)
                        if err:
                            return f"array element [{i}]: {err}"
        return None

    return None


def _check_str(value: str) -> str | None:
    return None  # Any string is valid


def _check_int(value: str) -> str | None:
    try:
        int(value)
    except ValueError:
        return f"expected int, got {value!r}"
    return None


def _check_float(value: str) -> str | None:
    try:
        float(value)
    except ValueError:
        return f"expected float, got {value!r}"
    return None


def _check_bool(value: str) -> str | None:
    if value.lower() not in ("true", "false", "1", "0", "yes", "no"):
        return f"expected bool, got {value!r}"
    return None


def _check_port(value: str) -> str | None:
    try:
        port = int(value)
    except ValueError:
        return f"expected port (int), got {value!r}"
    if not (1 <= port <= 65535):
        return f"port out of range: {port} (expected 1-65535)"
    return None


def _check_url(value: str) -> str | None:
    if "://" not in value:
        return f"expected URL (scheme://...), got {value!r}"
    return None


def _check_email(value: str) -> str | None:
    if "@" not in value or "." not in value.split("@")[-1]:
        return f"expected email, got {value!r}"
    return None


_TYPE_CHECKERS = {
    SimpleType.STR: _check_str,
    SimpleType.INT: _check_int,
    SimpleType.FLOAT: _check_float,
    SimpleType.BOOL: _check_bool,
    SimpleType.PORT: _check_port,
    SimpleType.URL: _check_url,
    SimpleType.EMAIL: _check_email,
    SimpleType.PATH: _check_str,  # No filesystem validation
}


# --- Inline validation (safe eval) ---

_SAFE_BUILTINS = {
    "len": len,
    "min": min,
    "max": max,
    "abs": abs,
    "int": int,
    "float": float,
    "str": str,
    "bool": bool,
    "isinstance": isinstance,
    "True": True,
    "False": False,
    "None": None,
}


def _check_validation(var: Variable, value: str) -> str | None:
    """Evaluate inline Python validation expression."""
    try:
        x = _coerce_value(var, value)
    except (ValueError, TypeError):
        return f"cannot coerce {value!r} for validation"

    try:
        result = eval(var.validation, {"__builtins__": _SAFE_BUILTINS}, {"x": x})
    except Exception as e:
        return f"validation error: {e}"

    if not result:
        return f"validation failed: {var.validation} (x={x!r})"
    return None
