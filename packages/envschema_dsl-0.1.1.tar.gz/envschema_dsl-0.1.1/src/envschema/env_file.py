"""Parser for .env files."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class EnvEntry:
    key: str
    value: str
    line: int


@dataclass
class EnvFile:
    entries: list[EnvEntry] = field(default_factory=list)

    def get(self, key: str) -> str | None:
        for entry in self.entries:
            if entry.key == key:
                return entry.value
        return None

    def keys(self) -> list[str]:
        return [e.key for e in self.entries]

    def duplicates(self) -> list[tuple[str, list[int]]]:
        """Return keys that appear more than once, with their line numbers."""
        seen: dict[str, list[int]] = {}
        for entry in self.entries:
            seen.setdefault(entry.key, []).append(entry.line)
        return [(k, lines) for k, lines in seen.items() if len(lines) > 1]

    def as_dict(self) -> dict[str, str]:
        """Last-write-wins dict, matching how .env loaders behave."""
        return {e.key: e.value for e in self.entries}


def parse_env(content: str) -> EnvFile:
    """Parse .env file content into an EnvFile."""
    entries = []
    for lineno, raw_line in enumerate(content.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        eq = line.find("=")
        if eq == -1:
            continue
        key = line[:eq].strip()
        value = line[eq + 1:].strip()
        # Strip surrounding quotes
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        if key:
            entries.append(EnvEntry(key=key, value=value, line=lineno))
    return EnvFile(entries=entries)


def parse_env_file(path: str | Path) -> EnvFile:
    """Parse a .env file from disk."""
    return parse_env(Path(path).read_text())
