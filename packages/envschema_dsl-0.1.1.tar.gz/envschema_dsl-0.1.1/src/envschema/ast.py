"""AST node definitions for EnvSchema DSL."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class SimpleType(Enum):
    STR = "str"
    INT = "int"
    FLOAT = "float"
    BOOL = "bool"
    PORT = "port"
    URL = "url"
    EMAIL = "email"
    PATH = "path"


@dataclass
class EnumType:
    values: list[str]


@dataclass
class TypeRef:
    """Reference to a named type (from type alias or preset)."""
    name: str


@dataclass
class UnionType:
    """Union of types: TypeA + TypeB."""
    types: list[SimpleType | EnumType | TypeRef]


@dataclass
class ArrayType:
    element_type: SimpleType | EnumType | TypeRef


@dataclass
class Decorator:
    name: str
    arg: str | None = None


@dataclass
class Expansion:
    """Wildcard expansion marker — {PROVIDERS} or {PROVIDERS|upper}."""
    source: str  # Variable name to expand from (e.g., "PROVIDERS")
    filter: str | None = None  # Optional filter (e.g., "upper")


@dataclass
class Include:
    """#include directive."""
    target: str  # preset name or file path
    is_local: bool = False  # True for "path", False for <preset>
    line: int | None = None


@dataclass
class TypeAlias:
    """type Name = expr."""
    name: str
    value: SimpleType | EnumType | TypeRef | UnionType
    line: int | None = None


@dataclass
class Variable:
    name: str
    type: SimpleType | EnumType | ArrayType | TypeRef | None = None
    default: str | int | float | bool | None = None
    decorators: list[Decorator] = field(default_factory=list)
    validation: str | None = None
    expansion: Expansion | None = None
    line: int | None = None

    @property
    def is_required(self) -> bool:
        return any(d.name == "required" for d in self.decorators)

    @property
    def is_secret(self) -> bool:
        return any(d.name == "secret" for d in self.decorators)


@dataclass
class Comment:
    text: str
    line: int | None = None


@dataclass
class Schema:
    variables: list[Variable] = field(default_factory=list)
    comments: list[Comment] = field(default_factory=list)
    includes: list[Include] = field(default_factory=list)
    type_aliases: list[TypeAlias] = field(default_factory=list)

    def resolve_type(self, name: str) -> SimpleType | EnumType | UnionType | None:
        """Look up a type alias by name."""
        for alias in self.type_aliases:
            if alias.name == name:
                return alias.value
        return None
