"""EnvSchema — DSL for typed .env files."""

from .ast import (
    ArrayType, Comment, Decorator, EnumType, Expansion, Include,
    Schema, SimpleType, TypeAlias, TypeRef, UnionType, Variable,
)
from .parser import parse, parse_file

__all__ = [
    "ArrayType",
    "Comment",
    "Decorator",
    "EnumType",
    "Include",
    "Schema",
    "SimpleType",
    "TypeAlias",
    "TypeRef",
    "UnionType",
    "Variable",
    "parse",
    "parse_file",
]
