# omnidoc/utils/serialize.py
"""
Serialization utilities — Document → JSON dict or TOON dict.

Chunks (doc.chunks) are included as-is when present.
For RAG chunking, install omnidoc-rag: pip install omnidoc-rag
"""

from typing import Any, Dict, List


def document_to_json(doc) -> Dict[str, Any]:
    """Serialize a Document to a RAG-ready JSON-compatible dict."""
    return {
        "metadata": doc.metadata,
        "sections": [{"page": s.page, "text": s.text} for s in doc.sections],
        "tables": [
            {"page": t.page, "headers": t.headers, "rows": t.rows} for t in doc.tables
        ],
        "chunks": _chunks_as_dicts(doc.chunks),
        "raw_text": doc.raw_text,
    }


def document_to_toon(doc) -> Dict[str, Any]:
    """Serialize a Document to agent-native TOON format."""
    chunks = _chunks_as_dicts(doc.chunks)
    return {
        "type": "document",
        "document": doc.metadata,
        "content": [{"page": s.page, "text": s.text} for s in doc.sections],
        "reasoning": [
            {
                "chunk_id": c.get("id"),
                "intent": c.get("intent"),
                "content": c.get("text"),
            }
            for c in chunks
        ],
        "confidence": round(min(1.0, 0.6 + 0.05 * len(chunks)), 2) if chunks else 0.6,
    }


def _chunks_as_dicts(chunks) -> List[Dict[str, Any]]:
    """Normalise SemanticChunk dataclasses or plain dicts to dicts."""
    result = []
    for c in chunks:
        if isinstance(c, dict):
            result.append(c)
        else:
            result.append(
                {
                    "id": getattr(c, "id", None),
                    "text": getattr(c, "text", ""),
                    "intent": getattr(c, "intent", None),
                    "metadata": getattr(c, "metadata", {}),
                }
            )
    return result
