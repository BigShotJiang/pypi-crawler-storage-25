import re


def clean_text(text: str) -> str:
    """
    Lightly clean extracted PDF/document text.

    Rules (in priority order):
      1. Keep ALL lines containing digits (page numbers, codes, IDs, KPIs).
      2. Keep ALL lines containing any alphanumeric character.
      3. Drop lines that are pure symbol/whitespace noise (no alnum chars).
      4. Normalize multiple blank lines → single blank line.
      5. Normalize multiple spaces/tabs → single space.

    Deliberately NOT dropped:
      - Acronyms / abbreviations (IT4IT, HTTP, XML, SLA, BPMN …)
      - Short headings and labels
      - Lines with only uppercase letters
    """
    if not text:
        return ""

    # Normalize form-feed to space
    text = text.replace("\x0c", " ")

    lines_out = []

    for raw_line in text.splitlines():
        line = raw_line.strip()

        # Blank lines become separators — keep one later via regex
        if not line:
            lines_out.append("")
            continue

        # Drop lines with no alphanumeric content at all (pure symbols/borders)
        if not any(c.isalnum() for c in line):
            continue

        lines_out.append(line)

    text = "\n".join(lines_out)

    # Collapse 3+ consecutive blank lines → 2 (preserves paragraph breaks)
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Collapse multiple inline spaces/tabs
    text = re.sub(r"[ \t]{2,}", " ", text)

    return text.strip()
