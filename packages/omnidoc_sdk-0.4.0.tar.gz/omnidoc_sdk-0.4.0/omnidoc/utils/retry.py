"""
omnidoc/utils/retry.py
----------------------
Exponential-backoff retry decorator for transient failures (OCR APIs,
cloud storage, network I/O).

Usage
-----
    from omnidoc.utils.retry import with_retry

    @with_retry(max_attempts=3, base_delay=1.0, exceptions=(ClientError,))
    def call_aws():
        ...

    # Or inline:
    result = with_retry(max_attempts=3)(my_function)(arg1, arg2)
"""

import functools
import logging
import random
import time
from typing import Callable, Tuple, Type

logger = logging.getLogger(__name__)

# Default exception types considered transient
_DEFAULT_TRANSIENT: Tuple[Type[Exception], ...] = (
    OSError,
    TimeoutError,
    ConnectionError,
)


def with_retry(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    backoff_factor: float = 2.0,
    jitter: bool = True,
    exceptions: Tuple[Type[Exception], ...] = _DEFAULT_TRANSIENT,
) -> Callable:
    """
    Decorator / higher-order function that retries *fn* on *exceptions*.

    Parameters
    ----------
    max_attempts:   Total call attempts (1 = no retry).
    base_delay:     Initial wait in seconds before first retry.
    max_delay:      Cap on per-attempt wait.
    backoff_factor: Multiplier applied to delay after each failure.
    jitter:         Add ±25 % random jitter to avoid thundering-herd.
    exceptions:     Exception types that trigger a retry.
    """
    if max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            delay = base_delay
            last_exc: Exception = RuntimeError("unreachable")

            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        break

                    actual_delay = min(delay, max_delay)
                    if jitter:
                        actual_delay *= 0.75 + random.random() * 0.5

                    logger.warning(
                        "Attempt %d/%d for '%s' failed: %s — retrying in %.2fs",
                        attempt,
                        max_attempts,
                        fn.__qualname__,
                        exc,
                        actual_delay,
                    )
                    time.sleep(actual_delay)
                    delay = min(delay * backoff_factor, max_delay)

            logger.error(
                "All %d attempts for '%s' exhausted. Last error: %s",
                max_attempts,
                fn.__qualname__,
                last_exc,
            )
            raise last_exc

        return wrapper

    return decorator
