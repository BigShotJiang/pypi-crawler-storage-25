import logging
import os

import pdfplumber

logger = logging.getLogger(__name__)


def is_scanned_pdf(path: str) -> bool:
    """Return True if the PDF has no extractable text on the first two pages."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"PDF not found: {path}")

    try:
        with pdfplumber.open(path) as pdf:
            if not pdf.pages:
                logger.warning(
                    "is_scanned_pdf: '%s' has no pages; treating as scanned", path
                )
                return True
            for page in pdf.pages[:2]:
                if page.extract_text():
                    return False
    except Exception as exc:
        logger.warning(
            "is_scanned_pdf: could not inspect '%s' (%s); assuming scanned", path, exc
        )
        return True

    return True
