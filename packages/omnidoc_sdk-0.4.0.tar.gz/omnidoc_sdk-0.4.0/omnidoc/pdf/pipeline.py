# omnidoc/pdf/pipeline.py
# -------------------------------------------------
# Suppress noisy third-party loggers at import time.
# Use OMNIDOC_LOG_LEVEL=DEBUG to restore them.
# -------------------------------------------------
import logging
import os
import warnings
from typing import Any, Dict, Optional, Union

import pdfplumber

from omnidoc.pdf.detector import is_scanned_pdf
from omnidoc.pdf.text import _extract_page_text
from omnidoc.pdf.ocr_tables import extract_ocr_tables
from omnidoc.pdf.normalize import build_document
from omnidoc.core.document import Table

from omnidoc.ocr.base import OCREngine
from omnidoc.ocr.tesseract import TesseractOCR

from omnidoc.utils.text import clean_text
from omnidoc.layout.ordering import order_blocks
from omnidoc.layout.utils import text_blocks_only

warnings.filterwarnings("ignore")
for _noisy in ("pdfminer", "pdfplumber", "pypdf", "PIL"):
    logging.getLogger(_noisy).setLevel(logging.CRITICAL)

logger = logging.getLogger(__name__)

_VALID_OUTPUT_FORMATS = frozenset({"document", "json", "toon"})


def extract_pdf(
    path: str,
    *,
    ocr_engine: Optional[OCREngine] = None,
    enable_layout: bool = True,
    enable_pii_masking: bool = False,
    enable_cloud_ocr: bool = False,
    enable_vlm: bool = False,
    enable_semantic_chunks: bool = False,
    output_format: str = "document",  # document | json | toon
    config=None,  # Optional[OmnidocConfig]
) -> Union[Dict[str, Any], object]:
    """
    Enterprise-grade PDF extraction pipeline.

    Returns a Document object (default), a RAG-ready JSON dict, or TOON format.

    Parameters
    ----------
    path:               Absolute or relative path to a PDF file.
    ocr_engine:         Custom OCR engine; auto-selected when None.
    enable_layout:      Use layout-aware extraction (column order, reading order).
                        For digital PDFs this uses pdfplumber's layout mode.
                        For scanned PDFs this uses layout ML + Tesseract.
    enable_pii_masking: Redact PII from raw_text (requires [privacy] extra).
    enable_cloud_ocr:   Use AWS Textract for scanned PDFs.
    enable_vlm:         Use Donut VLM for scanned PDFs.
    output_format:      "document" | "json" | "toon"
    config:             OmnidocConfig instance; uses default_config when None.
    """
    from omnidoc.config import OmnidocConfig, default_config

    cfg: OmnidocConfig = config if config is not None else default_config

    # ------------------------------------------------------------------
    # Input validation
    # ------------------------------------------------------------------
    if not isinstance(path, str) or not path.strip():
        raise ValueError("path must be a non-empty string")

    if not os.path.exists(path):
        raise FileNotFoundError(f"PDF not found: {path}")

    if not os.path.isfile(path):
        raise ValueError(f"Path is not a file: {path}")

    file_size = os.path.getsize(path)
    if file_size > cfg.max_file_bytes:
        raise ValueError(
            f"File size {file_size / 1024 / 1024:.1f} MB exceeds limit "
            f"{cfg.max_file_mb} MB for '{path}'"
        )

    if output_format not in _VALID_OUTPUT_FORMATS:
        raise ValueError(
            f"Invalid output_format '{output_format}'. "
            f"Expected one of: {sorted(_VALID_OUTPUT_FORMATS)}"
        )

    logger.info(
        "extract_pdf: starting — path='%s' size=%.1fKB layout=%s cloud_ocr=%s vlm=%s",
        path,
        file_size / 1024,
        enable_layout,
        enable_cloud_ocr,
        enable_vlm,
    )

    sections: list = []
    tables: list = []

    # ------------------------------------------------------------------
    # Scan detection
    # ------------------------------------------------------------------
    try:
        scanned = is_scanned_pdf(path)
    except Exception as exc:
        logger.warning("extract_pdf: scan detection failed (%s); assuming digital", exc)
        scanned = False

    logger.debug("extract_pdf: scanned=%s", scanned)

    # ------------------------------------------------------------------
    # OCR routing
    # ------------------------------------------------------------------
    if scanned and enable_cloud_ocr:
        from omnidoc.ocr.aws_textract import TextractOCR

        ocr_engine = TextractOCR(region=cfg.aws_region, timeout=cfg.ocr_timeout)
    else:
        ocr_engine = ocr_engine or TesseractOCR()

    # ==================================================================
    # 1 & 2. DIGITAL PDF — pdfplumber (authoritative for digital text)
    #
    # For digital PDFs, pdfplumber reads the actual PDF text layer.
    # This is always more accurate and complete than image-based OCR.
    # layout=True preserves column order and reading-order positions.
    # OCR is used ONLY for pages with no extractable text (scanned pages
    # embedded within an otherwise digital PDF).
    # ==================================================================
    if not scanned:
        logger.debug("extract_pdf: branch=digital dpi=%d", cfg.pdf_dpi)
        try:
            import pytesseract

            # Lazy-load page images only for pages that need OCR fallback
            page_images: Optional[list] = None

            with pdfplumber.open(path) as pdf:
                for i, page in enumerate(pdf.pages):
                    page_num = i + 1

                    # --- Primary: pdfplumber text (fast, accurate) ---
                    text = _extract_page_text(page, page_num)

                    # --- Fallback: OCR for pages with no extractable text ---
                    if not text.strip():
                        logger.debug(
                            "extract_pdf: page %d has no digital text — using OCR fallback",
                            page_num,
                        )
                        if page_images is None:
                            try:
                                from pdf2image import convert_from_path

                                page_images = convert_from_path(path, dpi=cfg.pdf_dpi)
                            except Exception as exc:
                                logger.warning(
                                    "extract_pdf: pdf2image failed (%s); "
                                    "scanned pages in '%s' will be blank",
                                    exc,
                                    path,
                                )
                                page_images = []

                        if i < len(page_images):
                            try:
                                text = pytesseract.image_to_string(page_images[i])
                            except Exception as exc:  # pragma: no cover
                                logger.warning(  # pragma: no cover
                                    "extract_pdf: OCR fallback failed on page %d: %s",
                                    page_num,
                                    exc,
                                )

                    sections.append({"page": page_num, "text": clean_text(text)})

                    # --- Tables: pdfplumber per-page (most accurate for digital) ---
                    try:
                        page_tables = page.extract_tables() or []
                        for tbl_data in page_tables:
                            if not tbl_data or len(tbl_data) < 1:
                                continue
                            headers = [str(c or "").strip() for c in tbl_data[0]]
                            rows = [
                                [str(c or "").strip() for c in row]
                                for row in tbl_data[1:]
                            ]
                            if any(h for h in headers):
                                tables.append(
                                    Table(
                                        page=page_num,
                                        headers=headers,
                                        rows=rows,
                                    )
                                )
                    except Exception as exc:
                        logger.warning(
                            "extract_pdf: pdfplumber table extraction failed on page %d: %s",
                            page_num,
                            exc,
                        )

            # --- Supplement with camelot for lattice/stream tables ---
            camelot_tables = _extract_camelot_tables(path)
            tables.extend(camelot_tables)

        except Exception as exc:
            logger.error("extract_pdf: digital pipeline failed: %s", exc, exc_info=True)
            raise

    # ==================================================================
    # 3. SCANNED PDF — OCR-based
    # ==================================================================
    else:
        logger.debug("extract_pdf: branch=scanned")
        try:
            import pytesseract
            from omnidoc.layout.detector import detect_layout

            for page in ocr_engine.extract(path):
                text = page.get("text", "")

                if enable_vlm and "image" in page:
                    try:
                        from omnidoc.layout.donut import DonutExtractor

                        text = DonutExtractor().extract(page["image"])
                    except Exception as exc:
                        logger.warning(
                            "extract_pdf: VLM failed on page %s: %s",
                            page.get("page"),
                            exc,
                        )

                elif enable_layout and "image" in page:
                    try:
                        blocks = detect_layout(page["image"])
                        if blocks:
                            blocks = order_blocks(text_blocks_only(blocks))
                            text = "\n".join(b.text for b in blocks)
                        else:
                            text = pytesseract.image_to_string(page["image"])
                        ocr_tables = extract_ocr_tables(page["image"])
                        if ocr_tables:
                            tables.append({"page": page["page"], "rows": ocr_tables})
                    except Exception as exc:
                        logger.warning(
                            "extract_pdf: scanned layout failed on page %s: %s",
                            page.get("page"),
                            exc,
                        )

                sections.append({"page": page["page"], "text": clean_text(text)})

        except Exception as exc:
            logger.error("extract_pdf: scanned pipeline failed: %s", exc, exc_info=True)
            raise

    # ==================================================================
    # BUILD DOCUMENT
    # ==================================================================
    doc = build_document(path, sections, tables)
    doc.metadata.update(
        {
            "source_type": "pdf",
            "pipeline": "pdf",
            "scanned": scanned,
        }
    )

    # Reconstruct raw_text from all sections preserving page order
    doc.raw_text = "\n\n".join(sec.text for sec in doc.sections if sec.text)

    # PII masking (optional)
    if enable_pii_masking or cfg.enable_pii_masking:
        try:
            from omnidoc.privacy.pii import mask_pii

            doc.raw_text = mask_pii(doc.raw_text)
        except Exception as exc:
            logger.error("extract_pdf: PII masking failed: %s", exc, exc_info=True)
            raise

    # Semantic chunks (optional)
    if enable_semantic_chunks:
        doc.chunks = _make_chunks(doc)

    logger.info(
        "extract_pdf: done — %d sections, %d tables",
        len(doc.sections),
        len(doc.tables),
    )

    # Output format
    from omnidoc.utils.serialize import document_to_json, document_to_toon

    if output_format == "json":
        return document_to_json(doc)
    if output_format == "toon":
        return document_to_toon(doc)
    return doc


def _extract_camelot_tables(path: str) -> list:
    """
    Supplement pdfplumber table extraction with camelot.
    Tries lattice first (bordered tables), then stream (borderless).
    Never raises — returns empty list on any failure.
    """
    try:
        import camelot
    except ImportError:
        return []

    result = []

    for flavor in ("lattice", "stream"):
        try:
            raw = camelot.read_pdf(path, pages="all", flavor=flavor)
            for t in raw:
                try:
                    df = t.df
                    if df.empty or len(df) < 1:
                        continue
                    headers = df.iloc[0].astype(str).tolist()
                    rows = (
                        df.iloc[1:].astype(str).values.tolist() if len(df) > 1 else []
                    )
                    result.append(Table(page=t.page, headers=headers, rows=rows))
                except Exception as exc:
                    logger.debug("_extract_camelot_tables: skipping table: %s", exc)
        except Exception as exc:
            logger.debug("_extract_camelot_tables: %s flavor failed: %s", flavor, exc)

    return result


def _make_chunks(doc) -> list:
    """Generate basic semantic chunks from a Document's sections."""
    import hashlib

    chunks = []
    for i, sec in enumerate(doc.sections):
        text = sec.text.strip() if sec.text else ""
        if not text:
            continue
        chunk_id = hashlib.md5(f"{i}:{text[:64]}".encode()).hexdigest()[:12]
        chunks.append(
            {
                "id": chunk_id,
                "text": text,
                "intent": "narrative",
                "confidence": 0.85,
                "page": sec.page,
            }
        )
    return chunks
