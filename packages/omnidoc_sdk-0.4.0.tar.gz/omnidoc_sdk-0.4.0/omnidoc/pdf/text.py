import logging

import pdfplumber
from omnidoc.core.document import Section

logger = logging.getLogger(__name__)


def extract_text(path: str) -> list[Section]:
    """
    Extract text from a digital PDF page-by-page.

    Uses pdfplumber with layout=True which respects character positions to
    reconstruct proper reading order (handles multi-column, headers, sidebars).
    Falls back to plain extraction if layout mode fails on any page.
    """
    sections = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages):
            text = _extract_page_text(page, i + 1)
            sections.append(Section(page=i + 1, text=text))
    return sections


def extract_page_text(path: str, page_number: int) -> str:
    """Extract text from a single page (1-indexed). Used by pipeline."""
    with pdfplumber.open(path) as pdf:
        if page_number < 1 or page_number > len(pdf.pages):
            return ""
        return _extract_page_text(pdf.pages[page_number - 1], page_number)


def extract_page_tables(path: str, page_number: int) -> list:
    """Extract tables from a single page (1-indexed) using pdfplumber."""
    with pdfplumber.open(path) as pdf:
        if page_number < 1 or page_number > len(pdf.pages):
            return []
        return pdf.pages[page_number - 1].extract_tables() or []


def _extract_page_text(page, page_num: int) -> str:
    """Extract text from a pdfplumber page object with layout fallback."""
    # layout=True preserves column order and reading position
    try:
        text = page.extract_text(layout=True) or ""
        if text.strip():
            return text
    except Exception as exc:  # pragma: no cover
        logger.debug(
            "extract_text: layout mode failed on page %d: %s", page_num, exc
        )  # pragma: no cover

    # Plain extraction as fallback
    try:
        text = page.extract_text(x_tolerance=3, y_tolerance=3) or ""
        if text.strip():
            return text
    except Exception as exc:  # pragma: no cover
        logger.debug(
            "extract_text: plain extraction failed on page %d: %s", page_num, exc
        )  # pragma: no cover

    return ""
