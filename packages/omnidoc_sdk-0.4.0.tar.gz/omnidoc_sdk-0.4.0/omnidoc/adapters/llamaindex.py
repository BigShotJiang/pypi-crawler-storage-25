def to_llamaindex(doc):
    from llama_index.core import Document

    return [
        Document(text=section.text, metadata={"page": section.page})
        for section in doc.sections
    ]
