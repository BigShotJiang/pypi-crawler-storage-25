def to_langchain(doc):
    from langchain.schema import Document as LCDocument

    return [
        LCDocument(page_content=section.text, metadata={"page": section.page})
        for section in doc.sections
    ]
