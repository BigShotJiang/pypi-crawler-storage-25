from enum import Enum


class DocumentType(Enum):
    # ── Text & Office ─────────────────────────────────
    TXT = "txt"
    DOCX = "docx"
    PDF = "pdf"
    RTF = "rtf"

    # ── Spreadsheet ───────────────────────────────────
    XLSX = "xlsx"
    XLS = "xls"
    CSV = "csv"
    TSV = "tsv"

    # ── Presentation ──────────────────────────────────
    PPTX = "pptx"

    # ── OpenDocument (LibreOffice) ────────────────────
    ODT = "odt"
    ODS = "ods"
    ODP = "odp"

    # ── Images ────────────────────────────────────────
    PNG = "png"
    JPG = "jpg"
    JPEG = "jpeg"
    TIFF = "tiff"
    TIF = "tif"
    WEBP = "webp"
    HEIC = "heic"
    HEIF = "heif"
    SVG = "svg"
    BMP = "bmp"
    GIF = "gif"

    # ── Structured data ───────────────────────────────
    JSON = "json"
    XML = "xml"
    YAML = "yaml"
    YML = "yml"

    # ── Web ───────────────────────────────────────────
    HTML = "html"
    HTM = "htm"

    # ── Docs / Markdown ───────────────────────────────
    MD = "md"
    RST = "rst"
    EPUB = "epub"

    # ── Email ─────────────────────────────────────────
    EML = "eml"
    MSG = "msg"

    # ── Code ──────────────────────────────────────────
    PY = "py"
    JAVA = "java"
    JS = "js"
    TS = "ts"
    GO = "go"
    CPP = "cpp"
    C = "c"
    RS = "rs"

    # ── Notebooks ─────────────────────────────────────
    IPYNB = "ipynb"

    # ── Archives ──────────────────────────────────────
    ZIP = "zip"
    TAR = "tar"
    GZ = "gz"  # .tar.gz handled via compound extension detection
    SEVENZ = "7z"

    # ── Multimedia ────────────────────────────────────
    MP4 = "mp4"
    MP3 = "mp3"
    WAV = "wav"
    M4A = "m4a"
    MOV = "mov"
    AVI = "avi"
    MKV = "mkv"

    UNKNOWN = "unknown"
