"""
omnidoc/cli/main.py
--------------------
CLI entry point — `omnidoc extract <file>`.

Errors are printed as human-readable messages (not raw tracebacks)
so that end users get actionable feedback.
"""

import argparse
import json
import logging
import os
import sys
from typing import NoReturn


def _die(message: str, code: int = 1) -> NoReturn:
    print(f"error: {message}", file=sys.stderr)
    sys.exit(code)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="omnidoc",
        description="OmniDoc — enterprise document intelligence CLI",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # ── extract ──────────────────────────────────────────────────────
    ex = sub.add_parser("extract", help="Extract text and chunks from a document")
    ex.add_argument("file", help="Path to the document (PDF, DOCX, TXT, …)")
    ex.add_argument(
        "--format",
        choices=["text", "json", "toon"],
        default="text",
        help="Output format (default: text)",
    )
    ex.add_argument(
        "--layout",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Enable layout ML for PDFs (default: on)",
    )
    ex.add_argument(
        "--cloud-ocr",
        action="store_true",
        default=False,
        help="Use AWS Textract for scanned PDFs",
    )
    ex.add_argument(
        "--pii",
        action="store_true",
        default=False,
        help="Mask PII in output (requires [privacy] extra)",
    )
    ex.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="WARNING",
        help="Logging verbosity (default: WARNING)",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # ── configure logging ────────────────────────────────────────────
    try:
        from omnidoc.utils.logging_config import configure_logging

        configure_logging(level=args.log_level)
    except Exception:
        logging.basicConfig(level=getattr(logging, args.log_level, logging.WARNING))

    # ── validate input file ──────────────────────────────────────────
    if not os.path.exists(args.file):
        _die(f"file not found: {args.file}")

    if not os.path.isfile(args.file):
        _die(f"path is not a file: {args.file}")

    # ── dispatch ─────────────────────────────────────────────────────
    if args.command == "extract":
        _run_extract(args)


def _run_extract(args) -> None:
    from omnidoc.loader.load import load_document

    output_format_map = {"text": "document", "json": "json", "toon": "toon"}
    fmt = output_format_map[args.format]

    try:
        # For PDFs use extract_pdf directly so format flag works
        ext = os.path.splitext(args.file)[1].lower()
        if ext == ".pdf":
            from omnidoc.pdf.pipeline import extract_pdf

            result = extract_pdf(
                args.file,
                enable_layout=args.layout,
                enable_cloud_ocr=args.cloud_ocr,
                enable_pii_masking=args.pii,
                output_format=fmt,
            )
        else:
            result = load_document(args.file)
            fmt = "document"  # non-PDF always returns Document object

    except FileNotFoundError as exc:
        _die(str(exc))
    except ValueError as exc:
        _die(f"invalid input — {exc}")
    except ImportError as exc:
        _die(
            f"missing optional dependency — {exc}\nInstall the required extra: pip install 'omnidoc-sdk[office]'"
        )
    except MemoryError:
        _die(
            "out of memory — try a smaller file or reduce DPI with OMNIDOC_PDF_DPI=150"
        )
    except Exception as exc:
        # Show a clean message; log the full traceback at DEBUG level
        logging.getLogger(__name__).debug("extract failed", exc_info=True)
        _die(f"extraction failed — {type(exc).__name__}: {exc}")

    # ── output ───────────────────────────────────────────────────────
    if fmt in ("json", "toon"):
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        # Document object
        raw = getattr(result, "raw_text", "") or ""
        if not raw.strip():
            print("(no text extracted)", file=sys.stderr)
        else:
            print(raw)


if __name__ == "__main__":  # pragma: no cover
    main()  # pragma: no cover
