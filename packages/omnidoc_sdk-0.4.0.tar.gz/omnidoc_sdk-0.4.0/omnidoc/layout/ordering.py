import logging
from typing import Any, List

logger = logging.getLogger(__name__)

# Height of vertical buckets in pixels (groups text on approximately the same row)
_BUCKET_HEIGHT = 40


def order_blocks(blocks: List[Any]) -> List[Any]:
    """
    Sort layout blocks top-to-bottom, left-to-right.

    Handles multi-column layouts by bucketing blocks into horizontal
    strips of _BUCKET_HEIGHT pixels, then sorting left-to-right within
    each strip.

    Blocks that are missing coordinate attributes are placed at the end.
    """

    def _sort_key(b):
        try:
            y1 = float(b.block.y_1)
            x1 = float(b.block.x_1)
            return (round(y1 / _BUCKET_HEIGHT), x1)
        except (AttributeError, TypeError, ValueError):
            logger.warning("order_blocks: block missing coordinates — placing at end")
            return (float("inf"), float("inf"))

    return sorted(blocks, key=_sort_key)
