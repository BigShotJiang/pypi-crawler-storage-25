"""Tests for the PDF pipeline (extract_pdf + load_document)."""

import os
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")
PDF_PATH = os.path.join(DATA, "sample.pdf")


# ---------------------------------------------------------------------------
# Core pipeline
# ---------------------------------------------------------------------------


def test_pdf_extract_basic():
    from omnidoc.pdf.pipeline import extract_pdf

    doc = extract_pdf(PDF_PATH, enable_layout=False, enable_semantic_chunks=False)

    assert doc is not None
    assert isinstance(doc.raw_text, str)
    assert len(doc.raw_text) > 0
    assert doc.metadata["source_type"] == "pdf"
    assert doc.metadata["pipeline"] == "pdf"
    assert isinstance(doc.metadata["scanned"], bool)


def test_pdf_sections_exist():
    from omnidoc.pdf.pipeline import extract_pdf

    doc = extract_pdf(PDF_PATH, enable_layout=False, enable_semantic_chunks=False)

    assert len(doc.sections) >= 1
    for sec in doc.sections:
        assert isinstance(sec.page, int)
        assert sec.page >= 1
        assert isinstance(sec.text, str)


def test_pdf_semantic_chunks():
    from omnidoc.pdf.pipeline import extract_pdf

    doc = extract_pdf(PDF_PATH, enable_layout=False, enable_semantic_chunks=True)

    assert hasattr(doc, "chunks")
    assert len(doc.chunks) > 0

    for chunk in doc.chunks:
        assert "id" in chunk
        assert "text" in chunk
        assert "intent" in chunk
        assert "confidence" in chunk
        assert len(chunk["text"]) > 0
        assert 0.0 < chunk["confidence"] <= 1.0


def test_pdf_json_output():
    from omnidoc.pdf.pipeline import extract_pdf

    result = extract_pdf(PDF_PATH, enable_layout=False, output_format="json")

    assert isinstance(result, dict)
    assert "metadata" in result
    assert "sections" in result
    assert "chunks" in result
    assert "tables" in result
    assert isinstance(result["chunks"], list)


def test_pdf_toon_output():
    from omnidoc.pdf.pipeline import extract_pdf

    result = extract_pdf(PDF_PATH, enable_layout=False, output_format="toon")

    assert isinstance(result, dict)
    assert "document" in result
    assert "reasoning" in result
    assert "confidence" in result
    assert isinstance(result["reasoning"], list)


def test_pdf_via_loader():
    from omnidoc.loader.load import load_document

    doc = load_document(PDF_PATH)

    assert doc is not None
    assert len(doc.raw_text) > 0
    assert len(doc.chunks) > 0


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------


def test_pdf_missing_file_raises():
    from omnidoc.pdf.pipeline import extract_pdf

    with pytest.raises(FileNotFoundError):
        extract_pdf("/nonexistent/file.pdf")


def test_pdf_invalid_output_format():
    from omnidoc.pdf.pipeline import extract_pdf

    with pytest.raises(ValueError, match="output_format"):
        extract_pdf(PDF_PATH, output_format="invalid")


def test_pdf_empty_path_raises():
    from omnidoc.pdf.pipeline import extract_pdf

    with pytest.raises(ValueError):
        extract_pdf("")


def test_loader_missing_file_raises():
    from omnidoc.loader.load import load_document

    with pytest.raises(FileNotFoundError):
        load_document("/nonexistent/file.pdf")
