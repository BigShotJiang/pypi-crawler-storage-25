# omnidoc/tests/test_new_extractors.py
"""
Tests for all newly added extractors:
  HTMLExtractor, YAMLExtractor, EMLExtractor,
  NotebookExtractor, CodeExtractor, RTFExtractor (stub),
  EPUBExtractor (stub), OpenDocumentExtractor (stub),
  MSGExtractor (stub), MediaExtractor (stub).

Heavy optional-dependency extractors (EPUB, ODT, MSG, Media) are skipped
when their backing library is not installed — allowing the test suite to
pass in a lean environment.
"""

import email as _email_mod
import email.policy
import sys
import textwrap
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write(tmp_path, name, content, mode="w", encoding="utf-8"):
    p = tmp_path / name
    if mode == "wb":
        p.write_bytes(content)
    else:
        p.write_text(content, encoding=encoding)
    return str(p)


# ===========================================================================
# HTMLExtractor
# ===========================================================================


class TestHTMLExtractor:
    pytest.importorskip("bs4", reason="beautifulsoup4 not installed")

    def test_basic_html(self, tmp_path):
        from omnidoc.extractors.web.html_extractor import HTMLExtractor

        html = "<html><head><title>Test</title></head><body><p>Hello world</p></body></html>"
        path = _write(tmp_path, "page.html", html)
        doc = HTMLExtractor().extract(path)
        assert "Hello world" in doc.raw_text
        assert doc.metadata["type"] == "html"
        assert doc.metadata.get("title") == "Test"

    def test_strips_scripts(self, tmp_path):
        from omnidoc.extractors.web.html_extractor import HTMLExtractor

        html = "<html><body><script>alert(1)</script><p>Clean text</p></body></html>"
        path = _write(tmp_path, "page.html", html)
        doc = HTMLExtractor().extract(path)
        assert "alert" not in doc.raw_text
        assert "Clean text" in doc.raw_text

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.web.html_extractor import HTMLExtractor

        with pytest.raises(FileNotFoundError):
            HTMLExtractor().extract(str(tmp_path / "ghost.html"))

    def test_sections_produced(self, tmp_path):
        from omnidoc.extractors.web.html_extractor import HTMLExtractor

        html = "<html><body><h1>Title</h1><p>Para one</p><p>Para two</p></body></html>"
        path = _write(tmp_path, "page.html", html)
        doc = HTMLExtractor().extract(path)
        assert len(doc.sections) >= 2


# ===========================================================================
# YAMLExtractor
# ===========================================================================


class TestYAMLExtractor:
    pytest.importorskip("yaml", reason="pyyaml not installed")

    def test_basic_yaml(self, tmp_path):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

        content = "name: Alice\nage: 30\ncity: London\n"
        path = _write(tmp_path, "data.yaml", content)
        doc = YAMLExtractor().extract(path)
        assert "Alice" in doc.raw_text
        assert doc.metadata["type"] == "yaml"

    def test_nested_yaml(self, tmp_path):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

        content = textwrap.dedent("""\
            server:
              host: localhost
              port: 8080
            features:
              - auth
              - logging
        """)
        path = _write(tmp_path, "config.yaml", content)
        doc = YAMLExtractor().extract(path)
        assert "localhost" in doc.raw_text
        assert "auth" in doc.raw_text

    def test_invalid_yaml(self, tmp_path):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

        path = _write(tmp_path, "bad.yaml", "key: [unclosed")
        with pytest.raises(ValueError, match="invalid YAML"):
            YAMLExtractor().extract(path)

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

        with pytest.raises(FileNotFoundError):
            YAMLExtractor().extract(str(tmp_path / "ghost.yaml"))


# ===========================================================================
# EMLExtractor
# ===========================================================================


class TestEMLExtractor:
    def _make_eml(
        self, tmp_path, subject="Hello", body="Test body", from_="alice@example.com"
    ):
        msg = _email_mod.message.EmailMessage()
        msg["Subject"] = subject
        msg["From"] = from_
        msg["To"] = "bob@example.com"
        msg["Date"] = "Mon, 01 Jan 2024 10:00:00 +0000"
        msg.set_content(body)
        path = tmp_path / "email.eml"
        path.write_bytes(msg.as_bytes())
        return str(path)

    def test_plain_email(self, tmp_path):
        from omnidoc.extractors.email.eml_extractor import EMLExtractor

        path = self._make_eml(
            tmp_path, subject="Project Update", body="Quarterly review done."
        )
        doc = EMLExtractor().extract(path)
        assert "Project Update" in doc.raw_text
        assert "Quarterly review done." in doc.raw_text
        assert doc.metadata["type"] == "eml"
        assert doc.metadata["subject"] == "Project Update"

    def test_headers_in_metadata(self, tmp_path):
        from omnidoc.extractors.email.eml_extractor import EMLExtractor

        path = self._make_eml(tmp_path, from_="sender@corp.com")
        doc = EMLExtractor().extract(path)
        assert "sender@corp.com" in doc.metadata["from"]

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.email.eml_extractor import EMLExtractor

        with pytest.raises(FileNotFoundError):
            EMLExtractor().extract(str(tmp_path / "ghost.eml"))

    def test_multipart_email(self, tmp_path):
        from omnidoc.extractors.email.eml_extractor import EMLExtractor
        from email.mime.multipart import MIMEMultipart

        msg = MIMEMultipart()
        msg["Subject"] = "Multipart"
        msg["From"] = "a@b.com"
        msg["To"] = "c@d.com"
        from email.mime.text import MIMEText

        msg.attach(MIMEText("Plain part", "plain"))
        msg.attach(MIMEText("<b>HTML part</b>", "html"))
        path = tmp_path / "multi.eml"
        path.write_bytes(msg.as_bytes())
        doc = EMLExtractor().extract(str(path))
        assert "Plain part" in doc.raw_text


# ===========================================================================
# NotebookExtractor
# ===========================================================================


class TestNotebookExtractor:
    pytest.importorskip("nbformat", reason="nbformat not installed")

    def _make_notebook(self, tmp_path, cells):
        """cells: list of (cell_type, source) tuples"""
        import nbformat

        nb = nbformat.v4.new_notebook()
        for ctype, src in cells:
            if ctype == "code":
                nb.cells.append(nbformat.v4.new_code_cell(src))
            elif ctype == "markdown":
                nb.cells.append(nbformat.v4.new_markdown_cell(src))
        path = tmp_path / "notebook.ipynb"
        with open(str(path), "w") as f:
            nbformat.write(nb, f)
        return str(path)

    def test_markdown_cells(self, tmp_path):
        from omnidoc.extractors.notebook.extractor import NotebookExtractor

        path = self._make_notebook(tmp_path, [("markdown", "# Title\nIntro text")])
        doc = NotebookExtractor().extract(path)
        assert "Title" in doc.raw_text
        assert doc.metadata["type"] == "ipynb"

    def test_code_cells(self, tmp_path):
        from omnidoc.extractors.notebook.extractor import NotebookExtractor

        path = self._make_notebook(tmp_path, [("code", "x = 1 + 2\nprint(x)")])
        doc = NotebookExtractor().extract(path)
        assert "x = 1 + 2" in doc.raw_text

    def test_mixed_cells(self, tmp_path):
        from omnidoc.extractors.notebook.extractor import NotebookExtractor

        path = self._make_notebook(
            tmp_path,
            [
                ("markdown", "## Analysis"),
                ("code", "import pandas as pd"),
                ("markdown", "Results follow"),
            ],
        )
        doc = NotebookExtractor().extract(path)
        assert len(doc.sections) == 3
        assert "Analysis" in doc.raw_text
        assert "import pandas" in doc.raw_text

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.notebook.extractor import NotebookExtractor

        with pytest.raises(FileNotFoundError):
            NotebookExtractor().extract(str(tmp_path / "ghost.ipynb"))


# ===========================================================================
# CodeExtractor
# ===========================================================================


class TestCodeExtractor:
    def test_python_file(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        code = textwrap.dedent("""\
            def add(a, b):
                return a + b

            class Calc:
                pass
        """)
        path = _write(tmp_path, "calc.py", code)
        doc = CodeExtractor().extract(path)
        assert "def add" in doc.raw_text
        assert doc.metadata["language"] == "python"
        assert doc.metadata["type"] == "code"

    def test_python_block_splitting(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        code = textwrap.dedent("""\
            def foo():
                pass

            def bar():
                pass
        """)
        path = _write(tmp_path, "funcs.py", code)
        doc = CodeExtractor(split_blocks=True).extract(path)
        # Should have 2 blocks
        assert len(doc.sections) >= 2

    def test_java_file(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        code = 'public class Hello {\n    public static void main(String[] args) {\n        System.out.println("hi");\n    }\n}'
        path = _write(tmp_path, "Hello.java", code)
        doc = CodeExtractor().extract(path)
        assert "Hello" in doc.raw_text
        assert doc.metadata["language"] == "java"

    def test_line_count(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        code = "a = 1\nb = 2\nc = 3\n"
        path = _write(tmp_path, "vars.py", code)
        doc = CodeExtractor().extract(path)
        assert doc.metadata["lines"] == 4  # 3 newlines = 4 lines

    def test_no_split_mode(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        code = "def a(): pass\ndef b(): pass\n"
        path = _write(tmp_path, "ab.py", code)
        doc = CodeExtractor(split_blocks=False).extract(path)
        assert len(doc.sections) == 1

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.code.extractor import CodeExtractor

        with pytest.raises(FileNotFoundError):
            CodeExtractor().extract(str(tmp_path / "ghost.py"))


# ===========================================================================
# RTFExtractor — skipped if striprtf not available
# ===========================================================================


@pytest.mark.skipif(
    not __import__("importlib").util.find_spec("striprtf"),
    reason="striprtf not installed",
)
class TestRTFExtractor:
    def test_basic_rtf(self, tmp_path):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        # Minimal valid RTF
        rtf = r"{\rtf1\ansi Hello RTF World}"
        path = _write(tmp_path, "doc.rtf", rtf)
        doc = RTFExtractor().extract(path)
        assert (
            "Hello" in doc.raw_text or doc.raw_text == ""
        )  # some striprtf versions vary
        assert doc.metadata["type"] == "rtf"

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        with pytest.raises(FileNotFoundError):
            RTFExtractor().extract(str(tmp_path / "ghost.rtf"))


# ===========================================================================
# EPUBExtractor — skipped if ebooklib not available
# ===========================================================================


@pytest.mark.skipif(
    not __import__("importlib").util.find_spec("ebooklib"),
    reason="ebooklib not installed",
)
class TestEPUBExtractor:
    def _make_epub(self, tmp_path):
        from ebooklib import epub

        book = epub.EpubBook()
        book.set_title("Test Book")
        book.set_language("en")
        c1 = epub.EpubHtml(title="Chapter 1", file_name="chap1.xhtml", lang="en")
        c1.content = (
            "<html><body><h1>Chapter One</h1><p>Content here.</p></body></html>"
        )
        book.add_item(c1)
        book.toc = (epub.Link("chap1.xhtml", "Chapter 1", "chap1"),)
        book.add_item(epub.EpubNcx())
        book.add_item(epub.EpubNav())
        book.spine = ["nav", c1]
        path = str(tmp_path / "test.epub")
        epub.write_epub(path, book, {})
        return path

    def test_extract_epub(self, tmp_path):
        from omnidoc.extractors.ebook.epub_extractor import EPUBExtractor

        path = self._make_epub(tmp_path)
        doc = EPUBExtractor().extract(path)
        assert "Chapter One" in doc.raw_text or "Content here" in doc.raw_text
        assert doc.metadata["type"] == "epub"

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.ebook.epub_extractor import EPUBExtractor

        with pytest.raises(FileNotFoundError):
            EPUBExtractor().extract(str(tmp_path / "ghost.epub"))


# ===========================================================================
# OpenDocumentExtractor — skipped if odfpy not available
# ===========================================================================


@pytest.mark.skipif(
    not __import__("importlib").util.find_spec("odf"),
    reason="odfpy not installed",
)
class TestOpenDocumentExtractor:
    def _make_odt(self, tmp_path):
        from odf.opendocument import OpenDocumentText
        from odf.text import P

        doc_odf = OpenDocumentText()
        p = P(text="Hello from ODT")
        doc_odf.text.addElement(p)
        path = str(tmp_path / "test.odt")
        doc_odf.save(path)
        return path

    def test_extract_odt(self, tmp_path):
        from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

        path = self._make_odt(tmp_path)
        doc = OpenDocumentExtractor().extract(path)
        assert "Hello from ODT" in doc.raw_text
        assert doc.metadata["type"] == "odt"

    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

        with pytest.raises(FileNotFoundError):
            OpenDocumentExtractor().extract(str(tmp_path / "ghost.odt"))


# ===========================================================================
# MediaExtractor — unit test via mock (no Whisper required)
# ===========================================================================


class TestMediaExtractor:
    def test_missing_file(self, tmp_path):
        from omnidoc.extractors.media.extractor import MediaExtractor

        with pytest.raises(FileNotFoundError):
            MediaExtractor().extract(str(tmp_path / "ghost.mp3"))

    def test_unsupported_extension(self, tmp_path):
        from omnidoc.extractors.media.extractor import MediaExtractor

        path = _write(tmp_path, "file.txt", "data")
        with pytest.raises(ValueError, match="unsupported extension"):
            MediaExtractor().extract(path)

    def test_transcription_via_mock(self, tmp_path):
        from omnidoc.extractors.media.extractor import MediaExtractor

        # Create a dummy mp3 file (just needs to exist)
        path = _write(tmp_path, "audio.mp3", b"ID3\x00fake", mode="wb")

        fake_whisper = MagicMock()
        fake_model = MagicMock()
        fake_model.transcribe.return_value = {
            "text": "Hello from Whisper",
            "segments": [{"text": "Hello from Whisper"}],
            "language": "en",
        }
        fake_whisper.load_model.return_value = fake_model

        with patch.dict(sys.modules, {"whisper": fake_whisper}):
            extractor = MediaExtractor(model="base")
            doc = extractor.extract(path)

        assert "Hello from Whisper" in doc.raw_text
        assert doc.metadata["type"] == "media"
        assert doc.metadata["language"] == "en"


# ===========================================================================
# Router integration — detect_document_type covers new extensions
# ===========================================================================


class TestRouterNewTypes:
    def _detect(self, filename):
        from omnidoc.loader.router import detect_document_type

        return detect_document_type(filename)

    def test_html(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("page.html") == DocumentType.HTML

    def test_htm_alias(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("page.htm") == DocumentType.HTML

    def test_yaml(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("config.yaml") == DocumentType.YAML

    def test_yml_alias(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("config.yml") == DocumentType.YAML

    def test_eml(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("email.eml") == DocumentType.EML

    def test_epub(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("book.epub") == DocumentType.EPUB

    def test_odt(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("doc.odt") == DocumentType.ODT

    def test_ods(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("sheet.ods") == DocumentType.ODS

    def test_odp(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("slides.odp") == DocumentType.ODP

    def test_rtf(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("doc.rtf") == DocumentType.RTF

    def test_ipynb(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("notebook.ipynb") == DocumentType.IPYNB

    def test_py(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("script.py") == DocumentType.PY

    def test_mp3(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("audio.mp3") == DocumentType.MP3

    def test_mp4(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("video.mp4") == DocumentType.MP4

    def test_tar_gz_compound(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("archive.tar.gz") == DocumentType.TAR

    def test_7z(self):
        from omnidoc.loader.types import DocumentType

        assert self._detect("archive.7z") == DocumentType.SEVENZ
