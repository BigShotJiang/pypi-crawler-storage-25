"""Tests for ImageExtractor (.png, .jpg)."""

import os
import tempfile
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")
IMG_PATH = os.path.join(DATA, "invoice.png")


# ---------------------------------------------------------------------------
# Happy-path
# ---------------------------------------------------------------------------


def test_image_basic():
    from omnidoc.extractors.image.extractor import ImageExtractor

    doc = ImageExtractor().extract(IMG_PATH)

    assert doc is not None
    assert doc.metadata["type"] == "image"
    assert doc.metadata["pages"] == 1
    assert len(doc.sections) == 1
    assert doc.sections[0].page == 1
    assert isinstance(doc.raw_text, str)  # may be empty if OCR finds nothing


def test_image_tables_empty():
    from omnidoc.extractors.image.extractor import ImageExtractor

    doc = ImageExtractor().extract(IMG_PATH)
    assert doc.tables == []


def test_image_via_loader():
    from omnidoc.loader.load import load_document

    doc = load_document(IMG_PATH)
    assert doc is not None
    assert doc.metadata["type"] == "image"


# ---------------------------------------------------------------------------
# Corrupt image — must not crash
# ---------------------------------------------------------------------------


def test_image_corrupt_raises_valueerror():
    from omnidoc.extractors.image.extractor import ImageExtractor

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False, mode="wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + b"\x00" * 20)  # truncated PNG header
        path = f.name

    try:
        with pytest.raises((ValueError, Exception)):
            ImageExtractor().extract(path)
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


def test_image_missing_file_raises():
    from omnidoc.extractors.image.extractor import ImageExtractor

    with pytest.raises(FileNotFoundError):
        ImageExtractor().extract("/nonexistent/image.png")


# ---------------------------------------------------------------------------
# Programmatic image (no disk file needed)
# ---------------------------------------------------------------------------


def test_image_synthetic():
    """Create a white PNG in-memory and verify extraction doesn't crash."""
    pytest.importorskip("PIL")
    from PIL import Image as PILImage
    from omnidoc.extractors.image.extractor import ImageExtractor

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        path = f.name

    img = PILImage.new("RGB", (200, 100), color=(255, 255, 255))
    img.save(path)

    try:
        doc = ImageExtractor().extract(path)
        # White image may produce empty text — should not raise
        assert isinstance(doc.raw_text, str)
    finally:
        os.unlink(path)
