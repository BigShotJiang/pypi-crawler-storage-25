"""Tests for SpreadsheetExtractor (.xlsx, .csv)."""

import os
import tempfile
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")
CSV_PATH = os.path.join(DATA, "sample.csv")


# ---------------------------------------------------------------------------
# CSV happy-path
# ---------------------------------------------------------------------------


def test_csv_basic():
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(CSV_PATH)

    assert doc is not None
    assert doc.metadata["type"] == "spreadsheet"
    assert len(doc.tables) == 1
    assert len(doc.sections) >= 1
    assert doc.sections[0].page == 1


def test_csv_has_headers():
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(CSV_PATH)

    tbl = doc.tables[0]
    assert isinstance(tbl.headers, list)
    assert len(tbl.headers) > 0
    # Headers must all be strings
    for h in tbl.headers:
        assert isinstance(h, str)


def test_csv_rows_are_strings():
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(CSV_PATH)

    for row in doc.tables[0].rows:
        for cell in row:
            assert isinstance(cell, str)


def test_csv_raw_text_populated():
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(CSV_PATH)
    assert len(doc.raw_text) > 0


def test_csv_semantic_chunks():
    from omnidoc.loader.load import load_document

    doc = load_document(CSV_PATH)

    assert hasattr(doc, "chunks")
    assert len(doc.chunks) > 0


# ---------------------------------------------------------------------------
# Encoding edge cases
# ---------------------------------------------------------------------------


def test_csv_latin1_encoding():
    """Must not crash on latin-1 CSV files."""
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="wb") as f:
        f.write("name,value\nRen\xe9,caf\xe9\n".encode("latin-1"))
        path = f.name

    try:
        doc = SpreadsheetExtractor().extract(path)
        assert len(doc.tables[0].headers) == 2
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


def test_csv_missing_file():
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    with pytest.raises(FileNotFoundError):
        SpreadsheetExtractor().extract("/nonexistent/data.csv")


def test_csv_malformed_raises():
    """Completely binary garbage should raise ValueError, not crash silently."""
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode="wb") as f:
        f.write(b"\x00\x01\x02\x03\xff\xfe" * 100)
        path = f.name

    try:
        # May raise ValueError or return an empty doc — should NOT raise unhandled exception
        try:
            SpreadsheetExtractor().extract(path)
        except ValueError:
            pass  # Expected
    finally:
        os.unlink(path)
