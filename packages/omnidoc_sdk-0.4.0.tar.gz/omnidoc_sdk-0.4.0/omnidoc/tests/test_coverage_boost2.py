"""
Additional coverage tests targeting remaining gaps.
"""

import email
import email.mime.multipart
import email.mime.text
import email.mime.base
import importlib
import io
import logging
import os
import sys
import tarfile
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
from PIL import Image

DATA = Path(__file__).parent / "data"

# ---------------------------------------------------------------------------
# archive/extractor.py — TAR, 7z, ZIP path-traversal, ZIP oversized
# ---------------------------------------------------------------------------


def test_archive_tar_extraction(tmp_path):
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    # Create a real .tar file
    tar_path = str(tmp_path / "test.tar")
    with tarfile.open(tar_path, "w") as tf:
        content = b"hello tar content"
        info = tarfile.TarInfo(name="hello.txt")
        info.size = len(content)
        tf.addfile(info, io.BytesIO(content))

    result = ArchiveExtractor().extract(tar_path)
    assert result["type"] == "archive"
    assert len(result["files"]) == 1


def test_archive_tar_gz_extraction(tmp_path):
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    tar_path = str(tmp_path / "test.tar.gz")
    with tarfile.open(tar_path, "w:gz") as tf:
        content = b"compressed content"
        info = tarfile.TarInfo(name="file.txt")
        info.size = len(content)
        tf.addfile(info, io.BytesIO(content))

    result = ArchiveExtractor().extract(tar_path)
    assert result["type"] == "archive"


def test_archive_tar_path_traversal_skipped(tmp_path):
    """TAR member with path traversal is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    tar_path = str(tmp_path / "test.tar")
    with tarfile.open(tar_path, "w") as tf:
        content = b"malicious"
        info = tarfile.TarInfo(name="../../../etc/passwd")
        info.size = len(content)
        tf.addfile(info, io.BytesIO(content))

    result = ArchiveExtractor().extract(tar_path)
    # Path traversal member is skipped — no files extracted
    assert result["files"] == []


def test_archive_tar_oversized_member_skipped(tmp_path):
    """TAR member exceeding size limit is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor, _MAX_MEMBER_BYTES

    tar_path = str(tmp_path / "test.tar")
    # Create a valid tar with a normal file
    with tarfile.open(tar_path, "w") as tf:
        content = b"small"
        info = tarfile.TarInfo(name="normal.txt")
        info.size = len(content)
        tf.addfile(info, io.BytesIO(content))

    # Patch getmembers to return a member whose .size exceeds the limit
    oversized = tarfile.TarInfo(name="huge.bin")
    oversized.size = _MAX_MEMBER_BYTES + 1
    oversized.type = tarfile.REGTYPE

    with patch("tarfile.open") as mock_open:
        mock_tf = MagicMock()
        mock_tf.__enter__ = lambda s: mock_tf
        mock_tf.__exit__ = MagicMock(return_value=False)
        mock_tf.getmembers.return_value = [oversized]
        mock_open.return_value = mock_tf

        with patch("tarfile.is_tarfile", return_value=True):
            result = ArchiveExtractor().extract(tar_path)

    assert result["files"] == []


def test_archive_zip_path_traversal_skipped(tmp_path):
    """ZIP member with path traversal (outside dest) is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    zip_path = str(tmp_path / "test.zip")
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("safe_file.txt", "safe content")

    # We patch _extract_zip to simulate a path-traversal member
    def mock_zip(self, zip_path, dest):
        import pathlib

        dest_path = pathlib.Path(dest).resolve()
        # Simulate trying to extract a traversal path
        member_mock = MagicMock()
        member_mock.filename = "../../../etc/passwd"
        member_mock.file_size = 100
        member_mock.is_dir.return_value = False
        target = (dest_path / member_mock.filename).resolve()
        if not str(target).startswith(str(dest_path) + os.sep):
            logging.getLogger(__name__).warning(
                "Skipping path-traversal ZIP member: '%s'", member_mock.filename
            )
        return []

    with patch.object(ArchiveExtractor, "_extract_zip", mock_zip):
        result = ArchiveExtractor().extract(zip_path)
    assert result["files"] == []


def test_archive_zip_oversized_member_skipped(tmp_path):
    """ZIP member exceeding size limit is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor, _MAX_MEMBER_BYTES

    zip_path = str(tmp_path / "test.zip")
    # We'll mock the ZipFile infolist to have an oversized member
    with zipfile.ZipFile(zip_path, "w") as zf:
        zf.writestr("normal.txt", "content")

    oversized_member = MagicMock()
    oversized_member.filename = "huge.bin"
    oversized_member.file_size = _MAX_MEMBER_BYTES + 1
    oversized_member.is_dir.return_value = False

    normal_member = MagicMock()
    normal_member.filename = "ok.txt"
    normal_member.file_size = 100
    normal_member.is_dir.return_value = False

    tmp_dir = str(tmp_path / "dest")
    os.makedirs(tmp_dir)

    with patch("zipfile.ZipFile") as mock_zf_cls:
        mock_zf = MagicMock()
        mock_zf.__enter__ = lambda s: mock_zf
        mock_zf.__exit__ = MagicMock(return_value=False)
        mock_zf.infolist.return_value = [oversized_member, normal_member]
        mock_zf_cls.return_value = mock_zf

        def fake_extract(member, dest):
            pass

        mock_zf.extract = fake_extract

        with patch("zipfile.is_zipfile", return_value=True):
            result = ArchiveExtractor().extract(zip_path)

    # Oversized member is skipped
    assert result["type"] == "archive"


def test_archive_7z_extraction(tmp_path):
    """7z extraction via mocked py7zr (avoids API version issues)."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    sevenz_path = str(tmp_path / "test.7z")
    Path(sevenz_path).write_bytes(b"placeholder")

    mock_bio = MagicMock()
    mock_bio.read.return_value = b"hello content"

    with patch("py7zr.SevenZipFile") as mock_sz_cls:
        mock_sz = MagicMock()
        mock_sz.__enter__ = lambda s: mock_sz
        mock_sz.__exit__ = MagicMock(return_value=False)
        mock_sz.read.return_value = {"hello.txt": mock_bio}
        mock_sz_cls.return_value = mock_sz

        result = ArchiveExtractor().extract(sevenz_path)

    assert result["type"] == "archive"
    assert any("hello.txt" in f for f in result["files"])


def test_archive_7z_not_installed(tmp_path):
    """7z path when py7zr is not installed."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    sevenz_path = str(tmp_path / "test.7z")
    # Create a dummy file
    Path(sevenz_path).write_bytes(b"fake7z")

    with patch.dict(sys.modules, {"py7zr": None}):
        with pytest.raises(ImportError, match="7-Zip"):
            ArchiveExtractor().extract(sevenz_path)


def test_archive_7z_path_traversal_skipped(tmp_path):
    """7z member with path traversal is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    sevenz_path = str(tmp_path / "test.7z")
    Path(sevenz_path).write_bytes(b"placeholder")

    mock_bio = MagicMock()
    mock_bio.read.return_value = b"malicious"

    with patch("py7zr.SevenZipFile") as mock_sz_cls:
        mock_sz = MagicMock()
        mock_sz.__enter__ = lambda s: mock_sz
        mock_sz.__exit__ = MagicMock(return_value=False)
        mock_sz.read.return_value = {"../etc/passwd": mock_bio}
        mock_sz_cls.return_value = mock_sz

        result = ArchiveExtractor().extract(sevenz_path)

    assert result["files"] == []


def test_archive_7z_oversized_member_skipped(tmp_path):
    """7z member that's too big is skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor, _MAX_MEMBER_BYTES

    sevenz_path = str(tmp_path / "test.7z")
    Path(sevenz_path).write_bytes(b"placeholder")

    mock_bio = MagicMock()
    mock_bio.read.return_value = b"x" * (_MAX_MEMBER_BYTES + 1)

    with patch("py7zr.SevenZipFile") as mock_sz_cls:
        mock_sz = MagicMock()
        mock_sz.__enter__ = lambda s: mock_sz
        mock_sz.__exit__ = MagicMock(return_value=False)
        mock_sz.read.return_value = {"bigfile.bin": mock_bio}
        mock_sz_cls.return_value = mock_sz

        result = ArchiveExtractor().extract(sevenz_path)

    assert result["files"] == []


def test_archive_invalid_zip(tmp_path):
    """File that is not a valid ZIP raises ValueError."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    bad_path = str(tmp_path / "not.zip")
    Path(bad_path).write_bytes(b"not a zip file at all")

    with pytest.raises(Exception):
        ArchiveExtractor().extract(bad_path)


def test_archive_not_found():
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    with pytest.raises(FileNotFoundError):
        ArchiveExtractor().extract("/no/such/archive.zip")


def test_archive_tar_member_extract_fails(tmp_path):
    """TAR member extraction failure is logged and skipped."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    tar_path = str(tmp_path / "test.tar")
    with tarfile.open(tar_path, "w") as tf:
        content = b"hello"
        info = tarfile.TarInfo(name="file.txt")
        info.size = len(content)
        tf.addfile(info, io.BytesIO(content))

    # Patch tf.extract to raise
    orig_open = tarfile.open

    def patched_open(*args, **kwargs):
        tf = orig_open(*args, **kwargs)

        def fail_extract(member, path, **kwargs):
            raise RuntimeError("simulated extract error")

        tf.extract = fail_extract
        return tf

    with patch("tarfile.open", patched_open):
        result = ArchiveExtractor().extract(tar_path)

    assert result["type"] == "archive"


# ---------------------------------------------------------------------------
# code/extractor.py — remaining paths
# ---------------------------------------------------------------------------


def test_code_extractor_pygments_exception(tmp_path):
    """When pygments lexer lookup fails, coverage falls to except block."""
    py_file = tmp_path / "script.py"
    py_file.write_text("def hello():\n    pass\n")

    # Make pygments raise so the except block is hit
    with patch("pygments.lex", side_effect=Exception("pygments error")):
        from omnidoc.extractors.code.extractor import CodeExtractor

        doc = CodeExtractor().extract(str(py_file))
    assert doc is not None


def test_code_extractor_javascript(tmp_path):
    """JavaScript/TypeScript path in _split_into_blocks."""
    js_file = tmp_path / "app.js"
    js_file.write_text(
        "function greet(name) {\n  return 'Hello ' + name;\n}\n\nclass Foo {}\n"
    )

    from omnidoc.extractors.code.extractor import CodeExtractor

    doc = CodeExtractor().extract(str(js_file))
    assert doc is not None


def test_code_extractor_java(tmp_path):
    """Java path in _split_into_blocks."""
    java_file = tmp_path / "Main.java"
    java_file.write_text(
        "public class Main {\n"
        "    public static void main(String[] args) {\n"
        '        System.out.println("Hello");\n'
        "    }\n"
        "}\n"
    )

    from omnidoc.extractors.code.extractor import CodeExtractor

    doc = CodeExtractor().extract(str(java_file))
    assert doc is not None


def test_code_extractor_no_split(tmp_path):
    """split_blocks=False disables block splitting."""
    py_file = tmp_path / "script.py"
    py_file.write_text("x = 1\ny = 2\n")

    from omnidoc.extractors.code.extractor import CodeExtractor

    doc = CodeExtractor(split_blocks=False).extract(str(py_file))
    assert len(doc.sections) == 1


def test_code_extractor_no_match_blocks(tmp_path):
    """Python file with no def/class produces single section."""
    py_file = tmp_path / "script.py"
    py_file.write_text("x = 1\ny = 2\n")

    from omnidoc.extractors.code.extractor import CodeExtractor

    doc = CodeExtractor(split_blocks=True).extract(str(py_file))
    # No def/class → fallback to single section
    assert len(doc.sections) >= 1


# ---------------------------------------------------------------------------
# ebook/epub_extractor.py — ImportError + no-content paths
# ---------------------------------------------------------------------------


def test_epub_ebooklib_not_installed(tmp_path):
    f = tmp_path / "book.epub"
    f.write_bytes(b"fake epub")

    with patch.dict(sys.modules, {"ebooklib": None, "ebooklib.epub": None}):
        from omnidoc.extractors.ebook.epub_extractor import EPUBExtractor

        importlib.reload(
            importlib.import_module("omnidoc.extractors.ebook.epub_extractor")
        )
        with pytest.raises((ImportError, Exception)):
            EPUBExtractor().extract(str(f))


def test_epub_bs4_not_installed(tmp_path):
    f = tmp_path / "book.epub"
    f.write_bytes(b"fake epub")

    mock_ebooklib = MagicMock()
    mock_epub = MagicMock()
    mock_ebooklib.epub = mock_epub
    mock_ebooklib.ITEM_DOCUMENT = 9  # typical value

    # Make epub.read_epub return a book
    mock_book = MagicMock()
    mock_book.title = "Test"
    mock_book.get_metadata.return_value = []
    mock_book.get_items_of_type.return_value = []
    mock_epub.read_epub.return_value = mock_book

    with patch.dict(
        sys.modules,
        {
            "ebooklib": mock_ebooklib,
            "ebooklib.epub": mock_epub,
            "bs4": None,
            "beautifulsoup4": None,
        },
    ):
        from omnidoc.extractors.ebook import epub_extractor as epub_mod

        importlib.reload(epub_mod)
        with pytest.raises((ImportError, ValueError, Exception)):
            epub_mod.EPUBExtractor().extract(str(f))


def _make_epub_mocks(items_data, title="", authors=None):
    """Helper: build ebooklib+epub mocks for epub tests."""
    mock_ebooklib = MagicMock()
    mock_ebooklib.ITEM_DOCUMENT = 9

    mock_items = []
    for content_bytes in items_data:
        item = MagicMock()
        item.get_content.return_value = content_bytes
        mock_items.append(item)

    mock_book = MagicMock()
    mock_book.title = title
    mock_book.get_metadata.return_value = [(a, {}) for a in (authors or [])]
    mock_book.get_items_of_type.return_value = mock_items

    # Make epub.read_epub return mock_book via the ebooklib mock's epub attr
    mock_ebooklib.epub.read_epub.return_value = mock_book

    return mock_ebooklib


def test_epub_no_sections_raises(tmp_path):
    """EPUB with no readable content raises ValueError."""
    f = tmp_path / "book.epub"
    f.write_bytes(b"placeholder")
    mock_ebooklib = _make_epub_mocks([])

    with patch.dict(sys.modules, {"ebooklib": mock_ebooklib}):
        from omnidoc.extractors.ebook import epub_extractor as epub_mod

        importlib.reload(epub_mod)
        with pytest.raises(ValueError, match="no readable content"):
            epub_mod.EPUBExtractor().extract(str(f))


def test_epub_item_no_content(tmp_path):
    """EPUB item with no content is skipped; real content item succeeds."""
    f = tmp_path / "book.epub"
    f.write_bytes(b"placeholder")
    mock_ebooklib = _make_epub_mocks(
        [b"", b"<html><body><p>Hello world</p></body></html>"],
        title="Test Book",
        authors=["Author Name"],
    )

    with patch.dict(sys.modules, {"ebooklib": mock_ebooklib}):
        from omnidoc.extractors.ebook import epub_extractor as epub_mod

        importlib.reload(epub_mod)
        doc = epub_mod.EPUBExtractor().extract(str(f))
    assert "Hello world" in doc.raw_text
    assert doc.metadata.get("title") == "Test Book"
    assert "authors" in doc.metadata


def test_epub_item_with_script_stripped(tmp_path):
    """Scripts and styles in EPUB items are stripped."""
    f = tmp_path / "book.epub"
    f.write_bytes(b"placeholder")
    mock_ebooklib = _make_epub_mocks(
        [
            b"<html><head><style>body{color:red}</style></head>"
            b"<body><script>alert('x')</script><p>Real content</p></body></html>"
        ]
    )

    with patch.dict(sys.modules, {"ebooklib": mock_ebooklib}):
        from omnidoc.extractors.ebook import epub_extractor as epub_mod

        importlib.reload(epub_mod)
        doc = epub_mod.EPUBExtractor().extract(str(f))
    assert "Real content" in doc.raw_text
    assert "alert" not in doc.raw_text


def test_epub_item_empty_text_after_decompose(tmp_path):
    """EPUB item that is all scripts → empty text → skipped."""
    f = tmp_path / "book.epub"
    f.write_bytes(b"placeholder")
    mock_ebooklib = _make_epub_mocks(
        [
            b"<script>var x=1;</script>",
            b"<p>Chapter 1</p>",
        ]
    )

    with patch.dict(sys.modules, {"ebooklib": mock_ebooklib}):
        from omnidoc.extractors.ebook import epub_extractor as epub_mod

        importlib.reload(epub_mod)
        doc = epub_mod.EPUBExtractor().extract(str(f))
    assert "Chapter 1" in doc.raw_text


# ---------------------------------------------------------------------------
# eml_extractor.py — multipart HTML, attachment, _decode_part exception
# ---------------------------------------------------------------------------


def test_eml_multipart_html_part(tmp_path):
    """Multipart EML with text/html part."""
    msg = email.mime.multipart.MIMEMultipart("alternative")
    msg["Subject"] = "HTML Test"
    msg["From"] = "sender@example.com"
    msg["To"] = "recv@example.com"
    msg["Date"] = "Mon, 01 Jan 2024 00:00:00 +0000"

    html_part = email.mime.text.MIMEText("<p>Hello HTML world</p>", "html")
    msg.attach(html_part)

    eml_path = tmp_path / "html_email.eml"
    eml_path.write_bytes(msg.as_bytes())

    from omnidoc.extractors.email.eml_extractor import EMLExtractor

    doc = EMLExtractor().extract(str(eml_path))
    assert doc is not None
    # HTML stripped to plain text
    assert any("Hello HTML world" in s.text for s in doc.sections)


def test_eml_multipart_with_attachment(tmp_path):
    """Multipart EML with an attachment — attachments listed in metadata."""
    msg = email.mime.multipart.MIMEMultipart()
    msg["Subject"] = "With Attachment"
    msg["From"] = "a@b.com"
    msg["To"] = "c@d.com"
    msg["Date"] = "Mon, 01 Jan 2024 00:00:00 +0000"

    body = email.mime.text.MIMEText("Plain text body", "plain")
    msg.attach(body)

    # Attachment part
    att = email.mime.base.MIMEBase("application", "octet-stream")
    att.set_payload(b"binary content")
    att.add_header("Content-Disposition", "attachment", filename="report.pdf")
    msg.attach(att)

    eml_path = tmp_path / "with_attach.eml"
    eml_path.write_bytes(msg.as_bytes())

    from omnidoc.extractors.email.eml_extractor import EMLExtractor

    doc = EMLExtractor().extract(str(eml_path))
    assert "attachments" in doc.metadata
    assert "report.pdf" in doc.metadata["attachments"]


def test_eml_decode_part_exception():
    """_decode_part returns '' when an exception occurs."""
    from omnidoc.extractors.email.eml_extractor import _decode_part

    mock_part = MagicMock()
    mock_part.get_payload.side_effect = RuntimeError("decode error")
    result = _decode_part(mock_part)
    assert result == ""


def test_eml_decode_part_empty_payload():
    """_decode_part returns '' when payload is None/empty."""
    from omnidoc.extractors.email.eml_extractor import _decode_part

    mock_part = MagicMock()
    mock_part.get_payload.return_value = None
    result = _decode_part(mock_part)
    assert result == ""


def test_eml_multipart_plain_text_part(tmp_path):
    """Multipart EML with text/plain part — no HTML stripping needed."""
    msg = email.mime.multipart.MIMEMultipart()
    msg["Subject"] = "Plain Test"
    msg["From"] = "x@y.com"
    msg["To"] = "a@b.com"

    part = email.mime.text.MIMEText("Plain text here", "plain")
    msg.attach(part)

    eml_path = tmp_path / "plain_multi.eml"
    eml_path.write_bytes(msg.as_bytes())

    from omnidoc.extractors.email.eml_extractor import EMLExtractor

    doc = EMLExtractor().extract(str(eml_path))
    assert any("Plain text here" in s.text for s in doc.sections)


# ---------------------------------------------------------------------------
# image/extractor.py — UnidentifiedImageError, non-RGB mode, timeout, exception
# ---------------------------------------------------------------------------


def test_image_unidentified_format(tmp_path):
    """File with garbage bytes raises ValueError."""
    bad_image = tmp_path / "garbage.png"
    bad_image.write_bytes(b"\x00\x01\x02\x03garbage data not an image")

    from omnidoc.extractors.image.extractor import ImageExtractor

    with pytest.raises(ValueError, match="unrecogni"):
        ImageExtractor().extract(str(bad_image))


def test_image_rgba_converted_to_rgb(tmp_path):
    """Image in RGBA mode is converted to RGB before OCR."""
    img = Image.new("RGBA", (50, 50), (255, 0, 0, 128))
    img_path = tmp_path / "rgba.png"
    img.save(str(img_path))

    with patch("pytesseract.image_to_string", return_value="text from rgba"):
        from omnidoc.extractors.image.extractor import ImageExtractor

        doc = ImageExtractor(timeout=0).extract(str(img_path))
    assert doc.raw_text == "text from rgba"


def test_image_ocr_timeout(tmp_path):
    """TimeoutError in OCR returns empty text."""
    img = Image.new("RGB", (50, 50))
    img_path = tmp_path / "test.png"
    img.save(str(img_path))

    with patch("pytesseract.image_to_string", side_effect=TimeoutError("timed out")):
        from omnidoc.extractors.image.extractor import ImageExtractor

        doc = ImageExtractor(timeout=30).extract(str(img_path))
    assert doc.raw_text == ""


def test_image_ocr_generic_exception(tmp_path):
    """Generic OCR exception returns empty text."""
    img = Image.new("RGB", (50, 50))
    img_path = tmp_path / "test.png"
    img.save(str(img_path))

    with patch("pytesseract.image_to_string", side_effect=RuntimeError("ocr failed")):
        from omnidoc.extractors.image.extractor import ImageExtractor

        doc = ImageExtractor(timeout=0).extract(str(img_path))
    assert doc.raw_text == ""


def test_image_open_exception(tmp_path):
    """Generic exception when opening image raises ValueError."""
    img_path = tmp_path / "bad.jpg"
    img_path.write_bytes(b"not an image")

    from omnidoc.extractors.image.extractor import ImageExtractor

    with pytest.raises(ValueError):
        ImageExtractor().extract(str(img_path))


# ---------------------------------------------------------------------------
# rtf_extractor.py — ImportError, rtf_to_text fail, empty, encoding exception
# ---------------------------------------------------------------------------


def test_rtf_striprtf_not_installed(tmp_path):
    """striprtf ImportError raises ImportError."""
    f = tmp_path / "doc.rtf"
    f.write_text("{\\rtf1 Hello}")

    with patch.dict(sys.modules, {"striprtf": None, "striprtf.striprtf": None}):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        with pytest.raises((ImportError, Exception)):
            RTFExtractor().extract(str(f))


def test_rtf_to_text_raises(tmp_path):
    """rtf_to_text raising exception raises ValueError."""
    f = tmp_path / "doc.rtf"
    f.write_text("{\\rtf1 content}")

    with patch("striprtf.striprtf.rtf_to_text", side_effect=Exception("parse error")):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        with pytest.raises(ValueError, match="failed to parse"):
            RTFExtractor().extract(str(f))


def test_rtf_empty_result(tmp_path):
    """RTF that converts to empty text gets fallback section."""
    f = tmp_path / "doc.rtf"
    f.write_text("{\\rtf1}")

    with patch("striprtf.striprtf.rtf_to_text", return_value=""):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        doc = RTFExtractor().extract(str(f))
    assert len(doc.sections) == 1
    assert doc.sections[0].text == ""


def test_rtf_encoding_exception_in_read(tmp_path):
    """File with latin-1 bytes (non-utf8) still works via encoding fallback."""
    f = tmp_path / "doc.rtf"
    # Write bytes containing 0xe7 (ç in latin-1) — not valid UTF-8 sequence
    f.write_bytes(b"{\\rtf1 Fran\xe7ois}")

    with patch("striprtf.striprtf.rtf_to_text", return_value="François"):
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor

        doc = RTFExtractor().extract(str(f))
    assert doc is not None


# ---------------------------------------------------------------------------
# media/extractor.py — mock whisper for all paths
# ---------------------------------------------------------------------------


def test_media_extractor_with_language(tmp_path):
    """MediaExtractor with language kwarg passes it to transcribe."""
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {
        "text": "Hello world",
        "segments": [{"text": "Hello world"}],
        "language": "en",
    }

    with patch.dict(sys.modules, {"whisper": mock_whisper}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        extractor = media_mod.MediaExtractor(model="base", language="en")
        doc = extractor.extract(str(mp3_path))

    assert "Hello world" in doc.raw_text
    assert doc.metadata.get("language") == "en"


def test_media_extractor_no_segments(tmp_path):
    """MediaExtractor with no segments falls back to full_text."""
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {
        "text": "Full transcript",
        "segments": [],
        "language": "",
    }

    with patch.dict(sys.modules, {"whisper": mock_whisper}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        doc = media_mod.MediaExtractor().extract(str(mp3_path))

    assert "Full transcript" in doc.raw_text


def test_media_extractor_empty_result(tmp_path):
    """MediaExtractor with empty text and no segments gets fallback section."""
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {"text": "", "segments": [], "language": ""}

    with patch.dict(sys.modules, {"whisper": mock_whisper}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        doc = media_mod.MediaExtractor().extract(str(mp3_path))

    assert len(doc.sections) == 1
    assert doc.sections[0].text == ""


def test_media_extractor_with_device(tmp_path):
    """MediaExtractor with device kwarg passes it to load_model."""
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {
        "text": "text",
        "segments": [],
        "language": "",
    }

    with patch.dict(sys.modules, {"whisper": mock_whisper}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        extractor = media_mod.MediaExtractor(device="cpu")
        extractor.extract(str(mp3_path))

    mock_whisper.load_model.assert_called_once_with("base", device="cpu")


def test_media_extractor_model_cached(tmp_path):
    """MediaExtractor caches loaded model on second call."""
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {
        "text": "text",
        "segments": [],
        "language": "",
    }

    with patch.dict(sys.modules, {"whisper": mock_whisper}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        extractor = media_mod.MediaExtractor()
        extractor.extract(str(mp3_path))
        extractor.extract(str(mp3_path))  # second call uses cached model

    # load_model called only once
    assert mock_whisper.load_model.call_count == 1


def test_media_extractor_whisper_not_installed(tmp_path):
    mp3_path = tmp_path / "audio.mp3"
    mp3_path.write_bytes(b"fake mp3")

    with patch.dict(sys.modules, {"whisper": None}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        with pytest.raises((ImportError, Exception)):
            media_mod.MediaExtractor().extract(str(mp3_path))


def test_media_extractor_avi_ffmpeg_conversion(tmp_path):
    """AVI extension triggers ffmpeg conversion path."""
    avi_path = tmp_path / "video.avi"
    avi_path.write_bytes(b"fake avi")

    mock_ffmpeg = MagicMock()
    mock_ffmpeg_input = MagicMock()
    mock_ffmpeg_output = MagicMock()

    mock_ffmpeg.input.return_value = mock_ffmpeg_input
    mock_ffmpeg_input.output.return_value = mock_ffmpeg_output
    mock_ffmpeg_output.overwrite_output.return_value = mock_ffmpeg_output
    mock_ffmpeg_output.run = MagicMock()

    # Create a fake temp wav path
    fake_wav = str(tmp_path / "fake.wav")
    Path(fake_wav).write_bytes(b"fake wav")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {
        "text": "transcribed",
        "segments": [],
        "language": "",
    }

    with patch.dict(sys.modules, {"whisper": mock_whisper, "ffmpeg": mock_ffmpeg}):
        with patch("tempfile.NamedTemporaryFile") as mock_tmp:
            mock_tmp_obj = MagicMock()
            mock_tmp_obj.name = fake_wav
            mock_tmp.return_value = mock_tmp_obj

            from omnidoc.extractors.media import extractor as media_mod

            importlib.reload(media_mod)
            doc = media_mod.MediaExtractor().extract(str(avi_path))

    assert doc is not None


def test_media_extractor_avi_ffmpeg_fails(tmp_path):
    """AVI extraction falls back to raw path when ffmpeg fails."""
    avi_path = tmp_path / "video.avi"
    avi_path.write_bytes(b"fake avi")

    mock_ffmpeg = MagicMock()
    mock_ffmpeg.input.side_effect = Exception("ffmpeg not found")

    mock_whisper = MagicMock()
    mock_model = MagicMock()
    mock_whisper.load_model.return_value = mock_model
    mock_model.transcribe.return_value = {"text": "raw", "segments": [], "language": ""}

    with patch.dict(sys.modules, {"whisper": mock_whisper, "ffmpeg": mock_ffmpeg}):
        from omnidoc.extractors.media import extractor as media_mod

        importlib.reload(media_mod)
        doc = media_mod.MediaExtractor().extract(str(avi_path))

    assert doc is not None


# ---------------------------------------------------------------------------
# pptx.py — title shape correctly assigned + slide_lines path
# ---------------------------------------------------------------------------


def test_pptx_title_shape_assigned(tmp_path):
    """PPTX slide where one shape IS the title shape."""
    try:
        from pptx import Presentation
    except ImportError:
        pytest.skip("python-pptx not installed")

    prs = Presentation()
    slide_layout = prs.slide_layouts[0]  # Title Slide layout
    slide = prs.slides.add_slide(slide_layout)

    # Set title and content
    if slide.shapes.title:
        slide.shapes.title.text = "Slide Title Text"

    pptx_path = str(tmp_path / "titled.pptx")
    prs.save(pptx_path)

    from omnidoc.extractors.office.pptx import PPTXExtractor

    doc = PPTXExtractor().extract(pptx_path)
    assert any("Slide Title Text" in s.text for s in doc.sections)


# ---------------------------------------------------------------------------
# spreadsheet.py — exception from _read, xlsx, TSV
# ---------------------------------------------------------------------------


def test_spreadsheet_read_exception(tmp_path):
    """_read raises → ValueError wraps it."""
    bad_csv = tmp_path / "bad.csv"
    bad_csv.write_text("col1,col2\nval1,val2")

    with patch("pandas.read_csv", side_effect=Exception("parse error")):
        from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

        with pytest.raises(ValueError, match="Failed to parse"):
            SpreadsheetExtractor().extract(str(bad_csv))


def test_spreadsheet_xlsx(tmp_path):
    """Excel .xlsx file reading."""
    import pandas as pd

    xlsx_path = tmp_path / "data.xlsx"
    df = pd.DataFrame({"A": [1, 2], "B": [3, 4]})
    df.to_excel(str(xlsx_path), index=False)

    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(str(xlsx_path))
    assert "A" in doc.tables[0].headers or "A" in doc.raw_text


def test_spreadsheet_tsv(tmp_path):
    """TSV file reading."""
    tsv_path = tmp_path / "data.tsv"
    tsv_path.write_text("col1\tcol2\nval1\tval2\n")

    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(str(tsv_path))
    assert "col1" in doc.raw_text or "col1" in doc.tables[0].headers


# ---------------------------------------------------------------------------
# openoffice/extractor.py — ODT, ODS, ODP
# ---------------------------------------------------------------------------


def test_openoffice_odfpy_not_installed(tmp_path):
    """odfpy ImportError raises ImportError."""
    f = tmp_path / "doc.odt"
    f.write_bytes(b"fake odt")

    with patch.dict(sys.modules, {"odf": None, "odf.opendocument": None}):
        from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

        with pytest.raises((ImportError, Exception)):
            OpenDocumentExtractor().extract(str(f))


def test_openoffice_odt_extraction(tmp_path):
    """Extract an ODT file with real odfpy."""
    from odf.opendocument import OpenDocumentText
    from odf.text import P

    doc_odf = OpenDocumentText()
    p = P(text="Hello from ODT")
    doc_odf.text.addElement(p)

    odt_path = str(tmp_path / "test.odt")
    doc_odf.save(odt_path)

    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    doc = OpenDocumentExtractor().extract(odt_path)
    assert doc is not None
    assert "Hello from ODT" in doc.raw_text


def test_openoffice_odt_with_table(tmp_path):
    """ODT with a table."""
    from odf.opendocument import OpenDocumentText
    from odf.text import P
    from odf.table import Table, TableRow, TableCell

    doc_odf = OpenDocumentText()
    tbl = Table()
    row = TableRow()
    cell = TableCell()
    cell.addElement(P(text="cell content"))
    row.addElement(cell)
    tbl.addElement(row)
    doc_odf.text.addElement(tbl)

    odt_path = str(tmp_path / "with_table.odt")
    doc_odf.save(odt_path)

    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    doc = OpenDocumentExtractor().extract(odt_path)
    assert doc is not None


def test_openoffice_ods_extraction(tmp_path):
    """Extract an ODS file with header + data rows."""
    from odf.opendocument import OpenDocumentSpreadsheet
    from odf.table import Table, TableRow, TableCell
    from odf.text import P

    doc_odf = OpenDocumentSpreadsheet()
    tbl = Table(name="Sheet1")
    # Header row
    hrow = TableRow()
    hcell = TableCell()
    hcell.addElement(P(text="ColA"))
    hrow.addElement(hcell)
    tbl.addElement(hrow)
    # Data row
    drow = TableRow()
    dcell = TableCell()
    dcell.addElement(P(text="val1"))
    drow.addElement(dcell)
    tbl.addElement(drow)
    doc_odf.spreadsheet.addElement(tbl)

    ods_path = str(tmp_path / "test.ods")
    doc_odf.save(ods_path)

    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    doc = OpenDocumentExtractor().extract(ods_path)
    assert doc is not None
    assert "ColA" in doc.raw_text


def test_openoffice_odp_extraction(tmp_path):
    """Extract an ODP file with actual slide content."""
    from odf.opendocument import OpenDocumentPresentation
    from odf.draw import Page, Frame, TextBox
    from odf.text import P

    doc_odf = OpenDocumentPresentation()
    slide = Page(masterpagename="Default")
    frame = Frame(width="20cm", height="10cm", x="0cm", y="0cm")
    tb = TextBox()
    tb.addElement(P(text="Hello from slide"))
    frame.addElement(tb)
    slide.addElement(frame)
    doc_odf.presentation.addElement(slide)

    odp_path = str(tmp_path / "test.odp")
    doc_odf.save(odp_path)

    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    doc = OpenDocumentExtractor().extract(odp_path)
    assert doc is not None
    assert any("Hello from slide" in s.text for s in doc.sections)


# ---------------------------------------------------------------------------
# yaml_extractor.py — encoding exception in loop
# ---------------------------------------------------------------------------


def test_yaml_encoding_loop_exception(tmp_path):
    """YAML file with latin-1 encoding (non-utf8 bytes) still parses."""
    yaml_path = tmp_path / "config.yaml"
    # Write bytes that are valid latin-1 but NOT valid utf-8
    yaml_path.write_bytes(b"name: Fran\xe7ois\n")

    from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

    doc = YAMLExtractor().extract(str(yaml_path))
    assert doc is not None


# ---------------------------------------------------------------------------
# html_extractor.py — no block elements → fallback, encoding exception
# ---------------------------------------------------------------------------


def test_html_no_block_elements(tmp_path):
    """HTML with no block-level elements falls back to get_text."""
    html = "<html><body><span>Just a span</span></body></html>"
    html_path = tmp_path / "simple.html"
    html_path.write_text(html)

    from omnidoc.extractors.web.html_extractor import HTMLExtractor

    doc = HTMLExtractor().extract(str(html_path))
    assert "Just a span" in doc.raw_text


def test_html_encoding_exception_in_read(tmp_path):
    """HTML file with latin-1 encoding (non-utf8) still reads."""
    html_path = tmp_path / "latin.html"
    # Write bytes that are valid latin-1 but not utf-8
    html_path.write_bytes(b"<html><body><p>Fran\xe7ois</p></body></html>")

    from omnidoc.extractors.web.html_extractor import HTMLExtractor

    doc = HTMLExtractor().extract(str(html_path))
    assert doc is not None


def test_html_with_title(tmp_path):
    """HTML with a title tag — metadata has 'title' key."""
    html = "<html><head><title>My Page Title</title></head><body><p>Content</p></body></html>"
    html_path = tmp_path / "titled.html"
    html_path.write_text(html)

    from omnidoc.extractors.web.html_extractor import HTMLExtractor

    doc = HTMLExtractor().extract(str(html_path))
    assert doc.metadata.get("title") == "My Page Title"


# ---------------------------------------------------------------------------
# layout/utils.py — line 21: all-non-alnum text that passes earlier filters
# ---------------------------------------------------------------------------


def test_text_blocks_only_long_all_nonalnum():
    """Text with 4+ all-non-alnum chars → dropped by line 21."""
    from omnidoc.layout.utils import text_blocks_only

    # "----" has 4 non-alnum chars, not in the specific garbage set
    block = SimpleNamespace(text="----")
    result = text_blocks_only([block])
    assert result == []


def test_text_blocks_only_short_with_alnum_passes():
    """Short text with an alnum char passes all filters."""
    from omnidoc.layout.utils import text_blocks_only

    block = SimpleNamespace(text="A1")
    result = text_blocks_only([block])
    assert block in result


def test_text_blocks_only_long_all_nonalnum_multichar():
    """5 dashes → all non-alnum, length > 3 → caught by line 21."""
    from omnidoc.layout.utils import text_blocks_only

    block = SimpleNamespace(text="-----")
    result = text_blocks_only([block])
    assert result == []


# ---------------------------------------------------------------------------
# ocr_tables.py — small contour skip and exception in contour loop
# ---------------------------------------------------------------------------


def test_extract_ocr_tables_real_image_no_contours(tmp_path):
    """Plain white image has no table-like contours → returns []."""
    from omnidoc.pdf.ocr_tables import extract_ocr_tables

    img = Image.new("RGB", (200, 200), color=(255, 255, 255))
    result = extract_ocr_tables(img)
    assert isinstance(result, list)


def test_extract_ocr_tables_contour_exception_handled():
    """Exception in contour loop is caught → warning logged, continues."""
    from omnidoc.pdf.ocr_tables import extract_ocr_tables

    img = Image.new("RGB", (200, 200), color=(255, 255, 255))

    # Inject a fake contour that will cause cv2.boundingRect to raise
    import cv2

    fake_contour = MagicMock()

    orig_boundingRect = cv2.boundingRect

    call_count = [0]

    def fake_findContours(*args, **kwargs):
        # Return one contour
        return [fake_contour], None

    def fake_boundingRect(cnt):
        call_count[0] += 1
        if cnt is fake_contour:
            raise RuntimeError("simulated boundingRect error")
        return orig_boundingRect(cnt)

    with (
        patch("cv2.findContours", fake_findContours),
        patch("cv2.boundingRect", fake_boundingRect),
    ):
        result = extract_ocr_tables(img)

    assert isinstance(result, list)


def test_extract_ocr_tables_small_contour_and_large(tmp_path):
    """Mix of small and large contours: small skipped, large processed."""
    from omnidoc.pdf.ocr_tables import extract_ocr_tables
    import numpy as np

    img = Image.new("RGB", (400, 300), color=(255, 255, 255))

    # One tiny contour (area < _MIN_TABLE_AREA) and one large contour
    small_w, small_h = 5, 5  # area = 25 < 500
    large_w, large_h = 100, 50  # area = 5000 > 500

    small_cnt = np.array(
        [[[0, 0]], [[small_w, 0]], [[small_w, small_h]], [[0, small_h]]], dtype=np.int32
    )
    large_cnt = np.array(
        [
            [[50, 50]],
            [[50 + large_w, 50]],
            [[50 + large_w, 50 + large_h]],
            [[50, 50 + large_h]],
        ],
        dtype=np.int32,
    )

    def fake_findContours(*args, **kwargs):
        return [small_cnt, large_cnt], None

    with (
        patch("cv2.findContours", fake_findContours),
        patch("pytesseract.image_to_string", return_value="row1\nrow2"),
    ):
        result = extract_ocr_tables(img)

    # Small contour is skipped, large produces lines
    assert isinstance(result, list)


# ---------------------------------------------------------------------------
# loader/load.py — remaining dispatch paths
# ---------------------------------------------------------------------------


def test_load_document_yaml(tmp_path):
    from omnidoc.loader.load import load_document

    yaml_path = tmp_path / "config.yaml"
    yaml_path.write_text("key: value\n")
    doc = load_document(str(yaml_path))
    assert doc is not None


def test_load_document_json(tmp_path):
    from omnidoc.loader.load import load_document

    json_path = tmp_path / "data.json"
    json_path.write_text('{"key": "value"}')
    doc = load_document(str(json_path))
    assert doc is not None


def test_load_document_xml(tmp_path):
    from omnidoc.loader.load import load_document

    xml_path = tmp_path / "data.xml"
    xml_path.write_text("<root><item>hello</item></root>")
    doc = load_document(str(xml_path))
    assert doc is not None


def test_load_document_html(tmp_path):
    from omnidoc.loader.load import load_document

    html_path = tmp_path / "page.html"
    html_path.write_text("<html><body><p>Hello</p></body></html>")
    doc = load_document(str(html_path))
    assert doc is not None


def test_load_document_rtf(tmp_path):
    from omnidoc.loader.load import load_document

    rtf_path = tmp_path / "doc.rtf"
    rtf_path.write_text("{\\rtf1 Hello world}")
    with patch("striprtf.striprtf.rtf_to_text", return_value="Hello world"):
        doc = load_document(str(rtf_path))
    assert doc is not None


def test_load_document_md(tmp_path):
    from omnidoc.loader.load import load_document

    md_path = tmp_path / "readme.md"
    md_path.write_text("# Heading\nContent here\n")
    doc = load_document(str(md_path))
    assert "Heading" in doc.raw_text


def test_load_document_ipynb(tmp_path):
    import nbformat

    nb = nbformat.v4.new_notebook()
    nb.cells.append(nbformat.v4.new_markdown_cell("# Title"))
    nb.cells.append(nbformat.v4.new_code_cell("x = 1"))

    ipynb_path = tmp_path / "notebook.ipynb"
    with open(str(ipynb_path), "w") as f:
        nbformat.write(nb, f)

    from omnidoc.loader.load import load_document

    doc = load_document(str(ipynb_path))
    assert doc is not None


# ---------------------------------------------------------------------------
# config.py — remaining env var paths
# ---------------------------------------------------------------------------


def test_config_env_bool_false(monkeypatch):
    monkeypatch.setenv("OMNIDOC_ENABLE_PII_MASKING", "false")
    from omnidoc.config import OmnidocConfig

    cfg = OmnidocConfig()
    assert cfg.enable_pii_masking is False


def test_config_env_str(monkeypatch):
    monkeypatch.setenv("OMNIDOC_AWS_REGION", "eu-west-1")
    from omnidoc.config import OmnidocConfig

    cfg = OmnidocConfig()
    assert cfg.aws_region == "eu-west-1"


# ---------------------------------------------------------------------------
# pdf/ocr_tables.py — empty lines in a large contour
# ---------------------------------------------------------------------------


def test_extract_ocr_tables_large_contour_empty_ocr():
    """Large contour where OCR returns no lines → nothing appended."""
    from omnidoc.pdf.ocr_tables import extract_ocr_tables
    import numpy as np

    img = Image.new("RGB", (400, 300), color=(255, 255, 255))

    large_w, large_h = 100, 50
    large_cnt = np.array(
        [
            [[50, 50]],
            [[50 + large_w, 50]],
            [[50 + large_w, 50 + large_h]],
            [[50, 50 + large_h]],
        ],
        dtype=np.int32,
    )

    def fake_findContours(*args, **kwargs):
        return [large_cnt], None

    with (
        patch("cv2.findContours", fake_findContours),
        patch("pytesseract.image_to_string", return_value=""),
    ):
        result = extract_ocr_tables(img)

    assert result == []


# ---------------------------------------------------------------------------
# Misc remaining lines
# ---------------------------------------------------------------------------


def test_pptx_extractor_title_shape_no_titleshape(tmp_path):
    """PPTX where title_shape is None (slide without title placeholder)."""
    try:
        from pptx import Presentation
    except ImportError:
        pytest.skip("python-pptx not installed")

    prs = Presentation()
    # Use a blank layout (no title placeholder)
    slide_layout = prs.slide_layouts[6]  # "Blank" layout
    slide = prs.slides.add_slide(slide_layout)

    # Add a text box manually (not a title)
    from pptx.util import Inches

    txBox = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(4), Inches(1))
    txBox.text = "Non-title text"

    pptx_path = str(tmp_path / "notitle.pptx")
    prs.save(pptx_path)

    from omnidoc.extractors.office.pptx import PPTXExtractor

    doc = PPTXExtractor().extract(pptx_path)
    assert any("Non-title text" in s.text for s in doc.sections)


def test_yaml_import_error(tmp_path):
    """YAMLExtractor raises ImportError when pyyaml not installed."""
    yaml_path = tmp_path / "config.yaml"
    yaml_path.write_text("key: value\n")

    with patch.dict(sys.modules, {"yaml": None}):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor

        with pytest.raises((ImportError, Exception)):
            YAMLExtractor().extract(str(yaml_path))


def test_html_bs4_not_installed(tmp_path):
    """HTMLExtractor raises ImportError when bs4 not installed."""
    html_path = tmp_path / "page.html"
    html_path.write_text("<html><body><p>Hello</p></body></html>")

    with patch.dict(sys.modules, {"bs4": None, "beautifulsoup4": None}):
        from omnidoc.extractors.web import html_extractor as html_mod

        importlib.reload(html_mod)
        with pytest.raises((ImportError, Exception)):
            html_mod.HTMLExtractor().extract(str(html_path))


# ---------------------------------------------------------------------------
# image/extractor.py — generic Exception path (lines 51-52)
# ---------------------------------------------------------------------------


def test_image_open_generic_exception(tmp_path):
    """Image.open raising OSError (not UnidentifiedImageError) hits except Exception."""
    img_path = tmp_path / "bad.jpg"
    img_path.write_bytes(b"fake")

    with patch("PIL.Image.open", side_effect=OSError("disk read error")):
        from omnidoc.extractors.image import extractor as img_mod

        importlib.reload(img_mod)
        with pytest.raises(ValueError, match="cannot open image"):
            img_mod.ImageExtractor().extract(str(img_path))


# ---------------------------------------------------------------------------
# archive/extractor.py — invalid TAR file raises ValueError (line 82)
# ---------------------------------------------------------------------------


def test_archive_tar_not_a_tar_file(tmp_path):
    """_extract_tar on a non-TAR file raises ValueError."""
    not_tar = tmp_path / "not_a_tar.tar"
    not_tar.write_text("this is not a tar file")

    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    with pytest.raises(ValueError, match="not a valid TAR"):
        ArchiveExtractor().extract(str(not_tar))


# ---------------------------------------------------------------------------
# eml_extractor.py — non-multipart text/html body (line 67)
# ---------------------------------------------------------------------------


def test_eml_nonmultipart_html_body(tmp_path):
    """Non-multipart EML with Content-Type text/html strips HTML."""
    import email.mime.text

    msg = email.mime.text.MIMEText(
        "<html><body><p>HTML body here</p></body></html>", "html"
    )
    msg["Subject"] = "HTML Only"
    msg["From"] = "a@b.com"
    msg["To"] = "c@d.com"
    msg["Date"] = "Mon, 01 Jan 2024 00:00:00 +0000"

    eml_path = tmp_path / "html_body.eml"
    eml_path.write_bytes(msg.as_bytes())

    from omnidoc.extractors.email.eml_extractor import EMLExtractor

    doc = EMLExtractor().extract(str(eml_path))
    assert doc is not None
    assert any("HTML body here" in s.text for s in doc.sections)


# ---------------------------------------------------------------------------
# html_extractor.py — duplicate/empty text triggers continue (line 51)
# ---------------------------------------------------------------------------


def test_html_duplicate_text_skipped(tmp_path):
    """HTML with duplicate block-element text: duplicate skipped, not double-counted."""
    html = (
        "<html><body>"
        "<p>Repeated text</p>"
        "<div>Repeated text</div>"
        "<p>Unique text</p>"
        "</body></html>"
    )
    html_path = tmp_path / "dup.html"
    html_path.write_text(html)

    from omnidoc.extractors.web.html_extractor import HTMLExtractor

    doc = HTMLExtractor().extract(str(html_path))
    # "Repeated text" should appear only once despite two tags
    full_text = doc.raw_text
    assert full_text.count("Repeated text") == 1
    assert "Unique text" in full_text


# ---------------------------------------------------------------------------
# code/extractor.py — latin-1 encoding fallback (lines 105-106)
# ---------------------------------------------------------------------------


def test_code_extractor_latin1_bytes(tmp_path):
    """Code file with latin-1 bytes (not valid UTF-8) reads via fallback encoding."""
    py_file = tmp_path / "latin.py"
    # 0xe9 = é in latin-1, not valid UTF-8 sequence
    py_file.write_bytes(b"# comment with \xe9 accent\ndef hello():\n    pass\n")

    from omnidoc.extractors.code.extractor import CodeExtractor

    doc = CodeExtractor().extract(str(py_file))
    assert doc is not None
    assert doc.metadata["language"] == "python"


# ---------------------------------------------------------------------------
# spreadsheet.py — TSV encoding fallback (lines 67-68)
# ---------------------------------------------------------------------------


def test_spreadsheet_tsv_latin1_bytes(tmp_path):
    """TSV file with latin-1 bytes triggers UnicodeDecodeError on UTF-8 then succeeds."""
    tsv_path = tmp_path / "data.tsv"
    # Header and data row with a latin-1 byte (0xe9 = é)
    tsv_path.write_bytes(b"name\tvalue\nFran\xe7ois\t42\n")

    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor

    doc = SpreadsheetExtractor().extract(str(tsv_path))
    assert doc is not None


# ---------------------------------------------------------------------------
# openoffice/extractor.py — helper function corner cases
# ---------------------------------------------------------------------------


def test_openoffice_parse_odf_table_empty():
    """_parse_odf_table returns None when table has no rows."""
    from omnidoc.extractors.openoffice.extractor import _parse_odf_table

    mock_table = MagicMock()
    mock_table.childNodes = []
    result = _parse_odf_table(mock_table, 1)
    assert result is None


def test_openoffice_parse_odf_table_non_row_children():
    """_parse_odf_table skips non-table-row children."""
    from omnidoc.extractors.openoffice.extractor import _parse_odf_table

    mock_table = MagicMock()
    non_row = MagicMock()
    non_row.qname = ("ns", "column")  # not "table-row"
    mock_table.childNodes = [non_row]
    result = _parse_odf_table(mock_table, 1)
    assert result is None  # no rows → None


def test_openoffice_extract_ods_non_table_child():
    """_extract_ods skips non-table children in spreadsheet."""
    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    mock_doc = MagicMock()
    non_table = MagicMock()
    non_table.qname = ("ns", "named-expressions")  # not "table"
    mock_doc.spreadsheet.childNodes = [non_table]

    extractor = OpenDocumentExtractor.__new__(OpenDocumentExtractor)
    doc = extractor._extract_ods("fake.ods", mock_doc)
    assert doc.tables == []


def test_openoffice_extract_odp_non_page_child():
    """_extract_odp skips non-page children in presentation."""
    from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor

    mock_doc = MagicMock()
    non_page = MagicMock()
    non_page.qname = ("ns", "settings")  # not "page"
    mock_doc.presentation.childNodes = [non_page]

    extractor = OpenDocumentExtractor.__new__(OpenDocumentExtractor)
    doc = extractor._extract_odp("fake.odp", mock_doc)
    assert doc.sections == []


def test_openoffice_collect_texts_recursive():
    """_collect_texts recursively gathers text from nested nodes."""
    from omnidoc.extractors.openoffice.extractor import _collect_texts

    # Leaf node with data
    leaf = SimpleNamespace(data="leaf text", childNodes=[])
    # Parent with no direct data but with a child
    parent = SimpleNamespace(childNodes=[leaf])
    results = _collect_texts(parent)
    assert "leaf text" in results


# ---------------------------------------------------------------------------
# pdf/text.py — public API functions (extract_text, extract_page_text, extract_page_tables)
# ---------------------------------------------------------------------------


def test_pdf_extract_text_function(tmp_path):
    """extract_text() returns one Section per page."""
    from omnidoc.pdf.text import extract_text
    from unittest.mock import MagicMock, patch

    mock_page = MagicMock()
    mock_page.extract_text.return_value = "page content here"

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = [mock_page]

    with patch("omnidoc.pdf.text.pdfplumber.open", return_value=mock_pdf):
        sections = extract_text("fake.pdf")
    assert len(sections) == 1
    assert "page content" in sections[0].text


def test_pdf_extract_page_text_function(tmp_path):
    """extract_page_text() returns text for the given page number."""
    from omnidoc.pdf.text import extract_page_text
    from unittest.mock import MagicMock, patch

    mock_page = MagicMock()
    mock_page.extract_text.return_value = "specific page text"

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = [mock_page]

    with patch("omnidoc.pdf.text.pdfplumber.open", return_value=mock_pdf):
        text = extract_page_text("fake.pdf", 1)
    assert "specific page text" in text


def test_pdf_extract_page_text_out_of_range(tmp_path):
    """extract_page_text() returns '' for out-of-range page."""
    from omnidoc.pdf.text import extract_page_text
    from unittest.mock import MagicMock, patch

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = []

    with patch("omnidoc.pdf.text.pdfplumber.open", return_value=mock_pdf):
        text = extract_page_text("fake.pdf", 5)
    assert text == ""


def test_pdf_extract_page_tables_function(tmp_path):
    """extract_page_tables() returns tables for the given page."""
    from omnidoc.pdf.text import extract_page_tables
    from unittest.mock import MagicMock, patch

    mock_page = MagicMock()
    mock_page.extract_tables.return_value = [[["H1", "H2"], ["v1", "v2"]]]

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = [mock_page]

    with patch("omnidoc.pdf.text.pdfplumber.open", return_value=mock_pdf):
        tables = extract_page_tables("fake.pdf", 1)
    assert len(tables) == 1


def test_pdf_extract_page_tables_out_of_range(tmp_path):
    """extract_page_tables() returns [] for out-of-range page."""
    from omnidoc.pdf.text import extract_page_tables
    from unittest.mock import MagicMock, patch

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = []

    with patch("omnidoc.pdf.text.pdfplumber.open", return_value=mock_pdf):
        tables = extract_page_tables("fake.pdf", 1)
    assert tables == []


# ---------------------------------------------------------------------------
# pdf/pipeline.py — _extract_camelot_tables and empty tbl_data continue (line 181)
# ---------------------------------------------------------------------------


def test_pipeline_extract_camelot_tables_not_installed():
    """_extract_camelot_tables returns [] when camelot not installed."""
    from unittest.mock import patch

    with patch.dict(sys.modules, {"camelot": None}):
        from omnidoc.pdf import pipeline as pip_mod

        importlib.reload(pip_mod)
        result = pip_mod._extract_camelot_tables("fake.pdf")
    assert result == []


def test_pipeline_extract_camelot_tables_with_data(tmp_path):
    """_extract_camelot_tables returns Table objects when camelot finds tables."""
    import pandas as pd

    mock_table = MagicMock()
    mock_table.page = 1
    mock_table.df = pd.DataFrame([["Header"], ["Row1"]])

    mock_camelot = MagicMock()
    mock_camelot.read_pdf.return_value = [mock_table]

    with patch.dict(sys.modules, {"camelot": mock_camelot}):
        from omnidoc.pdf import pipeline as pip_mod

        importlib.reload(pip_mod)
        result = pip_mod._extract_camelot_tables("fake.pdf")
    assert len(result) >= 0  # may find tables depending on mock


def test_pipeline_extract_camelot_tables_read_fails(tmp_path):
    """_extract_camelot_tables handles camelot.read_pdf failure gracefully."""
    mock_camelot = MagicMock()
    mock_camelot.read_pdf.side_effect = Exception("camelot fail")

    with patch.dict(sys.modules, {"camelot": mock_camelot}):
        from omnidoc.pdf import pipeline as pip_mod

        importlib.reload(pip_mod)
        result = pip_mod._extract_camelot_tables("fake.pdf")
    assert result == []


def test_pipeline_empty_tbl_data_skipped(tmp_path):
    """Empty/None tbl_data entries are skipped (line 181 continue)."""
    from omnidoc.core.document import Section

    mock_page = MagicMock()
    mock_page.extract_text.return_value = "page content"
    # Returns one empty/None table entry — should be skipped
    mock_page.extract_tables.return_value = [None, [], [[]]]

    mock_pdf = MagicMock()
    mock_pdf.__enter__ = lambda s: s
    mock_pdf.__exit__ = MagicMock(return_value=False)
    mock_pdf.pages = [mock_page]

    mock_doc = MagicMock()
    mock_doc.sections = [Section(page=1, text="page content")]
    mock_doc.tables = []
    mock_doc.chunks = []
    mock_doc.metadata = {}
    mock_doc.raw_text = "page content"

    pdf = tmp_path / "doc.pdf"
    pdf.write_bytes(b"%PDF-1.4")

    with (
        patch("omnidoc.pdf.pipeline.is_scanned_pdf", return_value=False),
        patch("omnidoc.pdf.pipeline.pdfplumber.open", return_value=mock_pdf),
        patch("omnidoc.pdf.pipeline.build_document", return_value=mock_doc),
        patch("omnidoc.pdf.pipeline._extract_camelot_tables", return_value=[]),
    ):
        from omnidoc.pdf.pipeline import extract_pdf

        result = extract_pdf(str(pdf))
    assert result is not None


# ---------------------------------------------------------------------------
# postprocess/slide_normalizer.py line 62 — buffer.append for body lines
# ---------------------------------------------------------------------------


def test_slide_normalizer_body_line_buffered():
    """Lines that are not headings/junk/artifacts reach buffer.append (line 62)."""
    from omnidoc.postprocess.slide_normalizer import normalize_slide_sections
    from omnidoc.core.document import Section

    # Lowercase lines are NOT matched by HEADING_PATTERN (^[A-Z]...)
    # and are long enough to pass SLIDE_ARTIFACT_PATTERN
    sections = [Section(page=1, text="this is body content here\nmore body text below")]
    result = normalize_slide_sections(sections)
    full_text = " ".join(s.text for s in result)
    assert "body content" in full_text
