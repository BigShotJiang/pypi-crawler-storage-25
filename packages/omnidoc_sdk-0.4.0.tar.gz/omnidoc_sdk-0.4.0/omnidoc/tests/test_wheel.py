"""Smoke tests — verify package structure and public API surface."""

import pkgutil


def test_all_expected_submodules_present():
    import omnidoc

    modules = {m.name for m in pkgutil.iter_modules(omnidoc.__path__)}
    required = {
        "pdf",
        "cli",
        "adapters",
        "core",
        "extractors",
        "loader",
        "ocr",
        "utils",
        "layout",
        "postprocess",
    }
    missing = required - modules
    assert not missing, f"Missing submodules: {missing}"


def test_public_api_importable():
    from omnidoc.pdf.pipeline import extract_pdf
    from omnidoc.loader.load import load_document
    from omnidoc.config import OmnidocConfig
    from omnidoc.utils.retry import with_retry
    from omnidoc.utils.logging_config import configure_logging
    from omnidoc.utils.serialize import document_to_json, document_to_toon
    from omnidoc.core.document import Document, Section, Table
    from omnidoc.ocr.tesseract import TesseractOCR

    assert all(
        symbol is not None
        for symbol in (
            extract_pdf,
            load_document,
            OmnidocConfig,
            with_retry,
            configure_logging,
            document_to_json,
            document_to_toon,
            Document,
            Section,
            Table,
            TesseractOCR,
        )
    )


def test_all_extractors_importable():
    from omnidoc.extractors.text.extractor import TextExtractor
    from omnidoc.extractors.office.docx import DocxExtractor
    from omnidoc.extractors.office.pptx import PPTXExtractor
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor
    from omnidoc.extractors.structured.json_xml import JSONExtractor, XMLExtractor
    from omnidoc.extractors.archive.extractor import ArchiveExtractor
    from omnidoc.extractors.image.extractor import ImageExtractor
    from omnidoc.extractors.markdown.extractor import MarkdownExtractor

    assert all(
        symbol is not None
        for symbol in (
            TextExtractor,
            DocxExtractor,
            PPTXExtractor,
            SpreadsheetExtractor,
            JSONExtractor,
            XMLExtractor,
            ArchiveExtractor,
            ImageExtractor,
            MarkdownExtractor,
        )
    )


def test_ocr_engines_importable():
    from omnidoc.ocr.base import OCREngine
    from omnidoc.ocr.tesseract import TesseractOCR

    # Cloud engines — only import the class, don't instantiate (needs credentials)
    from omnidoc.ocr.aws_textract import TextractOCR
    from omnidoc.ocr.azure_form_recognizer import AzureFormRecognizer

    assert all(
        symbol is not None
        for symbol in (
            OCREngine,
            TesseractOCR,
            TextractOCR,
            AzureFormRecognizer,
        )
    )


def test_adapters_importable():
    import sys
    from unittest.mock import MagicMock
    from omnidoc.core.document import Document, Section

    # ── LangChain adapter ────────────────────────────────────────────────
    lc_doc_cls = MagicMock()
    lc_doc_cls.side_effect = lambda page_content, metadata: {
        "page_content": page_content,
        "metadata": metadata,
    }
    lc_schema = MagicMock()
    lc_schema.Document = lc_doc_cls
    lc_mock = MagicMock()
    lc_mock.schema = lc_schema

    with __import__("unittest.mock", fromlist=["patch"]).patch.dict(
        sys.modules, {"langchain": lc_mock, "langchain.schema": lc_schema}
    ):
        import importlib
        import omnidoc.adapters.langchain as _lc_mod

        importlib.reload(_lc_mod)
        doc = Document(
            metadata={},
            sections=[Section(page=1, text="Hello")],
            tables=[],
            raw_text="Hello",
        )
        result = _lc_mod.to_langchain(doc)
        assert len(result) == 1
        assert result[0]["page_content"] == "Hello"

    # ── LlamaIndex adapter ───────────────────────────────────────────────
    li_doc_cls = MagicMock()
    li_doc_cls.side_effect = lambda text, metadata: {"text": text, "metadata": metadata}
    li_core = MagicMock()
    li_core.Document = li_doc_cls
    li_mock = MagicMock()
    li_mock.core = li_core

    with __import__("unittest.mock", fromlist=["patch"]).patch.dict(
        sys.modules, {"llama_index": li_mock, "llama_index.core": li_core}
    ):
        import omnidoc.adapters.llamaindex as _li_mod

        importlib.reload(_li_mod)
        result = _li_mod.to_llamaindex(doc)
        assert len(result) == 1
        assert result[0]["text"] == "Hello"


def test_document_dataclass_fields():
    from omnidoc.core.document import Document, Section, Table

    sec = Section(page=1, text="test")
    tbl = Table(page=1, headers=["A", "B"], rows=[["1", "2"]])
    doc = Document(
        metadata={"file": "x.pdf"},
        sections=[sec],
        tables=[tbl],
        raw_text="test",
    )
    assert doc.sections[0].page == 1
    assert doc.tables[0].headers == ["A", "B"]
    assert doc.chunks == []  # RAG chunking lives in omnidoc-rag
