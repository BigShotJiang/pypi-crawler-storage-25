# omnidoc/extractors/email/eml_extractor.py
import email
import email.policy
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class EMLExtractor(BaseExtractor):
    """
    Extract text from RFC-822 .eml files using Python's stdlib email module.

    Extracts headers (From, To, Subject, Date), the plain-text body, and
    any text/html parts (stripped of tags).  Attachments are listed in
    metadata but not recursively decoded.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"EMLExtractor: file not found: {path}")

        with open(path, "rb") as fh:
            msg = email.message_from_binary_file(fh, policy=email.policy.default)

        subject = str(msg.get("Subject", ""))
        from_addr = str(msg.get("From", ""))
        to_addr = str(msg.get("To", ""))
        date = str(msg.get("Date", ""))

        sections: List[Section] = []
        attachments: List[str] = []

        header_block = "\n".join(
            filter(
                None,
                [
                    f"From: {from_addr}" if from_addr else "",
                    f"To: {to_addr}" if to_addr else "",
                    f"Subject: {subject}" if subject else "",
                    f"Date: {date}" if date else "",
                ],
            )
        )
        if header_block:
            sections.append(Section(page=1, text=header_block))

        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                disp = str(part.get("Content-Disposition", ""))
                if "attachment" in disp:
                    fname = part.get_filename() or ct
                    attachments.append(fname)
                    continue
                if ct == "text/plain":
                    text = _decode_part(part)
                    if text:
                        sections.append(Section(page=1, text=text))
                elif ct == "text/html":
                    text = _strip_html(_decode_part(part))
                    if text:
                        sections.append(Section(page=1, text=text))
        else:
            ct = msg.get_content_type()
            body = _decode_part(msg)
            if ct == "text/html":
                body = _strip_html(body)
            if body:
                sections.append(Section(page=1, text=body))

        raw_text = "\n\n".join(s.text for s in sections)
        metadata: dict = {
            "file": path,
            "type": "eml",
            "pages": 1,
            "subject": subject,
            "from": from_addr,
            "to": to_addr,
            "date": date,
        }
        if attachments:
            metadata["attachments"] = attachments

        logger.debug(
            "EMLExtractor: extracted %d sections from '%s'", len(sections), path
        )
        return Document(
            metadata=metadata, sections=sections, tables=[], raw_text=raw_text
        )


def _decode_part(part) -> str:
    try:
        payload = part.get_payload(decode=True)
        if not payload:
            return ""
        charset = part.get_content_charset() or "utf-8"
        return payload.decode(charset, errors="replace").strip()
    except Exception:
        return ""


def _strip_html(html: str) -> str:
    try:
        from bs4 import BeautifulSoup

        return BeautifulSoup(html, "html.parser").get_text(separator="\n", strip=True)
    except ImportError:  # pragma: no cover
        import re  # pragma: no cover

        return re.sub(r"<[^>]+>", " ", html).strip()  # pragma: no cover
