# omnidoc/extractors/code/extractor.py
import logging
import os
from pathlib import Path
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)

# Maps file extension → Pygments lexer alias (used only for metadata)
_EXT_LANGUAGE: dict = {
    ".py": "python",
    ".java": "java",
    ".js": "javascript",
    ".ts": "typescript",
    ".go": "go",
    ".cpp": "cpp",
    ".c": "c",
    ".rs": "rust",
    ".rb": "ruby",
    ".sh": "bash",
    ".cs": "csharp",
    ".kt": "kotlin",
    ".swift": "swift",
    ".php": "php",
    ".r": "r",
    ".scala": "scala",
    ".lua": "lua",
    ".pl": "perl",
}

_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class CodeExtractor(BaseExtractor):
    """
    Extract source code from text-based code files.

    The raw source is returned as-is in a single Section. When pygments is
    installed the code is also lexed so callers can access token-level data
    via metadata['tokens']. Without pygments the extractor works fine — only
    token metadata is absent.

    Logical block splitting: top-level function/class definitions each become
    their own Section so semantic chunking works on meaningful boundaries.
    """

    def __init__(self, split_blocks: bool = True) -> None:
        self._split_blocks = split_blocks

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"CodeExtractor: file not found: {path}")

        ext = Path(path).suffix.lower()
        language = _EXT_LANGUAGE.get(ext, "text")

        source = _read_source(path)

        sections: List[Section] = []
        if self._split_blocks and language in (
            "python",
            "java",
            "javascript",
            "typescript",
        ):
            sections = _split_into_blocks(source, language)
        if not sections:
            sections = [Section(page=1, text=source)]

        metadata: dict = {
            "file": path,
            "type": "code",
            "language": language,
            "pages": 1,
            "lines": source.count("\n") + 1,
        }

        # Optional: token count via pygments
        try:
            import pygments
            from pygments.lexers import get_lexer_by_name
            from pygments.token import Token

            lexer = get_lexer_by_name(language, stripall=True)
            tokens = list(pygments.lex(source, lexer))
            # Count non-whitespace tokens as a useful metric
            code_tokens = [t for t in tokens if t[0] not in Token.Text]
            metadata["token_count"] = len(code_tokens)
        except Exception:
            pass  # pygments not installed or lexer not found — skip silently

        logger.debug(
            "CodeExtractor: %s — %d lines, %d sections from '%s'",
            language,
            metadata["lines"],
            len(sections),
            path,
        )
        return Document(
            metadata=metadata, sections=sections, tables=[], raw_text=source
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_source(path: str) -> str:
    for enc in _ENCODINGS:
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as fh:  # pragma: no cover
        return fh.read()  # pragma: no cover


def _split_into_blocks(source: str, language: str) -> List[Section]:
    """
    Naively split source code into top-level definition blocks.

    Uses simple line-prefix heuristics rather than a full AST so it works
    without any extra dependencies. Each block starts at a `def`/`class`/
    `function`/`public class` line and runs until the next one.
    """
    import re

    if language == "python":
        pattern = re.compile(r"^(def |class |async def )", re.MULTILINE)
    elif language in ("javascript", "typescript"):
        pattern = re.compile(
            r"^(function |const \w+ = |class |export (default )?function |export (default )?class )",
            re.MULTILINE,
        )
    elif language == "java":
        pattern = re.compile(
            r"^    (public|private|protected|static|void|class|interface|enum)\b",
            re.MULTILINE,
        )
    else:
        return []  # pragma: no cover  (only called for python/java/js/ts)

    lines = source.splitlines(keepends=True)
    split_lines = {m.start() for m in pattern.finditer(source)}

    # Convert byte offsets to line indices
    split_line_indices: List[int] = []
    offset = 0
    for i, line in enumerate(lines):
        if offset in split_lines:
            split_line_indices.append(i)
        offset += len(line)

    if not split_line_indices:
        return []

    # Add sentinel
    split_line_indices.append(len(lines))

    blocks: List[Section] = []
    page = 1
    for start, end in zip(split_line_indices, split_line_indices[1:]):
        block = "".join(lines[start:end]).strip()
        if block:
            blocks.append(Section(page=page, text=block))
            page += 1
    return blocks
