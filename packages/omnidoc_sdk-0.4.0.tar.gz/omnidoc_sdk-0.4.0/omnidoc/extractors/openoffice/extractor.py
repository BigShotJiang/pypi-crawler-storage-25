# omnidoc/extractors/openoffice/extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)


class OpenDocumentExtractor(BaseExtractor):
    """
    Extract text from OpenDocument files via odfpy.

    Handles:
      .odt  — Writer documents  (text + tables)
      .odp  — Impress presentations (slide text)
      .ods  — Calc spreadsheets (tabular data)
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"OpenDocumentExtractor: file not found: {path}")

        try:
            from odf import opendocument
        except ImportError as exc:
            raise ImportError(
                "OpenDocument support requires odfpy.\n"
                "Install with: pip install 'omnidoc-sdk[openoffice]'"
            ) from exc

        lower = path.lower()
        doc_odf = opendocument.load(path)

        if lower.endswith(".ods"):
            return self._extract_ods(path, doc_odf)
        elif lower.endswith(".odp"):
            return self._extract_odp(path, doc_odf)
        else:
            return self._extract_odt(path, doc_odf)

    # ------------------------------------------------------------------

    def _extract_odt(self, path: str, doc_odf) -> Document:
        sections: List[Section] = []
        tables: List[Table] = []
        page = 1

        # Paragraphs and headings
        for elem in doc_odf.text.childNodes:
            tag = elem.qname[1] if hasattr(elem, "qname") else ""
            if tag in ("p", "h"):
                text = _odf_text(elem)
                if text:
                    sections.append(Section(page=page, text=text))
            elif tag == "table":
                tbl = _parse_odf_table(elem, page)
                if tbl:
                    tables.append(tbl)
                    sections.append(Section(page=page, text=_table_to_text(tbl)))

        raw = "\n\n".join(s.text for s in sections)
        logger.debug(
            "ODTExtractor: %d sections, %d tables from '%s'",
            len(sections),
            len(tables),
            path,
        )
        return Document(
            metadata={"file": path, "type": "odt", "pages": page},
            sections=sections,
            tables=tables,
            raw_text=raw,
        )

    def _extract_odp(self, path: str, doc_odf) -> Document:
        sections: List[Section] = []
        page = 0

        for draw_page in doc_odf.presentation.childNodes:
            tag = draw_page.qname[1] if hasattr(draw_page, "qname") else ""
            if tag != "page":
                continue
            page += 1
            texts = _collect_texts(draw_page)
            if texts:
                sections.append(Section(page=page, text="\n".join(texts)))

        raw = "\n\n".join(s.text for s in sections)
        logger.debug("ODPExtractor: %d slides from '%s'", page, path)
        return Document(
            metadata={"file": path, "type": "odp", "pages": page},
            sections=sections,
            tables=[],
            raw_text=raw,
        )

    def _extract_ods(self, path: str, doc_odf) -> Document:
        sections: List[Section] = []
        tables: List[Table] = []
        page = 1

        for sheet in doc_odf.spreadsheet.childNodes:
            tag = sheet.qname[1] if hasattr(sheet, "qname") else ""
            if tag != "table":
                continue
            tbl = _parse_odf_table(sheet, page)
            if tbl:
                tables.append(tbl)
                sections.append(Section(page=page, text=_table_to_text(tbl)))
                page += 1

        raw = "\n\n".join(s.text for s in sections)
        logger.debug("ODSExtractor: %d sheets from '%s'", page - 1, path)
        return Document(
            metadata={"file": path, "type": "ods", "pages": max(1, page - 1)},
            sections=sections,
            tables=tables,
            raw_text=raw,
        )


# ---------------------------------------------------------------------------
# ODF helpers
# ---------------------------------------------------------------------------


def _odf_text(node) -> str:
    """Recursively collect all text content from an ODF element."""
    parts: List[str] = []
    if hasattr(node, "data"):
        parts.append(node.data)
    for child in getattr(node, "childNodes", []):
        parts.append(_odf_text(child))
    return "".join(parts).strip()


def _collect_texts(node) -> List[str]:
    """Gather non-empty text strings from all descendant nodes."""
    results: List[str] = []
    t = _odf_text(node)
    if t:
        results.append(t)
    for child in getattr(node, "childNodes", []):
        results.extend(_collect_texts(child))
    return results


def _parse_odf_table(table_node, page: int):
    """Convert an ODF table element to a Table dataclass."""
    rows_data: List[List[str]] = []
    for row_node in getattr(table_node, "childNodes", []):
        tag = row_node.qname[1] if hasattr(row_node, "qname") else ""
        if tag != "table-row":
            continue
        row: List[str] = []
        for cell_node in getattr(row_node, "childNodes", []):
            ctag = cell_node.qname[1] if hasattr(cell_node, "qname") else ""
            if ctag in ("table-cell", "covered-table-cell"):
                row.append(_odf_text(cell_node))
        if row:
            rows_data.append(row)

    if not rows_data:
        return None

    headers = rows_data[0] if rows_data else []
    body = rows_data[1:] if len(rows_data) > 1 else []
    return Table(page=page, headers=headers, rows=body)


def _table_to_text(tbl: Table) -> str:
    lines = ["\t".join(tbl.headers)]
    for row in tbl.rows:
        lines.append("\t".join(row))
    return "\n".join(lines)
