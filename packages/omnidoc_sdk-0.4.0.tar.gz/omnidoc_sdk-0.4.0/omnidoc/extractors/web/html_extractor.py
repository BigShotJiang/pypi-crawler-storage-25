# omnidoc/extractors/web/html_extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class HTMLExtractor(BaseExtractor):
    """
    Extract text from HTML files via BeautifulSoup4.

    Strips all tags and script/style content; preserves logical paragraph
    breaks so the text is suitable for semantic chunking.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"HTMLExtractor: file not found: {path}")

        try:
            from bs4 import BeautifulSoup
        except ImportError as exc:
            raise ImportError(
                "HTML support requires beautifulsoup4.\n"
                "Install with: pip install 'omnidoc-sdk[docs]'"
            ) from exc

        raw_html = _read_html(path)
        soup = BeautifulSoup(raw_html, "html.parser")

        # Extract title before removing <head>
        title = soup.title.string.strip() if soup.title and soup.title.string else ""

        # Remove scripts, styles, and hidden elements
        for tag in soup(["script", "style", "head", "meta", "noscript"]):
            tag.decompose()

        # Build sections from block-level elements
        sections: List[Section] = []
        block_tags = [
            "p",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "li",
            "td",
            "th",
            "blockquote",
            "pre",
            "div",
        ]

        seen: set = set()
        for tag in soup.find_all(block_tags):
            text = tag.get_text(separator=" ", strip=True)
            if not text or text in seen:
                continue
            seen.add(text)
            sections.append(Section(page=1, text=text))

        # Fallback: get_text on full body
        if not sections:
            body_text = soup.get_text(separator="\n", strip=True)
            sections = [Section(page=1, text=body_text)]

        raw_text = "\n\n".join(s.text for s in sections)

        metadata: dict = {"file": path, "type": "html", "pages": 1}
        if title:
            metadata["title"] = title

        logger.debug(
            "HTMLExtractor: extracted %d sections from '%s'", len(sections), path
        )
        return Document(
            metadata=metadata, sections=sections, tables=[], raw_text=raw_text
        )


# ---------------------------------------------------------------------------
# Encoding helpers
# ---------------------------------------------------------------------------

_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


def _read_html(path: str) -> str:
    for enc in _ENCODINGS:
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as fh:  # pragma: no cover
        return fh.read()  # pragma: no cover
