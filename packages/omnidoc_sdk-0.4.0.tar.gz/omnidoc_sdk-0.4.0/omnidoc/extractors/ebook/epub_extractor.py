# omnidoc/extractors/ebook/epub_extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class EPUBExtractor(BaseExtractor):
    """
    Extract text from EPUB e-books via ebooklib + BeautifulSoup4.

    Each EPUB document item (chapter/section) becomes a Section.
    The chapter title (if detectable) is prepended to its text block.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"EPUBExtractor: file not found: {path}")

        try:
            import ebooklib
            from ebooklib import epub
        except ImportError as exc:
            raise ImportError(
                "EPUB support requires ebooklib.\n"
                "Install with: pip install 'omnidoc-sdk[ebook]'"
            ) from exc

        try:
            from bs4 import BeautifulSoup
        except ImportError as exc:
            raise ImportError(
                "EPUB text extraction requires beautifulsoup4.\n"
                "Install with: pip install 'omnidoc-sdk[docs]'"
            ) from exc

        book = epub.read_epub(path, options={"ignore_ncx": True})

        title = book.title or ""
        authors = [str(a) for a in (book.get_metadata("DC", "creator") or [])]
        # get_metadata returns list of (value, attrs) tuples
        authors = [a[0] if isinstance(a, tuple) else a for a in authors]

        sections: List[Section] = []
        page_num = 0

        for item in book.get_items_of_type(ebooklib.ITEM_DOCUMENT):
            content = item.get_content()
            if not content:
                continue
            soup = BeautifulSoup(content, "html.parser")
            # Remove scripts/styles
            for tag in soup(["script", "style"]):
                tag.decompose()
            text = soup.get_text(separator="\n", strip=True)
            if not text:
                continue
            page_num += 1
            sections.append(Section(page=page_num, text=text))

        if not sections:
            raise ValueError(f"EPUBExtractor: no readable content found in '{path}'")

        raw_text = "\n\n".join(s.text for s in sections)
        metadata: dict = {
            "file": path,
            "type": "epub",
            "pages": page_num,
        }
        if title:
            metadata["title"] = title
        if authors:
            metadata["authors"] = authors

        logger.debug(
            "EPUBExtractor: extracted %d sections from '%s'", len(sections), path
        )
        return Document(
            metadata=metadata, sections=sections, tables=[], raw_text=raw_text
        )
