# omnidoc/extractors/structured/yaml_extractor.py
import json
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class YAMLExtractor(BaseExtractor):
    """
    Extract content from YAML / YML files.

    Parses the file with PyYAML, then serialises the result to a
    pretty-printed JSON string so it is easy to read and chunk.
    The raw YAML text is also preserved in metadata.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"YAMLExtractor: file not found: {path}")

        try:
            import yaml  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "YAML support requires PyYAML.\n" "Install with: pip install pyyaml"
            ) from exc

        raw = _read_text(path)
        try:
            data = yaml.safe_load(raw)
        except yaml.YAMLError as exc:
            raise ValueError(f"YAMLExtractor: invalid YAML in '{path}': {exc}") from exc

        pretty = json.dumps(data, indent=2, default=str, ensure_ascii=False)
        sections: List[Section] = [Section(page=1, text=pretty)]

        logger.debug("YAMLExtractor: parsed '%s'", path)
        return Document(
            metadata={"file": path, "type": "yaml", "pages": 1},
            sections=sections,
            tables=[],
            raw_text=pretty,
        )


_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


def _read_text(path: str) -> str:
    for enc in _ENCODINGS:
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as fh:  # pragma: no cover
        return fh.read()  # pragma: no cover
