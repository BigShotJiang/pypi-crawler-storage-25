import logging
import os
from typing import List

from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)


class DocxExtractor:
    """
    Production-grade DOCX extractor.

    Guarantees:
    - Heading-aware sections
    - Safe empty-table handling
    - Encoding-safe cell text extraction
    - RAG-ready output
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"DocxExtractor: file not found: {path}")

        try:
            from docx import Document as WordDocument
        except ImportError as exc:
            raise ImportError(
                "DOCX support requires python-docx.\n"
                "Install with: pip install 'omnidoc-sdk[office]'"
            ) from exc

        try:
            doc = WordDocument(path)
        except Exception as exc:
            raise ValueError(f"DocxExtractor: cannot open '{path}': {exc}") from exc

        sections: List[Section] = []
        tables: List[Table] = []
        buffer: List[str] = []
        page = 1

        def flush() -> None:
            nonlocal buffer
            text = "\n".join(buffer).strip()
            if text:
                sections.append(Section(page=page, text=text))
            buffer = []

        # ------------------------------------------------------------------
        # Paragraphs
        # ------------------------------------------------------------------
        for para in doc.paragraphs:
            text = (para.text or "").strip()
            if not text:
                continue

            style: str = ""
            try:
                style = para.style.name if para.style else ""
            except Exception:
                pass

            if style.startswith("Heading"):
                flush()
                sections.append(Section(page=page, text=text))
            else:
                buffer.append(text)

        flush()

        # ------------------------------------------------------------------
        # Tables
        # ------------------------------------------------------------------
        for t in doc.tables:
            try:
                rows: List[List[str]] = []
                for row in t.rows:
                    rows.append([_safe_cell_text(cell) for cell in row.cells])

                if not rows:
                    continue

                tables.append(
                    Table(
                        page=page,
                        headers=rows[0],
                        rows=rows[1:] if len(rows) > 1 else [],
                    )
                )
            except Exception as exc:
                logger.warning(
                    "DocxExtractor: skipping malformed table in '%s': %s", path, exc
                )

        raw_text = "\n".join(sec.text for sec in sections)
        logger.debug(
            "DocxExtractor: %d sections, %d tables from '%s'",
            len(sections),
            len(tables),
            path,
        )

        return Document(
            metadata={"file": path, "pages": 1, "type": "docx"},
            sections=sections,
            tables=tables,
            raw_text=raw_text,
        )


def _safe_cell_text(cell) -> str:
    try:
        return (cell.text or "").strip()
    except Exception:
        return ""
