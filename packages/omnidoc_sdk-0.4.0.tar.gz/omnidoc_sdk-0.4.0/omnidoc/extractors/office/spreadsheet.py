# omnidoc/extractors/office/spreadsheet.py
import logging
import os
from typing import List

import pandas as pd

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)

# CSV encodings tried in order before giving up
_CSV_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class SpreadsheetExtractor(BaseExtractor):
    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Spreadsheet not found: {path}")

        try:
            df = self._read(path)
        except Exception as exc:
            raise ValueError(f"Failed to parse spreadsheet '{path}': {exc}") from exc

        # Sanitise column names — pandas may return ints for unnamed cols
        df.columns = [str(c) for c in df.columns]

        table = Table(
            page=1,
            headers=list(df.columns),
            rows=df.fillna("").astype(str).values.tolist(),
        )

        raw = df.to_string(index=False)
        sections: List[Section] = [Section(page=1, text=raw)]

        logger.debug(
            "SpreadsheetExtractor: extracted %d rows × %d cols from '%s'",
            len(df),
            len(df.columns),
            path,
        )

        return Document(
            metadata={"file": path, "type": "spreadsheet", "pages": 1},
            sections=sections,
            tables=[table],
            raw_text=raw,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _read(self, path: str) -> "pd.DataFrame":
        lower = path.lower()
        if lower.endswith(".xlsx") or lower.endswith(".xls"):
            return pd.read_excel(path)

        # TSV — tab-separated values
        if lower.endswith(".tsv"):
            for enc in _CSV_ENCODINGS:
                try:
                    return pd.read_csv(path, sep="\t", encoding=enc)
                except (UnicodeDecodeError, LookupError):
                    continue
            return pd.read_csv(
                path, sep="\t", encoding="utf-8", encoding_errors="replace"
            )  # pragma: no cover

        # CSV (default) — try multiple encodings
        for enc in _CSV_ENCODINGS:
            try:
                return pd.read_csv(path, encoding=enc)
            except (UnicodeDecodeError, LookupError):
                continue

        # Last resort: replace bad bytes (latin-1 in _CSV_ENCODINGS always succeeds)
        return pd.read_csv(
            path, encoding="utf-8", encoding_errors="replace"
        )  # pragma: no cover
