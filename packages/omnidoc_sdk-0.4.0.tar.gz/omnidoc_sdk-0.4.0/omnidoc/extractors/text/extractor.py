import logging
import os

from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)

# Encodings tried in order; last entry always succeeds (errors='replace')
_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class TextExtractor:
    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Text file not found: {path}")

        text = self._read_with_fallback(path)

        sections = [Section(page=1, text=text)]

        logger.debug("TextExtractor: read %d chars from '%s'", len(text), path)

        return Document(
            metadata={"file": path, "pages": 1, "type": "text"},
            sections=sections,
            tables=[],
            raw_text=text,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _read_with_fallback(self, path: str) -> str:
        raw = open(path, "rb").read()

        # Try known encodings first (fast path)
        for enc in _ENCODINGS:
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue

        # chardet auto-detection (optional dependency)
        try:  # pragma: no cover
            import chardet  # pragma: no cover

            detected = (
                chardet.detect(raw).get("encoding") or "utf-8"
            )  # pragma: no cover
            return raw.decode(detected, errors="replace")  # pragma: no cover
        except ImportError:  # pragma: no cover
            pass  # pragma: no cover

        # Absolute fallback — never crashes (latin-1 in _ENCODINGS always succeeds)
        logger.warning(
            "TextExtractor: could not detect encoding for '%s'; replacing bad bytes",
            path,
        )  # pragma: no cover
        return raw.decode("utf-8", errors="replace")  # pragma: no cover
