"""Shared claim-to-AuthContext mapping used by both REST and MCP transports.

Both ``JwtCredentialValidator`` (REST) and ``AuthBridgeMiddleware`` (MCP)
produce an ``AuthContext`` from a validated JWT's claim dict. This module
centralises that mapping so any future field change requires a single edit.

The OIDC-standard ``sub`` claim is always mapped to ``user_id``/``username``.
Additional claims are extracted via ``claim_map`` (dot-path → attribute name)
from ``AuthConfig``. Mapped attributes named ``email`` or ``tenant_id``
populate the corresponding ``AuthContext`` fields; all others are available
to the Cedar policy engine via ``resolve_attributes()``.
"""

from __future__ import annotations

from collections.abc import Mapping
from types import MappingProxyType
from typing import Any

from sonnet_server.guards import AuthContext

# JWT standard/registered claims excluded from auto-mapping — these are
# protocol plumbing, not domain attributes meaningful to Cedar policies.
_JWT_PLUMBING: frozenset[str] = frozenset({"sub", "iat", "exp", "nbf", "iss", "aud", "jti"})


def resolve_dot_path(data: Mapping, path: str) -> Any | None:
    """Walk a dot-delimited path into a nested mapping, returning None on miss.

    Accepts any ``Mapping`` (dict, MappingProxyType, etc.) so callers can
    pass raw JWT dicts or the frozen ``AuthContext.claims`` proxy directly.

    **Limitation:** returns ``None`` both when a path is absent *and* when a
    leaf value is explicitly ``None``. Callers cannot distinguish the two cases.
    A claim value that is legitimately ``None`` in the JWT will be treated as
    absent. This is an accepted constraint — JWT claims used as Cedar attributes
    should carry a meaningful value; ``None`` is not a valid Cedar attribute value.

    >>> resolve_dot_path({"a": {"b": [1, 2]}}, "a.b")
    [1, 2]
    >>> resolve_dot_path({"a": 1}, "a.b.c") is None
    True
    """
    current: Any = data
    for segment in path.split("."):
        if not isinstance(current, Mapping):
            return None
        current = current.get(segment)
        if current is None:
            return None
    return current


_SENTINEL = object()


def resolve_attributes(
    claims: Mapping,
    claim_map: dict[str, str],
    auto_map_claims: bool = False,
) -> dict[str, Any]:
    """Resolve JWT claims to Cedar principal attributes.

    When ``auto_map_claims`` is True, all top-level claims are included
    as attributes using their original name (except ``sub``, ``iat``,
    ``exp``, ``nbf``, ``iss``, ``aud``, ``jti`` which are JWT plumbing).
    Falsy but present values (``False``, ``0``, ``[]``, ``""``) are included.
    Explicit ``claim_map`` entries take priority over auto-mapped names,
    allowing renames and dot-path extraction of nested claims.

    When ``auto_map_claims`` is False (default), only claims listed in
    ``claim_map`` are visible.
    """
    attrs: dict[str, Any] = {}

    # Auto-map: pass through all top-level claims (except JWT plumbing).
    # Include falsy-but-present values (e.g. active=False, count=0).
    # Skip only None and absent keys.
    if auto_map_claims:
        for key, value in claims.items():
            if key not in _JWT_PLUMBING and value is not None:
                attrs[key] = value

    # Explicit claim_map: overrides auto-mapped names, supports dot-paths.
    # resolve_dot_path returns None for both absent keys and None values;
    # we use a sentinel to distinguish "key present but falsy" from "key absent".
    for attr_name, dot_path in claim_map.items():
        # Walk the path manually to detect absent vs None leaf
        current: Any = claims
        found = True
        for segment in dot_path.split("."):
            if not isinstance(current, Mapping):
                found = False
                break
            current = current.get(segment, _SENTINEL)
            if current is _SENTINEL:
                found = False
                break
        if found and current is not None:
            attrs[attr_name] = current

    return attrs


def build_auth_context(
    claims: dict,
    claim_map: dict[str, str] | None = None,
    auto_map_claims: bool = False,
) -> AuthContext:
    """Build an ``AuthContext`` from a validated JWT claim dict.

    The OIDC-standard ``sub`` claim is always mapped to ``user_id`` and
    ``username``. Additional claims are extracted via ``claim_map`` and
    ``auto_map_claims``:

    - ``email`` → ``AuthContext.email`` (when mapped)
    - ``tenant_id`` → ``AuthContext.tenant_id`` (when mapped)
    - All others remain available to Cedar via ``resolve_attributes()``
      at evaluation time (re-derived from ``claims`` + ``claim_map``).

    Precondition: ``claims`` must come from a token that has already been
    validated (signature, expiry, issuer, audience).
    """
    sub = claims["sub"]
    attrs = resolve_attributes(claims, claim_map or {}, auto_map_claims=auto_map_claims)

    return AuthContext(
        user_id=sub,
        username=sub,
        email=attrs.get("email"),
        tenant_id=attrs.get("tenant_id"),
        claims=MappingProxyType(claims),
    )
