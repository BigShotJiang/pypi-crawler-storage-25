"""AuthSettings — typed auth configuration with env var + optional seed resolution.

Resolution per field (example with prefix ``COCO_RAG_``):
  env var COCO_RAG_AUTHN_ENABLED > seed value (e.g. from DB) > default.

The env prefix is passed explicitly to ``AuthSettings.resolve()`` so the
same model works for any consumer (COCO_RAG_, COCO_GRAPH_, ATLAS_, …).
No module-level mutable state — safe to call from any context.

Seed key contract (what callers pass to resolve()):
  ``authn_enabled`` (bool) — AuthN toggle
  ``authn_config``  (dict) — AuthN config blob (validated by AuthnConfig)
  ``authz_enabled`` (bool) — AuthZ toggle

DB storage keys (coco-rag settings table):
  authn_enabled         — flat boolean (AuthN toggle / emergency kill switch)
  authn_config          — JSON object: AuthN config (jwks_uri, issuer, audience,
                          mode, claim_map, auto_map_claims, mcp_base_url,
                          upstream_* fields)
  authz_enabled         — flat boolean (AuthZ / Cedar toggle)
  authz_cedar_policies  — text: Cedar policy source
  authz_cedar_schema    — text: Cedar schema source

CLI usage:
  coco-rag settings set authn_enabled true
  coco-rag settings set authn_config '{"jwks_uri": "...", "issuer": "...", "audience": "..."}'
  coco-rag settings set authz_enabled true
  coco-rag settings set-text authz_cedar_policies --file policies.cedar
  coco-rag settings set-text authz_cedar_schema   --file schema.cedarschema

Future (Phase 4 — atlas bundle pull):
  ``authz_config``  (dict) — AuthZ config blob (AuthzConfig, when added)
"""

from __future__ import annotations

import json
import os
from enum import StrEnum
from typing import Any, ClassVar

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator


def _validate_https_url(v: str | None, *, env_prefix: str = "") -> str | None:
    """Validate URL uses HTTPS with a non-empty host. Preserves value as-is (no normalisation).

    ``{env_prefix}AUTHN_ALLOW_HTTP=true`` relaxes to HTTP for test environments
    (localhost only). For example: ``COCO_RAG_AUTHN_ALLOW_HTTP=true``.
    """
    if v is None:
        return None
    from urllib.parse import urlparse

    parsed = urlparse(v)
    allow_http = os.environ.get(f"{env_prefix}AUTHN_ALLOW_HTTP", "").lower() in ("true", "1")

    if allow_http:
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError(f"URL must use HTTP(S) with a valid host: {v!r}")
        if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1"):
            raise ValueError(f"HTTP is only allowed for localhost in test mode: {v!r}")
        return v

    if parsed.scheme != "https" or not parsed.hostname:
        raise ValueError(f"URL must use HTTPS with a valid host: {v!r}")
    return v


class AuthMode(StrEnum):
    JWT_VERIFIER = "jwt_verifier"
    OAUTH_PROXY = "oauth_proxy"


class AuthnConfig(BaseModel):
    """JWT/JWKS authentication configuration.

    Stored as the ``auth_config`` settings key. All fields that must be
    consistent live here. The enable/disable toggle is a separate flat key
    (``auth_enabled``) so it can be flipped independently.

    MCP-specific fields (``mcp_base_url``, ``upstream_*``, ``mode``) are
    included here because the MCP auth provider is constructed from this
    config. Services without MCP leave these fields at their defaults.

    Instances are frozen — post-construction mutation raises ValidationError.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    jwks_uri: str | None = None
    issuer: str | None = None
    audience: str | None = None
    mode: AuthMode = AuthMode.JWT_VERIFIER

    # Claim mapping — controls how JWT claims become AuthContext fields and
    # Cedar principal attributes. Shared by both authn and authz layers.
    auto_map_claims: bool = False
    claim_map: dict[str, str] = Field(default_factory=dict)

    # MCP auth provider — public base URL for RFC 9728 metadata endpoint.
    # Required when mode=jwt_verifier and an MCP server is active.
    # Required when mode=oauth_proxy.
    mcp_base_url: str | None = None

    # OAuthProxy-only (when mode="oauth_proxy")
    upstream_authorization_endpoint: str | None = None
    upstream_token_endpoint: str | None = None
    upstream_client_id: str | None = None
    upstream_client_secret: SecretStr | None = None

    # Env var suffixes (without prefix) mapped to field names.
    # Used by AuthSettings.resolve() to apply per-field env var overrides.
    # Full env var: {prefix}AUTHN_{SUFFIX} e.g. COCO_RAG_AUTHN_JWKS_URI
    _ENV_SUFFIXES: ClassVar[dict[str, str]] = {
        "AUTHN_JWKS_URI": "jwks_uri",
        "AUTHN_ISSUER": "issuer",
        "AUTHN_AUDIENCE": "audience",
        "AUTHN_MODE": "mode",
        "AUTHN_AUTO_MAP_CLAIMS": "auto_map_claims",
        "AUTHN_CLAIM_MAP": "claim_map",
        "AUTHN_MCP_BASE_URL": "mcp_base_url",
        "AUTHN_UPSTREAM_AUTHORIZATION_ENDPOINT": "upstream_authorization_endpoint",
        "AUTHN_UPSTREAM_TOKEN_ENDPOINT": "upstream_token_endpoint",
        "AUTHN_UPSTREAM_CLIENT_ID": "upstream_client_id",
        "AUTHN_UPSTREAM_CLIENT_SECRET": "upstream_client_secret",
    }

    @field_validator(
        "jwks_uri", "issuer", "mcp_base_url", "upstream_authorization_endpoint", "upstream_token_endpoint", mode="before"
    )
    @classmethod
    def _require_https(cls, v: str | None) -> str | None:
        # The field validator has no access to the env prefix. It enforces
        # HTTPS strictly and respects the bare AUTHN_ALLOW_HTTP env var (no
        # prefix). Callers that need prefix-aware allow-HTTP (e.g. test
        # environments using COCO_RAG_AUTHN_ALLOW_HTTP) must use
        # AuthSettings.resolve(), which applies the prefix before building
        # the model. Direct construction (e.g. in tests) should either use
        # HTTPS URLs or set the unprefixed AUTHN_ALLOW_HTTP env var.
        return _validate_https_url(v)

    @model_validator(mode="after")
    def _validate_oauth_proxy_fields(self) -> AuthnConfig:
        if self.mode == AuthMode.OAUTH_PROXY:
            missing = [
                f
                for f in ("mcp_base_url", "upstream_authorization_endpoint", "upstream_token_endpoint", "upstream_client_id")
                if not getattr(self, f)
            ]
            if missing:
                raise ValueError(f"oauth_proxy mode requires: {', '.join(missing)}")
        return self


class AuthSettings(BaseModel):
    """Complete auth settings: authn toggle + config, authz toggle.

    Instances are frozen — post-construction mutation raises ValidationError.

    Note: AuthzConfig will be added in Phase 4 when atlas bundle pull
    fields (atlas_url, bundle_ttl) exist. Adding an empty model now would
    be structural noise with no current value.
    """

    model_config = ConfigDict(frozen=True)

    enabled: bool = False
    config: AuthnConfig = Field(default_factory=AuthnConfig)
    authz_enabled: bool = False

    @model_validator(mode="after")
    def _validate_enabled_requires_config(self) -> AuthSettings:
        """When auth is enabled, jwks_uri, issuer, and audience are all required."""
        if self.enabled:
            missing = [f for f in ("jwks_uri", "issuer", "audience") if not getattr(self.config, f)]
            if missing:
                raise ValueError(f"auth_enabled=true requires auth_config fields: {', '.join(missing)}")
        return self

    @classmethod
    def resolve(cls, *, env_prefix: str = "", seed: dict[str, Any] | None = None) -> AuthSettings:
        """Build AuthSettings from env vars with optional seed values.

        Args:
            env_prefix: Env var prefix for this consumer, e.g. ``"COCO_RAG_"``.
            seed: Optional pre-loaded values (e.g. from a DB settings table).
                  Expected keys:
                    ``authn_enabled`` (bool)  — AuthN toggle
                    ``authn_config``  (dict)  — AuthN config blob (AuthnConfig)
                    ``authz_enabled`` (bool)  — AuthZ toggle
                  Per-field resolution: env var > seed value > default.
                  Unexpected keys are ignored with a warning logged.
        """
        from loguru import logger

        seed = seed or {}

        unexpected = set(seed) - {"authn_enabled", "authn_config", "authz_enabled"}
        if unexpected:
            logger.warning("AuthSettings.resolve: unexpected seed keys ignored: {}", sorted(unexpected))

        enabled = _resolve(env_prefix, "AUTHN_ENABLED", seed.get("authn_enabled"), default=False)
        authz_enabled = _resolve(env_prefix, "AUTHZ_ENABLED", seed.get("authz_enabled"), default=False)

        seed_config = seed.get("authn_config")
        if seed_config is None:
            seed_config = {}
        elif not isinstance(seed_config, dict):
            logger.warning("AuthSettings.resolve: authn_config is not a dict ({}), ignoring", type(seed_config).__name__)
            seed_config = {}

        config_data = dict(seed_config)
        for suffix, field in AuthnConfig._ENV_SUFFIXES.items():
            _override_from_env(config_data, field, env_prefix, suffix)

        return cls(
            enabled=enabled,
            config=AuthnConfig.model_validate(config_data),
            authz_enabled=authz_enabled,
        )


def _resolve(env_prefix: str, env_suffix: str, seed_value: Any, *, default: Any = None) -> Any:
    """Return env var value if set, else seed value, else default."""
    env_val = os.environ.get(f"{env_prefix}{env_suffix}")
    if env_val is not None:
        return _parse_env_value(env_val)
    if seed_value is not None:
        return seed_value
    return default


def _override_from_env(config_data: dict, field: str, env_prefix: str, env_suffix: str) -> None:
    """Override a single field in config_data if the env var is set."""
    env_val = os.environ.get(f"{env_prefix}{env_suffix}")
    if env_val is not None:
        config_data[field] = _parse_env_value(env_val)


def _parse_env_value(val: str) -> Any:
    """Parse an env var string into a Python value."""
    lower = val.lower()
    if lower in ("true", "1", "yes"):
        return True
    if lower in ("false", "0", "no"):
        return False
    try:
        result = json.loads(val)
        if result is None:
            raise ValueError("Env var value 'null' is not supported — unset the variable to use the default")
        return result
    except json.JSONDecodeError:
        return val
