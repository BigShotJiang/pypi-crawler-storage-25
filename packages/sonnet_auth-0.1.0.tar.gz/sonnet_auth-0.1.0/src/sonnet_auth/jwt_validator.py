"""JwtCredentialValidator — validates JWT bearer tokens against a JWKS endpoint.

Uses joserfc (the successor to authlib.jose) — the same crypto library as
FastMCP's JWTVerifier, ensuring consistent token validation across both
REST and MCP transports.

JWKS keys are fetched synchronously at construction time. If the JWKS
endpoint is unreachable at startup, the validator starts with no keys
and returns None (→ 401) for every request until the TTL-based refresh
succeeds. This avoids a hard startup failure when the IdP is temporarily
unavailable during rolling deploys.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import httpx
from joserfc import jwt as joserfc_jwt
from joserfc.errors import JoseError
from joserfc.jwk import KeySet
from loguru import logger

from sonnet_auth.context import build_auth_context
from sonnet_server.guards import AuthContext, CredentialValidator

if TYPE_CHECKING:
    from sonnet_auth.settings import AuthConfig

# JWKS cache TTL in seconds — keys are re-fetched after this interval
_JWKS_CACHE_TTL = 3600


class JwtCredentialValidator(CredentialValidator):
    """Validates JWT bearer tokens (RS256/ES256) against a JWKS endpoint.

    Uses joserfc for consistent crypto with FastMCP's JWTVerifier.
    The ``jwks_client`` parameter is injectable for testing.

    Precondition: ``auth_config.jwks_uri`` must be non-None and HTTPS.
    This is enforced by ``AuthSettings`` validation before construction.
    """

    def __init__(
        self,
        auth_config: AuthConfig,
        *,
        key_set: KeySet | None = None,
    ) -> None:
        if not auth_config.jwks_uri:
            raise ValueError("JwtCredentialValidator requires auth_config.jwks_uri to be set")
        self._jwks_uri = auth_config.jwks_uri
        self._issuer = auth_config.issuer
        self._audience = auth_config.audience
        self._claim_map: dict[str, str] = auth_config.claim_map
        self._auto_map_claims: bool = auth_config.auto_map_claims

        if key_set is not None:
            # Injected key set (tests) — skip network fetch
            self._key_set: KeySet | None = key_set
        else:
            try:
                self._key_set = self._fetch_key_set()
            except RuntimeError as exc:
                # JWKS endpoint unreachable at startup — start with no keys.
                # All requests return 401 until the TTL refresh succeeds.
                logger.warning("JWKS fetch failed at startup — all requests will return 401 until resolved: {}", exc)
                self._key_set = None

        self._key_set_fetched_at = time.monotonic()

    def _fetch_key_set(self) -> KeySet:
        """Fetch JWKS from the configured endpoint synchronously."""
        try:
            response = httpx.get(self._jwks_uri, timeout=10.0)
            response.raise_for_status()
            key_set = KeySet.import_key_set(response.json())
            logger.trace("JWKS fetched successfully — {} key(s)", len(key_set.keys))
            return key_set
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Failed to fetch JWKS from {self._jwks_uri}: {exc}") from exc

    def _get_key_set(self) -> KeySet | None:
        """Return cached key set, refreshing if TTL has expired or no keys yet."""
        if self._key_set is None or time.monotonic() - self._key_set_fetched_at > _JWKS_CACHE_TTL:
            logger.debug("Fetching JWKS from {} ({})", self._jwks_uri, "retry" if self._key_set is None else "TTL expired")
            try:
                self._key_set = self._fetch_key_set()
                self._key_set_fetched_at = time.monotonic()
            except RuntimeError as exc:
                if self._key_set is not None:
                    logger.warning("JWKS refresh failed, using cached keys: {}", exc)
                else:
                    logger.warning("JWKS fetch failed — all requests will return 401: {}", exc)
        return self._key_set

    def validate(self, bearer_token: str) -> AuthContext | None:
        """Validate a bearer token. Returns AuthContext on success, None on failure.

        Returns None (→ 401) if no JWKS keys are available yet.
        """
        try:
            key_set = self._get_key_set()
            if key_set is None:
                logger.debug("JWT validation skipped — no JWKS keys available")
                return None
            token = joserfc_jwt.decode(bearer_token, key_set, algorithms=["RS256", "ES256"])

            claims_registry = joserfc_jwt.JWTClaimsRegistry(
                sub={"essential": True},
                exp={"essential": True},
                **({} if self._issuer is None else {"iss": {"essential": True, "value": self._issuer}}),
                **({} if self._audience is None else {"aud": {"essential": True, "value": self._audience}}),
            )
            claims_registry.validate(token.claims)

            ctx = build_auth_context(token.claims, self._claim_map, auto_map_claims=self._auto_map_claims)
            logger.trace(
                "JWT validated: user={} iss={} aud={}",
                ctx.user_id,
                token.claims.get("iss"),
                token.claims.get("aud"),
            )
            return ctx
        except JoseError as exc:
            logger.debug("JWT validation failed: {}", exc)
            return None
        except RuntimeError as exc:
            logger.warning("JWKS error during token validation: {}", exc)
            return None
        except (KeyError, AttributeError) as exc:
            # Configuration error (e.g. malformed claim_map, unexpected claims shape).
            # Re-raise so misconfigurations surface clearly rather than silently
            # producing 401 responses that look like invalid tokens.
            raise RuntimeError(f"Auth configuration error during token validation: {exc}") from exc
