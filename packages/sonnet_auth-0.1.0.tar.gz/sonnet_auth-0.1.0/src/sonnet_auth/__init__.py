"""sonnet-auth -- JWT/JWKS authentication and Cedar authorization for sonnet-server.

Public API:

  AuthN (JWT/JWKS):
    AuthSettings            -- settings model with resolve(env_prefix, seed)
    AuthnConfig             -- JWT/JWKS config (Pydantic, frozen)
    AuthMode                -- jwt_verifier | oauth_proxy
    JwtCredentialValidator   -- implements sonnet-server CredentialValidator protocol
    build_auth_context      -- JWT claims -> AuthContext
    resolve_attributes      -- JWT claims -> Cedar principal attributes
    resolve_dot_path        -- nested claim extraction

  AuthZ (Cedar, requires sonnet-auth[cedar]):
    AuthzDeniedError        -- raised by check_authz on deny; transports map to 403
    check_authz             -- raises AuthzDeniedError on deny, no-op if disabled
    filter_authz            -- returns permitted resource IDs
    resolve_principal_attrs -- resolves JWT claims + enrichment -> Cedar attrs
    set_resource_attribute_resolver -- register domain-specific resolver
    set_principal_enricher  -- register principal enricher (org hierarchy, etc.)
    ResourceAttributeResolver -- protocol for resource attr lookup
    PrincipalEnricher       -- protocol for principal attr enrichment
    PolicyEngine            -- Cedar policy evaluator (check, filter, reload)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# AuthN -- always available
from sonnet_auth.context import build_auth_context, resolve_attributes, resolve_dot_path
from sonnet_auth.jwt_validator import JwtCredentialValidator
from sonnet_auth.settings import AuthMode, AuthnConfig, AuthSettings

if TYPE_CHECKING:
    # Expose Cedar types for static analysis tools (mypy, pyright, IDEs).
    # These are lazily imported at runtime to avoid cedarpy dependency
    # when only authn is used.
    from sonnet_auth.authz import (
        AuthzDeniedError,
        PrincipalEnricher,
        ResourceAttributeResolver,
        check_authz,
        filter_authz,
        resolve_principal_attrs,
        set_principal_enricher,
        set_resource_attribute_resolver,
    )
    from sonnet_auth.policy_engine import PolicyEngine

__all__ = [
    # AuthN
    "AuthMode",
    "AuthnConfig",
    "AuthSettings",
    "JwtCredentialValidator",
    "build_auth_context",
    "resolve_attributes",
    "resolve_dot_path",
    # AuthZ (lazy -- imported on use to avoid cedarpy import at module level)
    "AuthzDeniedError",
    "PolicyEngine",
    "PrincipalEnricher",
    "ResourceAttributeResolver",
    "check_authz",
    "filter_authz",
    "resolve_principal_attrs",
    "set_principal_enricher",
    "set_resource_attribute_resolver",
]


def __getattr__(name: str):
    """Lazy imports for Cedar authz -- avoids cedarpy import when only using authn."""
    if name == "PolicyEngine":
        from sonnet_auth.policy_engine import PolicyEngine

        return PolicyEngine
    if name in (
        "AuthzDeniedError",
        "PrincipalEnricher",
        "ResourceAttributeResolver",
        "check_authz",
        "filter_authz",
        "resolve_principal_attrs",
        "set_principal_enricher",
        "set_resource_attribute_resolver",
    ):
        from sonnet_auth import authz

        return getattr(authz, name)
    raise AttributeError(f"module 'sonnet_auth' has no attribute {name!r}")
