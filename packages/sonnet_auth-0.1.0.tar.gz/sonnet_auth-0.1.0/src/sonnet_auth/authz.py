"""AuthZ helpers — one-liner authorization for REST handlers and MCP tools.

This module is the single entry point for authorization checks. It hides
all internal plumbing (claim resolution, principal enrichment, Cedar
evaluation) behind two stable functions:

  check_authz()   — raises 403 on deny, no-op if authz disabled
  filter_authz()  — returns permitted resource IDs, returns all if disabled

Resource attribute resolution is pluggable via ``ResourceAttributeResolver``.
Register the consumer's implementation once at startup:

    from sonnet_auth.authz import set_resource_attribute_resolver
    set_resource_attribute_resolver(PropertiesCacheResolver())

The caller API (check_authz / filter_authz) never changes regardless of the
resolver, enrichment, or Cedar evaluation happening behind the scenes.

Internal flow:
  1. get_policy_engine()                  → engine or None (no-op if disabled)
  2. get_current_auth()                   → AuthContext (identity from JWT)
  3. resolve_attributes(claims, claim_map) → base attrs from token
  4. PrincipalEnricher.enrich()           → enriched attrs (if registered)
  5. resolver.resolve(type, id)           → resource attrs
  6. engine.check() / engine.filter()    → Cedar evaluation
"""

from __future__ import annotations

from typing import Any, Protocol

from loguru import logger

from sonnet_auth.context import resolve_attributes
from sonnet_auth.policy_engine import PolicyEngine
from sonnet_server.guards import get_current_auth
from sonnet_server.services.registry import get_service_registry

# ---------------------------------------------------------------------------
# ResourceAttributeResolver — pluggable resource attribute lookup
# ---------------------------------------------------------------------------


class ResourceAttributeResolver(Protocol):
    """Maps a resource type + ID to Cedar entity attributes.

    Implement this protocol in each consumer and register it at startup
    via ``set_resource_attribute_resolver()``. coco-rag's implementation
    uses ``PropertiesCache`` backed by the PostgreSQL settings table.

    Returns an empty dict when no attributes are found — Cedar policies
    that require ABAC attributes will deny by default.
    """

    def resolve(self, resource_type: str, resource_id: str) -> dict[str, Any]: ...


_resource_attribute_resolver: ResourceAttributeResolver | None = None


def set_resource_attribute_resolver(resolver: ResourceAttributeResolver) -> None:
    """Register the resource attribute resolver. Call once at startup."""
    global _resource_attribute_resolver  # noqa: PLW0603
    _resource_attribute_resolver = resolver


# ---------------------------------------------------------------------------
# PrincipalEnricher — pluggable principal attribute enrichment
# ---------------------------------------------------------------------------


class PrincipalEnricher(Protocol):
    """Enriches resolved JWT claim attributes before Cedar evaluation.

    Implement this protocol to add org hierarchy, group expansion, or remote
    attribute lookups. Register it via ``set_principal_enricher()``.

    The default (no enricher registered) is a no-op — attrs pass through
    unchanged.
    """

    def enrich(self, user_id: str, attrs: dict[str, Any]) -> dict[str, Any]: ...


_principal_enricher: PrincipalEnricher | None = None


def set_principal_enricher(enricher: PrincipalEnricher) -> None:
    """Register the principal enricher. Call once at startup."""
    global _principal_enricher  # noqa: PLW0603
    _principal_enricher = enricher


# ---------------------------------------------------------------------------
# Engine resolution
# ---------------------------------------------------------------------------


def get_policy_engine() -> PolicyEngine | None:
    """Return PolicyEngine if authz enabled, None if not configured."""
    try:
        return get_service_registry().get(PolicyEngine)
    except KeyError:
        return None


def resolve_principal_attrs(engine: PolicyEngine, user_id: str, claims: dict) -> dict[str, Any]:
    """Resolve claim_map attrs and run principal enrichment.

    Both ``claim_map`` and ``auto_map_claims`` come from the engine (set at
    construction from AuthnConfig). No DB access — safe in tests and CI.

    Public — used by the /authz/check dry-run endpoint.
    """
    attrs = resolve_attributes(claims, engine.claim_map, auto_map_claims=engine.auto_map_claims)
    if _principal_enricher is not None:
        attrs = _principal_enricher.enrich(user_id, attrs)
    logger.trace("Principal attrs resolved: user={} attrs={}", user_id, attrs)
    return attrs


# ---------------------------------------------------------------------------
# Resource attribute resolution
# ---------------------------------------------------------------------------


def _resolve_resource_attrs(resource_type: str, resource_id: str, resource_attrs: dict[str, Any] | None) -> dict[str, Any]:
    """Resolve resource attributes — explicit attrs take priority, then resolver."""
    if resource_attrs is not None:
        return resource_attrs
    if _resource_attribute_resolver is not None:
        return _resource_attribute_resolver.resolve(resource_type, resource_id)
    return {}


# ---------------------------------------------------------------------------
# Public API — stable forever
# ---------------------------------------------------------------------------


class AuthzDeniedError(Exception):
    """Raised when Cedar policy evaluation denies an action.

    Transport layers (REST, MCP) catch this and convert it to the appropriate
    response -- ``HTTPException(403)`` for REST, a tool error for MCP.

    In practice, sonnet-server's REST handlers register an exception handler
    that converts ``AuthzDeniedError`` to 403, so callers that use
    ``check_authz`` in REST handlers need not catch it explicitly.
    """

    def __init__(self, action: str, resource_type: str, resource_id: str) -> None:
        super().__init__(f"Forbidden: {action} on {resource_type}/{resource_id}")
        self.action = action
        self.resource_type = resource_type
        self.resource_id = resource_id


def check_authz(
    action: str,
    resource_type: str,
    resource_id: str,
    resource_attrs: dict[str, Any] | None = None,
) -> None:
    """Check Cedar policy — raises AuthzDeniedError on deny, no-op if authz disabled.

    Call at the top of any REST handler or MCP tool that accesses a resource.
    Resource properties are resolved automatically via the registered
    ``ResourceAttributeResolver`` unless ``resource_attrs`` is explicitly provided.

    Callers in REST handlers do not need to catch ``AuthzDeniedError`` —
    the transport layer converts it to HTTP 403 via the registered exception
    handler. MCP tool handlers should catch it and return a tool error.
    """
    engine = get_policy_engine()
    if not engine:
        return
    auth = get_current_auth()
    principal_attrs = resolve_principal_attrs(engine, auth.user_id, auth.claims)
    resolved_attrs = _resolve_resource_attrs(resource_type, resource_id, resource_attrs)
    if not engine.check(auth.user_id, principal_attrs, action, resource_type, resource_id, resolved_attrs):
        logger.info(
            "AuthZ denied: user={} action={} resource={}/{}{}",
            auth.user_id,
            action,
            resource_type,
            resource_id,
            f" resource_attrs={resolved_attrs}" if resolved_attrs else "",
        )
        raise AuthzDeniedError(action, resource_type, resource_id)


def filter_authz(
    action: str,
    resource_type: str,
    resources: list[tuple[str, dict[str, Any]]] | list[str],
) -> set[str]:
    """Filter to permitted resource IDs — returns all IDs if authz disabled.

    Accepts either ``[(id, attrs), ...]`` or ``[id, ...]``. When attrs are
    not provided, they are resolved automatically via the registered
    ``ResourceAttributeResolver``. Enrichment is applied once per call.
    """
    if not resources:
        return set()

    engine = get_policy_engine()
    if not engine:
        if isinstance(resources[0], str):
            return set(resources)
        return {rid for rid, _ in resources}

    # Normalise input to [(id, attrs)] pairs
    if isinstance(resources[0], str):
        pairs = [(rid, _resolve_resource_attrs(resource_type, rid, None)) for rid in resources]
    else:
        pairs = [(rid, _resolve_resource_attrs(resource_type, rid, attrs)) for rid, attrs in resources]

    auth = get_current_auth()
    principal_attrs = resolve_principal_attrs(engine, auth.user_id, auth.claims)
    return set(engine.filter(auth.user_id, principal_attrs, action, resource_type, pairs))
