"""PolicyEngine — Cedar-based authorization evaluation.

Pure evaluator: receives validated policies + schema at construction,
performs no I/O. Loading from the settings table is the caller's
responsibility (see services/di.py).

The engine exposes two operations:

  check()   — permit/deny a single (principal, action, resource) triple
  filter()  — from a list of (resource_id, resource_attrs) pairs, return
               only the IDs the principal is permitted to act on.
               Uses is_authorized_batch() internally — one Cedar call for
               the entire list, not N individual calls.

Principal attributes and resource attributes are always provided by the
caller (authz helpers). The engine never resolves claims, never runs
enrichers, never fetches anything — it is a pure function of its inputs.
"""

from __future__ import annotations

from typing import Any

from cedarpy import is_authorized, is_authorized_batch, validate_policies
from loguru import logger

# Cedar entity type name for principals — must match the schema
_TYPE_USER = "User"


class PolicyEngine:
    """Cedar policy evaluator.

    Construction validates policies against the schema and raises
    ``ValueError`` immediately if validation fails — fail fast at startup,
    not at first request.

    Stores ``claim_map`` as a read-only property for the authz helpers to
    read — the engine itself never uses it.
    """

    def __init__(
        self,
        policies: str,
        schema: str,
        claim_map: dict[str, str] | None = None,
        auto_map_claims: bool = False,
    ) -> None:
        result = validate_policies(policies, schema)
        if not result.validation_passed:
            raise ValueError(f"Cedar policy validation failed: {result.errors}")

        self._policies = policies
        self._claim_map: dict[str, str] = claim_map or {}
        self._auto_map_claims: bool = auto_map_claims
        logger.info("PolicyEngine initialised — Cedar policies validated successfully")

    @property
    def claim_map(self) -> dict[str, str]:
        """JWT claim dot-paths → Cedar attribute names. Read by authz helpers."""
        return self._claim_map

    @property
    def auto_map_claims(self) -> bool:
        """Whether to pass all top-level JWT claims as Cedar attributes. Read by authz helpers."""
        return self._auto_map_claims

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def reload(self, policies: str, schema: str) -> None:
        """Replace policies and schema. Validates before swapping — old policies
        stay active if validation fails.

        Raises:
            ValueError: If the new policies fail validation against the schema.
        """
        result = validate_policies(policies, schema)
        if not result.validation_passed:
            raise ValueError(f"Cedar policy validation failed: {result.errors}")
        self._policies = policies
        logger.info("PolicyEngine reloaded — new Cedar policies validated and active")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(
        self,
        user_id: str,
        principal_attrs: dict[str, Any],
        action: str,
        resource_type: str,
        resource_id: str,
        resource_attrs: dict[str, Any] | None = None,
    ) -> bool:
        """Return True if the principal is permitted to perform action on resource.

        Args:
            user_id:         Principal entity ID (from AuthContext.user_id).
            principal_attrs: Pre-built principal attributes (from authz helpers).
            action:          Cedar action name (e.g. "search", "configure").
            resource_type:   Cedar entity type (e.g. "Topic", "Source").
            resource_id:     Resource identifier (e.g. "backend", "my-repo").
            resource_attrs:  Resource attributes for ABAC. Empty dict or None for RBAC.
        """
        entities = [
            _build_principal_entity(user_id, principal_attrs),
            _build_resource_entity(resource_type, resource_id, resource_attrs or {}),
        ]
        request = _build_request(user_id, action, resource_type, resource_id)
        logger.trace(
            "Cedar check: principal={} principal_attrs={} action={} resource={}/{} resource_attrs={}",
            user_id,
            principal_attrs,
            action,
            resource_type,
            resource_id,
            resource_attrs or {},
        )
        result = is_authorized(request, self._policies, entities)

        decision = "ALLOW" if result.allowed else "DENY"
        logger.debug(
            "PolicyEngine.check: user={} action={} resource={}/{} → {}",
            user_id,
            action,
            resource_type,
            resource_id,
            decision,
        )
        if not result.allowed:
            logger.trace("PolicyEngine deny diagnostics: {}", result.diagnostics)
        return result.allowed

    def filter(
        self,
        user_id: str,
        principal_attrs: dict[str, Any],
        action: str,
        resource_type: str,
        resources: list[tuple[str, dict[str, Any]]],
    ) -> list[str]:
        """Return the subset of resource IDs the principal is permitted to act on.

        Uses is_authorized_batch() for efficiency — one Cedar evaluation
        call regardless of list length.

        Args:
            user_id:         Principal entity ID.
            principal_attrs: Pre-built principal attributes.
            action:          Cedar action name.
            resource_type:   Cedar entity type ("Topic" or "Source").
            resources:       List of (resource_id, resource_attrs) pairs.

        Returns:
            List of permitted resource IDs (preserves input order).
        """
        if not resources:
            return []

        entities = [_build_principal_entity(user_id, principal_attrs)] + [
            _build_resource_entity(resource_type, rid, attrs) for rid, attrs in resources
        ]
        requests = [_build_request(user_id, action, resource_type, rid) for rid, _ in resources]
        logger.trace(
            "Cedar filter: principal={} principal_attrs={} action={} type={} resources={}",
            user_id,
            principal_attrs,
            action,
            resource_type,
            [(rid, attrs) for rid, attrs in resources],
        )
        results = is_authorized_batch(requests=requests, policies=self._policies, entities=entities)
        permitted = [rid for (rid, _), result in zip(resources, results, strict=True) if result.allowed]

        logger.debug(
            "PolicyEngine.filter: user={} action={} type={} total={} permitted={}",
            user_id,
            action,
            resource_type,
            len(resources),
            len(permitted),
        )
        if len(permitted) < len(resources):
            denied = [rid for rid in (r[0] for r in resources) if rid not in set(permitted)]
            logger.trace("PolicyEngine filter denied resources: {}", denied)
        return permitted


# ------------------------------------------------------------------
# Entity / request builders (module-level — no state, easy to test)
# ------------------------------------------------------------------


def _build_principal_entity(user_id: str, attrs: dict[str, Any]) -> dict:
    """Build a Cedar User entity from pre-built attributes."""
    return {
        "uid": {"__entity": {"type": _TYPE_USER, "id": user_id}},
        "attrs": attrs,
        "parents": [],
    }


def _build_resource_entity(resource_type: str, resource_id: str, attrs: dict[str, Any]) -> dict:
    """Build a Cedar resource entity (Topic, Source, etc.)."""
    return {
        "uid": {"__entity": {"type": resource_type, "id": resource_id}},
        "attrs": attrs,
        "parents": [],
    }


def _build_request(user_id: str, action: str, resource_type: str, resource_id: str) -> dict:
    """Build a Cedar authorization request dict.

    Cedar entity references use ``Type::"id"`` syntax — embedded double
    quotes would break parsing.  User-controlled values (user_id from JWT
    ``sub``, resource_id from tool args) are checked defensively here.
    """
    for name, value in (("user_id", user_id), ("resource_id", resource_id)):
        if '"' in value:
            raise ValueError(f"Cedar entity ID must not contain double quotes: {name}={value!r}")
    return {
        "principal": f'{_TYPE_USER}::"{user_id}"',
        "action": f'Action::"{action}"',
        "resource": f'{resource_type}::"{resource_id}"',
        "context": {},
    }
