"""Unit tests for PolicyEngine — Cedar authorization evaluation."""

from __future__ import annotations

import pytest

from sonnet_auth.policy_engine import (
    PolicyEngine,
    _build_principal_entity,
    _build_request,
    _build_resource_entity,
)

# ---------------------------------------------------------------------------
# Fixtures — Cedar artifacts
# ---------------------------------------------------------------------------

_SCHEMA = """
{
  "": {
    "entityTypes": {
      "User": {
        "shape": {
          "type": "Record",
          "attributes": {
            "roles": { "type": "Set", "element": { "type": "String" } },
            "org_id": { "type": "String", "required": false },
            "email":  { "type": "String", "required": false },
            "tenant_id": { "type": "String", "required": false }
          }
        }
      },
      "Topic":  { "shape": { "type": "Record", "attributes": {} } },
      "Source": { "shape": { "type": "Record", "attributes": {} } }
    },
    "actions": {
      "search":    { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Topic", "Source"] } },
      "list":      { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Topic", "Source"] } },
      "get_file":  { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Source"] } },
      "grep":      { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Source", "Topic"] } },
      "configure": { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Source"] } },
      "drop":      { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Source"] } }
    }
  }
}
"""

_POLICIES_RBAC = """
permit(
  principal,
  action in [Action::"search", Action::"list", Action::"get_file", Action::"grep"],
  resource
)
when { principal.roles.contains("reader") };

permit(
  principal,
  action in [Action::"configure", Action::"drop"],
  resource
)
when { principal.roles.contains("admin") };
"""

_POLICIES_PLATFORM_ADMIN = """
permit(principal, action, resource)
when { principal.roles.contains("platform_admin") };
"""

_INVALID_POLICIES = """
permit(principal, action, resource)
when { principal.nonexistent_attribute == "x" };
"""


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestPolicyEngineConstruction:
    def test_valid_policies_and_schema_accepted(self):
        engine = PolicyEngine(_POLICIES_RBAC, _SCHEMA)
        assert engine is not None

    def test_invalid_policies_raise_on_construction(self):
        with pytest.raises(ValueError, match="Cedar policy validation failed"):
            PolicyEngine(_INVALID_POLICIES, _SCHEMA)

    def test_empty_policies_accepted_deny_all(self):
        engine = PolicyEngine("", _SCHEMA)
        assert engine.check("alice", {"roles": ["reader"]}, "search", "Topic", "backend") is False

    def test_claim_map_exposed_as_property(self):
        engine = PolicyEngine(_POLICIES_RBAC, _SCHEMA, claim_map={"roles": "roles"})
        assert engine.claim_map == {"roles": "roles"}

    def test_no_claim_map_defaults_to_empty(self):
        engine = PolicyEngine(_POLICIES_RBAC, _SCHEMA)
        assert engine.claim_map == {}


# ---------------------------------------------------------------------------
# reload()
# ---------------------------------------------------------------------------


class TestPolicyEngineReload:
    def test_reload_swaps_policies(self):
        engine = PolicyEngine(_POLICIES_RBAC, _SCHEMA)
        attrs = {"roles": ["platform_admin"]}
        assert engine.check("alice", attrs, "search", "Topic", "backend") is False

        engine.reload(_POLICIES_PLATFORM_ADMIN, _SCHEMA)
        assert engine.check("alice", attrs, "search", "Topic", "backend") is True

    def test_reload_invalid_policies_keeps_old(self):
        engine = PolicyEngine(_POLICIES_RBAC, _SCHEMA)
        attrs = {"roles": ["reader"]}
        assert engine.check("alice", attrs, "search", "Topic", "backend") is True

        with pytest.raises(ValueError, match="Cedar policy validation failed"):
            engine.reload(_INVALID_POLICIES, _SCHEMA)

        assert engine.check("alice", attrs, "search", "Topic", "backend") is True

    def test_reload_valid_then_check(self):
        engine = PolicyEngine("", _SCHEMA)
        attrs = {"roles": ["reader"]}
        assert engine.check("alice", attrs, "search", "Topic", "backend") is False

        engine.reload(_POLICIES_RBAC, _SCHEMA)
        assert engine.check("alice", attrs, "search", "Topic", "backend") is True


# ---------------------------------------------------------------------------
# check() — RBAC
# ---------------------------------------------------------------------------


class TestPolicyEngineCheck:
    @pytest.fixture(scope="class")
    def engine(self):
        return PolicyEngine(_POLICIES_RBAC, _SCHEMA)

    def test_reader_can_search(self, engine):
        assert engine.check("alice", {"roles": ["reader"]}, "search", "Topic", "backend") is True

    def test_reader_can_list(self, engine):
        assert engine.check("alice", {"roles": ["reader"]}, "list", "Source", "my-repo") is True

    def test_reader_cannot_configure(self, engine):
        assert engine.check("alice", {"roles": ["reader"]}, "configure", "Source", "my-repo") is False

    def test_admin_can_configure(self, engine):
        assert engine.check("bob", {"roles": ["admin"]}, "configure", "Source", "my-repo") is True

    def test_admin_cannot_search_without_reader_role(self, engine):
        assert engine.check("bob", {"roles": ["admin"]}, "search", "Topic", "backend") is False

    def test_admin_and_reader_can_do_both(self, engine):
        attrs = {"roles": ["admin", "reader"]}
        assert engine.check("carol", attrs, "search", "Topic", "backend") is True
        assert engine.check("carol", attrs, "configure", "Source", "my-repo") is True

    def test_no_roles_denied_everything(self, engine):
        assert engine.check("anon", {"roles": []}, "search", "Topic", "backend") is False
        assert engine.check("anon", {"roles": []}, "configure", "Source", "my-repo") is False

    def test_resource_attrs_ignored_in_rbac(self, engine):
        assert (
            engine.check("alice", {"roles": ["reader"]}, "search", "Topic", "backend", resource_attrs={"org_id": "acme"}) is True
        )

    def test_different_resource_ids_same_result_rbac(self, engine):
        attrs = {"roles": ["reader"]}
        assert engine.check("alice", attrs, "search", "Topic", "backend") is True
        assert engine.check("alice", attrs, "search", "Topic", "frontend") is True


# ---------------------------------------------------------------------------
# filter() — batch RBAC
# ---------------------------------------------------------------------------


class TestPolicyEngineFilter:
    @pytest.fixture(scope="class")
    def engine(self):
        return PolicyEngine(_POLICIES_RBAC, _SCHEMA)

    def test_reader_can_search_all_topics(self, engine):
        resources = [("backend", {}), ("frontend", {}), ("infra", {})]
        result = engine.filter("alice", {"roles": ["reader"]}, "search", "Topic", resources)
        assert result == ["backend", "frontend", "infra"]

    def test_non_reader_filtered_out_entirely(self, engine):
        resources = [("backend", {}), ("frontend", {})]
        result = engine.filter("anon", {"roles": []}, "search", "Topic", resources)
        assert result == []

    def test_empty_resources_returns_empty(self, engine):
        assert engine.filter("alice", {"roles": ["reader"]}, "search", "Topic", []) == []

    def test_preserves_input_order(self, engine):
        resources = [("c", {}), ("a", {}), ("b", {})]
        result = engine.filter("alice", {"roles": ["reader"]}, "search", "Topic", resources)
        assert result == ["c", "a", "b"]

    def test_admin_filter_configure(self, engine):
        resources = [("repo-1", {}), ("repo-2", {})]
        result = engine.filter("bob", {"roles": ["admin"]}, "configure", "Source", resources)
        assert result == ["repo-1", "repo-2"]

    def test_reader_filtered_from_configure(self, engine):
        resources = [("repo-1", {}), ("repo-2", {})]
        result = engine.filter("alice", {"roles": ["reader"]}, "configure", "Source", resources)
        assert result == []


# ---------------------------------------------------------------------------
# filter() — ABAC
# ---------------------------------------------------------------------------

_SCHEMA_ABAC = """
{
  "": {
    "entityTypes": {
      "User": {
        "shape": {
          "type": "Record",
          "attributes": {
            "org_id": { "type": "String" }
          }
        }
      },
      "Topic": {
        "shape": {
          "type": "Record",
          "attributes": {
            "org_id": { "type": "String" }
          }
        }
      }
    },
    "actions": {
      "search": { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Topic"] } }
    }
  }
}
"""

_POLICIES_ABAC = """
permit(principal, action == Action::"search", resource)
when { principal.org_id == resource.org_id };
"""


class TestPolicyEngineFilterABAC:
    @pytest.fixture(scope="class")
    def engine(self):
        return PolicyEngine(_POLICIES_ABAC, _SCHEMA_ABAC)

    def test_partial_filter_by_org(self, engine):
        resources = [
            ("backend", {"org_id": "acme"}),
            ("secret-project", {"org_id": "other-corp"}),
            ("frontend", {"org_id": "acme"}),
        ]
        result = engine.filter("alice", {"org_id": "acme"}, "search", "Topic", resources)
        assert result == ["backend", "frontend"]

    def test_no_match_filters_all(self, engine):
        resources = [("backend", {"org_id": "acme"}), ("infra", {"org_id": "acme"})]
        result = engine.filter("bob", {"org_id": "nobody"}, "search", "Topic", resources)
        assert result == []

    def test_all_match(self, engine):
        resources = [("a", {"org_id": "acme"}), ("b", {"org_id": "acme"})]
        result = engine.filter("carol", {"org_id": "acme"}, "search", "Topic", resources)
        assert result == ["a", "b"]


# ---------------------------------------------------------------------------
# Entity / request builders
# ---------------------------------------------------------------------------


class TestBuildPrincipalEntity:
    def test_basic_structure(self):
        entity = _build_principal_entity("alice", {"roles": ["reader"]})
        assert entity["uid"] == {"__entity": {"type": "User", "id": "alice"}}
        assert entity["attrs"] == {"roles": ["reader"]}
        assert entity["parents"] == []

    def test_empty_attrs(self):
        entity = _build_principal_entity("alice", {})
        assert entity["attrs"] == {}


class TestBuildResourceEntity:
    def test_basic_structure(self):
        entity = _build_resource_entity("Topic", "backend", {})
        assert entity["uid"] == {"__entity": {"type": "Topic", "id": "backend"}}
        assert entity["attrs"] == {}
        assert entity["parents"] == []

    def test_attrs_passed_through(self):
        entity = _build_resource_entity("Source", "my-repo", {"org_id": "acme", "sensitivity": "internal"})
        assert entity["attrs"] == {"org_id": "acme", "sensitivity": "internal"}


class TestBuildRequest:
    def test_structure(self):
        req = _build_request("alice", "search", "Topic", "backend")
        assert req["principal"] == 'User::"alice"'
        assert req["action"] == 'Action::"search"'
        assert req["resource"] == 'Topic::"backend"'
        assert req["context"] == {}

    def test_user_id_with_special_chars(self):
        req = _build_request("user@example.com", "list", "Source", "repo-1")
        assert req["principal"] == 'User::"user@example.com"'

    def test_user_id_with_quotes_raises(self):
        with pytest.raises(ValueError, match="must not contain double quotes"):
            _build_request('alice"', "search", "Topic", "backend")

    def test_resource_id_with_quotes_raises(self):
        with pytest.raises(ValueError, match="must not contain double quotes"):
            _build_request("alice", "search", "Topic", 'back"end')
