"""Unit tests for AuthSettings and AuthnConfig — Pydantic validation and env var resolution."""

import pytest
from pydantic import ValidationError

from sonnet_auth.settings import AuthMode, AuthnConfig, AuthSettings, _parse_env_value

_PREFIX = "COCO_RAG_"


# ---------------------------------------------------------------------------
# _parse_env_value
# ---------------------------------------------------------------------------


class TestParseEnvValue:
    def test_true_variants(self):
        for val in ("true", "True", "TRUE", "1", "yes"):
            assert _parse_env_value(val) is True

    def test_false_variants(self):
        for val in ("false", "False", "FALSE", "0", "no"):
            assert _parse_env_value(val) is False

    def test_json_object(self):
        assert _parse_env_value('{"org_id": "org_id"}') == {"org_id": "org_id"}

    def test_json_array(self):
        assert _parse_env_value('["a", "b"]') == ["a", "b"]

    def test_plain_string(self):
        assert _parse_env_value("https://example.com") == "https://example.com"

    def test_integer(self):
        assert _parse_env_value("42") == 42

    def test_null_raises(self):
        with pytest.raises(ValueError, match="null.*not supported"):
            _parse_env_value("null")


# ---------------------------------------------------------------------------
# AuthnConfig validation
# ---------------------------------------------------------------------------


class TestAuthnConfigDefaults:
    def test_all_defaults(self):
        cfg = AuthnConfig()
        assert cfg.jwks_uri is None
        assert cfg.issuer is None
        assert cfg.audience is None
        assert cfg.mode == AuthMode.JWT_VERIFIER
        assert cfg.claim_map == {}

    def test_frozen(self):
        cfg = AuthnConfig()
        with pytest.raises(ValidationError):
            cfg.mode = AuthMode.OAUTH_PROXY  # type: ignore[misc]

    def test_extra_fields_rejected(self):
        with pytest.raises(ValidationError):
            AuthnConfig.model_validate({"unknown_field": "value"})


class TestAuthnConfigUrlValidation:
    def test_jwks_uri_must_be_https(self):
        with pytest.raises(ValueError):
            AuthnConfig(jwks_uri="http://insecure.com/jwks")

    def test_jwks_uri_https_accepted(self):
        cfg = AuthnConfig(jwks_uri="https://idp.example.com/jwks")
        assert cfg.jwks_uri == "https://idp.example.com/jwks"

    def test_issuer_must_be_https(self):
        with pytest.raises(ValueError):
            AuthnConfig(issuer="http://insecure.com")

    def test_upstream_endpoints_must_be_https(self):
        with pytest.raises(ValueError):
            AuthnConfig(
                mode="oauth_proxy",
                upstream_authorization_endpoint="http://insecure/authorize",
                upstream_token_endpoint="https://ok/token",
                upstream_client_id="id",
            )


class TestAuthnConfigOAuthProxy:
    def test_requires_upstream_fields(self):
        with pytest.raises(ValueError, match="oauth_proxy mode requires"):
            AuthnConfig(mode="oauth_proxy")

    def test_valid_oauth_proxy(self):
        cfg = AuthnConfig(
            mode="oauth_proxy",
            mcp_base_url="https://coco-rag.example.com",
            upstream_authorization_endpoint="https://idp/authorize",
            upstream_token_endpoint="https://idp/token",
            upstream_client_id="my-client",
        )
        assert cfg.mode == AuthMode.OAUTH_PROXY

    def test_jwt_verifier_does_not_require_upstream(self):
        cfg = AuthnConfig(mode="jwt_verifier")
        assert cfg.upstream_authorization_endpoint is None


class TestAuthnConfigSecretStr:
    def test_client_secret_hidden_in_repr(self):
        cfg = AuthnConfig(
            mode="oauth_proxy",
            mcp_base_url="https://coco-rag.example.com",
            upstream_authorization_endpoint="https://idp/authorize",
            upstream_token_endpoint="https://idp/token",
            upstream_client_id="client",
            upstream_client_secret="my-secret",
        )
        assert "my-secret" not in repr(cfg)
        assert cfg.upstream_client_secret.get_secret_value() == "my-secret"


# ---------------------------------------------------------------------------
# AuthSettings validation
# ---------------------------------------------------------------------------


class TestAuthSettingsValidation:
    def test_disabled_without_config_accepted(self):
        auth = AuthSettings(enabled=False)
        assert auth.config.jwks_uri is None

    def test_enabled_without_jwks_uri_rejected(self):
        with pytest.raises(ValueError, match="jwks_uri"):
            AuthSettings(enabled=True, config=AuthnConfig())

    def test_enabled_without_issuer_rejected(self):
        with pytest.raises(ValueError, match="issuer"):
            AuthSettings(enabled=True, config=AuthnConfig(jwks_uri="https://idp/jwks", audience="aud"))

    def test_enabled_without_audience_rejected(self):
        with pytest.raises(ValueError, match="audience"):
            AuthSettings(enabled=True, config=AuthnConfig(jwks_uri="https://idp/jwks", issuer="https://idp"))

    def test_enabled_with_all_required_accepted(self):
        auth = AuthSettings(
            enabled=True,
            config=AuthnConfig(jwks_uri="https://idp/jwks", issuer="https://idp", audience="coco-rag"),
        )
        assert auth.enabled is True

    def test_frozen(self):
        auth = AuthSettings()
        with pytest.raises(ValidationError):
            auth.enabled = True  # type: ignore[misc]

    def test_authz_enabled_on_auth_settings(self):
        auth = AuthSettings(authz_enabled=True)
        assert auth.authz_enabled is True

    def test_authz_enabled_default_false(self):
        auth = AuthSettings()
        assert auth.authz_enabled is False


# ---------------------------------------------------------------------------
# AuthSettings.resolve
# ---------------------------------------------------------------------------


class TestAuthSettingsResolve:
    def test_defaults_when_no_seed(self):
        auth = AuthSettings.resolve(env_prefix=_PREFIX)
        assert auth.enabled is False
        assert auth.config.jwks_uri is None

    def test_loads_from_seed(self, monkeypatch):
        monkeypatch.delenv("COCO_RAG_AUTHN_ENABLED", raising=False)
        monkeypatch.delenv("COCO_RAG_AUTHZ_ENABLED", raising=False)
        auth = AuthSettings.resolve(
            env_prefix=_PREFIX,
            seed={
                "authn_enabled": True,
                "authn_config": {
                    "jwks_uri": "https://idp.example.com/jwks",
                    "issuer": "https://idp.example.com",
                    "audience": "coco-rag",
                },
                "authz_enabled": True,
            },
        )
        assert auth.enabled is True
        assert auth.config.jwks_uri == "https://idp.example.com/jwks"
        assert auth.config.audience == "coco-rag"
        assert auth.authz_enabled is True

    def test_env_var_overrides_enabled(self, monkeypatch):
        monkeypatch.setenv("COCO_RAG_AUTHN_ENABLED", "false")
        auth = AuthSettings.resolve(env_prefix=_PREFIX, seed={"authn_enabled": True})
        assert auth.enabled is False

    def test_env_var_overrides_config_field(self, monkeypatch):
        monkeypatch.setenv("COCO_RAG_AUTHN_JWKS_URI", "https://env-override.com/jwks")
        auth = AuthSettings.resolve(
            env_prefix=_PREFIX,
            seed={"authn_config": {"jwks_uri": "https://db-value.com/jwks"}},
        )
        assert auth.config.jwks_uri == "https://env-override.com/jwks"

    def test_authz_env_var(self, monkeypatch):
        monkeypatch.setenv("COCO_RAG_AUTHZ_ENABLED", "true")
        auth = AuthSettings.resolve(env_prefix=_PREFIX)
        assert auth.authz_enabled is True

    def test_claim_map_from_seed(self):
        auth = AuthSettings.resolve(
            env_prefix=_PREFIX,
            seed={"authn_config": {"claim_map": {"roles": "realm_access.roles", "org_id": "org_id"}}},
        )
        assert auth.config.claim_map == {"roles": "realm_access.roles", "org_id": "org_id"}

    def test_claim_map_env_var_override(self, monkeypatch):
        monkeypatch.setenv("COCO_RAG_AUTHN_CLAIM_MAP", '{"roles": "groups"}')
        auth = AuthSettings.resolve(
            env_prefix=_PREFIX,
            seed={"authn_config": {"claim_map": {"roles": "realm_access.roles"}}},
        )
        assert auth.config.claim_map == {"roles": "groups"}

    def test_partial_seed_config_uses_defaults(self):
        auth = AuthSettings.resolve(env_prefix=_PREFIX, seed={"authn_config": {"jwks_uri": "https://idp/jwks"}})
        assert auth.config.jwks_uri == "https://idp/jwks"
        assert auth.config.mode == AuthMode.JWT_VERIFIER

    def test_invalid_seed_config_raises(self):
        with pytest.raises(ValueError):
            AuthSettings.resolve(env_prefix=_PREFIX, seed={"authn_config": {"jwks_uri": "http://insecure/jwks"}})

    def test_enabled_without_required_fields_raises(self, monkeypatch):
        monkeypatch.delenv("COCO_RAG_AUTHN_ENABLED", raising=False)
        with pytest.raises(ValueError, match="issuer"):
            AuthSettings.resolve(
                env_prefix=_PREFIX,
                seed={"authn_enabled": True, "authn_config": {"jwks_uri": "https://idp/jwks"}},
            )

    def test_non_dict_seed_config_ignored(self):
        auth = AuthSettings.resolve(env_prefix=_PREFIX, seed={"authn_config": "corrupted-string"})
        assert auth.config.jwks_uri is None

    def test_unexpected_seed_keys_ignored(self):
        # Should not raise; unexpected keys are logged and ignored
        auth = AuthSettings.resolve(env_prefix=_PREFIX, seed={"typo_key": True})
        assert auth.enabled is False

    def test_oauth_proxy_from_seed(self):
        auth = AuthSettings.resolve(
            env_prefix=_PREFIX,
            seed={
                "authn_config": {
                    "mode": "oauth_proxy",
                    "mcp_base_url": "https://coco-rag.example.com",
                    "upstream_authorization_endpoint": "https://idp/authorize",
                    "upstream_token_endpoint": "https://idp/token",
                    "upstream_client_id": "my-client",
                    "upstream_client_secret": "secret",
                },
            },
        )
        assert auth.config.mode == AuthMode.OAUTH_PROXY
        assert auth.config.upstream_client_secret.get_secret_value() == "secret"
