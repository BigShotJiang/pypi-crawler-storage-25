"""Unit tests for JwtCredentialValidator."""

import time
from unittest.mock import MagicMock

import pytest
from joserfc import jwt as joserfc_jwt
from joserfc.jwk import KeySet, RSAKey

from sonnet_auth.jwt_validator import JwtCredentialValidator
from sonnet_auth.settings import AuthnConfig

# ---------------------------------------------------------------------------
# Module-scoped RSA key pair — generated once per test session
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def rsa_key_pair():
    private_key = RSAKey.generate_key(2048, parameters=None, private=True)
    public_key = RSAKey.import_key(private_key.as_dict(is_private=False))
    return private_key, public_key


@pytest.fixture(scope="module")
def key_set(rsa_key_pair):
    _, public_key = rsa_key_pair
    return KeySet([public_key])


@pytest.fixture(scope="module")
def make_token(rsa_key_pair):
    """Factory fixture: creates signed JWTs with the test RSA key."""
    private_key, _ = rsa_key_pair

    def _make(claims: dict, algorithm: str = "RS256") -> str:
        defaults = {
            "sub": "user-123",
            "iss": "https://idp.example.com",
            "aud": "coco-rag",
            "exp": int(time.time()) + 300,
            "iat": int(time.time()),
        }
        defaults.update(claims)
        return joserfc_jwt.encode({"alg": algorithm}, defaults, private_key)

    return _make


@pytest.fixture(scope="module")
def auth_config():
    return AuthnConfig(
        jwks_uri="https://idp.example.com/.well-known/jwks.json",
        issuer="https://idp.example.com",
        audience="coco-rag",
    )


@pytest.fixture(scope="module")
def validator(auth_config, key_set):
    """Validator with injected key set — no HTTP calls."""
    return JwtCredentialValidator(auth_config, key_set=key_set)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestJwtCredentialValidatorInit:
    def test_raises_without_jwks_uri(self):
        with pytest.raises(ValueError, match="jwks_uri"):
            JwtCredentialValidator(AuthnConfig())


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


class TestJwtCredentialValidatorValid:
    def test_valid_token_returns_auth_context(self, validator, make_token):
        token = make_token({"sub": "alice", "preferred_username": "alice@acme.com", "email": "alice@acme.com"})
        ctx = validator.validate(token)
        assert ctx is not None
        assert ctx.user_id == "alice"
        assert ctx.username == "alice"  # only sub is mapped to username
        assert ctx.claims["preferred_username"] == "alice@acme.com"
        assert ctx.claims["email"] == "alice@acme.com"

    def test_custom_claims_available_via_claims_dict(self, validator, make_token):
        token = make_token({"org_id": "acme", "roles": ["admin"]})
        ctx = validator.validate(token)
        assert ctx is not None
        assert ctx.claims["org_id"] == "acme"
        assert ctx.claims["roles"] == ["admin"]

    def test_username_equals_sub(self, validator, make_token):
        token = make_token({"sub": "user-456"})
        ctx = validator.validate(token)
        assert ctx is not None
        assert ctx.username == "user-456"

    def test_claims_are_immutable(self, validator, make_token):
        token = make_token({})
        ctx = validator.validate(token)
        assert ctx is not None
        with pytest.raises(TypeError):
            ctx.claims["new_key"] = "value"

    def test_sub_in_claims(self, validator, make_token):
        token = make_token({"sub": "u-99"})
        ctx = validator.validate(token)
        assert ctx is not None
        assert "sub" in ctx.claims


# ---------------------------------------------------------------------------
# Invalid token cases
# ---------------------------------------------------------------------------


class TestJwtCredentialValidatorInvalid:
    def test_expired_token(self, validator, make_token):
        token = make_token({"exp": int(time.time()) - 60})
        assert validator.validate(token) is None

    def test_wrong_issuer(self, validator, make_token):
        token = make_token({"iss": "https://wrong-idp.com"})
        assert validator.validate(token) is None

    def test_wrong_audience(self, validator, make_token):
        token = make_token({"aud": "wrong-audience"})
        assert validator.validate(token) is None

    def test_malformed_token(self, validator):
        assert validator.validate("not-a-jwt") is None

    def test_empty_token(self, validator):
        assert validator.validate("") is None

    def test_missing_sub_claim(self, validator, rsa_key_pair):
        """Token without sub fails essential claim check."""
        private_key, public_key = rsa_key_pair
        ks = KeySet([public_key])
        cfg = AuthnConfig(jwks_uri="https://idp/jwks", issuer="https://idp", audience="aud")
        v = JwtCredentialValidator(cfg, key_set=ks)
        token = joserfc_jwt.encode(
            {"alg": "RS256"},
            {"iss": "https://idp", "aud": "aud", "exp": int(time.time()) + 300},
            private_key,
        )
        assert v.validate(token) is None

    def test_wrong_signing_key(self, auth_config, make_token):
        """Token signed with a different key is rejected."""
        other_key = RSAKey.generate_key(2048, parameters=None, private=True)
        other_public = RSAKey.import_key(other_key.as_dict(is_private=False))
        wrong_ks = KeySet([other_public])
        v = JwtCredentialValidator(auth_config, key_set=wrong_ks)
        token = make_token({})
        assert v.validate(token) is None


# ---------------------------------------------------------------------------
# JWKS error handling
# ---------------------------------------------------------------------------


class TestJwtCredentialValidatorErrors:
    def test_jwks_fetch_failure_at_startup_returns_none_on_validate(self, monkeypatch):
        """Network failure at startup — validator starts with no keys, validate() returns None (→ 401)."""
        import httpx

        monkeypatch.setattr(httpx, "get", MagicMock(side_effect=httpx.ConnectError("unreachable")))
        v = JwtCredentialValidator(
            AuthnConfig(
                jwks_uri="https://idp/jwks",
                issuer="https://idp",
                audience="aud",
            )
        )
        # No RuntimeError — starts gracefully with no keys
        assert v._key_set is None
        # validate() returns None (→ 401) without crashing
        result = v.validate("any.bearer.token")
        assert result is None

    def test_jwks_recovers_after_startup_failure(self, auth_config, key_set, monkeypatch):
        """JWKS unavailable at startup — recovers automatically when IdP becomes available."""
        import httpx

        # First call (startup) fails
        call_count = 0
        original_get = httpx.get

        def _flaky_get(url, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise httpx.ConnectError("unreachable")
            return original_get(url, **kw)  # never reached — monkeypatch overrides before recovery

        monkeypatch.setattr(httpx, "get", MagicMock(side_effect=httpx.ConnectError("unreachable")))
        v = JwtCredentialValidator(AuthnConfig(jwks_uri="https://idp/jwks", issuer="https://idp", audience="aud"))
        assert v._key_set is None

        # IdP comes back — next _get_key_set() call succeeds
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json = MagicMock(return_value=key_set.as_dict())
        monkeypatch.setattr(httpx, "get", MagicMock(return_value=mock_response))

        result = v._get_key_set()
        assert result is not None
        assert v._key_set is not None

    def test_stale_key_set_logs_warning_and_uses_cache(self, auth_config, key_set, monkeypatch, caplog):
        """JWKS refresh failure falls back to cached keys."""
        import logging

        import httpx

        v = JwtCredentialValidator(auth_config, key_set=key_set)
        # Force TTL expiry
        v._key_set_fetched_at = 0

        monkeypatch.setattr(httpx, "get", MagicMock(side_effect=httpx.ConnectError("unreachable")))
        with caplog.at_level(logging.WARNING):
            result = v._get_key_set()

        # Still returns cached key set
        assert result is key_set


# ---------------------------------------------------------------------------
# No issuer / no audience validation
# ---------------------------------------------------------------------------


class TestJwtCredentialValidatorOptionalClaims:
    def test_no_audience_rejects_token_with_aud(self, rsa_key_pair):
        """Validator without audience configured rejects tokens with aud claim.

        joserfc is strict: if aud is present in the token but the validator
        has no audience configured, the aud claim is not validated. However,
        AuthSettings prevents auth_enabled=True without audience, so this
        documents the direct-construction edge case only.
        """
        private_key, public_key = rsa_key_pair
        ks = KeySet([public_key])
        cfg = AuthnConfig(jwks_uri="https://idp/jwks", issuer="https://idp")
        v = JwtCredentialValidator(cfg, key_set=ks)
        # Token with aud but no audience configured — joserfc skips aud check
        token = joserfc_jwt.encode(
            {"alg": "RS256"},
            {"sub": "u", "iss": "https://idp", "aud": "some-audience", "exp": int(time.time()) + 300},
            private_key,
        )
        # Without audience validation, valid token passes
        ctx = v.validate(token)
        assert ctx is not None
