"""Unit tests for auth context — dot-path extraction, claim mapping, build_auth_context."""

from types import MappingProxyType

import pytest

from sonnet_auth.context import build_auth_context, resolve_attributes, resolve_dot_path

# ---------------------------------------------------------------------------
# resolve_dot_path
# ---------------------------------------------------------------------------


class TestResolveDotPath:
    def test_top_level_key(self):
        assert resolve_dot_path({"sub": "alice"}, "sub") == "alice"

    def test_nested_key(self):
        data = {"realm_access": {"roles": ["admin", "user"]}}
        assert resolve_dot_path(data, "realm_access.roles") == ["admin", "user"]

    def test_deeply_nested(self):
        data = {"a": {"b": {"c": {"d": 42}}}}
        assert resolve_dot_path(data, "a.b.c.d") == 42

    def test_missing_top_level(self):
        assert resolve_dot_path({"sub": "alice"}, "missing") is None

    def test_missing_nested(self):
        assert resolve_dot_path({"a": {"b": 1}}, "a.c") is None

    def test_path_through_non_dict(self):
        assert resolve_dot_path({"a": "string"}, "a.b") is None

    def test_none_intermediate(self):
        assert resolve_dot_path({"a": {"b": None}}, "a.b.c") is None

    def test_empty_dict(self):
        assert resolve_dot_path({}, "any.path") is None

    def test_value_is_false(self):
        # False is a valid value, not None — should be returned
        assert resolve_dot_path({"active": False}, "active") is False

    def test_value_is_zero(self):
        assert resolve_dot_path({"count": 0}, "count") == 0

    def test_value_is_empty_string(self):
        assert resolve_dot_path({"name": ""}, "name") == ""

    def test_value_is_empty_list(self):
        assert resolve_dot_path({"roles": []}, "roles") == []


# ---------------------------------------------------------------------------
# resolve_attributes
# ---------------------------------------------------------------------------


class TestResolveAttributes:
    def test_maps_top_level_claims(self):
        claims = {"sub": "alice", "org_id": "acme", "email": "alice@acme.com"}
        claim_map = {"org_id": "org_id", "email": "email"}
        attrs = resolve_attributes(claims, claim_map)
        assert attrs == {"org_id": "acme", "email": "alice@acme.com"}

    def test_maps_nested_claims(self):
        claims = {"sub": "alice", "realm_access": {"roles": ["admin"]}}
        claim_map = {"roles": "realm_access.roles"}
        attrs = resolve_attributes(claims, claim_map)
        assert attrs == {"roles": ["admin"]}

    def test_skips_missing_claims(self):
        claims = {"sub": "alice"}
        claim_map = {"roles": "realm_access.roles", "org_id": "org_id"}
        attrs = resolve_attributes(claims, claim_map)
        assert attrs == {}

    def test_partial_match(self):
        claims = {"sub": "alice", "org_id": "acme"}
        claim_map = {"roles": "realm_access.roles", "org_id": "org_id"}
        attrs = resolve_attributes(claims, claim_map)
        assert attrs == {"org_id": "acme"}

    def test_empty_claim_map(self):
        claims = {"sub": "alice", "org_id": "acme"}
        assert resolve_attributes(claims, {}) == {}

    def test_empty_claims(self):
        claim_map = {"roles": "realm_access.roles"}
        assert resolve_attributes({}, claim_map) == {}

    def test_preserves_falsy_non_none_values(self):
        """False, 0, and [] are valid claim values — must not be skipped."""
        claims = {"active": False, "level": 0, "roles": [], "name": ""}
        claim_map = {"active": "active", "level": "level", "roles": "roles", "name": "name"}
        attrs = resolve_attributes(claims, claim_map)
        assert attrs == {"active": False, "level": 0, "roles": [], "name": ""}

    def test_auto_map_preserves_falsy_non_none_values(self):
        """auto_map_claims=True must include falsy claim values."""
        claims = {"sub": "alice", "active": False, "level": 0, "roles": [], "iat": 1234}
        attrs = resolve_attributes(claims, {}, auto_map_claims=True)
        # sub is excluded (JWT plumbing), iat is excluded (JWT plumbing),
        # but active=False, level=0, and roles=[] must be included
        assert attrs["active"] is False
        assert attrs["level"] == 0
        assert attrs["roles"] == []
        assert "sub" not in attrs
        assert "iat" not in attrs


# ---------------------------------------------------------------------------
# build_auth_context
# ---------------------------------------------------------------------------


class TestBuildAuthContext:
    def test_sub_only(self):
        ctx = build_auth_context({"sub": "alice"})
        assert ctx.user_id == "alice"
        assert ctx.username == "alice"
        assert ctx.email is None
        assert ctx.tenant_id is None
        assert isinstance(ctx.claims, MappingProxyType)

    def test_missing_sub_raises(self):
        with pytest.raises(KeyError):
            build_auth_context({"email": "no-sub@example.com"})

    def test_claims_immutable(self):
        ctx = build_auth_context({"sub": "alice", "org": "acme"})
        with pytest.raises(TypeError):
            ctx.claims["new"] = "value"

    def test_no_claim_map_ignores_extra_claims(self):
        ctx = build_auth_context({"sub": "alice", "email": "alice@example.com"})
        assert ctx.email is None  # email not mapped without claim_map

    def test_claim_map_maps_email(self):
        ctx = build_auth_context(
            {"sub": "alice", "email": "alice@acme.com"},
            claim_map={"email": "email"},
        )
        assert ctx.email == "alice@acme.com"

    def test_claim_map_maps_tenant_id(self):
        ctx = build_auth_context(
            {"sub": "alice", "tenant": "t-1"},
            claim_map={"tenant_id": "tenant"},
        )
        assert ctx.tenant_id == "t-1"

    def test_claim_map_maps_nested_email(self):
        ctx = build_auth_context(
            {"sub": "alice", "user_info": {"email": "alice@acme.com"}},
            claim_map={"email": "user_info.email"},
        )
        assert ctx.email == "alice@acme.com"

    def test_claim_map_missing_claim_defaults_to_none(self):
        ctx = build_auth_context(
            {"sub": "alice"},
            claim_map={"email": "email", "tenant_id": "org.tenant_id"},
        )
        assert ctx.email is None
        assert ctx.tenant_id is None

    def test_claim_map_non_standard_attrs_not_on_context(self):
        """Non-standard mapped attributes (roles, org_id) are not on AuthContext fields.
        They're resolved at Cedar evaluation time via resolve_attributes()."""
        from sonnet_auth.context import resolve_attributes

        claims = {"sub": "alice", "realm_access": {"roles": ["admin"]}, "org_id": "acme"}
        claim_map = {"roles": "realm_access.roles", "org_id": "org_id"}
        ctx = build_auth_context(claims, claim_map=claim_map)

        # Non-standard attrs are NOT named fields on AuthContext
        assert not hasattr(ctx, "roles")
        assert not hasattr(ctx, "org_id")

        # They remain in raw claims (unchanged)
        assert ctx.claims["org_id"] == "acme"
        assert ctx.claims["realm_access"]["roles"] == ["admin"]

        # Cedar engine re-derives them at evaluation time via resolve_attributes
        attrs = resolve_attributes(ctx.claims, claim_map)
        assert attrs == {"roles": ["admin"], "org_id": "acme"}

    def test_claim_map_empty_dict_same_as_none(self):
        ctx = build_auth_context({"sub": "alice"}, claim_map={})
        assert ctx.email is None
        assert ctx.tenant_id is None

    def test_all_raw_claims_preserved(self):
        claims = {"sub": "alice", "iss": "https://idp", "aud": "coco-rag", "custom": "value"}
        ctx = build_auth_context(claims, claim_map={"email": "email"})
        assert ctx.claims["iss"] == "https://idp"
        assert ctx.claims["aud"] == "coco-rag"
        assert ctx.claims["custom"] == "value"
