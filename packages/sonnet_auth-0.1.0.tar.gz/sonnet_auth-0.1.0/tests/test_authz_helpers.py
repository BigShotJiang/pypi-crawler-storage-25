"""Unit tests for auth/authz.py helpers — check_authz, filter_authz, resolve_principal_attrs."""

from __future__ import annotations

from types import MappingProxyType
from unittest.mock import patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from sonnet_auth.authz import check_authz, filter_authz, resolve_principal_attrs
from sonnet_auth.policy_engine import PolicyEngine
from sonnet_server.guards import AuthContext, set_auth_context
from sonnet_server.services.registry import get_service_registry

_SCHEMA = """
{
  "": {
    "entityTypes": {
      "User": {
        "shape": {
          "type": "Record",
          "attributes": {
            "roles": { "type": "Set", "element": { "type": "String" } }
          }
        }
      },
      "Topic": { "shape": { "type": "Record", "attributes": {} } },
      "Source": { "shape": { "type": "Record", "attributes": {} } }
    },
    "actions": {
      "search":    { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Topic", "Source"] } },
      "configure": { "appliesTo": { "principalTypes": ["User"], "resourceTypes": ["Source"] } }
    }
  }
}
"""

_POLICIES = """
permit(principal, action == Action::"search", resource)
when { principal.roles.contains("reader") };

permit(principal, action == Action::"configure", resource)
when { principal.roles.contains("admin") };
"""


def _make_auth(user_id: str, roles: list[str]) -> AuthContext:
    return AuthContext(
        user_id=user_id,
        username=user_id,
        claims=MappingProxyType({"sub": user_id, "roles": roles}),
    )


def _make_engine(claim_map: dict | None = None) -> PolicyEngine:
    return PolicyEngine(_POLICIES, _SCHEMA, claim_map=claim_map or {"roles": "roles"})


# ---------------------------------------------------------------------------
# resolve_principal_attrs
# ---------------------------------------------------------------------------


class TestResolvePrincipalAttrs:
    def test_resolves_roles_via_claim_map(self):
        engine = _make_engine(claim_map={"roles": "roles"})
        attrs = resolve_principal_attrs(engine, "alice", {"sub": "alice", "roles": ["reader"]})
        assert attrs == {"roles": ["reader"]}

    def test_empty_claim_map_returns_empty_attrs(self):
        engine = PolicyEngine(_POLICIES, _SCHEMA, claim_map={})
        attrs = resolve_principal_attrs(engine, "alice", {"sub": "alice", "roles": ["reader"]})
        assert attrs == {}

    def test_missing_claim_skipped(self):
        engine = _make_engine(claim_map={"org_id": "org_id"})
        attrs = resolve_principal_attrs(engine, "alice", {"sub": "alice"})
        assert attrs == {}


# ---------------------------------------------------------------------------
# check_authz + filter_authz — via a FastAPI test app with real AuthContext
# ---------------------------------------------------------------------------


@pytest.fixture()
def engine():
    return _make_engine()


@pytest.fixture()
def app_with_authz(engine):
    """FastAPI test app with PolicyEngine in DI and routes that call check/filter.

    Mocks _resolve_resource_attrs to avoid DB access (properties cache → connection pool).
    These tests verify authz logic, not property resolution.
    """
    get_service_registry().register_singleton(PolicyEngine, engine)

    # Patch resource attrs resolution to avoid DB access — return empty attrs (RBAC tests)
    resolve_patch = patch("sonnet_auth.authz._resolve_resource_attrs", return_value={})
    resolve_patch.start()

    from fastapi import Request
    from fastapi.responses import JSONResponse

    from sonnet_auth.authz import AuthzDeniedError

    app = FastAPI()

    @app.exception_handler(AuthzDeniedError)
    async def _authz_denied(request: Request, exc: AuthzDeniedError) -> JSONResponse:  # noqa: ARG001
        return JSONResponse(status_code=403, content={"detail": "Forbidden"})

    @app.get("/search/{topic}")
    def search(topic: str):
        check_authz("search", "Topic", topic)
        return {"ok": True}

    @app.get("/configure/{source}")
    def configure(source: str):
        check_authz("configure", "Source", source)
        return {"ok": True}

    @app.get("/sources")
    def list_sources():
        resources = [("backend", {}), ("frontend", {}), ("secret", {})]
        permitted = filter_authz("search", "Topic", resources)
        return {"permitted": sorted(permitted)}

    yield TestClient(app, raise_server_exceptions=False)

    resolve_patch.stop()


class TestCheckAuthz:
    def test_reader_allowed(self, app_with_authz):
        auth = _make_auth("alice", ["reader"])
        set_auth_context(auth)
        resp = app_with_authz.get("/search/backend")
        assert resp.status_code == 200

    def test_reader_denied_configure(self, app_with_authz):
        auth = _make_auth("alice", ["reader"])
        set_auth_context(auth)
        resp = app_with_authz.get("/configure/my-repo")
        assert resp.status_code == 403

    def test_admin_allowed_configure(self, app_with_authz):
        auth = _make_auth("bob", ["admin"])
        set_auth_context(auth)
        resp = app_with_authz.get("/configure/my-repo")
        assert resp.status_code == 200

    def test_no_roles_denied(self, app_with_authz):
        auth = _make_auth("anon", [])
        set_auth_context(auth)
        resp = app_with_authz.get("/search/backend")
        assert resp.status_code == 403

    def test_no_engine_is_noop(self):
        """When PolicyEngine is not registered, check_authz is a no-op."""
        with patch("sonnet_auth.authz.get_policy_engine", return_value=None):
            # Should not raise even without AuthContext
            check_authz("search", "Topic", "backend")


class TestFilterAuthz:
    def test_reader_sees_all(self, app_with_authz):
        auth = _make_auth("alice", ["reader"])
        set_auth_context(auth)
        resp = app_with_authz.get("/sources")
        assert resp.status_code == 200
        assert resp.json()["permitted"] == ["backend", "frontend", "secret"]

    def test_no_roles_sees_nothing(self, app_with_authz):
        auth = _make_auth("anon", [])
        set_auth_context(auth)
        resp = app_with_authz.get("/sources")
        assert resp.status_code == 200
        assert resp.json()["permitted"] == []

    def test_no_engine_returns_all(self):
        """When PolicyEngine is not registered, filter_authz returns all resource IDs."""
        with patch("sonnet_auth.authz.get_policy_engine", return_value=None):
            resources = [("a", {}), ("b", {}), ("c", {})]
            result = filter_authz("search", "Topic", resources)
            assert result == {"a", "b", "c"}
