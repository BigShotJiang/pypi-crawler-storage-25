"""Tests for dynamic ai-guide and skill generation."""

from __future__ import annotations

import json
from pathlib import Path

import click

from cz_cli.guide_builder import (
    CommandEntry,
    build_ai_guide,
    build_command_inventory,
    build_toon_payload,
    examples_epilog,
    generate_skill_markdown,
    skill_drift_diff,
    write_generated_skill,
)
from cz_cli.main import cli


def _normalize_usage(text: str) -> str:
    normalized = " ".join(text.split())
    if normalized.startswith("Usage:"):
        normalized = normalized.split(":", 1)[1].strip()
    return normalized


def _resolve_command_usage(root: click.Command, path: str) -> str:
    ctx = click.Context(root, info_name="cz-cli")
    command = root
    for token in path.split():
        if not isinstance(command, click.Group):
            raise AssertionError(f"Not a group while resolving {path}: {command}")
        next_command = command.get_command(ctx, token)
        if next_command is None:
            raise AssertionError(f"Unknown command token '{token}' in path '{path}'")
        ctx = click.Context(next_command, info_name=token, parent=ctx)
        command = next_command
    return _normalize_usage(command.get_usage(ctx))


def test_ai_guide_and_inventory_have_same_command_signatures() -> None:
    inventory = build_command_inventory(cli)
    ai_guide = build_ai_guide(cli, budget_chars=200000)

    guide_usage = {item["name"]: item["usage"] for item in ai_guide["commands"]}
    inventory_usage = {entry.name: entry.usage for entry in inventory}

    assert guide_usage == inventory_usage


def test_help_usage_matches_inventory_usage() -> None:
    inventory = build_command_inventory(cli)

    for entry in inventory:
        expected = entry.usage
        actual = _resolve_command_usage(cli, entry.name)
        assert actual == expected


def test_inventory_includes_group_command_usage() -> None:
    inventory = build_command_inventory(cli)
    names = {entry.name for entry in inventory}
    usage_by_name = {entry.name: entry.usage for entry in inventory}
    kind_by_name = {entry.name: entry.kind for entry in inventory}

    assert "profile" in names
    assert "task flow" in names
    assert "profile show" in names
    assert usage_by_name["profile"].startswith("cz-cli profile [OPTIONS] COMMAND")
    assert usage_by_name["task flow"].startswith("cz-cli task flow [OPTIONS] COMMAND")
    assert kind_by_name["profile"] == "group"
    assert kind_by_name["task flow"] == "group"
    assert kind_by_name["profile show"] == "command"


def test_ai_guide_includes_kind_for_each_command() -> None:
    ai_guide = build_ai_guide(cli, budget_chars=200000)
    for item in ai_guide["commands"]:
        assert item["kind"] in {"group", "command"}


def test_generated_skill_contains_every_usage_signature() -> None:
    skill_markdown = generate_skill_markdown(cli)

    assert "pip3 install cz-cli -U" in skill_markdown  # fallback install instruction still present
    assert "generated_cli_version" in skill_markdown
    assert "generated_with" in skill_markdown
    # {{COMPANION_SKILLS}} placeholder is rendered (replaced by actual content or fallback)
    assert "{{COMPANION_SKILLS}}" not in skill_markdown
    # The Command Inventory section is present (static or generated)
    assert "## Command Inventory" in skill_markdown


def test_generated_skill_contains_examples_section() -> None:
    skill_markdown = generate_skill_markdown(cli)
    # The static Examples/Quick Start section was removed.
    # Verify the Command Inventory section and key companion-skill routing rule are present.
    assert "## Command Inventory" in skill_markdown
    assert "companion skill" in skill_markdown.lower()


def test_ai_guide_includes_shell_quote_hint_for_ddl() -> None:
    ai_guide = build_ai_guide(cli, budget_chars=200000)
    entry = next(item for item in ai_guide["commands"] if item["name"] == "table create")
    assert "shell_quote_hint" in entry
    assert "quotes" in entry["shell_quote_hint"]


def test_ai_guide_default_omits_task_create_options() -> None:
    ai_guide = build_ai_guide(cli)
    entry = next(item for item in ai_guide["commands"] if item["name"] == "task create")
    assert "options" not in entry
    assert "arguments" not in entry


def test_ai_guide_wide_includes_task_create_options() -> None:
    ai_guide = build_ai_guide(cli, wide=True)
    entry = next(item for item in ai_guide["commands"] if item["name"] == "task create")
    assert "options" in entry
    assert any("--folder-id" in opt.get("flags", []) for opt in entry["options"])


def test_ai_guide_default_is_smaller_than_wide() -> None:
    compact = build_ai_guide(cli)
    wide = build_ai_guide(cli, wide=True)
    assert len(json.dumps(compact, ensure_ascii=False)) < len(json.dumps(wide, ensure_ascii=False))


def test_ai_guide_budget_under_limit_keeps_full_sections() -> None:
    ai_guide = build_ai_guide(cli, wide=True, budget_chars=200000)

    assert ai_guide["truncation"]["applied"] is False
    assert "tips" in ai_guide
    assert "recommended_workflow" in ai_guide
    assert "options" in ai_guide["commands"][0]


def test_ai_guide_budget_over_limit_is_deterministic_and_preserves_mandatory_sections() -> None:
    first = build_ai_guide(cli, budget_chars=3000)
    second = build_ai_guide(cli, budget_chars=3000)

    assert first == second
    assert first["truncation"]["applied"] is True

    assert "global_options" in first
    assert "safety" in first
    assert "output_format" in first
    assert "exit_codes" in first
    assert first["commands"]
    for item in first["commands"]:
        assert item["name"]
        assert item["usage"]


def test_skill_drift_diff_detects_and_clears_drift(tmp_path: Path) -> None:
    target_path = tmp_path / "SKILL.md"
    target_path.write_text("stale\n", encoding="utf-8")

    diff_text = skill_drift_diff(cli, output_path=target_path)
    assert diff_text
    assert "stale" in diff_text

    write_generated_skill(cli, output_path=target_path)
    diff_after = skill_drift_diff(cli, output_path=target_path)
    assert diff_after == ""


# ---------------------------------------------------------------------------
# Examples infrastructure tests
# ---------------------------------------------------------------------------

_FAKE_EXAMPLES = [
    {"cmd": "cz-cli test run --fast", "desc": "Run tests quickly"},
    {"cmd": "cz-cli test run --all", "desc": "Run all tests"},
]


def test_examples_epilog_formats_correctly() -> None:
    epilog = examples_epilog(_FAKE_EXAMPLES)
    assert epilog.startswith("Examples:")
    assert "cz-cli test run --fast" in epilog
    assert "Run tests quickly" in epilog
    assert "cz-cli test run --all" in epilog


def test_examples_epilog_empty_returns_empty_string() -> None:
    assert examples_epilog([]) == ""


def test_build_command_inventory_emits_examples_when_present() -> None:
    """Commands with .examples attribute get examples populated in CommandEntry."""

    @click.command("demo-cmd")
    def _demo() -> None:
        """Demo command."""

    _demo.examples = _FAKE_EXAMPLES  # type: ignore[attr-defined]

    @click.group("demo-group")
    def _group() -> None:
        """Demo group."""

    _group.add_command(_demo)

    inventory = build_command_inventory(_group, cli_name="cz-cli")
    entry = next((e for e in inventory if e.name == "demo-cmd"), None)
    assert entry is not None
    assert isinstance(entry, CommandEntry)
    assert entry.examples == _FAKE_EXAMPLES
    # to_dict() includes examples when present
    assert entry.to_dict()["examples"] == _FAKE_EXAMPLES


def test_build_command_inventory_omits_examples_when_absent() -> None:
    """Commands without .examples attribute have examples=None in CommandEntry."""

    @click.command("bare-cmd")
    def _bare() -> None:
        """Bare command."""

    @click.group("bare-group")
    def _group() -> None:
        """Bare group."""

    _group.add_command(_bare)

    inventory = build_command_inventory(_group, cli_name="cz-cli")
    entry = next((e for e in inventory if e.name == "bare-cmd"), None)
    assert entry is not None
    assert entry.examples is None
    # to_dict() omits examples when None
    assert "examples" not in entry.to_dict()


def test_budget_trimming_removes_examples_before_descriptions() -> None:
    """_trim_command_examples fires before _drop_descriptions in budget pipeline."""
    # Build ai-guide with wide=True so examples are present and the budget
    # is tight enough to trigger trimming but not so tight it drops everything.
    ai_guide_full = build_ai_guide(cli, wide=True, budget_chars=200000)

    # Check that commands with examples have them in full output
    commands_with_examples_full = [
        c for c in ai_guide_full["commands"] if "examples" in c
    ]

    if not commands_with_examples_full:
        # No examples have been added to commands yet — test is a no-op placeholder
        return

    # With a very tight budget, examples should be gone but usage strings remain
    ai_guide_tight = build_ai_guide(cli, wide=True, budget_chars=5000)
    for cmd in ai_guide_tight["commands"]:
        assert "examples" not in cmd, (
            f"Command '{cmd['name']}' still has examples after budget trim"
        )
        assert cmd["usage"], f"Command '{cmd['name']}' lost usage after budget trim"


# ---------------------------------------------------------------------------
# TOON compression tests
# ---------------------------------------------------------------------------


def test_build_toon_payload_commands_have_uniform_scalar_keys() -> None:
    """build_toon_payload() produces commands with identical key sets and scalar values.

    TOON compresses arrays only when every element has identical keys AND every
    value is a scalar.  This test enforces both conditions so that
    commands[N]{name,kind,usage,description}: table compression is guaranteed.
    """
    ai_guide = build_ai_guide(cli, budget_chars=200000)
    toon = build_toon_payload(ai_guide)

    commands = toon["commands"]
    assert commands, "commands must not be empty"

    # 1. All key sets must be identical.
    key_sets = [frozenset(c.keys()) for c in commands]
    assert len(set(key_sets)) == 1, (
        f"commands have {len(set(key_sets))} different key sets — toon cannot compress:\n"
        + "\n".join(f"  {sorted(ks)}" for ks in set(key_sets))
    )

    # 2. Every value must be a scalar (str / int / float / bool / None).
    for cmd in commands:
        for key, value in cmd.items():
            assert not isinstance(value, (list, dict)), (
                f"Command '{cmd['name']}' key '{key}' has non-scalar value {type(value).__name__!r} "
                f"— toon cannot compress"
            )

    # 3. examples and shell_quote_hint must NOT appear inside commands.
    for cmd in commands:
        assert "examples" not in cmd, (
            f"Command '{cmd['name']}' still has 'examples' inline — must be in command_examples sibling"
        )
        assert "shell_quote_hint" not in cmd, (
            f"Command '{cmd['name']}' still has 'shell_quote_hint' inline — must be in command_hints sibling"
        )


def test_build_toon_payload_preserves_examples_in_sibling_keys() -> None:
    """Examples and hints extracted to sibling dicts, not lost."""
    ai_guide = build_ai_guide(cli, budget_chars=200000)

    # Confirm source payload has inline examples on some commands.
    src_examples = {c["name"]: c["examples"] for c in ai_guide["commands"] if "examples" in c}
    src_hints = {c["name"]: c["shell_quote_hint"] for c in ai_guide["commands"] if "shell_quote_hint" in c}

    toon = build_toon_payload(ai_guide)

    # Examples must appear in command_examples sibling.
    if src_examples:
        assert "command_examples" in toon, "command_examples sibling key missing"
        for name, examples in src_examples.items():
            assert name in toon["command_examples"], f"examples for '{name}' not in command_examples"
            assert toon["command_examples"][name] == examples

    # Hints must appear in command_hints sibling.
    if src_hints:
        assert "command_hints" in toon, "command_hints sibling key missing"
        for name, hint in src_hints.items():
            assert name in toon["command_hints"], f"hint for '{name}' not in command_hints"
            assert toon["command_hints"][name] == hint


def test_build_ai_guide_json_retains_inline_examples() -> None:
    """JSON output keeps examples inline per command — backward compatible."""
    ai_guide = build_ai_guide(cli, budget_chars=200000)
    commands_with_examples = [c for c in ai_guide["commands"] if "examples" in c]
    assert commands_with_examples, "Expected some commands to have inline examples in JSON output"
    # Specifically sql command should have examples.
    sql_entry = next((c for c in ai_guide["commands"] if c["name"] == "sql"), None)
    assert sql_entry is not None
    assert "examples" in sql_entry, "sql command should have inline examples in JSON output"


def test_toon_output_compresses_commands_to_table() -> None:
    """End-to-end: ai-guide toon output contains commands[N]{name,kind,usage,description}: line."""
    from click.testing import CliRunner
    from cz_cli.main import cli as _cli

    runner = CliRunner()
    result = runner.invoke(_cli, ["ai-guide", "-o", "toon"])
    assert result.exit_code == 0, f"ai-guide -o toon failed: {result.output}"

    lines = result.output.split("\n")
    cmd_lines = [line for line in lines if line.startswith("commands[")]
    assert cmd_lines, f"No 'commands[N]{{...}}:' line found in toon output:\n{result.output[:500]}"
    cmd_line = cmd_lines[0]
    assert "{name,kind,usage,description}" in cmd_line, (
        f"commands line not compressed to table form: {cmd_line!r}\n"
        "TOON requires all values scalar and all keys uniform — check build_toon_payload()"
    )

