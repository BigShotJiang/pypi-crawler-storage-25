"""Tests for ctrl+code."""
