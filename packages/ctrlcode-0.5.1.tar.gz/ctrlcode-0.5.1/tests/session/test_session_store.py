"""Tests for SessionStore — create, resume, get, load_or_create_project_id."""

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from ctrlcode.session.session_store import SessionStore
from ctrlcode.session.models import Session


def _make_store(tmp_path: Path, conv_manager=None, provider=None):
    if conv_manager is None:
        conv_manager = MagicMock()
        # create_conversation returns an object with .id
        fake_conv = MagicMock()
        fake_conv.id = "conv-1"
        conv_manager.create_conversation.return_value = fake_conv
        conv_manager.get_messages.return_value = []
    if provider is None:
        provider = MagicMock()
    return SessionStore(conv_manager, provider, tmp_path)


# ---------------------------------------------------------------------------
# load_or_create_project_id
# ---------------------------------------------------------------------------

def test_creates_project_id_when_absent(tmp_path):
    store = _make_store(tmp_path)
    pid = store.load_or_create_project_id()
    assert len(pid) == 36  # UUID format


def test_loads_existing_project_id(tmp_path):
    store = _make_store(tmp_path)
    (tmp_path / "project_id").write_text("my-fixed-uuid")
    pid = store.load_or_create_project_id()
    assert pid == "my-fixed-uuid"


def test_project_id_stable_across_calls(tmp_path):
    store = _make_store(tmp_path)
    pid1 = store.load_or_create_project_id()
    pid2 = store.load_or_create_project_id()
    assert pid1 == pid2


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------

def test_create_returns_session(tmp_path):
    store = _make_store(tmp_path)
    session = store.create()
    assert isinstance(session, Session)


def test_create_stores_session_in_memory(tmp_path):
    store = _make_store(tmp_path)
    session = store.create()
    assert store.get(session.id) is session


def test_create_writes_index(tmp_path):
    store = _make_store(tmp_path)
    session = store.create()
    assert (tmp_path / "session_index.json").exists()
    index = json.loads((tmp_path / "session_index.json").read_text())
    assert session.id in index


# ---------------------------------------------------------------------------
# resume
# ---------------------------------------------------------------------------

def test_resume_from_in_memory_session(tmp_path):
    store = _make_store(tmp_path)
    session = store.create()
    result = store.resume(session.id)
    assert result is session


def test_resume_from_index_file(tmp_path):
    cm = MagicMock()
    cm.get_messages.return_value = [MagicMock()]
    cm.to_model_format.return_value = [{"role": "user", "content": "hello"}]
    store = _make_store(tmp_path, conv_manager=cm)

    # Manually write an index entry
    index = {"old-session": "old-conv"}
    (tmp_path / "session_index.json").write_text(json.dumps(index))

    result = store.resume("old-session")
    assert result is not None
    assert result.conv_id == "old-conv"


def test_resume_returns_none_when_no_index(tmp_path):
    store = _make_store(tmp_path)
    result = store.resume("no-such-id")
    assert result is None


def test_resume_returns_none_when_session_not_in_index(tmp_path):
    store = _make_store(tmp_path)
    (tmp_path / "session_index.json").write_text(json.dumps({"other": "conv"}))
    result = store.resume("missing-session")
    assert result is None


def test_resume_returns_none_when_get_messages_fails(tmp_path):
    cm = MagicMock()
    cm.get_messages.side_effect = Exception("no such conv")
    store = _make_store(tmp_path, conv_manager=cm)

    index = {"bad-session": "bad-conv"}
    (tmp_path / "session_index.json").write_text(json.dumps(index))

    result = store.resume("bad-session")
    assert result is None


def test_resume_returns_none_on_corrupt_index(tmp_path):
    store = _make_store(tmp_path)
    (tmp_path / "session_index.json").write_text("NOT JSON!")
    result = store.resume("anything")
    assert result is None


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------

def test_get_returns_none_for_unknown(tmp_path):
    store = _make_store(tmp_path)
    assert store.get("xyz") is None


def test_get_returns_created_session(tmp_path):
    store = _make_store(tmp_path)
    session = store.create()
    assert store.get(session.id) is session
