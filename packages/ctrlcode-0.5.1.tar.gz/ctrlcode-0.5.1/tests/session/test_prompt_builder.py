"""Tests for prompt_builder — load_base_prompt, load_agent_instructions, detect_verification_commands."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from ctrlcode.session.prompt_builder import (
    load_agent_instructions,
    load_base_prompt,
    detect_verification_commands,
)


# ---------------------------------------------------------------------------
# load_base_prompt
# ---------------------------------------------------------------------------

def test_returns_fallback_when_no_workspace(tmp_path):
    result = load_base_prompt(None)
    assert "Ctrl+Code" in result  # Bundled fallback contains this


def test_project_override_takes_precedence(tmp_path):
    prompts_dir = tmp_path / "prompts"
    prompts_dir.mkdir()
    prompt_file = prompts_dir / "SYSTEM_PROMPT.md"
    prompt_file.write_text("Custom project prompt")

    result = load_base_prompt(tmp_path)
    assert result == "Custom project prompt"


def test_falls_back_when_project_file_missing(tmp_path):
    # No prompts/SYSTEM_PROMPT.md — should return bundled fallback
    result = load_base_prompt(tmp_path)
    assert len(result) > 0
    assert "Ctrl+Code" in result


def test_falls_back_on_read_error(tmp_path):
    prompts_dir = tmp_path / "prompts"
    prompts_dir.mkdir()
    prompt_file = prompts_dir / "SYSTEM_PROMPT.md"
    prompt_file.write_text("Override")
    prompt_file.chmod(0o000)

    try:
        result = load_base_prompt(tmp_path)
        # Either falls back gracefully or reads — both are acceptable
        assert isinstance(result, str)
    finally:
        prompt_file.chmod(0o644)


# ---------------------------------------------------------------------------
# load_agent_instructions
# ---------------------------------------------------------------------------

def test_no_instructions_returns_empty(tmp_path):
    # No AGENT.md anywhere
    with patch("platformdirs.user_config_dir", return_value=str(tmp_path / "no_config")):
        result = load_agent_instructions(tmp_path)
    assert result == ""


def test_project_agent_md_loaded(tmp_path):
    agent_file = tmp_path / "AGENT.md"
    agent_file.write_text("Always use type hints.")

    with patch("platformdirs.user_config_dir", return_value=str(tmp_path / "no_config")):
        result = load_agent_instructions(tmp_path)

    assert "Always use type hints." in result
    assert "Project-Specific Instructions" in result


def test_global_agent_md_loaded(tmp_path):
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "AGENT.md").write_text("Global rule.")

    with patch("platformdirs.user_config_dir", return_value=str(config_dir)):
        result = load_agent_instructions(None)

    assert "Global rule." in result
    assert "Global Agent Instructions" in result


def test_both_agent_mds_combined(tmp_path):
    # Project AGENT.md
    (tmp_path / "AGENT.md").write_text("Project rule.")

    # Global AGENT.md
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "AGENT.md").write_text("Global rule.")

    with patch("platformdirs.user_config_dir", return_value=str(config_dir)):
        result = load_agent_instructions(tmp_path)

    assert "Global rule." in result
    assert "Project rule." in result
    assert "---" in result  # separator between sections


def test_no_workspace_root_with_global_only(tmp_path):
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    (config_dir / "AGENT.md").write_text("Only global.")

    with patch("platformdirs.user_config_dir", return_value=str(config_dir)):
        result = load_agent_instructions(None)

    assert "Only global." in result


# ---------------------------------------------------------------------------
# detect_verification_commands
# ---------------------------------------------------------------------------

def test_detect_returns_list(tmp_path):
    detector = MagicMock()
    detector.detect.return_value = ["pytest"]
    detector.parse_agent_md.return_value = []
    detector.merge.return_value = ["pytest"]

    with patch("platformdirs.user_config_dir", return_value=str(tmp_path / "no_config")):
        result = detect_verification_commands(tmp_path, detector)

    assert result == ["pytest"]


def test_detect_merges_all_sources(tmp_path):
    detector = MagicMock()
    detector.detect.return_value = ["pytest"]
    detector.parse_agent_md.return_value = ["mypy"]
    detector.merge.return_value = ["pytest", "mypy"]

    with patch("platformdirs.user_config_dir", return_value=str(tmp_path / "config")):
        result = detect_verification_commands(tmp_path, detector)

    assert "pytest" in result
    detector.merge.assert_called_once()


def test_detect_uses_cwd_when_no_workspace():
    detector = MagicMock()
    detector.detect.return_value = []
    detector.parse_agent_md.return_value = []
    detector.merge.return_value = []

    result = detect_verification_commands(None, detector)
    assert isinstance(result, list)
    detector.detect.assert_called_once()
