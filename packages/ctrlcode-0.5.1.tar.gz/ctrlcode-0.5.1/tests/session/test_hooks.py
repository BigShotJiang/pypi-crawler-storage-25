"""Tests for session hooks — check_auto_chain, write_progress_file, make_before_complete_hook."""

import uuid
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.session.hooks import (
    check_auto_chain,
    write_progress_file,
    make_before_complete_hook,
)


# ---------------------------------------------------------------------------
# check_auto_chain
# ---------------------------------------------------------------------------

def test_check_auto_chain_search_single_result():
    result = check_auto_chain("search_files", ["/src/foo.py"])
    assert result is not None
    assert result["tool"] == "read_file"
    assert result["arguments"] == {"path": "/src/foo.py"}
    assert result["call_id"].startswith("auto_")


def test_check_auto_chain_search_multiple_results_no_chain():
    result = check_auto_chain("search_files", ["/a.py", "/b.py"])
    assert result is None


def test_check_auto_chain_search_empty_results_no_chain():
    result = check_auto_chain("search_files", [])
    assert result is None


def test_check_auto_chain_other_tool_returns_none():
    result = check_auto_chain("read_file", ["/a.py"])
    assert result is None


def test_check_auto_chain_non_list_result():
    result = check_auto_chain("search_files", "/a.py")
    assert result is None


def test_check_auto_chain_call_id_is_unique():
    r1 = check_auto_chain("search_files", ["/a.py"])
    r2 = check_auto_chain("search_files", ["/b.py"])
    assert r1["call_id"] != r2["call_id"]


# ---------------------------------------------------------------------------
# write_progress_file
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_write_progress_file_creates_file(tmp_path):
    ctrlcode_dir = tmp_path / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Done the work", [])
    progress = ctrlcode_dir / "progress.md"
    assert progress.exists()


@pytest.mark.anyio
async def test_write_progress_file_contains_summary(tmp_path):
    ctrlcode_dir = tmp_path / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Fixed the bug", [])
    content = (ctrlcode_dir / "progress.md").read_text()
    assert "Fixed the bug" in content


@pytest.mark.anyio
async def test_write_progress_file_with_touched_files(tmp_path):
    ctrlcode_dir = tmp_path / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Summary", ["src/a.py", "src/b.py"])
    content = (ctrlcode_dir / "progress.md").read_text()
    assert "src/a.py" in content
    assert "src/b.py" in content


@pytest.mark.anyio
async def test_write_progress_file_no_files_section(tmp_path):
    ctrlcode_dir = tmp_path / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Done", [])
    content = (ctrlcode_dir / "progress.md").read_text()
    assert "Files touched" not in content


@pytest.mark.anyio
async def test_write_progress_file_creates_parent_dir(tmp_path):
    ctrlcode_dir = tmp_path / "nested" / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "OK", [])
    assert (ctrlcode_dir / "progress.md").exists()


# ---------------------------------------------------------------------------
# make_before_complete_hook
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_hook_returns_none_when_no_todos_no_verification():
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=[],
        tool_executor=None,
        verification_commands=[],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


@pytest.mark.anyio
async def test_hook_blocks_when_pending_todos():
    from ctrlcode.session.verification import VerificationDetector
    from ctrlcode.tools.executor import ToolExecutor

    mock_executor = MagicMock(spec=ToolExecutor)
    mock_result = MagicMock()
    mock_result.success = True
    mock_result.result = {
        "todos": [
            {"content": "Write tests", "status": "pending"},
        ]
    }
    mock_executor.execute = AsyncMock(return_value=mock_result)

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=[],
        tool_executor=mock_executor,
        verification_commands=[],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is not None
    assert "unfinished" in result


@pytest.mark.anyio
async def test_hook_allows_when_all_todos_done():
    from ctrlcode.session.verification import VerificationDetector
    from ctrlcode.tools.executor import ToolExecutor

    mock_executor = MagicMock(spec=ToolExecutor)
    mock_result = MagicMock()
    mock_result.success = True
    mock_result.result = {
        "todos": [
            {"content": "Write tests", "status": "done"},
        ]
    }
    mock_executor.execute = AsyncMock(return_value=mock_result)

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=[],
        tool_executor=mock_executor,
        verification_commands=[],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


@pytest.mark.anyio
async def test_hook_blocks_missing_verification_commands():
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=[],
        tool_executor=None,
        verification_commands=["pytest"],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is not None
    assert "pytest" in result


@pytest.mark.anyio
async def test_hook_passes_when_verification_command_ran():
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=["pytest tests/"],
        tool_executor=None,
        verification_commands=["pytest"],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


@pytest.mark.anyio
async def test_hook_swallows_executor_exception():
    from ctrlcode.session.verification import VerificationDetector
    from ctrlcode.tools.executor import ToolExecutor

    mock_executor = MagicMock(spec=ToolExecutor)
    mock_executor.execute = AsyncMock(side_effect=RuntimeError("boom"))

    hook = make_before_complete_hook(
        session_id="s1",
        commands_run=[],
        tool_executor=mock_executor,
        verification_commands=[],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


