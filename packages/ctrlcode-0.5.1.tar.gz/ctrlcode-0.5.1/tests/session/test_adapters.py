"""Tests for LLMClientAdapter — invoke bridging provider to sync interface."""

import asyncio
import concurrent.futures
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ctrlcode.session.adapters import LLMClientAdapter


def _make_future(result: dict) -> concurrent.futures.Future:
    """Create a resolved concurrent.futures.Future (what run_coroutine_threadsafe returns)."""
    f: concurrent.futures.Future = concurrent.futures.Future()
    f.set_result(result)
    return f


def _make_adapter():
    provider = MagicMock()
    loop = asyncio.new_event_loop()
    return LLMClientAdapter(provider, loop), provider, loop


def test_invoke_returns_content():
    adapter, _, _ = _make_adapter()
    future = _make_future({"text": "hi there", "usage": {}, "model": "m"})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = adapter.invoke([{"role": "user", "content": "hello"}])

    assert result["content"] == "hi there"
    assert result["model"] == "m"


def test_invoke_maps_token_usage():
    adapter, _, _ = _make_adapter()
    future = _make_future({"text": "x", "usage": {"prompt_tokens": 20, "completion_tokens": 8}, "model": ""})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = adapter.invoke([])

    assert result["usage"]["input"] == 20
    assert result["usage"]["output"] == 8


def test_invoke_prepends_system_messages():
    adapter, _, _ = _make_adapter()
    future = _make_future({"text": "ok", "usage": {}, "model": ""})
    captured = {}

    def fake_run(coro, _loop):
        captured["called"] = True
        return future

    with patch("asyncio.run_coroutine_threadsafe", side_effect=fake_run):
        adapter.invoke([{"role": "user", "content": "q"}], system=["Be helpful"])

    assert captured["called"]


def test_invoke_missing_fields_default_to_empty():
    adapter, _, _ = _make_adapter()
    future = _make_future({})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = adapter.invoke([])

    assert result["content"] == ""
    assert result["model"] == ""
    assert result["usage"]["input"] == 0
    assert result["usage"]["output"] == 0
