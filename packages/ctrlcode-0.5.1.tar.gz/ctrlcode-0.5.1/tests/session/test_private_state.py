"""Tests for the private-field marker pattern on Session dataclass."""

import ast
from dataclasses import fields
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from ctrlcode.session.models import Session, _PRIVATE, public_fields


def make_session() -> Session:
    return Session(id="sess_001", conv_id="conv_abc", provider=MagicMock())


# ---------------------------------------------------------------------------
# public_fields exclusions
# ---------------------------------------------------------------------------

def test_public_fields_excludes_conv_id():
    assert "conv_id" not in public_fields(make_session())


def test_public_fields_excludes_provider():
    assert "provider" not in public_fields(make_session())


def test_public_fields_excludes_context_before_turn():
    assert "context_before_turn" not in public_fields(make_session())


# ---------------------------------------------------------------------------
# public_fields inclusions
# ---------------------------------------------------------------------------

def test_public_fields_includes_id():
    assert public_fields(make_session())["id"] == "sess_001"


def test_public_fields_includes_cumulative_tokens():
    s = make_session()
    s.cumulative_tokens = 42
    assert public_fields(s)["cumulative_tokens"] == 42


# ---------------------------------------------------------------------------
# Metadata marker
# ---------------------------------------------------------------------------

def test_private_metadata_on_conv_id():
    f = next(f for f in fields(Session) if f.name == "conv_id")
    assert f.metadata.get("private") is True


def test_private_metadata_on_provider():
    f = next(f for f in fields(Session) if f.name == "provider")
    assert f.metadata.get("private") is True


def test_private_metadata_on_context_before_turn():
    f = next(f for f in fields(Session) if f.name == "context_before_turn")
    assert f.metadata.get("private") is True


def test_no_private_metadata_on_id():
    f = next(f for f in fields(Session) if f.name == "id")
    assert not f.metadata.get("private", False)


def test_no_private_metadata_on_cumulative_tokens():
    f = next(f for f in fields(Session) if f.name == "cumulative_tokens")
    assert not f.metadata.get("private", False)


# ---------------------------------------------------------------------------
# Attribute access still works (metadata must not break normal usage)
# ---------------------------------------------------------------------------

def test_attribute_access_still_works():
    s = make_session()
    assert s.conv_id == "conv_abc"
    assert s.context_before_turn == 0


# ---------------------------------------------------------------------------
# Lint guard: boundary files must not reference session.conv_id directly
# ---------------------------------------------------------------------------

def _conv_id_violations(path: Path) -> list[int]:
    """Return line numbers where session.conv_id is accessed in the given file."""
    tree = ast.parse(path.read_text())
    return [
        node.lineno
        for node in ast.walk(tree)
        if isinstance(node, ast.Attribute)
        and node.attr == "conv_id"
        and isinstance(node.value, ast.Name)
        and node.value.id == "session"
    ]


def test_server_does_not_access_session_conv_id():
    """Boundary guard: server.py must never read session.conv_id."""
    path = Path(__file__).parents[2] / "src" / "ctrlcode" / "server.py"
    violations = _conv_id_violations(path)
    assert not violations, f"server.py accesses session.conv_id at lines {violations}"


def test_tui_does_not_access_session_conv_id():
    """Boundary guard: no tui/ file must read session.conv_id."""
    tui_dir = Path(__file__).parents[2] / "src" / "tui"
    all_violations: dict[str, list[int]] = {}
    for py_file in tui_dir.rglob("*.py"):
        lines = _conv_id_violations(py_file)
        if lines:
            all_violations[str(py_file.relative_to(tui_dir))] = lines
    assert not all_violations, f"tui/ accesses session.conv_id: {all_violations}"
