"""Tests for build_system_prompt — section injection, fallbacks, assembler integration."""

import json
import pytest
from pathlib import Path
from unittest.mock import AsyncMock


async def build(**kwargs):
    from ctrlcode.session.system_prompt import build_system_prompt
    defaults = dict(
        base_prompt="# Base",
        agent_instructions="",
        verification_commands=[],
        ctrlcode_dir=kwargs.pop("ctrlcode_dir"),
        workspace_root=kwargs.pop("workspace_root", None),
        assembler=kwargs.pop("assembler", _silent_assembler()),
        context_limit=200000,
        context_before_turn=0,
        user_input="do something",
    )
    defaults.update(kwargs)
    return await build_system_prompt(**defaults)


def _silent_assembler():
    m = AsyncMock()
    m.assemble = AsyncMock(return_value="")
    return m


def _assembler_with(context: str):
    m = AsyncMock()
    m.assemble = AsyncMock(return_value=context)
    return m


def _assembler_raises():
    m = AsyncMock()
    m.assemble = AsyncMock(side_effect=Exception("embedding down"))
    return m


# ---------------------------------------------------------------------------
# Base structure
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_returns_system_role_dict(tmp_path):
    result = await build(ctrlcode_dir=tmp_path)
    assert result["role"] == "system"
    assert isinstance(result["content"], str)


@pytest.mark.anyio
async def test_includes_base_prompt(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, base_prompt="MY BASE PROMPT")
    assert "MY BASE PROMPT" in result["content"]


@pytest.mark.anyio
async def test_includes_environment_section(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, workspace_root=tmp_path)
    assert "Working directory" in result["content"]
    assert "Platform" in result["content"]
    assert "Today's date" in result["content"]


@pytest.mark.anyio
async def test_git_repo_detected(tmp_path):
    (tmp_path / ".git").mkdir()
    result = await build(ctrlcode_dir=tmp_path, workspace_root=tmp_path)
    assert "Yes" in result["content"]


@pytest.mark.anyio
async def test_non_git_workspace(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, workspace_root=tmp_path)
    assert "No" in result["content"]


@pytest.mark.anyio
async def test_workspace_root_none_falls_back_to_cwd(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, workspace_root=None)
    assert "Working directory" in result["content"]


# ---------------------------------------------------------------------------
# Agent instructions
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_agent_instructions_injected(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, agent_instructions="## Agent Rules\nDo X")
    assert "Agent Rules" in result["content"]


@pytest.mark.anyio
async def test_empty_agent_instructions_omitted(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, agent_instructions="")
    # No extra blank sections
    assert result["content"].count("\n\n\n") == 0


# ---------------------------------------------------------------------------
# Project backlog
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_project_backlog_injected(tmp_path):
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    (todos_dir / "project.json").write_text(json.dumps([
        {"content": "Fix the bug", "status": "pending"},
        {"content": "Write tests", "status": "in_progress"},
        {"content": "Deploy", "status": "completed"},
    ]))

    result = await build(ctrlcode_dir=tmp_path)
    assert "Project Backlog" in result["content"]
    assert "Fix the bug" in result["content"]
    assert "[ ]" in result["content"]   # pending
    assert "[~]" in result["content"]   # in_progress
    assert "[x]" in result["content"]   # completed


@pytest.mark.anyio
async def test_project_backlog_absent_when_no_file(tmp_path):
    result = await build(ctrlcode_dir=tmp_path)
    assert "Project Backlog" not in result["content"]


@pytest.mark.anyio
async def test_project_backlog_absent_when_empty_list(tmp_path):
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    (todos_dir / "project.json").write_text("[]")

    result = await build(ctrlcode_dir=tmp_path)
    assert "Project Backlog" not in result["content"]


@pytest.mark.anyio
async def test_project_backlog_skips_on_malformed_json(tmp_path):
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    (todos_dir / "project.json").write_text("not json{{{")

    result = await build(ctrlcode_dir=tmp_path)
    assert "Project Backlog" not in result["content"]


# ---------------------------------------------------------------------------
# Prior session progress
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_progress_file_injected(tmp_path):
    (tmp_path / "progress.md").write_text("## Session: 2024-01-01\n\nDone: added auth")

    result = await build(ctrlcode_dir=tmp_path)
    assert "Prior Session Progress" in result["content"]
    assert "added auth" in result["content"]
    assert "git log" in result["content"]


@pytest.mark.anyio
async def test_progress_file_absent_when_missing(tmp_path):
    result = await build(ctrlcode_dir=tmp_path)
    assert "Prior Session Progress" not in result["content"]


@pytest.mark.anyio
async def test_progress_file_absent_when_empty(tmp_path):
    (tmp_path / "progress.md").write_text("   \n  ")
    result = await build(ctrlcode_dir=tmp_path)
    assert "Prior Session Progress" not in result["content"]


# ---------------------------------------------------------------------------
# Verification commands
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_verification_commands_injected(tmp_path):
    result = await build(
        ctrlcode_dir=tmp_path,
        verification_commands=["pytest", "ruff check src/"],
    )
    assert "Verification" in result["content"]
    assert "`pytest`" in result["content"]
    assert "`ruff check src/`" in result["content"]


@pytest.mark.anyio
async def test_no_verification_section_when_empty(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, verification_commands=[])
    assert "Verification" not in result["content"]


# ---------------------------------------------------------------------------
# Semantic context
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_semantic_context_appended(tmp_path):
    asm = _assembler_with("--- Retrieved Context ---\nsome relevant history\n--- End ---")
    result = await build(ctrlcode_dir=tmp_path, assembler=asm)
    assert "Retrieved Context" in result["content"]
    assert "some relevant history" in result["content"]


@pytest.mark.anyio
async def test_assembler_exception_yields_no_context(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, assembler=_assembler_raises())
    assert "Retrieved Context" not in result["content"]


@pytest.mark.anyio
async def test_empty_semantic_context_not_appended(tmp_path):
    result = await build(ctrlcode_dir=tmp_path, assembler=_silent_assembler())
    # No blank context section
    assert "Retrieved Context" not in result["content"]


@pytest.mark.anyio
async def test_budget_passed_to_assembler(tmp_path):
    asm = _assembler_with("")
    await build(
        ctrlcode_dir=tmp_path,
        assembler=asm,
        context_limit=100000,
        context_before_turn=50000,
    )
    call_kwargs = asm.assemble.call_args[1]
    assert call_kwargs["budget_tokens"] > 0
    assert call_kwargs["budget_tokens"] <= 100000
