"""Tests for _make_output_summarizer in session manager."""

import asyncio
import concurrent.futures
from unittest.mock import MagicMock, patch

from ctrlcode.session.manager import _make_output_summarizer


def _make_future(result: dict) -> concurrent.futures.Future:
    f: concurrent.futures.Future = concurrent.futures.Future()
    f.set_result(result)
    return f


def _make_provider():
    return MagicMock()


def test_make_output_summarizer_returns_callable():
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)
    assert callable(summarizer)


def test_summarizer_returns_llm_content():
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future = _make_future({"text": "grep found 5 matches in src/", "usage": {}, "model": ""})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = summarizer("grep", "lots of output text")

    assert result == "grep found 5 matches in src/"


def test_summarizer_strips_whitespace():
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future = _make_future({"text": "  summary with padding  ", "usage": {}, "model": ""})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = summarizer("bash", "output")

    assert result == "summary with padding"


def test_summarizer_prompt_includes_tool_name():
    """The prompt sent to the LLM references the tool name."""
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future = _make_future({"text": "ok", "usage": {}, "model": ""})
    captured_messages = []

    def fake_run(coro, _loop):
        # Capture the coroutine args by inspecting the adapter's last call indirectly
        return future

    with patch("asyncio.run_coroutine_threadsafe", side_effect=fake_run) as mock_run:
        summarizer("read", "file contents here")
        # The coroutine was submitted — just verify it was called
        assert mock_run.called


def test_summarizer_truncates_long_output():
    """Output longer than 3000 chars is truncated before sending to LLM."""
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future = _make_future({"text": "truncated summary", "usage": {}, "model": ""})
    long_output = "x" * 10_000

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = summarizer("bash", long_output)

    assert result == "truncated summary"


def test_summarizer_empty_llm_response_returns_empty_string():
    """If LLM returns empty content, summarizer returns empty string."""
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future = _make_future({})

    with patch("asyncio.run_coroutine_threadsafe", return_value=future):
        result = summarizer("bash", "output text")

    assert result == ""


def test_multiple_summarizer_calls_are_independent():
    """Each call to the summarizer is independent."""
    provider = _make_provider()
    loop = asyncio.new_event_loop()
    summarizer = _make_output_summarizer(provider, loop)

    future1 = _make_future({"text": "first summary", "usage": {}, "model": ""})
    future2 = _make_future({"text": "second summary", "usage": {}, "model": ""})

    with patch("asyncio.run_coroutine_threadsafe", side_effect=[future1, future2]):
        result1 = summarizer("bash", "output one")
        result2 = summarizer("grep", "output two")

    assert result1 == "first summary"
    assert result2 == "second summary"
