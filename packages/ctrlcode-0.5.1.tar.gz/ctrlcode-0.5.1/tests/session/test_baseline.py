"""Tests for BaselineManager — store, get, has_baseline, clear, extract_from_request."""

import pytest
from ctrlcode.session.baseline import Baseline, BaselineManager


@pytest.fixture
def mgr():
    return BaselineManager()


# ---------------------------------------------------------------------------
# store / get / has_baseline
# ---------------------------------------------------------------------------

def test_store_and_get(mgr):
    b = Baseline(code="def foo(): pass")
    mgr.store("sess1", b)
    assert mgr.get("sess1") is b


def test_get_returns_none_for_unknown(mgr):
    assert mgr.get("unknown") is None


def test_has_baseline_true_after_store(mgr):
    mgr.store("s", Baseline(code="x"))
    assert mgr.has_baseline("s") is True


def test_has_baseline_false_initially(mgr):
    assert mgr.has_baseline("s") is False


# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------

def test_clear_removes_baseline(mgr):
    mgr.store("s", Baseline(code="y"))
    mgr.clear("s")
    assert mgr.has_baseline("s") is False


def test_clear_noop_for_unknown(mgr):
    mgr.clear("nonexistent")  # should not raise


# ---------------------------------------------------------------------------
# extract_from_request
# ---------------------------------------------------------------------------

def test_extract_python_code_block(mgr):
    user_input = "Can you improve this?\n```python\ndef add(a, b):\n    return a + b\n```"
    code = mgr.extract_from_request(user_input)
    assert code is not None
    assert "def add" in code


def test_extract_plain_code_fence(mgr):
    user_input = "Fix this:\n```\ndef broken(): pass\n```"
    code = mgr.extract_from_request(user_input)
    assert code is not None
    assert "def broken" in code


def test_extract_returns_none_when_no_block(mgr):
    assert mgr.extract_from_request("just plain text") is None


def test_extract_returns_first_block(mgr):
    user_input = "```python\ndef first(): pass\n```\n```python\ndef second(): pass\n```"
    code = mgr.extract_from_request(user_input)
    assert "first" in code


# ---------------------------------------------------------------------------
# Baseline dataclass defaults
# ---------------------------------------------------------------------------

def test_baseline_default_language():
    b = Baseline(code="x")
    assert b.language == "python"


def test_baseline_default_context():
    b = Baseline(code="x")
    assert b.context == {}
