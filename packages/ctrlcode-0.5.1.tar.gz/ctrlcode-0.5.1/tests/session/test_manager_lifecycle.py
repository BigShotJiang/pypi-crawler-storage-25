"""Tests for SessionManager lifecycle — create/resume/get session, close, context stats."""

import pytest
from pathlib import Path

from tests.mocks.mock_provider import MockProvider
from ctrlcode.session.manager import SessionManager
from ctrlcode.session.models import ReactConfig


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def provider():
    return MockProvider()


@pytest.fixture
def manager(tmp_path, provider):
    return SessionManager(provider=provider, workspace_root=tmp_path)


@pytest.fixture
async def manager_with_session(manager):
    session = manager.create_session()
    return manager, session


# ---------------------------------------------------------------------------
# _ctrlcode_dir
# ---------------------------------------------------------------------------

def test_ctrlcode_dir_with_workspace(tmp_path, provider):
    m = SessionManager(provider=provider, workspace_root=tmp_path)
    assert m._ctrlcode_dir == tmp_path / ".ctrlcode"


def test_ctrlcode_dir_without_workspace(provider):
    m = SessionManager(provider=provider, workspace_root=None)
    assert m._ctrlcode_dir.name == ".ctrlcode"


# ---------------------------------------------------------------------------
# create_session
# ---------------------------------------------------------------------------

def test_create_session_returns_session(manager):
    session = manager.create_session()
    assert session is not None
    assert session.id is not None


def test_create_session_is_retrievable(manager):
    session = manager.create_session()
    retrieved = manager.get_session(session.id)
    assert retrieved is not None
    assert retrieved.id == session.id


def test_create_session_with_custom_provider(manager, provider):
    custom_provider = MockProvider()
    session = manager.create_session(provider=custom_provider)
    assert session is not None


def test_multiple_sessions_have_distinct_ids(manager):
    s1 = manager.create_session()
    s2 = manager.create_session()
    assert s1.id != s2.id


# ---------------------------------------------------------------------------
# get_session
# ---------------------------------------------------------------------------

def test_get_session_returns_none_for_unknown(manager):
    assert manager.get_session("nonexistent-id") is None


# ---------------------------------------------------------------------------
# resume_session
# ---------------------------------------------------------------------------

def test_resume_session_returns_session(manager):
    created = manager.create_session()
    resumed = manager.resume_session(created.id)
    assert resumed is not None
    assert resumed.id == created.id


def test_resume_session_returns_none_for_unknown(manager):
    result = manager.resume_session("no-such-id")
    assert result is None


# ---------------------------------------------------------------------------
# sessions property
# ---------------------------------------------------------------------------

def test_sessions_reflects_created(manager):
    s = manager.create_session()
    assert s.id in manager.sessions


# ---------------------------------------------------------------------------
# get_baseline
# ---------------------------------------------------------------------------

def test_get_baseline_returns_none_initially(manager):
    s = manager.create_session()
    assert manager.get_baseline(s.id) is None


# ---------------------------------------------------------------------------
# close
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_close_clears_memory_state(manager):
    session = manager.create_session()
    # Initialise memory via the middleware directly
    await manager._memory_mw.ensure(session)
    assert manager._memory_mw._memory is not None

    await manager.close()

    assert manager._memory_mw._memory is None
    assert manager._memory_mw._writers == {}
    assert manager._memory_mw._assemblers == {}
    assert manager._workspace_mw.monitor is None


@pytest.mark.anyio
async def test_close_is_idempotent(manager):
    await manager.close()
    await manager.close()  # should not raise


# ---------------------------------------------------------------------------
# WorkspaceMiddleware (formerly _ensure_workspace_index)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_workspace_middleware_no_monitor_without_workspace(provider):
    m = SessionManager(provider=provider, workspace_root=None)
    session = m.create_session()
    from ctrlcode.session.middleware import TurnContext
    ctx = TurnContext(session=session, user_input="hi")
    await m._workspace_mw.before_turn(ctx)
    assert m._workspace_mw.monitor is None
    await m.close()


@pytest.mark.anyio
async def test_workspace_middleware_creates_monitor(manager):
    session = manager.create_session()
    # Memory must be initialised first (WorkspaceMiddleware depends on it)
    await manager._memory_mw.ensure(session)
    from ctrlcode.session.middleware import TurnContext
    ctx = TurnContext(session=session, user_input="hi")
    ctx.extra["assembler"] = manager._memory_mw._assemblers[session.id]
    await manager._workspace_mw.before_turn(ctx)
    assert manager._workspace_mw.monitor is not None
    await manager.close()


@pytest.mark.anyio
async def test_workspace_middleware_is_idempotent(manager):
    session = manager.create_session()
    await manager._memory_mw.ensure(session)
    from ctrlcode.session.middleware import TurnContext
    ctx = TurnContext(session=session, user_input="hi")
    ctx.extra["assembler"] = manager._memory_mw._assemblers[session.id]
    await manager._workspace_mw.before_turn(ctx)
    monitor1 = manager._workspace_mw.monitor
    await manager._workspace_mw.before_turn(ctx)
    monitor2 = manager._workspace_mw.monitor
    assert monitor1 is monitor2
    await manager.close()


@pytest.mark.anyio
async def test_workspace_middleware_patches_dep_indexer_into_assembler(manager):
    session = manager.create_session()
    # Initialise memory first so assembler exists with dep_indexer=None
    await manager._memory_mw.ensure(session)
    assembler = manager._memory_mw._assemblers[session.id]
    assert assembler._dep_indexer is None

    # Running WorkspaceMiddleware.before_turn should back-patch dep_indexer
    from ctrlcode.session.middleware import TurnContext
    ctx = TurnContext(session=session, user_input="hi")
    ctx.extra["assembler"] = assembler
    await manager._workspace_mw.before_turn(ctx)
    assert assembler._dep_indexer is not None
    await manager.close()


# ---------------------------------------------------------------------------
# get_context_stats
# ---------------------------------------------------------------------------

def test_get_context_stats_raises_for_unknown(manager):
    with pytest.raises(ValueError, match="Session not found"):
        manager.get_context_stats("bad-id")


def test_get_context_stats_returns_dict(manager):
    s = manager.create_session()
    stats = manager.get_context_stats(s.id)
    assert "message_count" in stats
    assert "estimated_tokens" in stats
    assert "max_tokens" in stats


# ---------------------------------------------------------------------------
# compact_conversation / clear_conversation
# ---------------------------------------------------------------------------

def test_compact_conversation_raises_for_unknown(manager):
    with pytest.raises(ValueError, match="Session not found"):
        manager.compact_conversation("bad-id")


def test_compact_conversation_does_not_raise_for_valid(manager):
    s = manager.create_session()
    manager.compact_conversation(s.id)  # should not raise


def test_clear_conversation_raises_for_unknown(manager):
    with pytest.raises(ValueError, match="Session not found"):
        manager.clear_conversation("bad-id")


def test_clear_conversation_resets_tokens(manager):
    s = manager.create_session()
    s.cumulative_tokens = 1000
    manager.clear_conversation(s.id)
    assert s.cumulative_tokens == 0


def test_clear_conversation_assigns_new_conv_id(manager):
    s = manager.create_session()
    old_conv_id = s.conv_id
    manager.clear_conversation(s.id)
    assert s.conv_id != old_conv_id


# ---------------------------------------------------------------------------
# ReactConfig defaults
# ---------------------------------------------------------------------------

def test_react_config_defaults(manager):
    assert manager.react_config is not None
    assert manager.react_config.max_continuations > 0


def test_react_config_custom(tmp_path, provider):
    cfg = ReactConfig(max_continuations=5)
    m = SessionManager(provider=provider, workspace_root=tmp_path, react_config=cfg)
    assert m.react_config.max_continuations == 5
