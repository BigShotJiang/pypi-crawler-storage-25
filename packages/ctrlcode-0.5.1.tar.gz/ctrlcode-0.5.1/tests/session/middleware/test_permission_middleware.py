"""Tests for PermissionMiddleware."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.session.middleware.permission import PermissionMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session


def _make_ctx() -> TurnContext:
    session = MagicMock(spec=Session, id="s1", context_before_turn=0)
    return TurnContext(session=session, user_input="do something")


def _make_tool_call(tool: str, **kwargs) -> dict:
    return {"tool": tool, "input": kwargs}


# ------------------------------------------------------------------
# No permission manager
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_no_permission_manager_allows_all():
    mw = PermissionMiddleware(permission_manager=None)
    tc = _make_tool_call("write_file", path="/tmp/x.py", content="# code")
    events = [ev async for ev in mw.pre_tool(_make_ctx(), tc)]
    assert events == []
    assert "__perm_denied__" not in tc["input"]


# ------------------------------------------------------------------
# Markdown fence stripping
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_strips_markdown_fences_from_write_file():
    mw = PermissionMiddleware(permission_manager=None)
    tc = _make_tool_call("write_file", path="/tmp/x.py", content="```python\ncode\n```")
    [_ async for _ in mw.pre_tool(_make_ctx(), tc)]
    assert tc["input"]["content"] == "code"


@pytest.mark.anyio
async def test_strips_markdown_fences_from_update_file():
    mw = PermissionMiddleware(permission_manager=None)
    tc = _make_tool_call("update_file", path="/tmp/x.py", content="```\ncode\n```")
    [_ async for _ in mw.pre_tool(_make_ctx(), tc)]
    assert tc["input"]["content"] == "code"


@pytest.mark.anyio
async def test_no_fence_stripping_for_read_file():
    mw = PermissionMiddleware(permission_manager=None)
    tc = _make_tool_call("read_file", path="/tmp/x.py")
    [_ async for _ in mw.pre_tool(_make_ctx(), tc)]
    # No content key added
    assert "content" not in tc["input"]


# ------------------------------------------------------------------
# Permission denial
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_permission_denied_sets_flag(monkeypatch):
    pm = MagicMock()
    pm.is_safe_command.return_value = False
    pm.request_permission_async = AsyncMock(return_value=(False, "user said no"))

    monkeypatch.setattr(
        "ctrlcode.permissions.is_destructive",
        lambda name: True,
    )

    mw = PermissionMiddleware(permission_manager=pm)
    tc = _make_tool_call("delete_file", path="/important.py")
    [_ async for _ in mw.pre_tool(_make_ctx(), tc)]
    assert tc["input"]["__perm_denied__"] is True
    assert tc["input"]["__perm_context__"] == "user said no"


@pytest.mark.anyio
async def test_permission_approved_sets_flag(monkeypatch):
    pm = MagicMock()
    pm.is_safe_command.return_value = False
    pm.request_permission_async = AsyncMock(return_value=(True, ""))

    monkeypatch.setattr(
        "ctrlcode.permissions.is_destructive",
        lambda name: True,
    )

    mw = PermissionMiddleware(permission_manager=pm)
    tc = _make_tool_call("delete_file", path="/important.py")
    [_ async for _ in mw.pre_tool(_make_ctx(), tc)]
    assert tc["input"].get("__perm_approved__") is True
    assert "__perm_denied__" not in tc["input"]
