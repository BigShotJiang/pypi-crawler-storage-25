"""Tests for MiddlewareStack."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.session.middleware.base import BaseMiddleware, TurnContext
from ctrlcode.session.middleware.stack import MiddlewareStack
from ctrlcode.providers.base import StreamEvent
from ctrlcode.session.models import Session


def _make_session():
    return MagicMock(spec=Session, id="test-session", context_before_turn=0)


def _make_ctx():
    return TurnContext(session=_make_session(), user_input="hello")


class _RecordingMiddleware(BaseMiddleware):
    def __init__(self, name: str):
        self.name = name
        self.calls: list[str] = []

    async def before_turn(self, ctx: TurnContext) -> None:
        self.calls.append("before_turn")

    async def pre_tool(self, ctx, tool_call):
        self.calls.append("pre_tool")
        return
        yield  # noqa: unreachable

    async def after_tool_call(self, ctx, tool_call, result):
        self.calls.append("after_tool_call")
        return
        yield  # noqa: unreachable

    async def after_turn(self, ctx: TurnContext) -> None:
        self.calls.append("after_turn")

    async def close(self) -> None:
        self.calls.append("close")


# ------------------------------------------------------------------
# run_before_turn
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_before_turn_calls_all_in_order():
    a = _RecordingMiddleware("a")
    b = _RecordingMiddleware("b")
    stack = MiddlewareStack([a, b])
    await stack.run_before_turn(_make_ctx())
    assert a.calls == ["before_turn"]
    assert b.calls == ["before_turn"]


@pytest.mark.anyio
async def test_before_turn_raises_on_failure():
    class BoomMiddleware(BaseMiddleware):
        async def before_turn(self, ctx):
            raise ValueError("boom")

    stack = MiddlewareStack([BoomMiddleware()])
    with pytest.raises(ValueError, match="boom"):
        await stack.run_before_turn(_make_ctx())


# ------------------------------------------------------------------
# pre_tool_hook
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_pre_tool_hook_yields_events_from_all():
    class YieldingMiddleware(BaseMiddleware):
        async def pre_tool(self, ctx, tool_call):
            yield StreamEvent(type="test", data={"mw": "yes"})

    stack = MiddlewareStack([YieldingMiddleware(), YieldingMiddleware()])
    hook = stack.make_pre_tool_hook(_make_ctx())
    events = [ev async for ev in hook({"tool": "foo", "input": {}})]
    assert len(events) == 2
    assert all(e.type == "test" for e in events)


# ------------------------------------------------------------------
# post_tool_hook
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_post_tool_hook_yields_events_from_all():
    class YieldingMiddleware(BaseMiddleware):
        async def after_tool_call(self, ctx, tool_call, result):
            yield StreamEvent(type="post", data={})

    stack = MiddlewareStack([YieldingMiddleware(), YieldingMiddleware()])
    hook = stack.make_post_tool_hook(_make_ctx())
    result = MagicMock(success=True)
    events = [ev async for ev in hook({"tool": "foo", "input": {}}, result)]
    assert len(events) == 2


# ------------------------------------------------------------------
# run_after_turn
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_after_turn_calls_all_in_order():
    a = _RecordingMiddleware("a")
    b = _RecordingMiddleware("b")
    stack = MiddlewareStack([a, b])
    await stack.run_after_turn(_make_ctx())
    assert a.calls == ["after_turn"]
    assert b.calls == ["after_turn"]


@pytest.mark.anyio
async def test_after_turn_swallows_exceptions():
    class BoomMiddleware(BaseMiddleware):
        async def after_turn(self, ctx):
            raise RuntimeError("boom")

    good = _RecordingMiddleware("good")
    stack = MiddlewareStack([BoomMiddleware(), good])
    await stack.run_after_turn(_make_ctx())  # should not raise
    assert good.calls == ["after_turn"]


# ------------------------------------------------------------------
# close
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_close_calls_all_in_reverse_order():
    a = _RecordingMiddleware("a")
    b = _RecordingMiddleware("b")
    c = _RecordingMiddleware("c")
    order = []

    original_close_a = a.close
    original_close_b = b.close
    original_close_c = c.close

    async def close_a():
        order.append("a")
        await original_close_a()

    async def close_b():
        order.append("b")
        await original_close_b()

    async def close_c():
        order.append("c")
        await original_close_c()

    a.close = close_a
    b.close = close_b
    c.close = close_c

    stack = MiddlewareStack([a, b, c])
    await stack.close()
    assert order == ["c", "b", "a"]
