"""Tests for ProgressMiddleware."""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from ctrlcode.session.middleware.progress import ProgressMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session


def _make_ctx(task_summary: str = "", touched_files=None) -> TurnContext:
    session = MagicMock(spec=Session, id="s1", context_before_turn=0)
    ctx = TurnContext(session=session, user_input="x")
    ctx.task_summary = task_summary
    ctx.touched_files = touched_files or []
    return ctx


@pytest.mark.anyio
async def test_no_summary_skips_write(tmp_path):
    mw = ProgressMiddleware(ctrlcode_dir=tmp_path)
    ctx = _make_ctx(task_summary="")
    with patch("ctrlcode.session.middleware.progress.write_progress_file", new_callable=AsyncMock) as mock_write:
        await mw.after_turn(ctx)
        mock_write.assert_not_called()


@pytest.mark.anyio
async def test_summary_triggers_write(tmp_path):
    mw = ProgressMiddleware(ctrlcode_dir=tmp_path)
    ctx = _make_ctx(task_summary="did things", touched_files=["a.py"])
    with patch("ctrlcode.session.middleware.progress.write_progress_file", new_callable=AsyncMock) as mock_write:
        await mw.after_turn(ctx)
        mock_write.assert_called_once_with(tmp_path, "did things", ["a.py"])
