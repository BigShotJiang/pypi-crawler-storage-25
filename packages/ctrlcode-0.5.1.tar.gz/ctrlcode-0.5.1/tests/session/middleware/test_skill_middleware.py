"""Tests for SkillMiddleware."""

import pytest
from unittest.mock import MagicMock

from ctrlcode.session.middleware.skill import SkillMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session


def _make_ctx(user_input: str) -> TurnContext:
    session = MagicMock(spec=Session, id="s1", context_before_turn=0)
    return TurnContext(session=session, user_input=user_input)


def _make_registry(expanded: str, was_skill: bool):
    registry = MagicMock()
    registry.process_input.return_value = (expanded, was_skill)
    return registry


@pytest.mark.anyio
async def test_skill_expanded_updates_user_input():
    registry = _make_registry("expanded prompt", was_skill=True)
    mw = SkillMiddleware(registry)
    ctx = _make_ctx("/commit")
    await mw.before_turn(ctx)
    assert ctx.user_input == "expanded prompt"


@pytest.mark.anyio
async def test_skill_expanded_stores_events():
    registry = _make_registry("expanded prompt", was_skill=True)
    mw = SkillMiddleware(registry)
    ctx = _make_ctx("/commit")
    await mw.before_turn(ctx)
    events = ctx.extra.get("skill_events", [])
    assert len(events) == 1
    assert events[0].type == "skill_expanded"
    assert events[0].data["original"] == "/commit"
    assert events[0].data["expanded"] == "expanded prompt"


@pytest.mark.anyio
async def test_non_skill_input_unchanged():
    registry = _make_registry("hello", was_skill=False)
    mw = SkillMiddleware(registry)
    ctx = _make_ctx("hello")
    await mw.before_turn(ctx)
    assert ctx.user_input == "hello"
    assert ctx.extra.get("skill_events") is None


@pytest.mark.anyio
async def test_unknown_skill_raises_value_error():
    registry = MagicMock()
    registry.process_input.side_effect = ValueError("unknown skill: /nope")
    mw = SkillMiddleware(registry)
    ctx = _make_ctx("/nope")
    with pytest.raises(ValueError, match="unknown skill"):
        await mw.before_turn(ctx)
