"""Tests for WorkspaceMiddleware."""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from ctrlcode.session.middleware.workspace import WorkspaceMiddleware
from ctrlcode.session.middleware.memory import MemoryMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session


def _make_session(session_id: str = "s1") -> MagicMock:
    return MagicMock(spec=Session, id=session_id, context_before_turn=0)


def _make_ctx(session_id: str = "s1") -> TurnContext:
    session = _make_session(session_id)
    return TurnContext(session=session, user_input="hi")


def _make_memory_mw() -> MagicMock:
    mw = MagicMock(spec=MemoryMiddleware)
    mw.ensure = AsyncMock()
    mw._memory = MagicMock()
    mw._memory._store = MagicMock()
    mw._assemblers = {}
    return mw


# ------------------------------------------------------------------
# before_turn — no workspace_root
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_no_workspace_root_skips_monitor():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=None,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()
    await mw.before_turn(ctx)
    assert mw.monitor is None


# ------------------------------------------------------------------
# before_turn — monitor created and idempotent
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_monitor_created_on_first_call(tmp_path):
    memory_mw = _make_memory_mw()
    sessions = {"s1": MagicMock(conv_id="c1")}
    mw = WorkspaceMiddleware(
        workspace_root=tmp_path,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions=sessions,
    )
    ctx = _make_ctx()

    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = MagicMock()
    fake_changeset = MagicMock(is_empty=True)
    fake_monitor.refresh = AsyncMock(return_value=fake_changeset)
    fake_monitor.start_watching = AsyncMock()
    fake_monitor.stop_watching = AsyncMock()

    with patch("ctrlcode.session.middleware.workspace.WorkspaceMonitor", return_value=fake_monitor):
        await mw.before_turn(ctx)

    assert mw.monitor is fake_monitor


@pytest.mark.anyio
async def test_before_turn_idempotent(tmp_path):
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=tmp_path,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()

    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = MagicMock()
    fake_changeset = MagicMock(is_empty=True)
    fake_monitor.refresh = AsyncMock(return_value=fake_changeset)
    fake_monitor.start_watching = AsyncMock()

    with patch("ctrlcode.session.middleware.workspace.WorkspaceMonitor", return_value=fake_monitor) as mock_cls:
        await mw.before_turn(ctx)
        await mw.before_turn(ctx)

    # Monitor constructor called only once
    assert mock_cls.call_count == 1


# ------------------------------------------------------------------
# after_tool_call — blast-radius warning
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_after_tool_call_no_monitor_skips():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=None,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()
    result = MagicMock(success=True)
    events = [ev async for ev in mw.after_tool_call(ctx, {"tool": "write_file", "input": {"path": "a.py"}}, result)]
    assert events == []


@pytest.mark.anyio
async def test_after_tool_call_failed_result_skips():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    mw._monitor = MagicMock()
    ctx = _make_ctx()
    result = MagicMock(success=False)
    events = [ev async for ev in mw.after_tool_call(ctx, {"tool": "write_file", "input": {"path": "a.py"}}, result)]
    assert events == []


# ------------------------------------------------------------------
# after_turn — updates workspace index for touched files
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_after_turn_no_monitor_skips():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=None,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()
    ctx.touched_files = ["a.py"]
    await mw.after_turn(ctx)  # should not raise


@pytest.mark.anyio
async def test_after_turn_calls_update_file_for_each_touched():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    fake_monitor = MagicMock()
    fake_monitor.update_file = AsyncMock()
    mw._monitor = fake_monitor

    ctx = _make_ctx()
    ctx.touched_files = ["a.py", "b.py"]
    await mw.after_turn(ctx)

    assert fake_monitor.update_file.call_count == 2


# ------------------------------------------------------------------
# close
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_close_stops_watcher():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    fake_monitor = MagicMock()
    fake_monitor.stop_watching = AsyncMock()
    mw._monitor = fake_monitor

    await mw.close()
    fake_monitor.stop_watching.assert_called_once()
    assert mw.monitor is None


@pytest.mark.anyio
async def test_close_no_monitor_does_not_raise():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=None,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    await mw.close()  # should not raise


@pytest.mark.anyio
async def test_monitor_logs_non_empty_changeset(tmp_path, caplog):
    import logging
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=tmp_path,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()

    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = MagicMock()
    fake_changeset = MagicMock(is_empty=False, added=["a.py"], modified=[], moved=[], deleted=[])
    fake_monitor.refresh = AsyncMock(return_value=fake_changeset)
    fake_monitor.start_watching = AsyncMock()

    with patch("ctrlcode.session.middleware.workspace.WorkspaceMonitor", return_value=fake_monitor):
        with caplog.at_level(logging.INFO):
            await mw.before_turn(ctx)

    assert "Workspace changed" in caplog.text


@pytest.mark.anyio
async def test_monitor_refresh_failure_is_non_fatal(tmp_path, caplog):
    import logging
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=tmp_path,
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    ctx = _make_ctx()

    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = MagicMock()
    fake_monitor.refresh = AsyncMock(side_effect=RuntimeError("disk error"))
    fake_monitor.start_watching = AsyncMock()

    with patch("ctrlcode.session.middleware.workspace.WorkspaceMonitor", return_value=fake_monitor):
        with caplog.at_level(logging.WARNING):
            await mw.before_turn(ctx)  # should not raise

    assert "non-fatal" in caplog.text


@pytest.mark.anyio
async def test_after_tool_call_blast_radius_no_session_skips():
    """No session in sessions dict → early return, no blast-radius warning."""
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},  # session not present
    )
    mw._monitor = MagicMock()
    ctx = _make_ctx("s1")
    result = MagicMock(success=True)
    events = [ev async for ev in mw.after_tool_call(ctx, {"tool": "write_file", "input": {"path": "a.py"}}, result)]
    assert events == []


@pytest.mark.anyio
async def test_after_tool_call_blast_radius_with_dependents():
    memory_mw = _make_memory_mw()
    conv_manager = MagicMock()
    session = MagicMock(conv_id="c1")
    sessions = {"s1": session}
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=conv_manager,
        sessions=sessions,
    )
    dep_indexer = MagicMock()
    dep_indexer.get_dependents = AsyncMock(return_value=["b.py", "c.py"])
    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = dep_indexer
    mw._monitor = fake_monitor

    ctx = _make_ctx("s1")
    result = MagicMock(success=True)
    events = [ev async for ev in mw.after_tool_call(ctx, {"tool": "write_file", "input": {"path": "a.py"}}, result)]

    assert events == []  # no yielded events
    conv_manager.add_message.assert_called_once()
    call_args = conv_manager.add_message.call_args[0]
    assert call_args[0] == "c1"


@pytest.mark.anyio
async def test_after_tool_call_no_dependents_skips_warning():
    memory_mw = _make_memory_mw()
    conv_manager = MagicMock()
    session = MagicMock(conv_id="c1")
    sessions = {"s1": session}
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=conv_manager,
        sessions=sessions,
    )
    dep_indexer = MagicMock()
    dep_indexer.get_dependents = AsyncMock(return_value=[])
    fake_monitor = MagicMock()
    fake_monitor.dep_indexer = dep_indexer
    mw._monitor = fake_monitor

    ctx = _make_ctx("s1")
    result = MagicMock(success=True)
    [_ async for _ in mw.after_tool_call(ctx, {"tool": "write_file", "input": {"path": "a.py"}}, result)]

    conv_manager.add_message.assert_not_called()


@pytest.mark.anyio
async def test_after_turn_update_file_exception_is_swallowed():
    memory_mw = _make_memory_mw()
    mw = WorkspaceMiddleware(
        workspace_root=MagicMock(),
        memory_mw=memory_mw,
        conv_manager=MagicMock(),
        sessions={},
    )
    fake_monitor = MagicMock()
    fake_monitor.update_file = AsyncMock(side_effect=RuntimeError("io error"))
    mw._monitor = fake_monitor

    ctx = _make_ctx()
    ctx.touched_files = ["a.py"]
    await mw.after_turn(ctx)  # should not raise
