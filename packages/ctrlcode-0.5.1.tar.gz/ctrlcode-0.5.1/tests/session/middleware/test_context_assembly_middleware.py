"""Tests for ContextAssemblyMiddleware."""

import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from ctrlcode.session.middleware.context_assembly import ContextAssemblyMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session


def _make_mw(tmp_path: Path) -> ContextAssemblyMiddleware:
    return ContextAssemblyMiddleware(
        base_prompt="You are an agent.",
        agent_instructions="",
        verification_commands=[],
        ctrlcode_dir=tmp_path / ".ctrlcode",
        workspace_root=tmp_path,
        context_limit=100000,
    )


def _make_ctx(assembler=None, context_before_turn: int = 0) -> TurnContext:
    session = MagicMock(spec=Session, id="s1", context_before_turn=context_before_turn)
    ctx = TurnContext(session=session, user_input="do the thing")
    if assembler is not None:
        ctx.extra["assembler"] = assembler
    return ctx


@pytest.mark.anyio
async def test_no_assembler_skips_build(tmp_path):
    mw = _make_mw(tmp_path)
    ctx = _make_ctx(assembler=None)
    await mw.before_turn(ctx)
    assert ctx.system_prompt_msg is None


@pytest.mark.anyio
async def test_system_prompt_built_and_stored(tmp_path):
    mw = _make_mw(tmp_path)
    assembler = MagicMock()
    ctx = _make_ctx(assembler=assembler)

    fake_msg = {"role": "system", "content": "built prompt"}
    with patch(
        "ctrlcode.session.middleware.context_assembly.build_system_prompt",
        new_callable=AsyncMock,
        return_value=fake_msg,
    ) as mock_build:
        await mw.before_turn(ctx)

    assert ctx.system_prompt_msg == fake_msg
    mock_build.assert_called_once()


@pytest.mark.anyio
async def test_build_failure_leaves_prompt_none(tmp_path):
    mw = _make_mw(tmp_path)
    assembler = MagicMock()
    ctx = _make_ctx(assembler=assembler)

    with patch(
        "ctrlcode.session.middleware.context_assembly.build_system_prompt",
        new_callable=AsyncMock,
        side_effect=RuntimeError("network error"),
    ):
        await mw.before_turn(ctx)  # should not raise

    assert ctx.system_prompt_msg is None


@pytest.mark.anyio
async def test_passes_user_input_to_build(tmp_path):
    mw = _make_mw(tmp_path)
    assembler = MagicMock()
    ctx = _make_ctx(assembler=assembler)
    ctx.user_input = "specific query"

    with patch(
        "ctrlcode.session.middleware.context_assembly.build_system_prompt",
        new_callable=AsyncMock,
        return_value={"role": "system", "content": "x"},
    ) as mock_build:
        await mw.before_turn(ctx)

    _, kwargs = mock_build.call_args
    assert kwargs.get("user_input") == "specific query" or mock_build.call_args[0][-1] == "specific query"
