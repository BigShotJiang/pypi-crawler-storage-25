"""Tests for BaselineMiddleware."""

import pytest
from unittest.mock import MagicMock

from ctrlcode.session.middleware.baseline import BaselineMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.session.models import Session
from ctrlcode.session.baseline import BaselineManager, Baseline


def _make_ctx(user_input: str) -> TurnContext:
    session = MagicMock(spec=Session, id="s1", context_before_turn=0)
    return TurnContext(session=session, user_input=user_input)


@pytest.mark.anyio
async def test_no_baseline_does_not_store():
    manager = MagicMock(spec=BaselineManager)
    manager.extract_from_request.return_value = None
    mw = BaselineMiddleware(baseline_manager=manager, session_id="s1")
    ctx = _make_ctx("just a normal message")
    await mw.before_turn(ctx)
    manager.store.assert_not_called()


@pytest.mark.anyio
async def test_baseline_extracted_and_stored():
    manager = MagicMock(spec=BaselineManager)
    manager.extract_from_request.return_value = "def foo(): pass"
    mw = BaselineMiddleware(baseline_manager=manager, session_id="s1")
    ctx = _make_ctx("```python\ndef foo(): pass\n```")
    await mw.before_turn(ctx)
    manager.store.assert_called_once()
    call_args = manager.store.call_args
    assert call_args[0][0] == "s1"
    assert isinstance(call_args[0][1], Baseline)
    assert call_args[0][1].code == "def foo(): pass"
