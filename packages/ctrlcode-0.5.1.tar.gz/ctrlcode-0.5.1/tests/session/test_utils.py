"""Tests for session utils — strip_markdown_fences, generate_msg_id."""

import re

from ctrlcode.session.utils import generate_msg_id, strip_markdown_fences


# ---------------------------------------------------------------------------
# strip_markdown_fences
# ---------------------------------------------------------------------------

def test_removes_opening_fence():
    result = strip_markdown_fences("```python\ncode here\n```")
    assert result == "code here"


def test_removes_plain_fence():
    result = strip_markdown_fences("```\nsome content\n```")
    assert result == "some content"


def test_no_fences_unchanged():
    content = "just plain text\nno fences"
    assert strip_markdown_fences(content) == content


def test_only_opening_fence_removed():
    result = strip_markdown_fences("```python\ncode here")
    assert result == "code here"


def test_only_closing_fence_removed():
    # First line is not a fence, last line is
    result = strip_markdown_fences("code here\n```")
    assert result == "code here"


def test_strips_run_with_trailing_line():
    # "Run with:" at end (no closing fence after it)
    result = strip_markdown_fences("code\nRun with: python main.py")
    assert "Run with:" not in result
    assert "code" in result


def test_strips_multiple_run_with_lines():
    result = strip_markdown_fences("code\nRun with: foo\nRun with: bar")
    assert "Run with:" not in result
    assert "code" in result


def test_empty_string():
    assert strip_markdown_fences("") == ""


def test_fence_with_language_tag_removed():
    result = strip_markdown_fences("```typescript\nconst x = 1;\n```")
    assert "typescript" not in result
    assert "const x = 1;" in result


# ---------------------------------------------------------------------------
# generate_msg_id
# ---------------------------------------------------------------------------

def test_generate_msg_id_prefix():
    assert generate_msg_id().startswith("msg_")


def test_generate_msg_id_length():
    # "msg_" + 12 hex chars = 16 chars
    assert len(generate_msg_id()) == 16


def test_generate_msg_id_hex_suffix():
    msg_id = generate_msg_id()
    suffix = msg_id[4:]  # strip "msg_"
    assert re.fullmatch(r"[0-9a-f]{12}", suffix)


def test_generate_msg_id_unique():
    ids = {generate_msg_id() for _ in range(100)}
    assert len(ids) == 100
