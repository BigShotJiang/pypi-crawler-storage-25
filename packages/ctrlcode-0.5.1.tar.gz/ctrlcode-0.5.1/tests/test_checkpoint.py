"""Tests for CheckpointManager — async blocking, response handling, global singleton."""

import asyncio
import pytest

from ctrlcode.checkpoint import (
    CheckpointManager,
    get_checkpoint_manager,
    set_checkpoint_manager,
)


@pytest.fixture
def manager():
    return CheckpointManager()


# ---------------------------------------------------------------------------
# handle_checkpoint_response
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_continue_response_resolves_true(manager):
    async def responder():
        await asyncio.sleep(0)
        manager.handle_checkpoint_response("cp1", "continue")

    asyncio.create_task(responder())
    result = await manager.request_checkpoint("cp1", timeout=5.0)
    assert result is True


@pytest.mark.anyio
async def test_abort_response_resolves_false(manager):
    async def responder():
        await asyncio.sleep(0)
        manager.handle_checkpoint_response("cp1", "abort")

    asyncio.create_task(responder())
    result = await manager.request_checkpoint("cp1", timeout=5.0)
    assert result is False


@pytest.mark.anyio
async def test_timeout_auto_continues(manager):
    result = await manager.request_checkpoint("cp-timeout", timeout=0.05)
    assert result is True


@pytest.mark.anyio
async def test_checkpoint_removed_after_resolution(manager):
    async def responder():
        await asyncio.sleep(0)
        manager.handle_checkpoint_response("cp2", "continue")

    asyncio.create_task(responder())
    await manager.request_checkpoint("cp2", timeout=5.0)
    assert "cp2" not in manager._pending


def test_handle_unknown_checkpoint_no_crash(manager):
    manager.handle_checkpoint_response("nonexistent", "continue")


@pytest.mark.anyio
async def test_handle_already_resolved_no_crash(manager):
    async def responder():
        await asyncio.sleep(0)
        manager.handle_checkpoint_response("cp3", "continue")
        manager.handle_checkpoint_response("cp3", "continue")  # second call

    asyncio.create_task(responder())
    await manager.request_checkpoint("cp3", timeout=5.0)


# ---------------------------------------------------------------------------
# Global singleton
# ---------------------------------------------------------------------------

def test_get_checkpoint_manager_initially_none():
    set_checkpoint_manager(None)
    assert get_checkpoint_manager() is None


def test_set_and_get_checkpoint_manager():
    m = CheckpointManager()
    set_checkpoint_manager(m)
    assert get_checkpoint_manager() is m
    set_checkpoint_manager(None)  # cleanup
