"""Tests for UpdateFileTools — update_file operations, security, regex validation."""

import pytest
from pathlib import Path

from ctrlcode.tools.update import UpdateFileTools


@pytest.fixture
def tools(tmp_path):
    return UpdateFileTools(tmp_path)


def make_file(tmp_path: Path, name: str, content: str) -> str:
    """Write a file and return its name relative to tmp_path."""
    (tmp_path / name).write_text(content)
    return name


# ---------------------------------------------------------------------------
# replace operation
# ---------------------------------------------------------------------------

def test_replace_single_line(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "line1\nline2\nline3\n")
    result = tools.update_file(name, "replace", start_line=2, content="replaced")
    assert result["success"] is True
    content = (tmp_path / name).read_text()
    assert "replaced" in content
    assert "line1" in content
    assert "line3" in content


def test_replace_range(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "a\nb\nc\nd\n")
    result = tools.update_file(name, "replace", start_line=2, end_line=3, content="new")
    assert result["success"] is True
    text = (tmp_path / name).read_text()
    assert "new" in text
    assert "b" not in text
    assert "c" not in text


def test_replace_adds_trailing_newline(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "line1\n")
    tools.update_file(name, "replace", start_line=1, content="no newline")
    text = (tmp_path / name).read_text()
    assert text.endswith("\n")


def test_replace_requires_content(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "x\n")
    result = tools.update_file(name, "replace", start_line=1)
    assert "error" in result


# ---------------------------------------------------------------------------
# insert operation
# ---------------------------------------------------------------------------

def test_insert_before_line(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "first\nsecond\n")
    result = tools.update_file(name, "insert", start_line=2, content="inserted")
    assert result["success"] is True
    lines = (tmp_path / name).read_text().splitlines()
    assert lines[1] == "inserted"
    assert lines[2] == "second"


def test_insert_requires_content(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "x\n")
    result = tools.update_file(name, "insert", start_line=1)
    assert "error" in result


# ---------------------------------------------------------------------------
# delete operation
# ---------------------------------------------------------------------------

def test_delete_single_line(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "keep\ndelete_me\nkeep\n")
    result = tools.update_file(name, "delete", start_line=2)
    assert result["success"] is True
    text = (tmp_path / name).read_text()
    assert "delete_me" not in text
    assert text.count("keep") == 2


def test_delete_range(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "a\nb\nc\nd\n")
    result = tools.update_file(name, "delete", start_line=2, end_line=3)
    assert result["success"] is True
    lines = (tmp_path / name).read_text().splitlines()
    assert "b" not in lines
    assert "c" not in lines


# ---------------------------------------------------------------------------
# search_pattern
# ---------------------------------------------------------------------------

def test_search_pattern_finds_and_replaces(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "foo = 1\nbar = 2\nbaz = 3\n")
    result = tools.update_file(name, "replace", search_pattern="bar", content="bar = 99")
    assert result["success"] is True
    text = (tmp_path / name).read_text()
    assert "bar = 99" in text


def test_search_pattern_not_found_error(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "foo\nbar\n")
    result = tools.update_file(name, "replace", search_pattern="zzz", content="x")
    assert "error" in result


def test_search_pattern_delete_multiple_matches(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "keep\ndelete\ndelete\nkeep\n")
    result = tools.update_file(name, "delete", search_pattern="delete")
    assert result["success"] is True


# ---------------------------------------------------------------------------
# Validation and error handling
# ---------------------------------------------------------------------------

def test_path_outside_workspace_rejected(tools):
    result = tools.update_file("../../etc/passwd", "replace", start_line=1, content="x")
    assert "error" in result


def test_file_not_found_error(tools):
    result = tools.update_file("nonexistent.py", "replace", start_line=1, content="x")
    assert "error" in result


def test_invalid_operation_rejected(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "line\n")
    result = tools.update_file(name, "rewrite", start_line=1, content="x")
    assert "error" in result


def test_start_line_out_of_range(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "one\n")
    result = tools.update_file(name, "replace", start_line=99, content="x")
    assert "error" in result


def test_end_line_out_of_range(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "one\ntwo\n")
    result = tools.update_file(name, "replace", start_line=1, end_line=99, content="x")
    assert "error" in result


def test_no_start_line_no_pattern_error(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "x\n")
    result = tools.update_file(name, "replace", content="y")
    assert "error" in result


# ---------------------------------------------------------------------------
# _validate_regex_pattern
# ---------------------------------------------------------------------------

def test_validate_valid_pattern():
    valid, msg = UpdateFileTools._validate_regex_pattern(r"\bfoo\b")
    assert valid is True
    assert msg == ""


def test_validate_invalid_regex():
    valid, msg = UpdateFileTools._validate_regex_pattern(r"[unclosed")
    assert valid is False
    assert "Invalid regex" in msg


def test_validate_pattern_too_long():
    long_pattern = "a" * 501
    valid, msg = UpdateFileTools._validate_regex_pattern(long_pattern)
    assert valid is False
    assert "too long" in msg


def test_validate_nested_quantifier_rejected():
    # (a+)+ is a classic ReDoS pattern
    valid, msg = UpdateFileTools._validate_regex_pattern(r"(a+)+")
    assert valid is False
    assert "nested quantifiers" in msg


# ---------------------------------------------------------------------------
# result fields
# ---------------------------------------------------------------------------

def test_result_includes_operation(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "x\n")
    result = tools.update_file(name, "delete", start_line=1)
    assert result.get("operation") == "delete"


def test_result_includes_line_counts(tools, tmp_path):
    name = make_file(tmp_path, "f.py", "a\nb\nc\n")
    result = tools.update_file(name, "delete", start_line=2)
    assert result.get("lines_before") == 3
    assert result.get("lines_after") == 2
