"""Tests for SkillLoader — load_skill, load_all, load_from_paths, metadata parsing."""

from pathlib import Path

import pytest

from ctrlcode.skills.loader import Skill, SkillLoader


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_skill_folder(parent: Path, name: str, skill_md: str, readme: str | None = None) -> Path:
    folder = parent / name
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "SKILL.md").write_text(skill_md)
    if readme is not None:
        (folder / "README.md").write_text(readme)
    return folder


# ---------------------------------------------------------------------------
# load_skill — happy path
# ---------------------------------------------------------------------------

def test_load_skill_returns_skill(tmp_path):
    folder = make_skill_folder(tmp_path, "greet", "# Greet\nSay hello {args}")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill is not None
    assert skill.name == "greet"


def test_load_skill_reads_instructions(tmp_path):
    folder = make_skill_folder(tmp_path, "deploy", "Deploy the app to {args}")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert "Deploy the app" in skill.instructions


def test_load_skill_infers_description_from_first_line(tmp_path):
    folder = make_skill_folder(tmp_path, "foo", "# My Skill\nDo stuff")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.description == "My Skill"


def test_load_skill_readme_overrides_description(tmp_path):
    folder = make_skill_folder(tmp_path, "bar", "# Bar\nDo bar", readme="A custom README.")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.description == "A custom README."


def test_load_skill_folder_path_set(tmp_path):
    folder = make_skill_folder(tmp_path, "baz", "# Baz")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.folder_path == folder


def test_load_skill_scripts_loaded(tmp_path):
    folder = make_skill_folder(tmp_path, "scripted", "# Script")
    scripts_dir = folder / "scripts"
    scripts_dir.mkdir()
    (scripts_dir / "run.sh").write_text("#!/bin/bash\necho hi")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert len(skill.scripts) == 1


def test_load_skill_resources_loaded(tmp_path):
    folder = make_skill_folder(tmp_path, "resourced", "# Resource")
    res_dir = folder / "resources"
    res_dir.mkdir()
    (res_dir / "data.txt").write_text("reference data")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert len(skill.resources) == 1


def test_load_skill_no_scripts_or_resources_empty(tmp_path):
    folder = make_skill_folder(tmp_path, "minimal", "# Minimal")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.scripts == []
    assert skill.resources == []


# ---------------------------------------------------------------------------
# load_skill — missing SKILL.md
# ---------------------------------------------------------------------------

def test_load_skill_missing_skill_md_returns_none(tmp_path):
    folder = tmp_path / "empty_skill"
    folder.mkdir()
    loader = SkillLoader()
    assert loader.load_skill(folder) is None


# ---------------------------------------------------------------------------
# _parse_requires_args
# ---------------------------------------------------------------------------

def test_parse_requires_args_default_false(tmp_path):
    folder = make_skill_folder(tmp_path, "norequire", "# Simple\nJust do it")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


def test_parse_requires_args_inline_yes(tmp_path):
    content = "# Skill\n**Requires arguments**: yes\nDo stuff with {args}"
    folder = make_skill_folder(tmp_path, "withargs", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is True


def test_parse_requires_args_inline_no(tmp_path):
    content = "# Skill\n**Requires arguments**: no\nDo stuff"
    folder = make_skill_folder(tmp_path, "noargs", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


# ---------------------------------------------------------------------------
# _parse_examples
# ---------------------------------------------------------------------------

def test_parse_examples_from_code_block(tmp_path):
    content = "# Skill\nInstructions.\n\n## Examples\n\n```\n/skill foo\n/skill bar\n```"
    folder = make_skill_folder(tmp_path, "ex", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert "/skill foo" in skill.examples


def test_parse_examples_from_bullet_points(tmp_path):
    content = "# Skill\nInstructions.\n\n## Examples\n\n- \"example one\"\n- \"example two\""
    folder = make_skill_folder(tmp_path, "bex", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert "example one" in skill.examples


def test_parse_examples_empty_when_no_section(tmp_path):
    folder = make_skill_folder(tmp_path, "noex", "# Skill\nJust instructions.")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.examples == []


# ---------------------------------------------------------------------------
# load_all
# ---------------------------------------------------------------------------

def test_load_all_loads_multiple_skills(tmp_path):
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    make_skill_folder(skills_dir, "alpha", "# Alpha")
    make_skill_folder(skills_dir, "beta", "# Beta")
    loader = SkillLoader(skills_dir)
    skills = loader.load_all()
    assert "alpha" in skills
    assert "beta" in skills


def test_load_all_skips_non_directories(tmp_path):
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    (skills_dir / "notadir.md").write_text("ignore me")
    make_skill_folder(skills_dir, "real", "# Real")
    loader = SkillLoader(skills_dir)
    skills = loader.load_all()
    assert "real" in skills
    assert "notadir.md" not in skills


def test_load_all_missing_dir_returns_empty(tmp_path):
    loader = SkillLoader(tmp_path / "nonexistent")
    assert loader.load_all() == {}


def test_load_all_none_dir_returns_empty():
    loader = SkillLoader(None)
    assert loader.load_all() == {}


# ---------------------------------------------------------------------------
# load_from_paths
# ---------------------------------------------------------------------------

def test_load_from_paths_multiple_dirs(tmp_path):
    dir_a = tmp_path / "a"
    dir_b = tmp_path / "b"
    dir_a.mkdir()
    dir_b.mkdir()
    make_skill_folder(dir_a, "skill_a", "# A")
    make_skill_folder(dir_b, "skill_b", "# B")
    loader = SkillLoader()
    skills = loader.load_from_paths([dir_a, dir_b])
    assert "skill_a" in skills
    assert "skill_b" in skills


def test_load_from_paths_first_wins_on_duplicate(tmp_path):
    dir_a = tmp_path / "a"
    dir_b = tmp_path / "b"
    dir_a.mkdir()
    dir_b.mkdir()
    make_skill_folder(dir_a, "shared", "# From A")
    make_skill_folder(dir_b, "shared", "# From B")
    loader = SkillLoader()
    skills = loader.load_from_paths([dir_a, dir_b])
    assert "From A" in skills["shared"].instructions


def test_load_from_paths_skips_missing_dirs(tmp_path):
    real_dir = tmp_path / "real"
    real_dir.mkdir()
    make_skill_folder(real_dir, "sk", "# Sk")
    loader = SkillLoader()
    skills = loader.load_from_paths([tmp_path / "missing", real_dir])
    assert "sk" in skills


# ---------------------------------------------------------------------------
# YAML frontmatter parsing
# ---------------------------------------------------------------------------

FRONTMATTER_SKILL = """\
---
name: deploy
description: Deploy the application to production
license: builtin
requires_args: true
---

# Deploy

## Instructions

Run deployment pipeline for {args}.
"""


def test_frontmatter_name_overrides_folder_name(tmp_path):
    folder = make_skill_folder(tmp_path, "deploy-folder", FRONTMATTER_SKILL)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill is not None
    assert skill.name == "deploy"


def test_frontmatter_description_used(tmp_path):
    folder = make_skill_folder(tmp_path, "deploy", FRONTMATTER_SKILL)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.description == "Deploy the application to production"


def test_frontmatter_requires_args_true(tmp_path):
    folder = make_skill_folder(tmp_path, "deploy", FRONTMATTER_SKILL)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is True


def test_frontmatter_requires_args_false(tmp_path):
    content = "---\nrequires_args: false\n---\n# NoArgs\nDo stuff"
    folder = make_skill_folder(tmp_path, "noargs", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


def test_frontmatter_description_beats_readme(tmp_path):
    folder = make_skill_folder(tmp_path, "deploy", FRONTMATTER_SKILL, readme="README description")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.description == "Deploy the application to production"


def test_no_frontmatter_falls_back_to_inference(tmp_path):
    folder = make_skill_folder(tmp_path, "plain", "# Plain Skill\nDo stuff")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.name == "plain"
    assert skill.description == "Plain Skill"


def test_malformed_frontmatter_falls_back(tmp_path):
    # No closing ---
    content = "---\nname: broken\n# Body starts here\nDo stuff"
    folder = make_skill_folder(tmp_path, "broken", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill is not None  # should not raise


def test_source_field_propagated_via_load_all(tmp_path):
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    make_skill_folder(skills_dir, "alpha", "# Alpha")
    loader = SkillLoader(skills_dir)
    skills = loader.load_all(source="project")
    assert skills["alpha"].source == "project"


def test_source_field_propagated_via_load_skill(tmp_path):
    folder = make_skill_folder(tmp_path, "beta", "# Beta")
    loader = SkillLoader()
    skill = loader.load_skill(folder, source="global")
    assert skill.source == "global"


def test_source_defaults_to_empty(tmp_path):
    folder = make_skill_folder(tmp_path, "gamma", "# Gamma")
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.source == ""


def test_source_propagated_via_load_from_paths(tmp_path):
    dir_a = tmp_path / "a"
    dir_a.mkdir()
    make_skill_folder(dir_a, "delta", "# Delta")
    loader = SkillLoader()
    skills = loader.load_from_paths([dir_a], source="project")
    assert skills["delta"].source == "project"


def test_load_from_paths_source_defaults_to_empty(tmp_path):
    dir_a = tmp_path / "a"
    dir_a.mkdir()
    make_skill_folder(dir_a, "epsilon", "# Epsilon")
    loader = SkillLoader()
    skills = loader.load_from_paths([dir_a])
    assert skills["epsilon"].source == ""


# ---------------------------------------------------------------------------
# Additional edge cases to cover pre-existing branches
# ---------------------------------------------------------------------------

def test_parse_requires_args_metadata_section_yes(tmp_path):
    content = "# Skill\n\n## Metadata\n\n- **Requires arguments**: yes\n\n## Instructions\n\nDo stuff"
    folder = make_skill_folder(tmp_path, "meta_yes", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is True


def test_parse_requires_args_metadata_section_no(tmp_path):
    content = "# Skill\n\n## Metadata\n\n- **Requires arguments**: no\n\n## Instructions\n\nDo stuff"
    folder = make_skill_folder(tmp_path, "meta_no", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


def test_parse_requires_args_metadata_section_empty_no_crash(tmp_path):
    # ## Metadata section exists but has no "requires arguments" line → default False
    content = "# Skill\n\n## Metadata\n\nSome other note here.\n"
    folder = make_skill_folder(tmp_path, "meta_empty", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


def test_parse_requires_args_metadata_section_terminated_by_next_heading(tmp_path):
    # Inner loop should break when another ## heading is found
    content = "# Skill\n\n## Metadata\n\n## NextSection\n\nContent"
    folder = make_skill_folder(tmp_path, "meta_term", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.requires_args is False


def test_parse_examples_stops_at_next_section(tmp_path):
    content = (
        "# Skill\nInstructions.\n\n## Examples\n\n```\n/skill foo\n```\n\n"
        "## Other Section\n\nMore content"
    )
    folder = make_skill_folder(tmp_path, "multisec", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert "/skill foo" in skill.examples


def test_frontmatter_unknown_key_ignored(tmp_path):
    content = "---\nunknown_key: some value\nname: myfoo\n---\n# Myfoo\nDo stuff"
    folder = make_skill_folder(tmp_path, "myfoo", content)
    loader = SkillLoader()
    skill = loader.load_skill(folder)
    assert skill.name == "myfoo"


def test_load_all_swallows_exception_from_bad_skill(tmp_path):
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    # Valid skill
    make_skill_folder(skills_dir, "good", "# Good")
    # Corrupt folder: SKILL.md is a directory (will fail to read)
    bad = skills_dir / "bad"
    bad.mkdir()
    (bad / "SKILL.md").mkdir()  # directory instead of file — read will fail
    loader = SkillLoader(skills_dir)
    skills = loader.load_all()
    assert "good" in skills  # bad skill didn't abort the whole load


def test_load_from_paths_swallows_exception_from_bad_skill(tmp_path):
    dir_a = tmp_path / "a"
    dir_a.mkdir()
    make_skill_folder(dir_a, "ok", "# Ok")
    bad = dir_a / "bad"
    bad.mkdir()
    (bad / "SKILL.md").mkdir()
    loader = SkillLoader()
    skills = loader.load_from_paths([dir_a])
    assert "ok" in skills
