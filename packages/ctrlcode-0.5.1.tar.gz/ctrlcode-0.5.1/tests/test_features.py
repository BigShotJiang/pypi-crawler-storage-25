"""Tests for project-scoped todos (scope='project') replacing the old FeatureTools."""

import json
import pytest
from pathlib import Path

from ctrlcode.tools.todo import TodoTools


@pytest.fixture
def workspace(tmp_path):
    return tmp_path


@pytest.fixture
def data_dir(tmp_path):
    return tmp_path / "data"


@pytest.fixture
def todo(workspace, data_dir):
    return TodoTools(data_dir, workspace_root=workspace)


# ------------------------------------------------------------------
# Writing project-scoped todos
# ------------------------------------------------------------------

def test_project_todo_write_creates_workspace_file(todo, workspace):
    todo.todo_write([{"content": "Add auth"}], scope="project")
    assert (workspace / ".ctrlcode" / "todos" / "project.json").exists()


def test_project_todo_write_returns_created_with_id(todo):
    r = todo.todo_write([{"content": "Add auth"}], scope="project")
    assert r["success"] is True
    t = r["todos"][0]
    assert t["content"] == "Add auth"
    assert "id" in t
    assert t["scope"] == "project"


def test_project_todo_defaults(todo):
    r = todo.todo_write([{"content": "Search feature"}], scope="project")
    t = r["todos"][0]
    assert t["status"] == "pending"
    assert t["priority"] == "medium"
    assert t["steps"] == []


def test_project_todo_explicit_status(todo):
    r = todo.todo_write([{"content": "Done thing", "status": "completed"}], scope="project")
    assert r["todos"][0]["status"] == "completed"


def test_project_todo_write_appends(todo):
    todo.todo_write([{"content": "Item A"}], scope="project")
    todo.todo_write([{"content": "Item B"}], scope="project")
    r = todo.todo_list(scope="project")
    assert len(r["todos"]) == 2


def test_project_todo_isolated_from_session_todos(todo):
    todo.todo_write([{"content": "Project item"}], scope="project")
    todo.todo_write([{"content": "Session item"}], session_id="sess-1")

    project = todo.todo_list(scope="project")
    session = todo.todo_list(session_id="sess-1")

    assert len(project["todos"]) == 1
    assert project["todos"][0]["content"] == "Project item"
    assert len(session["todos"]) == 1
    assert session["todos"][0]["content"] == "Session item"


# ------------------------------------------------------------------
# Listing project-scoped todos
# ------------------------------------------------------------------

def test_project_todo_list_all(todo):
    todo.todo_write([{"content": "A"}, {"content": "B"}], scope="project")
    r = todo.todo_list(scope="project")
    assert r["success"] is True
    assert len(r["todos"]) == 2


def test_project_todo_list_empty(todo):
    r = todo.todo_list(scope="project")
    assert r["todos"] == []


def test_project_todo_list_filtered_by_status(todo):
    todo.todo_write([
        {"content": "Pending one"},
        {"content": "Done one", "status": "completed"},
    ], scope="project")
    r = todo.todo_list(scope="project", status="pending")
    assert len(r["todos"]) == 1
    assert r["todos"][0]["content"] == "Pending one"


# ------------------------------------------------------------------
# Updating project-scoped todos
# ------------------------------------------------------------------

def test_project_todo_update_status(todo):
    tid = todo.todo_write([{"content": "Work item"}], scope="project")["todos"][0]["id"]
    r = todo.todo_update(tid, status="in_progress", scope="project")
    assert r["success"] is True
    assert r["todos"][0]["status"] == "in_progress"


def test_project_todo_update_content(todo):
    tid = todo.todo_write([{"content": "Old"}], scope="project")["todos"][0]["id"]
    todo.todo_update(tid, content="New", scope="project")
    r = todo.todo_list(scope="project")
    assert r["todos"][0]["content"] == "New"


def test_project_todo_update_not_found(todo):
    r = todo.todo_update("bad-id", status="completed", scope="project")
    assert r["success"] is False


def test_project_todo_update_wrong_scope_not_found(todo):
    """Updating with wrong scope should not find the item."""
    tid = todo.todo_write([{"content": "Project item"}], scope="project")["todos"][0]["id"]
    r = todo.todo_update(tid, status="completed", scope="session")  # wrong scope
    assert r["success"] is False


# ------------------------------------------------------------------
# Persistence
# ------------------------------------------------------------------

def test_project_todo_persists_across_instances(workspace, data_dir):
    t1 = TodoTools(data_dir, workspace_root=workspace)
    t1.todo_write([{"content": "Persist me", "priority": "high"}], scope="project")

    t2 = TodoTools(data_dir, workspace_root=workspace)
    r = t2.todo_list(scope="project")
    assert len(r["todos"]) == 1
    assert r["todos"][0]["content"] == "Persist me"
    assert r["todos"][0]["priority"] == "high"


def test_project_todo_file_is_valid_json(todo, workspace):
    todo.todo_write([{"content": "Test"}], scope="project")
    raw = (workspace / ".ctrlcode" / "todos" / "project.json").read_text()
    data = json.loads(raw)
    assert isinstance(data, list)
    assert data[0]["content"] == "Test"


# ------------------------------------------------------------------
# No workspace_root fallback
# ------------------------------------------------------------------

def test_project_scope_without_workspace_falls_back_to_global(data_dir):
    """When no workspace_root is set, project scope falls back to global.json."""
    todo = TodoTools(data_dir)  # no workspace_root
    r = todo.todo_write([{"content": "Global fallback"}], scope="project")
    assert r["success"] is True
    # Should have written to global.json, not crash
    assert (data_dir / "todos" / "global.json").exists()
