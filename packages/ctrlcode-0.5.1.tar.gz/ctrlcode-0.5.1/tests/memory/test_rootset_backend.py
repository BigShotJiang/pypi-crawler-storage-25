"""Tests for RootsetMemoryBackend — delegates all calls to ArtifactStore."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.memory.rootset_backend import RootsetMemoryBackend
from ctrlcode.memory.store import Artifact, ArtifactResult, ArtifactStore


def _make_backend():
    store = MagicMock(spec=ArtifactStore)
    # Make all async methods return sensible defaults
    store.add_artifact = AsyncMock(return_value=MagicMock(spec=Artifact))
    store.search_artifacts = AsyncMock(return_value=[])
    store.get_artifact = AsyncMock(return_value=None)
    store.update_artifact = AsyncMock(return_value=None)
    store.delete_artifact = AsyncMock(return_value=None)
    store.log_engagement = AsyncMock(return_value=None)
    store.get_engagement_sum = AsyncMock(return_value=0.0)
    store.index_entities = AsyncMock(return_value=None)
    store.lookup_by_entities = AsyncMock(return_value=[])
    store.structural_lookup = AsyncMock(return_value=[])
    store.close = AsyncMock(return_value=None)
    return RootsetMemoryBackend(store), store


@pytest.mark.anyio
async def test_add_artifact_delegates():
    backend, store = _make_backend()
    await backend.add_artifact("content", "note", namespace="ns", metadata={"k": "v"})
    store.add_artifact.assert_called_once_with(
        "content", "note", namespace="ns", metadata={"k": "v"}
    )


@pytest.mark.anyio
async def test_search_artifacts_delegates():
    backend, store = _make_backend()
    await backend.search_artifacts("query", top_k=5, kind="note", namespace="ns")
    store.search_artifacts.assert_called_once_with(
        "query", top_k=5, kind="note", namespace="ns",
    )


@pytest.mark.anyio
async def test_get_artifact_delegates():
    backend, store = _make_backend()
    await backend.get_artifact(42)
    store.get_artifact.assert_called_once_with(42)


@pytest.mark.anyio
async def test_update_artifact_delegates():
    backend, store = _make_backend()
    await backend.update_artifact(7, metadata={"x": 1}, content="new")
    store.update_artifact.assert_called_once_with(7, metadata={"x": 1}, content="new")


@pytest.mark.anyio
async def test_delete_artifact_delegates():
    backend, store = _make_backend()
    await backend.delete_artifact(9)
    store.delete_artifact.assert_called_once_with(9)


@pytest.mark.anyio
async def test_log_engagement_delegates():
    backend, store = _make_backend()
    await backend.log_engagement("cluster", "sess", 100, "turn1")
    store.log_engagement.assert_called_once_with("cluster", "sess", 100, "turn1")


@pytest.mark.anyio
async def test_get_engagement_sum_delegates():
    backend, store = _make_backend()
    store.get_engagement_sum = AsyncMock(return_value=3.14)
    result = await backend.get_engagement_sum("cluster", "sess")
    assert result == 3.14
    store.get_engagement_sum.assert_called_once_with("cluster", "sess")


@pytest.mark.anyio
async def test_index_entities_delegates():
    backend, store = _make_backend()
    await backend.index_entities(1, [("A", "B")], "sess")
    store.index_entities.assert_called_once_with(1, [("A", "B")], "sess")


@pytest.mark.anyio
async def test_lookup_by_entities_delegates():
    backend, store = _make_backend()
    store.lookup_by_entities = AsyncMock(return_value=["r1"])
    result = await backend.lookup_by_entities(["E1"], "sess", top_k=10)
    assert result == ["r1"]
    store.lookup_by_entities.assert_called_once_with(["E1"], "sess", top_k=10)


@pytest.mark.anyio
async def test_structural_lookup_delegates():
    backend, store = _make_backend()
    store.structural_lookup = AsyncMock(return_value=["r2"])
    result = await backend.structural_lookup({"/a.py"}, "sess", top_k=5)
    assert result == ["r2"]
    store.structural_lookup.assert_called_once_with({"/a.py"}, "sess", top_k=5)


@pytest.mark.anyio
async def test_close_delegates():
    backend, store = _make_backend()
    await backend.close()
    store.close.assert_called_once()
