"""Tests for SaliencyScorer — weighted multi-signal scoring."""

import pytest
from ctrlcode.memory.saliency import SaliencyScorer, SaliencyResult


@pytest.fixture
def scorer():
    return SaliencyScorer()


# ---------------------------------------------------------------------------
# user_correction signal tests
# ---------------------------------------------------------------------------

def test_correction_word_actually(scorer):
    result = scorer.score_turn("actually that's wrong", [], "", [])
    assert result.score >= 0.20  # correction signal contributes but not dominant alone
    assert result.reason == "user_correction"


def test_correction_word_no_comma(scorer):
    result = scorer.score_turn("no, that's not right", [], "", [])
    assert result.score >= 0.20
    assert result.reason == "user_correction"


def test_correction_word_wrong(scorer):
    result = scorer.score_turn("wrong approach", [], "", [])
    assert result.score >= 0.20
    assert result.reason == "user_correction"


def test_correction_word_instead(scorer):
    result = scorer.score_turn("instead use this", [], "", [])
    assert result.score >= 0.20
    assert result.reason == "user_correction"


# ---------------------------------------------------------------------------
# error_resolved signal tests  
# ---------------------------------------------------------------------------

def test_error_resolved_same_tool_success_and_failure(scorer):
    tool_calls = [
        {"tool": "run_command", "success": False},
        {"tool": "run_command", "success": True},
    ]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score >= 0.20  # error resolution contributes to weighted score
    assert result.reason == "error_resolved"


# ---------------------------------------------------------------------------
# decision signal tests
# ---------------------------------------------------------------------------

def test_decision_phrase_lets_use(scorer):
    result = scorer.score_turn("", [], "let's use pytest for testing", [])
    assert result.score >= 0.15  # decision signal contributes but moderated
    assert result.reason == "decision"


def test_decision_phrase_we_decided(scorer):
    result = scorer.score_turn("", [], "we decided to go with postgres", [])
    assert result.score >= 0.15
    assert result.reason == "decision"


# ---------------------------------------------------------------------------
# structural and tool diversity tests
# ---------------------------------------------------------------------------

def test_file_write_structural_signal(scorer):
    tool_calls = [{"tool": "write_file", "success": True}]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score >= 0.25  # write tools contribute to structural + tool diversity
    assert result.reason in ["tool_diversity", "structural_changes"]


def test_file_write_branch_update_file(scorer):
    tool_calls = [{"tool": "update_file", "success": True}]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score >= 0.25


def test_file_write_not_triggered_on_failure(scorer):
    # write_file failed, structural/diversity signals shouldn't score highly
    tool_calls = [{"tool": "write_file", "success": False}]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score < 0.25  # failed operations reduce signal strength


# ---------------------------------------------------------------------------
# length ratio and code block tests
# ---------------------------------------------------------------------------

def test_code_block_in_assistant_text(scorer):
    result = scorer.score_turn("help", [], "Here is the code:\n```python\npass\n```", [])
    assert result.score >= 0.13  # code blocks contribute to length ratio signal
    assert result.reason == "detailed_response"


# ---------------------------------------------------------------------------
# tool diversity tests  
# ---------------------------------------------------------------------------

def test_read_then_write_diversity(scorer):
    tool_calls = [
        {"tool": "read_file", "success": True},
        {"tool": "edit_file", "success": False},
    ]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score >= 0.15  # mixed tool usage increases diversity score
    assert result.reason == "tool_diversity"


def test_file_read_only(scorer):
    tool_calls = [{"tool": "read_file", "success": True}]
    result = scorer.score_turn("", tool_calls, "", [])
    assert result.score >= 0.15  # read tools contribute to diversity
    assert result.reason == "tool_diversity"


# ---------------------------------------------------------------------------
# default and baseline tests
# ---------------------------------------------------------------------------

def test_default_score(scorer):
    result = scorer.score_turn("please do this task", [], "okay done", [])
    assert result.score >= 0.10  # baseline score from weighted system
    assert result.score <= 0.20


def test_returns_saliency_result(scorer):
    result = scorer.score_turn("", [], "", [])
    assert isinstance(result, SaliencyResult)


# ---------------------------------------------------------------------------
# weighted signal combination tests
# ---------------------------------------------------------------------------

def test_correction_with_write_tools_high_score(scorer):
    """Correction signal + structural signal should score higher."""
    tool_calls = [{"tool": "write_file", "success": True}]
    result = scorer.score_turn("actually that's wrong", tool_calls, "", [])
    assert result.score >= 0.40  # combined signals boost score
    

def test_diverse_tools_score_higher(scorer):
    """Read + write + execution should score higher than single tool."""
    diverse_tools = [
        {"tool": "read_file", "success": True},
        {"tool": "write_file", "success": True}, 
        {"tool": "run_command", "success": True}
    ]
    single_tool = [{"tool": "read_file", "success": True}]
    
    diverse_result = scorer.score_turn("", diverse_tools, "", [])
    single_result = scorer.score_turn("", single_tool, "", [])
    
    assert diverse_result.score > single_result.score


def test_long_response_scores_higher(scorer):
    """Long detailed response should score higher than short one."""
    long_response = "Here's a detailed explanation of the approach:\n" + "x" * 500
    short_response = "Done."
    
    long_result = scorer.score_turn("help", [], long_response, [])
    short_result = scorer.score_turn("help", [], short_response, [])
    
    assert long_result.score > short_result.score


def test_structural_signal_scales_with_writes(scorer):
    """More write operations should increase structural score."""
    many_writes = [
        {"tool": "write_file", "success": True},
        {"tool": "edit_file", "success": True},
        {"tool": "update_file", "success": True}
    ]
    single_write = [{"tool": "write_file", "success": True}]
    
    many_result = scorer.score_turn("", many_writes, "", [])
    single_result = scorer.score_turn("", single_write, "", [])
    
    assert many_result.score > single_result.score
