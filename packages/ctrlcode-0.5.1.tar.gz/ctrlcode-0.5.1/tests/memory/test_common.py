"""Tests for memory/indexers/common.py — extract_string_content, extract_definitions, resolve_relative."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from ctrlcode.memory.indexers.common import (
    extract_definitions,
    extract_string_content,
    resolve_relative,
)


# ---------------------------------------------------------------------------
# Helpers — minimal tree-sitter node mocks
# ---------------------------------------------------------------------------

def make_node(node_type, start_byte=0, end_byte=0, children=None, fields=None):
    """Build a minimal mock of a tree-sitter Node."""
    node = MagicMock()
    node.type = node_type
    node.start_byte = start_byte
    node.end_byte = end_byte
    node.children = children or []

    def _child_by_field_name(name):
        return (fields or {}).get(name)

    node.child_by_field_name.side_effect = _child_by_field_name
    return node


# ---------------------------------------------------------------------------
# extract_string_content
# ---------------------------------------------------------------------------

def test_extract_string_content_via_content_child():
    source = b'"hello world"'
    content_child = make_node("string_content", start_byte=1, end_byte=12)
    node = make_node("string", start_byte=0, end_byte=13, children=[content_child])
    result = extract_string_content(node, source)
    assert result == "hello world"


def test_extract_string_content_via_string_fragment():
    source = b'`fragment`'
    frag_child = make_node("string_fragment", start_byte=1, end_byte=9)
    node = make_node("string", start_byte=0, end_byte=10, children=[frag_child])
    result = extract_string_content(node, source)
    assert result == "fragment"


def test_extract_string_content_fallback_double_quotes():
    source = b'"stripped"'
    node = make_node("string", start_byte=0, end_byte=10, children=[])
    result = extract_string_content(node, source)
    assert result == "stripped"


def test_extract_string_content_fallback_single_quotes():
    source = b"'value'"
    node = make_node("string", start_byte=0, end_byte=7, children=[])
    result = extract_string_content(node, source)
    assert result == "value"


def test_extract_string_content_fallback_backtick():
    source = b"`tpl`"
    node = make_node("string", start_byte=0, end_byte=5, children=[])
    result = extract_string_content(node, source)
    assert result == "tpl"


def test_extract_string_content_fallback_no_quotes_returns_none():
    source = b"notaquote"
    node = make_node("string", start_byte=0, end_byte=9, children=[])
    result = extract_string_content(node, source)
    assert result is None


def test_extract_string_content_single_char_returns_none():
    source = b'"'
    node = make_node("string", start_byte=0, end_byte=1, children=[])
    result = extract_string_content(node, source)
    assert result is None


# ---------------------------------------------------------------------------
# extract_definitions
# ---------------------------------------------------------------------------

def test_extract_definitions_unknown_lang_returns_empty():
    tree = MagicMock()
    tree.root_node = make_node("module", children=[])
    result = extract_definitions(tree, b"", "unknown_lang_xyz")
    assert result == []


def test_extract_definitions_python_function(tmp_path):
    from tree_sitter_language_pack import get_parser
    src = b"def my_function():\n    pass\n"
    parser = get_parser("python")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "python")
    assert "my_function" in defs


def test_extract_definitions_python_class(tmp_path):
    from tree_sitter_language_pack import get_parser
    src = b"class MyClass:\n    pass\n"
    parser = get_parser("python")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "python")
    assert "MyClass" in defs


def test_extract_definitions_python_multiple(tmp_path):
    from tree_sitter_language_pack import get_parser
    src = b"def foo():\n    pass\ndef bar():\n    pass\n"
    parser = get_parser("python")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "python")
    assert "foo" in defs
    assert "bar" in defs


def test_extract_definitions_deduplicates(tmp_path):
    from tree_sitter_language_pack import get_parser
    src = b"def foo():\n    pass\ndef foo():\n    pass\n"
    parser = get_parser("python")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "python")
    assert defs.count("foo") == 1


def test_extract_definitions_typescript_function(tmp_path):
    from tree_sitter_language_pack import get_parser
    src = b"function greet(name: string): void {}\n"
    parser = get_parser("typescript")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "typescript")
    assert "greet" in defs


def test_extract_definitions_empty_source_returns_empty():
    from tree_sitter_language_pack import get_parser
    src = b""
    parser = get_parser("python")
    tree = parser.parse(src)
    defs = extract_definitions(tree, src, "python")
    assert defs == []


# ---------------------------------------------------------------------------
# resolve_relative
# ---------------------------------------------------------------------------

def test_resolve_relative_exact_file(tmp_path):
    (tmp_path / "utils.py").write_text("")
    result = resolve_relative("utils.py", tmp_path, tmp_path, [".py"])
    assert result == "utils.py"


def test_resolve_relative_with_extension(tmp_path):
    (tmp_path / "helper.py").write_text("")
    result = resolve_relative("helper", tmp_path, tmp_path, [".py", ".ts"])
    assert result == "helper.py"


def test_resolve_relative_tries_extensions_in_order(tmp_path):
    (tmp_path / "mod.ts").write_text("")
    result = resolve_relative("mod", tmp_path, tmp_path, [".py", ".ts"])
    assert result == "mod.ts"


def test_resolve_relative_returns_none_when_not_found(tmp_path):
    result = resolve_relative("ghost", tmp_path, tmp_path, [".py", ".ts"])
    assert result is None


def test_resolve_relative_subdirectory(tmp_path):
    subdir = tmp_path / "src"
    subdir.mkdir()
    (subdir / "app.py").write_text("")
    result = resolve_relative("src/app.py", tmp_path, tmp_path, [".py"])
    assert result == "src/app.py"


def test_resolve_relative_outside_workspace_returns_none(tmp_path):
    other = tmp_path.parent / "outside.py"
    other.write_text("")
    result = resolve_relative("../outside.py", tmp_path, tmp_path, [".py"])
    # Outside workspace root — should return None
    assert result is None
