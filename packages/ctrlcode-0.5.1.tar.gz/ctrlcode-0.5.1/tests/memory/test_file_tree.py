"""Tests for memory/file_tree.py — _sha256, _dir_hash, FileChangeSet, FileTreeIndex helpers."""

import hashlib
from pathlib import Path

import pytest

from ctrlcode.memory.file_tree import (
    _sha256,
    _dir_hash,
    FileChangeSet,
    FileTreeIndex,
    IGNORED_DIRS,
    IGNORED_EXTENSIONS,
)


# ---------------------------------------------------------------------------
# _sha256
# ---------------------------------------------------------------------------

def test_sha256_matches_expected(tmp_path):
    f = tmp_path / "hello.txt"
    f.write_bytes(b"hello world")
    result = _sha256(f)
    expected = hashlib.sha256(b"hello world").hexdigest()
    assert result == expected


def test_sha256_different_files_different_hashes(tmp_path):
    a = tmp_path / "a.txt"
    b = tmp_path / "b.txt"
    a.write_bytes(b"content A")
    b.write_bytes(b"content B")
    assert _sha256(a) != _sha256(b)


def test_sha256_same_content_same_hash(tmp_path):
    a = tmp_path / "a.txt"
    b = tmp_path / "b.txt"
    a.write_bytes(b"same content")
    b.write_bytes(b"same content")
    assert _sha256(a) == _sha256(b)


# ---------------------------------------------------------------------------
# _dir_hash
# ---------------------------------------------------------------------------

def test_dir_hash_is_deterministic():
    children = [("file.py", "abc123"), ("main.py", "def456")]
    assert _dir_hash(children) == _dir_hash(children)


def test_dir_hash_order_independent():
    c1 = [("a.py", "hash1"), ("b.py", "hash2")]
    c2 = [("b.py", "hash2"), ("a.py", "hash1")]
    # sorted() is applied, so order doesn't matter
    assert _dir_hash(c1) == _dir_hash(c2)


def test_dir_hash_different_children():
    c1 = [("a.py", "hash1")]
    c2 = [("a.py", "hash2")]
    assert _dir_hash(c1) != _dir_hash(c2)


def test_dir_hash_returns_hex_string():
    result = _dir_hash([("x.py", "abc")])
    assert len(result) == 64
    assert all(c in "0123456789abcdef" for c in result)


# ---------------------------------------------------------------------------
# FileChangeSet
# ---------------------------------------------------------------------------

def test_file_change_set_all_changed_includes_modified():
    cs = FileChangeSet(modified=["a.py"])
    assert "a.py" in cs.all_changed


def test_file_change_set_all_changed_includes_deleted():
    cs = FileChangeSet(deleted=["b.py"])
    assert "b.py" in cs.all_changed


def test_file_change_set_all_changed_includes_moved_old():
    cs = FileChangeSet(moved=[("old.py", "new.py")])
    assert "old.py" in cs.all_changed
    # new.py should NOT be in all_changed
    assert "new.py" not in cs.all_changed


def test_file_change_set_is_empty_true():
    cs = FileChangeSet()
    assert cs.is_empty is True


def test_file_change_set_is_empty_false_when_added():
    cs = FileChangeSet(added=["new.py"])
    assert cs.is_empty is False


def test_file_change_set_is_empty_false_when_modified():
    cs = FileChangeSet(modified=["m.py"])
    assert cs.is_empty is False


# ---------------------------------------------------------------------------
# FileTreeIndex._is_ignored
# ---------------------------------------------------------------------------

def test_is_ignored_venv(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / ".venv" / "lib.py") is True


def test_is_ignored_pycache(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / "__pycache__" / "mod.pyc") is True


def test_is_ignored_pyc_extension(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / "module.pyc") is True


def test_is_not_ignored_regular_py(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / "src" / "module.py") is False


def test_is_not_ignored_regular_txt(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / "README.txt") is False


def test_is_ignored_ctrlcode_dir(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    assert idx._is_ignored(tmp_path / ".ctrlcode" / "progress.md") is True


# ---------------------------------------------------------------------------
# FileTreeIndex._rel
# ---------------------------------------------------------------------------

def test_rel_returns_relative_path(tmp_path):
    idx = FileTreeIndex.__new__(FileTreeIndex)
    idx._root = tmp_path
    full = tmp_path / "src" / "foo.py"
    assert idx._rel(full) == "src/foo.py"
