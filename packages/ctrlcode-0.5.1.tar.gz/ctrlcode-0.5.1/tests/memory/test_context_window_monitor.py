"""Unit tests for ContextWindowMonitor."""

import asyncio
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock, patch

import pytest

from ctrlcode.memory.context_window_monitor import ContextWindowMonitor, MODEL_CAPACITIES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_monitor(tmp_path: Path, model: str = "claude-3-5-sonnet-20241022") -> ContextWindowMonitor:
    return ContextWindowMonitor(
        model=model,
        ctrlcode_dir=tmp_path / ".ctrlcode",
        threshold=0.85,
        fallback_tokens=170_000,
    )


def _make_message(role: str = "user", text: str = "hello") -> MagicMock:
    part = MagicMock()
    part.text = text
    msg = MagicMock()
    msg.role = role
    msg.parts = [part]
    msg.id = f"msg_{role}_{text[:8]}"
    return msg


# ---------------------------------------------------------------------------
# Model capacity table
# ---------------------------------------------------------------------------

def test_known_model_capacity(tmp_path):
    mon = _make_monitor(tmp_path, model="claude-3-5-sonnet-20241022")
    assert mon.max_tokens_for_model() == 200_000


def test_unknown_model_fallback(tmp_path):
    mon = _make_monitor(tmp_path, model="some-future-model-v99")
    assert mon.max_tokens_for_model() == 170_000


def test_prefix_match_returns_capacity(tmp_path):
    """A model name that starts with a known prefix should match."""
    mon = _make_monitor(tmp_path, model="claude-3-5-sonnet-20250101-preview")
    assert mon.max_tokens_for_model() == 200_000


def test_gpt4o_capacity(tmp_path):
    mon = _make_monitor(tmp_path, model="gpt-4o")
    assert mon.max_tokens_for_model() == 128_000


# ---------------------------------------------------------------------------
# Threshold detection
# ---------------------------------------------------------------------------

def test_threshold_not_triggered(tmp_path):
    mon = _make_monitor(tmp_path)
    below = int(200_000 * 0.84)
    assert mon.is_over_threshold(below) is False


def test_threshold_triggered(tmp_path):
    mon = _make_monitor(tmp_path)
    at_threshold = int(200_000 * 0.85)
    assert mon.is_over_threshold(at_threshold) is True


def test_threshold_above_triggers(tmp_path):
    mon = _make_monitor(tmp_path)
    above = int(200_000 * 0.90)
    assert mon.is_over_threshold(above) is True


# ---------------------------------------------------------------------------
# offload_history
# ---------------------------------------------------------------------------

def test_offload_history_creates_file(tmp_path):
    mon = _make_monitor(tmp_path)
    msgs = [_make_message("user", "hello there"), _make_message("assistant", "hi back")]
    path = mon.offload_history("sess-001", msgs)
    assert path.exists()
    content = path.read_text()
    assert "hello there" in content
    assert "hi back" in content


def test_offload_history_creates_in_correct_dir(tmp_path):
    mon = _make_monitor(tmp_path)
    msgs = [_make_message("user", "test")]
    path = mon.offload_history("sess-abc", msgs)
    assert path == tmp_path / ".ctrlcode" / "conversation_history" / "sess-abc.md"


def test_offload_history_appends(tmp_path):
    mon = _make_monitor(tmp_path)
    mon.offload_history("sess-002", [_make_message("user", "batch one")])
    mon.offload_history("sess-002", [_make_message("assistant", "batch two")])
    content = (tmp_path / ".ctrlcode" / "conversation_history" / "sess-002.md").read_text()
    assert "batch one" in content
    assert "batch two" in content


# ---------------------------------------------------------------------------
# summarize_and_compact
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_summarize_and_compact_with_mock_client(tmp_path):
    """With a mock LLM client, conversation should be shortened and summary prepended."""
    from harnessutils import ConversationManager, MemoryStorage, Message, TextPart
    from harnessutils.config import HarnessConfig

    conv_mgr = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())
    conv = conv_mgr.create_conversation()
    cid = conv.id

    # Add 10 messages
    for i in range(10):
        msg = Message(id=f"msg_{i:03}", role="user" if i % 2 == 0 else "assistant")
        msg.add_part(TextPart(text=f"message number {i}"))
        conv_mgr.add_message(cid, msg)

    mock_client = MagicMock()
    mock_client.invoke.return_value = {"content": "Summary of old messages."}

    mon = _make_monitor(tmp_path)
    result = await mon.summarize_and_compact(
        session_id="sess-test",
        conv_manager=conv_mgr,
        conv_id=cid,
        llm_client=mock_client,
    )

    assert "tokens_saved" in result
    assert "new_conv_id" in result
    new_cid = result["new_conv_id"]

    new_messages = conv_mgr.get_messages(new_cid)
    # First message should be the summary
    first_text = ""
    for part in new_messages[0].parts:
        first_text += getattr(part, "text", "")
    assert "Context compaction" in first_text
    assert "Summary of old messages." in first_text

    # Total messages should be fewer than 10 (summary + newer half)
    assert len(new_messages) < 10


@pytest.mark.asyncio
async def test_summarize_and_compact_no_client(tmp_path):
    """Without LLM client, should fall back to truncation summary gracefully."""
    from harnessutils import ConversationManager, MemoryStorage, Message, TextPart
    from harnessutils.config import HarnessConfig

    conv_mgr = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())
    conv = conv_mgr.create_conversation()
    cid = conv.id

    for i in range(6):
        msg = Message(id=f"msg_{i:03}", role="user")
        msg.add_part(TextPart(text=f"content {i}"))
        conv_mgr.add_message(cid, msg)

    mon = _make_monitor(tmp_path)
    result = await mon.summarize_and_compact(
        session_id="sess-nollm",
        conv_manager=conv_mgr,
        conv_id=cid,
        llm_client=None,
    )

    assert result["tokens_saved"] >= 0
    new_cid = result["new_conv_id"]
    new_messages = conv_mgr.get_messages(new_cid)
    assert len(new_messages) > 0

    # Offload file should exist
    history_file = tmp_path / ".ctrlcode" / "conversation_history" / "sess-nollm.md"
    assert history_file.exists()


@pytest.mark.asyncio
async def test_summarize_and_compact_empty_conv(tmp_path):
    """Empty conversation should return immediately with no change."""
    from harnessutils import ConversationManager, MemoryStorage
    from harnessutils.config import HarnessConfig

    conv_mgr = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())
    conv = conv_mgr.create_conversation()
    cid = conv.id

    mon = _make_monitor(tmp_path)
    result = await mon.summarize_and_compact(
        session_id="sess-empty",
        conv_manager=conv_mgr,
        conv_id=cid,
        llm_client=None,
    )

    assert result["tokens_saved"] == 0
    assert result["new_conv_id"] == cid


# ---------------------------------------------------------------------------
# compact_conversation tool
# ---------------------------------------------------------------------------

def test_compact_conversation_tool_registered():
    """compact_conversation tool should be present in registry after setup_context_tools."""
    from ctrlcode.tools.registry import ToolRegistry
    from ctrlcode.tools import setup_context_tools

    registry = ToolRegistry()

    session = MagicMock()
    session.provider.model = "claude-3-5-sonnet-20241022"

    session_manager = MagicMock()
    session_manager.get_session.return_value = session
    session_manager._ctx_monitors = {}
    session_manager._ctrlcode_dir = Path("/tmp/.ctrlcode")
    session_manager.conv_manager = MagicMock()

    setup_context_tools(registry, session_manager, "sess-xyz")

    tool_defs = registry.get_tool_definitions()
    names = [t["name"] for t in tool_defs]
    assert "compact_conversation" in names
