"""Tests for versioned schema migration runner."""

import hashlib
import json
from datetime import datetime, timezone

import aiosqlite
import pytest

from ctrlcode.memory.migrations import (
    LATEST_VERSION,
    SchemaMigrationError,
    get_schema_version,
    run_migrations,
)
from ctrlcode.memory.store import ArtifactStore, _DDL


@pytest.mark.anyio
async def test_get_schema_version_returns_zero_on_empty_db(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        v = await get_schema_version(db)
        assert v == 0


@pytest.mark.anyio
async def test_run_migrations_stamps_latest_version(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        v = await get_schema_version(db)
        assert v == LATEST_VERSION


@pytest.mark.anyio
async def test_run_migrations_idempotent(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        await run_migrations(db)  # second call is a no-op
        v = await get_schema_version(db)
        assert v == LATEST_VERSION


@pytest.mark.anyio
async def test_migration_failure_rolls_back(tmp_path, monkeypatch):
    """A failing migration leaves the version unchanged."""
    import ctrlcode.memory.migrations as m

    async def bad_migration(db: aiosqlite.Connection) -> None:
        raise RuntimeError("intentional failure")

    original_latest = LATEST_VERSION
    monkeypatch.setattr(m, "LATEST_VERSION", original_latest + 1)
    monkeypatch.setitem(m._MIGRATION_STEPS, original_latest + 1, bad_migration)

    async with aiosqlite.connect(str(tmp_path / "fail.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        # Run migrations up to current LATEST first (reset to real latest)
        monkeypatch.setattr(m, "LATEST_VERSION", original_latest)
        await run_migrations(db)
        # Now inject the failing step
        monkeypatch.setattr(m, "LATEST_VERSION", original_latest + 1)
        with pytest.raises(SchemaMigrationError):
            await run_migrations(db)
        # Version must not have advanced
        v = await get_schema_version(db)
        assert v == original_latest


@pytest.mark.anyio
async def test_store_initialises_with_correct_version(tmp_path):
    store = ArtifactStore(tmp_path / "rootset.db")
    await store._ensure_init()
    v = await get_schema_version(store._db)
    assert v == LATEST_VERSION
    await store.close()


@pytest.mark.anyio
async def test_v2_migration_adds_source_file_column(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "v2.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        async with db.execute("PRAGMA table_info(artifacts)") as cur:
            cols = {row[1] async for row in cur}
        assert "source_file" in cols


@pytest.mark.anyio
async def test_v2_backfill_populates_source_file(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "backfill.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        meta = json.dumps({"source_file": "src/foo.py"})
        now = datetime.now(timezone.utc).isoformat()
        content = b"body"
        await db.execute(
            "INSERT INTO artifacts (namespace, kind, content, metadata, content_hash, created_at, updated_at)"
            " VALUES ('ns','turn','body',?,?,?,?)",
            (meta, hashlib.sha256(content).hexdigest(), now, now),
        )
        await db.commit()
        await run_migrations(db)
        async with db.execute("SELECT source_file FROM artifacts WHERE namespace='ns'") as cur:
            row = await cur.fetchone()
        assert row[0] == "src/foo.py"
