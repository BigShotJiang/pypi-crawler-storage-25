"""Tests for DependencyIndexer — index_file, full_index, reindex_changed, graph queries."""

import time
from pathlib import Path

import pytest

from ctrlcode.memory.store import ArtifactStore
from ctrlcode.memory.dependency_indexer import DependencyIndexer, BLAST_RADIUS_MAX


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def store(tmp_path):
    # Put DB inside .ctrlcode/ so it's ignored by the workspace scanner
    s = ArtifactStore(tmp_path / ".ctrlcode" / "test.db")
    await s._ensure_init()
    yield s
    await s.close()


@pytest.fixture
def workspace(tmp_path):
    return tmp_path


@pytest.fixture
def indexer(store, workspace):
    return DependencyIndexer(store, workspace)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def write_py(workspace: Path, rel_path: str, content: str) -> Path:
    full = workspace / rel_path
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content)
    return full


# ---------------------------------------------------------------------------
# index_file
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_index_file_creates_edges(indexer, workspace):
    write_py(workspace, "utils.py", "")
    write_py(workspace, "main.py", "from utils import helper")

    resolved = await indexer.index_file("main.py")

    assert "utils.py" in resolved


@pytest.mark.anyio
async def test_index_file_returns_empty_for_missing_file(indexer):
    result = await indexer.index_file("nonexistent.py")
    assert result == []


@pytest.mark.anyio
async def test_index_file_replaces_stale_edges(indexer, workspace):
    write_py(workspace, "old_dep.py", "")
    write_py(workspace, "new_dep.py", "")
    write_py(workspace, "main.py", "from old_dep import x")

    await indexer.index_file("main.py")
    deps_before = await indexer.get_dependencies("main.py")
    assert "old_dep.py" in deps_before

    # Rewrite main.py to use new_dep instead
    write_py(workspace, "main.py", "from new_dep import x")
    await indexer.index_file("main.py")

    deps_after = await indexer.get_dependencies("main.py")
    assert "new_dep.py" in deps_after
    assert "old_dep.py" not in deps_after


@pytest.mark.anyio
async def test_index_file_external_imports_not_in_resolved(indexer, workspace):
    write_py(workspace, "main.py", "import os\nimport sys")

    resolved = await indexer.index_file("main.py")
    # os and sys are external — not resolved as internal paths
    assert resolved == []


# ---------------------------------------------------------------------------
# full_index
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_full_index_indexes_new_files(indexer, workspace):
    write_py(workspace, "a.py", "")
    write_py(workspace, "b.py", "from a import x")

    await indexer.full_index(["a.py", "b.py"])

    deps = await indexer.get_dependencies("b.py")
    assert "a.py" in deps


@pytest.mark.anyio
async def test_full_index_skips_unchanged_files(indexer, workspace, store):
    write_py(workspace, "a.py", "")
    write_py(workspace, "b.py", "from a import x")

    # First index
    await indexer.full_index(["a.py", "b.py"])

    # Record how many rows exist
    db = await store._ensure_init()
    async with db.execute("SELECT COUNT(*) FROM dependency_graph") as cur:
        row = await cur.fetchone()
    count_before = row[0]

    # Second index — files unchanged, should skip
    await indexer.full_index(["a.py", "b.py"])

    async with db.execute("SELECT COUNT(*) FROM dependency_graph") as cur:
        row = await cur.fetchone()
    count_after = row[0]

    assert count_after == count_before


@pytest.mark.anyio
async def test_full_index_reindexes_modified_files(indexer, workspace, store):
    write_py(workspace, "c.py", "")
    write_py(workspace, "d.py", "from c import x")

    await indexer.full_index(["c.py", "d.py"])

    # Modify d.py (touch to bump mtime past indexed_at)
    time.sleep(0.01)
    write_py(workspace, "e.py", "")
    write_py(workspace, "d.py", "from e import x")

    await indexer.full_index(["c.py", "d.py", "e.py"])

    deps = await indexer.get_dependencies("d.py")
    assert "e.py" in deps
    assert "c.py" not in deps  # stale edge removed


@pytest.mark.anyio
async def test_full_index_handles_empty_list(indexer):
    # Should not raise
    await indexer.full_index([])


# ---------------------------------------------------------------------------
# reindex_changed
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_reindex_changed_only_indexes_supported_extensions(indexer, workspace):
    write_py(workspace, "a.py", "")
    write_py(workspace, "b.py", "from a import x")
    (workspace / "README.md").write_text("# docs")

    await indexer.reindex_changed(["a.py", "b.py", "README.md"])

    deps = await indexer.get_dependencies("b.py")
    assert "a.py" in deps


@pytest.mark.anyio
async def test_reindex_changed_empty_list(indexer):
    await indexer.reindex_changed([])  # must not raise


# ---------------------------------------------------------------------------
# get_dependents
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_get_dependents_direct(indexer, workspace):
    write_py(workspace, "lib.py", "")
    write_py(workspace, "app.py", "from lib import x")

    await indexer.index_file("app.py")

    dependents = await indexer.get_dependents("lib.py")
    assert "app.py" in dependents
    assert "lib.py" not in dependents  # excludes self


@pytest.mark.anyio
async def test_get_dependents_transitive(indexer, workspace):
    write_py(workspace, "core.py", "")
    write_py(workspace, "mid.py", "from core import x")
    write_py(workspace, "top.py", "from mid import y")

    await indexer.index_file("mid.py")
    await indexer.index_file("top.py")

    dependents = await indexer.get_dependents("core.py", depth=3)
    assert "mid.py" in dependents
    assert "top.py" in dependents


@pytest.mark.anyio
async def test_get_dependents_depth_limits_traversal(indexer, workspace):
    # chain: a <- b <- c <- d
    write_py(workspace, "a.py", "")
    write_py(workspace, "b.py", "from a import x")
    write_py(workspace, "c.py", "from b import x")
    write_py(workspace, "d.py", "from c import x")

    for f in ["b.py", "c.py", "d.py"]:
        await indexer.index_file(f)

    # depth=1 only gets immediate importers
    shallow = await indexer.get_dependents("a.py", depth=1)
    assert "b.py" in shallow
    assert "c.py" not in shallow
    assert "d.py" not in shallow


@pytest.mark.anyio
async def test_get_dependents_returns_empty_for_no_importers(indexer, workspace):
    write_py(workspace, "standalone.py", "")
    await indexer.index_file("standalone.py")

    dependents = await indexer.get_dependents("standalone.py")
    assert dependents == set()


@pytest.mark.anyio
async def test_get_dependents_caps_at_blast_radius_max(indexer, workspace, store):
    # Create a hub file imported by many files
    write_py(workspace, "hub.py", "")
    for i in range(BLAST_RADIUS_MAX + 5):
        write_py(workspace, f"consumer{i}.py", "from hub import x")
        await indexer.index_file(f"consumer{i}.py")

    dependents = await indexer.get_dependents("hub.py")
    assert len(dependents) <= BLAST_RADIUS_MAX


# ---------------------------------------------------------------------------
# get_dependencies
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_get_dependencies_returns_internal_only(indexer, workspace):
    write_py(workspace, "utils.py", "")
    write_py(workspace, "main.py", "import os\nfrom utils import x")

    await indexer.index_file("main.py")

    deps = await indexer.get_dependencies("main.py")
    assert "utils.py" in deps
    assert not any("os" in d for d in deps)


@pytest.mark.anyio
async def test_get_dependencies_empty_for_unknown_file(indexer):
    deps = await indexer.get_dependencies("unknown.py")
    assert deps == []
