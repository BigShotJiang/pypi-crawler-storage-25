"""Tests for ArtifactStore — CRUD, FTS search, entity index, engagement, structural lookup."""

import pytest

from ctrlcode.memory.store import ArtifactStore


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def store(tmp_path):
    s = ArtifactStore(tmp_path / ".ctrlcode" / "test.db")
    await s._ensure_init()
    yield s
    await s.close()


# ---------------------------------------------------------------------------
# add_artifact / get_artifact
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_add_artifact_creates_and_returns(store):
    art = await store.add_artifact("hello world", kind="turn", namespace="sess-1")
    assert art.id is not None
    assert art.content == "hello world"
    assert art.kind == "turn"
    assert art.namespace == "sess-1"


@pytest.mark.anyio
async def test_add_artifact_deduplicates_same_content(store):
    a1 = await store.add_artifact("same content", kind="turn", namespace="ns")
    a2 = await store.add_artifact("same content", kind="turn", namespace="ns")
    assert a1.id == a2.id


@pytest.mark.anyio
async def test_add_artifact_different_namespace_not_deduplicated(store):
    a1 = await store.add_artifact("same content", kind="turn", namespace="ns-a")
    a2 = await store.add_artifact("same content", kind="turn", namespace="ns-b")
    assert a1.id != a2.id


@pytest.mark.anyio
async def test_add_artifact_stores_metadata(store):
    art = await store.add_artifact("content", kind="turn", metadata={"saliency": 0.9})
    assert art.metadata["saliency"] == 0.9


@pytest.mark.anyio
async def test_get_artifact_returns_correct(store):
    art = await store.add_artifact("find me", kind="turn", namespace="ns")
    fetched = await store.get_artifact(art.id)
    assert fetched is not None
    assert fetched.content == "find me"


@pytest.mark.anyio
async def test_get_artifact_returns_none_for_missing(store):
    result = await store.get_artifact(99999)
    assert result is None


# ---------------------------------------------------------------------------
# update_artifact
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_update_artifact_metadata(store):
    art = await store.add_artifact("original", kind="turn", namespace="ns")
    updated = await store.update_artifact(art.id, metadata={"superseded_by": "42"})
    assert updated is not None
    assert updated.metadata["superseded_by"] == "42"


@pytest.mark.anyio
async def test_update_artifact_content(store):
    art = await store.add_artifact("old content", kind="turn", namespace="ns")
    updated = await store.update_artifact(art.id, content="new content")
    assert updated is not None
    assert updated.content == "new content"


@pytest.mark.anyio
async def test_update_artifact_returns_none_for_unknown(store):
    # update_artifact on unknown id returns None (get_artifact returns None)
    result = await store.update_artifact(99999, metadata={"x": 1})
    assert result is None


# ---------------------------------------------------------------------------
# delete_artifact
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_delete_artifact_removes_it(store):
    art = await store.add_artifact("bye", kind="turn", namespace="ns")
    await store.delete_artifact(art.id)
    assert await store.get_artifact(art.id) is None


# ---------------------------------------------------------------------------
# search_artifacts (FTS)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_search_artifacts_finds_matching_content(store):
    await store.add_artifact("xyzfoo unique token here", kind="turn", namespace="ns")
    await store.add_artifact("completely different content", kind="turn", namespace="ns")

    results = await store.search_artifacts("xyzfoo", namespace="ns")
    contents = [r.artifact.content for r in results]
    assert "xyzfoo unique token here" in contents


@pytest.mark.anyio
async def test_search_artifacts_filters_by_namespace(store):
    await store.add_artifact("target content", kind="turn", namespace="sess-A")
    await store.add_artifact("target content", kind="turn", namespace="sess-B")

    results = await store.search_artifacts("target", namespace="sess-A")
    assert all(r.artifact.namespace == "sess-A" for r in results)


@pytest.mark.anyio
async def test_search_artifacts_filters_by_kind(store):
    await store.add_artifact("some text", kind="turn", namespace="ns")
    await store.add_artifact("some text", kind="session:summary", namespace="ns")

    results = await store.search_artifacts("some text", kind="turn", namespace="ns")
    # Only the 'turn' kind should appear — different content so won't deduplicate
    # Actually, same content+namespace but different kind → different artifacts


@pytest.mark.anyio
async def test_search_artifacts_empty_query_returns_recent(store):
    a1 = await store.add_artifact("first artifact", kind="turn", namespace="ns")
    a2 = await store.add_artifact("second artifact", kind="turn", namespace="ns")

    results = await store.search_artifacts("", namespace="ns", top_k=10)
    ids = [r.artifact.id for r in results]
    assert a1.id in ids
    assert a2.id in ids


@pytest.mark.anyio
async def test_search_artifacts_returns_empty_for_no_match(store):
    await store.add_artifact("something completely different", kind="turn", namespace="ns")
    results = await store.search_artifacts("xyzzy_no_match_abc", namespace="ns")
    assert results == []


# ---------------------------------------------------------------------------
# engagement log
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_engagement_sum_returns_zero_initially(store):
    total = await store.get_engagement_sum("src/foo.py", "sess-1")
    assert total == 0.0


@pytest.mark.anyio
async def test_log_and_get_engagement_sum(store):
    await store.log_engagement("src/foo.py", "sess-1", tokens=100, turn_id="t1")
    await store.log_engagement("src/foo.py", "sess-1", tokens=50, turn_id="t2")
    total = await store.get_engagement_sum("src/foo.py", "sess-1")
    assert total == 150.0


@pytest.mark.anyio
async def test_engagement_sum_scoped_to_session(store):
    await store.log_engagement("src/foo.py", "sess-A", tokens=200, turn_id="t1")
    total_b = await store.get_engagement_sum("src/foo.py", "sess-B")
    assert total_b == 0.0


@pytest.mark.anyio
async def test_get_engagement_stats_returns_zero_initially(store):
    retrievals, hits = await store.get_engagement_stats("src/foo.py", "sess-1")
    assert retrievals == 0
    assert hits == 0


@pytest.mark.anyio
async def test_log_and_get_engagement_stats(store):
    await store.log_engagement("src/foo.py", "sess-1", tokens=100, turn_id="t1", retrieval_count=3)
    await store.log_engagement("src/foo.py", "sess-1", tokens=50, turn_id="t2", retrieval_count=2)
    retrievals, hits = await store.get_engagement_stats("src/foo.py", "sess-1")
    assert retrievals == 2  # two log entries 
    assert hits == 5  # sum of retrieval_count values


@pytest.mark.anyio
async def test_engagement_stats_scoped_to_session(store):
    await store.log_engagement("src/foo.py", "sess-A", tokens=200, turn_id="t1", retrieval_count=5)
    retrievals_b, hits_b = await store.get_engagement_stats("src/foo.py", "sess-B")
    assert retrievals_b == 0
    assert hits_b == 0


# ---------------------------------------------------------------------------
# entity index
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_index_and_lookup_by_entities(store):
    art = await store.add_artifact("edited foo.py", kind="turn", namespace="ns")
    await store.index_entities(art.id, [("src/foo.py", "file")], session_id="sess-1")

    results = await store.lookup_by_entities(["src/foo.py"], "sess-1")
    assert any(r.artifact.id == art.id for r in results)


@pytest.mark.anyio
async def test_lookup_by_entities_returns_empty_for_no_match(store):
    results = await store.lookup_by_entities(["nonexistent.py"], "sess-1")
    assert results == []


@pytest.mark.anyio
async def test_lookup_by_entities_empty_list(store):
    results = await store.lookup_by_entities([], "sess-1")
    assert results == []


@pytest.mark.anyio
async def test_index_entities_noop_for_empty_pairs(store):
    art = await store.add_artifact("content", kind="turn", namespace="ns")
    # Should not raise
    await store.index_entities(art.id, [], session_id="sess-1")


# ---------------------------------------------------------------------------
# artifacts_referencing_path
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_artifacts_referencing_path_via_entity_index(store):
    art = await store.add_artifact("content", kind="turn", namespace="ns")
    await store.index_entities(art.id, [("src/bar.py", "file")], session_id="sess-1")

    ids = await store.artifacts_referencing_path("src/bar.py")
    assert art.id in ids


@pytest.mark.anyio
async def test_artifacts_referencing_path_returns_empty_for_unknown(store):
    ids = await store.artifacts_referencing_path("unknown/path.py")
    assert ids == []


# ---------------------------------------------------------------------------
# structural_lookup
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_structural_lookup_returns_matching_artifacts(store):
    art = await store.add_artifact("work on lib.py", kind="turn", namespace="ns")
    await store.index_entities(art.id, [("lib.py", "file")], session_id="sess-1")

    results = await store.structural_lookup({"lib.py"}, "sess-1")
    assert any(r.artifact.id == art.id for r in results)


@pytest.mark.anyio
async def test_structural_lookup_excludes_superseded(store):
    art = await store.add_artifact("stale work", kind="turn", namespace="ns",
                                   metadata={"superseded_by": "99"})
    await store.index_entities(art.id, [("lib.py", "file")], session_id="sess-1")

    results = await store.structural_lookup({"lib.py"}, "sess-1")
    assert not any(r.artifact.id == art.id for r in results)


@pytest.mark.anyio
async def test_structural_lookup_empty_paths(store):
    results = await store.structural_lookup(set(), "sess-1")
    assert results == []
