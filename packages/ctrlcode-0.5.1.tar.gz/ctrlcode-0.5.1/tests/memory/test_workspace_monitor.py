"""Tests for WorkspaceMonitor — refresh, update_file, _collect_source_files."""

from pathlib import Path

import pytest

from ctrlcode.memory.store import ArtifactStore
from ctrlcode.memory.workspace_monitor import WorkspaceMonitor
from ctrlcode.memory.dependency_indexer import _EXT_TO_LANG


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def store(tmp_path):
    # Put DB inside .ctrlcode/ so the workspace scanner ignores it
    s = ArtifactStore(tmp_path / ".ctrlcode" / "test.db")
    await s._ensure_init()
    yield s
    await s.close()


@pytest.fixture
def workspace(tmp_path):
    return tmp_path


@pytest.fixture
def monitor(store, workspace):
    return WorkspaceMonitor(store=store, workspace_root=workspace, session_id="test-session")


@pytest.fixture
def sync_monitor(workspace, tmp_path):
    """Lightweight monitor for sync tests that don't touch the DB."""
    store = ArtifactStore(tmp_path / ".ctrlcode" / "sync.db")
    return WorkspaceMonitor(store=store, workspace_root=workspace, session_id="test-session")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def write_file(workspace: Path, rel: str, content: str = "") -> Path:
    full = workspace / rel
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content)
    return full


# ---------------------------------------------------------------------------
# _collect_source_files
# ---------------------------------------------------------------------------

def test_collect_source_files_returns_supported_extensions(sync_monitor, workspace):
    write_file(workspace, "src/main.py", "")
    write_file(workspace, "src/app.ts", "")
    write_file(workspace, "src/lib.rs", "")
    write_file(workspace, "README.md", "")      # unsupported
    write_file(workspace, "data.csv", "")        # unsupported

    files = sync_monitor._collect_source_files()
    exts = {Path(f).suffix.lower() for f in files}

    assert ".py" in exts
    assert ".ts" in exts
    assert ".rs" in exts
    assert ".md" not in exts
    assert ".csv" not in exts


def test_collect_source_files_respects_ignored_dirs(sync_monitor, workspace):
    write_file(workspace, "src/main.py", "")
    write_file(workspace, "node_modules/pkg/index.js", "")
    write_file(workspace, ".venv/lib/helper.py", "")
    write_file(workspace, "__pycache__/cached.py", "")

    files = sync_monitor._collect_source_files()
    paths = set(files)

    assert "src/main.py" in paths
    assert not any("node_modules" in f for f in paths)
    assert not any(".venv" in f for f in paths)
    assert not any("__pycache__" in f for f in paths)


def test_collect_source_files_empty_workspace(sync_monitor):
    assert sync_monitor._collect_source_files() == []


# ---------------------------------------------------------------------------
# refresh — first run
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_refresh_first_run_indexes_source_files(monitor, workspace):
    write_file(workspace, "a.py", "")
    write_file(workspace, "b.py", "from a import x")

    change_set = await monitor.refresh()

    # After first run, dep graph should have edges for b.py
    deps = await monitor.dep_indexer.get_dependencies("b.py")
    assert "a.py" in deps


@pytest.mark.anyio
async def test_refresh_first_run_returns_changeset(monitor, workspace):
    write_file(workspace, "main.py", "")

    change_set = await monitor.refresh()

    # Added files should be in the change set
    assert len(change_set.added) > 0


@pytest.mark.anyio
async def test_refresh_first_run_empty_workspace(monitor):
    # Empty workspace — no source files, change set should be empty
    change_set = await monitor.refresh()
    assert change_set.is_empty
    assert monitor._collect_source_files() == []


# ---------------------------------------------------------------------------
# refresh — subsequent run
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_reindex_changed_updates_dep_edges(monitor, workspace):
    """reindex_changed removes stale edges and inserts fresh ones for modified files."""
    write_file(workspace, "c.py", "")
    write_file(workspace, "d.py", "from c import x")

    await monitor.dep_indexer.index_file("d.py")
    assert "c.py" in await monitor.dep_indexer.get_dependencies("d.py")

    # Rewrite d.py — now imports e instead of c
    write_file(workspace, "e.py", "")
    write_file(workspace, "d.py", "from e import x")

    await monitor.dep_indexer.reindex_changed(["d.py"])

    deps = await monitor.dep_indexer.get_dependencies("d.py")
    assert "e.py" in deps
    assert "c.py" not in deps


# ---------------------------------------------------------------------------
# update_file
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_update_file_reindexes_python(monitor, workspace):
    write_file(workspace, "lib.py", "")
    write_file(workspace, "main.py", "from lib import x")

    await monitor.update_file("main.py")

    deps = await monitor.dep_indexer.get_dependencies("main.py")
    assert "lib.py" in deps


@pytest.mark.anyio
async def test_update_file_reindexes_typescript(monitor, workspace):
    write_file(workspace, "src/util.ts", "")
    write_file(workspace, "src/app.ts", 'import { x } from "./util"')

    await monitor.update_file("src/app.ts")

    deps = await monitor.dep_indexer.get_dependencies("src/app.ts")
    assert any("util" in d for d in deps)


@pytest.mark.anyio
async def test_update_file_skips_unsupported_extension(monitor, workspace):
    write_file(workspace, "notes.txt", "some text")

    # Should not raise and dep_indexer should not be called for .txt
    await monitor.update_file("notes.txt")

    deps = await monitor.dep_indexer.get_dependencies("notes.txt")
    assert deps == []


@pytest.mark.anyio
async def test_update_file_handles_missing_file_gracefully(monitor):
    # Should not raise even if file doesn't exist on disk
    await monitor.update_file("ghost.py")


# ---------------------------------------------------------------------------
# start_watching / stop_watching
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_start_watching_creates_task(monitor):
    await monitor.start_watching()
    assert monitor._watch_task is not None
    await monitor.stop_watching()


@pytest.mark.anyio
async def test_start_watching_is_idempotent(monitor):
    await monitor.start_watching()
    task1 = monitor._watch_task
    await monitor.start_watching()  # second call should not replace task
    assert monitor._watch_task is task1
    await monitor.stop_watching()


@pytest.mark.anyio
async def test_stop_watching_clears_task(monitor):
    await monitor.start_watching()
    await monitor.stop_watching()
    assert monitor._watch_task is None


@pytest.mark.anyio
async def test_stop_watching_safe_when_not_started(monitor):
    await monitor.stop_watching()  # must not raise


# ---------------------------------------------------------------------------
# _supersede_path
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_supersede_path_marks_artifact_as_external(monitor):
    artifact = await monitor._store.add_artifact(
        "some content",
        kind="turn:assistant",
        namespace="sess",
        metadata={"entities": {"files": ["foo.py"]}},
    )
    await monitor._store.index_entities(artifact.id, [("foo.py", "file")], "sess")

    await monitor._supersede_path("foo.py")

    updated = await monitor._store.get_artifact(artifact.id)
    assert updated.metadata.get("superseded_by") == "__external__"
    assert updated.metadata.get("validity_score") == 0.0


@pytest.mark.anyio
async def test_supersede_path_skips_already_superseded(monitor):
    artifact = await monitor._store.add_artifact(
        "content",
        kind="turn:assistant",
        namespace="sess",
        metadata={"superseded_by": "prior"},
    )
    await monitor._store.index_entities(artifact.id, [("bar.py", "file")], "sess")

    await monitor._supersede_path("bar.py")

    updated = await monitor._store.get_artifact(artifact.id)
    # Original superseded_by should be unchanged
    assert updated.metadata.get("superseded_by") == "prior"


@pytest.mark.anyio
async def test_supersede_path_no_artifacts_no_error(monitor):
    await monitor._supersede_path("nonexistent.py")  # must not raise


# ---------------------------------------------------------------------------
# _supersede_stale
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_supersede_stale_marks_modified_files(monitor):
    from ctrlcode.memory.file_tree import FileChangeSet

    artifact = await monitor._store.add_artifact(
        "content",
        kind="turn:assistant",
        namespace="sess",
        metadata={},
    )
    await monitor._store.index_entities(artifact.id, [("changed.py", "file")], "sess")

    change_set = FileChangeSet(
        added=set(), modified={"changed.py"}, deleted=set(), moved={}
    )
    await monitor._supersede_stale(change_set)

    updated = await monitor._store.get_artifact(artifact.id)
    assert updated.metadata.get("superseded_by") == "__external__"


@pytest.mark.anyio
async def test_supersede_stale_skips_already_superseded(monitor):
    from ctrlcode.memory.file_tree import FileChangeSet

    artifact = await monitor._store.add_artifact(
        "content",
        kind="turn:assistant",
        namespace="sess",
        metadata={"superseded_by": "existing"},
    )
    await monitor._store.index_entities(artifact.id, [("stale.py", "file")], "sess")

    change_set = FileChangeSet(
        added=set(), modified={"stale.py"}, deleted=set(), moved={}
    )
    await monitor._supersede_stale(change_set)

    updated = await monitor._store.get_artifact(artifact.id)
    assert updated.metadata.get("superseded_by") == "existing"
