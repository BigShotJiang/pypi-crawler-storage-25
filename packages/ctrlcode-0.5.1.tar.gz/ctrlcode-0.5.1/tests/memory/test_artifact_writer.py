"""Tests for ArtifactWriter — write_turn, supersession, summary, helpers."""

from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.memory.artifact_writer import ArtifactWriter, _content_match_file
from ctrlcode.memory.chunker import MessageChunker
from ctrlcode.memory.entity_extractor import EntityExtractor
from ctrlcode.memory.saliency import SaliencyScorer, SaliencyResult
from ctrlcode.memory.store import Artifact, ArtifactResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_artifact(id=1, kind="turn", content="text", metadata=None):
    return Artifact(
        id=id, namespace="sess", kind=kind, content=content,
        metadata=metadata or {}, content_hash="abc",
        created_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
        updated_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
    )


def make_backend(add_return=None, search_return=None):
    b = AsyncMock()
    b.add_artifact = AsyncMock(return_value=add_return or make_artifact())
    b.search_artifacts = AsyncMock(return_value=search_return or [])
    b.update_artifact = AsyncMock(return_value=make_artifact())
    b.index_entities = AsyncMock(return_value=None)
    b.log_engagement = AsyncMock(return_value=None)
    return b


def make_writer(backend=None, workspace_root=None, llm_client=None):
    return ArtifactWriter(
        backend=backend or make_backend(),
        chunker=MessageChunker(),
        scorer=SaliencyScorer(),
        extractor=EntityExtractor(),
        project_id="proj-1",
        session_id="sess-1",
        llm_client=llm_client,
        workspace_root=workspace_root,
    )


# ---------------------------------------------------------------------------
# _content_match_file
# ---------------------------------------------------------------------------

def test_content_match_file_found(tmp_path):
    f = tmp_path / "foo.py"
    f.write_text("def hello(): pass\nreturn 42")
    result = _content_match_file("def hello(): pass", f)
    assert result is not None


def test_content_match_file_not_found(tmp_path):
    f = tmp_path / "bar.py"
    f.write_text("completely different content")
    result = _content_match_file("def hello(): pass", f)
    assert result is None


def test_content_match_file_missing_file():
    result = _content_match_file("anything", Path("/nonexistent/file.py"))
    assert result is None


def test_content_match_file_returns_hash(tmp_path):
    f = tmp_path / "baz.py"
    f.write_text("unique content 12345")
    h = _content_match_file("unique content", f)
    assert h is not None and len(h) == 64  # SHA-256 hex


# ---------------------------------------------------------------------------
# _extract_content
# ---------------------------------------------------------------------------

def test_extract_content_string():
    w = make_writer()
    assert w._extract_content({"content": "hello"}) == "hello"


def test_extract_content_list():
    w = make_writer()
    msg = {"content": [{"type": "text", "text": "part one"}, {"type": "text", "text": "part two"}]}
    assert w._extract_content(msg) == "part one part two"


def test_extract_content_missing_key():
    w = make_writer()
    assert w._extract_content({}) == ""


def test_extract_content_list_skips_non_text():
    w = make_writer()
    msg = {"content": [{"type": "image"}, {"type": "text", "text": "visible"}]}
    assert w._extract_content(msg) == "visible"


# ---------------------------------------------------------------------------
# write_turn — basic paths
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_write_turn_calls_add_artifact(make_backend_fixture):
    backend = make_backend(add_return=make_artifact(id=1))
    w = make_writer(backend=backend)

    await w.write_turn(
        user_input="add a function",
        turn_messages=[{"role": "assistant", "content": "def foo(): pass"}],
        tool_calls=[],
        assistant_text="def foo(): pass",
    )

    backend.add_artifact.assert_called()


@pytest.mark.anyio
async def test_write_turn_skips_empty_messages():
    backend = make_backend()
    w = make_writer(backend=backend)

    await w.write_turn(
        user_input="do something",
        turn_messages=[{"role": "assistant", "content": ""}],
        tool_calls=[],
        assistant_text="",
    )

    backend.add_artifact.assert_not_called()


@pytest.mark.anyio
async def test_write_turn_indexes_entities_for_file_mentions():
    backend = make_backend(add_return=make_artifact(id=5))
    w = make_writer(backend=backend)

    await w.write_turn(
        user_input="edit foo.py",
        turn_messages=[{"role": "assistant", "content": "edited src/foo.py and fixed the bug"}],
        tool_calls=[],
        assistant_text="edited src/foo.py",
    )

    backend.index_entities.assert_called()


@pytest.mark.anyio
async def test_write_turn_logs_engagement_for_file_entities():
    backend = make_backend(add_return=make_artifact(id=7))
    w = make_writer(backend=backend)

    await w.write_turn(
        user_input="edit foo.py",
        turn_messages=[{"role": "assistant", "content": "updated src/foo.py with changes"}],
        tool_calls=[],
        assistant_text="updated src/foo.py",
    )

    backend.log_engagement.assert_called()


@pytest.mark.anyio
async def test_write_turn_triggers_supersession_on_file_write():
    old_art = make_artifact(id=1, metadata={"entities": {"files": ["foo.py"], "functions": [], "errors": []}})
    backend = make_backend(
        add_return=make_artifact(id=2),
        search_return=[ArtifactResult(artifact=old_art, score=0.9)],
    )
    w = make_writer(backend=backend)

    await w.write_turn(
        user_input="rewrite foo.py",
        turn_messages=[{"role": "assistant", "content": "rewrote foo.py"}],
        tool_calls=[{"tool": "write_file", "input": {"path": "foo.py"}, "success": True}],
        assistant_text="rewrote foo.py",
    )

    backend.update_artifact.assert_called()



# ---------------------------------------------------------------------------
# _update_summary
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_update_summary_skips_below_threshold():
    backend = make_backend()
    w = make_writer(backend=backend)
    low_saliency = SaliencyResult(score=0.50, reason="default")

    await w._update_summary(low_saliency, "some text")

    backend.search_artifacts.assert_not_called()
    backend.add_artifact.assert_not_called()


@pytest.mark.anyio
async def test_update_summary_creates_new_entry():
    backend = make_backend(search_return=[], add_return=make_artifact(id=10, kind="session:summary"))
    w = make_writer(backend=backend)
    high_saliency = SaliencyResult(score=0.85, reason="decision")

    await w._update_summary(high_saliency, "we decided to use postgres")

    backend.add_artifact.assert_called_once()
    call_kwargs = backend.add_artifact.call_args[1]
    assert call_kwargs["kind"] == "session:summary"


@pytest.mark.anyio
async def test_update_summary_appends_to_existing():
    existing = make_artifact(id=10, kind="session:summary", content="prior entry")
    backend = make_backend(
        search_return=[ArtifactResult(artifact=existing, score=1.0)],
        add_return=make_artifact(id=10),
    )
    w = make_writer(backend=backend)
    high_saliency = SaliencyResult(score=0.85, reason="decision")

    await w._update_summary(high_saliency, "new decision text")

    backend.update_artifact.assert_called_once()
    call_kwargs = backend.update_artifact.call_args[1]
    assert "prior entry" in call_kwargs["content"]
    assert "new decision text" in call_kwargs["content"]


# ---------------------------------------------------------------------------
# _condense_summary
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_condense_summary_no_llm_returns_last_20_lines():
    w = make_writer()
    lines = [f"line {i}" for i in range(30)]
    existing = "\n".join(lines[:25])
    new_entry = "\n".join(lines[25:])
    result = await w._condense_summary(existing, new_entry, 1)
    result_lines = result.split("\n")
    assert len(result_lines) == 20
    assert result_lines[-1] == "line 29"


@pytest.mark.anyio
async def test_condense_summary_with_llm_uses_client():
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "condensed summary"})
    w = make_writer(llm_client=llm)

    lines = [f"line {i}" for i in range(30)]
    existing = "\n".join(lines[:25])
    new_entry = "\n".join(lines[25:])
    result = await w._condense_summary(existing, new_entry, 2)

    llm.invoke.assert_called_once()
    assert result == "condensed summary"


@pytest.mark.anyio
async def test_condense_summary_llm_exception_falls_back():
    llm = MagicMock()
    llm.invoke = MagicMock(side_effect=Exception("API error"))
    w = make_writer(llm_client=llm)

    lines = [f"line {i}" for i in range(30)]
    existing = "\n".join(lines[:25])
    new_entry = "\n".join(lines[25:])
    result = await w._condense_summary(existing, new_entry, 0)
    assert len(result.split("\n")) == 20


# ---------------------------------------------------------------------------
# _update_summary — force_llm_summary path
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_update_summary_force_bypasses_saliency_threshold():
    """force_llm_summary=True should run even when saliency is below threshold."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "forced summary"})
    backend = make_backend(search_return=[], add_return=make_artifact(id=20, kind="session:summary"))
    w = make_writer(backend=backend, llm_client=llm)
    low_saliency = SaliencyResult(score=0.10, reason="default")

    await w._update_summary(low_saliency, "some text", force_llm_summary=True)

    backend.add_artifact.assert_called_once()
    llm.invoke.assert_called_once()


@pytest.mark.anyio
async def test_update_summary_force_calls_llm_within_budget():
    """force_llm_summary=True should call LLM even when summary is well under token budget."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "condensed"})
    existing = make_artifact(
        id=10, kind="session:summary", content="short summary",
        metadata={"session_id": "sess-1", "compaction_count": 0},
    )
    backend = make_backend(
        search_return=[ArtifactResult(artifact=existing, score=1.0)],
        add_return=make_artifact(id=10),
    )
    w = make_writer(backend=backend, llm_client=llm)
    saliency = SaliencyResult(score=0.50, reason="default")

    await w._update_summary(saliency, "new work", force_llm_summary=True)

    llm.invoke.assert_called_once()


@pytest.mark.anyio
async def test_update_summary_force_increments_compaction_count():
    """force_llm_summary=True should increment compaction_count in stored metadata."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "condensed"})
    existing = make_artifact(
        id=10, kind="session:summary", content="prior summary",
        metadata={"session_id": "sess-1", "compaction_count": 2},
    )
    backend = make_backend(
        search_return=[ArtifactResult(artifact=existing, score=1.0)],
        add_return=make_artifact(id=10),
    )
    w = make_writer(backend=backend, llm_client=llm)
    saliency = SaliencyResult(score=0.50, reason="default")

    await w._update_summary(saliency, "new work", force_llm_summary=True)

    call_kwargs = backend.update_artifact.call_args[1]
    assert call_kwargs["metadata"]["compaction_count"] == 3


@pytest.mark.anyio
async def test_update_summary_force_creates_artifact_when_none_exists():
    """force_llm_summary=True with no existing summary should add a new artifact."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "fresh summary"})
    backend = make_backend(search_return=[], add_return=make_artifact(id=30, kind="session:summary"))
    w = make_writer(backend=backend, llm_client=llm)
    saliency = SaliencyResult(score=0.50, reason="default")

    await w._update_summary(saliency, "first turn work", force_llm_summary=True)

    backend.add_artifact.assert_called_once()
    call_kwargs = backend.add_artifact.call_args[1]
    assert call_kwargs["kind"] == "session:summary"
    assert call_kwargs["metadata"]["compaction_count"] == 1


# ---------------------------------------------------------------------------
# _update_summary — heuristic overflow triggers LLM
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_update_summary_overflow_triggers_llm_and_increments_count():
    """When appended summary exceeds 450 tokens, LLM condensation runs and compaction_count increments."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "condensed overflow summary"})
    long_content = "word " * 400  # ~2000 chars → ~500 tokens, over the 450-token cap
    existing = make_artifact(
        id=10, kind="session:summary", content=long_content,
        metadata={"session_id": "sess-1", "compaction_count": 1},
    )
    backend = make_backend(
        search_return=[ArtifactResult(artifact=existing, score=1.0)],
        add_return=make_artifact(id=10),
    )
    w = make_writer(backend=backend, llm_client=llm)
    high_saliency = SaliencyResult(score=0.85, reason="decision")

    await w._update_summary(high_saliency, "new entry")

    llm.invoke.assert_called_once()
    call_kwargs = backend.update_artifact.call_args[1]
    assert call_kwargs["metadata"]["compaction_count"] == 2


# ---------------------------------------------------------------------------
# _condense_summary — prompt structure
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_condense_summary_prompt_contains_structured_fields():
    """Prompt sent to LLM must contain all required structured fields."""
    llm = MagicMock()
    llm.invoke = MagicMock(return_value={"content": "ok"})
    w = make_writer(llm_client=llm)

    await w._condense_summary("prior summary", "new entry", compaction_count=3)

    prompt = llm.invoke.call_args[1]["messages"][0]["content"]
    assert "Current task state:" in prompt
    assert "Key decisions:" in prompt
    assert "Open items:" in prompt
    assert "Prior compaction count: 3" in prompt


# ---------------------------------------------------------------------------
# pytest fixture shim (write_turn tests use positional fixture arg)
# ---------------------------------------------------------------------------

@pytest.fixture
def make_backend_fixture():
    """Unused fixture — write_turn tests build their own backends."""
    pass
