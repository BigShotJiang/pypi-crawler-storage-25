"""Tests for ContextAssembler — scoring, formatting, entity extraction, assemble."""

import math
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.memory.context_assembler import ContextAssembler
from ctrlcode.memory.store import Artifact, ArtifactResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_artifact(
    id: int = 1,
    kind: str = "turn",
    content: str = "some content",
    metadata: dict | None = None,
    created_at: datetime | None = None,
) -> Artifact:
    return Artifact(
        id=id,
        namespace="test",
        kind=kind,
        content=content,
        metadata=metadata or {},
        content_hash="abc",
        created_at=created_at or datetime(2024, 1, 1, tzinfo=timezone.utc),
        updated_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
    )


def make_result(artifact: Artifact, score: float = 0.5) -> ArtifactResult:
    return ArtifactResult(artifact=artifact, score=score)


def make_backend(search_results=None, entity_results=None, structural_results=None):
    backend = AsyncMock()
    backend.search_artifacts = AsyncMock(return_value=search_results or [])
    backend.lookup_by_entities = AsyncMock(return_value=entity_results or [])
    backend.structural_lookup = AsyncMock(return_value=structural_results or [])
    backend.get_engagement_sum = AsyncMock(return_value=0.0)
    backend.get_engagement_stats = AsyncMock(return_value=(0, 0))
    backend.get_artifact = AsyncMock(return_value=None)
    return backend


def make_assembler(backend=None, dep_indexer=None):
    return ContextAssembler(
        backend=backend or make_backend(),
        project_id="proj-1",
        session_id="sess-1",
        dep_indexer=dep_indexer,
    )


# ---------------------------------------------------------------------------
# _extract_file_entities
# ---------------------------------------------------------------------------

class TestExtractFileEntities:
    def test_extracts_python_paths(self):
        asm = make_assembler()
        result = asm._extract_file_entities("look at src/foo.py and utils.py")
        assert "src/foo.py" in result
        assert "utils.py" in result

    def test_extracts_typescript(self):
        asm = make_assembler()
        result = asm._extract_file_entities("edit src/app.ts")
        assert "src/app.ts" in result

    def test_extracts_multiple_extensions(self):
        asm = make_assembler()
        # Note: the regex alternation has 'js' before 'json', so .json files match as .js
        # Use .toml and .yaml to avoid that edge case
        result = asm._extract_file_entities("config.toml and schema.yaml and readme.md")
        assert "config.toml" in result
        assert "schema.yaml" in result
        assert "readme.md" in result

    def test_returns_empty_for_no_files(self):
        asm = make_assembler()
        result = asm._extract_file_entities("just some plain text with no files")
        assert result == set()


# ---------------------------------------------------------------------------
# _decay
# ---------------------------------------------------------------------------

class TestDecay:
    def test_recent_content_has_high_penalty(self):
        # age=0 → decay ≈ 0.917: recent cross-cluster content is heavily penalized
        asm = make_assembler()
        assert asm._decay(0) > 0.8

    def test_old_content_has_low_penalty(self):
        # age=100 → decay ≈ 0.2: old cross-cluster content is lightly penalized
        asm = make_assembler()
        assert asm._decay(100) < 0.3

    def test_penalty_decreases_with_age(self):
        asm = make_assembler()
        penalties = [asm._decay(h) for h in [0, 4, 8, 24, 72]]
        assert penalties == sorted(penalties, reverse=True)


# ---------------------------------------------------------------------------
# _score
# ---------------------------------------------------------------------------

class TestScore:
    def test_entity_hit_gives_bonus(self):
        asm = make_assembler()
        art = make_artifact(id=1, metadata={"saliency": 0.5})
        result = make_result(art, score=0.5)

        with_entity = asm._score(result, set(), {1}, False, {}, set())
        without_entity = asm._score(result, set(), set(), False, {}, set())

        assert with_entity > without_entity

    def test_structural_hit_gives_bonus(self):
        asm = make_assembler()
        art = make_artifact(id=1, metadata={"saliency": 0.5})
        result = make_result(art, score=0.5)

        with_structural = asm._score(result, set(), set(), False, {}, {1})
        without_structural = asm._score(result, set(), set(), False, {}, set())

        assert with_structural > without_structural

    def test_superseded_halves_score(self):
        asm = make_assembler()
        art = make_artifact(id=1, metadata={"saliency": 0.5})
        result = make_result(art, score=0.5)

        normal = asm._score(result, set(), set(), False, {}, set())
        superseded = asm._score(result, set(), set(), True, {}, set())

        assert superseded < normal
        assert abs(superseded - normal * 0.5) < 0.01

    def test_engagement_bonus_wilson_style(self):
        asm = make_assembler()
        art = make_artifact(id=1, metadata={"saliency": 0.5, "entities": {"files": ["src/foo.py"]}})
        result = make_result(art, score=0.5)

        # Test with various hit counts to verify Wilson-style formula
        no_hits = asm._score(result, {"src/foo.py"}, set(), False, {}, set())
        with_hits = asm._score(result, {"src/foo.py"}, set(), False, {"src/foo.py": (0, 10)}, set())
        few_hits = asm._score(result, {"src/foo.py"}, set(), False, {"src/foo.py": (0, 2)}, set())

        assert with_hits > no_hits  # hits should increase score
        assert with_hits > few_hits  # more hits should score better
        # With k=5, 10 hits gives 10/(10+5)=0.67 bonus, 2 hits gives 2/(2+5)=0.29 bonus


# ---------------------------------------------------------------------------
# _format
# ---------------------------------------------------------------------------

class TestFormat:
    def test_returns_empty_when_no_content(self):
        asm = make_assembler()
        result = asm._format("", [], 4096)
        assert result == ""

    def test_includes_summary_section(self):
        asm = make_assembler()
        art = make_artifact(content="some work was done")
        result = asm._format("summary text", [(make_result(art), False, False)], 4096)
        assert "summary text" in result
        assert "Session Summary" in result

    def test_includes_history_section(self):
        asm = make_assembler()
        art = make_artifact(content="edited foo.py")
        result = asm._format("", [(make_result(art), False, False)], 4096)
        assert "Relevant History" in result
        assert "edited foo.py" in result

    def test_superseded_label_shown(self):
        asm = make_assembler()
        art = make_artifact(content="old work", metadata={"saliency": 0.3})
        result = asm._format("", [(make_result(art), True, False)], 4096)
        assert "SUPERSEDED" in result

    def test_superseding_label_shown(self):
        asm = make_assembler()
        art = make_artifact(content="new work")
        result = asm._format("", [(make_result(art), False, True)], 4096)
        assert "supersedes above" in result

    def test_respects_budget(self):
        asm = make_assembler()
        # Very small budget — should truncate
        art = make_artifact(content="x" * 2000)
        result = asm._format("", [(make_result(art), False, False)], 50)
        # Header + footer should still be present, but content may be cut
        assert "Retrieved Context" in result

    def test_wraps_with_header_and_footer(self):
        asm = make_assembler()
        art = make_artifact(content="detail")
        result = asm._format("", [(make_result(art), False, False)], 4096)
        assert result.startswith("--- Retrieved Context ---")
        assert result.endswith("--- End Retrieved Context ---")


# ---------------------------------------------------------------------------
# assemble
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_assemble_returns_empty_when_no_results():
    backend = make_backend(search_results=[], entity_results=[])
    # Summary search also returns nothing
    backend.search_artifacts = AsyncMock(return_value=[])
    asm = make_assembler(backend=backend)

    result = await asm.assemble("fix the bug", budget_tokens=4096)
    assert result == ""


@pytest.mark.anyio
async def test_assemble_includes_semantic_results():
    art = make_artifact(id=1, content="previously edited utils.py")
    backend = make_backend(search_results=[make_result(art, 0.8)])
    backend.search_artifacts = AsyncMock(side_effect=[
        [],                          # summary search
        [make_result(art, 0.8)],     # semantic search
    ])
    asm = make_assembler(backend=backend)

    result = await asm.assemble("edit utils.py", budget_tokens=4096)
    assert "previously edited utils.py" in result


@pytest.mark.anyio
async def test_assemble_calls_structural_lookup_when_dep_indexer_present():
    art = make_artifact(id=2, content="dependent file content")
    dep_indexer = AsyncMock()
    dep_indexer.get_dependents = AsyncMock(return_value={"dep.py"})

    backend = make_backend()
    backend.search_artifacts = AsyncMock(return_value=[])
    backend.structural_lookup = AsyncMock(return_value=[make_result(art, 0.6)])

    asm = make_assembler(backend=backend, dep_indexer=dep_indexer)

    await asm.assemble("fix utils.py", budget_tokens=4096)

    dep_indexer.get_dependents.assert_called()
    backend.structural_lookup.assert_called()


@pytest.mark.anyio
async def test_assemble_skips_structural_when_no_dep_indexer():
    backend = make_backend()
    backend.search_artifacts = AsyncMock(return_value=[])
    asm = make_assembler(backend=backend, dep_indexer=None)

    await asm.assemble("fix utils.py", budget_tokens=4096)

    backend.structural_lookup.assert_not_called()


@pytest.mark.anyio
async def test_assemble_handles_search_exception_gracefully():
    backend = make_backend()
    backend.search_artifacts = AsyncMock(side_effect=[
        [],                               # summary
        Exception("embedding API down"),  # semantic search fails
    ])
    asm = make_assembler(backend=backend)

    # Should not raise
    result = await asm.assemble("something", budget_tokens=4096)
    assert isinstance(result, str)


@pytest.mark.anyio
async def test_assemble_injects_query_files():
    art = make_artifact(id=3, content="work on bar.py")
    dep_indexer = AsyncMock()
    dep_indexer.get_dependents = AsyncMock(return_value=set())

    backend = make_backend()
    backend.search_artifacts = AsyncMock(return_value=[])
    backend.lookup_by_entities = AsyncMock(return_value=[make_result(art, 0.7)])

    asm = make_assembler(backend=backend, dep_indexer=dep_indexer)

    await asm.assemble("help", query_files={"bar.py"}, budget_tokens=4096)

    backend.lookup_by_entities.assert_called()
    call_args = backend.lookup_by_entities.call_args[0]
    assert "bar.py" in call_args[0]
