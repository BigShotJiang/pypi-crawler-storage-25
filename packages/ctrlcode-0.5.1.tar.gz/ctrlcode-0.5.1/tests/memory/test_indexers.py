"""Tests for language-specific import indexers."""

from pathlib import Path

from tree_sitter_language_pack import get_parser


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse(lang: str, source: bytes | str, rel_path: str, workspace_root: Path) -> list[dict]:
    """Parse source with tree-sitter and run the indexer for lang."""
    src = source if isinstance(source, bytes) else source.encode()
    parser = get_parser(lang)
    tree = parser.parse(src)
    # import the right parse function by dispatch (same as dependency_indexer)
    from ctrlcode.memory.dependency_indexer import _LANG_PARSERS
    fn = _LANG_PARSERS[lang]
    return fn(tree, src, rel_path, workspace_root)


def importees(results: list[dict]) -> list[str]:
    return [r["importee"] for r in results]


def internal(results: list[dict]) -> list[dict]:
    return [r for r in results if r["import_type"] == "internal"]


def external(results: list[dict]) -> list[dict]:
    return [r for r in results if r["import_type"] == "external"]


# ---------------------------------------------------------------------------
# Python
# ---------------------------------------------------------------------------

class TestPython:
    def test_absolute_import(self, tmp_path):
        (tmp_path / "os.py").touch()
        results = _parse("python", "import os", "main.py", tmp_path)
        assert any(r["importee"] == "os.py" and r["import_type"] == "internal" for r in results)

    def test_from_import_external(self, tmp_path):
        results = _parse("python", "from collections import OrderedDict", "main.py", tmp_path)
        ext = external(results)
        assert ext and "collections" in ext[0]["importee"]

    def test_relative_import(self, tmp_path):
        (tmp_path / "utils.py").touch()
        results = _parse("python", "from .utils import helper", "pkg/main.py", tmp_path)
        intern = internal(results)
        assert intern and "utils.py" in intern[0]["importee"]


# ---------------------------------------------------------------------------
# JavaScript / TypeScript
# ---------------------------------------------------------------------------

class TestJsTs:
    def test_relative_import_resolved(self, tmp_path):
        (tmp_path / "utils.js").write_text("")
        results = _parse("javascript", 'import foo from "./utils"', "main.js", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.js"

    def test_package_import_external(self, tmp_path):
        results = _parse("typescript", 'import React from "react"', "app.ts", tmp_path)
        assert external(results) and external(results)[0]["importee"] == "react"

    def test_require_resolved(self, tmp_path):
        (tmp_path / "lib.js").write_text("")
        results = _parse("javascript", 'const x = require("./lib")', "main.js", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "lib.js"

    def test_tsx_import(self, tmp_path):
        (tmp_path / "Button.tsx").write_text("")
        results = _parse("tsx", 'import Button from "./Button"', "App.tsx", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "Button.tsx"


# ---------------------------------------------------------------------------
# Rust
# ---------------------------------------------------------------------------

class TestRust:
    def test_crate_resolved(self, tmp_path):
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "utils.rs").write_text("")
        results = _parse("rust", "use crate::utils::helper;", "src/main.rs", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "src/utils.rs"

    def test_external_crate(self, tmp_path):
        results = _parse("rust", "use serde::Serialize;", "src/main.rs", tmp_path)
        assert external(results)

    def test_mod_declaration(self, tmp_path):
        src = tmp_path / "src"
        src.mkdir()
        (src / "models.rs").write_text("")
        results = _parse("rust", "mod models;", "src/main.rs", tmp_path)
        assert internal(results) and "models.rs" in internal(results)[0]["importee"]


# ---------------------------------------------------------------------------
# C / C++
# ---------------------------------------------------------------------------

class TestCCpp:
    def test_local_include_resolved(self, tmp_path):
        (tmp_path / "utils.h").write_text("")
        results = _parse("c", '#include "utils.h"', "main.c", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.h"

    def test_system_include_external(self, tmp_path):
        results = _parse("c", "#include <stdio.h>", "main.c", tmp_path)
        assert external(results) and "<stdio.h>" in external(results)[0]["importee"]

    def test_cpp_include(self, tmp_path):
        (tmp_path / "mylib.hpp").write_text("")
        results = _parse("cpp", '#include "mylib.hpp"', "main.cpp", tmp_path)
        assert internal(results)


# ---------------------------------------------------------------------------
# Objective-C (reuses C parser)
# ---------------------------------------------------------------------------

class TestObjC:
    def test_local_import_resolved(self, tmp_path):
        (tmp_path / "MyClass.h").write_text("")
        results = _parse("objc", '#import "MyClass.h"', "main.m", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "MyClass.h"

    def test_framework_import_external(self, tmp_path):
        results = _parse("objc", "#import <Foundation/Foundation.h>", "main.m", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Ruby
# ---------------------------------------------------------------------------

class TestRuby:
    def test_require_relative_resolved(self, tmp_path):
        (tmp_path / "utils.rb").write_text("")
        results = _parse("ruby", 'require_relative "utils"', "main.rb", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.rb"

    def test_require_external(self, tmp_path):
        results = _parse("ruby", 'require "json"', "main.rb", tmp_path)
        assert external(results) and external(results)[0]["importee"] == "json"


# ---------------------------------------------------------------------------
# Java / Kotlin
# ---------------------------------------------------------------------------

class TestJava:
    def test_import_external(self, tmp_path):
        results = _parse("java", "import java.util.List;", "Main.java", tmp_path)
        assert external(results) and "java.util" in external(results)[0]["importee"]

    def test_import_internal(self, tmp_path):
        src = tmp_path / "src" / "main" / "java" / "com" / "example"
        src.mkdir(parents=True)
        (src / "Foo.java").write_text("")
        results = _parse("java", "import com.example.Foo;", "Main.java", tmp_path)
        assert internal(results)


class TestKotlin:
    def test_import_external(self, tmp_path):
        results = _parse("kotlin", "import kotlin.collections.List", "Main.kt", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Lua
# ---------------------------------------------------------------------------

class TestLua:
    def test_dotted_require_resolved(self, tmp_path):
        (tmp_path / "mymodule.lua").write_text("")
        results = _parse("lua", 'require("mymodule")', "main.lua", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "mymodule.lua"

    def test_relative_require_resolved(self, tmp_path):
        (tmp_path / "lib.lua").write_text("")
        results = _parse("lua", 'require("./lib")', "main.lua", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "lib.lua"

    def test_external_require(self, tmp_path):
        results = _parse("lua", 'require("socket")', "main.lua", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Dart
# ---------------------------------------------------------------------------

class TestDart:
    def test_relative_import_resolved(self, tmp_path):
        (tmp_path / "utils.dart").write_text("")
        results = _parse("dart", "import './utils.dart';", "main.dart", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.dart"

    def test_package_import_external(self, tmp_path):
        results = _parse("dart", "import 'package:flutter/material.dart';", "main.dart", tmp_path)
        assert external(results)

    def test_dart_sdk_external(self, tmp_path):
        results = _parse("dart", "import 'dart:async';", "main.dart", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Zig
# ---------------------------------------------------------------------------

class TestZig:
    def test_relative_import_resolved(self, tmp_path):
        (tmp_path / "utils.zig").write_text("")
        results = _parse("zig", 'const u = @import("./utils.zig");', "main.zig", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.zig"

    def test_std_import_external(self, tmp_path):
        results = _parse("zig", 'const std = @import("std");', "main.zig", tmp_path)
        assert external(results) and external(results)[0]["importee"] == "std"


# ---------------------------------------------------------------------------
# Go
# ---------------------------------------------------------------------------

class TestGo:
    def test_stdlib_external(self, tmp_path):
        results = _parse("go", 'import "fmt"', "main.go", tmp_path)
        assert external(results) and external(results)[0]["importee"] == "fmt"

    def test_relative_import_resolved(self, tmp_path):
        pkg = tmp_path / "utils"
        pkg.mkdir()
        (pkg / "helper.go").write_text("package utils")
        results = _parse("go", 'import "./utils"', "main.go", tmp_path)
        assert internal(results) and "utils/helper.go" in internal(results)[0]["importee"]


# ---------------------------------------------------------------------------
# Scala
# ---------------------------------------------------------------------------

class TestScala:
    def test_import_external(self, tmp_path):
        results = _parse("scala", "import scala.collection.mutable.ListBuffer", "Main.scala", tmp_path)
        assert external(results)
        assert "scala.collection.mutable" in results[0]["importee"]


# ---------------------------------------------------------------------------
# Swift
# ---------------------------------------------------------------------------

class TestSwift:
    def test_import_external(self, tmp_path):
        results = _parse("swift", "import Foundation\nimport UIKit", "App.swift", tmp_path)
        names = importees(results)
        assert "Foundation" in names
        assert "UIKit" in names
        assert all(r["import_type"] == "external" for r in results)


# ---------------------------------------------------------------------------
# PHP
# ---------------------------------------------------------------------------

class TestPhp:
    def test_require_relative_resolved(self, tmp_path):
        (tmp_path / "config.php").write_text("")
        results = _parse("php", "<?php\nrequire './config.php';", "main.php", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "config.php"

    def test_require_once_resolved(self, tmp_path):
        lib = tmp_path / "lib"
        lib.mkdir()
        (lib / "helper.php").write_text("")
        results = _parse("php", "<?php\nrequire_once './lib/helper.php';", "main.php", tmp_path)
        assert internal(results)

    def test_use_namespace_external(self, tmp_path):
        results = _parse("php", "<?php\nuse App\\Models\\User;", "main.php", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# C#
# ---------------------------------------------------------------------------

class TestCSharp:
    def test_using_simple(self, tmp_path):
        results = _parse("csharp", "using System;", "Program.cs", tmp_path)
        assert external(results) and results[0]["importee"] == "System"

    def test_using_qualified(self, tmp_path):
        results = _parse("csharp", "using System.Collections.Generic;", "Program.cs", tmp_path)
        assert external(results)
        assert "System.Collections.Generic" in results[0]["importee"]


# ---------------------------------------------------------------------------
# Elixir
# ---------------------------------------------------------------------------

class TestElixir:
    def test_import(self, tmp_path):
        results = _parse("elixir", "import Enum", "main.ex", tmp_path)
        assert external(results) and results[0]["importee"] == "Enum"

    def test_alias(self, tmp_path):
        results = _parse("elixir", "alias MyApp.User", "main.ex", tmp_path)
        assert external(results) and "User" in results[0]["importee"]

    def test_use_and_require(self, tmp_path):
        src = "use GenServer\nrequire Logger"
        results = _parse("elixir", src, "main.ex", tmp_path)
        names = importees(results)
        assert "GenServer" in names
        assert "Logger" in names


# ---------------------------------------------------------------------------
# Haskell
# ---------------------------------------------------------------------------

class TestHaskell:
    def test_simple_import(self, tmp_path):
        results = _parse("haskell", "import Data.List", "Main.hs", tmp_path)
        assert external(results) and results[0]["importee"] == "Data.List"

    def test_qualified_import(self, tmp_path):
        results = _parse("haskell", "import qualified Data.Map as Map", "Main.hs", tmp_path)
        assert external(results) and results[0]["importee"] == "Data.Map"

    def test_import_with_names(self, tmp_path):
        results = _parse("haskell", "import Data.Maybe (fromMaybe)", "Main.hs", tmp_path)
        assert external(results) and results[0]["importee"] == "Data.Maybe"


# ---------------------------------------------------------------------------
# OCaml
# ---------------------------------------------------------------------------

class TestOCaml:
    def test_open(self, tmp_path):
        results = _parse("ocaml", "open Printf\nopen MyModule", "main.ml", tmp_path)
        names = importees(results)
        assert "Printf" in names
        assert "MyModule" in names
        assert all(r["import_type"] == "external" for r in results)


# ---------------------------------------------------------------------------
# F#
# ---------------------------------------------------------------------------

class TestFSharp:
    def test_open(self, tmp_path):
        results = _parse("fsharp", "open System.IO\nopen MyModule", "Main.fs", tmp_path)
        names = importees(results)
        assert "System.IO" in names
        assert "MyModule" in names


# ---------------------------------------------------------------------------
# Erlang
# ---------------------------------------------------------------------------

class TestErlang:
    def test_include_resolved(self, tmp_path):
        (tmp_path / "header.hrl").write_text("")
        src = b'-include("header.hrl").'
        results = _parse("erlang", src, "main.erl", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "header.hrl"

    def test_include_lib_external(self, tmp_path):
        src = b'-include_lib("stdlib/include/lists.hrl").'
        results = _parse("erlang", src, "main.erl", tmp_path)
        assert external(results)

    def test_import_attribute_external(self, tmp_path):
        src = b'-import(lists, [map/2]).'
        results = _parse("erlang", src, "main.erl", tmp_path)
        assert external(results) and results[0]["importee"] == "lists"


# ---------------------------------------------------------------------------
# Clojure
# ---------------------------------------------------------------------------

class TestClojure:
    def test_ns_require(self, tmp_path):
        src = "(ns my.app\n  (:require [clojure.string :as str]\n            [clojure.set :refer [union]]))"
        results = _parse("clojure", src, "main.clj", tmp_path)
        names = importees(results)
        assert "clojure.string" in names
        assert "clojure.set" in names

    def test_ns_import(self, tmp_path):
        src = "(ns my.app\n  (:import (java.util Date)))"
        results = _parse("clojure", src, "main.clj", tmp_path)
        assert any("java.util" in r["importee"] for r in results)


# ---------------------------------------------------------------------------
# Julia
# ---------------------------------------------------------------------------

class TestJulia:
    def test_import_external(self, tmp_path):
        results = _parse("julia", "import Pkg", "main.jl", tmp_path)
        assert external(results) and results[0]["importee"] == "Pkg"

    def test_using_external(self, tmp_path):
        results = _parse("julia", "using LinearAlgebra", "main.jl", tmp_path)
        assert external(results)

    def test_include_resolved(self, tmp_path):
        (tmp_path / "utils.jl").write_text("")
        results = _parse("julia", 'include("utils.jl")', "main.jl", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.jl"


# ---------------------------------------------------------------------------
# Groovy
# ---------------------------------------------------------------------------

class TestGroovy:
    def test_import_external(self, tmp_path):
        results = _parse("groovy", "import groovy.json.JsonSlurper", "main.groovy", tmp_path)
        assert external(results) and "groovy.json.JsonSlurper" in results[0]["importee"]


# ---------------------------------------------------------------------------
# Nim
# ---------------------------------------------------------------------------

class TestNim:
    def test_import_external(self, tmp_path):
        results = _parse("nim", "import os\nimport strutils", "main.nim", tmp_path)
        names = importees(results)
        assert "os" in names
        assert "strutils" in names

    def test_relative_import_resolved(self, tmp_path):
        (tmp_path / "mymodule.nim").write_text("")
        results = _parse("nim", "import ./mymodule", "main.nim", tmp_path)
        assert internal(results) and "mymodule" in internal(results)[0]["importee"]


# ---------------------------------------------------------------------------
# D
# ---------------------------------------------------------------------------

class TestD:
    def test_import_external(self, tmp_path):
        results = _parse("d", "import std.stdio;\nimport std.algorithm;", "main.d", tmp_path)
        names = importees(results)
        assert "std.stdio" in names
        assert "std.algorithm" in names
        assert all(r["import_type"] == "external" for r in results)


# ---------------------------------------------------------------------------
# Perl
# ---------------------------------------------------------------------------

class TestPerl:
    def test_use_external(self, tmp_path):
        results = _parse("perl", "use Foo::Bar;", "main.pl", tmp_path)
        assert external(results) and results[0]["importee"] == "Foo::Bar"

    def test_require_file_resolved(self, tmp_path):
        (tmp_path / "utils.pl").write_text("")
        results = _parse("perl", 'require "utils.pl";', "main.pl", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.pl"

    def test_require_module_external(self, tmp_path):
        results = _parse("perl", "require Foo::Baz;", "main.pl", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# R
# ---------------------------------------------------------------------------

class TestR:
    def test_library_external(self, tmp_path):
        results = _parse("r", "library(dplyr)", "main.r", tmp_path)
        assert external(results) and results[0]["importee"] == "dplyr"

    def test_source_resolved(self, tmp_path):
        (tmp_path / "utils.R").write_text("")
        results = _parse("r", 'source("./utils.R")', "main.r", tmp_path)
        assert internal(results)

    def test_source_external(self, tmp_path):
        results = _parse("r", 'source("https://example.com/script.R")', "main.r", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Solidity
# ---------------------------------------------------------------------------

class TestSolidity:
    def test_relative_import_resolved(self, tmp_path):
        (tmp_path / "Token.sol").write_text("")
        results = _parse("solidity", 'import "./Token.sol";', "main.sol", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "Token.sol"

    def test_package_import_external(self, tmp_path):
        results = _parse("solidity", 'import "@openzeppelin/contracts/ERC20.sol";', "main.sol", tmp_path)
        assert external(results)

    def test_named_import_resolved(self, tmp_path):
        (tmp_path / "SafeMath.sol").write_text("")
        results = _parse("solidity", 'import {SafeMath} from "./SafeMath.sol";', "main.sol", tmp_path)
        assert internal(results)


# ---------------------------------------------------------------------------
# V (vlang)
# ---------------------------------------------------------------------------

class TestV:
    def test_import_external(self, tmp_path):
        results = _parse("v", "import os\nimport net.http", "main.v", tmp_path)
        names = importees(results)
        assert "os" in names
        assert "net.http" in names
        assert all(r["import_type"] == "external" for r in results)


# ---------------------------------------------------------------------------
# Gleam
# ---------------------------------------------------------------------------

class TestGleam:
    def test_import_external(self, tmp_path):
        results = _parse("gleam", "import gleam/list\nimport gleam/string", "main.gleam", tmp_path)
        names = importees(results)
        assert "gleam/list" in names
        assert "gleam/string" in names


# ---------------------------------------------------------------------------
# Elm
# ---------------------------------------------------------------------------

class TestElm:
    def test_import_external(self, tmp_path):
        results = _parse("elm", "import Html exposing (..)\nimport Json.Decode as D", "Main.elm", tmp_path)
        names = importees(results)
        assert "Html" in names
        assert "Json.Decode" in names


# ---------------------------------------------------------------------------
# PureScript
# ---------------------------------------------------------------------------

class TestPureScript:
    def test_import_external(self, tmp_path):
        results = _parse("purescript", "import Data.Array (map)\nimport Data.Maybe", "Main.purs", tmp_path)
        names = importees(results)
        assert "Data.Array" in names
        assert "Data.Maybe" in names


# ---------------------------------------------------------------------------
# Haxe
# ---------------------------------------------------------------------------

class TestHaxe:
    def test_import_external(self, tmp_path):
        results = _parse("haxe", "import haxe.ds.Map;\nimport mypackage.MyClass;", "Main.hx", tmp_path)
        names = importees(results)
        assert any("haxe.ds.Map" in n for n in names)
        assert any("mypackage.MyClass" in n for n in names)


# ---------------------------------------------------------------------------
# GDScript
# ---------------------------------------------------------------------------

class TestGDScript:
    def test_preload_resolved(self, tmp_path):
        scripts = tmp_path / "scripts"
        scripts.mkdir()
        (scripts / "MyClass.gd").write_text("")
        results = _parse("gdscript", 'const X = preload("res://scripts/MyClass.gd")', "main.gd", tmp_path)
        assert internal(results) and "scripts/MyClass.gd" in internal(results)[0]["importee"]

    def test_preload_unresolved(self, tmp_path):
        results = _parse("gdscript", 'const X = preload("res://missing.gd")', "main.gd", tmp_path)
        assert external(results)


# ---------------------------------------------------------------------------
# Pony
# ---------------------------------------------------------------------------

class TestPony:
    def test_use_external(self, tmp_path):
        results = _parse("pony", 'use "collections"\nuse "files"', "main.pony", tmp_path)
        names = importees(results)
        assert "collections" in names
        assert "files" in names
        assert all(r["import_type"] == "external" for r in results)


# ---------------------------------------------------------------------------
# Racket
# ---------------------------------------------------------------------------

class TestRacket:
    def test_symbol_require_external(self, tmp_path):
        results = _parse("racket", "(require racket/list)", "main.rkt", tmp_path)
        assert external(results) and results[0]["importee"] == "racket/list"

    def test_string_require_resolved(self, tmp_path):
        (tmp_path / "mymodule.rkt").write_text("")
        results = _parse("racket", '(require "mymodule.rkt")', "main.rkt", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "mymodule.rkt"

    def test_file_form_resolved(self, tmp_path):
        target = tmp_path / "path" / "to"
        target.mkdir(parents=True)
        (target / "file.rkt").write_text("")
        results = _parse("racket", '(require (file "path/to/file.rkt"))', "main.rkt", tmp_path)
        assert internal(results)


# ---------------------------------------------------------------------------
# Scheme
# ---------------------------------------------------------------------------

class TestScheme:
    def test_import_external(self, tmp_path):
        results = _parse("scheme", "(import (scheme list) (mylib utils))", "main.scm", tmp_path)
        assert all(r["import_type"] == "external" for r in results)
        assert len(results) == 2

    def test_include_resolved(self, tmp_path):
        (tmp_path / "utils.scm").write_text("")
        results = _parse("scheme", '(include "utils.scm")', "main.scm", tmp_path)
        assert internal(results) and internal(results)[0]["importee"] == "utils.scm"


# ---------------------------------------------------------------------------
# Odin
# ---------------------------------------------------------------------------

class TestOdin:
    def test_package_import_external(self, tmp_path):
        results = _parse("odin", 'import "core:fmt"\nimport "vendor:raylib"', "main.odin", tmp_path)
        names = importees(results)
        assert "core:fmt" in names
        assert "vendor:raylib" in names
        assert all(r["import_type"] == "external" for r in results)

    def test_relative_import_resolved(self, tmp_path):
        pkg = tmp_path / "utils"
        pkg.mkdir()
        (pkg / "helper.odin").write_text("")
        results = _parse("odin", 'import "./utils"', "main.odin", tmp_path)
        assert internal(results)


# ---------------------------------------------------------------------------
# EXT_TO_LANG coverage: every extension maps to a lang with a parser
# ---------------------------------------------------------------------------

def test_all_extensions_have_parsers():
    from ctrlcode.memory.indexers import _EXT_TO_LANG
    from ctrlcode.memory.dependency_indexer import _LANG_PARSERS
    missing = set(_EXT_TO_LANG.values()) - set(_LANG_PARSERS.keys())
    assert not missing, f"Languages in _EXT_TO_LANG with no parser: {missing}"


def test_all_langs_in_pack():
    from tree_sitter_language_pack import SupportedLanguage
    from ctrlcode.memory.indexers import _EXT_TO_LANG
    pack = set(SupportedLanguage.__args__)
    not_in_pack = set(_EXT_TO_LANG.values()) - pack
    assert not not_in_pack, f"Languages not in tree-sitter-language-pack: {not_in_pack}"
