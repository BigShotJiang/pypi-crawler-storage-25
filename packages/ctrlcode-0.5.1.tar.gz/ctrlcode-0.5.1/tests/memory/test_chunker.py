"""Tests for MessageChunker — chunk_message, _chunk_prose, _chunk_tool_body, _split_on_fences."""

import pytest
from ctrlcode.memory.chunker import MessageChunker, Chunk


@pytest.fixture
def chunker():
    return MessageChunker()


# ---------------------------------------------------------------------------
# _split_on_fences
# ---------------------------------------------------------------------------

def test_split_no_fences(chunker):
    segs = chunker._split_on_fences("plain prose text")
    assert len(segs) == 1
    assert segs[0][0] == "prose"


def test_split_extracts_code_block(chunker):
    content = "before\n```python\ncode here\n```\nafter"
    segs = chunker._split_on_fences(content)
    types = [s[0] for s in segs]
    assert "code" in types
    assert "prose" in types


def test_split_code_has_language(chunker):
    content = "```typescript\nconst x = 1;\n```"
    segs = chunker._split_on_fences(content)
    code_seg = next(s for s in segs if s[0] == "code")
    assert code_seg[2] == "typescript"


def test_split_code_no_language_empty_string(chunker):
    content = "```\nsome code\n```"
    segs = chunker._split_on_fences(content)
    code_seg = next(s for s in segs if s[0] == "code")
    assert code_seg[2] == ""


def test_split_multiple_fences(chunker):
    content = "```python\nfoo\n```\nprose\n```js\nbar\n```"
    segs = chunker._split_on_fences(content)
    code_segs = [s for s in segs if s[0] == "code"]
    assert len(code_segs) == 2


# ---------------------------------------------------------------------------
# _chunk_prose
# ---------------------------------------------------------------------------

def test_chunk_prose_short_content_is_single_chunk(chunker):
    chunks = chunker._chunk_prose("Hello world.", "turn:user")
    assert len(chunks) == 1
    assert chunks[0].kind == "turn:user"


def test_chunk_prose_preserves_content(chunker):
    text = "This is a sentence. This is another."
    chunks = chunker._chunk_prose(text, "turn:user")
    combined = " ".join(c.content for c in chunks)
    assert "sentence" in combined
    assert "another" in combined


def test_chunk_prose_empty_falls_back(chunker):
    chunks = chunker._chunk_prose("", "turn:user")
    assert len(chunks) >= 1


def test_chunk_prose_large_text_splits(chunker):
    # Create a long text that exceeds TARGET_MAX (800 token-equivalents = ~3200 chars)
    sentence = "The quick brown fox jumps over the lazy dog. "
    text = sentence * 100  # ~4400 chars
    chunks = chunker._chunk_prose(text, "turn:assistant")
    assert len(chunks) > 1


# ---------------------------------------------------------------------------
# _heuristic_code_chunk
# ---------------------------------------------------------------------------

def test_heuristic_splits_on_blank_lines(chunker):
    code = "def foo():\n    pass\n\ndef bar():\n    pass"
    chunks = chunker._heuristic_code_chunk(code, "python", "turn:assistant")
    assert len(chunks) == 2


def test_heuristic_single_block(chunker):
    code = "x = 1"
    chunks = chunker._heuristic_code_chunk(code, "python", "turn:assistant")
    assert len(chunks) == 1
    assert chunks[0].content == "x = 1"
    assert chunks[0].language == "python"


def test_heuristic_empty_returns_one_chunk(chunker):
    chunks = chunker._heuristic_code_chunk("", "py", "turn:assistant")
    assert len(chunks) == 1


# ---------------------------------------------------------------------------
# _chunk_tool_body
# ---------------------------------------------------------------------------

def test_tool_body_traceback_single_chunk(chunker):
    body = "Traceback (most recent call last):\n  File foo.py, line 1\nValueError: bad"
    chunks = chunker._chunk_tool_body(body, "run_command")
    assert len(chunks) == 1
    assert chunks[0].metadata["tool"] == "run_command"


def test_tool_body_json_dict_with_many_keys(chunker):
    import json
    data = {"a": 1, "b": 2, "c": 3, "d": 4}
    body = json.dumps(data)
    chunks = chunker._chunk_tool_body(body, "read_file")
    assert len(chunks) == 4
    assert all(c.kind == "turn:tool_result" for c in chunks)


def test_tool_body_json_dict_few_keys_no_split(chunker):
    import json
    data = {"a": 1, "b": 2}
    body = json.dumps(data)
    chunks = chunker._chunk_tool_body(body, "read_file")
    # 2 keys ≤ 3, falls through to paragraph split or prose
    assert len(chunks) >= 1


def test_tool_body_paragraphs_split(chunker):
    body = "First paragraph.\n\nSecond paragraph."
    chunks = chunker._chunk_tool_body(body, "list_dir")
    assert len(chunks) == 2


def test_tool_body_plain_prose_falls_through(chunker):
    body = "Just a plain result string."
    chunks = chunker._chunk_tool_body(body, "run_command")
    assert len(chunks) >= 1
    assert all(c.kind == "turn:tool_result" for c in chunks)


# ---------------------------------------------------------------------------
# chunk_message
# ---------------------------------------------------------------------------

def test_chunk_message_user_role(chunker):
    chunks = chunker.chunk_message("user", "fix the bug")
    assert all(c.kind == "turn:user" for c in chunks)


def test_chunk_message_assistant_role(chunker):
    chunks = chunker.chunk_message("assistant", "Here is the fix.")
    assert all(c.kind == "turn:assistant" for c in chunks)


def test_chunk_message_other_role_is_tool_result(chunker):
    chunks = chunker.chunk_message("system", "some result")
    assert all(c.kind == "turn:tool_result" for c in chunks)


def test_chunk_message_tool_prefix_dispatches_tool_body(chunker):
    # Use an error-like body so _chunk_tool_body returns with meta intact
    content = "[Tool: run_command]\nTraceback (most recent call last):\n  line 1\nError: bad"
    chunks = chunker.chunk_message("user", content)
    assert all(c.metadata.get("tool") == "run_command" for c in chunks)


def test_chunk_message_with_code_fence(chunker):
    content = "Here is code:\n```python\ndef foo(): pass\n```\nDone."
    chunks = chunker.chunk_message("assistant", content)
    assert len(chunks) >= 1


def test_chunk_message_returns_list_of_chunks(chunker):
    chunks = chunker.chunk_message("user", "hello")
    assert isinstance(chunks, list)
    assert all(isinstance(c, Chunk) for c in chunks)
