"""Tests for PermissionManager — request_permission_async, handle_permission_response, cache."""

import asyncio
from unittest.mock import AsyncMock

import pytest

from ctrlcode.permissions import (
    DESTRUCTIVE_TOOLS,
    PermissionManager,
    PermissionRequest,
    PermissionResponse,
    _extract_executable,
    _platform_safe_commands,
    get_permission_manager,
    is_destructive,
    is_safe_command,
    request_permission,
    set_permission_manager,
)


# ---------------------------------------------------------------------------
# DESTRUCTIVE_TOOLS / is_destructive
# ---------------------------------------------------------------------------

def test_is_destructive_write_file():
    assert is_destructive("write_file") is True


def test_is_destructive_read_file():
    assert is_destructive("read_file") is False


def test_is_destructive_all_destructive_tools():
    for tool in ("write_file", "update_file", "create_file", "edit_file", "delete_file", "run_command"):
        assert is_destructive(tool) is True


def test_is_destructive_safe_tools():
    for tool in ("read_file", "search_files", "list_directory", "get_file_info", "fetch", "todo_list"):
        assert is_destructive(tool) is False


# ---------------------------------------------------------------------------
# PermissionResponse dataclass
# ---------------------------------------------------------------------------

def test_permission_response_dataclass():
    r = PermissionResponse(approved=True, accept_all=False, context=None)
    assert r.approved is True
    assert r.accept_all is False
    assert r.context is None


def test_permission_response_with_context():
    r = PermissionResponse(approved=False, context="use config system instead")
    assert r.approved is False
    assert r.context == "use config system instead"


# ---------------------------------------------------------------------------
# Auto-approve (no callback)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_auto_approve_when_no_callback():
    mgr = PermissionManager()
    approved, ctx = await mgr.request_permission_async("write_file", "/tmp/x", "test")
    assert approved is True
    assert ctx is None


# ---------------------------------------------------------------------------
# accept_all short-circuit
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_request_permission_accept_all_short_circuits():
    callback = AsyncMock()
    mgr = PermissionManager(approval_callback=callback)
    mgr.set_accept_all(True)
    approved, ctx = await mgr.request_permission_async("write_file", "/tmp/x", "test")
    assert approved is True
    assert ctx is None
    callback.assert_not_called()


def test_set_accept_all():
    mgr = PermissionManager()
    assert mgr.accept_all is False
    mgr.set_accept_all(True)
    assert mgr.accept_all is True
    mgr.set_accept_all(False)
    assert mgr.accept_all is False


# ---------------------------------------------------------------------------
# Cached paths
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_cached_path_returns_true_without_callback():
    mgr = PermissionManager()
    mgr._approved_paths.add("write_file:/tmp/x")
    approved, ctx = await mgr.request_permission_async("write_file", "/tmp/x", "test")
    assert approved is True


# ---------------------------------------------------------------------------
# Callback + handle_permission_response
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_callback_approve():
    approved_fut: asyncio.Future = asyncio.get_event_loop().create_future()

    async def callback(request_id: str, req: PermissionRequest):
        approved_fut.set_result(request_id)

    mgr = PermissionManager(approval_callback=callback)

    async def approve_after_callback():
        req_id = await approved_fut
        mgr.handle_permission_response(req_id, PermissionResponse(approved=True))

    results = await asyncio.gather(
        mgr.request_permission_async("read_file", "/tmp/y", "need"),
        approve_after_callback(),
    )
    approved, ctx = results[0]
    assert approved is True
    assert ctx is None


@pytest.mark.anyio
async def test_callback_deny():
    denied_fut: asyncio.Future = asyncio.get_event_loop().create_future()

    async def callback(request_id: str, req: PermissionRequest):
        denied_fut.set_result(request_id)

    mgr = PermissionManager(approval_callback=callback)

    async def deny_after_callback():
        req_id = await denied_fut
        mgr.handle_permission_response(req_id, PermissionResponse(approved=False))

    results = await asyncio.gather(
        mgr.request_permission_async("write_file", "/tmp/z", "need"),
        deny_after_callback(),
    )
    approved, ctx = results[0]
    assert approved is False


@pytest.mark.anyio
async def test_request_permission_returns_context():
    """Context string flows through the future back to the caller."""
    context_fut: asyncio.Future = asyncio.get_event_loop().create_future()

    async def callback(request_id: str, req: PermissionRequest):
        context_fut.set_result(request_id)

    mgr = PermissionManager(approval_callback=callback)

    async def send_context_response():
        req_id = await context_fut
        mgr.handle_permission_response(
            req_id, PermissionResponse(approved=False, context="use config system")
        )

    results = await asyncio.gather(
        mgr.request_permission_async("write_file", "/tmp/c", "need"),
        send_context_response(),
    )
    approved, ctx = results[0]
    assert approved is False
    assert ctx == "use config system"


@pytest.mark.anyio
async def test_accept_all_enabled_by_response():
    """accept_all=True in PermissionResponse sets manager.accept_all."""
    response_fut: asyncio.Future = asyncio.get_event_loop().create_future()

    async def callback(request_id: str, req: PermissionRequest):
        response_fut.set_result(request_id)

    mgr = PermissionManager(approval_callback=callback)

    async def send_accept_all():
        req_id = await response_fut
        mgr.handle_permission_response(
            req_id, PermissionResponse(approved=True, accept_all=True)
        )

    results = await asyncio.gather(
        mgr.request_permission_async("write_file", "/tmp/a", "need"),
        send_accept_all(),
    )
    approved, _ = results[0]
    assert approved is True
    assert mgr.accept_all is True


@pytest.mark.anyio
async def test_remember_caches_approval():
    approved_fut: asyncio.Future = asyncio.get_event_loop().create_future()

    async def callback(request_id: str, req: PermissionRequest):
        approved_fut.set_result(request_id)

    mgr = PermissionManager(approval_callback=callback)

    async def approve():
        req_id = await approved_fut
        mgr.handle_permission_response(req_id, PermissionResponse(approved=True))

    await asyncio.gather(
        mgr.request_permission_async("write_file", "/tmp/r", "need", remember=True),
        approve(),
    )

    # Second call should use cache (no callback needed)
    approved, ctx = await mgr.request_permission_async("write_file", "/tmp/r", "need")
    assert approved is True
    assert "write_file:/tmp/r" in mgr._approved_paths


@pytest.mark.anyio
async def test_timeout_returns_false():
    async def callback(request_id: str, req: PermissionRequest):
        pass  # never resolves

    mgr = PermissionManager(approval_callback=callback)
    approved, ctx = await mgr.request_permission_async("write_file", "/tmp/t", "test", timeout=0.05)
    assert approved is False
    assert ctx is None


# ---------------------------------------------------------------------------
# handle_permission_response edge cases
# ---------------------------------------------------------------------------

def test_handle_response_unknown_id_noop():
    mgr = PermissionManager()
    mgr.handle_permission_response("no-such-id", PermissionResponse(approved=True))  # should not raise


@pytest.mark.anyio
async def test_handle_response_already_done_noop():
    mgr = PermissionManager()
    f: asyncio.Future = asyncio.get_event_loop().create_future()
    f.set_result(PermissionResponse(approved=True))
    mgr._pending_requests["done-id"] = f
    mgr.handle_permission_response("done-id", PermissionResponse(approved=False))  # should not raise


# ---------------------------------------------------------------------------
# clear_cache
# ---------------------------------------------------------------------------

def test_clear_cache_removes_approvals():
    mgr = PermissionManager()
    mgr._approved_paths.add("write_file:/tmp/a")
    mgr.clear_cache()
    assert len(mgr._approved_paths) == 0


# ---------------------------------------------------------------------------
# Global singleton
# ---------------------------------------------------------------------------

def test_set_and_get_permission_manager():
    mgr = PermissionManager()
    set_permission_manager(mgr)
    assert get_permission_manager() is mgr


@pytest.mark.anyio
async def test_request_permission_no_global_manager_auto_approves():
    set_permission_manager(None)
    approved, ctx = await request_permission("read_file", "/tmp/q", "test")
    assert approved is True
    assert ctx is None


@pytest.mark.anyio
async def test_request_permission_uses_global_manager():
    mgr = PermissionManager()  # auto-approve
    set_permission_manager(mgr)
    approved, ctx = await request_permission("read_file", "/tmp/q", "test")
    assert approved is True


# ---------------------------------------------------------------------------
# Safe command allowlist
# ---------------------------------------------------------------------------

def test_extract_executable_simple():
    assert _extract_executable("ls -la /tmp") == "ls"


def test_extract_executable_full_path():
    assert _extract_executable("/usr/bin/grep foo bar") == "grep"


def test_extract_executable_empty():
    assert _extract_executable("") == ""


def test_is_safe_command_known_safe():
    safe = frozenset({"ls", "cat", "grep"})
    assert is_safe_command("ls -la", safe) is True
    assert is_safe_command("cat /etc/hosts", safe) is True


def test_is_safe_command_unknown():
    safe = frozenset({"ls", "cat"})
    assert is_safe_command("rm -rf /", safe) is False


def test_platform_safe_commands_nonempty():
    cmds = _platform_safe_commands()
    assert len(cmds) > 0
    assert "ls" in cmds or "dir" in cmds  # at least one universal command


def test_permission_manager_default_safe_commands():
    mgr = PermissionManager()
    # ls is safe on all platforms
    assert mgr.is_safe_command("ls -la /tmp") is True


def test_permission_manager_extra_safe_commands_merged():
    mgr = PermissionManager(extra_safe_commands=["my-linter", "custom-check"])
    assert mgr.is_safe_command("my-linter src/") is True
    assert mgr.is_safe_command("custom-check --strict") is True
    # Platform defaults still present
    assert mgr.is_safe_command("ls") is True


def test_permission_manager_unsafe_command():
    mgr = PermissionManager()
    assert mgr.is_safe_command("rm -rf /") is False
    assert mgr.is_safe_command("curl -X POST http://example.com") is False
