"""Tests for MetricsDashboard — format_report, get_trend_data, calculate_roi, get_summary."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.metrics.dashboard import MetricsDashboard, MetricsSummary


@pytest.fixture
def dashboard():
    return MetricsDashboard()


# ---------------------------------------------------------------------------
# get_summary — no memory
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_get_summary_no_memory_returns_defaults(dashboard):
    summary = await dashboard.get_summary()
    assert isinstance(summary, MetricsSummary)
    assert summary.total_sessions == 0


@pytest.mark.anyio
async def test_get_summary_with_memory():
    memory = MagicMock()
    memory.search_artifacts = AsyncMock(return_value=[])
    d = MetricsDashboard(memory)
    summary = await d.get_summary()
    # No sessions since we removed fuzzing
    assert summary.total_sessions == 0


# ---------------------------------------------------------------------------
# format_report
# ---------------------------------------------------------------------------

def test_format_report_contains_header(dashboard):
    report = dashboard.format_report()
    assert "HISTORICAL LEARNING METRICS DASHBOARD" in report


def test_format_report_shows_session_count(dashboard):
    summary = MetricsSummary(total_sessions=42)
    report = dashboard.format_report(summary)
    assert "42" in report


def test_format_report_shows_bug_count(dashboard):
    summary = MetricsSummary(total_bugs_in_db=7)
    report = dashboard.format_report(summary)
    assert "7" in report


def test_format_report_without_summary_uses_defaults(dashboard):
    report = dashboard.format_report()
    assert "0" in report  # defaults to 0


# ---------------------------------------------------------------------------
# get_trend_data
# ---------------------------------------------------------------------------

def test_get_trend_data_returns_dict(dashboard):
    data = dashboard.get_trend_data()
    assert isinstance(data, dict)
    assert "sessions_by_day" in data


def test_get_trend_data_respects_days_param(dashboard):
    data = dashboard.get_trend_data(days=7)
    assert isinstance(data, dict)


# ---------------------------------------------------------------------------
# calculate_roi
# ---------------------------------------------------------------------------

def test_calculate_roi_returns_dict(dashboard):
    roi = dashboard.calculate_roi()
    assert "roi_percentage" in roi
    assert "total_cost_usd" in roi


# ---------------------------------------------------------------------------
# get_top_oracles / get_common_bug_patterns
# ---------------------------------------------------------------------------

def test_get_top_oracles_returns_list(dashboard):
    assert dashboard.get_top_oracles() == []


def test_get_common_bug_patterns_returns_list(dashboard):
    assert dashboard.get_common_bug_patterns() == []
