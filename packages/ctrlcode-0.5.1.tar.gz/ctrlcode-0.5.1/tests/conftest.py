"""Global test configuration and fixtures."""

import pytest
from unittest.mock import AsyncMock, MagicMock


class MockProvider:
    """Minimal mock provider for tests that need an LLM provider."""

    def __init__(self, response_text: str = "{}"):
        self.response_text = response_text
        self.call_count = 0

    async def generate(self, messages: list[dict], **kwargs) -> dict:
        self.call_count += 1
        return {"text": self.response_text}

    async def stream(self, messages: list[dict], **kwargs):
        yield {"type": "text", "data": {"text": self.response_text}}

    def normalize_tool_call(self, tool_call: dict) -> dict:
        return tool_call


@pytest.fixture
def mock_provider():
    """Provide a mock LLM provider."""
    return MockProvider()
