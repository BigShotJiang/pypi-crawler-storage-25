"""Tests for WebFetchTools — validation, SSRF protection, error handling."""

import urllib.error
import urllib.request
from unittest.mock import MagicMock, patch

import pytest

from ctrlcode.tools.webfetch import WebFetchTools


# ---------------------------------------------------------------------------
# Input validation (no network needed)
# ---------------------------------------------------------------------------

def test_rejects_non_http_protocol():
    t = WebFetchTools()
    result = t.fetch("ftp://example.com/file")
    assert "error" in result
    assert "http" in result["error"].lower()


def test_rejects_localhost():
    t = WebFetchTools()
    result = t.fetch("http://localhost/api")
    assert "error" in result
    assert "localhost" in result["error"].lower()


def test_rejects_127_0_0_1():
    t = WebFetchTools()
    result = t.fetch("http://127.0.0.1/secret")
    assert "error" in result


def test_rejects_unsupported_method():
    t = WebFetchTools()
    with patch("urllib.request.urlopen"):
        result = t.fetch("https://example.com", method="TRACE")
    assert "error" in result
    assert "TRACE" in result["error"]


def test_timeout_clamped_to_max():
    t = WebFetchTools()
    mock_response = MagicMock()
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    mock_response.read.return_value = b"ok"
    mock_response.headers = {}
    mock_response.status = 200

    with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
        t.fetch("https://example.com", timeout=9999)
        _, kwargs = mock_open.call_args
        assert kwargs["timeout"] <= 120


def test_timeout_clamped_to_min():
    t = WebFetchTools()
    mock_response = MagicMock()
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    mock_response.read.return_value = b"ok"
    mock_response.headers = {}
    mock_response.status = 200

    with patch("urllib.request.urlopen", return_value=mock_response) as mock_open:
        t.fetch("https://example.com", timeout=0)
        _, kwargs = mock_open.call_args
        assert kwargs["timeout"] >= 1


# ---------------------------------------------------------------------------
# Successful request (mocked)
# ---------------------------------------------------------------------------

def test_successful_get_returns_body():
    t = WebFetchTools()
    mock_response = MagicMock()
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    mock_response.read.return_value = b'{"ok": true}'
    mock_response.headers = {"content-type": "application/json"}
    mock_response.status = 200

    with patch("urllib.request.urlopen", return_value=mock_response):
        result = t.fetch("https://api.example.com/data")

    assert result["success"] is True
    assert result["status_code"] == 200
    assert '{"ok": true}' in result["body"]
    assert result["method"] == "GET"


def test_post_with_body():
    t = WebFetchTools()
    mock_response = MagicMock()
    mock_response.__enter__ = MagicMock(return_value=mock_response)
    mock_response.__exit__ = MagicMock(return_value=False)
    mock_response.read.return_value = b"created"
    mock_response.headers = {}
    mock_response.status = 201

    with patch("urllib.request.urlopen", return_value=mock_response):
        result = t.fetch("https://api.example.com/items", method="POST", body='{"name":"foo"}')

    assert result["success"] is True
    assert result["method"] == "POST"


# ---------------------------------------------------------------------------
# Error handling (mocked)
# ---------------------------------------------------------------------------

def test_http_error_returns_status_code():
    t = WebFetchTools()
    err = urllib.error.HTTPError(
        url="https://example.com", code=404, msg="Not Found", hdrs={}, fp=None
    )
    with patch("urllib.request.urlopen", side_effect=err):
        result = t.fetch("https://example.com/missing")

    assert result["success"] is False
    assert result["status_code"] == 404
    assert "404" in result["error"]


def test_url_error_returns_failure():
    t = WebFetchTools()
    err = urllib.error.URLError(reason="Name or service not known")
    with patch("urllib.request.urlopen", side_effect=err):
        result = t.fetch("https://doesnotexist.invalid/")

    assert result["success"] is False
    assert "error" in result


def test_timeout_error_returns_message():
    t = WebFetchTools()
    with patch("urllib.request.urlopen", side_effect=TimeoutError()):
        result = t.fetch("https://slow.example.com/", timeout=1)

    assert result["success"] is False
    assert "timed out" in result["error"]
