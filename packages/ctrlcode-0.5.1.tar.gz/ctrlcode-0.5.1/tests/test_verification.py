"""Tests for VerificationDetector — auto-detected project verification commands."""

import pytest
from pathlib import Path

from ctrlcode.session.verification import VerificationDetector


@pytest.fixture
def detector():
    return VerificationDetector()


@pytest.fixture
def workspace(tmp_path):
    return tmp_path


# ------------------------------------------------------------------
# detect() — project marker scanning
# ------------------------------------------------------------------

def test_detect_python_uv(detector, workspace):
    (workspace / "pyproject.toml").write_text("[project]")
    (workspace / "uv.lock").write_text("")
    assert detector.detect(workspace) == ["uv run pytest"]


def test_detect_python_poetry(detector, workspace):
    (workspace / "pyproject.toml").write_text("[project]")
    (workspace / "poetry.lock").write_text("")
    assert detector.detect(workspace) == ["poetry run pytest"]


def test_detect_python_bare(detector, workspace):
    (workspace / "pyproject.toml").write_text("[project]")
    assert detector.detect(workspace) == ["pytest"]


def test_detect_pytest_ini(detector, workspace):
    (workspace / "pytest.ini").write_text("[pytest]")
    assert detector.detect(workspace) == ["pytest"]


def test_detect_go(detector, workspace):
    (workspace / "go.mod").write_text("module example.com/app")
    assert detector.detect(workspace) == ["go test ./..."]


def test_detect_rust(detector, workspace):
    (workspace / "Cargo.toml").write_text("[package]")
    assert detector.detect(workspace) == ["cargo test"]


def test_detect_npm(detector, workspace):
    (workspace / "package.json").write_text('{"scripts": {"test": "jest"}}')
    (workspace / "package-lock.json").write_text("{}")
    assert detector.detect(workspace) == ["npm test"]


def test_detect_pnpm(detector, workspace):
    (workspace / "package.json").write_text('{"scripts": {"test": "jest"}}')
    (workspace / "pnpm-lock.yaml").write_text("")
    assert detector.detect(workspace) == ["pnpm test"]


def test_detect_yarn(detector, workspace):
    (workspace / "package.json").write_text('{"scripts": {"test": "jest"}}')
    (workspace / "yarn.lock").write_text("")
    assert detector.detect(workspace) == ["yarn test"]


def test_detect_package_json_no_test_script(detector, workspace):
    (workspace / "package.json").write_text('{"scripts": {"build": "tsc"}}')
    assert detector.detect(workspace) == []


def test_detect_makefile_test(detector, workspace):
    (workspace / "Makefile").write_text("test:\n\tpytest\n")
    assert detector.detect(workspace) == ["make test"]


def test_detect_makefile_verify(detector, workspace):
    (workspace / "Makefile").write_text("verify:\n\t./check.sh\n")
    assert detector.detect(workspace) == ["make verify"]


def test_detect_makefile_test_takes_priority_over_verify(detector, workspace):
    (workspace / "Makefile").write_text("test:\n\tpytest\nverify:\n\t./check.sh\n")
    assert detector.detect(workspace) == ["make test"]


def test_detect_dbt(detector, workspace):
    (workspace / "dbt_project.yml").write_text("name: my_project")
    assert detector.detect(workspace) == ["dbt test"]


def test_detect_no_markers(detector, workspace):
    assert detector.detect(workspace) == []


def test_detect_multiple_markers(detector, workspace):
    (workspace / "go.mod").write_text("module example.com")
    (workspace / "Makefile").write_text("test:\n\tgo test ./...\n")
    cmds = detector.detect(workspace)
    assert "go test ./..." in cmds
    assert "make test" in cmds


# ------------------------------------------------------------------
# parse_agent_md()
# ------------------------------------------------------------------

def test_parse_agent_md_fenced_sh(detector, tmp_path):
    md = tmp_path / "AGENT.md"
    md.write_text(
        "# Project\n\n"
        "## Verification\n\n"
        "Run these:\n\n"
        "```sh\n"
        "uv run pytest tests/ -x -q\n"
        "uv run mypy src/\n"
        "```\n"
    )
    assert detector.parse_agent_md(md) == ["uv run pytest tests/ -x -q", "uv run mypy src/"]


def test_parse_agent_md_fenced_bash(detector, tmp_path):
    md = tmp_path / "AGENT.md"
    md.write_text("## Verification\n\n```bash\ncargo test\n```\n")
    assert detector.parse_agent_md(md) == ["cargo test"]


def test_parse_agent_md_bullet_fallback(detector, tmp_path):
    md = tmp_path / "AGENT.md"
    md.write_text("## Verification\n\n- `uv run pytest`\n- `make lint`\n")
    assert detector.parse_agent_md(md) == ["uv run pytest", "make lint"]


def test_parse_agent_md_no_verification_section(detector, tmp_path):
    md = tmp_path / "AGENT.md"
    md.write_text("# Project\n\n## Setup\n\nRun `pip install`.\n")
    assert detector.parse_agent_md(md) == []


def test_parse_agent_md_missing_file(detector, tmp_path):
    assert detector.parse_agent_md(tmp_path / "AGENT.md") == []


def test_parse_agent_md_skips_comments(detector, tmp_path):
    md = tmp_path / "AGENT.md"
    md.write_text("## Verification\n\n```sh\n# run tests\npytest\n```\n")
    assert detector.parse_agent_md(md) == ["pytest"]


# ------------------------------------------------------------------
# merge()
# ------------------------------------------------------------------

def test_merge_combines_lists(detector):
    result = detector.merge(["pytest", "make test"], ["go test ./..."])
    assert result == ["pytest", "make test", "go test ./..."]


def test_merge_deduplicates(detector):
    result = detector.merge(["pytest", "make test"], ["pytest", "mypy"])
    assert result == ["pytest", "make test", "mypy"]


def test_merge_empty(detector):
    assert detector.merge([], []) == []


# ------------------------------------------------------------------
# command_ran()
# ------------------------------------------------------------------

def test_command_ran_exact_match(detector):
    assert detector.command_ran("pytest", ["pytest"])


def test_command_ran_with_extra_args(detector):
    assert detector.command_ran("uv run pytest", ["uv run pytest tests/ -x -q -k foo"])


def test_command_ran_go_test(detector):
    assert detector.command_ran("go test ./...", ["go test ./... -v -count=1"])


def test_command_ran_no_match(detector):
    assert not detector.command_ran("pytest", ["cargo test", "make build"])


def test_command_ran_empty_history(detector):
    assert not detector.command_ran("pytest", [])


def test_command_ran_does_not_cross_match(detector):
    # 'npm test' should not match 'npm install'
    assert not detector.command_ran("npm test", ["npm install"])
