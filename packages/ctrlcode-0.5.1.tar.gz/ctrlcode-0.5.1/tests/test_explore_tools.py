"""Tests for ExploreTools — search_files, read_file, list_directory, get_file_info, write_file."""

import pytest
from pathlib import Path
from unittest.mock import patch

from ctrlcode.tools.explore import ExploreTools


@pytest.fixture
def tools(tmp_path):
    return ExploreTools(tmp_path)


def make_file(tmp_path: Path, rel: str, content: str = "hello") -> Path:
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return p


# ---------------------------------------------------------------------------
# search_files
# ---------------------------------------------------------------------------

def test_search_files_finds_py_files(tools, tmp_path):
    make_file(tmp_path, "a.py")
    make_file(tmp_path, "b.py")
    results = tools.search_files("**/*.py")
    assert "a.py" in results
    assert "b.py" in results


def test_search_files_respects_max_results(tools, tmp_path):
    for i in range(10):
        make_file(tmp_path, f"file{i}.py")
    results = tools.search_files("**/*.py", max_results=3)
    assert len(results) <= 3


def test_search_files_empty_workspace(tools):
    results = tools.search_files("**/*.py")
    assert results == []


def test_search_files_returns_sorted(tools, tmp_path):
    make_file(tmp_path, "z.py")
    make_file(tmp_path, "a.py")
    results = tools.search_files("**/*.py")
    assert results == sorted(results)


# ---------------------------------------------------------------------------
# read_file
# ---------------------------------------------------------------------------

def test_read_file_returns_content(tools, tmp_path):
    make_file(tmp_path, "hello.txt", "line1\nline2\nline3\n")
    result = tools.read_file("hello.txt")
    assert result["content"] == "line1\nline2\nline3\n"
    assert result["total_lines"] == 3


def test_read_file_with_line_range(tools, tmp_path):
    make_file(tmp_path, "f.txt", "a\nb\nc\nd\n")
    result = tools.read_file("f.txt", start_line=2, end_line=3)
    assert "b" in result["content"]
    assert "a" not in result["content"]
    assert "d" not in result["content"]


def test_read_file_not_found(tools):
    result = tools.read_file("nonexistent.txt")
    assert "error" in result


def test_read_file_path_outside_workspace(tools):
    result = tools.read_file("../../etc/passwd")
    assert "error" in result


def test_read_file_returns_path(tools, tmp_path):
    make_file(tmp_path, "info.txt", "data")
    result = tools.read_file("info.txt")
    assert result["path"] == "info.txt"


# ---------------------------------------------------------------------------
# list_directory
# ---------------------------------------------------------------------------

def test_list_directory_root(tools, tmp_path):
    make_file(tmp_path, "file.py")
    (tmp_path / "subdir").mkdir()
    result = tools.list_directory()
    assert "file.py" in [f["path"] for f in result["files"]]
    assert "subdir" in result["directories"]


def test_list_directory_not_found(tools):
    result = tools.list_directory("nonexistent")
    assert "error" in result


def test_list_directory_path_outside_workspace(tools):
    result = tools.list_directory("../../etc")
    assert "error" in result


def test_list_directory_not_a_directory(tools, tmp_path):
    make_file(tmp_path, "f.txt")
    result = tools.list_directory("f.txt")
    assert "error" in result


def test_list_directory_max_depth(tools, tmp_path):
    make_file(tmp_path, "a/b/c.txt")
    result = tools.list_directory(max_depth=1)
    # At depth 1, we shouldn't see c.txt under a/b/
    files = [f["path"] for f in result["files"]]
    assert not any("b/c.txt" in f for f in files)


# ---------------------------------------------------------------------------
# get_file_info
# ---------------------------------------------------------------------------

def test_get_file_info_returns_metadata(tools, tmp_path):
    make_file(tmp_path, "info.txt", "hello world")
    result = tools.get_file_info("info.txt")
    assert result["is_file"] is True
    assert result["size"] > 0
    assert result["extension"] == ".txt"


def test_get_file_info_not_found(tools):
    result = tools.get_file_info("missing.txt")
    assert "error" in result


def test_get_file_info_path_outside_workspace(tools):
    result = tools.get_file_info("../../etc/passwd")
    assert "error" in result


def test_get_file_info_directory(tools, tmp_path):
    (tmp_path / "mydir").mkdir()
    result = tools.get_file_info("mydir")
    assert result["is_directory"] is True


# ---------------------------------------------------------------------------
# write_file (async)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_write_file_creates_new_file(tools, tmp_path):
    result = await tools.write_file("new.txt", "content here")
    assert result["success"] is True
    assert (tmp_path / "new.txt").read_text() == "content here"


@pytest.mark.anyio
async def test_write_file_fails_if_exists(tools, tmp_path):
    make_file(tmp_path, "existing.txt", "old")
    result = await tools.write_file("existing.txt", "new content")
    assert "error" in result
    assert "already exists" in result["error"]


@pytest.mark.anyio
async def test_write_file_creates_parent_dirs(tools, tmp_path):
    result = await tools.write_file("deep/nested/file.txt", "data")
    assert result["success"] is True
    assert (tmp_path / "deep" / "nested" / "file.txt").exists()


@pytest.mark.anyio
async def test_write_file_returns_bytes_written(tools, tmp_path):
    result = await tools.write_file("out.txt", "hello")
    assert result["bytes_written"] == 5


# ---------------------------------------------------------------------------
# search_code
# ---------------------------------------------------------------------------

def test_search_code_finds_match(tools, tmp_path):
    make_file(tmp_path, "code.py", "def my_function():\n    pass\n")
    results = tools.search_code("my_function")
    assert any("my_function" in r["content"] for r in results)
    assert any(r["file"] == "code.py" for r in results)


def test_search_code_no_match(tools, tmp_path):
    make_file(tmp_path, "code.py", "def foo(): pass\n")
    results = tools.search_code("zzznomatch")
    assert results == []


def test_search_code_with_file_pattern(tools, tmp_path):
    make_file(tmp_path, "a.py", "target_word\n")
    make_file(tmp_path, "b.txt", "target_word\n")
    results = tools.search_code("target_word", file_pattern="**/*.py")
    assert all(r["file"].endswith(".py") for r in results)


def test_search_code_respects_max_results(tools, tmp_path):
    content = "\n".join(f"hit_{i}" for i in range(30))
    make_file(tmp_path, "big.py", content)
    results = tools.search_code("hit_", max_results=5)
    assert len(results) <= 5


def test_search_code_returns_line_numbers(tools, tmp_path):
    make_file(tmp_path, "f.py", "a\nb\ntarget\nd\n")
    results = tools.search_code("target")
    assert any(r["line"] == 3 for r in results)


# ---------------------------------------------------------------------------
# python_grep (fallback search via FilesystemBackend._python_grep)
# ---------------------------------------------------------------------------

def test_python_grep_finds_match(tools, tmp_path):
    make_file(tmp_path, "code.py", "def my_function():\n    pass\n")
    results = tools._backend._python_grep("my_function", "**/*.py", 10)
    assert any("my_function" in r["content"] for r in results)


def test_python_grep_no_match(tools, tmp_path):
    make_file(tmp_path, "code.py", "def foo(): pass\n")
    results = tools._backend._python_grep("zzznomatch", "**/*.py", 10)
    assert results == []


def test_python_grep_respects_max(tools, tmp_path):
    content = "\n".join(f"match_{i}" for i in range(20))
    make_file(tmp_path, "big.py", content)
    results = tools._backend._python_grep("match_", "**/*.py", 5)
    assert len(results) <= 5
