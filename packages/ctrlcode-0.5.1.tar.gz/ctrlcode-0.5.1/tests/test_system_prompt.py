"""Tests for build_system_prompt — skills injection."""

import asyncio
from pathlib import Path

import pytest

from ctrlcode.session.system_prompt import build_system_prompt
from ctrlcode.skills.loader import Skill
from ctrlcode.skills.registry import SkillRegistry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _FakeAssembler:
    async def assemble(self, query: str, budget_tokens: int) -> str:
        return ""


def _make_registry(*skills: Skill) -> SkillRegistry:
    reg = SkillRegistry()
    for s in skills:
        reg.register(s)
    return reg


def _run(coro):
    return asyncio.run(coro)


BASE_KWARGS = dict(
    base_prompt="You are a helpful assistant.",
    agent_instructions="",
    verification_commands=[],
    ctrlcode_dir=Path("/tmp/ctrlcode"),
    workspace_root=None,
    assembler=_FakeAssembler(),
    context_limit=200_000,
    context_before_turn=1_000,
    user_input="hello",
)


# ---------------------------------------------------------------------------
# No skill_registry → no <skills> block
# ---------------------------------------------------------------------------

def test_no_skill_registry_no_skills_block():
    result = _run(build_system_prompt(**BASE_KWARGS, skill_registry=None))
    assert "<skills>" not in result["content"]


def test_skill_registry_none_explicit():
    result = _run(build_system_prompt(**BASE_KWARGS))
    assert "<skills>" not in result["content"]


# ---------------------------------------------------------------------------
# With skill_registry → <skills> block present
# ---------------------------------------------------------------------------

def test_skills_block_injected_when_registry_populated():
    reg = _make_registry(
        Skill(name="commit", instructions="Create a commit", description="Commit changes"),
        Skill(name="test", instructions="Run tests", description="Run test suite"),
    )
    result = _run(build_system_prompt(**BASE_KWARGS, skill_registry=reg))
    content = result["content"]
    assert "<skills>" in content
    assert "commit" in content
    assert "test" in content


def test_skills_guidelines_injected_when_registry_populated():
    reg = _make_registry(Skill(name="foo", instructions="do foo", description="Foo skill"))
    result = _run(build_system_prompt(**BASE_KWARGS, skill_registry=reg))
    assert "<skills_guidelines>" in result["content"]


def test_empty_registry_produces_no_skills_block():
    reg = SkillRegistry()  # empty
    result = _run(build_system_prompt(**BASE_KWARGS, skill_registry=reg))
    assert "<skills>" not in result["content"]


# ---------------------------------------------------------------------------
# Verification commands
# ---------------------------------------------------------------------------

def test_verification_commands_injected(tmp_path):
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "verification_commands": ["pytest", "mypy src/"]},
    ))
    content = result["content"]
    assert "pytest" in content
    assert "mypy src/" in content
    assert "Verification" in content


def test_no_verification_commands_no_section(tmp_path):
    result = _run(build_system_prompt(**BASE_KWARGS))
    assert "Verification" not in result["content"]


# ---------------------------------------------------------------------------
# Project todos
# ---------------------------------------------------------------------------

def test_project_todos_injected(tmp_path):
    import json
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    todos = [
        {"content": "Fix the bug", "status": "pending"},
        {"content": "Write tests", "status": "completed"},
    ]
    (todos_dir / "project.json").write_text(json.dumps(todos))
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    content = result["content"]
    assert "Fix the bug" in content
    assert "Project Backlog" in content


def test_empty_todos_list_no_backlog_section(tmp_path):
    import json
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    (todos_dir / "project.json").write_text(json.dumps([]))
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    assert "Project Backlog" not in result["content"]


# ---------------------------------------------------------------------------
# Prior session progress
# ---------------------------------------------------------------------------

def test_prior_progress_injected(tmp_path):
    (tmp_path / "progress.md").write_text("Completed auth middleware refactor.")
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    content = result["content"]
    assert "Completed auth middleware refactor." in content
    assert "Prior Session Progress" in content


def test_empty_progress_file_no_section(tmp_path):
    (tmp_path / "progress.md").write_text("")
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    assert "Prior Session Progress" not in result["content"]


# ---------------------------------------------------------------------------
# Exception fallback paths
# ---------------------------------------------------------------------------

def test_assembler_exception_falls_back_to_no_context():
    class _FailAssembler:
        async def assemble(self, query: str, budget_tokens: int) -> str:
            raise RuntimeError("embeddings unavailable")

    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "assembler": _FailAssembler()},
    ))
    assert result["role"] == "system"  # didn't raise, returned gracefully


def test_malformed_todos_json_no_crash(tmp_path):
    todos_dir = tmp_path / "todos"
    todos_dir.mkdir()
    (todos_dir / "project.json").write_text("not valid json {{")
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    assert "Project Backlog" not in result["content"]


def test_progress_file_read_error_no_crash(tmp_path):
    # Write a directory named progress.md so read_text() raises IsADirectoryError
    progress_dir = tmp_path / "progress.md"
    progress_dir.mkdir()
    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "ctrlcode_dir": tmp_path},
    ))
    assert "Prior Session Progress" not in result["content"]


# ---------------------------------------------------------------------------
# Semantic context injection
# ---------------------------------------------------------------------------

def test_semantic_context_injected():
    class _ContextAssembler:
        async def assemble(self, query: str, budget_tokens: int) -> str:
            return "<context>relevant file snippet</context>"

    result = _run(build_system_prompt(
        **{**BASE_KWARGS, "assembler": _ContextAssembler()},
    ))
    assert "relevant file snippet" in result["content"]
