"""Tests for SkillRegistry — register, expand, parse, process_input."""

import pytest
from ctrlcode.skills.loader import Skill
from ctrlcode.skills.registry import SkillRegistry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_skill(name="greet", instructions="Say hello {args}", requires_args=False):
    return Skill(name=name, instructions=instructions, requires_args=requires_args)


@pytest.fixture
def registry():
    return SkillRegistry()


@pytest.fixture
def populated(registry):
    registry.register(make_skill("greet", "Say hello {args}"))
    registry.register(make_skill("deploy", "Deploy now", requires_args=False))
    registry.register(make_skill("issue", "File issue: {args}", requires_args=True))
    return registry


# ---------------------------------------------------------------------------
# register / get / list
# ---------------------------------------------------------------------------

def test_register_and_get(registry):
    skill = make_skill("foo")
    registry.register(skill)
    assert registry.get("foo") is skill


def test_get_returns_none_for_unknown(registry):
    assert registry.get("unknown") is None


def test_register_all(registry):
    skills = {
        "a": make_skill("a"),
        "b": make_skill("b"),
    }
    registry.register_all(skills)
    assert registry.get("a") is not None
    assert registry.get("b") is not None


def test_list_skills(populated):
    names = {s.name for s in populated.list_skills()}
    assert "greet" in names
    assert "deploy" in names


def test_list_skills_empty(registry):
    assert registry.list_skills() == []


# ---------------------------------------------------------------------------
# expand
# ---------------------------------------------------------------------------

def test_expand_substitutes_args(populated):
    result = populated.expand("greet", "world")
    assert "world" in result


def test_expand_no_args_placeholder(populated):
    result = populated.expand("deploy")
    assert result == "Deploy now"


def test_expand_raises_for_unknown_skill(registry):
    with pytest.raises(KeyError, match="not found"):
        registry.expand("missing")


def test_expand_raises_when_args_required_but_missing(populated):
    with pytest.raises(ValueError, match="requires arguments"):
        populated.expand("issue", "")


def test_expand_with_required_args(populated):
    result = populated.expand("issue", "bug #42")
    assert "bug #42" in result


# ---------------------------------------------------------------------------
# parse_skill_command
# ---------------------------------------------------------------------------

def test_parse_slash_format(populated):
    name, args = populated.parse_skill_command("/greet world")
    assert name == "greet"
    assert args == "world"


def test_parse_slash_no_args(populated):
    name, args = populated.parse_skill_command("/deploy")
    assert name == "deploy"
    assert args == ""


def test_parse_skill_colon_format(populated):
    name, args = populated.parse_skill_command("skill:greet")
    assert name == "greet"


def test_parse_skill_colon_with_parens(populated):
    name, args = populated.parse_skill_command("skill:greet(universe)")
    assert name == "greet"
    assert args == "universe"


def test_parse_unknown_slash_command(populated):
    name, args = populated.parse_skill_command("/unknown_skill")
    assert name is None
    assert args is None


def test_parse_plain_text_returns_none(populated):
    name, args = populated.parse_skill_command("just a normal message")
    assert name is None


# ---------------------------------------------------------------------------
# process_input
# ---------------------------------------------------------------------------

def test_process_input_expands_skill(populated):
    expanded, was_skill = populated.process_input("/greet Alice")
    assert was_skill is True
    assert "Alice" in expanded


def test_process_input_passes_through_non_skill(populated):
    text = "fix the bug in auth.py"
    expanded, was_skill = populated.process_input(text)
    assert was_skill is False
    assert expanded == text


# ---------------------------------------------------------------------------
# render_system_prompt_block
# ---------------------------------------------------------------------------

def test_render_empty_registry_returns_empty_string(registry):
    assert registry.render_system_prompt_block() == ""


def test_render_includes_skills_tag(populated):
    block = populated.render_system_prompt_block()
    assert "<skills>" in block
    assert "</skills>" in block


def test_render_includes_all_skill_names(populated):
    block = populated.render_system_prompt_block()
    assert "greet" in block
    assert "deploy" in block
    assert "issue" in block


def test_render_includes_guidelines_tag(populated):
    block = populated.render_system_prompt_block()
    assert "<skills_guidelines>" in block
    assert "</skills_guidelines>" in block


def test_render_uses_description(registry):
    skill = Skill(name="myskill", instructions="do stuff", description="My custom skill")
    registry.register(skill)
    block = registry.render_system_prompt_block()
    assert "My custom skill" in block


def test_render_fallback_description_when_empty(registry):
    skill = Skill(name="nodesc", instructions="do stuff", description="")
    registry.register(skill)
    block = registry.render_system_prompt_block()
    assert "nodesc" in block
    assert "(no description)" in block


def test_render_single_skill(registry):
    registry.register(make_skill("solo", "Do solo things"))
    block = registry.render_system_prompt_block()
    assert "solo" in block
    assert "<skills>" in block
