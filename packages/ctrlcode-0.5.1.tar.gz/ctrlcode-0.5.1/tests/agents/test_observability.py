"""Tests for agents/observability.py — parsers and ObservabilityTools."""

import pytest

from ctrlcode.agents.observability import (
    TestOutputParser,
    PerformanceParser,
    LogParser,
    ObservabilityTools,
    TestResult,
    PerformanceMetrics,
    LogAnalysis,
)


# ---------------------------------------------------------------------------
# TestOutputParser.parse_pytest
# ---------------------------------------------------------------------------

class TestPytestParser:
    def test_parses_all_passed(self):
        output = "===== 10 passed in 0.5s ====="
        result = TestOutputParser.parse_pytest(output)
        assert result.passed == 10
        assert result.failed == 0
        assert result.skipped == 0
        assert result.duration == 0.5
        assert result.status == "pass"

    def test_parses_passed_and_failed(self):
        output = "===== 8 passed, 2 failed in 1.0s ====="
        result = TestOutputParser.parse_pytest(output)
        assert result.passed == 8
        assert result.failed == 2
        assert result.status == "fail"

    def test_parses_passed_failed_skipped(self):
        output = "===== 5 passed, 1 failed, 3 skipped in 2.3s ====="
        result = TestOutputParser.parse_pytest(output)
        assert result.passed == 5
        assert result.failed == 1
        assert result.skipped == 3
        assert result.total == 9

    def test_fallback_on_no_match(self):
        result = TestOutputParser.parse_pytest("no recognizable output")
        assert result.total == 0
        assert result.passed == 0
        assert result.status == "pass"

    def test_parses_failure_details(self):
        output = (
            "FAILED tests/test_foo.py::test_bar - AssertionError: expected 1\n"
            "===== 0 passed, 1 failed in 0.1s ====="
        )
        result = TestOutputParser.parse_pytest(output)
        assert len(result.failures) == 1
        assert "test_foo" in result.failures[0]["test"]

    def test_status_pass_when_zero_failures(self):
        output = "===== 5 passed in 0.5s ====="
        result = TestOutputParser.parse_pytest(output)
        assert result.status == "pass"


class TestGenericParser:
    def test_counts_passed(self):
        output = "Test 1 PASSED\nTest 2 PASSED\nTest 3 FAILED"
        result = TestOutputParser.parse_generic(output)
        assert result.passed >= 2
        assert result.failed >= 1
        assert result.status == "fail"

    def test_all_pass(self):
        output = "All tests PASSED"
        result = TestOutputParser.parse_generic(output)
        assert result.status == "pass"

    def test_skipped(self):
        output = "Test SKIPPED\nTest PASSED"
        result = TestOutputParser.parse_generic(output)
        assert result.skipped >= 1

    def test_empty_output(self):
        result = TestOutputParser.parse_generic("")
        assert result.total == 0
        assert result.status == "pass"


# ---------------------------------------------------------------------------
# PerformanceParser.parse_wrk
# ---------------------------------------------------------------------------

class TestWrkParser:
    def test_parses_percentile_ms(self):
        output = "50%  145ms\n75%  200ms\n90%  500ms\n95%  800ms\n99%  1000ms\nRequests/sec: 100.5"
        metrics = PerformanceParser.parse_wrk(output)
        assert metrics.p50 == 145.0
        assert metrics.p99 == 1000.0
        assert metrics.throughput == 100.5

    def test_parses_percentile_seconds_converts_to_ms(self):
        output = "50%  1.5s\n"
        metrics = PerformanceParser.parse_wrk(output)
        assert metrics.p50 == 1500.0

    def test_empty_output_defaults_none(self):
        metrics = PerformanceParser.parse_wrk("")
        assert metrics.p50 is None
        assert metrics.throughput is None

    def test_partial_output(self):
        output = "Requests/sec: 55.0"
        metrics = PerformanceParser.parse_wrk(output)
        assert metrics.throughput == 55.0
        assert metrics.p99 is None


class TestAbParser:
    def test_parses_mean_latency(self):
        output = "Time per request:       145.0 [ms] (mean)"
        metrics = PerformanceParser.parse_ab(output)
        assert metrics.mean == 145.0

    def test_parses_throughput(self):
        output = "Requests per second:    6.90 [#/sec] (mean)"
        metrics = PerformanceParser.parse_ab(output)
        assert metrics.throughput == 6.90

    def test_parses_error_rate(self):
        output = "Complete requests:      100\nFailed requests:        5"
        metrics = PerformanceParser.parse_ab(output)
        assert metrics.error_rate == 5.0

    def test_zero_error_rate(self):
        output = "Complete requests:      100\nFailed requests:        0"
        metrics = PerformanceParser.parse_ab(output)
        assert metrics.error_rate == 0.0

    def test_empty_output(self):
        metrics = PerformanceParser.parse_ab("")
        assert metrics.mean is None
        assert metrics.throughput is None


# ---------------------------------------------------------------------------
# LogParser.parse_structured_logs
# ---------------------------------------------------------------------------

class TestLogParser:
    def test_detects_errors(self):
        output = "INFO: all good\nERROR: something failed\nINFO: done"
        result = LogParser.parse_structured_logs(output)
        assert result.error_count == 1
        assert result.health == "errors"

    def test_detects_warnings(self):
        output = "INFO: all good\nWARNING: something is odd"
        result = LogParser.parse_structured_logs(output)
        assert result.warning_count == 1
        assert result.health == "warnings"

    def test_healthy_no_issues(self):
        output = "INFO: started\nINFO: done"
        result = LogParser.parse_structured_logs(output)
        assert result.health == "healthy"

    def test_total_line_count(self):
        output = "line1\nline2\nline3"
        result = LogParser.parse_structured_logs(output)
        assert result.total_lines == 3

    def test_fatal_detected_as_error(self):
        output = "FATAL: crash"
        result = LogParser.parse_structured_logs(output)
        assert result.error_count >= 1

    def test_critical_detected_as_error(self):
        output = "CRITICAL: system failure"
        result = LogParser.parse_structured_logs(output)
        assert result.error_count >= 1


# ---------------------------------------------------------------------------
# ObservabilityTools — high-level API
# ---------------------------------------------------------------------------

class TestObservabilityTools:
    def setup_method(self):
        self.tools = ObservabilityTools()

    def test_analyze_test_output_pytest(self):
        output = "===== 5 passed in 0.5s ====="
        result = self.tools.analyze_test_output(output, framework="pytest")
        assert result["status"] == "pass"
        assert "summary" in result
        assert result["summary"]["passed"] == 5

    def test_analyze_test_output_generic_framework(self):
        output = "PASSED PASSED FAILED"
        result = self.tools.analyze_test_output(output, framework="jest")
        assert result["status"] == "fail"

    def test_analyze_test_output_has_recommendation(self):
        output = "===== 3 passed in 0.2s ====="
        result = self.tools.analyze_test_output(output)
        assert "recommendation" in result
        assert result["recommendation"] == "approve"

    def test_analyze_test_recommendation_few_failures(self):
        output = "===== 8 passed, 1 failed in 0.5s ====="
        result = self.tools.analyze_test_output(output)
        assert "investigate" in result["recommendation"]

    def test_analyze_test_recommendation_many_failures(self):
        output = "===== 3 passed, 5 failed in 0.5s ====="
        result = self.tools.analyze_test_output(output)
        assert "fix" in result["recommendation"]

    def test_analyze_performance_wrk(self):
        output = "50%  100ms\n99%  200ms\nRequests/sec: 50.0"
        result = self.tools.analyze_performance(output, tool="wrk")
        assert "metrics" in result
        assert result["metrics"]["p99"] == 200.0

    def test_analyze_performance_with_threshold_pass(self):
        output = "99%  200ms"
        result = self.tools.analyze_performance(output, tool="wrk", threshold_ms=300.0)
        assert result["status"] == "pass"

    def test_analyze_performance_with_threshold_warning(self):
        output = "99%  400ms"
        result = self.tools.analyze_performance(output, tool="wrk", threshold_ms=300.0)
        assert result["status"] == "warning"

    def test_analyze_performance_ab(self):
        output = "Time per request:       100.0 [ms] (mean)\nRequests per second:    10.0 [#/sec] (mean)"
        result = self.tools.analyze_performance(output, tool="ab")
        assert result["metrics"]["mean"] == 100.0

    def test_analyze_performance_unknown_tool(self):
        result = self.tools.analyze_performance("output", tool="unknown")
        assert result["status"] == "pass"

    def test_analyze_logs_healthy(self):
        output = "INFO: ok\nINFO: done"
        result = self.tools.analyze_logs(output)
        assert result["status"] == "pass"
        assert result["health"] == "healthy"

    def test_analyze_logs_with_errors(self):
        output = "ERROR: boom"
        result = self.tools.analyze_logs(output, max_errors=0)
        assert result["status"] == "fail"

    def test_analyze_logs_warnings(self):
        output = "WARNING: slow"
        result = self.tools.analyze_logs(output)
        assert result["status"] == "warning"

    def test_analyze_logs_recommendation_approve(self):
        result = self.tools.analyze_logs("INFO: all good")
        assert result["recommendation"] == "approve"

    def test_perf_recommendation_no_threshold(self):
        metrics = PerformanceMetrics(p99=500.0)
        rec = self.tools._perf_recommendation(metrics, threshold=None)
        assert "baseline" in rec

    def test_perf_recommendation_marginal(self):
        metrics = PerformanceMetrics(p99=305.0)
        rec = self.tools._perf_recommendation(metrics, threshold=300.0)
        assert "marginal" in rec
