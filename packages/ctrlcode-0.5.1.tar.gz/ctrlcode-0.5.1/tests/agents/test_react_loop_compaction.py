"""Tests for compact_conversation handling in AgentReActLoop."""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.agents.react_loop import AgentReActLoop, _format_tool_preview
from ctrlcode.providers.base import StreamEvent


# ---------------------------------------------------------------------------
# _format_tool_preview
# ---------------------------------------------------------------------------

def test_format_tool_preview_compact():
    assert _format_tool_preview("compact_conversation", {}) == "Compacting context…"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_provider(tool_name: str, tool_input: dict):
    """Provider that yields one tool call then end_turn."""
    events = [
        StreamEvent(type="tool_call_start", data={"tool": tool_name, "call_id": "call-1"}),
        StreamEvent(type="tool_call_delta", data={"delta": "{}"}),
        StreamEvent(type="content_block_stop", data={}),
        StreamEvent(type="finish", data={"reason": "tool_use"}),
    ]

    async def stream(messages, tools=None, **kwargs):
        for ev in events:
            yield ev

    provider = MagicMock()
    provider.stream = stream
    return provider


def _make_conv_manager():
    conv = MagicMock()
    conv.to_model_format.return_value = [{"role": "user", "content": "hello"}]
    conv.get_messages.return_value = []
    conv.add_message.return_value = None
    conv.needs_compaction.return_value = False
    return conv


def _make_tool_executor(result_value: dict):
    """Tool executor that returns a successful result."""
    from ctrlcode.tools.executor import ToolCallResult
    executor = MagicMock()
    executor.execute = AsyncMock(
        return_value=ToolCallResult(
            tool_name="compact_conversation",
            call_id="call-1",
            success=True,
            result=str(result_value),
        )
    )
    # classify_batch: each tool call gets its own serial group (safe default for tests)
    executor.classify_batch.side_effect = lambda calls: [[tc] for tc in calls]
    return executor


# ---------------------------------------------------------------------------
# agent_compaction event emitted, loop continues
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_agent_compaction_event_emitted():
    """compact_conversation emits agent_compaction and does NOT break the loop."""
    provider = _make_provider("compact_conversation", {})
    conv = _make_conv_manager()
    executor = _make_tool_executor({"success": True, "tokens_freed": 500})

    # Second iteration: provider yields end_turn so loop stops
    call_count = 0

    async def stream_with_end(messages, tools=None, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            # First call: tool call
            events = [
                StreamEvent(type="tool_call_start", data={"tool": "compact_conversation", "call_id": "call-1"}),
                StreamEvent(type="tool_call_delta", data={"delta": "{}"}),
                StreamEvent(type="content_block_stop", data={}),
                StreamEvent(type="finish", data={"reason": "tool_use"}),
            ]
        else:
            # Second call: end turn
            events = [
                StreamEvent(type="text", data={"text": "Done."}),
                StreamEvent(type="finish", data={"reason": "end_turn"}),
            ]
        for ev in events:
            yield ev

    provider.stream = stream_with_end

    loop_instance = AgentReActLoop()
    events = []
    async for ev in loop_instance.stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=executor,
        tools=[],
        max_continuations=5,
    ):
        events.append(ev)

    event_types = [e.type for e in events]
    assert "agent_compaction" in event_types, f"Expected agent_compaction in {event_types}"

    # Loop should NOT have stopped after compaction — it should continue
    assert "continuation_complete" in event_types


@pytest.mark.asyncio
async def test_agent_compaction_not_emitted_on_failure():
    """compact_conversation does NOT emit agent_compaction if tool fails."""
    from ctrlcode.tools.executor import ToolCallResult

    provider = _make_provider("compact_conversation", {})
    conv = _make_conv_manager()

    call_count = 0

    async def stream_with_end(messages, tools=None, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            events = [
                StreamEvent(type="tool_call_start", data={"tool": "compact_conversation", "call_id": "call-1"}),
                StreamEvent(type="tool_call_delta", data={"delta": "{}"}),
                StreamEvent(type="content_block_stop", data={}),
                StreamEvent(type="finish", data={"reason": "tool_use"}),
            ]
        else:
            events = [
                StreamEvent(type="text", data={"text": "Done."}),
                StreamEvent(type="finish", data={"reason": "end_turn"}),
            ]
        for ev in events:
            yield ev

    provider.stream = stream_with_end

    executor = MagicMock()
    executor.execute = AsyncMock(
        return_value=ToolCallResult(
            tool_name="compact_conversation",
            call_id="call-1",
            success=False,
            error="compaction failed",
        )
    )
    executor.classify_batch.side_effect = lambda calls: [[tc] for tc in calls]

    loop_instance = AgentReActLoop()
    events = []
    async for ev in loop_instance.stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=executor,
        tools=[],
        max_continuations=5,
    ):
        events.append(ev)

    event_types = [e.type for e in events]
    assert "agent_compaction" not in event_types
