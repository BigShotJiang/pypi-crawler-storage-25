"""Test to reproduce premature loop termination bug.

Bug: When model produces text without tool calls in a continuation iteration,
the loop breaks due to `if finish_reason == "end_turn" or not tool_calls:`
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.agents.react_loop import AgentReActLoop
from ctrlcode.providers.base import StreamEvent
from ctrlcode.tools.executor import ToolCallResult


def _make_conv_manager():
    """Create a mock conversation manager."""
    conv = MagicMock()
    conv.to_model_format.return_value = [{"role": "user", "content": "do a multi-step task"}]
    conv.get_messages.return_value = []
    conv.add_message.return_value = None
    conv.needs_compaction.return_value = False
    return conv


def _make_tool_executor():
    """Create a mock tool executor."""
    executor = MagicMock()
    executor.execute = AsyncMock(
        return_value=ToolCallResult(
            tool_name="read_file",
            call_id="call-1",
            success=True,
            result="file contents",
        )
    )
    executor.classify_batch.side_effect = lambda calls: [[tc] for tc in calls]
    return executor


@pytest.mark.asyncio
async def test_loop_continues_when_text_without_tools():
    """
    Reproduce the bug: Model calls tool in iter 1, then produces text without
    tool calls in iter 2 (e.g., reasoning), then calls another tool in iter 3.
    
    Expected: Loop should continue through all 3 iterations.
    Actual (bug): Loop breaks at iter 2 because `not tool_calls` is True.
    """
    conv = _make_conv_manager()
    executor = _make_tool_executor()
    
    call_count = 0
    
    async def streaming_provider(messages, tools=None, **kwargs):
        nonlocal call_count
        call_count += 1
        
        if call_count == 1:
            # Iteration 1: Call read_file
            events = [
                StreamEvent(type="text", data={"text": "Let me read the file first."}),
                StreamEvent(type="tool_call_start", data={"tool": "read_file", "call_id": "call-1"}),
                StreamEvent(type="tool_call_delta", data={"delta": '{"path": "file1.txt"}'}),
                StreamEvent(type="content_block_stop", data={}),
                StreamEvent(type="finish", data={"reason": "tool_use"}),
            ]
        elif call_count == 2:
            # Iteration 2: Just text, NO tool calls (reasoning/thinking)
            # This is where the bug triggers - loop breaks here!
            events = [
                StreamEvent(type="text", data={"text": "Now I understand file1. Let me also check file2."}),
                StreamEvent(type="finish", data={"reason": "tool_use"}),
            ]
        elif call_count == 3:
            # Iteration 3: Call read_file again (should reach here but doesn't due to bug)
            events = [
                StreamEvent(type="text", data={"text": "Reading file2 now."}),
                StreamEvent(type="tool_call_start", data={"tool": "read_file", "call_id": "call-2"}),
                StreamEvent(type="tool_call_delta", data={"delta": '{"path": "file2.txt"}'}),
                StreamEvent(type="content_block_stop", data={}),
                StreamEvent(type="finish", data={"reason": "tool_use"}),
            ]
        elif call_count == 4:
            # Iteration 4: Final summary with end_turn
            events = [
                StreamEvent(type="text", data={"text": "I've read both files. file1 contains X, file2 contains Y."}),
                StreamEvent(type="finish", data={"reason": "end_turn"}),
            ]
        
        for ev in events:
            yield ev
    
    provider = MagicMock()
    provider.stream = streaming_provider
    
    loop_instance = AgentReActLoop()
    events = []
    async for ev in loop_instance.stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=executor,
        tools=[],
        max_continuations=10,
    ):
        events.append(ev)
    
    # Check that we reached iteration 3 (the second tool call)
    tool_results = [e for e in events if e.type == "tool_result"]
    
    # BUG: This will fail - only 1 tool result instead of 2
    # because loop broke at iteration 2 when there was text but no tool calls
    print(f"Total provider calls: {call_count}")
    print(f"Tool results: {len(tool_results)}")
    print(f"Event types: {[e.type for e in events]}")
    
    # Should be 2 tool calls (file1 and file2)
    assert len(tool_results) == 2, f"Expected 2 tool results, got {len(tool_results)}. Loop terminated prematurely!"
    assert call_count >= 3, f"Expected provider to be called at least 3 times, got {call_count}"


if __name__ == "__main__":
    asyncio.run(test_loop_continues_when_text_without_tools())
    print("Test passed!")