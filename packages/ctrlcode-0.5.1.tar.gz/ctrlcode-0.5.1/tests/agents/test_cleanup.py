"""Tests for agents/cleanup.py — GoldenPrinciplesScanner, CodeSmellDetector, CleanupAgent."""

import pytest

from ctrlcode.agents.cleanup import (
    GoldenPrinciplesScanner,
    CodeSmellDetector,
    DocFreshnessChecker,
    CleanupAgent,
    CleanupMetrics,
    Violation,
)


# ---------------------------------------------------------------------------
# GoldenPrinciplesScanner — scan_principle
# ---------------------------------------------------------------------------

class TestGoldenPrinciplesScanner:
    def setup_method(self):
        self.scanner = GoldenPrinciplesScanner()

    def test_scan_detects_bare_except(self):
        code = "try:\n    risky()\nexcept:\n    pass\n"
        violations = self.scanner.scan_principle("no-bare-excepts", code, "test.py")
        assert len(violations) >= 1
        assert violations[0].principle == "no-bare-excepts"
        assert violations[0].file == "test.py"

    def test_scan_no_violation_with_specific_except(self):
        code = "try:\n    risky()\nexcept ValueError:\n    pass\n"
        violations = self.scanner.scan_principle("no-bare-excepts", code, "test.py")
        assert violations == []

    def test_scan_detects_print_statement(self):
        code = 'print("hello")\n'
        violations = self.scanner.scan_principle("no-print-statements", code, "test.py")
        assert len(violations) >= 1
        assert violations[0].severity == "medium"

    def test_scan_no_violation_no_print(self):
        code = "logger.info('hello')\n"
        violations = self.scanner.scan_principle("no-print-statements", code, "test.py")
        assert violations == []

    def test_scan_unknown_principle_returns_empty(self):
        violations = self.scanner.scan_principle("nonexistent-rule", "code", "test.py")
        assert violations == []

    def test_scan_violation_has_snippet(self):
        code = "line1\nline2\nexcept:\n    pass\nline5\n"
        violations = self.scanner.scan_principle("no-bare-excepts", code, "test.py")
        assert violations[0].snippet != ""

    def test_scan_violation_line_number_positive(self):
        code = "try:\n    x()\nexcept:\n    pass"
        violations = self.scanner.scan_principle("no-bare-excepts", code, "test.py")
        assert violations[0].line >= 1

    def test_get_fix_suggestion_known(self):
        sug = self.scanner._get_fix_suggestion("no-bare-excepts")
        assert "exception" in sug.lower()

    def test_get_fix_suggestion_unknown(self):
        sug = self.scanner._get_fix_suggestion("unknown-rule")
        assert sug == "Review and refactor"

    def test_is_auto_fixable_print_statements(self):
        assert self.scanner._is_auto_fixable("no-print-statements") is True

    def test_is_auto_fixable_bare_excepts(self):
        assert self.scanner._is_auto_fixable("no-bare-excepts") is False

    def test_scan_prefer_shared_utils_detects_custom_retry(self):
        code = "def retry_request():\n    pass\n"
        violations = self.scanner.scan_principle("prefer-shared-utils", code, "test.py")
        assert len(violations) >= 1


# ---------------------------------------------------------------------------
# CodeSmellDetector — detect_long_functions
# ---------------------------------------------------------------------------

class TestCodeSmellDetector:
    def setup_method(self):
        self.detector = CodeSmellDetector()

    def test_detects_long_function(self):
        # Create a function with 60 lines
        body = "\n".join(f"    x = {i}" for i in range(60))
        code = f"def long_func():\n{body}\n"
        issues = self.detector.detect_long_functions(code, "test.py", threshold=50)
        assert len(issues) >= 1
        assert issues[0]["function"] == "long_func"

    def test_no_long_function_short(self):
        code = "def short():\n    return 1\n"
        issues = self.detector.detect_long_functions(code, "test.py", threshold=50)
        assert issues == []

    def test_long_function_issue_has_required_fields(self):
        body = "\n".join(f"    x = {i}" for i in range(60))
        code = f"def big_func():\n{body}\n"
        issues = self.detector.detect_long_functions(code, "test.py", threshold=50)
        issue = issues[0]
        assert issue["type"] == "long_function"
        assert issue["file"] == "test.py"
        assert "lines" in issue
        assert "suggestion" in issue

    def test_no_violation_no_functions(self):
        code = "x = 1\ny = 2\n"
        issues = self.detector.detect_long_functions(code, "test.py")
        assert issues == []

    def test_detects_duplicate_imports(self):
        code = "import os\nimport os\n"
        issues = self.detector.detect_duplicated_imports(code, "test.py")
        assert len(issues) >= 1
        assert issues[0]["type"] == "duplicate_import"

    def test_no_duplicate_unique_imports(self):
        code = "import os\nimport sys\n"
        issues = self.detector.detect_duplicated_imports(code, "test.py")
        assert issues == []

    def test_duplicate_import_has_line_info(self):
        code = "import os\nimport os\n"
        issues = self.detector.detect_duplicated_imports(code, "test.py")
        assert issues[0]["line"] == 2
        assert issues[0]["previous_line"] == 1

    def test_duplicate_import_suggestion(self):
        code = "import os\nimport os\n"
        issues = self.detector.detect_duplicated_imports(code, "test.py")
        assert "Remove" in issues[0]["suggestion"]


# ---------------------------------------------------------------------------
# DocFreshnessChecker — check_markdown_links
# ---------------------------------------------------------------------------

class TestDocFreshnessChecker:
    def setup_method(self):
        self.checker = DocFreshnessChecker()

    def test_detects_internal_link(self):
        content = "[Guide](./guide.md)\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert len(issues) >= 1
        assert issues[0]["type"] == "internal_link"
        assert issues[0]["link"] == "./guide.md"

    def test_skips_http_links(self):
        content = "[External](https://example.com)\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert issues == []

    def test_skips_http_link(self):
        content = "[Example](http://example.com)\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert issues == []

    def test_skips_anchor_links(self):
        content = "[Section](#section-title)\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert issues == []

    def test_internal_link_has_text_and_line(self):
        content = "line1\n[My Guide](./my-guide.md)\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert issues[0]["text"] == "My Guide"
        assert issues[0]["line"] >= 1

    def test_no_links_returns_empty(self):
        content = "Just plain text with no links.\n"
        issues = self.checker.check_markdown_links(content, "README.md")
        assert issues == []


# ---------------------------------------------------------------------------
# CleanupAgent
# ---------------------------------------------------------------------------

class TestCleanupAgent:
    def setup_method(self):
        self.agent = CleanupAgent()

    def test_scan_golden_principles_finds_violations(self):
        files = [("bad.py", 'print("debug")\n')]
        violations = self.agent.scan_golden_principles(files)
        assert any(v.principle == "no-print-statements" for v in violations)

    def test_scan_golden_principles_specific_principle(self):
        files = [("bad.py", "except:\n    pass\nprint('x')\n")]
        violations = self.agent.scan_golden_principles(files, ["no-bare-excepts"])
        assert all(v.principle == "no-bare-excepts" for v in violations)

    def test_scan_golden_principles_clean_file(self):
        files = [("clean.py", "def foo():\n    return 1\n")]
        violations = self.agent.scan_golden_principles(files)
        assert violations == []

    def test_scan_code_smells_returns_dict(self):
        files = [("f.py", "import os\nimport os\n")]
        result = self.agent.scan_code_smells(files)
        assert "long_functions" in result
        assert "duplicate_imports" in result

    def test_scan_code_smells_detects_duplicates(self):
        files = [("f.py", "import os\nimport os\n")]
        result = self.agent.scan_code_smells(files)
        assert len(result["duplicate_imports"]) >= 1

    def test_scan_code_smells_empty_files(self):
        result = self.agent.scan_code_smells([])
        assert result["long_functions"] == []
        assert result["duplicate_imports"] == []

    def test_generate_metrics_totals(self):
        v1 = Violation("no-bare-excepts", "a.py", 1, "snippet", "high", "fix", False)
        v2 = Violation("no-print-statements", "b.py", 2, "snippet", "medium", "fix", True)
        metrics = self.agent.generate_metrics(
            violations=[v1, v2],
            code_smells={"long_functions": [{"x": 1}], "duplicate_imports": []},
            stale_docs=3,
        )
        assert isinstance(metrics, CleanupMetrics)
        assert metrics.total_issues == 2 + 1 + 3  # violations + smell + stale docs
        assert metrics.high_priority == 1
        assert metrics.auto_fixable == 1

    def test_generate_metrics_violations_by_principle(self):
        v1 = Violation("no-bare-excepts", "a.py", 1, "", "high", "", False)
        v2 = Violation("no-bare-excepts", "b.py", 2, "", "high", "", False)
        metrics = self.agent.generate_metrics([v1, v2], {"long_functions": [], "duplicate_imports": []}, 0)
        assert metrics.violations_by_principle["no-bare-excepts"] == 2

    def test_generate_metrics_empty(self):
        metrics = self.agent.generate_metrics([], {"long_functions": [], "duplicate_imports": []}, 0)
        assert metrics.total_issues == 0
        assert metrics.high_priority == 0
        assert metrics.auto_fixable == 0
