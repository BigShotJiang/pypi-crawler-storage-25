"""Tests for AgentResultParser — parse_planner_result, parse_coder_result, parse_reviewer_result, parse_executor_result."""

import json
import pytest

from ctrlcode.agents.result_parser import AgentResultParser, _extract_feedback_items


# ---------------------------------------------------------------------------
# parse_planner_result
# ---------------------------------------------------------------------------

def test_planner_task_write_direct():
    tool_calls = [{"tool": "task_write", "input": {"tasks": [{"id": "t1"}]}}]
    result = AgentResultParser.parse_planner_result("", tool_calls)
    assert "tasks" in result
    assert result["tasks"][0]["id"] == "t1"


def test_planner_task_write_json_content():
    graph = {"tasks": [], "parallel_groups": []}
    tool_calls = [{"tool": "task_write", "input": {"content": json.dumps(graph)}}]
    result = AgentResultParser.parse_planner_result("", tool_calls)
    assert "tasks" in result


def test_planner_task_write_invalid_json_falls_through():
    tool_calls = [{"tool": "task_write", "input": {"content": "not json"}}]
    result = AgentResultParser.parse_planner_result('{"tasks": []}', tool_calls)
    # Falls through to JSON text parsing
    assert "tasks" in result


def test_planner_json_code_block_in_text():
    graph = {"tasks": [{"id": "t1"}]}
    text = f"```json\n{json.dumps(graph)}\n```"
    result = AgentResultParser.parse_planner_result(text, [])
    assert result["tasks"][0]["id"] == "t1"


def test_planner_raw_json_in_text():
    graph = {"tasks": [], "done": True}
    result = AgentResultParser.parse_planner_result(json.dumps(graph), [])
    assert result["done"] is True


def test_planner_fallback_on_no_json():
    result = AgentResultParser.parse_planner_result("no json here", [])
    assert "error" in result
    assert result["tasks"] == []


# ---------------------------------------------------------------------------
# parse_coder_result
# ---------------------------------------------------------------------------

def test_coder_tracks_write_file():
    tool_calls = [
        {"tool": "write_file", "input": {"path": "src/foo.py"}},
    ]
    result = AgentResultParser.parse_coder_result("done", tool_calls)
    assert "src/foo.py" in result["files_written"]


def test_coder_tracks_edit_file():
    tool_calls = [{"tool": "edit_file", "input": {"path": "main.py"}}]
    result = AgentResultParser.parse_coder_result("done", tool_calls)
    assert "main.py" in result["files_edited"]


def test_coder_tracks_read_file():
    tool_calls = [{"tool": "read_file", "input": {"path": "config.py"}}]
    result = AgentResultParser.parse_coder_result("summary text", tool_calls)
    assert "config.py" in result["files_read"]


def test_coder_empty_tool_calls():
    result = AgentResultParser.parse_coder_result("nothing", [])
    assert result["files_written"] == []
    assert result["tool_count"] == 0


def test_coder_includes_summary():
    result = AgentResultParser.parse_coder_result("implemented feature", [])
    assert result["summary"] == "implemented feature"


# ---------------------------------------------------------------------------
# parse_reviewer_result
# ---------------------------------------------------------------------------

def test_reviewer_approved_via_task_update():
    tool_calls = [{"tool": "task_update", "input": {"status": "completed"}}]
    result = AgentResultParser.parse_reviewer_result("Looks good!", tool_calls)
    assert result["status"] == "approved"


def test_reviewer_changes_requested_via_task_update():
    tool_calls = [{"tool": "task_update", "input": {"status": "changes_requested"}}]
    result = AgentResultParser.parse_reviewer_result("Please fix x", tool_calls)
    assert result["status"] == "changes_requested"


def test_reviewer_approved_from_text():
    result = AgentResultParser.parse_reviewer_result("LGTM, looks good!", [])
    assert result["status"] == "approved"


def test_reviewer_changes_requested_from_text():
    result = AgentResultParser.parse_reviewer_result("Issues found, changes requested", [])
    assert result["status"] == "changes_requested"


def test_reviewer_inconclusive_default():
    result = AgentResultParser.parse_reviewer_result("I looked at this code", [])
    assert result["status"] == "inconclusive"


def test_reviewer_extracts_feedback_items():
    text = "Changes requested:\n- Fix the bug\n- Add tests"
    result = AgentResultParser.parse_reviewer_result(text, [])
    # With "changes requested" in text
    assert len(result["changes_required"]) == 2


# ---------------------------------------------------------------------------
# parse_executor_result
# ---------------------------------------------------------------------------

def test_executor_detects_test_command():
    tool_calls = [{"tool": "bash", "input": {"command": "pytest tests/"}}]
    result = AgentResultParser.parse_executor_result("all tests pass", tool_calls)
    assert result["validation_status"] == "passed"
    assert len(result["test_results"]) == 1


def test_executor_detects_failure():
    result = AgentResultParser.parse_executor_result("tests fail with error", [])
    assert result["validation_status"] == "failed"


def test_executor_inconclusive_default():
    result = AgentResultParser.parse_executor_result("done", [])
    assert result["validation_status"] == "inconclusive"


def test_executor_tracks_commands():
    tool_calls = [
        {"tool": "bash", "input": {"command": "ls"}},
        {"tool": "bash", "input": {"command": "pwd"}},
    ]
    result = AgentResultParser.parse_executor_result("ok", tool_calls)
    assert "ls" in result["commands_run"]
    assert "pwd" in result["commands_run"]


# ---------------------------------------------------------------------------
# _extract_feedback_items
# ---------------------------------------------------------------------------

def test_extract_bullet_items():
    items = _extract_feedback_items("- Fix this\n- Fix that")
    assert "Fix this" in items
    assert "Fix that" in items


def test_extract_numbered_items():
    items = _extract_feedback_items("1. First thing\n2. Second thing")
    assert "First thing" in items
    assert "Second thing" in items


def test_extract_star_bullets():
    items = _extract_feedback_items("* item one\n* item two")
    assert "item one" in items


def test_extract_empty_text():
    assert _extract_feedback_items("") == []
