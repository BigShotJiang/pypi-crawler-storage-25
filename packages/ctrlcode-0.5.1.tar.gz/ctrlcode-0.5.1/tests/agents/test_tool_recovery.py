"""Unit tests for dangling tool call recovery."""

import pytest
from harnessutils import Message, TextPart


def _raw_asst(text="ok", pending=None) -> Message:
    msg = Message(id="raw_asst", role="assistant")
    if text:
        msg.add_part(TextPart(text=text))
    if pending is not None:
        msg.metadata["pending_tool_calls"] = pending
    return msg


def _raw_user(text: str) -> Message:
    msg = Message(id="raw_user", role="user")
    msg.add_part(TextPart(text=text))
    return msg


def _wire_asst(text="ok") -> dict:
    return {"role": "assistant", "content": text}


def _wire_user(text: str) -> dict:
    return {"role": "user", "content": text}


def _wire_tool_result(tool: str, text="data") -> dict:
    return {"role": "user", "content": f"[Tool: {tool}]\nResult: {text}"}


# ---------------------------------------------------------------------------
# patch_tool_calls
# ---------------------------------------------------------------------------

from ctrlcode.agents.tool_recovery import patch_tool_calls, has_dangling_tool_calls, find_dangling_tool_calls


def test_no_dangling_unchanged():
    """No pending calls → wire list returned unchanged."""
    raw = [
        _raw_user("do X"),
        _raw_asst("ok", pending=[{"tool": "read_file", "call_id": "abc"}]),
        _raw_user("[Tool: read_file]\nResult: data"),
    ]
    wire = [
        _wire_user("do X"),
        _wire_asst("ok"),
        _wire_tool_result("read_file"),
    ]
    assert patch_tool_calls(wire, raw) == wire


def test_single_dangling_inserts_synthetic():
    raw = [
        _raw_user("do X"),
        _raw_asst("reading…", pending=[{"tool": "read_file", "call_id": "abc123"}]),
        _raw_user("continue"),
    ]
    wire = [
        _wire_user("do X"),
        _wire_asst("reading…"),
        _wire_user("continue"),
    ]
    patched = patch_tool_calls(wire, raw)
    assert len(patched) == 4
    synthetic = patched[2]
    assert synthetic["role"] == "user"
    assert "read_file" in synthetic["content"]
    assert "did not complete" in synthetic["content"]
    assert "abc123" in synthetic["content"]
    assert patched[3]["content"] == "continue"


def test_multiple_dangling_all_get_synthetic():
    pending = [
        {"tool": "read_file", "call_id": "id1"},
        {"tool": "write_file", "call_id": "id2"},
    ]
    raw = [
        _raw_asst("working", pending=pending),
        _raw_user("continue"),
    ]
    wire = [
        _wire_asst("working"),
        _wire_user("continue"),
    ]
    patched = patch_tool_calls(wire, raw)
    assert len(patched) == 4
    contents = [m["content"] for m in patched]
    assert any("read_file" in c and "did not complete" in c for c in contents)
    assert any("write_file" in c and "did not complete" in c for c in contents)


def test_no_pending_metadata_no_change():
    """Assistant message with no pending metadata → unchanged."""
    raw = [_raw_asst("ok"), _raw_user("hi")]
    wire = [_wire_asst("ok"), _wire_user("hi")]
    assert patch_tool_calls(wire, raw) == wire


def test_mixed_resolved_and_dangling():
    """One resolved, one dangling — only the dangling one gets a synthetic."""
    pending = [
        {"tool": "read_file", "call_id": "id1"},
        {"tool": "write_file", "call_id": "id2"},
    ]
    raw = [
        _raw_asst("working", pending=pending),
        _raw_user("[Tool: read_file]\nResult: data"),  # resolved
        _raw_user("continue"),                          # not a tool result
    ]
    wire = [
        _wire_asst("working"),
        _wire_tool_result("read_file"),
        _wire_user("continue"),
    ]
    patched = patch_tool_calls(wire, raw)
    assert len(patched) == 4
    synthetic_contents = [
        m["content"] for m in patched if "did not complete" in m.get("content", "")
    ]
    assert len(synthetic_contents) == 1
    assert "write_file" in synthetic_contents[0]


def test_mcp_tool_treated_same_as_builtin():
    raw = [
        _raw_asst("ok", pending=[{"tool": "mcp__server__tool_name", "call_id": "xyz"}]),
        _raw_user("next"),
    ]
    wire = [
        _wire_asst("ok"),
        _wire_user("next"),
    ]
    patched = patch_tool_calls(wire, raw)
    assert len(patched) == 3
    assert "mcp__server__tool_name" in patched[1]["content"]
    assert "did not complete" in patched[1]["content"]


def test_empty_messages_unchanged():
    assert patch_tool_calls([], []) == []


def test_no_assistant_messages_unchanged():
    raw = [_raw_user("hi"), _raw_user("there")]
    wire = [_wire_user("hi"), _wire_user("there")]
    assert patch_tool_calls(wire, raw) == wire


def test_silent_assistant_dangling():
    """Assistant with no text (no wire representation) — inject before next user message."""
    pending = [{"tool": "read_file", "call_id": "id1"}]
    silent_asst = Message(id="asst1", role="assistant")  # no parts
    silent_asst.metadata["pending_tool_calls"] = pending

    raw = [
        _raw_user("do X"),
        silent_asst,
        _raw_user("continue"),
    ]
    wire = [
        _wire_user("do X"),
        # no assistant wire message (it was silent)
        _wire_user("continue"),
    ]
    patched = patch_tool_calls(wire, raw)
    assert len(patched) == 3
    assert any("did not complete" in m.get("content", "") for m in patched)
    assert any("read_file" in m.get("content", "") for m in patched)


# ---------------------------------------------------------------------------
# find_dangling_tool_calls
# ---------------------------------------------------------------------------

def test_find_dangling_returns_unresolved():
    raw = [
        _raw_asst("ok", pending=[{"tool": "read_file", "call_id": "x"}]),
        _raw_user("continue"),
    ]
    result = find_dangling_tool_calls(raw)
    assert result == [{"tool": "read_file", "call_id": "x"}]


def test_find_dangling_empty_when_resolved():
    raw = [
        _raw_asst("ok", pending=[{"tool": "read_file", "call_id": "x"}]),
        _raw_user("[Tool: read_file]\nResult: data"),
    ]
    assert find_dangling_tool_calls(raw) == []


def test_find_dangling_multiple_calls():
    pending = [
        {"tool": "read_file", "call_id": "id1"},
        {"tool": "write_file", "call_id": "id2"},
    ]
    raw = [
        _raw_asst("ok", pending=pending),
        _raw_user("continue"),
    ]
    result = find_dangling_tool_calls(raw)
    assert len(result) == 2
    assert {"tool": "read_file", "call_id": "id1"} in result
    assert {"tool": "write_file", "call_id": "id2"} in result


def test_find_dangling_mixed_resolved():
    pending = [
        {"tool": "read_file", "call_id": "id1"},
        {"tool": "write_file", "call_id": "id2"},
    ]
    raw = [
        _raw_asst("ok", pending=pending),
        _raw_user("[Tool: read_file]\nResult: data"),
        _raw_user("continue"),
    ]
    result = find_dangling_tool_calls(raw)
    assert result == [{"tool": "write_file", "call_id": "id2"}]


def test_find_dangling_empty_history():
    assert find_dangling_tool_calls([]) == []


# ---------------------------------------------------------------------------
# has_dangling_tool_calls
# ---------------------------------------------------------------------------

def test_has_dangling_true():
    raw = [
        _raw_asst("ok", pending=[{"tool": "read_file", "call_id": "x"}]),
        _raw_user("continue"),
    ]
    assert has_dangling_tool_calls(raw) is True


def test_has_dangling_false_when_resolved():
    raw = [
        _raw_asst("ok", pending=[{"tool": "read_file", "call_id": "x"}]),
        _raw_user("[Tool: read_file]\nResult: data"),
    ]
    assert has_dangling_tool_calls(raw) is False


def test_has_dangling_false_no_pending():
    raw = [_raw_asst("ok"), _raw_user("hi")]
    assert has_dangling_tool_calls(raw) is False


# ---------------------------------------------------------------------------
# Integration test: simulate interrupted session via harnessutils
# ---------------------------------------------------------------------------

def test_simulate_interrupted_session():
    """Build a dangling conversation with harnessutils and verify patch fixes it."""
    from harnessutils import ConversationManager, MemoryStorage
    from harnessutils.config import HarnessConfig

    mgr = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())
    conv = mgr.create_conversation()
    cid = conv.id

    user_msg = Message(id="msg_001", role="user")
    user_msg.add_part(TextPart(text="please read config.py"))
    mgr.add_message(cid, user_msg)

    # Simulate crash: assistant message with pending call, but no tool result
    asst_msg = Message(id="msg_002", role="assistant")
    asst_msg.add_part(TextPart(text="I'll read that file for you."))
    asst_msg.metadata["pending_tool_calls"] = [
        {"tool": "read_file", "call_id": "toolu_xyz"}
    ]
    mgr.add_message(cid, asst_msg)

    raw = mgr.get_messages(cid)
    wire = mgr.to_model_format(cid)

    assert has_dangling_tool_calls(raw)

    patched = patch_tool_calls(wire, raw)
    assert any("did not complete" in m.get("content", "") for m in patched)
    assert any("read_file" in m.get("content", "") for m in patched)
    # user + assistant + synthetic
    assert len(patched) == 3
