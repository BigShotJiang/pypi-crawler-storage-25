"""Tests for MultiAgentWorkflow, WorkflowOrchestrator helpers."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.agents.workflow import MultiAgentWorkflow, TaskGraph, WorkflowOrchestrator


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_coordinator(spawn_return=None, parallel_return=None):
    coord = MagicMock()
    coord.bus = MagicMock()
    coord.spawn_agent = AsyncMock(return_value=spawn_return or {"agent_id": "ag-1", "status": "ok"})
    coord.spawn_agents_parallel = AsyncMock(
        return_value=parallel_return or [{"agent_id": "ag-2"}, {"agent_id": "ag-3"}]
    )
    return coord


def make_workflow(coordinator=None, event_callback=None, checkpoint_callback=None):
    coord = coordinator or make_coordinator()
    return MultiAgentWorkflow(coord, event_callback=event_callback, checkpoint_callback=checkpoint_callback)


def make_task_graph(tasks=None, parallel_groups=None):
    tasks = tasks or [{"id": "t1", "description": "do thing", "files": ["a.py"]}]
    parallel_groups = parallel_groups or [["t1"]]
    return TaskGraph(tasks=tasks, parallel_groups=parallel_groups, risks=[], checkpoints=[])


# ---------------------------------------------------------------------------
# _emit_event
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_emit_event_no_callback_is_noop():
    wf = make_workflow(event_callback=None)
    await wf._emit_event("some_event", {"key": "val"})  # must not raise


@pytest.mark.anyio
async def test_emit_event_calls_callback():
    events = []

    async def cb(event_type, data):
        events.append((event_type, data))

    wf = make_workflow(event_callback=cb)
    await wf._emit_event("test_event", {"x": 1})

    assert len(events) == 1
    assert events[0] == ("test_event", {"x": 1})


@pytest.mark.anyio
async def test_emit_event_swallows_callback_exception():
    async def bad_cb(event_type, data):
        raise RuntimeError("callback boom")

    wf = make_workflow(event_callback=bad_cb)
    await wf._emit_event("evt", {})  # must not raise


# ---------------------------------------------------------------------------
# _extract_changed_files
# ---------------------------------------------------------------------------

def test_extract_changed_files_collects_all_files():
    wf = make_workflow()
    tasks = [
        {"task": {"files": ["a.py", "b.py"]}},
        {"task": {"files": ["c.py"]}},
    ]
    files = wf._extract_changed_files(tasks)
    assert set(files) == {"a.py", "b.py", "c.py"}


def test_extract_changed_files_deduplicates():
    wf = make_workflow()
    tasks = [
        {"task": {"files": ["a.py"]}},
        {"task": {"files": ["a.py"]}},
    ]
    files = wf._extract_changed_files(tasks)
    assert files.count("a.py") == 1


def test_extract_changed_files_empty_tasks():
    wf = make_workflow()
    assert wf._extract_changed_files([]) == []


def test_extract_changed_files_task_without_files_key():
    wf = make_workflow()
    tasks = [{"task": {}}, {"other": "stuff"}]
    files = wf._extract_changed_files(tasks)
    assert files == []


# ---------------------------------------------------------------------------
# WorkflowOrchestrator._is_trivial_request
# ---------------------------------------------------------------------------

def make_orchestrator():
    orch = object.__new__(WorkflowOrchestrator)
    return orch


def test_is_trivial_fix_typo():
    orch = make_orchestrator()
    assert orch._is_trivial_request("fix typo in README") is True


def test_is_trivial_change_color():
    orch = make_orchestrator()
    assert orch._is_trivial_request("change color of button") is True


def test_is_trivial_update_readme():
    orch = make_orchestrator()
    assert orch._is_trivial_request("update readme with new section") is True


def test_is_trivial_add_comment():
    orch = make_orchestrator()
    assert orch._is_trivial_request("add comment to function") is True


def test_is_trivial_case_insensitive():
    orch = make_orchestrator()
    assert orch._is_trivial_request("FIX TYPO") is True


def test_is_not_trivial_complex_request():
    orch = make_orchestrator()
    assert orch._is_trivial_request("implement user authentication") is False


def test_is_not_trivial_empty_string():
    orch = make_orchestrator()
    assert orch._is_trivial_request("") is False


# ---------------------------------------------------------------------------
# MultiAgentWorkflow._planning_phase
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_planning_phase_returns_task_graph():
    coord = make_coordinator(spawn_return={
        "agent_id": "ag-1",
        "status": "ok",
        "task_graph": {
            "tasks": [{"id": "t1", "description": "task one"}],
            "parallel_groups": [["t1"]],
            "risks": [],
            "checkpoints": [],
        },
    })
    wf = make_workflow(coordinator=coord)
    graph = await wf._planning_phase("build a feature")
    assert len(graph.tasks) == 1
    assert graph.tasks[0]["id"] == "t1"


@pytest.mark.anyio
async def test_planning_phase_error_returns_empty_graph():
    coord = make_coordinator(spawn_return={"agent_id": "ag-1", "status": "error", "error": "boom"})
    wf = make_workflow(coordinator=coord)
    graph = await wf._planning_phase("something")
    assert graph.tasks == []
    assert graph.parallel_groups == []


# ---------------------------------------------------------------------------
# MultiAgentWorkflow._review_phase
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_review_phase_returns_approved():
    coord = make_coordinator(spawn_return={
        "agent_id": "ag-r",
        "status": "ok",
        "review": {"status": "approved", "feedback": "", "changes_required": []},
    })
    wf = make_workflow(coordinator=coord)
    result = await wf._review_phase([{"task": {}}])
    assert result["status"] == "approved"


@pytest.mark.anyio
async def test_review_phase_error_returns_inconclusive():
    coord = make_coordinator(spawn_return={"agent_id": "ag-r", "status": "error", "error": "oops"})
    wf = make_workflow(coordinator=coord)
    result = await wf._review_phase([])
    assert result["status"] == "inconclusive"
    assert "error" in result


# ---------------------------------------------------------------------------
# MultiAgentWorkflow._validation_phase
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_validation_phase_pass():
    coord = make_coordinator(spawn_return={
        "agent_id": "ag-v",
        "status": "ok",
        "validation": {"validation_status": "passed", "test_results": [], "output": "ok"},
    })
    wf = make_workflow(coordinator=coord)
    result = await wf._validation_phase([])
    assert result["status"] == "pass"


@pytest.mark.anyio
async def test_validation_phase_fail():
    coord = make_coordinator(spawn_return={
        "agent_id": "ag-v",
        "status": "ok",
        "validation": {"validation_status": "failed", "test_results": [], "output": ""},
    })
    wf = make_workflow(coordinator=coord)
    result = await wf._validation_phase([])
    assert result["status"] == "fail"


@pytest.mark.anyio
async def test_validation_phase_error_returns_fail():
    coord = make_coordinator(spawn_return={"agent_id": "ag-v", "status": "error", "error": "crash"})
    wf = make_workflow(coordinator=coord)
    result = await wf._validation_phase([])
    assert result["status"] == "fail"
    assert result["error"] == "crash"


# ---------------------------------------------------------------------------
# MultiAgentWorkflow.execute — top-level happy path
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_completes_successfully():
    def spawn_side_effect(**kwargs):
        agent_type = kwargs.get("agent_type")
        if agent_type == "planner":
            return {
                "agent_id": "ag-p",
                "status": "ok",
                "task_graph": {
                    "tasks": [{"id": "t1", "description": "do it", "files": []}],
                    "parallel_groups": [["t1"]],
                    "risks": [],
                    "checkpoints": [],
                },
            }
        elif agent_type == "reviewer":
            return {
                "agent_id": "ag-r",
                "status": "ok",
                "review": {"status": "approved", "feedback": "", "changes_required": []},
            }
        elif agent_type == "executor":
            return {
                "agent_id": "ag-v",
                "status": "ok",
                "validation": {"validation_status": "passed", "test_results": [], "output": ""},
            }
        return {"agent_id": "ag-x", "status": "ok"}

    coord = make_coordinator()
    coord.spawn_agent = AsyncMock(side_effect=lambda **kw: spawn_side_effect(**kw))

    wf = make_workflow(coordinator=coord)
    result = await wf.execute("build the feature")

    assert result["status"] == "completed"
    assert result["user_intent"] == "build the feature"
    assert len(result["errors"]) == 0


@pytest.mark.anyio
async def test_execute_sets_error_status_on_exception():
    coord = make_coordinator()
    coord.spawn_agent = AsyncMock(side_effect=RuntimeError("unexpected failure"))

    wf = make_workflow(coordinator=coord)
    result = await wf.execute("something")

    assert result["status"] == "error"
    assert len(result["errors"]) > 0
    assert "unexpected failure" in result["errors"][0]


# ---------------------------------------------------------------------------
# MultiAgentWorkflow._execution_phase — parallel group
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execution_phase_parallel_group():
    tasks = [
        {"id": "t1", "description": "task 1", "files": []},
        {"id": "t2", "description": "task 2", "files": []},
    ]
    graph = TaskGraph(
        tasks=tasks,
        parallel_groups=[["t1", "t2"]],
        risks=[],
        checkpoints=[],
    )
    coord = make_coordinator(
        parallel_return=[{"agent_id": "ag-1"}, {"agent_id": "ag-2"}]
    )
    wf = make_workflow(coordinator=coord)
    completed = await wf._execution_phase(graph)
    assert len(completed) == 2
    coord.spawn_agents_parallel.assert_called_once()


# ---------------------------------------------------------------------------
# MultiAgentWorkflow._execution_phase — checkpoint abort
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execution_phase_checkpoint_abort():
    tasks = [
        {"id": "t1", "description": "task 1", "files": []},
        {"id": "t2", "description": "task 2", "files": []},
    ]
    graph = TaskGraph(
        tasks=tasks,
        parallel_groups=[["t1"], ["t2"]],
        risks=[],
        checkpoints=[{"after_group": 0, "description": "check before t2"}],
    )

    async def checkpoint_cb(checkpoint_id):
        return False  # abort

    coord = make_coordinator()
    wf = make_workflow(coordinator=coord, checkpoint_callback=checkpoint_cb)
    completed = await wf._execution_phase(graph)

    # Only t1 should have run; t2 aborted by checkpoint
    assert len(completed) == 1
