"""Tests for react_loop pure functions and ReActResult dataclass."""

import pytest

from ctrlcode.agents.react_loop import (
    _gen_id,
    _safe_json,
    _format_tool_preview,
    ReActResult,
)


# ---------------------------------------------------------------------------
# _gen_id
# ---------------------------------------------------------------------------

def test_gen_id_starts_with_msg():
    assert _gen_id().startswith("msg_")


def test_gen_id_length():
    # "msg_" (4) + 12 hex chars = 16
    assert len(_gen_id()) == 16


def test_gen_id_is_unique():
    ids = {_gen_id() for _ in range(50)}
    assert len(ids) == 50


def test_gen_id_hex_suffix():
    suffix = _gen_id()[4:]
    assert all(c in "0123456789abcdef" for c in suffix)


# ---------------------------------------------------------------------------
# _safe_json
# ---------------------------------------------------------------------------

def test_safe_json_parses_valid():
    assert _safe_json('{"a": 1}') == {"a": 1}


def test_safe_json_returns_empty_on_invalid():
    assert _safe_json("not json") == {}


def test_safe_json_returns_empty_on_empty_string():
    assert _safe_json("") == {}


def test_safe_json_returns_empty_on_partial():
    assert _safe_json('{"key":') == {}


def test_safe_json_handles_nested():
    result = _safe_json('{"x": {"y": 2}}')
    assert result == {"x": {"y": 2}}


# ---------------------------------------------------------------------------
# _format_tool_preview — match branches
# ---------------------------------------------------------------------------

def test_format_read_file_with_path():
    result = _format_tool_preview("read_file", {"path": "/src/foo.py"})
    assert result == "Reading foo.py"


def test_format_get_file_info():
    result = _format_tool_preview("get_file_info", {"file_path": "/a/b/c.py"})
    assert result == "Reading c.py"


def test_format_write_file():
    result = _format_tool_preview("write_file", {"path": "/out/bar.py"})
    assert result == "Writing bar.py"


def test_format_update_file():
    result = _format_tool_preview("update_file", {"path": "/cfg/x.toml"})
    assert result == "Updating x.toml"


def test_format_list_directory_with_path():
    result = _format_tool_preview("list_directory", {"path": "/src"})
    assert result == "Listing src"


def test_format_list_directory_no_path():
    result = _format_tool_preview("list_directory", {})
    assert result == "Listing ."


def test_format_search_files():
    result = _format_tool_preview("search_files", {"pattern": "*.py"})
    assert result == "Searching '*.py'"


def test_format_search_code():
    result = _format_tool_preview("search_code", {"query": "def foo"})
    assert result == "Searching 'def foo'"


def test_format_search_truncates_long_pattern():
    long_pattern = "x" * 60
    result = _format_tool_preview("search_files", {"pattern": long_pattern})
    assert len(result) <= len("Searching '") + 40 + 1  # 40-char truncation + quote


def test_format_run_command():
    result = _format_tool_preview("run_command", {"command": "pytest"})
    assert result == "$ pytest"


def test_format_run_command_truncates():
    long_cmd = "a" * 100
    result = _format_tool_preview("run_command", {"command": long_cmd})
    assert len(result) <= 2 + 50  # "$ " + 50 chars


def test_format_fetch():
    result = _format_tool_preview("fetch", {"url": "https://example.com"})
    assert result == "Fetching https://example.com"


def test_format_unknown_tool_titlecased():
    result = _format_tool_preview("my_custom_tool", {})
    assert result == "My Custom Tool"


def test_format_no_path_returns_empty_string():
    result = _format_tool_preview("read_file", {})
    assert result == "Reading "


# ---------------------------------------------------------------------------
# ReActResult dataclass
# ---------------------------------------------------------------------------

def test_react_result_fields():
    r = ReActResult(
        assistant_text="hello",
        tool_calls=[{"tool": "read_file"}],
        usage_tokens=42,
        continuation_count=3,
    )
    assert r.assistant_text == "hello"
    assert r.tool_calls == [{"tool": "read_file"}]
    assert r.usage_tokens == 42
    assert r.continuation_count == 3


def test_react_result_empty():
    r = ReActResult(assistant_text="", tool_calls=[], usage_tokens=0, continuation_count=0)
    assert r.assistant_text == ""
    assert r.tool_calls == []


# ---------------------------------------------------------------------------
# AgentReActLoop.collect — static method
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_collect_assembles_text():
    from ctrlcode.agents.react_loop import AgentReActLoop
    from ctrlcode.providers.base import StreamEvent

    async def gen():
        yield StreamEvent(type="text", data={"text": "Hello "})
        yield StreamEvent(type="text", data={"text": "world"})
        yield StreamEvent(type="continuation_complete", data={"iterations": 2})

    result = await AgentReActLoop.collect(gen())
    assert result.assistant_text == "Hello world"
    assert result.continuation_count == 2


@pytest.mark.anyio
async def test_collect_gathers_tool_calls():
    from ctrlcode.agents.react_loop import AgentReActLoop
    from ctrlcode.providers.base import StreamEvent

    async def gen():
        yield StreamEvent(type="tool_result", data={"tool": "read_file", "success": True})
        yield StreamEvent(type="continuation_complete", data={"iterations": 1})

    result = await AgentReActLoop.collect(gen())
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["tool"] == "read_file"


@pytest.mark.anyio
async def test_collect_sums_usage():
    from ctrlcode.agents.react_loop import AgentReActLoop
    from ctrlcode.providers.base import StreamEvent

    async def gen():
        yield StreamEvent(type="usage", data={"usage": {"completion_tokens": 10}})
        yield StreamEvent(type="usage", data={"usage": {"completion_tokens": 5}})
        yield StreamEvent(type="continuation_complete", data={"iterations": 1})

    result = await AgentReActLoop.collect(gen())
    assert result.usage_tokens == 15


@pytest.mark.anyio
async def test_collect_empty_stream():
    from ctrlcode.agents.react_loop import AgentReActLoop

    async def gen():
        return
        yield  # make it an async generator

    result = await AgentReActLoop.collect(gen())
    assert result.assistant_text == ""
    assert result.tool_calls == []
    assert result.usage_tokens == 0
    assert result.continuation_count == 0
