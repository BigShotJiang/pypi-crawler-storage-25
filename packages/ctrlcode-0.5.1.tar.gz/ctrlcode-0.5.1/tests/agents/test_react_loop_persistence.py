"""Regression tests for assistant message persistence in AgentReActLoop.stream().

Bug: asst_msg was built each iteration but never added to conv_manager in the
tool-use path.  This caused the model to lose all context of its own prior
responses between iterations, leading it to re-introduce itself on every turn.

Fix: conv_manager.add_message(conv_id, asst_msg) is now called after
finish_reason == "tool_use" and before tool execution.

These tests ensure that regression cannot silently re-enter the codebase.
"""

import json
import pytest
from unittest.mock import AsyncMock, MagicMock

from harnessutils import Message, TextPart

from ctrlcode.agents.react_loop import AgentReActLoop
from ctrlcode.providers.base import StreamEvent
from ctrlcode.tools.executor import ToolCallResult


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _conv_manager():
    conv = MagicMock()
    conv.to_model_format.return_value = [{"role": "user", "content": "do the thing"}]
    conv.get_messages.return_value = []
    conv.add_message.return_value = None
    conv.needs_compaction.return_value = False
    return conv


def _executor(tool_name="read_file", result="contents"):
    ex = MagicMock()
    ex.execute = AsyncMock(
        return_value=ToolCallResult(
            tool_name=tool_name, call_id="call-1", success=True, result=result
        )
    )
    ex.classify_batch.side_effect = lambda calls: [[tc] for tc in calls]
    return ex


def _tool_use_events(text, tool_name, call_id="call-1"):
    """Events for one assistant turn: text + tool call + tool_use finish."""
    return [
        StreamEvent(type="text", data={"text": text}),
        StreamEvent(type="tool_call_start", data={"tool": tool_name, "call_id": call_id}),
        StreamEvent(type="tool_call_delta", data={"delta": json.dumps({"path": "/x"})}),
        StreamEvent(type="content_block_stop", data={}),
        StreamEvent(type="finish", data={"reason": "tool_use"}),
        StreamEvent(type="usage", data={"usage": {"completion_tokens": 20}}),
    ]


def _tool_only_events(tool_name, call_id="call-1"):
    """Events for a tool call with NO preceding text."""
    return [
        StreamEvent(type="tool_call_start", data={"tool": tool_name, "call_id": call_id}),
        StreamEvent(type="tool_call_delta", data={"delta": json.dumps({"path": "/x"})}),
        StreamEvent(type="content_block_stop", data={}),
        StreamEvent(type="finish", data={"reason": "tool_use"}),
        StreamEvent(type="usage", data={"usage": {"completion_tokens": 10}}),
    ]


def _end_turn_events(text):
    return [
        StreamEvent(type="text", data={"text": text}),
        StreamEvent(type="finish", data={"reason": "end_turn"}),
        StreamEvent(type="usage", data={"usage": {"completion_tokens": 10}}),
    ]


def _two_turn_provider(first_text, tool_name, final_text):
    """Provider: iter 0 → text + tool call; iter 1 → text + end_turn."""
    call_idx = 0

    async def stream(messages, tools=None, **kwargs):
        nonlocal call_idx
        call_idx += 1
        events = (
            _tool_use_events(first_text, tool_name)
            if call_idx == 1
            else _end_turn_events(final_text)
        )
        for ev in events:
            yield ev

    provider = MagicMock()
    provider.stream = stream
    return provider


def _added_messages(conv):
    """Return all Message objects passed to conv_manager.add_message."""
    return [c.args[1] for c in conv.add_message.call_args_list]


def _assistant_messages(conv):
    return [m for m in _added_messages(conv) if isinstance(m, Message) and m.role == "assistant"]


# ---------------------------------------------------------------------------
# Core regression: assistant message must be persisted after tool use
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_assistant_message_persisted_after_tool_use():
    """Regression: conv_manager.add_message must be called with an assistant
    message when the model calls a tool.  Without this the model loses all
    context of its previous responses and re-introduces itself every iteration.
    """
    conv = _conv_manager()
    provider = _two_turn_provider("I'll help you.", "read_file", "Done.")

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=_executor(),
        tools=[],
    ):
        pass

    msgs = _assistant_messages(conv)
    assert len(msgs) >= 1, (
        "No assistant message persisted — model will lose context between tool iterations"
    )


@pytest.mark.asyncio
async def test_assistant_message_contains_model_text():
    """The persisted assistant message must carry the text the model produced."""
    conv = _conv_manager()
    intro = "I'll analyse the git history now."
    provider = _two_turn_provider(intro, "read_file", "Done.")

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=_executor(),
        tools=[],
    ):
        pass

    msgs = _assistant_messages(conv)
    assert msgs, "Expected at least one assistant message"
    text_parts = [
        getattr(p, "text", "") for m in msgs for p in m.parts if isinstance(p, TextPart)
    ]
    assert any(intro in t for t in text_parts), (
        f"Assistant text '{intro}' not found in persisted message parts: {text_parts}"
    )


# ---------------------------------------------------------------------------
# Ordering: assistant message must come before the tool-result user message
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_assistant_message_saved_before_tool_result():
    """The assistant message must be persisted BEFORE the tool-result user
    message so that conversation history alternates correctly.
    """
    conv = _conv_manager()
    provider = _two_turn_provider("Let me read that.", "read_file", "Done.")

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=_executor(),
        tools=[],
    ):
        pass

    all_msgs = _added_messages(conv)
    roles = []
    for m in all_msgs:
        if isinstance(m, Message):
            roles.append(m.role)

    # Find first assistant message and the first tool-result user message
    asst_idx = next((i for i, r in enumerate(roles) if r == "assistant"), None)
    tool_result_idx = next(
        (
            i
            for i, m in enumerate(all_msgs)
            if isinstance(m, Message)
            and m.role == "user"
            and any("[Tool:" in getattr(p, "text", "") for p in m.parts)
        ),
        None,
    )

    assert asst_idx is not None, "No assistant message found in add_message calls"
    assert tool_result_idx is not None, "No tool-result user message found"
    assert asst_idx < tool_result_idx, (
        f"Assistant message (pos {asst_idx}) must come before tool result (pos {tool_result_idx})"
    )


# ---------------------------------------------------------------------------
# No empty assistant message when model produces no text
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_no_assistant_message_when_model_produces_no_text():
    """When the model emits tool calls with no preceding text, no empty
    assistant message should be saved (prevents malformed conversation history).
    """
    call_idx = 0

    async def stream(messages, tools=None, **kwargs):
        nonlocal call_idx
        call_idx += 1
        events = (
            _tool_only_events("read_file") if call_idx == 1 else _end_turn_events("All done.")
        )
        for ev in events:
            yield ev

    provider = MagicMock()
    provider.stream = stream
    conv = _conv_manager()

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=_executor(),
        tools=[],
    ):
        pass

    msgs = _assistant_messages(conv)
    # Any persisted assistant messages must have at least one non-empty text part
    for m in msgs:
        text = "".join(getattr(p, "text", "") for p in m.parts if isinstance(p, TextPart))
        assert text.strip(), f"Empty assistant message was persisted: {m}"


# ---------------------------------------------------------------------------
# Multi-iteration: every tool-use turn persists its assistant message
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_each_tool_use_iteration_persists_assistant_message():
    """Each iteration that calls a tool must save its own assistant message,
    so the full conversation chain is preserved across N continuations.
    """
    call_idx = 0
    tool_iterations = 3

    async def stream(messages, tools=None, **kwargs):
        nonlocal call_idx
        call_idx += 1
        if call_idx <= tool_iterations:
            for ev in _tool_use_events(f"Step {call_idx}.", "read_file", f"call-{call_idx}"):
                yield ev
        else:
            for ev in _end_turn_events("All done."):
                yield ev

    provider = MagicMock()
    provider.stream = stream
    conv = _conv_manager()
    ex = MagicMock()
    ex.execute = AsyncMock(
        side_effect=[
            ToolCallResult(
                tool_name="read_file", call_id=f"call-{i}", success=True, result="ok"
            )
            for i in range(1, tool_iterations + 1)
        ]
    )
    ex.classify_batch.side_effect = lambda calls: [[tc] for tc in calls]

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=ex,
        tools=[],
        max_continuations=10,
    ):
        pass

    msgs = _assistant_messages(conv)
    assert len(msgs) == tool_iterations, (
        f"Expected {tool_iterations} assistant messages (one per tool iteration), "
        f"got {len(msgs)}"
    )


# ---------------------------------------------------------------------------
# Conversation alternation invariant
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_no_consecutive_user_messages_in_persisted_history():
    """After a multi-turn loop, the sequence of persisted messages must never
    have two consecutive user-role messages.  Consecutive user messages are
    invalid for most LLM providers and indicate a missing assistant message.
    """
    call_idx = 0

    async def stream(messages, tools=None, **kwargs):
        nonlocal call_idx
        call_idx += 1
        events = (
            _tool_use_events("Working on it.", "read_file")
            if call_idx == 1
            else _end_turn_events("Done.")
        )
        for ev in events:
            yield ev

    provider = MagicMock()
    provider.stream = stream
    conv = _conv_manager()

    async for _ in AgentReActLoop().stream(
        provider=provider,
        conv_manager=conv,
        conv_id="conv-1",
        tool_executor=_executor(),
        tools=[],
    ):
        pass

    # The initial user message is already in conv before the loop starts;
    # we check only the messages added during the loop.
    added = _added_messages(conv)
    roles = [m.role for m in added if isinstance(m, Message)]

    for i in range(len(roles) - 1):
        assert not (roles[i] == "user" and roles[i + 1] == "user"), (
            f"Consecutive user messages at positions {i},{i+1} in {roles}"
        )
