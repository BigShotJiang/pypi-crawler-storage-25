"""Tests for TaskGraph — get_task, get_parallel_group."""

import pytest

from ctrlcode.agents.workflow import TaskGraph


@pytest.fixture
def graph():
    return TaskGraph(
        tasks=[
            {"id": "t1", "name": "first"},
            {"id": "t2", "name": "second"},
        ],
        parallel_groups=[["t1"], ["t2", "t3"]],
        risks=["risk1"],
        checkpoints=[{"id": "cp1"}],
    )


# ---------------------------------------------------------------------------
# get_task
# ---------------------------------------------------------------------------

def test_get_task_returns_task(graph):
    task = graph.get_task("t1")
    assert task is not None
    assert task["name"] == "first"


def test_get_task_returns_none_for_unknown(graph):
    assert graph.get_task("unknown") is None


def test_get_task_second_item(graph):
    task = graph.get_task("t2")
    assert task["name"] == "second"


# ---------------------------------------------------------------------------
# get_parallel_group
# ---------------------------------------------------------------------------

def test_get_parallel_group_first(graph):
    group = graph.get_parallel_group(0)
    assert group == ["t1"]


def test_get_parallel_group_second(graph):
    group = graph.get_parallel_group(1)
    assert group == ["t2", "t3"]


def test_get_parallel_group_out_of_bounds_returns_empty(graph):
    assert graph.get_parallel_group(99) == []


def test_get_parallel_group_negative_returns_empty(graph):
    assert graph.get_parallel_group(-1) == []
