"""Tests for compact_conversation tool (setup_context_tools)."""

import pytest
from unittest.mock import AsyncMock, MagicMock, call, patch
from pathlib import Path

from ctrlcode.tools import setup_context_tools
from ctrlcode.tools.registry import ToolRegistry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_COMPACT_RESULT = {
    "tokens_saved": 1200,
    "new_conv_id": "new-conv-id",
    "summary_text": "Work done so far: fixed the auth bug.",
    "messages_compacted": 4,
}


def _make_mock_session(conv_id="conv-1", session_id="sess-1"):
    session = MagicMock()
    session.id = session_id
    session.conv_id = conv_id
    session.provider = MagicMock()
    session.provider.model = "claude-sonnet-4-6"
    return session


def _make_conv_manager(n_messages: int):
    conv = MagicMock()
    messages = []
    for i in range(n_messages):
        msg = MagicMock()
        msg.role = "user" if i % 2 == 0 else "assistant"
        msg.parts = [MagicMock(text=f"message content {i}")]
        messages.append(msg)
    conv.get_messages.return_value = messages
    conv.to_model_format.return_value = [
        {"role": "user" if i % 2 == 0 else "assistant", "content": f"content {i}"}
        for i in range(n_messages)
    ]
    conv.calculate_context_usage.return_value = 5000
    conv.create_conversation.return_value = MagicMock(id="new-conv-id")
    return conv


def _make_session_manager(conv_manager, session, ctrlcode_dir, *, with_writer=False):
    sm = MagicMock()
    sm.get_session.return_value = session
    sm.conv_manager = conv_manager
    sm._ctrlcode_dir = ctrlcode_dir
    sm._ctx_monitors = {}
    if with_writer:
        mock_backend = MagicMock()
        mock_backend.search_artifacts = AsyncMock(return_value=[])
        mock_backend.add_artifact = AsyncMock()
        mock_backend.update_artifact = AsyncMock()
        mock_writer = MagicMock()
        mock_writer._backend = mock_backend
        sm._memory_mw = MagicMock()
        sm._memory_mw._writers = {session.id: mock_writer}
    else:
        sm._memory_mw = None
    return sm


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def test_registers_compact_conversation():
    registry = ToolRegistry()
    sm = MagicMock()
    setup_context_tools(registry, sm, "sess-1")
    assert "compact_conversation" in registry.builtin_tools


def test_re_registers_for_new_session():
    """Each call updates the closure — multiagent safety."""
    registry = ToolRegistry()
    setup_context_tools(registry, MagicMock(), "sess-1")
    setup_context_tools(registry, MagicMock(), "sess-2")
    assert "compact_conversation" in registry.builtin_tools


# ---------------------------------------------------------------------------
# Early return — session not found
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_returns_early_for_missing_session():
    registry = ToolRegistry()
    sm = MagicMock()
    sm.get_session.return_value = None
    sm._memory_mw = None
    setup_context_tools(registry, sm, "sess-missing")

    fn = registry.builtin_tools["compact_conversation"].function
    result = await fn(reason="test")

    assert result["success"] is False
    assert "session not found" in result["error"]


# ---------------------------------------------------------------------------
# Return format
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_return_format(tmp_path):
    """Result has compacted, tokens_freed, summary_preview keys."""
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session()
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode")

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value=_COMPACT_RESULT,
    ):
        result = await fn(reason="phase done")

    assert result["success"] is True
    assert result["compacted"] == 4
    assert result["tokens_freed"] == 1200
    assert result["summary_preview"] == "Work done so far: fixed the auth bug."


# ---------------------------------------------------------------------------
# conv_id update
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_updates_session_conv_id_on_new_conv(tmp_path):
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session(conv_id="old-conv")
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode")

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value={**_COMPACT_RESULT, "new_conv_id": "new-conv"},
    ):
        await fn()

    assert session.conv_id == "new-conv"


@pytest.mark.asyncio
async def test_conv_id_unchanged_when_not_new(tmp_path):
    conv_manager = _make_conv_manager(8)
    session = _make_mock_session(conv_id="same-conv")
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode")

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value={**_COMPACT_RESULT, "new_conv_id": "same-conv"},
    ):
        await fn()

    assert session.conv_id == "same-conv"


# ---------------------------------------------------------------------------
# keep_last=6 passed to summarize_and_compact
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_passes_keep_last_6(tmp_path):
    """Agent-triggered compaction preserves the last 6 messages."""
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session()
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode")

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value=_COMPACT_RESULT,
    ) as mock_compact:
        await fn(reason="done")

    _, kwargs = mock_compact.call_args
    assert kwargs.get("keep_last") == 6


# ---------------------------------------------------------------------------
# Rootset artifact — add on first compaction
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_writes_rootset_artifact_on_first_compaction(tmp_path):
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session()
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode", with_writer=True)

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value=_COMPACT_RESULT,
    ):
        await fn(reason="phase complete")

    backend = sm._memory_mw._writers[session.id]._backend
    backend.add_artifact.assert_called_once()
    call_kwargs = backend.add_artifact.call_args
    assert call_kwargs.kwargs["kind"] == "session:summary"
    assert call_kwargs.kwargs["metadata"]["trigger"] == "agent_triggered"
    assert call_kwargs.kwargs["metadata"]["compaction_count"] == 1
    assert call_kwargs.kwargs["metadata"]["reason"] == "phase complete"


# ---------------------------------------------------------------------------
# Rootset artifact — upsert on subsequent compaction
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_updates_rootset_artifact_on_subsequent_compaction(tmp_path):
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session()
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode", with_writer=True)

    # Seed an existing session:summary artifact
    existing_art = MagicMock()
    existing_art.id = 42
    existing_art.metadata = {"compaction_count": 2}
    existing_result = MagicMock()
    existing_result.artifact = existing_art
    sm._memory_mw._writers[session.id]._backend.search_artifacts = AsyncMock(
        return_value=[existing_result]
    )

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value=_COMPACT_RESULT,
    ):
        await fn()

    backend = sm._memory_mw._writers[session.id]._backend
    backend.update_artifact.assert_called_once()
    update_kwargs = backend.update_artifact.call_args
    assert update_kwargs.args[0] == 42  # artifact id
    assert update_kwargs.kwargs["metadata"]["compaction_count"] == 3


# ---------------------------------------------------------------------------
# Rootset artifact — non-fatal if backend fails
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_rootset_write_failure_is_nonfatal(tmp_path):
    conv_manager = _make_conv_manager(10)
    session = _make_mock_session()
    sm = _make_session_manager(conv_manager, session, tmp_path / ".ctrlcode", with_writer=True)
    sm._memory_mw._writers[session.id]._backend.add_artifact = AsyncMock(
        side_effect=RuntimeError("db error")
    )

    registry = ToolRegistry()
    setup_context_tools(registry, sm, "sess-1")
    fn = registry.builtin_tools["compact_conversation"].function

    with patch(
        "ctrlcode.memory.context_window_monitor.ContextWindowMonitor.summarize_and_compact",
        new_callable=AsyncMock,
        return_value=_COMPACT_RESULT,
    ):
        result = await fn()  # must not raise

    assert result["success"] is True
