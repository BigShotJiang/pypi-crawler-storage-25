"""Tests for signal tools — context tool schemas."""

from ctrlcode.tools.signal import CONTEXT_TOOL_SCHEMAS


def test_context_tool_schemas_nonempty():
    assert len(CONTEXT_TOOL_SCHEMAS) >= 1


def test_context_schema_has_compact_conversation():
    names = [s["name"] for s in CONTEXT_TOOL_SCHEMAS]
    assert "compact_conversation" in names


def test_compact_conversation_schema_valid():
    schema = next(s for s in CONTEXT_TOOL_SCHEMAS if s["name"] == "compact_conversation")
    assert "description" in schema
    assert "input_schema" in schema
    assert schema["input_schema"]["type"] == "object"
