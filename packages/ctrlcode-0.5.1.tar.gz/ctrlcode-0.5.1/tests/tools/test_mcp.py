"""Tests for MCPClient and MCPTool."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.tools.mcp import MCPClient, MCPTool


def make_config(name="test-server", command=None, env=None):
    return {
        "name": name,
        "command": command or ["npx", "-y", "some-server"],
        "env": env,
    }


# ---------------------------------------------------------------------------
# MCPTool dataclass
# ---------------------------------------------------------------------------

def test_mcptool_fields():
    tool = MCPTool(
        name="do_thing",
        description="does a thing",
        input_schema={"type": "object"},
        server_name="srv",
    )
    assert tool.name == "do_thing"
    assert tool.description == "does a thing"
    assert tool.input_schema == {"type": "object"}
    assert tool.server_name == "srv"


# ---------------------------------------------------------------------------
# MCPClient.__init__
# ---------------------------------------------------------------------------

def test_mcpclient_server_name_from_config():
    client = MCPClient(make_config(name="my-server"))
    assert client.server_name == "my-server"


def test_mcpclient_default_server_name():
    client = MCPClient({"command": ["cmd"]})
    assert client.server_name == "unknown"


def test_mcpclient_initial_state_is_none():
    client = MCPClient(make_config())
    assert client.session is None
    assert client._exit_stack is None


def test_mcpclient_server_params_splits_command():
    client = MCPClient(make_config(command=["npx", "-y", "server"]))
    assert client.server_params.command == "npx"
    assert client.server_params.args == ["-y", "server"]


def test_mcpclient_env_forwarded():
    client = MCPClient(make_config(env={"FOO": "bar"}))
    assert client.server_params.env == {"FOO": "bar"}


# ---------------------------------------------------------------------------
# call_tool — no session
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_call_tool_raises_without_session():
    client = MCPClient(make_config())
    with pytest.raises(RuntimeError, match="not initialized"):
        await client.call_tool("my_tool", {})


# ---------------------------------------------------------------------------
# list_tools — no session
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_list_tools_raises_without_session():
    client = MCPClient(make_config())
    with pytest.raises(RuntimeError, match="not initialized"):
        await client.list_tools()


# ---------------------------------------------------------------------------
# stop
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_stop_is_safe_when_not_started():
    client = MCPClient(make_config())
    await client.stop()  # must not raise
    assert client.session is None
    assert client._exit_stack is None


@pytest.mark.anyio
async def test_stop_closes_exit_stack_and_clears_state():
    client = MCPClient(make_config())
    mock_stack = AsyncMock()
    client._exit_stack = mock_stack
    client.session = MagicMock()

    await client.stop()

    mock_stack.aclose.assert_called_once()
    assert client.session is None
    assert client._exit_stack is None


# ---------------------------------------------------------------------------
# context manager
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_context_manager_calls_start_and_stop():
    client = MCPClient(make_config())
    client.start = AsyncMock()
    client.stop = AsyncMock()

    async with client as c:
        assert c is client
        client.start.assert_called_once()

    client.stop.assert_called_once()


# ---------------------------------------------------------------------------
# list_tools — with mocked session
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_list_tools_returns_mcp_tools():
    client = MCPClient(make_config(name="srv"))

    mock_tool = MagicMock()
    mock_tool.name = "do_thing"
    mock_tool.description = "does a thing"
    mock_tool.inputSchema = {"type": "object", "properties": {}}

    mock_session = AsyncMock()
    mock_session.list_tools = AsyncMock(return_value=MagicMock(tools=[mock_tool]))
    client.session = mock_session

    tools = await client.list_tools()

    assert len(tools) == 1
    assert tools[0].name == "do_thing"
    assert tools[0].server_name == "srv"
    assert tools[0].description == "does a thing"


@pytest.mark.anyio
async def test_list_tools_empty_list():
    client = MCPClient(make_config())
    mock_session = AsyncMock()
    mock_session.list_tools = AsyncMock(return_value=MagicMock(tools=[]))
    client.session = mock_session

    tools = await client.list_tools()
    assert tools == []


# ---------------------------------------------------------------------------
# call_tool — with mocked session
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_call_tool_returns_content():
    client = MCPClient(make_config())
    mock_result = MagicMock()
    mock_result.content = [{"type": "text", "text": "result"}]

    mock_session = AsyncMock()
    mock_session.call_tool = AsyncMock(return_value=mock_result)
    client.session = mock_session

    result = await client.call_tool("my_tool", {"arg": "val"})

    mock_session.call_tool.assert_called_once_with("my_tool", {"arg": "val"})
    assert result == mock_result.content


@pytest.mark.anyio
async def test_call_tool_passes_empty_args():
    client = MCPClient(make_config())
    mock_result = MagicMock()
    mock_result.content = []
    mock_session = AsyncMock()
    mock_session.call_tool = AsyncMock(return_value=mock_result)
    client.session = mock_session

    result = await client.call_tool("tool", {})
    mock_session.call_tool.assert_called_once_with("tool", {})
