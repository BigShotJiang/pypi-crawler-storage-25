"""Tests for tools/__init__.py — setup_* registration functions."""

import pytest
from pathlib import Path

from ctrlcode.tools import (
    setup_bash_tools,
    setup_explore_tools,
    setup_todo_tools,
    setup_update_tools,
    setup_webfetch_tools,
)
from ctrlcode.tools.registry import ToolRegistry


@pytest.fixture
def registry():
    return ToolRegistry()


def test_setup_explore_tools_registers_tools(registry, tmp_path):
    setup_explore_tools(registry, tmp_path)
    names = [t.name for t in registry.list_tools()]
    assert "search_files" in names
    assert "read_file" in names
    assert "list_directory" in names
    assert "write_file" in names


def test_setup_bash_tools_registers_run_command(registry, tmp_path):
    setup_bash_tools(registry, tmp_path)
    names = [t.name for t in registry.list_tools()]
    assert "run_command" in names


def test_setup_webfetch_tools_registers_fetch(registry):
    setup_webfetch_tools(registry)
    names = [t.name for t in registry.list_tools()]
    assert any("fetch" in n for n in names)


def test_setup_update_tools_registers_update_file(registry, tmp_path):
    setup_update_tools(registry, tmp_path)
    names = [t.name for t in registry.list_tools()]
    assert "update_file" in names


def test_setup_todo_tools_registers_todo_write(registry, tmp_path):
    setup_todo_tools(registry, tmp_path, workspace_root=tmp_path)
    names = [t.name for t in registry.list_tools()]
    assert "todo_write" in names


def test_setup_todo_tools_registers_task_aliases(registry, tmp_path):
    setup_todo_tools(registry, tmp_path)
    names = [t.name for t in registry.list_tools()]
    # task_write is an alias for todo_write
    assert "task_write" in names


def test_setup_all_tools_no_duplicates(registry, tmp_path):
    setup_explore_tools(registry, tmp_path)
    setup_bash_tools(registry, tmp_path)
    setup_webfetch_tools(registry)
    setup_update_tools(registry, tmp_path)
    names = [t.name for t in registry.list_tools()]
    assert len(names) == len(set(names))
