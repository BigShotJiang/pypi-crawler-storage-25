"""Tests for ToolExecutor — execute, execute_batch."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.tools.executor import ToolCallResult, ToolExecutor
from ctrlcode.tools.registry import BuiltinTool, ToolRegistry
from ctrlcode.permissions import PermissionManager, PermissionResponse


def _make_builtin_registry(name: str, fn, schema: dict | None = None, required: list | None = None):
    r = ToolRegistry()
    r.register_builtin(
        name=name,
        description="test",
        input_schema={"type": "object", "properties": {}, "required": required or []},
        function=fn,
    )
    if schema:
        r.builtin_tools[name].input_schema = schema
    return r


# ---------------------------------------------------------------------------
# execute — tool not found
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_tool_not_found():
    r = ToolRegistry()
    ex = ToolExecutor(r)
    result = await ex.execute("nonexistent", {}, "c1")
    assert result.success is False
    assert "not found" in result.error


# ---------------------------------------------------------------------------
# execute — built-in sync
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_builtin_sync_success():
    def greet(name):
        return {"message": f"hello {name}"}

    r = _make_builtin_registry("greet", greet)
    ex = ToolExecutor(r)
    result = await ex.execute("greet", {"name": "world"}, "c1")
    assert result.success is True
    assert result.result["message"] == "hello world"


@pytest.mark.anyio
async def test_execute_builtin_async_success():
    async def async_tool(x):
        return {"value": x * 2}

    r = _make_builtin_registry("double", async_tool)
    ex = ToolExecutor(r)
    result = await ex.execute("double", {"x": 5}, "c2")
    assert result.success is True
    assert result.result["value"] == 10


@pytest.mark.anyio
async def test_execute_builtin_returns_error_dict():
    def bad_tool():
        return {"error": "something went wrong"}

    r = _make_builtin_registry("bad", bad_tool)
    ex = ToolExecutor(r)
    result = await ex.execute("bad", {}, "c3")
    assert result.success is False
    assert "something went wrong" in result.error


@pytest.mark.anyio
async def test_execute_builtin_missing_required_param():
    def greet(name):
        return {"ok": True}

    r = ToolRegistry()
    r.register_builtin(
        "greet", "test",
        {"type": "object", "required": ["name"], "properties": {}},
        greet,
    )
    ex = ToolExecutor(r)
    result = await ex.execute("greet", {}, "c4")
    assert result.success is False
    assert "name" in result.error


@pytest.mark.anyio
async def test_execute_builtin_exception_returns_failure():
    def broken():
        raise ValueError("kaboom")

    r = _make_builtin_registry("broken", broken)
    ex = ToolExecutor(r)
    result = await ex.execute("broken", {}, "c5")
    assert result.success is False
    assert "kaboom" in result.error


# ---------------------------------------------------------------------------
# execute_batch
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_batch_returns_results():
    def fn(**kwargs):
        return {"ok": True}

    r = _make_builtin_registry("tool", fn)
    ex = ToolExecutor(r)
    calls = [
        {"name": "tool", "arguments": {}, "call_id": "c1"},
        {"name": "tool", "arguments": {}, "call_id": "c2"},
    ]
    results = await ex.execute_batch(calls)
    assert len(results) == 2
    assert all(r.success for r in results)


@pytest.mark.anyio
async def test_execute_batch_empty():
    r = ToolRegistry()
    ex = ToolExecutor(r)
    results = await ex.execute_batch([])
    assert results == []


# ---------------------------------------------------------------------------
# Permission checks in executor
# ---------------------------------------------------------------------------

def _make_deny_manager():
    """Return a PermissionManager that always denies."""
    mgr = MagicMock(spec=PermissionManager)
    mgr.request_permission_async = AsyncMock(return_value=(False, None))
    return mgr


def _make_approve_manager():
    mgr = MagicMock(spec=PermissionManager)
    mgr.request_permission_async = AsyncMock(return_value=(True, None))
    return mgr


def _make_context_manager(context: str):
    mgr = MagicMock(spec=PermissionManager)
    mgr.request_permission_async = AsyncMock(return_value=(False, context))
    return mgr


@pytest.mark.anyio
async def test_executor_blocks_destructive_tool_on_deny():
    def write(path, content):
        return {"success": True}

    r = _make_builtin_registry("write_file", write)
    ex = ToolExecutor(r, permission_manager=_make_deny_manager())
    result = await ex.execute("write_file", {"path": "/tmp/x", "content": "hi"}, "c1")
    assert result.success is False
    assert "rejected" in result.error.lower()


@pytest.mark.anyio
async def test_executor_injects_context_on_add_context():
    def write(path, content):
        return {"success": True}

    r = _make_builtin_registry("write_file", write)
    ex = ToolExecutor(r, permission_manager=_make_context_manager("use config system"))
    result = await ex.execute("write_file", {"path": "/tmp/x", "content": "hi"}, "c1")
    assert result.success is False
    assert "use config system" in result.error


@pytest.mark.anyio
async def test_executor_skips_check_for_safe_tools():
    """read_file executes without hitting permission manager."""
    def read(path):
        return {"content": "data"}

    r = _make_builtin_registry("read_file", read)
    mgr = MagicMock(spec=PermissionManager)
    mgr.request_permission_async = AsyncMock(return_value=(True, None))

    ex = ToolExecutor(r, permission_manager=mgr)
    result = await ex.execute("read_file", {"path": "/tmp/x"}, "c1")
    assert result.success is True
    mgr.request_permission_async.assert_not_called()


@pytest.mark.anyio
async def test_executor_allows_destructive_tool_when_approved():
    def write(path, content):
        return {"success": True, "bytes_written": 2}

    r = _make_builtin_registry("write_file", write)
    ex = ToolExecutor(r, permission_manager=_make_approve_manager())
    result = await ex.execute("write_file", {"path": "/tmp/x", "content": "hi"}, "c1")
    assert result.success is True


@pytest.mark.anyio
async def test_executor_no_permission_manager_runs_destructive():
    """When no permission_manager is set, destructive tools run freely."""
    def write(path, content):
        return {"success": True}

    r = _make_builtin_registry("write_file", write)
    ex = ToolExecutor(r)  # no permission_manager
    result = await ex.execute("write_file", {"path": "/tmp/x", "content": "hi"}, "c1")
    assert result.success is True


@pytest.mark.anyio
async def test_executor_safe_run_command_skips_permission():
    """run_command with a safe executable skips the permission check."""
    def run(command):
        return {"output": "files...", "exit_code": 0}

    r = _make_builtin_registry("run_command", run)
    deny_mgr = _make_deny_manager()
    deny_mgr.is_safe_command = MagicMock(return_value=True)

    ex = ToolExecutor(r, permission_manager=deny_mgr)
    result = await ex.execute("run_command", {"command": "ls -la"}, "c1")
    # Despite deny manager, safe command runs
    assert result.success is True
    deny_mgr.request_permission_async.assert_not_called()


@pytest.mark.anyio
async def test_executor_unsafe_run_command_requires_permission():
    """run_command with an unsafe executable still hits the permission check."""
    def run(command):
        return {"output": "gone", "exit_code": 0}

    r = _make_builtin_registry("run_command", run)
    deny_mgr = _make_deny_manager()
    deny_mgr.is_safe_command = MagicMock(return_value=False)

    ex = ToolExecutor(r, permission_manager=deny_mgr)
    result = await ex.execute("run_command", {"command": "rm -rf /"}, "c1")
    assert result.success is False
    deny_mgr.request_permission_async.assert_called_once()
