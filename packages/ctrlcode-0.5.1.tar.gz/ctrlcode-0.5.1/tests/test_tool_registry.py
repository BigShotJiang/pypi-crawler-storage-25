"""Tests for ToolRegistry — register_builtin, get_tool, list_tools, definitions."""

import pytest
from unittest.mock import AsyncMock, MagicMock

from ctrlcode.tools.registry import BuiltinTool, ToolRegistry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def dummy_fn(**kwargs):
    return "result"


def _register(registry: ToolRegistry, name: str = "mytool") -> None:
    registry.register_builtin(
        name=name,
        description=f"{name} description",
        input_schema={"type": "object", "properties": {}},
        function=dummy_fn,
    )


# ---------------------------------------------------------------------------
# register_builtin
# ---------------------------------------------------------------------------

def test_register_builtin_adds_tool():
    r = ToolRegistry()
    _register(r)
    assert "mytool" in r.builtin_tools


def test_register_builtin_sets_fields():
    r = ToolRegistry()
    r.register_builtin("foo", "Foo tool", {"type": "object"}, dummy_fn)
    t = r.builtin_tools["foo"]
    assert t.name == "foo"
    assert t.description == "Foo tool"
    assert t.function is dummy_fn


def test_register_builtin_skips_duplicate():
    r = ToolRegistry()
    _register(r, "dup")
    _register(r, "dup")  # second registration should be skipped
    assert len([k for k in r.builtin_tools if k == "dup"]) == 1


# ---------------------------------------------------------------------------
# get_tool
# ---------------------------------------------------------------------------

def test_get_tool_returns_builtin():
    r = ToolRegistry()
    _register(r, "alpha")
    t = r.get_tool("alpha")
    assert t is not None
    assert t.name == "alpha"


def test_get_tool_returns_none_for_unknown():
    r = ToolRegistry()
    assert r.get_tool("nonexistent") is None


# ---------------------------------------------------------------------------
# is_builtin
# ---------------------------------------------------------------------------

def test_is_builtin_true_for_registered():
    r = ToolRegistry()
    _register(r, "checker")
    assert r.is_builtin("checker") is True


def test_is_builtin_false_for_unknown():
    r = ToolRegistry()
    assert r.is_builtin("unknown") is False


# ---------------------------------------------------------------------------
# list_tools
# ---------------------------------------------------------------------------

def test_list_tools_empty_initially():
    r = ToolRegistry()
    assert r.list_tools() == []


def test_list_tools_includes_builtins():
    r = ToolRegistry()
    _register(r, "t1")
    _register(r, "t2")
    names = [t.name for t in r.list_tools()]
    assert "t1" in names
    assert "t2" in names


# ---------------------------------------------------------------------------
# get_tool_definitions
# ---------------------------------------------------------------------------

def test_get_tool_definitions_format():
    r = ToolRegistry()
    r.register_builtin("mydef", "desc", {"type": "object"}, dummy_fn)
    defs = r.get_tool_definitions()
    assert len(defs) == 1
    d = defs[0]
    assert d["name"] == "mydef"
    assert d["description"] == "desc"
    assert "input_schema" in d


def test_get_tool_definitions_empty():
    r = ToolRegistry()
    assert r.get_tool_definitions() == []


# ---------------------------------------------------------------------------
# get_tool_definitions_filtered
# ---------------------------------------------------------------------------

def test_get_tool_definitions_filtered():
    r = ToolRegistry()
    _register(r, "allowed")
    _register(r, "blocked")
    filtered = r.get_tool_definitions_filtered(["allowed"])
    names = [d["name"] for d in filtered]
    assert "allowed" in names
    assert "blocked" not in names


def test_get_tool_definitions_filtered_empty_list():
    r = ToolRegistry()
    _register(r, "tool")
    assert r.get_tool_definitions_filtered([]) == []


# ---------------------------------------------------------------------------
# remove_server / close_all (async)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_remove_server_clears_tools():
    r = ToolRegistry()
    # Inject a fake MCP client
    mock_client = MagicMock()
    mock_client.stop = AsyncMock()
    mock_tool = MagicMock()
    mock_tool.server_name = "srv"
    mock_tool.name = "srv_tool"
    r.clients["srv"] = mock_client
    r.mcp_tools["srv_tool"] = mock_tool

    await r.remove_server("srv")

    assert "srv" not in r.clients
    assert "srv_tool" not in r.mcp_tools
    mock_client.stop.assert_called_once()


@pytest.mark.anyio
async def test_remove_server_noop_for_unknown():
    r = ToolRegistry()
    await r.remove_server("nonexistent")  # should not raise


@pytest.mark.anyio
async def test_close_all_clears_everything():
    r = ToolRegistry()
    mock_client = MagicMock()
    mock_client.stop = AsyncMock()
    r.clients["s"] = mock_client
    _register(r, "b")

    await r.close_all()

    assert r.clients == {}
    assert r.builtin_tools == {}
    mock_client.stop.assert_called_once()
