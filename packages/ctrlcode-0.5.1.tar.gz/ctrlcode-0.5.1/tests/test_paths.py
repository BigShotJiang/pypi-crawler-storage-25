"""Tests for paths.py — get_config_dir, get_data_dir, get_cache_dir with env overrides."""

import os
from pathlib import Path

import pytest

from ctrlcode.paths import get_cache_dir, get_config_dir, get_data_dir


def test_get_config_dir_returns_path():
    result = get_config_dir()
    assert isinstance(result, Path)


def test_get_data_dir_returns_path():
    result = get_data_dir()
    assert isinstance(result, Path)


def test_get_cache_dir_returns_path():
    result = get_cache_dir()
    assert isinstance(result, Path)


def test_get_config_dir_env_override(monkeypatch, tmp_path):
    monkeypatch.setenv("CTRLCODE_CONFIG_DIR", str(tmp_path))
    assert get_config_dir() == tmp_path


def test_get_data_dir_env_override(monkeypatch, tmp_path):
    monkeypatch.setenv("CTRLCODE_DATA_DIR", str(tmp_path))
    assert get_data_dir() == tmp_path


def test_get_cache_dir_env_override(monkeypatch, tmp_path):
    monkeypatch.setenv("CTRLCODE_CACHE_DIR", str(tmp_path))
    assert get_cache_dir() == tmp_path


def test_get_config_dir_default_without_override(monkeypatch):
    monkeypatch.delenv("CTRLCODE_CONFIG_DIR", raising=False)
    result = get_config_dir()
    assert "ctrlcode" in str(result).lower()


def test_get_data_dir_default_without_override(monkeypatch):
    monkeypatch.delenv("CTRLCODE_DATA_DIR", raising=False)
    result = get_data_dir()
    assert "ctrlcode" in str(result).lower()


def test_get_cache_dir_default_without_override(monkeypatch):
    monkeypatch.delenv("CTRLCODE_CACHE_DIR", raising=False)
    result = get_cache_dir()
    assert "ctrlcode" in str(result).lower()
