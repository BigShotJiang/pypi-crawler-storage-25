"""Tests for before_complete_hook, react loop guard wiring, and progress file writing."""

import json
import pytest
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock

from harnessutils import ConversationManager

from ctrlcode.agents.react_loop import AgentReActLoop
from ctrlcode.providers.base import StreamEvent
from ctrlcode.tools.registry import ToolRegistry
from ctrlcode.tools.executor import ToolExecutor
from ctrlcode.tools.todo import TodoTools

from tests.mocks.mock_provider import MockProvider, create_tool_call_response, create_text_response


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def make_run_command_response(command: str) -> dict:
    return create_tool_call_response(
        tool_name="run_command",
        tool_input={"command": command},
        call_id="cmd-1",
    )


@pytest.fixture
def workspace(tmp_path):
    return tmp_path


@pytest.fixture
def conv_manager(workspace):
    return ConversationManager(workspace_root=workspace, harness_name=".ctrlcode")


@pytest.fixture
def conv_id(conv_manager):
    return conv_manager.create_conversation(project_id="test").id


@pytest.fixture
def registry():
    reg = ToolRegistry()
    reg.register_builtin(
        name="run_command",
        description="Run shell command",
        input_schema={"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]},
        function=lambda command, **kw: {"stdout": "ok", "returncode": 0, "success": True},
    )
    return reg


@pytest.fixture
def executor(registry):
    return ToolExecutor(registry)


async def collect_events(loop, **kwargs) -> list[StreamEvent]:
    return [e async for e in loop.stream(**kwargs)]


# ------------------------------------------------------------------
# React loop — before_complete_hook blocks on text-only response
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_hook_blocks_completion_emits_event(conv_manager, conv_id, executor):
    """Hook returning a reason should yield before_complete_blocked and let loop continue."""
    block_count = [0]

    async def hook(text: str):
        if block_count[0] == 0:
            block_count[0] += 1
            return "Pending todos exist"
        return None  # allow on second attempt

    provider = MockProvider([
        create_text_response("First attempt"),
        create_text_response("Second attempt"),
    ])

    loop = AgentReActLoop()
    events = await collect_events(
        loop,
        provider=provider,
        conv_manager=conv_manager,
        conv_id=conv_id,
        tool_executor=executor,
        tools=[],
        before_complete_hook=hook,
    )

    event_types = [e.type for e in events]
    assert "before_complete_blocked" in event_types

    blocked = next(e for e in events if e.type == "before_complete_blocked")
    assert blocked.data["reason"] == "Pending todos exist"

    assert "task_summary" in event_types


@pytest.mark.anyio
async def test_hook_allows_completion_when_returning_none(conv_manager, conv_id, executor):
    """Hook returning None should let completion through immediately."""
    async def hook(text: str):
        return None

    provider = MockProvider([create_text_response("All done")])
    loop = AgentReActLoop()
    events = await collect_events(
        loop,
        provider=provider,
        conv_manager=conv_manager,
        conv_id=conv_id,
        tool_executor=executor,
        tools=[],
        before_complete_hook=hook,
    )

    event_types = [e.type for e in events]
    assert "before_complete_blocked" not in event_types
    assert "task_summary" in event_types


@pytest.mark.anyio
async def test_no_hook_completion_passes(conv_manager, conv_id, executor):
    """With no hook, text-only response should complete immediately."""
    provider = MockProvider([create_text_response("Done")])
    loop = AgentReActLoop()
    events = await collect_events(
        loop,
        provider=provider,
        conv_manager=conv_manager,
        conv_id=conv_id,
        tool_executor=executor,
        tools=[],
        before_complete_hook=None,
    )

    event_types = [e.type for e in events]
    assert "before_complete_blocked" not in event_types
    assert "task_summary" in event_types


# ------------------------------------------------------------------
# TodoTools — steps field
# ------------------------------------------------------------------

def test_todo_write_stores_steps():
    with tempfile.TemporaryDirectory() as d:
        todo = TodoTools(d)
        r = todo.todo_write([{
            "content": "Add tests",
            "steps": ["Write test_foo.py", "Run pytest", "Check coverage"],
        }])
        assert r["success"] is True
        assert r["todos"][0]["steps"] == ["Write test_foo.py", "Run pytest", "Check coverage"]


def test_todo_write_defaults_steps_to_empty():
    with tempfile.TemporaryDirectory() as d:
        todo = TodoTools(d)
        r = todo.todo_write([{"content": "Simple task"}])
        assert r["todos"][0]["steps"] == []


def test_todo_update_steps():
    with tempfile.TemporaryDirectory() as d:
        todo = TodoTools(d)
        tid = todo.todo_write([{"content": "Task"}])["todos"][0]["id"]
        r = todo.todo_update(tid, steps=["Step 1", "Step 2"])
        assert r["todos"][0]["steps"] == ["Step 1", "Step 2"]


def test_todo_steps_persisted():
    with tempfile.TemporaryDirectory() as d:
        todo = TodoTools(d)
        steps = ["Read file", "Edit function", "Run tests"]
        session_id = "sess-abc"
        todo.todo_write([{"content": "Fix bug", "steps": steps}], session_id=session_id)

        r = todo.todo_list(session_id=session_id)
        assert r["todos"][0]["steps"] == steps


# ------------------------------------------------------------------
# _write_progress_file
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_write_progress_file_creates_file(workspace):
    from ctrlcode.session.hooks import write_progress_file

    ctrlcode_dir = workspace / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Implemented auth", ["src/auth.py"])

    progress = ctrlcode_dir / "progress.md"
    assert progress.exists()
    content = progress.read_text()
    assert "Implemented auth" in content
    assert "src/auth.py" in content


@pytest.mark.anyio
async def test_write_progress_file_no_touched_files(workspace):
    from ctrlcode.session.hooks import write_progress_file

    ctrlcode_dir = workspace / ".ctrlcode"
    await write_progress_file(ctrlcode_dir, "Quick fix", [])

    content = (ctrlcode_dir / "progress.md").read_text()
    assert "Quick fix" in content
    assert "Files touched" not in content


# ------------------------------------------------------------------
# Verification guard integration
# ------------------------------------------------------------------

@pytest.mark.anyio
async def test_verification_guard_blocks_when_no_commands_ran(workspace):
    """Hook should block completion if verification commands exist but none were run."""
    from ctrlcode.session.hooks import make_before_complete_hook
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="test-session",
        commands_run=[],
        tool_executor=None,
        verification_commands=["pytest"],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is not None
    assert "pytest" in result


@pytest.mark.anyio
async def test_verification_guard_passes_when_command_ran(workspace):
    from ctrlcode.session.hooks import make_before_complete_hook
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="test-session",
        commands_run=["uv run pytest tests/ -x -q"],
        tool_executor=None,
        verification_commands=["pytest"],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


@pytest.mark.anyio
async def test_verification_guard_no_commands_configured_passes(workspace):
    from ctrlcode.session.hooks import make_before_complete_hook
    from ctrlcode.session.verification import VerificationDetector

    hook = make_before_complete_hook(
        session_id="test-session",
        commands_run=[],
        tool_executor=None,
        verification_commands=[],
        verification_detector=VerificationDetector(),
    )
    result = await hook("All done.")
    assert result is None


# ------------------------------------------------------------------
# make_post_tool_hook — blast-radius warning
# ------------------------------------------------------------------

def _make_monitor(dependents: list[str]):
    """Build a minimal workspace_monitor mock with a dep_indexer."""
    dep_indexer = AsyncMock()
    dep_indexer.get_dependents = AsyncMock(return_value=set(dependents))
    monitor = AsyncMock()
    monitor.dep_indexer = dep_indexer
    return monitor


def _make_session(conv_manager, conv_id):
    from unittest.mock import MagicMock
    session = MagicMock()
    session.conv_id = conv_id
    return session


def _make_success_result(value="ok"):
    from unittest.mock import MagicMock
    r = MagicMock()
    r.success = True
    r.result = value
    return r


def _make_fail_result():
    from unittest.mock import MagicMock
    r = MagicMock()
    r.success = False
    r.error = "boom"
    return r


@pytest.mark.anyio
async def test_blast_radius_injects_message_when_dependents_found(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s1"
    sessions = {session_id: _make_session(conv_manager, conv_id)}
    monitor = _make_monitor(["bar.py", "baz.py"])

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=monitor)
    tool_call = {"tool": "write_file", "input": {"path": "src/foo.py"}}

    async for _ in hook(tool_call, _make_success_result()):
        pass

    messages = conv_manager.to_model_format(conv_id)
    texts = [p for m in messages for p in [m.get("content", "")] if isinstance(p, str)]
    combined = " ".join(texts)
    assert "Blast radius" in combined
    assert "src/foo.py" in combined
    assert "bar.py" in combined


@pytest.mark.anyio
async def test_blast_radius_skipped_when_no_dependents(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s2"
    sessions = {session_id: _make_session(conv_manager, conv_id)}
    monitor = _make_monitor([])

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=monitor)
    tool_call = {"tool": "write_file", "input": {"path": "src/foo.py"}}

    async for _ in hook(tool_call, _make_success_result()):
        pass

    messages = conv_manager.to_model_format(conv_id)
    texts = [m.get("content", "") for m in messages if isinstance(m.get("content"), str)]
    assert not any("Blast radius" in t for t in texts)


@pytest.mark.anyio
async def test_blast_radius_skipped_on_failed_write(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s3"
    sessions = {session_id: _make_session(conv_manager, conv_id)}
    monitor = _make_monitor(["bar.py"])

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=monitor)
    tool_call = {"tool": "write_file", "input": {"path": "src/foo.py"}}

    async for _ in hook(tool_call, _make_fail_result()):
        pass

    # get_dependents should never be called for failed writes
    monitor.dep_indexer.get_dependents.assert_not_called()


@pytest.mark.anyio
async def test_blast_radius_skipped_for_non_write_tools(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s4"
    sessions = {session_id: _make_session(conv_manager, conv_id)}
    monitor = _make_monitor(["bar.py"])

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=monitor)
    tool_call = {"tool": "read_file", "input": {"path": "src/foo.py"}}

    async for _ in hook(tool_call, _make_success_result()):
        pass

    monitor.dep_indexer.get_dependents.assert_not_called()


@pytest.mark.anyio
async def test_blast_radius_truncates_at_ten(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s5"
    sessions = {session_id: _make_session(conv_manager, conv_id)}
    dependents = [f"file{i}.py" for i in range(15)]
    monitor = _make_monitor(dependents)

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=monitor)
    tool_call = {"tool": "update_file", "input": {"path": "src/foo.py"}}

    async for _ in hook(tool_call, _make_success_result()):
        pass

    messages = conv_manager.to_model_format(conv_id)
    texts = [m.get("content", "") for m in messages if isinstance(m.get("content"), str)]
    combined = " ".join(texts)
    assert "+5 more" in combined


@pytest.mark.anyio
async def test_blast_radius_no_monitor_no_crash(conv_manager, conv_id):
    from ctrlcode.session.hooks import make_post_tool_hook

    session_id = "s6"
    sessions = {session_id: _make_session(conv_manager, conv_id)}

    hook = make_post_tool_hook(session_id, sessions, None, conv_manager, workspace_monitor=None)
    tool_call = {"tool": "write_file", "input": {"path": "src/foo.py"}}

    # Should not raise
    async for _ in hook(tool_call, _make_success_result()):
        pass
