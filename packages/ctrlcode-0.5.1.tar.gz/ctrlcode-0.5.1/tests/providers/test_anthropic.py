"""Tests for AnthropicProvider — normalize_tool_call, generate (mocked)."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ctrlcode.providers.anthropic import AnthropicProvider


@pytest.fixture
def provider():
    with patch("ctrlcode.providers.anthropic.AsyncAnthropic"):
        return AnthropicProvider(api_key="test-key", model="claude-test")


# ---------------------------------------------------------------------------
# normalize_tool_call
# ---------------------------------------------------------------------------

def test_normalize_tool_call_extracts_name(provider):
    raw = {"name": "my_tool", "id": "call_1", "input": {"x": 1}}
    result = provider.normalize_tool_call(raw)
    assert result["name"] == "my_tool"


def test_normalize_tool_call_extracts_call_id(provider):
    raw = {"name": "t", "id": "abc123", "input": {}}
    result = provider.normalize_tool_call(raw)
    assert result["call_id"] == "abc123"


def test_normalize_tool_call_extracts_input(provider):
    raw = {"name": "t", "id": "c1", "input": {"key": "value"}}
    result = provider.normalize_tool_call(raw)
    assert result["input"] == {"key": "value"}


def test_normalize_tool_call_defaults_input_empty(provider):
    raw = {"name": "t", "id": "c1"}
    result = provider.normalize_tool_call(raw)
    assert result["input"] == {}


# ---------------------------------------------------------------------------
# generate — mocked client
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_generate_returns_text():
    with patch("ctrlcode.providers.anthropic.AsyncAnthropic") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        # Build mock response
        mock_block = MagicMock()
        mock_block.type = "text"
        mock_block.text = "Hello there!"

        mock_response = MagicMock()
        mock_response.content = [mock_block]
        mock_response.usage = MagicMock(input_tokens=10, output_tokens=5)
        mock_response.model = "claude-test"

        mock_client.messages.create = AsyncMock(return_value=mock_response)

        p = AnthropicProvider(api_key="key", model="claude-test")
        result = await p.generate([{"role": "user", "content": "hi"}])

    assert result["text"] == "Hello there!"
    assert result["usage"]["prompt_tokens"] == 10
    assert result["usage"]["completion_tokens"] == 5


@pytest.mark.anyio
async def test_generate_skips_non_text_blocks():
    with patch("ctrlcode.providers.anthropic.AsyncAnthropic") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        tool_block = MagicMock()
        tool_block.type = "tool_use"

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "response"

        mock_response = MagicMock()
        mock_response.content = [tool_block, text_block]
        mock_response.usage = MagicMock(input_tokens=5, output_tokens=3)
        mock_response.model = "m"

        mock_client.messages.create = AsyncMock(return_value=mock_response)

        p = AnthropicProvider(api_key="key", model="m")
        result = await p.generate([])

    assert result["text"] == "response"
