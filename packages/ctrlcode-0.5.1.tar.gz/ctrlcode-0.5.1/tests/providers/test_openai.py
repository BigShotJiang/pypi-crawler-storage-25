"""Tests for OpenAIProvider — normalize_tool_call, _convert_tools_to_openai_format, generate, stream."""

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ctrlcode.providers.openai import OpenAIProvider


# ---------------------------------------------------------------------------
# Helpers for stream mocking
# ---------------------------------------------------------------------------

def _make_chunk(content=None, tool_calls=None, finish_reason=None, usage=None):
    """Build a minimal mock OpenAI stream chunk."""
    chunk = MagicMock()
    chunk.usage = None

    if usage is not None:
        chunk.usage = MagicMock(
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
        )

    if content is not None or finish_reason is not None or tool_calls is not None:
        delta = MagicMock()
        delta.content = content
        delta.tool_calls = tool_calls or []
        choice = MagicMock()
        choice.delta = delta
        choice.finish_reason = finish_reason
        chunk.choices = [choice]
    else:
        chunk.choices = []

    return chunk


async def _make_stream(*chunks):
    """Create an async iterable of chunks."""
    for chunk in chunks:
        yield chunk


@pytest.fixture
def provider():
    with patch("ctrlcode.providers.openai.AsyncOpenAI"):
        return OpenAIProvider(api_key="test-key", model="gpt-4")


# ---------------------------------------------------------------------------
# normalize_tool_call
# ---------------------------------------------------------------------------

def test_normalize_tool_call_extracts_name(provider):
    raw = {"id": "call_1", "function": {"name": "my_tool", "arguments": "{}"}}
    result = provider.normalize_tool_call(raw)
    assert result["name"] == "my_tool"


def test_normalize_tool_call_extracts_call_id(provider):
    raw = {"id": "abc123", "function": {"name": "t", "arguments": "{}"}}
    result = provider.normalize_tool_call(raw)
    assert result["call_id"] == "abc123"


def test_normalize_tool_call_parses_arguments(provider):
    raw = {"id": "c1", "function": {"name": "t", "arguments": '{"key": "value"}'}}
    result = provider.normalize_tool_call(raw)
    assert result["input"] == {"key": "value"}


def test_normalize_tool_call_empty_arguments(provider):
    raw = {"id": "c1", "function": {"name": "t", "arguments": "{}"}}
    result = provider.normalize_tool_call(raw)
    assert result["input"] == {}


def test_normalize_tool_call_missing_function(provider):
    raw = {"id": "c1"}
    result = provider.normalize_tool_call(raw)
    assert result["name"] is None
    assert result["call_id"] == "c1"


# ---------------------------------------------------------------------------
# _convert_tools_to_openai_format
# ---------------------------------------------------------------------------

def test_convert_tools_wraps_in_function_type(provider):
    tools = [{"name": "my_tool", "description": "does stuff", "input_schema": {"type": "object"}}]
    result = provider._convert_tools_to_openai_format(tools)
    assert len(result) == 1
    assert result[0]["type"] == "function"


def test_convert_tools_maps_input_schema_to_parameters(provider):
    schema = {"type": "object", "properties": {"x": {"type": "integer"}}}
    tools = [{"name": "t", "description": "d", "input_schema": schema}]
    result = provider._convert_tools_to_openai_format(tools)
    assert result[0]["function"]["parameters"] == schema


def test_convert_tools_preserves_name_and_description(provider):
    tools = [{"name": "read_file", "description": "Read a file", "input_schema": {}}]
    result = provider._convert_tools_to_openai_format(tools)
    fn = result[0]["function"]
    assert fn["name"] == "read_file"
    assert fn["description"] == "Read a file"


def test_convert_multiple_tools(provider):
    tools = [
        {"name": "t1", "description": "d1", "input_schema": {}},
        {"name": "t2", "description": "d2", "input_schema": {}},
    ]
    result = provider._convert_tools_to_openai_format(tools)
    assert len(result) == 2
    assert result[1]["function"]["name"] == "t2"


# ---------------------------------------------------------------------------
# generate — mocked client
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_generate_returns_text():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        mock_choice = MagicMock()
        mock_choice.message.content = "Hello!"

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5
        mock_response.usage.total_tokens = 15
        mock_response.model = "gpt-4"

        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)

        p = OpenAIProvider(api_key="key", model="gpt-4")
        result = await p.generate([{"role": "user", "content": "hi"}])

    assert result["text"] == "Hello!"
    assert result["usage"]["prompt_tokens"] == 10
    assert result["usage"]["completion_tokens"] == 5
    assert result["usage"]["total_tokens"] == 15


@pytest.mark.anyio
async def test_generate_empty_content():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        mock_choice = MagicMock()
        mock_choice.message.content = None

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage = None
        mock_response.model = "gpt-4"

        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)

        p = OpenAIProvider(api_key="key", model="gpt-4")
        result = await p.generate([])

    assert result["text"] == ""
    assert result["usage"] == {}


@pytest.mark.anyio
async def test_generate_with_tools_converts_format():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        mock_choice = MagicMock()
        mock_choice.message.content = "ok"

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage = None
        mock_response.model = "gpt-4"

        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)

        p = OpenAIProvider(api_key="key", model="gpt-4")
        tools = [{"name": "read_file", "description": "Read", "input_schema": {}}]
        await p.generate([], tools=tools)

        call_kwargs = mock_client.chat.completions.create.call_args[1]
        assert call_kwargs["tools"][0]["type"] == "function"


# ---------------------------------------------------------------------------
# stream — mocked async stream
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_stream_yields_text_event():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        chunks = [
            _make_chunk(content="Hello "),
            _make_chunk(content="world"),
            _make_chunk(finish_reason="stop"),
        ]
        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(*chunks)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([{"role": "user", "content": "hi"}]):
            events.append(ev)

    text_events = [e for e in events if e.type == "text"]
    assert len(text_events) == 2
    assert text_events[0].data["text"] == "Hello "


@pytest.mark.anyio
async def test_stream_yields_finish_event():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        chunks = [_make_chunk(finish_reason="stop")]
        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(*chunks)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([]):
            events.append(ev)

    finish_events = [e for e in events if e.type == "finish"]
    assert len(finish_events) == 1
    assert finish_events[0].data["reason"] == "end_turn"


@pytest.mark.anyio
async def test_stream_maps_tool_calls_finish():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        chunks = [_make_chunk(finish_reason="tool_calls")]
        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(*chunks)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([]):
            events.append(ev)

    finish_events = [e for e in events if e.type == "finish"]
    assert finish_events[0].data["reason"] == "tool_use"
    # tool_calls finish also emits content_block_stop
    stop_events = [e for e in events if e.type == "content_block_stop"]
    assert len(stop_events) == 1


@pytest.mark.anyio
async def test_stream_yields_usage_event():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        chunks = [
            _make_chunk(usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}),
        ]
        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(*chunks)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([]):
            events.append(ev)

    usage_events = [e for e in events if e.type == "usage"]
    assert len(usage_events) == 1
    assert usage_events[0].data["usage"]["completion_tokens"] == 5


@pytest.mark.anyio
async def test_stream_tool_call_start_and_delta():
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        # First chunk: tool call starts
        tc1 = MagicMock()
        tc1.id = "call_abc"
        tc1.function.name = "read_file"
        tc1.function.arguments = '{"path":'

        # Second chunk: continuation (same id, no name)
        tc2 = MagicMock()
        tc2.id = "call_abc"
        tc2.function.name = None
        tc2.function.arguments = '"/foo.py"}'

        chunk1 = _make_chunk(tool_calls=[tc1])
        chunk2 = _make_chunk(tool_calls=[tc2])

        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(chunk1, chunk2)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([]):
            events.append(ev)

    start_events = [e for e in events if e.type == "tool_call_start"]
    delta_events = [e for e in events if e.type == "tool_call_delta"]
    assert len(start_events) == 1
    assert start_events[0].data["tool"] == "read_file"
    assert len(delta_events) >= 1


@pytest.mark.anyio
async def test_stream_skips_chunks_with_no_choices():
    """Chunks with no choices (usage-only) should not cause errors."""
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        usage_chunk = MagicMock()
        usage_chunk.choices = []
        usage_chunk.usage = MagicMock(prompt_tokens=5, completion_tokens=3, total_tokens=8)

        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream(usage_chunk)
        )

        p = OpenAIProvider(api_key="key", model="gpt-4")
        events = []
        async for ev in p.stream([]):
            events.append(ev)

    usage_events = [e for e in events if e.type == "usage"]
    assert len(usage_events) == 1


@pytest.mark.anyio
async def test_stream_qwen_model_adds_extra_body():
    """Qwen models should get thinking disabled."""
    with patch("ctrlcode.providers.openai.AsyncOpenAI") as mock_cls:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client

        mock_client.chat.completions.create = AsyncMock(
            return_value=_make_stream()
        )

        p = OpenAIProvider(api_key="key", model="qwen3-235b")
        async for _ in p.stream([]):
            pass

        call_kwargs = mock_client.chat.completions.create.call_args[1]
        assert "extra_body" in call_kwargs
        assert call_kwargs["extra_body"]["chat_template_kwargs"]["enable_thinking"] is False
