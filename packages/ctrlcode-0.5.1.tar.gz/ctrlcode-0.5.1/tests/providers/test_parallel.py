"""Tests for ParallelExecutor — execute_all, _execute_variant."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.providers.base import StreamEvent
from ctrlcode.providers.parallel import ParallelExecutor, ProviderOutput


def make_provider(text_chunks: list[str] = None, tokens: int = 10):
    """Build a mock provider that streams text events."""
    if text_chunks is None:
        text_chunks = ["hello"]

    async def fake_stream(messages, **kwargs):
        for chunk in text_chunks:
            yield StreamEvent(type="text", data={"text": chunk})
        yield StreamEvent(type="usage", data={"usage": {"total_tokens": tokens}})

    provider = MagicMock()
    provider.__class__.__name__ = "MockProvider"
    provider.stream = fake_stream
    return provider


# ---------------------------------------------------------------------------
# _execute_variant
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_variant_returns_output():
    provider = make_provider(["def foo(): pass"], tokens=20)
    result = await ParallelExecutor._execute_variant(
        provider=provider,
        variant={"prompt": "write foo"},
        variant_id="v0",
        context=[],
    )
    assert isinstance(result, ProviderOutput)
    assert result.variant_id == "v0"
    assert result.code == "def foo(): pass"
    assert result.tokens == 20


@pytest.mark.anyio
async def test_execute_variant_uses_provider_class_name():
    provider = make_provider(["x"])
    result = await ParallelExecutor._execute_variant(
        provider=provider,
        variant={"prompt": "do it"},
        variant_id="v1",
        context=[],
    )
    assert result.provider_name == "MockProvider"


@pytest.mark.anyio
async def test_execute_variant_elapsed_time_nonnegative():
    provider = make_provider(["ok"])
    result = await ParallelExecutor._execute_variant(
        provider=provider,
        variant={"prompt": "test"},
        variant_id="v0",
        context=[],
    )
    assert result.elapsed_time >= 0.0


# ---------------------------------------------------------------------------
# execute_all
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_execute_all_single_variant():
    provider = make_provider(["result"])
    outputs = await ParallelExecutor.execute_all(
        variants=[{"prompt": "q"}],
        providers=[provider],
        context=[],
    )
    assert len(outputs) == 1
    assert outputs[0].code == "result"


@pytest.mark.anyio
async def test_execute_all_round_robin_providers():
    p1 = make_provider(["from p1"])
    p2 = make_provider(["from p2"])
    outputs = await ParallelExecutor.execute_all(
        variants=[{"prompt": "a"}, {"prompt": "b"}],
        providers=[p1, p2],
        context=[],
    )
    assert len(outputs) == 2
    codes = {o.code for o in outputs}
    assert "from p1" in codes
    assert "from p2" in codes


@pytest.mark.anyio
async def test_execute_all_skips_failed_variants():
    async def failing_stream(messages, **kwargs):
        raise RuntimeError("provider down")
        yield  # make it a generator

    bad_provider = MagicMock()
    bad_provider.stream = failing_stream

    outputs = await ParallelExecutor.execute_all(
        variants=[{"prompt": "x"}],
        providers=[bad_provider],
        context=[],
    )
    assert outputs == []


@pytest.mark.anyio
async def test_execute_all_empty_variants():
    outputs = await ParallelExecutor.execute_all(
        variants=[],
        providers=[make_provider()],
        context=[],
    )
    assert outputs == []


@pytest.mark.anyio
async def test_execute_all_concatenates_text_chunks():
    provider = make_provider(["part1", " part2"])
    outputs = await ParallelExecutor.execute_all(
        variants=[{"prompt": "write"}],
        providers=[provider],
        context=[],
    )
    assert outputs[0].code == "part1 part2"
