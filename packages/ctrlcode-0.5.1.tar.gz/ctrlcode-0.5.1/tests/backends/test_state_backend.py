"""Tests for StateBackend — pure in-memory, no disk required."""

import pytest

from ctrlcode.backends.state import StateBackend
from ctrlcode.backends.protocol import BackendProtocol


@pytest.fixture
def state() -> StateBackend:
    b = StateBackend()
    b._files = {
        "src/main.py": "def main():\n    pass\n",
        "src/utils.py": "import os\nimport sys\n",
        "README.md": "# Project\n",
        "src/lib/helper.py": "def help():\n    return 42\n",
    }
    return b


def test_implements_protocol():
    assert isinstance(StateBackend(), BackendProtocol)


# ------------------------------------------------------------------
# read
# ------------------------------------------------------------------

def test_read_returns_content(state):
    result = state.read("src/main.py")
    assert result["content"] == "def main():\n    pass\n"
    assert result["total_lines"] == 2


def test_read_missing_file(state):
    result = state.read("nonexistent.py")
    assert "error" in result


def test_read_with_offset(state):
    result = state.read("src/utils.py", offset=1)
    assert result["content"] == "import sys\n"
    assert result["total_lines"] == 2


def test_read_with_limit(state):
    result = state.read("src/utils.py", limit=1)
    assert result["content"] == "import os\n"
    assert result["lines_returned"] == 1


# ------------------------------------------------------------------
# glob
# ------------------------------------------------------------------

def test_glob_py_files(state):
    results = state.glob("**/*.py")
    assert "src/main.py" in results
    assert "src/utils.py" in results
    assert "src/lib/helper.py" in results
    assert "README.md" not in results


def test_glob_max_results(state):
    results = state.glob("**/*.py", max_results=2)
    assert len(results) <= 2


def test_glob_no_matches(state):
    results = state.glob("**/*.go")
    assert results == []


def test_glob_exact_pattern(state):
    results = state.glob("README.md")
    assert results == ["README.md"]


# ------------------------------------------------------------------
# grep
# ------------------------------------------------------------------

def test_grep_finds_match(state):
    results = state.grep("import")
    assert any(r["file"] == "src/utils.py" for r in results)


def test_grep_returns_line_number(state):
    results = state.grep("import os")
    assert results[0]["line"] == 1


def test_grep_no_match(state):
    results = state.grep("zzznomatch")
    assert results == []


def test_grep_invalid_regex(state):
    results = state.grep("[invalid")
    assert len(results) == 1
    assert "error" in results[0]


# ------------------------------------------------------------------
# stat
# ------------------------------------------------------------------

def test_stat_file(state):
    result = state.stat("src/main.py")
    assert result["is_file"] is True
    assert result["is_directory"] is False
    assert result["size"] > 0
    assert result["extension"] == ".py"


def test_stat_virtual_dir(state):
    result = state.stat("src")
    assert result["is_directory"] is True
    assert result["is_file"] is False


def test_stat_missing(state):
    result = state.stat("nope.txt")
    assert "error" in result


# ------------------------------------------------------------------
# write / overwrite / edit
# ------------------------------------------------------------------

def test_write_new_file(state):
    result = state.write("new.py", "x = 1\n")
    assert result["success"] is True
    assert state.read("new.py")["content"] == "x = 1\n"


def test_write_existing_file_fails(state):
    result = state.write("src/main.py", "other")
    assert "error" in result
    assert "already exists" in result["error"]


def test_overwrite_creates_new(state):
    result = state.overwrite("brand_new.py", "hello\n")
    assert result["success"] is True
    assert state.read("brand_new.py")["content"] == "hello\n"


def test_overwrite_replaces_existing(state):
    state.overwrite("src/main.py", "new content\n")
    assert state.read("src/main.py")["content"] == "new content\n"


def test_edit_replaces_substring(state):
    result = state.edit("src/main.py", "pass", "return None")
    assert result["success"] is True
    assert "return None" in state.read("src/main.py")["content"]


def test_edit_missing_old_content(state):
    result = state.edit("src/main.py", "zzznomatch", "x")
    assert "error" in result


def test_edit_missing_file(state):
    result = state.edit("nope.py", "x", "y")
    assert "error" in result


# ------------------------------------------------------------------
# write_bytes
# ------------------------------------------------------------------

def test_write_bytes(state):
    result = state.write_bytes("image.png", b"\x89PNG\r\n")
    assert result["success"] is True
    assert state._binary["image.png"] == b"\x89PNG\r\n"


# ------------------------------------------------------------------
# execute
# ------------------------------------------------------------------

def test_execute_raises(state):
    with pytest.raises(NotImplementedError):
        state.execute("ls")


# ------------------------------------------------------------------
# ls
# ------------------------------------------------------------------

def test_ls_root(state):
    result = state.ls(".")
    # src and README.md at root
    assert any("src" in d for d in result["directories"])
    assert any(f["path"] == "README.md" for f in result["files"])


def test_ls_subdir(state):
    result = state.ls("src")
    assert any(f["path"] == "src/main.py" for f in result["files"])
    assert any(f["path"] == "src/utils.py" for f in result["files"])
    # src/lib is a subdirectory
    assert any("lib" in d for d in result["directories"])


def test_ls_missing(state):
    result = state.ls("nonexistent")
    assert "error" in result
