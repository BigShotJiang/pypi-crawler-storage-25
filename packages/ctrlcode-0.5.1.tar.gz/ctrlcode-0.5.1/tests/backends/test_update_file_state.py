"""UpdateFileTools tests using StateBackend — no disk I/O required."""

import pytest

from ctrlcode.backends.state import StateBackend
from ctrlcode.tools.update import UpdateFileTools


@pytest.fixture
def state() -> StateBackend:
    b = StateBackend()
    b._files = {
        "src/foo.py": "line1\nline2\nline3\n",
    }
    return b


@pytest.fixture
def tools(state) -> UpdateFileTools:
    return UpdateFileTools(workspace_root="/virtual", backend=state)


def test_replace_line(tools, state):
    result = tools.update_file("src/foo.py", "replace", start_line=2, content="REPLACED")
    assert result["success"] is True
    assert "REPLACED" in state._files["src/foo.py"]
    assert "line2" not in state._files["src/foo.py"]


def test_insert_line(tools, state):
    result = tools.update_file("src/foo.py", "insert", start_line=2, content="INSERTED")
    assert result["success"] is True
    lines = state._files["src/foo.py"].splitlines()
    assert "INSERTED" in lines


def test_delete_line(tools, state):
    result = tools.update_file("src/foo.py", "delete", start_line=2)
    assert result["success"] is True
    assert "line2" not in state._files["src/foo.py"]
    assert "line1" in state._files["src/foo.py"]
    assert "line3" in state._files["src/foo.py"]


def test_update_missing_file(tools):
    result = tools.update_file("nope.py", "replace", start_line=1, content="x")
    assert "error" in result
    assert "nope.py" in result["error"]


def test_invalid_operation(tools):
    result = tools.update_file("src/foo.py", "zap", start_line=1)
    assert "error" in result


def test_out_of_range_line(tools):
    result = tools.update_file("src/foo.py", "replace", start_line=99, content="x")
    assert "error" in result
    assert "out of range" in result["error"]


def test_search_pattern(tools, state):
    result = tools.update_file("src/foo.py", "replace", search_pattern="line2", content="FOUND")
    assert result["success"] is True
    assert "FOUND" in state._files["src/foo.py"]


def test_requires_content_for_replace(tools):
    result = tools.update_file("src/foo.py", "replace", start_line=1)
    assert "error" in result


def test_requires_start_line_or_pattern(tools):
    result = tools.update_file("src/foo.py", "replace", content="x")
    assert "error" in result
