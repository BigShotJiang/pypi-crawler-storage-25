"""Tests for CompositeBackend — prefix-routing across sub-backends."""

import pytest

from ctrlcode.backends.state import StateBackend
from ctrlcode.backends.composite import CompositeBackend


@pytest.fixture
def virtual() -> StateBackend:
    b = StateBackend()
    b._files = {
        "foo.py": "x = 1\n",
        "bar.py": "y = 2\n",
    }
    return b


@pytest.fixture
def real() -> StateBackend:
    b = StateBackend()
    b._files = {
        "main.py": "def main(): pass\n",
    }
    return b


@pytest.fixture
def composite(virtual, real) -> CompositeBackend:
    return CompositeBackend(
        mounts=[("virtual", virtual)],
        default=real,
    )


# ------------------------------------------------------------------
# Routing
# ------------------------------------------------------------------

def test_read_virtual_mount(composite, virtual):
    result = composite.read("virtual/foo.py")
    assert result["content"] == "x = 1\n"


def test_read_default(composite, real):
    result = composite.read("main.py")
    assert result["content"] == "def main(): pass\n"


def test_write_routes_to_virtual(composite, virtual):
    composite.write("virtual/new.py", "z = 3\n")
    assert virtual._files.get("new.py") == "z = 3\n"


def test_write_routes_to_default(composite, real):
    composite.write("other.py", "a = 0\n")
    assert real._files.get("other.py") == "a = 0\n"


def test_overwrite_routes_to_virtual(composite, virtual):
    composite.overwrite("virtual/foo.py", "updated\n")
    assert virtual._files["foo.py"] == "updated\n"


def test_stat_routes_to_virtual(composite):
    result = composite.stat("virtual/foo.py")
    assert result["is_file"] is True


def test_stat_missing_no_backend(composite):
    result = composite.stat("zzz/missing.py")
    # zzz/ has no mount → routed to default → not found
    assert "error" in result


def test_glob_collects_all_mounts(composite):
    results = composite.glob("**/*.py")
    # virtual mount results should be prefixed
    assert any("virtual/" in r for r in results)
    # default results should appear
    assert "main.py" in results


def test_grep_collects_all_mounts(composite):
    results = composite.grep("x = 1")
    assert any("virtual/" in r["file"] for r in results)


def test_ls_routes_to_virtual(composite, virtual):
    result = composite.ls("virtual")
    assert "error" not in result


def test_ls_routes_to_default(composite, real):
    result = composite.ls(".")
    assert "error" not in result


def test_overwrite_routes_to_default(composite, real):
    composite.overwrite("updated.py", "z = 9\n")
    assert real._files.get("updated.py") == "z = 9\n"


def test_edit_routes_to_virtual(composite, virtual):
    result = composite.edit("virtual/foo.py", "x = 1", "x = 99")
    assert result["success"] is True
    assert "x = 99" in virtual._files["foo.py"]


def test_write_bytes_routes_to_virtual(composite, virtual):
    result = composite.write_bytes("virtual/data.bin", b"\x01\x02")
    assert result["success"] is True
    assert virtual._binary.get("data.bin") == b"\x01\x02"


def test_execute_no_backend_returns_error():
    # CompositeBackend with no default and no matching mount
    b = CompositeBackend(mounts=[("virtual", StateBackend())])
    result = b.execute("echo hi", cwd="other/path")
    assert "error" in result


def test_route_exact_prefix_match(virtual):
    # Path equals the prefix exactly (no trailing /)
    b = CompositeBackend(mounts=[("virtual", virtual)])
    backend, sub = b._route("virtual")
    assert backend is virtual
    assert sub == "."


def test_no_backend_for_path_returns_error():
    b = CompositeBackend(mounts=[("virtual", StateBackend())])
    result = b.read("other/file.py")
    assert "error" in result
