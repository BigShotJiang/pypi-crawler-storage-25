"""Tests for FilesystemBackend — real disk, workspace_root containment."""

import pytest
from pathlib import Path

from ctrlcode.backends.filesystem import FilesystemBackend
from ctrlcode.backends.protocol import BackendProtocol


@pytest.fixture
def root(tmp_path):
    return tmp_path


@pytest.fixture
def fs(root):
    return FilesystemBackend(root)


def make_file(root: Path, rel: str, content: str = "hello\n") -> Path:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return p


def test_implements_protocol(fs):
    assert isinstance(fs, BackendProtocol)


# ------------------------------------------------------------------
# _resolve / security
# ------------------------------------------------------------------

def test_resolve_blocks_absolute_outside_root(fs, root):
    result = fs.read("/etc/passwd")
    assert "error" in result
    assert "outside" in result["error"].lower()


def test_resolve_allows_absolute_inside_root(fs, root):
    make_file(root, "a.txt", "content\n")
    result = fs.read(str(root / "a.txt"))
    assert result["content"] == "content\n"


def test_resolve_blocks_traversal(fs):
    result = fs.read("../../etc/passwd")
    assert "error" in result


# ------------------------------------------------------------------
# read
# ------------------------------------------------------------------

def test_read_returns_content(fs, root):
    make_file(root, "f.txt", "line1\nline2\n")
    result = fs.read("f.txt")
    assert result["content"] == "line1\nline2\n"
    assert result["total_lines"] == 2


def test_read_missing_file(fs):
    result = fs.read("nope.txt")
    assert result == {"error": "File not found"}


def test_read_not_a_file(fs, root):
    (root / "mydir").mkdir()
    result = fs.read("mydir")
    assert result == {"error": "Not a file"}


def test_read_binary_file(fs, root):
    (root / "bin.dat").write_bytes(b"\x00\x01\x02\x80\xff")
    result = fs.read("bin.dat")
    assert "error" in result
    assert "binary" in result["error"].lower()


def test_read_with_offset_and_limit(fs, root):
    make_file(root, "multi.txt", "a\nb\nc\nd\n")
    result = fs.read("multi.txt", offset=1, limit=2)
    assert result["content"] == "b\nc\n"
    assert result["total_lines"] == 4
    assert result["lines_returned"] == 2


# ------------------------------------------------------------------
# glob
# ------------------------------------------------------------------

def test_glob_finds_py_files(fs, root):
    make_file(root, "a.py")
    make_file(root, "b.py")
    make_file(root, "c.txt")
    results = fs.glob("**/*.py")
    assert "a.py" in results
    assert "b.py" in results
    assert "c.txt" not in results


def test_glob_max_results(fs, root):
    for i in range(10):
        make_file(root, f"f{i}.py")
    results = fs.glob("**/*.py", max_results=3)
    assert len(results) <= 3


# ------------------------------------------------------------------
# grep
# ------------------------------------------------------------------

def test_grep_finds_match(fs, root):
    make_file(root, "code.py", "def my_func():\n    pass\n")
    results = fs.grep("my_func")
    assert any(r["file"] == "code.py" for r in results)
    assert any("my_func" in r["content"] for r in results)


def test_grep_with_file_glob(fs, root):
    make_file(root, "a.py", "match_me\n")
    make_file(root, "b.txt", "match_me\n")
    results = fs.grep("match_me", file_glob="**/*.py")
    assert all(r["file"].endswith(".py") for r in results)


def test_grep_no_match(fs, root):
    make_file(root, "code.py", "def foo(): pass\n")
    results = fs.grep("zzznomatch")
    assert results == []


def test_grep_max_results(fs, root):
    content = "\n".join(f"hit_{i}" for i in range(30))
    make_file(root, "big.py", content)
    results = fs.grep("hit_", max_results=5)
    assert len(results) <= 5


# ------------------------------------------------------------------
# stat
# ------------------------------------------------------------------

def test_stat_file(fs, root):
    make_file(root, "f.py", "x=1\n")
    result = fs.stat("f.py")
    assert result["is_file"] is True
    assert result["is_directory"] is False
    assert result["size"] > 0
    assert result["extension"] == ".py"


def test_stat_directory(fs, root):
    (root / "mydir").mkdir()
    result = fs.stat("mydir")
    assert result["is_directory"] is True


def test_stat_missing(fs):
    result = fs.stat("nope.txt")
    assert "error" in result


def test_stat_outside_workspace(fs):
    result = fs.stat("../../etc")
    assert "error" in result


# ------------------------------------------------------------------
# write
# ------------------------------------------------------------------

def test_write_creates_file(fs, root):
    result = fs.write("new.txt", "hello\n")
    assert result["success"] is True
    assert (root / "new.txt").read_text() == "hello\n"


def test_write_fails_if_exists(fs, root):
    make_file(root, "existing.txt")
    result = fs.write("existing.txt", "new")
    assert "error" in result
    assert "already exists" in result["error"]


def test_write_creates_parent_dirs(fs, root):
    result = fs.write("deep/nested/f.txt", "x\n")
    assert result["success"] is True
    assert (root / "deep" / "nested" / "f.txt").exists()


def test_write_outside_workspace(fs):
    result = fs.write("../../evil.txt", "x")
    assert "error" in result


def test_write_absolute_path_inside_root(fs, root):
    result = fs.write(str(root / "abs.txt"), "content\n")
    assert result["success"] is True


# ------------------------------------------------------------------
# overwrite
# ------------------------------------------------------------------

def test_overwrite_creates_new_file(fs, root):
    result = fs.overwrite("brand_new.txt", "hello\n")
    assert result["success"] is True
    assert (root / "brand_new.txt").read_text() == "hello\n"


def test_overwrite_replaces_existing(fs, root):
    make_file(root, "existing.txt", "old\n")
    result = fs.overwrite("existing.txt", "new\n")
    assert result["success"] is True
    assert (root / "existing.txt").read_text() == "new\n"


def test_overwrite_outside_workspace(fs):
    result = fs.overwrite("../../evil.txt", "x")
    assert "error" in result


def test_overwrite_creates_parent_dirs(fs, root):
    result = fs.overwrite("deep/f.txt", "content\n")
    assert result["success"] is True
    assert (root / "deep" / "f.txt").read_text() == "content\n"


# ------------------------------------------------------------------
# edit
# ------------------------------------------------------------------

def test_edit_replaces_content(fs, root):
    make_file(root, "code.py", "def foo(): pass\n")
    result = fs.edit("code.py", "foo", "bar")
    assert result["success"] is True
    assert "bar" in (root / "code.py").read_text()
    assert "foo" not in (root / "code.py").read_text()


def test_edit_old_content_not_found(fs, root):
    make_file(root, "code.py", "def foo(): pass\n")
    result = fs.edit("code.py", "zzznomatch", "x")
    assert "error" in result


def test_edit_missing_file(fs):
    result = fs.edit("nope.py", "x", "y")
    assert "error" in result


# ------------------------------------------------------------------
# write_bytes
# ------------------------------------------------------------------

def test_write_bytes_creates_file(fs, root):
    result = fs.write_bytes("image.png", b"\x89PNG\r\n")
    assert result["success"] is True
    assert (root / "image.png").read_bytes() == b"\x89PNG\r\n"


def test_write_bytes_outside_workspace(fs):
    result = fs.write_bytes("../../evil.bin", b"x")
    assert "error" in result


# ------------------------------------------------------------------
# execute
# ------------------------------------------------------------------

def test_execute_success(fs):
    result = fs.execute("echo hello")
    assert result["success"] is True
    assert "hello" in result["stdout"]


def test_execute_cwd_outside_workspace(fs):
    result = fs.execute("ls", cwd="../../etc")
    assert "error" in result
    assert "outside" in result["error"].lower()


def test_execute_cwd_not_exists(fs):
    result = fs.execute("ls", cwd="nonexistent")
    assert "error" in result


def test_execute_cwd_not_a_directory(fs, root):
    make_file(root, "f.txt")
    result = fs.execute("ls", cwd="f.txt")
    assert "error" in result


def test_execute_timeout(fs):
    result = fs.execute("sleep 10", timeout=1)
    assert "error" in result
    assert "timed out" in result["error"].lower()


def test_execute_clamped_timeout(fs):
    result = fs.execute("echo ok", timeout=9999)
    assert result["success"] is True
