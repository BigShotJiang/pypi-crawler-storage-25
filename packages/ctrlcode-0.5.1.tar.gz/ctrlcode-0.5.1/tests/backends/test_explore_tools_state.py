"""ExploreTools tests using StateBackend — no disk I/O required."""

import pytest

from ctrlcode.backends.state import StateBackend
from ctrlcode.tools.explore import ExploreTools


@pytest.fixture
def state() -> StateBackend:
    b = StateBackend()
    b._files = {
        "src/main.py": "def main():\n    pass\n",
        "src/utils.py": "import os\n",
        "README.md": "# Project\n",
        "src/lib/helper.py": "def helper():\n    return 42\n",
    }
    return b


@pytest.fixture
def tools(state) -> ExploreTools:
    return ExploreTools(workspace_root="/virtual", backend=state)


def test_search_files_py(tools):
    results = tools.search_files("**/*.py")
    assert "src/main.py" in results
    assert "src/utils.py" in results
    assert "README.md" not in results


def test_search_files_max_results(tools):
    results = tools.search_files("**/*.py", max_results=2)
    assert len(results) <= 2


def test_read_file_content(tools):
    result = tools.read_file("src/main.py")
    assert result["content"] == "def main():\n    pass\n"
    assert result["total_lines"] == 2


def test_read_file_with_start_line(tools):
    result = tools.read_file("src/main.py", start_line=2)
    assert result["content"] == "    pass\n"


def test_read_file_with_range(tools):
    result = tools.read_file("src/utils.py", start_line=1, end_line=1)
    assert result["content"] == "import os\n"


def test_read_file_missing(tools):
    result = tools.read_file("does_not_exist.py")
    assert "error" in result


def test_search_code(tools):
    results = tools.search_code("import")
    assert any(r["file"] == "src/utils.py" for r in results)


def test_list_directory(tools):
    result = tools.list_directory(".")
    assert any("src" in d for d in result["directories"])
    assert any(f["path"] == "README.md" for f in result["files"])


def test_get_file_info(tools):
    result = tools.get_file_info("src/main.py")
    assert result["is_file"] is True
    assert result["extension"] == ".py"


@pytest.mark.asyncio
async def test_write_file_creates(tools, state):
    result = await tools.write_file("new.py", "print('hello')\n")
    assert result["success"] is True
    assert state._files.get("new.py") == "print('hello')\n"


@pytest.mark.asyncio
async def test_write_file_refuses_overwrite(tools):
    result = await tools.write_file("src/main.py", "other")
    assert "error" in result
