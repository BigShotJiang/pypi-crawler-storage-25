"""Tests for YoloParsingDetector — lint_file, lint_directory, format_violation."""

from pathlib import Path

import pytest

from ctrlcode.linters.yolo_parsing import (
    YoloParsingDetector,
    Violation,
    format_violation,
    lint_directory,
    lint_file,
)


def write_py(tmp_path: Path, name: str, code: str) -> Path:
    p = tmp_path / name
    p.write_text(code)
    return p


# ---------------------------------------------------------------------------
# YoloParsingDetector — subscript detection
# ---------------------------------------------------------------------------

def _detect(code: str) -> list[Violation]:
    import ast
    tree = ast.parse(code)
    detector = YoloParsingDetector("test.py")
    detector.visit(tree)
    return detector.violations


def test_detects_plain_dict_subscript():
    code = 'x = data["key"]'
    violations = _detect(code)
    assert len(violations) >= 1
    assert "data" in violations[0].message


def test_no_violation_for_self_access():
    code = 'x = self["key"]'
    violations = _detect(code)
    assert violations == []


def test_no_violation_in_try_keyerror_block():
    code = """
try:
    x = data["key"]
except KeyError:
    x = None
"""
    violations = _detect(code)
    assert violations == []


def test_detects_nested_subscript():
    code = 'x = data["user"]["email"]'
    violations = _detect(code)
    # At least one violation for nested access
    assert len(violations) >= 1


def test_no_violation_for_class_constructor_kwarg():
    # When data is passed as a keyword to an uppercase-named class,
    # the detector considers it validated — no violation expected
    code = """
class Model:
    pass
validated = Model(data=data)
x = data["key"]
"""
    violations = _detect(code)
    # data is in validated_names after Model(data=data)
    assert violations == []


def test_violation_has_required_fields():
    code = 'x = data["name"]'
    violations = _detect(code)
    v = violations[0]
    assert v.severity == "warning"
    assert v.principle == "no-yolo-parsing"
    assert v.line > 0


def test_detects_pydantic_parse_obj_as_validated():
    code = """
result = Schema.parse_obj(payload)
x = payload["key"]
"""
    violations = _detect(code)
    # payload is validated via parse_obj, no violation
    assert violations == []


# ---------------------------------------------------------------------------
# lint_file
# ---------------------------------------------------------------------------

def test_lint_file_detects_violations(tmp_path):
    f = write_py(tmp_path, "bad.py", 'x = data["key"]\n')
    violations = lint_file(f)
    assert len(violations) >= 1


def test_lint_file_clean_code(tmp_path):
    f = write_py(tmp_path, "clean.py", "x = 1 + 2\n")
    violations = lint_file(f)
    assert violations == []


def test_lint_file_syntax_error_returns_empty(tmp_path):
    f = write_py(tmp_path, "broken.py", "def broken(:\n")
    violations = lint_file(f)
    assert violations == []


# ---------------------------------------------------------------------------
# lint_directory
# ---------------------------------------------------------------------------

def test_lint_directory_finds_violations(tmp_path):
    write_py(tmp_path, "a.py", 'x = data["k"]\n')
    write_py(tmp_path, "b.py", "y = 1\n")
    violations = list(lint_directory(tmp_path))
    assert len(violations) >= 1


def test_lint_directory_empty(tmp_path):
    violations = list(lint_directory(tmp_path))
    assert violations == []


# ---------------------------------------------------------------------------
# format_violation
# ---------------------------------------------------------------------------

def test_format_violation_contains_file_info():
    v = Violation(
        file="test.py",
        line=10,
        column=5,
        message="Accessing data[\"key\"]",
        severity="warning",
        fix_suggestion="use schema",
        principle="no-yolo-parsing",
    )
    formatted = format_violation(v)
    assert "test.py" in formatted
    assert "10" in formatted


def test_format_violation_contains_message():
    v = Violation(
        file="f.py", line=1, column=0,
        message="My violation message",
        severity="warning",
        fix_suggestion="fix it",
        principle="test",
    )
    formatted = format_violation(v)
    assert "My violation message" in formatted
