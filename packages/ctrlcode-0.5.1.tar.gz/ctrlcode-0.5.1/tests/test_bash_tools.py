"""Tests for BashTools — command execution, cwd resolution, security, timeouts."""

import pytest
from ctrlcode.tools.bash import BashTools


@pytest.fixture
def tools(tmp_path):
    return BashTools(tmp_path)


# ---------------------------------------------------------------------------
# Basic execution
# ---------------------------------------------------------------------------

def test_run_command_success(tools):
    result = tools.run_command("echo hello")
    assert result["success"] is True
    assert "hello" in result["stdout"]
    assert result["returncode"] == 0


def test_run_command_captures_stderr(tools):
    result = tools.run_command("echo error >&2")
    assert "error" in result["stderr"]


def test_run_command_nonzero_returncode(tools):
    result = tools.run_command("exit 1")
    assert result["success"] is False
    assert result["returncode"] == 1


def test_run_command_includes_command_in_result(tools):
    result = tools.run_command("echo test")
    assert result["command"] == "echo test"


# ---------------------------------------------------------------------------
# Working directory
# ---------------------------------------------------------------------------

def test_run_command_custom_cwd(tools, tmp_path):
    subdir = tmp_path / "subdir"
    subdir.mkdir()
    result = tools.run_command("pwd", cwd="subdir")
    assert result["success"] is True
    assert "subdir" in result["stdout"]


def test_run_command_cwd_outside_workspace_rejected(tools):
    result = tools.run_command("ls", cwd="../../etc")
    assert "error" in result
    assert "outside" in result["error"].lower()


def test_run_command_nonexistent_cwd_rejected(tools):
    result = tools.run_command("ls", cwd="no_such_dir")
    assert "error" in result


def test_run_command_default_cwd_is_workspace(tools, tmp_path):
    result = tools.run_command("pwd")
    assert str(tmp_path) in result["stdout"]


# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------

def test_timeout_clamped_to_max(tools):
    # timeout > 300 gets clamped; use a fast command so we don't actually wait
    result = tools.run_command("echo ok", timeout=9999)
    assert result["success"] is True


def test_timeout_clamped_to_min(tools):
    result = tools.run_command("echo ok", timeout=0)
    assert result["success"] is True


def test_command_timeout_returns_error(tools):
    result = tools.run_command("sleep 10", timeout=1)
    assert "error" in result
    assert "timed out" in result["error"].lower()


# ---------------------------------------------------------------------------
# Workspace root initialisation
# ---------------------------------------------------------------------------

def test_workspace_root_resolved(tmp_path):
    t = BashTools(tmp_path)
    assert t.workspace_root == tmp_path.resolve()
