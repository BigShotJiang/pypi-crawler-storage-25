"""Tests for StaticAnalyzer — complexity, quality score, subprocess error handling."""

import pytest
from ctrlcode.analysis.static import StaticAnalyzer


@pytest.fixture
def analyzer():
    return StaticAnalyzer()


CLEAN = "def add(a: int, b: int) -> int:\n    return a + b\n"
COMPLEX = "\n".join([
    "def process(data):",
    "    for item in data:",
    "        if item > 0:",
    "            for sub in item:",
    "                if sub:",
    "                    try:",
    "                        pass",
    "                    except Exception:",
    "                        pass",
])


# ---------------------------------------------------------------------------
# _calculate_complexity
# ---------------------------------------------------------------------------

def test_complexity_empty_code(analyzer):
    assert analyzer._calculate_complexity("") == 0.0


def test_complexity_simple_code(analyzer):
    score = analyzer._calculate_complexity(CLEAN)
    assert score >= 0


def test_complexity_higher_for_nested_code(analyzer):
    simple = analyzer._calculate_complexity(CLEAN)
    complex_ = analyzer._calculate_complexity(COMPLEX)
    assert complex_ > simple


def test_complexity_ignores_comments(analyzer):
    with_comments = "# this is a comment\n" * 20 + CLEAN
    without = CLEAN
    assert analyzer._calculate_complexity(with_comments) == analyzer._calculate_complexity(without)


# ---------------------------------------------------------------------------
# _calculate_quality
# ---------------------------------------------------------------------------

def test_quality_perfect_when_no_issues(analyzer):
    score = analyzer._calculate_quality(type_errors=0, lint_issues=0, complexity=0.0)
    assert score == 1.0


def test_quality_decreases_with_type_errors(analyzer):
    clean = analyzer._calculate_quality(0, 0, 0.0)
    with_errors = analyzer._calculate_quality(3, 0, 0.0)
    assert with_errors < clean


def test_quality_decreases_with_lint_issues(analyzer):
    clean = analyzer._calculate_quality(0, 0, 0.0)
    with_lint = analyzer._calculate_quality(0, 5, 0.0)
    assert with_lint < clean


def test_quality_decreases_with_complexity(analyzer):
    clean = analyzer._calculate_quality(0, 0, 0.0)
    complex_ = analyzer._calculate_quality(0, 0, 30.0)
    assert complex_ < clean


def test_quality_clamped_to_zero(analyzer):
    score = analyzer._calculate_quality(100, 100, 100.0)
    assert score == 0.0


def test_quality_never_exceeds_one(analyzer):
    score = analyzer._calculate_quality(0, 0, 0.0)
    assert score <= 1.0


# ---------------------------------------------------------------------------
# analyze — integration (runs ruff/mypy via subprocess)
# ---------------------------------------------------------------------------

def test_analyze_returns_result_with_variant_id(analyzer):
    result = analyzer.analyze(CLEAN, "test-v1")
    assert result.variant_id == "test-v1"


def test_analyze_quality_score_in_range(analyzer):
    result = analyzer.analyze(CLEAN, "v1")
    assert 0.0 <= result.quality_score <= 1.0


def test_analyze_complexity_nonnegative(analyzer):
    result = analyzer.analyze(CLEAN, "v1")
    assert result.complexity_score >= 0.0


def test_analyze_clean_code_high_quality(analyzer):
    result = analyzer.analyze(CLEAN, "v1")
    assert result.quality_score > 0.5
