"""Tests for FeedbackSynthesizer — synthesize, _find_consensus, _find_discrepancies, _calculate_quality."""

import pytest
from unittest.mock import MagicMock

from ctrlcode.analysis.synthesizer import AnalysisResult, Feedback, FeedbackSynthesizer
from ctrlcode.analysis.ast_diff import ASTDiff
from ctrlcode.analysis.semantic import SemanticDiff
from ctrlcode.analysis.static import StaticAnalysisResult


def make_test_result(passed: bool) -> MagicMock:
    t = MagicMock()
    t.passed = passed
    return t


def make_ast_diff(similarity: float = 0.9, has_syntax_error: bool = False) -> ASTDiff:
    return ASTDiff(
        variant_id="v",
        structural_similarity=similarity,
        function_count=1,
        class_count=0,
        import_count=0,
        complexity_estimate=1,
        differences=[],
        has_syntax_error=has_syntax_error,
        error_message="",
    )


def make_semantic_diff(
    agreement: float = 0.9,
    improvements: list[str] | None = None,
    concerns: list[str] | None = None,
) -> SemanticDiff:
    return SemanticDiff(
        variant_id="v",
        agreement_score=agreement,
        behavioral_differences=[],
        correctness_assessment="correct",
        edge_cases=[],
        improvements=improvements or [],
        concerns=concerns or [],
    )


def make_static(quality: float = 0.8, type_errors: int = 0, complexity: float = 5.0) -> StaticAnalysisResult:
    return StaticAnalysisResult(
        variant_id="v",
        type_errors=type_errors,
        lint_issues=0,
        quality_score=quality,
        complexity_score=complexity,
    )


def empty_analysis() -> AnalysisResult:
    return AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )


@pytest.fixture
def synth():
    return FeedbackSynthesizer()


# ---------------------------------------------------------------------------
# synthesize
# ---------------------------------------------------------------------------

def test_synthesize_returns_feedback(synth):
    result = synth.synthesize(empty_analysis(), 1, "do something")
    assert isinstance(result, Feedback)


def test_synthesize_contains_user_request_in_prompt(synth):
    result = synth.synthesize(empty_analysis(), 1, "my special request")
    assert "my special request" in result.improvement_prompt


def test_synthesize_includes_iteration(synth):
    result = synth.synthesize(empty_analysis(), 3, "req")
    assert "3" in result.improvement_prompt


# ---------------------------------------------------------------------------
# _find_consensus
# ---------------------------------------------------------------------------

def test_consensus_all_high_semantic_agreement(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[make_semantic_diff(0.9), make_semantic_diff(0.95)],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    consensus = synth._find_consensus(analysis)
    assert any("semantic agreement" in c.lower() for c in consensus)


def test_consensus_all_similar_structure(synth):
    analysis = AnalysisResult(
        structural_diffs=[make_ast_diff(0.9), make_ast_diff(0.95)],
        semantic_diffs=[],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    consensus = synth._find_consensus(analysis)
    assert any("structure" in c.lower() for c in consensus)


def test_consensus_all_tests_pass(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[make_test_result(True), make_test_result(True)],
        static_results=[],
        elapsed_time=0.0,
    )
    consensus = synth._find_consensus(analysis)
    assert any("pass tests" in c.lower() for c in consensus)


def test_consensus_common_improvements_included(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[
            make_semantic_diff(improvements=["Better naming"]),
            make_semantic_diff(improvements=["Better naming"]),
        ],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    consensus = synth._find_consensus(analysis)
    assert "Better naming" in consensus


def test_consensus_empty_analysis(synth):
    assert synth._find_consensus(empty_analysis()) == []


# ---------------------------------------------------------------------------
# _find_discrepancies
# ---------------------------------------------------------------------------

def test_discrepancies_failed_tests(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[make_test_result(True), make_test_result(False)],
        static_results=[],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("failed" in x.lower() for x in d)


def test_discrepancies_low_semantic_agreement(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[make_semantic_diff(0.3)],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("low semantic" in x.lower() for x in d)


def test_discrepancies_concerns_included(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[make_semantic_diff(concerns=["Missing tests"])],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("Missing tests" in x for x in d)


def test_discrepancies_syntax_errors(synth):
    analysis = AnalysisResult(
        structural_diffs=[make_ast_diff(has_syntax_error=True)],
        semantic_diffs=[],
        test_results=[],
        static_results=[],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("syntax" in x.lower() for x in d)


def test_discrepancies_high_type_errors(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[],
        static_results=[make_static(type_errors=5)],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("type errors" in x.lower() for x in d)


def test_discrepancies_high_complexity(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[],
        static_results=[make_static(complexity=25.0)],
        elapsed_time=0.0,
    )
    d = synth._find_discrepancies(analysis)
    assert any("complexity" in x.lower() for x in d)


# ---------------------------------------------------------------------------
# _calculate_quality
# ---------------------------------------------------------------------------

def test_quality_zero_when_empty(synth):
    assert synth._calculate_quality(empty_analysis()) == 0.0


def test_quality_uses_test_weight(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[make_test_result(True), make_test_result(True)],
        static_results=[],
        elapsed_time=0.0,
    )
    score = synth._calculate_quality(analysis)
    assert abs(score - 0.4) < 0.01  # 100% pass * 0.4 weight


def test_quality_clamped_to_1(synth):
    synth2 = FeedbackSynthesizer(weights={"tests": 2.0, "static": 0.0, "semantic": 0.0})
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[make_test_result(True)],
        static_results=[],
        elapsed_time=0.0,
    )
    assert synth2._calculate_quality(analysis) <= 1.0


def test_quality_clamped_to_0(synth):
    analysis = AnalysisResult(
        structural_diffs=[],
        semantic_diffs=[],
        test_results=[make_test_result(False)],
        static_results=[],
        elapsed_time=0.0,
    )
    assert synth._calculate_quality(analysis) >= 0.0
