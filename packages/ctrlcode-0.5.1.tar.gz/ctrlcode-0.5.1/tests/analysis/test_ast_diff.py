"""Tests for ASTAnalyzer — compare, _analyze_ast, similarity, differences."""

import pytest
from ctrlcode.analysis.ast_diff import ASTAnalyzer, ASTDiff


@pytest.fixture
def analyzer():
    return ASTAnalyzer()


SIMPLE = "def foo(): pass"
WITH_CLASS = "class Bar:\n    def method(self): pass"
WITH_IMPORT = "import os\nfrom pathlib import Path"
SYNTAX_ERROR = "def broken(:"


# ---------------------------------------------------------------------------
# compare — happy path
# ---------------------------------------------------------------------------

def test_compare_identical_code_similarity_1(analyzer):
    result = analyzer.compare(SIMPLE, SIMPLE, "v1")
    assert result.structural_similarity == 1.0
    assert not result.has_syntax_error


def test_compare_counts_functions(analyzer):
    code = "def a(): pass\ndef b(): pass"
    result = analyzer.compare("", code, "v1")
    assert result.function_count == 2


def test_compare_counts_classes(analyzer):
    result = analyzer.compare("", WITH_CLASS, "v1")
    assert result.class_count == 1


def test_compare_counts_imports(analyzer):
    result = analyzer.compare("", WITH_IMPORT, "v1")
    assert result.import_count == 2


def test_compare_counts_complexity(analyzer):
    code = "for i in range(10):\n    if i > 5:\n        pass"
    result = analyzer.compare("", code, "v1")
    assert result.complexity_estimate >= 2  # loop + conditional


def test_compare_finds_differences(analyzer):
    baseline = "def foo(): pass"
    variant = "def foo(): pass\ndef bar(): pass"
    result = analyzer.compare(baseline, variant, "v1")
    assert any("functions" in d for d in result.differences)


def test_compare_no_differences_when_same(analyzer):
    result = analyzer.compare(SIMPLE, SIMPLE, "v1")
    assert result.differences == []


def test_compare_variant_id_preserved(analyzer):
    result = analyzer.compare(SIMPLE, SIMPLE, "my-variant-42")
    assert result.variant_id == "my-variant-42"


# ---------------------------------------------------------------------------
# compare — syntax errors
# ---------------------------------------------------------------------------

def test_baseline_syntax_error(analyzer):
    result = analyzer.compare(SYNTAX_ERROR, SIMPLE, "v1")
    assert result.has_syntax_error
    assert "Baseline syntax error" in result.error_message


def test_variant_syntax_error(analyzer):
    result = analyzer.compare(SIMPLE, SYNTAX_ERROR, "v1")
    assert result.has_syntax_error
    assert "Variant syntax error" in result.error_message


# ---------------------------------------------------------------------------
# _calculate_similarity
# ---------------------------------------------------------------------------

def test_similarity_empty_both_returns_1(analyzer):
    result = analyzer.compare("", "", "v1")
    assert result.structural_similarity == 1.0


def test_similarity_between_0_and_1(analyzer):
    result = analyzer.compare(SIMPLE, WITH_CLASS, "v1")
    assert 0.0 <= result.structural_similarity <= 1.0


def test_similarity_decreases_with_divergence(analyzer):
    close = analyzer.compare(SIMPLE, "def foo(): return 1", "v1")
    far = analyzer.compare(SIMPLE, "\n".join(f"def f{i}(): pass" for i in range(20)), "v2")
    assert close.structural_similarity >= far.structural_similarity


# ---------------------------------------------------------------------------
# _analyze_ast
# ---------------------------------------------------------------------------

def test_analyze_try_block_counted(analyzer):
    code = "try:\n    pass\nexcept Exception:\n    pass"
    result = analyzer.compare("", code, "v1")
    assert result.complexity_estimate >= 1
