"""Tests for SemanticAnalyzer — _parse_analysis, _build_comparison_prompt, compare."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from ctrlcode.analysis.semantic import SemanticAnalyzer, SemanticDiff


@pytest.fixture
def analyzer():
    provider = MagicMock()
    return SemanticAnalyzer(provider)


# ---------------------------------------------------------------------------
# _build_comparison_prompt
# ---------------------------------------------------------------------------

def test_build_prompt_contains_baseline(analyzer):
    prompt = analyzer._build_comparison_prompt("def foo(): pass", "def bar(): pass", "add foo")
    assert "def foo(): pass" in prompt


def test_build_prompt_contains_variant(analyzer):
    prompt = analyzer._build_comparison_prompt("def foo(): pass", "def bar(): pass", "add foo")
    assert "def bar(): pass" in prompt


def test_build_prompt_contains_user_request(analyzer):
    prompt = analyzer._build_comparison_prompt("a", "b", "my user request")
    assert "my user request" in prompt


def test_build_prompt_returns_string(analyzer):
    result = analyzer._build_comparison_prompt("a", "b", "request")
    assert isinstance(result, str)
    assert len(result) > 0


# ---------------------------------------------------------------------------
# _parse_analysis — structured response
# ---------------------------------------------------------------------------

FULL_RESPONSE = """SCORE: 8
DIFFERENCES:
- Uses early return instead of nested if
- Better variable naming
CORRECTNESS: correct
REASON: Both implementations produce equivalent results.
EDGE_CASES:
- Empty input not handled
- None input raises TypeError
IMPROVEMENTS:
- More readable code
CONCERNS:
- Missing type hints
"""


def test_parse_analysis_score(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert abs(result.agreement_score - 0.8) < 0.01


def test_parse_analysis_correctness(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert result.correctness_assessment == "correct"


def test_parse_analysis_differences(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert len(result.behavioral_differences) == 2
    assert any("early return" in d for d in result.behavioral_differences)


def test_parse_analysis_edge_cases(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert len(result.edge_cases) == 2


def test_parse_analysis_improvements(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert "More readable code" in result.improvements


def test_parse_analysis_concerns(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert "Missing type hints" in result.concerns


def test_parse_analysis_variant_id(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "my-variant")
    assert result.variant_id == "my-variant"


def test_parse_analysis_empty_text_defaults(analyzer):
    result = analyzer._parse_analysis("", "v0")
    assert result.agreement_score == 5.0  # Default 5.0 (not normalized when no SCORE line)
    assert result.correctness_assessment == "uncertain"
    assert result.behavioral_differences == []


def test_parse_analysis_malformed_score_uses_default(analyzer):
    result = analyzer._parse_analysis("SCORE: not_a_number\n", "v1")
    assert result.agreement_score == 5.0  # unchanged default on parse failure


def test_parse_analysis_returns_semantic_diff(analyzer):
    result = analyzer._parse_analysis(FULL_RESPONSE, "v1")
    assert isinstance(result, SemanticDiff)


# ---------------------------------------------------------------------------
# SemanticDiff post_init
# ---------------------------------------------------------------------------

def test_semantic_diff_post_init_none_lists():
    diff = SemanticDiff(
        variant_id="v",
        agreement_score=0.5,
        behavioral_differences=None,
        correctness_assessment="uncertain",
        edge_cases=None,
        improvements=None,
        concerns=None,
    )
    assert diff.behavioral_differences == []
    assert diff.edge_cases == []
    assert diff.improvements == []
    assert diff.concerns == []


# ---------------------------------------------------------------------------
# compare — mocked provider
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_compare_returns_semantic_diff():
    provider = MagicMock()
    provider.generate = AsyncMock(return_value={"text": FULL_RESPONSE})
    analyzer = SemanticAnalyzer(provider)

    result = await analyzer.compare("def foo(): pass", "def bar(): pass", "v1", "add function")

    assert isinstance(result, SemanticDiff)
    assert result.variant_id == "v1"


@pytest.mark.anyio
async def test_compare_passes_temperature_to_provider():
    provider = MagicMock()
    provider.generate = AsyncMock(return_value={"text": "SCORE: 5\n"})
    analyzer = SemanticAnalyzer(provider)

    await analyzer.compare("a", "b", "v1", "request")

    provider.generate.assert_called_once()
    _, kwargs = provider.generate.call_args
    assert kwargs.get("temperature") == 0.3
