"""Tests for TestExecutor — _parse_pytest_output, _generate_basic_tests, TestResult."""

import pytest

from ctrlcode.analysis.tests import TestExecutor, TestResult


@pytest.fixture
def executor():
    return TestExecutor()


# ---------------------------------------------------------------------------
# TestResult — pass_rate
# ---------------------------------------------------------------------------

def test_pass_rate_zero_when_no_tests():
    r = TestResult(variant_id="v", passed=True, total_tests=0, passed_tests=0)
    assert r.pass_rate == 0.0


def test_pass_rate_all_passed():
    r = TestResult(variant_id="v", passed=True, total_tests=5, passed_tests=5)
    assert r.pass_rate == 1.0


def test_pass_rate_partial():
    r = TestResult(variant_id="v", passed=False, total_tests=4, passed_tests=3)
    assert abs(r.pass_rate - 0.75) < 0.01


# ---------------------------------------------------------------------------
# _parse_pytest_output
# ---------------------------------------------------------------------------

def test_parse_passing_output(executor):
    stdout = "3 passed, 0 failed in 0.12s"
    result = executor._parse_pytest_output("v1", 0, stdout, "")
    assert result.passed is True
    assert result.passed_tests == 3
    assert result.variant_id == "v1"


def test_parse_failing_output(executor):
    stdout = "1 passed, 2 failed in 0.50s\nFAILED test_foo.py::test_bar"
    result = executor._parse_pytest_output("v2", 1, stdout, "")
    assert result.passed is False
    assert result.failed_tests == 2
    assert any("FAILED" in e for e in result.errors)


def test_parse_empty_output_defaults(executor):
    result = executor._parse_pytest_output("v0", 0, "", "")
    assert result.passed is True
    assert result.total_tests == 0


def test_parse_captures_execution_time(executor):
    stdout = "2 passed in 1.23s"
    result = executor._parse_pytest_output("v1", 0, stdout, "")
    assert abs(result.execution_time - 1.23) < 0.01


def test_parse_combines_stdout_stderr(executor):
    result = executor._parse_pytest_output("v1", 1, "some output", "error detail")
    assert "some output" in result.output
    assert "error detail" in result.output


def test_parse_no_errors_when_passed(executor):
    stdout = "1 passed in 0.5s"
    result = executor._parse_pytest_output("v1", 0, stdout, "")
    assert result.errors == []


def test_parse_extracts_error_lines(executor):
    stdout = "0 passed, 1 failed\nFAILED test_x.py::test_y\nERROR foo"
    result = executor._parse_pytest_output("v1", 1, stdout, "")
    assert len(result.errors) >= 1


# ---------------------------------------------------------------------------
# _generate_basic_tests
# ---------------------------------------------------------------------------

def test_generate_basic_tests_returns_string(executor):
    tests = executor._generate_basic_tests("def foo(): pass")
    assert isinstance(tests, str)
    assert len(tests) > 0


def test_generate_basic_tests_has_test_functions(executor):
    tests = executor._generate_basic_tests("x = 1")
    assert "def test_" in tests
