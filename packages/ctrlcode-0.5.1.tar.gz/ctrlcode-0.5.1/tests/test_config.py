"""Tests for Config.load, _validate_config_permissions, _save_api_key."""

import os
import stat
from pathlib import Path
from unittest.mock import patch

import pytest

from ctrlcode.config import Config, ProviderConfig, SecurityConfig


# ---------------------------------------------------------------------------
# Config.load — no file returns defaults
# ---------------------------------------------------------------------------

def test_load_no_file_returns_defaults(tmp_path):
    config_file = tmp_path / "config.toml"
    result = Config.load(config_file)
    assert isinstance(result, Config)
    assert result.anthropic is None
    assert result.openai is None


def test_load_default_server_config(tmp_path):
    config_file = tmp_path / "config.toml"
    result = Config.load(config_file)
    assert result.server.host == "127.0.0.1"
    assert result.server.port == 8765


# ---------------------------------------------------------------------------
# Config.load — TOML parsing
# ---------------------------------------------------------------------------

def _write_toml(path: Path, content: str) -> None:
    path.write_text(content)
    path.chmod(0o600)


def test_load_server_section(tmp_path):
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\nhost = "0.0.0.0"\nport = 9000\napi_key = "mykey"\n')
    result = Config.load(cfg)
    assert result.server.host == "0.0.0.0"
    assert result.server.port == 9000
    assert result.server.api_key == "mykey"


def test_load_anthropic_provider(tmp_path, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\napi_key = "s"\n[providers.anthropic]\napi_key = "ak"\nmodel = "claude-3"\n')
    result = Config.load(cfg)
    assert isinstance(result.anthropic, ProviderConfig)
    assert result.anthropic.api_key == "ak"
    assert result.anthropic.model == "claude-3"


def test_load_anthropic_api_key_from_env(tmp_path, monkeypatch):
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\napi_key = "s"\n[providers.anthropic]\nmodel = "claude-3"\n')
    monkeypatch.setenv("ANTHROPIC_API_KEY", "env-key")
    result = Config.load(cfg)
    assert result.anthropic is not None
    assert result.anthropic.api_key == "env-key"


def test_load_openai_provider(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\napi_key = "s"\n[providers.openai]\napi_key = "oaik"\nmodel = "gpt-4"\n')
    result = Config.load(cfg)
    assert isinstance(result.openai, ProviderConfig)
    assert result.openai.model == "gpt-4"


def test_load_context_section(tmp_path):
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\napi_key = "s"\n[context]\nprune_protect = 10000\ndefault_limit = 50000\n')
    result = Config.load(cfg)
    assert result.context.prune_protect == 10000
    assert result.context.default_limit == 50000



def test_load_generates_api_key_when_missing(tmp_path):
    cfg = tmp_path / "config.toml"
    _write_toml(cfg, '[server]\nhost = "127.0.0.1"\n')
    result = Config.load(cfg)
    # api_key should have been generated
    assert result.server.api_key is not None
    assert len(result.server.api_key) > 10


def test_load_skills_directory(tmp_path):
    cfg = tmp_path / "config.toml"
    skills_dir = tmp_path / "skills"
    skills_dir.mkdir()
    _write_toml(cfg, f'[server]\napi_key = "s"\n[skills]\ndirectory = "{skills_dir}"\n')
    result = Config.load(cfg)
    assert result.skills_directory == skills_dir


def test_load_workspace_root_from_config(tmp_path):
    cfg = tmp_path / "config.toml"
    ws = tmp_path / "workspace"
    ws.mkdir()
    _write_toml(cfg, f'[server]\napi_key = "s"\n[workspace]\nroot = "{ws}"\n')
    result = Config.load(cfg)
    assert result.workspace_root == ws


# ---------------------------------------------------------------------------
# _validate_config_permissions
# ---------------------------------------------------------------------------

@pytest.mark.skipif(os.name == "nt", reason="Unix permissions only")
def test_validate_permissions_world_writable_raises(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("")
    cfg.chmod(0o666)
    with pytest.raises(ValueError, match="world-writable"):
        Config._validate_config_permissions(cfg)


@pytest.mark.skipif(os.name == "nt", reason="Unix permissions only")
def test_validate_permissions_group_writable_raises(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("")
    cfg.chmod(0o660)
    with pytest.raises(ValueError, match="group-writable"):
        Config._validate_config_permissions(cfg)


@pytest.mark.skipif(os.name == "nt", reason="Unix permissions only")
def test_validate_permissions_600_ok(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("")
    cfg.chmod(0o600)
    Config._validate_config_permissions(cfg)  # should not raise


# ---------------------------------------------------------------------------
# _save_api_key
# ---------------------------------------------------------------------------

@pytest.mark.skipif(os.name == "nt", reason="Unix permissions only")
def test_save_api_key_writes_key(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text('[server]\nhost = "127.0.0.1"\n')
    cfg.chmod(0o600)
    Config._save_api_key(cfg, "test-generated-key")
    content = cfg.read_text()
    assert "test-generated-key" in content


@pytest.mark.skipif(os.name == "nt", reason="Unix permissions only")
def test_save_api_key_sets_secure_permissions(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("")
    cfg.chmod(0o644)
    Config._save_api_key(cfg, "mykey")
    mode = cfg.stat().st_mode
    assert not (mode & stat.S_IWOTH)
    assert not (mode & stat.S_IWGRP)


def test_save_api_key_creates_server_section_if_missing(tmp_path):
    cfg = tmp_path / "config.toml"
    cfg.write_text("")
    Config._save_api_key(cfg, "new-key")
    content = cfg.read_text()
    assert "new-key" in content
    assert "[server]" in content
