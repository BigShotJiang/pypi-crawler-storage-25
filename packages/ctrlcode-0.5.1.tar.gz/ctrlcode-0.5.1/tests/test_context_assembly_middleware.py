"""Tests for ContextAssemblyMiddleware."""

import asyncio
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from ctrlcode.session.middleware.context_assembly import ContextAssemblyMiddleware
from ctrlcode.session.middleware.base import TurnContext
from ctrlcode.skills.loader import Skill
from ctrlcode.skills.registry import SkillRegistry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_session():
    session = MagicMock()
    session.context_before_turn = 0
    return session


def _make_ctx(assembler=None, user_input="hello"):
    ctx = TurnContext(session=_make_session(), user_input=user_input)
    if assembler is not None:
        ctx.extra["assembler"] = assembler
    return ctx


class _FakeAssembler:
    async def assemble(self, query: str, budget_tokens: int) -> str:
        return ""


def _make_mw(**kwargs):
    defaults = dict(
        base_prompt="You are helpful.",
        agent_instructions="",
        verification_commands=[],
        ctrlcode_dir=Path("/tmp/ctrlcode"),
        workspace_root=None,
        context_limit=200_000,
    )
    defaults.update(kwargs)
    return ContextAssemblyMiddleware(**defaults)


def _run(coro):
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# __init__
# ---------------------------------------------------------------------------

def test_init_stores_all_fields():
    reg = SkillRegistry()
    mw = _make_mw(skill_registry=reg)
    assert mw._skill_registry is reg
    assert mw._base_prompt == "You are helpful."
    assert mw._context_limit == 200_000


def test_init_skill_registry_defaults_to_none():
    mw = _make_mw()
    assert mw._skill_registry is None


# ---------------------------------------------------------------------------
# before_turn — no assembler
# ---------------------------------------------------------------------------

def test_before_turn_no_assembler_skips_build():
    mw = _make_mw()
    ctx = _make_ctx(assembler=None)
    _run(mw.before_turn(ctx))
    assert ctx.system_prompt_msg is None


# ---------------------------------------------------------------------------
# before_turn — with assembler
# ---------------------------------------------------------------------------

def test_before_turn_sets_system_prompt_msg():
    mw = _make_mw()
    ctx = _make_ctx(assembler=_FakeAssembler())
    _run(mw.before_turn(ctx))
    assert ctx.system_prompt_msg is not None
    assert ctx.system_prompt_msg["role"] == "system"


def test_before_turn_injects_skills_when_registry_populated():
    reg = SkillRegistry()
    reg.register(Skill(name="commit", instructions="Commit it", description="Create a commit"))
    mw = _make_mw(skill_registry=reg)
    ctx = _make_ctx(assembler=_FakeAssembler())
    _run(mw.before_turn(ctx))
    assert "<skills>" in ctx.system_prompt_msg["content"]


def test_before_turn_swallows_build_exception(tmp_path):
    class _BadAssembler:
        async def assemble(self, query, budget_tokens):
            raise RuntimeError("boom")

    mw = _make_mw(ctrlcode_dir=tmp_path)
    ctx = _make_ctx(assembler=_BadAssembler())
    # Should not raise (assembler error is caught inside build_system_prompt)
    _run(mw.before_turn(ctx))


def test_before_turn_swallows_prompt_build_crash():
    """Cover the outer except in before_turn when build_system_prompt itself raises."""
    class _CrashRegistry:
        def render_system_prompt_block(self):
            raise RuntimeError("registry exploded")

    mw = _make_mw(skill_registry=_CrashRegistry())
    ctx = _make_ctx(assembler=_FakeAssembler())
    # Should not raise; exception is swallowed and logged
    _run(mw.before_turn(ctx))
    assert ctx.system_prompt_msg is None
