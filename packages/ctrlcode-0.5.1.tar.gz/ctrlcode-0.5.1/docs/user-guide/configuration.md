# Configuration Guide

Complete reference for ctrl+code configuration.

## Config File Location

Platform-specific paths:
- **Linux**: `~/.config/ctrlcode/config.toml`
- **macOS**: `~/Library/Application Support/ctrlcode/config.toml`
- **Windows**: `%APPDATA%\ctrlcode\config.toml`

Override with environment variable:
```bash
export CTRLCODE_CONFIG_DIR="/custom/path"
```

## Complete config.toml Reference

```toml
# Ctrl+Code Configuration

[server]
host = "127.0.0.1"                    # Server bind address
port = 8765                           # Server port
api_key = "auto-generated-32-chars"   # Auto-generated on first run

[providers.anthropic]
model = "claude-sonnet-4-5-20250929"  # Default: claude-sonnet-4-5-20250929
# api_key loaded from ANTHROPIC_API_KEY environment variable
# Or set directly (not recommended): api_key = "sk-ant-..."
# base_url = "https://api.anthropic.com"  # Optional: custom API endpoint

[providers.openai]
model = "gpt-4"                       # Default: gpt-4
# api_key loaded from OPENAI_API_KEY environment variable
# Or set directly (not recommended): api_key = "sk-..."
# base_url = "https://api.openai.com/v1"  # Optional: custom API endpoint

[context]
prune_protect = 40000                 # Tokens to protect from pruning (default: 40000)
default_limit = 200000                # Max context window size (default: 200000)

[security]
max_input_length = 200000             # Max input chars (200K default, -1 = unlimited)
rate_limit_enabled = true             # Enable rate limiting (default: true)
rate_limit_window_seconds = 60.0     # Rate limit window in seconds (default: 60)
rate_limit_max_requests = 30          # Max requests per window (default: 30)

# MCP server configuration
[[mcp.servers]]
name = "filesystem"
command = ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
env = { "DEBUG" = "mcp:*" }           # Optional environment variables

[[mcp.servers]]
name = "custom-server"
command = ["~/.config/ctrlcode/mcp-servers/my-server"]
env = {}

[skills]
directory = "~/.config/ctrlcode/skills"  # Custom skills directory (optional)

[workspace]
root = "/path/to/project"             # Override workspace root (default: cwd)
```

## Section Details

### [server]

Controls server network settings and authentication.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `host` | string | `"127.0.0.1"` | Server bind address (use `0.0.0.0` for external access) |
| `port` | integer | `8765` | Server port |
| `api_key` | string | auto-generated | Authentication key for TUI ↔ server (32-char secure random) |

**Security note**: `api_key` is auto-generated on first run and saved with 600 permissions. Only regenerate if compromised.

### [providers]

Configure LLM providers. At least one required.

#### Anthropic (Claude)

```toml
[providers.anthropic]
model = "claude-sonnet-4-5-20250929"
# base_url = "https://api.anthropic.com"  # Optional
```

- **API Key**: From `ANTHROPIC_API_KEY` env var (preferred) or `api_key` field
- **Default model**: `claude-sonnet-4-5-20250929`
- **Custom endpoint**: Use `base_url` for proxies/custom deployments

#### OpenAI (GPT)

```toml
[providers.openai]
model = "gpt-4"
# base_url = "https://api.openai.com/v1"  # Optional
```

- **API Key**: From `OPENAI_API_KEY` env var (preferred) or `api_key` field
- **Default model**: `gpt-4`
- **Custom endpoint**: Use `base_url` for proxies/Azure OpenAI

### [context]

Context window management settings.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `prune_protect` | integer | `40000` | Tokens protected from automatic pruning |
| `default_limit` | integer | `200000` | Maximum context window size in tokens |

When context approaches `default_limit`, oldest messages are pruned except the most recent `prune_protect` tokens.

### [security]

Security and rate limiting controls.

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `max_input_length` | integer | `200000` | Max input characters (`-1` = unlimited) |
| `rate_limit_enabled` | boolean | `true` | Enable request rate limiting |
| `rate_limit_window_seconds` | float | `60.0` | Rate limit time window |
| `rate_limit_max_requests` | integer | `30` | Max requests per window per session |

**Example - Disable rate limiting:**
```toml
[security]
rate_limit_enabled = false
```

**Example - Stricter limits:**
```toml
[security]
max_input_length = 50000
rate_limit_max_requests = 10
```

### [[mcp.servers]]

MCP (Model Context Protocol) server configuration. Array of server definitions.

```toml
[[mcp.servers]]
name = "server-name"
command = ["executable", "arg1", "arg2"]
env = { "VAR" = "value" }
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | yes | Unique server identifier |
| `command` | array | yes | Command and arguments |
| `env` | table | no | Environment variables |

**Security**: Executables must be in trusted locations:
- Virtual environment: `{venv}/bin/` or `{venv}/Scripts/`
- User installs: `~/.local/bin/`
- System: `/usr/local/bin/`, `/usr/bin/`
- Custom: `~/.config/ctrlcode/mcp-servers/`

**Example - Filesystem server:**
```toml
[[mcp.servers]]
name = "filesystem"
command = ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
```

**Example - Custom server:**
```toml
[[mcp.servers]]
name = "my-tools"
command = ["~/.config/ctrlcode/mcp-servers/my-server", "--port", "9000"]
env = { "DEBUG" = "1", "LOG_LEVEL" = "info" }
```

### [skills]

Custom slash command directory.

```toml
[skills]
directory = "~/.config/ctrlcode/skills"
```

Skills are Python modules that define custom `/slash` commands. See [Skills Guide](../developer-guide/skills.md) for details.

### [workspace]

Override default workspace root.

```toml
[workspace]
root = "/path/to/project"
```

Default: Current working directory (`cwd`)

## AGENT.md Files

Customize agent behavior with markdown instruction files, loaded hierarchically:

1. **Global**: `~/.config/ctrlcode/AGENT.md` - Your personal defaults
2. **Project**: `<workspace>/AGENT.md` - Project-specific instructions

Instructions are injected into the system prompt.

**Example global AGENT.md:**
```markdown
# My Coding Preferences

## Commit Messages
- Always use semantic commit format
- Include ticket numbers

## Code Style
- Prefer async/await over callbacks
- Max line length: 100 chars

## Testing
- Write tests for all new features
- Use pytest for Python
```

**Example project AGENT.md:**
```markdown
# MyProject

## Architecture
- Frontend: React + TypeScript + Vite
- Backend: FastAPI + PostgreSQL
- Use Tailwind for styling

## Conventions
- API routes: `/api/v1/...`
- Component names: PascalCase
- Test files: `*.test.ts`

## Database
- Migrations in `migrations/`
- Use Alembic for schema changes
```

## Environment Variables

Override config paths:

```bash
# Config directory
export CTRLCODE_CONFIG_DIR="$HOME/.custom/config"

# Data directory (sessions, logs)
export CTRLCODE_DATA_DIR="$HOME/.custom/data"

# Cache directory (conversations)
export CTRLCODE_CACHE_DIR="$HOME/.custom/cache"
```

Provider API keys:

```bash
# Preferred method (more secure than storing in config)
export ANTHROPIC_API_KEY="sk-ant-..."
export OPENAI_API_KEY="sk-..."
```

## Minimal Config

Minimal working config.toml:

```toml
# Ctrl+Code will auto-generate api_key on first run
# Provider API keys loaded from environment variables
```

That's it! Everything else uses defaults. Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` and run `ctrlcode`.

## Advanced Examples

### Remote Server Access

**Warning**: Only expose to trusted networks!

```toml
[server]
host = "0.0.0.0"  # Listen on all interfaces
port = 8765

# Stricter security for remote access
[security]
rate_limit_max_requests = 10
max_input_length = 50000
```

Then configure TUI to connect remotely:
```bash
ctrlcode --server http://remote-host:8765
```

### Multi-Provider Setup

```toml
[providers.anthropic]
model = "claude-sonnet-4-5-20250929"

[providers.openai]
model = "gpt-4"
base_url = "https://api.openai.com/v1"
```

Server preferentially uses Anthropic if both configured.

### Development/Testing Config

```toml
[server]
port = 9999  # Non-default port

[security]
rate_limit_enabled = false  # No rate limiting in dev
max_input_length = -1       # Unlimited input

[context]
default_limit = 100000  # Smaller for faster testing
```

## See Also

- [Getting Started](getting-started.md) - Installation and first run
- [Security Guide](security.md) - Security best practices
- [MCP Servers](../developer-guide/mcp-servers.md) - Writing MCP servers
- [Skills](../developer-guide/skills.md) - Creating custom slash commands
