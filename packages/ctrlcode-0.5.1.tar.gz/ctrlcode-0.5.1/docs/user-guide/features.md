# Features Guide

Complete reference for ctrl+code features and capabilities.

## Slash Commands

Built-in commands invoked with `/` prefix in the TUI.

### Core Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available slash commands |
| `/exit`, `/quit` | Exit the application |
| `/clear` | Clear chat history (local display only, session persists) |

### Session Management

| Command | Description |
|---------|-------------|
| `/compact` | Compact conversation history (remove redundancy, preserve context) |
| `/summarize` | Generate conversation summary *(not yet implemented)* |
| `/stats` | Show context statistics (token usage, message count) |

### Task Management

| Command | Description |
|---------|-------------|
| `/todos` | Open todo list modal (create, update, track tasks) |

### Multi-Agent Mode

| Command | Description |
|---------|-------------|
| `/agents` | Show active agents panel (Ctrl+A shortcut) |
| `/tasks` | Show task dependency graph (Ctrl+T shortcut) |
| `/review` | Show review feedback from agents (Ctrl+R shortcut) |

### Observability

| Command | Description |
|---------|-------------|
| `/status` | Open event bus viewer (real-time system events) |
| `/metrics` | Show observability results (performance, errors) |
| `/details` | Toggle continuation exploration details visibility |

## Skills System

Extend ctrl+code with slash-command skills. Skills are Markdown-based (`SKILL.md` files inside named folders) and are automatically injected into every turn's system prompt so the agent can apply them contextually — even without an explicit `/` invocation.

### Built-in Skills

Shipped in `src/ctrlcode/skills/builtin/`:

| Skill | Description |
|-------|-------------|
| `/commit` | Analyze diff, stage files, and write a semantic git commit message |
| `/refactor` | Refactor a function or module for clarity and maintainability (requires target argument) |
| `/test` | Run test suite, analyze failures, and suggest missing coverage |
| `/review` | Review current git diff for quality, bugs, and security issues |
| `/docs` | Document a class or function (requires target argument) |
| `/debug-session` | Structured debug workflow: reproduce → isolate → fix → verify |
| `/plan` | Write a `tasks/todo.md` plan with checkboxes before implementing anything |
| `/pr` | Summarize commits, push branch, and open a GitHub pull request |

### Skills Discovery Hierarchy

Skills are loaded from multiple locations. Later entries win (higher priority):

1. `{package}/skills/builtin/` — shipped with ctrlcode (lowest priority)
2. `~/.config/ctrlcode/skills/` — global user skills
3. `{workspace_root}/.ctrlcode/skills/` — project-level skills
4. `config.skills_directory` — explicit config override (highest priority)

Project-level skills (`.ctrlcode/skills/`) override global skills of the same name, which in turn override built-ins.

### SKILL.md Format

Each skill lives in its own folder with a `SKILL.md` file. An optional YAML frontmatter block carries metadata; the Markdown body is the skill's instructions and examples.

```markdown
---
name: refactor
description: Refactor a function or module for clarity and maintainability
license: builtin
requires_args: true
---

# Refactor

## Instructions
Refactor the target for improved readability, reduced duplication, and
maintainability. Preserve all existing behaviour.

## Examples

```
/refactor src/foo.py
```
```

**Frontmatter fields**:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | yes | Slash command name (invoked as `/<name>`) |
| `description` | string | no | Human-readable description (shown in `/help`) |
| `license` | string | no | `builtin` for shipped skills, omit for custom |
| `requires_args` | boolean | no | Whether skill requires an argument (default: false) |

### Creating Custom Skills

**Global skill** (available in every workspace):

```
~/.config/ctrlcode/skills/myskill/SKILL.md
```

**Project-local skill** (only available in this workspace):

```
.ctrlcode/skills/myskill/SKILL.md
```

**Minimal example** (`~/.config/ctrlcode/skills/explain/SKILL.md`):

```markdown
---
name: explain
description: Explain a concept in plain language
requires_args: true
---

# Explain

## Instructions
Explain the following concept clearly: {args}

Cover what it is, why it matters, common use cases, and pitfalls.

## Examples

```
/explain async/await
/explain dependency injection
```
```

### Using Skills

```bash
# Built-in, no argument
/commit

# Built-in, with argument
/refactor src/mymodule.py

# Custom skill, with argument
/explain context managers
```

Skills are loaded at server startup. To pick up new skills, restart the server (or use an explicit config override path and restart).

## Tools

Ctrl+code provides tools for file operations, code exploration, and system interaction.

### File Operations

- **read_file**: Read file contents from workspace
- **write_file**: Create or overwrite files
- **update_file**: Search-and-replace or regex-based edits (with ReDoS protection)
- **list_directory**: List files in directory

**Security**: All file operations restricted to workspace root (path traversal prevention)

### Code Exploration

- **search_files**: Glob pattern search for files across workspace
- **search_code**: Regex search across file contents

### Bash Execution

- **run_command**: Execute shell commands in workspace
  - Working directory preserved across commands
  - Timeout protection (default: 30s, configurable)
  - Output length limits (prevents memory issues)

**Security**: Commands run in workspace context, no arbitrary path execution

### Web Fetching

- **fetch**: Make HTTP requests (GET/POST/PUT/DELETE) and fetch web pages

### Observability

- **query_logs**: Query structured server logs
- **query_metrics**: Query performance and error metrics

### Todo Management

- **todo_write** (alias: `task_write`): Create new task
- **todo_update** (alias: `task_update`): Update task status/description
- **todo_list** (alias: `task_list`): List all tasks

Tasks are tracked in session and can be displayed via `/todos` modal.

### MCP Tools

Model Context Protocol servers extend tool capabilities:

```toml
[[mcp.servers]]
name = "filesystem"
command = ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
env = { "DEBUG" = "mcp:*" }
```

MCP servers provide additional tools loaded dynamically at runtime.

**Security**: Executables must be in trusted paths (see [Security Guide](security.md))

## TUI Features

Textual-based terminal user interface with advanced capabilities.

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Enter` | Submit message |
| `Ctrl+C` | Cancel current operation |
| `Ctrl+Q` | Quit application |
| `Ctrl+A` | Toggle agents panel |
| `Ctrl+T` | Toggle task graph |
| `Ctrl+R` | Toggle review feedback |
| `Ctrl+S` | Toggle event status |
| `Ctrl+M` | Toggle metrics |
| `↑` / `↓` | Navigate input history |

### Status Line

Bottom status bar showing:
- **Connection**: Server status (connected/disconnected)
- **Provider**: Active LLM provider (Anthropic/OpenAI)
- **Model**: Current model name
- **Session**: Session ID

### Modals

Event-driven modals for focused views:

**Agents Modal** (`Ctrl+A` or `/agents`):
- Active agent list
- Agent status (idle/working)
- Current task assignment

**Tasks Modal** (`Ctrl+T` or `/tasks`):
- Task dependency graph
- Task status (pending/in_progress/completed)
- Blocked relationships

**Status Modal** (`Ctrl+S` or `/status`):
- Real-time event stream
- System events (tool execution, errors)
- Filterable by event type

**Review Modal** (`Ctrl+R` or `/review`):
- Multi-agent review feedback
- Code quality suggestions
- Architecture recommendations

**Metrics Modal** (`Ctrl+M` or `/metrics`):
- Observability results
- Performance metrics
- Error tracking

### Code Blocks

Collapsible syntax-highlighted code blocks:
- Click header to collapse/expand
- Language detection from context
- Scroll long blocks independently

### Input History

Navigate previous messages:
- `↑` - Previous message
- `↓` - Next message
- History persists across session

## Session Management

Sessions track conversation history and state.

### Session Lifecycle

1. **Creation**: New session on TUI start (generates unique session ID)
2. **Logging**: All events logged to JSONL file (`~/.local/share/ctrlcode/sessions/<session_id>.jsonl`)
3. **Persistence**: Conversation stored in `~/.cache/ctrlcode/conversations/<session_id>.json`
4. **Resumption**: Sessions can be resumed across restarts (future feature)

### Context Compaction

Reduce token usage while preserving context:

```bash
/compact
```

**How it works**:
1. Analyzes conversation for redundancy
2. Removes duplicate information
3. Merges similar messages
4. Preserves critical context (recent messages, important decisions)
5. Updates conversation with compacted version

### Proactive Context Window Monitoring

The server monitors context usage before each turn. When usage reaches **85% of the model's context limit**, it automatically summarizes and compacts the oldest messages before the turn starts. The full history is archived to `.ctrlcode/conversation_history/{session_id}.md`.

**Context window limits by model**:

| Model family | Limit |
|---|---|
| Claude 3.x / 3.5 / 3.7 | 200,000 tokens |
| GPT-4o / GPT-4o-mini / GPT-4-turbo | 128,000 tokens |
| Fallback default | 170,000 tokens |

### Agent-Triggered Compaction

The agent can call `compact_conversation` autonomously when appropriate — for example, after completing a major phase of work, when starting a significantly different task, or when context feels stale. The last 6 messages are always preserved verbatim.

### Context Pruning

When context exceeds `context.default_limit` tokens:

1. **Oldest messages pruned** (FIFO)
2. **Recent messages protected** (last `context.prune_protect` tokens)
3. **Critical context preserved** (system prompt, AGENT.md instructions)

Configure in `config.toml`:

```toml
[context]
prune_protect = 40000     # Protect last 40K tokens
default_limit = 200000    # Max context window
```

### Session Statistics

View token usage and message counts:

```bash
/stats

# Output:
# Messages: 42
# Tokens: 85,234 / 200,000 (43%)
# Protected: 40,000 tokens
```

## Multi-Agent Mode

Coordinate multiple specialized agents for complex tasks.

### Agent Types

Agents are dynamically spawned based on task requirements:
- **Planner**: Breaks down tasks into steps
- **Implementer**: Writes code
- **Reviewer**: Reviews code quality
- **Tester**: Writes and runs tests
- **Debugger**: Investigates failures

### Agent Panel

View active agents in real-time (`Ctrl+A`):
- Agent name and role
- Current status (idle/working/waiting)
- Assigned task
- Progress indicator

### Task Graph

Visualize task dependencies (`Ctrl+T`):
- Nodes: Tasks
- Edges: Dependencies (task A blocks task B)
- Colors: Status (pending/in_progress/completed)
- Interactive: Click nodes for details

### Review Feedback

Aggregated agent reviews (`Ctrl+R`):
- Code quality scores
- Architecture suggestions
- Performance concerns
- Security issues flagged

### Coordination

Agents coordinate through:
- **Task queue**: Shared priority queue
- **Dependencies**: Tasks block others until complete
- **Reviews**: Code must pass review before merge
- **Conflict resolution**: Automated or user-prompted

## Best Practices

### Effective Specifications

**DO**:
- Be specific about requirements
- Include examples of expected behavior
- Mention edge cases explicitly
- Specify performance requirements
- Note security considerations

**DON'T**:
- Write vague specs ("make it better")
- Assume implicit requirements
- Skip error handling details
- Ignore performance constraints

### Skills Organization

- **One skill per folder**: `~/.config/ctrlcode/skills/myskill/SKILL.md`
- **Descriptive names**: Use clear slash command names
- **Examples**: Include usage examples in the Markdown body
- **Prompt quality**: Write detailed instructions with clear scope
- **Project-local first**: Use `.ctrlcode/skills/` for workspace-specific skills

### Session Management

- **Compact regularly**: Use `/compact` when history grows (saves tokens)
- **Clear when switching contexts**: `/clear` for fresh start on new topics
- **Monitor stats**: Check `/stats` to avoid context limits
- **Let auto-compaction work**: The server handles compaction at 85% usage automatically

## Troubleshooting

### Skills Issues

**Skill not found after creating it**:
- Restart the server — skills are loaded at startup
- Verify the folder contains a `SKILL.md` file (not a bare `.toml` or `.md`)
- Check the folder is in a discovered location (builtin, global, project, or config override)

**Skill not receiving arguments**:
- Ensure `requires_args: true` is set in the frontmatter
- Use `{args}` placeholder in the instructions body

### Performance Issues

**TUI is slow**:
- Reduce event bus verbosity
- Disable multi-agent mode if not needed
- Compact conversation history

**Server high memory usage**:
- Check for large tool outputs (truncate if needed)
- Reduce context window size
- Clear old sessions from disk

**Context limit reached unexpectedly**:
- Check `/stats` — auto-compaction triggers at 85% but large single turns can still overflow
- Use `/compact` manually after long tool-heavy exchanges
- Review archived history in `.ctrlcode/conversation_history/` if needed

## See Also

- [Configuration Guide](configuration.md) - Customize settings
- [Security Guide](security.md) - Security features and best practices
- [Getting Started](getting-started.md) - Installation and setup
- [Developer Guide](../developer-guide/) - Extend ctrl+code with custom tools/skills
