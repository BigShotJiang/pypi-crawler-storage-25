# Architectural Patterns

System design patterns and structure for ctrl+code.

## System Architecture

```
┌─────────────────────────────────────────────────┐
│                    TUI Client                    │
│         (Textual-based terminal UI)             │
└────────────┬────────────────────────────────────┘
             │ JSON-RPC over HTTP
┌────────────▼────────────────────────────────────┐
│              Server (aiohttp)                   │
│  ┌───────────────────────────────────────────┐  │
│  │         Session Manager                   │  │
│  │  process_turn → MiddlewareStack           │  │
│  └───────┬──────────────────┬────────────────┘  │
│          │                  │                    │
│  ┌───────▼────────┐  ┌─────▼──────────────────┐ │
│  │ Multi-Agent    │  │  Tool Registry &       │ │
│  │ Orchestrator   │  │  Executor              │ │
│  └───────┬────────┘  └────────────────────────┘ │
│          │                                       │
│  ┌───────▼─────────────────────────────────┐    │
│  │    AgentCoordinator + AgentBus          │    │
│  │  (Inter-agent communication)            │    │
│  └────┬──────┬──────┬──────┬───────────────┘    │
│       │      │      │      │                     │
│  ┌────▼──┐┌──▼───┐┌▼────┐┌▼──────┐             │
│  │Planner││Coder ││Review││Executor│             │
│  │ Agent ││Agent ││Agent ││ Agent  │             │
│  └───────┘└──────┘└─────┘└────────┘             │
└──────────────────────────────────────────────────┘
```

## Multi-Agent Workflow Pattern

**Phase 1: Planning**
```python
user_intent → Orchestrator
              ↓
          Planner Agent
              ↓
          Task Graph (with dependencies)
```

**Phase 2: Execution**
```python
Task Graph → Orchestrator
              ↓
          Parallel Coder Agents
          (one per independent task)
              ↓
          Code Changes + Test Results
```

**Phase 3: Review**
```python
Code Changes → Orchestrator
               ↓
           Reviewer Agent
               ↓
           Approved / Changes Requested
               ↓ (if changes requested)
           Back to Coder Agent(s)
```

**Phase 4: Validation**
```python
Approved Changes → Orchestrator
                   ↓
               Executor Agent
                   ↓
               Runtime Verification
                   ↓
               Pass / Fail
```

## Agent Communication Pattern

**Message Structure**:
```python
@dataclass
class AgentMessage:
    from_agent: str        # Source agent ID
    to_agent: str          # Target agent ID
    message_type: str      # "task" | "result" | "feedback" | "question"
    payload: dict[str, Any]  # Message data
    context: dict[str, Any] = field(default_factory=dict)  # Additional context
    message_id: str | None = None  # Auto-generated UUID if not provided
```

**AgentBus** handles message routing:
```python
bus = AgentBus()
bus.register_handler("coder-1", coder_message_handler)
await bus.send(AgentMessage(
    from_agent="planner",
    to_agent="coder-1",
    message_type="task",
    payload={"task_id": "task-1", "description": "Add endpoint"}
))
```

## Session Management Pattern

**Per-session state** (`src/ctrlcode/session/models.py`):
```python
@dataclass
class Session:
    id: str
    conv_id: str = field(metadata=_PRIVATE)           # Never exposed in RPC
    provider: Provider = field(metadata=_PRIVATE)     # Never exposed in RPC
    cumulative_tokens: int = 0
    context_before_turn: int = field(default=0, metadata=_PRIVATE)
```

**Session lifecycle**:
1. Client creates session → SessionManager assigns ID + provider
2. Client sends messages → `process_turn` constructs a `TurnContext` and runs the `MiddlewareStack`
3. `MiddlewareStack` calls `before_turn` hooks (memory, skills, system prompt assembly), then drives the ReAct loop
4. Per-tool hooks (`pre_tool`, `after_tool_call`) fire for permission checks and blast-radius warnings
5. `after_turn` hooks persist artifacts, update progress file, and account tokens
6. Session maintains conversation history via harnessutils `ConversationManager`

## Middleware Architecture

`SessionManager.process_turn` delegates all cross-cutting concerns to a `MiddlewareStack`. Source: `src/ctrlcode/session/middleware/`.

**TurnContext** — shared mutable state for one turn:
```python
@dataclass
class TurnContext:
    session: Session
    user_input: str
    tool_calls: list[dict]
    assistant_parts: list[str]
    touched_files: list[str]
    commands_run: list[str]
    task_summary: str
    compaction_fired: bool
    iteration_warning_fired: bool
    system_prompt_msg: dict | None
    extra: dict          # middleware-private scratch space
```

**Hook points** (in execution order per turn):

| Hook | When | Failure behaviour |
|---|---|---|
| `before_turn(ctx)` | Once, before ReAct loop starts | Raises → aborts the turn |
| `pre_tool(ctx, tool_call)` | Before each tool execution | Yields StreamEvents |
| `after_tool_call(ctx, tool_call, result)` | After each tool execution | Yields StreamEvents |
| `after_turn(ctx)` | Once, after ReAct loop completes | Logged + swallowed |
| `close()` | SessionManager teardown | Logged + swallowed |

**MiddlewareStack** composes an ordered list of `BaseMiddleware` instances. `run_before_turn` stops on first failure. `run_after_turn` logs and continues past failures. `close()` iterates in reverse registration order.

**Concrete middleware** (registration order):

| Class | File | Responsibility |
|---|---|---|
| `MemoryMiddleware` | `memory.py` | Load rootset memories into context |
| `PermissionMiddleware` | `permission.py` | Pre-tool permission checks |
| `ContextAssemblyMiddleware` | `context_assembly.py` | Assemble system prompt each turn |
| `WorkspaceMiddleware` | `workspace.py` | Workspace index refresh |
| `SkillMiddleware` | `skill.py` | Expand skills into system prompt |
| `BaselineMiddleware` | `baseline.py` | Snapshot context token count before turn |
| `ProgressMiddleware` | `progress.py` | Write `.ctrlcode/progress.md` after turn |

## Pluggable Backend Architecture

All I/O performed by built-in tools goes through `BackendProtocol`. Source: `src/ctrlcode/backends/`.

**BackendProtocol interface** (`protocol.py`):
```python
@runtime_checkable
class BackendProtocol(Protocol):
    def read(self, path, *, offset, limit) -> dict
    def ls(self, path, *, max_depth) -> dict
    def glob(self, pattern, *, max_results) -> list[str]
    def grep(self, pattern, *, file_glob, context_lines, max_results) -> list[dict]
    def stat(self, path) -> dict
    def write(self, path, content) -> dict      # fails if file exists
    def overwrite(self, path, content) -> dict  # atomic create-or-replace
    def edit(self, path, old_content, new_content) -> dict  # atomic patch
    def write_bytes(self, path, data) -> dict
    def execute(self, command, *, cwd, timeout) -> dict
```

**Three implementations**:

| Class | File | Use case |
|---|---|---|
| `FilesystemBackend` | `filesystem.py` | Production — real disk I/O |
| `StateBackend` | `state.py` | Testing/sandboxing — in-memory dict, `execute` raises `NotImplementedError` |
| `CompositeBackend` | `composite.py` | Routes by path prefix; delegates to registered backends |

Tools accept an optional `backend: BackendProtocol` parameter instead of calling the OS directly. The default is `FilesystemBackend`. Tests inject `StateBackend` for deterministic, side-effect-free execution.

## Private State Pattern

Fields that must never appear in RPC responses or TUI rendering are marked with `field(metadata={"private": True})` using the `_PRIVATE` sentinel in `src/ctrlcode/session/models.py`.

```python
_PRIVATE: Final = {"private": True}

def public_fields(obj: Any) -> dict[str, Any]:
    """Return only the user-visible fields of a dataclass instance."""
    return {
        f.name: getattr(obj, f.name)
        for f in fields(obj)
        if not f.metadata.get("private", False)
    }
```

`public_fields(session)` is called at all serialisation boundaries (RPC responses, logging). Private fields on `Session`: `conv_id`, `provider`, `context_before_turn`.

## Context Window Management

Two complementary mechanisms prevent context overflow.

### Proactive Monitoring (`src/ctrlcode/memory/context_window_monitor.py`)

`ContextWindowMonitor` runs before each turn. If current token usage exceeds **85% of model capacity**, it summarizes the oldest half of the conversation via an LLM call and replaces those messages with a dense summary (target <600 tokens). Summarized messages are also appended to `.ctrlcode/conversation_history/{session_id}.md` for offline review.

`MODEL_CAPACITIES` maps known model IDs to their context window sizes (with prefix fallback for unknown model variants). Default fallback is 170,000 tokens.

```python
monitor = ContextWindowMonitor(model="claude-sonnet-4-6", ctrlcode_dir=Path(".ctrlcode"))
if monitor.is_over_threshold(current_tokens):
    result = await monitor.summarize_and_compact(
        session_id, conv_manager, conv_id, llm_client, keep_last=6
    )
    # result: {tokens_saved, new_conv_id, summary_text, messages_compacted}
```

### Agent-Triggered Compaction

The `compact_conversation` builtin tool is registered lazily in `process_turn` and bound to the current session. The agent can invoke it autonomously at phase boundaries when context is stale.

- Always preserves the last 6 messages verbatim
- Writes a `session:summary` artifact to rootset
- Declared in `src/ctrlcode/tools/signal.py`; invocation handled in `src/ctrlcode/agents/react_loop.py`
- System prompt instructs the agent when to call it (see `src/ctrlcode/session/prompt_builder.py`)

## Dangling Tool Call Recovery

`patch_tool_calls` in `src/ctrlcode/agents/tool_recovery.py` handles conversations where the process was interrupted after an assistant turn was persisted but before tool results were written.

It compares `pending_tool_calls` metadata on assistant messages against the `[Tool: name]` result messages that follow. For any unresolved calls, it inserts synthetic error result messages into the wire-format message list before sending to the provider.

```python
wire_messages = patch_tool_calls(wire_messages, raw_messages)
```

`task_complete` is exempt from patching (it is a terminal signal, not a real tool call).

## Schema Migration Pattern

`src/ctrlcode/memory/migrations.py` provides a versioned migration runner for `rootset.db`.

**How it works**:
- A `schema_version` table records the current version and migration timestamp
- `LATEST_VERSION = 2` is the current target
- `_MIGRATION_STEPS` maps each version number to a coroutine that applies that migration
- `run_migrations(db)` detects the current version and runs all pending steps in order, each in its own transaction; rolls back and raises `SchemaMigrationError` on failure

**CLI** (`ctrlcode-db`):
```
ctrlcode-db status              # show current schema version
ctrlcode-db migrate             # apply pending migrations
ctrlcode-db migrate --db PATH   # target a specific db file
ctrlcode-db migrate --dry-run   # preview without applying
```

**Adding a new migration**: increment `LATEST_VERSION`, write an `async def _migrate_vN_to_vN1(db)` coroutine, and add it to `_MIGRATION_STEPS`.

## Skills System Architecture

Skills are reusable prompt workflows loaded from folder-based structures. Source: `src/ctrlcode/skills/`.

**Skill folder structure**:
```
my-skill/
    SKILL.md        # required — instructions (may include YAML frontmatter)
    README.md       # optional — human description
    scripts/        # optional — executable scripts
    resources/      # optional — reference materials
```

**YAML frontmatter** in `SKILL.md` (all fields optional):
```yaml
---
name: my-skill
description: Short description shown in system prompt
requires_args: false
---
```
If frontmatter is absent, name falls back to the folder name and description is inferred from `README.md` or the first line of the body.

**Loading hierarchy** (earlier sources take precedence for name collisions):
1. `builtin` — `src/ctrlcode/skills/builtin/`
2. `global` — `~/.ctrlcode/skills/`
3. `project` — `.ctrlcode/skills/` in the workspace root
4. `config` — path override from session config

`SkillLoader.load_all(source)` loads one directory; `load_from_paths(paths, source)` loads multiple. Each skill's `source` field records its origin.

**System prompt injection**: `SkillRegistry.render_system_prompt_block()` returns a `<skills>` + `<skills_guidelines>` XML block injected into every turn's system prompt by `SkillMiddleware`. The block lists all registered skills with their descriptions and instructs the agent on when to invoke or implicitly apply them.

```
<skills>
Available skills — invoke with /name [args] or reference contextually:

commit     — Generate a semantic commit message
pr         — Open a pull request
...
</skills>

<skills_guidelines>
Skills are reusable workflows. The rules:
- Invoke explicitly when the user types /name or says "use the X skill"
- Apply implicitly when the request clearly matches the skill's intent
- Never mention skill names unless the user asked for them by name
</skills_guidelines>
```

**Invocation formats**:
- `/skill-name [args]` — explicit slash command
- `skill:skill-name(args)` — programmatic format
- Implicit — agent applies skill instructions when user intent matches

## Tool Registry Pattern

**Tool Definition**:
```python
{
    "name": "read_file",
    "description": "Read file contents",
    "input_schema": {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
        },
        "required": ["path"]
    }
}
```

**Tool Executor**:
- Validates input against schema
- Executes tool function
- Returns structured result
- Logs execution for observability

**Tool Subsets** per agent:
- Planner: `search_files`, `search_code`, `read_file`, `list_directory`
- Coder: `read_file`, `write_file`, `update_file`, `run_command`
- Reviewer: `read_file`, `run_command`, `search_code`
- Executor: `run_command`, `fetch`

## Event Streaming Pattern

**Server → Client events**:
```python
StreamEvent(type="text", data={"text": "Processing..."})
StreamEvent(type="tool_call_start", data={"tool": "read_file"})
StreamEvent(type="tool_result", data={"success": True, "result": "..."})
StreamEvent(type="workflow_phase_change", data={"phase": "execution"})
```

**Client EventBus** distributes to handlers:
```python
events.subscribe("workflow_phase_change", _on_phase_change)
events.emit("workflow_phase_change", {"phase": "execution"})
```

## Progressive Disclosure Pattern

**Load minimal context upfront**:
```python
# Load AGENTS.md (~500 tokens) as map
system_prompt = load_file("docs/AGENTS.md")

# Fetch specific docs as needed
if task_requires_auth:
    system_prompt += load_file("docs/architectural-patterns.md#auth")
```

**Benefits**:
- Smaller context window usage
- Faster response times
- More focused agent reasoning
- Scales to larger codebases

## Error Recovery Pattern

**Levels of escalation**:
1. **Agent retry**: Same agent, different approach
2. **Agent replacement**: Different agent instance
3. **Human escalation**: Orchestrator asks for help
4. **Fallback mode**: Switch to single-agent execution

**Example**:
```python
try:
    result = await coder_agent.run(task)
except AgentError as e:
    logger.warning(f"Coder failed, retrying: {e}")
    result = await coder_agent.run(task)  # Retry

    if not result.success:
        logger.error(f"Coder failed twice, escalating to human")
        await orchestrator.escalate_to_human(task, error=e)
```

## Data Flow

**User message**:
```
User Input (src/tui/)
    → RPC Client
    → Server SessionManager
    → MiddlewareStack.run_before_turn (memory, skills, system prompt)
    → ReAct Loop
        → pre_tool hooks (permissions)
        → Tool Execution (via BackendProtocol)
        → after_tool_call hooks (warnings, auto-chain)
    → MiddlewareStack.run_after_turn (artifacts, progress, tokens)
    → Stream Events back to TUI
```

**Workflow state**:
- Stored in Orchestrator
- Task graph tracked via task management tools
- Agent status emitted as events
- TUI widgets render real-time status

## Testing Strategy

**Unit tests**: Individual agent logic, tool execution, middleware hooks, backend implementations
**Integration tests**: Multi-agent workflows end-to-end, migration runner
**Manual tests**: TUI interaction, visual verification

Test files mirror source structure in `tests/` directory. Inject `StateBackend` for tests that exercise tool logic without real filesystem side-effects.
