# Tech Debt Tracker

Known technical debt, prioritized by impact and effort.

## High Priority

### None Currently

## Medium Priority

*(None currently)*

## Low Priority

### Test Coverage

**Issue:** Limited test coverage for newer features (middleware stack, multi-agent).

**Impact:** Low - Features work but harder to refactor safely.

**Effort:** Medium - Need comprehensive test suite.

**Action:** Add unit and integration tests incrementally.

**Owner:** TBD

**Status:** Ongoing

## Resolved

### Context Window Management Documentation

**Issue:** harness-utils context management docs were minimal.

**Action:** Created `docs/references/harness-utils-api.md` and `docs/references/multi-agent-guide.md`

**Status:** Resolved

## Adding Tech Debt

When you identify tech debt:

1. Add to appropriate priority section
2. Include: Issue, Impact, Effort, Action, Owner, Status
3. Link to related issues/PRs if available
4. Update status as work progresses
5. Move to Resolved when complete

## Prioritization

**High Priority:**
- Blocking development or production issues
- Security vulnerabilities
- Data corruption risks
- Major performance problems

**Medium Priority:**
- Developer productivity impact
- Maintainability concerns
- Minor performance issues
- Missing documentation

**Low Priority:**
- Code style inconsistencies
- Nice-to-have improvements
- Speculative optimizations
- Aspirational features
