# Agent Documentation Map

This file is the entry point for all agents. It's intentionally short (~100 lines).

## Quick Start

You are an AI agent working with ctrl+code. Start here, then follow links as needed.

**Core principle**: Load what you need, when you need it. Don't load everything.

## Core Beliefs

See `core-beliefs.md` for non-negotiable principles that guide all decisions.

## Coding Standards

See `coding-standards.md` for how we write code (style, patterns, conventions).

## Architecture

See `architectural-patterns.md` for system design patterns and structure.

Key patterns documented there:
- Middleware architecture (TurnContext, AgentMiddleware, MiddlewareStack)
- Pluggable backend protocol (FilesystemBackend / StateBackend / CompositeBackend)
- Context window monitoring and compaction
- Private state markers on Session dataclass
- Schema migration runner (rootset.db)
- Skills loading hierarchy and system prompt injection

## Golden Principles (Mechanically Enforced)

See `golden-principles/` for rules that linters enforce automatically.

Key principles:
- No YOLO parsing (validate at boundaries)
- Prefer shared utilities (don't reinvent)
- Structured logging (standard format)

## Tech Debt

See `tech-debt/tracker.md` for known issues, prioritized by impact.

## References

See `references/` for external documentation we've internalized:
- `harness-utils-api.md` - harness-utils usage patterns
- `multi-agent-guide.md` - Multi-agent harness patterns

## Tools

See `generated/tool-registry.md` for available tools (auto-generated from code).

## How to Navigate

1. **Start here** (AGENTS.md) - get the map
2. **Identify need** - what do I need to know?
3. **Follow link** - load specific doc
4. **Keep context focused** - don't load everything

## Project Structure

```
ctrl+code/
├── src/ctrlcode/
│   ├── agents/            # ReAct loop, tool recovery, multi-agent orchestration
│   ├── backends/          # BackendProtocol + FilesystemBackend/StateBackend/CompositeBackend
│   ├── cli/               # ctrlcode-db CLI (schema migration management)
│   ├── memory/            # Artifact store, context assembler, context window monitor,
│   │                      #   schema migrations, workspace monitor, dependency indexer
│   ├── providers/         # LLM provider adapters (Anthropic, OpenAI)
│   ├── session/
│   │   ├── middleware/    # AgentMiddleware protocol + MiddlewareStack + concrete middleware:
│   │   │                  #   memory, permission, context_assembly, workspace, skill,
│   │   │                  #   baseline, progress
│   │   └── ...            # Session models, manager, system prompt builder
│   ├── skills/            # SkillLoader, SkillRegistry, builtin skills
│   │   └── builtin/       # commit, refactor, test, review, docs, debug-session, plan, pr
│   └── tools/             # Tool registry, executor, tool implementations
├── prompts/               # System prompt and per-agent prompts
│   └── agents/            # Per-agent specialized prompts
├── tests/                 # Mirror of src/ structure
└── docs/                  # This directory
```

## Key Invariants

- **`uv run python`** — always use uv, never bare `python`
- **Middleware ordering** — memory → workspace → context_assembly → skill → baseline → permission → progress
- **Skills precedence** — builtin < global < project (.ctrlcode/skills/) < config override
- **Session private fields** — `conv_id`, `provider`, `context_before_turn` are marked private; serialize via `public_fields(session)`
- **Schema version** — `rootset.db` must be migrated via `run_migrations(db)`; current `LATEST_VERSION=2`
- **SYSTEM_PROMPT.md** — bundled fallback in `session/manager.py` must stay in sync

---

**Remember**: Keep context lean. Fetch details as needed. Quality over quantity.
