# OpenAI OAuth Support — Implementation Plan

## Overview

Add OAuth authentication for OpenAI as an alternative to API-key auth. Two flows: browser (PKCE + local callback server) and headless (device-code polling). Tokens stored at `<config_dir>/openai_oauth.json` with mode 600. When OAuth credentials are present and valid, the OpenAI provider uses the OAuth access token as a Bearer token and injects `ChatGPT-Account-Id` when an account_id was extracted from the JWT.

No new runtime dependencies. All network I/O uses `urllib` from stdlib. The callback HTTP server uses `http.server` + `threading`. PKCE uses `secrets` + `base64` + `hashlib`.

---

## New File: `src/ctrlcode/auth/openai_oauth.py`

This module owns everything: constants, token store, PKCE helpers, browser flow, device flow, token refresh, account-ID extraction.

### Constants

```python
OAUTH_CLIENT_ID    = "app_EMYNkIFoJCKbM3lCCQHWbShR"   # public client (no secret)
OAUTH_ISSUER       = "https://auth.openai.com"
OAUTH_AUTHORIZE    = f"{OAUTH_ISSUER}/oauth/authorize"
OAUTH_TOKEN        = f"{OAUTH_ISSUER}/oauth/token"
DEVICE_USERCODE    = f"{OAUTH_ISSUER}/api/accounts/deviceauth/usercode"
DEVICE_POLL        = f"{OAUTH_ISSUER}/oauth/token"      # same token endpoint, different grant
CALLBACK_PORT      = 1455
CALLBACK_URI       = f"http://localhost:{CALLBACK_PORT}/callback"
TOKEN_FILENAME     = "openai_oauth.json"
```

### Data structure stored in `openai_oauth.json`

```json
{
  "access_token":  "<jwt>",
  "refresh_token": "<opaque>",
  "expires_at":    1234567890,
  "account_id":    "<uuid or null>"
}
```

`expires_at` is a Unix timestamp (int). `account_id` is nullable; when null the header is omitted.

### Token store helpers

```python
def _token_path() -> Path:
    from ctrlcode.paths import get_config_dir
    return get_config_dir() / TOKEN_FILENAME

def load_tokens() -> dict | None:
    """Return parsed JSON or None if file absent/unreadable."""

def save_tokens(data: dict) -> None:
    """Atomic write + chmod 600. Write to temp file, os.replace(), then chmod."""

def clear_tokens() -> None:
    """Delete token file if present."""
```

### JWT account-ID extraction

```python
def _extract_account_id(access_token: str) -> str | None:
    """
    Decode JWT payload (no signature verification — just read claims).
    Priority:
      1. claims["chatgpt_account_id"]
      2. claims["https://api.openai.com/auth"]["chatgpt_account_id"]
         (or claims["https://api.openai.com/auth.chatgpt_account_id"])
      3. claims["organizations"][0]["id"]
    Returns None if none found or token is malformed.
    """
    import base64, json
    try:
        parts = access_token.split(".")
        payload_b64 = parts[1] + "=="   # pad to multiple of 4
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        if aid := payload.get("chatgpt_account_id"):
            return aid
        nested = payload.get("https://api.openai.com/auth", {})
        if aid := nested.get("chatgpt_account_id"):
            return aid
        flat_key = "https://api.openai.com/auth.chatgpt_account_id"
        if aid := payload.get(flat_key):
            return aid
        orgs = payload.get("organizations", [])
        if orgs:
            return orgs[0].get("id")
    except Exception:
        pass
    return None
```

### PKCE helpers

```python
def _generate_pkce() -> tuple[str, str]:
    """Return (code_verifier, code_challenge). Challenge = S256(verifier)."""
    import secrets, hashlib, base64
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
    return verifier, challenge
```

### Browser flow

```python
def browser_login() -> dict:
    """
    Full browser PKCE flow. Returns token dict with account_id injected.
    Raises RuntimeError on failure.

    Steps:
      1. Generate PKCE pair + state = secrets.token_urlsafe(16)
      2. Build authorize URL:
           response_type=code, client_id, redirect_uri=CALLBACK_URI,
           scope="openid profile email offline_access",
           code_challenge, code_challenge_method=S256, state
      3. Start local callback server on CALLBACK_PORT (threading.Event for sync)
      4. webbrowser.open(authorize_url)
      5. Block (timeout=120s) waiting for callback_received event
      6. Callback handler: parse ?code=&state=, verify state, signal event,
         respond 200 "You can close this tab."
      7. POST to OAUTH_TOKEN:
           grant_type=authorization_code, client_id, code,
           redirect_uri, code_verifier
      8. Parse response -> access_token, refresh_token, expires_in
      9. expires_at = int(time.time()) + expires_in - 30  (30s safety buffer)
      10. account_id = _extract_account_id(access_token)
      11. save_tokens({access_token, refresh_token, expires_at, account_id})
      12. Return token dict
    """
```

Callback server uses `http.server.BaseHTTPRequestHandler` in a `threading.Thread(daemon=True)`:

```python
class _CallbackHandler(BaseHTTPRequestHandler):
    # Class-level shared state set before server starts:
    #   _result: dict   (populated by handler with code + state)
    #   _done: threading.Event

    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        qs = parse_qs(urlparse(self.path).query)
        _CallbackHandler._result["code"]  = qs.get("code",  [None])[0]
        _CallbackHandler._result["state"] = qs.get("state", [None])[0]
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"<html><body><p>Authenticated. You can close this tab.</p></body></html>")
        _CallbackHandler._done.set()

    def log_message(self, *_):
        pass  # suppress access log
```

### Headless / device-code flow

```python
def device_login() -> dict:
    """
    Device-code flow for SSH/headless environments.
    Raises RuntimeError on failure or cancellation.

    Steps:
      1. POST DEVICE_USERCODE with {"client_id": OAUTH_CLIENT_ID}
         Response: {device_code, user_code, verification_uri, expires_in, interval}
      2. Print:
           "Go to {verification_uri} and enter code: {user_code}"
      3. Poll DEVICE_POLL every `interval` seconds:
           POST grant_type=urn:ietf:params:oauth:grant-type:device_code,
                device_code=..., client_id=...
         - 200 with access_token    -> success, break
         - {"error":"authorization_pending"} -> continue polling
         - {"error":"slow_down"}             -> interval += 5, continue
         - {"error":"expired_token"}         -> raise RuntimeError("Device code expired")
         - {"error":"access_denied"}         -> raise RuntimeError("Access denied")
      4. On success: steps 8-12 identical to browser flow
    """
```

### Token refresh

```python
def refresh_tokens(tokens: dict) -> dict:
    """
    Exchange refresh_token for a new access_token.
    POST OAUTH_TOKEN:
      grant_type=refresh_token, refresh_token=..., client_id=...
    On success: update + save tokens, return updated dict.
    On 4xx: clear_tokens() + raise RuntimeError("Session expired. Run `ctrlcode auth login`.")
    """
```

### Top-level helper used by provider/config

```python
def get_valid_tokens() -> dict | None:
    """
    Load tokens. If expired (expires_at < now), attempt refresh automatically.
    Returns valid token dict or None if no credentials exist.
    Raises RuntimeError if refresh fails.
    """
    tokens = load_tokens()
    if not tokens:
        return None
    if tokens.get("expires_at", 0) < int(time.time()):
        tokens = refresh_tokens(tokens)
    return tokens
```

---

## New File: `src/ctrlcode/auth/__init__.py`

```python
from .openai_oauth import (
    browser_login,
    device_login,
    get_valid_tokens,
    clear_tokens,
    load_tokens,
)
__all__ = ["browser_login", "device_login", "get_valid_tokens", "clear_tokens", "load_tokens"]
```

---

## Modified File: `src/ctrlcode/config.py`

### Add `account_id` to `ProviderConfig`

```python
@dataclass
class ProviderConfig:
    api_key: str = ""
    model: str = ""
    base_url: str | None = None
    account_id: str | None = None   # injected from OAuth JWT claims
```

### OAuth fallback in `Config.load()`

After the existing OpenAI block, add:

```python
# OAuth fallback: if no API key configured, check for stored OAuth tokens
if openai is None or not openai.api_key:
    try:
        from ctrlcode.auth.openai_oauth import get_valid_tokens
        oauth_tokens = get_valid_tokens()
        if oauth_tokens and openai is not None:
            openai = ProviderConfig(
                api_key=oauth_tokens["access_token"],
                model=openai.model,
                base_url=openai.base_url,
                account_id=oauth_tokens.get("account_id"),
            )
    except Exception:
        pass
```

Note: OAuth tokens alone (without a `[providers.openai]` section in config) are insufficient — the model must also be configured. The setup wizard always writes the model to TOML.

---

## Modified File: `src/ctrlcode/providers/openai.py`

```python
def __init__(
    self,
    api_key: str,
    model: str = "gpt-4",
    base_url: str | None = None,
    account_id: str | None = None,   # NEW
):
    self.api_key = api_key
    self.base_url = base_url
    self.account_id = account_id
    self.model = model

    effective_key = api_key if api_key else "none"

    default_headers: dict[str, str] = {}
    if account_id:
        default_headers["ChatGPT-Account-Id"] = account_id

    self.client = AsyncOpenAI(
        api_key=effective_key,
        base_url=base_url,
        default_headers=default_headers or None,
    )
```

No changes to `stream()` — `default_headers` on `AsyncOpenAI` applies to every request automatically.

---

## Modified File: `src/ctrlcode/server.py`

Single-line change in `HarnessServer.__init__()`:

```python
if config.openai:
    self.providers["openai"] = OpenAIProvider(
        api_key=config.openai.api_key,
        model=config.openai.model,
        base_url=config.openai.base_url,
        account_id=getattr(config.openai, "account_id", None),  # NEW
    )
```

---

## Modified File: `src/ctrlcode/setup.py`

In the OpenAI provider configuration block, insert an auth-method choice before the API key prompt:

```python
if short == "openai":
    _print()
    _print(f"  {_bold('How would you like to authenticate with OpenAI?')}")
    _print(f"  {_dim('1.')} OAuth  (browser login — for ChatGPT subscribers)")
    _print(f"  {_dim('2.')} API key  (from platform.openai.com)")
    auth_choice = _prompt("Choose [1/2]", default="1")

    if auth_choice.strip() == "1":
        is_tty = sys.stdout.isatty() and sys.stdin.isatty()
        try:
            from ctrlcode.auth.openai_oauth import browser_login, device_login, get_valid_tokens
            existing_oauth = get_valid_tokens()
            if existing_oauth:
                _print(f"  {_green('✓')} Existing OAuth session found")
                api_key = existing_oauth["access_token"]
            elif is_tty:
                _print("  Opening browser for OAuth login…")
                tokens = browser_login()
                api_key = tokens["access_token"]
                _print(f"  {_green('✓')} OAuth login successful")
            else:
                _print(f"  {_dim('Headless mode detected — using device code flow')}")
                tokens = device_login()
                api_key = tokens["access_token"]
                _print(f"  {_green('✓')} OAuth login successful")
        except Exception as exc:
            _print(f"  {_yellow('!')}  OAuth failed: {exc}")
            _print(f"  Falling back to API key")
            api_key = _prompt("API key (or Enter to skip)", secret=True)
            if not api_key:
                _print(f"  {_dim('Skipping OpenAI')}")
                continue
        # OAuth tokens live in openai_oauth.json — do NOT write to config.toml
        # Config.load() picks them up automatically at runtime
        api_key = ""   # blank in TOML; runtime fills from token store
    # else: fall through to existing API key prompt logic
```

When OAuth is chosen, the written `[providers.openai]` TOML section has no `api_key` field (since `_SECTION_TEMPLATE` does not write it). `Config.load()` sees no key, tries token store, finds valid tokens, constructs `ProviderConfig` with the access token.

---

## Error handling and edge cases

| Scenario | Behaviour |
|---|---|
| Port 1455 already in use | `browser_login()` raises `OSError`; setup wizard catches, prints guidance, offers retry |
| Browser unavailable (SSH) | After 5s, prompt "Did your browser open? [y/N]"; if no, switch to device flow |
| JWT decode fails | `_extract_account_id` returns `None`; `account_id` stored as `null`; header omitted silently |
| Refresh token expired | `refresh_tokens()` clears token file, raises `RuntimeError`; surface to user as "Session expired, re-run setup" |
| OPENAI_API_KEY set in env | Takes priority over OAuth in `Config.load()`; OAuth path is only reached when env var is absent and TOML `api_key` is empty |
| OAuth tokens present but no `[providers.openai]` TOML section | OAuth skipped — model unknown; user must re-run setup |
| `openai_oauth.json` wrong permissions | `load_tokens()` warns if `mode & 0o077 != 0`, mirrors `Config._validate_config_permissions()` |
| Concurrent refresh | Not a concern for single-user CLI; no locking needed |

---

## Implementation sequence

1. Create `src/ctrlcode/auth/__init__.py` and `src/ctrlcode/auth/openai_oauth.py`
2. Add `account_id: str | None = None` to `ProviderConfig` in `config.py`
3. Add OAuth fallback block in `Config.load()`
4. Update `OpenAIProvider.__init__()` to accept `account_id` and pass via `default_headers`
5. Update `HarnessServer.__init__()` to pass `account_id` through
6. Update `setup.py` with OAuth vs API-key branch for OpenAI
7. Write tests in `tests/test_openai_oauth.py`: PKCE generation, JWT decode (all 3 claim variants), token save/load/refresh, device-code poll state machine (mock urllib)

---

## Files touched summary

| File | Change |
|---|---|
| `src/ctrlcode/auth/__init__.py` | **New** |
| `src/ctrlcode/auth/openai_oauth.py` | **New** — all OAuth logic |
| `src/ctrlcode/config.py` | Add `account_id` to `ProviderConfig`; OAuth fallback in `load()` |
| `src/ctrlcode/providers/openai.py` | Accept `account_id`, inject via `default_headers` |
| `src/ctrlcode/server.py` | Pass `account_id` when constructing `OpenAIProvider` |
| `src/ctrlcode/setup.py` | Offer OAuth vs API-key choice for OpenAI provider |
