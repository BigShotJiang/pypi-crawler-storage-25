# Agent-Triggered Compaction Tool — Implementation Plan

## Overview

This plan adds a `compact_conversation` built-in tool the agent can call autonomously to summarize and offload conversation history. Unlike the existing mid-task compaction (triggered by harnessutils' `needs_compaction()` check during the ReAct loop), this gives the agent explicit agency — it can call `compact_conversation` at phase boundaries or when context feels stale.

The tool operates entirely within the active ReAct loop: it receives `conv_manager` and `session_id` through closure (same pattern as `task_complete_guard`), summarizes messages excluding the last 6, writes a `.ctrlcode/conversation_history/{session_id}.md` offload file, replaces the in-memory history with a single summary message, and writes a `session:summary` artifact to rootset. It returns stats to the agent.

Key design constraint: the builtin function needs access to `conv_manager`, `session_id`, and the `ArtifactWriter` — none of which are available in simple stateless builtins like `task_complete`. The solution is a factory function (same as `make_task_complete_guard`) that captures those references in a closure, then registers the resulting coroutine as a builtin.

**Note:** This plan closely ties to the Proactive Context Window Monitoring plan (`plan_context_monitoring.md`). The `compact_conversation` tool should reuse the summarization logic from that plan to avoid duplication.

---

## Affected Files

| File | Change type | Summary |
|---|---|---|
| `src/ctrlcode/tools/compaction.py` | **New file** | `CompactionTools` class + `COMPACTION_TOOL_SCHEMAS` constant |
| `src/ctrlcode/tools/__init__.py` | **Modify** | Import and expose `setup_compaction_tools` |
| `src/ctrlcode/session/manager.py` | **Modify** | Wire `setup_compaction_tools` with session context; handle `compact_conversation` event from react loop |
| `src/ctrlcode/agents/react_loop.py` | **Modify** | Detect `compact_conversation` tool call and emit a `compaction` event (same as mid-task compaction); add to `_format_tool_preview` |
| `prompts/SYSTEM_PROMPT.md` | **Modify** | Add section instructing the agent when to call `compact_conversation` |

---

## Step-by-Step Implementation Tasks

- [ ] **1. Create `src/ctrlcode/tools/compaction.py`**
  - [ ] Define `COMPACTION_TOOL_SCHEMAS` list with the `compact_conversation` schema (see below)
  - [ ] Define `make_compact_conversation_fn(conv_manager, conv_id, session_id, ctrlcode_dir, artifact_writer)` factory
  - [ ] Inside factory, implement the async coroutine:
    - [ ] Fetch all messages via `conv_manager.to_model_format(conv_id)`
    - [ ] Guard: if fewer than 7 messages total, return early with "nothing to compact" message
    - [ ] Determine split: messages to compact = all except last 6
    - [ ] Estimate token count of messages-to-compact via `conv_manager.calculate_context_usage` before and after
    - [ ] Build summary using the same structured prompt as `_condense_summary` in `artifact_writer.py`; if `artifact_writer._llm_client` is available, call it; otherwise use heuristic truncation (last 20 lines of concatenated content)
    - [ ] Write offload file to `ctrlcode_dir / "conversation_history" / f"{session_id}.md"` (append mode with timestamp header — see History Offload Format below)
    - [ ] Replace in-memory conversation: insert a new summary `Message` (role `user`) with text `[Compaction Summary]\n{summary}` at position 0 of the preserved window; remove the compacted messages
    - [ ] Write `session:summary` artifact to rootset via `artifact_writer._backend.add_artifact(...)` (see Integration section below)
    - [ ] Return `{"compacted": N, "tokens_freed": estimate, "summary_preview": summary[:200]}`

- [ ] **2. Modify `src/ctrlcode/tools/__init__.py`**
  - [ ] Import `COMPACTION_TOOL_SCHEMAS`, `make_compact_conversation_fn` from `.compaction`
  - [ ] Add `setup_compaction_tools(registry, conv_manager, conv_id, session_id, ctrlcode_dir, artifact_writer)` function
  - [ ] Add to `__all__`

- [ ] **3. Modify `src/ctrlcode/session/manager.py`**
  - [ ] In `process_turn()`, after `ArtifactWriter`/`ContextAssembler` are resolved from `_ensure_memory`, register the compaction tool:
    ```python
    if "compact_conversation" not in self.tool_registry.builtin_tools:
        setup_compaction_tools(self.tool_registry, self.conv_manager, session.conv_id, session_id, self._ctrlcode_dir, writer)
    ```
  - [ ] In the event loop over `AgentReActLoop.stream(...)`, detect `event.type == "agent_compaction"` and set a flag for `write_turn`

- [ ] **4. Modify `src/ctrlcode/agents/react_loop.py`**
  - [ ] In the tool execution section, add a special case for `compact_conversation` tool name (analogous to `task_complete`)
  - [ ] After the tool executes successfully, emit `StreamEvent(type="agent_compaction", data={"result": result.result})`
  - [ ] Do NOT break the loop — unlike `task_complete`, compaction should let the agent continue with its next action
  - [ ] Add `"compact_conversation"` to `_format_tool_preview` with label `"Compacting context…"`

- [ ] **5. Modify `prompts/SYSTEM_PROMPT.md`**
  - [ ] Add `compact_conversation` to the **Tools available** list
  - [ ] Add a **Context management** section with instructions (see System Prompt Additions below)
  - [ ] **IMPORTANT**: Also update the bundled fallback prompt in `src/ctrlcode/session/manager.py` to stay in sync (per project memory)

- [ ] **6. Write tests**
  - [ ] Unit test: `make_compact_conversation_fn` with mock `conv_manager` — verify messages split, offload file written, return dict structure
  - [ ] Unit test: fewer than 7 messages returns early without error
  - [ ] Integration test: call tool via `ToolExecutor.execute`, verify rootset artifact written
  - [ ] Test: `react_loop` emits `agent_compaction` event after tool executes and loop continues

---

## Tool Schema Definition

```python
COMPACTION_TOOL_SCHEMAS = [
    {
        "name": "compact_conversation",
        "description": (
            "Summarize and offload older conversation history to free up context window space. "
            "Call this when you have completed a major phase of work, when context feels stale, "
            "or when you are about to start a significantly different task in the same session. "
            "The last 6 messages are always preserved verbatim. "
            "Returns a confirmation with the number of messages compacted and tokens freed."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": (
                        "Optional: brief description of why you're compacting "
                        "(e.g. 'completed refactor phase', 'starting new feature'). "
                        "Included in the offload file for auditability."
                    ),
                },
            },
            "required": [],
        },
    }
]
```

---

## Summarization Algorithm

**Input:** All messages from `conv_manager.to_model_format(conv_id)`, excluding the last 6.

**Guard:** If total messages <= 6, return early: `{"compacted": 0, "tokens_freed": 0, "summary_preview": "Nothing to compact — fewer than 7 messages in history."}`.

**Summary generation (two paths):**

1. **LLM path** (when `artifact_writer._llm_client` is not None): invoke the same prompt structure used in `ArtifactWriter._condense_summary`. Pass the serialized content of the messages-to-compact. The prompt asks for the structured 6-field summary (Session focus / Current task state / Key decisions / Recent changes / Open items / Prior compaction count).

2. **Heuristic fallback** (no LLM client): concatenate all message content strings, keep the last 20 lines.

**Token estimate:** use `len(serialized_messages) // 4` as a character-to-token approximation (consistent with how `ArtifactWriter` does it in `write_turn`).

**History replacement in `conv_manager`:**
- Before implementing, verify whether `harnessutils.ConversationManager.compact()` accepts a `summary_override` or pre-written summary. If yes, use it. If not, directly manipulate the stored message list: keep only the last 6 messages plus the new summary message.
- The new summary message is a `role: user` message: `[Compaction Summary — {timestamp}]\n{reason_if_any}\n\n{summary}`.

---

## History Offload Format

File path: `.ctrlcode/conversation_history/{session_id}.md`
Write mode: **append** (each compaction adds a new section)

```markdown
## Compaction — {ISO timestamp}

**Reason:** {reason if provided, else "agent-triggered"}
**Messages compacted:** {N}
**Estimated tokens freed:** {estimate}

### Summary

{full LLM or heuristic summary}

### Raw Messages (abbreviated)

{for each compacted message: role | first 120 chars of content}

---
```

The raw messages section is a brief audit trail — not full content, just enough to know what was there.

---

## System Prompt Additions

Add to `prompts/SYSTEM_PROMPT.md` in the **Tools available** section:
```
- `compact_conversation` — summarize and offload older conversation history when context is stale
```

Add a new **Context management** section:
```markdown
## Context management

Call `compact_conversation` when:
- You have just completed a major phase of work (e.g. finished a feature, all tests pass)
- You are about to start a significantly different task in the same session
- You notice you are re-reading the same files repeatedly because context is crowded
- The session has had 20+ turns and earlier context is unlikely to be needed

Do NOT call it:
- In the middle of an active subtask
- When you have just started a session (nothing to compact yet)
- When fewer than 7 messages exist in history

The last 6 messages are always preserved verbatim. A summary is written to both the
active context and to `.ctrlcode/conversation_history/{session_id}.md` for auditability.
```

---

## Integration with Rootset Artifact Store

After summarization, write a `session:summary` artifact:

```python
await artifact_writer._backend.add_artifact(
    content=summary_text,
    kind="session:summary",
    namespace=session_id,
    metadata={
        "session_id": session_id,
        "compaction_count": existing_compaction_count + 1,
        "trigger": "agent_triggered",
        "reason": reason or "",
        "messages_compacted": N,
        "tokens_freed_estimate": tokens_freed,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    },
)
```

The `existing_compaction_count` is read by first searching for an existing `session:summary` artifact (same pattern as `ArtifactWriter._update_summary`). If one exists, upsert it via `update_artifact`; if not, `add_artifact`. This ensures the `ContextAssembler` can still find the summary on the next turn under the `session:summary` kind — no change to the read path is needed.

---

## Key Implementation Constraint: Registration Timing

The `compact_conversation` tool needs `conv_manager`, `conv_id`, and `artifact_writer` — all session-scoped and only available inside `process_turn()`. The cleanest approach:

- Register the tool **lazily inside `process_turn()`**, after `_ensure_memory()` resolves the writer.
- Use a guard (`if "compact_conversation" not in self.tool_registry.builtin_tools`) to prevent re-registration on subsequent turns.
- This is safe because the writer reference is stable for the session's lifetime (stored in `self._writers[session.id]`).

---

## Testing Approach

**Unit tests** (`tests/tools/test_compaction.py`):
- Mock `ConversationManager` with a `to_model_format` that returns a list of N messages
- Call the factory function, verify:
  - Returns early when N <= 6
  - Compacts all but last 6 when N > 6
  - Offload file is written with correct structure
  - `artifact_writer._backend.add_artifact` called with `kind="session:summary"`
  - Return dict has `compacted`, `tokens_freed`, `summary_preview` keys
- Test heuristic fallback path (no `llm_client`)
- Test LLM path with mock client

**Integration test** (`tests/session/test_compact_tool_integration.py`):
- Create a `SessionManager` with in-memory providers
- Run several turns to build up history
- Directly call `ToolExecutor.execute("compact_conversation", {})`
- Verify conversation message count drops
- Verify rootset has a `session:summary` artifact

**React loop test** (`tests/agents/test_react_loop_compaction.py`):
- Run `AgentReActLoop.stream()` with a mock tool executor that returns the compaction result
- Verify `agent_compaction` event emitted
- Verify loop continues after compaction (does NOT break like `task_complete`)
