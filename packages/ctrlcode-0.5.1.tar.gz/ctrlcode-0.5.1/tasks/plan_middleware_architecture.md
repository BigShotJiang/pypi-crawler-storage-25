# Middleware-First Architecture Plan

## Overview

`SessionManager` currently acts as a monolith: it owns memory init, workspace indexing, skill expansion, baseline extraction, context assembly, system prompt construction, hook wiring, and post-turn artifact writing — all tangled inside `process_turn`. The goal is to decompose these concerns into independently composable `AgentMiddleware` objects that the `AgentReActLoop` invokes through a clean hook contract.

The migration strategy is **incremental and non-breaking**: the existing `SessionManager` API remains intact; middleware is layered underneath via a new `MiddlewareStack` adapter that `process_turn` delegates to.

---

## Affected Files

| File | Change |
|---|---|
| `src/ctrlcode/session/manager.py` | Slim down `process_turn`; delegate to `MiddlewareStack` |
| `src/ctrlcode/agents/react_loop.py` | Accept `middleware_stack` param; call hook methods |
| `src/ctrlcode/session/middleware/__init__.py` | New package; exports public API |
| `src/ctrlcode/session/middleware/base.py` | `AgentMiddleware` protocol + `TurnContext` dataclass |
| `src/ctrlcode/session/middleware/stack.py` | `MiddlewareStack` runner |
| `src/ctrlcode/session/middleware/memory.py` | `MemoryMiddleware` (memory init + artifact write) |
| `src/ctrlcode/session/middleware/permission.py` | `PermissionMiddleware` (pre-tool permission check + markdown strip) |
| `src/ctrlcode/session/middleware/context_assembly.py` | `ContextAssemblyMiddleware` (system prompt + semantic context) |
| `src/ctrlcode/session/middleware/workspace.py` | `WorkspaceMiddleware` (workspace index + blast-radius warning) |
| `src/ctrlcode/session/middleware/skill.py` | `SkillMiddleware` (skill expansion) |
| `src/ctrlcode/session/middleware/baseline.py` | `BaselineMiddleware` (baseline extraction) |
| `src/ctrlcode/session/middleware/progress.py` | `ProgressMiddleware` (progress file write) |
| `tests/session/middleware/` | New test directory mirroring middleware package |

---

## Middleware Hook Interface Design

### `TurnContext` — shared mutable state for a single turn

```python
@dataclass
class TurnContext:
    session: Session
    user_input: str
    tool_calls: list[dict]          # populated as turn progresses
    assistant_parts: list[str]      # populated as turn progresses
    touched_files: list[str]        # populated post-turn
    commands_run: list[str]         # populated as run_command results arrive
    task_summary: str               # set when task_complete fires
    compaction_fired: bool
    iteration_warning_fired: bool
    system_prompt_msg: dict | None  # built by ContextAssemblyMiddleware
    extra: dict                     # escape hatch for middleware-specific data
```

### `AgentMiddleware` — protocol with four hook points

```python
class AgentMiddleware(Protocol):

    async def before_turn(self, ctx: TurnContext) -> None:
        """Called once before the ReAct loop starts for this turn.

        Use for: memory init, skill expansion, baseline extraction,
        workspace index refresh, system prompt assembly.
        """
        ...

    async def wrap_model_call(
        self,
        ctx: TurnContext,
        call_next: Callable[[], AsyncIterator[StreamEvent]],
    ) -> AsyncIterator[StreamEvent]:
        """Wrap each provider streaming call.

        Use for: token budget enforcement, logging, tracing.
        Default implementation must call call_next() and yield all events.
        """
        ...

    async def after_tool_call(
        self,
        ctx: TurnContext,
        tool_call: dict,
        result: ToolCallResult,
    ) -> AsyncIterator[StreamEvent]:
        """Called after each tool execution within the loop.

        Use for: blast-radius warnings, auto-chaining, permission logging.
        Yields additional StreamEvents to inject into the stream.
        """
        ...

    async def after_turn(self, ctx: TurnContext) -> None:
        """Called once after the ReAct loop completes for this turn.

        Use for: artifact writing, progress file, token accounting.
        """
        ...
```

All four methods have default no-op implementations in a `BaseMiddleware` ABC so concrete classes only override what they need.

The `before_turn` hook replaces the permission pre-tool and post-tool hook factories. `after_tool_call` replaces `make_post_tool_hook`. `after_turn` replaces the post-loop artifact write block.

### `MiddlewareStack` — ordered composition

```python
class MiddlewareStack:
    def __init__(self, middlewares: list[AgentMiddleware]) -> None: ...

    async def run_before_turn(self, ctx: TurnContext) -> None:
        """Run all before_turn hooks in registration order."""

    def make_after_tool_hook(self, ctx: TurnContext) -> Callable:
        """Return a callable compatible with react_loop's post_tool_hook signature."""

    async def run_after_turn(self, ctx: TurnContext) -> None:
        """Run all after_turn hooks in registration order."""
```

The `pre_tool_hook` and `post_tool_hook` callables passed to `AgentReActLoop.stream()` become thin adapters that delegate to `MiddlewareStack`.

---

## Middleware Extraction Map

| Current code location | Becomes |
|---|---|
| `_ensure_memory()` + `writer.write_turn()` | `MemoryMiddleware.before_turn` + `MemoryMiddleware.after_turn` |
| `make_pre_tool_hook` (permission + markdown strip) | `PermissionMiddleware.before_turn` (registers as pre_tool adapter) |
| `make_post_tool_hook` (blast radius + auto-chain) | `WorkspaceMiddleware.after_tool_call` |
| `make_task_complete_guard` | Stays as a standalone callable (not middleware — it's a guard, not a hook) |
| `build_system_prompt` + `ContextAssembler.assemble` | `ContextAssemblyMiddleware.before_turn` |
| `_ensure_workspace_index` | `WorkspaceMiddleware.before_turn` |
| `skill_registry.process_input` | `SkillMiddleware.before_turn` |
| `baseline_manager.extract_from_request` | `BaselineMiddleware.before_turn` |
| `write_progress_file` | `ProgressMiddleware.after_turn` |

---

## Step-by-Step Implementation Tasks

- [ ] **Step 1 — Define the contracts** (`middleware/base.py`)
  - Write `TurnContext` dataclass with all fields listed above
  - Write `AgentMiddleware` Protocol
  - Write `BaseMiddleware` ABC with no-op default implementations for all four hooks
  - No logic, no dependencies — pure interface definition

- [ ] **Step 2 — Implement `MiddlewareStack`** (`middleware/stack.py`)
  - `run_before_turn`: iterate middlewares in order, `await mw.before_turn(ctx)`
  - `make_pre_tool_hook`: returns an async generator adapter that calls each mw's pre-tool logic
  - `make_after_tool_hook`: returns async generator adapter that calls `mw.after_tool_call` for each middleware
  - `run_after_turn`: iterate middlewares in order, `await mw.after_turn(ctx)`
  - Note: `PermissionMiddleware` maps cleanly to the existing `pre_tool_hook` signature. Keep the pre_tool concept as a separate optional method `pre_tool(ctx, tool_call) -> AsyncIterator[StreamEvent]` on `BaseMiddleware` (default no-op), called from the stack's hook adapter.

- [ ] **Step 3 — Extract `SkillMiddleware`** (`middleware/skill.py`)
  - `before_turn`: expand skill if `skill_registry` present; mutate `ctx.user_input` in place; yield `skill_expanded` event (or store in `ctx.extra["skill_events"]` for re-emission)
  - Dependency: `SkillRegistry` (optional, injected at construction)

- [ ] **Step 4 — Extract `BaselineMiddleware`** (`middleware/baseline.py`)
  - `before_turn`: call `baseline_manager.extract_from_request(ctx.user_input)` and store baseline
  - Simple, no async I/O — fastest to extract

- [ ] **Step 5 — Extract `MemoryMiddleware`** (`middleware/memory.py`)
  - `before_turn`: call `_ensure_memory` logic (init `ArtifactStore`, `RootsetMemoryBackend`, `ArtifactWriter`, `ContextAssembler`); store `writer` and `assembler` in `ctx.extra`
  - `after_turn`: call `writer.write_turn(...)` using accumulated `ctx.tool_calls`, `ctx.assistant_parts`, `ctx.touched_files`, `ctx.task_summary`, `ctx.compaction_fired`, `ctx.iteration_warning_fired`
  - Carries the `asyncio.Lock` for memory init; this is the most stateful middleware

- [ ] **Step 6 — Extract `WorkspaceMiddleware`** (`middleware/workspace.py`)
  - `before_turn`: `_ensure_workspace_index` logic — init `WorkspaceMonitor`, refresh, start watching, back-patch `dep_indexer` into assemblers
  - `after_tool_call`: blast-radius warning (currently in `make_post_tool_hook`); also handle `update_file` workspace index refresh (currently in post-loop block)
  - Dependency: `MemoryMiddleware` must run `before_turn` first (ordering constraint — documented in stack construction)

- [ ] **Step 7 — Extract `ContextAssemblyMiddleware`** (`middleware/context_assembly.py`)
  - `before_turn`: call `build_system_prompt(...)` using `assembler` from `ctx.extra` (set by `MemoryMiddleware`); store result in `ctx.system_prompt_msg`
  - Dependency: `MemoryMiddleware` must run `before_turn` first

- [ ] **Step 8 — Extract `PermissionMiddleware`** (`middleware/permission.py`)
  - Implements `pre_tool(ctx, tool_call) -> AsyncIterator[StreamEvent]`
  - Logic from `make_pre_tool_hook`: permission check → markdown strip
  - Injects `__perm_denied__` / `__perm_approved__` sentinels as before (no executor change required)

- [ ] **Step 9 — Extract `ProgressMiddleware`** (`middleware/progress.py`)
  - `after_turn`: call `write_progress_file` if `ctx.task_summary` is non-empty
  - Trivially small; confirms the pattern works end-to-end

- [ ] **Step 10 — Wire `MiddlewareStack` into `SessionManager`** (`session/manager.py`)
  - Add `_build_middleware_stack() -> MiddlewareStack` factory method
  - In `process_turn`: construct `TurnContext`, call `stack.run_before_turn(ctx)`, pass hook adapters to `AgentReActLoop.stream()`, call `stack.run_after_turn(ctx)` after the loop
  - Remove extracted logic from `process_turn` body as each middleware is wired in
  - Keep all existing public methods unchanged

- [ ] **Step 11 — Update `AgentReActLoop.stream()`** (`agents/react_loop.py`)
  - Add optional `middleware_stack: MiddlewareStack | None = None` parameter
  - When provided, replace `pre_tool_hook` / `post_tool_hook` callables with stack-derived adapters
  - Keep existing hook parameters for backward compat

- [ ] **Step 12 — Package `__init__.py`** (`middleware/__init__.py`)
  - Export: `AgentMiddleware`, `BaseMiddleware`, `TurnContext`, `MiddlewareStack`
  - Export concrete classes: `MemoryMiddleware`, `PermissionMiddleware`, `ContextAssemblyMiddleware`, `WorkspaceMiddleware`, `SkillMiddleware`, `BaselineMiddleware`, `ProgressMiddleware`

- [ ] **Step 13 — Write tests for each middleware** (`tests/session/middleware/`)
  - One test file per middleware class
  - Test `before_turn`, `after_tool_call`, `after_turn` in isolation with mocked dependencies
  - Test `MiddlewareStack` ordering and hook delegation

---

## Migration Strategy

**Phase 1 — Non-breaking parallel path** (Steps 1–9)

Create the middleware package without touching `manager.py` or `react_loop.py` at all. Each middleware is implemented and unit-tested in isolation. The codebase stays green throughout.

**Phase 2 — Wire in, piece by piece** (Step 10, incremental)

Wire one middleware at a time into `process_turn`. After each extraction, run the full test suite. The ordering:
1. `SkillMiddleware` (no async deps, easiest)
2. `BaselineMiddleware` (same)
3. `ProgressMiddleware` (after_turn only, no before_turn deps)
4. `MemoryMiddleware` (stateful, but isolated)
5. `WorkspaceMiddleware` (depends on memory being initialised)
6. `ContextAssemblyMiddleware` (depends on memory for assembler)
7. `PermissionMiddleware` (pre_tool path)

**Phase 3 — Clean up `react_loop.py`** (Step 11)

Add the optional `middleware_stack` parameter only after `process_turn` is fully delegating. The hook callables remain as the wire format — the stack just produces them.

**Backward compatibility guarantee**: `SessionManager.__init__` signature, all public methods, `AgentReActLoop.stream()` existing parameters, and `Session`/`ReactConfig` dataclasses are not modified.

---

## Testing Approach

**Unit tests (per middleware)**

- Construct middleware with mocked dependencies
- Call `before_turn(ctx)` / `after_tool_call(ctx, call, result)` / `after_turn(ctx)` directly
- Assert side effects on `ctx` fields and mock calls
- Use `pytest.mark.anyio` for async tests (existing pattern in the repo)

**Stack tests** (`tests/session/middleware/test_stack.py`)
- Verify hooks fire in registration order
- Verify a middleware raising does not swallow events from others (log-and-continue for `after_turn`, re-raise for `before_turn`)
- Use lightweight `FakeMiddleware` stubs that record call order

**Integration tests**
- Extend `tests/session/test_manager_lifecycle.py` with a `process_turn` smoke test using `MockProvider`
- Assert that existing behaviour (artifact writing, system prompt injection, token accounting) still occurs

**Regression baseline**
- Before starting Phase 2, capture the test suite pass rate: `uv run pytest tests/ -q`
- After each middleware extraction, re-run and verify no regressions
