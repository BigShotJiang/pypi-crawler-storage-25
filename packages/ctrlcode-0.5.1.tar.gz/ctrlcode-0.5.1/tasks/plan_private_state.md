# Private State Attributes — Implementation Plan

## Overview

ctrl+code's `Session` dataclass and `SessionManager` class mix user-visible state (session ID, token counts) with middleware-internal plumbing (`conv_id`, memory backends, writers, assemblers, workspace monitor). This causes two problems:

1. The JSON-RPC `session.create` response exposes `id` and `provider.__class__.__name__` — but nothing prevents future code from accidentally serialising `conv_id` or other internal identifiers into API responses.
2. When the middleware architecture evolves, there is no contract at the type level distinguishing "safe to send over the wire" from "internal only".

The goal is to introduce a `PrivateField` marker pattern that makes the distinction explicit and machine-checkable, without breaking existing code and without adding new dependencies.

---

## Audit Table

### `Session` dataclass (`src/ctrlcode/session/models.py`)

| Field | Type | Classification | Rationale |
|---|---|---|---|
| `id` | `str` | **user-visible** | Returned in every RPC response; client uses it as the session handle |
| `conv_id` | `str` | **middleware-internal** | harness-utils conversation ID; meaningless to external callers; should never leave the server |
| `provider` | `Provider` | **middleware-internal** | Live provider object; cannot be serialised; provider *name* is user-visible but the object is not |
| `cumulative_tokens` | `int` | **user-visible** | Shown in TUI `/stats`; returned via `session.stats` endpoint |
| `context_before_turn` | `int` | **middleware-internal** | Turn-scoped scratch value; used only inside `process_turn` to compute deltas; never exposed externally |

### `SessionManager` instance variables (`src/ctrlcode/session/manager.py`)

All `SessionManager` attributes are middleware-internal. None are dataclass fields. They already use `_` prefix by convention where appropriate. No changes needed here — `SessionManager` is never serialised.

### `ReactConfig` dataclass (`src/ctrlcode/session/models.py`)

All fields (`mid_task_compaction`, `doom_loop_threshold`, `max_continuations`) are configuration/middleware-internal. `ReactConfig` is never serialised to an RPC response. No changes needed in this phase.

---

## Chosen Pattern: `dataclasses.field(metadata=...)` + `public_fields()` helper

### Rationale

Three approaches were considered:

**Option A — TypedDict split**: Introduce `SessionPublic(TypedDict)` alongside `Session`. Clean separation but requires maintaining two parallel structures and touching every callsite.

**Option B — Pydantic `PrivateAttr`**: Exactly the deepagents pattern. But the codebase uses plain `dataclasses`, not Pydantic. Adding Pydantic just for this is disproportionate.

**Option C — `dataclasses.field(metadata=...)` + helper** (chosen): Uses existing stdlib. Mark each private field with `metadata={"private": True}`. Add a `public_fields(obj)` helper that returns only non-private fields. All serialisation sites call `public_fields(session)` instead of manual dict construction. This is:
- Zero new dependencies
- Self-documenting at the field definition
- Inspectable at runtime
- Backward-compatible (existing code that reads `session.conv_id` still works)

### Implementation sketch

```python
# src/ctrlcode/session/models.py

from dataclasses import dataclass, field, fields
from typing import Any, Final

_PRIVATE: Final = {"private": True}


def public_fields(obj) -> dict[str, Any]:
    """Return only the user-visible fields of a dataclass instance.

    Any field declared with field(metadata=_PRIVATE) is excluded.
    Used to ensure serialisation boundaries never expose internal state.
    """
    return {
        f.name: getattr(obj, f.name)
        for f in fields(obj)
        if not f.metadata.get("private", False)
    }


@dataclass
class Session:
    id: str
    conv_id: str = field(metadata=_PRIVATE)
    provider: "Provider" = field(metadata=_PRIVATE)
    cumulative_tokens: int = 0
    context_before_turn: int = field(default=0, metadata=_PRIVATE)
```

`public_fields(session)` then returns `{"id": "...", "cumulative_tokens": 0}`.

---

## Serialisation Boundary Analysis

There are five places where session state reaches the outside world:

### 1. `HarnessServer.create_session` → JSON response

Current output is hand-constructed (safe today — no `conv_id` leaks). After the plan, add a comment noting which fields are drawn from `public_fields()`. No shape change needed.

**Action**: Add comment at the return dict. No change to returned values.

### 2. `HarnessServer.get_stats` → JSON response

Delegates to `SessionManager.get_context_stats`, which constructs its own dict from `ConversationManager` methods. Does not expose `Session` fields directly.

**Action**: None.

### 3. Streaming `turn.process` events

Streams `StreamEvent.to_dict()` objects. The `data` dict is constructed in `manager.py` and `react_loop.py`. No `Session` internals leak into event data.

**Action**: None for existing events. When adding new events in future, enforce that `Session` fields are accessed via `public_fields()` if the intent is user-visible data.

### 4. TUI rendering

The TUI holds its own copy of state — does not serialise the server-side `Session` object. Token counts are received via `token_usage` events.

**Action**: None.

### 5. `SessionLogger` JSONL output

Logs event type, session ID, and event-specific data. Does not log `Session` internals.

**Action**: None.

---

## Affected Files

| File | Change |
|---|---|
| `src/ctrlcode/session/models.py` | Add `_PRIVATE` sentinel, `public_fields()` helper, annotate `Session` fields |
| `src/ctrlcode/server.py` | Add comment at `create_session` response explaining field provenance |
| `tests/session/test_manager_lifecycle.py` | Add assertions for `public_fields()` behaviour |
| `tests/session/test_private_state.py` | **New** — unit tests for the pattern + optional lint guard |

---

## Step-by-Step Implementation Tasks

- [ ] **Step 1 — Define the pattern in `models.py`**
  - Add `_PRIVATE: Final = {"private": True}` constant at module level
  - Add `public_fields(obj: Any) -> dict[str, Any]` function using `dataclasses.fields()`
  - Annotate `Session.conv_id` with `field(metadata=_PRIVATE)`
  - Annotate `Session.provider` with `field(metadata=_PRIVATE)` (non-serialisable object)
  - Annotate `Session.context_before_turn` with `field(default=0, metadata=_PRIVATE)` (internal scratch)
  - Leave `Session.id` and `Session.cumulative_tokens` unannotated (user-visible)

- [ ] **Step 2 — Verify no existing tests break**
  - Run `uv run pytest tests/session/` — all should pass because `session.conv_id` attribute access still works
  - `field(metadata=...)` does not change attribute access behaviour

- [ ] **Step 3 — Add serialisation tests** (`tests/session/test_manager_lifecycle.py`)
  - Assert `"conv_id" not in public_fields(session)`
  - Assert `"id" in public_fields(session)`
  - Assert `"cumulative_tokens" in public_fields(session)`
  - Assert `"provider" not in public_fields(session)`
  - Assert `"context_before_turn" not in public_fields(session)`

- [ ] **Step 4 — Update `server.py` comment**
  - At `create_session` return dict, add inline comment: `# Draws from Session.public_fields() + server-level config`
  - Documentation only — the hand-constructed dict is already correct

- [ ] **Step 5 — Add lint guard** (`tests/session/test_private_state.py`, optional)
  - Add a test that uses `ast.parse` or `inspect` to verify that no code in `server.py` or `tui/` accesses `session.conv_id` directly (it should only appear inside `session/` module files)
  - This acts as a boundary guard that fails CI if a future commit accidentally exposes `conv_id` to a response

- [ ] **Step 6 — Document the pattern**
  - Add a short docstring to `public_fields()` explaining the contract
  - Add a comment above `_PRIVATE` explaining it excludes fields from RPC responses and TUI rendering

---

## Testing Approach

### Unit tests (pure, no server)

```python
# tests/session/test_private_state.py

import pytest
from dataclasses import fields
from ctrlcode.session.models import Session, public_fields, _PRIVATE


def make_session():
    from unittest.mock import MagicMock
    return Session(id="sess_001", conv_id="conv_abc", provider=MagicMock())


def test_public_fields_excludes_conv_id():
    s = make_session()
    result = public_fields(s)
    assert "conv_id" not in result

def test_public_fields_excludes_provider():
    s = make_session()
    result = public_fields(s)
    assert "provider" not in result

def test_public_fields_excludes_context_before_turn():
    s = make_session()
    result = public_fields(s)
    assert "context_before_turn" not in result

def test_public_fields_includes_id():
    s = make_session()
    result = public_fields(s)
    assert result["id"] == "sess_001"

def test_public_fields_includes_cumulative_tokens():
    s = make_session()
    s.cumulative_tokens = 42
    result = public_fields(s)
    assert result["cumulative_tokens"] == 42

def test_private_metadata_marker_on_conv_id():
    f = next(f for f in fields(Session) if f.name == "conv_id")
    assert f.metadata.get("private") is True

def test_attribute_access_still_works():
    # field(metadata=...) must not break normal attribute access
    s = make_session()
    assert s.conv_id == "conv_abc"
```

### Regression tests

Run the full `tests/session/` suite after Step 1 — all existing tests must pass with zero changes to test code. The `test_clear_conversation_resets_tokens` and `test_clear_conversation_assigns_new_conv_id` tests in `test_manager_lifecycle.py` directly access `s.cumulative_tokens` and `s.conv_id` — these must continue to work.

---

## Middleware Architecture Forward-Compatibility

When the middleware architecture (from `plan_middleware_architecture.md`) introduces `TurnContext` or new middleware-scoped state objects, the rule is:

- Any field that is an object reference (backend, lock, writer, assembler) → always `field(metadata=_PRIVATE)`
- Any field that is a scalar the user would care about (token counts, model name, session status) → unannotated (user-visible)
- Any field that is a scalar used only for internal delta calculation → `field(metadata=_PRIVATE)`

The `public_fields()` helper generalises to any dataclass, so `TurnContext` or `AgentContext` introduced later can use the same pattern without any changes to the helper function.
