# Proactive Context Window Monitoring — Implementation Plan

## Overview

`ConversationManager.calculate_context_usage()` already counts tokens accurately via tiktoken (`cl100k_base`), and the existing `needs_compaction()` in harnessutils uses a reactive check against `model_limits.default_context_limit`. The problem is that `needs_compaction` is only called inside the ReAct iteration loop (mid-task), and `SessionManager.process_turn` has no proactive check at the conversation level that fires at an 85% threshold before each turn starts.

This plan adds a `ContextWindowMonitor` class in `src/ctrlcode/memory/` that owns the threshold logic and model capacity table, wires it into `process_turn` (after `_ensure_memory`, before the ReAct loop), and exposes a `compact_conversation` tool the agent can call manually.

---

## Affected Files

| File | Change |
|---|---|
| `src/ctrlcode/memory/context_window_monitor.py` | **New** — monitor class, model table, threshold logic, summarization, history offload |
| `src/ctrlcode/session/manager.py` | Wire monitor into `process_turn`, register `compact_conversation` tool |
| `src/ctrlcode/tools/signal.py` | Add `compact_conversation` schema + stub |
| `src/ctrlcode/tools/__init__.py` | Add `setup_context_tools()` helper |
| `tests/memory/test_context_window_monitor.py` | **New** — unit tests |

---

## Step-by-Step Implementation Tasks

- [ ] **1. Create `src/ctrlcode/memory/context_window_monitor.py`**
  - [ ] 1a. Define `MODEL_CAPACITY` table (see table below)
  - [ ] 1b. Implement `ContextWindowMonitor.__init__` (provider model name, ctrlcode_dir, threshold=0.85, fallback=170_000)
  - [ ] 1c. Implement `monitor.max_tokens_for_model() -> int`
  - [ ] 1d. Implement `monitor.is_over_threshold(current_tokens) -> bool`
  - [ ] 1e. Implement `monitor.offload_history(session_id, messages) -> Path`
  - [ ] 1f. Implement `monitor.summarize_and_compact(session_id, conv_manager, conv_id, llm_client) -> int` (tokens saved)

- [ ] **2. Modify `src/ctrlcode/session/manager.py`**
  - [ ] 2a. Import `ContextWindowMonitor`
  - [ ] 2b. Add per-session monitor dict: `self._ctx_monitors: dict[str, ContextWindowMonitor]`
  - [ ] 2c. In `process_turn`, after `calculate_context_usage` snapshot, call `monitor.check_and_compact()` if over threshold
  - [ ] 2d. Yield `StreamEvent(type="context_compaction", data={...})` on compaction
  - [ ] 2e. Pass monitor reference to the `compact_conversation` tool handler
  - [ ] 2f. Wire `setup_context_tools()` into `__init__` when `tool_registry` is set

- [ ] **3. Modify `src/ctrlcode/tools/signal.py` (or new `context.py`)**
  - [ ] 3a. Add `CONTEXT_TOOL_SCHEMAS` list with `compact_conversation` schema
  - [ ] 3b. Implement `compact_conversation(session_id)` callable stub that delegates to `SessionManager`

- [ ] **4. Modify `src/ctrlcode/tools/__init__.py`**
  - [ ] 4a. Add `setup_context_tools(registry, session_manager)` that registers `compact_conversation`

- [ ] **5. Write `tests/memory/test_context_window_monitor.py`**
  - [ ] 5a. Test model capacity table lookup (known + unknown model)
  - [ ] 5b. Test threshold detection at exactly 85% and just below
  - [ ] 5c. Test `offload_history` writes correct markdown to `.ctrlcode/conversation_history/{session_id}.md`
  - [ ] 5d. Test `summarize_and_compact` with mock LLM client
  - [ ] 5e. Test that `compact_conversation` tool returns expected dict

---

## Token Counting Approach

`tiktoken` is already a declared dependency (`tiktoken>=0.12.0`). `harnessutils` exposes:

```python
from harnessutils.tokens.exact import count_tokens_exact
from harnessutils.tokens.exact import count_tokens_fast
```

Both use `cl100k_base` encoding. `ConversationManager.calculate_context_usage(conv_id, model=model_name)` calls `count_tokens_exact` under the hood.

The monitor should call `conv_manager.calculate_context_usage(conv_id, model=model_name)` directly — this avoids reimplementing counting and stays consistent with the existing usage telemetry already computed in `process_turn`. No additional API call is needed.

---

## Model Capacity Table

```python
MODEL_CAPACITIES: dict[str, int] = {
    # Claude 3.x
    "claude-3-haiku-20240307":    200_000,
    "claude-3-sonnet-20240229":   200_000,
    "claude-3-opus-20240229":     200_000,
    # Claude 3.5
    "claude-3-5-haiku-20241022":  200_000,
    "claude-3-5-sonnet-20241022": 200_000,
    "claude-3-5-sonnet-20240620": 200_000,
    # Claude 3.7 / 4.x
    "claude-3-7-sonnet-20250219": 200_000,
    "claude-sonnet-4-5-20250929": 200_000,
    "claude-opus-4-5":            200_000,
    # GPT-4 family
    "gpt-4o":                     128_000,
    "gpt-4o-mini":                128_000,
    "gpt-4-turbo":                128_000,
    "gpt-4":                        8_192,
    "gpt-3.5-turbo":              16_385,
    # Fallback
    "_fallback":                  170_000,
}
```

Lookup strategy: exact match first; if no match, check if `model_name` starts with any known prefix (e.g., `"claude-3-5"` → 200k); final fallback is `_fallback = 170_000`.

---

## Summarization Prompt Design

```
You are compacting conversation history to free context window space.
Below are messages from the oldest portion of this conversation that are about to be removed.
Write a dense summary (under 600 tokens) that preserves:

1. Every decision made (architectural, design, user preference)
2. Files created or modified, and the change made to each
3. Errors encountered and how they were resolved
4. Tasks completed vs. tasks still pending
5. Any important facts the agent would need to avoid repeating work

Do NOT include raw code unless it is essential to understanding a decision.
Do NOT pad with filler. Be terse.

--- MESSAGES TO SUMMARIZE ---
{formatted_messages}
--- END ---

Output only the summary, no preamble.
```

The summary is prepended to the conversation as a `role: user` system note:

```
[Context compaction: {N} messages summarized. Prior context:]
{summary}
```

---

## Integration with Existing ContextAssembler

`ContextAssembler` reads from the semantic artifact store — it is **not** modified by this feature. The two systems operate on orthogonal stores:

- `ContextAssembler` manages the *semantic/long-term* store (rootset.db, vector search).
- `ContextWindowMonitor` manages the *active conversation* in `ConversationManager` (harnessutils FilesystemStorage).

The only coordination: before compacting, `ArtifactWriter.write_turn()` should already have been called (it runs at the end of `process_turn`). Since the monitor fires at the *start* of the next turn (after `_ensure_memory`, before the ReAct loop), the previous turn's artifacts are already written. This ordering is safe.

---

## Precise Integration Point in `process_turn`

After the context usage snapshot and before the system prompt is built:

```python
# --- Proactive context window check ---
monitor = self._ctx_monitors.get(session_id)
if monitor is None:
    monitor = ContextWindowMonitor(
        model=session.provider.model,
        ctrlcode_dir=self._ctrlcode_dir,
        threshold=0.85,
        fallback_tokens=170_000,
    )
    self._ctx_monitors[session_id] = monitor

if monitor.is_over_threshold(session.context_before_turn):
    compaction_client = LLMClientAdapter(session.provider, asyncio.get_running_loop())
    tokens_saved = await monitor.summarize_and_compact(
        session_id=session_id,
        conv_manager=self.conv_manager,
        conv_id=session.conv_id,
        llm_client=compaction_client,
    )
    yield StreamEvent(
        type="context_compaction",
        data={"tokens_saved": tokens_saved, "trigger": "threshold"},
    )
    # Re-snapshot context after compaction
    session.context_before_turn = self.conv_manager.calculate_context_usage(
        session.conv_id, model=session.provider.model
    )
```

The monitor is **not** placed inside the ReAct iteration loop — that is where `needs_compaction` (mid-task) already fires. The proactive check fires once per user turn, at turn entry, keeping iteration count overhead at zero.

---

## `compact_conversation` Tool Schema

```python
{
    "name": "compact_conversation",
    "description": (
        "Summarize and compact older conversation history to free context window space. "
        "Call this when you notice the conversation is very long or when working with "
        "large file reads/outputs that are no longer needed. "
        "The full history is archived to .ctrlcode/conversation_history/ before compaction."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "reason": {
                "type": "string",
                "description": "Brief reason for compacting (e.g., 'large tool outputs accumulated')",
            }
        },
        "required": [],
    },
}
```

The function receives `session_id` via closure (same pattern as `task_complete` in `react_loop.py`). Returns `{"success": True, "tokens_freed": N, "archived_to": path_str}`.

---

## `_ctx_monitors` Dict Lifecycle

`_ctx_monitors` should be cleared in `SessionManager.close()` alongside `_writers` and `_assemblers`. No async cleanup needed — the monitor is stateless beyond config.

---

## Testing Approach

**Unit tests (`tests/memory/test_context_window_monitor.py`):**

1. `test_known_model_capacity` — assert `max_tokens_for_model("claude-3-5-sonnet-20241022")` returns 200_000
2. `test_unknown_model_fallback` — assert `max_tokens_for_model("some-future-model-v99")` returns 170_000
3. `test_threshold_not_triggered` — 84% of capacity → `is_over_threshold` returns False
4. `test_threshold_triggered` — 85% of capacity → `is_over_threshold` returns True
5. `test_offload_history_creates_file` — call `offload_history(session_id, messages)`, assert `.ctrlcode/conversation_history/{session_id}.md` exists and contains message content
6. `test_offload_history_appends` — call twice with different messages, assert both batches appear in file
7. `test_summarize_and_compact_with_mock_client` — mock `LLMClientAdapter.invoke` to return fixed text, assert conv history shortened and summary message prepended
8. `test_summarize_and_compact_no_client` — when no LLM client, assert graceful fallback (truncate oldest N messages directly)

**Integration tests:**

9. `test_compact_conversation_tool_registered` — create `SessionManager` with `tool_registry`, assert `compact_conversation` in tool definitions
10. `test_process_turn_triggers_compaction` — mock `calculate_context_usage` to return above-threshold value, assert `context_compaction` StreamEvent is yielded
