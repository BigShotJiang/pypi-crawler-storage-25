# Dangling Tool Call Recovery — Implementation Plan

## Overview

The ReAct loop in `src/ctrlcode/agents/react_loop.py` processes tool calls by:

1. Streaming the LLM response, collecting tool call events
2. Persisting the assistant turn as `Message(role="assistant", TextPart(text=...))`
3. Executing each tool call and persisting results as `Message(role="user", TextPart(text="[Tool: {name}]\nResult: ..."))`

If execution is interrupted between step 2 and step 3 (network error, SIGINT, timeout, crash), the conversation ends with an assistant message that referenced tool calls but has no corresponding user-role result messages. On the next turn, `to_model_format()` sends this history to the LLM, which may either hallucinate results or error out.

The fix is a `patch_tool_calls(messages)` function that scans the wire-level message list, detects unpaired tool call references, and inserts synthetic "did not complete" result messages. This runs once per turn, before the provider sees the history.

**Key constraint**: ctrl+code uses a TEXT-BASED tool call representation, not structured `ToolPart`/`ToolState` objects. Tool calls are embedded as plain text in assistant messages and tool results are plain text in user messages. The patch must work at the wire-format level.

---

## Affected Files

| File | Change |
|------|--------|
| `src/ctrlcode/agents/react_loop.py` | Add import of `patch_tool_calls`; call it at start of each iteration; write pending tool calls to assistant message metadata |
| `src/ctrlcode/agents/tool_recovery.py` | **New file**: `patch_tool_calls()` function |
| `tests/agents/test_tool_recovery.py` | **New file**: unit tests |

---

## Message Structure Analysis

### Wire format produced by `conv_manager.to_model_format(conv_id)`

```python
# Normal completed turn
{"role": "assistant", "content": "I'll read that file."}
{"role": "user", "content": "[Tool: read_file]\nResult: {file contents}"}

# Dangling: assistant message has pending_tool_calls metadata but no result follows
{"role": "assistant", "content": "I'll read that file.", "metadata": {
    "pending_tool_calls": [{"tool": "read_file", "call_id": "toolu_xyz"}]
}}
{"role": "user", "content": "continue please"}  # next user prompt, not a tool result
```

In ctrl+code's ReAct loop, tool calls are tracked in-memory during streaming (`tool_calls: list[dict]`). They are NOT embedded as structured tool_call objects in the persisted assistant message. The `call_id`, `tool`, and `input` are only available in the local variables during the loop.

We solve this by **persisting call intent into the assistant message metadata** at execution time, giving the recovery function something concrete to work with.

### The fallback scenario (no metadata)

For sessions that predate this change, `pending_tool_calls` metadata will be absent. The fallback detects the structural pattern: an assistant message followed by a user message that does NOT start with `[Tool:`.

---

## Step-by-Step Implementation Tasks

- [ ] **1. Create `src/ctrlcode/agents/tool_recovery.py`** — single-responsibility module for the patching algorithm
- [ ] **2. Implement `find_dangling_tool_calls(messages: list[dict]) -> list[dict]`** — scans wire-format messages for assistant messages followed by non-tool-result user messages
- [ ] **3. Implement `patch_tool_calls(messages: list[dict]) -> list[dict]`** — returns a new list with synthetic tool result messages inserted
- [ ] **4. Add call site in `react_loop.py`** — call `patch_tool_calls()` on the messages list at the top of each iteration, before passing to the provider
- [ ] **5. Add metadata write in `react_loop.py`** — after building `asst_msg` and before `conv_manager.add_message`, attach pending tool calls to `asst_msg.metadata["pending_tool_calls"]`
- [ ] **6. Add call site in `session/manager.py` resume path** — call patch after loading history on resume (for early warning logging)
- [ ] **7. Write unit tests** in `tests/agents/test_tool_recovery.py` covering all edge cases

---

## The Patching Algorithm

### Phase A — Persist call intent (during normal execution)

In `react_loop.py`, after building `asst_msg` (currently lines ~147–151), attach the pending tool calls as metadata before adding to the conversation:

```python
asst_msg = Message(id=_gen_id(), role="assistant")
if assistant_text:
    asst_msg.add_part(TextPart(text="".join(assistant_text)))
# NEW: record pending tool calls in metadata for recovery
if tool_calls:
    asst_msg.metadata["pending_tool_calls"] = [
        {"tool": tc["tool"], "call_id": tc["call_id"]}
        for tc in tool_calls
    ]
conv_manager.add_message(conv_id, asst_msg)
```

`Message.to_dict()` includes `metadata` in the serialized dict. On resume, `Message.from_dict()` restores it. This means metadata is a safe, reliable channel for persisting pending tool call information across process restarts.

### Phase B — Detect and patch (at start of each turn)

```pseudocode
function patch_tool_calls(messages: list[dict]) -> list[dict]:
    result = list(messages)
    i = 0
    while i < len(result):
        msg = result[i]
        if msg["role"] != "assistant":
            i += 1
            continue

        # Collect pending tool calls from metadata (if stored)
        pending = msg.get("metadata", {}).get("pending_tool_calls", [])
        if not pending:
            i += 1
            continue

        # Find which calls have result messages immediately following
        j = i + 1
        resolved_calls = set()
        while j < len(result) and result[j]["role"] == "user":
            content = result[j].get("content", "")
            if content.startswith("[Tool:"):
                tool_name = content.split("[Tool: ", 1)[1].split("]", 1)[0].strip()
                resolved_calls.add(tool_name)
            j += 1

        # For each pending call with no result, insert synthetic result
        insert_pos = i + 1
        patched = 0
        for tc in pending:
            if tc["tool"] == "task_complete":
                continue  # idempotent, skip
            if tc["tool"] not in resolved_calls:
                synthetic = {
                    "role": "user",
                    "content": (
                        f"[Tool: {tc['tool']}]\n"
                        f"Error: Tool call {tc['tool']} (id={tc['call_id']}) "
                        f"did not complete (cancelled or timed out)."
                    )
                }
                result.insert(insert_pos + patched, synthetic)
                patched += 1
                logger.warning(
                    f"patch_tool_calls: inserted synthetic result for dangling "
                    f"call {tc['tool']} (id={tc['call_id']})"
                )
        i = j + patched

    return result
```

### Fallback (no metadata available, legacy sessions)

```python
def _has_dangling_turn_legacy(messages: list[dict]) -> bool:
    if len(messages) < 2:
        return False
    second_last = messages[-2]
    last = messages[-1]
    if second_last["role"] != "assistant":
        return False
    if last["role"] != "user":
        return False
    content = last.get("content", "")
    return not content.startswith("[Tool:")

# If detected, insert a generic recovery notice
LEGACY_RECOVERY_MSG = {
    "role": "user",
    "content": "[System: Previous tool execution was interrupted. No tool results are available for the prior turn. Please re-attempt any necessary tool calls.]"
}
```

---

## Where in the Execution Flow to Run the Patch

### Location 1 — Per-iteration in `react_loop.py` (primary)

At the top of the `while` loop, after `messages = conv_manager.to_model_format(conv_id)`:

```python
messages = conv_manager.to_model_format(conv_id)
messages = patch_tool_calls(messages)  # NEW
if system_prompt_msg:
    messages = [system_prompt_msg] + messages
```

The patch operates on the wire-format list returned by `to_model_format()` (a copy, not the stored messages). No stored messages are mutated. The patch only lives for that one LLM call.

### Location 2 — On resume (logging only)

In `session/manager.py`'s `process_turn()`, after `self.conv_manager.prune_before_turn(session.conv_id)` — call a simpler check that just logs a warning if dangling calls are detected. This gives early visibility without modifying messages.

---

## Edge Cases

| Scenario | Handling |
|---|---|
| Multiple dangling calls in one assistant turn | The while-loop with `patched` counter handles this — each call gets its own synthetic result inserted in order |
| `task_complete` tool | Skip in `patch_tool_calls` — it's idempotent and the model will re-attempt |
| MCP tools | Same path as built-in tools — no special handling needed |
| Doom loop guard / write-path tally paths | Both produce `[Tool: ...]`-prefixed user messages — detected as "resolved" |
| `allowed_tools` filter skips execution | Only write metadata for tool calls that will actually be executed (filter by `allowed_tools` before writing metadata) |
| Compacted messages | After LLM summarization, old messages are replaced by a summary. Dangling calls pre-compaction will be gone from history — acceptable. |
| Concurrent sessions | Each session has its own `conv_id`. `patch_tool_calls` operates on a per-turn message list copy. No shared state. |

---

## Testing Approach

### Unit tests for `patch_tool_calls` (no mocking needed)

```python
# Test 1: No dangling calls — messages unchanged
messages = [
    {"role": "user", "content": "do X"},
    {"role": "assistant", "content": "ok", "metadata": {}},
    {"role": "user", "content": "[Tool: read_file]\nResult: data"},
]
assert patch_tool_calls(messages) == messages

# Test 2: Single dangling call — synthetic result inserted
messages = [
    {"role": "user", "content": "do X"},
    {"role": "assistant", "content": "reading...", "metadata": {
        "pending_tool_calls": [{"tool": "read_file", "call_id": "abc123"}]
    }},
    {"role": "user", "content": "continue"},
]
patched = patch_tool_calls(messages)
assert len(patched) == 4
assert patched[2]["role"] == "user"
assert "did not complete" in patched[2]["content"]
assert "read_file" in patched[2]["content"]
assert patched[3]["content"] == "continue"

# Test 3: Multiple dangling calls — all get synthetic results
# Test 4: task_complete call is skipped
# Test 5: No metadata (legacy) — fallback behavior
# Test 6: Mixed: one resolved, one dangling
# Test 7: MCP tool call (same as regular)
```

### Integration test: simulate interrupted session

```python
@pytest.mark.anyio
async def test_patch_on_resume_after_crash(tmp_path):
    # 1. Construct interrupted state manually:
    #    - add an assistant message with pending_tool_calls metadata
    #    - do NOT add the tool result
    # 2. Resume the session and call process_turn()
    # 3. Assert that the provider received a patched message list
    #    (mock the provider, capture the messages argument)
    # 4. Assert "did not complete" appears in the message sent to the provider
```

### How to simulate dangling tool calls

```python
from harnessutils import ConversationManager, Message, TextPart, MemoryStorage, HarnessConfig

mgr = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())
conv = mgr.create_conversation()
cid = conv.id

user_msg = Message(id="msg_001", role="user")
user_msg.add_part(TextPart(text="please read config.py"))
mgr.add_message(cid, user_msg)

# Simulates crash after streaming but before tool result was written
asst_msg = Message(id="msg_002", role="assistant")
asst_msg.add_part(TextPart(text="I'll read that file for you."))
asst_msg.metadata["pending_tool_calls"] = [
    {"tool": "read_file", "call_id": "toolu_xyz"}
]
mgr.add_message(cid, asst_msg)
# <-- No tool result message = dangling state

wire_msgs = mgr.to_model_format(cid)
patched = patch_tool_calls(wire_msgs)
# patched should have a synthetic "[Tool: read_file]...did not complete" message
assert any("did not complete" in m.get("content", "") for m in patched)
```

---

## Summary of Changes

Contained in **one new file** plus **two small edits**:

1. `src/ctrlcode/agents/tool_recovery.py` — new, ~60 lines
2. `src/ctrlcode/agents/react_loop.py` — ~5 lines added (metadata write + patch call)
3. `tests/agents/test_tool_recovery.py` — new, ~80 lines of tests

Total blast radius: minimal. No changes to harnessutils, session manager, or storage layer.
