# Permission System — Todo

## Status: Complete

---

- [x] **Step 1** — Extend PermissionManager
  - [x] Add `PermissionResponse` dataclass to `permissions.py`
  - [x] Add `DESTRUCTIVE_TOOLS` frozenset and `is_destructive()` helper
  - [x] Add `accept_all: bool` flag to `PermissionManager`
  - [x] Change `_pending_requests` future type to `Future[PermissionResponse]`
  - [x] `request_permission_async` short-circuits when `accept_all=True`
  - [x] `request_permission_async` returns `(bool, str | None)`
  - [x] `handle_permission_response` accepts `PermissionResponse`
  - [x] Add `set_accept_all(val: bool)` method
  - [x] Update global `request_permission()` helper signature

- [x] **Step 2** — Central check in ToolExecutor
  - [x] Add `permission_manager` param to `ToolExecutor.__init__`
  - [x] Add destructive check in `execute()` before tool call
  - [x] Return denial `ToolCallResult` with optional context on reject
  - [x] Wire `permission_manager` into ToolExecutor in server.py
  - [x] Remove one-off check from `write_file()` in `tools/explore.py`

- [x] **Step 3** — Extend RPC layer
  - [x] Update `client.send_permission_response` with `accept_all` and `context` params
  - [x] Add `client.set_accept_all(val: bool)` method
  - [x] Update server `handle_permission_response` to parse `PermissionResponse`
  - [x] Add server `handle_set_accept_all` handler
  - [x] Route `permission.set_accept_all` in server `handle_rpc()`
  - [x] Emit `accept_all_changed` stream event on state change

- [x] **Step 4** — Redesign PermissionModal
  - [x] Replace two-button layout with Approve / Accept All / Reject / Add Context
  - [x] Add inline `TextArea` (hidden by default) for "Add Context" flow
  - [x] Show/hide TextArea on "Add Context" press
  - [x] Add "Accept All" warning note in modal footer
  - [x] Wire all buttons to correct `send_permission_response` calls
  - [x] Update CSS for new layout

- [x] **Step 5** — TUI accept_all indicator + Tab binding
  - [x] Add `accept_all_active: bool` to TUI app
  - [x] Handle `accept_all_changed` stream event in `_handle_stream_event`
  - [x] Add Tab key binding → `action_toggle_accept_all`
  - [x] Guard: Tab only acts when `accept_all_active` is True
  - [x] Show `"⚡ Accept All — Tab to disable"` indicator in status area
  - [x] Hide indicator when `accept_all_active` is False

- [x] **Step 6** — Tests
  - [x] `test_is_destructive_write_file`
  - [x] `test_is_destructive_read_file`
  - [x] `test_permission_response_dataclass`
  - [x] `test_request_permission_accept_all_short_circuits`
  - [x] `test_request_permission_returns_context`
  - [x] `test_executor_blocks_destructive_tool_on_deny`
  - [x] `test_executor_injects_context_on_add_context`
  - [x] `test_executor_skips_check_for_safe_tools`

---

## Notes

- Accept All is server-side state (`PermissionManager.accept_all`). The TUI just reflects it.
- When accept_all is active, no modal is shown — tools proceed silently.
- Context string is injected as part of the tool error result, which the react loop stores as a user message. The LLM reads it on the next turn.
- Tab key is a no-op in the TUI when accept_all is not active.
