# Plan: Self-Summarization

## Goal
Replace the current heuristic session summary (append 300 chars on high-saliency turns) with a
model-written structured summary — prompted to produce what it would need to resume work if all
context were lost. Non-blocking: written async post-stream, never on the hot path.

---

## Background

Current flow in `ArtifactWriter._update_summary`:
- Triggers only on saliency ≥ 0.80
- Appends `[reason] {first 300 chars of assistant text}` to the existing summary
- Condenses via a generic "preserve key decisions" prompt when over ~450 tokens
- No awareness of task state, remaining work, or how many times it's been condensed

What we want (per Cursor's approach, adapted for prompted rather than trained):
- The model writes the summary itself with an explicit "what do I need to continue" framing
- Structured format with a `current_task_state` field (missing from current format)
- Tracks `compaction_count` so the model knows how much history is already summarized
- Triggered on: significant turns (existing trigger) AND when mid-task compaction fires

---

## Changes

### 1. `src/ctrlcode/memory/artifact_writer.py`

**`_update_summary` — add compaction_count tracking**

Store `compaction_count` in the `session:summary` artifact metadata. Increment on every LLM
condensation call.

```python
compaction_count = existing.metadata.get("compaction_count", 0) if existing else 0
```

**`_condense_summary` — replace generic prompt with task-aware self-summary prompt**

Old prompt: `"Condense this session summary to under 400 tokens, preserving key decisions and changes"`

New prompt:
```
Write a session summary that would let you resume this task if all prior context were lost.
Be concise (under 500 tokens). Structure it exactly as:

Session focus: <dominant files or topic>
Current task state: <what is being worked on RIGHT NOW — the active task, not what's done>
Key decisions: <architectural or implementation decisions made>
Recent changes: <files written/edited and what changed>
Open items: <remaining work, unresolved questions>
Prior compaction count: <N>

Current summary:
{existing}

New work this turn:
{new_entry}

Output only the structured summary, no preamble.
```

**`write_turn` — add `force_llm_summary` parameter**

```python
async def write_turn(self, ..., force_llm_summary: bool = False) -> None:
```

When `force_llm_summary=True`, call `_condense_summary` unconditionally (bypassing the token
budget check). This is the path triggered by mid-task compaction and the 80% iteration warning.

Also lower the heuristic trigger from saliency ≥ 0.80 to ≥ 0.70 so more turns contribute to
the summary.

---

### 2. `src/ctrlcode/session/manager.py`

**Track compaction and iteration_warning events during the turn**

In `process_turn()`, collect events from the react_loop stream. Add:

```python
compaction_fired = False
iteration_warning_fired = False

async for event in react_loop.stream(...):
    if event.type == "compaction":
        compaction_fired = True
    elif event.type == "iteration_warning":
        iteration_warning_fired = True
    yield event
```

**Pass `force_llm_summary` to `write_turn`**

```python
await writer.write_turn(
    ...,
    force_llm_summary=compaction_fired or iteration_warning_fired,
)
```

This ensures: whenever the model is about to lose context (compaction) or is being told to wrap
up (80% warning), a full LLM self-summary is written to rootset before the next turn starts.

---

### 3. `src/ctrlcode/agents/react_loop.py`

No changes needed. The `compaction` and `iteration_warning` events are already emitted; we just
need manager.py to observe them.

---

## What does NOT change

- Timing: `write_turn` is still called post-stream, after the response is already yielded to the
  user. Zero added latency on the hot path.
- Frequency: LLM self-summary only fires on compaction, iteration_warning, or when saliency ≥
  0.70 AND summary is near the token cap. Most turns remain heuristic-only.
- `ContextAssembler`: reads `session:summary` unchanged — the format is more structured now but
  still plain text.

---

## Verification

- [ ] Write a turn with saliency ≥ 0.70 and summary near cap — confirm LLM summary fires
- [ ] Trigger a compaction event (manually or via test) — confirm `force_llm_summary=True` path runs
- [ ] Trigger iteration_warning (80% threshold) — confirm self-summary is written
- [ ] Confirm summary artifact contains all 6 structured fields
- [ ] Confirm `compaction_count` increments correctly across multiple condensations
- [ ] Confirm no added latency: response streams before `write_turn` is awaited
