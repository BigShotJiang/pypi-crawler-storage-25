# Permission System — Implementation Plan

## Overview

Build a user-facing permission system that intercepts destructive tool operations before they execute. The system presents a TUI modal with four choices — **Approve**, **Accept All**, **Reject**, **Add Context** — and supports a persistent "Accept All" mode that can be toggled via the `Tab` key from the main TUI.

---

## Current State

| What exists | Notes |
|---|---|
| `PermissionManager` in `permissions.py` | Approve/deny only. `Future[bool]`. |
| `PermissionModal` in TUI | Two buttons (Approve, Deny). No context input. |
| `write_file` has a permission check | One-off, not via executor |
| `update_file`, `run_command` have no checks | Need coverage |
| `RPCClient.send_permission_response` | Only sends `approved: bool` |
| Server `handle_permission_response` | Only accepts bool |

---

## Architecture: How It Fits Together

```
ReAct loop
  └─ ToolExecutor.execute()          ← permission check lives here
       └─ is_destructive(tool_name)
            └─ PermissionManager.request_permission_async()
                 └─ blocks on asyncio.Future[PermissionResponse]
                      ↑ resolved by:
                 Server.handle_permission_response() ← RPC endpoint
                      ↑ called by:
                 RPCClient.send_permission_response() ← TUI sends
                      ↑ triggered by:
                 PermissionModal (user clicks a button)
```

**Context injection path:**
When user selects "Add Context", the tool call is blocked and the error message returned to the react loop includes the user's context string. The loop writes this as a user message into the conversation — the LLM reads it on the next iteration and adapts.

**Accept All path:**
When the user selects "Accept All", `permission_manager.accept_all = True` is set server-side. All future `request_permission_async` calls short-circuit (no modal shown). The TUI displays a persistent indicator and binds `Tab` to call the `permission.set_accept_all` RPC endpoint to toggle it back off.

---

## What Is "Destructive"

```python
DESTRUCTIVE_TOOLS = {
    "write_file",
    "update_file",
    "create_file",
    "edit_file",
    "delete_file",
    "run_command",
}
```

Everything else (read_file, search_files, search_code, list_directory, get_file_info, fetch, todo_*, task_complete, get_logs, run_test) is safe and requires no approval.

---

## Implementation Steps

### Step 1 — Extend `PermissionManager` (backend data model)

**Files:** `src/ctrlcode/permissions.py`

Changes:
- Add `PermissionResponse` dataclass: `approved: bool`, `accept_all: bool = False`, `context: str | None = None`
- Add `DESTRUCTIVE_TOOLS: frozenset[str]` constant and `is_destructive(tool_name) -> bool`
- Add `accept_all: bool = False` flag to `PermissionManager`
- Change `_pending_requests` from `Future[bool]` → `Future[PermissionResponse]`
- Update `request_permission_async` to:
  - Short-circuit immediately when `self.accept_all is True`
  - Return `tuple[bool, str | None]` — `(approved, context)`
- Update `handle_permission_response(request_id, response: PermissionResponse)`
- Add `set_accept_all(val: bool)` method
- Update global `request_permission()` helper to return `(bool, str | None)`

No callers change in this step — write_file still calls the old signature and will be updated in Step 2.

---

### Step 2 — Central permission check in `ToolExecutor`

**Files:** `src/ctrlcode/tools/executor.py`, `src/ctrlcode/session/manager.py`

Changes:
- Add `permission_manager: PermissionManager | None = None` to `ToolExecutor.__init__`
- In `execute()`, before calling the tool function:
  ```python
  if self.permission_manager and is_destructive(tool_name):
      approved, context = await self.permission_manager.request_permission_async(
          operation=tool_name,
          path=arguments.get("path", arguments.get("command", "")),
          reason=f"Agent wants to run {tool_name}",
          details={"input": arguments},
      )
      if not approved:
          error = "Operation rejected by user."
          if context:
              error += f"\nUser context: {context}"
          return ToolCallResult(tool_name=tool_name, call_id=call_id,
                                success=False, error=error)
  ```
- In `session/manager.py` (or wherever ToolExecutor is instantiated): pass `permission_manager` through
- Remove the one-off permission check from `write_file()` in `tools/explore.py` (now handled centrally)

---

### Step 3 — Extend the RPC layer

**Files:** `src/tui/client.py`, `src/ctrlcode/server.py`

Changes to `client.py`:
- `send_permission_response(request_id, approved, *, accept_all=False, context=None)`
- Add `set_accept_all(val: bool)` method calling new `permission.set_accept_all` RPC endpoint

Changes to `server.py`:
- `handle_permission_response` RPC handler: parse `accept_all` and `context` from params, build `PermissionResponse`, call `manager.handle_permission_response(request_id, response)`
- Add `handle_set_accept_all` handler for `permission.set_accept_all` RPC method
- Route both in `handle_rpc()`
- When accept_all changes, yield a `accept_all_changed` stream event to the TUI session so the indicator updates

---

### Step 4 — Redesign `PermissionModal`

**Files:** `src/tui/widgets/modals/permission_modal.py`

Full redesign:

```
┌─────────────────────────────────────────────┐
│ ⚠  Permission Required                      │
│─────────────────────────────────────────────│
│ Operation:  write_file                      │
│ Path:       src/foo.py                      │
│ Reason:     Agent wants to run write_file   │
│─────────────────────────────────────────────│
│ [ ✓ Approve ] [ ⚡ Accept All ] [ ✗ Reject ]│
│ [ ✎ Add Context ]                           │
│─────────────────────────────────────────────│
│ ⚡ Accept All permits ALL future operations │
│   without prompting. Tab to disable later.  │
└─────────────────────────────────────────────┘
```

When "Add Context" is clicked, an inline `TextArea` appears:
```
┌─────────────────────────────────────────────┐
│ Add context for the agent:                  │
│ ┌─────────────────────────────────────────┐ │
│ │ Don't write to foo.py, use the config   │ │
│ │ system instead.                         │ │
│ └─────────────────────────────────────────┘ │
│ [ Submit ] [ Cancel ]                       │
└─────────────────────────────────────────────┘
```

Button actions:
- **Approve** → `send_permission_response(request_id, approved=True)`
- **Accept All** → `send_permission_response(request_id, approved=True, accept_all=True)`
- **Reject** → `send_permission_response(request_id, approved=False)`
- **Add Context → Submit** → `send_permission_response(request_id, approved=False, context=text)`

---

### Step 5 — TUI accept_all indicator + Tab key binding

**Files:** `src/tui/app.py`, `src/tui/widgets/status_line.py`

Changes to `app.py`:
- Add `accept_all_active: reactive[bool] = reactive(False)`
- Handle `accept_all_changed` stream event: update `accept_all_active`
- Bind `Tab` key → `action_toggle_accept_all()`
- `action_toggle_accept_all()` calls `await self.client.set_accept_all(not self.accept_all_active)` — only active when `accept_all_active` is True (Tab is a no-op otherwise, preserving normal focus behavior when accept_all is off)
- Watch `accept_all_active`: show/hide a status indicator

Changes to `status_line.py` (or inline in app):
- When `accept_all_active` is True: show `"⚡ Accept All — Tab to disable"` indicator in a clearly visible location (e.g., below the input, in warning color)
- When False: indicator is hidden

---

### Step 6 — Tests

**Files:** `tests/test_permissions.py` (extend), `tests/tools/test_executor.py` (extend)

- `test_is_destructive_write_file` — write_file is destructive
- `test_is_destructive_read_file` — read_file is not
- `test_permission_response_dataclass` — all fields
- `test_request_permission_accept_all_short_circuits` — when accept_all=True, no callback fired
- `test_request_permission_returns_context` — context flows through future
- `test_executor_blocks_destructive_tool_on_deny` — executor returns error when denied
- `test_executor_injects_context_on_add_context` — error message contains user context
- `test_executor_skips_check_for_safe_tools` — read_file executes without permission check

---

## Key Design Decisions

**Why ToolExecutor, not pre-tool hook?**
The pre-tool hook yields events but doesn't control execution — the executor runs regardless. The executor is the single chokepoint for all built-in tools and returns `ToolCallResult`, which naturally carries denial errors back into the conversation.

**Why return `(bool, context)` from `request_permission_async`?**
Keeps the executor code simple. The executor just checks the bool and, if denied, includes context in the error string — no new result types needed.

**Why Tab key for accept_all toggle?**
When accept_all is active, normal focus-cycling Tab behaviour is not needed (no modal is open). Tab is easy to reach, memorable, and creates a clear "press once to enable trust, press once to revoke" mental model. When accept_all is not active, Tab does nothing (passes through naturally).

**Why inline TextArea for context, not a separate modal?**
Fewer UI layers. The user already has the tool details visible — adding context inline keeps the context of what they're responding to.
