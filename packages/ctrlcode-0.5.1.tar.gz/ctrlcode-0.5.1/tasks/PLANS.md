# Improvement Plans Index

Derived from comparative analysis of ctrl+code vs deepagents. Work these in order — earlier plans unblock later ones.

## Dependency Order

```
1. Middleware Architecture      ← foundation for everything
2. Pluggable Backends           ← depends on middleware pattern being clear
3. Private State Attributes     ← small, do alongside 1 or 2
4. Dangling Tool Call Recovery  ← standalone, easy win anytime
5. Schema Migration             ← standalone, easy win anytime
6. Proactive Context Monitoring ← needs session manager to be stable (after 1)
7. Agent-Triggered Compaction   ← reuses summarization logic from 6 (do after 6)
8. Skills Progressive Disclosure ← standalone, can be done anytime after 1
```

## Plans

| # | Plan | File | Status |
|---|------|------|--------|
| 1 | Middleware-First Architecture | [plan_middleware_architecture.md](plan_middleware_architecture.md) | done |
| 2 | Pluggable Backends | [plan_pluggable_backends.md](plan_pluggable_backends.md) | done |
| 3 | Private State Attributes | [plan_private_state.md](plan_private_state.md) | done |
| 4 | Dangling Tool Call Recovery | [plan_patch_tool_calls.md](plan_patch_tool_calls.md) | done |
| 5 | Schema Migration | [plan_schema_migration.md](plan_schema_migration.md) | done |
| 6 | Proactive Context Monitoring | [plan_context_monitoring.md](plan_context_monitoring.md) | done |
| 7 | Agent-Triggered Compaction | [plan_agent_compaction.md](plan_agent_compaction.md) | done |
| 8 | Skills Progressive Disclosure | [plan_skills_system.md](plan_skills_system.md) | done |

## Notes

- Plans 6 and 7 are coupled — implement 6 first, 7 reuses its summarization logic
- Plan 4 is the smallest (~60 lines new code, 2 small edits) — good warmup
- Plan 1 is the largest and most architectural — review carefully before starting
- Update status above to `in_progress` / `done` as work proceeds
