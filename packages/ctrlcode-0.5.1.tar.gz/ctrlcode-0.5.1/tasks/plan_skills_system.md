# Skills System (Progressive Disclosure) — Implementation Plan

## Overview

The current skills system provides slash-command expansion: when a user types `/commit`, the registry replaces the input with the full SKILL.md instructions text. This works, but it's invisible to the model during normal conversation — the model doesn't know skills exist unless the user explicitly invokes them.

The goal is to add a second delivery mechanism: **system prompt injection**. Skills are injected into every turn's system prompt in a `<skills>` block so the model can reason about them contextually and apply them unprompted when appropriate.

This is purely additive. The slash-command path in `SkillRegistry.process_input` stays intact. The new path is a read-only rendering pass in `build_system_prompt`.

---

## What Already Exists (Do Not Duplicate)

- `src/ctrlcode/skills/loader.py` — `SkillLoader` + `Skill` dataclass, folder-based discovery
- `src/ctrlcode/skills/registry.py` — `SkillRegistry`, slash-command expansion
- `src/ctrlcode/skills/builtin/` — 5 built-in skills (commit, refactor, test, review, docs)
- `src/ctrlcode/server.py:_load_skills()` — loads builtin, global (`~/.config/ctrlcode/skills/`), and config-dir skills
- `src/ctrlcode/session/manager.py` — receives `skill_registry`, calls `process_input` per turn

---

## Gaps to Fill

### Gap 1: No project-level skills path (`.ctrlcode/skills/`)
`_load_skills` does not auto-detect `{workspace_root}/.ctrlcode/skills/`.

### Gap 2: Precedence is inverted in `load_from_paths`
`SkillLoader.load_from_paths` uses "first wins". For the desired behaviour (project overrides global, global overrides builtin), the caller must pass paths in ascending priority order AND the loader must let later entries win.

### Gap 3: No system prompt injection
`build_system_prompt` in `system_prompt.py` has no awareness of skills. `SessionManager` holds `skill_registry` but never passes it to `build_system_prompt`.

### Gap 4: No `<skills_guidelines>` block in system prompt
The model needs instructions explaining what skills are, that they exist, and how/when to use them contextually.

### Gap 5: SKILL.md format undocumented
The existing format uses `## Metadata` with freeform lines. YAML frontmatter would make machine-parsing reliable.

---

## SKILL.md Format Spec

### Current format (keep backward-compatible)

```markdown
# <Name>

<one-line description when no README.md>

## Instructions

<body>

## Examples

```
/name [args]
```

## Metadata

- **Requires arguments**: Yes|No
```

### Proposed addition: YAML frontmatter (optional, progressive)

```markdown
---
name: refactor
description: Refactor a specific function or module for clarity and maintainability
license: builtin
requires_args: true
---

# Refactor

...body...
```

The loader should parse frontmatter if present and fall back to existing inference if absent. Both old and new skills work without changes.

**Fields:**
- `name` (str, optional) — overrides folder name if set
- `description` (str) — short one-liner for the `<skills>` listing
- `license` (str: `builtin` | `user` | `project`) — informational
- `requires_args` (bool) — cleaner than the prose-parsed `## Metadata` section

---

## Example — `debug-session` Skill (new builtin)

```markdown
---
name: debug-session
description: Structured debugging workflow: reproduce, isolate, root-cause, fix, verify
license: builtin
requires_args: false
---

# Debug Session

## When to Use

Use when the user reports a bug, unexpected behaviour, or failing test and wants a
systematic fix, not just a patch.

## Instructions

1. **Reproduce**: Read the error message or test output carefully. Run the failing command.
2. **Isolate**: Narrow the scope — read the relevant files, identify the failing call site.
3. **Root cause**: Trace through the logic. Don't guess; confirm with a read or run.
4. **Fix**: Make the minimal change that resolves the root cause. Avoid side-effects.
5. **Verify**: Re-run the failing test or command and show the output.

Never apply a workaround if you can find the actual cause.

## Examples

```
/debug-session TypeError in src/foo.py line 42
```
```

---

## Skills Discovery / Loading Algorithm

### Path Priority (ascending — last writer wins)

1. `{package}/skills/builtin/` — shipped with ctrlcode (lowest)
2. `~/.config/ctrlcode/skills/` — global user skills
3. `{workspace_root}/.ctrlcode/skills/` — project-level skills (**new**, auto-detected)
4. `config.skills_directory` — explicit config override (highest)

### Algorithm (in `server._load_skills`)

```python
# Load builtin → register all
skill_registry.register_all(builtin_loader.load_all())

# Load global (if path exists) → overwrite same-named skills
if global_skills_dir.exists():
    skill_registry.register_all(global_loader.load_all(source="global"))

# Load project-local (workspace/.ctrlcode/skills/, if exists) → overwrite
if config.workspace_root:
    project_skills_dir = config.workspace_root / ".ctrlcode" / "skills"
    if project_skills_dir.exists():
        project_loader = SkillLoader(project_skills_dir)
        skill_registry.register_all(project_loader.load_all(source="project"))

# Load config.skills_directory (if set) → overwrite
if config.skills_directory:
    skill_registry.register_all(config_loader.load_all(source="config"))
```

`SkillRegistry.register_all` already uses dict assignment which overwrites — no change needed there. The only missing step is adding the project-local path.

---

## System Prompt Injection Design

### The `<skills>` block

```
<skills>
Available skills — invoke with /name [args] or reference contextually:

commit        — Create a semantic git commit (analyzes diff, stages, writes message)
refactor      — Refactor a function or module: provide the target as an argument
test          — Run test suite, analyze failures, suggest missing coverage
review        — Review current git diff for quality, bugs, and security issues
docs          — Document a class/function: provide the target as an argument
debug-session — Structured debug workflow: reproduce → isolate → fix → verify
</skills>

<skills_guidelines>
Skills are reusable workflows. The rules:
- Invoke a skill explicitly when the user types /name or says "use the X skill"
- Apply a skill's instructions implicitly when the user's request clearly matches its intent
  (e.g., "write tests for foo.py" → apply test skill approach without being told)
- Never mention skills by name unless the user asked for them by name
- Do not invent skill names that don't exist in the list above
</skills_guidelines>
```

### Rendering rules

- Emit the block only when at least one skill is registered
- The listing shows: left-aligned name (padded to max_name_length + 2), em-dash, description
- Full skill body is NOT included — it would inflate tokens for skills never used. The full body is only injected via slash-command expansion (existing path).
- `<skills_guidelines>` is a static string, same every turn.

---

## Layering / Precedence Rules

| Source | Path | Precedence |
|--------|------|------------|
| Builtin | `src/ctrlcode/skills/builtin/` | Lowest |
| Global | `~/.config/ctrlcode/skills/` | Medium |
| Project | `.ctrlcode/skills/` | High |
| Config override | `config.skills_directory` | Highest |

A project skill with the same name as a builtin replaces it entirely (both in registry and in the `<skills>` injection listing). No merge of bodies.

---

## Affected Files

| File | Change |
|------|--------|
| `src/ctrlcode/skills/loader.py` | Add YAML frontmatter parsing; add `source` field to `Skill` |
| `src/ctrlcode/skills/registry.py` | Add `render_system_prompt_block()` method |
| `src/ctrlcode/session/system_prompt.py` | Accept `skill_registry` param; inject `<skills>` + `<skills_guidelines>` |
| `src/ctrlcode/session/manager.py` | Pass `self.skill_registry` into `build_system_prompt` call |
| `src/ctrlcode/server.py` | Add `.ctrlcode/skills/` project-local path in `_load_skills` |
| `src/ctrlcode/skills/builtin/debug-session/SKILL.md` | New builtin skill |
| `tests/test_skill_registry.py` | Tests for `render_system_prompt_block` |
| `tests/test_skills_loader.py` | Tests for frontmatter parsing |
| `tests/test_system_prompt.py` | Tests for skills injection |

---

## Step-by-Step Implementation Tasks

### Phase 1 — Loader Improvements

- [ ] Add `source: str` field to `Skill` dataclass (default `""`)
- [ ] Add YAML frontmatter parsing to `SkillLoader.load_skill`:
  - If content starts with `---`, split on second `---`, parse YAML block (a 10-line mini-parser using `re` for the 4 known keys suffices — avoid new deps)
  - Populate `name`, `description`, `requires_args` from frontmatter if present
  - Fall back to existing inference when frontmatter absent
- [ ] Update `_parse_requires_args` and `_parse_examples` to skip YAML block when present
- [ ] Add `source` parameter to `load_skill` and propagate through `load_all` and `load_from_paths`

### Phase 2 — Registry: System Prompt Rendering

- [ ] Add `render_system_prompt_block(self) -> str` to `SkillRegistry`:
  - Returns `""` if no skills registered
  - Returns the `<skills>...</skills>` block with name + description table
  - Returns the `<skills_guidelines>...</skills_guidelines>` block appended
  - Name column width = max skill name length + 2

### Phase 3 — Project-Local Skills Discovery

- [ ] In `server._load_skills`, after loading global skills, add auto-detection of `{workspace_root}/.ctrlcode/skills/`
- [ ] Set `source="project"` on skills loaded from this path

### Phase 4 — System Prompt Injection

- [ ] Update `build_system_prompt` signature in `system_prompt.py`: add `skill_registry: Optional[SkillRegistry] = None`
- [ ] Insert skills block into content assembly (after `agent_section`, before `env_section`):
  ```python
  if skill_registry:
      skills_block = skill_registry.render_system_prompt_block()
      if skills_block:
          content += f"\n\n{skills_block}"
  ```
- [ ] Update the call site in `manager.py` `process_turn` to pass `self.skill_registry`

### Phase 5 — New Builtin Skills

- [ ] Create `src/ctrlcode/skills/builtin/debug-session/SKILL.md` (structured debug workflow — see example above)
- [ ] Optionally update existing builtin skills to use YAML frontmatter for cleaner descriptions

### Phase 6 — Tests

- [ ] `tests/test_skill_registry.py` — add tests for `render_system_prompt_block`:
  - Empty registry returns `""`
  - Non-empty returns `<skills>` block with all registered skill names
  - Description fallback when empty
- [ ] `tests/test_skills_loader.py` — add tests for frontmatter parsing:
  - Skill with frontmatter: name, description, requires_args from YAML
  - Skill without frontmatter: existing inference still works
  - Malformed frontmatter: falls back gracefully
- [ ] `tests/test_system_prompt.py` — new or extend existing:
  - `build_system_prompt` with `skill_registry=None` produces no `<skills>` block
  - `build_system_prompt` with populated registry includes `<skills>` and `<skills_guidelines>`

---

## 3 Additional Skills Useful for ctrl+code

### 1. `plan` (new builtin)

```markdown
---
name: plan
description: Write a tasks/todo.md plan with checkboxes before implementing anything
license: builtin
requires_args: true
---
```

Enforces the planning workflow: write a `tasks/todo.md` with checkboxes, confirm with user before acting.

### 2. `pr` (new builtin)

```markdown
---
name: pr
description: Create a GitHub pull request: summarize commits, push branch, open PR
license: builtin
requires_args: false
---
```

Encapsulates the standard PR creation flow: check branch, summarize changes since base, push, open PR with gh CLI, return URL.

### 3. `debug-session` (described above)

---

## Testing Approach

**Unit tests (fast, no I/O)**
- `test_skill_registry.py`: `render_system_prompt_block` formatting edge cases
- `test_skills_loader.py`: YAML frontmatter parsing, fallback behaviour, `source` field propagation

**Integration tests (tmp_path, real file I/O)**
- Extend existing loader tests for frontmatter variants
- `test_system_prompt_integration.py`: construct a real `SkillRegistry`, populate with 2 skills, run `build_system_prompt`, assert `<skills>` and `<skills_guidelines>` appear

**Manual smoke test**
- Start server, run `skills.list` RPC call, confirm project-local `.ctrlcode/skills/` skill appears and overrides a same-named global skill
