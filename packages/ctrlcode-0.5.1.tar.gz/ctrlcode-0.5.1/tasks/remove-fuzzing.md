# Plan: Remove Fuzzing Subsystem

## Why
- `_execute_test` in `derived_orchestrator.py` is `random.random() < 0.2` — tests never actually run
- The oracle is derived by the same LLM that wrote the code; no independence, so divergences don't signal correctness
- Multiple LLM calls per code write (context derivation + test generation + per-divergence analysis) for zero real verification benefit
- Real verification is already handled by the test runner detection + `task_complete` guard

---

## Files to Delete

- [ ] `src/ctrlcode/fuzzing/` (entire directory)
  - `__init__.py`
  - `analyzer.py`
  - `budget.py`
  - `context.py`
  - `context_fuzzer.py`
  - `derived_orchestrator.py`
  - `oracle_adapter.py`
- [ ] `src/ctrlcode/analysis/bug_detector.py` — only referenced from fuzzing

---

## Files to Modify

### `src/ctrlcode/config.py`
- [ ] Delete `FuzzingConfig` dataclass
- [ ] Remove `fuzzing: FuzzingConfig` field from `CtrlCodeConfig`
- [ ] Remove fuzzing parse block in `from_dict()`

### `src/ctrlcode/server.py`
- [ ] Remove `from .fuzzing.derived_orchestrator import DerivedFuzzingOrchestrator` import
- [ ] Remove fuzzing orchestrator init block (~lines 79–97)
- [ ] Remove `fuzzing_orchestrator` and `fuzzing_enabled` from `SessionManager(...)` call
- [ ] Remove `self.fuzzing_orchestrator = fuzzing_orchestrator` assignment
- [ ] Remove `get_history_metrics()` method (or stub it to return `{"enabled": False}` if the route is needed)

### `src/ctrlcode/session/manager.py`
- [ ] Remove `from ..fuzzing.derived_orchestrator import DerivedFuzzingOrchestrator` import
- [ ] Remove `fuzzing_orchestrator` and `fuzzing_enabled` params from `__init__`
- [ ] Remove `self.fuzzing_orchestrator` and `self.fuzzing_enabled` assignments
- [ ] Remove the `fuzzing_orchestrator.set_memory()` call in `_ensure_memory()`
- [ ] Remove `fuzz_messages` variable (used only to pass to pre_tool_hook for fuzzing)
- [ ] Simplify `make_pre_tool_hook(...)` call — remove fuzzing args

### `src/ctrlcode/session/hooks.py`
- [ ] Remove `fuzzing_enabled` and `fuzzing_orchestrator` params from `make_pre_tool_hook()`
- [ ] Remove step 3 ("Fuzz write content") from the hook body — delete the `async for ev in maybe_fuzz_tool_content(...)` block
- [ ] Delete `maybe_fuzz_tool_content()` function entirely
- [ ] Delete `_WRITE_TOOLS` set (only used by `maybe_fuzz_tool_content`)
- [ ] Remove `from ..fuzzing.derived_orchestrator import FuzzingResult` lazy import inside the function

### `src/ctrlcode/analysis/synthesizer.py`
- [ ] Check imports and remove any fuzzing references

### `src/ctrlcode/metrics/dashboard.py`
- [ ] Check imports and remove any fuzzing references

### `src/ctrlcode/__init__.py`
- [ ] Remove any fuzzing exports

---

## Verification

- [ ] `uv run python -c "from ctrlcode.server import CtrlCodeServer"` — no import errors
- [ ] `uv run pytest` — test suite passes (even if pre-existing failures exist)
- [ ] Grep for any remaining `fuzzing` imports: `grep -r "from.*fuzzing" src/`
