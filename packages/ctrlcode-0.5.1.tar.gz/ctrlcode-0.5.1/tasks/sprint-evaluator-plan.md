# Sprint Evaluator Architecture

GAN-inspired Planner → [Generator ↔ Evaluator sprint loop] with pluggable verifiers.

## Design decisions locked in
- V1 sprint model: feature-at-a-time with DoD negotiation before each sprint
- Context stays continuous (no resets); saliency handles context growth
- Planner controls verifier metadata per sprint (type, order, parallelism)
- Hard gate default (must pass to proceed); soft gate mode available for exploratory tasks
- Failure after max_retries → pause and report to user
- Agent-to-agent communication via files

---

## Implementation checklist

### Phase 1 — Config & data models
- [ ] Add `SprintConfig` to `config.py` (`max_retries: int = 3`, `gate_mode: str = "hard"`)
- [ ] Add `SprintConfig` to `Config` dataclass and `Config.load()`
- [ ] Create `src/ctrlcode/agents/sprint.py`:
  - `VerifierConfig` dataclass (type, args, parallel flag)
  - `Sprint` dataclass (id, feature description, verifier_configs, status)
  - `SprintContract` dataclass (sprint_id, what_will_be_built, acceptance_criteria, verifier_steps)
  - `SprintResult` dataclass (sprint_id, passed, findings, retry_count)
  - `GateMode` enum (HARD, SOFT)

### Phase 2 — Verifier subsystem
- [ ] Create `src/ctrlcode/agents/verifiers/` package:
  - `base.py`: `Verifier` protocol (`verify(contract, workspace) -> VerifierResult`)
  - `test_runner.py`: `TestRunnerVerifier` — runs a command, checks exit code + output
  - `registry.py`: `VerifierRegistry` — maps type string → Verifier instance
- [ ] `VerifierResult` dataclass (passed, output, findings)

### Phase 3 — Evaluator agent
- [ ] `prompts/agents/evaluator.md` — evaluator system prompt:
  - Role: validate sprint contract criteria, not code review
  - Run verifiers, interpret output against DoD
  - Produce structured pass/fail + specific findings for generator
  - Hard gate: block on any criterion failure; soft gate: advise and continue
- [ ] Add `get_evaluator_config()` to `AgentRegistry` in `registry.py`
  - Tools: `run_command`, `read_file`, `fetch` (for browser verifier later)
  - `max_delegation_depth = 0` (no sub-delegation)

### Phase 4 — SprintOrchestrator
- [ ] Create `src/ctrlcode/agents/sprint_orchestrator.py`:
  - `SprintOrchestrator` class
  - `run(spec, sprints, gate_mode, max_retries)` async method
  - Per-sprint flow:
    1. `_negotiate_dod(sprint)` → writes `sprint_{id}_contract.md`, both agents agree
    2. `_build(sprint, contract)` → runs coder agent
    3. `_verify(sprint, contract, attempt)` → runs evaluator + verifiers
    4. Retry loop up to `max_retries`
    5. On exhaustion: emit `sprint_failed` event, pause for user
  - Soft gate: evaluator findings injected as context, build continues regardless

### Phase 5 — Planner integration
- [ ] Update `prompts/agents/planner.md`:
  - Output structured spec with sprint list
  - Each sprint includes: feature description + `verifiers` block (type, args, parallel)
  - Example verifier entries: `test_runner(command="uv run pytest")`, `browser`, `formal`
- [ ] Update `AgentResultParser.parse_planner_result()` in `result_parser.py`:
  - Parse sprint list and verifier configs from planner output
  - Return `list[Sprint]` alongside existing task graph

### Phase 6 — Workflow integration
- [ ] Update `WorkflowOrchestrator` in `workflow.py`:
  - After planner phase, pass sprints to `SprintOrchestrator`
  - Thread `gate_mode` and `max_retries` from config
  - Emit sprint lifecycle events: `sprint_start`, `sprint_pass`, `sprint_fail`, `sprint_user_intervention`

### Phase 7 — Tests
- [ ] `tests/agents/test_sprint.py` — data model unit tests
- [ ] `tests/agents/verifiers/test_test_runner.py` — TestRunnerVerifier
- [ ] `tests/agents/test_sprint_orchestrator.py` — orchestrator with mocked agents/verifiers
  - Hard gate blocks on failure
  - Soft gate continues with findings
  - Retry exhaustion triggers user notification
  - DoD negotiation produces contract file

---

## New files
```
src/ctrlcode/agents/sprint.py
src/ctrlcode/agents/verifiers/__init__.py
src/ctrlcode/agents/verifiers/base.py
src/ctrlcode/agents/verifiers/test_runner.py
src/ctrlcode/agents/verifiers/registry.py
src/ctrlcode/agents/sprint_orchestrator.py
prompts/agents/evaluator.md
tests/agents/test_sprint.py
tests/agents/verifiers/test_test_runner.py
tests/agents/test_sprint_orchestrator.py
```

## Modified files
```
src/ctrlcode/config.py              — SprintConfig
src/ctrlcode/agents/registry.py    — evaluator agent config
src/ctrlcode/agents/result_parser.py — parse sprint list from planner
src/ctrlcode/agents/workflow.py     — plug in SprintOrchestrator
prompts/agents/planner.md           — sprint + verifier metadata output
```
