# Pluggable Backends Plan

## Overview

Currently all I/O in ctrl+code is performed directly by the tool classes (`ExploreTools`, `UpdateFileTools`, `BashTools`, `TodoTools`) and the memory subsystem (`ArtifactStore`, `FileTreeIndex`, `DependencyIndexer`, `WorkspaceMonitor`). Every one of these classes calls `open()`, `subprocess.run()`, `Path.glob()`, `Path.rglob()`, `os.walk()`, or `aiosqlite.connect()` directly against real disk.

The goal is to introduce a `BackendProtocol` that abstracts I/O, then retrofit the five tool classes to call the backend instead of the OS directly. Three concrete backends will be provided:

- `FilesystemBackend` — wraps the current behavior, identical semantics, zero behaviour change for production
- `StateBackend` — pure in-memory dict, ephemeral, no disk required, enables fast unit tests
- `CompositeBackend` — routes by path prefix, useful for mixing real and mock paths

The `ArtifactStore` / SQLite layer is explicitly out of scope for Phase 1. It already has a clean boundary (`ArtifactStore` is injected into consumers) and swapping its storage would require a separate `StorageBackend` protocol. That is noted as Phase 2.

---

## Affected Files

Files that do direct filesystem or subprocess access and will need to be migrated:

| File | I/O type |
|---|---|
| `src/ctrlcode/tools/explore.py` | `Path.glob`, `open()`, `os.walk`, `subprocess.run` (ripgrep) |
| `src/ctrlcode/tools/update.py` | `open()`, `fcntl`, temp file write + atomic rename |
| `src/ctrlcode/tools/bash.py` | `subprocess.run` |
| `src/ctrlcode/tools/todo.py` | `open()`, `fcntl`, `Path.mkdir`, temp file write + atomic rename |
| `src/ctrlcode/session/hooks.py` | `Path.write_text`, `Path.mkdir` (progress file) |
| `src/ctrlcode/session/prompt_builder.py` | `Path.read_text`, `Path.exists` (prompt/AGENT.md loading) |
| `src/ctrlcode/memory/file_tree.py` | `Path.rglob`, `open()` (SHA-256 hashing), `Path.stat` |
| `src/ctrlcode/memory/workspace_monitor.py` | `Path.rglob`, `Path.is_file`, `Path.suffix` |
| `src/ctrlcode/memory/dependency_indexer.py` | `open()` (source file reading for AST parse) |

Files **not** in scope (no raw I/O, or I/O is behind an already-clean boundary):

- `src/ctrlcode/memory/store.py` — SQLite via `aiosqlite`, Phase 2
- `src/ctrlcode/tools/webfetch.py` — HTTP via `httpx`, not disk I/O
- `src/ctrlcode/tools/browser.py` — browser automation, not disk I/O
- `src/ctrlcode/tools/mcp.py` — subprocess for MCP servers (separate concern)
- `src/ctrlcode/checkpoint.py` — no I/O

---

## Backend Protocol Interface Design

New file: `src/ctrlcode/backends/protocol.py`

```python
"""BackendProtocol — abstract I/O interface for ctrl+code tool layer."""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class BackendProtocol(Protocol):
    """
    Defines all I/O operations performed by built-in tools.

    Implementations:
      FilesystemBackend  — real disk (default, production)
      StateBackend       — in-memory dict (testing, sandboxing)
      CompositeBackend   — routes by path prefix
    """

    def read(
        self,
        path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Read a file. Returns {content, total_lines} or {error}."""
        ...

    def ls(self, path: str = ".", *, max_depth: int = 1) -> dict[str, Any]:
        """List a directory. Returns {directories, files} or {error}."""
        ...

    def glob(self, pattern: str, *, max_results: int = 100) -> list[str]:
        """Return relative paths matching a glob pattern."""
        ...

    def grep(
        self,
        pattern: str,
        *,
        file_glob: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        """Search file contents. Returns [{file, line, content}]."""
        ...

    def stat(self, path: str) -> dict[str, Any]:
        """Return file metadata (size, mtime, is_file, is_dir)."""
        ...

    def write(self, path: str, content: str) -> dict[str, Any]:
        """Create a new file (fails if exists). Returns {success, path, bytes_written}."""
        ...

    def overwrite(self, path: str, content: str) -> dict[str, Any]:
        """Write content to path, creating or replacing. Atomic."""
        ...

    def edit(self, path: str, old_content: str, new_content: str) -> dict[str, Any]:
        """Replace old_content with new_content (atomic). Returns {success, path}."""
        ...

    def write_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        """Write raw bytes."""
        ...

    def execute(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        """
        Run a shell command. Returns {stdout, stderr, returncode}.
        Raise NotImplementedError for backends that disallow execution (sandbox).
        """
        ...
```

---

## Step-by-Step Implementation Tasks

### Phase 1 — Protocol + FilesystemBackend (no behaviour change)

- [ ] 1.1  Create `src/ctrlcode/backends/` package with `__init__.py`
- [ ] 1.2  Write `src/ctrlcode/backends/protocol.py` with `BackendProtocol` as above
- [ ] 1.3  Write `src/ctrlcode/backends/filesystem.py` — `FilesystemBackend` implements `BackendProtocol` by moving the exact current logic out of the tool classes (one method per protocol method)
- [ ] 1.4  Verify `FilesystemBackend` passes `isinstance(fs, BackendProtocol)` at runtime
- [ ] 1.5  Add `__all__` export in `src/ctrlcode/backends/__init__.py`

### Phase 2 — StateBackend (in-memory)

- [ ] 2.1  Write `src/ctrlcode/backends/state.py` — `StateBackend`. Stores files in `dict[str, str]` keyed by normalised relative path. `glob()` uses `fnmatch.fnmatch`. `grep()` iterates dict values with `re.search`. `execute()` raises `NotImplementedError`.
- [ ] 2.2  Write unit tests for `StateBackend` in `tests/backends/test_state_backend.py` covering: write/read round-trip, glob, grep, stat, edit, path-not-found errors

### Phase 3 — CompositeBackend

- [ ] 3.1  Write `src/ctrlcode/backends/composite.py` — `CompositeBackend`. Constructor: `mounts: list[tuple[str, BackendProtocol]]`. Route: find longest-prefix mount, strip prefix, delegate. Default/fallback mount for paths that don't match any prefix.
- [ ] 3.2  Write unit tests `tests/backends/test_composite_backend.py`

### Phase 4 — Wire backend into ExploreTools

- [ ] 4.1  Change `ExploreTools.__init__` signature: `def __init__(self, workspace_root, backend: BackendProtocol | None = None)`. If `backend is None`, default to `FilesystemBackend(workspace_root)`.
- [ ] 4.2  Replace `Path.glob(...)` in `search_files` → `backend.glob(...)`
- [ ] 4.3  Replace `open(file_path)` in `read_file` → `backend.read(...)`
- [ ] 4.4  Replace `os.walk(...)` in `list_directory` → `backend.ls(...)`
- [ ] 4.5  Replace `subprocess.run(["rg", ...])` in `search_code` → `backend.grep(...)`. `_fallback_search` also migrates to `backend.grep()`.
- [ ] 4.6  Replace `file_path.stat()` in `get_file_info` → `backend.stat(...)`
- [ ] 4.7  Replace `open(file_path, "w")` in `write_file` → `backend.write(...)`
- [ ] 4.8  Update `setup_explore_tools()` in `src/ctrlcode/tools/__init__.py` to accept optional `backend` kwarg and pass it through
- [ ] 4.9  Extend tests in `tests/test_explore_tools.py` — add a parallel test class using `StateBackend` to prove identical semantics

### Phase 5 — Wire backend into UpdateFileTools

- [ ] 5.1  Change `UpdateFileTools.__init__` to accept optional `backend`
- [ ] 5.2  Replace `open(file_path, "r")` reads → `backend.read(...)`
- [ ] 5.3  Replace the temp-file + fcntl + atomic rename write sequence → read via backend, compute new content in Python, call `backend.overwrite(path, new_content)`
- [ ] 5.4  Update `setup_update_tools()` to thread backend through
- [ ] 5.5  Update tests in `tests/test_update_file.py` + add StateBackend variant

### Phase 6 — Wire backend into BashTools

- [ ] 6.1  Change `BashTools.__init__` to accept optional `backend`
- [ ] 6.2  Replace `subprocess.run(command, ...)` → `backend.execute(command, cwd=..., timeout=...)`
- [ ] 6.3  `FilesystemBackend.execute()` keeps the current subprocess logic
- [ ] 6.4  `StateBackend.execute()` raises `NotImplementedError`
- [ ] 6.5  Update `setup_bash_tools()` to thread backend through
- [ ] 6.6  Update tests in `tests/test_bash_tools.py`

### Phase 7 — Wire backend into TodoTools

- [ ] 7.1  Change `TodoTools.__init__` to accept optional `backend`
- [ ] 7.2  `_read_todos` uses `backend.read(...)` instead of `open()`
- [ ] 7.3  `_write_todos` uses `backend.overwrite(...)` instead of temp-file/fcntl (StateBackend overwrite is inherently atomic)
- [ ] 7.4  Update `setup_todo_tools()` and tests

### Phase 8 — Wire backend into session/hooks.py

- [ ] 8.1  `write_progress_file`: add optional `backend` parameter. Default: use `Path.write_text` (unchanged). With backend: call `backend.overwrite(str(progress_file), content)`.

### Phase 9 — session/prompt_builder.py (intentionally skipped)

`load_base_prompt` and `load_agent_instructions` read from `~/.config/ctrlcode/`. These are host meta-config reads, not workspace I/O. Leave them using plain `Path.read_text` — they operate on the host, not the sandboxed workspace.

### Phase 10 — Wire backend into memory/ (lower priority)

- [ ] 10.1  `DependencyIndexer.index_file()` reads source files with `open()`. Add a `backend` kwarg, default to `FilesystemBackend`. Low impact.
- [ ] 10.2  `FileTreeIndex.scan()` walks the real workspace — tightly coupled to SQLite/ArtifactStore. Defer until StorageBackend (Phase 2).

### Phase 11 — CLI wiring

- [ ] 11.1  Locate the CLI entry point (server/app init code that calls `setup_*_tools`)
- [ ] 11.2  Confirm no backend kwarg is passed → `FilesystemBackend` is instantiated by default inside each tool class. Zero change to CLI behaviour.
- [ ] 11.3  Document how to pass a `StateBackend` or `CompositeBackend` to the setup functions for programmatic use.

### Phase 12 — Tests demonstrating StateBackend value

- [ ] 12.1  Add `tests/backends/` package
- [ ] 12.2  `test_explore_tools_with_state_backend.py` — prepopulate `StateBackend` with virtual files, assert `search_files`, `read_file`, `list_directory`, `grep` work. No `tmp_path`, no disk I/O.
- [ ] 12.3  `test_update_file_with_state_backend.py` — prepopulate, call `update_file`, assert result in backend memory
- [ ] 12.4  `test_composite_backend_routing.py` — mount `StateBackend` at `virtual/`, `FilesystemBackend` at root. Assert reads to `virtual/foo.py` hit state, others hit disk.

---

## Migration Strategy

The migration is strictly incremental. Each phase is independently mergeable:

1. Phases 1–3 add new files only. No existing code is modified. CI stays green.
2. Phases 4–9 each touch exactly one tool class + its companion `setup_*` function + its tests. Each phase can be a single commit.
3. The backend parameter is optional in every constructor and setup function. The default (`None` → `FilesystemBackend`) means callers that don't pass a backend are unaffected.
4. The existing test suite continues to pass throughout because `tmp_path` (a real temp dir) causes `FilesystemBackend` to be selected by default.
5. No big-bang rewrite. Each phase can be reviewed and merged independently.

The only coordination constraint: Phase 1 (protocol + `FilesystemBackend`) must land before any of Phases 4–9.

---

## Key Design Decisions

1. **`workspace_root` is kept on tool classes** — needed for security path-containment checks. `FilesystemBackend` receives `workspace_root` and enforces the same checks. `StateBackend` enforces containment against its own virtual root.

2. **`execute()` in the protocol** — having it in the protocol allows `CompositeBackend` to route execution to a specific sub-backend. `StateBackend` raises `NotImplementedError` by design — this is the sandboxing mechanism.

3. **`ArtifactStore` / SQLite is out of scope for Phase 1** — it is already injected as a dependency and its boundary is already clean.

4. **`TodoTools` uses file locking (`fcntl`)** — `StateBackend.overwrite()` is inherently atomic (dict assignment), so `fcntl` disappears naturally. `FilesystemBackend.overwrite()` retains the temp-file + rename approach.

5. **`session/prompt_builder.py` is not migrated** — it reads from `~/.config/ctrlcode/` (host config, not workspace). Don't conflate workspace I/O with host configuration.

---

## Testing Approach: StateBackend enables disk-free unit tests

```python
# tests/backends/test_explore_tools_state.py

import pytest
from ctrlcode.backends.state import StateBackend
from ctrlcode.tools.explore import ExploreTools


@pytest.fixture
def state():
    b = StateBackend()
    b._files = {
        "src/main.py":   "def main():\n    pass\n",
        "src/utils.py":  "import os\n",
        "README.md":     "# Project\n",
    }
    return b


def test_search_files_no_disk(state):
    tools = ExploreTools(workspace_root="/virtual", backend=state)
    result = tools.search_files("**/*.py")
    assert "src/main.py" in result
    assert "src/utils.py" in result
    assert "README.md" not in result


def test_read_file_no_disk(state):
    tools = ExploreTools(workspace_root="/virtual", backend=state)
    result = tools.read_file("src/main.py")
    assert result["content"] == "def main():\n    pass\n"
    assert result["total_lines"] == 2


def test_grep_no_disk(state):
    tools = ExploreTools(workspace_root="/virtual", backend=state)
    results = tools.search_code("import")
    assert any(r["file"] == "src/utils.py" for r in results)
```
