# Behavioral Telemetry System — Implementation Plan

## Overview

Add privacy-preserving behavioral telemetry to ctrl+code. Collects anonymous
usage patterns (which tools, session duration, which features are used) to
enable the developer to understand real-world usage and optimize the product.

**Hard constraints:**
- Never collect: file paths, file contents, code, user text, tool inputs/outputs,
  error messages, MCP server names, workspace paths, API keys, skill content
- Always anonymous: no user identity, session IDs match local logs, install ID is stable per installation
- Non-blocking: telemetry never adds latency to the request path
- Opt-out via `[telemetry] enabled = false` in config.toml

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        ctrl+code process                        │
│                                                                 │
│  HarnessServer / SessionManager / ToolExecutor / Workflow       │
│        │                                                        │
│        │  collector.track(event)  ← fire-and-forget            │
│        ▼                                                        │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              TelemetryCollector (singleton)             │    │
│  │  - enabled flag (from TelemetryConfig)                  │    │
│  │  - asyncio.Queue[TelemetryEvent]  (maxsize=2000)        │    │
│  │  - install_id (UUID4, stable per installation)          │    │
│  │  - session_id  (raw session UUID, matches local logs)   │    │
│  └───────────────────────┬─────────────────────────────────┘    │
│                          │  (background task, never blocks)      │
│  ┌───────────────────────▼─────────────────────────────────┐    │
│  │              TelemetryExporter (background)             │    │
│  │  - drains queue into batch (up to 50 events)            │    │
│  │  - flushes every 60s OR on process shutdown             │    │
│  │  - httpx.AsyncClient POST to endpoint                   │    │
│  │  - all failures swallowed silently                      │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────┘
```

### Module Layout

```
src/ctrlcode/telemetry/
    __init__.py          # public re-exports
    events.py            # TelemetryEvent dataclass + typed factory functions
    install_id.py        # UUID4 generation, generate-once file persistence
    collector.py         # TelemetryCollector: queue, track(), close()
    exporter.py          # TelemetryExporter: background flush loop, httpx POST
```

---

## Privacy Model

| Dimension | Approach |
|-----------|----------|
| Tool names | Passed through as-is |
| Slash commands | Passed through as-is |
| Provider / model | Passed through (public identifiers, not secrets) |
| Error info | Only `type(exc).__name__` transmitted. Message never touched |
| Token counts | Integer counts only, never associated with content |
| Session IDs | Passed through as-is. Matches local logs so users can correlate telemetry with their own debug output |
| Install ID | UUID4 in `get_config_dir() / "install_id"`. Generated once, persists for life of the installation |
| Platform | `platform.system()`, `platform.release()`, `sys.version` only |

**Never collected:** file paths, file contents, code snippets, user message text, tool
inputs, tool outputs, error messages, MCP names/commands, workspace paths, API keys,
custom skill names or prompts.

---

## Events Collected

| Event | Key Fields |
|-------|-----------|
| `session_started` | provider, model, platform, os_name, python_version |
| `session_ended` | session_duration_s, turn_count, total_output_tokens |
| `turn_completed` | duration_ms, input_tokens, output_tokens, tool_calls_count, had_fuzzing, had_error |
| `tool_called` | tool_name (allowlisted), duration_ms, success |
| `slash_command_used` | command (allowlisted) |
| `fuzzing_completed` | iterations_used, max_iterations, outcome, tokens_used, duration_ms |
| `workflow_executed` | phases_completed, agents_spawned, tasks_completed, had_error |
| `error_occurred` | error_class (class name only), component |
| `context_compacted` | tokens_before, tokens_after, compression_ratio |

All events include: `event_type`, `timestamp_utc`, `install_id`, `app_version`, `session_id`.

---

## Integration Points

| Location | File | What |
|----------|------|------|
| Config dataclass | `config.py` | Add `TelemetryConfig`, parse `[telemetry]` TOML section |
| Server startup | `server.py` `_startup()` | Start collector, first-run notice |
| Server shutdown | `server.py` `_shutdown()` | `await collector.flush_and_close()` |
| Session creation | `server.py` `create_session()` | Emit `session_started` |
| Session clear | `server.py` `clear_session()` | Emit `session_ended` |
| Turn completion | `session/manager.py` `process_turn()` | Emit `turn_completed` |
| Tool execution | `tools/executor.py` `execute()` | Emit `tool_called`, `error_occurred` |
| Fuzzing | `session/hooks.py` `maybe_fuzz_tool_content()` | Emit `fuzzing_completed` |
| Workflow | `server.py` `execute_workflow()` | Emit `workflow_executed` |
| Context compact | `session/manager.py` `compact_conversation()` | Emit `context_compacted` |
| Slash commands | `session/manager.py` `process_turn()` skill branch | Emit `slash_command_used` |

---

## Step Dependency Order

```
A1 → A2 → A3 (needs A1+A2) → A4 (needs A1) → A5 (needs A1-A4)
B1  (independent — config.py only)
C1 (needs A5 + B1)
C2 (needs C1)
D1 (needs A5 + C1)
D2 (needs A5 + C1)
E1 (needs A5 + D1)
E2 (needs A5 + C1)
E3 (needs A5 + D1)
F1 (needs A5 + D1)
F2 (needs A5 + C1 + D1)
```

**Minimum viable pipeline:** A1 → A2 → A3 → A4 → A5 → B1 → C1 → C2 → D1 → D2
This covers session lifecycle, turn metrics, and tool call metrics end-to-end.

---

## Implementation Prompts

---

### Step A1 — Create `src/ctrlcode/telemetry/events.py`

```text
Create src/ctrlcode/telemetry/events.py.

This module defines the event schema and factory functions. No I/O. No external
dependencies beyond Python stdlib.

1. Define a TelemetryEvent dataclass:

    from dataclasses import dataclass, field
    from typing import Any

    @dataclass
    class TelemetryEvent:
        event_type: str
        timestamp_utc: str       # set by factories via datetime.utcnow().isoformat() + "Z"
        install_id: str
        app_version: str
        session_id: str          # raw session UUID, matches local logs
        payload: dict[str, Any]  # event-specific safe fields only

        def to_dict(self) -> dict[str, Any]:
            return {
                "event_type": self.event_type,
                "timestamp_utc": self.timestamp_utc,
                "install_id": self.install_id,
                "app_version": self.app_version,
                "session_id": self.session_id,
                **self.payload,
            }

2. Factory functions — each sets timestamp_utc via datetime.utcnow().isoformat() + "Z"
   internally. install_id, app_version, and session_id are passed in as-is.

    def make_session_started(install_id, app_version, session_id,
                             provider, model, platform_name, os_name,
                             python_version) -> TelemetryEvent

    def make_session_ended(install_id, app_version, session_id,
                           session_duration_s, turn_count,
                           total_input_tokens, total_output_tokens) -> TelemetryEvent

    def make_turn_completed(install_id, app_version, session_id,
                            duration_ms, input_tokens, output_tokens,
                            tool_calls_count, had_fuzzing, had_error) -> TelemetryEvent

    def make_tool_called(install_id, app_version, session_id,
                         tool_name, duration_ms, success) -> TelemetryEvent

    def make_slash_command_used(install_id, app_version, session_id,
                                command) -> TelemetryEvent

    def make_fuzzing_completed(install_id, app_version, session_id,
                               iterations_used, max_iterations, outcome,
                               tokens_used, duration_ms) -> TelemetryEvent
        # outcome must be one of: "pass", "fail", "budget_exhausted"

    def make_workflow_executed(install_id, app_version, session_id,
                               phases_completed, agents_spawned,
                               tasks_completed, had_error) -> TelemetryEvent

    def make_error_occurred(install_id, app_version, session_id,
                            error_class, component) -> TelemetryEvent

    def make_context_compacted(install_id, app_version, session_id,
                               tokens_before, tokens_after,
                               compression_ratio) -> TelemetryEvent

Do not create __init__.py yet.
```

---

### Step A2 — Create `src/ctrlcode/telemetry/install_id.py`

```text
Create src/ctrlcode/telemetry/install_id.py.

Dependencies: stdlib only + ctrlcode.paths.

    from ctrlcode.paths import get_config_dir

    def load_or_create_install_id() -> tuple[str, bool]:
        """
        Return (install_id, is_new_install).

        is_new_install is True only when the install_id file did not previously
        exist (first run on this machine / fresh reinstall).

        Storage: get_config_dir() / "install_id" — a single line UUID4 string.

        Algorithm:
          1. If file exists and content is a non-empty string: return it (is_new_install=False).
          2. Otherwise: generate uuid.uuid4(), atomic-write to file, return (uuid_str, True).
          3. Atomic write: write to .tmp sibling, os.replace() to final path.

        On ANY exception: return (str(uuid.uuid4()), False). Never raise.
        """

Requirements:
- uuid.uuid4() for ID generation
- Atomic write: path.with_suffix(".tmp"), then os.replace()
- Create config dir: config_dir.mkdir(parents=True, exist_ok=True)
- Single try/except Exception wraps all file operations
- No rotation logic, no timestamps, no secondary files
```

---

### Step A3 — Create `src/ctrlcode/telemetry/collector.py`

```text
Create src/ctrlcode/telemetry/collector.py.

Dependencies: events.py, install_id.py.

    import asyncio
    import logging
    from typing import Callable
    from .events import TelemetryEvent
    from .install_id import load_or_create_install_id

    logger = logging.getLogger(__name__)

    _collector: "TelemetryCollector | None" = None

    def get_collector() -> "TelemetryCollector | None":
        return _collector

    def set_collector(collector: "TelemetryCollector") -> None:
        global _collector
        _collector = collector

    class TelemetryCollector:
        def __init__(self, enabled: bool, endpoint: str, app_version: str):
            self.enabled = enabled
            self.endpoint = endpoint
            self.app_version = app_version
            self._is_new_install = False
            if enabled:
                install_id, is_new = load_or_create_install_id()
                self._install_id = install_id
                self._is_new_install = is_new
            else:
                self._install_id = ""
            self._queue: asyncio.Queue[TelemetryEvent] = asyncio.Queue(maxsize=2000)
            self._exporter_task: asyncio.Task | None = None

        def start(self) -> None:
            """Start background exporter. Must be called from running event loop."""
            if not self.enabled:
                return
            from .exporter import TelemetryExporter
            exporter = TelemetryExporter(queue=self._queue, endpoint=self.endpoint)
            self._exporter_task = asyncio.create_task(exporter.run())

        def track(self, event: TelemetryEvent) -> None:
            """Enqueue event. Fire-and-forget. Never blocks. Never raises."""
            if not self.enabled:
                return
            try:
                self._queue.put_nowait(event)
            except asyncio.QueueFull:
                pass  # drop silently

        async def flush_and_close(self) -> None:
            """Drain queue, send remaining, cancel background task. Never raises."""
            if not self.enabled:
                return
            try:
                if self._exporter_task and not self._exporter_task.done():
                    self._exporter_task.cancel()
                    try:
                        await self._exporter_task
                    except (asyncio.CancelledError, Exception):
                        pass
                from .exporter import TelemetryExporter
                exporter = TelemetryExporter(queue=self._queue, endpoint=self.endpoint)
                await exporter.flush_remaining()
            except Exception as e:
                logger.debug(f"Telemetry flush error (non-fatal): {e}")

        def make_event(self, factory_fn: Callable, session_id: str,
                       **kwargs) -> TelemetryEvent:
            """
            Inject install_id + app_version and call factory.
            session_id is passed through as-is so it matches local logs.
            """
            return factory_fn(
                install_id=self._install_id,
                app_version=self.app_version,
                session_id=session_id,
                **kwargs,
            )
```

---

### Step A4 — Create `src/ctrlcode/telemetry/exporter.py`

```text
Create src/ctrlcode/telemetry/exporter.py.

Dependencies: events.py. httpx is in pyproject.toml (>=0.28.1).

    import asyncio
    import logging
    from .events import TelemetryEvent

    logger = logging.getLogger(__name__)

    FLUSH_INTERVAL_S = 60
    BATCH_SIZE = 50

    class TelemetryExporter:
        def __init__(self, queue: asyncio.Queue, endpoint: str):
            self._queue = queue
            self._endpoint = endpoint

        async def run(self) -> None:
            """Background loop: sleep, drain, POST. Exits on CancelledError."""
            try:
                while True:
                    await asyncio.sleep(FLUSH_INTERVAL_S)
                    batch = self._drain_batch()
                    if batch:
                        await self._send_batch(batch)
            except asyncio.CancelledError:
                pass

        async def flush_remaining(self) -> None:
            """Drain all queued events and POST. Called on shutdown."""
            while True:
                batch = self._drain_batch()
                if not batch:
                    break
                await self._send_batch(batch)

        def _drain_batch(self) -> list[TelemetryEvent]:
            batch = []
            for _ in range(BATCH_SIZE):
                try:
                    batch.append(self._queue.get_nowait())
                except asyncio.QueueEmpty:
                    break
            return batch

        async def _send_batch(self, events: list[TelemetryEvent]) -> None:
            """POST batch as JSON. Catches ALL exceptions. Logs DEBUG only. Never raises."""
            try:
                import httpx
                payload = {"events": [e.to_dict() for e in events]}
                async with httpx.AsyncClient(timeout=5.0) as client:
                    response = await client.post(
                        self._endpoint,
                        json=payload,
                        headers={
                            "Content-Type": "application/json",
                            "User-Agent": f"ctrlcode/{events[0].app_version}",
                        },
                    )
                    if response.status_code >= 400:
                        logger.debug(f"Telemetry endpoint returned {response.status_code}")
            except Exception as e:
                logger.debug(f"Telemetry send failed (non-fatal): {e}")
```

---

### Step A5 — Create `src/ctrlcode/telemetry/__init__.py`

```text
Create src/ctrlcode/telemetry/__init__.py.

Re-export the full public surface so callers use `from ctrlcode.telemetry import X`:

    from .collector import TelemetryCollector, get_collector, set_collector
    from .events import (
        TelemetryEvent,
        make_session_started,
        make_session_ended,
        make_turn_completed,
        make_tool_called,
        make_slash_command_used,
        make_fuzzing_completed,
        make_workflow_executed,
        make_error_occurred,
        make_context_compacted,
    )

    __all__ = [
        "TelemetryCollector", "get_collector", "set_collector",
        "TelemetryEvent",
        "make_session_started", "make_session_ended", "make_turn_completed",
        "make_tool_called", "make_slash_command_used", "make_fuzzing_completed",
        "make_workflow_executed", "make_error_occurred", "make_context_compacted",
    ]

No other logic. The telemetry package is now importable but not yet wired in.
```

---

### Step B1 — Add `TelemetryConfig` to `config.py`

```text
Edit src/ctrlcode/config.py.

1. Add dataclass after SecurityConfig:

    @dataclass
    class TelemetryConfig:
        """Behavioral telemetry configuration."""
        enabled: bool = True
        endpoint: str = "https://telemetry.ctrlcode.dev/v1/events"  # receiver service, not S3 directly

2. Add field to Config (after the permissions field):
        telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)

3. In Config.load(), after the permissions parsing block:
        telemetry_data = data.get("telemetry", {})
        telemetry = TelemetryConfig(
            enabled=telemetry_data.get("enabled", True),
            endpoint=telemetry_data.get(
                "endpoint", "https://telemetry.ctrlcode.dev/v1/events"
            ),
        )

4. Pass telemetry=telemetry to the return cls(...) call.

No other changes. All existing behavior preserved.
```

---

### Step C1 — Wire collector into `HarnessServer`

```text
Edit src/ctrlcode/server.py.

Prior steps produced: TelemetryCollector, set_collector from ctrlcode.telemetry.
                      Config.telemetry is TelemetryConfig.

1. In HarnessServer.__init__, after self.tech_debt_metrics = ... block:

        from .telemetry import TelemetryCollector, set_collector
        try:
            import ctrlcode as _cc
            _app_version = getattr(_cc, "__version__", "unknown")
        except Exception:
            _app_version = "unknown"
        self.telemetry = TelemetryCollector(
            enabled=config.telemetry.enabled,
            endpoint=config.telemetry.endpoint,
            app_version=_app_version,
        )
        set_collector(self.telemetry)

2. In _startup, as the FIRST statement:

        self.telemetry.start()
        if self.telemetry.enabled and self.telemetry._is_new_install:
            logger.info(
                "\n"
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                " ctrl+code collects anonymous usage data to improve\n"
                " the tool. No code, paths, or personal data is sent.\n"
                " Opt out: set [telemetry] enabled = false in config.toml\n"
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            )

3. In _shutdown, as the FIRST statement (before tool_registry.close_all):

        await self.telemetry.flush_and_close()
```

---

### Step C2 — Emit `session_started` from `create_session`

```text
Edit src/ctrlcode/server.py, method create_session().

After the session object is assigned (after create_session or resume_session call):

        if self.telemetry.enabled and session is not None:
            import platform, sys
            from .telemetry import make_session_started
            evt = self.telemetry.make_event(
                make_session_started,
                session_id=session.id,
                provider=session.provider.__class__.__name__
                          .replace("Provider", "").lower(),
                model=getattr(session.provider, "model", "unknown"),
                platform_name=platform.system(),
                os_name=platform.release(),
                python_version=sys.version.split()[0],
            )
            self.telemetry.track(evt)
```

---

### Step D1 — Emit `turn_completed` from `process_turn`

```text
Edit src/ctrlcode/session/manager.py, method process_turn().

1. Add at the very TOP of process_turn body:
       import time as _time
       _turn_start = _time.monotonic()
       _had_fuzzing = False

2. Inside the streaming event loop, where fuzzing events are processed, set
   _had_fuzzing = True if a fuzzing-related event_type is detected.

3. At the very END of process_turn (after the final yield):

       from ..telemetry import get_collector, make_turn_completed
       _collector = get_collector()
       if _collector and _collector.enabled:
           _duration_ms = int((_time.monotonic() - _turn_start) * 1000)
           evt = _collector.make_event(
               make_turn_completed,
               session_id=session_id,
               duration_ms=_duration_ms,
               input_tokens=session.context_before_turn,
               output_tokens=session.cumulative_tokens,
               tool_calls_count=0,       # refined in D2
               had_fuzzing=_had_fuzzing,
               had_error=False,          # refined in D2
           )
           _collector.track(evt)

session_id is already a parameter of process_turn.
All telemetry imports are inside the function to avoid circular imports.
```

---

### Step D2 — Emit `tool_called` and `error_occurred` from `ToolExecutor.execute`

```text
Edit src/ctrlcode/tools/executor.py, method execute().

1. Add optional parameter to signature:
       async def execute(self, tool_name: str, arguments: dict,
                         call_id: str, session_id: str = "none") -> ToolCallResult:

   Update all call sites in the codebase to pass session_id where available:
   - In session/manager.py: pass session_id=session_id
   - Other call sites without session_id: pass session_id="none"

2. At top of execute(), before the try block:
       import time as _time
       _tool_start = _time.monotonic()
       _success = False

3. In the success path, just before each return:
       _success = True

4. Replace/augment the except block:
       except Exception as e:
           logger.error(f"Tool execution failed for '{tool_name}': {e}")
           _duration_ms = int((_time.monotonic() - _tool_start) * 1000)
           from ..telemetry import get_collector, make_tool_called, make_error_occurred
           _col = get_collector()
           if _col and _col.enabled:
               _col.track(_col.make_event(
                   make_tool_called, session_id=session_id,
                   tool_name=tool_name, duration_ms=_duration_ms, success=False,
               ))
               _col.track(_col.make_event(
                   make_error_occurred, session_id=session_id,
                   error_class=type(e).__name__, component="tool_executor",
               ))
           return ToolCallResult(tool_name=tool_name, call_id=call_id,
                                 success=False, error=str(e))

5. Add a finally block that emits on success:
       finally:
           if _success:
               _duration_ms = int((_time.monotonic() - _tool_start) * 1000)
               from ..telemetry import get_collector, make_tool_called
               _col = get_collector()
               if _col and _col.enabled:
                   _col.track(_col.make_event(
                       make_tool_called, session_id=session_id,
                       tool_name=tool_name, duration_ms=_duration_ms, success=True,
                   ))
```

---

### Step E1 — Emit `fuzzing_completed` from `maybe_fuzz_tool_content`

```text
Edit src/ctrlcode/session/hooks.py.

First, read src/ctrlcode/fuzzing/budget.py and the FuzzingResult dataclass to
get exact field names (iterations, budget_used, divergences_found, etc.).

After the block that applies the fuzzing result to the tool call, add:

        from ..telemetry import get_collector, make_fuzzing_completed
        _col = get_collector()
        if result and _col and _col.enabled:
            budget = result.budget_used if hasattr(result, "budget_used") else {}
            token_fraction = budget.get("tokens", 0.0)
            time_fraction = budget.get("seconds", 0.0)

            if token_fraction >= 0.99 or time_fraction >= 0.99:
                _outcome = "budget_exhausted"
            elif getattr(result, "divergences_found", 0) > 0:
                _outcome = "fail"
            else:
                _outcome = "pass"

            _max_iter = getattr(result, "max_iterations", 10)
            _iter_used = getattr(result, "iterations", 0)
            _tokens_used = int(token_fraction * getattr(result, "budget_tokens", 100000))
            _duration_ms = int(time_fraction * getattr(result, "budget_seconds", 30) * 1000)

            evt = _col.make_event(
                make_fuzzing_completed,
                session_id=session_id,
                iterations_used=_iter_used,
                max_iterations=_max_iter,
                outcome=_outcome,
                tokens_used=_tokens_used,
                duration_ms=_duration_ms,
            )
            _col.track(evt)

Verify that session_id is already a parameter of maybe_fuzz_tool_content;
add it if missing.
```

---

### Step E2 — Emit `workflow_executed` from `execute_workflow`

```text
Edit src/ctrlcode/server.py, method execute_workflow().

Wrap the orchestrator.handle_user_request() call:

        import time as _wf_time
        _wf_start = _wf_time.monotonic()
        _wf_had_error = False
        _wf_result = None
        try:
            _wf_result = await orchestrator.handle_user_request(user_intent)
            result = _wf_result
        except Exception as _wf_exc:
            _wf_had_error = True
            raise
        finally:
            if self.telemetry.enabled:
                from .telemetry import make_workflow_executed
                _phases: list[str] = []
                _tasks = 0
                _agents = 0
                if _wf_result is not None:
                    task_graph = _wf_result.get("task_graph")
                    if task_graph and hasattr(task_graph, "tasks"):
                        _tasks = len(task_graph.tasks)
                    completed = _wf_result.get("completed_tasks", [])
                    _agents = len(completed) if isinstance(completed, list) else 0
                    _phases = ["planning", "execution", "review", "validation"]
                _wf_session_id = params.get("session_id", "none")
                evt = self.telemetry.make_event(
                    make_workflow_executed,
                    session_id=_wf_session_id,
                    phases_completed=_phases,
                    agents_spawned=_agents,
                    tasks_completed=_tasks,
                    had_error=_wf_had_error,
                )
                self.telemetry.track(evt)

Preserve all existing execute_workflow streaming logic; only wrap the one call.
```

---

### Step E3 — Emit `context_compacted` from `compact_conversation`

```text
Edit src/ctrlcode/session/manager.py, method compact_conversation().

Read the current implementation first to understand the exact structure.
Then replace with:

    def compact_conversation(self, session_id: str) -> None:
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        try:
            tokens_before = self.conv_manager.calculate_context_usage(
                session.conv_id, model=getattr(session.provider, "model", None)
            )
        except Exception:
            tokens_before = 0

        self.conv_manager.prune_before_turn(session.conv_id)

        try:
            tokens_after = self.conv_manager.calculate_context_usage(
                session.conv_id, model=getattr(session.provider, "model", None)
            )
        except Exception:
            tokens_after = tokens_before

        ratio = round(tokens_after / tokens_before, 4) if tokens_before > 0 else 1.0

        from ..telemetry import get_collector, make_context_compacted
        _col = get_collector()
        if _col and _col.enabled:
            evt = _col.make_event(
                make_context_compacted,
                session_id=session_id,
                tokens_before=tokens_before,
                tokens_after=tokens_after,
                compression_ratio=ratio,
            )
            _col.track(evt)
```

---

### Step F1 — Emit `slash_command_used` from skill expansion

```text
Edit src/ctrlcode/session/manager.py, method process_turn().

In the skill expansion block, refactor the `if was_skill:` branch:

        if was_skill:
            _original_input = user_input         # save before overwrite
            yield StreamEvent(type="skill_expanded", ...)
            user_input = expanded_input

            from ..telemetry import get_collector, make_slash_command_used
            _col = get_collector()
            if _col and _col.enabled:
                _cmd = _original_input.strip().split()[0].lstrip("/") \
                       if _original_input.strip() else "unknown"
                evt = _col.make_event(
                    make_slash_command_used,
                    session_id=session_id,
                    command=_cmd,
                )
                _col.track(evt)

command name is passed through as-is.
```

---

### Step F2 — `session_ended` event and `turn_count` tracking

```text
Two changes:

PART 1 — Add turn_count to Session model.
Edit src/ctrlcode/session/models.py:
    @dataclass
    class Session:
        ...existing fields...
        turn_count: int = 0

Edit src/ctrlcode/session/manager.py, end of process_turn():
After the turn_completed telemetry block from D1, add:
    session.turn_count += 1

PART 2 — Emit session_ended from clear_session.
Edit src/ctrlcode/server.py, method clear_session().

Before the existing session clear logic:

    _session_to_clear = None
    try:
        _session_to_clear = self.session_manager.get_session(
            params.get("session_id", "")
        )
    except Exception:
        pass

    if _session_to_clear and self.telemetry.enabled:
        from .telemetry import make_session_ended
        evt = self.telemetry.make_event(
            make_session_ended,
            session_id=_session_to_clear.id,
            session_duration_s=0,
            turn_count=_session_to_clear.turn_count,
            total_input_tokens=0,
            total_output_tokens=_session_to_clear.cumulative_tokens,
        )
        self.telemetry.track(evt)

    # ... existing clear logic follows

If SessionManager.get_session() doesn't exist, add it:
    def get_session(self, session_id: str) -> Session | None:
        return self._store.get(session_id)
```

---

## Collection Service

The client POSTs batches to an HTTP endpoint. That endpoint is a thin receiver — its only job is to append events to S3 as NDJSON and return 200.

### Storage Layout

```
s3://ctrlcode-telemetry/
  events/
    year=2026/month=03/day=17/
      <uuid>.ndjson
      <uuid>.ndjson
    year=2026/month=03/day=18/
      ...
```

One file per batch received. Hive-style date partitioning so DuckDB can prune by date cheaply.

### Receiver

A minimal aiohttp (or FastAPI) service:

```python
@routes.post("/v1/events")
async def receive(request):
    body = await request.json()
    events = body.get("events", [])
    if not events:
        return web.Response(status=200)

    ndjson = "\n".join(json.dumps(e) for e in events)
    key = f"events/year={y}/month={m:02d}/day={d:02d}/{uuid4()}.ndjson"
    await s3.put_object(Bucket=BUCKET, Key=key, Body=ndjson)
    # s3 client configured with endpoint_url pointing at self-hosted store
    return web.Response(status=200)
```

- No auth needed (events are already anonymous, and the worst case is junk data)
- No IP logging
- Failures return 200 anyway — client discards on any response, no retry logic needed

Deploy as a small container on Fly.io, Railway, or a single Lambda + API Gateway.

### Querying with DuckDB

```sql
-- Install + session counts per day
SELECT
    json_extract_string(event, '$.timestamp_utc')::DATE AS day,
    COUNT(DISTINCT json_extract_string(event, '$.install_id'))  AS installs,
    COUNT(DISTINCT json_extract_string(event, '$.session_id'))  AS sessions
FROM read_ndjson_auto('s3://ctrlcode-telemetry/events/**/*.ndjson') AS t(event)
WHERE json_extract_string(event, '$.event_type') = 'session_started'
GROUP BY 1
ORDER BY 1 DESC;

-- Most used tools
SELECT
    json_extract_string(event, '$.tool_name') AS tool,
    COUNT(*) AS calls,
    AVG(json_extract(event, '$.duration_ms')::INT) AS avg_ms
FROM read_ndjson_auto('s3://ctrlcode-telemetry/events/**/*.ndjson') AS t(event)
WHERE json_extract_string(event, '$.event_type') = 'tool_called'
GROUP BY 1
ORDER BY 2 DESC;

-- Fuzzing outcome distribution
SELECT
    json_extract_string(event, '$.outcome') AS outcome,
    COUNT(*) AS n
FROM read_ndjson_auto('s3://ctrlcode-telemetry/events/**/*.ndjson') AS t(event)
WHERE json_extract_string(event, '$.event_type') = 'fuzzing_completed'
GROUP BY 1;
```

DuckDB reads S3-compatible storage directly via the `httpfs` extension — no data pipeline needed.

```sql
INSTALL httpfs;
LOAD httpfs;
SET s3_endpoint = 'your-minio-host:9000';
SET s3_access_key_id = '...';
SET s3_secret_access_key = '...';
SET s3_use_ssl = true;
SET s3_url_style = 'path';  -- MinIO and most self-hosted stores use path style, not virtual-hosted
```

---

## Key Implementation Challenges

1. **asyncio.Queue before event loop:** Queue created in `__init__` (fine Python 3.10+).
   Exporter Task created in `start()` from `_startup()` (running loop). Order enforced.

2. **session_id threading into ToolExecutor:** `execute()` gains `session_id: str = "none"`.
   Three call sites in session/manager.py and session/hooks.py need updating.

3. **FuzzingResult field names:** Read `src/ctrlcode/fuzzing/budget.py` before Step E1
   to confirm exact keys in `budget_used` dict.

4. **Shutdown ordering:** `flush_and_close()` must be FIRST in `_shutdown()`, before
   MCP servers and session manager are closed.

5. **Lazy imports:** All `from ..telemetry import ...` inside function bodies to
   avoid circular imports at module load time.
