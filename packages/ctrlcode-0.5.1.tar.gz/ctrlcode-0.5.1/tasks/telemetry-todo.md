# Telemetry Implementation Todo

Track progress against `tasks/telemetry-plan.md`.

## Module Foundation (A series)

- [ ] **A1** — Create `src/ctrlcode/telemetry/events.py` (TelemetryEvent dataclass, allowlists, factory functions)
- [ ] **A2** — Create `src/ctrlcode/telemetry/install_id.py` (UUID4, weekly rotation, atomic file write)
- [ ] **A3** — Create `src/ctrlcode/telemetry/collector.py` (TelemetryCollector, queue, track(), flush_and_close())
- [ ] **A4** — Create `src/ctrlcode/telemetry/exporter.py` (background flush loop, httpx POST, error swallowing)
- [ ] **A5** — Create `src/ctrlcode/telemetry/__init__.py` (re-exports only)

## Config (B series)

- [ ] **B1** — Add `TelemetryConfig` dataclass to `config.py`, parse `[telemetry]` TOML section

## Server Wiring (C series)

- [ ] **C1** — Wire `TelemetryCollector` into `HarnessServer.__init__`, `_startup()`, `_shutdown()`
- [ ] **C2** — Emit `session_started` from `create_session()`

## Core Metrics (D series)

- [ ] **D1** — Emit `turn_completed` from `session/manager.py process_turn()`
- [ ] **D2** — Emit `tool_called` and `error_occurred` from `tools/executor.py ToolExecutor.execute()`

## Feature Events (E series)

- [ ] **E1** — Emit `fuzzing_completed` from `session/hooks.py maybe_fuzz_tool_content()`
- [ ] **E2** — Emit `workflow_executed` from `server.py execute_workflow()`
- [ ] **E3** — Emit `context_compacted` from `session/manager.py compact_conversation()`

## Session Lifecycle (F series)

- [ ] **F1** — Emit `slash_command_used` from skill expansion branch in `process_turn()`
- [ ] **F2** — Add `turn_count` to Session model; emit `session_ended` from `clear_session()`

---

## Notes

- Minimum viable pipeline: A1 → A2 → A3 → A4 → A5 → B1 → C1 → C2 → D1 → D2
- All telemetry imports must be inside function bodies (lazy) to avoid circular imports
- See full design and code-generation prompts in `tasks/telemetry-plan.md`
