# Permission System — LLM Implementation Prompts

Each prompt below is self-contained and builds on the previous. Read the relevant source files before implementing each step. The plan is in `tasks/PLAN.md`.

---

## Prompt 1 — Extend PermissionManager

```
You are implementing Step 1 of a permission system for ctrl+code.

Read the current file in full before making any changes:
  src/ctrlcode/permissions.py

Make the following changes to that file:

1. Add a `PermissionResponse` dataclass at the top (after imports):
   - `approved: bool`
   - `accept_all: bool = False`
   - `context: str | None = None`

2. Add two constants directly below the dataclasses:
   ```python
   DESTRUCTIVE_TOOLS: frozenset[str] = frozenset({
       "write_file",
       "update_file",
       "create_file",
       "edit_file",
       "delete_file",
       "run_command",
   })

   def is_destructive(tool_name: str) -> bool:
       """Return True if tool_name requires user permission before running."""
       return tool_name in DESTRUCTIVE_TOOLS
   ```

3. On `PermissionManager`:
   - Add `accept_all: bool = False` as an instance attribute in `__init__`
   - Change `_pending_requests` type annotation from `dict[str, asyncio.Future]` to
     `dict[str, asyncio.Future[PermissionResponse]]`
   - Add a `set_accept_all(self, val: bool) -> None` method that sets `self.accept_all = val`

4. In `request_permission_async`:
   - As the very first check (before the cache check), add:
     ```python
     if self.accept_all:
         return (True, None)
     ```
   - Change the return type annotation to `-> tuple[bool, str | None]`
   - Change `future: asyncio.Future[bool] = asyncio.Future()` to
     `future: asyncio.Future[PermissionResponse] = asyncio.Future()`
   - Change `approved = await asyncio.wait_for(future, timeout=timeout)` to
     `response = await asyncio.wait_for(future, timeout=timeout)`
   - After that line, update the cache logic:
     ```python
     if response.approved and response.accept_all:
         self.accept_all = True
     if response.approved and remember:
         self._approved_paths.add(cache_key)
     return (response.approved, response.context)
     ```
   - Change the timeout return to `return (False, None)`
   - Change the exception return to `return (False, None)`

5. In `handle_permission_response`:
   - Change signature to `handle_permission_response(self, request_id: str, response: PermissionResponse) -> None`
   - Change `future.set_result(approved)` to `future.set_result(response)`
   - Update the log line accordingly

6. Update the global `request_permission()` helper function:
   - Change return type annotation to `-> tuple[bool, str | None]`
   - Change `return await manager.request_permission_async(...)` — no changes needed to the call itself since the method signature already changed
   - Change the fallback `return True` to `return (True, None)`

Do not change anything else. Do not add docstrings or comments to code you did not touch.
After implementing, run:
  uv run pytest tests/test_permissions.py -q
All existing tests should still pass (they will need no changes since new behavior is additive).
```

---

## Prompt 2 — Central permission check in ToolExecutor

```
You are implementing Step 2 of a permission system for ctrl+code.

Step 1 is complete. `PermissionResponse`, `DESTRUCTIVE_TOOLS`, `is_destructive()`, and the updated
`request_permission_async() -> tuple[bool, str | None]` all exist in `src/ctrlcode/permissions.py`.

Read these files in full before making changes:
  src/ctrlcode/tools/executor.py
  src/ctrlcode/session/manager.py
  src/ctrlcode/tools/explore.py

Changes to `src/ctrlcode/tools/executor.py`:

1. At the top, add to imports:
   ```python
   from ..permissions import PermissionManager, is_destructive
   ```

2. Add `permission_manager: PermissionManager | None = None` as a parameter to `ToolExecutor.__init__`
   and store it as `self.permission_manager = permission_manager`.

3. In `ToolExecutor.execute()`, add the permission check BEFORE the tool is called (i.e., before the
   `if tool_def` block that dispatches to built-in vs MCP). Insert:
   ```python
   # Permission check for destructive tools
   if self.permission_manager and is_destructive(tool_name):
       path_or_cmd = arguments.get("path", arguments.get("command", ""))
       approved, context = await self.permission_manager.request_permission_async(
           operation=tool_name,
           path=str(path_or_cmd),
           reason=f"Agent wants to {tool_name.replace('_', ' ')}",
           details={"arguments": arguments},
       )
       if not approved:
           error = "Operation rejected by user."
           if context:
               error += f"\nUser context: {context}"
           return ToolCallResult(
               tool_name=tool_name,
               call_id=call_id,
               success=False,
               error=error,
           )
   ```

Changes to `src/ctrlcode/session/manager.py`:

4. Find where `ToolExecutor` is instantiated. Pass `permission_manager=self.permission_manager`
   (or however the permission manager is accessible on the session/manager). The exact variable name
   may vary — look for `ToolExecutor()` in the file. Do not break any other arguments.

Changes to `src/ctrlcode/tools/explore.py`:

5. Find the one-off permission check inside `write_file()`. It calls `request_permission(...)`.
   Remove that block entirely — the executor now handles it centrally.
   Keep the rest of `write_file()` unchanged.

After implementing, run:
  uv run pytest tests/tools/test_executor.py tests/test_permissions.py -q
All existing tests should still pass.
```

---

## Prompt 3 — Extend the RPC layer

```
You are implementing Step 3 of a permission system for ctrl+code.

Steps 1 and 2 are complete. `PermissionResponse` exists, `PermissionManager.handle_permission_response`
now takes a `PermissionResponse`, and `ToolExecutor` does the central permission check.

Read these files in full before making changes:
  src/tui/client.py
  src/ctrlcode/server.py

Changes to `src/tui/client.py`:

1. Update `send_permission_response` signature to:
   ```python
   async def send_permission_response(
       self,
       request_id: str,
       approved: bool,
       *,
       accept_all: bool = False,
       context: str | None = None,
   ) -> dict[str, Any]:
   ```
   Update the `params` dict to include `accept_all` and `context`:
   ```python
   "params": {
       "request_id": request_id,
       "approved": approved,
       "accept_all": accept_all,
       "context": context,
   },
   ```

2. Add a new method `set_accept_all`:
   ```python
   async def set_accept_all(self, enabled: bool) -> dict[str, Any]:
       """Enable or disable accept-all mode server-side."""
       async with httpx.AsyncClient() as client:
           response = await client.post(
               f"{self.base_url}/rpc",
               json={
                   "jsonrpc": "2.0",
                   "method": "permission.set_accept_all",
                   "params": {"enabled": enabled},
                   "id": self._next_id(),
               },
               headers=self._get_headers(),
               timeout=5.0,
           )
           data = response.json()
           if "error" in data:
               raise RuntimeError(f"RPC error: {data['error']}")
           return data["result"]
   ```

Changes to `src/ctrlcode/server.py`:

3. Find `handle_permission_response` (the method that handles the `permission.response` RPC call).
   Update it to:
   - Import `PermissionResponse` from `..permissions` at the top of the method (or module imports)
   - Parse `accept_all = params.get("accept_all", False)` and `context = params.get("context")` from params
   - Build a `PermissionResponse(approved=approved, accept_all=accept_all, context=context)`
   - Call `manager.handle_permission_response(request_id, response)` (updated signature from Step 1)

4. Add a new handler method `handle_set_accept_all`:
   ```python
   async def handle_set_accept_all(self, params: dict) -> dict:
       enabled = params.get("enabled", False)
       manager = get_permission_manager()
       if manager:
           manager.set_accept_all(enabled)
           # Emit accept_all_changed event to TUI for the current session
           # (find how other events are broadcast to TUI — use the same pattern)
       return {"ok": True, "accept_all": enabled}
   ```

5. In `handle_rpc()` (the method that dispatches RPC method names), add a route:
   - `"permission.set_accept_all"` → `await self.handle_set_accept_all(params)`

6. When accept_all state changes (either via `handle_permission_response` receiving `accept_all=True`,
   or via `handle_set_accept_all`), emit a stream event of type `"accept_all_changed"` with
   `data={"enabled": bool}` to the active TUI session. Follow the existing pattern for how
   `permission_request` events are broadcast — use the same mechanism.

Do not change any other methods. After implementing, run the full test suite:
  uv run pytest -q
All tests should still pass.
```

---

## Prompt 4 — Redesign PermissionModal

```
You are implementing Step 4 of a permission system for ctrl+code.

Steps 1–3 are complete. `client.send_permission_response` now accepts `accept_all` and `context`.

Read these files in full before making changes:
  src/tui/widgets/modals/permission_modal.py
  src/tui/widgets/modal_base.py

Completely replace `PermissionModal` with the following design. Keep the same class name and
constructor signature (add no new constructor params). Replace only the CSS, `compose()`,
and event handlers.

Layout:
```
┌─────────────────────────────────────────────────────┐
│ ⚠  Permission Required                              │
├─────────────────────────────────────────────────────┤
│ Operation:  write_file                              │
│ Path:       src/ctrlcode/tools/explore.py           │
│ Reason:     Agent wants to write file               │
├─────────────────────────────────────────────────────┤
│  [ ✓ Approve ]  [ ⚡ Accept All ]  [ ✗ Reject ]    │
│  [ ✎ Add Context ]                                  │
├─────────────────────────────────────────────────────┤
│ ⚡ Accept All permits ALL future destructive        │
│   operations without prompting. Press Tab in the    │
│   main view to disable it at any time.              │
└─────────────────────────────────────────────────────┘
```

When "Add Context" is pressed, an additional section appears BELOW the buttons:
```
├─────────────────────────────────────────────────────┤
│ Add context for the agent:                          │
│ ┌─────────────────────────────────────────────────┐ │
│ │                                                 │ │
│ └─────────────────────────────────────────────────┘ │
│  [ Submit Context ]  [ Cancel ]                     │
└─────────────────────────────────────────────────────┘
```

Implementation requirements:

1. Import `TextArea` from `textual.widgets` (alongside existing imports).

2. Add `_context_visible: bool = False` as an instance attribute.

3. In `compose()`:
   - Render the header, details section, and four action buttons as shown.
   - Render a `Container(id="context-section")` that contains:
     - `Static("Add context for the agent:")`
     - `TextArea(id="context-input")`
     - A row with `Button("Submit Context", id="submit-context", variant="primary")`
       and `Button("Cancel", id="cancel-context")`
   - The context section starts hidden: add `classes="hidden"` to it.

4. In CSS, add:
   ```css
   .hidden { display: none; }
   #context-section { padding: 1 2; }
   #context-input { height: 4; margin: 1 0; }
   .accept-all-note { color: $warning; padding: 1 2; }
   .button-row { layout: horizontal; }
   ```

5. Handle button presses in `on_button_pressed`:
   - `"approve"`: call `await self._respond(approved=True)` then `self.dismiss()`
   - `"accept-all"`: call `await self._respond(approved=True, accept_all=True)` then `self.dismiss()`
   - `"reject"`: call `await self._respond(approved=False)` then `self.dismiss()`
   - `"add-context"`: toggle `_context_visible`, show/hide `#context-section` by toggling the
     `"hidden"` class, then focus the `TextArea`
   - `"submit-context"`: read `self.query_one("#context-input", TextArea).text`,
     call `await self._respond(approved=False, context=text.strip())`, then `self.dismiss()`
   - `"cancel-context"`: hide the context section (add `"hidden"` class back), clear the TextArea

6. Add helper `_respond`:
   ```python
   async def _respond(
       self,
       approved: bool,
       accept_all: bool = False,
       context: str | None = None,
   ) -> None:
       try:
           await self.app.client.send_permission_response(
               self.request_id,
               approved,
               accept_all=accept_all,
               context=context,
           )
       except Exception as e:
           self.app.notify(f"Failed to send permission response: {e}", severity="error")
   ```

Keep the constructor and `__init__` exactly as they are now. Only change CSS, `compose()`, and handlers.
```

---

## Prompt 5 — TUI accept_all indicator + Tab key binding

```
You are implementing Step 5 of a permission system for ctrl+code.

Steps 1–4 are complete. The modal can send accept_all=True. The server emits an
"accept_all_changed" stream event when accept_all state changes.

Read these files in full before making changes:
  src/tui/app.py

You need to make four focused changes:

1. **Reactive state**: Near where other `reactive` attributes are defined, add:
   ```python
   accept_all_active: reactive[bool] = reactive(False)
   ```

2. **Handle stream event**: In `_handle_stream_event` (the large dispatch method), add a case for
   the new event type. Find where `"permission_request"` is handled and add nearby:
   ```python
   elif event_type == "accept_all_changed":
       self.accept_all_active = event.get("data", {}).get("enabled", False)
       return
   ```

3. **Tab key binding and action**:
   - In the BINDINGS list (or wherever key bindings are defined), add:
     `Binding("tab", "toggle_accept_all", "Toggle Accept All", show=False)`
   - Add the action method:
     ```python
     async def action_toggle_accept_all(self) -> None:
         """Toggle accept-all mode off. No-op when not active."""
         if not self.accept_all_active:
             return
         try:
             await self.client.set_accept_all(False)
             self.accept_all_active = False
         except Exception as e:
             self.notify(f"Failed to disable accept-all: {e}", severity="error")
     ```
   Note: when `accept_all_active` is False, Tab falls through to normal Textual focus cycling
   because the action returns immediately. Only when accept_all is active does Tab do something.

4. **Visual indicator**: Add a `watch_accept_all_active` method to react to changes:
   ```python
   def watch_accept_all_active(self, active: bool) -> None:
       try:
           indicator = self.query_one("#accept-all-indicator")
           indicator.display = active
       except Exception:
           pass
   ```
   Find a good location in the main layout (compose method) to add a `Static` widget
   that serves as the indicator:
   ```python
   yield Static(
       "⚡ Accept All mode active — press Tab to disable",
       id="accept-all-indicator",
       classes="accept-all-indicator",
   )
   ```
   Start it with `display = False`. Add CSS:
   ```css
   #accept-all-indicator {
       background: $warning 30%;
       color: $warning;
       text-style: bold;
       padding: 0 2;
       display: none;
   }
   ```

Make only these four changes. Do not refactor anything else. After implementing, run:
  uv run pytest -q
All tests should still pass.
```

---

## Prompt 6 — Tests

```
You are implementing Step 6 of a permission system for ctrl+code.

Steps 1–5 are complete. Read these files before writing tests:
  src/ctrlcode/permissions.py
  src/ctrlcode/tools/executor.py
  tests/test_permissions.py       (existing tests to understand patterns)
  tests/tools/test_executor.py    (existing tests to understand patterns)

Add the following tests.

To `tests/test_permissions.py`, add a new section:

```python
# ---------------------------------------------------------------------------
# New in permission system v2
# ---------------------------------------------------------------------------

def test_is_destructive_write_file():
    from ctrlcode.permissions import is_destructive
    assert is_destructive("write_file") is True

def test_is_destructive_update_file():
    from ctrlcode.permissions import is_destructive
    assert is_destructive("update_file") is True

def test_is_destructive_run_command():
    from ctrlcode.permissions import is_destructive
    assert is_destructive("run_command") is True

def test_is_not_destructive_read_file():
    from ctrlcode.permissions import is_destructive
    assert is_destructive("read_file") is False

def test_is_not_destructive_search_files():
    from ctrlcode.permissions import is_destructive
    assert is_destructive("search_files") is False

def test_permission_response_defaults():
    from ctrlcode.permissions import PermissionResponse
    r = PermissionResponse(approved=True)
    assert r.accept_all is False
    assert r.context is None

def test_accept_all_short_circuits(manager):
    """When accept_all is set, no callback is fired."""
    manager.set_accept_all(True)
    # Must run in an event loop — use anyio
    import anyio
    async def _run():
        approved, context = await manager.request_permission_async("write_file", "a.py", "test")
        assert approved is True
        assert context is None
    anyio.from_thread.run_sync(lambda: None)  # ensure loop exists
    import asyncio
    asyncio.run(_run())

@pytest.mark.anyio
async def test_accept_all_short_circuits_async():
    from ctrlcode.permissions import PermissionManager
    fired = []
    async def cb(req_id, req):
        fired.append(req_id)
    mgr = PermissionManager(approval_callback=cb)
    mgr.set_accept_all(True)
    approved, context = await mgr.request_permission_async("write_file", "a.py", "test")
    assert approved is True
    assert fired == []  # callback never fired

@pytest.mark.anyio
async def test_permission_response_carries_context():
    from ctrlcode.permissions import PermissionManager, PermissionResponse
    import asyncio
    async def cb(req_id, req):
        # Simulate user responding with context
        response = PermissionResponse(approved=False, context="use config system")
        mgr.handle_permission_response(req_id, response)
    mgr = PermissionManager(approval_callback=cb)
    approved, context = await mgr.request_permission_async("write_file", "a.py", "test")
    assert approved is False
    assert context == "use config system"

@pytest.mark.anyio
async def test_accept_all_flag_set_on_accept_all_response():
    from ctrlcode.permissions import PermissionManager, PermissionResponse
    async def cb(req_id, req):
        mgr.handle_permission_response(req_id, PermissionResponse(approved=True, accept_all=True))
    mgr = PermissionManager(approval_callback=cb)
    approved, context = await mgr.request_permission_async("write_file", "a.py", "test")
    assert approved is True
    assert mgr.accept_all is True
```

To `tests/tools/test_executor.py`, add a new section:

```python
# ---------------------------------------------------------------------------
# Permission system integration
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_executor_blocks_destructive_tool_when_denied():
    from ctrlcode.permissions import PermissionManager, PermissionResponse
    async def cb(req_id, req):
        mgr.handle_permission_response(req_id, PermissionResponse(approved=False))
    mgr = PermissionManager(approval_callback=cb)

    registry = MagicMock()
    registry.get_tool.return_value = None  # tool not needed since check fires first
    executor = ToolExecutor(registry=registry, permission_manager=mgr)

    result = await executor.execute("write_file", {"path": "foo.py", "content": "x"}, "call1")
    assert result.success is False
    assert "rejected" in result.error.lower()

@pytest.mark.anyio
async def test_executor_includes_context_in_error():
    from ctrlcode.permissions import PermissionManager, PermissionResponse
    async def cb(req_id, req):
        mgr.handle_permission_response(req_id, PermissionResponse(approved=False, context="use config"))
    mgr = PermissionManager(approval_callback=cb)

    registry = MagicMock()
    registry.get_tool.return_value = None
    executor = ToolExecutor(registry=registry, permission_manager=mgr)

    result = await executor.execute("write_file", {"path": "foo.py", "content": "x"}, "call1")
    assert "use config" in result.error

@pytest.mark.anyio
async def test_executor_skips_permission_for_safe_tools():
    """read_file should execute without any permission check."""
    from ctrlcode.permissions import PermissionManager
    fired = []
    async def cb(req_id, req):
        fired.append(req_id)
    mgr = PermissionManager(approval_callback=cb)

    # Set up a real-ish tool registry that returns a sync function
    registry = MagicMock()
    tool_def = MagicMock()
    tool_def.func = lambda path: {"content": "hello"}
    tool_def.is_async = False
    tool_def.required_params = []
    tool_def.server_name = None
    registry.get_tool.return_value = tool_def
    registry.is_builtin.return_value = True

    executor = ToolExecutor(registry=registry, permission_manager=mgr)
    result = await executor.execute("read_file", {"path": "README.md"}, "call2")
    assert fired == []  # no permission check for safe tools
```

Run:
  uv run pytest tests/test_permissions.py tests/tools/test_executor.py -q
All tests should pass.
```

---

## Integration Checklist

Before calling the feature complete, verify:

- [ ] `uv run pytest -q` — all tests pass, 0 warnings
- [ ] Start server + TUI, ask agent to write a file → modal appears with 4 buttons
- [ ] Click "Approve" → file is written, no indicator shown
- [ ] Ask agent to write again → modal appears again (single approval, not cached)
- [ ] Click "Accept All" → file is written, `"⚡ Accept All mode active"` indicator appears
- [ ] Ask agent to write again → NO modal, file written silently
- [ ] Press `Tab` → indicator disappears, next write shows modal again
- [ ] Click "Reject" on a write → tool returns error, agent adjusts on next turn
- [ ] Click "Add Context", type text, Submit → tool returns error with context in message, agent uses it
- [ ] Ask agent to `run_command` → modal appears (run_command is destructive)
- [ ] Ask agent to `search_files` → NO modal (search_files is safe)
