# Schema Migration Plan for rootset.db

## Overview

`rootset.db` is a SQLite database initialized by `ArtifactStore._ensure_init()` in `src/ctrlcode/memory/store.py`. Currently the DDL is applied via `executescript(_DDL)` (idempotent `CREATE ... IF NOT EXISTS`) and two additive `ALTER TABLE` statements in a `_MIGRATIONS` list are silently retried on every startup — swallowing all errors with a bare `except: pass`. This means:

- There is no record of which migrations have run.
- Non-additive changes (rename column, drop table, add index with constraints) have no safe path.
- A user upgrading across a schema-breaking release loses their store silently or gets corrupted data.

This plan replaces the informal `_MIGRATIONS` list with a proper versioned migration runner: a `schema_version` table, sequential numbered migration functions, and a `ctrlcode-db` CLI sub-command to inspect or run migrations without starting the full server.

---

## Current Schema Audit

All tables, columns, and indexes defined in `_DDL` (plus the two existing `_MIGRATIONS`):

### Table: `artifacts`
| Column | Type | Constraints |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| namespace | TEXT | NOT NULL DEFAULT 'default' |
| kind | TEXT | NOT NULL |
| content | TEXT | NOT NULL |
| metadata | TEXT | NOT NULL DEFAULT '{}' |
| content_hash | TEXT | NOT NULL |
| created_at | TEXT | NOT NULL |
| updated_at | TEXT | NOT NULL |
| source_file_hash | TEXT | (added by `_MIGRATIONS[0]`) |

Indexes: `idx_art_ns(namespace)`, `idx_art_kind(kind)`, `idx_art_hash(content_hash)`

### Virtual Table: `artifacts_fts` (FTS5)
Columns mirrored: `kind`, `content`
Triggers: `art_fts_ins`, `art_fts_del`, `art_fts_upd`

### Table: `artifact_embeddings`
| Column | Type | Constraints |
|--------|------|-------------|
| artifact_id | INTEGER | PRIMARY KEY, REFERENCES artifacts(id) ON DELETE CASCADE |
| embedding | TEXT | NOT NULL |

### Table: `entity_index`
| Column | Type | Constraints |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| entity | TEXT | NOT NULL |
| entity_type | TEXT | NOT NULL |
| artifact_id | INTEGER | NOT NULL REFERENCES artifacts(id) ON DELETE CASCADE |
| session_id | TEXT | NOT NULL |

Indexes: `idx_entity_lookup(entity, session_id)`, `idx_entity_artifact(artifact_id)`

### Table: `engagement_log`
| Column | Type | Constraints |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| cluster_key | TEXT | NOT NULL |
| session_id | TEXT | NOT NULL |
| tokens | INTEGER | NOT NULL |
| turn_id | TEXT | NOT NULL |
| recorded_at | TEXT | NOT NULL DEFAULT CURRENT_TIMESTAMP |
| retrieval_count | INTEGER | DEFAULT 1 (added by `_MIGRATIONS[1]`) |

Index: `idx_engagement_cluster(cluster_key, session_id)`

### Table: `file_tree`
| Column | Type | Constraints |
|--------|------|-------------|
| path | TEXT | PRIMARY KEY |
| node_type | TEXT | NOT NULL |
| content_hash | TEXT | NOT NULL |
| mtime | REAL | |
| size | INTEGER | |
| parent_path | TEXT | |
| scanned_at | TEXT | NOT NULL |

Indexes: `idx_file_tree_hash(content_hash)`, `idx_file_tree_parent(parent_path)`

### Table: `dependency_graph`
| Column | Type | Constraints |
|--------|------|-------------|
| id | INTEGER | PRIMARY KEY |
| importer | TEXT | NOT NULL |
| importee | TEXT | NOT NULL |
| import_type | TEXT | NOT NULL |
| import_names | TEXT | |
| indexed_at | TEXT | NOT NULL DEFAULT CURRENT_TIMESTAMP |
| | | UNIQUE(importer, importee) |

Indexes: `idx_dep_importee(importee)`, `idx_dep_importer(importer)`

---

## `schema_version` Table Definition

```sql
CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER NOT NULL,
    migrated_at TEXT    NOT NULL
);
```

Design decisions:
- Single-row table; always holds the current version after migration completes.
- `version` is an integer — simple, ordered, unambiguous.
- `migrated_at` is an ISO-8601 UTC string for auditability.
- Insert on first run (baseline = `1`), update in-place on each subsequent migration.

---

## Migration Runner Design

### Location

New module: `src/ctrlcode/memory/migrations.py`

### Public Interface

```python
LATEST_VERSION: int  # = highest migration number defined

async def get_schema_version(db: aiosqlite.Connection) -> int:
    """Return the current schema version, or 0 if schema_version table absent."""

async def run_migrations(db: aiosqlite.Connection) -> None:
    """Detect current version, apply all pending migrations in order."""
```

### Internal structure

```python
# One callable per version step
_MIGRATION_STEPS: dict[int, Callable[[aiosqlite.Connection], Awaitable[None]]] = {
    1: _baseline_v1,
    2: _migrate_v1_to_v2,
    # future: 3: _migrate_v2_to_v3, ...
}
```

### Algorithm

```python
current = await get_schema_version(db)
for version in range(current + 1, LATEST_VERSION + 1):
    fn = _MIGRATION_STEPS[version]
    await db.execute("BEGIN")
    try:
        await fn(db)
        await _set_schema_version(db, version)
        await db.commit()
        logger.info(f"Migrated schema to v{version}")
    except Exception as exc:
        await db.rollback()
        raise SchemaMigrationError(f"Migration to v{version} failed: {exc}") from exc
```

### Transaction handling

Each migration step runs inside an explicit `BEGIN` / `COMMIT` or `ROLLBACK`. Use `db.execute("BEGIN")` explicitly rather than relying on context manager transactions (aiosqlite runs in autocommit mode by default in Python 3.12+).

FTS virtual tables and triggers do not participate in DDL transactions on all SQLite builds — migrations that modify FTS triggers should drop and recreate them as a single step and document the caveat.

### Error recovery

`SchemaMigrationError` (defined in `migrations.py`) is raised and propagates up through `_ensure_init`. The caller (`SessionManager._ensure_memory`) should catch it, log a structured error with the db path and version info, and abort startup rather than silently proceeding with a corrupt schema.

---

## Baseline v1 and v1 → v2 Migration

### v1 (baseline)

`_baseline_v1` records that the database has been initialised with the current DDL (including both `_MIGRATIONS` columns). For a brand-new database this is version 1. For a pre-existing database without a `schema_version` table the runner detects version 0 and runs `_baseline_v1`, which only inserts the version record and silently applies the two legacy ALTER TABLE columns (no-ops if they already exist).

```python
async def _baseline_v1(db: aiosqlite.Connection) -> None:
    # Apply the two legacy migration columns (idempotent, silently skip if already exist)
    for stmt in [
        "ALTER TABLE artifacts ADD COLUMN source_file_hash TEXT",
        "ALTER TABLE engagement_log ADD COLUMN retrieval_count INTEGER DEFAULT 1",
    ]:
        try:
            await db.execute(stmt)
        except Exception:
            pass  # column already exists — ok for baseline only
```

### v1 → v2 (schema improvements)

The only meaningful schema improvement: promote `source_file` from inside the JSON `metadata` blob to a real indexed column on `artifacts`. This allows `artifacts_referencing_path` to use `WHERE source_file = ?` instead of `json_extract`. Also adds two missing indexes.

Changes in v2:
1. Add `source_file TEXT` column to `artifacts` — promotes from JSON blob to real column
2. Add `idx_art_source_file` index on `artifacts(source_file)`
3. Add `idx_entity_type_session` index on `entity_index(entity_type, session_id)` — improves entity_type filter queries
4. Back-fill `source_file` from existing `metadata` JSON for pre-existing rows

```python
async def _migrate_v1_to_v2(db: aiosqlite.Connection) -> None:
    await db.execute("ALTER TABLE artifacts ADD COLUMN source_file TEXT")
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_art_source_file ON artifacts(source_file)"
    )
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_entity_type_session "
        "ON entity_index(entity_type, session_id)"
    )
    # Back-fill source_file from metadata JSON for existing rows
    await db.execute(
        "UPDATE artifacts SET source_file = json_extract(metadata, '$.source_file') "
        "WHERE source_file IS NULL AND json_extract(metadata, '$.source_file') IS NOT NULL"
    )
```

No data loss. All changes are additive. The back-fill is safe in a transaction.

---

## Integration into `_ensure_init`

The revised `_ensure_init` in `store.py`:

```python
async def _ensure_init(self) -> aiosqlite.Connection:
    if self._db is not None:
        return self._db
    self._db_path.parent.mkdir(parents=True, exist_ok=True)
    db = await aiosqlite.connect(str(self._db_path))
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA journal_mode=WAL")
    await db.execute("PRAGMA busy_timeout=5000")
    await db.executescript(_DDL)       # idempotent CREATE IF NOT EXISTS
    await db.commit()
    await run_migrations(db)           # NEW: versioned migration runner
    self._db = db
    return db
```

The old `_MIGRATIONS` list and its loop are removed entirely.

---

## CLI Command Design

### Entry point

Add to `pyproject.toml`:
```toml
[project.scripts]
ctrlcode-db = "ctrlcode.cli.db:main"
```

### New files

- `src/ctrlcode/cli/__init__.py` — empty package marker
- `src/ctrlcode/cli/db.py` — CLI entry point

### Commands

```
ctrlcode-db status [--db PATH]
    Prints: current schema version, latest version, whether migration is needed.

ctrlcode-db migrate [--db PATH] [--dry-run]
    Runs pending migrations.
    --dry-run prints the SQL without applying.
    Exits 0 if already current or migration succeeded.
    Exits 1 if migration fails (prints error with version that failed).
```

Implementation sketch:

```python
import argparse, asyncio, sys
from pathlib import Path
from ctrlcode.memory.migrations import get_schema_version, run_migrations, LATEST_VERSION

def main():
    parser = argparse.ArgumentParser(prog="ctrlcode-db")
    parser.add_argument("--db", type=Path, default=None,
                        help="Path to rootset.db (default: .ctrlcode/rootset.db)")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status")
    migrate_p = sub.add_parser("migrate")
    migrate_p.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    db_path = args.db or (Path.cwd() / ".ctrlcode" / "rootset.db")
    asyncio.run(_run(args, db_path))

async def _run(args, db_path: Path):
    import aiosqlite
    async with aiosqlite.connect(str(db_path)) as db:
        current = await get_schema_version(db)
        if args.command == "status":
            print(f"DB path:         {db_path}")
            print(f"Current version: {current}")
            print(f"Latest version:  {LATEST_VERSION}")
            if current < LATEST_VERSION:
                print(f"Pending migrations: v{current+1} .. v{LATEST_VERSION}")
            else:
                print("Up to date.")
        elif args.command == "migrate":
            if args.dry_run:
                print(f"[dry-run] Would migrate from v{current} to v{LATEST_VERSION}")
                sys.exit(0)
            await run_migrations(db)
            print(f"Migrated to v{LATEST_VERSION}")
```

---

## Affected Files

| File | Change |
|------|--------|
| `src/ctrlcode/memory/store.py` | Remove `_MIGRATIONS` list and loop; call `run_migrations(db)` in `_ensure_init` |
| `src/ctrlcode/memory/migrations.py` | **NEW** — `schema_version` DDL, `get_schema_version`, `run_migrations`, migration functions |
| `src/ctrlcode/memory/__init__.py` | Export `run_migrations`, `LATEST_VERSION` if needed by CLI |
| `src/ctrlcode/cli/__init__.py` | **NEW** — empty package marker |
| `src/ctrlcode/cli/db.py` | **NEW** — `ctrlcode-db` CLI |
| `pyproject.toml` | Add `ctrlcode-db = "ctrlcode.cli.db:main"` to `[project.scripts]` |
| `tests/memory/test_migrations.py` | **NEW** — migration tests |

---

## Step-by-Step Implementation Tasks

- [ ] **1. Create `src/ctrlcode/memory/migrations.py`**
  - Define `_SCHEMA_VERSION_DDL` — `CREATE TABLE IF NOT EXISTS schema_version ...`
  - Implement `get_schema_version(db)` — queries `schema_version`, returns `0` if table absent or empty
  - Implement `_set_schema_version(db, version)` — upsert single row
  - Implement `_baseline_v1(db)` — silently applies the two old `ALTER TABLE` columns and stamps v1
  - Implement `_migrate_v1_to_v2(db)` — adds `source_file` column + indexes + back-fill
  - Implement `run_migrations(db)` — loop from `current+1` to `LATEST_VERSION`, `BEGIN`/`COMMIT`/`ROLLBACK` per step, raise `SchemaMigrationError` on failure
  - Define `LATEST_VERSION = 2`
  - Define `SchemaMigrationError(RuntimeError)`

- [ ] **2. Update `src/ctrlcode/memory/store.py`**
  - Remove `_MIGRATIONS` list
  - Remove the migration loop from `_ensure_init`
  - Add `from .migrations import run_migrations` import
  - Add `await run_migrations(db)` after the DDL `executescript` block in `_ensure_init`
  - Wrap with `try/except SchemaMigrationError` that re-raises with db path context

- [ ] **3. Create `src/ctrlcode/cli/__init__.py`** (empty)

- [ ] **4. Create `src/ctrlcode/cli/db.py`** with `main()` as described above

- [ ] **5. Update `pyproject.toml`**
  - Add `ctrlcode-db = "ctrlcode.cli.db:main"` to `[project.scripts]`

- [ ] **6. Write `tests/memory/test_migrations.py`** (see Testing section)

- [ ] **7. Manual smoke test**
  - Run `uv run ctrlcode-db status` in a workspace with an existing `rootset.db`
  - Run `uv run ctrlcode-db migrate`
  - Verify `schema_version` row exists with `version=2`

---

## Testing Approach

All tests use `tmp_path` (pytest fixture) for isolated databases. Never touch real `.ctrlcode/rootset.db`.

```python
import pytest
import aiosqlite
from ctrlcode.memory.store import ArtifactStore, _DDL
from ctrlcode.memory.migrations import (
    get_schema_version, run_migrations, LATEST_VERSION,
    SchemaMigrationError,
)

@pytest.mark.anyio
async def test_get_schema_version_returns_zero_on_empty_db(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        v = await get_schema_version(db)
        assert v == 0

@pytest.mark.anyio
async def test_run_migrations_stamps_latest_version(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        v = await get_schema_version(db)
        assert v == LATEST_VERSION

@pytest.mark.anyio
async def test_run_migrations_idempotent(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "test.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        await run_migrations(db)  # second call is a no-op
        v = await get_schema_version(db)
        assert v == LATEST_VERSION

@pytest.mark.anyio
async def test_migration_failure_rolls_back(tmp_path, monkeypatch):
    """A failing migration leaves the version unchanged."""
    import ctrlcode.memory.migrations as m

    async def bad_migration(db):
        raise RuntimeError("intentional failure")

    monkeypatch.setitem(m._MIGRATION_STEPS, LATEST_VERSION + 1, bad_migration)
    monkeypatch.setattr(m, "LATEST_VERSION", LATEST_VERSION + 1)

    async with aiosqlite.connect(str(tmp_path / "fail.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        # Run migrations up to current LATEST
        import ctrlcode.memory.migrations as m2
        original_latest = LATEST_VERSION
        monkeypatch.setattr(m2, "LATEST_VERSION", original_latest)
        await run_migrations(db)
        # Now inject bad step
        monkeypatch.setattr(m2, "LATEST_VERSION", original_latest + 1)
        with pytest.raises(SchemaMigrationError):
            await run_migrations(db)
        # Version should not have advanced
        v = await get_schema_version(db)
        assert v == original_latest

@pytest.mark.anyio
async def test_store_initialises_with_correct_version(tmp_path):
    store = ArtifactStore(tmp_path / "rootset.db")
    await store._ensure_init()
    v = await get_schema_version(store._db)
    assert v == LATEST_VERSION
    await store.close()

@pytest.mark.anyio
async def test_v2_migration_adds_source_file_column(tmp_path):
    async with aiosqlite.connect(str(tmp_path / "v2.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        await run_migrations(db)
        async with db.execute("PRAGMA table_info(artifacts)") as cur:
            cols = {row[1] async for row in cur}
        assert "source_file" in cols

@pytest.mark.anyio
async def test_v2_backfill_populates_source_file(tmp_path):
    import json, hashlib
    from datetime import datetime, timezone
    async with aiosqlite.connect(str(tmp_path / "backfill.db")) as db:
        await db.executescript(_DDL)
        await db.commit()
        meta = json.dumps({"source_file": "src/foo.py"})
        now = datetime.now(timezone.utc).isoformat()
        await db.execute(
            "INSERT INTO artifacts (namespace, kind, content, metadata, content_hash, created_at, updated_at)"
            " VALUES ('ns','turn','body',?,?,?,?)",
            (meta, hashlib.sha256(b"body").hexdigest(), now, now)
        )
        await db.commit()
        await run_migrations(db)
        async with db.execute("SELECT source_file FROM artifacts WHERE namespace='ns'") as cur:
            row = await cur.fetchone()
        assert row[0] == "src/foo.py"
```

---

## How to Write a New Migration

When the schema needs to change in a future release:

1. Add a new async function `_migrate_vN_to_vN1(db: aiosqlite.Connection) -> None` in `src/ctrlcode/memory/migrations.py`.
2. Add it to `_MIGRATION_STEPS[N+1]`.
3. Bump `LATEST_VERSION` to `N+1`.
4. Write the migration using `await db.execute(...)` only — do NOT call `db.commit()` inside the function; the runner owns the transaction.
5. For FTS5 trigger changes: drop and recreate the trigger in a single migration step and add a code comment noting that FTS DDL is not transactional on all SQLite builds.
6. Add tests covering: migration runs, data back-fill (if any), idempotency, and rollback on failure.
7. Document in a comment at the top of the migration function why the change is needed and what data transformation occurs.

---

## Notes and Constraints

- **aiosqlite autocommit**: Use `await db.execute("BEGIN")` explicitly rather than relying on context manager transactions for migration steps.
- **SQLite ALTER TABLE limits**: SQLite does not support `DROP COLUMN` before 3.35. Migrations needing destructive changes should use the SQLite recommended pattern: create new table → copy data → drop old → rename new.
- **FTS5 and transactions**: Writes to `artifacts_fts` in the same transaction as `artifacts` commit atomically. However DDL on virtual tables (DROP/CREATE FTS) is not transactional — document per migration.
- **db_path**: The canonical path is `.ctrlcode/rootset.db` relative to `workspace_root`. The CLI must accept an explicit `--db` override for CI/testing.
