# ctrl+code Project Instructions

> Note: This is the project-level AGENT.md. Global defaults are in ~/.config/ctrlcode/AGENT.md

## Project Overview

ctrl+code is an AI coding harness: a middleware-driven agent loop that connects LLMs to a workspace via tools, skills, and session management. It handles context window management, permission gating, schema migrations, and composable middleware.

## Architecture

- **Server** (`src/ctrlcode/server.py`): JSON-RPC server handling sessions
- **Session Manager** (`src/ctrlcode/session/manager.py`): Conversation orchestration via MiddlewareStack
- **Middleware** (`src/ctrlcode/session/middleware/`): Composable turn hooks (memory, context assembly, skills, permissions, etc.)
- **Providers** (`src/ctrlcode/providers/`): LLM integrations (Anthropic, OpenAI)
- **Backends** (`src/ctrlcode/backends/`): Pluggable I/O — FilesystemBackend, StateBackend, CompositeBackend
- **Tools** (`src/ctrlcode/tools/`): Built-in tools + MCP support
- **Skills** (`src/ctrlcode/skills/`): Reusable slash-command workflows, injected into system prompt
- **Memory** (`src/ctrlcode/memory/`): Rootset artifact store (SQLite/FTS5), context window monitor, schema migrations
- **TUI** (`tui/`): Textual-based terminal interface

## Code Style

- Use Python 3.12+ features (type hints, match/case, etc.)
- Prefer async/await for I/O operations
- Keep functions focused and single-purpose
- Use dataclasses for structured data
- Follow existing logging patterns (`logger.info/warning/error`)

## Tool Usage

When exploring this codebase:
- Use `search_code` to find class/function definitions
- Use `search_files` to locate files by pattern
- Use `read_file` to examine implementation details
- Check related files (e.g., if editing a provider, check base.py first)

## Testing

- Run tests with `uv run pytest`
- Skills are in `src/ctrlcode/skills/builtin/`
- Test execution uses `analysis/tests.py`

## Key Patterns

- All RPC methods are in `server.py` and call into `SessionManager`
- Tool execution loop is in `session/manager.py:process_turn()`
- Streaming events use `StreamEvent` dataclass from `providers/base.py`
- Skills expand via `SkillRegistry.process_input()`
