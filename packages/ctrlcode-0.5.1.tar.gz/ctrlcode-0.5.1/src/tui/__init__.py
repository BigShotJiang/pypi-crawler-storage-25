"""Ctrl+Code TUI client."""

import importlib.metadata

__version__ = importlib.metadata.version("ctrlcode")
