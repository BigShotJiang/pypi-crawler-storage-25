"""Inline permission prompt widget — mounts in the chat stream."""

from textual.app import ComposeResult
from textual.containers import Container, Horizontal
from textual.widgets import Button, Input, Static


class PermissionWidget(Container):
    """Compact inline permission prompt.

    Pending state  — one-line bar with four icon buttons.
    Context state  — second row with a text input appears.
    Resolved state — collapses to a single muted summary line.
    """

    DEFAULT_CSS = """
    PermissionWidget {
        width: 100%;
        height: auto;
        border-left: thick $warning;
        background: $surface-darken-1;
        padding: 0 1;
        margin-bottom: 1;
    }

    PermissionWidget .perm-row {
        height: auto;
        width: 100%;
    }

    PermissionWidget .perm-label {
        width: 1fr;
        height: 3;
        content-align: left middle;
        color: $warning;
    }

    PermissionWidget .perm-buttons {
        width: auto;
        height: auto;
    }

    PermissionWidget Button {
        min-width: 6;
        margin: 0 0 0 1;
    }

    PermissionWidget #ctx-row {
        height: auto;
        width: 100%;
        display: none;
        margin: 1 0 0 0;
    }

    PermissionWidget .ctx-visible {
        display: block;
    }

    PermissionWidget Input {
        height: 3;
        width: 1fr;
        background: $surface;
    }

    PermissionWidget.resolved {
        border-left: thick $panel;
    }

    PermissionWidget.resolved .perm-label {
        color: $text-disabled;
    }
    """

    def __init__(
        self,
        request_id: str,
        operation: str,
        path: str,
        reason: str,
        details: dict | None = None,
    ):
        super().__init__()
        self.request_id = request_id
        self.operation = operation
        self.path = path
        self._pending = True

    def compose(self) -> ComposeResult:
        with Horizontal(classes="perm-row"):
            yield Static(
                f"⚠ {self.operation}  {self.path}",
                classes="perm-label",
            )
            with Horizontal(classes="perm-buttons"):
                yield Button("✓", id="approve", variant="success")
                yield Button("⚡", id="accept_all", variant="warning")
                yield Button("✗", id="reject", variant="error")
                yield Button("✎", id="add_context")

        with Horizontal(id="ctx-row"):
            yield Input(placeholder="Add context for the agent…", id="ctx-input")
            yield Button("→", id="ctx-submit", variant="primary")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if not self._pending:
            return
        event.stop()

        btn = event.button.id

        if btn == "approve":
            await self._send(approved=True)
            self._resolve("✓ approved")

        elif btn == "accept_all":
            await self._send(approved=True, accept_all=True)
            self._resolve("⚡ accept all enabled")

        elif btn == "reject":
            await self._send(approved=False)
            self._resolve("✗ rejected")

        elif btn == "add_context":
            self.query_one("#ctx-row").add_class("ctx-visible")
            self.query_one("#ctx-input", Input).focus()

        elif btn == "ctx-submit":
            await self._submit_context()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Enter key in context input submits."""
        if event.input.id == "ctx-input" and self._pending:
            event.stop()
            await self._submit_context()

    async def _submit_context(self) -> None:
        text = self.query_one("#ctx-input", Input).value.strip()
        await self._send(approved=False, context=text or None)
        note = f'  "{text}"' if text else ""
        self._resolve(f"✗ rejected{note}")

    def _resolve(self, outcome: str) -> None:
        """Collapse widget to a single resolved summary line."""
        self._pending = False
        self.add_class("resolved")
        self.remove_children()
        self.mount(Static(
            f"⚠ {self.operation}  {self.path}  —  {outcome}",
            classes="perm-label",
        ))

    async def _send(
        self,
        approved: bool,
        accept_all: bool = False,
        context: str | None = None,
    ) -> None:
        try:
            await self.app.client.send_permission_response(  # type: ignore[attr-defined]
                self.request_id,
                approved,
                accept_all=accept_all,
                context=context,
            )
        except Exception as e:
            self.app.notify(f"Failed to send permission response: {e}", severity="error")
