"""MiddlewareStack — ordered composition of AgentMiddleware instances."""

from __future__ import annotations

import logging
import time
from typing import Any, AsyncIterator, Callable

from ...providers.base import StreamEvent
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


class MiddlewareStack:
    """Composes an ordered list of BaseMiddleware instances.

    Provides three public surfaces consumed by SessionManager:

    * ``run_before_turn(ctx)`` — call each mw.before_turn in order; any
      exception propagates immediately.
    * ``make_pre_tool_hook(ctx)`` — returns an async-generator callable
      matching react_loop's ``pre_tool_hook`` signature.
    * ``make_post_tool_hook(ctx)`` — returns an async-generator callable
      matching react_loop's ``post_tool_hook`` signature.
    * ``run_after_turn(ctx)`` — call each mw.after_turn in order; exceptions
      are logged and swallowed so one failure does not block others.
    """

    def __init__(self, middlewares: list[BaseMiddleware]) -> None:
        self._middlewares = middlewares

    # ------------------------------------------------------------------
    # Before turn
    # ------------------------------------------------------------------

    async def run_before_turn(self, ctx: TurnContext) -> None:
        """Run all before_turn hooks in registration order.

        Raises on first failure — aborts the turn.
        """
        for mw in self._middlewares:
            await mw.before_turn(ctx)

    # ------------------------------------------------------------------
    # Hook factories (compatible with AgentReActLoop.stream signatures)
    # ------------------------------------------------------------------

    def make_pre_tool_hook(self, ctx: TurnContext) -> Callable:
        """Return a callable: ``async (tool_call) -> AsyncIterator[StreamEvent]``.

        Calls each middleware's ``pre_tool`` method in registration order,
        yielding all events.
        """
        middlewares = self._middlewares

        async def hook(tool_call: dict) -> AsyncIterator[StreamEvent]:
            ctx.extra.setdefault("_tool_start_times", {})[tool_call.get("call_id", "")] = time.monotonic()
            for mw in middlewares:
                async for ev in mw.pre_tool(ctx, tool_call):
                    yield ev

        return hook

    def make_post_tool_hook(self, ctx: TurnContext) -> Callable:
        """Return a callable: ``async (tool_call, result) -> AsyncIterator[StreamEvent]``.

        Calls each middleware's ``after_tool_call`` method in registration order,
        yielding all events.
        """
        middlewares = self._middlewares

        async def hook(tool_call: dict, result: Any) -> AsyncIterator[StreamEvent]:
            call_id = tool_call.get("call_id", "")
            start = ctx.extra.get("_tool_start_times", {}).pop(call_id, None)
            if start is not None:
                ctx.tool_timings.append({
                    "tool": tool_call.get("tool", ""),
                    "call_id": call_id,
                    "duration_s": time.monotonic() - start,
                    "success": getattr(result, "success", True),
                })
            for mw in middlewares:
                async for ev in mw.after_tool_call(ctx, tool_call, result):
                    yield ev

        return hook

    # ------------------------------------------------------------------
    # After turn
    # ------------------------------------------------------------------

    async def run_after_turn(self, ctx: TurnContext) -> None:
        """Run all after_turn hooks in registration order.

        Exceptions are logged and swallowed — one failure does not block others.
        """
        for mw in self._middlewares:
            try:
                await mw.after_turn(ctx)
            except Exception as exc:
                logger.warning(
                    f"Middleware {type(mw).__name__}.after_turn raised (non-fatal): {exc}"
                )

    async def close(self) -> None:
        """Tear down all middlewares in reverse registration order."""
        for mw in reversed(self._middlewares):
            try:
                await mw.close()
            except Exception as exc:
                logger.warning(
                    f"Middleware {type(mw).__name__}.close raised (non-fatal): {exc}"
                )
