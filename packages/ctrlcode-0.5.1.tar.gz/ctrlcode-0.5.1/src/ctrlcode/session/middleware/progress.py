"""ProgressMiddleware — write .ctrlcode/progress.md after each completed turn."""

from __future__ import annotations

import logging
from pathlib import Path

from ..hooks import write_progress_file
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


class ProgressMiddleware(BaseMiddleware):
    """Write a progress summary file after the turn if the agent produced one.

    Responsibilities:
    - ``after_turn``: if ``ctx.task_summary`` is non-empty, call
      ``write_progress_file`` to persist the summary and touched files to
      ``.ctrlcode/progress.md`` so the next session can read it.
    """

    def __init__(self, ctrlcode_dir: Path) -> None:
        self._ctrlcode_dir = ctrlcode_dir

    async def after_turn(self, ctx: TurnContext) -> None:
        if not ctx.task_summary:
            return
        await write_progress_file(self._ctrlcode_dir, ctx.task_summary, ctx.touched_files)
