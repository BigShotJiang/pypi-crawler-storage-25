"""SkillMiddleware — expands slash-commands before the ReAct loop."""

from __future__ import annotations

import logging

from ...providers.base import StreamEvent
from ...skills.registry import SkillRegistry
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


class SkillMiddleware(BaseMiddleware):
    """Expand skill slash-commands in user_input before the turn begins.

    If the user typed ``/commit`` (or any registered skill name), the input
    is replaced with the full skill instructions. The original and expanded
    inputs are stored in ``ctx.extra["skill_events"]`` so ``process_turn``
    can yield the ``skill_expanded`` StreamEvent.

    Raises ``ValueError`` if the skill name is unrecognised — propagates
    through the stack and should be caught by ``process_turn`` to emit a
    ``request_error`` event.
    """

    def __init__(self, skill_registry: SkillRegistry) -> None:
        self._registry = skill_registry

    async def before_turn(self, ctx: TurnContext) -> None:
        expanded_input, was_skill = self._registry.process_input(ctx.user_input)
        if was_skill:
            ctx.extra["skill_events"] = [
                StreamEvent(
                    type="skill_expanded",
                    data={"original": ctx.user_input, "expanded": expanded_input},
                )
            ]
            ctx.user_input = expanded_input
