"""BaselineMiddleware — extract and store baseline code from user input."""

from __future__ import annotations

import logging

from ..baseline import BaselineManager, Baseline
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


class BaselineMiddleware(BaseMiddleware):
    """Extract baseline code from the user's message and cache it for the session.

    The ``BaselineManager`` detects code blocks in the user's input that
    represent a "before" state (used for diff-based feedback generation).
    This middleware extracts them early so downstream processing can compare
    against the baseline.
    """

    def __init__(self, baseline_manager: BaselineManager, session_id: str) -> None:
        self._manager = baseline_manager
        self._session_id = session_id

    async def before_turn(self, ctx: TurnContext) -> None:
        baseline_code = self._manager.extract_from_request(ctx.user_input)
        if baseline_code:
            self._manager.store(self._session_id, Baseline(code=baseline_code))
