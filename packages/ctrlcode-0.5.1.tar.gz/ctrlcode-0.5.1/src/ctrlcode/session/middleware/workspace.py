"""WorkspaceMiddleware — workspace indexing and blast-radius warnings."""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Optional

from harnessutils import ConversationManager, Message, TextPart

from ...providers.base import StreamEvent
from ...memory.workspace_monitor import WorkspaceMonitor
from ..utils import generate_msg_id
from .base import BaseMiddleware, TurnContext
from .memory import MemoryMiddleware

logger = logging.getLogger(__name__)

_WRITE_TOOLS = {"write_file", "update_file", "edit_file", "create_file"}


class WorkspaceMiddleware(BaseMiddleware):
    """Maintain the workspace file-tree index and emit blast-radius warnings.

    Responsibilities:
    - ``before_turn``: lazily create and refresh the ``WorkspaceMonitor``.
      Back-patches ``dep_indexer`` into any assemblers already created by
      ``MemoryMiddleware``.
    - ``after_tool_call``: if the agent wrote a file, look up its dependents
      and inject a ``[System: Blast radius]`` message into the conversation so
      the model is aware of files it may have broken.
    - ``after_turn``: refresh workspace index entries for files touched this
      turn.

    Must be registered AFTER ``MemoryMiddleware`` in the stack so that
    ``_memory_mw.ensure`` has already run before ``before_turn`` is called.
    """

    def __init__(
        self,
        workspace_root,
        memory_mw: MemoryMiddleware,
        conv_manager: ConversationManager,
        sessions: dict,
    ) -> None:
        self._workspace_root = workspace_root
        self._memory_mw = memory_mw
        self._conv_manager = conv_manager
        self._sessions = sessions
        self._monitor: Optional[WorkspaceMonitor] = None

    @property
    def monitor(self) -> Optional[WorkspaceMonitor]:
        return self._monitor

    async def before_turn(self, ctx: TurnContext) -> None:
        if not self._workspace_root:
            return
        if self._monitor is not None:
            return

        # Ensure memory is initialised (idempotent)
        await self._memory_mw.ensure(ctx.session)
        assert self._memory_mw._memory is not None

        store = self._memory_mw._memory._store  # type: ignore[attr-defined]
        self._monitor = WorkspaceMonitor(
            store=store,
            workspace_root=self._workspace_root,
            session_id=ctx.session.id,
        )
        # Back-patch dep_indexer into assemblers that were created before monitor
        dep_indexer = self._monitor.dep_indexer
        for assembler in self._memory_mw._assemblers.values():
            assembler._dep_indexer = dep_indexer

        try:
            change_set = await self._monitor.refresh()
            await self._monitor.start_watching()
            if not change_set.is_empty:
                logger.info(
                    f"Workspace changed since last session: "
                    f"+{len(change_set.added)} ~{len(change_set.modified)} "
                    f"→{len(change_set.moved)} -{len(change_set.deleted)}"
                )
        except Exception as exc:
            logger.warning(f"Workspace index refresh failed (non-fatal): {exc}")

    async def after_tool_call(
        self,
        ctx: TurnContext,
        tool_call: dict,
        result: Any,
    ) -> AsyncIterator[StreamEvent]:
        if not self._monitor or not result.success:
            return  # type: ignore[return-value]
            yield  # noqa: unreachable

        session = self._sessions.get(ctx.session.id)
        if not session:
            return  # type: ignore[return-value]
            yield  # noqa: unreachable

        if tool_call["tool"] in _WRITE_TOOLS:
            path = tool_call["input"].get("path", "")
            if path:
                try:
                    dependents = await self._monitor.dep_indexer.get_dependents(path)
                    if dependents:
                        dep_list = ", ".join(sorted(dependents)[:10])
                        extra = (
                            f" (+{len(dependents) - 10} more)"
                            if len(dependents) > 10
                            else ""
                        )
                        note = Message(id=generate_msg_id(), role="user")
                        note.add_part(
                            TextPart(
                                text=(
                                    f"[System: Blast radius] {path} is imported by: "
                                    f"{dep_list}{extra}. "
                                    f"Verify these files are not broken by your change."
                                )
                            )
                        )
                        self._conv_manager.add_message(session.conv_id, note)
                except Exception:
                    pass

        return  # type: ignore[return-value]
        yield  # noqa: unreachable

    async def after_turn(self, ctx: TurnContext) -> None:
        if not self._monitor or not ctx.touched_files:
            return
        for rel_path in ctx.touched_files:
            try:
                await self._monitor.update_file(rel_path)
            except Exception:
                pass

    async def close(self) -> None:
        if self._monitor is not None:
            await self._monitor.stop_watching()
            self._monitor = None
