"""Base types for the middleware system: TurnContext, AgentMiddleware, BaseMiddleware."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, AsyncIterator, TYPE_CHECKING

from ...providers.base import StreamEvent
from ..models import Session

if TYPE_CHECKING:
    from ...tools.executor import ToolCallResult

logger = logging.getLogger(__name__)


@dataclass
class TurnContext:
    """Shared mutable state for a single conversation turn.

    Constructed once per ``process_turn`` call and passed to every middleware
    hook. Middleware use ``extra`` as an escape hatch for middleware-private data
    (e.g. writer, assembler, pre_turn_count).
    """

    session: Session
    user_input: str
    tool_calls: list[dict] = field(default_factory=list)
    assistant_parts: list[str] = field(default_factory=list)
    touched_files: list[str] = field(default_factory=list)
    commands_run: list[str] = field(default_factory=list)
    task_summary: str = ""
    compaction_fired: bool = False
    iteration_warning_fired: bool = False
    system_prompt_msg: dict | None = None
    extra: dict = field(default_factory=dict)
    # Turn-level observability
    turn_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    turn_started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    turn_duration_s: float = 0.0
    tool_timings: list[dict] = field(default_factory=list)  # {tool, call_id, duration_s, success}
    context_before: int = 0
    context_after: int = 0
    # Snapshot of the message history sent to the model at the start of this turn
    messages_snapshot: list[dict] = field(default_factory=list)
    # Full conversation after the turn completes (includes all tool call exchanges)
    messages_after: list[dict] = field(default_factory=list)


class BaseMiddleware:
    """ABC with no-op default implementations for all middleware hooks.

    Concrete middleware classes should subclass this and override only the
    hooks they need.
    """

    async def before_turn(self, ctx: TurnContext) -> None:
        """Called once before the ReAct loop starts for this turn.

        Use for: memory init, skill expansion, baseline extraction,
        workspace index refresh, system prompt assembly.

        Raises on failure — causes the turn to abort.
        """

    async def pre_tool(
        self, ctx: TurnContext, tool_call: dict
    ) -> AsyncIterator[StreamEvent]:
        """Called before each tool execution. Yields StreamEvents.

        Use for: permission checks, input sanitization.
        """
        return  # type: ignore[return-value]
        yield  # makes this an async generator  # noqa: unreachable

    async def after_tool_call(
        self,
        ctx: TurnContext,
        tool_call: dict,
        result: Any,
    ) -> AsyncIterator[StreamEvent]:
        """Called after each tool execution. Yields additional StreamEvents.

        Use for: blast-radius warnings, auto-chaining.
        """
        return  # type: ignore[return-value]
        yield  # makes this an async generator  # noqa: unreachable

    async def after_turn(self, ctx: TurnContext) -> None:
        """Called once after the ReAct loop completes for this turn.

        Use for: artifact writing, progress file, token accounting.

        Errors are logged and swallowed — do not abort the turn.
        """

    async def close(self) -> None:
        """Called when the owning SessionManager is torn down.

        Use for: stopping file watchers, closing database connections.
        """
