"""MemoryMiddleware — lazy init of semantic memory and per-turn artifact writing."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Callable, Optional

from harnessutils import ConversationManager

from ...memory.artifact_writer import ArtifactWriter
from ...memory.chunker import MessageChunker
from ...memory.context_assembler import ContextAssembler
from ...memory.entity_extractor import EntityExtractor
from ...memory.rootset_backend import RootsetMemoryBackend
from ...memory.saliency import SaliencyScorer
from ...memory.store import ArtifactStore
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)

_WRITE_TOOLS = {"write_file", "update_file", "edit_file", "create_file"}


class MemoryMiddleware(BaseMiddleware):
    """Own and lazily initialise the semantic memory subsystem.

    Responsibilities:
    - ``before_turn``: ensure ``ArtifactStore``, ``RootsetMemoryBackend``,
      ``ArtifactWriter``, and ``ContextAssembler`` are initialised for the
      session.  Stores ``writer`` and ``assembler`` in ``ctx.extra`` so that
      ``ContextAssemblyMiddleware`` and ``WorkspaceMiddleware`` can access them.
      Also records ``pre_turn_count`` so ``after_turn`` can compute the delta.
    - ``after_turn``: call ``writer.write_turn`` with all accumulated turn data.

    State owned here (previously on ``SessionManager``):
    - ``_memory``, ``_memory_lock``, ``_writers``, ``_assemblers``
    """

    def __init__(
        self,
        db_path: Path,
        workspace_root: Optional[Path],
        conv_manager: ConversationManager,
        project_id_loader: Callable[[], str],
    ) -> None:
        self._db_path = db_path
        self._workspace_root = workspace_root
        self._conv_manager = conv_manager
        self._project_id_loader = project_id_loader

        self._memory: Optional[RootsetMemoryBackend] = None
        self._memory_lock = asyncio.Lock()
        self._writers: dict[str, ArtifactWriter] = {}
        self._assemblers: dict[str, ContextAssembler] = {}
        # Set by WorkspaceMiddleware after monitor is created
        self._compaction_client = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def ensure(self, session) -> tuple[ArtifactWriter, ContextAssembler]:
        """Lazily initialise memory backend and per-session writer/assembler."""
        async with self._memory_lock:
            if self._memory is None:
                store = ArtifactStore(self._db_path)
                self._memory = RootsetMemoryBackend(store)
                self._conv_manager.semantic_memory = self._memory

        if session.id not in self._writers:
            project_id = self._project_id_loader()
            dep_indexer = None
            # WorkspaceMiddleware back-patches dep_indexer after monitor init;
            # use None here and let the assembler be updated in place.
            self._writers[session.id] = ArtifactWriter(
                backend=self._memory,  # type: ignore[arg-type]
                chunker=MessageChunker(),
                scorer=SaliencyScorer(),
                extractor=EntityExtractor(),
                project_id=project_id,
                session_id=session.id,
                llm_client=self._compaction_client,
                workspace_root=self._workspace_root,
            )
            self._assemblers[session.id] = ContextAssembler(
                backend=self._memory,  # type: ignore[arg-type]
                project_id=project_id,
                session_id=session.id,
                dep_indexer=dep_indexer,
            )

        return self._writers[session.id], self._assemblers[session.id]

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    async def before_turn(self, ctx: TurnContext) -> None:
        writer, assembler = await self.ensure(ctx.session)
        ctx.extra["writer"] = writer
        ctx.extra["assembler"] = assembler
        # Snapshot message count AFTER the user message will be added
        # (process_turn sets ctx.extra["pre_turn_count"] after adding user msg)

    async def after_turn(self, ctx: TurnContext) -> None:
        writer: ArtifactWriter | None = ctx.extra.get("writer")
        if not writer:
            return

        pre_turn_count: int = ctx.extra.get("pre_turn_count", 0)
        delta = self._conv_manager.to_model_format(ctx.session.conv_id)[pre_turn_count:]

        try:
            await writer.write_turn(
                user_input=ctx.user_input,
                turn_messages=delta,
                tool_calls=ctx.tool_calls,
                assistant_text="".join(ctx.assistant_parts),
                touched_files=ctx.touched_files or None,
                force_llm_summary=ctx.compaction_fired or ctx.iteration_warning_fired,
            )
        except Exception as exc:
            logger.warning(f"Artifact write failed (non-fatal): {exc}")

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    async def close(self) -> None:
        if self._memory is not None:
            await self._memory.close()
            self._memory = None
            self._writers.clear()
            self._assemblers.clear()
