"""Trajectory capture middleware — opt-in JSONL recording of turn data for training."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


def _content_to_text(content: Any) -> str:
    """Flatten an Anthropic API content value to a plain string.

    Handles: plain str, list of content blocks (text, tool_use, tool_result).
    Tool calls and results are serialised with XML markers so training data
    can be parsed back without a schema.
    """
    if isinstance(content, str):
        return content

    if not isinstance(content, list):
        return str(content)

    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            parts.append(str(block))
            continue
        btype = block.get("type", "")
        if btype == "text":
            parts.append(block.get("text", ""))
        elif btype == "tool_use":
            payload = json.dumps({
                "name": block.get("name", ""),
                "id": block.get("id", ""),
                "input": block.get("input", {}),
            })
            parts.append(f"<tool_call>{payload}</tool_call>")
        elif btype == "tool_result":
            result_content = block.get("content", "")
            if isinstance(result_content, list):
                result_content = " ".join(
                    b.get("text", "") for b in result_content if isinstance(b, dict)
                )
            payload = json.dumps({
                "tool_use_id": block.get("tool_use_id", ""),
                "content": result_content,
            })
            parts.append(f"<tool_response>{payload}</tool_response>")
        else:
            parts.append(str(block))

    return "\n".join(p for p in parts if p)


def _build_conversations(
    system_prompt: str,
    messages: list[dict],
) -> list[dict]:
    """Convert model-format messages into ShareGPT-style conversation turns."""
    turns: list[dict] = []
    if system_prompt:
        turns.append({"from": "system", "value": system_prompt})
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        text = _content_to_text(content)
        if not text:
            continue
        turns.append({
            "from": "human" if role == "user" else "gpt",
            "value": text,
        })
    return turns


class TrajectoryMiddleware(BaseMiddleware):
    """Appends one JSONL line per turn to {trajectories_dir}/{session_id}.jsonl.

    Disabled by default — enabled via ``[trajectories] enabled = true`` in config.

    Each record contains a ``conversations`` array in ShareGPT format (ready for
    most SFT pipelines) plus metadata for filtering and curriculum design.
    Permission-denied tool inputs are omitted.
    """

    def __init__(self, trajectories_dir: Path) -> None:
        self._dir = trajectories_dir

    async def after_turn(self, ctx: TurnContext) -> None:
        timing_by_call_id = {t["call_id"]: t for t in ctx.tool_timings}

        tool_entries = []
        for tc in ctx.tool_calls:
            inp = tc.get("input") or {}
            denied = "__perm_denied__" in inp
            entry: dict = {
                "tool": tc.get("tool", ""),
                "success": tc.get("success", True),
                "duration_s": timing_by_call_id.get(tc.get("call_id", ""), {}).get("duration_s"),
            }
            if not denied:
                clean_input = {k: v for k, v in inp.items() if not k.startswith("__perm_")}
                entry["input"] = clean_input
                entry["result"] = tc.get("result", "")
            tool_entries.append(entry)

        # Extract system prompt text
        system_text = ""
        if ctx.system_prompt_msg:
            for block in ctx.system_prompt_msg.get("content", []):
                if isinstance(block, dict) and block.get("type") == "text":
                    system_text += block.get("text", "")

        # Quality signal
        any_perm_denied = any(
            "__perm_denied__" in (tc.get("input") or {}) for tc in ctx.tool_calls
        )
        quality_ok = (
            not ctx.iteration_warning_fired
            and not any_perm_denied
            and bool(ctx.assistant_parts or ctx.task_summary)
        )

        record = {
            # Training-ready conversation in ShareGPT format
            "conversations": _build_conversations(system_text, ctx.messages_after),
            # Metadata for filtering / curriculum design
            "turn_id": ctx.turn_id,
            "session_id": ctx.session.id,
            "timestamp": ctx.turn_started_at.isoformat(),
            "tool_calls": tool_entries,
            "quality_ok": quality_ok,
            "context_before_tokens": ctx.context_before,
            "context_after_tokens": ctx.context_after,
            "wall_time_s": ctx.turn_duration_s,
        }

        try:
            self._dir.mkdir(parents=True, exist_ok=True)
            out_file = self._dir / f"{ctx.session.id}.jsonl"
            with out_file.open("a") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as exc:
            logger.warning(f"TrajectoryMiddleware: failed to write trajectory: {exc}")
