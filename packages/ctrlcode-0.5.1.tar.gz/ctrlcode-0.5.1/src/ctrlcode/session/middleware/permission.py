"""PermissionMiddleware — gate destructive tool calls and strip markdown fences."""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Optional

from ...providers.base import StreamEvent
from ..utils import strip_markdown_fences
from .base import BaseMiddleware, TurnContext

logger = logging.getLogger(__name__)


class PermissionMiddleware(BaseMiddleware):
    """Check permissions for destructive tools and strip markdown fences.

    Responsibilities:
    - ``pre_tool``: for destructive tools, request async permission approval.
      If denied, sets ``__perm_denied__`` in ``tool_call["input"]`` so the
      executor skips execution.  If approved, sets ``__perm_approved__``.
    - ``pre_tool``: strip markdown fences from ``write_file``/``update_file``
      content after permission is resolved.

    Logic is extracted verbatim from ``make_pre_tool_hook`` in ``hooks.py``.
    """

    def __init__(self, permission_manager: Optional[Any] = None) -> None:
        self._permission_manager = permission_manager

    async def pre_tool(
        self, ctx: TurnContext, tool_call: dict
    ) -> AsyncIterator[StreamEvent]:
        # 1. Permission check FIRST — before any work that could take minutes
        if self._permission_manager is not None:
            from ...permissions import is_destructive

            tool_name = tool_call["tool"]
            arguments = tool_call["input"]
            _is_safe_run = tool_name == "run_command" and self._permission_manager.is_safe_command(
                arguments.get("command", "")
            )
            if is_destructive(tool_name) and not _is_safe_run:
                approved, context = await self._permission_manager.request_permission_async(
                    operation=tool_name,
                    path=arguments.get("path", arguments.get("command", "")),
                    reason=f"Agent wants to run {tool_name}",
                    details={"input": arguments},
                )
                if not approved:
                    tool_call["input"]["__perm_denied__"] = True
                    tool_call["input"]["__perm_context__"] = context
                    return
                else:
                    tool_call["input"]["__perm_approved__"] = True

        # 2. Strip markdown fences from write content
        if tool_call["tool"] in ("write_file", "update_file"):
            content = tool_call["input"].get("content", "")
            if content:
                tool_call["input"]["content"] = strip_markdown_fences(content)

        return
        yield  # noqa: unreachable
