"""Session management using harness-utils."""

import asyncio
import logging
import time
from typing import Any, AsyncIterator, Optional
from pathlib import Path

from harnessutils import ConversationManager, Message, TextPart
from harnessutils.config import HarnessConfig

from ..providers.base import Provider, StreamEvent
from .adapters import LLMClientAdapter
from .baseline import BaselineManager, Baseline
from .hooks import make_before_complete_hook
from .models import ReactConfig, Session
from .prompt_builder import load_base_prompt, load_agent_instructions, detect_verification_commands
from .session_store import SessionStore
from .utils import generate_msg_id
from .verification import VerificationDetector
from ..tools.executor import ToolExecutor
from ..tools.registry import ToolRegistry
from ..skills.registry import SkillRegistry
from ..memory.context_window_monitor import ContextWindowMonitor
from .middleware import (
    MiddlewareStack,
    TurnContext,
    BaselineMiddleware,
    ContextAssemblyMiddleware,
    MemoryMiddleware,
    PermissionMiddleware,
    ProgressMiddleware,
    SkillMiddleware,
    WorkspaceMiddleware,
)

logger = logging.getLogger(__name__)

# Re-export for import compatibility
__all__ = ["SessionManager", "Session", "ReactConfig", "LLMClientAdapter"]


def _make_output_summarizer(provider: "Provider", loop: "asyncio.AbstractEventLoop"):
    """Return a synchronous summarizer callback for use with prune_before_turn.

    The returned callable takes (tool_name, output) and returns a one-sentence
    summary preserving key facts (filenames, counts, error messages).
    """
    client = LLMClientAdapter(provider, loop)

    def summarize(tool: str, output: str) -> str:
        prompt = (
            f"Summarize this {tool} tool output in one concise sentence (max 20 words). "
            f"Preserve key facts: filenames, counts, error messages, values.\n\n{output[:3000]}"
        )
        result = client.invoke(messages=[{"role": "user", "content": prompt}])
        return result.get("content", "").strip()

    return summarize


class SessionManager:
    """Manages conversation sessions with baseline tracking."""

    def __init__(
        self,
        provider: Provider,
        config: Optional[HarnessConfig] = None,
        tool_executor: Optional[ToolExecutor] = None,
        tool_registry: Optional[ToolRegistry] = None,
        skill_registry: Optional[SkillRegistry] = None,
        context_limit: int = 200000,
        workspace_root: Optional[Path] = None,
        react_config: Optional[ReactConfig] = None,
    ):
        self.provider = provider
        self.workspace_root = workspace_root
        self.baseline_manager = BaselineManager()
        self.tool_executor = tool_executor
        self.tool_registry = tool_registry
        self.skill_registry = skill_registry
        self.context_limit = context_limit
        self.react_config = react_config or ReactConfig()
        self._ctx_monitors: dict[str, ContextWindowMonitor] = {}

        self.conv_manager = ConversationManager(
            config=config or HarnessConfig(),
            workspace_root=workspace_root,
            harness_name=".ctrlcode",
        )
        self._store = SessionStore(self.conv_manager, provider, self._ctrlcode_dir)

        self._verification_detector = VerificationDetector()
        self._base_prompt = load_base_prompt(workspace_root)
        self._agent_instructions = load_agent_instructions(workspace_root)
        self._verification_commands = detect_verification_commands(workspace_root, self._verification_detector)

        # --- Middleware stack ---
        permission_manager = tool_executor.permission_manager if tool_executor else None
        self._permission_manager = permission_manager

        self._memory_mw = MemoryMiddleware(
            db_path=self._ctrlcode_dir / "rootset.db",
            workspace_root=workspace_root,
            conv_manager=self.conv_manager,
            project_id_loader=self._store.load_or_create_project_id,
        )
        self._workspace_mw = WorkspaceMiddleware(
            workspace_root=workspace_root,
            memory_mw=self._memory_mw,
            conv_manager=self.conv_manager,
            sessions=self._store.sessions,
        )
        self._mw_stack = MiddlewareStack([
            self._memory_mw,
            self._workspace_mw,
            SkillMiddleware(skill_registry) if skill_registry else _NoopMiddleware(),
            BaselineMiddleware(self.baseline_manager, ""),  # session_id patched per-turn
            ContextAssemblyMiddleware(
                base_prompt=self._base_prompt,
                agent_instructions=self._agent_instructions,
                verification_commands=self._verification_commands,
                ctrlcode_dir=self._ctrlcode_dir,
                workspace_root=workspace_root,
                context_limit=context_limit,
                skill_registry=skill_registry,
            ),
            PermissionMiddleware(permission_manager),
            ProgressMiddleware(self._ctrlcode_dir),
        ])

    @property
    def _ctrlcode_dir(self) -> Path:
        return (self.workspace_root / ".ctrlcode") if self.workspace_root else (Path.cwd() / ".ctrlcode")

    @property
    def sessions(self) -> dict[str, Session]:
        """Expose session dict for backward compatibility."""
        return self._store.sessions

    async def close(self) -> None:
        self._ctx_monitors.clear()
        await self._mw_stack.close()

    # ------------------------------------------------------------------
    # Session lifecycle (facade over SessionStore)
    # ------------------------------------------------------------------

    def create_session(self, provider: Optional[Provider] = None, workspace_root: Optional[Path] = None) -> Session:
        if workspace_root:
            self._update_workspace(workspace_root)
        return self._store.create(provider, workspace_root=workspace_root or self.workspace_root)

    def _update_workspace(self, workspace_root: Path) -> None:
        """Update workspace root across all components. Safe for single-user server."""
        self.workspace_root = workspace_root
        self._memory_mw._workspace_root = workspace_root
        self._workspace_mw._workspace_root = workspace_root
        self._base_prompt = load_base_prompt(workspace_root)
        self._agent_instructions = load_agent_instructions(workspace_root)
        self._verification_commands = detect_verification_commands(workspace_root, self._verification_detector)

    def resume_session(self, session_id: str, provider: Optional[Provider] = None) -> Optional[Session]:
        return self._store.resume(session_id, provider)

    def get_session(self, session_id: str) -> Optional[Session]:
        return self._store.get(session_id)

    # ------------------------------------------------------------------
    # Main conversation loop
    # ------------------------------------------------------------------

    async def process_turn(
        self,
        session_id: str,
        user_input: str,
        tools: list[dict] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")

        ctx = TurnContext(session=session, user_input=user_input)
        ctx.context_before = session.context_before_turn
        self._store.mark_active(session_id)

        # Patch session_id into BaselineMiddleware (it's stateless per-turn)
        for mw in self._mw_stack._middlewares:
            if isinstance(mw, BaselineMiddleware):
                mw._session_id = session_id
                break

        # Compute context usage snapshot before user message (acceptable approximation)
        session.context_before_turn = self.conv_manager.calculate_context_usage(
            session.conv_id, model=session.provider.model
        )

        # --- Proactive context window check ---
        monitor = self._ctx_monitors.get(session_id)
        if monitor is None:
            monitor = ContextWindowMonitor(
                model=session.provider.model,
                ctrlcode_dir=self._ctrlcode_dir,
            )
            self._ctx_monitors[session_id] = monitor

        if monitor.is_over_threshold(session.context_before_turn):
            compaction_llm = LLMClientAdapter(session.provider, asyncio.get_running_loop())
            compact_result = await monitor.summarize_and_compact(
                session_id=session_id,
                conv_manager=self.conv_manager,
                conv_id=session.conv_id,
                llm_client=compaction_llm,
            )
            new_conv_id = compact_result.get("new_conv_id")
            if new_conv_id and new_conv_id != session.conv_id:
                session.conv_id = new_conv_id
            session.context_before_turn = self.conv_manager.calculate_context_usage(
                session.conv_id, model=session.provider.model
            )
            yield StreamEvent(
                type="context_compaction",
                data={"tokens_saved": compact_result.get("tokens_saved", 0), "trigger": "threshold"},
            )

        # Run all before_turn hooks (skill expansion, baseline, memory, workspace, context assembly)
        try:
            await self._mw_stack.run_before_turn(ctx)
        except ValueError as e:
            # SkillMiddleware raises ValueError for unknown skill names
            yield StreamEvent(type="request_error", data={"error": str(e)})
            return

        # Emit skill_expanded event if skill was processed
        for ev in ctx.extra.get("skill_events", []):
            yield ev

        # Add the (possibly expanded) user message
        _summarizer = _make_output_summarizer(session.provider, asyncio.get_running_loop())
        self.conv_manager.prune_before_turn(
            session.conv_id,
            query=user_input,
            summarizer=_summarizer,
        )

        # Early warning: log if history has dangling tool calls from a prior crash
        from ..agents.tool_recovery import has_dangling_tool_calls
        _history = self.conv_manager.get_messages(session.conv_id)
        if has_dangling_tool_calls(_history):
            logger.warning(
                "Session %s has dangling tool calls in history — will be patched by ReAct loop",
                session_id,
            )

        user_msg = Message(id=generate_msg_id(), role="user")
        user_msg.add_part(TextPart(text=ctx.user_input))
        self.conv_manager.add_message(session.conv_id, user_msg)

        messages = self.conv_manager.to_model_format(session.conv_id)
        logger.info(f"to_model_format: {len(messages)} messages, roles={[m.get('role') for m in messages]}")

        ctx.extra["pre_turn_count"] = len(messages)
        ctx.messages_snapshot = messages  # exact input sent to the model this turn

        # Register compact_conversation bound to this session (overwrite for multi-session safety)
        if self.tool_registry:
            from ..tools import setup_context_tools
            setup_context_tools(self.tool_registry, self, session_id)

        if tools is None and self.tool_registry:
            tools = self.tool_registry.get_tool_definitions()
            logger.info(f"Fetched {len(tools)} tool definitions from registry")
        else:
            logger.info(f"Tools parameter: {tools}")

        compaction_client: LLMClientAdapter | None = None
        if self.react_config.mid_task_compaction:
            compaction_client = LLMClientAdapter(session.provider, asyncio.get_running_loop())
        # Make compaction client available to MemoryMiddleware for LLM summary
        self._memory_mw._compaction_client = compaction_client

        _commands_run: list[str] = []

        from ..agents.react_loop import AgentReActLoop
        usage_tokens = 0
        assert self.tool_executor is not None, "tool_executor required for process_turn"

        _turn_start = time.monotonic()
        async for event in AgentReActLoop().stream(
            provider=session.provider,
            conv_manager=self.conv_manager,
            conv_id=session.conv_id,
            tool_executor=self.tool_executor,
            tools=tools or [],
            system_prompt_msg=ctx.system_prompt_msg,
            max_continuations=self.react_config.max_continuations,
            doom_loop_threshold=self.react_config.doom_loop_threshold,
            tool_delay=self.react_config.tool_delay,
            max_output_tokens=self.react_config.max_output_tokens,
            compaction_client=compaction_client,
            pre_tool_hook=self._mw_stack.make_pre_tool_hook(ctx),
            post_tool_hook=self._mw_stack.make_post_tool_hook(ctx),
            before_complete_hook=make_before_complete_hook(
                session_id, _commands_run, self.tool_executor,
                self._verification_commands, self._verification_detector,
                touched_files=ctx.touched_files,
            ),
        ):
            if event.type == "tool_result":
                ctx.tool_calls.append(event.data)
                if event.data.get("tool") == "run_command":
                    cmd = event.data.get("input", {}).get("command", "")
                    if cmd:
                        _commands_run.append(cmd)
                        ctx.commands_run.append(cmd)
            elif event.type == "text":
                ctx.assistant_parts.append(event.data.get("text", ""))
            elif event.type == "task_summary":
                ctx.task_summary = event.data.get("summary", "")
            elif event.type == "compaction":
                ctx.compaction_fired = True
            elif event.type == "agent_compaction":
                ctx.compaction_fired = True
            elif event.type == "iteration_warning":
                ctx.iteration_warning_fired = True
            if event.type == "usage":
                usage_tokens += event.data.get("usage", {}).get("completion_tokens", 0)
                yield StreamEvent(
                    type="token_usage",
                    data={
                        "total_tokens": self.conv_manager.calculate_context_usage(session.conv_id, model=session.provider.model),
                        "output_tokens": usage_tokens,
                        "turn_tokens": 0,
                        "input_tokens": 0,
                    },
                )
            yield event

        # Populate touched_files on ctx for after_turn hooks
        ctx.touched_files = [
            tc.get("input", {}).get("path", "")
            for tc in ctx.tool_calls
            if tc.get("tool") in ("write_file", "update_file", "edit_file", "create_file")
            and tc.get("success") and tc.get("input", {}).get("path")
        ]

        ctx.context_after = self.conv_manager.calculate_context_usage(session.conv_id, model=session.provider.model)
        ctx.messages_after = self.conv_manager.to_model_format(session.conv_id)
        ctx.turn_duration_s = time.monotonic() - _turn_start
        await self._mw_stack.run_after_turn(ctx)

        context_after = ctx.context_after
        total_turn_tokens = context_after - session.context_before_turn
        if usage_tokens > 0:
            session.cumulative_tokens += usage_tokens
        yield StreamEvent(
            type="token_usage",
            data={
                "total_tokens": context_after,
                "turn_tokens": total_turn_tokens,
                "output_tokens": usage_tokens,
                "input_tokens": total_turn_tokens - usage_tokens if total_turn_tokens > usage_tokens else 0,
            },
        )

    # ------------------------------------------------------------------
    # Conversation utilities
    # ------------------------------------------------------------------

    def get_baseline(self, session_id: str) -> Optional[Baseline]:
        return self.baseline_manager.get(session_id)

    def get_context_stats(self, session_id: str) -> dict[str, Any]:
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")
        messages = self.conv_manager.to_model_format(session.conv_id)
        token_count = self.conv_manager.calculate_context_usage(session.conv_id, model=session.provider.model)
        logger.info(f"Context stats for {session_id}: {len(messages)} messages, {token_count} tokens")
        return {"message_count": len(messages), "estimated_tokens": token_count, "max_tokens": self.context_limit}

    def get_session_messages(self, session_id: str) -> list[dict]:
        """Return model-format messages for a session."""
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")
        return self.conv_manager.to_model_format(session.conv_id)

    def compact_conversation(self, session_id: str) -> None:
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")
        self.conv_manager.prune_before_turn(session.conv_id)

    def clear_conversation(self, session_id: str) -> None:
        session = self._store.get(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")
        old_conv_id = session.conv_id
        new_conv = self.conv_manager.create_conversation(project_id="ctrl-code")
        session.conv_id = new_conv.id
        session.cumulative_tokens = 0
        logger.info(f"Cleared conversation history for session {session_id} (old: {old_conv_id}, new: {new_conv.id})")


class _NoopMiddleware:
    """Placeholder when an optional middleware (e.g. SkillMiddleware) has no registry."""

    async def before_turn(self, ctx: TurnContext) -> None:
        pass

    async def pre_tool(self, ctx: TurnContext, tool_call: dict):
        return
        yield  # noqa: unreachable

    async def after_tool_call(self, ctx: TurnContext, tool_call: dict, result: Any):
        return
        yield  # noqa: unreachable

    async def after_turn(self, ctx: TurnContext) -> None:
        pass

    async def close(self) -> None:
        pass
