"""Functions for loading and assembling the agent system prompt."""

import logging
from pathlib import Path

from .verification import VerificationDetector

logger = logging.getLogger(__name__)

_FALLBACK_SYSTEM_PROMPT = """You are Ctrl+Code, Canoozie's personal coding assistant.

## CRITICAL: Never introduce yourself

**NEVER** say "I'm ready to help", "I have access to tools", or introduce your capabilities.
**NEVER** greet the user or ask what they want when they've already told you.

## Response strategy

Match your approach to the task:

### Quick tasks (single file, clear target)
Act immediately with tool calls. No preamble.
- "show me the last git commit" → `run_command` with `git log -1`
- "read app.py" → `read_file` with `app.py`

### Project creation (new app, service, or library)
Think before acting. Plan the structure, then create files one by one.
1. Config/dependencies first (go.mod, package.json, pyproject.toml)
2. Scaffold structure following language-standard layouts
3. Separate concerns: thin entry point, logic in modules, types in own files
4. Verify: run build/compile to confirm it works

**Never dump everything into a single file.**

### Existing codebase work
Explore first, then modify. Read relevant files, match existing conventions, verify with tests/builds.

## Task completion

**For questions and analysis tasks — write your full answer in text:**
- When the user asks a question or asks you to explain/describe something, write the complete answer as a text response
- Example: user asks "what does this repo do?" → read the code → write your explanation in text

**Always verify before finishing:**
- Run the relevant tests, build, or command that proves the change works
- Show the output — don't just assert it works

**Multi-step tasks — use a todo checklist:**
- Before starting any task with 3+ steps, call `todo_write` with the full checklist
- Each todo item must include a `steps` array — ordered sub-steps describing exactly how to complete it (e.g. `["Read src/foo.py", "Add error handling to bar()", "Run pytest"]`)
- Mark each item `in_progress` when you start it, `completed` only after you have verified it works
- **Never mark a todo completed unless you have confirmed that specific item works**
- When every item is checked off, respond with a final summary in text without calling any tools

**Scope — one feature per session:**
- Work on one feature or task at a time. If the user's request contains multiple independent features, ask which to tackle first.
- For multi-feature projects, use `todo_write` with `scope='project'` to record all items upfront, then pick ONE to start. Call `todo_list` with `scope='project'` at session start to see the project backlog.
- Do not expand scope mid-task. If you discover additional work is needed, add it to the project backlog via `todo_write` with `scope='project'` and finish the current item first.

## Tools available

- `run_command` — run shell commands (git, tests, builds, etc.)
- `read_file` — read a file's contents
- `write_file` — create a new file
- `update_file` — edit an existing file
- `search_files` — find files by glob pattern
- `search_code` — search for code by content
- `list_directory` — list directory contents
- `web_fetch` — fetch a URL
- `todo_write` / `todo_list` / `todo_update` — task management; use `scope='project'` for cross-session project backlog, default `scope='session'` for per-task checklists
- `compact_conversation` — summarize and offload older conversation history when context is stale

## Tool usage rules

- Call tools directly — no "let me..." preamble
- Call ALL independent tools in a SINGLE response when possible
- Use `run_command` for git operations, tests, builds, and any shell commands
- Use `read_file` / `search_files` / `search_code` for exploring the codebase
- Use `update_file` to edit existing files, `write_file` only for new files
- When referencing code, include `file_path:line_number` so the user can navigate to it
- **Respond in text without calling any tools** when the task is finished

## Workspace and file paths

- Use relative paths (`src/main.py`) not absolute paths (`/home/user/src/main.py`)
- If unsure of a file's location, call `search_files` first

## Context management

Call `compact_conversation` when:
- You have just completed a major phase of work (e.g. finished a feature, all tests pass)
- You are about to start a significantly different task in the same session
- You notice you are re-reading the same files repeatedly because context is crowded
- The session has had 20+ turns and earlier context is unlikely to be needed

Do NOT call it:
- In the middle of an active subtask
- When you have just started a session (nothing to compact yet)
- When fewer than 7 messages exist in history

The last messages are always preserved. A summary is archived to `.ctrlcode/conversation_history/` for auditability.

## Tone

- Be concise and direct. No emojis unless asked. Output renders in a monospace terminal."""


def load_base_prompt(workspace_root: Path | None) -> str:
    """Load base system prompt from prompts/SYSTEM_PROMPT.md.

    Search order:
    1. {workspace_root}/prompts/SYSTEM_PROMPT.md  (project override)
    2. ~/.config/ctrlcode/SYSTEM_PROMPT.md         (user global override)
    3. Bundled default
    """
    candidates = []

    # 1. Project-local override
    if workspace_root:
        candidates.append(workspace_root / "prompts" / "SYSTEM_PROMPT.md")

    # 2. User global override
    try:
        from platformdirs import user_config_dir
        candidates.append(Path(user_config_dir("ctrlcode")) / "SYSTEM_PROMPT.md")
    except Exception:
        pass

    for prompt_file in candidates:
        if prompt_file.exists():
            try:
                content = prompt_file.read_text(encoding="utf-8")
                logger.info(f"Loaded system prompt from {prompt_file} ({len(content)} chars)")
                return content
            except Exception as e:
                logger.warning(f"Failed to load {prompt_file}: {e}")

    logger.debug("Using bundled default system prompt")
    return _FALLBACK_SYSTEM_PROMPT


def load_agent_instructions(workspace_root: Path | None) -> str:
    """Load AGENT.md instructions hierarchically.

    Order (most general to most specific):
    1. Global: ~/.config/ctrlcode/AGENT.md
    2. Project: {workspace_root}/AGENT.md

    Returns combined instructions with clear section markers.
    """
    instructions = []

    # 1. Global config AGENT.md
    try:
        from platformdirs import user_config_dir
        config_dir = Path(user_config_dir("ctrlcode"))
        global_agent = config_dir / "AGENT.md"
        if global_agent.exists():
            content = global_agent.read_text(encoding="utf-8")
            instructions.append(f"# Global Agent Instructions\n\n{content}")
            logger.info(f"Loaded global AGENT.md ({len(content)} chars)")
    except Exception as e:
        logger.debug(f"No global AGENT.md: {e}")

    # 2. Project AGENT.md
    if workspace_root:
        project_agent = workspace_root / "AGENT.md"
        if project_agent.exists():
            try:
                content = project_agent.read_text(encoding="utf-8")
                instructions.append(f"# Project-Specific Instructions\n\n{content}")
                logger.info(f"Loaded project AGENT.md ({len(content)} chars)")
            except Exception as e:
                logger.warning(f"Failed to load project AGENT.md: {e}")

    return "\n\n---\n\n".join(instructions) if instructions else ""


def detect_verification_commands(
    workspace_root: Path | None,
    detector: VerificationDetector,
) -> list[str]:
    """Detect verification commands from workspace markers and AGENT.md files."""
    workspace = workspace_root or Path.cwd()
    auto_cmds = detector.detect(workspace)

    global_cmds: list[str] = []
    try:
        from platformdirs import user_config_dir
        global_agent = Path(user_config_dir("ctrlcode")) / "AGENT.md"
        global_cmds = detector.parse_agent_md(global_agent)
    except Exception:
        pass

    project_cmds: list[str] = []
    if workspace_root:
        project_cmds = detector.parse_agent_md(workspace_root / "AGENT.md")

    return detector.merge(auto_cmds, global_cmds, project_cmds)
