"""Adapters that bridge ctrl+code types to external library interfaces."""

import asyncio

from ..providers.base import Provider


class LLMClientAdapter:
    """Bridges ctrl+code Provider to harness-utils LLMClient (synchronous interface).

    compact() is synchronous and called from a thread executor.
    invoke() submits provider.generate() to the running event loop and blocks.
    """

    def __init__(self, provider: Provider, loop: asyncio.AbstractEventLoop):
        self._provider = provider
        self._loop = loop

    def invoke(
        self,
        messages: list[dict],
        system: list[str] | None = None,
        model: str | None = None,
    ) -> dict:
        all_messages = messages
        if system:
            all_messages = [{"role": "system", "content": "\n".join(system)}] + messages
        future = asyncio.run_coroutine_threadsafe(
            self._provider.generate(all_messages), self._loop
        )
        result = future.result(timeout=120)
        return {
            "content": result.get("text", ""),
            "usage": {
                "input": result.get("usage", {}).get("prompt_tokens", 0),
                "output": result.get("usage", {}).get("completion_tokens", 0),
            },
            "model": result.get("model", ""),
        }
