"""Assemble the per-turn system prompt from all runtime sources."""

import json
import logging
import platform
from datetime import date
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


async def build_system_prompt(
    base_prompt: str,
    agent_instructions: str,
    verification_commands: list[str],
    ctrlcode_dir: Path,
    workspace_root: Optional[Path],
    assembler,
    context_limit: int,
    context_before_turn: int,
    user_input: str,
    skill_registry=None,
) -> dict:
    """Build a system prompt message dict from all runtime sources."""
    agent_section = f"\n\n{agent_instructions}" if agent_instructions else ""

    skills_section = ""
    if skill_registry is not None:
        block = skill_registry.render_system_prompt_block()
        if block:
            skills_section = f"\n\n{block}"

    work_dir = workspace_root or Path.cwd()
    is_git = (work_dir / ".git").exists()
    env_section = f"""
**Environment:**
```
Working directory: {work_dir}
Is directory a git repo: {"Yes" if is_git else "No"}
Platform: {platform.system().lower()}
OS Version: {platform.platform()}
Today's date: {date.today().isoformat()}
```"""

    try:
        available_budget = max(1024, context_limit - context_before_turn - 1024)
        semantic_context = await assembler.assemble(query=user_input, budget_tokens=available_budget)
    except Exception:
        semantic_context = ""

    content = f"{base_prompt}{agent_section}{skills_section}{env_section}"

    # Inject project-scoped todo backlog
    project_todos_file = ctrlcode_dir / "todos" / "project.json"
    if project_todos_file.exists():
        try:
            project_todos = json.loads(project_todos_file.read_text(encoding="utf-8"))
            if isinstance(project_todos, list) and project_todos:
                status_symbol = {"pending": "[ ]", "in_progress": "[~]", "completed": "[x]"}
                lines = [
                    f"- {status_symbol.get(t.get('status', 'pending'), '[ ]')} {t.get('content', '')}"
                    for t in project_todos
                ]
                content += (
                    "\n\n## Project Backlog\n\n"
                    "Work on ONE pending item per session. Use `todo_write`/`todo_list`/`todo_update` "
                    "with `scope='project'` to manage this list.\n\n"
                    "Legend: `[ ]` pending · `[~]` in progress · `[x]` done\n\n"
                    + "\n".join(lines)
                )
        except Exception:
            pass

    # Inject prior-session progress
    progress_file = ctrlcode_dir / "progress.md"
    if progress_file.exists():
        try:
            progress_content = progress_file.read_text(encoding="utf-8").strip()
            if progress_content:
                content += (
                    f"\n\n## Prior Session Progress\n\n{progress_content}\n\n"
                    f"**Session startup:** Run `git log --oneline -10` to see recent "
                    f"commits and confirm the current state before proceeding."
                )
        except Exception:
            pass

    # Inject verification commands
    if verification_commands:
        cmds_list = "\n".join(f"- `{c}`" for c in verification_commands)
        content += (
            f"\n\n## Verification\n\n"
            f"Before finishing, run ALL of the following and show the output:\n\n"
            f"{cmds_list}"
        )

    if semantic_context:
        content += f"\n\n{semantic_context}"

    return {"role": "system", "content": content}
