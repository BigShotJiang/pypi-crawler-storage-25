"""Auto-detection of project verification commands."""

import json
import re
from pathlib import Path


class VerificationDetector:
    """Detect verification commands from workspace markers and AGENT.md."""

    def detect(self, workspace_root: Path) -> list[str]:
        """Scan workspace for known project markers and return verification commands."""
        commands: list[str] = []

        # Python: pyproject.toml / pytest.ini / setup.cfg
        if (
            (workspace_root / "pyproject.toml").exists()
            or (workspace_root / "pytest.ini").exists()
            or (workspace_root / "setup.cfg").exists()
        ):
            runner = self._infer_python_runner(workspace_root)
            commands.append(f"{runner} pytest" if runner else "pytest")

        # Go
        if (workspace_root / "go.mod").exists():
            commands.append("go test ./...")

        # Rust
        if (workspace_root / "Cargo.toml").exists():
            commands.append("cargo test")

        # Node / JS / TS
        package_json = workspace_root / "package.json"
        if package_json.exists():
            cmd = self._node_test_command(workspace_root, package_json)
            if cmd:
                commands.append(cmd)

        # Makefile with test or verify target
        makefile = workspace_root / "Makefile"
        if makefile.exists():
            targets = self._makefile_targets(makefile)
            if "test" in targets:
                commands.append("make test")
            elif "verify" in targets:
                commands.append("make verify")

        # dbt
        if (workspace_root / "dbt_project.yml").exists():
            commands.append("dbt test")

        return commands

    def parse_agent_md(self, agent_md_path: Path) -> list[str]:
        """Extract commands from the ## Verification section of an AGENT.md file."""
        if not agent_md_path.exists():
            return []
        try:
            content = agent_md_path.read_text(encoding="utf-8")
        except Exception:
            return []

        return self._extract_verification_commands(content)

    def merge(self, *command_lists: list[str]) -> list[str]:
        """Merge multiple command lists, preserving order and deduplicating."""
        seen: set[str] = set()
        result: list[str] = []
        for cmds in command_lists:
            for cmd in cmds:
                if cmd not in seen:
                    seen.add(cmd)
                    result.append(cmd)
        return result

    def command_ran(self, required: str, commands_run: list[str]) -> bool:
        """Return True if any executed command matches the required command (substring)."""
        # Extract the base command (first non-runner word)
        base = self._base_command(required)
        return any(base in cmd for cmd in commands_run)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _infer_python_runner(self, workspace_root: Path) -> str:
        """Infer the Python runner from lockfiles."""
        if (workspace_root / "uv.lock").exists():
            return "uv run"
        if (workspace_root / "poetry.lock").exists():
            return "poetry run"
        return ""

    def _node_test_command(self, workspace_root: Path, package_json: Path) -> str:
        """Return the npm/pnpm/yarn test command if a test script is defined."""
        try:
            data = json.loads(package_json.read_text(encoding="utf-8"))
            if "test" not in (data.get("scripts") or {}):
                return ""
        except Exception:
            return ""

        if (workspace_root / "pnpm-lock.yaml").exists():
            return "pnpm test"
        if (workspace_root / "yarn.lock").exists():
            return "yarn test"
        return "npm test"

    def _makefile_targets(self, makefile: Path) -> set[str]:
        """Parse target names from a Makefile."""
        targets: set[str] = set()
        try:
            for line in makefile.read_text(encoding="utf-8").splitlines():
                m = re.match(r"^([a-zA-Z0-9_-]+)\s*:", line)
                if m:
                    targets.add(m.group(1))
        except Exception:
            pass
        return targets

    def _extract_verification_commands(self, content: str) -> list[str]:
        """Parse commands from the ## Verification section of markdown content."""
        # Find the ## Verification section
        section_match = re.search(
            r"^##\s+Verification\b.*?$(.+?)(?=^##\s|\Z)",
            content,
            re.MULTILINE | re.DOTALL | re.IGNORECASE,
        )
        if not section_match:
            return []

        section = section_match.group(1)
        commands: list[str] = []

        # Extract commands from fenced sh/bash/shell blocks
        for fence_match in re.finditer(
            r"```(?:sh|bash|shell)?\s*\n(.*?)```",
            section,
            re.DOTALL,
        ):
            for line in fence_match.group(1).splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    commands.append(line)

        # Fallback: bullet points with backtick-quoted commands
        if not commands:
            for bullet_match in re.finditer(r"^\s*[-*]\s+`([^`]+)`", section, re.MULTILINE):
                commands.append(bullet_match.group(1).strip())

        return commands

    def _base_command(self, cmd: str) -> str:
        """Extract the meaningful base command for substring matching.

        E.g. 'uv run pytest' -> 'pytest', 'go test ./...' -> 'go test', 'make test' -> 'make test'
        """
        # Strip common runner prefixes
        for prefix in ("uv run ", "poetry run ", "npx "):
            if cmd.startswith(prefix):
                cmd = cmd[len(prefix):]
                break
        # Return first word (or first two for multi-word commands like 'go test', 'make test')
        parts = cmd.split()
        if len(parts) >= 2 and parts[0] in ("go", "make", "cargo", "dbt", "npm", "pnpm", "yarn"):
            return f"{parts[0]} {parts[1]}"
        return parts[0] if parts else cmd
