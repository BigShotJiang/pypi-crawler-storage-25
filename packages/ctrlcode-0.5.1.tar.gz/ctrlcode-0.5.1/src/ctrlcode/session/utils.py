"""Stateless utility functions for the session layer."""

import uuid


def strip_markdown_fences(content: str) -> str:
    """Remove markdown code fences from content if present."""
    lines = content.splitlines()

    # Check if first line is a code fence
    if lines and lines[0].strip().startswith("```"):
        # Remove first line
        lines = lines[1:]

    # Check if last line is a closing fence
    if lines and lines[-1].strip() == "```":
        # Remove last line
        lines = lines[:-1]

    # Remove any trailing instruction lines (e.g., "Run with: ...")
    while lines and lines[-1].strip().startswith("Run with:"):
        lines = lines[:-1]

    return "\n".join(lines)


def generate_msg_id() -> str:
    """Generate a unique message ID."""
    return f"msg_{uuid.uuid4().hex[:12]}"
