"""Entity extraction from artifact content."""

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class Entities:
    files: list[str]
    functions: list[str]
    errors: list[str]


class EntityExtractor:
    FILE_RE = re.compile(r'[\w./\-]+\.(?:py|ts|js|rs|go|md|toml|json|yaml)')
    FUNC_RE = re.compile(r'(?:async\s+)?def\s+(\w+)|(?:fn|func|function)\s+(\w+)')
    ERROR_RE = re.compile(r'\b\w*(?:Error|Exception|Traceback)\b')

    def extract(self, content: str, language: str = "") -> Entities:
        files = list(dict.fromkeys(self.FILE_RE.findall(content)))
        errors = list(dict.fromkeys(self.ERROR_RE.findall(content)))
        
        # Use tree-sitter for function extraction when language is known
        functions = self._extract_functions(content, language)
        
        return Entities(files=files, functions=functions, errors=errors)

    def _extract_functions(self, content: str, language: str) -> list[str]:
        """Extract function/class names using tree-sitter when possible, regex fallback."""
        if language and language != "":
            try:
                from tree_sitter_language_pack import get_parser
                from .indexers.common import extract_definitions
                
                normalized = language.lower()
                parser = get_parser(normalized)
                tree = parser.parse(content.encode())
                definitions = extract_definitions(tree, content.encode(), normalized)
                if definitions:
                    return list(dict.fromkeys(definitions))
            except (ImportError, LookupError, Exception):
                # Fall back to regex if tree-sitter fails
                pass
        
        # Regex fallback for prose or when tree-sitter unavailable
        functions = list(dict.fromkeys(
            m.group(1) or m.group(2) for m in self.FUNC_RE.finditer(content)
        ))
        return functions
