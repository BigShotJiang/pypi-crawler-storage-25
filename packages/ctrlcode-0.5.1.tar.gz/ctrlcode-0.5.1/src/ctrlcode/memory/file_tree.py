"""Merkle-tree workspace scanner for change detection."""

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .store import ArtifactStore

logger = logging.getLogger(__name__)

IGNORED_DIRS = {
    ".venv", "__pycache__", ".git", "build", "dist",
    ".mypy_cache", ".ruff_cache", "node_modules", ".ctrlcode",
}
IGNORED_EXTENSIONS = {".pyc", ".pyo"}


@dataclass
class FileChangeSet:
    added: list[str] = field(default_factory=list)
    modified: list[str] = field(default_factory=list)
    moved: list[tuple[str, str]] = field(default_factory=list)   # (old_path, new_path)
    deleted: list[str] = field(default_factory=list)

    @property
    def all_changed(self) -> list[str]:
        """Paths that need artifact supersession."""
        result = list(self.modified) + list(self.deleted)
        result += [old for old, _ in self.moved]
        return result

    @property
    def is_empty(self) -> bool:
        return not (self.added or self.modified or self.moved or self.deleted)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _dir_hash(children: list[tuple[str, str]]) -> str:
    """Hash a directory node from sorted (name, child_hash) pairs."""
    payload = "\n".join(f"{name}:{chash}" for name, chash in sorted(children))
    return hashlib.sha256(payload.encode()).hexdigest()


class FileTreeIndex:
    """Scans the workspace and detects file changes via content hashes (Merkle tree)."""

    def __init__(self, store: ArtifactStore, workspace_root: Path) -> None:
        self._store = store
        self._root = workspace_root

    def _rel(self, path: Path) -> str:
        return str(path.relative_to(self._root))

    def _is_ignored(self, path: Path) -> bool:
        for part in path.parts:
            if part in IGNORED_DIRS:
                return True
        if path.suffix in IGNORED_EXTENSIONS:
            return True
        return False

    async def scan(self) -> FileChangeSet:
        """Walk filesystem, compare against stored tree, return classified change set."""
        db = await self._store._ensure_init()

        # Load stored state: path → (content_hash, mtime)
        stored: dict[str, tuple[str, Optional[float]]] = {}
        async with db.execute("SELECT path, content_hash, mtime FROM file_tree WHERE node_type='file'") as cur:
            async for row in cur:
                stored[row["path"]] = (row["content_hash"], row["mtime"])

        # Build reverse map: content_hash → old_path (for move detection)
        hash_to_old_path: dict[str, str] = {h: p for p, (h, _) in stored.items()}

        change_set = FileChangeSet()
        seen_paths: set[str] = set()

        for fs_path in self._root.rglob("*"):
            if not fs_path.is_file():
                continue
            if self._is_ignored(fs_path):
                continue

            rel = self._rel(fs_path)
            seen_paths.add(rel)

            try:
                stat = fs_path.stat()
                mtime = stat.st_mtime
                size = stat.st_size
            except OSError:
                continue

            if rel in stored:
                stored_hash, stored_mtime = stored[rel]
                # mtime pre-filter: if unchanged, trust stored hash
                if stored_mtime is not None and abs(mtime - stored_mtime) < 0.01:
                    continue  # UNCHANGED
                # mtime differs — recompute hash
                try:
                    new_hash = _sha256(fs_path)
                except OSError:
                    continue
                if new_hash == stored_hash:
                    # mtime changed but content same — update mtime only
                    await self._upsert_file(db, rel, new_hash, mtime, size)
                else:
                    change_set.modified.append(rel)
                    await self._upsert_file(db, rel, new_hash, mtime, size)
            else:
                # New path — check if it's a move
                try:
                    new_hash = _sha256(fs_path)
                except OSError:
                    continue
                if new_hash in hash_to_old_path:
                    old_path = hash_to_old_path[new_hash]
                    change_set.moved.append((old_path, rel))
                    await self._upsert_file(db, rel, new_hash, mtime, size)
                else:
                    change_set.added.append(rel)
                    await self._upsert_file(db, rel, new_hash, mtime, size)

        # Deleted: in stored but not seen
        for path in stored:
            if path not in seen_paths:
                change_set.deleted.append(path)
                await db.execute("DELETE FROM file_tree WHERE path=?", (path,))

        await db.commit()
        return change_set

    async def update_file(self, rel_path: str) -> None:
        """Update a single file entry (called after agent writes a file)."""
        db = await self._store._ensure_init()
        full = self._root / rel_path
        if not full.exists():
            await db.execute("DELETE FROM file_tree WHERE path=?", (rel_path,))
            await db.commit()
            return
        try:
            stat = full.stat()
            new_hash = _sha256(full)
            await self._upsert_file(db, rel_path, new_hash, stat.st_mtime, stat.st_size)
            await db.commit()
        except OSError:
            pass

    async def get_hash(self, rel_path: str) -> Optional[str]:
        db = await self._store._ensure_init()
        async with db.execute("SELECT content_hash FROM file_tree WHERE path=?", (rel_path,)) as cur:
            row = await cur.fetchone()
        return row["content_hash"] if row else None

    async def _upsert_file(
        self,
        db,
        path: str,
        content_hash: str,
        mtime: float,
        size: int,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        parent = str(Path(path).parent) if "/" in path else None
        await db.execute(
            """
            INSERT INTO file_tree (path, node_type, content_hash, mtime, size, parent_path, scanned_at)
            VALUES (?, 'file', ?, ?, ?, ?, ?)
            ON CONFLICT(path) DO UPDATE SET
                content_hash=excluded.content_hash,
                mtime=excluded.mtime,
                size=excluded.size,
                scanned_at=excluded.scanned_at
            """,
            (path, content_hash, mtime, size, parent, now),
        )
