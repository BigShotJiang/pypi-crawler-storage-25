"""Message chunking for artifact storage."""

import json
import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Chunk:
    content: str
    kind: str       # "turn:user" | "turn:assistant" | "turn:tool_result" | "turn:code"
    language: str   # "" for prose, "python" etc for code
    metadata: dict[str, Any] = field(default_factory=dict)


class MessageChunker:
    TARGET_MAX = 800    # approx tokens (chars // 4)
    HARD_MAX = 1200
    CODE_FENCE = re.compile(r'```(\w*)\n(.*?)```', re.DOTALL)
    SENTENCE_SEP = re.compile(r'(?<=[.!?])\s+')
    TOOL_PREFIX = re.compile(r'^\[Tool: ([^\]]+)\]\n')

    def chunk_message(self, role: str, content: str) -> list[Chunk]:
        base_kind = f"turn:{role}" if role in ("user", "assistant") else "turn:tool_result"

        m = self.TOOL_PREFIX.match(content)
        if role == "user" and m:
            tool_name = m.group(1)
            body = content[m.end():]
            return self._chunk_tool_body(body, tool_name)

        segments = self._split_on_fences(content)
        chunks: list[Chunk] = []
        for seg_type, seg_content, lang in segments:
            if seg_type == "code":
                chunks.extend(self._chunk_code(seg_content, lang, base_kind))
            else:
                chunks.extend(self._chunk_prose(seg_content, base_kind))
        return chunks

    def _chunk_code(self, content: str, lang: str, base_kind: str) -> list[Chunk]:
        try:
            return self._treesitter_chunk(content, lang, base_kind)
        except Exception:
            return self._heuristic_code_chunk(content, lang, base_kind)

    def _chunk_prose(self, content: str, base_kind: str) -> list[Chunk]:
        sentences = self.SENTENCE_SEP.split(content.strip())
        chunks: list[Chunk] = []
        current: list[str] = []
        prev: str | None = None
        for sent in sentences:
            current.append(sent)
            if sum(len(s) for s in current) // 4 >= self.TARGET_MAX:
                chunks.append(Chunk(" ".join(current), base_kind, "", {}))
                current = [prev] if prev else []
            prev = sent
        if current:
            chunks.append(Chunk(" ".join(current), base_kind, "", {}))
        return chunks or [Chunk(content, base_kind, "", {})]

    def _chunk_tool_body(self, body: str, tool_name: str) -> list[Chunk]:
        meta = {"tool": tool_name}
        if re.search(r'Traceback|Error:|Exception:', body):
            return [Chunk(body, "turn:tool_result", "", meta)]
        try:
            data = json.loads(body)
            if isinstance(data, dict) and len(data) > 3:
                return [
                    Chunk(f"{k}: {json.dumps(v)}", "turn:tool_result", "", {**meta, "key": k})
                    for k, v in data.items()
                ]
        except (json.JSONDecodeError, ValueError):
            pass
        entries = [e.strip() for e in re.split(r'\n\s*\n', body) if e.strip()]
        if len(entries) > 1:
            return [Chunk(e, "turn:tool_result", "", meta) for e in entries]
        return self._chunk_prose(body, "turn:tool_result")

    def _treesitter_chunk(self, content: str, lang: str, base_kind: str) -> list[Chunk]:
        from tree_sitter_language_pack import get_parser
        normalized = lang.lower() or "python"
        try:
            parser = get_parser(normalized)  # type: ignore[arg-type]
        except LookupError:
            raise ValueError(f"unsupported language: {lang}")
        tree = parser.parse(content.encode())
        TOP_LEVEL_NODES = {
            "function_definition", "class_definition", "decorated_definition",  # Python
            "function_declaration", "method_definition", "class_declaration",   # JS/TS/Java
            "function_item", "impl_item", "struct_item", "trait_item",          # Rust
            "function_definition_statement",                                     # Go-ish
        }
        chunks = []
        for node in tree.root_node.children:
            if node.type in TOP_LEVEL_NODES:
                text = content[node.start_byte:node.end_byte]
                chunks.append(Chunk(text, base_kind, normalized, {}))
        return chunks if chunks else [Chunk(content, base_kind, lang, {})]

    def _heuristic_code_chunk(self, content: str, lang: str, base_kind: str) -> list[Chunk]:
        blocks = [b.strip() for b in re.split(r'\n\s*\n', content) if b.strip()]
        return [Chunk(b, base_kind, lang, {}) for b in blocks] if blocks else [Chunk(content, base_kind, lang, {})]

    def _split_on_fences(self, content: str) -> list[tuple[str, str, str]]:
        segments: list[tuple[str, str, str]] = []
        last = 0
        for m in self.CODE_FENCE.finditer(content):
            if m.start() > last:
                segments.append(("prose", content[last:m.start()], ""))
            segments.append(("code", m.group(2), m.group(1) or ""))
            last = m.end()
        if last < len(content):
            segments.append(("prose", content[last:], ""))
        return segments
