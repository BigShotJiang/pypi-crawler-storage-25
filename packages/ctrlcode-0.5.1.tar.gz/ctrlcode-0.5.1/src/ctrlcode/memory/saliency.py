"""Saliency scoring for conversation turns."""

from dataclasses import dataclass
import math


@dataclass
class SaliencyResult:
    score: float
    reason: str


class SaliencyScorer:
    CORRECTION_WORDS = {"actually", "no,", "wrong", "instead", "not what i meant", "that's not"}
    DECISION_PHRASES = {"let's use", "we'll go with", "approach is", "we decided", "i want to use"}
    WRITE_TOOLS = {"write_file", "update_file", "edit_file", "create_file"}
    READ_TOOLS = {"read_file"}
    EXECUTION_TOOLS = {"run_command", "bash"}

    def score_turn(
        self,
        user_input: str,
        tool_calls: list[dict],
        assistant_text: str,
        turn_messages: list[dict],
    ) -> SaliencyResult:
        # Calculate individual signal scores
        correction_score = self._calculate_correction_signal(user_input, assistant_text)
        structural_score = self._calculate_structural_signal(tool_calls)
        tool_diversity_score = self._calculate_tool_diversity_signal(tool_calls)
        length_ratio_score = self._calculate_length_ratio_signal(user_input, assistant_text)
        
        # Special high-priority signals (preserve original high-value detection)
        error_resolved_score = self._calculate_error_resolved_signal(tool_calls)
        
        # Weighted combination
        base_score = (
            correction_score * 0.25 +
            structural_score * 0.20 +
            tool_diversity_score * 0.30 +
            length_ratio_score * 0.15 +
            error_resolved_score * 0.10
        )
        
        # Apply sigmoid to normalize to 0.1-0.95 range
        final_score = 0.1 + 0.85 / (1 + math.exp(-6 * (base_score - 0.5)))
        
        # Determine primary reason for score
        reason = self._determine_primary_reason(
            correction_score, structural_score, tool_diversity_score, 
            length_ratio_score, error_resolved_score
        )
        
        return SaliencyResult(round(final_score, 2), reason)
    
    def _calculate_correction_signal(self, user_input: str, assistant_text: str) -> float:
        """Detect user corrections and decision-making language."""
        user_lower = user_input.lower()
        asst_lower = assistant_text.lower()
        
        score = 0.0
        
        # User correction words
        if any(w in user_lower for w in self.CORRECTION_WORDS):
            score += 0.8
            
        # Decision phrases in assistant response  
        if any(p in asst_lower for p in self.DECISION_PHRASES):
            score += 0.6
            
        return min(score, 1.0)
    
    def _calculate_structural_signal(self, tool_calls: list[dict]) -> float:
        """Weight based on how many files/operations were touched."""
        if not tool_calls:
            return 0.0
            
        # Count successful write operations (proxy for files touched)
        write_count = sum(1 for tc in tool_calls 
                         if tc.get("tool") in self.WRITE_TOOLS and tc.get("success", True))
        
        # Count code blocks and significant operations
        total_operations = len(tool_calls)
        
        # Scale: 0 operations = 0, 1-2 = moderate, 3+ = high
        if write_count == 0 and total_operations <= 1:
            return 0.1
        elif write_count == 0:
            return 0.3
        elif write_count <= 2:
            return 0.6
        else:
            return 0.9
    
    def _calculate_tool_diversity_signal(self, tool_calls: list[dict]) -> float:
        """Higher score for diverse tool usage (read+write+run > read-only)."""
        if not tool_calls:
            return 0.0
            
        tools_used = {tc.get("tool", "") for tc in tool_calls if tc.get("success", True)}
        
        has_read = bool(tools_used & self.READ_TOOLS)
        has_write = bool(tools_used & self.WRITE_TOOLS) 
        has_execution = bool(tools_used & self.EXECUTION_TOOLS)
        
        diversity_count = sum([has_read, has_write, has_execution])
        
        if diversity_count >= 3:
            return 0.9  # read + write + execution
        elif diversity_count == 2:
            if has_write:
                return 0.7  # write + other
            else:
                return 0.5  # read + execution only
        elif has_write:
            return 0.6  # write only
        elif has_read:
            return 0.3  # read only  
        else:
            return 0.2  # other tools only
    
    def _calculate_length_ratio_signal(self, user_input: str, assistant_text: str) -> float:
        """Long assistant response / short user input = detailed explanation."""
        user_len = len(user_input.strip())
        asst_len = len(assistant_text.strip())
        
        if user_len == 0:
            return 0.0
            
        ratio = asst_len / user_len
        
        # Code blocks add extra value
        code_bonus = 0.2 if "```" in assistant_text else 0.0
        
        # Scale ratio: <2 = low, 2-5 = medium, >5 = high
        if ratio < 2:
            base_score = 0.2
        elif ratio < 5:
            base_score = 0.5  
        else:
            base_score = 0.8
            
        return min(base_score + code_bonus, 1.0)
    
    def _calculate_error_resolved_signal(self, tool_calls: list[dict]) -> float:
        """Detect same tool with failure then success."""
        tool_names_by_success: dict[str, list[bool]] = {}
        for tc in tool_calls:
            name = tc.get("tool", "")
            tool_names_by_success.setdefault(name, []).append(tc.get("success", True))
            
        for results in tool_names_by_success.values():
            if False in results and True in results:
                return 1.0  # Strong signal for problem resolution
                
        return 0.0
    
    def _determine_primary_reason(self, correction: float, structural: float, 
                                 diversity: float, length_ratio: float, error_resolved: float) -> str:
        """Determine the primary reason for the score."""
        scores = [
            (error_resolved, "error_resolved"),
            (correction, "user_correction" if correction > 0.7 else "decision"),
            (diversity, "tool_diversity"),
            (structural, "structural_changes"),
            (length_ratio, "detailed_response")
        ]
        
        # Return reason for highest scoring signal
        scores.sort(key=lambda x: x[0], reverse=True)
        return scores[0][1] if scores[0][0] > 0.1 else "default"
