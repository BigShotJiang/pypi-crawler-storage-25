"""ArtifactWriter — write-path for semantic memory."""

import logging
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .chunker import MessageChunker
from .entity_extractor import EntityExtractor
from .rootset_backend import RootsetMemoryBackend
from .saliency import SaliencyResult, SaliencyScorer

logger = logging.getLogger(__name__)

WRITE_TOOLS = {"write_file", "update_file", "edit_file", "create_file"}


def _content_match_file(chunk_text: str, file_path: Path) -> Optional[str]:
    """Return content_hash if chunk_text pattern is found in file_path, else None."""
    try:
        import hashlib
        content = file_path.read_text(encoding="utf-8", errors="ignore")
        # Use first 200 chars of chunk as fingerprint (avoid whitespace sensitivity)
        needle = re.sub(r'\s+', ' ', chunk_text[:200]).strip()
        haystack = re.sub(r'\s+', ' ', content)
        if needle and needle in haystack:
            return hashlib.sha256(content.encode()).hexdigest()
    except OSError:
        pass
    return None


class ArtifactWriter:
    def __init__(
        self,
        backend: RootsetMemoryBackend,
        chunker: MessageChunker,
        scorer: SaliencyScorer,
        extractor: EntityExtractor,
        project_id: str,
        session_id: str,
        llm_client: Any | None = None,
        workspace_root: Optional[Path] = None,
    ) -> None:
        self._backend = backend
        self._chunker = chunker
        self._scorer = scorer
        self._extractor = extractor
        self._project_id = project_id
        self._session_id = session_id
        self._llm_client = llm_client
        self._workspace_root = workspace_root

    async def write_turn(
        self,
        user_input: str,
        turn_messages: list[dict],
        tool_calls: list[dict],
        assistant_text: str,
        touched_files: Optional[list[str]] = None,
        force_llm_summary: bool = False,
    ) -> None:
        saliency = self._scorer.score_turn(user_input, tool_calls, assistant_text, turn_messages)
        file_to_new_artifact: dict[str, int] = {}
        turn_first_artifact_id: Optional[int] = None
        turn_dominant_files: set[str] = set()

        # Build map of touched file rel_path → full Path for content matching
        touched_file_paths: dict[str, Path] = {}
        if touched_files and self._workspace_root:
            for rel in touched_files:
                full = self._workspace_root / rel
                if full.exists():
                    touched_file_paths[rel] = full

        for msg in turn_messages:
            role = msg.get("role", "")
            content = self._extract_content(msg)
            if not content.strip():
                continue
            chunks = self._chunker.chunk_message(role, content)
            for i, chunk in enumerate(chunks):
                entities = self._extractor.extract(chunk.content, chunk.language)

                # Content matching: find which touched file this chunk came from
                source_file: Optional[str] = None
                source_file_hash: Optional[str] = None
                for rel, full_path in touched_file_paths.items():
                    h = _content_match_file(chunk.content, full_path)
                    if h:
                        source_file = rel
                        source_file_hash = h
                        break

                metadata: dict[str, Any] = {
                    **chunk.metadata,
                    "saliency": saliency.score,
                    "saliency_reason": saliency.reason,
                    "entities": {
                        "files": entities.files,
                        "functions": entities.functions,
                        "errors": entities.errors,
                    },
                    "session_id": self._session_id,
                    "chunk_index": i,
                    "total_chunks": len(chunks),
                    "turn_ts": datetime.now(timezone.utc).isoformat(),
                }
                if source_file:
                    metadata["source_file"] = source_file
                    metadata["source_file_hash"] = source_file_hash
                try:
                    artifact = await self._backend.add_artifact(
                        chunk.content,
                        kind=chunk.kind,
                        namespace=self._session_id,
                        metadata=metadata,
                    )
                    
                    # Write high-saliency artifacts to project namespace for cross-session persistence
                    if saliency.score >= 0.85:
                        project_metadata = {**metadata, "namespace": self._project_id}
                        await self._backend.add_artifact(
                            chunk.content,
                            kind=chunk.kind,
                            namespace=self._project_id,
                            metadata=project_metadata,
                        )
                    if turn_first_artifact_id is None:
                        turn_first_artifact_id = artifact.id
                    for f in entities.files:
                        file_to_new_artifact[f] = artifact.id
                        turn_dominant_files.add(f)
                    entity_pairs = (
                        [(f, "file") for f in entities.files]
                        + [(fn, "function") for fn in entities.functions]
                        + [(e, "error") for e in entities.errors]
                    )
                    if entity_pairs:
                        await self._backend.index_entities(
                            artifact.id, entity_pairs, self._session_id
                        )
                except Exception as e:
                    logger.warning(f"Failed to store artifact chunk: {e}")

        # Supersession trigger 1: file write
        written_files = [
            tc.get("input", {}).get("path", "")
            for tc in tool_calls
            if tc.get("tool") in WRITE_TOOLS and tc.get("success")
        ]
        for fpath in written_files:
            if fpath:
                try:
                    await self._supersede_file_chunks(fpath, file_to_new_artifact.get(fpath))
                except Exception as e:
                    logger.warning(f"Supersession failed for {fpath}: {e}")

        # Supersession trigger 2: user correction — mark prior assistant chunk superseded
        if saliency.score >= 0.95:
            try:
                await self._supersede_prior_assistant_chunk(turn_first_artifact_id)
            except Exception as e:
                logger.warning(f"Correction supersession failed: {e}")

        # Supersession trigger 3: error resolved — mark most recent error chunk superseded
        if saliency.reason == "error_resolved":
            try:
                await self._supersede_recent_error_chunk(turn_first_artifact_id)
            except Exception as e:
                logger.warning(f"Error resolution supersession failed: {e}")

        # Engagement tracking: attribute turn tokens to dominant file clusters
        if turn_dominant_files:
            approx_tokens = (
                sum(len(self._extract_content(m)) for m in turn_messages) // 4
            )
            turn_id = str(uuid.uuid4())
            for fpath in turn_dominant_files:
                try:
                    await self._backend.log_engagement(
                        fpath, self._session_id, approx_tokens, turn_id
                    )
                except Exception as e:
                    logger.warning(f"Engagement log failed for {fpath}: {e}")

        try:
            await self._update_summary(saliency, assistant_text, force_llm_summary)
        except Exception as e:
            logger.warning(f"Summary update failed: {e}")

    def _extract_content(self, msg: dict) -> str:
        content = msg.get("content", "")
        if isinstance(content, list):
            return " ".join(
                p.get("text", "") for p in content if isinstance(p, dict) and "text" in p
            )
        return str(content)

    async def _supersede_file_chunks(self, file_path: str, new_id: Optional[int]) -> None:
        prior = await self._backend.search_artifacts(
            file_path, kind=None, namespace=self._session_id, top_k=20,
        )
        for result in prior:
            art = result.artifact
            if (
                art.id != new_id
                and file_path in art.metadata.get("entities", {}).get("files", [])
                and not art.metadata.get("superseded_by")
            ):
                await self._backend.update_artifact(
                    art.id, metadata={**art.metadata, "superseded_by": new_id}
                )

    async def _supersede_prior_assistant_chunk(self, new_id: Optional[int]) -> None:
        """Trigger 2: mark the most recent prior assistant response as superseded."""
        prior = await self._backend.search_artifacts(
            "", kind="turn:assistant",
            namespace=self._session_id, top_k=1,
        )
        for result in prior:
            art = result.artifact
            if art.id != new_id and not art.metadata.get("superseded_by"):
                await self._backend.update_artifact(
                    art.id, metadata={**art.metadata, "superseded_by": new_id}
                )
                break

    async def _supersede_recent_error_chunk(self, new_id: Optional[int]) -> None:
        """Trigger 3: mark the most recent tool_result chunk that contains errors as superseded."""
        prior = await self._backend.search_artifacts(
            "", kind="turn:tool_result",
            namespace=self._session_id, top_k=5,
        )
        for result in prior:
            art = result.artifact
            if (
                art.id != new_id
                and art.metadata.get("entities", {}).get("errors")
                and not art.metadata.get("superseded_by")
            ):
                await self._backend.update_artifact(
                    art.id, metadata={**art.metadata, "superseded_by": new_id}
                )
                break

    async def _update_summary(self, saliency: SaliencyResult, assistant_text: str, force_llm_summary: bool = False) -> None:
        if not force_llm_summary and saliency.score < 0.70:
            return
        results = await self._backend.search_artifacts(
            "session summary", kind="session:summary",
            namespace=self._session_id, top_k=1,
        )
        existing = results[0].artifact if results else None
        compaction_count = existing.metadata.get("compaction_count", 0) if existing else 0
        
        highlight = assistant_text[:300].strip()
        new_entry = f"[{saliency.reason}] {highlight}"

        # Force LLM summary or check token budget for regular updates
        if force_llm_summary:
            combined = await self._condense_summary(existing.content if existing else "", new_entry, compaction_count)
            compaction_count += 1
            metadata = {"session_id": self._session_id, "compaction_count": compaction_count}
            if existing:
                await self._backend.update_artifact(existing.id, content=combined, metadata=metadata)
            else:
                await self._backend.add_artifact(
                    combined,
                    kind="session:summary",
                    namespace=self._session_id,
                    metadata=metadata,
                )
        elif existing:
            combined = existing.content + "\n" + new_entry
            if len(combined) // 4 > 450:
                combined = await self._condense_summary(existing.content, new_entry, compaction_count)
                compaction_count += 1
                metadata = {**existing.metadata, "compaction_count": compaction_count}
                await self._backend.update_artifact(existing.id, content=combined, metadata=metadata)
            else:
                await self._backend.update_artifact(existing.id, content=combined)
        else:
            await self._backend.add_artifact(
                new_entry,
                kind="session:summary",
                namespace=self._session_id,
                metadata={"session_id": self._session_id, "compaction_count": compaction_count},
            )

    async def _condense_summary(self, existing: str, new_entry: str, compaction_count: int) -> str:
        if not self._llm_client:
            lines = (existing + "\n" + new_entry).split("\n")
            return "\n".join(lines[-20:])
        try:
            prompt = f"""Write a session summary that would let you resume this task if all prior context were lost.
Be concise (under 500 tokens). Structure it exactly as:

Session focus: <dominant files or topic>
Current task state: <what is being worked on RIGHT NOW — the active task, not what's done>
Key decisions: <architectural or implementation decisions made>
Recent changes: <files written/edited and what changed>
Open items: <remaining work, unresolved questions>
Prior compaction count: {compaction_count}

Current summary:
{existing}

New work this turn:
{new_entry}

Output only the structured summary, no preamble."""
            
            result = self._llm_client.invoke(
                messages=[{
                    "role": "user",
                    "content": prompt,
                }]
            )
            return result.get("content", existing + "\n" + new_entry)
        except Exception:
            lines = (existing + "\n" + new_entry).split("\n")
            return "\n".join(lines[-20:])
