"""C# using-directive resolver (namespace paths only; no relative resolution)."""

from pathlib import Path


def _flatten_name(node, source: bytes) -> str:
    """Flatten qualified_name or identifier into a dotted string."""
    if node.type == "identifier":
        return source[node.start_byte:node.end_byte].decode(errors="replace")
    if node.type == "qualified_name":
        parts = []
        for child in node.children:
            if child.type in ("identifier", "qualified_name"):
                parts.append(_flatten_name(child, source))
        return ".".join(parts)
    return ""


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []
    for node in tree.root_node.children:
        if node.type == "using_directive":
            for child in node.children:
                if child.type in ("qualified_name", "identifier"):
                    name = _flatten_name(child, source)
                    if name:
                        results.append({
                            "importee": name,
                            "import_type": "external",
                            "import_names": None,
                        })
                    break
    return results
