"""Haxe import resolver (package paths only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "import_statement":
            parts = []
            for child in node.children:
                if child.type in ("package_name", "type_name"):
                    parts.append(source[child.start_byte:child.end_byte].decode(errors="replace"))
            if parts:
                results.append({
                    "importee": ".".join(parts),
                    "import_type": "external",
                    "import_names": None,
                })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
