"""Swift import resolver (module names only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    for node in tree.root_node.children:
        if node.type == "import_declaration":
            for child in node.children:
                if child.type == "identifier":
                    parts = [
                        source[c.start_byte:c.end_byte].decode(errors="replace")
                        for c in child.children
                        if c.type == "simple_identifier"
                    ]
                    if parts:
                        results.append({
                            "importee": ".".join(parts),
                            "import_type": "external",  # module names; no file resolution
                            "import_names": None,
                        })

    return results
