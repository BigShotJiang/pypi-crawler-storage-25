"""Ruby require/require_relative resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type == "call":
            callee = node.children[0] if node.children else None
            if callee and callee.type == "identifier":
                fn_name = source[callee.start_byte:callee.end_byte].decode()
                if fn_name in ("require", "require_relative", "load"):
                    for child in node.children:
                        if child.type == "argument_list":
                            for arg in child.children:
                                if arg.type == "string":
                                    spec = extract_string_content(arg, source)
                                    if spec:
                                        is_relative = (
                                            fn_name == "require_relative"
                                            or spec.startswith("./")
                                            or spec.startswith("../")
                                        )
                                        resolved = (
                                            resolve_relative(spec, importer_dir, workspace_root, [".rb"])
                                            if is_relative else None
                                        )
                                        results.append({
                                            "importee": resolved or spec,
                                            "import_type": "internal" if resolved else "external",
                                            "import_names": None,
                                        })
                                    break
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
