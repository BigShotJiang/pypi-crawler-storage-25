"""Python import resolver."""

import json
from pathlib import Path
from typing import Optional


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []
    importer_dir = Path(rel_path).parent

    def _resolve(module_parts: list[str], relative_dots: int = 0) -> Optional[str]:
        if relative_dots > 0:
            base = importer_dir
            for _ in range(relative_dots):
                base = base.parent
            if module_parts:
                candidate = workspace_root / base / Path(*module_parts).with_suffix(".py")
                if candidate.exists():
                    return str((base / Path(*module_parts).with_suffix(".py")))
                pkg = workspace_root / base / Path(*module_parts) / "__init__.py"
                if pkg.exists():
                    return str((base / Path(*module_parts) / "__init__.py"))
            return None
        else:
            candidate = workspace_root / Path(*module_parts).with_suffix(".py")
            if candidate.exists():
                return str(candidate.relative_to(workspace_root))
            pkg = workspace_root / Path(*module_parts) / "__init__.py"
            if pkg.exists():
                return str(pkg.relative_to(workspace_root))
            return None

    def _walk(node) -> None:
        if node.type == "import_statement":
            for child in node.named_children:
                if child.type in ("dotted_name", "aliased_import"):
                    name_node = child.child_by_field_name("name") or child
                    parts = name_node.text.decode().split(".")
                    resolved = _resolve(parts)
                    results.append({
                        "importee": resolved or ".".join(parts),
                        "import_type": "internal" if resolved else "external",
                        "import_names": None,
                    })

        elif node.type == "import_from_statement":
            dots = 0
            module_parts: list[str] = []
            names: list[str] = []
            seen_import_kw = False
            for child in node.children:
                if child.type == "import":
                    seen_import_kw = True
                elif child.type == "relative_import":
                    dots = child.text.decode().count(".")
                    for rc in child.children:
                        if rc.type == "dotted_name":
                            module_parts = rc.text.decode().split(".")
                elif child.type == "dotted_name":
                    if not seen_import_kw:
                        module_parts = child.text.decode().split(".")
                    else:
                        names.append(child.text.decode())
                elif child.type == "import_prefix":
                    dots = child.text.decode().count(".")
                elif child.type in ("import_list", "wildcard_import"):
                    for n in child.named_children:
                        if n.type in ("dotted_name", "identifier"):
                            names.append(n.text.decode())

            if module_parts or dots:
                resolved = _resolve(module_parts, dots)
                results.append({
                    "importee": resolved or ".".join(module_parts),
                    "import_type": "internal" if resolved else "external",
                    "import_names": json.dumps(names) if names else None,
                })

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
