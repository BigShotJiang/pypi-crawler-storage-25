"""PureScript import resolver (module names only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "import":
            for child in node.children:
                if child.type == "qualified_module":
                    parts = [
                        source[m.start_byte:m.end_byte].decode(errors="replace")
                        for m in child.children
                        if m.type == "module"
                    ]
                    if parts:
                        results.append({
                            "importee": ".".join(parts),
                            "import_type": "external",
                            "import_names": None,
                        })
                    break
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
