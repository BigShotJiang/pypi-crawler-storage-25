"""Gleam import resolver (module paths only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    for node in tree.root_node.children:
        if node.type == "import":
            for child in node.children:
                if child.type == "module":
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                    break

    return results
