"""PHP require/include and use-statement resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative

_REQUIRE_TYPES = {"require_expression", "require_once_expression", "include_expression", "include_once_expression"}


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type in _REQUIRE_TYPES:
            for child in node.children:
                if child.type == "string":
                    spec = extract_string_content(child, source)
                    if spec:
                        if spec.startswith("./") or spec.startswith("../"):
                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".php"])
                        else:
                            resolved = None
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })

        elif node.type == "namespace_use_declaration":
            # use App\Models\User  or  use App\Http\{A, B}
            prefix_parts: list[str] = []
            for child in node.children:
                if child.type == "namespace_use_clause":
                    clause_parts = _qualified_name_parts(child)
                    if clause_parts:
                        results.append({
                            "importee": "\\".join(prefix_parts + clause_parts),
                            "import_type": "external",
                            "import_names": None,
                        })
                elif child.type == "namespace_use_group":
                    for gc in child.children:
                        if gc.type == "namespace_use_clause":
                            clause_parts = _qualified_name_parts(gc)
                            if clause_parts:
                                results.append({
                                    "importee": "\\".join(prefix_parts + clause_parts),
                                    "import_type": "external",
                                    "import_names": None,
                                })
                elif child.type == "qualified_name":
                    prefix_parts = _qualified_name_parts(child)

        for child in node.children:
            _walk(child)

    def _qualified_name_parts(node) -> list[str]:
        parts: list[str] = []

        def _collect(n) -> None:
            if n.type == "name":
                parts.append(source[n.start_byte:n.end_byte].decode(errors="replace"))
            elif n.type in ("qualified_name", "namespace_name", "namespace_use_clause"):
                for child in n.children:
                    _collect(child)

        _collect(node)
        return parts

    _walk(tree.root_node)
    return results
