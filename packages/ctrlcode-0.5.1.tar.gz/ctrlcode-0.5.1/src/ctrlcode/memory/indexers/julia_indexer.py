"""Julia import/using/include resolver."""

from pathlib import Path

from .common import resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type in ("import_statement", "using_statement"):
            # import Pkg / using LinearAlgebra — extract first identifier
            for child in node.children:
                if child.type == "identifier":
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                    break
                elif child.type == "selected_import":
                    for sc in child.children:
                        if sc.type == "identifier":
                            name = source[sc.start_byte:sc.end_byte].decode(errors="replace")
                            results.append({
                                "importee": name,
                                "import_type": "external",
                                "import_names": None,
                            })
                            break
                    break

        elif node.type == "call_expression":
            # include("utils.jl")
            callee = node.children[0] if node.children else None
            if callee and source[callee.start_byte:callee.end_byte].decode() == "include":
                for child in node.children:
                    if child.type == "argument_list":
                        for arg in child.children:
                            if arg.type == "string_literal":
                                content = None
                                for sc in arg.children:
                                    if sc.type == "content":
                                        content = source[sc.start_byte:sc.end_byte].decode(errors="replace")
                                        break
                                if content:
                                    resolved = resolve_relative(content, importer_dir, workspace_root, [".jl"])
                                    results.append({
                                        "importee": resolved or content,
                                        "import_type": "internal" if resolved else "external",
                                        "import_names": None,
                                    })
                        break

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
