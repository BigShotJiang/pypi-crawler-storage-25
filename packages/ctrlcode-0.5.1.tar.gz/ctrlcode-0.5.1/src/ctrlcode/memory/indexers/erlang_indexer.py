"""Erlang -include / -import resolver."""

from pathlib import Path
from typing import Optional

from .common import resolve_relative


def _string_content(node, source: bytes) -> Optional[str]:
    raw = source[node.start_byte:node.end_byte].decode(errors="replace").strip()
    if len(raw) >= 2 and raw[0] == '"' and raw[-1] == '"':
        return raw[1:-1]
    return None


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    for node in tree.root_node.children:
        if node.type == "pp_include":
            # -include("header.hrl") — relative to importer
            for child in node.children:
                if child.type == "string":
                    spec = _string_content(child, source)
                    if spec:
                        resolved = resolve_relative(spec, importer_dir, workspace_root, [".hrl", ".erl"])
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
                    break

        elif node.type == "pp_include_lib":
            # -include_lib("stdlib/include/lists.hrl") — library path, always external
            for child in node.children:
                if child.type == "string":
                    spec = _string_content(child, source)
                    if spec:
                        results.append({
                            "importee": spec,
                            "import_type": "external",
                            "import_names": None,
                        })
                    break

        elif node.type == "import_attribute":
            # -import(module, [fun/arity]) — module name, external
            for child in node.children:
                if child.type == "atom":
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                    break

    return results
