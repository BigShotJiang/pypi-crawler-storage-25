"""Solidity import resolver (relative paths resolved; package paths external)."""

from pathlib import Path

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    for node in tree.root_node.children:
        if node.type == "import_directive":
            for child in node.children:
                if child.type == "string":
                    spec = extract_string_content(child, source)
                    if spec:
                        if spec.startswith("./") or spec.startswith("../"):
                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".sol"])
                        else:
                            resolved = None
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
                    break

    return results
