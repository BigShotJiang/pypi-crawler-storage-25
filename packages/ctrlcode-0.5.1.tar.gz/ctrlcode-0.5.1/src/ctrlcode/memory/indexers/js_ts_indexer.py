"""JavaScript / TypeScript import resolver."""

from pathlib import Path
from typing import Optional


_EXTENSIONS = [".js", ".jsx", ".ts", ".tsx", "/index.js", "/index.jsx", "/index.ts", "/index.tsx"]


def _resolve(spec: str, importer_dir: Path, workspace_root: Path) -> Optional[str]:
    if not (spec.startswith("./") or spec.startswith("../")):
        return None
    base = (importer_dir / spec).resolve()
    root = workspace_root.resolve()
    if base.exists():
        try:
            return str(base.relative_to(root))
        except ValueError:
            return None
    base_str = str(base)
    for suffix in _EXTENSIONS:
        candidate = Path(base_str + suffix)
        if candidate.exists():
            try:
                return str(candidate.relative_to(root))
            except ValueError:
                pass
    return None


def _string_fragment(node, source: bytes) -> Optional[str]:
    for child in node.children:
        if child.type == "string_fragment":
            return source[child.start_byte:child.end_byte].decode(errors="replace")
    return None


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type == "import_statement":
            for child in reversed(node.children):
                if child.type == "string":
                    spec = _string_fragment(child, source)
                    if spec:
                        resolved = _resolve(spec, importer_dir, workspace_root)
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
                    break

        elif node.type == "call_expression":
            callee = node.child_by_field_name("function") or (node.children[0] if node.children else None)
            if callee and source[callee.start_byte:callee.end_byte].decode() == "require":
                args = node.child_by_field_name("arguments")
                if args:
                    for child in args.children:
                        if child.type == "string":
                            spec = _string_fragment(child, source)
                            if spec:
                                resolved = _resolve(spec, importer_dir, workspace_root)
                                results.append({
                                    "importee": resolved or spec,
                                    "import_type": "internal" if resolved else "external",
                                    "import_names": None,
                                })
                            break

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
