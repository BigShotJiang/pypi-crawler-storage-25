"""R library()/source() resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative

_SOURCE_FNS = {"source", "sys.source"}
_LIBRARY_FNS = {"library", "require"}


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type == "call":
            callee = None
            for child in node.children:
                if child.type == "identifier":
                    callee = source[child.start_byte:child.end_byte].decode(errors="replace")
                    break

            if callee in _SOURCE_FNS:
                # source("file.R") — first string argument is the path
                for child in node.children:
                    if child.type == "arguments":
                        for arg in child.children:
                            if arg.type == "argument":
                                for sc in arg.children:
                                    if sc.type == "string":
                                        spec = extract_string_content(sc, source)
                                        if spec:
                                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".R", ".r"])
                                            results.append({
                                                "importee": resolved or spec,
                                                "import_type": "internal" if resolved else "external",
                                                "import_names": None,
                                            })
                                        break
                                break  # process only first argument
                        break

            elif callee in _LIBRARY_FNS:
                # library(pkg) — first argument is a bare name or string
                for child in node.children:
                    if child.type == "arguments":
                        for arg in child.children:
                            if arg.type == "argument":
                                for sc in arg.children:
                                    if sc.type == "identifier":
                                        name = source[sc.start_byte:sc.end_byte].decode(errors="replace")
                                        results.append({
                                            "importee": name,
                                            "import_type": "external",
                                            "import_names": None,
                                        })
                                    elif sc.type == "string":
                                        pkg = extract_string_content(sc, source)
                                        if pkg:
                                            results.append({
                                                "importee": pkg,
                                                "import_type": "external",
                                                "import_names": None,
                                            })
                                break  # process only first argument
                        break

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
