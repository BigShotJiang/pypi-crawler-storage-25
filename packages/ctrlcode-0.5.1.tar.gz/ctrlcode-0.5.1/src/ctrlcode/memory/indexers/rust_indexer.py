"""Rust import resolver."""

from pathlib import Path
from typing import Optional


def _flatten(node, source: bytes) -> list[str]:
    parts: list[str] = []
    if node.type in ("scoped_identifier", "scoped_use_list", "use_tree"):
        for child in node.children:
            if child.type not in ("::", "{", "}", ","):
                parts.extend(_flatten(child, source))
    elif node.type in ("identifier", "crate", "super", "self"):
        parts.append(source[node.start_byte:node.end_byte].decode(errors="replace"))
    return parts


def _resolve(parts: list[str], importer_dir: Path, workspace_root: Path) -> Optional[str]:
    if not parts:
        return None
    anchor, tail = parts[0], parts[1:]
    if anchor == "crate":
        base = workspace_root / "src"
    elif anchor == "super":
        base = importer_dir.parent
    elif anchor == "self":
        base = importer_dir
    else:
        return None

    if not tail:
        return None

    def _try(segs: list[str]) -> Optional[str]:
        if not segs:
            return None
        candidate = base.joinpath(*segs[:-1]) / f"{segs[-1]}.rs"
        if candidate.exists():
            try:
                return str(candidate.relative_to(workspace_root))
            except ValueError:
                pass
        candidate = base.joinpath(*segs) / "mod.rs"
        if candidate.exists():
            try:
                return str(candidate.relative_to(workspace_root))
            except ValueError:
                pass
        return None

    return _try(tail) or _try(tail[:-1])


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    for node in tree.root_node.children:
        if node.type == "use_declaration":
            for child in node.named_children:
                if child.type in ("scoped_identifier", "scoped_use_list", "identifier", "crate", "use_tree"):
                    parts = _flatten(child, source)
                    resolved = _resolve(parts, importer_dir, workspace_root)
                    results.append({
                        "importee": resolved or "::".join(parts),
                        "import_type": "internal" if resolved else "external",
                        "import_names": None,
                    })
                    break

        elif node.type == "mod_item":
            has_body = any(c.type == "declaration_list" for c in node.children)
            if not has_body:
                for child in node.named_children:
                    if child.type == "identifier":
                        mod_name = source[child.start_byte:child.end_byte].decode()
                        for candidate in [
                            importer_dir / f"{mod_name}.rs",
                            importer_dir / mod_name / "mod.rs",
                        ]:
                            if candidate.exists():
                                try:
                                    results.append({
                                        "importee": str(candidate.relative_to(workspace_root)),
                                        "import_type": "internal",
                                        "import_names": None,
                                    })
                                except ValueError:
                                    pass
                                break
                        break

    return results
