"""Scheme import/include resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type == "list":
            children = [c for c in node.children if c.type not in ("(", ")")]
            if not children or children[0].type != "symbol":
                for child in node.children:
                    _walk(child)
                return

            sym = source[children[0].start_byte:children[0].end_byte].decode()

            if sym == "import":
                # (import (scheme list) (mylib utils)) — library specs, all external
                for arg in children[1:]:
                    if arg.type == "list":
                        segs = [
                            source[c.start_byte:c.end_byte].decode(errors="replace")
                            for c in arg.children
                            if c.type == "symbol"
                        ]
                        if segs:
                            results.append({
                                "importee": " ".join(segs),
                                "import_type": "external",
                                "import_names": None,
                            })

            elif sym == "include":
                # (include "utils.scm") — relative file
                for arg in children[1:]:
                    if arg.type == "string":
                        spec = extract_string_content(arg, source)
                        if spec:
                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".scm", ".ss"])
                            results.append({
                                "importee": resolved or spec,
                                "import_type": "internal" if resolved else "external",
                                "import_names": None,
                            })

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
