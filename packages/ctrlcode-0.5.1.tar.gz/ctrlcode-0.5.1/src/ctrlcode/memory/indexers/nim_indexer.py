"""Nim import/include resolver."""

from pathlib import Path

from .common import resolve_relative


def _get_module_specs(expression_list_node, source: bytes) -> list[tuple[str, bool]]:
    """Return (spec, is_relative) pairs from an expression_list node."""
    specs = []
    for child in expression_list_node.children:
        if child.type == "identifier":
            name = source[child.start_byte:child.end_byte].decode(errors="replace")
            specs.append((name, False))
        elif child.type == "prefix_expression":
            # ./mymodule — operator is "./" and identifier is the name
            op = ""
            name = ""
            for pc in child.children:
                if pc.type == "operator":
                    op = source[pc.start_byte:pc.end_byte].decode(errors="replace")
                elif pc.type == "identifier":
                    name = source[pc.start_byte:pc.end_byte].decode(errors="replace")
            if name:
                specs.append((op + name, True))
    return specs


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    for node in tree.root_node.children:
        if node.type == "import_statement":
            for child in node.children:
                if child.type == "expression_list":
                    for spec, is_relative in _get_module_specs(child, source):
                        if is_relative:
                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".nim"])
                        else:
                            resolved = None
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })

        elif node.type in ("import_from_statement", "include_statement"):
            # from module import x  /  include module — always external (no path)
            for child in node.children:
                if child.type == "expression_list":
                    for spec, _ in _get_module_specs(child, source):
                        results.append({
                            "importee": spec,
                            "import_type": "external",
                            "import_names": None,
                        })
                    break

    return results
