"""Perl use/require resolver."""

from pathlib import Path

from .common import resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _walk(node) -> None:
        if node.type == "use_statement":
            for child in node.children:
                if child.type == "package":
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                    break

        elif node.type == "require_expression":
            for child in node.children:
                if child.type == "interpolated_string_literal":
                    # require "utils.pl" — may be relative
                    content = None
                    for sc in child.children:
                        if sc.type == "string_content":
                            content = source[sc.start_byte:sc.end_byte].decode(errors="replace")
                            break
                    if content:
                        if content.startswith("./") or content.startswith("../") or content.endswith((".pl", ".pm")):
                            resolved = resolve_relative(content, importer_dir, workspace_root, [".pl", ".pm"])
                        else:
                            resolved = None
                        results.append({
                            "importee": resolved or content,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
                elif child.type == "bareword":
                    # require Foo::Baz — external module
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
