"""Scala import resolver (fully-qualified package paths; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    for node in tree.root_node.children:
        if node.type == "import_declaration":
            # Collect dot-separated identifier segments until we hit selectors or wildcard
            prefix_parts: list[str] = []
            names: list[str] = []
            for child in node.children:
                if child.type == "identifier":
                    prefix_parts.append(source[child.start_byte:child.end_byte].decode(errors="replace"))
                elif child.type == "namespace_selectors":
                    for sel in child.children:
                        if sel.type == "identifier":
                            names.append(source[sel.start_byte:sel.end_byte].decode(errors="replace"))
                # namespace_wildcard (_) and dots are skipped

            if prefix_parts:
                importee = ".".join(prefix_parts)
                results.append({
                    "importee": importee,
                    "import_type": "external",  # package paths; no file resolution
                    "import_names": None,
                })

    return results
