"""Lua require() resolver."""

from pathlib import Path
from typing import Optional

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _find_require_string(node) -> Optional[str]:
        if node.type in ("function_call", "call"):
            callee = None
            for child in node.children:
                if child.type == "identifier":
                    callee = source[child.start_byte:child.end_byte].decode()
                elif child.type in ("arguments", "argument_list"):
                    if callee == "require":
                        for arg in child.children:
                            if arg.type == "string":
                                return extract_string_content(arg, source)
        return None

    def _walk(node) -> None:
        spec = _find_require_string(node)
        if spec:
            if spec.startswith("./") or spec.startswith("../"):
                resolved = resolve_relative(spec, importer_dir, workspace_root, [".lua"])
            else:
                # Dotted module path: foo.bar.baz → foo/bar/baz.lua or foo/bar/baz/init.lua
                parts = spec.replace(".", "/")
                resolved = None
                for suffix in [".lua", "/init.lua"]:
                    candidate = (
                        workspace_root / (parts + suffix.lstrip("/"))
                        if suffix.startswith("/")
                        else workspace_root / (parts + suffix)
                    )
                    if candidate.exists():
                        try:
                            resolved = str(candidate.relative_to(workspace_root))
                        except ValueError:
                            pass
                        break
            results.append({
                "importee": resolved or spec,
                "import_type": "internal" if resolved else "external",
                "import_names": None,
            })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
