"""GDScript preload()/load() resolver.

res:// paths are Godot project-root-relative; we strip the prefix and
resolve against workspace_root (assumed to be the project root).
"""

from pathlib import Path

from .common import extract_string_content

_LOAD_FNS = {"preload", "load"}


def _strip_res(spec: str) -> str:
    if spec.startswith("res://"):
        return spec[len("res://"):]
    if spec.startswith("user://"):
        return spec[len("user://"):]
    return spec


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "call":
            callee = None
            for child in node.children:
                if child.type == "identifier":
                    callee = source[child.start_byte:child.end_byte].decode(errors="replace")
                    break
            if callee in _LOAD_FNS:
                for child in node.children:
                    if child.type == "arguments":
                        for arg in child.children:
                            if arg.type == "string":
                                spec = extract_string_content(arg, source)
                                if spec:
                                    rel = _strip_res(spec)
                                    candidate = workspace_root / rel
                                    if candidate.exists():
                                        try:
                                            resolved = str(candidate.relative_to(workspace_root))
                                        except ValueError:
                                            resolved = None
                                    else:
                                        resolved = None
                                    results.append({
                                        "importee": resolved or spec,
                                        "import_type": "internal" if resolved else "external",
                                        "import_names": None,
                                    })
                        break

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
