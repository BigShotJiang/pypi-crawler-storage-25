"""C / C++ include resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []
    for node in tree.root_node.children:
        if node.type == "preproc_include":
            for child in node.children:
                if child.type == "string_literal":
                    spec = extract_string_content(child, source)
                    if spec:
                        resolved = resolve_relative(spec, importer_dir, workspace_root, [])
                        results.append({
                            "importee": resolved or spec,
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
                elif child.type == "system_lib_string":
                    raw = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({"importee": raw, "import_type": "external", "import_names": None})
    return results
