"""Elixir import/alias/use/require resolver (module names only)."""

from pathlib import Path

_IMPORT_FNS = {"import", "alias", "use", "require"}


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "call":
            callee = None
            for child in node.children:
                if child.type == "identifier":
                    callee = source[child.start_byte:child.end_byte].decode(errors="replace")
                    break
            if callee in _IMPORT_FNS:
                for child in node.children:
                    if child.type == "arguments":
                        for arg in child.children:
                            if arg.type == "alias":
                                name = source[arg.start_byte:arg.end_byte].decode(errors="replace")
                                results.append({
                                    "importee": name,
                                    "import_type": "external",
                                    "import_names": None,
                                })
                        break
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
