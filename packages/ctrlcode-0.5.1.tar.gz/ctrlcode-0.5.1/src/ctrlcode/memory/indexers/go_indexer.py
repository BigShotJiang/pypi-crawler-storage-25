"""Go import resolver (relative paths only; module-path imports are external)."""

from pathlib import Path
from typing import Optional

from .common import extract_string_content


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _get_spec(node) -> Optional[str]:
        for child in node.children:
            if child.type == "interpreted_string_literal":
                return extract_string_content(child, source)
        return None

    def _add(spec: str) -> None:
        if spec.startswith("./") or spec.startswith("../"):
            pkg_dir = (importer_dir / spec).resolve()
            resolved = None
            try:
                rel_dir = pkg_dir.relative_to(workspace_root.resolve())
                if pkg_dir.is_dir():
                    for go_file in pkg_dir.glob("*.go"):
                        resolved = str(go_file.relative_to(workspace_root))
                        break
                    if not resolved:
                        resolved = str(rel_dir)
            except ValueError:
                pass
            results.append({
                "importee": resolved or spec,
                "import_type": "internal" if resolved else "external",
                "import_names": None,
            })
        else:
            results.append({"importee": spec, "import_type": "external", "import_names": None})

    def _walk(node) -> None:
        if node.type == "import_declaration":
            for child in node.children:
                if child.type == "import_spec":
                    spec = _get_spec(child)
                    if spec:
                        _add(spec)
                elif child.type == "import_spec_list":
                    for spec_node in child.children:
                        if spec_node.type == "import_spec":
                            spec = _get_spec(spec_node)
                            if spec:
                                _add(spec)
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
