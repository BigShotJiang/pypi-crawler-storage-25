"""Shared utilities for language-specific import indexers."""

from pathlib import Path
from typing import Optional


_EXT_TO_LANG: dict[str, str] = {
    # Python
    ".py": "python",
    # JavaScript / TypeScript
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    # Rust
    ".rs": "rust",
    # Go
    ".go": "go",
    # Ruby
    ".rb": "ruby",
    # JVM
    ".java": "java",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".groovy": "groovy",
    ".scala": "scala",
    # C / C++
    ".c": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".h": "c",
    ".hpp": "cpp",
    # Objective-C (same preproc_include AST as C)
    ".m": "objc",
    ".mm": "objc",
    # C#
    ".cs": "csharp",
    # Scripting
    ".lua": "lua",
    ".pl": "perl",
    ".pm": "perl",
    ".php": "php",
    # Systems
    ".dart": "dart",
    ".zig": "zig",
    ".d": "d",
    ".v": "v",
    ".nim": "nim",
    ".odin": "odin",
    # Functional
    ".hs": "haskell",
    ".ml": "ocaml",
    ".mli": "ocaml",
    ".fs": "fsharp",
    ".fsi": "fsharp",
    ".fsx": "fsharp",
    ".ex": "elixir",
    ".exs": "elixir",
    ".erl": "erlang",
    ".hrl": "erlang",
    ".clj": "clojure",
    ".cljs": "clojure",
    ".cljc": "clojure",
    ".elm": "elm",
    ".purs": "purescript",
    ".gleam": "gleam",
    # Lisp family
    ".rkt": "racket",
    ".scm": "scheme",
    ".ss": "scheme",
    # Scientific / other
    ".jl": "julia",
    ".r": "r",
    ".hx": "haxe",
    ".swift": "swift",
    ".pony": "pony",
    # Game / blockchain
    ".gd": "gdscript",
    ".sol": "solidity",
}


# Map languages to their definition node types and the field containing the name
DEFINITION_NODES: dict[str, dict[str, str]] = {
    "python": {
        "function_definition": "name",
        "class_definition": "name",
        "decorated_definition": "definition",
    },
    "javascript": {
        "function_declaration": "name",
        "method_definition": "name",
        "class_declaration": "name",
        "function_expression": "name",
        "arrow_function": "name",
    },
    "typescript": {
        "function_declaration": "name",
        "method_definition": "name",
        "class_declaration": "name",
        "interface_declaration": "name",
        "type_alias_declaration": "name",
        "function_expression": "name",
        "arrow_function": "name",
    },
    "tsx": {
        "function_declaration": "name",
        "method_definition": "name",
        "class_declaration": "name",
        "interface_declaration": "name",
        "type_alias_declaration": "name",
        "function_expression": "name",
        "arrow_function": "name",
    },
    "rust": {
        "function_item": "name",
        "struct_item": "name",
        "trait_item": "name",
        "impl_item": "type",
        "enum_item": "name",
        "mod_item": "name",
    },
    "go": {
        "function_declaration": "name",
        "method_declaration": "name",
        "type_declaration": "name",
        "struct_type": "name",
        "interface_type": "name",
    },
    "java": {
        "method_declaration": "name",
        "class_declaration": "name",
        "interface_declaration": "name",
        "constructor_declaration": "name",
        "enum_declaration": "name",
    },
    "kotlin": {
        "function_declaration": "simple_identifier",
        "class_declaration": "simple_identifier",
        "object_declaration": "simple_identifier",
        "interface_declaration": "simple_identifier",
    },
    "c": {
        "function_definition": "declarator",
        "struct_specifier": "type_identifier",
        "enum_specifier": "type_identifier",
        "union_specifier": "type_identifier",
    },
    "cpp": {
        "function_definition": "declarator",
        "class_specifier": "type_identifier",
        "struct_specifier": "type_identifier",
        "namespace_definition": "name",
        "template_declaration": "name",
    },
    "csharp": {
        "method_declaration": "identifier",
        "class_declaration": "identifier",
        "interface_declaration": "identifier",
        "struct_declaration": "identifier",
        "enum_declaration": "identifier",
    },
    "ruby": {
        "method": "name",
        "class": "constant",
        "module": "constant",
        "singleton_method": "name",
    },
    "php": {
        "function_definition": "name",
        "method_declaration": "name",
        "class_declaration": "name",
        "interface_declaration": "name",
        "trait_declaration": "name",
    },
    "swift": {
        "function_declaration": "simple_identifier",
        "class_declaration": "type_identifier",
        "struct_declaration": "type_identifier",
        "protocol_declaration": "type_identifier",
        "enum_declaration": "type_identifier",
    },
}


def extract_string_content(node, source: bytes) -> Optional[str]:
    """Extract string content from a tree-sitter string node.

    Handles nodes with a dedicated content child (string_content,
    string_fragment, interpreted_string_literal_content) and falls back
    to stripping surrounding quotes from the raw source bytes.
    """
    CONTENT_TYPES = {
        "string_content", "string_fragment",
        "interpreted_string_literal_content",
    }
    for child in node.children:
        if child.type in CONTENT_TYPES:
            return source[child.start_byte:child.end_byte].decode(errors="replace")
    raw = source[node.start_byte:node.end_byte].decode(errors="replace").strip()
    if len(raw) >= 2 and raw[0] in ('"', "'", "`") and raw[-1] == raw[0]:
        return raw[1:-1]
    return None


def extract_definitions(tree, source: bytes, lang: str) -> list[str]:
    """Extract function/class/struct definitions from a tree-sitter parse tree.
    
    Returns a list of definition names found in the source code.
    Uses the DEFINITION_NODES mapping to identify relevant nodes for the language.
    """
    if lang not in DEFINITION_NODES:
        return []
    
    node_map = DEFINITION_NODES[lang]
    definitions = []
    
    def _walk(node) -> None:
        if node.type in node_map:
            name_field = node_map[node.type]
            
            # Handle special cases for different field types
            if name_field == "definition":
                # For decorated_definition, we need to get the underlying definition
                def_child = node.child_by_field_name("definition")
                if def_child and def_child.type in node_map:
                    inner_field = node_map[def_child.type]
                    name_node = def_child.child_by_field_name(inner_field)
                    if name_node:
                        definitions.append(source[name_node.start_byte:name_node.end_byte].decode(errors="replace"))
            elif name_field == "declarator":
                # For C/C++ function_definition, extract from declarator
                decl_node = node.child_by_field_name("declarator")
                if decl_node:
                    # Try function_declarator first, then identifier
                    func_decl = None
                    for child in decl_node.children:
                        if child.type == "function_declarator":
                            func_decl = child.child_by_field_name("declarator")
                            break
                    if func_decl:
                        definitions.append(source[func_decl.start_byte:func_decl.end_byte].decode(errors="replace"))
                    else:
                        # Fallback to identifier in declarator
                        for child in decl_node.children:
                            if child.type == "identifier":
                                definitions.append(source[child.start_byte:child.end_byte].decode(errors="replace"))
                                break
            else:
                # Standard case: get named field
                name_node = node.child_by_field_name(name_field)
                if name_node:
                    definitions.append(source[name_node.start_byte:name_node.end_byte].decode(errors="replace"))
        
        # Recursively walk children
        for child in node.children:
            _walk(child)
    
    _walk(tree.root_node)
    return list(dict.fromkeys(definitions))  # Remove duplicates while preserving order


def resolve_relative(
    spec: str,
    importer_dir: Path,
    workspace_root: Path,
    extensions: list[str],
) -> Optional[str]:
    """Resolve a relative import specifier to a workspace-relative path.

    Tries the spec as-is then appends each extension in order.
    Returns None if no file is found.
    """
    base = (importer_dir / spec).resolve()
    root = workspace_root.resolve()
    if base.exists():
        try:
            return str(base.relative_to(root))
        except ValueError:
            return None
    base_str = str(base)
    for ext in extensions:
        candidate = Path(base_str + ext)
        if candidate.exists():
            try:
                return str(candidate.relative_to(root))
            except ValueError:
                pass
    return None
