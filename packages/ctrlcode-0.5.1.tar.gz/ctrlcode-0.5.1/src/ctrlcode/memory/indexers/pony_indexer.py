"""Pony use-statement resolver (package strings only; no relative resolution)."""

from pathlib import Path

from .common import extract_string_content


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    for node in tree.root_node.children:
        if node.type == "use_statement":
            for child in node.children:
                if child.type == "string":
                    spec = extract_string_content(child, source)
                    if spec:
                        results.append({
                            "importee": spec,
                            "import_type": "external",
                            "import_names": None,
                        })
                    break

    return results
