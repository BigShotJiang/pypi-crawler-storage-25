"""Zig @import() resolver (relative paths only; std/package imports are external)."""

from pathlib import Path
from typing import Optional

from .common import resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _find_string_literal(node) -> Optional[str]:
        if node.type == "STRINGLITERALSINGLE":
            raw = source[node.start_byte:node.end_byte].decode(errors="replace")
            if len(raw) >= 2:
                return raw[1:-1]
        for child in node.children:
            result = _find_string_literal(child)
            if result is not None:
                return result
        return None

    def _walk(node) -> None:
        if node.type == "SuffixExpr":
            builtin_node = None
            args_node = None
            for child in node.children:
                if child.type == "BUILTINIDENTIFIER":
                    if source[child.start_byte:child.end_byte].decode() == "@import":
                        builtin_node = child
                elif child.type == "FnCallArguments":
                    args_node = child
            if builtin_node and args_node:
                spec = _find_string_literal(args_node)
                if spec:
                    if spec.startswith("./") or spec.startswith("../"):
                        resolved = resolve_relative(spec, importer_dir, workspace_root, [".zig"])
                    else:
                        resolved = None  # std or package name
                    results.append({
                        "importee": resolved or spec,
                        "import_type": "internal" if resolved else "external",
                        "import_names": None,
                    })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
