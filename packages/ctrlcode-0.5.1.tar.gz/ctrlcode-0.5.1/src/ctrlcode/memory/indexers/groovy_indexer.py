"""Groovy import resolver (package paths only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "command":
            units = [c for c in node.children if c.type == "unit"]
            if len(units) >= 2:
                # Check first unit is "import"
                first_text = source[units[0].start_byte:units[0].end_byte].decode(errors="replace").strip()
                if first_text == "import":
                    # Get module path from second unit (may contain identifiers and dots)
                    module = source[units[1].start_byte:units[1].end_byte].decode(errors="replace").strip()
                    if module:
                        results.append({
                            "importee": module,
                            "import_type": "external",
                            "import_names": None,
                        })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
