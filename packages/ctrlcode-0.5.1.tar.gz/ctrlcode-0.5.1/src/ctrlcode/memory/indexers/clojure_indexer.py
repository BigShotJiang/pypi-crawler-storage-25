"""Clojure ns :require/:import resolver (namespace names only)."""

from pathlib import Path


def _sym_text(node, source: bytes) -> str:
    if node.type == "sym_lit":
        for child in node.children:
            if child.type == "sym_name":
                return source[child.start_byte:child.end_byte].decode(errors="replace")
    return source[node.start_byte:node.end_byte].decode(errors="replace")


def _kwd_name(node, source: bytes) -> str:
    for child in node.children:
        if child.type == "kwd_name":
            return source[child.start_byte:child.end_byte].decode(errors="replace")
    return ""


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _process_vec(vec_node) -> None:
        """First element of a vec_lit in :require is the namespace name."""
        for child in vec_node.children:
            if child.type == "sym_lit":
                name = _sym_text(child, source)
                if name:
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                return  # only first sym_lit is the module

    def _walk(node) -> None:
        if node.type == "list_lit":
            children = [c for c in node.children if c.type not in ("(", ")")]
            if not children:
                for child in node.children:
                    _walk(child)
                return

            first = children[0]

            # (ns ...) — look for :require and :import sub-lists
            if first.type == "sym_lit" and _sym_text(first, source) == "ns":
                for child in children[1:]:
                    if child.type == "list_lit":
                        sub = [c for c in child.children if c.type not in ("(", ")")]
                        if sub and sub[0].type == "kwd_lit":
                            kwd = _kwd_name(sub[0], source)
                            if kwd == "require":
                                for item in sub[1:]:
                                    if item.type == "vec_lit":
                                        _process_vec(item)
                            elif kwd == "import":
                                for item in sub[1:]:
                                    if item.type in ("list_lit", "vec_lit"):
                                        # (java.util Date) — first sym is the package
                                        for ic in item.children:
                                            if ic.type == "sym_lit":
                                                name = _sym_text(ic, source)
                                                if name:
                                                    results.append({
                                                        "importee": name,
                                                        "import_type": "external",
                                                        "import_names": None,
                                                    })
                                                break
                return  # don't recurse into ns form children again

        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
