"""Racket require resolver."""

from pathlib import Path

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _process_require_arg(node) -> None:
        """Process one argument of a (require ...) form."""
        if node.type == "symbol":
            # symbol like racket/list — external
            name = source[node.start_byte:node.end_byte].decode(errors="replace")
            results.append({"importee": name, "import_type": "external", "import_names": None})

        elif node.type == "string":
            # (require "mymodule.rkt") — relative file
            spec = extract_string_content(node, source)
            if spec:
                resolved = resolve_relative(spec, importer_dir, workspace_root, [".rkt", ".ss", ".scm"])
                results.append({
                    "importee": resolved or spec,
                    "import_type": "internal" if resolved else "external",
                    "import_names": None,
                })

        elif node.type == "list":
            # (file "path/to/file.rkt") or (lib ...) etc.
            children = [c for c in node.children if c.type not in ("(", ")")]
            if children and source[children[0].start_byte:children[0].end_byte].decode() == "file":
                for c in children[1:]:
                    if c.type == "string":
                        spec = extract_string_content(c, source)
                        if spec:
                            resolved = resolve_relative(spec, importer_dir, workspace_root, [".rkt"])
                            results.append({
                                "importee": resolved or spec,
                                "import_type": "internal" if resolved else "external",
                                "import_names": None,
                            })

    def _walk(node) -> None:
        if node.type == "list":
            children = [c for c in node.children if c.type not in ("(", ")")]
            if children and children[0].type == "symbol":
                sym = source[children[0].start_byte:children[0].end_byte].decode()
                if sym == "require":
                    for arg in children[1:]:
                        _process_require_arg(arg)
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
