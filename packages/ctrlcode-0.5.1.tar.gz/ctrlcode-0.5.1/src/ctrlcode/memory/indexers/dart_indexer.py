"""Dart import resolver (relative paths only; package:/dart: are external)."""

from pathlib import Path
from typing import Optional

from .common import extract_string_content, resolve_relative


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    importer_dir = (workspace_root / rel_path).parent
    results = []

    def _find_string(node) -> Optional[str]:
        if node.type == "string_literal":
            return extract_string_content(node, source)
        for child in node.children:
            result = _find_string(child)
            if result is not None:
                return result
        return None

    def _walk(node) -> None:
        if node.type == "import_specification":
            spec = _find_string(node)
            if spec:
                if spec.startswith("./") or spec.startswith("../"):
                    resolved = resolve_relative(spec, importer_dir, workspace_root, [".dart"])
                else:
                    resolved = None  # package: or dart: URI
                results.append({
                    "importee": resolved or spec,
                    "import_type": "internal" if resolved else "external",
                    "import_names": None,
                })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
