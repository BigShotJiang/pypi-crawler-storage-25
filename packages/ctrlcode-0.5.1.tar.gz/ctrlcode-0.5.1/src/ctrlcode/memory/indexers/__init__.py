"""Language-specific import indexers for the dependency graph."""

from .common import _EXT_TO_LANG, extract_string_content, resolve_relative
from .python_indexer import parse_imports as parse_python_imports
from .js_ts_indexer import parse_imports as parse_js_ts_imports
from .rust_indexer import parse_imports as parse_rust_imports
from .c_cpp_indexer import parse_imports as parse_c_cpp_imports
from .ruby_indexer import parse_imports as parse_ruby_imports
from .java_kotlin_indexer import parse_java_imports, parse_kotlin_imports
from .lua_indexer import parse_imports as parse_lua_imports
from .dart_indexer import parse_imports as parse_dart_imports
from .zig_indexer import parse_imports as parse_zig_imports
from .go_indexer import parse_imports as parse_go_imports
from .scala_indexer import parse_imports as parse_scala_imports
from .swift_indexer import parse_imports as parse_swift_imports
from .php_indexer import parse_imports as parse_php_imports
from .csharp_indexer import parse_imports as parse_csharp_imports
from .elixir_indexer import parse_imports as parse_elixir_imports
from .haskell_indexer import parse_imports as parse_haskell_imports
from .ocaml_indexer import parse_imports as parse_ocaml_imports
from .fsharp_indexer import parse_imports as parse_fsharp_imports
from .erlang_indexer import parse_imports as parse_erlang_imports
from .clojure_indexer import parse_imports as parse_clojure_imports
from .julia_indexer import parse_imports as parse_julia_imports
from .groovy_indexer import parse_imports as parse_groovy_imports
from .nim_indexer import parse_imports as parse_nim_imports
from .d_indexer import parse_imports as parse_d_imports
from .perl_indexer import parse_imports as parse_perl_imports
from .r_indexer import parse_imports as parse_r_imports
from .solidity_indexer import parse_imports as parse_solidity_imports
from .v_indexer import parse_imports as parse_v_imports
from .gleam_indexer import parse_imports as parse_gleam_imports
from .elm_indexer import parse_imports as parse_elm_imports
from .purescript_indexer import parse_imports as parse_purescript_imports
from .haxe_indexer import parse_imports as parse_haxe_imports
from .gdscript_indexer import parse_imports as parse_gdscript_imports
from .pony_indexer import parse_imports as parse_pony_imports
from .racket_indexer import parse_imports as parse_racket_imports
from .scheme_indexer import parse_imports as parse_scheme_imports
from .odin_indexer import parse_imports as parse_odin_imports

__all__ = [
    "_EXT_TO_LANG",
    "extract_string_content",
    "resolve_relative",
    "parse_python_imports",
    "parse_js_ts_imports",
    "parse_rust_imports",
    "parse_c_cpp_imports",
    "parse_ruby_imports",
    "parse_java_imports",
    "parse_kotlin_imports",
    "parse_lua_imports",
    "parse_dart_imports",
    "parse_zig_imports",
    "parse_go_imports",
    "parse_scala_imports",
    "parse_swift_imports",
    "parse_php_imports",
    "parse_csharp_imports",
    "parse_elixir_imports",
    "parse_haskell_imports",
    "parse_ocaml_imports",
    "parse_fsharp_imports",
    "parse_erlang_imports",
    "parse_clojure_imports",
    "parse_julia_imports",
    "parse_groovy_imports",
    "parse_nim_imports",
    "parse_d_imports",
    "parse_perl_imports",
    "parse_r_imports",
    "parse_solidity_imports",
    "parse_v_imports",
    "parse_gleam_imports",
    "parse_elm_imports",
    "parse_purescript_imports",
    "parse_haxe_imports",
    "parse_gdscript_imports",
    "parse_pony_imports",
    "parse_racket_imports",
    "parse_scheme_imports",
    "parse_odin_imports",
]
