"""Haskell import resolver (module names only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "import":
            for child in node.children:
                if child.type == "module":
                    name = source[child.start_byte:child.end_byte].decode(errors="replace")
                    results.append({
                        "importee": name,
                        "import_type": "external",
                        "import_names": None,
                    })
                    break  # first module node is the imported module; skip 'as' alias
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
