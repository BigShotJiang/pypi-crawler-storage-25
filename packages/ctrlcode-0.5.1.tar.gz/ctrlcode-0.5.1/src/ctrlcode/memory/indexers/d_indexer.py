"""D import resolver (module paths only; no relative resolution)."""

from pathlib import Path


def parse_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    for node in tree.root_node.children:
        if node.type == "import_declaration":
            for child in node.children:
                if child.type == "imported":
                    for fqn in child.children:
                        if fqn.type == "module_fqn":
                            name = source[fqn.start_byte:fqn.end_byte].decode(errors="replace")
                            results.append({
                                "importee": name,
                                "import_type": "external",
                                "import_names": None,
                            })

    return results
