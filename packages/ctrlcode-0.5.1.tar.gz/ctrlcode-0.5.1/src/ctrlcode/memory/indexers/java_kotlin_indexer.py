"""Java and Kotlin import resolver (package path → file path)."""

from pathlib import Path
from typing import Optional

_SRC_ROOTS = ["src/main/java", "src/main/kotlin", "src", ""]


def _flatten(node, source: bytes) -> list[str]:
    """Flatten a Java scoped_identifier or Kotlin identifier into name segments."""
    parts: list[str] = []
    if node.child_count == 0:
        text = source[node.start_byte:node.end_byte].decode(errors="replace")
        if text not in (".", "::", "import", ";", "*"):
            parts.append(text)
    elif node.type in ("scoped_identifier", "identifier"):
        for child in node.children:
            if child.type not in (".", "::"):
                parts.extend(_flatten(child, source))
    elif node.type == "simple_identifier":
        parts.append(source[node.start_byte:node.end_byte].decode(errors="replace"))
    return parts


def _resolve(parts: list[str], workspace_root: Path, extensions: list[str]) -> Optional[str]:
    if not parts:
        return None
    candidates = [parts]
    if parts[-1][0].isupper():
        candidates.append(parts[:-1])
    for segs in candidates:
        if not segs:
            continue
        rel = Path(*segs)
        for src_root in _SRC_ROOTS:
            base = workspace_root / src_root if src_root else workspace_root
            for ext in extensions:
                candidate = base / rel.with_suffix(ext)
                if candidate.exists():
                    try:
                        return str(candidate.relative_to(workspace_root))
                    except ValueError:
                        pass
    return None


def parse_java_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []
    for node in tree.root_node.children:
        if node.type == "import_declaration":
            for child in node.named_children:
                if child.type == "scoped_identifier":
                    parts = _flatten(child, source)
                    if parts:
                        resolved = _resolve(parts, workspace_root, [".java"])
                        results.append({
                            "importee": resolved or ".".join(parts),
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
    return results


def parse_kotlin_imports(tree, source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    results = []

    def _walk(node) -> None:
        if node.type == "import_header":
            for child in node.named_children:
                if child.type == "identifier":
                    parts = [
                        source[c.start_byte:c.end_byte].decode()
                        for c in child.children
                        if c.type == "simple_identifier"
                    ]
                    if parts:
                        resolved = _resolve(parts, workspace_root, [".kt", ".kts", ".java"])
                        results.append({
                            "importee": resolved or ".".join(parts),
                            "import_type": "internal" if resolved else "external",
                            "import_names": None,
                        })
        for child in node.children:
            _walk(child)

    _walk(tree.root_node)
    return results
