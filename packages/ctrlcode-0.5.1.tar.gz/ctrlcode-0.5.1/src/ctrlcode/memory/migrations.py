"""Versioned schema migration runner for rootset.db."""

import logging
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone

import aiosqlite

logger = logging.getLogger(__name__)

LATEST_VERSION: int = 2

_SCHEMA_VERSION_DDL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER NOT NULL,
    migrated_at TEXT    NOT NULL
);
"""


class SchemaMigrationError(RuntimeError):
    pass


async def get_schema_version(db: aiosqlite.Connection) -> int:
    """Return the current schema version, or 0 if schema_version table is absent or empty."""
    try:
        async with db.execute("SELECT version FROM schema_version LIMIT 1") as cur:
            row = await cur.fetchone()
        return int(row[0]) if row else 0
    except Exception:
        return 0


async def _set_schema_version(db: aiosqlite.Connection, version: int) -> None:
    now = datetime.now(timezone.utc).isoformat()
    existing = await get_schema_version(db)
    if existing == 0:
        await db.execute(
            "INSERT INTO schema_version (version, migrated_at) VALUES (?, ?)",
            (version, now),
        )
    else:
        await db.execute(
            "UPDATE schema_version SET version = ?, migrated_at = ?",
            (version, now),
        )


async def _baseline_v1(db: aiosqlite.Connection) -> None:
    """Record baseline version. Silently apply the two legacy ALTER TABLE columns."""
    await db.executescript(_SCHEMA_VERSION_DDL)
    for stmt in [
        "ALTER TABLE artifacts ADD COLUMN source_file_hash TEXT",
        "ALTER TABLE engagement_log ADD COLUMN retrieval_count INTEGER DEFAULT 1",
    ]:
        try:
            await db.execute(stmt)
        except Exception:
            pass  # column already exists — ok for baseline only


async def _migrate_v1_to_v2(db: aiosqlite.Connection) -> None:
    """Promote source_file from JSON metadata blob to a real indexed column.

    Changes:
    - Add source_file TEXT column to artifacts
    - Add idx_art_source_file index on artifacts(source_file)
    - Add idx_entity_type_session index on entity_index(entity_type, session_id)
    - Back-fill source_file from existing metadata JSON for pre-existing rows
    """
    await db.execute("ALTER TABLE artifacts ADD COLUMN source_file TEXT")
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_art_source_file ON artifacts(source_file)"
    )
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_entity_type_session "
        "ON entity_index(entity_type, session_id)"
    )
    await db.execute(
        "UPDATE artifacts SET source_file = json_extract(metadata, '$.source_file') "
        "WHERE source_file IS NULL AND json_extract(metadata, '$.source_file') IS NOT NULL"
    )


_MIGRATION_STEPS: dict[int, Callable[[aiosqlite.Connection], Awaitable[None]]] = {
    1: _baseline_v1,
    2: _migrate_v1_to_v2,
}


async def run_migrations(db: aiosqlite.Connection) -> None:
    """Detect current version, apply all pending migrations in order."""
    # Ensure schema_version table exists before querying it
    await db.executescript(_SCHEMA_VERSION_DDL)
    await db.commit()

    current = await get_schema_version(db)
    for version in range(current + 1, LATEST_VERSION + 1):
        fn = _MIGRATION_STEPS[version]
        await db.execute("BEGIN")
        try:
            await fn(db)
            await _set_schema_version(db, version)
            await db.commit()
            logger.info("Migrated schema to v%d", version)
        except Exception as exc:
            await db.rollback()
            raise SchemaMigrationError(
                f"Migration to v{version} failed: {exc}"
            ) from exc
