"""RootsetMemoryBackend — SemanticMemoryBackend adapter over ArtifactStore."""

from typing import Any, Optional

from .store import Artifact, ArtifactResult, ArtifactStore


class RootsetMemoryBackend:
    """Satisfies harnessutils.SemanticMemoryBackend protocol using the local ArtifactStore."""

    def __init__(self, store: ArtifactStore) -> None:
        self._store = store

    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: dict[str, Any] | None = None,
    ) -> Artifact:
        return await self._store.add_artifact(
            content, kind, namespace=namespace, metadata=metadata
        )

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: str | None = None,
        namespace: str | None = None,
    ) -> list[ArtifactResult]:
        return await self._store.search_artifacts(
            query, top_k=top_k, kind=kind, namespace=namespace,
        )

    async def get_artifact(self, artifact_id: int) -> Artifact | None:
        return await self._store.get_artifact(artifact_id)

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: dict[str, Any] | None = None,
        content: str | None = None,
    ) -> Optional[Artifact]:
        return await self._store.update_artifact(
            artifact_id, metadata=metadata, content=content
        )

    async def delete_artifact(self, artifact_id: int) -> None:
        await self._store.delete_artifact(artifact_id)

    async def log_engagement(
        self, cluster_key: str, session_id: str, tokens: int, turn_id: str
    ) -> None:
        await self._store.log_engagement(cluster_key, session_id, tokens, turn_id)

    async def get_engagement_sum(self, cluster_key: str, session_id: str) -> float:
        return await self._store.get_engagement_sum(cluster_key, session_id)

    async def get_engagement_stats(self, cluster_key: str, session_id: str) -> tuple[int, int]:
        return await self._store.get_engagement_stats(cluster_key, session_id)

    async def index_entities(
        self,
        artifact_id: int,
        entity_pairs: list[tuple[str, str]],
        session_id: str,
    ) -> None:
        await self._store.index_entities(artifact_id, entity_pairs, session_id)

    async def lookup_by_entities(
        self,
        entities: list[str],
        session_id: str,
        top_k: int = 20,
    ) -> list[ArtifactResult]:
        return await self._store.lookup_by_entities(entities, session_id, top_k=top_k)

    async def structural_lookup(
        self,
        paths: set[str],
        session_id: str,
        top_k: int = 20,
    ) -> list[ArtifactResult]:
        return await self._store.structural_lookup(paths, session_id, top_k=top_k)

    async def close(self) -> None:
        await self._store.close()
