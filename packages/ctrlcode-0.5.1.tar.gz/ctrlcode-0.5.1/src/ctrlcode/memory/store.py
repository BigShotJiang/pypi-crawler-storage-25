"""SQLite-backed artifact store for semantic memory."""

import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import aiosqlite

from .migrations import SchemaMigrationError, run_migrations

logger = logging.getLogger(__name__)

_DDL = """
CREATE TABLE IF NOT EXISTS artifacts (
    id           INTEGER PRIMARY KEY,
    namespace    TEXT    NOT NULL DEFAULT 'default',
    kind         TEXT    NOT NULL,
    content      TEXT    NOT NULL,
    metadata     TEXT    NOT NULL DEFAULT '{}',
    content_hash TEXT    NOT NULL,
    created_at   TEXT    NOT NULL,
    updated_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_art_ns   ON artifacts(namespace);
CREATE INDEX IF NOT EXISTS idx_art_kind ON artifacts(kind);
CREATE INDEX IF NOT EXISTS idx_art_hash ON artifacts(content_hash);

CREATE VIRTUAL TABLE IF NOT EXISTS artifacts_fts USING fts5(
    kind, content,
    tokenize = 'porter unicode61',
    content  = artifacts,
    content_rowid = id
);

CREATE TRIGGER IF NOT EXISTS art_fts_ins AFTER INSERT ON artifacts BEGIN
    INSERT INTO artifacts_fts(rowid, kind, content) VALUES (new.id, new.kind, new.content);
END;
CREATE TRIGGER IF NOT EXISTS art_fts_del AFTER DELETE ON artifacts BEGIN
    INSERT INTO artifacts_fts(artifacts_fts, rowid, kind, content)
    VALUES ('delete', old.id, old.kind, old.content);
END;
CREATE TRIGGER IF NOT EXISTS art_fts_upd AFTER UPDATE ON artifacts BEGIN
    INSERT INTO artifacts_fts(artifacts_fts, rowid, kind, content)
    VALUES ('delete', old.id, old.kind, old.content);
    INSERT INTO artifacts_fts(rowid, kind, content) VALUES (new.id, new.kind, new.content);
END;

CREATE TABLE IF NOT EXISTS entity_index (
    id          INTEGER PRIMARY KEY,
    entity      TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    artifact_id INTEGER NOT NULL REFERENCES artifacts(id) ON DELETE CASCADE,
    session_id  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entity_lookup   ON entity_index(entity, session_id);
CREATE INDEX IF NOT EXISTS idx_entity_artifact ON entity_index(artifact_id);

CREATE TABLE IF NOT EXISTS engagement_log (
    id          INTEGER PRIMARY KEY,
    cluster_key TEXT NOT NULL,
    session_id  TEXT NOT NULL,
    tokens      INTEGER NOT NULL,
    turn_id     TEXT NOT NULL,
    recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_engagement_cluster ON engagement_log(cluster_key, session_id);

CREATE TABLE IF NOT EXISTS file_tree (
    path        TEXT    PRIMARY KEY,
    node_type   TEXT    NOT NULL,
    content_hash TEXT   NOT NULL,
    mtime       REAL,
    size        INTEGER,
    parent_path TEXT,
    scanned_at  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_file_tree_hash   ON file_tree(content_hash);
CREATE INDEX IF NOT EXISTS idx_file_tree_parent ON file_tree(parent_path);

CREATE TABLE IF NOT EXISTS dependency_graph (
    id           INTEGER PRIMARY KEY,
    importer     TEXT    NOT NULL,
    importee     TEXT    NOT NULL,
    import_type  TEXT    NOT NULL,
    import_names TEXT,
    indexed_at   TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(importer, importee)
);
CREATE INDEX IF NOT EXISTS idx_dep_importee ON dependency_graph(importee);
CREATE INDEX IF NOT EXISTS idx_dep_importer ON dependency_graph(importer);
"""


@dataclass
class Artifact:
    id: int
    namespace: str
    kind: str
    content: str
    metadata: dict[str, Any]
    content_hash: str
    created_at: datetime
    updated_at: datetime


@dataclass
class ArtifactResult:
    artifact: Artifact
    score: float


def _row_to_artifact(row: aiosqlite.Row) -> Artifact:
    return Artifact(
        id=row["id"],
        namespace=row["namespace"],
        kind=row["kind"],
        content=row["content"],
        metadata=json.loads(row["metadata"]),
        content_hash=row["content_hash"],
        created_at=datetime.fromisoformat(row["created_at"]),
        updated_at=datetime.fromisoformat(row["updated_at"]),
    )


class ArtifactStore:
    """Async SQLite artifact store with FTS5 text search."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._db: Optional[aiosqlite.Connection] = None

    async def _ensure_init(self) -> aiosqlite.Connection:
        if self._db is not None:
            return self._db
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        db = await aiosqlite.connect(str(self._db_path))
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA journal_mode=WAL")
        await db.execute("PRAGMA busy_timeout=5000")
        await db.executescript(_DDL)
        await db.commit()
        try:
            await run_migrations(db)
        except SchemaMigrationError as exc:
            logger.error("Schema migration failed for %s: %s", self._db_path, exc)
            raise
        self._db = db
        return db

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None

    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Artifact:
        db = await self._ensure_init()
        meta = metadata or {}
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        now = datetime.now(timezone.utc).isoformat()

        # Return existing if same hash+namespace+kind
        async with db.execute(
            "SELECT * FROM artifacts WHERE content_hash=? AND namespace=? AND kind=?",
            (content_hash, namespace, kind),
        ) as cur:
            row = await cur.fetchone()
        if row:
            return _row_to_artifact(row)

        async with db.execute(
            "INSERT INTO artifacts (namespace, kind, content, metadata, content_hash, created_at, updated_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (namespace, kind, content, json.dumps(meta), content_hash, now, now),
        ) as cur:
            artifact_id = cur.lastrowid
        assert artifact_id is not None
        await db.commit()

        return Artifact(
            id=artifact_id,
            namespace=namespace,
            kind=kind,
            content=content,
            metadata=meta,
            content_hash=content_hash,
            created_at=datetime.fromisoformat(now),
            updated_at=datetime.fromisoformat(now),
        )

    async def get_artifact(self, artifact_id: int) -> Optional[Artifact]:
        db = await self._ensure_init()
        async with db.execute("SELECT * FROM artifacts WHERE id=?", (artifact_id,)) as cur:
            row = await cur.fetchone()
        return _row_to_artifact(row) if row else None

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: Optional[dict[str, Any]] = None,
        content: Optional[str] = None,
    ) -> Optional[Artifact]:
        db = await self._ensure_init()
        now = datetime.now(timezone.utc).isoformat()
        updates: list[str] = ["updated_at = ?"]
        params: list[Any] = [now]
        if content is not None:
            updates += ["content = ?", "content_hash = ?"]
            params += [content, hashlib.sha256(content.encode()).hexdigest()]
        if metadata is not None:
            updates.append("metadata = ?")
            params.append(json.dumps(metadata))
        params.append(artifact_id)
        await db.execute(
            f"UPDATE artifacts SET {', '.join(updates)} WHERE id = ?", params
        )
        await db.commit()
        return await self.get_artifact(artifact_id)

    async def delete_artifact(self, artifact_id: int) -> None:
        db = await self._ensure_init()
        await db.execute("DELETE FROM artifacts WHERE id=?", (artifact_id,))
        await db.commit()

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: Optional[str] = None,
        namespace: Optional[str] = None,
    ) -> list[ArtifactResult]:
        db = await self._ensure_init()
        return await self._fts_search(db, query, top_k=top_k, kind=kind, namespace=namespace)

    async def _fts_search(
        self,
        db: aiosqlite.Connection,
        query: str,
        *,
        top_k: int,
        kind: Optional[str],
        namespace: Optional[str],
    ) -> list[ArtifactResult]:
        if not query.strip():
            # No query — return most recent
            sql = """SELECT * FROM artifacts
                     WHERE (json_extract(metadata, '$.validity_score') IS NULL
                            OR json_extract(metadata, '$.validity_score') > 0)"""
            params: list[Any] = []
            if namespace:
                sql += " AND namespace=?"
                params.append(namespace)
            if kind:
                sql += " AND kind=?"
                params.append(kind)
            sql += " ORDER BY created_at DESC LIMIT ?"
            params.append(top_k)
            async with db.execute(sql, params) as cur:
                rows = await cur.fetchall()
            return [ArtifactResult(artifact=_row_to_artifact(r), score=1.0) for r in rows]

        # Escape FTS query
        safe_query = query.replace('"', '""')
        sql = """
            SELECT a.*, bm25(artifacts_fts) AS score
            FROM artifacts_fts
            JOIN artifacts a ON a.id = artifacts_fts.rowid
            WHERE artifacts_fts MATCH ?
              AND (json_extract(a.metadata, '$.validity_score') IS NULL
                   OR json_extract(a.metadata, '$.validity_score') > 0)
        """
        params = [f'"{safe_query}"']
        if namespace:
            sql += " AND a.namespace=?"
            params.append(namespace)
        if kind:
            sql += " AND a.kind=?"
            params.append(kind)
        sql += " ORDER BY score LIMIT ?"
        params.append(top_k)

        try:
            async with db.execute(sql, params) as cur:
                rows = await cur.fetchall()
        except Exception:
            # FTS query syntax error — return empty
            return []

        # BM25 from sqlite fts5 returns negative values (lower = better)
        results = []
        for row in rows:
            raw = row["score"]
            # Normalise to 0–1 range (approximate)
            score = 1.0 / (1.0 + abs(raw)) if raw else 0.5
            results.append(ArtifactResult(artifact=_row_to_artifact(row), score=score))
        return results

    async def log_engagement(
        self,
        cluster_key: str,
        session_id: str,
        tokens: int,
        turn_id: str,
        retrieval_count: int = 1,
    ) -> None:
        """Record token engagement and retrieval count for a file/cluster in this session."""
        db = await self._ensure_init()
        now = datetime.now(timezone.utc).isoformat()
        await db.execute(
            "INSERT INTO engagement_log (cluster_key, session_id, tokens, turn_id, recorded_at, retrieval_count)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (cluster_key, session_id, tokens, turn_id, now, retrieval_count),
        )
        await db.commit()

    async def get_engagement_sum(self, cluster_key: str, session_id: str) -> float:
        """Return total tokens attributed to a cluster in this session."""
        db = await self._ensure_init()
        async with db.execute(
            "SELECT COALESCE(SUM(tokens), 0) FROM engagement_log WHERE cluster_key=? AND session_id=?",
            (cluster_key, session_id),
        ) as cur:
            row = await cur.fetchone()
        return float(row[0]) if row else 0.0

    async def get_engagement_stats(self, cluster_key: str, session_id: str) -> tuple[int, int]:
        """Return (total_retrievals, total_hits) for a cluster in this session."""
        db = await self._ensure_init()
        async with db.execute(
            "SELECT COALESCE(COUNT(*), 0), COALESCE(SUM(retrieval_count), 0) FROM engagement_log WHERE cluster_key=? AND session_id=?",
            (cluster_key, session_id),
        ) as cur:
            row = await cur.fetchone()
        return (int(row[0]), int(row[1])) if row else (0, 0)

    async def index_entities(
        self,
        artifact_id: int,
        entity_pairs: list[tuple[str, str]],
        session_id: str,
    ) -> None:
        """Index (entity, entity_type) → artifact relationships for exact lookup."""
        if not entity_pairs:
            return
        db = await self._ensure_init()
        await db.executemany(
            "INSERT INTO entity_index (entity, entity_type, artifact_id, session_id) VALUES (?, ?, ?, ?)",
            [(entity, entity_type, artifact_id, session_id) for entity, entity_type in entity_pairs],
        )
        await db.commit()

    async def lookup_by_entities(
        self,
        entities: list[str],
        session_id: str,
        top_k: int = 20,
    ) -> list["ArtifactResult"]:
        """Return artifacts that reference any of the given entities (exact match)."""
        if not entities:
            return []
        db = await self._ensure_init()
        placeholders = ",".join("?" * len(entities))
        sql = f"""
            SELECT a.*, COUNT(*) AS match_count
            FROM entity_index ei
            JOIN artifacts a ON a.id = ei.artifact_id
            WHERE ei.entity IN ({placeholders}) AND ei.session_id = ?
              AND (json_extract(a.metadata, '$.validity_score') IS NULL
                   OR json_extract(a.metadata, '$.validity_score') > 0)
            GROUP BY a.id
            ORDER BY match_count DESC
            LIMIT ?
        """
        params: list[Any] = list(entities) + [session_id, top_k]
        async with db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [ArtifactResult(artifact=_row_to_artifact(row), score=1.0) for row in rows]

    async def artifacts_referencing_path(self, path: str) -> list[int]:
        """Return artifact IDs that reference the given workspace-relative path."""
        db = await self._ensure_init()
        ids: set[int] = set()
        # Via entity_index (file mentions extracted from text)
        async with db.execute(
            "SELECT artifact_id FROM entity_index WHERE entity = ?", (path,)
        ) as cur:
            async for row in cur:
                ids.add(row[0])
        # Via source_file_hash column (content matching)
        async with db.execute(
            "SELECT id FROM artifacts WHERE source_file_hash IS NOT NULL"
            " AND json_extract(metadata, '$.source_file') = ?",
            (path,),
        ) as cur:
            async for row in cur:
                ids.add(row[0])
        # Via text search — catches tool results and summaries that mention the path
        # but were never indexed as file entities (e.g. search_files results)
        async with db.execute(
            "SELECT id FROM artifacts WHERE content LIKE ?",
            (f"%{path}%",),
        ) as cur:
            async for row in cur:
                ids.add(row[0])
        return list(ids)

    async def structural_lookup(
        self,
        paths: set[str],
        session_id: str,
        top_k: int = 20,
    ) -> list["ArtifactResult"]:
        """Return recent non-superseded artifacts whose source files overlap with paths."""
        if not paths:
            return []
        db = await self._ensure_init()
        placeholders = ",".join("?" * len(paths))
        sql = f"""
            SELECT DISTINCT a.*
            FROM entity_index ei
            JOIN artifacts a ON a.id = ei.artifact_id
            WHERE ei.entity IN ({placeholders})
              AND ei.session_id = ?
              AND json_extract(a.metadata, '$.superseded_by') IS NULL
              AND (json_extract(a.metadata, '$.validity_score') IS NULL
                   OR json_extract(a.metadata, '$.validity_score') > 0)
            ORDER BY a.created_at DESC
            LIMIT ?
        """
        params: list[Any] = list(paths) + [session_id, top_k]
        async with db.execute(sql, params) as cur:
            rows = await cur.fetchall()
        return [ArtifactResult(artifact=_row_to_artifact(row), score=1.0) for row in rows]

