"""Proactive context window monitor — checks token usage before each turn and compacts if needed."""

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from harnessutils import ConversationManager, Message
    from ..session.adapters import LLMClientAdapter

logger = logging.getLogger(__name__)

MODEL_CAPACITIES: dict[str, int] = {
    # Claude 3.x
    "claude-3-haiku-20240307":    200_000,
    "claude-3-sonnet-20240229":   200_000,
    "claude-3-opus-20240229":     200_000,
    # Claude 3.5
    "claude-3-5-haiku-20241022":  200_000,
    "claude-3-5-sonnet-20241022": 200_000,
    "claude-3-5-sonnet-20240620": 200_000,
    # Claude 3.7 / 4.x
    "claude-3-7-sonnet-20250219": 200_000,
    "claude-sonnet-4-5-20250929": 200_000,
    "claude-sonnet-4-6":          200_000,
    "claude-opus-4-5":            200_000,
    "claude-opus-4-6":            200_000,
    # GPT-4 family
    "gpt-4o":                     128_000,
    "gpt-4o-mini":                128_000,
    "gpt-4-turbo":                128_000,
    "gpt-4":                        8_192,
    "gpt-3.5-turbo":              16_385,
    # Fallback
    "_fallback":                  170_000,
}

_SUMMARIZE_PROMPT = """\
You are compacting conversation history to free context window space.
Below are messages from the oldest portion of this conversation that are about to be removed.
Write a dense summary (under 600 tokens) that preserves:

1. Every decision made (architectural, design, user preference)
2. Files created or modified, and the change made to each
3. Errors encountered and how they were resolved
4. Tasks completed vs. tasks still pending
5. Any important facts the agent would need to avoid repeating work

Do NOT include raw code unless it is essential to understanding a decision.
Do NOT pad with filler. Be terse.

--- MESSAGES TO SUMMARIZE ---
{formatted_messages}
--- END ---

Output only the summary, no preamble."""


def _format_messages_for_summary(messages: list[dict]) -> str:
    lines = []
    for msg in messages:
        role = msg.get("role", "unknown").upper()
        content = msg.get("content", "")
        if isinstance(content, list):
            # Handle structured content blocks
            parts = []
            for block in content:
                if isinstance(block, dict):
                    parts.append(block.get("text", str(block)))
                else:
                    parts.append(str(block))
            content = " ".join(parts)
        lines.append(f"[{role}]: {content}")
    return "\n".join(lines)


class ContextWindowMonitor:
    """Tracks token usage relative to model capacity and compacts conversation when threshold is crossed."""

    def __init__(
        self,
        model: str,
        ctrlcode_dir: Path,
        threshold: float = 0.85,
        fallback_tokens: int = 170_000,
    ) -> None:
        self._model = model
        self._ctrlcode_dir = ctrlcode_dir
        self._threshold = threshold
        self._fallback_tokens = fallback_tokens

    def max_tokens_for_model(self) -> int:
        """Return the context window size for the configured model."""
        if self._model in MODEL_CAPACITIES:
            return MODEL_CAPACITIES[self._model]
        # Short-prefix match: e.g. "claude-3-5" → 200_000
        _PREFIX_MAP: dict[str, int] = {
            "claude-3-5":    200_000,
            "claude-3-7":    200_000,
            "claude-3":      200_000,
            "claude-sonnet": 200_000,
            "claude-opus":   200_000,
            "claude-haiku":  200_000,
            "gpt-4o":        128_000,
            "gpt-4-turbo":   128_000,
            "gpt-4":           8_192,
            "gpt-3.5":        16_385,
        }
        for prefix, capacity in _PREFIX_MAP.items():
            if self._model.startswith(prefix):
                return capacity
        return self._fallback_tokens

    def is_over_threshold(self, current_tokens: int) -> bool:
        """Return True if current_tokens >= threshold * max_tokens."""
        return current_tokens >= self._threshold * self.max_tokens_for_model()

    def offload_history(self, session_id: str, messages: "list[Message]") -> Path:
        """Write raw messages to .ctrlcode/conversation_history/{session_id}.md and return path.

        Appends to the file if it already exists.
        """
        history_dir = self._ctrlcode_dir / "conversation_history"
        history_dir.mkdir(parents=True, exist_ok=True)
        outfile = history_dir / f"{session_id}.md"

        timestamp = datetime.now(tz=timezone.utc).isoformat()
        lines: list[str] = [f"\n## Compaction batch — {timestamp}\n"]
        for msg in messages:
            role = getattr(msg, "role", "unknown").upper()
            parts = getattr(msg, "parts", [])
            text_parts = []
            for part in parts:
                t = getattr(part, "text", None)
                if t:
                    text_parts.append(t)
            content = " ".join(text_parts) if text_parts else "(no text)"
            lines.append(f"**[{role}]** {content}\n")

        with outfile.open("a", encoding="utf-8") as fh:
            fh.write("\n".join(lines))

        logger.info("Offloaded %d messages to %s", len(messages), outfile)
        return outfile

    async def summarize_and_compact(
        self,
        session_id: str,
        conv_manager: "ConversationManager",
        conv_id: str,
        llm_client: "LLMClientAdapter | None",
        keep_last: int | None = None,
    ) -> dict[str, Any]:
        """Summarize the oldest portion of conversation messages and replace them.

        Creates a new conversation, prepends a summary message, and appends the
        newer portion. Returns a dict with ``tokens_saved``, ``new_conv_id``,
        and ``summary_text``.

        Args:
            keep_last: If set, keep this many most-recent messages verbatim and
                compact everything older. If None, compacts the oldest half.
        """
        messages = conv_manager.get_messages(conv_id)
        tokens_before = conv_manager.calculate_context_usage(conv_id, model=self._model)

        if not messages:
            return {"tokens_saved": 0, "new_conv_id": conv_id, "summary_text": ""}

        if keep_last is not None:
            split = max(1, len(messages) - keep_last)
        else:
            split = max(1, len(messages) // 2)
        old_msgs = messages[:split]
        new_msgs = messages[split:]

        # Offload old messages to disk
        self.offload_history(session_id, old_msgs)

        # Generate summary
        summary_text = await self._generate_summary(old_msgs, llm_client)

        # Build new conversation
        from harnessutils import Message, TextPart
        from ..session.utils import generate_msg_id

        new_conv = conv_manager.create_conversation(project_id="ctrl-code")
        new_conv_id = new_conv.id

        # Prepend summary as user message
        summary_msg = Message(id=generate_msg_id(), role="user")
        summary_msg.add_part(TextPart(
            text=f"[Context compaction: {len(old_msgs)} messages summarized. Prior context:]\n{summary_text}"
        ))
        conv_manager.add_message(new_conv_id, summary_msg)

        # Re-add the newer messages
        for msg in new_msgs:
            conv_manager.add_message(new_conv_id, msg)

        tokens_after = conv_manager.calculate_context_usage(new_conv_id, model=self._model)
        tokens_saved = max(0, tokens_before - tokens_after)

        logger.info(
            "Context compaction for session %s: %d → %d tokens (%d saved), new conv_id=%s",
            session_id, tokens_before, tokens_after, tokens_saved, new_conv_id,
        )
        return {
            "tokens_saved": tokens_saved,
            "new_conv_id": new_conv_id,
            "summary_text": summary_text,
            "messages_compacted": len(old_msgs),
        }

    async def _generate_summary(
        self,
        messages: "list[Message]",
        llm_client: "LLMClientAdapter | None",
    ) -> str:
        """Call the LLM to summarize messages, falling back to a simple truncation summary."""
        if llm_client is None:
            return self._fallback_summary(messages)

        wire_msgs: list[dict] = []
        for msg in messages:
            role = getattr(msg, "role", "user")
            parts = getattr(msg, "parts", [])
            text_parts = [getattr(p, "text", "") for p in parts if getattr(p, "text", None)]
            wire_msgs.append({"role": role, "content": " ".join(text_parts)})

        formatted = _format_messages_for_summary(wire_msgs)
        prompt = _SUMMARIZE_PROMPT.format(formatted_messages=formatted)

        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: llm_client.invoke([{"role": "user", "content": prompt}]),
            )
            return result.get("content", self._fallback_summary(messages))
        except Exception as exc:  # noqa: BLE001
            logger.warning("LLM summarization failed (%s), using fallback", exc)
            return self._fallback_summary(messages)

    @staticmethod
    def _fallback_summary(messages: "list[Message]") -> str:
        """Simple truncation summary when no LLM client is available."""
        lines = [f"[{len(messages)} messages were removed to free context space.]"]
        for msg in messages[:5]:
            role = getattr(msg, "role", "unknown")
            parts = getattr(msg, "parts", [])
            texts = [getattr(p, "text", "") for p in parts if getattr(p, "text", None)]
            snippet = " ".join(texts)[:120]
            lines.append(f"- [{role}]: {snippet}")
        if len(messages) > 5:
            lines.append(f"  ... and {len(messages) - 5} more messages.")
        return "\n".join(lines)
