"""Orchestrates workspace scanning, dependency indexing, and artifact supersession."""

import asyncio
import logging
from pathlib import Path
from typing import Optional

from .file_tree import FileChangeSet, FileTreeIndex, IGNORED_DIRS, IGNORED_EXTENSIONS
from .dependency_indexer import DependencyIndexer, _EXT_TO_LANG
from .store import ArtifactStore

logger = logging.getLogger(__name__)


class WorkspaceMonitor:
    """Coordinates scan → reindex → supersession, plus continuous FS watching."""

    def __init__(
        self,
        store: ArtifactStore,
        workspace_root: Path,
        session_id: str,
    ) -> None:
        self._store = store
        self._root = workspace_root
        self._session_id = session_id
        self._file_tree = FileTreeIndex(store, workspace_root)
        self._dep_indexer = DependencyIndexer(store, workspace_root)
        self._watch_task: Optional[asyncio.Task] = None
        # Paths recently written by the harness — skip watcher-triggered re-indexing
        self._harness_written: set[str] = set()

    @property
    def file_tree(self) -> FileTreeIndex:
        return self._file_tree

    @property
    def dep_indexer(self) -> DependencyIndexer:
        return self._dep_indexer

    async def refresh(self) -> FileChangeSet:
        """
        Full refresh cycle:
        1. Scan filesystem (Merkle tree diff)
        2. If first run, full dependency index; otherwise reindex changed files
        3. Supersede stale artifacts
        Returns the FileChangeSet for logging/display.
        """
        db = await self._store._ensure_init()

        # Detect first run (no rows in file_tree)
        async with db.execute("SELECT COUNT(*) FROM file_tree") as cur:
            row = await cur.fetchone()
        is_first_run = row[0] == 0 if row else True

        # 1. Scan
        change_set = await self._file_tree.scan()

        if is_first_run:
            # Full dependency index on first run
            source_files = self._collect_source_files()
            if source_files:
                logger.info(f"WorkspaceMonitor: full index of {len(source_files)} source files")
                await self._dep_indexer.full_index(source_files)
        else:
            # Incremental reindex for changed files
            if change_set.all_changed:
                await self._dep_indexer.reindex_changed(change_set.all_changed)

        # 3. Supersede stale artifacts
        if change_set.all_changed:
            await self._supersede_stale(change_set)

        if not change_set.is_empty:
            logger.info(
                f"WorkspaceMonitor: +{len(change_set.added)} "
                f"~{len(change_set.modified)} "
                f"→{len(change_set.moved)} "
                f"-{len(change_set.deleted)}"
            )

        return change_set

    async def update_file(self, rel_path: str) -> None:
        """Update a single file after the agent writes it."""
        # Mark as harness-written so the watcher skips the corresponding FS event
        self._harness_written.add(rel_path)
        asyncio.get_running_loop().call_later(3.0, self._harness_written.discard, rel_path)
        await self._file_tree.update_file(rel_path)
        if Path(rel_path).suffix.lower() in _EXT_TO_LANG:
            await self._dep_indexer.index_file(rel_path)

    async def start_watching(self) -> None:
        """Start a background task watching the workspace for external changes."""
        if self._watch_task and not self._watch_task.done():
            return
        self._watch_task = asyncio.create_task(self._watch_loop(), name="workspace-watcher")
        logger.info(f"Workspace watcher started for {self._root}")

    async def stop_watching(self) -> None:
        """Stop the background filesystem watcher."""
        if self._watch_task and not self._watch_task.done():
            self._watch_task.cancel()
            try:
                await self._watch_task
            except asyncio.CancelledError:
                pass
        self._watch_task = None
        logger.info("Workspace watcher stopped")

    async def _watch_loop(self) -> None:
        """Watch for external filesystem changes and keep artifacts in sync."""
        try:
            from watchfiles import awatch, Change
        except ImportError:
            logger.warning("watchfiles not installed; real-time workspace watching disabled")
            return

        try:
            async for changes in awatch(self._root):
                for change_type, abs_path in changes:
                    try:
                        rel_path = str(Path(abs_path).relative_to(self._root))
                    except ValueError:
                        continue

                    # Skip ignored dirs/extensions
                    parts = Path(rel_path).parts
                    if any(p in IGNORED_DIRS for p in parts):
                        continue
                    if Path(rel_path).suffix.lower() in IGNORED_EXTENSIONS:
                        continue

                    if rel_path in self._harness_written:
                        continue  # harness wrote this, already handled

                    if change_type == Change.deleted:
                        logger.debug(f"External delete detected: {rel_path}")
                        await self._supersede_path(rel_path)
                        await self._file_tree.update_file(rel_path)  # deletes row when file gone

                    elif change_type == Change.modified:
                        logger.debug(f"External modify detected: {rel_path}")
                        await self._supersede_path(rel_path)
                        await self._file_tree.update_file(rel_path)
                        if Path(rel_path).suffix.lower() in _EXT_TO_LANG:
                            await self._dep_indexer.index_file(rel_path)

                    elif change_type == Change.added:
                        logger.debug(f"External add detected: {rel_path}")
                        await self._file_tree.update_file(rel_path)
                        if Path(rel_path).suffix.lower() in _EXT_TO_LANG:
                            await self._dep_indexer.index_file(rel_path)

        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.warning(f"Workspace watcher error: {e}")

    async def _supersede_path(self, path: str) -> None:
        """Invalidate all artifacts referencing this path."""
        artifact_ids = await self._store.artifacts_referencing_path(path)
        for art_id in artifact_ids:
            artifact = await self._store.get_artifact(art_id)
            if artifact is None or artifact.metadata.get("superseded_by"):
                continue
            await self._store.update_artifact(art_id, metadata={
                **artifact.metadata,
                "superseded_by": "__external__",
                "validity_score": 0.0,
            })
        if artifact_ids:
            logger.info(f"Invalidated {len(artifact_ids)} artifacts for external change: {path}")

    def _collect_source_files(self) -> list[str]:
        """Walk workspace and return all indexable source files (respecting ignore list)."""
        results = []
        for path in self._root.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in _EXT_TO_LANG:
                continue
            skip = False
            for part in path.parts:
                if part in IGNORED_DIRS:
                    skip = True
                    break
            if not skip and path.suffix not in IGNORED_EXTENSIONS:
                results.append(str(path.relative_to(self._root)))
        return results

    async def _supersede_stale(self, change_set: FileChangeSet) -> None:
        """Mark artifacts referencing changed/deleted/moved paths as externally superseded."""
        all_stale_paths = change_set.all_changed
        for path in all_stale_paths:
            artifact_ids = await self._store.artifacts_referencing_path(path)
            for art_id in artifact_ids:
                artifact = await self._store.get_artifact(art_id)
                if artifact is None:
                    continue
                if artifact.metadata.get("superseded_by"):
                    continue  # already superseded
                new_meta = {
                    **artifact.metadata,
                    "superseded_by": "__external__",
                    "validity_score": 0.0,
                }
                await self._store.update_artifact(art_id, metadata=new_meta)
