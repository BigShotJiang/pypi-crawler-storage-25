"""Dependency graph builder using tree-sitter for import analysis."""

import logging
from datetime import datetime, timezone
from pathlib import Path

from .store import ArtifactStore
from .indexers import (
    _EXT_TO_LANG,
    parse_python_imports,
    parse_js_ts_imports,
    parse_rust_imports,
    parse_c_cpp_imports,
    parse_ruby_imports,
    parse_java_imports,
    parse_kotlin_imports,
    parse_lua_imports,
    parse_dart_imports,
    parse_zig_imports,
    parse_go_imports,
    parse_scala_imports,
    parse_swift_imports,
    parse_php_imports,
    parse_csharp_imports,
    parse_elixir_imports,
    parse_haskell_imports,
    parse_ocaml_imports,
    parse_fsharp_imports,
    parse_erlang_imports,
    parse_clojure_imports,
    parse_julia_imports,
    parse_groovy_imports,
    parse_nim_imports,
    parse_d_imports,
    parse_perl_imports,
    parse_r_imports,
    parse_solidity_imports,
    parse_v_imports,
    parse_gleam_imports,
    parse_elm_imports,
    parse_purescript_imports,
    parse_haxe_imports,
    parse_gdscript_imports,
    parse_pony_imports,
    parse_racket_imports,
    parse_scheme_imports,
    parse_odin_imports,
)

logger = logging.getLogger(__name__)

BLAST_RADIUS_MAX = 30

# Language → parser function dispatch table
_LANG_PARSERS = {
    "python":     parse_python_imports,
    "javascript": parse_js_ts_imports,
    "typescript": parse_js_ts_imports,
    "tsx":        parse_js_ts_imports,
    "rust":       parse_rust_imports,
    "c":          parse_c_cpp_imports,
    "cpp":        parse_c_cpp_imports,
    "objc":       parse_c_cpp_imports,   # identical preproc_include AST
    "ruby":       parse_ruby_imports,
    "java":       parse_java_imports,
    "kotlin":     parse_kotlin_imports,
    "lua":        parse_lua_imports,
    "dart":       parse_dart_imports,
    "zig":        parse_zig_imports,
    "go":         parse_go_imports,
    "scala":      parse_scala_imports,
    "swift":      parse_swift_imports,
    "php":        parse_php_imports,
    "csharp":     parse_csharp_imports,
    "elixir":     parse_elixir_imports,
    "haskell":    parse_haskell_imports,
    "ocaml":      parse_ocaml_imports,
    "fsharp":     parse_fsharp_imports,
    "erlang":     parse_erlang_imports,
    "clojure":    parse_clojure_imports,
    "julia":      parse_julia_imports,
    "groovy":     parse_groovy_imports,
    "nim":        parse_nim_imports,
    "d":          parse_d_imports,
    "perl":       parse_perl_imports,
    "r":          parse_r_imports,
    "solidity":   parse_solidity_imports,
    "v":          parse_v_imports,
    "gleam":      parse_gleam_imports,
    "elm":        parse_elm_imports,
    "purescript": parse_purescript_imports,
    "haxe":       parse_haxe_imports,
    "gdscript":   parse_gdscript_imports,
    "pony":       parse_pony_imports,
    "racket":     parse_racket_imports,
    "scheme":     parse_scheme_imports,
    "odin":       parse_odin_imports,
}


def _parse_imports(source: bytes, rel_path: str, workspace_root: Path) -> list[dict]:
    """Parse imports from source bytes using tree-sitter with workspace resolution."""
    ext = Path(rel_path).suffix.lower()
    lang = _EXT_TO_LANG.get(ext)
    if not lang:
        return []

    parser_fn = _LANG_PARSERS.get(lang)
    if not parser_fn:
        return []

    try:
        from tree_sitter_language_pack import get_parser
        parser = get_parser(lang)  # type: ignore[arg-type]
        tree = parser.parse(source)
    except Exception as exc:
        logger.debug(f"tree-sitter parse failed for {rel_path}: {exc}")
        return []

    return parser_fn(tree, source, rel_path, workspace_root)


class DependencyIndexer:
    """Builds and queries the import dependency graph."""

    def __init__(self, store: ArtifactStore, workspace_root: Path) -> None:
        self._store = store
        self._root = workspace_root

    async def index_file(self, rel_path: str) -> list[str]:
        """Parse imports from one file and upsert edges. Returns resolved importees."""
        full = self._root / rel_path
        try:
            source = full.read_bytes()
        except OSError:
            return []

        edges = _parse_imports(source, rel_path, self._root)
        db = await self._store._ensure_init()

        await db.execute("DELETE FROM dependency_graph WHERE importer=?", (rel_path,))

        resolved = []
        now = datetime.now(timezone.utc).isoformat()
        for edge in edges:
            importee = edge["importee"]
            import_type = edge["import_type"]
            import_names = edge["import_names"]
            try:
                await db.execute(
                    """
                    INSERT INTO dependency_graph (importer, importee, import_type, import_names, indexed_at)
                    VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT(importer, importee) DO UPDATE SET
                        import_type=excluded.import_type,
                        import_names=excluded.import_names,
                        indexed_at=excluded.indexed_at
                    """,
                    (rel_path, importee, import_type, import_names, now),
                )
            except Exception as exc:
                logger.debug(f"Failed to insert dep edge {rel_path}->{importee}: {exc}")
            if import_type == "internal":
                resolved.append(importee)

        await db.commit()
        return resolved

    async def reindex_changed(self, paths: list[str]) -> None:
        """Re-parse imports for a set of changed files (called after Merkle scan)."""
        indexable = [p for p in paths if Path(p).suffix.lower() in _EXT_TO_LANG]
        for path in indexable:
            try:
                await self.index_file(path)
            except Exception as exc:
                logger.warning(f"reindex_changed failed for {path}: {exc}")

    async def full_index(self, source_files: list[str]) -> None:
        """Parse all indexable source files. Used on first session. Runs in batches.

        Skips files already indexed whose mtime hasn't changed since indexed_at.
        """
        db = await self._store._ensure_init()

        # Load last-indexed timestamp per importer so we can skip unchanged files
        async with db.execute(
            "SELECT importer, MAX(indexed_at) FROM dependency_graph GROUP BY importer"
        ) as cur:
            existing_rows = await cur.fetchall()
        last_indexed: dict[str, str] = {row[0]: row[1] for row in existing_rows}

        now = datetime.now(timezone.utc).isoformat()
        batch_size = 100

        for i in range(0, len(source_files), batch_size):
            batch = source_files[i : i + batch_size]
            new_rows: list[tuple] = []
            files_to_reindex: list[str] = []

            for rel_path in batch:
                full = self._root / rel_path
                # Skip if already indexed and file hasn't changed since then
                if rel_path in last_indexed:
                    try:
                        mtime = datetime.fromtimestamp(full.stat().st_mtime, tz=timezone.utc).isoformat()
                        if mtime <= last_indexed[rel_path]:
                            continue
                    except OSError:
                        continue

                files_to_reindex.append(rel_path)
                try:
                    source = full.read_bytes()
                except OSError:
                    continue
                edges = _parse_imports(source, rel_path, self._root)
                for edge in edges:
                    new_rows.append((
                        rel_path,
                        edge["importee"],
                        edge["import_type"],
                        edge["import_names"],
                        now,
                    ))

            # Remove stale edges for files being reindexed before inserting fresh ones
            for rel_path in files_to_reindex:
                await db.execute("DELETE FROM dependency_graph WHERE importer=?", (rel_path,))

            if new_rows:
                await db.executemany(
                    """
                    INSERT INTO dependency_graph
                        (importer, importee, import_type, import_names, indexed_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    new_rows,
                )
            await db.commit()

    async def get_dependents(self, path: str, depth: int = 3) -> set[str]:
        """BFS up the graph: who imports this file, transitively (depth-limited, capped)."""
        db = await self._store._ensure_init()
        frontier = {path}
        visited = {path}

        for _ in range(depth):
            if len(visited) >= BLAST_RADIUS_MAX:
                break
            if not frontier:
                break
            placeholders = ",".join("?" * len(frontier))
            sql = f"SELECT importer FROM dependency_graph WHERE importee IN ({placeholders})"
            async with db.execute(sql, list(frontier)) as cur:
                rows = await cur.fetchall()
            next_frontier = {row[0] for row in rows} - visited
            if not next_frontier:
                break
            remaining = BLAST_RADIUS_MAX - len(visited)
            next_frontier = set(list(next_frontier)[:remaining])
            visited |= next_frontier
            frontier = next_frontier

        visited.discard(path)
        return visited

    async def get_dependencies(self, path: str) -> list[str]:
        """Direct imports of this file (depth 1, outward edges)."""
        db = await self._store._ensure_init()
        async with db.execute(
            "SELECT importee FROM dependency_graph WHERE importer=? AND import_type='internal'",
            (path,),
        ) as cur:
            rows = await cur.fetchall()
        return [row[0] for row in rows]
