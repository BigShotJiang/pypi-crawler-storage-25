"""ContextAssembler — read-path for semantic memory."""

import logging
import math
import re
from datetime import datetime, timezone
from typing import Any, Optional

from .store import ArtifactResult
from .rootset_backend import RootsetMemoryBackend

logger = logging.getLogger(__name__)


class ContextAssembler:
    def __init__(
        self,
        backend: RootsetMemoryBackend,
        project_id: str,
        session_id: str,
        dep_indexer: Optional[Any] = None,  # DependencyIndexer, optional
    ) -> None:
        self._backend = backend
        self._project_id = project_id
        self._session_id = session_id
        self._dep_indexer = dep_indexer

    async def assemble(
        self,
        query: str,
        top_k: int = 10,
        budget_tokens: int = 4096,
        query_files: Optional[set[str]] = None,
    ) -> str:
        # 1. Session summary (always-on)
        summary_results = await self._backend.search_artifacts(
            "session summary", kind="session:summary",
            namespace=self._session_id, top_k=1,
        )
        summary = summary_results[0].artifact.content if summary_results else ""

        # 2. Semantic search over session history
        try:
            results = await self._backend.search_artifacts(
                query, top_k=top_k * 2,
                namespace=self._session_id,
            )
        except Exception as e:
            logger.warning(f"Context retrieval failed: {e}")
            results = []

        # 3. Entity index lookup (exact match — no embedding needed)
        cluster_files = self._extract_file_entities(query)
        if query_files:
            cluster_files |= query_files
        entity_hit_ids: set[int] = set()
        try:
            if cluster_files:
                entity_results = await self._backend.lookup_by_entities(
                    list(cluster_files), self._session_id, top_k=top_k
                )
                entity_hit_ids = {r.artifact.id for r in entity_results}
                # Merge entity hits that didn't appear in semantic results
                existing_ids = {r.artifact.id for r in results}
                for r in entity_results:
                    if r.artifact.id not in existing_ids:
                        results.append(r)
        except Exception as e:
            logger.debug(f"Entity lookup failed: {e}")

        # 3.5. Structural lookup via dependency graph blast radius
        structural_hit_ids: set[int] = set()
        if self._dep_indexer and cluster_files:
            try:
                blast: set[str] = set()
                for f in cluster_files:
                    dependents = await self._dep_indexer.get_dependents(f)
                    blast |= dependents
                if blast:
                    structural_results = await self._backend.structural_lookup(
                        blast, self._session_id, top_k=top_k
                    )
                    structural_hit_ids = {r.artifact.id for r in structural_results}
                    existing_ids = {r.artifact.id for r in results}
                    for r in structural_results:
                        if r.artifact.id not in existing_ids:
                            results.append(r)
            except Exception as e:
                logger.debug(f"Structural lookup failed: {e}")

        # 4. Cross-session project memory search
        project_hit_ids: set[int] = set()
        try:
            project_results = await self._backend.search_artifacts(
                query, top_k=top_k,
                namespace=self._project_id,
            )
            project_hit_ids = {r.artifact.id for r in project_results}
            # Merge project hits that didn't appear in session results
            existing_ids = {r.artifact.id for r in results}
            for r in project_results:
                if r.artifact.id not in existing_ids:
                    results.append(r)
        except Exception as e:
            logger.debug(f"Project memory lookup failed: {e}")

        # 5. Pre-fetch engagement stats for cluster files  
        engagement_stats: dict[str, tuple[int, int]] = {}
        for f in cluster_files:
            try:
                engagement_stats[f] = await self._backend.get_engagement_stats(f, self._session_id)
            except Exception:
                pass

        # 6. Score all candidates; superseded chunks scored at 0.5× validity
        scored: list[tuple[float, Any, bool]] = []
        for r in results:
            is_superseded = bool(r.artifact.metadata.get("superseded_by"))
            score = self._score(r, cluster_files, entity_hit_ids, is_superseded, engagement_stats, structural_hit_ids, project_hit_ids)
            scored.append((score, r, is_superseded))
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:top_k]

        # 7. Supersession resolution: for superseded items, also inject superseding artifact
        final_items: list[tuple[Any, bool, bool]] = []  # (result, is_superseded, is_superseding)
        seen_ids: set[int] = set()
        for _score, r, is_superseded in top:
            if r.artifact.id in seen_ids:
                continue
            seen_ids.add(r.artifact.id)
            final_items.append((r, is_superseded, False))
            if is_superseded:
                superseding_id = r.artifact.metadata.get("superseded_by")
                if superseding_id:
                    try:
                        superseding = await self._backend.get_artifact(int(superseding_id))
                        if superseding and superseding.id not in seen_ids:
                            seen_ids.add(superseding.id)
                            final_items.append(
                                (ArtifactResult(artifact=superseding, score=_score), False, True)
                            )
                    except Exception:
                        pass

        return self._format(summary, final_items, budget_tokens)

    def _score(
        self,
        result: Any,
        cluster_files: set[str],
        entity_hit_ids: set[int],
        is_superseded: bool,
        engagement_stats: dict[str, tuple[int, int]],
        structural_hit_ids: Optional[set[int]] = None,
        project_hit_ids: Optional[set[int]] = None,
    ) -> float:
        art = result.artifact
        saliency = art.metadata.get("saliency", 0.20)
        topical = result.score
        entity_bonus = 0.2 if art.id in entity_hit_ids else 0.0
        structural_bonus = 0.15 if (structural_hit_ids and art.id in structural_hit_ids) else 0.0
        entity_files = set(art.metadata.get("entities", {}).get("files", []))
        same_cluster = bool(entity_files & cluster_files)
        try:
            age_hours = (
                datetime.now(timezone.utc) - art.created_at.replace(tzinfo=timezone.utc)
            ).total_seconds() / 3600
        except Exception:
            age_hours = 0.0
        recency_penalty = 0.0 if same_cluster else self._decay(age_hours)
        validity_score = 0.5 if is_superseded else 1.0
        # Engagement bonus: Wilson-style ratio hits / (hits + k) where k dampens low-frequency items
        cluster_key = next(iter(entity_files & cluster_files), None)
        if cluster_key and cluster_key in engagement_stats:
            _, hits = engagement_stats[cluster_key]
            k = 5  # damping factor for Wilson-style ratio
            engagement = hits / (hits + k)
        else:
            engagement = 0.0
        
        # Cross-session discount: project namespace artifacts get ×0.6 weighting
        cross_session_discount = 0.6 if (project_hit_ids and art.id in project_hit_ids) else 1.0
        
        return (
            (topical + entity_bonus + structural_bonus + saliency * 0.3)
            * validity_score
            * (1.0 - recency_penalty)
            * (1.0 + engagement)
            * cross_session_discount
        )

    def _decay(self, age_hours: float) -> float:
        return 1.0 - (1.0 / (1.0 + math.exp(-0.05 * (age_hours - 72))))

    def _extract_file_entities(self, text: str) -> set[str]:
        return set(re.findall(r'[\w./\-]+\.(?:py|ts|js|rs|go|md|toml|json|yaml)', text))

    def _format(
        self,
        summary: str,
        items: list[tuple[Any, bool, bool]],
        budget_tokens: int,
    ) -> str:
        if not summary and not items:
            return ""

        lines: list[str] = ["--- Retrieved Context ---"]
        used_tokens = 10  # header + footer

        if summary:
            summary_tokens = len(summary) // 4 + 5
            if used_tokens + summary_tokens <= budget_tokens:
                lines += ["[Session Summary]", summary, ""]
                used_tokens += summary_tokens

        if items:
            lines.append("[Relevant History]")
            used_tokens += 3
            for r, is_superseded, is_superseding in items:
                art = r.artifact
                ts = art.created_at.strftime("%H:%M") if art.created_at else ""
                saliency = art.metadata.get("saliency", 0)

                if is_superseded:
                    header = f"[{art.kind} {ts} saliency={saliency:.2f} — SUPERSEDED see below]"
                elif is_superseding:
                    header = f"[{art.kind} {ts} — supersedes above]"
                else:
                    header = f"[{art.kind} {ts} saliency={saliency:.2f}]"

                chunk = art.content[:800]
                item_tokens = (len(header) + len(chunk)) // 4 + 3
                if used_tokens + item_tokens > budget_tokens:
                    break
                lines.append(header)
                lines.append(chunk)
                lines.append("")
                used_tokens += item_tokens

        lines.append("--- End Retrieved Context ---")
        return "\n".join(lines)
