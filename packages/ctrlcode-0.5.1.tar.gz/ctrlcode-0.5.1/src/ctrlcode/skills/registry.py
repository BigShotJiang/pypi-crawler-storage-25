"""Skill registry for managing and expanding skills."""

import re
from typing import Optional

from .loader import Skill


class SkillRegistry:
    """Registry for managing skills."""

    def __init__(self):
        """Initialize skill registry."""
        self.skills: dict[str, Skill] = {}

    def register(self, skill: Skill) -> None:
        """
        Register a skill.

        Args:
            skill: Skill to register
        """
        self.skills[skill.name] = skill

    def register_all(self, skills: dict[str, Skill]) -> None:
        """
        Register multiple skills.

        Args:
            skills: Dict of skills to register
        """
        self.skills.update(skills)

    def get(self, name: str) -> Optional[Skill]:
        """
        Get skill by name.

        Args:
            name: Skill name

        Returns:
            Skill or None if not found
        """
        return self.skills.get(name)

    def list_skills(self) -> list[Skill]:
        """
        List all registered skills.

        Returns:
            List of all skills
        """
        return list(self.skills.values())

    def expand(self, skill_name: str, args: str = "") -> str:
        """
        Expand skill to full prompt.

        Args:
            skill_name: Name of skill to expand
            args: Optional arguments for skill

        Returns:
            Expanded prompt

        Raises:
            KeyError: If skill not found
        """
        skill = self.skills.get(skill_name)
        if not skill:
            raise KeyError(f"Skill not found: {skill_name}")

        # Check if args required
        if skill.requires_args and not args:
            raise ValueError(f"Skill '{skill_name}' requires arguments")

        # Expand instructions with args
        instructions = skill.instructions

        # Simple template expansion
        # Supports {args} placeholder
        instructions = instructions.replace("{args}", args)

        return instructions

    def parse_skill_command(self, user_input: str) -> tuple[Optional[str], Optional[str]]:
        """
        Parse skill command from user input.

        Supports formats:
        - /skill_name
        - /skill_name arg1 arg2
        - skill:skill_name
        - skill:skill_name(arg1, arg2)

        Args:
            user_input: User input string

        Returns:
            Tuple of (skill_name, args) or (None, None) if not a skill command
        """
        # Check for /skill format
        if user_input.startswith("/"):
            parts = user_input[1:].split(None, 1)
            skill_name = parts[0]
            args = parts[1] if len(parts) > 1 else ""

            if skill_name in self.skills:
                return skill_name, args

        # Check for skill:name format
        skill_pattern = r"^skill:(\w+)(?:\((.*)\))?$"
        match = re.match(skill_pattern, user_input.strip())
        if match:
            skill_name = match.group(1)
            args = match.group(2) or ""

            if skill_name in self.skills:
                return skill_name, args

        return None, None

    def render_system_prompt_block(self) -> str:
        """Return a ``<skills>`` + ``<skills_guidelines>`` block for the system prompt.

        Returns an empty string when no skills are registered.
        """
        if not self.skills:
            return ""

        max_len = max(len(s.name) for s in self.skills.values())
        col = max_len + 2
        lines = []
        for name in sorted(self.skills):
            skill = self.skills[name]
            desc = skill.description or "(no description)"
            lines.append(f"{name:<{col}}— {desc}")

        skills_block = (
            "<skills>\n"
            "Available skills — invoke with /name [args] or reference contextually:\n\n"
            + "\n".join(lines)
            + "\n</skills>"
        )
        guidelines_block = (
            "<skills_guidelines>\n"
            "Skills are reusable workflows. The rules:\n"
            "- Invoke a skill explicitly when the user types /name or says \"use the X skill\"\n"
            "- Apply a skill's instructions implicitly when the user's request clearly matches its intent\n"
            "  (e.g., \"write tests for foo.py\" → apply test skill approach without being told)\n"
            "- Never mention skills by name unless the user asked for them by name\n"
            "- Do not invent skill names that don't exist in the list above\n"
            "</skills_guidelines>"
        )
        return f"{skills_block}\n\n{guidelines_block}"

    def process_input(self, user_input: str) -> tuple[str, bool]:
        """
        Process user input and expand skills if found.

        Args:
            user_input: User input string

        Returns:
            Tuple of (processed_input, was_skill)
        """
        skill_name, args = self.parse_skill_command(user_input)

        if skill_name:
            expanded = self.expand(skill_name, args or "")
            return expanded, True

        return user_input, False
