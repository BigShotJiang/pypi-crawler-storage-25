"""Skill loading from folder-based structure following Agent Skills spec."""

import logging
import re
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Keys we recognise in YAML frontmatter
_FRONTMATTER_KEYS = {"name", "description", "license", "requires_args"}


def _parse_frontmatter(content: str) -> tuple[dict, str]:
    """Return (frontmatter_dict, body) if content starts with '---', else ({}, content)."""
    if not content.startswith("---"):
        return {}, content

    end = content.find("\n---", 3)
    if end == -1:
        return {}, content

    yaml_block = content[3:end].strip()
    body = content[end + 4:].lstrip("\n")

    fm: dict = {}
    for line in yaml_block.splitlines():
        m = re.match(r"^(\w+)\s*:\s*(.+)$", line.strip())
        if m:
            key, val = m.group(1), m.group(2).strip()
            if key not in _FRONTMATTER_KEYS:
                continue
            if key == "requires_args":
                fm[key] = val.lower() in ("true", "yes", "1")
            else:
                fm[key] = val

    return fm, body


@dataclass
class Skill:
    """A skill definition loaded from folder structure following Agent Skills spec.

    Agent Skills are folders containing:
    - SKILL.md: The main skill instructions (required)
    - scripts/: Optional executable scripts
    - resources/: Optional reference materials
    - README.md: Optional description of the skill
    """

    name: str
    instructions: str  # Content from SKILL.md
    description: str = ""  # From README.md, frontmatter, or inferred
    requires_args: bool = False
    examples: list[str] = field(default_factory=list)
    scripts: list[Path] = field(default_factory=list)  # Scripts in scripts/
    resources: list[Path] = field(default_factory=list)  # Files in resources/
    folder_path: Optional[Path] = None  # Path to skill folder
    source: str = ""  # "builtin", "global", "project", or "config"


class SkillLoader:
    """Loads skills from folder-based structure following Agent Skills spec."""

    def __init__(self, skills_dir: Optional[Path] = None):
        """
        Initialize skill loader.

        Args:
            skills_dir: Directory containing skill folders
        """
        self.skills_dir = skills_dir

    def load_skill(self, skill_folder: Path, source: str = "") -> Optional[Skill]:
        """
        Load a skill from a folder following Agent Skills spec.

        Expected structure:
        skill_folder/
            SKILL.md (required)
            README.md (optional)
            scripts/ (optional)
                script1.sh
                script2.py
            resources/ (optional)
                reference.txt
                template.json

        Args:
            skill_folder: Path to skill folder
            source: Origin tag ("builtin", "global", "project", "config")

        Returns:
            Loaded skill or None if invalid
        """
        # Check for required SKILL.md (Agent Skills spec)
        skill_file = skill_folder / "SKILL.md"
        if not skill_file.exists():
            logger.warning(f"Missing SKILL.md in {skill_folder}")
            return None

        # Load SKILL.md content
        with open(skill_file, "r", encoding="utf-8") as f:
            raw_content = f.read()

        # Parse optional YAML frontmatter
        fm, body = _parse_frontmatter(raw_content)

        # Full instructions include the frontmatter so slash-command expansion
        # still receives the original text; body is used for metadata inference.
        instructions = raw_content

        # Determine name (frontmatter > folder name)
        skill_name = fm.get("name") or skill_folder.name

        # Determine description (frontmatter > README.md > first line of body)
        description = fm.get("description", "")
        if not description:
            readme_file = skill_folder / "README.md"
            if readme_file.exists():
                with open(readme_file, "r", encoding="utf-8") as f:
                    description = f.read().strip()
            else:
                first_line = body.split("\n")[0] if body else ""
                description = first_line.strip("# ").strip()

        # Load optional scripts
        scripts_dir = skill_folder / "scripts"
        scripts = []
        if scripts_dir.exists():
            scripts = list(scripts_dir.iterdir())

        # Load optional resources
        resources_dir = skill_folder / "resources"
        resources = []
        if resources_dir.exists():
            resources = list(resources_dir.iterdir())

        # Parse metadata — frontmatter wins, fall back to prose parsing on body
        if "requires_args" in fm:
            requires_args = fm["requires_args"]
        else:
            requires_args = self._parse_requires_args(body)

        examples = self._parse_examples(body)

        return Skill(
            name=skill_name,
            instructions=instructions,
            description=description,
            requires_args=requires_args,
            examples=examples,
            scripts=scripts,
            resources=resources,
            folder_path=skill_folder,
            source=source,
        )

    def _parse_requires_args(self, instructions: str) -> bool:
        """Parse requires_args from SKILL.md metadata section."""
        # Check for metadata section: ## Metadata or ## Meta
        for line in instructions.split("\n"):
            if line.strip().lower().startswith("## metadata"):
                # Look for requires_args in following lines
                for meta_line in instructions.split("\n")[instructions.split("\n").index(line)+1:]:
                    if meta_line.strip().startswith("##"):
                        break
                    if "requires arguments" in meta_line.lower():
                        if "no" in meta_line.lower():
                            return False
                        if "yes" in meta_line.lower() or "true" in meta_line.lower():
                            return True
                break
        
        # Also check for inline metadata format
        if "**Requires arguments**:" in instructions or "**Requires arguments**:" in instructions:
            for line in instructions.split("\n"):
                if "requires arguments" in line.lower():
                    if "no" in line.lower():
                        return False
                    if "yes" in line.lower() or "true" in line.lower():
                        return True
        
        return False

    def _parse_examples(self, instructions: str) -> list[str]:
        """Parse examples from SKILL.md examples section."""
        examples = []
        
        # Look for ## Examples section
        in_examples = False
        in_code_block = False
        
        for line in instructions.split("\n"):
            if "## examples" in line.lower():
                in_examples = True
                continue
            
            if in_examples:
                # Check if we've moved to another section
                if line.strip().startswith("##") and "examples" not in line.lower():
                    break
                
                # Parse code block examples
                if line.strip().startswith("```"):
                    in_code_block = not in_code_block
                    continue
                
                if in_code_block and line.strip():
                    # Remove trailing backticks if present
                    example = line.strip().rstrip("```")
                    if example:
                        examples.append(example)
                
                # Also parse bullet point examples
                if line.strip().startswith("-") and not in_code_block:
                    example = line.strip()[1:].strip().strip('"').strip("'")
                    if example:
                        examples.append(example)
        
        return examples

    def load_all(self, source: str = "") -> dict[str, Skill]:
        """
        Load all skills from directory.

        Args:
            source: Origin tag propagated to each loaded Skill

        Returns:
            Dict mapping skill name to skill
        """
        skills: dict[str, Skill] = {}

        if not self.skills_dir or not self.skills_dir.exists():
            logger.warning(f"Skills directory not found: {self.skills_dir}")
            return skills

        for item in self.skills_dir.iterdir():
            if item.is_dir():
                try:
                    skill = self.load_skill(item, source=source)
                    if skill:
                        skills[skill.name] = skill
                        logger.info(f"Loaded skill: {skill.name}")
                except Exception as e:
                    logger.error(f"Failed to load skill from {item}: {e}")

        return skills

    def load_from_paths(self, paths: list[Path], source: str = "") -> dict[str, Skill]:
        """
        Load skills from multiple directories.

        Args:
            paths: List of directory paths
            source: Origin tag propagated to each loaded Skill

        Returns:
            Dict mapping skill name to skill
        """
        skills = {}

        for path in paths:
            if not path.exists():
                logger.warning(f"Skill path not found: {path}")
                continue

            for item in path.iterdir():
                if item.is_dir():
                    try:
                        skill = self.load_skill(item, source=source)
                        if skill and skill.name not in skills:
                            skills[skill.name] = skill
                            logger.info(f"Loaded skill: {skill.name}")
                        elif skill and skill.name in skills:
                            logger.warning(f"Skill '{skill.name}' already loaded, skipping")
                    except Exception as e:
                        logger.error(f"Failed to load skill from {item}: {e}")

        return skills