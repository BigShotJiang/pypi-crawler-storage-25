---
name: pr
description: Create a GitHub pull request: summarize commits, push branch, open PR
license: builtin
requires_args: false
---

# Pull Request

## When to Use

Use when the user asks to open, create, or submit a pull request for the current branch.

## Instructions

1. **Check branch**: Confirm you are not on main/master. If so, ask the user which branch to use.
2. **Summarise changes**: Run `git log --oneline <base>...HEAD` to list commits since the base branch.
3. **Push**: Push the current branch with `git push -u origin <branch>` if not already pushed.
4. **Open PR**: Use `gh pr create` with a concise title (≤70 chars) and a body that covers:
   - What changed and why (2-4 bullet points)
   - Test plan (what was checked)
5. **Return URL**: Output the PR URL so the user can review it.

Never force-push to main/master.

## Examples

```
/pr
```
