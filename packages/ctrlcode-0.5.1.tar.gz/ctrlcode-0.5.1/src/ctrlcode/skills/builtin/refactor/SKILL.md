# Refactor

Refactor the code: {args}

## Instructions

1. Read and understand the current implementation
2. Identify improvement opportunities:
   - Code duplication
   - Complex functions (high cyclomatic complexity)
   - Poor naming
   - Missing abstractions
   - Violation of SOLID principles
3. Propose refactoring changes with:
   - Clear explanation of the issue
   - Proposed solution
   - Benefits of the change
   - Any trade-offs
4. Make the changes incrementally
5. Ensure tests still pass after each change

Focus on improving:
- Readability
- Maintainability
- Testability
- Performance (where applicable)

## Examples

```
/refactor src/ctrlcode/session/manager.py
skill:refactor(process_turn method)
```

## Metadata

- **Requires arguments**: Yes
