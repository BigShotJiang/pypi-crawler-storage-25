# Review

Review the current code changes.

## Instructions

1. Run `git diff` to see all changes
2. Analyze the changes for:
   - Code quality and style
   - Potential bugs or edge cases
   - Security vulnerabilities
   - Performance issues
   - Missing error handling
   - Test coverage gaps
3. **Output the complete review directly in your response** with:
   - Positive observations (what's good)
   - Issues found (severity: critical, major, minor)
   - Specific suggestions for improvement
   - Code examples where helpful

Format your review clearly with sections for each category.

## Examples

```
/review
skill:review
```

## Metadata

- **Requires arguments**: No
