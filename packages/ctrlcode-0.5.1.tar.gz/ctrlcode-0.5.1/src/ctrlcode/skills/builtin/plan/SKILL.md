---
name: plan
description: Write a tasks/todo.md plan with checkboxes before implementing anything
license: builtin
requires_args: true
---

# Plan

## When to Use

Use before starting any non-trivial task (3+ steps or architectural decisions). Write
a plan first, confirm with the user, then implement.

## Instructions

1. **Write the plan**: Create `tasks/todo.md` with a clear title and checkable items:
   - Break work into discrete, verifiable steps
   - Each item should be completable and testable independently
   - Note any dependencies between steps
2. **Check in**: Present the plan and ask for confirmation before writing any code.
3. **Implement**: Work through items in order, marking each `[x]` when done.
4. **Document results**: Add a results section summarising what was done.

If anything goes sideways mid-implementation, stop and re-plan rather than pushing through.

## Examples

```
/plan add rate limiting to the API
```
```
/plan refactor the session manager to use middleware
```
