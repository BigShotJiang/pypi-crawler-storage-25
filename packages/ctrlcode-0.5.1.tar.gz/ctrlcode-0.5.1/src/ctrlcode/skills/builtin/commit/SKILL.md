# Commit

Create a git commit with a semantic commit message.

## Overview

This skill helps create meaningful git commits by analyzing code changes and generating semantic commit messages that follow best practices.

## Instructions

When invoked, follow these steps:

1. **Analyze the current state**
   - Run `git status` to see all changes (staged and unstaged)
   - Run `git diff` to review the actual changes
   - Run `git log --oneline -5` to see recent commit message style

2. **Create a semantic commit message**
   - Summarize the nature of changes (new feature, bug fix, refactor, etc.)
   - Keep it concise (1-2 sentences)
   - Focus on the "why" rather than the "what"
   - Follow the commit style of this repository
   - Use semantic prefixes: `feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `chore:`

3. **Stage and commit**
   - Stage relevant files
   - **Never** stage files that contain secrets (e.g., `.env`, `*.key`, credentials)
   - Create the commit with the message ending with:
     ```
     Co-Authored-By: Ctrl+Code <noreply@ctrl.code>
     ```

## Important Guidelines

- **Security first**: Do NOT commit files that contain secrets or sensitive data
- **No pushes**: Do NOT push unless explicitly requested by the user
- **Quality**: Ensure the commit message is clear and follows the repository's conventions
- **Scope**: Commit related changes together, but avoid mixing unrelated modifications

## Examples

```
/commit
skill:commit
```

## Metadata

- **Requires arguments**: No
- **Side effects**: Modifies git repository (stages files, creates commits)