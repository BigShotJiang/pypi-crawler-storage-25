# Test

Run tests and analyze results.

## Instructions

1. Identify the test framework (pytest, unittest, jest, etc.)
2. Run the test suite
3. If tests fail:
   - Show the failing tests
   - Analyze the failure reasons
   - Suggest fixes
4. If tests pass:
   - Report test coverage if available
   - Suggest additional test cases for edge cases
5. Check for:
   - Missing tests for new functionality
   - Flaky tests
   - Test performance issues

Provide a summary with test counts, pass rate, and recommendations.

## Examples

```
/test
skill:test
```

## Metadata

- **Requires arguments**: No
