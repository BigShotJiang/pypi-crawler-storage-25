# Docs

Document: {args}

## Instructions

1. Use search_code and read_file to find the target in the codebase
2. Read only what you need to understand its purpose and public interface
3. Write concise documentation **directly in your response** — do not write to a file
4. Keep it short: aim for under 300 words
5. Include only:
   - One-sentence description of what it does
   - Constructor/init params (if relevant)
   - Key public methods with brief descriptions
   - One minimal usage example
   - Any non-obvious gotchas

Do not include exhaustive API tables, pipeline stage diagrams, StreamEvent catalogs, or example analysis reports unless the user explicitly asks for them.

## Examples

```
/docs ContextWindowMonitor
skill:docs(MyClass)
```

## Metadata

- **Requires arguments**: Yes
