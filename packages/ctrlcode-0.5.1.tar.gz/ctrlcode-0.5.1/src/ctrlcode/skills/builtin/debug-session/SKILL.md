---
name: debug-session
description: Structured debugging workflow: reproduce, isolate, root-cause, fix, verify
license: builtin
requires_args: false
---

# Debug Session

## When to Use

Use when the user reports a bug, unexpected behaviour, or failing test and wants a
systematic fix, not just a patch.

## Instructions

1. **Reproduce**: Read the error message or test output carefully. Run the failing command.
2. **Isolate**: Narrow the scope — read the relevant files, identify the failing call site.
3. **Root cause**: Trace through the logic. Don't guess; confirm with a read or run.
4. **Fix**: Make the minimal change that resolves the root cause. Avoid side-effects.
5. **Verify**: Re-run the failing test or command and show the output.

Never apply a workaround if you can find the actual cause.

## Examples

```
/debug-session TypeError in src/foo.py line 42
```
