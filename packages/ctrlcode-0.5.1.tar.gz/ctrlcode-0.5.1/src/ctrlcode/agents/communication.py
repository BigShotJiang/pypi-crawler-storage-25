"""Agent communication protocol for message passing between agents."""

from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from enum import Enum
import asyncio
import json
import logging

from harnessutils import ConversationManager, Message, TextPart
from harnessutils.storage import FilesystemStorage, MemoryStorage
from harnessutils.config import HarnessConfig, StorageConfig

logger = logging.getLogger(__name__)


class AgentVerbosity(Enum):
    """Control agent event streaming verbosity."""

    SILENT = 0      # Only workflow events
    WORKFLOW = 1    # + agent summaries (default)
    DETAILED = 2    # Stream all internal events


@dataclass
class AgentMessage:
    """Message passed between agents."""

    from_agent: str
    to_agent: str
    message_type: str  # "task", "result", "feedback", "question"
    payload: dict[str, Any]
    context: dict[str, Any] = field(default_factory=dict)
    message_id: str | None = None

    def __post_init__(self):
        """Generate message ID if not provided."""
        if self.message_id is None:
            import uuid
            self.message_id = str(uuid.uuid4())


class AgentBus:
    """Event bus for inter-agent communication."""

    def __init__(self):
        """Initialize agent bus."""
        self.message_queue: deque[AgentMessage] = deque()
        self.handlers: dict[str, Callable[[AgentMessage], Awaitable[Any]]] = {}
        self.message_log: list[AgentMessage] = []

    async def send(self, message: AgentMessage) -> Any:
        """
        Send message to target agent.

        Args:
            message: AgentMessage to send

        Returns:
            Handler result if handler exists, None otherwise
        """
        # Log message
        self.message_log.append(message)

        # Add to queue
        self.message_queue.append(message)

        # Find handler for target agent
        if message.to_agent in self.handlers:
            handler = self.handlers[message.to_agent]
            return await handler(message)

        return None

    def register_handler(
        self,
        agent_name: str,
        handler: Callable[[AgentMessage], Awaitable[Any]]
    ):
        """
        Register message handler for agent.

        Args:
            agent_name: Agent identifier
            handler: Async function to handle messages
        """
        self.handlers[agent_name] = handler

    def unregister_handler(self, agent_name: str):
        """
        Remove message handler for agent.

        Args:
            agent_name: Agent identifier
        """
        if agent_name in self.handlers:
            del self.handlers[agent_name]

    def get_messages_for_agent(self, agent_name: str) -> list[AgentMessage]:
        """
        Get all messages sent to specific agent.

        Args:
            agent_name: Agent identifier

        Returns:
            List of messages
        """
        return [msg for msg in self.message_log if msg.to_agent == agent_name]

    def get_conversation(
        self,
        agent1: str,
        agent2: str
    ) -> list[AgentMessage]:
        """
        Get all messages between two agents.

        Args:
            agent1: First agent identifier
            agent2: Second agent identifier

        Returns:
            List of messages in chronological order
        """
        return [
            msg for msg in self.message_log
            if (msg.from_agent == agent1 and msg.to_agent == agent2) or
               (msg.from_agent == agent2 and msg.to_agent == agent1)
        ]

    def clear(self):
        """Clear all messages and queue."""
        self.message_queue.clear()
        self.message_log.clear()


class AgentCoordinator:
    """Coordinates agent spawning and communication."""

    def __init__(
        self,
        agent_registry: Any,
        storage_path: Path | str,
        provider: Any,
        tool_registry: Any | None = None,
        max_delegation_depth: int = 2,
        trajectories_dir: Path | None = None,
        parent_session_id: str | None = None,
    ):
        """
        Initialize coordinator.

        Args:
            agent_registry: AgentRegistry instance
            storage_path: Base path for agent conversation storage
            provider: LLM provider instance
            tool_registry: Optional ToolRegistry for tool access
            max_delegation_depth: Global default maximum agent delegation depth
            trajectories_dir: If set, write per-agent trajectory JSONL here
            parent_session_id: Session ID that spawned this coordinator (for cross-referencing)
        """
        self.registry = agent_registry
        self.bus = AgentBus()
        self.active_agents: dict[str, Any] = {}
        self.storage_path = Path(storage_path)
        self.provider = provider
        self.tool_registry = tool_registry
        self.max_delegation_depth = max_delegation_depth
        self.trajectories_dir = trajectories_dir
        self.parent_session_id = parent_session_id
        self.conversation_managers: dict[str, ConversationManager] = {}

    def _emit_agent_event(
        self,
        event: Any,
        agent_id: str,
        verbosity: AgentVerbosity,
        event_callback: Callable | None = None
    ):
        """
        Filter and emit agent events based on verbosity level.

        Args:
            event: StreamEvent to potentially emit
            agent_id: Agent identifier
            verbosity: Verbosity level
            event_callback: Optional callback for events
        """
        if not event_callback:
            return

        # SILENT: no internal events
        if verbosity == AgentVerbosity.SILENT:
            return

        # WORKFLOW: only summaries and major events
        if verbosity == AgentVerbosity.WORKFLOW:
            if event.type in ["continuation_complete", "tool_result", "usage"]:
                event_callback(event)
            return

        # DETAILED: all events
        if verbosity == AgentVerbosity.DETAILED:
            event_callback(event)

    async def spawn_agent(
        self,
        agent_type: str,
        task: dict[str, Any],
        agent_id: str | None = None,
        verbosity: AgentVerbosity = AgentVerbosity.WORKFLOW,
        event_callback: Callable | None = None,
        depth: int = 0,
        parent_agent_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Spawn specialized agent to execute task.

        Args:
            agent_type: Type of agent (planner, coder, reviewer, executor)
            task: Task data for agent
            agent_id: Optional agent identifier
            verbosity: Event streaming verbosity level
            event_callback: Optional callback for streaming events
            depth: Current delegation depth (0 = top-level)
            parent_agent_id: ID of the agent that spawned this one (for cross-referencing)

        Returns:
            Agent execution result
        """
        # Get agent configuration
        agent_config = self.registry.get_agent_configs()[agent_type]

        # Generate agent ID if not provided
        if agent_id is None:
            import uuid
            agent_id = f"{agent_type}-{uuid.uuid4().hex[:8]}"

        # Create harness-utils config from agent config
        harness_config = HarnessConfig()
        harness_config.pruning.prune_protect = agent_config.prune_protect
        harness_config.pruning.prune_minimum = agent_config.prune_minimum
        harness_config.truncation.max_lines = agent_config.max_lines
        harness_config.compaction.use_predictive = agent_config.use_predictive

        # Create storage scoped to agent_id — prevents collision when multiple
        # agents of the same type run concurrently or recursively.
        storage: FilesystemStorage | MemoryStorage
        if agent_type in ["planner", "coder", "reviewer"]:
            # Persistent storage — each agent gets its own subdirectory
            storage_config = StorageConfig(
                base_path=self.storage_path / "agents" / agent_id
            )
            storage = FilesystemStorage(storage_config)
        else:
            # Ephemeral storage for executor, orchestrator
            storage = MemoryStorage()

        # Create ConversationManager for this agent
        conv_manager = ConversationManager(
            storage=storage,
            config=harness_config
        )

        # Create conversation
        conv = conv_manager.create_conversation(
            project_id=f"agent-{agent_type}"
        )
        conv_id = conv.id

        # Write spawn index entry for session replay cross-referencing.
        # JSONL (one record per line) is append-safe for concurrent parallel agents.
        self._append_spawn_index({
            "agent_id": agent_id,
            "agent_type": agent_type,
            "parent_agent_id": parent_agent_id,
            "parent_session_id": self.parent_session_id,
            "depth": depth,
            "conv_id": conv_id,
            "started_at": datetime.now(timezone.utc).isoformat(),
        })

        # Store conversation manager
        self.conversation_managers[agent_id] = conv_manager

        # Load system prompt
        system_prompt = self.registry.load_system_prompt(agent_type)

        # Add system prompt as first message
        system_msg = Message(id="system", role="system")  # type: ignore[arg-type]
        system_msg.add_part(TextPart(text=system_prompt))
        conv_manager.add_message(conv_id, system_msg)

        # Add task as user message
        task_description = task.get("description", str(task))
        task_message = Message(id="task", role="user")
        task_message.add_part(TextPart(text=task_description))
        conv_manager.add_message(conv_id, task_message)

        # Get filtered tool definitions
        if self.tool_registry:
            tools = self.tool_registry.get_tool_definitions_filtered(agent_config.tools)
        else:
            tools = []
            logger.warning(f"No tool_registry provided for agent {agent_type}")

        # Execute ReAct loop
        try:
            from ..tools.executor import ToolExecutor
            from ..tools.registry import ParallelMode
            from .react_loop import AgentReActLoop
            from .result_parser import AgentResultParser

            # Create tool executor
            if not self.tool_registry:
                raise RuntimeError(f"No tool_registry available for agent {agent_type}")
            tool_executor = ToolExecutor(self.tool_registry)

            # Register spawn_agent as a depth-aware builtin for this agent.
            # Effective max depth: per-agent override takes precedence over global default.
            # max_delegation_depth=0 on an AgentConfig means delegation is disabled.
            effective_max_depth = (
                agent_config.max_delegation_depth
                if agent_config.max_delegation_depth is not None
                else self.max_delegation_depth
            )

            async def _spawn_agent_handler(agent_type: str, task: str) -> dict[str, Any]:
                if depth >= effective_max_depth:
                    return {
                        "error": (
                            f"Max delegation depth ({effective_max_depth}) reached. "
                            f"Complete this task directly without spawning sub-agents."
                        )
                    }
                result = await self.spawn_agent(
                    agent_type=agent_type,
                    task={"description": task},
                    depth=depth + 1,
                    parent_agent_id=agent_id,
                )
                # Return a concise summary + cross-reference so the LLM and replay tools
                # can follow the chain: parent conv → child agent_id → child conv.
                return {
                    "agent_id": result.get("agent_id"),
                    "agent_type": result.get("agent_type"),
                    "status": result.get("status"),
                    "depth": depth + 1,
                    "summary": (
                        result.get("files_changed")
                        or result.get("task_graph")
                        or result.get("review")
                        or result.get("validation")
                        or result.get("output", "")
                    ),
                }

            self.tool_registry.register_builtin(
                name="spawn_agent",
                description=(
                    "Delegate a subtask to a specialized sub-agent. "
                    "Use to parallelize independent work or hand off to a specialist. "
                    f"Current depth: {depth}/{effective_max_depth}."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "agent_type": {
                            "type": "string",
                            "enum": ["planner", "coder", "reviewer", "executor"],
                            "description": "Type of agent to spawn",
                        },
                        "task": {
                            "type": "string",
                            "description": "Full task description for the sub-agent",
                        },
                    },
                    "required": ["agent_type", "task"],
                },
                function=_spawn_agent_handler,
                parallel_mode=ParallelMode.NEVER,
                overwrite=True,
            )

            # Execute ReAct loop — stream events, forward to callback, then collect
            loop = AgentReActLoop()

            async def _forward_events(gen):
                async for ev in gen:
                    if event_callback:
                        self._emit_agent_event(ev, agent_id, verbosity, event_callback)
                    yield ev

            execution_result = await AgentReActLoop.collect(
                _forward_events(loop.stream(
                    provider=self.provider,
                    conv_manager=conv_manager,
                    conv_id=conv_id,
                    tool_executor=tool_executor,
                    tools=tools,
                    allowed_tools=agent_config.tools,
                    max_continuations=50,
                    max_output_tokens=agent_config.max_output_tokens or 32_000,
                ))
            )

            # Parse result based on agent type
            if agent_type == "planner":
                parsed = AgentResultParser.parse_planner_result(
                    execution_result.assistant_text,
                    execution_result.tool_calls
                )
                result = {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "status": "completed",
                    "task_graph": parsed,
                    "conv_id": conv_id,
                    "depth": depth,
                    "usage_tokens": execution_result.usage_tokens
                }
            elif agent_type == "coder":
                parsed = AgentResultParser.parse_coder_result(
                    execution_result.assistant_text,
                    execution_result.tool_calls
                )
                result = {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "status": "completed",
                    "files_changed": parsed,
                    "conv_id": conv_id,
                    "depth": depth,
                    "usage_tokens": execution_result.usage_tokens
                }
            elif agent_type == "reviewer":
                parsed = AgentResultParser.parse_reviewer_result(
                    execution_result.assistant_text,
                    execution_result.tool_calls
                )
                result = {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "status": "completed",
                    "review": parsed,
                    "conv_id": conv_id,
                    "depth": depth,
                    "usage_tokens": execution_result.usage_tokens
                }
            elif agent_type == "executor":
                parsed = AgentResultParser.parse_executor_result(
                    execution_result.assistant_text,
                    execution_result.tool_calls
                )
                result = {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "status": "completed",
                    "validation": parsed,
                    "conv_id": conv_id,
                    "depth": depth,
                    "usage_tokens": execution_result.usage_tokens
                }
            else:
                # Generic result
                result = {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "status": "completed",
                    "output": execution_result.assistant_text,
                    "tool_calls": execution_result.tool_calls,
                    "conv_id": conv_id,
                    "depth": depth,
                    "usage_tokens": execution_result.usage_tokens
                }

            # Write trajectory record for this sub-agent if enabled.
            # Mirrors TrajectoryMiddleware format with additional delegation metadata.
            if self.trajectories_dir:
                self._write_agent_trajectory(
                    agent_id=agent_id,
                    agent_type=agent_type,
                    conv_manager=conv_manager,
                    conv_id=conv_id,
                    system_prompt=system_prompt,
                    depth=depth,
                    parent_agent_id=parent_agent_id,
                    usage_tokens=execution_result.usage_tokens,
                    continuation_count=execution_result.continuation_count,
                )

        except Exception as e:
            logger.error(f"Agent execution failed: {e}", exc_info=True)
            result = {
                "agent_id": agent_id,
                "agent_type": agent_type,
                "status": "error",
                "error": str(e),
                "task": task,
                "conv_id": conv_id,
                "depth": depth,
            }

        # Track active agent
        self.active_agents[agent_id] = {
            "type": agent_type,
            "config": agent_config,
            "result": result,
            "conv_manager": conv_manager,
            "conv_id": conv_id,
        }

        return result

    async def spawn_agents_parallel(
        self,
        agents_tasks: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """
        Spawn multiple agents in parallel.

        Args:
            agents_tasks: List of dicts with 'type' and 'task' keys

        Returns:
            List of agent execution results
        """
        tasks = [
            self.spawn_agent(
                agent_type=agent_task["type"],
                task=agent_task["task"]
            )
            for agent_task in agents_tasks
        ]

        results = await asyncio.gather(*tasks)
        return list(results)

    def get_agent_status(self, agent_id: str) -> dict[str, Any] | None:
        """
        Get status of agent.

        Args:
            agent_id: Agent identifier

        Returns:
            Agent status dict or None if not found
        """
        return self.active_agents.get(agent_id)

    def cleanup_agent(self, agent_id: str):
        """
        Remove agent from active tracking.

        Args:
            agent_id: Agent identifier
        """
        if agent_id in self.active_agents:
            del self.active_agents[agent_id]

    def _append_spawn_index(self, entry: dict[str, Any]) -> None:
        """Append one record to the spawn index JSONL for session replay.

        JSONL is append-only so concurrent parallel agent spawns are safe.
        The index maps agent_id → parent chain, enabling tree traversal.
        """
        try:
            index_path = self.storage_path / "agents" / "spawn_index.jsonl"
            index_path.parent.mkdir(parents=True, exist_ok=True)
            with index_path.open("a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as exc:
            logger.warning(f"Failed to write spawn index: {exc}")

    def _write_agent_trajectory(
        self,
        agent_id: str,
        agent_type: str,
        conv_manager: ConversationManager,
        conv_id: str,
        system_prompt: str,
        depth: int,
        parent_agent_id: str | None,
        usage_tokens: int,
        continuation_count: int,
    ) -> None:
        """Write a trajectory record for a completed sub-agent.

        Format mirrors TrajectoryMiddleware (ShareGPT conversations array) so
        sub-agent trajectories are compatible with the same training pipelines.
        Additional fields (agent_id, depth, parent_agent_id) link records into
        the delegation tree for curriculum filtering.
        """
        from ..session.middleware.trajectory import _build_conversations

        try:
            assert self.trajectories_dir is not None
            messages = conv_manager.to_model_format(conv_id)
            record = {
                "conversations": _build_conversations(system_prompt, messages),
                # Delegation metadata for replay and curriculum design
                "agent_id": agent_id,
                "agent_type": agent_type,
                "parent_agent_id": parent_agent_id,
                "parent_session_id": self.parent_session_id,
                "depth": depth,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "usage_tokens": usage_tokens,
                "continuation_count": continuation_count,
            }
            self.trajectories_dir.mkdir(parents=True, exist_ok=True)
            out_file = self.trajectories_dir / f"{agent_id}.jsonl"
            with out_file.open("a") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as exc:
            logger.warning(f"Failed to write agent trajectory for {agent_id}: {exc}")
