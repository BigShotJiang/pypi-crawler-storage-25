"""Reusable ReAct loop execution for agents and sessions."""

import asyncio
import json
import logging
import uuid
from collections import deque
from dataclasses import dataclass
from typing import Any, AsyncIterator, Callable, TYPE_CHECKING

from harnessutils import ConversationManager, Message, TextPart

from ..providers.base import Provider, StreamEvent
from ..tools.executor import ToolExecutor
from .tool_recovery import patch_tool_calls

if TYPE_CHECKING:
    from ..session.manager import LLMClientAdapter

logger = logging.getLogger(__name__)


def _gen_id() -> str:
    return f"msg_{uuid.uuid4().hex[:12]}"


def _safe_json(s: str) -> dict:
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return {}


def _format_tool_preview(tool: str, input: dict) -> str:
    """One-line description of what a tool is about to do."""
    path = input.get("path", "") or input.get("file_path", "")
    basename = path.split("/")[-1] if path else ""

    match tool:
        case "read_file" | "get_file_info":
            return f"Reading {basename or path}"
        case "write_file":
            return f"Writing {basename or path}"
        case "update_file":
            return f"Updating {basename or path}"
        case "list_directory":
            return f"Listing {basename or path or '.'}"
        case "search_files" | "search_code":
            pattern = input.get("pattern", input.get("query", "?"))
            return f"Searching '{pattern[:40]}'"
        case "run_command":
            cmd = input.get("command", "?")
            return f"$ {cmd[:50]}"
        case "fetch":
            url = input.get("url", "?")
            return f"Fetching {url[:60]}"
        case "compact_conversation":
            return "Compacting context…"
        case _:
            return tool.replace("_", " ").title()


@dataclass
class ReActResult:
    """Result from executing a ReAct loop."""

    assistant_text: str
    tool_calls: list[dict[str, Any]]
    usage_tokens: int
    continuation_count: int


class AgentReActLoop:
    """Execute ReAct (Reason + Act) loops with tool calling."""

    async def stream(
        self,
        provider: Provider,
        conv_manager: ConversationManager,
        conv_id: str,
        tool_executor: ToolExecutor,
        tools: list[dict[str, Any]],
        system_prompt_msg: dict | None = None,
        allowed_tools: list[str] | None = None,
        max_continuations: int = 50,
        doom_loop_threshold: int = 3,
        tool_delay: float = 0.1,
        compaction_client: "LLMClientAdapter | None" = None,
        max_output_tokens: int = 32_000,
        pre_tool_hook: Callable | None = None,
        post_tool_hook: Callable | None = None,
        before_complete_hook: Callable | None = None,
        middleware_stack=None,  # MiddlewareStack | None — avoids circular import
    ) -> AsyncIterator[StreamEvent]:
        """Stream ReAct loop events.

        Yields all provider events pass-through, plus:
          task_summary, doom_loop, react_limit, compaction, continuation_complete,
          iteration_warning, before_complete_blocked
        """
        iteration = 0
        recent_call_keys: deque[str] = deque(maxlen=doom_loop_threshold)
        write_path_tally: dict[str, int] = {}
        all_tool_calls: list[dict] = []
        usage_tokens = 0
        last_msg_id: str | None = None
        last_continuation_text: list[str] = []  # fallback for silent final turns (iter > 0 only)

        while iteration <= max_continuations:
            # Build messages for this iteration
            messages = conv_manager.to_model_format(conv_id)
            messages = patch_tool_calls(messages, conv_manager.get_messages(conv_id))
            if system_prompt_msg:
                messages = [system_prompt_msg] + messages

            # Stream one LLM turn
            assistant_text: list[str] = []
            tool_calls: list[dict] = []
            current_tool: dict | None = None
            finish_reason = "end_turn"

            async for event in provider.stream(messages, tools=tools, max_tokens=max_output_tokens):
                yield event  # pass-through — TUI sees everything

                if event.type == "text":
                    assistant_text.append(event.data["text"])
                elif event.type == "finish":
                    finish_reason = event.data.get("reason", "end_turn")
                elif event.type == "usage":
                    usage_tokens += event.data.get("usage", {}).get("completion_tokens", 0)
                elif event.type == "tool_call_start":
                    current_tool = {
                        "tool": event.data["tool"],
                        "call_id": event.data["call_id"],
                        "input": "",
                    }
                elif event.type == "tool_call_delta":
                    if current_tool:
                        current_tool["input"] += event.data.get("delta", "")
                elif event.type == "content_block_stop":
                    if current_tool:
                        current_tool["input"] = _safe_json(current_tool["input"])
                        tool_calls.append(current_tool)
                        all_tool_calls.append(current_tool)
                        current_tool = None

            # Track last non-empty continuation text (iter > 0 only, avoids re-emitting iter 0)
            if assistant_text and iteration > 0:
                last_continuation_text = list(assistant_text)

            # Persist assistant turn
            asst_msg = Message(id=_gen_id(), role="assistant")
            if assistant_text:
                asst_msg.add_part(TextPart(text="".join(assistant_text)))
            # Record pending tool calls for crash-recovery — see tool_recovery.py
            # ── Termination: mechanical ───────────────────────────────────
            # Only terminate when the model explicitly signals it's done (end_turn).
            # Do NOT terminate just because there are no tool calls — the model may
            # produce reasoning/thinking text between tool calls. Terminating on
            # `not tool_calls` causes premature exit on multi-step tasks.
            if finish_reason == "end_turn":
                # Model gave empty response mid-continuation — nudge it to complete.
                # This happens when the model says "Let me read X" + calls tools, then
                # produces nothing in the following iteration before ending the turn.
                if not assistant_text and iteration > 0 and iteration < max_continuations:
                    nudge_msg = Message(id=_gen_id(), role="user")
                    nudge_msg.add_part(TextPart(text=(
                        "[System: You have not yet provided your response. "
                        "Please provide your complete answer now based on the information gathered above.]"
                    )))
                    conv_manager.add_message(conv_id, nudge_msg)
                    iteration += 1
                    continue

                # Use final-turn text, or last continuation text if model ended silently
                summary = "".join(assistant_text) or "".join(last_continuation_text)

                # Run before_complete_hook — can block completion if guards aren't satisfied
                # (e.g. pending todos, unrun verification commands).
                if before_complete_hook and summary and iteration < max_continuations:
                    block_reason = await before_complete_hook(summary)
                    if block_reason:
                        # Persist assistant response before blocking — without this the model
                        # loses its own previous text and repeats the same answer on every iteration.
                        if asst_msg.parts:
                            conv_manager.add_message(conv_id, asst_msg)
                        block_msg = Message(id=_gen_id(), role="user")
                        block_msg.add_part(TextPart(text=f"[System: Not done yet] {block_reason}"))
                        conv_manager.add_message(conv_id, block_msg)
                        yield StreamEvent(
                            type="before_complete_blocked",
                            data={"reason": block_reason},
                        )
                        iteration += 1
                        continue

                if summary:
                    yield StreamEvent(
                        type="task_summary",
                        data={"summary": summary},
                    )
                break

            # ── Safety cap ────────────────────────────────────────────────
            if iteration >= max_continuations:
                yield StreamEvent(type="react_limit", data={"iterations": iteration})
                break

            # ── Persist assistant turn before tool execution ───────────────
            # Without this the model has no context of its own previous responses
            # and re-introduces itself on every iteration.
            if asst_msg.parts:
                conv_manager.add_message(conv_id, asst_msg)

            # ── Execute tools ─────────────────────────────────────────────
            task_done = False

            # Filter allowed tools and run pre-execution guards (doom loop, path tally)
            executable: list[dict] = []
            for tool_call in tool_calls:
                if allowed_tools and tool_call["tool"] not in allowed_tools:
                    continue

                # Doom loop guard — same (tool, args) N times in a row
                call_key = tool_call["tool"] + "|" + json.dumps(
                    tool_call["input"], sort_keys=True
                )
                recent_call_keys.append(call_key)
                if (
                    len(recent_call_keys) == doom_loop_threshold
                    and len(set(recent_call_keys)) == 1
                ):
                    yield StreamEvent(
                        type="doom_loop",
                        data={"tool": tool_call["tool"], "count": doom_loop_threshold},
                    )
                    task_done = True
                    break

                # Path-write tally — same path written/updated too many times
                _write_tools = {"write_file", "update_file"}
                if tool_call["tool"] in _write_tools:
                    _path = tool_call["input"].get("path", "")
                    if _path:
                        _tally_key = f"{tool_call['tool']}|{_path}"
                        write_path_tally[_tally_key] = write_path_tally.get(_tally_key, 0) + 1
                        if write_path_tally[_tally_key] > doom_loop_threshold:
                            result_msg = Message(id=_gen_id(), role="user")
                            result_msg.add_part(TextPart(text=(
                                f"[Tool: {tool_call['tool']}]\n"
                                f"Error: '{_path}' has been written {write_path_tally[_tally_key]} times "
                                f"this session. Stop rewriting it — the file is done. "
                                f"Move on to the next task."
                            )))
                            conv_manager.add_message(conv_id, result_msg)
                            yield StreamEvent(
                                type="tool_result",
                                data={
                                    "tool": tool_call["tool"],
                                    "input": tool_call["input"],
                                    "success": False,
                                    "result": f"Repeated write to '{_path}' blocked — move on.",
                                    "continuation": iteration > 0,
                                    "continuation_index": iteration,
                                },
                            )
                            continue

                executable.append(tool_call)

            if task_done:
                break

            # Classify into serial groups and execute (with parallel batching within groups)
            groups = tool_executor.classify_batch(executable)
            first_group = True
            for group in groups:
                if not first_group and tool_delay > 0:
                    await asyncio.sleep(tool_delay)
                first_group = False

                if len(group) == 1:
                    # Serial path — single tool
                    tool_call = group[0]
                    if iteration > 0:
                        yield StreamEvent(
                            type="tool_preview",
                            data={"description": _format_tool_preview(tool_call["tool"], tool_call["input"])},
                        )
                    if pre_tool_hook:
                        async for ev in pre_tool_hook(tool_call):
                            yield ev
                    result = await tool_executor.execute(
                        tool_name=tool_call["tool"],
                        arguments=tool_call["input"],
                        call_id=tool_call["call_id"],
                    )
                    yield StreamEvent(
                        type="tool_result",
                        data={
                            "tool": tool_call["tool"],
                            "call_id": tool_call["call_id"],
                            "input": tool_call["input"],
                            "success": result.success,
                            "result": result.result if result.success else result.error,
                            "continuation": iteration > 0,
                            "continuation_index": iteration,
                        },
                    )
                    if post_tool_hook:
                        async for ev in post_tool_hook(tool_call, result):
                            yield ev
                    result_msg = Message(id=_gen_id(), role="user")
                    result_text = f"[Tool: {tool_call['tool']}]\n"
                    result_text += (
                        f"Result: {result.result}" if result.success else f"Error: {result.error}"
                    )
                    result_msg.add_part(TextPart(text=result_text))
                    conv_manager.add_message(conv_id, result_msg)
                    if tool_call["tool"] == "compact_conversation" and result.success:
                        yield StreamEvent(type="agent_compaction", data={"result": result.result})

                else:
                    # Parallel path — emit previews first, then execute concurrently
                    if iteration > 0:
                        for tc in group:
                            yield StreamEvent(
                                type="tool_preview",
                                data={"description": _format_tool_preview(tc["tool"], tc["input"])},
                            )
                    batch_results = await tool_executor.execute_parallel_group(
                        group, pre_tool_hook, post_tool_hook
                    )
                    for (result, hook_events), tool_call in zip(batch_results, group):
                        for ev in hook_events:
                            yield ev
                        yield StreamEvent(
                            type="tool_result",
                            data={
                                "tool": tool_call["tool"],
                                "call_id": tool_call["call_id"],
                                "input": tool_call["input"],
                                "success": result.success,
                                "result": result.result if result.success else result.error,
                                "continuation": iteration > 0,
                                "continuation_index": iteration,
                            },
                        )
                        result_msg = Message(id=_gen_id(), role="user")
                        result_text = f"[Tool: {tool_call['tool']}]\n"
                        result_text += (
                            f"Result: {result.result}" if result.success else f"Error: {result.error}"
                        )
                        result_msg.add_part(TextPart(text=result_text))
                        conv_manager.add_message(conv_id, result_msg)

            # ── Wrap-up warning at 80% of iteration cap ──────────────────
            warn_threshold = max(1, int(max_continuations * 0.8))
            if iteration == warn_threshold:
                warn_msg = Message(id=_gen_id(), role="user")
                warn_msg.add_part(TextPart(text=(
                    f"[System: You have used {iteration} of {max_continuations} iterations. "
                    f"Wrap up now: commit any in-progress changes with git, write a brief "
                    f".ctrlcode/progress.md noting what was done and what remains, "
                    f"then respond with a final summary without calling any more tools.]"
                )))
                conv_manager.add_message(conv_id, warn_msg)
                yield StreamEvent(
                    type="iteration_warning",
                    data={"iteration": iteration, "limit": max_continuations},
                )

            # ── Mid-task compaction ───────────────────────────────────────
            # Tier 3: LLM summarization if needed (only if adapter provided)
            if compaction_client is not None:
                from harnessutils.models.usage import Usage

                usage_obj = Usage(input=0, output=usage_tokens)
                if conv_manager.needs_compaction(conv_id, usage_obj):
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(
                        None,
                        lambda: conv_manager.compact(
                            conv_id,
                            compaction_client,
                            parent_message_id=last_msg_id,
                            auto_mode=True,
                        ),
                    )
                    yield StreamEvent(type="compaction", data={"tier": 3})

            iteration += 1

        yield StreamEvent(
            type="continuation_complete",
            data={"iterations": iteration, "tool_count": len(all_tool_calls)},
        )

    @staticmethod
    async def collect(stream_gen: AsyncIterator[StreamEvent]) -> ReActResult:
        """Collect a stream() generator into a ReActResult (for sub-agents)."""
        text_parts: list[str] = []
        tool_calls: list[dict] = []
        usage_tokens = 0
        continuation_count = 0

        async for event in stream_gen:
            if event.type == "text":
                text_parts.append(event.data["text"])
            elif event.type == "tool_result":
                tool_calls.append(event.data)
            elif event.type == "usage":
                usage_tokens += event.data.get("usage", {}).get("completion_tokens", 0)
            elif event.type == "continuation_complete":
                continuation_count = event.data.get("iterations", 0)

        return ReActResult(
            assistant_text="".join(text_parts),
            tool_calls=tool_calls,
            usage_tokens=usage_tokens,
            continuation_count=continuation_count,
        )
