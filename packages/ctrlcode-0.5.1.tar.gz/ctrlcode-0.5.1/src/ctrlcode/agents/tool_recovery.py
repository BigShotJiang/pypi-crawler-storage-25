"""Dangling tool call recovery — patch interrupted tool calls before sending to provider."""

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from harnessutils.models.message import Message

logger = logging.getLogger(__name__)

_SKIP_TOOLS: set[str] = set()


def _get_raw_text(msg: "Message") -> str:
    """Extract plain text from a Message's parts."""
    parts = []
    for part in msg.parts:
        text = getattr(part, "text", None)
        if text:
            parts.append(text)
    return "".join(parts)


def _make_synthetic(tc: dict) -> dict:
    return {
        "role": "user",
        "content": (
            f"[Tool: {tc['tool']}]\n"
            f"Error: Tool call {tc['tool']} (id={tc.get('call_id', 'unknown')}) "
            f"did not complete (cancelled or timed out)."
        ),
    }


def patch_tool_calls(
    wire_messages: list[dict],
    raw_messages: "list[Message]",
) -> list[dict]:
    """Return a new wire-format message list with synthetic results for dangling tool calls.

    ``wire_messages`` is the output of ``conv_manager.to_model_format()`` — metadata-free.
    ``raw_messages`` is the output of ``conv_manager.get_messages()`` — has metadata.

    A dangling call is one recorded in an assistant message's ``pending_tool_calls``
    metadata that has no ``[Tool: name]`` result immediately following it in raw history.
    This happens when the process is interrupted after the assistant turn is persisted
    but before tool results are written.
    """
    # Collect patches: list of (wire_insert_idx, synthetic_dict)
    patches: list[tuple[int, dict]] = []

    # Track position in wire_messages as we walk raw_messages in order
    wire_cursor = 0

    for i, raw_msg in enumerate(raw_messages):
        if raw_msg.role != "assistant":
            # Advance wire cursor past corresponding user message (if any)
            if raw_msg.role == "user" and raw_msg.parts and wire_cursor < len(wire_messages):
                if wire_messages[wire_cursor].get("role") == "user":
                    wire_cursor += 1
            continue

        pending = raw_msg.metadata.get("pending_tool_calls", [])

        # Advance wire cursor to find this assistant's wire position
        asst_wire_idx: int | None = None
        if raw_msg.parts:
            if wire_cursor < len(wire_messages) and wire_messages[wire_cursor].get("role") == "assistant":
                asst_wire_idx = wire_cursor
                wire_cursor += 1

        if not pending:
            continue

        # Determine which pending calls are resolved in subsequent raw messages
        resolved: set[str] = set()
        j = i + 1
        while j < len(raw_messages) and raw_messages[j].role == "user":
            content = _get_raw_text(raw_messages[j])
            if content.startswith("[Tool:"):
                tool_name = content.split("[Tool: ", 1)[1].split("]", 1)[0].strip()
                resolved.add(tool_name)
                j += 1
            else:
                break

        unresolved = [
            tc for tc in pending
            if tc.get("tool") not in _SKIP_TOOLS and tc.get("tool") not in resolved
        ]
        if not unresolved:
            continue

        # Determine where to inject synthetics in wire_messages
        if asst_wire_idx is not None:
            # Insert right after the assistant wire message
            insert_pos = asst_wire_idx + 1
        else:
            # Silent assistant (no parts) — not present in wire; insert before next user
            insert_pos = wire_cursor  # next wire position = where next user message will be

        for offset, tc in enumerate(unresolved):
            patches.append((insert_pos + offset, _make_synthetic(tc)))
            logger.warning(
                "patch_tool_calls: inserting synthetic result for dangling call %s (id=%s)",
                tc.get("tool"),
                tc.get("call_id", "unknown"),
            )

    if not patches:
        return wire_messages

    result = list(wire_messages)
    # Apply patches lowest-index first, tracking shift offset
    shift = 0
    for insert_pos, synthetic in sorted(patches, key=lambda p: p[0]):
        result.insert(insert_pos + shift, synthetic)
        shift += 1

    return result


def find_dangling_tool_calls(raw_messages: "list[Message]") -> list[dict]:
    """Return all unresolved pending tool calls across the conversation history.

    Each entry is a ``{"tool": ..., "call_id": ...}`` dict from a ``pending_tool_calls``
    metadata field that has no corresponding ``[Tool: name]`` result message following it.
    """
    dangling: list[dict] = []
    for i, msg in enumerate(raw_messages):
        if msg.role != "assistant":
            continue
        pending = msg.metadata.get("pending_tool_calls", [])
        if not pending:
            continue
        resolved: set[str] = set()
        j = i + 1
        while j < len(raw_messages) and raw_messages[j].role == "user":
            content = _get_raw_text(raw_messages[j])
            if content.startswith("[Tool:"):
                tool_name = content.split("[Tool: ", 1)[1].split("]", 1)[0].strip()
                resolved.add(tool_name)
                j += 1
            else:
                break
        dangling.extend(
            tc for tc in pending
            if tc.get("tool") not in _SKIP_TOOLS and tc.get("tool") not in resolved
        )
    return dangling


def has_dangling_tool_calls(raw_messages: "list[Message]") -> bool:
    """Return True if the conversation has any unresolved dangling tool calls.

    Cheap check used for logging on resume; delegates to ``find_dangling_tool_calls``.
    """
    return bool(find_dangling_tool_calls(raw_messages))
