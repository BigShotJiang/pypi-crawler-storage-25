"""User permission system for file operations."""

import asyncio
import logging
import shlex
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Awaitable, Callable, Optional
from uuid import uuid4

logger = logging.getLogger(__name__)


DESTRUCTIVE_TOOLS: frozenset[str] = frozenset({
    "write_file",
    "update_file",
    "create_file",
    "edit_file",
    "delete_file",
    "run_command",
})


def is_destructive(tool_name: str) -> bool:
    """Return True if tool_name requires permission before execution."""
    return tool_name in DESTRUCTIVE_TOOLS


# ---------------------------------------------------------------------------
# Safe command allowlists (read-only / informational commands that never
# mutate the filesystem or network state and don't require user approval)
# ---------------------------------------------------------------------------

# Commands available and safe on all Unix-like platforms
_SAFE_COMMANDS_UNIX: frozenset[str] = frozenset({
    # Directory listing / navigation
    "ls", "pwd", "tree",
    # File reading (no writes)
    "cat", "head", "tail", "less", "more", "file", "stat",
    # Searching
    "grep", "rg", "ag", "ack", "find",
    # Text processing (read-only usage)
    "wc", "sort", "uniq", "cut", "diff", "comm", "tr", "fold",
    # Shell built-ins / environment inspection
    "echo", "printf", "date", "env", "printenv", "set", "export",
    "which", "whereis", "type", "command",
    # System info (read-only)
    "uname", "hostname", "whoami", "id", "groups", "uptime",
    "ps", "df", "du", "lsblk",
    # Network info (read-only)
    "ping", "nslookup", "dig", "host", "netstat", "ss",
    # Misc utilities
    "man", "info", "help",
    # Python / Node introspection
    "python", "python3", "node", "ruby",
    # Package manager inspection (no install/remove)
    "pip", "pip3", "npm", "yarn", "pnpm",
    # Version checks
    "git",  # subcommand checked separately — only read-only git subcommands
})

_SAFE_COMMANDS_LINUX: frozenset[str] = _SAFE_COMMANDS_UNIX | frozenset({
    "lscpu", "lsusb", "lspci", "lsof",
    "systemctl",  # status/list only (subcommands not checked here — still useful to list)
    "journalctl",
    "ip",        # read-only: ip addr, ip route
    "ifconfig",
    "free",
    "vmstat",
    "iostat",
    "top",
    "htop",
    "strace",  # tracing (read)
})

_SAFE_COMMANDS_MACOS: frozenset[str] = _SAFE_COMMANDS_UNIX | frozenset({
    "sw_vers",
    "system_profiler",
    "defaults",     # read: defaults read ...
    "plutil",
    "mdls",
    "mdfind",
    "lsof",
    "dscl",
    "networksetup",
    "ifconfig",
    "diskutil",     # info subcommand only
    "brew",         # info/list (no install)
    "port",
    "open",         # open with default app
    "pbpaste",
    "pbcopy",
})

_SAFE_COMMANDS_WINDOWS: frozenset[str] = frozenset({
    "dir", "type", "echo", "where", "whoami", "hostname",
    "ver", "set", "path",
    "systeminfo", "ipconfig", "netstat", "tasklist",
    "findstr", "find", "fc",
    "attrib",     # read-only attribute listing
    "tree",
    "wmic",       # read-only queries
    "powershell", "pwsh",
    "python", "python3", "node",
    "pip", "pip3", "npm", "yarn",
    "git",
})


def _platform_safe_commands() -> frozenset[str]:
    """Return the default safe command set for the current platform."""
    if sys.platform == "darwin":
        return _SAFE_COMMANDS_MACOS
    if sys.platform == "win32":
        return _SAFE_COMMANDS_WINDOWS
    return _SAFE_COMMANDS_LINUX  # Linux and other Unix-likes


def _extract_executable(command: str) -> str:
    """Extract the base executable name from a shell command string.

    Examples:
        "ls -la /tmp"  -> "ls"
        "/usr/bin/grep foo bar"  -> "grep"
        "uv run python script.py"  -> "uv"
    """
    try:
        tokens = shlex.split(command)
    except ValueError:
        # Unbalanced quotes etc — fall back to splitting on whitespace
        tokens = command.split()
    if not tokens:
        return ""
    return Path(tokens[0]).name.lower()


def is_safe_command(command: str, safe_commands: frozenset[str]) -> bool:
    """Return True if *command* matches a known-safe executable.

    Only the executable name (not subcommands or flags) is checked.
    Callers that need subcommand-level granularity should extend the
    safe_commands set or handle the check themselves.
    """
    exe = _extract_executable(command)
    return bool(exe) and exe in safe_commands


@dataclass
class PermissionRequest:
    """Request for user permission."""

    operation: str  # "write_file", "read_file", etc.
    path: str  # Path being accessed
    reason: str  # Why permission is needed
    details: Optional[dict] = None  # Additional context


@dataclass
class PermissionResponse:
    """Response from user to a permission request."""

    approved: bool
    accept_all: bool = False
    context: Optional[str] = None


class PermissionManager:
    """Manages user permissions for file operations."""

    def __init__(
        self,
        approval_callback: Optional[Callable[[str, PermissionRequest], Awaitable[None]]] = None,
        extra_safe_commands: Optional[list[str]] = None,
    ):
        """Initialize permission manager.

        Args:
            approval_callback: Async function to send permission request to TUI
                             Called with (request_id, request)
                             If None, all requests are auto-approved (dev mode)
            extra_safe_commands: Additional command names (executables) to treat as safe,
                                 merged with the platform defaults.
        """
        self.approval_callback = approval_callback
        self.accept_all: bool = False
        self._approved_paths: set[str] = set()  # Paths approved this session
        self._pending_requests: dict[str, asyncio.Future] = {}  # request_id -> Future[PermissionResponse]

        platform_defaults = _platform_safe_commands()
        if extra_safe_commands:
            self.safe_commands: frozenset[str] = platform_defaults | frozenset(
                c.lower() for c in extra_safe_commands
            )
        else:
            self.safe_commands = platform_defaults

    def is_safe_command(self, command: str) -> bool:
        """Return True if *command* is in the safe-command allowlist."""
        return is_safe_command(command, self.safe_commands)

    def set_accept_all(self, val: bool) -> None:
        """Enable or disable accept-all mode."""
        self.accept_all = val
        logger.info(f"accept_all set to {val}")

    async def request_permission_async(
        self,
        operation: str,
        path: str,
        reason: str,
        details: Optional[dict] = None,
        remember: bool = False,
        timeout: Optional[float] = None,
    ) -> tuple[bool, Optional[str]]:
        """Request user permission for an operation (async).

        Waits indefinitely for user input — no timeout.  Call
        ``cancel_all_pending()`` to unblock all waiting requests when the
        client disconnects or the session ends; that raises CancelledError
        which propagates up and stops the agent loop cleanly.

        Args:
            operation: Operation name
            path: File/directory path
            reason: Human-readable reason
            details: Additional context
            remember: If True, remember approval for this path

        Returns:
            (approved, context) tuple
        """
        # Accept-all short-circuit — no modal, no callback
        if self.accept_all:
            logger.debug(f"accept_all active; auto-approving {operation} on {path}")
            return True, None

        # Check if already approved this session
        cache_key = f"{operation}:{path}"
        if cache_key in self._approved_paths:
            logger.debug(f"Permission cached for {operation} on {path}")
            return True, None

        # No callback = auto-approve (dev mode)
        if not self.approval_callback:
            logger.warning(f"Auto-approving {operation} on {path} (no callback)")
            return True, None

        # Create permission request
        request = PermissionRequest(
            operation=operation,
            path=path,
            reason=reason,
            details=details
        )

        # Generate unique request ID
        request_id = str(uuid4())

        # Create future for response
        future: asyncio.Future[PermissionResponse] = asyncio.Future()
        self._pending_requests[request_id] = future

        try:
            # Send request to TUI via callback
            await self.approval_callback(request_id, request)

            # Wait for response — timeout=None waits indefinitely.
            # cancel_all_pending() cancels the future when the client disconnects.
            try:
                response = await asyncio.wait_for(future, timeout=timeout)
            except asyncio.TimeoutError:
                logger.debug(f"Permission request timed out for {operation} on {path}")
                return False, None

            if response.accept_all:
                self.accept_all = True
                logger.info("accept_all enabled by user")

            if response.approved and remember:
                self._approved_paths.add(cache_key)
                logger.info(f"Cached approval for {operation} on {path}")

            return response.approved, response.context

        except asyncio.CancelledError:
            # Client disconnected or session ended — propagate to stop the loop
            logger.info(f"Permission request cancelled for {operation} on {path}")
            raise

        except Exception as e:
            logger.error(f"Permission request error: {e}")
            return False, None  # Fail closed on unexpected errors

        finally:
            # Clean up pending request
            self._pending_requests.pop(request_id, None)

    def cancel_all_pending(self) -> None:
        """Cancel all pending permission requests.

        Call this when the client disconnects or the session ends.  Each
        pending future is cancelled, which causes ``request_permission_async``
        to raise ``CancelledError``, which propagates up through the middleware
        stack and stops the agent loop cleanly — no silent denials.
        """
        for request_id, future in list(self._pending_requests.items()):
            if not future.done():
                future.cancel()
                logger.info(f"Cancelled pending permission request {request_id}")
        self._pending_requests.clear()

    def handle_permission_response(self, request_id: str, response: PermissionResponse) -> None:
        """Handle permission response from TUI.

        Args:
            request_id: Request ID
            response: PermissionResponse from user
        """
        future = self._pending_requests.get(request_id)

        if not future:
            logger.warning(f"No pending request for ID {request_id}")
            return

        if future.done():
            logger.warning(f"Request {request_id} already completed")
            return

        # Set result to unblock waiting task
        future.set_result(response)
        logger.info(f"Permission {'approved' if response.approved else 'denied'} for request {request_id}")

    def clear_cache(self):
        """Clear all cached approvals."""
        self._approved_paths.clear()


# Global instance (set by server on init)
_permission_manager: Optional[PermissionManager] = None


def set_permission_manager(manager: PermissionManager):
    """Set global permission manager."""
    global _permission_manager
    _permission_manager = manager


def get_permission_manager() -> Optional[PermissionManager]:
    """Get global permission manager."""
    return _permission_manager


async def request_permission(
    operation: str,
    path: str,
    reason: str,
    details: Optional[dict] = None,
    remember: bool = False,
    timeout: float = 60.0
) -> tuple[bool, Optional[str]]:
    """Request permission using global manager (async).

    Args:
        operation: Operation name
        path: File/directory path
        reason: Human-readable reason
        details: Additional context
        remember: Cache approval for session
        timeout: Timeout in seconds

    Returns:
        (approved, context) tuple
    """
    manager = get_permission_manager()

    if not manager:
        # No manager = dev mode, auto-approve
        logger.warning(f"No permission manager, auto-approving {operation} on {path}")
        return True, None

    return await manager.request_permission_async(operation, path, reason, details, remember, timeout)
