"""Built-in bash execution tools for running shell commands."""

from pathlib import Path
from typing import Any

from ..backends import BackendProtocol, FilesystemBackend


class BashTools:
    """Built-in tools for executing bash commands."""

    def __init__(
        self,
        workspace_root: str | Path,
        backend: BackendProtocol | None = None,
    ):
        self.workspace_root = Path(workspace_root).resolve()
        self._backend: BackendProtocol = backend or FilesystemBackend(self.workspace_root)

    def run_command(
        self,
        command: str,
        timeout: int = 30,
        cwd: str | None = None,
    ) -> dict[str, Any]:
        """
        Execute a shell command.

        Args:
            command: Shell command to execute
            timeout: Timeout in seconds (default 30, max 300)
            cwd: Working directory for command (relative to workspace root)

        Returns:
            Dict with stdout, stderr, returncode, and metadata
        """
        return self._backend.execute(command, cwd=cwd, timeout=timeout)


# Tool schemas for LLM providers (Anthropic/OpenAI format)
BASH_TOOL_SCHEMAS = [
    {
        "name": "run_command",
        "parallel_mode": "never",
        "description": "Execute a shell command in the workspace. Use for git operations, testing, build tools, etc. Commands run in a bash shell.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Shell command to execute (e.g., 'git status', 'npm test', 'make build')",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 30, max 300)",
                    "default": 30,
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory relative to workspace root (e.g., 'src', 'tests')",
                },
            },
            "required": ["command"],
        },
    },
]
