"""Signal tools for LLM ↔ loop communication."""


CONTEXT_TOOL_SCHEMAS = [
    {
        "name": "compact_conversation",
        "parallel_mode": "never",
        "description": (
            "Summarize and compact older conversation history to free context window space. "
            "Call this when you notice the conversation is very long or when working with "
            "large file reads/outputs that are no longer needed. "
            "The full history is archived to .ctrlcode/conversation_history/ before compaction."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {
                    "type": "string",
                    "description": "Brief reason for compacting (e.g., 'large tool outputs accumulated')",
                },
            },
            "required": [],
        },
    },
]
