"""Built-in todo list tools for task management."""

import json
import fcntl
import uuid
from pathlib import Path
from time import time
from typing import Any


class TodoTools:
    """Built-in tools for managing todo lists."""

    def __init__(self, data_dir: str | Path, workspace_root: str | Path | None = None):
        """
        Initialize todo tools.

        Args:
            data_dir: Data directory for storing session/global todos
            workspace_root: Workspace root for project-scoped todos
        """
        self.data_dir = Path(data_dir)
        self.todos_dir = self.data_dir / "todos"
        self.todos_dir.mkdir(parents=True, exist_ok=True)
        self.workspace_root = Path(workspace_root) if workspace_root else None

    def _get_todo_file(self, session_id: str | None, scope: str = "session") -> Path:
        """Get path to todo file based on scope and session."""
        if scope == "project":
            if self.workspace_root:
                return self.workspace_root / ".ctrlcode" / "todos" / "project.json"
            # Fall back to global if no workspace configured
            return self.todos_dir / "global.json"
        if session_id:
            return self.todos_dir / f"{session_id}.json"
        return self.todos_dir / "global.json"

    def _read_todos(self, file_path: Path) -> list[dict]:
        """Read todos from file with locking."""
        if not file_path.exists():
            return []

        try:
            with open(file_path, "r") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                try:
                    data = json.load(f)
                    return data if isinstance(data, list) else []
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except (json.JSONDecodeError, IOError):
            return []

    def _write_todos(self, file_path: Path, todos: list[dict]) -> None:
        """Write todos to file atomically with locking."""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = file_path.with_suffix(".tmp")

        try:
            # Write to temp file with exclusive lock
            with open(temp_path, "w") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    json.dump(todos, f, indent=2)
                    f.flush()
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)

            # Atomic rename
            temp_path.replace(file_path)
        except Exception as e:
            if temp_path.exists():
                temp_path.unlink()
            raise e

    def todo_write(
        self,
        items: list[dict[str, Any]],
        session_id: str | None = None,
        scope: str = "session",
    ) -> dict[str, Any]:
        """
        Create or append todo items.

        Args:
            items: List of todo items with 'content' and optional 'steps', 'activeForm', 'priority', 'status'
            session_id: Optional session ID for session-specific todos
            scope: 'session' (default) or 'project' for cross-session project todos

        Returns:
            Dict with success status and created todos
        """
        try:
            file_path = self._get_todo_file(session_id, scope)
            todos = self._read_todos(file_path)
            current_time = time()

            created = []
            for item in items:
                if not item.get("content"):
                    continue

                todo = {
                    "id": str(uuid.uuid4()),
                    "content": item["content"],
                    "steps": item.get("steps") or [],
                    "scope": scope,
                    "status": item.get("status", "pending"),
                    "activeForm": item.get("activeForm", item["content"]),
                    "priority": item.get("priority", "medium"),
                    "created_at": current_time,
                    "updated_at": current_time,
                }
                todos.append(todo)
                created.append(todo)

            self._write_todos(file_path, todos)
            return {"success": True, "todos": created, "error": None}

        except Exception as e:
            return {"success": False, "todos": [], "error": str(e)}

    def todo_list(
        self,
        session_id: str | None = None,
        status: str | None = None,
        scope: str = "session",
    ) -> dict[str, Any]:
        """
        List todo items with optional filtering.

        Args:
            session_id: Optional session ID for session-specific todos
            status: Optional status filter (pending, in_progress, completed)
            scope: 'session' (default) or 'project' to list project-scoped todos

        Returns:
            Dict with success status and todos list
        """
        try:
            file_path = self._get_todo_file(session_id, scope)
            todos = self._read_todos(file_path)

            if status:
                todos = [t for t in todos if t.get("status") == status]

            return {"success": True, "todos": todos, "error": None}

        except Exception as e:
            return {"success": False, "todos": [], "error": str(e)}

    def todo_update(
        self,
        id: str,
        status: str | None = None,
        content: str | None = None,
        steps: list[str] | None = None,
        activeForm: str | None = None,
        priority: str | None = None,
        session_id: str | None = None,
        scope: str = "session",
    ) -> dict[str, Any]:
        """
        Update an existing todo item.

        Args:
            id: UUID of the todo to update
            status: New status (pending, in_progress, completed)
            content: New content
            activeForm: Present continuous form shown when in progress
            priority: New priority (high, medium, low)
            session_id: Optional session ID for session-specific todos

        Returns:
            Dict with success status and updated todo
        """
        try:
            file_path = self._get_todo_file(session_id, scope)
            todos = self._read_todos(file_path)

            todo_found = None
            for todo in todos:
                if todo.get("id") == id:
                    todo_found = todo
                    if status is not None:
                        todo["status"] = status
                    if content is not None:
                        todo["content"] = content
                    if steps is not None:
                        todo["steps"] = steps
                    if activeForm is not None:
                        todo["activeForm"] = activeForm
                    if priority is not None:
                        todo["priority"] = priority
                    todo["updated_at"] = time()
                    break

            if not todo_found:
                return {
                    "success": False,
                    "todos": [],
                    "error": f"Todo with id '{id}' not found",
                }

            self._write_todos(file_path, todos)
            return {"success": True, "todos": [todo_found], "error": None}

        except Exception as e:
            return {"success": False, "todos": [], "error": str(e)}


# Tool schemas for LLM providers (Anthropic/OpenAI format)
TODO_TOOL_SCHEMAS = [
    {
        "name": "todo_write",
        "description": "Create or append todo items for task tracking. Use this when planning work or breaking down complex tasks. Each item should include step-by-step sub-steps describing exactly how to complete it.",
        "input_schema": {
            "type": "object",
            "properties": {
                "items": {
                    "type": "array",
                    "description": "List of todo items to create",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {
                                "type": "string",
                                "description": "Task description (brief, actionable)",
                            },
                            "steps": {
                                "type": "array",
                                "description": "Ordered sub-steps describing exactly how to complete this item (e.g., ['Read src/foo.py', 'Add error handling to bar()', 'Run pytest to verify'])",
                                "items": {"type": "string"},
                            },
                            "activeForm": {
                                "type": "string",
                                "description": "Present continuous form shown when in progress (e.g., 'Running tests')",
                            },
                            "priority": {
                                "type": "string",
                                "description": "Task priority",
                                "enum": ["high", "medium", "low"],
                                "default": "medium",
                            },
                            "status": {
                                "type": "string",
                                "description": "Initial status",
                                "enum": ["pending", "in_progress", "completed"],
                                "default": "pending",
                            },
                        },
                        "required": ["content"],
                    },
                },
                "session_id": {
                    "type": "string",
                    "description": "Session ID (required when scope is 'session' and you want session-specific todos)",
                },
                "scope": {
                    "type": "string",
                    "description": "'session' (default) for per-session todos, 'project' for cross-session project-level todos stored in the workspace",
                    "enum": ["session", "project"],
                    "default": "session",
                },
            },
            "required": ["items"],
        },
    },
    {
        "name": "todo_list",
        "description": "List todos with optional filtering by status. Use this to check what tasks are pending or track progress. Use scope='project' at session start to see the project backlog.",
        "input_schema": {
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Session ID for session-specific todos",
                },
                "status": {
                    "type": "string",
                    "description": "Filter by status",
                    "enum": ["pending", "in_progress", "completed"],
                },
                "scope": {
                    "type": "string",
                    "description": "'session' (default) or 'project' to list the project-level backlog",
                    "enum": ["session", "project"],
                    "default": "session",
                },
            },
            "required": [],
        },
    },
    {
        "name": "todo_update",
        "description": "Update an existing todo item. Use this to mark tasks as in progress or completed, or modify task details. Do not mark an item completed unless you have verified it works.",
        "input_schema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "UUID of the todo to update",
                },
                "status": {
                    "type": "string",
                    "description": "New status",
                    "enum": ["pending", "in_progress", "completed"],
                },
                "content": {
                    "type": "string",
                    "description": "New task description",
                },
                "steps": {
                    "type": "array",
                    "description": "Updated sub-steps for this item",
                    "items": {"type": "string"},
                },
                "activeForm": {
                    "type": "string",
                    "description": "Present continuous form shown when in progress (e.g., 'Running tests')",
                },
                "priority": {
                    "type": "string",
                    "description": "New priority",
                    "enum": ["high", "medium", "low"],
                },
                "session_id": {
                    "type": "string",
                    "description": "Session ID (required when scope is 'session')",
                },
                "scope": {
                    "type": "string",
                    "description": "'session' (default) or 'project' — must match the scope used when writing the todo",
                    "enum": ["session", "project"],
                    "default": "session",
                },
            },
            "required": ["id"],
        },
    },
]
