"""MCP tool system for ctrl-code."""

from pathlib import Path
from typing import Any, cast

from .mcp import MCPClient, MCPTool
from .registry import ToolRegistry, BuiltinTool, ParallelMode
from .executor import ToolExecutor, ToolCallResult
from .explore import ExploreTools, EXPLORE_TOOL_SCHEMAS
from .todo import TodoTools, TODO_TOOL_SCHEMAS
from .bash import BashTools, BASH_TOOL_SCHEMAS
from .webfetch import WebFetchTools, WEBFETCH_TOOL_SCHEMAS
from .update import UpdateFileTools, UPDATE_TOOL_SCHEMAS
from .observability import ObservabilityTools, OBSERVABILITY_TOOL_SCHEMAS
from .browser import BrowserTools, BROWSER_TOOL_SCHEMAS, get_browser_tools
from .signal import CONTEXT_TOOL_SCHEMAS
from ..backends import BackendProtocol


def setup_explore_tools(
    registry: ToolRegistry,
    workspace_root: str | Path,
    backend: BackendProtocol | None = None,
) -> None:
    """
    Register built-in exploration tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for file exploration
    """
    explore = ExploreTools(workspace_root, backend=backend)

    # Register each tool with its schema and function
    for schema in EXPLORE_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(explore, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=ParallelMode(s.get("parallel_mode", "never")),
        )


def setup_todo_tools(
    registry: ToolRegistry,
    data_dir: str | Path,
    workspace_root: str | Path | None = None,
) -> None:
    """
    Register built-in todo tools.

    Args:
        registry: Tool registry to register tools in
        data_dir: Data directory for storing session/global todos
        workspace_root: Workspace root for project-scoped todos
    """
    todo = TodoTools(data_dir, workspace_root=workspace_root)

    # Register each tool with its schema and function
    for schema in TODO_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(todo, tool_name)
        pm = ParallelMode(s.get("parallel_mode", "never"))

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=pm,
        )

        # Also register as task_* alias for user flexibility
        task_alias = tool_name.replace("todo_", "task_")
        registry.register_builtin(
            name=task_alias,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=pm,
        )


def setup_bash_tools(
    registry: ToolRegistry,
    workspace_root: str | Path,
    backend: BackendProtocol | None = None,
) -> None:
    """
    Register built-in bash tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for command execution
        backend: Optional backend override (defaults to FilesystemBackend)
    """
    bash = BashTools(workspace_root, backend=backend)

    # Register each tool with its schema and function
    for schema in BASH_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(bash, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=ParallelMode(s.get("parallel_mode", "never")),
        )


def setup_webfetch_tools(registry: ToolRegistry) -> None:
    """
    Register built-in web fetch tools.

    Args:
        registry: Tool registry to register tools in
    """
    webfetch = WebFetchTools()

    # Register each tool with its schema and function
    for schema in WEBFETCH_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(webfetch, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=ParallelMode(s.get("parallel_mode", "never")),
        )


def setup_update_tools(
    registry: ToolRegistry,
    workspace_root: str | Path,
    backend: BackendProtocol | None = None,
) -> None:
    """
    Register built-in update file tools.

    Args:
        registry: Tool registry to register tools in
        workspace_root: Root directory for file operations
        backend: Optional backend override (defaults to FilesystemBackend)
    """
    update = UpdateFileTools(workspace_root, backend=backend)

    # Register each tool with its schema and function
    for schema in UPDATE_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(update, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
            parallel_mode=ParallelMode(s.get("parallel_mode", "never")),
        )


def setup_observability_tools(registry: ToolRegistry, log_dir: str | Path | None = None) -> None:
    """
    Register built-in observability tools.

    Args:
        registry: Tool registry to register tools in
        log_dir: Directory containing log files (optional)
    """
    observability = ObservabilityTools(log_dir)

    # Register each tool with its schema and function
    for schema in OBSERVABILITY_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(observability, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
        )



def setup_context_tools(
    registry: ToolRegistry,
    session_manager: Any,
    session_id: str,
) -> None:
    """Register context compaction tool bound to a specific session."""
    from ..memory.context_window_monitor import ContextWindowMonitor

    async def compact_conversation(reason: str = "") -> dict:
        import asyncio
        from datetime import datetime, timezone
        from ..session.adapters import LLMClientAdapter

        session = session_manager.get_session(session_id)
        if session is None:
            return {"success": False, "error": "session not found"}

        # Reuse existing monitor or create a temporary one
        monitor: ContextWindowMonitor = session_manager._ctx_monitors.get(session_id)
        if monitor is None:
            monitor = ContextWindowMonitor(
                model=session.provider.model,
                ctrlcode_dir=session_manager._ctrlcode_dir,
            )

        llm_client = LLMClientAdapter(session.provider, asyncio.get_running_loop())
        result = await monitor.summarize_and_compact(
            session_id=session_id,
            conv_manager=session_manager.conv_manager,
            conv_id=session.conv_id,
            llm_client=llm_client,
            keep_last=6,
        )
        new_conv_id = result.get("new_conv_id")
        if new_conv_id and new_conv_id != session.conv_id:
            session.conv_id = new_conv_id

        tokens_freed = result.get("tokens_saved", 0)
        n_compacted = result.get("messages_compacted", 0)
        summary_text = result.get("summary_text", "")

        # Write session:summary artifact to rootset (upsert)
        writer = getattr(session_manager, "_memory_mw", None)
        if writer is not None:
            writer = writer._writers.get(session.id)
        if writer is not None:
            try:
                existing = await writer._backend.search_artifacts(
                    "session summary",
                    kind="session:summary",
                    namespace=session_id,
                    top_k=1,
                )
                existing_art = existing[0].artifact if existing else None
                compaction_count = (
                    existing_art.metadata.get("compaction_count", 0) + 1
                    if existing_art else 1
                )
                metadata = {
                    "session_id": session_id,
                    "compaction_count": compaction_count,
                    "trigger": "agent_triggered",
                    "reason": reason or "",
                    "messages_compacted": n_compacted,
                    "tokens_freed_estimate": tokens_freed,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                if existing_art:
                    await writer._backend.update_artifact(
                        existing_art.id, content=summary_text, metadata=metadata
                    )
                else:
                    await writer._backend.add_artifact(
                        summary_text,
                        kind="session:summary",
                        namespace=session_id,
                        metadata=metadata,
                    )
            except Exception:
                pass  # non-fatal

        return {
            "success": True,
            "compacted": n_compacted,
            "tokens_freed": tokens_freed,
            "summary_preview": summary_text[:200],
        }

    schema = CONTEXT_TOOL_SCHEMAS[0]
    registry.register_builtin(
        name=cast(str, schema["name"]),
        description=schema["description"],
        input_schema=schema["input_schema"],
        function=compact_conversation,
        parallel_mode=ParallelMode(schema.get("parallel_mode", "never")),
        overwrite=True,
    )


def setup_browser_tools(registry: ToolRegistry) -> None:
    """
    Register built-in browser automation tools.

    Args:
        registry: Tool registry to register tools in
    """
    browser = get_browser_tools()

    # Register each tool with its schema and function
    for schema in BROWSER_TOOL_SCHEMAS:
        s: dict[str, Any] = schema  # type: ignore[assignment]
        tool_name = cast(str, s["name"])

        # Map tool name to method
        function = getattr(browser, tool_name)

        registry.register_builtin(
            name=tool_name,
            description=s["description"],
            input_schema=s["input_schema"],
            function=function,
        )


__all__ = [
    "BackendProtocol",
    "MCPClient",
    "MCPTool",
    "ToolRegistry",
    "BuiltinTool",
    "ToolExecutor",
    "ToolCallResult",
    "ExploreTools",
    "TodoTools",
    "BashTools",
    "WebFetchTools",
    "UpdateFileTools",
    "ObservabilityTools",
    "BrowserTools",
    "setup_explore_tools",
    "setup_todo_tools",
    "setup_bash_tools",
    "setup_webfetch_tools",
    "setup_update_tools",
    "setup_observability_tools",
    "setup_browser_tools",
    "setup_context_tools",
    "ParallelMode",
]
