"""Built-in exploration tools for codebase navigation."""

from pathlib import Path
from dataclasses import dataclass
from typing import Any

from ..backends import BackendProtocol, FilesystemBackend


@dataclass
class SearchResult:
    """Result from code search."""

    file: str
    line: int
    content: str
    context_before: list[str] | None = None
    context_after: list[str] | None = None


class ExploreTools:
    """Built-in tools for exploring codebases."""

    def __init__(
        self,
        workspace_root: str | Path,
        backend: BackendProtocol | None = None,
    ):
        self.workspace_root = Path(workspace_root).resolve()
        self._backend: BackendProtocol = backend or FilesystemBackend(self.workspace_root)

    def search_files(self, pattern: str, max_results: int = 100) -> list[str]:
        """
        Search for files matching glob pattern.

        Args:
            pattern: Glob pattern (e.g., "**/*.py", "src/**/*.ts")
            max_results: Maximum results to return

        Returns:
            List of file paths relative to workspace root
        """
        return self._backend.glob(pattern, max_results=max_results)

    def search_code(
        self,
        query: str,
        file_pattern: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        """
        Search code content using ripgrep.

        Args:
            query: Search query (regex supported)
            file_pattern: Glob pattern to limit search
            context_lines: Lines of context before/after match
            max_results: Maximum results to return

        Returns:
            List of search results with file, line, content, context
        """
        return self._backend.grep(
            query,
            file_glob=file_pattern,
            context_lines=context_lines,
            max_results=max_results,
        )

    def read_file(
        self,
        path: str,
        start_line: int | None = None,
        end_line: int | None = None,
    ) -> dict[str, Any]:
        """
        Read file contents.

        Args:
            path: File path relative to workspace root
            start_line: Start line (1-indexed, inclusive)
            end_line: End line (1-indexed, inclusive)

        Returns:
            Dict with content, total_lines, and metadata
        """
        result = self._backend.read(path)
        if "error" in result:
            return result

        if start_line is not None or end_line is not None:
            lines = result["content"].splitlines(keepends=True)
            total_lines = result["total_lines"]
            start = (start_line - 1) if start_line else 0
            end = end_line if end_line else total_lines
            selected = lines[start:end]
            result["content"] = "".join(selected)
            result["lines_returned"] = len(selected)

        return result

    async def write_file(self, path: str, content: str) -> dict[str, Any]:
        """
        Create a new file. Fails if the file already exists — use update_file to modify existing files.

        Args:
            path: File path relative to workspace root
            content: Content to write to file

        Returns:
            Dict with success status and metadata
        """
        return self._backend.write(path, content)

    def list_directory(
        self, path: str = ".", max_depth: int = 1
    ) -> dict[str, Any]:
        """
        List directory contents.

        Args:
            path: Directory path relative to workspace root
            max_depth: How deep to recurse (1 = immediate children only)

        Returns:
            Dict with directories and files
        """
        return self._backend.ls(path, max_depth=max_depth)

    def get_file_info(self, path: str) -> dict[str, Any]:
        """
        Get file metadata.

        Args:
            path: File path relative to workspace root

        Returns:
            Dict with size, modified time, type, etc.
        """
        return self._backend.stat(path)


# Tool schemas for LLM providers (Anthropic/OpenAI format)
EXPLORE_TOOL_SCHEMAS = [
    {
        "name": "search_files",
        "parallel_mode": "safe",
        "description": "Search for files in the codebase using glob patterns. Use this to find files by name or extension.",
        "input_schema": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern to match files (e.g., '**/*.py' for all Python files, 'src/**/*.ts' for TypeScript in src/)",
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return",
                    "default": 100,
                },
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "search_code",
        "parallel_mode": "safe",
        "description": "Search for code content across files. Use this to find where specific functions, classes, or patterns are used.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query (supports regex). E.g., 'class FuzzingOrchestrator', 'def process_turn'",
                },
                "file_pattern": {
                    "type": "string",
                    "description": "Limit search to files matching this glob pattern",
                    "default": "**/*",
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Number of context lines before/after match",
                    "default": 2,
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return",
                    "default": 50,
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "read_file",
        "parallel_mode": "safe",
        "description": "Read contents of a file. Use this to examine specific files found through search.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path relative to workspace root",
                },
                "start_line": {
                    "type": "integer",
                    "description": "Start line number (1-indexed, inclusive). Omit to read from beginning.",
                },
                "end_line": {
                    "type": "integer",
                    "description": "End line number (1-indexed, inclusive). Omit to read to end.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "parallel_mode": "path_scoped",
        "description": "Create a new file with the given content. Fails if the file already exists — use update_file to modify existing files. Parent directories are created automatically.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path relative to workspace root (e.g., 'fizzbuzz.py', 'src/utils.py'). NEVER use absolute paths.",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file",
                },
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "list_directory",
        "parallel_mode": "safe",
        "description": "List contents of a directory. Use this to understand project structure.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory path relative to workspace root",
                    "default": ".",
                },
                "max_depth": {
                    "type": "integer",
                    "description": "How deep to recurse (1 = immediate children only)",
                    "default": 1,
                },
            },
            "required": [],
        },
    },
    {
        "name": "get_file_info",
        "parallel_mode": "safe",
        "description": "Get metadata about a file (size, modified time, type).",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path relative to workspace root",
                },
            },
            "required": ["path"],
        },
    },
]
