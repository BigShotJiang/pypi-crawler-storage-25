"""Tool execution coordinator."""

import asyncio
import logging
from typing import Any, Callable, TYPE_CHECKING
from dataclasses import dataclass

from .registry import ParallelMode, ToolRegistry
from ..permissions import is_destructive

if TYPE_CHECKING:
    from ..permissions import PermissionManager

logger = logging.getLogger(__name__)


@dataclass
class ToolCallResult:
    """Result of a tool call."""

    tool_name: str
    call_id: str
    success: bool
    result: Any = None
    error: str | None = None


class ToolExecutor:
    """Executes tool calls (both MCP and built-in)."""

    def __init__(self, registry: ToolRegistry, permission_manager: "PermissionManager | None" = None):
        """
        Initialize tool executor.

        Args:
            registry: Tool registry with MCP clients and built-in tools
            permission_manager: Optional permission manager for destructive tool checks
        """
        self.registry = registry
        self.permission_manager = permission_manager

    async def execute(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        call_id: str,
    ) -> ToolCallResult:
        """
        Execute a tool call.

        Args:
            tool_name: Name of tool to call
            arguments: Tool arguments
            call_id: Unique call identifier

        Returns:
            ToolCallResult with execution result
        """
        # Strip pre_tool_hook sentinels before any logic (they're internal bookkeeping)
        perm_denied = arguments.pop("__perm_denied__", False)
        perm_context = arguments.pop("__perm_context__", None)
        perm_approved = arguments.pop("__perm_approved__", False)

        # If pre_tool_hook already denied permission, short-circuit immediately
        if perm_denied:
            error = "Operation rejected by user."
            if perm_context:
                error += f"\nUser context: {perm_context}"
            return ToolCallResult(
                tool_name=tool_name,
                call_id=call_id,
                success=False,
                error=error,
            )

        # Permission check for destructive tools (only if not already handled by pre_tool_hook)
        # For run_command, skip if the command is in the safe allowlist
        _is_safe_run = (
            tool_name == "run_command"
            and self.permission_manager is not None
            and self.permission_manager.is_safe_command(arguments.get("command", ""))
        )
        if self.permission_manager and is_destructive(tool_name) and not _is_safe_run and not perm_approved:
            approved, context = await self.permission_manager.request_permission_async(
                operation=tool_name,
                path=arguments.get("path", arguments.get("command", "")),
                reason=f"Agent wants to run {tool_name}",
                details={"input": arguments},
            )
            if not approved:
                error = "Operation rejected by user."
                if context:
                    error += f"\nUser context: {context}"
                return ToolCallResult(
                    tool_name=tool_name,
                    call_id=call_id,
                    success=False,
                    error=error,
                )

        # Get tool definition
        tool = self.registry.get_tool(tool_name)
        if not tool:
            logger.error(f"Tool not found: {tool_name}")
            return ToolCallResult(
                tool_name=tool_name,
                call_id=call_id,
                success=False,
                error=f"Tool '{tool_name}' not found",
            )

        # Execute based on tool type
        try:
            if self.registry.is_builtin(tool_name):
                # Built-in tool - call function directly
                from .registry import BuiltinTool
                import inspect
                builtin_tool = tool
                assert isinstance(builtin_tool, BuiltinTool)

                # Validate required params against schema before calling
                required = builtin_tool.input_schema.get("required", [])
                missing = [p for p in required if p not in arguments]
                if missing:
                    return ToolCallResult(
                        tool_name=tool_name,
                        call_id=call_id,
                        success=False,
                        error=f"Missing required argument(s) for '{tool_name}': {', '.join(missing)}",
                    )

                # Check if function is async and await if needed
                if inspect.iscoroutinefunction(builtin_tool.function):
                    result = await builtin_tool.function(**arguments)
                else:
                    result = builtin_tool.function(**arguments)

                # Check if tool returned an error (error key exists and is not None)
                if isinstance(result, dict) and "error" in result and result["error"] is not None:
                    logger.error(f"Built-in tool '{tool_name}' returned error: {result['error']}")
                    return ToolCallResult(
                        tool_name=tool_name,
                        call_id=call_id,
                        success=False,
                        error=result["error"],
                    )

                logger.info(f"Built-in tool '{tool_name}' executed successfully")
                return ToolCallResult(
                    tool_name=tool_name,
                    call_id=call_id,
                    success=True,
                    result=result,
                )

            else:
                # MCP tool - call via client
                from .mcp import MCPTool
                mcp_tool = tool
                assert isinstance(mcp_tool, MCPTool)

                client = self.registry.get_client(mcp_tool.server_name)
                if not client:
                    logger.error(f"Client not found for server: {mcp_tool.server_name}")
                    return ToolCallResult(
                        tool_name=tool_name,
                        call_id=call_id,
                        success=False,
                        error=f"Server '{mcp_tool.server_name}' not available",
                    )

                result = await client.call_tool(tool_name, arguments)
                logger.info(f"MCP tool '{tool_name}' executed successfully")

                return ToolCallResult(
                    tool_name=tool_name,
                    call_id=call_id,
                    success=True,
                    result=result,
                )

        except Exception as e:
            logger.error(f"Tool execution failed: {e}")
            return ToolCallResult(
                tool_name=tool_name,
                call_id=call_id,
                success=False,
                error=str(e),
            )

    async def execute_batch(
        self,
        tool_calls: list[dict[str, Any]],
    ) -> list[ToolCallResult]:
        """Execute multiple tool calls sequentially (legacy / test helper)."""
        results = []
        for call in tool_calls:
            result = await self.execute(
                tool_name=call.get("tool", call.get("name", "")),
                arguments=call.get("input", call.get("arguments", {})),
                call_id=call.get("call_id", ""),
            )
            results.append(result)
        return results

    def classify_batch(self, tool_calls: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
        """Group tool calls into ordered execution groups.

        Each group runs concurrently; groups run serially. Rules:
        - <= 1 call → single group, skip analysis
        - NEVER tools → flush current batch, own group of 1
        - SAFE tools → accumulate (max 5 per group)
        - PATH_SCOPED tools → accumulate only if their path doesn't overlap current batch
        - Unknown tools → NEVER fallback
        """
        if len(tool_calls) <= 1:
            return [tool_calls] if tool_calls else []

        groups: list[list[dict[str, Any]]] = []
        current_batch: list[dict[str, Any]] = []
        current_paths: set[str] = set()

        def flush():
            if current_batch:
                groups.append(list(current_batch))
                current_batch.clear()
                current_paths.clear()

        for tc in tool_calls:
            tool_name = tc.get("tool", "")
            bt = self.registry.builtin_tools.get(tool_name)
            mode = bt.parallel_mode if bt is not None else ParallelMode.NEVER

            if mode == ParallelMode.NEVER:
                flush()
                groups.append([tc])
            elif mode == ParallelMode.SAFE:
                if len(current_batch) >= 5:
                    flush()
                current_batch.append(tc)
            elif mode == ParallelMode.PATH_SCOPED:
                path = (tc.get("input") or {}).get("path") or (tc.get("input") or {}).get("file_path") or ""
                if path and path in current_paths:
                    # Overlapping path — flush and start fresh
                    flush()
                current_batch.append(tc)
                if path:
                    current_paths.add(path)
            else:
                flush()
                groups.append([tc])

        flush()
        return groups

    async def _execute_one(
        self,
        tool_call: dict[str, Any],
        pre_hook: Callable | None,
        post_hook: Callable | None,
    ) -> tuple["ToolCallResult", list]:
        """Execute one tool call with pre/post hooks, collecting events."""
        events: list = []
        if pre_hook:
            async for ev in pre_hook(tool_call):
                events.append(ev)
        result = await self.execute(
            tool_name=tool_call["tool"],
            arguments=tool_call["input"],
            call_id=tool_call["call_id"],
        )
        if post_hook:
            async for ev in post_hook(tool_call, result):
                events.append(ev)
        return result, events

    _parallel_semaphore = asyncio.Semaphore(5)

    async def execute_parallel_group(
        self,
        group: list[dict[str, Any]],
        pre_hook: Callable | None = None,
        post_hook: Callable | None = None,
    ) -> list[tuple["ToolCallResult", list]]:
        """Execute a group of tool calls concurrently (max 5 at a time)."""
        async with self._parallel_semaphore:
            return list(await asyncio.gather(
                *[self._execute_one(tc, pre_hook, post_hook) for tc in group]
            ))
