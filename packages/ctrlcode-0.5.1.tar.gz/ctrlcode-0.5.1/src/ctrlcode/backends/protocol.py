"""BackendProtocol — abstract I/O interface for ctrl+code tool layer."""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class BackendProtocol(Protocol):
    """
    Defines all I/O operations performed by built-in tools.

    Implementations:
      FilesystemBackend  — real disk (default, production)
      StateBackend       — in-memory dict (testing, sandboxing)
      CompositeBackend   — routes by path prefix
    """

    def read(
        self,
        path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Read a file. Returns {content, total_lines, lines_returned} or {error}."""
        ...

    def ls(self, path: str = ".", *, max_depth: int = 1) -> dict[str, Any]:
        """List a directory. Returns {path, directories, files} or {error}."""
        ...

    def glob(self, pattern: str, *, max_results: int = 100) -> list[str]:
        """Return relative paths matching a glob pattern."""
        ...

    def grep(
        self,
        pattern: str,
        *,
        file_glob: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        """Search file contents. Returns [{file, line, content}]."""
        ...

    def stat(self, path: str) -> dict[str, Any]:
        """Return file metadata (size, mtime, is_file, is_dir, extension)."""
        ...

    def write(self, path: str, content: str) -> dict[str, Any]:
        """Create a new file (fails if exists). Returns {success, path, bytes_written}."""
        ...

    def overwrite(self, path: str, content: str) -> dict[str, Any]:
        """Write content to path, creating or replacing. Atomic. Returns {success, path}."""
        ...

    def edit(self, path: str, old_content: str, new_content: str) -> dict[str, Any]:
        """Replace old_content with new_content (atomic). Returns {success, path}."""
        ...

    def write_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        """Write raw bytes. Returns {success, path}."""
        ...

    def execute(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        """
        Run a shell command. Returns {stdout, stderr, returncode, command, cwd, success}.
        Raise NotImplementedError for backends that disallow execution (sandbox).
        """
        ...
