"""CompositeBackend — routes I/O to sub-backends by path prefix."""

from typing import Any

from .protocol import BackendProtocol


class CompositeBackend:
    """
    Routes operations to sub-backends based on path prefix.

    Constructor: mounts = [(prefix, backend), ...] in order of specificity.
    The longest matching prefix wins. A mount with prefix "" acts as the default.
    """

    def __init__(
        self,
        mounts: list[tuple[str, BackendProtocol]],
        default: BackendProtocol | None = None,
    ) -> None:
        # Sort longest prefix first so we match most specific mount first
        self._mounts = sorted(mounts, key=lambda m: len(m[0]), reverse=True)
        self._default = default

    def _route(self, path: str) -> tuple[BackendProtocol | None, str]:
        """
        Find the backend responsible for path.
        Returns (backend, stripped_path) where stripped_path has the prefix removed.
        """
        for prefix, backend in self._mounts:
            if not prefix:
                continue
            norm_prefix = prefix.rstrip("/") + "/"
            if path.startswith(norm_prefix):
                return backend, path[len(norm_prefix):]
            if path == prefix.rstrip("/"):
                return backend, "."
        return self._default, path

    def read(self, path: str, *, offset: int | None = None, limit: int | None = None) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.read(sub_path, offset=offset, limit=limit)

    def ls(self, path: str = ".", *, max_depth: int = 1) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.ls(sub_path, max_depth=max_depth)

    def glob(self, pattern: str, *, max_results: int = 100) -> list[str]:
        # Collect from all mounts and re-prefix results
        all_results: list[str] = []
        seen_prefixes: set[str] = set()
        for prefix, backend in self._mounts:
            seen_prefixes.add(prefix)
            raw = backend.glob(pattern, max_results=max_results)
            for r in raw:
                prefixed = (prefix.rstrip("/") + "/" + r) if prefix else r
                all_results.append(prefixed)
        if self._default and "" not in seen_prefixes:
            for r in self._default.glob(pattern, max_results=max_results):
                all_results.append(r)
        return sorted(all_results)[:max_results]

    def grep(
        self,
        pattern: str,
        *,
        file_glob: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        all_results: list[dict[str, Any]] = []
        seen_prefixes: set[str] = set()
        for prefix, backend in self._mounts:
            seen_prefixes.add(prefix)
            raw = backend.grep(pattern, file_glob=file_glob, context_lines=context_lines, max_results=max_results)
            for r in raw:
                if prefix and "file" in r:
                    r = dict(r)
                    r["file"] = prefix.rstrip("/") + "/" + r["file"]
                all_results.append(r)
        if self._default and "" not in seen_prefixes:
            all_results.extend(
                self._default.grep(pattern, file_glob=file_glob, context_lines=context_lines, max_results=max_results)
            )
        return all_results[:max_results]

    def stat(self, path: str) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.stat(sub_path)

    def write(self, path: str, content: str) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.write(sub_path, content)

    def overwrite(self, path: str, content: str) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.overwrite(sub_path, content)

    def edit(self, path: str, old_content: str, new_content: str) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.edit(sub_path, old_content, new_content)

    def write_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        backend, sub_path = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for path: '{path}'"}
        return backend.write_bytes(sub_path, data)

    def execute(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        # Route execution based on cwd; if no cwd, use default
        path = cwd or "."
        backend, sub_cwd = self._route(path)
        if backend is None:
            return {"error": f"No backend mounted for cwd: '{path}'"}
        return backend.execute(command, cwd=sub_cwd if cwd else None, timeout=timeout)
