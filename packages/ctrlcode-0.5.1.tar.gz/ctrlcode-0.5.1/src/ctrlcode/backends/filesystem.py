"""FilesystemBackend — real-disk implementation of BackendProtocol."""

import fcntl
import json
import os
import subprocess
from pathlib import Path
from typing import Any


class FilesystemBackend:
    """Implements BackendProtocol against real disk with workspace_root containment."""

    def __init__(self, workspace_root: str | Path) -> None:
        self._root = Path(workspace_root).resolve()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve(self, path: str) -> Path | None:
        """
        Resolve path against workspace root. Returns None if outside root.
        Absolute paths that fall inside the root are accepted.
        """
        p = Path(path)
        if p.is_absolute():
            try:
                p = p.relative_to(self._root)
            except ValueError:
                return None
        resolved = (self._root / p).resolve()
        if not str(resolved).startswith(str(self._root)):
            return None
        return resolved

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def read(
        self,
        path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        file_path = self._resolve(path)
        if file_path is None:
            return {"error": "Path outside workspace"}
        if not file_path.exists():
            return {"error": "File not found"}
        if not file_path.is_file():
            return {"error": "Not a file"}
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except UnicodeDecodeError:
            return {"error": "File is binary or uses unsupported encoding"}
        except Exception as e:
            return {"error": str(e)}

        total_lines = len(lines)
        start = offset if offset is not None else 0
        end = (start + limit) if limit is not None else total_lines
        selected = lines[start:end]
        return {
            "content": "".join(selected),
            "total_lines": total_lines,
            "lines_returned": len(selected),
            "path": path,
        }

    def ls(self, path: str = ".", *, max_depth: int = 1) -> dict[str, Any]:
        dir_path = self._resolve(path)
        if dir_path is None:
            return {"error": "Path outside workspace"}
        if not dir_path.exists():
            return {"error": "Directory not found"}
        if not dir_path.is_dir():
            return {"error": "Not a directory"}

        directories: list[str] = []
        files: list[dict[str, Any]] = []

        for root, dirs, filenames in os.walk(dir_path):
            root_path = Path(root)
            depth = len(root_path.relative_to(dir_path).parts)
            if depth >= max_depth:
                dirs.clear()
                continue
            for d in sorted(dirs):
                rel = (root_path / d).relative_to(self._root)
                directories.append(str(rel))
            for fname in sorted(filenames):
                fpath = root_path / fname
                rel = fpath.relative_to(self._root)
                files.append({"path": str(rel), "size": fpath.stat().st_size})

        return {
            "path": str(Path(path)),
            "directories": directories[:100],
            "files": files[:100],
        }

    def glob(self, pattern: str, *, max_results: int = 100) -> list[str]:
        try:
            matches = []
            for p in self._root.glob(pattern):
                if p.is_file():
                    matches.append(str(p.relative_to(self._root)))
                    if len(matches) >= max_results:
                        break
            return sorted(matches)
        except Exception as e:
            return [f"Error: {e}"]

    def grep(
        self,
        pattern: str,
        *,
        file_glob: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        try:
            cmd = [
                "rg",
                "--json",
                "-C", str(context_lines),
                "--max-count", str(max_results),
                pattern,
            ]
            if file_glob != "**/*":
                cmd.extend(["-g", file_glob])
            cmd.append(".")

            result = subprocess.run(
                cmd,
                cwd=self._root,
                capture_output=True,
                text=True,
            )
            if result.returncode not in (0, 1):
                return [{"error": result.stderr}]

            results = []
            for line in result.stdout.splitlines():
                if not line.strip():
                    continue
                data = json.loads(line)
                if data.get("type") == "match":
                    md = data["data"]
                    abs_p = (self._root / md["path"]["text"]).resolve()
                    rel = abs_p.relative_to(self._root)
                    results.append({
                        "file": str(rel),
                        "line": md["line_number"],
                        "content": md["lines"]["text"].rstrip(),
                    })
            return results[:max_results]

        except FileNotFoundError:
            return self._python_grep(pattern, file_glob, max_results)
        except Exception as e:
            return [{"error": str(e)}]

    def _python_grep(
        self, pattern: str, file_glob: str, max_results: int
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        try:
            for p in self._root.glob(file_glob):
                if not p.is_file():
                    continue
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        for line_num, line in enumerate(f, 1):
                            if pattern.lower() in line.lower():
                                results.append({
                                    "file": str(p.relative_to(self._root)),
                                    "line": line_num,
                                    "content": line.rstrip(),
                                })
                                if len(results) >= max_results:
                                    return results
                except (UnicodeDecodeError, PermissionError):
                    continue
        except Exception as e:
            return [{"error": str(e)}]
        return results

    def stat(self, path: str) -> dict[str, Any]:
        file_path = self._resolve(path)
        if file_path is None:
            return {"error": "Path outside workspace"}
        if not file_path.exists():
            return {"error": "File not found"}
        s = file_path.stat()
        return {
            "path": path,
            "size": s.st_size,
            "modified": s.st_mtime,
            "is_file": file_path.is_file(),
            "is_directory": file_path.is_dir(),
            "extension": file_path.suffix,
        }

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def write(self, path: str, content: str) -> dict[str, Any]:
        p = Path(path)
        if p.is_absolute():
            try:
                path = str(p.relative_to(self._root))
            except ValueError:
                pass  # Security check below handles it

        file_path = self._resolve(path)
        if file_path is None:
            return {"error": "Path outside workspace"}

        if file_path.exists():
            return {
                "error": (
                    f"File already exists: '{path}'. "
                    "Use update_file to modify existing files."
                )
            }

        file_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            return {"error": str(e)}

        return {
            "success": True,
            "path": str(file_path),
            "bytes_written": len(content.encode("utf-8")),
        }

    def overwrite(self, path: str, content: str) -> dict[str, Any]:
        file_path = self._resolve(path)
        if file_path is None:
            return {"error": "Path outside workspace"}

        file_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = file_path.with_suffix(file_path.suffix + ".tmp")
        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    f.write(content)
                    f.flush()
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            temp_path.replace(file_path)
        except Exception as e:
            if temp_path.exists():
                temp_path.unlink()
            return {"error": str(e)}

        return {"success": True, "path": str(file_path)}

    def edit(self, path: str, old_content: str, new_content: str) -> dict[str, Any]:
        read_result = self.read(path)
        if "error" in read_result:
            return read_result
        current = read_result["content"]
        if old_content not in current:
            return {"error": f"old_content not found in '{path}'"}
        updated = current.replace(old_content, new_content, 1)
        return self.overwrite(path, updated)

    def write_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        file_path = self._resolve(path)
        if file_path is None:
            return {"error": "Path outside workspace"}
        file_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(file_path, "wb") as f:
                f.write(data)
        except Exception as e:
            return {"error": str(e)}
        return {"success": True, "path": str(file_path)}

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        timeout = max(1, min(timeout, 300))

        work_dir = self._root
        if cwd:
            resolved_cwd = self._resolve(cwd)
            if resolved_cwd is None:
                return {"error": "Working directory outside workspace"}
            if not resolved_cwd.exists():
                return {"error": "Working directory does not exist"}
            if not resolved_cwd.is_dir():
                return {"error": "Working directory is not a directory"}
            work_dir = resolved_cwd

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "command": command,
                "cwd": str(work_dir.relative_to(self._root)),
                "success": result.returncode == 0,
            }
        except subprocess.TimeoutExpired:
            return {
                "error": f"Command timed out after {timeout} seconds",
                "command": command,
            }
        except Exception as e:
            return {"error": str(e), "command": command}
