"""StateBackend — pure in-memory implementation of BackendProtocol for testing."""

import fnmatch
import re
from pathlib import Path, PurePosixPath
from typing import Any


def _glob_to_regex(pattern: str) -> re.Pattern:
    """Convert a glob pattern (with ** support) to a compiled regex."""
    regex = ""
    i = 0
    while i < len(pattern):
        if pattern[i : i + 2] == "**":
            regex += ".*"
            i += 2
            # Skip the trailing / if present so "**/" collapses cleanly
            if i < len(pattern) and pattern[i] == "/":
                i += 1
        elif pattern[i] == "*":
            regex += "[^/]*"
            i += 1
        elif pattern[i] == "?":
            regex += "[^/]"
            i += 1
        elif pattern[i] in ".^$+{}[]|()":
            regex += re.escape(pattern[i])
            i += 1
        else:
            regex += pattern[i]
            i += 1
    return re.compile(f"^{regex}$")


class StateBackend:
    """
    In-memory backend. Stores files in a dict keyed by normalised relative paths.
    execute() raises NotImplementedError — this is the sandboxing mechanism.
    """

    def __init__(self) -> None:
        self._files: dict[str, str] = {}
        self._binary: dict[str, bytes] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _normalize(self, path: str) -> str:
        """Normalise to forward-slash relative path without leading slash."""
        return str(PurePosixPath(path)).lstrip("/").lstrip("./").rstrip("/") or "."

    def _key(self, path: str) -> str:
        n = self._normalize(path)
        return n

    def _virtual_dirs(self) -> set[str]:
        """Return set of virtual directory paths implied by file keys."""
        dirs: set[str] = set()
        for key in self._files:
            parts = key.split("/")
            for i in range(1, len(parts)):
                dirs.add("/".join(parts[:i]))
        return dirs

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def read(
        self,
        path: str,
        *,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        key = self._key(path)
        if key not in self._files:
            return {"error": "File not found"}
        content = self._files[key]
        lines = content.splitlines(keepends=True)
        total_lines = len(lines)
        start = offset if offset is not None else 0
        end = (start + limit) if limit is not None else total_lines
        selected = lines[start:end]
        return {
            "content": "".join(selected),
            "total_lines": total_lines,
            "lines_returned": len(selected),
            "path": path,
        }

    def ls(self, path: str = ".", *, max_depth: int = 1) -> dict[str, Any]:
        base = self._normalize(path)
        if base == ".":
            base = ""

        all_dirs = self._virtual_dirs()

        # Check the requested path is a known dir or root
        if base and base not in all_dirs:
            if base not in self._files:
                return {"error": "Directory not found"}
            return {"error": "Not a directory"}

        directories: list[str] = []
        files: list[dict[str, Any]] = []
        seen_dirs: set[str] = set()

        for key in sorted(self._files.keys()):
            # Must be under base (or all files if base is empty)
            if base:
                if not key.startswith(base + "/"):
                    continue
                rel = key[len(base) + 1:]
            else:
                rel = key

            parts = rel.split("/")
            depth = len(parts) - 1  # directories above the file
            if depth >= max_depth:
                # Too deep — record the top-level sub-dir if not yet seen
                top_dir = (base + "/" + parts[0]) if base else parts[0]
                if top_dir not in seen_dirs:
                    seen_dirs.add(top_dir)
                    directories.append(top_dir)
                continue

            if len(parts) == 1:
                # Direct child file
                files.append({"path": key, "size": len(self._files[key])})
            else:
                # Intermediate directory at depth <= max_depth - 1
                top_dir = (base + "/" + parts[0]) if base else parts[0]
                if top_dir not in seen_dirs:
                    seen_dirs.add(top_dir)
                    directories.append(top_dir)

        return {
            "path": path,
            "directories": sorted(set(directories))[:100],
            "files": files[:100],
        }

    def glob(self, pattern: str, *, max_results: int = 100) -> list[str]:
        try:
            compiled = _glob_to_regex(pattern)
            matches = []
            for key in sorted(self._files.keys()):
                if compiled.match(key):
                    matches.append(key)
                    if len(matches) >= max_results:
                        break
            return matches
        except Exception as e:
            return [f"Error: {e}"]

    def grep(
        self,
        pattern: str,
        *,
        file_glob: str = "**/*",
        context_lines: int = 2,
        max_results: int = 50,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        try:
            compiled = re.compile(pattern)
        except re.error as e:
            return [{"error": f"Invalid regex: {e}"}]

        file_compiled = _glob_to_regex(file_glob)
        for key in sorted(self._files.keys()):
            if not file_compiled.match(key):
                continue
            content = self._files[key]
            for line_num, line in enumerate(content.splitlines(), 1):
                if compiled.search(line):
                    results.append({
                        "file": key,
                        "line": line_num,
                        "content": line,
                    })
                    if len(results) >= max_results:
                        return results
        return results

    def stat(self, path: str) -> dict[str, Any]:
        key = self._key(path)
        if key in self._files:
            return {
                "path": path,
                "size": len(self._files[key]),
                "modified": 0.0,
                "is_file": True,
                "is_directory": False,
                "extension": Path(key).suffix,
            }
        if key in self._virtual_dirs():
            return {
                "path": path,
                "size": 0,
                "modified": 0.0,
                "is_file": False,
                "is_directory": True,
                "extension": "",
            }
        return {"error": "File not found"}

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def write(self, path: str, content: str) -> dict[str, Any]:
        key = self._key(path)
        if key in self._files:
            return {
                "error": (
                    f"File already exists: '{path}'. "
                    "Use update_file to modify existing files."
                )
            }
        self._files[key] = content
        return {
            "success": True,
            "path": path,
            "bytes_written": len(content.encode("utf-8")),
        }

    def overwrite(self, path: str, content: str) -> dict[str, Any]:
        key = self._key(path)
        self._files[key] = content
        return {"success": True, "path": path}

    def edit(self, path: str, old_content: str, new_content: str) -> dict[str, Any]:
        key = self._key(path)
        if key not in self._files:
            return {"error": "File not found"}
        current = self._files[key]
        if old_content not in current:
            return {"error": f"old_content not found in '{path}'"}
        self._files[key] = current.replace(old_content, new_content, 1)
        return {"success": True, "path": path}

    def write_bytes(self, path: str, data: bytes) -> dict[str, Any]:
        key = self._key(path)
        self._binary[key] = data
        return {"success": True, "path": path}

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, Any]:
        raise NotImplementedError("StateBackend does not support command execution (sandbox mode)")
