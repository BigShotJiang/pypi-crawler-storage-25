"""Pluggable backend system for ctrl+code tool I/O."""

from .protocol import BackendProtocol
from .filesystem import FilesystemBackend
from .state import StateBackend
from .composite import CompositeBackend

__all__ = [
    "BackendProtocol",
    "FilesystemBackend",
    "StateBackend",
    "CompositeBackend",
]
