"""Interactive first-run setup wizard for ctrl+code."""

import os
import stat
import sys
from pathlib import Path
from typing import Optional, List, Tuple


# ---------------------------------------------------------------------------
# Terminal helpers
# ---------------------------------------------------------------------------

def _print(msg: str = "", end: str = "\n") -> None:
    print(msg, end=end, flush=True)


def _bold(text: str) -> str:
    return f"\033[1m{text}\033[0m" if sys.stdout.isatty() else text


def _dim(text: str) -> str:
    return f"\033[2m{text}\033[0m" if sys.stdout.isatty() else text


def _green(text: str) -> str:
    return f"\033[32m{text}\033[0m" if sys.stdout.isatty() else text


def _yellow(text: str) -> str:
    return f"\033[33m{text}\033[0m" if sys.stdout.isatty() else text


def _prompt(label: str, default: str = "", secret: bool = False) -> str:
    suffix = f" [{default}]" if default and not secret else ""
    prompt_str = f"  {_bold(label)}{suffix}: "
    try:
        if secret:
            import getpass
            value = getpass.getpass(prompt_str)
        else:
            value = input(prompt_str)
    except (KeyboardInterrupt, EOFError):
        _print()
        return ""
    return value.strip() or default


def _choose(label: str, options: list[tuple[str, str]], allow_custom: bool = False) -> str:
    """Numbered menu. Returns the value of the chosen option.
    If allow_custom is True, user may type a model name not in the list."""
    _print(f"\n  {_bold(label)}")
    for i, (_, display) in enumerate(options, 1):
        _print(f"    {_dim(str(i) + '.')} {display}")
    if allow_custom:
        _print(f"    {_dim('m.')} Enter model name manually")
    while True:
        raw = _prompt(f"Choose [1-{len(options)}{'|m' if allow_custom else ''}]", default="1")
        if allow_custom and raw.lower() == "m":
            return _prompt("Model name")
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(options):
                return options[idx][0]
        except ValueError:
            pass


# ---------------------------------------------------------------------------
# Provider model fetching
# ---------------------------------------------------------------------------

def _fetch_anthropic_models(api_key: str, base_url: str) -> list[tuple[str, Optional[int]]]:
    """Return list of (model_id, context_window) from Anthropic models API."""
    import urllib.request, json
    url = base_url.rstrip("/") + "/models"
    req = urllib.request.Request(
        url,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read())
            return [
                (m["id"], m.get("context_window"))
                for m in data.get("data", []) if m.get("id")
            ]
    except Exception:
        return []


def _fetch_openai_models(api_key: str, base_url: str) -> list[tuple[str, Optional[int]]]:
    """Return list of (model_id, context_window) from an OpenAI-compatible /models endpoint."""
    import urllib.request, json
    url = base_url.rstrip("/") + "/models"
    headers: dict[str, str] = {"accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read())
            return sorted(
                [(m["id"], m.get("context_window") or m.get("max_model_len"))
                 for m in data.get("data", []) if m.get("id")],
                key=lambda x: x[0],
            )
    except Exception:
        return []


def _pick_model(models: list[tuple[str, Optional[int]]], label: str) -> tuple[str, Optional[int]]:
    """Let the user choose from a fetched model list. Returns (model_id, context_window)."""
    if not models:
        name = _prompt(f"{label} model name")
        return name, None
    options = [
        (mid, f"{mid}  {_dim('(' + str(ctx // 1024) + 'k ctx)') if ctx else ''}")
        for mid, ctx in models
    ]
    ctx_by_id = {mid: ctx for mid, ctx in models}
    chosen = _choose(label, options, allow_custom=True)
    return chosen, ctx_by_id.get(chosen)


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

_SECTION_TEMPLATE = """\
[providers.{name}]
model = "{model}"{base_url_line}
"""


def _build_config(sections: list[dict], context_limit: int = 200000, skills_dir: str = "") -> str:
    prune_protect = min(50000, max(20000, context_limit // 5))
    header = (
        "# ctrl+code configuration\n"
        "# ---------------------------------------------------------------------------\n\n"
        "# Server — host/port the harness listens on, plus the shared API key used by\n"
        "# the TUI to authenticate with the local server.\n"
        "[server]\n"
        'host = "127.0.0.1"\n'
        "port = 8765\n\n"
    )
    providers_comment = (
        "# Providers — configure one or more LLM backends. ctrl+code prefers Anthropic\n"
        "# when both are present. Add base_url to point at a self-hosted endpoint.\n"
    )
    body = providers_comment
    for s in sections:
        base_url_line = f'\nbase_url = "{s["base_url"]}"' if s.get("base_url") else ""
        body += _SECTION_TEMPLATE.format(
            name=s["name"],
            model=s["model"],
            base_url_line=base_url_line,
        )
    context_section = (
        "\n# Context — controls how much conversation history is kept in the model's\n"
        "# context window. prune_protect is the minimum token budget reserved for the\n"
        "# active turn; default_limit is the total context window size.\n"
        f"[context]\n"
        f"prune_protect = {prune_protect}\n"
        f"default_limit = {context_limit}\n"
    )
    skills_section = (
        "\n# Skills — path to a directory of custom skill files (.md). Skills extend\n"
        "# the agent with reusable prompt templates invocable by name.\n"
        f'[skills]\ndirectory = "{skills_dir}"\n'
    ) if skills_dir else ""
    security_section = (
        "\n# Security — input validation and rate limiting. Uncomment and adjust to\n"
        "# override the defaults shown below.\n"
        "# [security]\n"
        "# max_input_length = 200000        # max chars per user message, -1 = unlimited\n"
        "# rate_limit_enabled = true\n"
        "# rate_limit_window_seconds = 60.0\n"
        "# rate_limit_max_requests = 30\n"
    )
    trajectories_section = (
        "\n# Trajectories — opt-in collection of session transcripts for training data.\n"
        "# Set enabled = true to start capturing.\n"
        "[trajectories]\n"
        "enabled = false\n"
    )
    return header + body + context_section + skills_section + security_section + trajectories_section


def _write_config(config_path: Path, content: str) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(content)
    config_path.chmod(stat.S_IRUSR | stat.S_IWUSR)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def needs_setup() -> bool:
    """Return True if no provider is configured (env or config file)."""
    from ctrlcode.config import Config
    config = Config.load()
    return config.anthropic is None and config.openai is None


def run_setup() -> bool:
    """
    Run interactive first-run setup wizard.

    Returns True if at least one provider was configured, False if aborted.
    """
    from ctrlcode.paths import get_config_dir

    config_path = get_config_dir() / "config.toml"
    configured_sections: list[dict] = []
    _keys_entered_this_session: list[str] = []
    detected_context_limit: Optional[int] = None

    _print()
    _print(_bold("  Welcome to ctrl+code"))
    _print(_dim("  Let's get you set up — this only takes a minute."))
    _print()

    # --- Provider menu ---
    _print(f"  {_bold('Which providers would you like to configure?')}")
    _print(f"  {_dim('(You can configure multiple — ctrl+code will prefer Anthropic by default)')}")

    providers_to_configure = []

    for short, label, default_base in [
        ("anthropic", "Anthropic (Claude)", "https://api.anthropic.com/v1"),
        ("openai",    "OpenAI",             "https://api.openai.com/v1"),
        ("custom",    "Self-hosted / compatible (Ollama, vLLM, LiteLLM…)", ""),
    ]:
        _print()
        raw = _prompt(f"Configure {label}? [y/N]", default="n")
        if raw.lower().startswith("y"):
            providers_to_configure.append((short, label, default_base))

    if not providers_to_configure:
        _print()
        _print(f"  {_yellow('⚠')}  No providers selected.")
        _print("  You can configure later by editing:")
        _print(f"  {_dim(str(config_path))}")
        _print()
        return False

    # --- Configure each provider ---
    for short, label, default_base in providers_to_configure:
        _print()
        _print(f"  {_bold('─── ' + label + ' ───')}")

        # Base URL (always ask for custom; optional for official providers)
        if short == "custom":
            base_url = _prompt("Base URL (e.g. http://localhost:11434/v1)")
            if not base_url:
                _print(f"  {_yellow('Skipping')} — base URL required for self-hosted")
                continue
            section_name = "openai"  # OpenAI-compat wire
        else:
            raw_url = _prompt(f"Base URL", default=default_base)
            base_url = raw_url if raw_url != default_base else ""
            section_name = short

        # API key
        env_var = "ANTHROPIC_API_KEY" if short == "anthropic" else "OPENAI_API_KEY"
        existing_key = os.environ.get(env_var, "").strip()

        if existing_key:
            _print(f"  {_green('✓')} Using {env_var} from environment")
            api_key = existing_key
        else:
            if short == "anthropic":
                _print(f"  {_dim('Get a key at: https://console.anthropic.com/')}")
            elif short == "openai":
                _print(f"  {_dim('Get a key at: https://platform.openai.com/')}")
            api_key = _prompt("API key (or Enter to skip)", secret=True)
            if not api_key and short != "custom":
                _print(f"  {_dim('Skipping ' + label)}")
                continue

        # Fetch models
        effective_base = (base_url or default_base)
        _print(f"  Fetching available models…", end="\r")

        if short == "anthropic":
            models = _fetch_anthropic_models(api_key, effective_base)
        else:
            models = _fetch_openai_models(api_key, effective_base)

        if models:
            _print(f"  {_green('✓')} Found {len(models)} model(s)          ")
        else:
            _print(f"  {_yellow('!')}  Could not fetch models — enter name manually")

        model, context_window = _pick_model(models, "Model")
        if not model:
            _print(f"  {_dim('Skipping ' + label + ' — no model selected')}")
            continue

        # Use the first provider's context window to set config limits
        if context_window and detected_context_limit is None:
            detected_context_limit = context_window

        # Store key in environment for this process
        if api_key and not existing_key:
            os.environ[env_var] = api_key
            _keys_entered_this_session.append(env_var)

        configured_sections.append({
            "name": section_name,
            "model": model,
            "base_url": base_url,
        })
        _print(f"  {_green('✓')} {label} configured ({model})")

    if not configured_sections:
        _print()
        _print(f"  {_yellow('⚠')}  No providers were configured.")
        return False

    # --- Write config ---
    skills_dir = get_config_dir() / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    _write_config(config_path, _build_config(
        configured_sections,
        context_limit=detected_context_limit or 200000,
        skills_dir=str(skills_dir),
    ))

    _print()
    _print(f"  {_green('✓')} Config written to {_dim(str(config_path))}")

    # Remind user to persist any keys we collected (that weren't already in env)
    if _keys_entered_this_session:
        _print()
        _print(f"  {_yellow('!')}  Add your key(s) to your shell profile so they persist:")
        for k in _keys_entered_this_session:
            _print(f"      export {k}={repr(os.environ[k])}")

    _print()
    _print(f"  {_bold('Starting ctrl+code...')}")
    _print()

    return True
