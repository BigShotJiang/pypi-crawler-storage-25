# SDLC Doctrine (Portable)

One-page reference for the kd-and-YouTrack-native SDLC. Aimed at operators and
LLM agents running sessions in any project on this substrate. Canonical source
for "where does this go?", "how do I run a session?", and "what happens
when X?". Questions before theory.

## About this doctrine

This is the portable SDLC doctrine bundled with kd-cli. It describes the
invariant method — layers, cycles, verification modes, publication tiers,
marker-bridged files, cache semantics, repo-doc audit — that all
doctrine-aligned projects share. Project-specific agreements (document
naming, required fields, routing, closeout-gate checklists) belong in an
**SDLC profile** article in the project's own tracker; pin the profile
from `.kd/primer.yaml` to make it the active reference for the workspace.

The bundled body is the starting template. A project may publish this text
as its canonical doctrine article, edit a copy to suit local conventions, or
inherit it verbatim and capture variations in a profile.

## The three layers

Every artifact in the project lives in exactly one of three homes.

- **Layer A — Upstream (YouTrack).** Canonical. Epic issues are the planning
  containers for milestone-sized work; child issues carry session-level
  execution; articles hold durable knowledge (design records, non-code-adjacent
  how-tos, branch indexes, daybooks, migration playbooks).
- **Layer B — Thin repo.** Committed, version-controlled, reviewed in PRs.
  Only files that satisfy one of four mechanical categories (below).
- **Layer C — Workspace-local.** Under `.kd/`, never committed. Primer +
  disposable cache.

Files that satisfy no layer's rules do not belong anywhere.

## Where does this file go?

Layer B membership is **mechanical**, binary per file. No per-read "is this
code-adjacent enough?" judgment.

| Category         | Contents                                                     | Examples                                                    |
|------------------|--------------------------------------------------------------|-------------------------------------------------------------|
| Harness-consumed | Files LLM harnesses or humans load every session             | `AGENTS.md`, `RULES.md`, `CODING_STYLE.md`, `CLAUDE.md`     |
| Tool-packaged    | Ships in the wheel / consumed by the installed tool          | Embedded operating guide, packaged data                     |
| Build-essential  | Build + release machinery                                    | `pyproject.toml`, CI config, `CHANGELOG.md`                 |
| Marker-bridged   | Carries a `kd-meta` marker pointing at an upstream article   | ADRs, code-coupled specs                                    |

Decision flow:

1. Read on every session by the harness or humans? → **Harness-consumed**.
2. Ships in the wheel? → **Tool-packaged**.
3. Part of build or release? → **Build-essential**.
4. ADR or spec that needs **both** review coupling **and** upstream
   discoverability? → **Marker-bridged**.
5. Everything else → Layer A (upstream article).

**Repo documentation audit.** At closeout, every committed documentation file
must satisfy one Layer B category. If a document moved upstream, delete the
repo copy unless it still remains harness-consumed, tool-packaged,
build-essential, or marker-bridged. Exceptions require an explicit compliance
or audit reason recorded in the file or linked issue.

**Incubation exception.** A repo-local proposal staging area (the convention
is a `proposals` folder under the project's docs tree) is an explicit place
for design drafts. At acceptance, a proposal migrates upstream as an article
(`kind:proposal`, `lifecycle:accepted`); the local file is deleted. Not a
general drafting sink.

## Marker-bridged files

Marker-bridged files are **repo-authoritative; upstream renders**. The reviewed
source of truth is the git file. YouTrack makes that content discoverable and
linkable from issues, but it is not a second editable source.

The repo file and the upstream render are not two sources to keep in sync;
they are one artifact in two forms. `kd /article push` propagates from form
one (the reviewed git file) to form two (the upstream render). Nothing
propagates in the reverse direction unless an operator runs `kd /article
pull` and merges by hand. Treat the upstream copy as a rendered view, not
as a peer.

- Review happens in the repo PR.
- Push happens after merge to the canonical branch, or by explicit operator
  action / narrow post-merge automation.
- No blind overwrite **when a baseline exists**: every update push performs a
  live read of the upstream `updated` field. Baseline priority is
  `cache > legacy_marker > none`: when the per-connection cache holds a sidecar
  for the article, its `upstream_updated` is the drift baseline
  (`conflict_check: cache`); otherwise the legacy in-marker timestamp drives
  the check (`conflict_check: legacy_marker`); identity-only markers with no
  cache report `conflict_check: skipped_no_baseline` and proceed under the
  explicit trust-new policy. Every successful push refreshes the active-
  connection cache scope so the seam stays current invocation-to-invocation.
  Cache reads are fail-closed: a malformed sidecar refuses before any upstream
  write. If both upstream and repo changed, pull, diff, merge by hand, then
  push. `--force` is only for an inspected overwrite.
- The `kd-meta` marker is identity (`slug` + `upstream-id`), not tool state.
  Push inserts the marker on the first push that creates or resolves the
  upstream article (and again only to repair a stale `upstream-id`); commit
  that one-time change with the content. Subsequent pushes leave the local
  file byte-identical, and a stderr notice flags any write-back when it
  actually happens. Files written by older kd versions still carry an
  `upstream-updated` line — the parser keeps accepting it for forward
  compatibility, but new pushes and new pulls never emit it.

## What belongs upstream as an article?

- Design records (what used to be `docs/design/`).
- Specs not coupled to code review.
- How-tos that don't require the source tree.
- Branch indexes (`Index: Proposals`, `Index: How-to`, etc.).
- Migration playbooks.
- One daybook per project (`kind:daybook`).

Operational articles need enough structure to stay network-shaped, not just
searchable prose. Minimum metadata: `kind:*`, `lifecycle:*`, owning project,
and relevant backrefs to governing epics, issues, proposals, or code-coupled
artifacts.

### Proposal shape in YouTrack

A proposal is a **knowledge artifact**, not an execution container.

- During incubation, the draft may live locally in the repo's proposal
  staging area.
- Once accepted, the canonical proposal is a **YouTrack article** tagged
  `kind:proposal` and `lifecycle:accepted`.
- Epics and session issues may link to the proposal when it governs the work,
  but the proposal itself does not replace the epic → child-issue planning
  hierarchy.
- Do not model proposals as a substitute for milestone containers or session
  tickets.

### Tag taxonomy pattern

Adapt per project; shared tags stay consistent across projects:

- `kind:*` — artifact type: `kind:proposal`, `kind:how-to`, `kind:spec`,
  `kind:design`, `kind:adr`, `kind:sdlc`, `kind:index`, `kind:daybook`,
  `kind:history`, `kind:digest`.
- `lifecycle:*` — state: `lifecycle:draft`, `lifecycle:accepted`,
  `lifecycle:deprecated`, `lifecycle:historical`.
- `area:*`, `component:*`, `module:*` — per-project domain tags.
- `market:*`, `meter:*`, etc. — per-project commercial / domain extensions.

## How do I model milestone-sized work?

Use native YouTrack hierarchy for execution work. Do not flatten planning
structure into a free-text custom field.

- **Proposal / rationale** lives as an article (`kind:proposal`, design note,
  migration playbook, etc.). It is durable knowledge, not the execution
  container.
- **Epic issue** is the canonical container for one milestone-sized body of
  work.
- **Session issue** (task / story / session) is a child of the epic and holds
  one execution slice with its own closeout.
- **Optional subtask or checklist item** breaks a session issue down further
  when that improves execution clarity.
- **Custom fields such as `Milestone` are auxiliary.** They can support
  filtering, board grouping, or reporting, but they do not replace the epic →
  child-issue structure and must not be the only place where the hierarchy
  exists.
- **Ordering is explicit when needed.** If sessions must run in a fixed order,
  record that order on the child issues or in the epic plan; do not rely on a
  free-text milestone string or title convention as the sole source of
  sequencing.

## How do I run a session?

Four inputs decide the cycle variant.

| Input    | State(s)                  | Consequence                                                 |
|----------|---------------------------|-------------------------------------------------------------|
| Tracker  | Reachable / Unreachable   | Unreachable → offline cycle                                 |
| Ticket   | Exists / Missing          | Missing → create a ticket or use the umbrella               |
| HITL     | N/A / Executed / Deferred | Deferred → name the reason; no auto follow-up ticket        |
| Cache    | Warm / Cold               | Cold + tracker unreachable → cold-start cycle               |

### Standard cycle

Tracker + ticket + HITL all green (or HITL N/A). Commit prefix `PROJ-N:`.
Close out per publication tiers.

### Offline cycle

Tracker unreachable, cache warm. Commits land with `PROJ-N:` prefix as
usual. Reconciliation (push commits, post closeouts, transition state)
happens at the next online session — see *What happens when the tracker
is down?* below.

### No-HITL cycle

Two sub-states:

- **HITL not applicable.** Task has no upstream-facing behavior (docstring
  cleanup, internal refactor, tooling change). Closeout proceeds standardly
  with no HITL mention; verification mode is `not_applicable`.
- **HITL deferred.** Surface exists and HITL would be desirable, but was
  not run (no test tenant, destructive op, time pressure). Closeout names
  the reason. **No follow-up ticket is created automatically.** Next steps
  absorb the risk: the next session that touches the surface picks it up,
  or a real incident creates a real ticket on its own terms.

### No-ticket cycle

Ad-hoc exploration, proposal drafting, or hygiene work. Rule: **no commit
lands without a ticket prefix.** Two compliant paths:

- **New-ticket path.** Exploration produces code worth keeping: create or
  select the ticket first, then commit with `PROJ-N:` prefix.
- **Umbrella path.** See *When do I use the umbrella ticket?* below.

### Cold-start cycle

Fresh clone / no cache / no tracker. Work is limited to repo-local reading,
code review, and proposal drafting in the repo's staging area for later
migration.
Fallback variant.

## What's project-specific?

The portable doctrine names the invariant method: layers, cycles,
verification modes, publication tiers, marker-bridged files, cache
semantics, repo-doc audit, umbrella rule. Project-specific policy belongs
in an **SDLC profile** — a project-local upstream article that inherits
this doctrine and records configurable agreements: document naming,
required fields like `Updated:` lines, routing tables, closeout-gate
checklists, timeless-doc rules, and any project-shaped variations on the
publication tiers.

A workspace declares its profile by pinning the profile article in
`.kd/primer.yaml`. The session-start load sequence becomes: primer →
portable doctrine → project profile → assigned ticket. A project may
operate without a profile when its conventions match the portable
doctrine verbatim; the mechanism exists so project-specific agreements
have a canonical home before they leak back into the doctrine and bloat
it.

Tooling support (doctrine-aware lint or template commands, profile
inspection) is a separate, deferred concern. The profile mechanism
itself is the contract; tooling can grow against it later without
changing the doctrine.

## How do I verify HITL?

A small closed vocabulary replaces ambiguous "simulated HITL" / "realistic
testing" phrasing. Record the mode in the session closeout.

| Mode             | Meaning                                                    | Closeout consequence                              |
|------------------|------------------------------------------------------------|---------------------------------------------------|
| `live_hitl`      | Real upstream read + write verification completed          | Full closeout                                     |
| `read_only_hitl` | Real upstream reads; writes not exercised                  | Closeout with explicit limitation                 |
| `cached`         | Verified against hydrated cache only                       | Closeout notes upstream validation debt           |
| `simulated`      | Unit tests / fixtures only                                 | Defer closeout if behavior touches upstream       |
| `not_applicable` | No upstream-facing behavior                                | No HITL mention required                          |

## How do I close out a session?

Publication is **tiered**, not verbatim-always. The goal is durable trace,
not log migration.

| Session kind                   | Upstream record                                                                         |
|--------------------------------|-----------------------------------------------------------------------------------------|
| Short session                  | Full closeout comment on the issue (changes, files, decisions, test results)            |
| Long session                   | Compact issue capsule (paragraph summary + outcomes) + article link for durable parts   |
| Durable reference produced     | Publish the artifact as an article; reference from the issue capsule                    |
| Ephemeral raw thinking         | Do not publish raw. Summarize the outcome; discard the rest                             |

Test question: *would a future reader of this issue benefit from reading
the full session, or only from the outcome?* Full session → publish;
outcome only → summarize.

**Recommended two-commit shape** for sessions that change both code and
operator-visible docs:

1. Code + tests.
2. Docs updates + session conclusion.

The split keeps code reviewable independently from documentation
bookkeeping. Single-commit closeout is fine when the session is docs-only,
hygiene-only, or small enough that splitting would add churn rather than
reviewability — the rule is "every commit carries a `PROJ-N:` prefix",
not "every session ships exactly two commits".

## What happens when the tracker is down?

Offline cycle. Session proceeds against cached context. Commits land with
`PROJ-N:` prefix as usual.

Reconciliation at the next online session is a **protocol step, not a
managed state file**:

1. `git log <last-online-head>..HEAD --grep='^[A-Z]\+-[0-9]\+:'` — lists
   tickets touched offline. The shipped helper is
   `kd /issue touched --git-range <A>..<B>` (local-only; never reads
   the tracker).
2. For each ticket: push commits, post the closeout record per the
   publication tiers, transition state.
3. Push any article edits drafted locally (major rewrites go via a scratch
   upstream article; minor edits push directly).

No local `pending-syncs.yaml` or equivalent. Git history is the queue;
commit prefixes are the index into it.

## What's in `.kd/`?

Three concepts are conceptually distinct. They differ in the one property
that matters: **what happens when you delete them.**

| Concept | Source of truth           | Deletion loss            | Where                              |
|---------|---------------------------|--------------------------|-----------------------------------|
| Cache   | Upstream (YouTrack)       | None — rehydrates        | `.kd/cache/`                      |
| State   | kd-local, durable         | Loses operational state  | Not introduced yet                |
| Scratch | Operator / LLM, transient | None by construction     | Out of scope; use `/tmp` or untracked files |

Today only cache exists. If durable local state becomes necessary, it gets
its own directory with its own contract — it does not move into the cache
directory.

### Cache contract

`.kd/cache/` contains only rehydratable upstream-mirror content (pulled
articles, pulled issues, cached tag lists, field schemas, query result
sets, staleness stamps). The active connection is the scope key:
multi-connection workspaces materialize one scope per connection at
`.kd/cache/connections/<slug>/`, where `<slug>` is the slugified
connection name (lowercased, whitespace and characters outside
`[a-z0-9_-]` collapsed). Content lands per kind under
`.kd/cache/connections/<slug>/articles/`,
`.kd/cache/connections/<slug>/issues/`, and
`.kd/cache/connections/<slug>/queries/`.

Each scope carries `scope.yaml` with the immutable identity tuple
`{kind, connection, provider, base_url, compat_tier, created_at}`.
Refresh is idempotent on full identity match and refuses to write into
a scope whose recorded identity diverges from the active connection —
that catches cases where renaming a connection while keeping the same
upstream would otherwise silently aim refreshes at the wrong scope dir.

- **Disposable.** Never committed. Deletion is always safe; an explicit
  `kd /cache refresh` selector rehydrates from upstream. Selectors are
  mutually exclusive — `--primer-scope`, `--issue ID`, `--article ID`,
  `--query NAME`, `--milestone VALUE`, `--epic ID --include-children`.
  Implicit read-through writes are out of scope.
- **Explicit staleness.** Every cached entry stamps its upstream `updated`
  time; readers know what they're looking at.
- **Read-side mirror, not a write buffer.** No sync, no queue.

**Clear semantics.** `kd /cache clear` defaults to the active scope
and does not require a live tracker (local-only operation, no token
resolution). `--all` clears the entire `.kd/cache/` tree, sweeping
every scope plus any legacy flat directories left by older kd
versions. Switch which scope is cleared with `kd -c NAME /cache clear`.

**Status semantics.** `kd /cache status` is the read-only counterpart:
default scan is workspace-wide (every scope plus an `unscoped:` block
for any legacy flat content from older kd versions), local-only with
no token resolved, and
reports per-kind counts, latest and oldest fetch, and a `stale_count`
against an inclusive `fetched_at <= now - stale_after_days` rule
(default 7 days; override per call with `--stale-after-days N`).
`--scope NAME` focuses on one scope, matched against each manifest's
`connection` field. Manifest validation here is schema-only; identity
drift between a `scope.yaml` and the active config is a write-time
concern owned by `refresh`, not flagged here.

**Self-describing banner.** Every cached artifact opens with a banner
that names the upstream entity and the fetched timestamp. Markdown
bodies (cached article `.md` files) use a comment banner:

```text
<!-- kd-cache: upstream=PROJ-A-1 fetched=2026-04-21T10:12:00Z.
     Disposable mirror. Edits lost on refresh. Not authoritative. -->
```

YAML payloads (cached issue `.yaml` and query `.yaml` files) use a
two-line `#`-prefixed banner with the same fields:

```text
# kd-cache: upstream=PROJ-105 fetched=2026-04-21T10:12:00Z.
# Disposable mirror. Edits lost on refresh. Not authoritative.
```

The banner is informational (not a `kd-meta` marker, not round-tripped).

### Three operations that look alike

Easy to confuse; naming them keeps cached content from drifting into
`docs/`:

| Operation              | Destination               | Ownership  | Mutability                                          |
|------------------------|---------------------------|------------|-----------------------------------------------------|
| Cache hydrate          | `.kd/cache/`              | kd-managed | Operator never edits; refresh overwrites            |
| Article pull (claim)   | `docs/…`                  | Operator   | One-shot transfer; operator authors thereafter      |
| Marker-bridged pull    | `docs/…` with `kd-meta`   | Operator   | Edits push back via the marker                      |

Cache hydrate covers long-offline warm-up and temporary bulk pulls. Neither
produces content that belongs in `docs/`.

### Write-gating

Commands that mutate upstream (create issue, push article, update tag,
transition state) **require a live tracker**. They refuse to operate on
cache-only context. No stale cache read can silently become a destructive
upstream write.

## Migration safety rules

When moving local operational docs upstream, keep the migration thin and
auditable:

- Create tag taxonomy and root/index articles first.
- Migrate in small slices: read → classify → push → readback → verify tags →
  delete local shadow → commit.
- Do not delete a local document before upstream readback confirms the article
  exists, is readable, and carries the intended tags/backrefs.
- The primer points to the migration plan; it does not track session progress.
- Do not leave "helpful" duplicate repo copies after migration unless they
  satisfy a Layer B category or a named compliance/audit exception.

## When do I use the umbrella ticket?

Each project declares **one fixed umbrella ticket** (pinned in the project
primer). The umbrella exists to preserve the "no commit without a ticket"
rule for work that genuinely has no story to tell.

**Use umbrella for:**

- Formatting / lint / whitespace sweeps
- Typo and comment fixes
- Dep bumps with no behavior change
- Internal hygiene with no narrative

**Do not use umbrella for:**

- Work that changes behavior
- Work that merits a changelog entry
- Work touching API contracts, tests, or docs beyond typos

**Test question:** *does this commit have a story worth telling?* Yes →
real ticket. No → umbrella is fine.

Umbrella is a tool for compliance, not an escape hatch. Overuse turns it
into a dumping ground where real work hides.

## Accepted tradeoffs

- **Article history lives in YouTrack page history.** No git-style
  line-level diff; no `git blame` into non-bridged articles; no
  `docs/**/*.md` CI hooks on non-bridged article edits. Mitigations:
  marker-bridged Layer B preserves review coupling for ADRs and code-
  coupled specs; major article rewrites draft in scratch upstream articles
  (`lifecycle:draft`) before promotion; accepted articles use append-only
  cross-ref banners when materially revised.
- **No write-sync daemon.** Cache is read-side mirror only. Upstream mutations
  always go through normal live commands and always require a live tracker.

## Session starter checklist

When you begin a session:

1. Load the project primer and this doctrine.
2. Read the assigned ticket (or create one / select the umbrella per
   no-ticket rules).
3. Classify the session: which cycle variant applies?
4. Plan in the session document (if the project still uses session docs
   locally) or directly against the ticket.
5. Execute: code, tests, docs.
6. Verify: run the project's `lint / type-check / tests` gate.
7. Close out per the publication tier that matches the session kind;
   record the verification mode and run the repo-doc audit when docs changed.
8. Commit: every commit carries a `PROJ-N:` prefix; use the recommended
   two-commit shape (code + tests, then docs + conclusion) when the
   session mixes both, single-commit otherwise.
9. Transition the ticket.

Updated: 2026-04-26
