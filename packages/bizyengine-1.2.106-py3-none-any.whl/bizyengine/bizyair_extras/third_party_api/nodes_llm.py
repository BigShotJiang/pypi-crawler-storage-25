import json
import logging

from bizyengine.misc.utils import cache_trd_models, get_trd_models

from .trd_nodes_base import BizyAirTrdApiBaseNode

_TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR = """{"gemini-3-pro-preview": "gemini-3-pro-preview", "gemini-3-flash-preview": "gemini-3-flash-preview"}"""


class TRD_LLM_API_DynamicReturnType:
    """描述符：每次访问都重新计算 RETURN_TYPES"""

    def __get__(self, obj, objtype=None):
        return (
            "STRING",
            _TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR,
        )


class LLMToolConfig(BizyAirTrdApiBaseNode):
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("tools",)
    CATEGORY = "☁️BizyAir/External APIs/LLm Tools"
    NODE_DISPLAY_NAME = "LLM Tool Config"
    FUNCTION = "execute"  # 覆盖api_call

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "enable_thinking": (
                    "BOOLEAN",
                    {
                        "default": False,
                        "tooltip": "是否开启思考模式",
                    },
                ),
                "web_search": (
                    "BOOLEAN",
                    {
                        "default": True,
                        "tooltip": "开启后，模型将根据输入情况按需进行联网搜索",
                    },
                ),
            }
        }

    def execute(self, **kwargs):
        web_search = kwargs.pop("web_search", True)
        tools = []
        if web_search:
            tools.append("web_search")
        return (json.dumps(tools),)

    # Return: data, model, prompt
    def handle_inputs(self, headers, prompt_id, **kwargs):
        pass

    # Return: videos, images, texts, output urls(as a json string of url string array)
    def handle_outputs(self, outputs):
        pass


class TRD_LLM_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Third-Party LLM API"
    RETURN_TYPES = TRD_LLM_API_DynamicReturnType()
    RETURN_NAMES = ("string", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/LLM"
    INPUT_IS_LIST = False

    @classmethod
    def INPUT_TYPES(s):
        type = "chat"
        models = get_trd_models(type)
        if models is None:
            logging.debug("TRD_LLM_API INPUT_TYPES caching models")
            cache_trd_models(type, "temp")
            models = get_trd_models(type)
            if models and "nodes" in models:
                models = models["nodes"]
                # 更新返回值定义中的模型映射，ComfyUI应该是先取INPUT再取RETURN所以可以被更新
                global _TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR
                logging.debug(f"prev: {_TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR}")
                _TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR = json.dumps(models)
                logging.debug(f"now: {_TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR}")
        elif "nodes" in models:
            logging.debug("TRD_LLM_API INPUT_TYPES using cache")
            models = models["nodes"]
        if models:
            models_list = list(models)
        else:
            models_list = ["gemini-3-pro-preview", "gemini-3-flash-preview"]
        return {
            "required": {
                "model": (
                    models_list,
                    {
                        "default": (
                            models_list[0]
                            if len(models_list) > 0
                            else "gemini-3-flash-preview"
                        )
                    },
                ),
                "system_prompt": (
                    "STRING",
                    {
                        "default": "你是一个有帮助的AI助手。",
                        "multiline": True,
                    },
                ),
                "user_prompt": (
                    "STRING",
                    {
                        "default": "你好，请介绍一下你自己。",
                        "multiline": True,
                    },
                ),
                "max_tokens": ("INT", {"default": 32768, "min": 1, "max": 65536}),
                "temperature": (
                    "FLOAT",
                    {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01},
                ),
            },
            "optional": {
                "tools": (
                    "STRING",
                    {
                        "default": "[]",
                        "tooltip": "来自 LLM Tool Config 节点的 tools 配置",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        temperature = kwargs.get("temperature", 1.0)
        max_tokens = kwargs.get("max_tokens", 32768)
        user_prompt = kwargs.get("user_prompt", "")
        system_prompt = kwargs.get("system_prompt", "")
        model = kwargs.get("model", "gemini-3-flash-preview")
        # model可能是展示名，映射成路径名
        try:
            model_mapping = json.loads(_TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR)
            if isinstance(model_mapping, dict):
                model = model_mapping[model]
        except Exception as e:
            logging.error(
                f"Failed to deserialize _TRD_LLM_API_DYNAMIC_RETURN_TYPES_STR: {e}"
            )

        tools_raw = kwargs.get("tools", "[]")
        try:
            tools = json.loads(tools_raw)
        except (json.JSONDecodeError, TypeError):
            tools = []

        data = {
            "user_prompt": user_prompt,
            "system_prompt": system_prompt,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "enable_thinking": "enable_thinking" in tools,
            "enable_search": "web_search" in tools,
            "tools": tools,
        }
        return data, model

    def handle_outputs(self, outputs):
        return (outputs[2][0], "")
