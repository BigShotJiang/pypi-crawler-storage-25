from .trd_nodes_base import BizyAirTrdApiBaseNode


class GPT_IMAGE_1_T2I_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "GPT Image 1 Text To Image"
    RETURN_TYPES = ("IMAGE", "STRING", """{"gpt-image-1": "gpt-image-1"}""")
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/OpenAI"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "size": (["1:1", "2:3", "3:2"], {"default": "1:1"}),
                "variants": ([1, 2, 4], {"default": 1}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        size = kwargs.get("size", "1:1")
        variants = kwargs.get("variants", 1)
        data = {
            "prompt": prompt,
            "size": size,
            "variants": variants,
        }
        if variants == 4:
            data["provider"] = "KieAI"
        return data, "gpt-image-1"

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class GPT_IMAGE_EDIT_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "GPT Image Edit"
    RETURN_TYPES = ("IMAGE", "STRING", """{"gpt-image-1": "gpt-image-1"}""")
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/OpenAI"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
                "size": (["1:1", "2:3", "3:2"], {"default": "1:1"}),
                "variants": ([1, 2, 4], {"default": 1}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        images = kwargs.get("images", None)
        if images is None:
            raise ValueError("Images are required")
        prompt = kwargs.get("prompt", "")
        size = kwargs.get("size", "1:1")
        variants = kwargs.get("variants", 1)

        urls = []
        for batch_number, img in enumerate(images if images is not None else []):
            if img is not None:
                url = self.upload_file(
                    self.compress_image(image=img, total_pixels=4096 * 4096),
                    f"{prompt_id}_{batch_number}.webp",
                    headers,
                )
                urls.append(url)
        if len(urls) == 0:
            raise ValueError("At least one image is required")

        data = {
            "urls": urls,
            "prompt": prompt,
            "size": size,
            "variants": variants,
        }
        if variants == 4:
            data["provider"] = "KieAI"
        return data, "gpt-image-1"

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class GPT_IMAGE_2_T2I_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "GPT Image 2 Text To Image"
    RETURN_TYPES = ("IMAGE", "STRING", """{"gpt-image-2": "gpt-image-2"}""")
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/OpenAI"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
            },
            "optional": {
                "aspect_ratio": (
                    [
                        "1:1",
                        "2:3",
                        "3:2",
                        "4:5",
                        "5:4",
                        "3:4",
                        "4:3",
                        "16:9",
                        "9:16",
                        "21:9",
                    ],
                    {
                        "default": "1:1",
                        "tooltip": "Aspect ratio of the generated image, default is 1:1, injected into prompt",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        aspect_ratio = kwargs.get("aspect_ratio", None)
        data = {
            "prompt": prompt,
        }
        if aspect_ratio:
            data["aspect_ratio"] = aspect_ratio
        return data, "gpt-image-2"

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")


class GPT_IMAGE_2_I2I_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "GPT Image 2 Image To Image"
    RETURN_TYPES = ("IMAGE", "STRING", """{"gpt-image-2": "gpt-image-2"}""")
    RETURN_NAMES = ("images", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/OpenAI"
    INPUT_IS_LIST = True

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "inputcount": (
                    "INT",
                    {
                        "default": 1,
                        "min": 1,
                        "max": 4,
                        "tooltip": "动态控制输入的参考图数量，范围1-4，点击Update inputs按钮刷新",
                    },
                ),
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                    },
                ),
            },
            "optional": {
                "aspect_ratio": (
                    [
                        "1:1",
                        "2:3",
                        "3:2",
                        "4:5",
                        "5:4",
                        "3:4",
                        "4:3",
                        "16:9",
                        "9:16",
                        "21:9",
                    ],
                    {
                        "default": "1:1",
                        "tooltip": "Aspect ratio of the generated image, default is 1:1, injected into prompt",
                    },
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        images = kwargs.get("images", [None])
        if images is None:
            raise ValueError("Images are required")
        prompt = kwargs.get("prompt", "")[0]
        aspect_ratio = kwargs.get("aspect_ratio", None)[0]

        # 图片上传
        total_input_images = 0
        for img_batch in images if images is not None else []:
            if img_batch is not None:
                total_input_images += img_batch.shape[0]
        extra_images, total_extra_images = self.get_extra_images(**kwargs)
        total_input_images += total_extra_images
        if total_input_images > 4:
            raise ValueError(
                "Total number of input images is too large, current maximum is 4"
            )

        single_image_size_limit = 10 * 1024 * 1024  # 10MB
        image_urls = []
        index = 1

        for img_batch in images if images is not None else []:
            for img in img_batch if img_batch is not None else []:
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    if bio.getbuffer().nbytes > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, maximum supported size is 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_image_{index}.webp",
                        headers,
                    )
                    image_urls.append(url)
                    index += 1

        for img_batch in extra_images:
            for img in img_batch if img_batch is not None else []:
                if img is not None:
                    bio = self.compress_image(
                        image=img,
                        total_pixels=6000 * 6000,
                        max_size=single_image_size_limit,
                    )
                    if bio.getbuffer().nbytes > single_image_size_limit:
                        raise ValueError(
                            "Image size is too large, maximum supported size is 10MB"
                        )
                    url = self.upload_file(
                        bio,
                        f"{prompt_id}_image_{index}.webp",
                        headers,
                    )
                    image_urls.append(url)
                    index += 1

        data = {
            "urls": image_urls,
            "prompt": prompt,
        }
        if aspect_ratio:
            data["aspect_ratio"] = aspect_ratio
        return data, "gpt-image-2"

    def handle_outputs(self, outputs):
        images = self.combine_images(outputs[1])
        urls_str = outputs[3]
        return (images, urls_str, "")
