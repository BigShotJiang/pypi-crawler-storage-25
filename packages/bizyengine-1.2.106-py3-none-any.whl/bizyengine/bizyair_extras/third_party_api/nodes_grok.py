import io

from .trd_nodes_base import BizyAirTrdApiBaseNode


class Grok_Imagine_Video_Third_Party_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Grok Imagine Video Third-Party"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"grok-imagine-video": "grok-imagine-video"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Grok"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "Prompt length must be between 5 and 20000 characters.",
                    },
                ),
                "model": (
                    ["grok-imagine-video"],
                    {"default": "grok-imagine-video"},
                ),
                "duration": ("INT", {"default": 6, "min": 6, "max": 30}),
            },
            "optional": {
                "image": (
                    "IMAGE",
                    {
                        "default": None,
                        "tooltip": "Optional image to guide video generation.",
                    },
                ),
                "aspect_ratio": (
                    ["9:16", "16:9", "1:1", "2:3", "3:2"],
                    {"default": "16:9"},
                ),
                "resolution": (
                    [
                        "480p",
                        "720p",
                    ],
                    {"default": "720p"},
                ),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        model = kwargs.get("model", "grok-imagine-video")
        image = kwargs.get("image", None)
        duration = kwargs.get("duration", 6)
        aspect_ratio = kwargs.get("aspect_ratio", "16:9")
        resolution = kwargs.get("resolution", "720p")
        prompt_length = len(prompt.strip()) if isinstance(prompt, str) else 0

        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required")
        if prompt_length < 5 or prompt_length > 20000:
            raise ValueError(
                "Prompt length for Grok Imagine Video Third-Party must be between 5 and 20000 characters"
            )

        data = {
            "prompt": prompt,
            "model": model,
            "duration": duration,
            "aspect_ratio": aspect_ratio,
            "resolution": resolution,
        }

        if image is not None:
            image_url = self.upload_file(
                self.compress_image(image=image, total_pixels=4096 * 4096),
                f"{prompt_id}.webp",
                headers,
            )
            data["urls"] = [
                image_url,
            ]

        return data, "grok-imagine-video"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "grok-imagine-video")


class Grok_Imagine_Video_Official_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Grok Imagine Video Official"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"grok-imagine-video-official": "grok-imagine-video-official"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Grok"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "Prompt length must be between 5 and 800 characters.",
                    },
                ),
                "model": (
                    ["grok-imagine-video-official"],
                    {"default": "grok-imagine-video-official"},
                ),
                "duration": ([6, 10], {"default": 6}),
            },
            "optional": {
                "image": ("IMAGE", {"default": None}),
                "aspect_ratio": (
                    ["9:16", "16:9", "1:1"],
                    {
                        "default": "16:9",
                        "tooltip": "Aspect ratio options for Grok Imagine Video Official. Not work when image input is provided.",
                    },
                ),
                "resolution": (["480p", "720p"], {"default": "720p"}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        prompt = kwargs.get("prompt", "")
        model = kwargs.get("model", "grok-imagine-video-official")
        image = kwargs.get("image", None)
        duration = kwargs.get("duration", 6)
        aspect_ratio = kwargs.get("aspect_ratio", "16:9")
        resolution = kwargs.get("resolution", "720p")
        prompt_length = len(prompt.strip()) if isinstance(prompt, str) else 0

        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required")
        if prompt_length < 5 or prompt_length > 800:
            raise ValueError(
                "Prompt length for Grok Imagine Video Official must be between 5 and 800 characters"
            )

        data = {
            "prompt": prompt,
            "model": model,
            "duration": duration,
            "resolution": resolution,
            "aspect_ratio": aspect_ratio,
        }

        if image is not None:
            image_url = self.upload_file(
                self.compress_image(image=image, total_pixels=4096 * 4096),
                f"{prompt_id}.webp",
                headers,
            )
            data["urls"] = [
                image_url,
            ]

        return data, "grok-imagine-video-official"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "grok-imagine-video-official")


class Grok_Imagine_Video_Edit_Official_API(BizyAirTrdApiBaseNode):
    NODE_DISPLAY_NAME = "Grok Imagine Video Edit Official"
    RETURN_TYPES = (
        "VIDEO",
        "STRING",
        """{"grok-imagine-video-edit-official": "grok-imagine-video-edit-official"}""",
    )
    RETURN_NAMES = ("video", "urls", "bizyair_model_name")
    CATEGORY = "☁️BizyAir/External APIs/Grok"

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": (
                    "STRING",
                    {
                        "multiline": True,
                        "default": "",
                        "tooltip": "Prompt length must be between 5 and 800 characters.",
                    },
                ),
                "model": (
                    ["grok-imagine-video-official"],
                    {"default": "grok-imagine-video-official"},
                ),
            },
            "optional": {
                "video": ("VIDEO", {"default": None}),
                "resolution": (["480p", "720p"], {"default": "720p"}),
            },
        }

    def handle_inputs(self, headers, prompt_id, **kwargs):
        video = kwargs.get("video", None)
        prompt = kwargs.get("prompt", "")
        model = kwargs.get("model", "grok-imagine-video-official")
        resolution = kwargs.get("resolution", "720p")
        prompt_length = len(prompt.strip()) if isinstance(prompt, str) else 0

        if prompt is None or prompt.strip() == "":
            raise ValueError("Prompt is required")
        if video is None:
            raise ValueError(
                "Video input is required for Grok Imagine Video Edit Official"
            )
        if prompt_length < 5 or prompt_length > 800:
            raise ValueError(
                "Prompt length for Grok Imagine Video Edit Official must be between 5 and 800 characters"
            )

        # 预校验标准：视频大小不超过50MB，最短1秒，最长8秒

        # 校验视频长度
        if hasattr(video, "get_duration") and callable(
            getattr(video, "get_duration", None)
        ):
            duration = video.get_duration()
            if duration > 8 or duration < 1:
                raise ValueError("Video duration must be between 1 and 8 seconds")
        if duration is None:
            raise ValueError("Cannot get video duration, please check your video input")

        video_bytes_io = io.BytesIO()
        format_to_use = getattr(video, "container", "mp4")
        codec_to_use = getattr(video, "codec", "h264")
        video.save_to(video_bytes_io, format=format_to_use, codec=codec_to_use)
        video_bytes_io.seek(0)
        length = video_bytes_io.getbuffer().nbytes
        if length > 50 * 1024 * 1024:
            raise ValueError("Video size is too large, must be less than 50MB")
        video_bytes_io.seek(0)
        video_url = self.upload_file(
            video_bytes_io,
            f"{prompt_id}_video.{format_to_use}",
            headers,
        )

        data = {
            "prompt": prompt,
            "urls": [video_url],
            "model": model,
            "resolution": resolution,
            "duration": duration,
        }
        return data, "grok-imagine-video-edit-official"

    def handle_outputs(self, outputs):
        urls_str = outputs[3]
        return (outputs[0][0], urls_str, "grok-imagine-video-official")
