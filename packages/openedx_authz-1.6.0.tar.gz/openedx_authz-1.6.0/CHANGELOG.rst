Change Log
##########

..
   All enhancements and patches to openedx_authz will be documented
   in this file.  It adheres to the structure of https://keepachangelog.com/ ,
   but in reStructuredText instead of Markdown (for ease of incorporation into
   Sphinx documentation and the PyPI description).

   This project adheres to Semantic Versioning (https://semver.org/).

.. There should always be an "Unreleased" section for changes pending release.

Unreleased
**********

1.6.0 - 2026-04-10
******************

Added
=====

* Add org-wide support to migration commands for forward and backward migration of course authoring permissions.

1.5.0 - 2026-04-09
******************

Added
=====

* Add ``users/`` endpoint to fetch all team members, with optional filters for orgs, scopes, search by username user full name or email, sorting and pagination.

Fixed
=====

* Fix enforcer ``is_admin_or_superuser_check`` that was not taking into account Org glob scopes.

1.4.0 - 2026-04-09
******************

Added
=====

* Add ``orgs/`` endpoint to list and search orgs, with pagination, as required for filters in the Admin Console.

1.3.0 2026-04-08
****************

Added
=====

* Add stub CCX_COACH role/ CCXCourseOverviewData scope to prevent errors when working with CCX courses.
* Add ADR for global scope support for role assignments.

1.2.0 - 2026-03-30
******************

Added
=====

* Add ``get_user_role_assignments_filtered`` api function to fetch user role assignments filtered by user, role, and/or scope.
* Add ``org`` property to ``ContentLibraryData`` and ``CourseOverviewData``.

1.1.0 - 2026-03-17
******************

Added
=====

* Add support for organization global scopes.

1.0.0 - 2026-03-13
******************

Removed
=======

* Dropped support for Python 3.11.

0.23.0 - 2026-02-18
********************

Added
=====

* Add authz_migrate_course_authoring command to migrate legacy CourseAccessRole data to the new Authz (Casbin-based) system
* Add authz_rollback_course_authoring command to rollback Authz roles back to legacy CourseAccessRole
* Support optional --delete flag for controlled cleanup of source permissions after successful migration
* Add migrate_legacy_course_roles_to_authz and migrate_authz_to_legacy_course_roles service functions
* Add unit tests to verify migration and command behavior

Added
=====

* ADR on the AuthZ for Course Authoring Migration Process Details.

0.22.0 - 2026-02-19
********************

* ADR on the AuthZ for Course Authoring implementation plan.
* ADR on the AuthZ for Course Authoring Feature Flag Implementation Details.
* Defined courses roles and permissions mappings, including legacy compatible permissions.

0.21.0 - 2026-02-12
********************

Added
=====

* Add course staff role, permission to manage advanced course settings, and introduce course scope

0.20.0 - 2025-11-27
********************

Added
=====

* Add configurable logging level for Casbin enforcer via ``CASBIN_LOG_LEVEL`` setting (defaults to WARNING).


0.19.2 - 2025-11-25
********************

Performance
===========

* Use a RequestCache for is_admin_or_superuser matcher to improve performance.

0.19.1 - 2025-11-25
********************

Fixed
=====

* Use `short_name` instead of `name` from organization when building library key.

0.19.0 - 2025-11-18
********************

Added
=====

* Handle cache invalidation via a uuid in the database to ensure policy reloads
  occur only when necessary.

0.18.0 - 2025-11-17
********************

Added
=====

* Migration to transfer legacy permissions from ContentLibraryPermission to the new Casbin-based authorization model.

0.17.1 - 2025-11-14
********************

Fixed
=====

* Avoid circular import of AuthzEnforcer.

0.17.0 - 2025-11-14
********************

Added
=====

* Signal to clear policies associated to a user when they are retired.

0.16.0 - 2025-11-13
********************

Changed
=======

* **BREAKING**: Update permission format to include app namespace prefix.

Added
=====

* Register ``CasbinRule`` model in the Django admin.
* Register ``ExtendedCasbinRule`` model in the Django admin as an inline model of ``CasbinRule``.

0.15.0 - 2025-11-11
********************

Added
=====

* `ExtendedCasbinRule` model to extend the base CasbinRule model for additional metadata, and cascade delete
  support.

0.14.0 - 2025-11-11
********************

Added
=====

* Implement custom matcher to check for staff and superuser status.

0.13.1 - 2025-11-11
********************

Fixed
=====

* Avoid duplicates when getting scopes for given user and permissions.

0.13.0 - 2025-11-05
********************

Added
=====

* Add support for global scopes instead of generic `sc` scope to support instance-level permissions.

0.12.0 - 2025-10-30
********************

Changed
=======

* Load authorization policies in permission class.

0.11.2 - 2025-10-30
********************

Added
=====

* Consider Content Library V2 toggle only in CMS service variant.

0.11.1 - 2025-10-29
********************

Changed
=======

* Refactor to get permissions' scopes instead of role.

Fixed
=====

* Use correct content library toggle to check if Content Library V2 is enabled.

0.11.0 - 2025-10-29
********************

Added
=====

* Disable auto-save and auto-load of policies if Content Library V2 is disabled.

0.10.1 - 2025-10-28
********************

Fixed
=====

* Fix constants and test class to be able to use it outside this app.

0.10.0 - 2025-10-28
*******************

Added
=====

* New ``get_object()`` method in ScopeData to retrieve underlying domain objects
* Implementation of ``get_object()`` for ContentLibraryData with canonical key validation

Changed
=======

* Refactor ``ContentLibraryData.exists()`` to use ``get_object()`` internally

0.9.1 - 2025-10-28
******************

Fixed
=====

* Fix role user count to accurately filter users assigned to roles within specific scopes instead of across all scopes.

0.9.0 - 2025-10-27
******************

Added
=====

* Function API to retrieve scopes for a given role and subject.

0.8.0 - 2025-10-24
******************

Added
=====

* Allow disabling auto-load and auto-save of policies by setting CASBIN_AUTO_LOAD_POLICY_INTERVAL to -1.

Changed
=======

* Migrate from using pycodestyle and isort to ruff for code quality checks and formatting.
* Enhance enforcement command with dual operational modes (database and file mode).

0.7.0 - 2025-10-23
******************

Added
=====

* Initial migration to establish dependency on casbin_adapter for automatic CasbinRule table creation.

0.6.0 - 2025-10-22
******************

Changed
=======

* Use a SyncedEnforcer with default auto load policy.

Removed
=======

* Remove Casbin Redis watcher from engine configuration.

0.5.0 - 2025-10-21
******************

Added
=====

* Default policy for Content Library roles and permissions.

Fixed
=====

* Add plugin_settings in test settings.
* Update permissions for RoleListView.

0.4.1 - 2025-10-16
******************

Fixed
=====

* Load policy before adding policies in the loading script to avoid duplicates.

0.4.0 - 2025-16-10
******************

Changed
=======

* Initialize enforcer when application is ready to avoid access errors.

0.3.0 - 2025-10-10
******************

Added
=====

* Implementation of REST API for roles and permissions management.

0.2.0 - 2025-10-10
******************

Added
=====

* ADRs for key design decisions.
* Casbin model (CONF) and engine layer for authorization.
* Implementation of public API for roles and permissions management.

0.1.0 - 2025-08-27
******************

Added
=====

* Basic repo structure and initial setup.
