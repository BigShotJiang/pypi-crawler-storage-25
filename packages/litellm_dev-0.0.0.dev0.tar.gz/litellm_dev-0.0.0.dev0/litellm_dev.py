"""Placeholder for the litellm-dev development channel.

See https://github.com/BerriAI/litellm for the real package.
Real dev builds replace this stub.
"""

__version__ = "0.0.0.dev0"
