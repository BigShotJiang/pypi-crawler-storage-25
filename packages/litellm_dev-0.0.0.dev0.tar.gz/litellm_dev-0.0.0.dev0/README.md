# litellm-dev (placeholder)

Namespace placeholder for the `litellm-dev` development channel of
[BerriAI/litellm](https://github.com/BerriAI/litellm).

Real dev builds are published as PEP 440 pre-releases (`1.X.Y.devN`).
Install the latest dev build with:

    pip install --pre litellm-dev
