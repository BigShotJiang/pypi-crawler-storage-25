<a id="mypy-boto3-securityhub"></a>

# mypy-boto3-securityhub

[![PyPI - mypy-boto3-securityhub](https://img.shields.io/pypi/v/mypy-boto3-securityhub.svg?color=blue)](https://pypi.org/project/mypy-boto3-securityhub/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mypy-boto3-securityhub.svg?color=blue)](https://pypi.org/project/mypy-boto3-securityhub/)
[![Docs](https://img.shields.io/readthedocs/boto3-stubs.svg?color=blue)](https://youtype.github.io/boto3_stubs_docs/)
[![PyPI - Downloads](https://static.pepy.tech/badge/mypy-boto3-securityhub)](https://pypistats.org/packages/mypy-boto3-securityhub)

![boto3.typed](https://github.com/youtype/mypy_boto3_builder/raw/main/logo.png)

Type annotations for
[boto3 SecurityHub 1.43.5](https://pypi.org/project/boto3/) compatible with
[VSCode](https://code.visualstudio.com/),
[PyCharm](https://www.jetbrains.com/pycharm/),
[Emacs](https://www.gnu.org/software/emacs/),
[Sublime Text](https://www.sublimetext.com/),
[mypy](https://github.com/python/mypy),
[pyright](https://github.com/microsoft/pyright) and other tools.

Generated with
[mypy-boto3-builder 8.12.0](https://github.com/youtype/mypy_boto3_builder).

More information can be found on
[boto3-stubs](https://pypi.org/project/boto3-stubs/) page and in
[mypy-boto3-securityhub docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_securityhub/).

See how it helps you find and fix potential bugs:

![types-boto3 demo](https://github.com/youtype/mypy_boto3_builder/raw/main/demo.gif)

- [mypy-boto3-securityhub](#mypy-boto3-securityhub)
  - [How to install](#how-to-install)
    - [Generate locally (recommended)](<#generate-locally-(recommended)>)
    - [VSCode extension](#vscode-extension)
    - [From PyPI with pip](#from-pypi-with-pip)
  - [How to uninstall](#how-to-uninstall)
  - [Usage](#usage)
    - [VSCode](#vscode)
    - [PyCharm](#pycharm)
    - [Emacs](#emacs)
    - [Sublime Text](#sublime-text)
    - [Other IDEs](#other-ides)
    - [mypy](#mypy)
    - [pyright](#pyright)
    - [Pylint compatibility](#pylint-compatibility)
  - [Explicit type annotations](#explicit-type-annotations)
    - [Client annotations](#client-annotations)
    - [Paginators annotations](#paginators-annotations)
    - [Literals](#literals)
    - [Type definitions](#type-definitions)
  - [How it works](#how-it-works)
  - [What's new](#what's-new)
    - [Implemented features](#implemented-features)
    - [Latest changes](#latest-changes)
  - [Versioning](#versioning)
  - [Thank you](#thank-you)
  - [Documentation](#documentation)
  - [Support and contributing](#support-and-contributing)

<a id="how-to-install"></a>

## How to install

<a id="generate-locally-(recommended)"></a>

### Generate locally (recommended)

You can generate type annotations for `boto3` package locally with
`mypy-boto3-builder`. Use
[uv](https://docs.astral.sh/uv/getting-started/installation/) for build
isolation.

1. Run mypy-boto3-builder in your package root directory:
   `uvx --with 'boto3==1.43.5' mypy-boto3-builder`
2. Select `boto3-stubs` AWS SDK.
3. Add `SecurityHub` service.
4. Use provided commands to install generated packages.

<a id="vscode-extension"></a>

### VSCode extension

Add
[AWS Boto3](https://marketplace.visualstudio.com/items?itemName=Boto3typed.boto3-ide)
extension to your VSCode and run `AWS boto3: Quick Start` command.

Click `Modify` and select `boto3 common` and `SecurityHub`.

<a id="from-pypi-with-pip"></a>

### From PyPI with pip

Install `boto3-stubs` for `SecurityHub` service.

```bash
# install with boto3 type annotations
python -m pip install 'boto3-stubs[securityhub]'

# Lite version does not provide session.client/resource overloads
# it is more RAM-friendly, but requires explicit type annotations
python -m pip install 'boto3-stubs-lite[securityhub]'

# standalone installation
python -m pip install mypy-boto3-securityhub
```

<a id="how-to-uninstall"></a>

## How to uninstall

```bash
python -m pip uninstall -y mypy-boto3-securityhub
```

<a id="usage"></a>

## Usage

<a id="vscode"></a>

### VSCode

- Install
  [Python extension](https://marketplace.visualstudio.com/items?itemName=ms-python.python)
- Install
  [Pylance extension](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance)
- Set `Pylance` as your Python Language Server
- Install `boto3-stubs[securityhub]` in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

Both type checking and code completion should now work. No explicit type
annotations required, write your `boto3` code as usual.

<a id="pycharm"></a>

### PyCharm

> ⚠️ Due to slow PyCharm performance on `Literal` overloads (issue
> [PY-40997](https://youtrack.jetbrains.com/issue/PY-40997)), it is recommended
> to use [boto3-stubs-lite](https://pypi.org/project/boto3-stubs-lite/) until
> the issue is resolved.

> ⚠️ If you experience slow performance and high CPU usage, try to disable
> `PyCharm` type checker and use [mypy](https://github.com/python/mypy) or
> [pyright](https://github.com/microsoft/pyright) instead.

> ⚠️ To continue using `PyCharm` type checker, you can try to replace
> `boto3-stubs` with
> [boto3-stubs-lite](https://pypi.org/project/boto3-stubs-lite/):

```bash
pip uninstall boto3-stubs
pip install boto3-stubs-lite
```

Install `boto3-stubs[securityhub]` in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

Both type checking and code completion should now work.

<a id="emacs"></a>

### Emacs

- Install `boto3-stubs` with services you use in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

- Install [use-package](https://github.com/jwiegley/use-package),
  [lsp](https://github.com/emacs-lsp/lsp-mode/),
  [company](https://github.com/company-mode/company-mode) and
  [flycheck](https://github.com/flycheck/flycheck) packages
- Install [lsp-pyright](https://github.com/emacs-lsp/lsp-pyright) package

```elisp
(use-package lsp-pyright
  :ensure t
  :hook (python-mode . (lambda ()
                          (require 'lsp-pyright)
                          (lsp)))  ; or lsp-deferred
  :init (when (executable-find "python3")
          (setq lsp-pyright-python-executable-cmd "python3"))
  )
```

- Make sure emacs uses the environment where you have installed `boto3-stubs`

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="sublime-text"></a>

### Sublime Text

- Install `boto3-stubs[securityhub]` with services you use in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

- Install [LSP-pyright](https://github.com/sublimelsp/LSP-pyright) package

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="other-ides"></a>

### Other IDEs

Not tested, but as long as your IDE supports `mypy` or `pyright`, everything
should work.

<a id="mypy"></a>

### mypy

- Install `mypy`: `python -m pip install mypy`
- Install `boto3-stubs[securityhub]` in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pyright"></a>

### pyright

- Install `pyright`: `npm i -g pyright`
- Install `boto3-stubs[securityhub]` in your environment:

```bash
python -m pip install 'boto3-stubs[securityhub]'
```

Optionally, you can install `boto3-stubs` to `typings` directory.

Type checking should now work. No explicit type annotations required, write
your `boto3` code as usual.

<a id="pylint-compatibility"></a>

### Pylint compatibility

It is totally safe to use `TYPE_CHECKING` flag in order to avoid
`mypy-boto3-securityhub` dependency in production. However, there is an issue
in `pylint` that it complains about undefined variables. To fix it, set all
types to `object` in non-`TYPE_CHECKING` mode.

```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mypy_boto3_ec2 import EC2Client, EC2ServiceResource
    from mypy_boto3_ec2.waiters import BundleTaskCompleteWaiter
    from mypy_boto3_ec2.paginators import DescribeVolumesPaginator
else:
    EC2Client = object
    EC2ServiceResource = object
    BundleTaskCompleteWaiter = object
    DescribeVolumesPaginator = object

...
```

<a id="explicit-type-annotations"></a>

## Explicit type annotations

<a id="client-annotations"></a>

### Client annotations

`SecurityHubClient` provides annotations for `boto3.client("securityhub")`.

```python
from boto3.session import Session

from mypy_boto3_securityhub import SecurityHubClient

client: SecurityHubClient = Session().client("securityhub")

# now client usage is checked by mypy and IDE should provide code completion
```

<a id="paginators-annotations"></a>

### Paginators annotations

`mypy_boto3_securityhub.paginator` module contains type annotations for all
paginators.

```python
from boto3.session import Session

from mypy_boto3_securityhub import SecurityHubClient
from mypy_boto3_securityhub.paginator import (
    DescribeActionTargetsPaginator,
    DescribeProductsPaginator,
    DescribeProductsV2Paginator,
    DescribeStandardsControlsPaginator,
    DescribeStandardsPaginator,
    GetEnabledStandardsPaginator,
    GetFindingHistoryPaginator,
    GetFindingsPaginator,
    GetFindingsTrendsV2Paginator,
    GetFindingsV2Paginator,
    GetInsightsPaginator,
    GetRecommendedPolicyV2Paginator,
    GetResourcesTrendsV2Paginator,
    GetResourcesV2Paginator,
    ListAggregatorsV2Paginator,
    ListConfigurationPoliciesPaginator,
    ListConfigurationPolicyAssociationsPaginator,
    ListEnabledProductsForImportPaginator,
    ListFindingAggregatorsPaginator,
    ListInvitationsPaginator,
    ListMembersPaginator,
    ListOrganizationAdminAccountsPaginator,
    ListSecurityControlDefinitionsPaginator,
    ListStandardsControlAssociationsPaginator,
)

client: SecurityHubClient = Session().client("securityhub")

# Explicit type annotations are optional here
# Types should be correctly discovered by mypy and IDEs
describe_action_targets_paginator: DescribeActionTargetsPaginator = client.get_paginator(
    "describe_action_targets"
)
describe_products_paginator: DescribeProductsPaginator = client.get_paginator("describe_products")
describe_products_v2_paginator: DescribeProductsV2Paginator = client.get_paginator(
    "describe_products_v2"
)
describe_standards_controls_paginator: DescribeStandardsControlsPaginator = client.get_paginator(
    "describe_standards_controls"
)
describe_standards_paginator: DescribeStandardsPaginator = client.get_paginator(
    "describe_standards"
)
get_enabled_standards_paginator: GetEnabledStandardsPaginator = client.get_paginator(
    "get_enabled_standards"
)
get_finding_history_paginator: GetFindingHistoryPaginator = client.get_paginator(
    "get_finding_history"
)
get_findings_paginator: GetFindingsPaginator = client.get_paginator("get_findings")
get_findings_trends_v2_paginator: GetFindingsTrendsV2Paginator = client.get_paginator(
    "get_findings_trends_v2"
)
get_findings_v2_paginator: GetFindingsV2Paginator = client.get_paginator("get_findings_v2")
get_insights_paginator: GetInsightsPaginator = client.get_paginator("get_insights")
get_recommended_policy_v2_paginator: GetRecommendedPolicyV2Paginator = client.get_paginator(
    "get_recommended_policy_v2"
)
get_resources_trends_v2_paginator: GetResourcesTrendsV2Paginator = client.get_paginator(
    "get_resources_trends_v2"
)
get_resources_v2_paginator: GetResourcesV2Paginator = client.get_paginator("get_resources_v2")
list_aggregators_v2_paginator: ListAggregatorsV2Paginator = client.get_paginator(
    "list_aggregators_v2"
)
list_configuration_policies_paginator: ListConfigurationPoliciesPaginator = client.get_paginator(
    "list_configuration_policies"
)
list_configuration_policy_associations_paginator: ListConfigurationPolicyAssociationsPaginator = (
    client.get_paginator("list_configuration_policy_associations")
)
list_enabled_products_for_import_paginator: ListEnabledProductsForImportPaginator = (
    client.get_paginator("list_enabled_products_for_import")
)
list_finding_aggregators_paginator: ListFindingAggregatorsPaginator = client.get_paginator(
    "list_finding_aggregators"
)
list_invitations_paginator: ListInvitationsPaginator = client.get_paginator("list_invitations")
list_members_paginator: ListMembersPaginator = client.get_paginator("list_members")
list_organization_admin_accounts_paginator: ListOrganizationAdminAccountsPaginator = (
    client.get_paginator("list_organization_admin_accounts")
)
list_security_control_definitions_paginator: ListSecurityControlDefinitionsPaginator = (
    client.get_paginator("list_security_control_definitions")
)
list_standards_control_associations_paginator: ListStandardsControlAssociationsPaginator = (
    client.get_paginator("list_standards_control_associations")
)
```

<a id="literals"></a>

### Literals

`mypy_boto3_securityhub.literals` module contains literals extracted from
shapes that can be used in user code for type checking.

Full list of `SecurityHub` Literals can be found in
[docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_securityhub/literals/).

```python
from mypy_boto3_securityhub.literals import ActorSessionMfaStatusType


def check_value(value: ActorSessionMfaStatusType) -> bool: ...
```

<a id="type-definitions"></a>

### Type definitions

`mypy_boto3_securityhub.type_defs` module contains structures and shapes
assembled to typed dictionaries and unions for additional type checking.

Full list of `SecurityHub` TypeDefs can be found in
[docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_securityhub/type_defs/).

```python
# TypedDict usage example
from mypy_boto3_securityhub.type_defs import AcceptAdministratorInvitationRequestTypeDef


def get_value() -> AcceptAdministratorInvitationRequestTypeDef:
    return {
        "AdministratorId": ...,
    }
```

<a id="how-it-works"></a>

## How it works

Fully automated
[mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder) carefully
generates type annotations for each service, patiently waiting for `boto3`
updates. It delivers drop-in type annotations for you and makes sure that:

- All available `boto3` services are covered.
- Each public class and method of every `boto3` service gets valid type
  annotations extracted from `botocore` schemas.
- Type annotations include up-to-date documentation.
- Link to documentation is provided for every method.
- Code is processed by [ruff](https://docs.astral.sh/ruff/) for readability.

<a id="what's-new"></a>

## What's new

<a id="implemented-features"></a>

### Implemented features

- Fully type annotated `boto3`, `botocore`, `aiobotocore` and `aioboto3`
  libraries
- `mypy`, `pyright`, `VSCode`, `PyCharm`, `Sublime Text` and `Emacs`
  compatibility
- `Client`, `ServiceResource`, `Resource`, `Waiter` `Paginator` type
  annotations for each service
- Generated `TypeDefs` for each service
- Generated `Literals` for each service
- Auto discovery of types for `boto3.client` and `boto3.resource` calls
- Auto discovery of types for `session.client` and `session.resource` calls
- Auto discovery of types for `client.get_waiter` and `client.get_paginator`
  calls
- Auto discovery of types for `ServiceResource` and `Resource` collections
- Auto discovery of types for `aiobotocore.Session.create_client` calls

<a id="latest-changes"></a>

### Latest changes

Builder changelog can be found in
[Releases](https://github.com/youtype/mypy_boto3_builder/releases).

<a id="versioning"></a>

## Versioning

`mypy-boto3-securityhub` version is the same as related `boto3` version and
follows
[Python Packaging version specifiers](https://packaging.python.org/en/latest/specifications/version-specifiers/).

<a id="thank-you"></a>

## Thank you

- [Allie Fitter](https://github.com/alliefitter) for
  [boto3-type-annotations](https://pypi.org/project/boto3-type-annotations/),
  this package is based on top of his work
- [black](https://github.com/psf/black) developers for an awesome formatting
  tool
- [Timothy Edmund Crosley](https://github.com/timothycrosley) for
  [isort](https://github.com/PyCQA/isort) and how flexible it is
- [mypy](https://github.com/python/mypy) developers for doing all dirty work
  for us
- [pyright](https://github.com/microsoft/pyright) team for the new era of typed
  Python

<a id="documentation"></a>

## Documentation

All services type annotations can be found in
[boto3 docs](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_securityhub/)

<a id="support-and-contributing"></a>

## Support and contributing

This package is auto-generated. Please reports any bugs or request new features
in [mypy-boto3-builder](https://github.com/youtype/mypy_boto3_builder/issues/)
repository.
