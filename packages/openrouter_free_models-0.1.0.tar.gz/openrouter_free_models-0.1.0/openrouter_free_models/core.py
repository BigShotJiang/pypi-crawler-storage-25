import requests
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class ModelInfo:
    """Information about a free model"""
    name: str
    context_length: int
    provider: str
    supports_tools: bool
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model info to dictionary"""
        return {
            'name': self.name,
            'context_length': self.context_length,
            'provider': self.provider,
            'supports_tools': self.supports_tools
        }


class FreeModel:
    """Find and get information about the best working free model from OpenRouter"""
    
    BASE_URL = "https://openrouter.ai/api/v1"
    TEST_MESSAGE = "OK"  # Simple test message
    TEST_MAX_TOKENS = 5
    MAX_MODELS_TO_TEST = 10
    
    def __init__(self, api_key: str):
        """
        Initialize and find the best working free model
        
        Args:
            api_key: OpenRouter API key
        """
        if not api_key:
            raise ValueError("API key is required. Get one at \
https://openrouter.ai/keys")
        self.api_key = api_key
        self.model_info: Optional[ModelInfo] = None
        self._find_best_working_model()
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with optional auth"""
        headers = {"Content-Type": "application/json"}
        headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    def _get_free_models(self) -> list:
        """
        Fetch all free models from OpenRouter API
        
        Returns:
            List of free models sorted by context length (largest first)
        """
        try:
            response = requests.get(
                f"{self.BASE_URL}/models",
                headers=self._get_headers(),
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            
            free_models = []
            for model in data.get('data', []):
                pricing = model.get('pricing', {})
                
                # Check if model is free (both input and output cost 0)
                try:
                    input_cost = float(pricing.get('prompt', 1))
                    output_cost = float(pricing.get('completion', 1))
                    
                    if input_cost == 0.0 and output_cost == 0.0:
                        free_models.append(model)
                except (ValueError, TypeError):
                    continue
            
            # Sort by context length (largest first) to prefer better models
            free_models.sort(
                key=lambda x: x.get('context_length', 0),
                reverse=True
            )
            
            return free_models[:self.MAX_MODELS_TO_TEST]
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to fetch models from OpenRouter: {e}")
    
    def _test_model_quota(self, model_id: str) -> bool:
        """
        Test if model has available quota by sending a tiny request
        
        Args:
            model_id: The model identifier to test
            
        Returns:
            True if model has quota, False otherwise
        """
        payload = {
            "model": model_id,
            "messages": [
                {"role": "user", "content": self.TEST_MESSAGE}
            ],
            "max_tokens": self.TEST_MAX_TOKENS,
            "temperature": 0.1
        }
        
        try:
            response = requests.post(
                f"{self.BASE_URL}/chat/completions",
                headers=self._get_headers(),
                json=payload,
                timeout=15
            )
            
            # 200 = success, 402 = insufficient quota
            return response.status_code == 200
            
        except requests.exceptions.RequestException:
            return False
    
    def _extract_provider(self, model_id: str) -> str:
        """Extract provider name from model ID (e.g., 'google/gemini-flash' -> 'google')"""
        return model_id.split('/')[0] if '/' in model_id else 'unknown'
    
    def _parse_model_info(self, model_data: dict) -> ModelInfo:
        """Parse raw model data into ModelInfo object"""
        model_id = model_data.get('id', 'unknown')
        
        return ModelInfo(
            name=model_id,
            context_length=model_data.get('context_length', 0),
            provider=self._extract_provider(model_id),
            supports_tools=model_data.get('features', {}).get('supports_tools', False)
        )
    
    def _find_best_working_model(self):
        """
        Find the best working free model by testing each one until we find one with quota
        """
        free_models = self._get_free_models()
        
        if not free_models:
            raise Exception("No free models found on OpenRouter")
        
        
        for i, model_data in enumerate(free_models, 1):
            model_id = model_data.get('id', 'unknown')
            
            if self._test_model_quota(model_id):
                self.model_info = self._parse_model_info(model_data)
                return
        
        raise Exception(
            f"No working free models found. All {len(free_models)} models have exhausted their quota. "
            "Try again later or provide an API key for better stability."
        )
    
    @property
    def name(self) -> str:
        """Get model name"""
        if not self.model_info:
            raise Exception("No model found")
        return self.model_info.name
    
    @property
    def context_length(self) -> int:
        """Get model context length"""
        if not self.model_info:
            raise Exception("No model found")
        return self.model_info.context_length
    
    @property
    def provider(self) -> str:
        """Get model provider"""
        if not self.model_info:
            raise Exception("No model found")
        return self.model_info.provider
    
    @property
    def supports_tools(self) -> bool:
        """Check if model supports tools/function calling"""
        if not self.model_info:
            raise Exception("No model found")
        return self.model_info.supports_tools
    
    def to_dict(self) -> Dict[str, Any]:
        """Get all model information as dictionary"""
        if not self.model_info:
            raise Exception("No model found")
        return self.model_info.to_dict()
    
    def __str__(self) -> str:
        """String representation"""
        if not self.model_info:
            return "FreeModel(not initialized)"
        return f"FreeModel(model={self.name}, context={self.context_length}, provider={self.provider})"


def get_best_free_model(api_key: str) -> FreeModel:
    """
    Convenience function to get the best working free model
    
    Args:
        api_key: OpenRouter API key
        
    Returns:
        FreeModel instance with the best working model
        
    Example:
        >>> model = get_best_free_model()
        >>> print(model.name)
        'google/gemini-flash-1.5'
        >>> print(model.context_length)
        1000000
    """
    return FreeModel(api_key=api_key)
