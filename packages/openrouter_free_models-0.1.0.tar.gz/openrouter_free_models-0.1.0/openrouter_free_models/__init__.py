"""
free_router - Find the best working free model on OpenRouter
"""

from .core import FreeModel, get_best_free_model

__version__ = "0.1.0"
__all__ = ["FreeModel", "get_best_free_model"]
