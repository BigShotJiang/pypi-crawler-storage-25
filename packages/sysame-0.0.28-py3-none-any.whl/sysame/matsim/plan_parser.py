"""
Module for parsing MATSim plans xml file.
"""

##### IMPORTS #####
from __future__ import annotations

# Standard imports
import math
import gzip
from os import PathLike
from dataclasses import dataclass
from typing import Any, Literal, Optional

# Third party imports
import polars as pl
from lxml import etree as ET  # type: ignore

# Local imports

##### CONSTANTS #####
# Only these tags are ever meaningful; all others are skipped immediately.
_KNOWN_TAGS: frozenset = frozenset(
    {"person", "plan", "activity", "leg", "route", "attributes", "attribute"}
)


##### CLASSES #####
@dataclass
class ParsedPlans:
    """
    Container for all normalised dataframes produced by ``parse_matsim_plans``.

    Each dataframe is a Polars DataFrame.  All dataframes share the composite key
    `(person_id, plan_index)` so they can be joined freely.

    Attributes
    ----------
    persons : pl.DataFrame
        One row per person.  Columns: `person_id` (str),
        `selected_plan_indices` (list[int]).
    person_attrs : pl.DataFrame
        One row per person, one column per person-level attribute declared in
        the `<attributes>` block.  All attribute values are stored as strings;
        cast individual columns as needed.  Always contains `person_id`.
    plans : pl.DataFrame
        One row per plan.  Columns: `person_id`, `plan_index` (int),
        `plan_uid` (str, `"<person_id>#<plan_index>"`), `score` (float),
        `selected` (bool), `attributes` (dict or None).
    elements : pl.DataFrame
        Ordered sequence of activities and legs within each plan.  Columns:
        `person_id`, `plan_index`, `elem_index` (0-based position),
        `elem_type` (`"activity"` or `"leg"`), `ref_index` (index into
        the `activities` or `legs` table).
    activities : pl.DataFrame
        One row per activity.  Columns: `person_id`, `plan_index`,
        `act_index` (int), `type` (str), `x` (float), `y` (float),
        `link` (str), `facility` (str), `start_time` (`HH:MM:SS` str),
        `end_time` (`HH:MM:SS` str), `attributes` (dict or None).
    legs : pl.DataFrame
        One row per leg.  Columns: `person_id`, `plan_index`,
        `leg_index` (int), `mode` (str), `dep_time` (`HH:MM:SS` str),
        `arr_time` (`HH:MM:SS` str), `trav_time_min` (float),
        `euclid_dist_m` (float), `route_type` (str), `route_start_link`
        (str), `route_end_link` (str), `route_trav_time` (`HH:MM:SS`
        str), `route_distance_m` (float), `route_links` (list[str] or
        None), `route_raw` (str), `attributes` (dict or None).
    plan_summary : pl.DataFrame
        One row per plan with pre-aggregated travel statistics.  Columns:
        `person_id`, `plan_index`, `plan_uid`, `score`, `selected`,
        `activities` (list[str] of activity types), `modes` (list[str]),
        `points` (list[dict] of `{"x": float, "y": float}`),
        `leg_times_min` (list[float]), `leg_euclid_dists_m` (list[float]),
        `leg_route_dists_m` (list[float|None]), `total_time_min` (float),
        `total_euclid_dist_m` (float), `total_route_dist_m` (float).
    """

    persons: pl.DataFrame
    person_attrs: pl.DataFrame
    plans: pl.DataFrame
    elements: pl.DataFrame
    activities: pl.DataFrame
    legs: pl.DataFrame
    plan_summary: pl.DataFrame

    def _plans_for_logsum(
        self, plan_set: Literal["all", "selected", "best", "average"]
    ) -> pl.DataFrame:
        """
        Return the subset of `self.plans` to use for logsum computation.

        Parameters
        ----------
        plan_set : {"all", "selected", "best", "average"}
            Which plans to include:

            * `"all"`      : every plan for each person.
            * `"selected"` : only plans where `selected` is `True`
              (i.e. the executed plan at the stored iteration).
            * `"best"`     : only the highest-score plan per person
              (ties broken by ascending `plan_index`).
            * `"average"` : a single synthetic plan per person whose
              score is the mean of all plan scores (null scores
              excluded from the average).

        Returns
        -------
        pl.DataFrame
            Filtered (or full) `plans` DataFrame.

        Raises
        ------
        ValueError
            If `plan_set` is not one of the accepted values.
        """
        if plan_set == "all":
            return self.plans
        if plan_set == "selected":
            return self.plans.filter(pl.col("selected"))
        if plan_set == "best":
            return (
                self.plans.sort(
                    by=["person_id", "score", "plan_index"],
                    descending=[False, True, False],
                    nulls_last=True,
                )
                .group_by("person_id")
                .head(1)
            )
        if plan_set == "average":
            return self.plans.group_by("person_id").agg(pl.col("score").mean())
        raise ValueError(
            "plan_set must be one of: 'all', 'selected', 'best', 'average'"
        )

    def plan_logsum(
        self,
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        """
        Compute the per-person inclusive value (logsum) over plan utilities.

        Uses the standard discrete-choice logsum formula:

        .. math::

            IV_i = \\frac{1}{\\lambda} \\ln\\left(\\sum_{j} e^{\\lambda V_{ij}}\\right)

        where :math:`V_{ij}` is the utility (`score`) of plan *j* for
        person *i* and :math:`\\lambda` is the scale parameter.
        Plans with a null score are excluded from the exponential sum;
        persons where *all* scores are null receive a null logsum.

        Parameters
        ----------
        lambda_scale : float, default 1.0
            Scale parameter :math:`\\lambda`.  Must be non-zero.
        plan_set : {"all", "selected", "best", "average"}, default "all"
            Which plans to include per person before computing the logsum:

            * `"all"`      : every stored plan.
            * `"selected"` : only plans marked as selected/executed.
            * `"best"`     : only the plan with the highest score.
            * `"average"` : a single synthetic plan whose score is the
              mean of all plan scores (equivalent to returning the
              average score directly as the logsum value).

        Returns
        -------
        pl.DataFrame
            Columns: `person_id` (str), `logsum` (float),
            `n_plans` (int, count of plans in the chosen set).

        Raises
        ------
        ValueError
            If `lambda_scale` is 0.
        """
        if lambda_scale == 0:
            raise ValueError("lambda_scale must be non-zero")

        plans = self._plans_for_logsum(plan_set)

        return plans.group_by("person_id").agg(
            pl.when(pl.col("score").is_not_null().any())
            .then(
                (pl.col("score").drop_nulls() * lambda_scale).exp().sum().log(math.e)
                / lambda_scale
            )
            .otherwise(None)
            .alias("logsum"),
            pl.len().alias("n_plans"),
        )

    def logsum_by(
        self,
        attr_name: str,
        agg: str = "mean",
        lambda_scale: float = 1.0,
        plan_set: Literal["all", "selected", "best", "average"] = "all",
    ) -> pl.DataFrame:
        """
        Aggregate per-person logsum values grouped by a person attribute.

        Computes ``plan_logsum`` for every person, then joins to
        ``person_attrs`` and groups by the requested attribute column.
        If the attribute is absent from ``person_attrs`` the attribute
        column is filled with ``None`` so the result still contains all
        persons.

        Parameters
        ----------
        attr_name : str
            Name of the `person_attrs` column to group by
            (e.g. `"subpopulation"`, `"income_group"`).
        agg : {"mean", "sum", "median"}, default "mean"
            Aggregation function applied to logsum values within each
            group.  Any unrecognised value falls back to `"mean"`.
        lambda_scale : float, default 1.0
            Scale parameter :math:`\\lambda` passed through to
            ``plan_logsum``.
        plan_set : {"all", "selected", "best", "average"}, default "all"
            Which plans to include per person before computing the logsum.

        Returns
        -------
        pl.DataFrame
            Columns: ``<attr_name>`` (str), ``logsum`` (float),
            ``n_persons`` (int).  Sorted ascending by ``<attr_name>``.

        Examples
        --------
        >>> parsed.logsum_by("subpopulation")
        >>> parsed.logsum_by("income_group", agg="sum", lambda_scale=0.5)
        """
        ls = self.plan_logsum(
            lambda_scale=lambda_scale,
            plan_set=plan_set,
        ).select(["person_id", "logsum"])

        if self.person_attrs.is_empty() or attr_name not in self.person_attrs.columns:
            attr = self.persons.select("person_id").with_columns(
                pl.lit(None).alias(attr_name)
            )
        else:
            attr = self.person_attrs.select(["person_id", pl.col(attr_name)])

        agg_map = {
            "mean": pl.col("logsum").mean(),
            "sum": pl.col("logsum").sum(),
            "median": pl.col("logsum").median(),
        }
        return (
            ls.join(attr, on="person_id", how="left")
            .group_by(attr_name)
            .agg(
                agg_map.get(agg, pl.col("logsum").mean()).alias("logsum"),
                pl.col("person_id").count().alias("n_persons"),
            )
            .sort(attr_name)
        )

    def persons_wide(self) -> pl.DataFrame:
        """
        Return `persons` left-joined to all person attribute columns.

        Equivalent to ``persons.join(person_attrs, on="person_id", how="left")``
        but handles the case where ``person_attrs`` is empty.
        Attribute values are stored as strings; cast individual columns as
        needed.  Useful for exploration and for building custom segmentations.

        Returns
        -------
        pl.DataFrame
            One row per person with ``person_id``, ``selected_plan_indices``,
            and one additional column per person attribute.  Persons with no
            recorded attributes still appear (attribute columns are ``None``).
        """
        if self.person_attrs.is_empty():
            return self.persons
        return self.persons.join(self.person_attrs, on="person_id", how="left")


##### FUNCTIONS #####
def _open_xml_source(path: str | PathLike[str]):
    """
    Return a context manager yielding a binary file-like object for *path*.

    Transparently handles both plain ``.xml`` files and gzip-compressed
    ``.xml.gz`` files.  Detection is based on the file extension (case-
    insensitive).

    Parameters
    ----------
    path : str or PathLike[str]
        Path to the XML source file.

    Returns
    -------
    context manager
        Yields a binary-mode file object suitable for ``lxml.etree.iterparse``.

    Raises
    ------
    OSError
        If the file cannot be opened.
    """

    class _Ctx:
        """
        Internal context manager that opens and closes the file handle.

        Parameters
        ----------
        p : str or PathLike[str]
            Path to the XML source file.
        """

        def __init__(self, p: str | PathLike[str]):
            self.p = p
            self.f = None

        def __enter__(self):
            """
            Open the file and return the file object.

            Returns
            -------
            file object
                Binary-mode file handle (plain or gzip-decompressed).
            """
            path_str = str(self.p)
            if path_str.lower().endswith(".gz"):
                self.f = gzip.open(self.p, "rb")
            else:
                self.f = open(self.p, "rb")
            return self.f

        def __exit__(self, exc_type, exc, tb):
            """
            Close the file handle, suppressing any close-time errors.

            Parameters
            ----------
            exc_type : type or None
                Exception type, if an exception occurred.
            exc : BaseException or None
                Exception instance.
            tb : traceback or None
                Traceback object.
            """
            try:
                if self.f is not None:
                    self.f.close()
            finally:
                self.f = None

    return _Ctx(path)


def _parse_time_to_seconds(s: Optional[str]) -> Optional[int]:
    """
    Parse a MATSim time string to a total number of seconds.

    Accepts either ``HH:MM:SS`` format or a bare integer/float string
    representing seconds.

    Parameters
    ----------
    s : str or None
        Time string to parse.  Returns ``None`` for empty or ``None`` input.

    Returns
    -------
    int or None
        Total seconds, or ``None`` if the input is empty or unparsable.
    """
    if not s:
        return None
    t = s.strip()
    try:
        if ":" in t:
            hh, mm, ss = t.split(":")
            return int(hh) * 3600 + int(mm) * 60 + int(ss)
        return int(float(t))
    except Exception:
        return None


def _normalise_hms(s: Optional[str]) -> Optional[str]:
    """
    Normalise a MATSim time value to ``"HH:MM:SS"`` string format.

    Takes the fast path (zero parsing) when the value already contains a
    colon — the overwhelmingly common case in MATSim output(?).  Falls back to
    parsing as a pure-seconds integer for the rare alternative representation.

    Parameters
    ----------
    s : str or None
        Raw time string from an XML attribute, or ``None``.

    Returns
    -------
    str or None
        Time formatted as ``"HH:MM:SS"``, or ``None`` if *s* is empty/``None``.
        Values that cannot be parsed are returned unchanged.
    """
    if not s:
        return None
    t = s.strip()
    if ":" in t:
        return t  # already HH:MM:SS — zero extra work
    # Pure-seconds integer fallback
    try:
        total = int(float(t))
        hh, rem = divmod(total, 3600)
        mm, sec = divmod(rem, 60)
        return f"{hh:02d}:{mm:02d}:{sec:02d}"
    except Exception:
        return t


def _cast_attr_value(java_class: Optional[str], text: Optional[str]) -> Any:
    """
    Convert a MATSim XML attribute text value to an appropriate Python type.

    Uses the ``class`` attribute of ``<attribute>`` elements (the Java class
    name) to determine the target type.  Falls back to heuristic type
    inference (bool → float → int → str) when no class hint is available.

    Parameters
    ----------
    java_class : str or None
        Value of the ``class`` XML attribute, e.g.
        ``"java.lang.Integer"`` or ``"java.lang.Double"``.  May be ``None``.
    text : str or None
        Raw text content of the ``<attribute>`` element.

    Returns
    -------
    int, float, bool, str, or None
        Typed value, or ``None`` if *text* is ``None``.
    """
    if text is None:
        return None
    t = text.strip()
    if java_class:
        jc = java_class.rsplit(".", 1)[-1].lower()
        if jc in ("integer", "int", "long"):
            try:
                return int(t)
            except Exception:
                return t
        if jc in ("double", "float", "bigdecimal"):
            try:
                return float(t)
            except Exception:
                return t
        if jc in ("boolean",):
            return t.lower() in ("true", "1", "yes")
        return t
    if t.lower() in ("true", "false"):
        return t.lower() == "true"
    try:
        if "." in t:
            return float(t)
        return int(t)
    except Exception:
        return t


def _euclidean(p1, p2) -> float:
    """
    Compute the Euclidean distance between two 2-D points.

    Parameters
    ----------
    p1 : tuple[float, float]
        ``(x, y)`` coordinates of the first point.
    p2 : tuple[float, float]
        ``(x, y)`` coordinates of the second point.

    Returns
    -------
    float
        Straight-line distance in the same units as the input coordinates
        (typically metres for MATSim projected coordinate systems).
    """
    return math.hypot(p2[0] - p1[0], p2[1] - p1[1])


def parse_matsim_plans(path: str | PathLike[str]) -> ParsedPlans:
    """
    Stream-parse a MATSim plans file into a set of normalised Polars dataframes.

    Reads ``.xml`` and ``.xml.gz`` formats.  Uses ``lxml.etree.iterparse``
    for constant-memory streaming so that very large files (millions of
    persons) can be processed without loading the entire DOM.

    Columnar storage (one Python list per column) is used during parsing
    to minimise allocations.

    Parameters
    ----------
    path : str or PathLike[str]
        Path to the MATSim plans XML file, optionally gzip-compressed
        (detected by a ``.gz`` extension).

    Returns
    -------
    ParsedPlans
        Dataclass containing the following Polars DataFrames:

        * **persons** : ``(person_id, selected_plan_indices)``
        * **person_attrs** : ``(person_id, <one column per attribute>)``
        * **plans** : ``(person_id, plan_index, plan_uid, score, selected,
          attributes)``
        * **elements** : ``(person_id, plan_index, elem_index, elem_type,
          ref_index)`` — ordered activity/leg sequence within each plan
        * **activities** : ``(person_id, plan_index, act_index, type, x, y,
          link, facility, start_time, end_time, attributes)``
        * **legs** : ``(person_id, plan_index, leg_index, mode, dep_time,
          arr_time, trav_time_min, euclid_dist_m, route_type,
          route_start_link, route_end_link, route_trav_time,
          route_distance_m, route_links, route_raw, attributes)``
        * **plan_summary** : ``(person_id, plan_index, plan_uid, score,
          selected, activities, modes, points, leg_times_min,
          leg_euclid_dists_m, leg_route_dists_m, total_time_min,
          total_euclid_dist_m, total_route_dist_m)``

    Notes
    -----
    Time columns use the following conventions:

    * Absolute times (``dep_time``, ``arr_time``, ``start_time``,
      ``end_time``, ``route_trav_time``) are ``HH:MM:SS`` strings.
    * Travel durations (``trav_time_min``, ``leg_times_min``,
      ``total_time_min``) are stored in **minutes** as floats.
    * Euclidean distances are derived from the ``x``/``y`` coordinates of
      consecutive activities.  Route distances come directly from the XML
      ``distance`` attribute.

    Raises
    ------
    OSError
        If the file cannot be opened or read.
    lxml.etree.XMLSyntaxError
        If the XML is malformed.
    """
    per_cols: dict[str, list[Any]] = {"person_id": [], "selected_plan_indices": []}
    # person_attrs has dynamic/unknown columns so list-of-dicts is kept here.
    person_attr_records: list[dict[str, Any]] = []
    pl_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "attributes": [],
    }
    el_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "elem_index": [],
        "elem_type": [],
        "ref_index": [],
    }
    ac_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "act_index": [],
        "type": [],
        "x": [],
        "y": [],
        "link": [],
        "facility": [],
        "start_time": [],
        "end_time": [],
        "attributes": [],
    }
    lg_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "leg_index": [],
        "mode": [],
        "dep_time": [],
        "arr_time": [],
        "trav_time_min": [],
        "euclid_dist_m": [],
        "route_type": [],
        "route_start_link": [],
        "route_end_link": [],
        "route_trav_time": [],
        "route_distance_m": [],
        "route_links": [],
        "route_raw": [],
        "attributes": [],
    }
    ps_cols: dict[str, list[Any]] = {
        "person_id": [],
        "plan_index": [],
        "plan_uid": [],
        "score": [],
        "selected": [],
        "activities": [],
        "modes": [],
        "points": [],
        "leg_times_min": [],
        "leg_euclid_dists_m": [],
        "leg_route_dists_m": [],
        "total_time_min": [],
        "total_euclid_dist_m": [],
        "total_route_dist_m": [],
    }

    # Streaming context
    iterparse_kwargs: dict[str, Any] = {
        "events": ("start", "end"),
        "load_dtd": False,
        "resolve_entities": False,
        "huge_tree": True,
    }

    with _open_xml_source(path) as _src:
        context = ET.iterparse(_src, **iterparse_kwargs)

        # Person state
        current_person_id = None
        person_attrs: dict[str, Any] = {}
        selected_plan_idxs_for_person: list[int] = []

        # Plan state
        in_plan = False
        plan_index = -1
        plan_score = None
        plan_selected = False
        plan_attrs: dict[str, Any] = {}
        elem_index = -1

        # Activity state
        in_activity = False
        act_index = -1
        current_activity_attrs: dict[str, Any] = {}

        # Leg state
        in_leg = False
        leg_index = -1
        current_leg_attrs: dict[str, Any] = {}
        leg_route_ctx: dict[str, Any] = {}

        # For euclidean distances
        last_activity_point = None
        pending_leg_row_idx = None

        # Per-plan summary accumulators
        summary_act_types: list[str] = []
        summary_modes: list[str] = []
        summary_points: list[Any] = []
        summary_leg_times: list[Optional[float]] = []
        summary_leg_euclid_dists: list[float] = []
        summary_leg_route_dists: list[Optional[float]] = []

        # Attribute collection target stack
        attr_target_stack: list[dict[str, Any]] = []

        def finish_plan() -> None:
            """
            Flush accumulators for the current plan into the columnar stores.

            Called at the ``</plan>`` end event.  Aligns the per-leg distance
            lists to the same length as ``summary_leg_times``, computes
            aggregate totals, and appends one row to both ``pl_cols`` (the
            plans table) and ``ps_cols`` (the plan-summary table).

            Modifies ``pl_cols`` and ``ps_cols`` in the enclosing scope.
            """
            nonlocal \
                summary_leg_euclid_dists, \
                summary_leg_route_dists, \
                summary_leg_times
            # Align arrays
            n_legs = len(summary_leg_times)
            if len(summary_leg_euclid_dists) < n_legs:
                summary_leg_euclid_dists += [0.0] * (
                    n_legs - len(summary_leg_euclid_dists)
                )
            if len(summary_leg_route_dists) < n_legs:
                summary_leg_route_dists += [None] * (
                    n_legs - len(summary_leg_route_dists)
                )

            # summary_leg_times holds minutes (float); sum directly
            total_time_min = sum(t for t in summary_leg_times if t is not None)
            total_euclid = float(sum(summary_leg_euclid_dists))
            total_route_vals = [
                d for d in summary_leg_route_dists if isinstance(d, (int, float))
            ]
            total_route = float(sum(total_route_vals)) if total_route_vals else None

            plan_uid = f"{current_person_id}#{plan_index}"

            pl_cols["person_id"].append(current_person_id)
            pl_cols["plan_index"].append(plan_index)
            pl_cols["plan_uid"].append(plan_uid)
            pl_cols["score"].append(plan_score)
            pl_cols["selected"].append(plan_selected)
            pl_cols["attributes"].append(dict(plan_attrs) if plan_attrs else None)

            ps_cols["person_id"].append(current_person_id)
            ps_cols["plan_index"].append(plan_index)
            ps_cols["plan_uid"].append(plan_uid)
            ps_cols["score"].append(plan_score)
            ps_cols["selected"].append(plan_selected)
            ps_cols["activities"].append(list(summary_act_types))
            ps_cols["modes"].append(list(summary_modes))
            ps_cols["points"].append(list(summary_points))
            ps_cols["leg_times_min"].append(list(summary_leg_times))
            ps_cols["leg_euclid_dists_m"].append(list(summary_leg_euclid_dists))
            ps_cols["leg_route_dists_m"].append(list(summary_leg_route_dists))
            ps_cols["total_time_min"].append(
                total_time_min if total_time_min > 0 else None
            )
            ps_cols["total_euclid_dist_m"].append(
                total_euclid if total_euclid > 0 else None
            )
            ps_cols["total_route_dist_m"].append(total_route)

        for event, elem in context:
            tag = elem.tag
            # Fast path: skip non-string tags (comments/PIs) and irrelevant elements.
            if isinstance(tag, str):
                if "}" in tag:
                    tag = tag.split("}", 1)[1]
                if tag not in _KNOWN_TAGS:
                    elem.clear()
                    continue
            else:
                elem.clear()
                continue

            if event == "start":
                if tag == "person":
                    current_person_id = elem.attrib.get("id")
                    person_attrs = {}
                    selected_plan_idxs_for_person = []
                    plan_index = -1

                elif tag == "plan" and current_person_id is not None:
                    attrib = elem.attrib
                    in_plan = True
                    plan_index += 1
                    plan_score = None
                    plan_selected = False
                    plan_attrs = {}
                    elem_index = -1
                    in_activity = False
                    in_leg = False
                    act_index = -1
                    leg_index = -1
                    last_activity_point = None
                    pending_leg_row_idx = None
                    summary_act_types = []
                    summary_modes = []
                    summary_points = []
                    summary_leg_times = []
                    summary_leg_euclid_dists = []
                    summary_leg_route_dists = []

                    score_raw = attrib.get("score")
                    if score_raw is not None:
                        try:
                            plan_score = float(score_raw)
                        except Exception:
                            plan_score = None
                    sel_raw = attrib.get("selected", "no").lower()
                    plan_selected = sel_raw in ("yes", "true", "1")
                    if plan_selected:
                        selected_plan_idxs_for_person.append(plan_index)

                elif tag == "activity" and in_plan:
                    attrib = elem.attrib
                    in_activity = True
                    elem_index += 1
                    act_index += 1
                    current_activity_attrs = {}

                    act_type = attrib.get("type", "")
                    x = attrib.get("x")
                    y = attrib.get("y")
                    link = attrib.get("link")
                    facility = attrib.get("facility")
                    start_time = _normalise_hms(attrib.get("start_time"))
                    end_time = _normalise_hms(attrib.get("end_time"))

                    if x is not None and y is not None:
                        try:
                            px, py = float(x), float(y)
                        except Exception:
                            px, py = float("nan"), float("nan")
                    else:
                        px, py = float("nan"), float("nan")

                    summary_act_types.append(act_type)
                    summary_points.append({"x": px, "y": py})

                    # Resolve pending leg euclidean distance
                    if (
                        pending_leg_row_idx is not None
                        and last_activity_point is not None
                    ):
                        eu = _euclidean(last_activity_point, (px, py))
                        lg_cols["euclid_dist_m"][pending_leg_row_idx] = eu
                        summary_leg_euclid_dists.append(eu)
                        pending_leg_row_idx = None

                    if not math.isnan(px) and not math.isnan(py):
                        last_activity_point = (px, py)

                    # Append activity columns; attributes patched in-place at end event
                    ac_cols["person_id"].append(current_person_id)
                    ac_cols["plan_index"].append(plan_index)
                    ac_cols["act_index"].append(act_index)
                    ac_cols["type"].append(act_type)
                    ac_cols["x"].append(px)
                    ac_cols["y"].append(py)
                    ac_cols["link"].append(link)
                    ac_cols["facility"].append(facility)
                    ac_cols["start_time"].append(start_time)
                    ac_cols["end_time"].append(end_time)
                    ac_cols["attributes"].append(None)

                    # Ordered elements
                    el_cols["person_id"].append(current_person_id)
                    el_cols["plan_index"].append(plan_index)
                    el_cols["elem_index"].append(elem_index)
                    el_cols["elem_type"].append("activity")
                    el_cols["ref_index"].append(act_index)

                elif tag == "leg" and in_plan:
                    attrib = elem.attrib
                    in_leg = True
                    elem_index += 1
                    leg_index += 1
                    current_leg_attrs = {}
                    leg_route_ctx = {}

                    mode = attrib.get("mode", "")
                    trav_time_s = _parse_time_to_seconds(
                        attrib.get("trav_time") or attrib.get("travel_time")
                    )
                    trav_time_min = (
                        (trav_time_s / 60.0) if trav_time_s is not None else None
                    )

                    summary_modes.append(mode)
                    summary_leg_times.append(trav_time_min)

                    # Append leg columns; route/euclid/attrs patched in-place later
                    lg_cols["person_id"].append(current_person_id)
                    lg_cols["plan_index"].append(plan_index)
                    lg_cols["leg_index"].append(leg_index)
                    lg_cols["mode"].append(mode)
                    lg_cols["dep_time"].append(
                        _normalise_hms(
                            attrib.get("dep_time") or attrib.get("departure_time")
                        )
                    )
                    lg_cols["arr_time"].append(
                        _normalise_hms(
                            attrib.get("arr_time") or attrib.get("arrival_time")
                        )
                    )
                    lg_cols["trav_time_min"].append(trav_time_min)
                    lg_cols["euclid_dist_m"].append(None)
                    lg_cols["route_type"].append(None)
                    lg_cols["route_start_link"].append(None)
                    lg_cols["route_end_link"].append(None)
                    lg_cols["route_trav_time"].append(None)
                    lg_cols["route_distance_m"].append(None)
                    lg_cols["route_links"].append(None)
                    lg_cols["route_raw"].append(None)
                    lg_cols["attributes"].append(None)

                    pending_leg_row_idx = len(lg_cols["person_id"]) - 1

                    # Ordered elements
                    el_cols["person_id"].append(current_person_id)
                    el_cols["plan_index"].append(plan_index)
                    el_cols["elem_index"].append(elem_index)
                    el_cols["elem_type"].append("leg")
                    el_cols["ref_index"].append(leg_index)

                elif tag == "route" and in_leg:
                    attrib = elem.attrib
                    route_type = attrib.get("type")
                    dist_raw = attrib.get("distance")
                    route_dist: Optional[float] = None
                    if dist_raw is not None:
                        try:
                            route_dist = float(dist_raw)
                        except Exception:
                            pass
                    leg_route_ctx = {
                        "route_type": route_type,
                        "route_start_link": attrib.get("start_link")
                        or attrib.get("startLinkId"),
                        "route_end_link": attrib.get("end_link")
                        or attrib.get("endLinkId"),
                        "route_trav_time": _normalise_hms(
                            attrib.get("trav_time") or attrib.get("travel_time")
                        ),
                        "route_distance_m": route_dist,
                    }

                elif tag == "attributes":
                    if in_activity:
                        attr_target_stack.append(current_activity_attrs)
                    elif in_leg:
                        attr_target_stack.append(current_leg_attrs)
                    elif in_plan:
                        attr_target_stack.append(plan_attrs)
                    elif current_person_id is not None:
                        attr_target_stack.append(person_attrs)
                    else:
                        # population-level attributes ignored
                        attr_target_stack.append({})

            # End events
            elif tag == "route" and in_leg:
                raw_text = (elem.text or "").strip()
                rtype = (leg_route_ctx.get("route_type") or "").lower()
                route_links = (
                    [tok for tok in raw_text.split() if tok]
                    if rtype == "links" and raw_text
                    else None
                )
                if lg_cols["person_id"]:
                    lg_cols["route_type"][-1] = leg_route_ctx.get("route_type")
                    lg_cols["route_start_link"][-1] = leg_route_ctx.get(
                        "route_start_link"
                    )
                    lg_cols["route_end_link"][-1] = leg_route_ctx.get("route_end_link")
                    lg_cols["route_trav_time"][-1] = leg_route_ctx.get(
                        "route_trav_time"
                    )
                    lg_cols["route_distance_m"][-1] = leg_route_ctx.get(
                        "route_distance_m"
                    )
                    lg_cols["route_links"][-1] = route_links
                    lg_cols["route_raw"][-1] = raw_text if raw_text else None
                    summary_leg_route_dists.append(
                        leg_route_ctx.get("route_distance_m")
                    )
                elem.clear()

            elif tag == "activity" and in_activity:
                ac_cols["attributes"][-1] = (
                    dict(current_activity_attrs) if current_activity_attrs else None
                )
                in_activity = False
                current_activity_attrs = {}
                elem.clear()

            elif tag == "leg" and in_leg:
                if lg_cols["person_id"]:
                    lg_cols["attributes"][-1] = (
                        dict(current_leg_attrs) if current_leg_attrs else None
                    )
                    # If no <route> was present, still align route distances
                    if len(summary_leg_route_dists) < len(summary_leg_times):
                        summary_leg_route_dists.append(lg_cols["route_distance_m"][-1])
                in_leg = False
                current_leg_attrs = {}
                leg_route_ctx = {}
                elem.clear()

            elif tag == "plan" and in_plan:
                # If a leg is pending without closing activity, pad distance
                if pending_leg_row_idx is not None:
                    lg_cols["euclid_dist_m"][pending_leg_row_idx] = 0.0
                    summary_leg_euclid_dists.append(0.0)
                    pending_leg_row_idx = None
                finish_plan()
                in_plan = False
                plan_attrs = {}
                elem.clear()

            elif tag == "person" and current_person_id is not None:
                per_cols["person_id"].append(current_person_id)
                per_cols["selected_plan_indices"].append(
                    list(selected_plan_idxs_for_person)
                )
                person_attr_records.append(
                    {
                        "person_id": current_person_id,
                        **{
                            _attr_name: (
                                str(_attr_val) if _attr_val is not None else None
                            )
                            for _attr_name, _attr_val in person_attrs.items()
                        },
                    }
                )
                current_person_id = None
                person_attrs = {}
                selected_plan_idxs_for_person = []
                elem.clear()

            elif tag == "attributes":
                if attr_target_stack:
                    attr_target_stack.pop()
                elem.clear()

            elif tag == "attribute":
                if attr_target_stack:
                    attrib = elem.attrib
                    name = attrib.get("name")
                    cls = attrib.get("class")
                    val = _cast_attr_value(cls, elem.text)
                    if name:
                        attr_target_stack[-1][name] = val
                elem.clear()

            else:
                elem.clear()

    # Build DataFrames from columnar data
    def _df_or_empty(cols, empty_cols) -> pl.DataFrame:
        """
        Build a ``pl.DataFrame`` from a dict of column lists, or return an
        empty schema DataFrame if the first column is empty.

        Parameters
        ----------
        cols : dict[str, list]
            Columnar data collected during parsing.
        empty_cols : dict[str, list]
            Schema template used when there is no data (all lists empty).

        Returns
        -------
        pl.DataFrame
            Populated or empty DataFrame with the appropriate columns.
        """
        first_key = next(iter(cols))
        return pl.DataFrame(cols) if cols[first_key] else pl.DataFrame(empty_cols)

    persons_df = _df_or_empty(per_cols, {"person_id": [], "selected_plan_indices": []})
    person_attrs_df = (
        pl.DataFrame(person_attr_records)
        if person_attr_records
        else pl.DataFrame({"person_id": []})
    )
    plans_df = _df_or_empty(
        pl_cols,
        {
            "person_id": [],
            "plan_index": [],
            "plan_uid": [],
            "score": [],
            "selected": [],
            "attributes": [],
        },
    )
    elements_df = _df_or_empty(
        el_cols,
        {
            "person_id": [],
            "plan_index": [],
            "elem_index": [],
            "elem_type": [],
            "ref_index": [],
        },
    )
    activities_df = _df_or_empty(
        ac_cols,
        {
            "person_id": [],
            "plan_index": [],
            "act_index": [],
            "type": [],
            "x": [],
            "y": [],
            "link": [],
            "facility": [],
            "start_time": [],
            "end_time": [],
            "attributes": [],
        },
    )
    legs_df = _df_or_empty(
        lg_cols,
        {
            "person_id": [],
            "plan_index": [],
            "leg_index": [],
            "mode": [],
            "dep_time": [],
            "arr_time": [],
            "trav_time_min": [],
            "euclid_dist_m": [],
            "route_type": [],
            "route_start_link": [],
            "route_end_link": [],
            "route_trav_time": [],
            "route_distance_m": [],
            "route_links": [],
            "route_raw": [],
            "attributes": [],
        },
    )
    plan_summary_df = _df_or_empty(
        ps_cols,
        {
            "person_id": [],
            "plan_index": [],
            "plan_uid": [],
            "score": [],
            "selected": [],
            "activities": [],
            "modes": [],
            "points": [],
            "leg_times_min": [],
            "leg_euclid_dists_m": [],
            "leg_route_dists_m": [],
            "total_time_min": [],
            "total_euclid_dist_m": [],
            "total_route_dist_m": [],
        },
    )

    return ParsedPlans(
        persons=persons_df,
        person_attrs=person_attrs_df,
        plans=plans_df,
        elements=elements_df,
        activities=activities_df,
        legs=legs_df,
        plan_summary=plan_summary_df,
    )
