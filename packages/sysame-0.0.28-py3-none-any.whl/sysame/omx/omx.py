"""
OMX (Open Matrix) file reader/writer built on PyTables.
"""

##### IMPORTS #####
from __future__ import annotations

# Standard imports
from pathlib import Path
from collections.abc import Iterator

# Third-party imports
import numpy as np
import tables # type: ignore

# Local imports

# Import Rules

##### CONSTANTS #####
OMX_VERSION = b"0.2"

##### GLOBALS #####
# Define global variables here (use with caution)

##### CLASSES #####
class ShapeError(Exception):
    """Raised when a matrix shape does not match the file's shape."""

class OMXFile:
    """Read/write OMX files backed by HDF5 via PyTables.

    Parameters
    ----------
    filepath : str | Path
        Path to the HDF5 / OMX file.
    mode : str
        File open mode (``'r'``, ``'w'``, ``'a'``).
    title : str
        Short description stored in the file when creating.
    data_group : str
        Name of the HDF5 group that holds matrix CArrays.
    lookup_group : str
        Name of the HDF5 group that holds mapping arrays.
    filters : tables.Filters | None
        Compression filters used when creating new datasets.
    shape : tuple[int, int] | None
        Enforce that all matrices have this shape. ``None`` to infer
        from the first matrix written/read.
    """

    def __init__(
        self,
        filepath: str | Path,
        mode: str = "r",
        title: str = "",
        data_group: str = "data",
        lookup_group: str = "lookup",
        filters: tables.Filters | None = None,
        shape: tuple[int, int] | None = None,
    ) -> None:
        if filters is None:
            filters = tables.Filters(
                complevel=1, shuffle=True, fletcher32=False, complib="zlib"
            )
        self._filepath = Path(filepath)
        self._mode = mode
        self._data_group = data_group
        self._lookup_group = lookup_group
        self._shape: tuple[int, int] | None = shape
        self._h5: tables.File = tables.open_file(
            str(filepath), mode=mode, title=title, filters=filters
        )

        # Ensure OMX structure exists for writable files
        if mode != "r":
            if "OMX_VERSION" not in self._h5.root._v_attrs:
                self._h5.root._v_attrs["OMX_VERSION"] = OMX_VERSION
            if shape is not None:
                self._h5.root._v_attrs["SHAPE"] = np.array(
                    [shape[0], shape[1]], dtype="int32"
                )
            if data_group not in self._h5.root:
                self._h5.create_group(self._h5.root, data_group)
            if lookup_group not in self._h5.root:
                self._h5.create_group(self._h5.root, lookup_group)


    def __enter__(self) -> "OMXFile":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        self.close()


    @property
    def _data_node(self) -> tables.Group:
        return self._h5.get_node(self._h5.root, self._data_group)

    @property
    def _lookup_node(self) -> tables.Group:
        return self._h5.get_node(self._h5.root, self._lookup_group)

    def _is_writable(self) -> bool:
        return self._mode in ("w", "a")


    def close(self) -> None:
        """Close the underlying HDF5 file."""
        if self._h5.isopen:
            self._h5.close()


    def shape(self) -> tuple[int, int] | None:
        """Return the common ``(rows, cols)`` shape of all matrices.

        Returns ``None`` when the file contains no matrices and no shape
        attribute has been set.
        """
        if self._shape is not None:
            return self._shape

        if "SHAPE" in self._h5.root._v_attrs:
            arr = self._h5.root._v_attrs["SHAPE"]
            self._shape = (int(arr[0]), int(arr[1]))
            return self._shape

        if len(self) > 0:
            first = next(self._h5.iter_nodes(self._data_node, "CArray"))
            self._shape = first.shape  # type: ignore[assignment]
            if self._is_writable():
                self._h5.root._v_attrs["SHAPE"] = np.array(
                    [self._shape[0], self._shape[1]], dtype="int32"
                )
            return self._shape

        return None


    def list_matrices(self) -> list[str]:
        """Return the names of all matrices in the file."""
        return [
            node.name
            for node in self._h5.list_nodes(self._data_node, "CArray")
        ]

    def __getitem__(self, key: str) -> tables.CArray:
        """Get a matrix CArray by name."""
        return self._h5.get_node(self._data_node, key)

    def __setitem__(self, key: str, dataset: np.ndarray) -> None:
        """Write a numpy array as a matrix into the file."""
        if not self._is_writable():
            raise IOError("File is not writable")
        atom = tables.Atom.from_dtype(dataset.dtype)
        self.create_matrix(key, atom=atom, shape=dataset.shape, obj=dataset)

    def __delitem__(self, key: str) -> None:
        """Remove a matrix by name."""
        self._h5.remove_node(self._data_node, key)

    def __contains__(self, item: str) -> bool:
        """Check whether a matrix with the given name exists."""
        return item in self._data_node._v_children

    def __len__(self) -> int:
        """Return the number of matrices in the file."""
        return len(self._h5.list_nodes(self._data_node, "CArray"))

    def __iter__(self) -> Iterator[tables.CArray]:
        """Iterate over CArray matrix nodes."""
        return self._h5.iter_nodes(self._data_node, "CArray")


    def create_matrix(
        self,
        name: str,
        atom: tables.Atom | None = None,
        shape: tuple[int, ...] | None = None,
        title: str = "",
        filters: tables.Filters | None = None,
        obj: np.ndarray | None = None,
        attrs: dict[str, object] | None = None,
    ) -> tables.CArray:
        """Create a new matrix (CArray) in the data group.

        Parameters
        ----------
        name : str
            Matrix name.
        atom : tables.Atom, optional
            Data type atom. Required when *obj* is not provided.
        shape : tuple, optional
            Matrix dimensions. Required when *obj* is not provided.
        title : str
            Short description.
        filters : tables.Filters, optional
            Override file-level compression.
        obj : np.ndarray, optional
            Existing array to store. If provided, *atom* and *shape* are
            inferred from it.
        attrs : dict, optional
            Key/value metadata to attach to the matrix.

        Returns
        -------
        tables.CArray
        """
        if self.shape() is not None and obj is not None and obj.shape != self.shape():
            raise ShapeError(
                f"{name} has shape {obj.shape} but this file requires shape {self.shape()}"
            )

        matrix = self._h5.create_carray(
            self._data_node, name, atom, shape, title, filters, obj=obj
        )

        # Store shape on first matrix added
        if self._shape is None:
            self._shape = (matrix.shape[0], matrix.shape[1])
            self._h5.root._v_attrs["SHAPE"] = np.array(
                [self._shape[0], self._shape[1]], dtype="int32"
            )

        if attrs:
            for k, v in attrs.items():
                matrix.attrs[k] = v

        return matrix


    def list_all_attributes(self) -> list[str]:
        """Return sorted list of all attribute names across all matrices."""
        all_tags: set[str] = set()
        for m in self._h5.iter_nodes(self._data_node, "CArray"):
            all_tags.update(m.attrs._v_attrnamesuser)
        return sorted(all_tags)


    def list_mappings(self) -> list[str]:
        """Return the names of all mappings (lookups) in the file."""
        try:
            return [m.name for m in self._h5.list_nodes(self._lookup_node)]
        except tables.NoSuchNodeError:
            return []

    def mapping(self, title: str) -> dict[object, int]:
        """Return a mapping as ``{entry: offset}``."""
        try:
            entries = list(self._h5.get_node(self._lookup_node, title)[:])
            return {entry: i for i, entry in enumerate(entries)}
        except tables.NoSuchNodeError:
            raise LookupError(f"No such mapping: {title}") from None

    def map_entries(self, title: str) -> list[object]:
        """Return the raw list of entries for a mapping."""
        try:
            return list(self._h5.get_node(self._lookup_node, title)[:])
        except tables.NoSuchNodeError:
            raise LookupError(f"No such mapping: {title}") from None

    def create_mapping(
        self,
        title: str,
        entries: list | np.ndarray,
        overwrite: bool = False,
    ) -> tables.Array:
        """Create an index mapping in the lookup group.

        Parameters
        ----------
        title : str
            Mapping name.
        entries : list | np.ndarray
            Equivalency entries; length must match a matrix dimension.
        overwrite : bool
            Allow overwriting an existing mapping.
        """
        if self.shape() is not None:
            if len(entries) not in self._shape:  # type: ignore[operator]
                raise ShapeError("Mapping must match one data dimension")

        if title in self.list_mappings():
            if overwrite:
                self.delete_mapping(title)
            else:
                raise LookupError(f"{title} mapping already exists.")

        mymap = self._h5.create_array(
            self._lookup_node,
            title,
            atom=tables.UInt32Atom(),
            shape=(len(entries),),
        )
        mymap[:] = entries
        return mymap

    def delete_mapping(self, title: str) -> None:
        """Remove a mapping by name."""
        try:
            self._h5.remove_node(self._lookup_node, title)
        except tables.NoSuchNodeError:
            raise LookupError(f"No such mapping: {title}") from None
        
##### FUNCTIONS #####
def open_file(
    filepath: str | Path,
    mode: str = "r",
    title: str = "",
    data_group: str = "data",
    lookup_group: str = "lookup",
    filters: tables.Filters | None = None,
    shape: tuple[int, int] | None = None,
) -> OMXFile:
    """Open (or create) an OMX file.

    Parameters
    ----------
    filepath : str | Path
        Path to the OMX / HDF5 file.
    mode : str
        ``'r'`` read-only, ``'w'`` write (truncate), ``'a'`` append.
    title : str
        File description (used on creation).
    data_group : str
        HDF5 group name that holds matrices. Default ``"data"``.
    lookup_group : str
        HDF5 group name that holds mappings. Default ``"lookup"``.
    filters : tables.Filters, optional
        Compression filters for new data. Default is zlib level-1.
    shape : tuple[int, int], optional
        Enforce this matrix shape for all matrices.

    Returns
    -------
    OMXFile
    """
    return OMXFile(
        filepath,
        mode=mode,
        title=title,
        data_group=data_group,
        lookup_group=lookup_group,
        filters=filters,
        shape=shape,
    )

