"""OMX (Open Matrix) file reader module for sysame.

A lightweight replacement for the unmaintained ``openmatrix`` package.
Built directly on PyTables/HDF5 with configurable group names.
"""

from .omx import OMXFile, open_file, ShapeError

__all__ = [
    "OMXFile",
    "open_file",
    "ShapeError",
]
