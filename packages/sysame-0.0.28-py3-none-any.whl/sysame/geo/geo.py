"""
Module for geoprocessing functions: spatial joins, conversions, buffering,
dissolving, nearest-neighbour lookups, and format I/O.
"""

##### IMPORTS #####

# Standard imports
from pathlib import Path
from typing import Optional, Union, Literal

# Third party imports
import numpy as np
import pandas as pd
import geopandas as gpd  # type: ignore
from shapely.geometry import Point, Polygon, MultiPolygon, LineString  # type: ignore
from shapely.ops import unary_union  # type: ignore

# Local imports

# Import Rules

##### CONSTANTS #####

_SUPPORTED_DRIVERS: dict[str, str] = {
    ".shp": "ESRI Shapefile",
    ".gpkg": "GPKG",
    ".geojson": "GeoJSON",
    ".json": "GeoJSON",
    ".parquet": "parquet",
}

##### CLASSES #####


##### FUNCTIONS #####
def points_in_polygons(
    points: gpd.GeoDataFrame,
    polygons: gpd.GeoDataFrame,
    point_id_col: Optional[str] = None,
    polygon_id_col: Optional[str] = None,
    assign_nearest_if_outside: bool = True,
) -> gpd.GeoDataFrame:
    """Assign each point to the polygon it falls within.

    Points that do not fall inside any polygon can optionally be assigned
    to the nearest polygon boundary.

    Parameters
    ----------
    points : gpd.GeoDataFrame
        GeoDataFrame of point geometries.
    polygons : gpd.GeoDataFrame
        GeoDataFrame of polygon geometries.
    point_id_col : str, optional
        Column in *points* to carry through as an identifier.
        If ``None`` the index is used.
    polygon_id_col : str, optional
        Column in *polygons* to carry through as the polygon label.
        If ``None`` the index is used.
    assign_nearest_if_outside : bool, default True
        When ``True``, points outside every polygon are snapped to the
        nearest polygon boundary and assigned that polygon's id.

    Returns
    -------
    gpd.GeoDataFrame
        Copy of *points* with columns ``polygon_id`` (matched polygon)
        and ``distance_to_polygon`` (0 for interior points, >0 for
        nearest-neighbour assignments).
    """
    points = points.copy()
    polygons = polygons.copy()

    # ensure matching CRS
    if points.crs != polygons.crs:
        polygons = polygons.to_crs(points.crs)

    # label columns
    _pid = polygon_id_col or polygons.index.name or "polygon_index"
    if polygon_id_col and polygon_id_col in polygons.columns:
        polygons = polygons.rename(columns={polygon_id_col: _pid})
    else:
        polygons[_pid] = polygons.index

    # spatial join – keep left so every point appears
    joined = gpd.sjoin(
        points, polygons[[_pid, "geometry"]], how="left", predicate="within"
    )
    joined["distance_to_polygon"] = 0.0

    if assign_nearest_if_outside:
        unmatched_mask = joined[_pid].isna()
        if unmatched_mask.any():
            unmatched_pts = joined.loc[unmatched_mask, "geometry"]
            nearest_idx, nearest_dist = _nearest_polygon(unmatched_pts, polygons)
            joined.loc[unmatched_mask, _pid] = polygons.loc[nearest_idx, _pid].values
            joined.loc[unmatched_mask, "distance_to_polygon"] = nearest_dist

    joined = joined.rename(columns={_pid: "polygon_id"})
    drop_cols = [c for c in ["index_right"] if c in joined.columns]
    joined = joined.drop(columns=drop_cols)
    return joined


def spatial_join(
    left: gpd.GeoDataFrame,
    right: gpd.GeoDataFrame,
    how: Literal["inner", "left", "right"] = "inner",
    predicate: Literal[
        "intersects", "within", "contains", "crosses", "overlaps", "touches"
    ] = "intersects",
) -> gpd.GeoDataFrame:
    """Thin wrapper around ``geopandas.sjoin`` with automatic CRS alignment.

    Parameters
    ----------
    left : gpd.GeoDataFrame
        Left GeoDataFrame.
    right : gpd.GeoDataFrame
        Right GeoDataFrame.
    how : {'inner', 'left', 'right'}, default 'inner'
        Join type.
    predicate : str, default 'intersects'
        Spatial predicate.

    Returns
    -------
    gpd.GeoDataFrame
    """
    if left.crs != right.crs:
        right = right.to_crs(left.crs)
    return gpd.sjoin(left, right, how=how, predicate=predicate)


def merge_shapes(
    gdf: gpd.GeoDataFrame,
    by: Optional[str] = None,
    aggfunc: Union[str, dict[str, str]] = "first",
) -> gpd.GeoDataFrame:
    """Dissolve (merge) geometries, optionally grouped by a column.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
        Input features.
    by : str, optional
        Column to group by before dissolving.  If ``None`` all features
        are merged into a single geometry.
    aggfunc : str or dict, default 'first'
        Aggregation function(s) for non-geometry columns.

    Returns
    -------
    gpd.GeoDataFrame
    """
    if by is None:
        merged_geom = unary_union(gdf.geometry)
        return gpd.GeoDataFrame(geometry=[merged_geom], crs=gdf.crs)
    return gdf.dissolve(by=by, aggfunc=aggfunc).reset_index()


def clip_geodataframe(
    gdf: gpd.GeoDataFrame,
    mask: gpd.GeoDataFrame,
) -> gpd.GeoDataFrame:
    """Clip features to a mask extent, aligning CRS automatically.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
        Features to clip.
    mask : gpd.GeoDataFrame
        Clipping mask.

    Returns
    -------
    gpd.GeoDataFrame
    """
    if gdf.crs != mask.crs:
        mask = mask.to_crs(gdf.crs)
    return gpd.clip(gdf, mask)


def buffer(
    gdf: gpd.GeoDataFrame,
    distance: float,
    cap_style: Literal["round", "flat", "square"] = "round",
    dissolve: bool = False,
) -> gpd.GeoDataFrame:
    """Buffer all geometries by a fixed distance.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
        Input features.
    distance : float
        Buffer distance in the units of the GeoDataFrame's CRS.
    cap_style : {'round', 'flat', 'square'}, default 'round'
        End-cap style.
    dissolve : bool, default False
        If ``True`` dissolve overlapping buffers into one geometry.

    Returns
    -------
    gpd.GeoDataFrame
    """
    cap_map = {"round": 1, "flat": 2, "square": 3}
    buffered = gdf.copy()
    buffered["geometry"] = gdf.geometry.buffer(distance, cap_style=cap_map[cap_style])
    if dissolve:
        buffered = merge_shapes(buffered)
    return buffered


def centroids(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Return a point GeoDataFrame of centroids, preserving attributes.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame

    Returns
    -------
    gpd.GeoDataFrame
    """
    out = gdf.copy()
    out["geometry"] = gdf.geometry.centroid
    return out


def representative_points(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Return a point guaranteed to lie inside each geometry.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame

    Returns
    -------
    gpd.GeoDataFrame
    """
    out = gdf.copy()
    out["geometry"] = gdf.geometry.representative_point()
    return out


def nearest_features(
    source: gpd.GeoDataFrame,
    target: gpd.GeoDataFrame,
    k: int = 1,
) -> pd.DataFrame:
    """Find the *k* nearest features in *target* for every feature in *source*.

    Parameters
    ----------
    source : gpd.GeoDataFrame
        Features to search from.
    target : gpd.GeoDataFrame
        Features to search within.
    k : int, default 1
        Number of nearest neighbours per source feature.

    Returns
    -------
    pd.DataFrame
        Columns: ``source_index``, ``target_index``, ``distance``.
    """
    if source.crs != target.crs:
        target = target.to_crs(source.crs)

    results: list[dict[str, object]] = []
    for src_idx, src_geom in zip(source.index, source.geometry):
        distances = target.geometry.distance(src_geom)
        nearest_k = distances.nsmallest(k)
        for tgt_idx, dist in nearest_k.items():
            results.append(
                {"source_index": src_idx, "target_index": tgt_idx, "distance": dist}
            )
    return pd.DataFrame(results)


def add_lat_lon_columns(
    gdf: gpd.GeoDataFrame,
    x_col: str = "longitude",
    y_col: str = "latitude",
) -> gpd.GeoDataFrame:
    """Add longitude / latitude columns derived from point geometries.

    If the GeoDataFrame is not in EPSG:4326 it is reprojected first,
    but the original CRS is preserved in the returned frame.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
    x_col : str, default 'longitude'
    y_col : str, default 'latitude'

    Returns
    -------
    gpd.GeoDataFrame
    """
    out = gdf.copy()
    if gdf.crs is not None and not gdf.crs.is_geographic:
        tmp = gdf.to_crs(epsg=4326)
    else:
        tmp = gdf
    out[x_col] = tmp.geometry.x
    out[y_col] = tmp.geometry.y
    return out


def df_to_geodataframe(
    df: pd.DataFrame,
    x_col: str = "x",
    y_col: str = "y",
    crs: Union[str, int] = "EPSG:4326",
) -> gpd.GeoDataFrame:
    """Convert a ``pandas.DataFrame`` with coordinate columns to a GeoDataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Source dataframe.
    x_col : str, default 'x'
        Column with x / longitude values.
    y_col : str, default 'y'
        Column with y / latitude values.
    crs : str or int, default 'EPSG:4326'
        Coordinate reference system.

    Returns
    -------
    gpd.GeoDataFrame
    """
    geometry = [Point(xy) for xy in zip(df[x_col], df[y_col])]
    return gpd.GeoDataFrame(df, geometry=geometry, crs=crs)


def read_geo(
    path: Union[str, Path],
    layer: Optional[str] = None,
) -> gpd.GeoDataFrame:
    """Read a spatial file (Shapefile, GeoPackage, GeoJSON, Parquet).

    Parameters
    ----------
    path : str or Path
        Path to the spatial file.
    layer : str, optional
        Layer name (relevant for GeoPackage).

    Returns
    -------
    gpd.GeoDataFrame
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return gpd.read_parquet(path)
    kwargs: dict[str, object] = {}
    if layer:
        kwargs["layer"] = layer
    return gpd.read_file(path, **kwargs)


def write_geo(
    gdf: gpd.GeoDataFrame,
    path: Union[str, Path],
    layer: Optional[str] = None,
) -> Path:
    """Write a GeoDataFrame to disk (Shapefile, GeoPackage, GeoJSON, Parquet).

    The format is inferred from the file extension.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
        Data to write.
    path : str or Path
        Destination file path.
    layer : str, optional
        Layer name (GeoPackage only).

    Returns
    -------
    Path
        The written file path.
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in _SUPPORTED_DRIVERS:
        raise ValueError(
            f"Unsupported format '{suffix}'. Supported: {', '.join(_SUPPORTED_DRIVERS)}"
        )
    if suffix == ".parquet":
        gdf.to_parquet(path)
    else:
        driver = _SUPPORTED_DRIVERS[suffix]
        kwargs: dict[str, object] = {"driver": driver}
        if layer and suffix == ".gpkg":
            kwargs["layer"] = layer
        gdf.to_file(path, **kwargs)
    return path


def reproject(
    gdf: gpd.GeoDataFrame,
    target_crs: Union[str, int],
) -> gpd.GeoDataFrame:
    """Reproject a GeoDataFrame to a new CRS.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
    target_crs : str or int
        Target CRS (e.g. ``'EPSG:27700'`` or ``27700``).

    Returns
    -------
    gpd.GeoDataFrame
    """
    if isinstance(target_crs, int):
        target_crs = f"EPSG:{target_crs}"
    return gdf.to_crs(target_crs)


def calculate_area(
    gdf: gpd.GeoDataFrame,
    unit: Literal["m2", "km2", "ha"] = "m2",
    col_name: str = "area",
) -> gpd.GeoDataFrame:
    """Add an area column to a polygon GeoDataFrame.

    Works best when the CRS uses metre-based units.  If the CRS is
    geographic (degrees) the areas will be in square-degrees which is
    rarely useful — consider reprojecting first.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
    unit : {'m2', 'km2', 'ha'}, default 'm2'
    col_name : str, default 'area'

    Returns
    -------
    gpd.GeoDataFrame
    """
    divisors = {"m2": 1.0, "km2": 1_000_000.0, "ha": 10_000.0}
    out = gdf.copy()
    out[col_name] = gdf.geometry.area / divisors[unit]
    return out


def calculate_length(
    gdf: gpd.GeoDataFrame,
    unit: Literal["m", "km"] = "m",
    col_name: str = "length",
) -> gpd.GeoDataFrame:
    """Add a length column to a line GeoDataFrame.

    Parameters
    ----------
    gdf : gpd.GeoDataFrame
    unit : {'m', 'km'}, default 'm'
    col_name : str, default 'length'

    Returns
    -------
    gpd.GeoDataFrame
    """
    divisors = {"m": 1.0, "km": 1_000.0}
    out = gdf.copy()
    out[col_name] = gdf.geometry.length / divisors[unit]
    return out


def _nearest_polygon(
    points: gpd.GeoSeries,
    polygons: gpd.GeoDataFrame,
) -> tuple[np.ndarray, np.ndarray]:
    """Return arrays of nearest polygon indices and distances for *points*."""
    poly_geoms = polygons.geometry.values
    indices = np.empty(len(points), dtype=int)
    distances = np.empty(len(points), dtype=float)
    for i, pt in enumerate(points):
        dists = np.array([pt.distance(pg) for pg in poly_geoms])
        min_idx = dists.argmin()
        indices[i] = polygons.index[min_idx]
        distances[i] = dists[min_idx]
    return indices, distances
