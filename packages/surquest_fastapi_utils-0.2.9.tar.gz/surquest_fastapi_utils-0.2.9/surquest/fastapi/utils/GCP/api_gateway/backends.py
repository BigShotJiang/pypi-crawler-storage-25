from enum import Enum
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class BackendType(str, Enum):
    APP_ENGINE = "app_engine"
    CLOUD_RUN = "cloud_run"
    CLOUD_FUNCTION = "cloud_function"


class GatewayBackend(BaseModel):
    """Configuration for the backend service behind API Gateway."""
    type: BackendType
    address: str = Field(..., description="Backend URL (e.g. https://my-service-xyz.a.run.app)")
    protocol: Optional[str] = Field(default=None, description="h2 for gRPC, otherwise omitted")
    path_translation: str = Field(default="APPEND_PATH_TO_ADDRESS")
    deadline: Optional[float] = Field(default=15.0, description="Backend deadline in seconds")
    jwt_audience: Optional[str] = None
    disable_auth: Optional[bool] = None

    def to_x_google_backend(self, path: Optional[str] = None) -> Dict[str, Any]:
        backend: Dict[str, Any] = {"address": self.address.rstrip("/")}
        if path:
            backend["address"] = f"{backend['address']}{path}"

        if self.deadline is not None:
            backend["deadline"] = self.deadline
        if self.path_translation:
            backend["pathTranslation"] = self.path_translation
        if self.protocol:
            backend["protocol"] = self.protocol
        if self.jwt_audience:
            backend["jwtAudience"] = self.jwt_audience
        if self.disable_auth is not None:
            backend["disableAuth"] = self.disable_auth
        return backend


class SecurityDefinition(BaseModel):
    """Google-extended security definition (API Key, JWT, Firebase, etc.)."""
    name: str
    type: str = "apiKey"
    in_: str = Field(default="query", alias="in")
    key_name: str = "key"
    issuer: Optional[str] = None
    jwks_uri: Optional[str] = None
    audiences: Optional[str] = None

    class Config:
        populate_by_name = True

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"type": self.type, "in": self.in_, "name": self.key_name}
        if self.issuer:
            d["x-google-issuer"] = self.issuer
        if self.jwks_uri:
            d["x-google-jwks_uri"] = self.jwks_uri
        if self.audiences:
            d["x-google-audiences"] = self.audiences
        return d
