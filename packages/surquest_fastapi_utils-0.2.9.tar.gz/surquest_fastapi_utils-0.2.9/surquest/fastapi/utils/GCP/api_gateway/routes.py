import json
import yaml
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, FastAPI, Response, Query

from .backends import GatewayBackend, SecurityDefinition
from .converter import generate_gateway_spec


def create_gateway_router(
    app: FastAPI,
    backend: GatewayBackend,
    host: str,
    prefix: str = "/gateway-spec",
    base_path: str = "/",
    schemes: Optional[List[str]] = None,
    security_definitions: Optional[List[SecurityDefinition]] = None,
    default_security: Optional[List[Dict[str, List[str]]]] = None,
    extra_x_google: Optional[Dict[str, Any]] = None,
    openapi_version: str = "3.0",
) -> APIRouter:
    """
    Mount endpoints that serve the generated GCP API Gateway spec
    in YAML or JSON, optionally filtered by tags.
    """
    router = APIRouter(prefix=prefix, tags=["gateway"])

    def _build(include_tags: Optional[List[str]], exclude_tags: Optional[List[str]], exclude_responses: bool, exclude_parameters_schemas: bool):
        return generate_gateway_spec(
            app=app,
            backend=backend,
            host=host,
            base_path=base_path,
            schemes=schemes,
            include_tags=include_tags,
            exclude_tags=exclude_tags,
            security_definitions=security_definitions,
            default_security=default_security,
            extra_x_google=extra_x_google,
            openapi_version=openapi_version,
            exclude_responses=exclude_responses,
            exclude_parameters_schemas=exclude_parameters_schemas,
        )

    @router.get("/json", include_in_schema=False)
    def gateway_json(
        include_tags: Optional[List[str]] = Query(default=None),
        exclude_tags: Optional[List[str]] = Query(default=None),
        exclude_responses: bool = Query(default=False),
        exclude_parameters_schemas: bool = Query(default=False),
    ):
        spec = _build(include_tags, exclude_tags, exclude_responses, exclude_parameters_schemas)
        return Response(
            content=json.dumps(spec, indent=2),
            media_type="application/json",
        )

    @router.get("/yaml", include_in_schema=False)
    def gateway_yaml(
        include_tags: Optional[List[str]] = Query(default=None),
        exclude_tags: Optional[List[str]] = Query(default=None),
        exclude_responses: bool = Query(default=False),
        exclude_parameters_schemas: bool = Query(default=False),
    ):
        spec = _build(include_tags, exclude_tags, exclude_responses, exclude_parameters_schemas)
        return Response(
            content=yaml.safe_dump(spec, sort_keys=False),
            media_type="application/x-yaml",
        )

    return router
