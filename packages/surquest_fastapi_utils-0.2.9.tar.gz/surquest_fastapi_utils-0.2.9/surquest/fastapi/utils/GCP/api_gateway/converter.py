from typing import Any, Dict, List, Optional, Set
from fastapi import FastAPI
from fastapi.routing import APIRoute

from .backends import GatewayBackend, SecurityDefinition


# OpenAPI 3 -> Swagger 2 type mapping helpers
_PRIMITIVE_TYPES = {"string", "integer", "number", "boolean"}


def _strip_schema(schema: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Reduce a JSON schema to GCP-Gateway-friendly primitives."""
    if not schema:
        return {"type": "string"}
    if "$ref" in schema:
        # API Gateway doesn't need full models — flatten to generic object/string
        return {"type": "string"}
    t = schema.get("type")
    if t in _PRIMITIVE_TYPES:
        out = {"type": t}
        if "format" in schema:
            out["format"] = schema["format"]
        if "enum" in schema:
            out["enum"] = schema["enum"]
        return out
    if t == "array":
        items = schema.get("items", {})
        return {"type": "array", "items": _strip_schema(items)}
    # object / anyOf / oneOf / allOf — collapse
    return {"type": "string"}


def _convert_parameters(openapi_params: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    converted = []
    for p in openapi_params:
        new_p = {
            "name": p["name"],
            "in": p["in"],
            "required": p.get("required", False),
        }
        if "description" in p:
            new_p["description"] = p["description"]
        schema = p.get("schema", {})
        stripped = _strip_schema(schema)
        new_p.update(stripped)
        converted.append(new_p)
    return converted


def _filter_routes_by_tags(
    app: FastAPI,
    include_tags: Optional[Set[str]],
    exclude_tags: Optional[Set[str]],
) -> List[APIRoute]:
    routes = []
    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        route_tags = set(route.tags or [])
        if include_tags and not (route_tags & include_tags):
            continue
        if exclude_tags and (route_tags & exclude_tags):
            continue
        routes.append(route)
    return routes


def generate_gateway_spec(
    app: FastAPI,
    backend: GatewayBackend,
    host: str,
    title: Optional[str] = None,
    version: Optional[str] = None,
    base_path: str = "/",
    schemes: Optional[List[str]] = None,
    include_tags: Optional[List[str]] = None,
    exclude_tags: Optional[List[str]] = None,
    security_definitions: Optional[List[SecurityDefinition]] = None,
    default_security: Optional[List[Dict[str, List[str]]]] = None,
    extra_x_google: Optional[Dict[str, Any]] = None,
    openapi_version: str = "3.0",
    exclude_responses: bool = False,
    exclude_parameters_schemas: bool = False,
) -> Dict[str, Any]:
    """
    Generate a spec with Google API Gateway extensions
    (x-google-backend, x-google-allow, x-google-endpoints, etc.)
    Depending on openapi_version, generates OpenAPI 3.0 or Swagger 2.0.
    """
    include_set = set(include_tags) if include_tags else None
    exclude_set = set(exclude_tags) if exclude_tags else None

    routes = _filter_routes_by_tags(app, include_set, exclude_set)
    openapi_schema = app.openapi()
    
    if openapi_version.startswith("3."):
        # Generate OpenAPI 3.x spec natively
        spec = openapi_schema.copy()
        
        # Override metadata
        spec["openapi"] = "3.0.0"
        spec["info"]["title"] = title or app.title
        spec["info"]["version"] = version or app.version
        if app.description:
            spec["info"]["description"] = app.description
            
        spec["servers"] = [{"url": f"{scheme}://{host}{base_path}"} for scheme in (schemes or ["https"])]
        
        # Openapi 3 x-google-api-management mapping
        # Maps Swagger 2 snake_case config to OpenAPI 3.x camelCase config
        sw2_backend = backend.to_x_google_backend()
        oa3_backend = {"address": sw2_backend["address"]}
        
        if "deadline" in sw2_backend:
            oa3_backend["deadline"] = sw2_backend["deadline"]
        if "path_translation" in sw2_backend:
            oa3_backend["pathTranslation"] = sw2_backend["path_translation"]
        if "protocol" in sw2_backend:
            oa3_backend["protocol"] = sw2_backend["protocol"]
        if "jwt_audience" in sw2_backend:
            oa3_backend["jwtAudience"] = sw2_backend["jwt_audience"]
        if "disable_auth" in sw2_backend:
            oa3_backend["disableAuth"] = sw2_backend["disable_auth"]

        spec["x-google-api-management"] = {
            "backends": {
                "default_backend": oa3_backend
            }
        }
        spec["x-google-backend"] = "default_backend"
        
        if extra_x_google:
            for k, v in extra_x_google.items():
                spec[f"x-google-{k}"] = v
                
        # Handle Security
        if security_definitions:
            if "components" not in spec:
                spec["components"] = {}
            if "securitySchemes" not in spec["components"]:
                spec["components"]["securitySchemes"] = {}
            for sd in security_definitions:
                spec["components"]["securitySchemes"][sd.name] = sd.to_dict()
                
        if default_security:
            spec["security"] = default_security
            
        if exclude_responses and "components" in spec and "schemas" in spec["components"]:
            del spec["components"]["schemas"]
            
        # Filter routes
        allowed_paths = {(r.path, m.lower()) for r in routes for m in r.methods}
        paths_to_keep = {}
        for path, methods in openapi_schema.get("paths", {}).items():
            kept_methods = {}
            for method, operation in methods.items():
                if (path, method.lower()) in allowed_paths:
                    op = dict(operation)
                    if exclude_responses:
                        op["responses"] = {"200": {"description": "Successful response"}}
                    if exclude_parameters_schemas and "parameters" in op:
                        new_params = []
                        for param in op["parameters"]:
                            p = dict(param)
                            if "schema" in p:
                                p["schema"] = {"type": "string"}
                            new_params.append(p)
                        op["parameters"] = new_params
                    if exclude_parameters_schemas and "requestBody" in op:
                        op["requestBody"] = {
                            "content": {
                                "application/json": {"schema": {"type": "object"}}
                            }
                        }
                    kept_methods[method] = op
            if kept_methods:
                paths_to_keep[path] = kept_methods
        spec["paths"] = paths_to_keep
        
        return spec

    # Generate Swagger 2.0 spec
    spec: Dict[str, Any] = {
        "swagger": "2.0",
        "info": {
            "title": title or app.title,
            "description": app.description or "",
            "version": version or app.version,
        },
        "host": host,
        "basePath": base_path,
        "schemes": schemes or ["https"],
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "x-google-backend": backend.to_x_google_backend(),
        "paths": {},
    }

    if extra_x_google:
        for k, v in extra_x_google.items():
            spec[f"x-google-{k}"] = v

    # Security
    if security_definitions:
        spec["securityDefinitions"] = {sd.name: sd.to_dict() for sd in security_definitions}
    if default_security:
        spec["security"] = default_security

    openapi_paths = openapi_schema.get("paths", {})

    allowed_paths = {(r.path, m.lower()) for r in routes for m in r.methods}

    for path, methods in openapi_paths.items():
        gw_path = _convert_path(path)
        for method, operation in methods.items():
            if (path, method.lower()) not in allowed_paths:
                continue

            op_spec: Dict[str, Any] = {
                "operationId": operation.get("operationId", f"{method}_{path}"),
                "summary": operation.get("summary", ""),
                "responses": {
                    "200": {"description": "Successful response"}
                },
            }
            if "description" in operation:
                op_spec["description"] = operation["description"]
            if "tags" in operation:
                op_spec["tags"] = operation["tags"]
            if "parameters" in operation:
                op_spec["parameters"] = _convert_parameters(operation["parameters"])

            # Body — collapse to a generic object
            request_body = operation.get("requestBody")
            if request_body:
                op_spec.setdefault("parameters", []).append({
                    "name": "body",
                    "in": "body",
                    "required": request_body.get("required", False),
                    "schema": {"type": "object"},
                })

            spec["paths"].setdefault(gw_path, {})[method.lower()] = op_spec

    return spec


def _convert_path(path: str) -> str:
    """OpenAPI path params are already {name}, same as Swagger 2."""
    return path
