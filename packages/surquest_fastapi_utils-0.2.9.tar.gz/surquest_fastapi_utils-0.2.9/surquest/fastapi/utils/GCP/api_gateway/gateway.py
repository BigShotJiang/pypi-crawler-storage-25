from typing import Optional, List, Dict, Any
from fastapi import FastAPI

from .backends import GatewayBackend, BackendType, SecurityDefinition
from .routes import create_gateway_router


class GCPGateway:
    """
    Main extension entry point.

    Example:
        app = FastAPI()
        gw = GCPGateway(
            app,
            backend=GatewayBackend(
                type=BackendType.CLOUD_RUN,
                address="https://my-service-xyz-uc.a.run.app",
            ),
            host="my-gateway-xxxx.uc.gateway.dev",
        )
    """

    def __init__(
        self,
        app: FastAPI,
        backend: GatewayBackend,
        host: str,
        prefix: str = "/spec/apiGateway",
        base_path: str = "/",
        schemes: Optional[List[str]] = None,
        security_definitions: Optional[List[SecurityDefinition]] = None,
        default_security: Optional[List[Dict[str, List[str]]]] = None,
        extra_x_google: Optional[Dict[str, Any]] = None,
        openapi_version: str = "3.0",
    ):
        self.app = app
        self.backend = backend
        router = create_gateway_router(
            app=app,
            backend=backend,
            host=host,
            prefix=prefix,
            base_path=base_path,
            schemes=schemes,
            security_definitions=security_definitions,
            default_security=default_security,
            extra_x_google=extra_x_google,
            openapi_version=openapi_version,
        )
        app.include_router(router)


# Convenience factories for the three GCP runtimes
def cloud_run_backend(address: str, **kwargs) -> GatewayBackend:
    return GatewayBackend(type=BackendType.CLOUD_RUN, address=address, **kwargs)


def app_engine_backend(address: str, **kwargs) -> GatewayBackend:
    return GatewayBackend(type=BackendType.APP_ENGINE, address=address, **kwargs)


def cloud_function_backend(address: str, **kwargs) -> GatewayBackend:
    # Cloud Functions usually require disable_auth=true if gateway uses its own SA
    kwargs.setdefault("disable_auth", False)
    return GatewayBackend(type=BackendType.CLOUD_FUNCTION, address=address, **kwargs)
