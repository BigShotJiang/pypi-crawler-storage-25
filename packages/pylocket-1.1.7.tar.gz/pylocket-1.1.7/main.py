"""
PyLocket CLI -- main entry point.

Usage::

    pylocket --help
    pylocket login
    pylocket apps list
    pylocket protect --app <APP_ID> --artifact ./dist/myapp.pyz
    pylocket status --build <BUILD_ID>
    pylocket fetch --build <BUILD_ID> --out ./protected/

The CLI is built with Click and uses Rich for beautiful terminal output.
"""
from __future__ import annotations

import asyncio
import functools
import sys
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from cli.commands.apps import apps
from cli.commands.auth import auth, login
from cli.commands.distribute import distribute
from cli.commands.fetch import fetch
from cli.commands.licenses import licenses
from cli.commands.protect import protect
from cli.commands.status import status

# ---------------------------------------------------------------------------
# Shared console
# ---------------------------------------------------------------------------
console = Console()
err_console = Console(stderr=True)

# ---------------------------------------------------------------------------
# Async helper
# ---------------------------------------------------------------------------

def async_command(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that lets a Click command be an ``async def``."""

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))

    return wrapper


# ---------------------------------------------------------------------------
# Root CLI group
# ---------------------------------------------------------------------------
@click.group(
    name="pylocket",
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.option(
    "--api-url",
    envvar="PYLOCKET_API_URL",
    default=None,
    help="PyLocket API base URL (default: https://api.pylocket.com).",
)
@click.option(
    "--token",
    envvar="PYLOCKET_TOKEN",
    default=None,
    help="Bearer token for authentication (overrides stored credentials).",
)
@click.version_option(version="1.1.7", prog_name="pylocket")
@click.pass_context
def cli(ctx: click.Context, api_url: Optional[str], token: Optional[str]) -> None:
    """PyLocket -- Python application protection and licensing platform.

    Protect your Python source code, manage applications, and deliver
    secure builds from the command line.
    """
    ctx.ensure_object(dict)
    ctx.obj["api_url"] = api_url
    ctx.obj["token"] = token


# ---------------------------------------------------------------------------
# Register sub-commands / groups
# ---------------------------------------------------------------------------
cli.add_command(login)
cli.add_command(apps)
cli.add_command(protect)
cli.add_command(status)
cli.add_command(fetch)
cli.add_command(licenses)
cli.add_command(auth)
cli.add_command(distribute)

from cli.commands.webhook import webhook
cli.add_command(webhook)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> None:
    """Package entry point."""
    try:
        cli(standalone_mode=False)
    except click.Abort:
        err_console.print("\n[yellow]Aborted.[/yellow]")
        sys.exit(130)
    except click.ClickException as exc:
        exc.show()
        sys.exit(exc.exit_code)
    except Exception as exc:
        err_console.print(
            Panel(
                Text(str(exc), style="red"),
                title="[bold red]Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
