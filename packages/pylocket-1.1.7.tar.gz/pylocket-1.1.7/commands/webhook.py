"""
Webhook configuration commands.

Configure webhook URLs to receive build event notifications
(build.completed, build.failed, build.rejected) instead of polling.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.table import Table

from cli.client import APIClient
from cli.config import resolve_api_url, load_token

console = Console()


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.get_event_loop().run_until_complete(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    console.print(f"[red]Error:[/red] {exc}")
    raise SystemExit(1)


@click.group(name="webhook")
@click.pass_context
def webhook(ctx: click.Context) -> None:
    """Configure build event webhooks."""
    pass


@webhook.command(name="set")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.option("--url", required=True, help="HTTPS webhook URL to receive build events.")
@click.pass_context
@_async
async def webhook_set(ctx: click.Context, app_id: str, url: str) -> None:
    """Set a webhook URL for build event notifications.

    When a build completes, fails, or is rejected, PyLocket will POST
    a signed JSON payload to this URL.
    """
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    async with APIClient(api_url, token=token or load_token(api_url)) as client:
        try:
            resp = await client._request(
                "PUT", f"/v1/apps/{app_id}/webhook",
                json={"url": url},
            )
        except Exception as exc:
            _handle_error(exc, api_url)
            return

    console.print()
    console.print("[green]✓ Webhook configured[/green]")
    console.print(f"  URL: {resp.get('url')}")
    console.print()
    console.print("[bold yellow]⚠ IMPORTANT: Save this secret now — it will not be shown again.[/bold yellow]")
    console.print(f"  Secret: [bold]{resp.get('secret')}[/bold]")
    console.print()
    console.print("Events: build.completed, build.failed, build.rejected")
    console.print()
    console.print("Verify payloads with the [bold]X-PyLocket-Signature[/bold] header:")
    console.print("  Format: t=<unix_timestamp>,v1=<hmac_sha256_hex>")
    console.print("  signed_content = f\"{timestamp}.{payload_json}\"")
    console.print("  expected = hmac.new(secret, signed_content, sha256).hexdigest()")


@webhook.command(name="remove")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.pass_context
@_async
async def webhook_remove(ctx: click.Context, app_id: str) -> None:
    """Remove the webhook configuration for an app."""
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    async with APIClient(api_url, token=token or load_token(api_url)) as client:
        try:
            await client._request("DELETE", f"/v1/apps/{app_id}/webhook")
        except Exception as exc:
            _handle_error(exc, api_url)
            return

    console.print("[green]✓ Webhook removed[/green]")


@webhook.command(name="test")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.pass_context
@_async
async def webhook_test(ctx: click.Context, app_id: str) -> None:
    """Send a test ping event to the configured webhook URL."""
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    async with APIClient(api_url, token=token or load_token(api_url)) as client:
        try:
            resp = await client._request("POST", f"/v1/apps/{app_id}/webhook/test")
        except Exception as exc:
            _handle_error(exc, api_url)
            return

    if resp.get("success"):
        console.print(f"[green]✓ Ping delivered[/green] — HTTP {resp.get('status_code')} from {resp.get('url')}")
    else:
        console.print(f"[red]✗ Ping failed[/red] — {resp.get('error') or f'HTTP {resp.get(\"status_code\")}'}")


@webhook.command(name="status")
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.pass_context
@_async
async def webhook_status(ctx: click.Context, app_id: str) -> None:
    """Show webhook configuration and recent delivery attempts."""
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    async with APIClient(api_url, token=token or load_token(api_url)) as client:
        try:
            app_data = await client._request("GET", f"/v1/apps/{app_id}")
            deliveries = await client._request(
                "GET", f"/v1/apps/{app_id}/webhook/deliveries?limit=10"
            )
        except Exception as exc:
            _handle_error(exc, api_url)
            return

    webhook_url = app_data.get("webhook_url")
    if not webhook_url:
        console.print("[yellow]No webhook configured for this app.[/yellow]")
        console.print("Set one with: pylocket webhook set --app <APP_ID> --url <HTTPS_URL>")
        return

    console.print(f"[bold]Webhook URL:[/bold] {webhook_url}")
    console.print(f"[bold]Secret hint:[/bold] ****{app_data.get('webhook_secret', '')[-4:]}")
    console.print()

    items = deliveries.get("deliveries", [])
    if not items:
        console.print("[dim]No delivery attempts yet.[/dim]")
        return

    table = Table(title=f"Recent Deliveries ({deliveries.get('total', 0)} total)")
    table.add_column("Event", style="cyan")
    table.add_column("Build ID", style="dim")
    table.add_column("Status", justify="center")
    table.add_column("Attempt")
    table.add_column("Time")
    for d in items:
        status_str = (
            f"[green]{d['status_code']}[/green]"
            if d.get("success")
            else f"[red]{d.get('status_code') or d.get('error_message', 'error')[:30]}[/red]"
        )
        table.add_row(
            d["event_type"],
            d["build_id"][:8],
            status_str,
            str(d["attempt"]),
            d.get("created_at", "")[:19],
        )
    console.print(table)
