"""
Fetch command for the PyLocket CLI.

    pylocket fetch --build <BUILD_ID> --out <PATH>

Downloads a protected artifact to the specified output directory.
"""
from __future__ import annotations

import asyncio
import functools
import sys
from pathlib import Path
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


def _format_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} TB"


# ---------------------------------------------------------------------------
# pylocket fetch
# ---------------------------------------------------------------------------
@click.command()
@click.option(
    "--build",
    "build_id",
    required=True,
    help="Build UUID of the protected artifact.",
)
@click.option(
    "--app",
    "app_id",
    default=None,
    help="App UUID (optional — improves lookup speed).",
)
@click.option(
    "--out",
    "output_path",
    required=True,
    type=click.Path(),
    help="Output directory or file path for the downloaded artifact.",
)
@click.pass_context
@_async
async def fetch(ctx: click.Context, build_id: str, app_id: Optional[str], output_path: str) -> None:
    """Download a protected artifact from a completed build.

    The build must have a status of COMPLETED. If it is still processing,
    this command will exit with a helpful message.
    """
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    console.print()

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            # ---- Step 1: Verify build is complete ------------------------
            with console.status(
                "[bold cyan]Checking build status...[/bold cyan]", spinner="dots"
            ):
                build = await client.get_build(build_id, app_id=app_id)

            build_status = build.get("status", "unknown")

            if build_status not in ("completed", "ready"):
                status_msg = {
                    "pending": (
                        "yellow",
                        "Build is still pending. It has not started processing yet.",
                    ),
                    "processing": (
                        "yellow",
                        "Build is currently processing. Please wait for it to complete.",
                    ),
                    "failed": (
                        "red",
                        f"Build failed: {build.get('error_message', 'Unknown error')}",
                    ),
                }
                color, msg = status_msg.get(
                    build_status,
                    ("red", f"Unexpected build status: {build_status}"),
                )
                err_console.print(
                    Panel(
                        f"[{color}]{msg}[/{color}]\n\n"
                        f"  [bold]Build ID:[/bold] {build_id}\n"
                        f"  [bold]Status:[/bold]   {build_status.upper()}",
                        title=f"[bold {color}]Cannot Download[/bold {color}]",
                        border_style=color,
                    )
                )
                if build_status in ("pending", "processing"):
                    console.print(
                        f"  [dim]Check status: "
                        f"pylocket status --build {build_id}[/dim]"
                    )
                sys.exit(1)

            # ---- Step 2: Get download URL --------------------------------
            with console.status(
                "[bold cyan]Requesting download URL...[/bold cyan]", spinner="dots"
            ):
                dl_info = await client.download_artifact(build_id, app_id=app_id)

            download_url = dl_info.get("download_url", "")
            if not download_url:
                err_console.print(
                    Panel(
                        "[red]The API did not return a download URL.[/red]\n"
                        "The protected artifact may not be available yet.",
                        title="[bold red]Download Error[/bold red]",
                        border_style="red",
                    )
                )
                sys.exit(1)

            # ---- Step 3: Determine destination path ----------------------
            out = Path(output_path).resolve()

            # If the output path looks like a directory (existing dir or
            # ends with /), put the file inside it. Otherwise treat as a
            # file path.
            if out.is_dir() or str(output_path).endswith("/"):
                out.mkdir(parents=True, exist_ok=True)
                # Derive filename from the download URL or build metadata.
                file_name = dl_info.get("file_name")
                if not file_name:
                    file_name = f"build-{build_id}-protected.zip"
                dest = out / file_name
            else:
                out.parent.mkdir(parents=True, exist_ok=True)
                dest = out

            # ---- Step 4: Download with progress bar ----------------------
            console.print(
                f"  [cyan]Downloading to:[/cyan] [bold]{dest}[/bold]"
            )
            console.print()

            with Progress(
                SpinnerColumn(),
                TextColumn("[bold cyan]Downloading...[/bold cyan]"),
                BarColumn(bar_width=40),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                dl_task = progress.add_task("download", total=0)

                def on_progress(downloaded: int, total: int) -> None:
                    if total > 0:
                        progress.update(dl_task, total=total, completed=downloaded)
                    else:
                        progress.update(dl_task, completed=downloaded)

                await client.download_file(
                    download_url, dest, on_progress=on_progress
                )

            # ---- Step 5: Report success ----------------------------------
            final_size = dest.stat().st_size
            console.print()
            console.print(
                Panel(
                    f"[bold green]Download complete![/bold green]\n\n"
                    f"  [bold]File:[/bold]      {dest.name}\n"
                    f"  [bold]Size:[/bold]      {_format_size(final_size)}\n"
                    f"  [bold]Location:[/bold]  {dest}\n"
                    f"  [bold]Build:[/bold]     {build_id}",
                    title="[bold green]Artifact Downloaded[/bold green]",
                    border_style="green",
                )
            )

    except SystemExit:
        raise
    except Exception as exc:
        _handle_error(exc, api_url)
