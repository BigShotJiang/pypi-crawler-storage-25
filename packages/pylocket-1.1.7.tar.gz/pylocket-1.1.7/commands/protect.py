"""
Protection command for the PyLocket CLI.

    pylocket protect --app <APP_ID> --artifact <PATH> [options]

Uploads a Python artifact, triggers protection, optionally waits for
completion, and downloads the protected output.
"""
from __future__ import annotations

import asyncio
import functools
import sys
import time
from pathlib import Path
from typing import Any, Callable, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table
from rich.text import Text

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)

# Supported artifact extensions.
SUPPORTED_EXTENSIONS = {
    ".py", ".pyz", ".pyw",
    ".whl", ".egg",
    ".zip", ".tar.gz", ".tgz", ".tar.bz2",
    ".exe", ".app",
}

# Map file extensions to API artifact_type values.
_EXT_TO_ARTIFACT_TYPE = {
    ".exe": "exe",
    ".app": "app",
    ".zip": "zip",
    ".tar.gz": "tar_gz",
    ".tgz": "tar_gz",
    ".tar.bz2": "tar_gz",
    ".whl": "whl",
    ".egg": "egg",
    ".py": "py",
    ".pyz": "pyz",
    ".pyw": "pyw",
}


def _detect_artifact_type(path: Path) -> str:
    """Detect the artifact type from the file extension."""
    name = path.name.lower()
    for ext, atype in _EXT_TO_ARTIFACT_TYPE.items():
        if name.endswith(ext):
            return atype
    return "zip"  # fallback

# Maximum poll duration before giving up (10 minutes).
_MAX_POLL_SECONDS = 600
_POLL_INTERVAL = 3  # seconds between status checks


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _validate_artifact(path: Path) -> None:
    """Raise click.BadParameter if the artifact is invalid."""
    if not path.exists():
        raise click.BadParameter(f"File not found: {path}")
    if not path.is_file():
        raise click.BadParameter(f"Not a file: {path}")

    # Check extension (handle .tar.gz specially)
    name = path.name.lower()
    valid = False
    for ext in SUPPORTED_EXTENSIONS:
        if name.endswith(ext):
            valid = True
            break
    if not valid:
        supported = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        raise click.BadParameter(
            f"Unsupported file type: {path.suffix}\n"
            f"Supported types: {supported}"
        )


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


def _format_size(n: int) -> str:
    """Human-readable file size."""
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} TB"


# ---------------------------------------------------------------------------
# pylocket protect
# ---------------------------------------------------------------------------
@click.command()
@click.option(
    "--app",
    "app_id",
    required=True,
    help="Application UUID.",
)
@click.option(
    "--artifact",
    "artifact_path",
    required=True,
    type=click.Path(exists=False),
    help="Path to the Python artifact to protect.",
)
@click.option(
    "--platform",
    default=None,
    help="Target platform (auto-detected if not specified). Examples: win-x64, linux-x64, darwin-arm64.",
)
@click.option(
    "--python",
    "python_version",
    default=None,
    type=click.Choice(["3.12", "3.13", "3.14"], case_sensitive=False),
    help="Python version used to build the artifact (3.12, 3.13, or 3.14).",
)
@click.option(
    "--version",
    "build_version",
    default="1.0.0",
    show_default=True,
    help="Build version label.",
)
@click.option(
    "--wait/--no-wait",
    default=True,
    show_default=True,
    help="Wait for the protection build to complete.",
)
@click.option(
    "--out",
    "output_dir",
    default=None,
    type=click.Path(),
    help="Download protected artifact to this directory (implies --wait).",
)
@click.pass_context
@_async
async def protect(
    ctx: click.Context,
    app_id: str,
    artifact_path: str,
    platform: Optional[str],
    python_version: Optional[str],
    build_version: str,
    wait: bool,
    output_dir: Optional[str],
) -> None:
    """Protect a Python artifact.

    Uploads the artifact, triggers the protection pipeline, optionally waits
    for the build to complete, and downloads the protected output.
    """
    path = Path(artifact_path).resolve()
    _validate_artifact(path)

    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    # If --out is provided, always wait.
    if output_dir:
        wait = True

    # Auto-detect platform if not specified.
    if not platform:
        import sysconfig
        plat_tag = sysconfig.get_platform()
        # Normalize: Python 3.12+ may use underscores (e.g. win_amd64)
        plat_tag = plat_tag.replace("_", "-")
        # Map sysconfig platform tags to PyLocket platform names
        _auto_map = {
            "win-amd64": "win-x64",
            "win32": "win-x64",
            "linux-x86-64": "linux-x64",
            "linux-x86_64": "linux-x64",
            "linux-aarch64": "linux-arm64",
            "macosx-": "darwin-arm64",  # prefix match, refined below
        }
        platform = "python"  # fallback
        for prefix, mapped in _auto_map.items():
            if plat_tag.startswith(prefix):
                platform = mapped
                break
        # Broad Windows fallback for any unmatched win-* variant
        if platform == "python" and plat_tag.startswith("win"):
            platform = "win-x64"
        # Refine macOS: check if ARM or Intel
        if plat_tag.startswith("macosx"):
            import platform as _pmod
            platform = "darwin-arm64" if _pmod.machine() == "arm64" else "darwin-x64"

    file_size = path.stat().st_size

    console.print()
    console.print(
        Panel(
            f"[bold cyan]Protecting Artifact[/bold cyan]\n\n"
            f"  [bold]App:[/bold]          {app_id}\n"
            f"  [bold]Artifact:[/bold]     {path.name}  ({_format_size(file_size)})\n"
            f"  [bold]Platform:[/bold]     {platform}\n"
            f"  [bold]Python:[/bold]       {python_version or 'auto'}\n"
            f"  [bold]Protection:[/bold]   maximum\n"
            f"  [bold]Version:[/bold]      {build_version}",
            border_style="cyan",
        )
    )
    console.print()

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            # ---- Step 1: Create build ------------------------------------
            with console.status(
                "[bold cyan]Creating build...[/bold cyan]", spinner="dots"
            ):
                build = await client.create_build(
                    app_id=app_id,
                    version=build_version,
                    python_version=python_version,
                    platform=platform,
                    artifact_type=_detect_artifact_type(path),
                )

            build_id = str(build.get("id", ""))
            upload_url = build.get("upload_url", "")
            console.print(f"  [green]Build created:[/green] [bold]{build_id}[/bold]")

            if not upload_url:
                err_console.print("[red]Build response did not include an upload URL.[/red]")
                sys.exit(1)

            # ---- Step 2: Upload artifact ---------------------------------
            console.print()
            with Progress(
                SpinnerColumn(),
                TextColumn("[bold cyan]Uploading...[/bold cyan]"),
                BarColumn(bar_width=40),
                DownloadColumn(),
                TransferSpeedColumn(),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                task = progress.add_task("upload", total=file_size)

                def on_upload_progress(uploaded: int, total: int) -> None:
                    progress.update(task, completed=uploaded)

                await client.upload_artifact_direct(
                    upload_url=upload_url,
                    build_id=build_id,
                    file_path=path,
                    app_id=app_id,
                    on_progress=on_upload_progress,
                )

            console.print("  [green]Upload complete.[/green]")

            # ---- Step 3: Poll for completion (if --wait) -----------------
            if not wait:
                console.print()
                console.print(
                    Panel(
                        f"Build [bold]{build_id}[/bold] is processing.\n"
                        f"Check status with: [cyan]pylocket status --build {build_id}[/cyan]",
                        title="[bold yellow]Build Queued[/bold yellow]",
                        border_style="yellow",
                    )
                )
                return

            console.print()
            build_status = build.get("status", "pending")
            start_time = time.monotonic()

            with Progress(
                SpinnerColumn(),
                BarColumn(bar_width=30),
                TextColumn("[bold cyan]{task.description}[/bold cyan]"),
                TextColumn("[dim]{task.fields[pct]}%[/dim]"),
                TimeElapsedColumn(),
                console=console,
            ) as progress:
                task = progress.add_task(
                    "Processing...", total=100, completed=0, pct="0"
                )

                while build_status in (
                    "pending", "processing", "queued",
                    "scanning", "packaging", "rejected",
                ):
                    if build_status == "rejected":
                        break

                    if time.monotonic() - start_time > _MAX_POLL_SECONDS:
                        console.print()
                        err_console.print(
                            Panel(
                                f"[yellow]Build {build_id} is still processing "
                                f"after {_MAX_POLL_SECONDS}s.[/yellow]\n"
                                f"Check later: [cyan]pylocket status --build {build_id}[/cyan]",
                                title="[bold yellow]Timeout[/bold yellow]",
                                border_style="yellow",
                            )
                        )
                        sys.exit(2)

                    await asyncio.sleep(_POLL_INTERVAL)
                    build_data = await client.get_build(build_id, app_id=app_id)
                    build_status = build_data.get("status", "pending")

                    # Update progress bar from server-computed fields
                    pct = build_data.get("progress_percent", 0)
                    msg = build_data.get("progress_message", "Processing...")
                    progress.update(
                        task, completed=pct, description=msg, pct=str(pct)
                    )

            # ---- Step 4: Report result -----------------------------------
            console.print()
            if build_status in ("completed", "ready"):
                console.print(
                    Panel(
                        f"[bold green]Build completed successfully![/bold green]\n\n"
                        f"  [bold]Build ID:[/bold]  {build_id}\n"
                        f"  [bold]Status:[/bold]    [green]COMPLETED[/green]",
                        title="[bold green]Protection Complete[/bold green]",
                        border_style="green",
                    )
                )

                # ---- Step 5: Download (if --out) -------------------------
                if output_dir:
                    out_path = Path(output_dir).resolve()
                    out_path.mkdir(parents=True, exist_ok=True)

                    with console.status(
                        "[bold cyan]Fetching download URL...[/bold cyan]",
                        spinner="dots",
                    ):
                        dl_info = await client.download_artifact(build_id, app_id=app_id)

                    download_url = dl_info.get("download_url", "")
                    if not download_url:
                        err_console.print(
                            "[red]No download URL returned by the API.[/red]"
                        )
                        sys.exit(1)

                    dest_file = out_path / f"{path.stem}-protected{path.suffix}"

                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[bold cyan]Downloading...[/bold cyan]"),
                        BarColumn(bar_width=40),
                        DownloadColumn(),
                        TransferSpeedColumn(),
                        TimeRemainingColumn(),
                        console=console,
                    ) as progress:
                        dl_task = progress.add_task("download", total=0)

                        def on_download_progress(downloaded: int, total: int) -> None:
                            if total > 0:
                                progress.update(dl_task, total=total, completed=downloaded)
                            else:
                                progress.update(dl_task, completed=downloaded)

                        await client.download_file(
                            download_url,
                            dest_file,
                            on_progress=on_download_progress,
                        )

                    console.print()
                    console.print(
                        f"  [green]Saved to:[/green] [bold]{dest_file}[/bold]"
                    )

            elif build_status == "rejected":
                err_console.print(
                    Panel(
                        f"[red]Build rejected:[/red] Malware detected in artifact.\n\n"
                        f"  [bold]Build ID:[/bold] {build_id}\n"
                        f"  The uploaded artifact was flagged by security scanning.",
                        title="[bold red]Build Rejected[/bold red]",
                        border_style="red",
                    )
                )
                sys.exit(1)
            elif build_status == "failed":
                error_msg = build_data.get("error_message", "Unknown error")
                err_console.print(
                    Panel(
                        f"[red]Build failed:[/red] {error_msg}\n\n"
                        f"  [bold]Build ID:[/bold] {build_id}",
                        title="[bold red]Protection Failed[/bold red]",
                        border_style="red",
                    )
                )
                sys.exit(1)
            else:
                err_console.print(
                    f"[yellow]Unexpected build status: {build_status}[/yellow]"
                )
                sys.exit(1)

    except SystemExit:
        raise
    except Exception as exc:
        _handle_error(exc, api_url)
