"""Nazode Watch — バックグラウンドAIデーモン for macOS"""

__version__ = "0.2.2"
