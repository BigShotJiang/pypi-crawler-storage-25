"""
Nazode Watch — バックグラウンドAIデーモン

機能:
  - クリップボード監視 → エラー/コード/URLをコピーしたら自動解析
  - ファイル保存監視 → コード保存時に自動AIレビュー
  - 定期スクリーンショット → 作業ログ自動保存
  - ログWebUI → localhost:8888 でブラウザ確認
  - 日次サマリー → 毎朝9時に昨日の統計を通知
  - Git pre-commit連携 → コミット前に自動チェック

使い方:
  nazode-watch start       バックグラウンドで起動
  nazode-watch stop        停止
  nazode-watch status      状態確認
  nazode-watch log         直近のログを表示
  nazode-watch web         ブラウザでログを開く (localhost:8888)
  nazode-watch install-hook [path]  Gitリポジトリにpre-commitフックを設置
  nazode-watch config      設定を編集
"""

import os
import sys
import json
import time
import signal
import platform
import subprocess
import threading
import hashlib
import urllib.request
import urllib.error
from datetime import datetime, date
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler

import ollama

# ── 設定 ─────────────────────────────────────────────────────────────────────

NAZODE_DIR  = Path.home() / ".nazode"
WATCH_DIR   = NAZODE_DIR / "watch"
LOG_FILE    = WATCH_DIR / "watch.log"
PID_FILE    = WATCH_DIR / "watch.pid"
WEB_PID     = WATCH_DIR / "web.pid"
SS_DIR      = NAZODE_DIR / "screenshots" / "watch"
SUMMARY_DIR = WATCH_DIR / "summaries"

WATCH_MODEL = "qwen2.5-coder:1.5b"

WATCH_EXTS  = {".py", ".js", ".ts", ".go", ".rs", ".java", ".swift", ".kt",
               ".c", ".cpp", ".h", ".rb", ".php", ".sh", ".yaml", ".toml"}

CLIP_INTERVAL    = 2.0
SS_INTERVAL      = 300
REVIEW_COOLDOWN  = 30
SUMMARY_HOUR     = 9   # 毎朝9時

PLATFORM = platform.system()  # "Darwin" / "Linux" / "Windows"

# ── ログ ─────────────────────────────────────────────────────────────────────

def _setup():
    WATCH_DIR.mkdir(parents=True, exist_ok=True)
    SS_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)


def _log(msg: str):
    ts = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


# ── 通知（クロスプラットフォーム）────────────────────────────────────────────

def _escape_applescript(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _notify(title: str, message: str):
    try:
        if PLATFORM == "Darwin":
            script = (
                f'display notification "{_escape_applescript(message)}" '
                f'with title "{_escape_applescript(title)}" sound name "default"'
            )
            subprocess.run(["osascript", "-e", script], capture_output=True)
        elif PLATFORM == "Linux":
            subprocess.run(["notify-send", title, message], capture_output=True)
        elif PLATFORM == "Windows":
            # plyer がなければ標準出力のみ
            try:
                from plyer import notification
                notification.notify(title=title, message=message, timeout=5)
            except ImportError:
                print(f"[通知] {title}: {message}")
    except Exception:
        pass


# ── クリップボード（クロスプラットフォーム）──────────────────────────────────

def _get_clipboard() -> str:
    try:
        if PLATFORM == "Darwin":
            result = subprocess.run(["pbpaste"], capture_output=True, text=True)
            return result.stdout
        elif PLATFORM == "Linux":
            for cmd in [["xclip", "-selection", "clipboard", "-o"],
                        ["xsel", "--clipboard", "--output"],
                        ["wl-paste"]]:
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    if result.returncode == 0:
                        return result.stdout
                except FileNotFoundError:
                    continue
        elif PLATFORM == "Windows":
            result = subprocess.run(
                ["powershell", "-command", "Get-Clipboard"],
                capture_output=True, text=True
            )
            return result.stdout
    except Exception:
        pass
    return ""


# ── スクリーンショット（クロスプラットフォーム）──────────────────────────────

def _take_screenshot(path: Path):
    if PLATFORM == "Darwin":
        subprocess.run(["screencapture", "-x", str(path)], capture_output=True)
    elif PLATFORM == "Linux":
        for cmd in [["scrot", str(path)],
                    ["import", "-window", "root", str(path)],
                    ["gnome-screenshot", "-f", str(path)]]:
            try:
                result = subprocess.run(cmd, capture_output=True)
                if result.returncode == 0:
                    return
            except FileNotFoundError:
                continue
    elif PLATFORM == "Windows":
        try:
            import mss
            with mss.mss() as sct:
                sct.shot(output=str(path))
        except ImportError:
            pass


# ── AI ───────────────────────────────────────────────────────────────────────

def _ai(prompt: str, max_tokens: int = 300) -> str:
    global WATCH_MODEL
    try:
        resp = ollama.chat(
            model=WATCH_MODEL,
            messages=[{"role": "user", "content": prompt}],
            options={"num_ctx": 4096, "num_predict": max_tokens,
                     "num_thread": 2, "temperature": 0.1, "keep_alive": -1},
        )
        return resp.message.content.strip()
    except Exception as e:
        return f"ERROR: {e}"


# ── クリップボード監視 ────────────────────────────────────────────────────────

def _classify_clipboard(text: str) -> str:
    t = text.strip().lower()
    if any(w in t for w in ["error", "exception", "traceback", "エラー", "失敗",
                              "errno", "fatal", "panic", "undefined", "syntaxerror",
                              "typeerror", "valueerror", "nameerror", "null pointer"]):
        return "error"
    code_markers = ["def ", "class ", "function ", "import ", "const ", "let ",
                    "var ", "return ", "if (", "for (", "=>", "->", "::", "{}"]
    if sum(1 for m in code_markers if m in text) >= 2:
        return "code"
    if text.strip().startswith("http://") or text.strip().startswith("https://"):
        return "url"
    return "other"


class ClipboardWatcher(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._last_hash = ""
        self._stop_event = threading.Event()

    def stop(self): self._stop_event.set()

    def run(self):
        _log("📋 クリップボード監視開始")
        while not self._stop_event.is_set():
            try:
                text = _get_clipboard().strip()
                if not text or len(text) < 20 or len(text) > 8000:
                    time.sleep(CLIP_INTERVAL)
                    continue

                h = hashlib.md5(text.encode()).hexdigest()
                if h == self._last_hash:
                    time.sleep(CLIP_INTERVAL)
                    continue
                self._last_hash = h

                kind = _classify_clipboard(text)

                if kind == "error":
                    _log(f"🔴 エラー検出: {text[:80]}...")
                    analysis = _ai(
                        f"以下のエラーを日本語で簡潔に説明し、解決策を1〜2行で提案してください:\n\n{text[:2000]}"
                    )
                    _notify("🔴 Nazode Watch: エラー検出", analysis[:100])
                    _log(f"  → {analysis[:200]}")

                elif kind == "code":
                    _log(f"💻 コードをコピー: {text[:60]}...")
                    review = _ai(
                        f"以下のコードの問題点があれば1〜2行で指摘してください。問題なければ「問題なし」と返してください:\n\n{text[:2000]}"
                    )
                    if "問題なし" not in review and len(review) > 5:
                        _notify("💻 Nazode Watch: コード確認", review[:100])
                        _log(f"  → {review[:200]}")

                elif kind == "url":
                    url = text.strip()
                    _log(f"🔗 URLをコピー: {url[:80]}")
                    try:
                        import urllib.parse as _urlparse
                        _parsed = _urlparse.urlparse(url)
                        if _parsed.scheme not in ("http", "https"):
                            _log(f"  → 許可されていないスキーム: {_parsed.scheme}")
                            time.sleep(CLIP_INTERVAL)
                            continue
                        req = urllib.request.Request(
                            url,
                            headers={"User-Agent": "Mozilla/5.0 (compatible; NazodeWatch/1.0)"}
                        )
                        with urllib.request.urlopen(req, timeout=6) as resp:
                            raw = resp.read(8000).decode("utf-8", errors="replace")
                        summary = _ai(
                            f"以下のHTMLから、このWebサイトが何のサイトか日本語で1〜2行で要約してください:\n\n{raw[:3000]}"
                        )
                        _notify("🔗 Nazode Watch: URL", summary[:100])
                        _log(f"  → {summary[:200]}")
                    except Exception as e:
                        _log(f"  → URL取得失敗: {e}")

            except Exception as e:
                _log(f"ClipboardWatcher error: {e}")
            time.sleep(CLIP_INTERVAL)


# ── ファイル保存監視 ──────────────────────────────────────────────────────────

class FileReviewer(threading.Thread):
    def __init__(self, watch_paths: list[str]):
        super().__init__(daemon=True)
        self._paths = [Path(p).expanduser() for p in watch_paths]
        self._stop_event = threading.Event()
        self._cooldowns: dict[str, float] = {}

    def stop(self): self._stop_event.set()

    def _should_review(self, path: str) -> bool:
        last = self._cooldowns.get(path, 0)
        return time.time() - last > REVIEW_COOLDOWN

    def run(self):
        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler

            class Handler(FileSystemEventHandler):
                def on_modified(inner_self, event):
                    if event.is_directory:
                        return
                    p = Path(event.src_path)
                    if p.suffix not in WATCH_EXTS:
                        return
                    if not self._should_review(str(p)):
                        return
                    self._cooldowns[str(p)] = time.time()
                    self._review_file(p)

            observer = Observer()
            handler = Handler()
            for watch_path in self._paths:
                if watch_path.exists():
                    observer.schedule(handler, str(watch_path), recursive=True)
                    _log(f"📁 ファイル監視: {watch_path}")

            observer.start()
            while not self._stop_event.is_set():
                time.sleep(1)
            observer.stop()
            observer.join()
        except ImportError:
            _log("watchdog 未インストール。ファイル監視をスキップ")

    def _review_file(self, path: Path):
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            if len(content) < 10:
                return
            _log(f"🔍 レビュー中: {path.name}")
            review = _ai(
                f"以下の{path.suffix}ファイルをレビューしてください。"
                f"重大な問題があれば1〜2行で指摘、問題なければ「OK」と返してください:\n\n{content[:2000]}"
            )
            if review.strip().upper() != "OK" and len(review) > 3:
                _notify(f"🔍 Nazode Watch: {path.name}", review[:100])
                _log(f"  → {review[:200]}")
            else:
                _log(f"  → OK")
        except Exception as e:
            _log(f"review error ({path.name}): {e}")


# ── 定期スクリーンショット ────────────────────────────────────────────────────

class ScreenLogger(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()

    def stop(self): self._stop_event.set()

    def run(self):
        _log(f"📸 スクリーンショットログ開始 (間隔: {SS_INTERVAL}秒)")
        while not self._stop_event.is_set():
            try:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                path = SS_DIR / f"{ts}.png"
                _take_screenshot(path)
                shots = sorted(SS_DIR.glob("*.png"), key=lambda p: p.stat().st_mtime)
                for old in shots[:-30]:
                    old.unlink()
            except Exception as e:
                _log(f"screenshot error: {e}")
            self._stop_event.wait(SS_INTERVAL)


# ── 日次サマリー ──────────────────────────────────────────────────────────────

class DailySummary(threading.Thread):
    """毎朝 SUMMARY_HOUR 時に前日のログを集計して通知する。"""

    def __init__(self):
        super().__init__(daemon=True)
        self._stop_event = threading.Event()
        self._last_date = date.today()

    def stop(self): self._stop_event.set()

    def run(self):
        _log(f"📊 日次サマリー有効 (毎日 {SUMMARY_HOUR:02d}:00)")
        while not self._stop_event.is_set():
            now = datetime.now()
            today = now.date()

            # 今日まだサマリーを出していない かつ SUMMARY_HOUR を過ぎている
            if today > self._last_date and now.hour >= SUMMARY_HOUR:
                self._last_date = today
                self._send_summary()

            self._stop_event.wait(60)  # 1分ごとにチェック

    def _send_summary(self):
        try:
            if not LOG_FILE.exists():
                return

            from datetime import timedelta
            yesterday = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")

            lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
            # 昨日の日付を含む行だけ対象（ログに日付が含まれない場合は全行）
            dated = [l for l in lines if yesterday in l]
            target = dated if dated else lines

            errors  = sum(1 for l in target if "エラー検出" in l)
            codes   = sum(1 for l in target if "コードをコピー" in l)
            reviews = sum(1 for l in target if "レビュー中" in l)
            urls    = sum(1 for l in target if "URLをコピー" in l)
            total   = errors + codes + reviews + urls

            summary_text = (
                f"エラー:{errors}件 コード:{codes}件 "
                f"ファイル:{reviews}件 URL:{urls}件 (計{total}件)"
            )

            _notify("📊 Nazode Watch: 昨日のサマリー", summary_text)
            _log(f"📊 日次サマリー送信: {summary_text}")

            # サマリーをファイルに保存
            summary_file = SUMMARY_DIR / f"{date.today().isoformat()}.txt"
            summary_file.write_text(summary_text + "\n", encoding="utf-8")

        except Exception as e:
            _log(f"DailySummary error: {e}")


# ── ログ Web UI ───────────────────────────────────────────────────────────────

WEB_PORT = 8888

_SHELL_HTML = (
    '<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8">'
    '<title>Nazode Watch</title><style>'
    '*{margin:0;padding:0;box-sizing:border-box}'
    'html,body{height:100%;background:#05070f;color:#a0aec0;font-family:"SF Mono","Fira Code",monospace;font-size:13px}'
    'body{display:flex;flex-direction:column;min-height:100vh}'

    '.hd{padding:24px 32px 0;border-bottom:1px solid #0e1a2e}'
    '.hd-inner{max-width:1100px;margin:0 auto;display:flex;align-items:flex-end;justify-content:space-between;padding-bottom:16px}'
    '.hd-title{font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#1e40af;margin-bottom:4px}'
    '.hd-main{font-size:26px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#e2e8f0}'
    '.hd-sub{font-size:11px;color:#1e3a5f;margin-top:4px}'
    '.hd-live{display:flex;align-items:center;gap:6px;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#1d4ed8}'
    '.live-dot{width:7px;height:7px;border-radius:50%;background:#3b82f6;animation:livepulse 1.6s ease-in-out infinite}'
    '@keyframes livepulse{0%,100%{opacity:1}50%{opacity:.3}}'

    '.stats{max-width:1100px;margin:24px auto 0;width:100%;padding:0 32px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px}'
    '.stat{background:#080e1a;border:1px solid #0e1a2e;border-radius:8px;padding:16px 20px}'
    '.stat-num{font-size:28px;font-weight:700;color:#e2e8f0;line-height:1}'
    '.stat-lbl{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#1e3a5f;margin-top:6px}'

    '.tabs-wrap{max-width:1100px;margin:20px auto 0;width:100%;padding:0 32px}'
    '.tabs-nav{display:flex;gap:0;border-bottom:1px solid #0e1a2e;margin-bottom:16px}'
    '.tab-btn{padding:8px 20px;font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:#1e3a5f;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;transition:color .2s,border-color .2s;background:none;border-top:none;border-left:none;border-right:none;font-family:inherit}'
    '.tab-btn.active{color:#3b82f6;border-bottom-color:#3b82f6}'
    '.tab-btn:hover{color:#6e7681}'
    '.tab-pane{display:none}.tab-pane.active{display:block}'
    '.ar-list{display:flex;flex-direction:column;gap:8px}'
    '.ar-card{background:#080e1a;border:1px solid #0e1a2e;border-radius:8px;overflow:hidden;transition:border-color .3s;animation:slidein .25s ease}'
    '@keyframes slidein{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}'
    '.ar-card.error{border-left:3px solid #f87171}'
    '.ar-card.code{border-left:3px solid #34d399}'
    '.ar-card.file{border-left:3px solid #a78bfa}'
    '.ar-card.url{border-left:3px solid #38bdf8}'
    '.ar-card-head{display:flex;align-items:center;gap:10px;padding:12px 16px;cursor:pointer;user-select:none}'
    '.ar-card-head:hover{background:#0a1020}'
    '.ar-badge{font-size:9px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:2px 8px;border-radius:3px;border:1px solid currentColor}'
    '.ar-badge.error{color:#f87171}.ar-badge.code{color:#34d399}.ar-badge.file{color:#a78bfa}.ar-badge.url{color:#38bdf8}.ar-badge.info{color:#6e7681}'
    '.ar-ts{font-size:10px;color:#1e3a5f}'
    '.ar-preview{flex:1;font-size:12px;color:#6e7681;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
    '.ar-chevron{font-size:10px;color:#1e3a5f;transition:transform .2s}'
    '.ar-card.open .ar-chevron{transform:rotate(180deg)}'
    '.ar-body{display:none;padding:0 16px 14px;font-size:13px;color:#e2e8f0;line-height:1.75;border-top:1px solid #0e1a2e}'
    '.ar-card.open .ar-body{display:block}'
    '.log-cnt{font-size:10px;color:#1e3a5f;margin-bottom:8px}'
    '.feed{display:flex;flex-direction:column;gap:1px}'
    '.ln{display:flex;gap:14px;padding:4px 8px;border-radius:4px;line-height:1.65}'
    '.ln:hover{background:#080e1a}'
    '.ts{color:#1e3a5f;flex-shrink:0;user-select:none}'
    '.msg{word-break:break-all}'
    '.ln.error .msg{color:#f87171}'
    '.ln.code .msg{color:#34d399}'
    '.ln.file .msg{color:#a78bfa}'
    '.ln.url .msg{color:#38bdf8}'
    '.ln.summary .msg{color:#fbbf24}'
    '.ln.info .msg{color:#2d4a6e}'
    '.sc-wrap{max-width:1100px;margin:20px auto 0;width:100%;padding:0 32px}'
    '.sc{background:#080e1a;border:1px solid #0e1a2e;border-radius:8px;padding:20px 24px;display:flex;align-items:center;gap:20px;position:relative;overflow:hidden}'
    '.sc::after{content:"";position:absolute;inset:0;background:var(--glow,transparent);pointer-events:none;transition:background .5s;border-radius:8px}'
    '.sc-icon{font-size:28px;flex-shrink:0}'
    '.sc-body{flex:1}'
    '.sc-label{font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:#1e3a5f;margin-bottom:4px}'
    '.sc-state{font-size:20px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#e2e8f0;transition:color .3s}'
    '.sc-sub{font-size:11px;color:#1e3a5f;margin-top:4px;transition:color .3s}'
    '.sc-badge{padding:4px 12px;border-radius:4px;font-size:10px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;border:1px solid currentColor}'

    '@keyframes pb{0%{box-shadow:0 0 0 0 rgba(59,130,246,.7)}70%{box-shadow:0 0 0 10px rgba(59,130,246,0)}100%{box-shadow:0 0 0 0 rgba(59,130,246,0)}}'
    '</style></head><body>'

    '<div class="hd"><div class="hd-inner">'
    '<div><div class="hd-title">AI Daemon Monitor</div>'
    '<div class="hd-main">NAZODE WATCH</div>'
    '<div class="hd-sub">Background clipboard &amp; file watcher</div></div>'
    '<div class="hd-live"><div class="live-dot"></div>LIVE</div>'
    '</div></div>'

    '<div class="stats">'
    '<div class="stat"><div class="stat-num" id="cnt-error">0</div><div class="stat-lbl">Errors Detected</div></div>'
    '<div class="stat"><div class="stat-num" id="cnt-review">0</div><div class="stat-lbl">File Reviews</div></div>'
    '<div class="stat"><div class="stat-num" id="cnt-url">0</div><div class="stat-lbl">URLs Analyzed</div></div>'
    '<div class="stat"><div class="stat-num" id="cnt-total">0</div><div class="stat-lbl">Total Events</div></div>'
    '</div>'

    '<div class="sc-wrap"><div class="sc" id="sc">'
    '<div class="sc-icon" id="sc-icon">&#x25CF;</div>'
    '<div class="sc-body">'
    '<div class="sc-label">Current State</div>'
    '<div class="sc-state" id="sc-state">STANDBY</div>'
    '<div class="sc-sub" id="sc-sub">クリップボードを監視中</div>'
    '</div>'
    '<div class="sc-badge" id="sc-badge" style="color:#1e3a5f;border-color:#0e1a2e">IDLE</div>'
    '</div></div>'

    '<div class="tabs-wrap">'
    '<div class="tabs-nav">'
    '<button class="tab-btn active" onclick="switchTab(\'analysis\',this)">Analysis Results</button>'
    '<button class="tab-btn" onclick="switchTab(\'log\',this)">Event Log <span id="log-cnt" style="opacity:.5"></span></button>'
    '</div>'
    '<div class="tab-pane active" id="tab-analysis"><div class="ar-list" id="ar-list"></div></div>'
    '<div class="tab-pane" id="tab-log"><div class="feed" id="feed"></div></div>'
    '</div>'

    '<script>'
    'function switchTab(id,btn){'
    'document.querySelectorAll(".tab-pane").forEach(p=>p.classList.remove("active"));'
    'document.querySelectorAll(".tab-btn").forEach(b=>b.classList.remove("active"));'
    'document.getElementById("tab-"+id).classList.add("active");'
    'btn.classList.add("active");}'
    'const STATES={'
    'idle:{icon:"&#x25CF;",iconColor:"#1e3a5f",state:"STANDBY",sub:"クリップボードを監視中",badge:"IDLE",badgeColor:"#1e3a5f",glow:"transparent"},'
    'thinking:{icon:"&#x25D4;",iconColor:"#3b82f6",state:"ANALYZING",sub:"AIが解析しています...",badge:"PROCESSING",badgeColor:"#3b82f6",glow:"radial-gradient(ellipse at 0% 50%,rgba(30,64,175,.15),transparent 70%)"},'
    'done:{icon:"&#x2713;",iconColor:"#22c55e",state:"COMPLETE",sub:"解析が完了しました",badge:"DONE",badgeColor:"#22c55e",glow:"radial-gradient(ellipse at 0% 50%,rgba(34,197,94,.1),transparent 70%)"}'
    '};'
    'let last="idle",doneT=null;'
    'function applyState(s){'
    'if(s===last)return;last=s;'
    'const c=STATES[s];'
    'const ic=document.getElementById("sc-icon");'
    'ic.innerHTML=c.icon;ic.style.color=c.iconColor;'
    'document.getElementById("sc-state").textContent=c.state;'
    'document.getElementById("sc-sub").textContent=c.sub;'
    'const b=document.getElementById("sc-badge");'
    'b.textContent=c.badge;b.style.color=c.badgeColor;b.style.borderColor=c.badgeColor;'
    'document.getElementById("sc").style.setProperty("--glow",c.glow);'
    '}'
    'function cls(l){'
    'if(l.includes("エラー")||l.includes("ERROR"))return"error";'
    'if(l.includes("💻")||l.includes("コードをコピー"))return"code";'
    'if(l.includes("🔍")||l.includes("レビュー"))return"file";'
    'if(l.includes("🔗")||l.includes("URL"))return"url";'
    'if(l.includes("📊")||l.includes("サマリー"))return"summary";'
    'return"info";}'
    'function ts(l){const m=l.match(/^(\\[\\d{2}:\\d{2}:\\d{2}\\])\\s*(.*)/);return m?[m[1],m[2]]:["",l];}'
    'function det(lines){'
    'const r=lines.slice(-5).join(" ");'
    'if(/解析中|レビュー中|要約中/.test(r))return"thinking";'
    'if(/エラー検出|レビュー完了|要約完了|検出|完了/.test(r))return"done";'
    'return"idle";}'
    'async function poll(){'
    'try{'
    'const d=await(await fetch("/data")).json();'
    'const s=det(d.lines);'
    'if(s==="done"&&last!=="done"){applyState("done");clearTimeout(doneT);doneT=setTimeout(()=>applyState("idle"),4000);}'
    'else if(s==="thinking")applyState("thinking");'
    'else if(s==="idle"&&last!=="done")applyState("idle");'
    'let err=0,rev=0,url=0;'
    'd.lines.forEach(l=>{if(l.includes("エラー")||l.includes("ERROR"))err++;else if(l.includes("レビュー"))rev++;else if(l.includes("URL")||l.includes("🔗"))url++;});'
    'document.getElementById("cnt-error").textContent=err;'
    'document.getElementById("cnt-review").textContent=rev;'
    'document.getElementById("cnt-url").textContent=url;'
    'document.getElementById("cnt-total").textContent=d.lines.length;'
    'const feed=document.getElementById("feed");'
    'const frag=document.createDocumentFragment();'
    'd.lines.slice(-300).reverse().forEach(line=>{'
    'const[t,m]=ts(line);'
    'const div=document.createElement("div");'
    'div.className="ln "+cls(line);'
    'const safe=m.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");'
    'div.innerHTML=`<span class="ts">${t}</span><span class="msg">${safe}</span>`;'
    'frag.appendChild(div);});'
    'feed.innerHTML="";feed.appendChild(frag);'
    'document.getElementById("log-cnt").textContent="("+d.lines.length+")";'
    'const list=document.getElementById("ar-list");'
    'if(d.results&&d.results.length!==list.dataset.count-0){'
    'list.dataset.count=d.results.length;'
    'list.innerHTML="";'
    'd.results.slice().reverse().forEach((r,i)=>{'
    'const card=document.createElement("div");'
    'card.className="ar-card "+r.kind;'
    'const preview=r.text.slice(0,60)+(r.text.length>60?"...":"");'
    'card.innerHTML=`<div class="ar-card-head" onclick="this.parentElement.classList.toggle(\'open\')">`'
    '+`<span class="ar-badge ${r.kind}">${r.kind.toUpperCase()}</span>`'
    '+`<span class="ar-ts">${r.ts}</span>`'
    '+`<span class="ar-preview">${preview.replace(/&/g,"&amp;").replace(/</g,"&lt;")}</span>`'
    '+`<span class="ar-chevron">▼</span>`'
    '+`</div><div class="ar-body">${r.text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/\\n/g,"<br>")}</div>`;'
    'if(i===0)card.classList.add("open");'
    'list.appendChild(card);});}'
    '}catch(e){}'
    'setTimeout(poll,2500);}'
    'poll();'
    '</script></body></html>'
)


def _detect_status(lines: list[str]) -> str:
    recent = " ".join(lines[-5:])
    if any(k in recent for k in ("解析中", "レビュー中", "要約中")):
        return "thinking"
    if any(k in recent for k in ("エラー検出", "レビュー完了", "要約完了", "検出", "完了")):
        return "done"
    return "idle"


class _LogHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/data":
            lines = LOG_FILE.read_text(encoding="utf-8").splitlines() if LOG_FILE.exists() else []
            # 全解析結果を抽出: "→ " で始まる行とその直前イベントをペアに
            results = []
            for i, line in enumerate(lines):
                stripped = line.strip()
                if not stripped.startswith("→ "):
                    continue
                text = stripped[2:]
                ts_match = line[:10] if line.startswith("[") else ""
                kind = "info"
                for prev in reversed(lines[:i]):
                    if "🔴" in prev or "エラー" in prev:
                        kind = "error"; break
                    if "💻" in prev:
                        kind = "code"; break
                    if "🔍" in prev or "レビュー" in prev:
                        kind = "file"; break
                    if "🔗" in prev or "URL" in prev:
                        kind = "url"; break
                results.append({"ts": ts_match, "kind": kind, "text": text})
            import json as _json
            body = _json.dumps(
                {"lines": lines[-500:], "results": results[-50:]},
                ensure_ascii=False
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)
        else:
            body = _SHELL_HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", len(body))
            self.end_headers()
            self.wfile.write(body)

    def log_message(self, format, *args):
        pass  # アクセスログを抑制


def _run_web_server():
    server = HTTPServer(("localhost", WEB_PORT), _LogHandler)
    WEB_PID.write_text(str(os.getpid()))
    print(f"🌐 ログビューア起動中: http://localhost:{WEB_PORT}")
    print("   終了: Ctrl+C")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        WEB_PID.unlink(missing_ok=True)


# ── Git pre-commit フック ─────────────────────────────────────────────────────

PRE_COMMIT_SCRIPT = """\
#!/bin/sh
# Nazode Watch — pre-commit AI review
# インストール: nazode-watch install-hook

STAGED=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\\.(py|js|ts|go|rs|java|swift|kt|c|cpp|rb|php|sh)$')

if [ -z "$STAGED" ]; then
  exit 0
fi

echo "[Nazode Watch] コミット前AIレビュー実行中..."

ISSUES=0
for FILE in $STAGED; do
  if [ -f "$FILE" ]; then
    RESULT=$(head -c 4000 "$FILE" | python3 - <<'PYEOF' 2>/dev/null
import sys, ollama
content = sys.stdin.read()
try:
    resp = ollama.chat(
        model='qwen2.5-coder:1.5b',
        messages=[{'role':'user','content':'以下のコードに重大な問題があれば1行で指摘。問題なければ「OK」とだけ返してください:\n\n' + content[:2000]}],
        options={'num_predict':100,'temperature':0.1,'keep_alive':-1}
    )
    print(resp.message.content.strip())
except Exception:
    print('OK')
PYEOF
)
    if [ "$RESULT" != "OK" ] && [ -n "$RESULT" ]; then
      echo "  ⚠️  $FILE: $RESULT"
      ISSUES=$((ISSUES+1))
    else
      echo "  ✅ $FILE: OK"
    fi
  fi
done

if [ $ISSUES -gt 0 ]; then
  echo ""
  echo "[Nazode Watch] $ISSUES 件の指摘があります。コミットを続けますか？ (y/N)"
  exec < /dev/tty
  read REPLY
  case "$REPLY" in
    y|Y) exit 0 ;;
    *)   echo "コミットを中止しました"; exit 1 ;;
  esac
fi

exit 0
"""


def cmd_install_hook(repo_path: str = "."):
    git_dir = Path(repo_path).expanduser().resolve() / ".git"
    if not git_dir.exists():
        print(f"エラー: {repo_path} はGitリポジトリではありません")
        sys.exit(1)

    hook_path = git_dir / "hooks" / "pre-commit"

    if hook_path.exists():
        print(f"既存のpre-commitフックが見つかりました: {hook_path}")
        ans = input("上書きしますか？ (y/N): ")
        if ans.lower() != "y":
            print("中止しました")
            return

    hook_path.write_text(PRE_COMMIT_SCRIPT)
    hook_path.chmod(0o755)
    print(f"✅ pre-commitフックをインストールしました: {hook_path}")
    print("   次回 git commit 時から自動AIレビューが実行されます")


# ── デーモン本体 ──────────────────────────────────────────────────────────────

def _load_config() -> dict:
    config_path = WATCH_DIR / "config.json"
    defaults = {
        "watch_paths": [str(Path.home())],
        "clipboard": True,
        "file_review": True,
        "screenshot_log": True,
        "daily_summary": True,
        "model": "qwen2.5-coder:1.5b",
    }
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text())
            defaults.update(cfg)
        except Exception:
            pass
    else:
        config_path.write_text(json.dumps(defaults, ensure_ascii=False, indent=2))
    return defaults


def run_daemon():
    global WATCH_MODEL
    _setup()
    cfg = _load_config()
    WATCH_MODEL = cfg.get("model", WATCH_MODEL)

    _log("=" * 50)
    _log(f"🚀 Nazode Watch 起動 (OS: {PLATFORM})")
    _log(f"   モデル: {WATCH_MODEL}")

    threads = []

    if cfg.get("clipboard", True):
        t = ClipboardWatcher(); t.start(); threads.append(t)

    if cfg.get("file_review", True):
        t = FileReviewer(cfg.get("watch_paths", [str(Path.home())])); t.start(); threads.append(t)

    if cfg.get("screenshot_log", True):
        t = ScreenLogger(); t.start(); threads.append(t)

    if cfg.get("daily_summary", True):
        t = DailySummary(); t.start(); threads.append(t)

    def _shutdown(sig, frame):
        _log("🛑 Nazode Watch 停止")
        for t in threads:
            t.stop()
        PID_FILE.unlink(missing_ok=True)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    PID_FILE.write_text(str(os.getpid()))
    _notify("Nazode Watch", "バックグラウンド監視を開始しました")

    while True:
        time.sleep(60)


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    _setup()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "start"

    if cmd == "start":
        if PID_FILE.exists():
            pid = PID_FILE.read_text().strip()
            try:
                os.kill(int(pid), 0)
                print(f"すでに起動中です (PID: {pid})")
                return
            except ProcessLookupError:
                PID_FILE.unlink(missing_ok=True)  # ゾンビPIDを削除して再起動
        proc = subprocess.Popen(
            [sys.executable, "-c",
             "from nazode_watch.watch import run_daemon; run_daemon()"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        time.sleep(1)
        if PID_FILE.exists():
            print(f"✅ Nazode Watch 起動完了 (PID: {PID_FILE.read_text().strip()})")
            print(f"   ログ: {LOG_FILE}")
            print(f"   Web UI: nazode-watch web")
        else:
            print(f"⚠️  起動に失敗した可能性があります。ログを確認: {LOG_FILE}")

    elif cmd == "stop":
        if not PID_FILE.exists():
            print("Nazode Watch は起動していません")
            return
        pid = int(PID_FILE.read_text().strip())
        try:
            os.kill(pid, signal.SIGTERM)
            PID_FILE.unlink(missing_ok=True)
            print(f"✅ Nazode Watch を停止しました (PID: {pid})")
        except ProcessLookupError:
            PID_FILE.unlink(missing_ok=True)
            print("プロセスが見つかりません（すでに停止済み）")

    elif cmd == "status":
        if PID_FILE.exists():
            pid = PID_FILE.read_text().strip()
            try:
                os.kill(int(pid), 0)
                print(f"🟢 Nazode Watch 実行中 (PID: {pid})")
            except ProcessLookupError:
                PID_FILE.unlink(missing_ok=True)
                print("🔴 Nazode Watch 停止中")
        else:
            print("🔴 Nazode Watch 停止中")
        print(f"   ログ: {LOG_FILE}")
        if LOG_FILE.exists():
            lines = LOG_FILE.read_text().splitlines()
            print(f"   ログ行数: {len(lines)}")

    elif cmd == "log":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 30
        if LOG_FILE.exists():
            lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
            for line in lines[-n:]:
                print(line)
        else:
            print("ログがありません")

    elif cmd == "web":
        # フォアグラウンドでWebサーバーを起動してブラウザを開く
        import webbrowser
        url = f"http://localhost:{WEB_PORT}"
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
        _run_web_server()

    elif cmd == "install-hook":
        repo_path = sys.argv[2] if len(sys.argv) > 2 else "."
        cmd_install_hook(repo_path)

    elif cmd == "config":
        cfg_path = WATCH_DIR / "config.json"
        editor = os.environ.get("EDITOR", "nano")
        subprocess.run([editor, str(cfg_path)])

    else:
        print("使い方: nazode-watch start|stop|status|log|web|install-hook|config")


if __name__ == "__main__":
    main()
