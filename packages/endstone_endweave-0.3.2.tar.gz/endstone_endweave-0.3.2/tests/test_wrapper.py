"""Tests for PacketWrapper API mechanics."""

import struct
from unittest.mock import MagicMock

from endstone_endweave.codec import (
    BOOL,
    BYTE,
    INT_BE,
    INT_LE,
    STRING,
    VAR_INT,
    PacketWrapper,
)
from endstone_endweave.codec.writer import PacketWriter
from endstone_endweave.connection import UserConnection
from endstone_endweave.protocol import Protocol
from endstone_endweave.protocol.direction import Direction


class TestPacketWrapperBasics:
    def test_passthrough_preserves_data(self):
        """passthrough reads and writes, returning the value."""
        w = PacketWriter()
        w.write_int_be(944)
        w.write_string("hello")
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        val = wrapper.passthrough(INT_BE)
        assert val == 944
        s = wrapper.passthrough(STRING)
        assert s == "hello"
        assert wrapper.to_bytes() == payload

    def test_read_removes_field(self):
        """read consumes from input without writing to output."""
        w = PacketWriter()
        w.write_int_be(944)
        w.write_string("hello")
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        val = wrapper.read(INT_BE)
        assert val == 944
        wrapper.passthrough(STRING)
        result = wrapper.to_bytes()
        w2 = PacketWriter()
        w2.write_string("hello")
        assert result == w2.to_bytes()

    def test_write_inserts_field(self):
        """write appends to output without reading from input."""
        w = PacketWriter()
        w.write_string("hello")
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        wrapper.write(INT_BE, 999)
        wrapper.passthrough(STRING)
        result = wrapper.to_bytes()

        w2 = PacketWriter()
        w2.write_int_be(999)
        w2.write_string("hello")
        assert result == w2.to_bytes()

    def test_cancel(self):
        wrapper = PacketWrapper(b"\x00")
        assert not wrapper.cancelled
        wrapper.cancel()
        assert wrapper.cancelled

    def test_passthrough_all(self):
        payload = b"\x01\x02\x03\x04"
        wrapper = PacketWrapper(payload)
        wrapper.read(BYTE)  # consume first byte
        remaining = wrapper.passthrough_all()
        assert remaining == b"\x02\x03\x04"
        assert wrapper.to_bytes() == b"\x02\x03\x04"

    def test_to_bytes_includes_unread_tail(self):
        """to_bytes appends any unread input bytes automatically."""
        payload = b"\x01\x02\x03\x04"
        wrapper = PacketWrapper(payload)
        wrapper.passthrough(BYTE)
        result = wrapper.to_bytes()
        assert result == payload

    def test_map_converts_type(self):
        """map() reads with old type and writes with new type."""
        w = PacketWriter()
        w.write_varint(42)
        w.write_byte(0xFF)
        wrapper = PacketWrapper(w.to_bytes())
        val = wrapper.map(VAR_INT, INT_LE)
        assert val == 42
        result = wrapper.to_bytes()
        assert result[:4] == struct.pack("<i", 42)
        assert result[4] == 0xFF

    def test_has_remaining(self):
        wrapper = PacketWrapper(b"\x01\x02")
        assert wrapper.has_remaining
        wrapper.read(BYTE)
        assert wrapper.has_remaining
        wrapper.read(BYTE)
        assert not wrapper.has_remaining

    def test_user(self):
        conn = UserConnection(address="1.2.3.4:1234", logger=MagicMock(), server_protocol=924)
        wrapper = PacketWrapper(b"\x00", user=conn)
        assert wrapper.user is conn


class TestPacketWrapperTransform:
    def test_remap_int_field(self):
        """Read a field, transform it, write the new value."""
        w = PacketWriter()
        w.write_int_be(944)
        w.write_bytes(b"\xde\xad")
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        old_val = wrapper.read(INT_BE)
        assert old_val == 944
        wrapper.write(INT_BE, 924)
        wrapper.passthrough_all()
        result = wrapper.to_bytes()

        assert struct.unpack(">i", result[:4])[0] == 924
        assert result[4:] == b"\xde\xad"

    def test_delete_middle_field(self):
        """Remove a field from the middle of a packet."""
        w = PacketWriter()
        w.write_byte(0x01)
        w.write_int_le(42)
        w.write_byte(0x02)
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        wrapper.passthrough(BYTE)
        wrapper.read(INT_LE)
        wrapper.passthrough(BYTE)
        result = wrapper.to_bytes()
        assert result == bytes([0x01, 0x02])

    def test_insert_field_in_middle(self):
        """Insert a new field between existing ones."""
        w = PacketWriter()
        w.write_byte(0x01)
        w.write_byte(0x02)
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload)
        wrapper.passthrough(BYTE)
        wrapper.write(BOOL, True)
        wrapper.passthrough(BYTE)
        result = wrapper.to_bytes()
        assert result == bytes([0x01, 0x01, 0x02])


class TestWrapperHandlerIntegration:
    """Test wrapper-style handlers integrated with Protocol."""

    def test_wrapper_handler_rewrites_packet(self):
        def rewrite_protocol(wrapper: PacketWrapper) -> None:
            conn = wrapper.user
            wrapper.read(INT_BE)
            wrapper.write(INT_BE, conn.server_protocol)

        p = Protocol(server_protocol=924, client_protocol=944)
        p.register_serverbound(193, rewrite_protocol)

        conn = UserConnection(address="1.2.3.4:1234", logger=MagicMock(), server_protocol=924)

        w = PacketWriter()
        w.write_int_be(944)
        w.write_bytes(b"\xde\xad")
        payload = w.to_bytes()

        wrapper = PacketWrapper(payload, user=conn)
        p.transform(Direction.SERVERBOUND, 193, wrapper)
        assert not wrapper.cancelled
        result = wrapper.to_bytes()
        assert struct.unpack(">i", result[:4])[0] == 924
        assert result[4:] == b"\xde\xad"

    def test_wrapper_handler_cancel(self):
        def cancel_handler(wrapper: PacketWrapper) -> None:
            wrapper.cancel()

        p = Protocol(server_protocol=924, client_protocol=944)
        p.register_serverbound(42, cancel_handler)

        conn = UserConnection(address="1.2.3.4:1234", logger=MagicMock(), server_protocol=924)
        wrapper = PacketWrapper(b"\x00", user=conn)
        p.transform(Direction.SERVERBOUND, 42, wrapper)
        assert wrapper.cancelled

    def test_wrapper_handler_passthrough_unchanged(self):
        def noop_handler(wrapper: PacketWrapper) -> None:
            wrapper.passthrough_all()

        p = Protocol(server_protocol=924, client_protocol=944)
        p.register_serverbound(42, noop_handler)

        conn = UserConnection(address="1.2.3.4:1234", logger=MagicMock(), server_protocol=924)
        wrapper = PacketWrapper(b"\x01\x02\x03", user=conn)
        p.transform(Direction.SERVERBOUND, 42, wrapper)
        assert not wrapper.cancelled
        assert wrapper.to_bytes() == b"\x01\x02\x03"
