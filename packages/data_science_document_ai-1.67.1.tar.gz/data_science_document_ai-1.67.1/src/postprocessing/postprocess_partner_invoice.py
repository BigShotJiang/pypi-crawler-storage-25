"""This module contains the postprocessing functions for the partner invoice."""
from collections import defaultdict

from rapidfuzz import fuzz, process

from src.io import logger
from src.utils import get_tms_item_code_mappings


def postprocessing_partner_invoice(partner_invoice):
    """Apply postprocessing to the partner invoice data."""
    # Flatten the invoice amount
    for amount in partner_invoice.get("invoiceAmount", {}):
        if isinstance(amount, list):
            amount = amount[0]
        if isinstance(amount, dict):
            partner_invoice.update(amount)
            break

    # Remove invoiceAmount - comes from DocAI
    if partner_invoice.get("invoiceAmount") is not None:
        partner_invoice.pop("invoiceAmount")

    # Remove containers - comes from DocAI
    # TODO: we can distribute containers to line items based on location proximity
    if partner_invoice.get("containers") is not None:
        partner_invoice.pop("containers")

    # Ensure only one item for optional multiple fields
    optional_multiple_list = [
        "dueDate",
        "eta",
        "etd",
        "fortoEntity",
        "hblNumber",
        "reverseChargeSentence",
    ]
    for k, v in partner_invoice.items():
        if (k in optional_multiple_list) and isinstance(v, list):
            partner_invoice[k] = v[0]

    # Update keys
    key_updates = {
        "pod": "portOfDischarge",
        "pol": "portOfLoading",
        "name": "lineItemDescription",
        "unit": "quantity",
    }

    def update_keys(d, key_updates):
        """
        Recursively updates keys in a dictionary according to a mapping provided in key_updates.

        d: The original dictionary
        key_updates: A dictionary mapping old key names to new key names

        return A new dictionary with updated key names
        """
        if isinstance(d, dict):
            return {
                key_updates.get(k, k): update_keys(v, key_updates) for k, v in d.items()
            }
        elif isinstance(d, list):
            return [update_keys(item, key_updates) for item in d]
        else:
            return d

    updated_data = update_keys(partner_invoice, key_updates)
    return updated_data


def post_process_bundeskasse(aggregated_data):
    """Post-process the Bundeskasse invoice data."""
    # Check if the Credit note number starts with ATS and classify it to Credit Note else Invoice
    invoice_type = (
        "bundeskasseCreditNote"
        if aggregated_data.get("creditNoteInvoiceNumber", {})
        .get("documentValue", "")
        .startswith("ATS")
        else "bundeskasseInvoice"
    )

    aggregated_data["documentType"] = {
        "documentValue": invoice_type,
        "formattedValue": invoice_type,
    }

    # Predefine mappings for tax codes
    tax_type_mappings = {
        "A0000": "Zölle (ohne EGKS-Zölle, Ausgleichs-, Antidumping- und Zusatzzölle, Zölle auf Agrarwaren) (ZOLLEU)",
        "B0000": "Einfuhrumsatzsteuer(EUSt)",
        "A3000": "Endgültige Antidumpingzölle(ANTIDUMPEU)",
    }

    line_items = aggregated_data.get("lineItem", [])
    is_recipient_forto = False  # Check if Forto account is in any line item

    # Process each line item
    for line_item in line_items:
        tax_type = line_item.get("taxType")
        if tax_type and "name" in line_item:
            # Map the tax type to the corresponding value
            line_item["name"]["formattedValue"] = tax_type_mappings.get(
                tax_type.get("documentValue"), line_item["name"]["documentValue"]
            )

        # Check if the deferredDutyPayer is forto
        KEYWORDS = {"de789147263644738", "forto", "009812"}

        def is_forto_recipient(line_item: dict) -> bool:
            values_to_check = [
                line_item.get("deferredDutyPayer", {}).get("documentValue", ""),
                line_item.get("vatId", {}).get("documentValue", ""),
            ]

            combined = " ".join(values_to_check).lower()
            return any(keyword in combined for keyword in KEYWORDS)

        if is_forto_recipient(line_item):
            # Update the defferDutyPayer to Forto Logistics SE & Co KG
            if "deferredDutyPayer" in line_item:
                line_item["deferredDutyPayer"] = {
                    "documentValue": line_item.get("deferredDutyPayer", {}).get(
                        "documentValue"
                    ),
                    "formattedValue": "DE789147263644738",
                }

            is_recipient_forto = True

    update_aggregated_data_fields(aggregated_data, is_recipient_forto)


def update_aggregated_data_fields(aggregated_data, is_recipient_forto):
    """Update the recipient, vendor and deferredDutyPayer information in the aggregated data."""
    # Check if the "recipientName" and "recipientAddress" keys exist
    keys_to_init = ["recipientName", "recipientAddress", "vendorName", "vendorAddress"]
    for key in keys_to_init:
        aggregated_data.setdefault(key, {"formattedValue": "", "documentValue": ""})

    # Update the vendor details always to Bundeskasse Trier
    aggregated_data["vendorName"]["formattedValue"] = "Bundeskasse Trier"
    aggregated_data["vendorAddress"][
        "formattedValue"
    ] = "Dasbachstraße 15, 54292 Trier, Germany"

    if is_recipient_forto:
        # Update the aggregated data with the recipient information
        aggregated_data["recipientName"][
            "formattedValue"
        ] = "Forto Logistics SE & Co KG"
        aggregated_data["recipientAddress"][
            "formattedValue"
        ] = "Schönhauser Allee 9, 10119 Berlin, Germany"


def select_unique_bank_account(bank_account):
    # Select the unique bank account if multiple are present
    if isinstance(bank_account, list) and bank_account:
        best = defaultdict(lambda: None)

        for item in bank_account:
            dv = item["documentValue"]
            if best[dv] is None or item["page"] < best[dv]["page"]:
                best[dv] = item

        unique = list(best.values())
        return unique


async def process_partner_invoice(params, aggregated_data, document_type_code):
    """Process the partner invoice data."""
    # Post process bundeskasse invoices
    if document_type_code == "bundeskasse":
        post_process_bundeskasse(aggregated_data)
        return

    if "bankAccount" in aggregated_data:
        aggregated_data["bankAccount"] = select_unique_bank_account(
            aggregated_data["bankAccount"]
        )

    line_items = aggregated_data.get("lineItem", [])
    # Add debug logging
    logger.info(f"Processing partnerInvoice with {len(line_items)} line items")

    reverse_charge = None
    reverse_charge_info = aggregated_data.get("reverseChargeSentence")

    # Check if reverseChargeSentence exists and has the expected structure
    if isinstance(reverse_charge_info, dict):
        # Get the reverse charge sentence and Check if the reverse charge sentence is present
        rev_charge_sentence = reverse_charge_info.get("formattedValue", "")
        reverse_charge_value = if_reverse_charge_sentence(rev_charge_sentence, params)

        # Assign the reverse charge value to the aggregated data
        reverse_charge_info["formattedValue"] = reverse_charge_value
        reverse_charge = aggregated_data.pop("reverseChargeSentence", None)

    # Partner Name
    partner_name = aggregated_data.get("vendorName", {}).get("documentValue", None)

    # Process everything in one go
    processed_items = await process_line_items_batch(
        params, line_items, reverse_charge, partner_name, document_type_code
    )

    # Update your main data structure
    aggregated_data["lineItem"] = processed_items


async def process_line_items_batch(
    params: dict,
    line_items: list[dict],
    reverse_charge=None,
    partner_name=None,
    document_type_code=None,
):
    """Map partner-invoice line items to Forto item codes.

    For each item with a description, build a per-item payload carrying the
    raw uniqueId (tms-mappings resolves it to shipment context on its side),
    call tms-mappings /line_items, and write the returned code onto
    item["itemCode"]. Also handles customsized uniqueId splitting and
    reverse-charge annotation.
    """
    # Split customsized uniqueId (independent of mapping)
    if partner_name and "customsized" in partner_name.lower():
        for item in line_items:
            unique_id_obj = item.get("uniqueId")
            if unique_id_obj and isinstance(unique_id_obj, dict):
                fmt_val = unique_id_obj.get("documentValue", "")
                unique_id_obj["formattedValue"] = fmt_val.split("-")[0]

    # Collect items that need mapping
    items_to_map = []  # list of (item, desc, unique_id)
    for item in line_items:
        description_obj = item.get("lineItemDescription")
        if not description_obj or not description_obj.get("formattedValue"):
            continue
        desc = description_obj["formattedValue"]
        unique_id_obj = item.get("uniqueId")
        unique_id = (
            unique_id_obj.get("formattedValue")
            if isinstance(unique_id_obj, dict)
            else None
        )
        items_to_map.append((item, desc, unique_id))

    if items_to_map:
        payload = [
            {
                "description": desc,
                "document_type": document_type_code,
                "unique_id": uid,
                "vendor_name": partner_name,
            }
            for _, desc, uid in items_to_map
        ]
        logger.info(
            f"Mapping {len(payload)} line items via tms-mappings /line_items..."
        )

        mapped_codes = await get_tms_item_code_mappings(payload)

        for (item, desc, _), code in zip(items_to_map, mapped_codes):
            item["itemCode"] = {
                "documentValue": desc,
                "formattedValue": code,
                "page": item["lineItemDescription"].get("page"),
            }

    # Add reverse charge here if exists
    if reverse_charge:
        for item in line_items:
            ic = item.get("itemCode")
            if (ic and ic.get("formattedValue") != "CDU") or not ic:
                item["reverseChargeSentence"] = reverse_charge

    return line_items


def get_fuzzy_match_score(target: str, sentences: list, threshold: int):
    """Get the best fuzzy match for a target string from a list of candidates.

    Args:
        target (str): The string to match.
        sentences (list): List of strings to match against.
        threshold (int): Minimum score threshold to consider a match.

    Returns:
        tuple: (best_match, score) if above threshold, else (None, 0)
    """
    # Use multiprocessing to find the best match
    result = process.extractOne(
        target, sentences, scorer=fuzz.WRatio, score_cutoff=threshold
    )

    if result is None:
        return None, False

    match, _, _ = result

    if match:
        return match, True

    return None, False


def if_reverse_charge_sentence(sentence: str, params):
    """Check if the reverse charge sentence is present in the line item."""
    reverse_charge_sentences = params["lookup_data"]["reverse_charge_sentences"]
    threshold = params["fuzzy_threshold_reverse_charge"]

    # Check if ("ARTICLE 144", "ART. 144") in the sentence
    if "ARTICLE 144" in sentence or "ART 144" in sentence:
        return False

    # Check if the sentence is similar to any of the reverse charge sentences
    match, _ = get_fuzzy_match_score(
        sentence, list(reverse_charge_sentences.keys()), threshold
    )

    if match:
        return reverse_charge_sentences[match]

    return False


async def associate_forto_item_code(items: list[dict], document_type_code=None):
    """Map a list of line-item requests to Forto item codes via tms-mappings.

    Args:
        items: list of dicts with keys
            `original_description`, `description`, `unique_id`, `vendor_name`.
        document_type_code: optional document type string forwarded to the API.

    Returns:
        list[{"description", "itemCode"}] aligned to input order. `description`
        echoes the caller's original description verbatim.
    """
    if not items:
        return []

    payload = [
        {
            "description": item["description"],
            "document_type": document_type_code,
            "unique_id": item.get("unique_id"),
            "vendor_name": item.get("vendor_name"),
        }
        for item in items
    ]
    logger.info(f"Mapping {len(payload)} line items via tms-mappings /line_items...")

    mapped_codes = await get_tms_item_code_mappings(payload)

    return [
        {"description": item["original_description"], "itemCode": code}
        for item, code in zip(items, mapped_codes)
    ]
