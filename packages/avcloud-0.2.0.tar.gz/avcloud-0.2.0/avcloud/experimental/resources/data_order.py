"""Data order endpoints."""

from __future__ import annotations

import json
from typing import Any

from avcloud.experimental.resources.entity import DataOrder

_GENERIC_RPC_PATH = "/avcloud/api/v2/genericrpc"


class DataOrders:
    """Client for data order endpoints."""

    def __init__(self, client: Any):
        self._client = client

    def get(self, id: str) -> DataOrder:
        """Fetch a data order by id.

        Args:
            id: The data order id.

        Returns:
            A DataOrder.
        """

        request_body = {"dataOrder": {"name": id}}
        response = self._client.post(
            _GENERIC_RPC_PATH,
            json={
                "method": "DataOrderExtService.FetchDataOrder",
                "request_json": json.dumps(request_body),
            },
        )
        response_data = json.loads(response.json().get("responseJson", "{}"))
        return DataOrder.from_dict(response_data.get("dataOrder", {}))

    def submit(self, search_request: dict[str, Any]) -> DataOrder:
        """Submit a new data order.

        Args:
            search_request: A search request dict in the same shape accepted by
                `client.search_v2.search`.

        Returns:
            A DataOrder.
        """

        request_body = {"query": search_request}
        response = self._client.post(
            _GENERIC_RPC_PATH,
            json={
                "method": "DataOrderExtService.SubmitDataOrder",
                "request_json": json.dumps(request_body),
            },
        )
        response_data = json.loads(response.json().get("responseJson", "{}"))
        return DataOrder.from_dict(response_data.get("dataOrder", {}))
