# ventureinkorea

[![PyPI](https://img.shields.io/pypi/v/ventureinkorea)](https://pypi.org/project/ventureinkorea/)
[![Python](https://img.shields.io/pypi/pyversions/ventureinkorea)](https://pypi.org/project/ventureinkorea/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Zero Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)](https://pypi.org/project/ventureinkorea/)

Python API client for [VentureInKorea](https://ventureinkorea.com) — a comprehensive database of Korean venture-certified companies (벤처인증기업), startup ecosystem terminology, and in-depth articles about Korea's innovation economy. Available in 4 languages (Korean, English, Japanese, Chinese).

VentureInKorea tracks companies that have received official **Venture Business Certification** (벤처기업인증) from the Korean Ministry of SMEs and Startups (중소벤처기업부), along with glossary terms covering the full spectrum of Korea's startup support infrastructure.

> **Explore the platform at [ventureinkorea.com](https://ventureinkorea.com)** — [Glossary](https://ventureinkorea.com/glossary/) · [Blog](https://ventureinkorea.com/blog/) · [Companies](https://ventureinkorea.com/companies/)

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
- [What You'll Find on VentureInKorea](#what-youll-find-on-ventureinkorea)
  - [Venture Business Certification (벤처기업인증)](#venture-business-certification-벤처기업인증)
  - [Startup Support Programs](#startup-support-programs)
  - [Glossary of Korean Startup Terms](#glossary-of-korean-startup-terms)
  - [Blog & Guides](#blog--guides)
- [API Endpoints](#api-endpoints)
- [Command-Line Interface](#command-line-interface)
- [MCP Server (Claude, Cursor, Windsurf)](#mcp-server-claude-cursor-windsurf)
- [API Reference](#api-reference)
- [Also Available](#also-available)
- [License](#license)

## Install

```bash
pip install ventureinkorea          # Core (zero dependencies)
pip install ventureinkorea[api]     # + httpx API client
pip install ventureinkorea[cli]     # + CLI with Rich tables
pip install ventureinkorea[mcp]     # + MCP server for AI assistants
pip install ventureinkorea[all]     # Everything
```

## Quick Start

```python
from ventureinkorea.api import VentureInKorea

# Search Korean venture companies and startup terms
with VentureInKorea() as api:
    # Search across all content
    results = api.search("AI startup")
    print(results)

    # Browse glossary terms about Korean startup ecosystem
    terms = api.list_terms()
    for term in terms["results"]:
        print(f"{term['name']}: {term['slug']}")

    # Get platform statistics
    stats = api.get_stats()
    print(f"Total companies: {stats}")
```

## What You'll Find on VentureInKorea

### Venture Business Certification (벤처기업인증)

South Korea's **Venture Business Certification** system, established under the *Act on Special Measures for the Promotion of Venture Businesses* (벤처기업육성에 관한 특별조치법, 1997), is one of the world's most structured government-backed startup classification frameworks. Companies that earn certification gain access to tax benefits, preferential public procurement, and reduced regulatory burdens.

There are three main certification tracks:

| Track | Korean | Requirement | Certifying Body |
|-------|--------|-------------|-----------------|
| **Venture Capital Investment** | 벤처투자기업 | Received investment from registered VC | KVCA |
| **R&D Investment** | 연구개발기업 | R&D spending >= 5% of revenue | KISED |
| **Innovation Growth** | 혁신성장기업 | Revenue growth + innovation evaluation | Technology guarantee agencies |

As of 2025, over **39,000 companies** hold active venture certification in Korea, spanning sectors from AI/ML and biotech to fintech, deep tech, and green energy.

```python
# Browse venture-certified companies
with VentureInKorea() as api:
    companies = api.list_companies()
    for co in companies["results"]:
        print(f"{co['name']}")
```

### Startup Support Programs

Korea's startup ecosystem is supported by a dense network of government programs. VentureInKorea covers the key programs that shape the ecosystem:

| Program | Korean | Description |
|---------|--------|-------------|
| **TIPS** | 민간투자주도형 기술창업지원 | Angel-led + government matching fund (up to 500M KRW) |
| **K-Startup Grand Challenge** | 글로벌 스타트업 육성 | International accelerator bringing global founders to Korea |
| **DCAMP** | 은행청년창업재단 | Korea's largest startup campus run by banking sector |
| **Born2Global** | 본투글로벌센터 | Helps Korean startups expand internationally |
| **KISED** | 창업진흥원 | Central government agency for startup promotion |
| **Startup Campus** | 판교 스타트업캠퍼스 | Pangyo Techno Valley hub for startup co-working |

```python
# Search for TIPS-related content
with VentureInKorea() as api:
    tips_info = api.search("TIPS")
    print(tips_info)
```

### Glossary of Korean Startup Terms

The glossary covers essential Korean venture and startup terminology — crucial for anyone navigating Korea's innovation economy, whether as an investor, founder, or researcher.

| Category | Examples |
|----------|---------|
| **Legal & Certification** | 벤처기업인증, 기업부설연구소, 이노비즈, 메인비즈 |
| **Investment** | 시리즈A/B/C, 엔젤투자, 벤처캐피탈, 기업가치 |
| **Government Programs** | TIPS, 창업지원, 기술보증, 정책자금 |
| **Startup Operations** | 스케일업, 피봇, MVP, 린 스타트업, PMF |
| **Exit & IPO** | 코스닥 상장, M&A, 기업공개, 스팩 합병 |

```python
# Get a specific glossary term
with VentureInKorea() as api:
    term = api.get_term("venture-certification")
    print(f"{term['name']}: {term.get('definition', '')}")
```

### Blog & Guides

In-depth articles covering Korea's startup landscape — from policy analysis and funding guides to ecosystem reports and founder interviews. All content is available in Korean, English, Japanese, and Simplified Chinese.

```python
# Browse blog posts
with VentureInKorea() as api:
    posts = api.list_posts()
    for post in posts["results"]:
        print(f"{post['title']} ({post['slug']})")
```

## API Endpoints

All endpoints are free, require no authentication, return JSON, and support CORS.

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/terms/` | List all glossary terms |
| GET | `/api/v1/terms/{slug}/` | Term detail |
| GET | `/api/v1/posts/` | List all blog posts |
| GET | `/api/v1/posts/{slug}/` | Post detail with FAQs |
| GET | `/api/v1/companies/` | List venture companies |
| GET | `/api/v1/companies/{pk}/` | Company detail |
| GET | `/api/v1/categories/` | Post categories |
| GET | `/api/v1/faq/` | Aggregated FAQs |
| GET | `/api/v1/stats/` | Platform statistics |
| GET | `/api/v1/search/?q=` | Unified search |
| GET | `/api/v1/autocomplete/?q=` | Autocomplete suggestions |

### Example

```bash
# Search for AI-related ventures
curl -s "https://ventureinkorea.com/api/v1/search/?q=AI"
```

```json
{
  "results": [
    {
      "name": "AI Startup Guide",
      "type": "post",
      "slug": "ai-startup-guide",
      "url": "/blog/ai-startup-guide/"
    }
  ],
  "query": "AI",
  "total": 1
}
```

Full API documentation at [ventureinkorea.com/developers/](https://ventureinkorea.com/developers/).

## Command-Line Interface

```bash
pip install ventureinkorea[cli]

# Search across all content
ventureinkorea search "AI startup"

# List glossary terms
ventureinkorea terms --limit 10

# List venture companies
ventureinkorea companies --limit 10

# Platform statistics
ventureinkorea stats
```

## MCP Server (Claude, Cursor, Windsurf)

```bash
pip install ventureinkorea[mcp]

# Start the MCP server
ventureinkorea-mcp
```

### Claude Desktop

```json
{
  "mcpServers": {
    "ventureinkorea": {
      "command": "uvx",
      "args": ["--from", "ventureinkorea[mcp]", "ventureinkorea-mcp"]
    }
  }
}
```

### Cursor / Windsurf

```json
{
  "mcpServers": {
    "ventureinkorea": {
      "command": "uvx",
      "args": ["--from", "ventureinkorea[mcp]", "ventureinkorea-mcp"]
    }
  }
}
```

Available tools: `search_ventures`, `get_term`, `get_company`, `get_post`, `get_stats`.

## API Reference

| Function | Description |
|----------|-------------|
| `list_terms(**params)` | List glossary terms |
| `get_term(slug)` | Get term by slug |
| `list_posts(**params)` | List blog posts |
| `get_post(slug)` | Get post with FAQs |
| `list_companies(**params)` | List venture companies |
| `get_company(pk)` | Get company by ID |
| `list_categories(**params)` | List post categories |
| `list_faqs(**params)` | List aggregated FAQs |
| `get_stats()` | Get platform statistics |
| `search(query)` | Unified search |
| `autocomplete(query)` | Autocomplete suggestions |

## Also Available

| Platform | Install | Link |
|----------|---------|------|
| **npm** | `npm install ventureinkorea` | [npm](https://www.npmjs.com/package/ventureinkorea) |
| **Go** | `go get github.com/dobestan/ventureinkorea-go` | [pkg.go.dev](https://pkg.go.dev/github.com/dobestan/ventureinkorea-go) |
| **Rust** | `cargo add ventureinkorea` | [crates.io](https://crates.io/crates/ventureinkorea) |
| **Ruby** | `gem install ventureinkorea` | [rubygems.org](https://rubygems.org/gems/ventureinkorea) |
| **MCP** | `uvx --from "ventureinkorea[mcp]" ventureinkorea-mcp` | [Config](#mcp-server-claude-cursor-windsurf) |

## License

MIT
