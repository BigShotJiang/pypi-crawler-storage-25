"""Tests for VentureInKorea API client."""

from __future__ import annotations

from ventureinkorea.api import VentureInKorea


def test_client_init() -> None:
    """Client initialises with default base URL."""
    client = VentureInKorea()
    assert client._client.base_url == "https://ventureinkorea.com"
    client.close()


def test_client_custom_url() -> None:
    """Client accepts custom base URL."""
    client = VentureInKorea(base_url="https://staging.ventureinkorea.com")
    assert "staging" in str(client._client.base_url)
    client.close()


def test_client_context_manager() -> None:
    """Client works as context manager."""
    with VentureInKorea() as api:
        assert api is not None
