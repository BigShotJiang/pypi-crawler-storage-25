"""MCP server for VentureInKorea API.

Requires the ``mcp`` extra: ``pip install ventureinkorea[mcp]``

Start the server::

    ventureinkorea-mcp
    # or
    uvx --from "ventureinkorea[mcp]" python -m ventureinkorea.mcp_server
"""

from __future__ import annotations

from mcp.server import FastMCP

mcp = FastMCP("ventureinkorea")


@mcp.tool()
def search_ventures(query: str) -> str:
    """Search across Korean venture companies, glossary terms, and blog posts."""
    from ventureinkorea.api import VentureInKorea

    import json

    with VentureInKorea() as api:
        data = api.search(query)
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
def get_term(slug: str) -> str:
    """Get a Korean venture/startup glossary term by slug."""
    from ventureinkorea.api import VentureInKorea

    import json

    with VentureInKorea() as api:
        data = api.get_term(slug)
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
def get_company(pk: int) -> str:
    """Get a certified venture company detail by ID."""
    from ventureinkorea.api import VentureInKorea

    import json

    with VentureInKorea() as api:
        data = api.get_company(pk)
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
def get_post(slug: str) -> str:
    """Get a blog post about Korean startup ecosystem by slug."""
    from ventureinkorea.api import VentureInKorea

    import json

    with VentureInKorea() as api:
        data = api.get_post(slug)
    return json.dumps(data, ensure_ascii=False, indent=2)


@mcp.tool()
def get_stats() -> str:
    """Get VentureInKorea platform statistics."""
    from ventureinkorea.api import VentureInKorea

    import json

    with VentureInKorea() as api:
        data = api.get_stats()
    return json.dumps(data, ensure_ascii=False, indent=2)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
