"""CLI interface for VentureInKorea API client.

Requires the ``cli`` extra: ``pip install ventureinkorea[cli]``
"""

from __future__ import annotations

import json

import typer
from rich.console import Console
from rich.table import Table

from ventureinkorea.api import VentureInKorea

app = typer.Typer(
    name="ventureinkorea",
    help="VentureInKorea — Korean venture startup API client.",
    no_args_is_help=True,
)
console = Console()


@app.command()
def search(query: str, limit: int = 10) -> None:
    """Search across all venture content."""
    with VentureInKorea() as api:
        data = api.search(query)
        console.print_json(json.dumps(data, ensure_ascii=False, indent=2))


@app.command()
def terms(limit: int = 20) -> None:
    """List glossary terms."""
    with VentureInKorea() as api:
        data = api.list_terms(limit=limit)
        table = Table(title="Venture Glossary Terms")
        table.add_column("Slug", style="cyan")
        table.add_column("Name", style="bold")
        for item in data.get("results", []):
            table.add_row(item.get("slug", ""), item.get("name", ""))
        console.print(table)


@app.command()
def companies(limit: int = 20) -> None:
    """List certified venture companies."""
    with VentureInKorea() as api:
        data = api.list_companies(limit=limit)
        table = Table(title="Venture Companies (벤처인증기업)")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="bold")
        for item in data.get("results", []):
            table.add_row(str(item.get("id", "")), item.get("name", ""))
        console.print(table)


@app.command()
def stats() -> None:
    """Display platform statistics."""
    with VentureInKorea() as api:
        data = api.get_stats()
        console.print_json(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    app()
