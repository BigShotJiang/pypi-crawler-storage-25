"""ventureinkorea — Korean venture startup API client for developers.

Search certified venture companies, glossary terms, and blog posts
from VentureInKorea (ventureinkorea.com).

Usage::

    from ventureinkorea.api import VentureInKorea

    with VentureInKorea() as api:
        results = api.search("AI startup")
        print(results)
"""

__version__ = "0.1.0"
