"""HTTP API client for ventureinkorea.com REST endpoints.

Requires the ``api`` extra: ``pip install ventureinkorea[api]``

Usage::

    from ventureinkorea.api import VentureInKorea

    with VentureInKorea() as api:
        terms = api.list_terms()
        company = api.get_company(1)
        results = api.search("AI")
"""

from __future__ import annotations

from typing import Any

import httpx


class VentureInKorea:
    """API client for the ventureinkorea.com REST API.

    Provides typed access to all ventureinkorea.com endpoints including
    glossary terms, blog posts, venture companies, search, and statistics.

    Args:
        base_url: API base URL. Defaults to ``https://ventureinkorea.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://ventureinkorea.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Glossary Terms ------------------------------------------------------

    def list_terms(self, **params: Any) -> dict[str, Any]:
        """List all glossary terms (벤처/스타트업 용어)."""
        return self._get("/api/v1/terms/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get glossary term detail by slug."""
        return self._get("/api/v1/terms/" + slug + "/")

    # -- Blog Posts ----------------------------------------------------------

    def list_posts(self, **params: Any) -> dict[str, Any]:
        """List all blog posts about Korean startup ecosystem."""
        return self._get("/api/v1/posts/", **params)

    def get_post(self, slug: str) -> dict[str, Any]:
        """Get blog post detail by slug (includes FAQs)."""
        return self._get("/api/v1/posts/" + slug + "/")

    # -- Companies -----------------------------------------------------------

    def list_companies(self, **params: Any) -> dict[str, Any]:
        """List all certified venture companies (벤처인증기업)."""
        return self._get("/api/v1/companies/", **params)

    def get_company(self, pk: int) -> dict[str, Any]:
        """Get venture company detail by primary key."""
        return self._get(f"/api/v1/companies/{pk}/")

    # -- Categories ----------------------------------------------------------

    def list_categories(self, **params: Any) -> dict[str, Any]:
        """List all post categories."""
        return self._get("/api/v1/categories/", **params)

    # -- FAQ -----------------------------------------------------------------

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List aggregated FAQs across all content."""
        return self._get("/api/v1/faq/", **params)

    # -- Statistics ----------------------------------------------------------

    def get_stats(self) -> dict[str, Any]:
        """Get platform-wide statistics (company count, post count, etc.)."""
        return self._get("/api/v1/stats/")

    # -- Search & Autocomplete -----------------------------------------------

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Unified search across all content (companies, terms, posts)."""
        return self._get("/api/v1/search/", q=query, **params)

    def autocomplete(self, query: str, **params: Any) -> dict[str, Any]:
        """Autocomplete suggestions for search queries."""
        return self._get("/api/v1/autocomplete/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> VentureInKorea:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
