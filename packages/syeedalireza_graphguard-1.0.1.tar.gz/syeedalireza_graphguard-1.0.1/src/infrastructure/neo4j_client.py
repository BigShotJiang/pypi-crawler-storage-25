from neo4j import GraphDatabase
import logging

logger = logging.getLogger(__name__)

class Neo4jClient:
    def __init__(self, uri, user, password):
        try:
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
        except Exception as e:
            logger.error(f"Failed to connect to Neo4j: {e}")
            self.driver = None

    def close(self):
        if self.driver:
            self.driver.close()

    def create_transaction_graph(self, user_id: str, device_id: str, ip_address: str, card_hash: str):
        if not self.driver:
            return
            
        query = """
        MERGE (u:User {id: $user_id})
        MERGE (d:Device {id: $device_id})
        MERGE (i:IP {address: $ip_address})
        MERGE (c:Card {hash: $card_hash})
        
        MERGE (u)-[:USED]->(d)
        MERGE (u)-[:CONNECTED_FROM]->(i)
        MERGE (u)-[:PAID_WITH]->(c)
        """
        with self.driver.session() as session:
            session.run(query, user_id=user_id, device_id=device_id, ip_address=ip_address, card_hash=card_hash)

    def find_connected_users(self, user_id: str) -> list:
        if not self.driver:
            return []
            
        # Find other users who share the same device or card (depth 2)
        query = """
        MATCH (u1:User {id: $user_id})-[:USED|PAID_WITH]->(resource)<-[:USED|PAID_WITH]-(u2:User)
        WHERE u1 <> u2
        RETURN DISTINCT u2.id AS connected_user
        """
        with self.driver.session() as session:
            result = session.run(query, user_id=user_id)
            return [record["connected_user"] for record in result]