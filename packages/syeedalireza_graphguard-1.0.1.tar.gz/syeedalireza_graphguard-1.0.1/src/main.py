from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from src.infrastructure.neo4j_client import Neo4jClient
import os

app = FastAPI(
    title="GraphGuard API",
    description="Graph-based Fraud Ring Detection System",
    version="1.0.0"
)

neo4j_client = Neo4jClient(
    uri=os.getenv("NEO4J_URI", "bolt://localhost:7687"),
    user=os.getenv("NEO4J_USER", "neo4j"),
    password=os.getenv("NEO4J_PASSWORD", "password")
)

class TransactionEvent(BaseModel):
    user_id: str
    device_id: str
    ip_address: str
    card_hash: str

@app.on_event("shutdown")
def shutdown_event():
    neo4j_client.close()

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/events", tags=["Ingestion"])
async def ingest_transaction(event: TransactionEvent):
    """
    Ingest a transaction and link the user to the device, IP, and card.
    If multiple users share the same device or card, a graph pattern emerges.
    """
    try:
        neo4j_client.create_transaction_graph(
            event.user_id, 
            event.device_id, 
            event.ip_address, 
            event.card_hash
        )
        return {"status": "success", "message": "Graph updated"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/fraud/rings/{user_id}", tags=["Analysis"])
async def detect_fraud_ring(user_id: str):
    """
    Check if a user is part of a fraud ring by traversing the graph.
    Finds other users connected via shared devices or cards.
    """
    try:
        connected_users = neo4j_client.find_connected_users(user_id)
        is_fraud_ring = len(connected_users) > 2 # Heuristic: >2 users sharing same resources
        
        return {
            "user_id": user_id,
            "is_fraud_ring": is_fraud_ring,
            "connected_users": connected_users,
            "risk_score": len(connected_users) * 10
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))