import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio
from unittest.mock import patch

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/health")
    assert response.status_code == 200

@pytest.mark.asyncio
@patch("src.main.neo4j_client.find_connected_users")
async def test_detect_fraud_ring(mock_find, async_client):
    # Mocking that this user is connected to 3 other users (Fraud Ring)
    mock_find.return_value = ["user2", "user3", "user4"]
    
    response = await async_client.get("/api/v1/fraud/rings/user1")
    assert response.status_code == 200
    data = response.json()
    
    assert data["is_fraud_ring"] is True
    assert len(data["connected_users"]) == 3
    assert data["risk_score"] == 30