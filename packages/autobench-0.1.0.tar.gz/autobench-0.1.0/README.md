silence is golden
