"""User-facing output formatting."""
