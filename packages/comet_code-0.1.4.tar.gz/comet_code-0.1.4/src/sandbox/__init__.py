"""Isolated workspace management."""
