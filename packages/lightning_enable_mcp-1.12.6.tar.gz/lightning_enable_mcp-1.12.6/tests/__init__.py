"""Lightning Enable MCP Tests"""
