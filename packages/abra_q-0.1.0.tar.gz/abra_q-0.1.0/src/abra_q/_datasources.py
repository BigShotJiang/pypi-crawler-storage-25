from __future__ import annotations

from typing import Any

from ._base import APINamespace


class Datasources(APINamespace):
    """Datasource management endpoints."""

    def list(self) -> dict[str, Any]:
        """Get all datasources the current user has access to."""
        return self._get("/datasources/")

    def available_types(self) -> list[dict[str, Any]]:
        """Get available datasource types that can be configured."""
        return self._get("/datasources/available")

    def create(
        self,
        *,
        id: str,
        name: str,
        datasource_type: str,
        description: str,
        connection_config: dict[str, Any],
        schemas: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a new datasource connection.

        Args:
            id: Unique datasource identifier.
            name: Display name.
            datasource_type: One of "postgres", "msql", "bigquery".
            description: Human-readable description.
            connection_config: Connection parameters (varies by type).
            schemas: Optional list of schemas to include.
        """
        body: dict[str, Any] = {
            "id": id,
            "name": name,
            "datasource_type": datasource_type,
            "description": description,
            "connection_config": connection_config,
        }
        if schemas is not None:
            body["schemas"] = schemas
        return self._post("/datasources/", json=body)

    def get(self, datasource_id: str) -> dict[str, Any]:
        """Get detailed info about a specific datasource."""
        return self._get(f"/datasources/{datasource_id}")

    def update(self, datasource_id: str, *, tables: list[dict[str, Any]], table_description: str, table_name: str, embed: bool | None = None) -> dict[str, Any]:
        """Update datasource configuration and descriptions."""
        params = {}
        if embed is not None:
            params["embed"] = str(embed).lower()
        body: dict[str, Any] = {
            "columns": tables,
            "table_description": table_description,
            "table_name": table_name,
        }
        return self._put(f"/datasources/{datasource_id}", json=body, params=params)

    def delete(self, datasource_id: str) -> dict[str, Any]:
        """Delete a datasource and all associated data."""
        return self._delete(f"/datasources/{datasource_id}")

    def update_description(self, datasource_id: str, description: str) -> dict[str, Any]:
        """Update only the datasource description."""
        return self._patch(f"/datasources/{datasource_id}/description", json={"description": description})

    def deactivate(self, datasource_id: str) -> dict[str, Any]:
        """Deactivate a datasource without deleting it."""
        return self._post(f"/datasources/{datasource_id}/deactivate")

    def test_connection(
        self,
        *,
        id: str,
        name: str,
        datasource_type: str,
        description: str,
        connection_config: dict[str, Any],
        schemas: list[str] | None = None,
    ) -> dict[str, Any]:
        """Test a datasource connection before creating it."""
        body: dict[str, Any] = {
            "id": id,
            "name": name,
            "datasource_type": datasource_type,
            "description": description,
            "connection_config": connection_config,
        }
        if schemas is not None:
            body["schemas"] = schemas
        return self._post("/datasources/test-connection", json=body)

    # --- Prompt / Query -------------------------------------------------

    def prompt(self, datasource_id: str, prompt: str) -> dict[str, Any]:
        """Generate a SQL query from a natural language prompt."""
        return self._post(f"/datasources/{datasource_id}/prompt", json={"prompt": prompt})

    def get_prompts(self, datasource_id: str) -> dict[str, Any]:
        """Get all prompts the user has asked for this datasource."""
        return self._get(f"/datasources/{datasource_id}/prompt")

    def query(self, datasource_id: str, sql: str) -> dict[str, Any]:
        """Execute a SQL query against a datasource."""
        return self._post(f"/datasources/{datasource_id}/query", json={"query": sql})

    # --- Enhance --------------------------------------------------------

    def enhance(self, datasource_id: str, *, table_ids: list[str] | None = None) -> dict[str, Any]:
        """Use AI to enhance table and column descriptions."""
        body = {}
        if table_ids is not None:
            body["table_ids"] = table_ids
        return self._post(f"/datasources/{datasource_id}/enhance", json=body)

    def get_enhancement(self, datasource_id: str, enhancement_id: str) -> dict[str, Any]:
        """Get an enhancement comparison."""
        return self._get(f"/datasources/{datasource_id}/enhancement/{enhancement_id}")

    def list_enhancements(self, datasource_id: str) -> dict[str, Any]:
        """Get enhancement history."""
        return self._get(f"/datasources/{datasource_id}/enhancements")

    # --- Reacquaint -----------------------------------------------------

    def reacquaint(self, datasource_id: str, *, schemas: dict[str, Any] | None = None) -> dict[str, Any]:
        """Resync datasource schema to detect changes."""
        return self._post(f"/datasources/{datasource_id}/reacquaint", json=schemas or {})

    # --- Sample queries -------------------------------------------------

    def sample_queries(self, datasource_id: str) -> dict[str, Any]:
        """Get sample queries for a datasource."""
        return self._get(f"/datasources/{datasource_id}/sample-queries")

    def generate_sample_queries(self, datasource_id: str) -> dict[str, Any]:
        """Generate sample queries using AI."""
        return self._post(f"/datasources/{datasource_id}/sample-queries")

    # --- Tables ---------------------------------------------------------

    def delete_table(self, datasource_id: str, table_id: str) -> dict[str, Any]:
        """Remove a table from the datasource metadata."""
        return self._delete(f"/datasources/{datasource_id}/tables/{table_id}")

    # --- Additional info ------------------------------------------------

    def get_additional_info(self, datasource_id: str) -> dict[str, Any]:
        """Get additional contextual information for a datasource."""
        return self._get(f"/datasources/{datasource_id}/additional-info")

    def add_additional_info(self, datasource_id: str, *, additional_info: str, additional_info_type: str | None = None, id: str | None = None) -> dict[str, Any]:
        """Add additional contextual info (used for LLM query generation)."""
        body: dict[str, Any] = {"additional_info": additional_info}
        if additional_info_type is not None:
            body["additional_info_type"] = additional_info_type
        if id is not None:
            body["id"] = id
        return self._post(f"/datasources/{datasource_id}/additional-info", json=body)

    def delete_additional_info(self, datasource_id: str, additional_info_id: str) -> dict[str, Any]:
        """Remove additional contextual info from a datasource."""
        return self._delete(f"/datasources/{datasource_id}/additional-info/{additional_info_id}")
