from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .client import AbraQ


class APINamespace:
    """Base class for API namespaces that holds a reference to the client."""

    def __init__(self, client: AbraQ) -> None:
        self._client = client

    # Convenience shortcuts
    def _get(self, path: str, **kwargs: Any) -> Any:
        return self._client._request("GET", path, **kwargs)

    def _post(self, path: str, **kwargs: Any) -> Any:
        return self._client._request("POST", path, **kwargs)

    def _put(self, path: str, **kwargs: Any) -> Any:
        return self._client._request("PUT", path, **kwargs)

    def _patch(self, path: str, **kwargs: Any) -> Any:
        return self._client._request("PATCH", path, **kwargs)

    def _delete(self, path: str, **kwargs: Any) -> Any:
        return self._client._request("DELETE", path, **kwargs)
