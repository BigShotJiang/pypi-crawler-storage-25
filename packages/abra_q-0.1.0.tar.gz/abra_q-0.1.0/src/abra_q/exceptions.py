from __future__ import annotations

import requests


class AbraQError(Exception):
    """Base exception for the Abra-Q SDK."""

    def __init__(self, message: str, status_code: int | None = None, response: requests.Response | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class AuthenticationError(AbraQError):
    """Raised on 401 — not authenticated."""


class PermissionDeniedError(AbraQError):
    """Raised on 403 — insufficient permissions."""


class NotFoundError(AbraQError):
    """Raised on 404 — resource not found."""


class ConflictError(AbraQError):
    """Raised on 409 — resource already exists."""


class BadRequestError(AbraQError):
    """Raised on 400 — invalid request."""


class ServerError(AbraQError):
    """Raised on 5xx — server-side error."""


_STATUS_MAP: dict[int, type[AbraQError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
}


def raise_for_status(response: requests.Response) -> None:
    """Raise a typed AbraQError if the response indicates failure."""
    if response.ok:
        return

    try:
        body = response.json()
        message = body.get("error", body.get("message", response.text))
    except Exception:
        message = response.text or response.reason

    code = response.status_code
    exc_cls = _STATUS_MAP.get(code, ServerError if code >= 500 else AbraQError)
    raise exc_cls(message, status_code=code, response=response)
