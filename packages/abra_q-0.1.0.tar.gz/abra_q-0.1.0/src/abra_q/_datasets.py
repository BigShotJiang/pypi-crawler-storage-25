from __future__ import annotations

from pathlib import Path
from typing import Any

from ._base import APINamespace


class Datasets(APINamespace):
    """Dataset parsing and import endpoints."""

    def parse(self, file_path: str | Path) -> dict[str, Any]:
        """Parse a CSV or Excel file and return its structure.

        Args:
            file_path: Path to a local CSV or Excel file.
        """
        path = Path(file_path)
        with open(path, "rb") as f:
            return self._client._request(
                "POST",
                "/datasources/datasets/parse",
                files={"file": (path.name, f)},
            )

    def import_dataset(self, *, sheets: list[dict[str, Any]]) -> dict[str, Any]:
        """Import a parsed dataset as a new datasource.

        Args:
            sheets: List of sheet import configs, each with keys:
                sheet_name, table_name, table_description, columns, rows.
        """
        return self._post("/datasources/datasets/import", json={"sheets": sheets})
