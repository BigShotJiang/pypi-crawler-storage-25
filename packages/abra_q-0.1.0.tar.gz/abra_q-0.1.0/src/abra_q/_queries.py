from __future__ import annotations

from typing import Any

from ._base import APINamespace


class Queries(APINamespace):
    """Saved query and agent-API query endpoints."""

    def get(self, query_id: str, *, api_key: str | None = None) -> dict[str, Any]:
        """Get a saved query by ID.

        Args:
            query_id: The query ID.
            api_key: Optional agent API key (used instead of cookie auth).
        """
        headers = {}
        if api_key is not None:
            headers["Authorization"] = api_key
        return self._get(f"/queries/{query_id}", headers=headers)

    def execute(self, query_id: str, *, api_key: str | None = None) -> dict[str, Any]:
        """Execute a saved query by ID.

        Args:
            query_id: The query ID.
            api_key: Optional agent API key (used instead of cookie auth).
        """
        headers = {}
        if api_key is not None:
            headers["Authorization"] = api_key
        return self._post(f"/queries/execute/{query_id}", headers=headers)


class QueryBuilder(APINamespace):
    """Interactive query-builder session endpoints."""

    def intelligent_prompt(self, prompt: str, datasource_ids: list[str], *, chat_id: str | None = None) -> dict[str, Any]:
        """Send a natural language prompt to the intelligent query builder.

        Args:
            prompt: Natural language question.
            datasource_ids: Datasources to query across.
            chat_id: Optional chat/session ID for context continuity.
        """
        params = {}
        if chat_id is not None:
            params["chat_id"] = chat_id
        return self._post(
            "/querybuilder/intelligent-prompt",
            json={"prompt": prompt, "datasource_ids": datasource_ids},
            params=params,
        )

    def get_query(self, query_id: str) -> dict[str, Any]:
        """Get a query-builder query by ID."""
        return self._get(f"/querybuilder/query/{query_id}")

    # --- Sessions -------------------------------------------------------

    def list_sessions(self) -> dict[str, Any]:
        """List all query-builder sessions."""
        return self._get("/querybuilder/sessions")

    def create_session(self) -> dict[str, Any]:
        """Create a new query-builder session."""
        return self._post("/querybuilder/sessions")

    def get_session(self, session_id: str) -> dict[str, Any]:
        """Get a query-builder session by ID."""
        return self._get(f"/querybuilder/sessions/{session_id}")

    def delete_session(self, session_id: str) -> dict[str, Any]:
        """Delete a query-builder session."""
        return self._delete(f"/querybuilder/sessions/{session_id}")

    def update_session_title(self, session_id: str, title: str) -> dict[str, Any]:
        """Update a session's title."""
        return self._put(f"/querybuilder/sessions/{session_id}/title", json={"title": title})
