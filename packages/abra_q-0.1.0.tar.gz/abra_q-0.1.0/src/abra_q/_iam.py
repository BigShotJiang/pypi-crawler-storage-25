from __future__ import annotations

from typing import Any

from ._base import APINamespace


class IAM(APINamespace):
    """IAM management — policies, roles, groups, agents, and user policies."""

    def actions(self) -> dict[str, Any]:
        """Get all available IAM actions and resource patterns."""
        return self._get("/iam/actions")

    # --- Policies -------------------------------------------------------

    def list_policies(self, *, limit: int | None = None, offset: int | None = None, search: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if search is not None:
            params["search"] = search
        return self._get("/iam/policies", params=params)

    def create_policy(self, *, id: str, name: str, statement: list[dict[str, Any]], description: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"id": id, "name": name, "statement": statement}
        if description is not None:
            body["description"] = description
        return self._post("/iam/policies", json=body)

    def get_policy(self, policy_id: str) -> dict[str, Any]:
        return self._get(f"/iam/policies/{policy_id}")

    def update_policy(self, policy_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a policy. Pass name, description, and/or statement."""
        return self._put(f"/iam/policies/{policy_id}", json=kwargs)

    def delete_policy(self, policy_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/policies/{policy_id}")

    def simulate_policy(self, *, principal_id: str, principal_type: str, action: str, resource: str, policy_document: dict[str, Any] | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {
            "principal_id": principal_id,
            "principal_type": principal_type,
            "action": action,
            "resource": resource,
        }
        if policy_document is not None:
            body["policy_document"] = policy_document
        return self._post("/iam/policies/simulate", json=body)

    # --- Roles ----------------------------------------------------------

    def list_roles(self) -> dict[str, Any]:
        return self._get("/iam/roles")

    def create_role(self, *, id: str, name: str, description: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"id": id, "name": name}
        if description is not None:
            body["description"] = description
        return self._post("/iam/roles", json=body)

    def get_role(self, role_id: str) -> dict[str, Any]:
        return self._get(f"/iam/roles/{role_id}")

    def update_role(self, role_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._put(f"/iam/roles/{role_id}", json=kwargs)

    def delete_role(self, role_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/roles/{role_id}")

    def list_role_policies(self, role_id: str) -> dict[str, Any]:
        return self._get(f"/iam/roles/{role_id}/policies")

    def attach_role_policy(self, role_id: str, policy_id: str) -> dict[str, Any]:
        return self._post(f"/iam/roles/{role_id}/policies", json={"policy_id": policy_id})

    def detach_role_policy(self, role_id: str, policy_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/roles/{role_id}/policies/{policy_id}")

    # --- Groups ---------------------------------------------------------

    def list_groups(self) -> dict[str, Any]:
        return self._get("/iam/groups")

    def create_group(self, *, id: str, name: str, description: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"id": id, "name": name}
        if description is not None:
            body["description"] = description
        return self._post("/iam/groups", json=body)

    def get_group(self, group_id: str) -> dict[str, Any]:
        return self._get(f"/iam/groups/{group_id}")

    def update_group(self, group_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._put(f"/iam/groups/{group_id}", json=kwargs)

    def delete_group(self, group_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/groups/{group_id}")

    def add_user_to_group(self, group_id: str, user_id: str) -> dict[str, Any]:
        return self._post(f"/iam/groups/{group_id}/users", json={"user_id": user_id})

    def remove_user_from_group(self, group_id: str, user_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/groups/{group_id}/users/{user_id}")

    def list_group_policies(self, group_id: str) -> dict[str, Any]:
        return self._get(f"/iam/groups/{group_id}/policies")

    def attach_group_policy(self, group_id: str, policy_id: str) -> dict[str, Any]:
        return self._post(f"/iam/groups/{group_id}/policies", json={"policy_id": policy_id})

    def detach_group_policy(self, group_id: str, policy_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/groups/{group_id}/policies/{policy_id}")

    # --- Agents ---------------------------------------------------------

    def list_agents(self) -> dict[str, Any]:
        return self._get("/iam/agents")

    def create_agent(self, *, id: str, description: str) -> dict[str, Any]:
        return self._post("/iam/agents", json={"id": id, "description": description})

    def get_agent(self, agent_id: str) -> dict[str, Any]:
        return self._get(f"/iam/agents/{agent_id}")

    def update_agent(self, agent_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update agent. Pass description and/or active."""
        return self._put(f"/iam/agents/{agent_id}", json=kwargs)

    def delete_agent(self, agent_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/agents/{agent_id}")

    def regenerate_agent_key(self, agent_id: str) -> dict[str, Any]:
        return self._post(f"/iam/agents/{agent_id}/regenerate-key")

    def assign_agent_role(self, agent_id: str, role_id: str) -> dict[str, Any]:
        return self._post(f"/iam/agents/{agent_id}/role", json={"role_id": role_id})

    def unassign_agent_role(self, agent_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/agents/{agent_id}/role")

    # --- User inline policies -------------------------------------------

    def list_user_policies(self, user_id: str) -> dict[str, Any]:
        return self._get(f"/iam/users/{user_id}/policies")

    def attach_user_policy(self, user_id: str, *, name: str, policy_id: str, statement: list[dict[str, Any]], description: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "policy_id": policy_id, "statement": statement}
        if description is not None:
            body["description"] = description
        return self._post(f"/iam/users/{user_id}/policies", json=body)

    def detach_user_policy(self, user_id: str, policy_id: str) -> dict[str, Any]:
        return self._delete(f"/iam/users/{user_id}/policies/{policy_id}")
