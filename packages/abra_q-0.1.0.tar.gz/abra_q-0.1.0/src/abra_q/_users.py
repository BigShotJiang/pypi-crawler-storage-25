from __future__ import annotations

from typing import Any

from ._base import APINamespace


class Users(APINamespace):
    """User management and authentication endpoints."""

    # --- Authentication -------------------------------------------------

    def login(self, email: str, password: str) -> dict[str, Any]:
        """Authenticate and start a session (cookie-based)."""
        return self._post("/users/login", json={"email": email, "password": password})

    def logout(self) -> dict[str, Any]:
        """End the current session."""
        return self._post("/users/logout")

    # --- Current user ---------------------------------------------------

    def me(self) -> dict[str, Any]:
        """Get the currently authenticated user's profile."""
        return self._get("/users/me")

    def change_password(self, current_password: str, new_password: str) -> dict[str, Any]:
        """Change the current user's password."""
        return self._post(
            "/users/change-password",
            json={"currentPassword": current_password, "newPassword": new_password},
        )

    def update_story_default(self, story_default: str) -> dict[str, Any]:
        """Update the current user's story default."""
        return self._put("/users/me/story-default", json={"storyDefault": story_default})

    # --- User management (admin) ----------------------------------------

    def list(self, *, search: str | None = None) -> dict[str, Any]:
        """List all users. Optionally filter by search term."""
        params = {}
        if search is not None:
            params["search"] = search
        return self._get("/users/", params=params)

    def create(self, email: str) -> dict[str, Any]:
        """Create a new user."""
        return self._post("/users/create", json={"email": email})

    def delete(self, user_id: str) -> dict[str, Any]:
        """Delete a user by ID."""
        return self._delete(f"/users/{user_id}")

    def reset_password(self, email: str) -> dict[str, Any]:
        """Reset a user's password."""
        return self._post("/users/reset-password", json={"email": email})
