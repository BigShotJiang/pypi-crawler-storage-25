from __future__ import annotations

from typing import Any

from ._base import APINamespace


class Preferences(APINamespace):
    """System preferences endpoints."""

    def get(self) -> dict[str, Any]:
        """Get all preferences."""
        return self._get("/preferences/")

    def set_llm_model(self, model: str, *, preferred: bool = False) -> dict[str, Any]:
        """Set the LLM model preference."""
        return self._post("/preferences/llm-model", json={"model": model, "preffered": preferred})

    def set_embedding_model(self, model: str, *, dimensions: int | None = None, preferred: bool = False) -> dict[str, Any]:
        """Set the embedding model preference."""
        body: dict[str, Any] = {"model": model, "preffered": preferred}
        if dimensions is not None:
            body["dimensions"] = dimensions
        return self._post("/preferences/embedding-model", json=body)

    def set_vector_threshold(self, label: str, threshold: float) -> dict[str, Any]:
        """Set a vector similarity threshold."""
        return self._post("/preferences/vector-threshold", json={"label": label, "threshold": threshold})

    def delete_vector_threshold(self, label: str) -> dict[str, Any]:
        """Delete a vector similarity threshold."""
        return self._delete(f"/preferences/vector-threshold/{label}")
