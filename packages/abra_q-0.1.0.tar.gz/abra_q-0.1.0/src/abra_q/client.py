from __future__ import annotations

from typing import Any

import requests

from .exceptions import raise_for_status


class AbraQ:
    """Python client for the Abra-Q API.

    Usage::

        from abra_q import AbraQ

        client = AbraQ("http://localhost:8080")
        client.login("user@example.com", "password")

        # List datasources
        ds = client.datasources.list()

        # Ask a natural-language question
        result = client.datasources.prompt("ds-id", "Show me top 10 customers by revenue")
    """

    def __init__(self, base_url: str, *, timeout: int = 30) -> None:
        """Initialize the Abra-Q client.

        Args:
            base_url: The base URL of the Abra-Q API (e.g. ``http://localhost:8080``).
            timeout: Default request timeout in seconds.
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()

        # Lazy-loaded namespaces
        self._datasources: Datasources | None = None
        self._datasets: Datasets | None = None
        self._queries: Queries | None = None
        self._query_builder: QueryBuilder | None = None
        self._iam: IAM | None = None
        self._users: Users | None = None
        self._preferences: Preferences | None = None

    # --- Convenience login at top level --------------------------------

    def login(self, email: str, password: str) -> dict[str, Any]:
        """Authenticate and start a session. Shortcut for ``client.users.login(...)``."""
        return self.users.login(email, password)

    def logout(self) -> dict[str, Any]:
        """End the current session."""
        return self.users.logout()

    # --- API namespaces (lazy properties) --------------------------------

    @property
    def datasources(self) -> Datasources:
        if self._datasources is None:
            from ._datasources import Datasources
            self._datasources = Datasources(self)
        return self._datasources

    @property
    def datasets(self) -> Datasets:
        if self._datasets is None:
            from ._datasets import Datasets
            self._datasets = Datasets(self)
        return self._datasets

    @property
    def queries(self) -> Queries:
        if self._queries is None:
            from ._queries import Queries
            self._queries = Queries(self)
        return self._queries

    @property
    def query_builder(self) -> QueryBuilder:
        if self._query_builder is None:
            from ._queries import QueryBuilder
            self._query_builder = QueryBuilder(self)
        return self._query_builder

    @property
    def iam(self) -> IAM:
        if self._iam is None:
            from ._iam import IAM
            self._iam = IAM(self)
        return self._iam

    @property
    def users(self) -> Users:
        if self._users is None:
            from ._users import Users
            self._users = Users(self)
        return self._users

    @property
    def preferences(self) -> Preferences:
        if self._preferences is None:
            from ._preferences import Preferences
            self._preferences = Preferences(self)
        return self._preferences

    # --- Internal HTTP ---------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Send an HTTP request through the session and return parsed JSON."""
        url = f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)

        # Merge any extra headers without replacing session headers
        if "headers" in kwargs:
            merged = dict(self._session.headers)
            merged.update(kwargs.pop("headers"))
            kwargs["headers"] = merged

        resp = self._session.request(method, url, **kwargs)
        raise_for_status(resp)

        if resp.status_code == 204 or not resp.content:
            return {}
        return resp.json()

    def __repr__(self) -> str:
        return f"AbraQ(base_url={self.base_url!r})"


# Type-checking imports for lazy properties
from ._datasources import Datasources as Datasources  # noqa: E402, F811
from ._datasets import Datasets as Datasets  # noqa: E402, F811
from ._iam import IAM as IAM  # noqa: E402, F811
from ._preferences import Preferences as Preferences  # noqa: E402, F811
from ._queries import Queries as Queries, QueryBuilder as QueryBuilder  # noqa: E402, F811
from ._users import Users as Users  # noqa: E402, F811
