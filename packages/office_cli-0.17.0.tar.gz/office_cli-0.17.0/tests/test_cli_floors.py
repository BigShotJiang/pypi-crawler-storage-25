"""End-to-end tests for ``office floors`` commands."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from office_cli.cli import main


def test_floors_list_text(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["floors", "list", "--data-dir", str(data_dir)]) == 0
    out = capsys.readouterr().out
    assert "tlv-floor-5" in out


def test_floors_list_json(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["floors", "list", "--json", "--data-dir", str(data_dir)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert len(payload["floors"]) == 1
    floor = payload["floors"][0]
    assert floor["floor"] == "tlv-floor-5"
    assert floor["clusters"] == {"T": 6, "Z": 2}


def test_floors_validate_good(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    svg = data_dir / "floors" / "tlv-floor-5.svg"
    rc = main(["floors", "validate", str(svg), "--json", "--data-dir", str(data_dir)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["results"][0]["ok"] is True


def test_floors_validate_bad(
    data_dir: Path, fixtures_root: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    bad = data_dir / "floors" / "tlv-floor-5.svg"
    bad.write_text(
        (fixtures_root / "floors" / "tlv-floor-5-bad.svg").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    rc = main(["floors", "validate", str(bad), "--json", "--data-dir", str(data_dir)])
    assert rc == 1
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["ok"] is False
    assert result["errors"]


def test_floors_validate_relative_path_from_other_cwd(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Relative SVG path must resolve against --data-dir, not cwd. Qodo #6."""
    other = data_dir.parent / "elsewhere"
    other.mkdir()
    monkeypatch.chdir(other)
    rc = main(
        [
            "floors",
            "validate",
            "floors/tlv-floor-5.svg",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["results"][0]["ok"] is True


def test_floors_doctor_prune_dry_run_reports(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Polluted SVG with --prune --dry-run → reports drops without writing."""
    svg = data_dir / "floors" / "tlv-floor-5.svg"
    polluted = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">'
        '<rect id="garbled-1" class="seat" x="100" y="100" width="40" height="40"/>'
        '<rect id="garbled-2" class="seat" x="200" y="100" width="40" height="40"/>'
        '<rect id="off-page" class="seat" x="100" y="-500" width="40" height="40"/>'
        '<polygon id="r1" class="room" points="1400,300 1700,300 1700,500 1400,500"/>'
        '<polygon id="r2" class="room" points="1401,301 1701,301 1701,501 1401,501"/>'
        "</svg>\n"
    )
    before = polluted
    svg.write_text(polluted, encoding="utf-8")

    rc = main(
        [
            "floors",
            "doctor",
            str(svg),
            "--prune",
            "--dry-run",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["dry_run"] is True
    assert result["seats_before"] == 3
    assert result["seats_after"] == 2
    assert result["rooms_before"] == 2
    assert result["rooms_after"] == 1
    # No write happened.
    assert svg.read_text(encoding="utf-8") == before


def test_floors_doctor_default_keep_all_autogrows_yaml(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """The new default: keep all 21 seats, fix ids, mutate offices.yaml.

    This is the headline e2e for PR-E. The fixture has T:6 + Z:2; after
    doctor on a polluted 21-seat SVG, offices.yaml should show T:21.
    """
    svg = data_dir / "floors" / "tlv-floor-5.svg"
    # 21 garbled seats + 14 garbled rooms (mirrors test_floors_doctor.py's
    # _polluted_svg fixture).
    on_page_seats = [
        ("5-T-06-7-2", 92.99, 73.25),
        ("5-T-06-7-0", 145.04, 75.10),
        ("5-T-06", 41.80, 102.08),
        ("5-T-06-7", 93.05, 101.54),
        ("5-T-06-7-4", 143.73, 102.45),
    ]
    seat_lines = [
        f'<rect id="{sid}" class="seat" x="{x}" y="{y}" width="51" height="25"/>'
        for sid, x, y in on_page_seats
    ]
    seat_lines += [
        f'<rect id="5-T-06-extra-{i}" class="seat" '
        f'x="{50 + (i * 3 % 100)}" y="{-300 - i * 8}" width="51" height="25"/>'
        for i in range(16)
    ]
    room_lines = []
    for i in range(14):
        offset = i * 0.5
        rid = "5.18" if i == 0 else f"5.18-{'-'.join(str(d) for d in range(1, i + 1))}"
        pts = (
            f"{1400 + offset},{300 + offset} {1700 + offset},{300 + offset} "
            f"{1700 + offset},{500 + offset} {1400 + offset},{500 + offset}"
        )
        room_lines.append(f'<polygon id="{rid}" class="room" points="{pts}"/>')
    polluted = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">\n'
        + "\n".join(seat_lines)
        + "\n"
        + "\n".join(room_lines)
        + "\n"
        + "</svg>\n"
    )
    svg.write_text(polluted, encoding="utf-8")

    rc = main(
        [
            "floors",
            "doctor",
            str(svg),
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["seats_before"] == 21
    assert result["seats_after"] == 21
    assert result["new_clusters"]["T"] == 21
    # offices.yaml mutated.
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    assert "T: { capacity: 21" in yaml_text


def test_floors_doctor_writes_and_validate_passes(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Doctor writes the cleaned SVG; subsequent validate is clean."""
    svg = data_dir / "floors" / "tlv-floor-5.svg"
    polluted = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">'
        '<rect id="g1" class="seat" x="100" y="100" width="40" height="40"/>'
        '<rect id="g2" class="seat" x="200" y="100" width="40" height="40"/>'
        '<rect id="g3" class="seat" x="300" y="100" width="40" height="40"/>'
        '<rect id="g4" class="seat" x="400" y="100" width="40" height="40"/>'
        '<rect id="g5" class="seat" x="500" y="100" width="40" height="40"/>'
        '<rect id="g6" class="seat" x="600" y="100" width="40" height="40"/>'
        '<rect id="g7" class="seat" x="700" y="100" width="40" height="40"/>'
        '<rect id="g8" class="seat" x="800" y="100" width="40" height="40"/>'
        '<polygon id="r1" class="room" points="1400,300 1700,300 1700,500 1400,500"/>'
        "</svg>\n"
    )
    svg.write_text(polluted, encoding="utf-8")

    rc = main(["floors", "doctor", str(svg), "--data-dir", str(data_dir)])
    assert rc == 0
    capsys.readouterr()  # drain doctor output

    rc = main(["floors", "validate", str(svg), "--json", "--data-dir", str(data_dir)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["ok"] is True
    assert result["errors"] == []


def test_floors_validate_by_id(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    """Issue #51: passing a floor id (no path) resolves against
    offices.yaml, not as a relative path."""
    rc = main(["floors", "validate", "tlv-floor-5", "--json", "--data-dir", str(data_dir)])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["floor"] == "tlv-floor-5"
    assert result["ok"] is True


def test_floors_doctor_by_id(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    """`office floors doctor tlv-floor-5 --dry-run` works the same as
    the path form."""
    rc = main(
        [
            "floors",
            "doctor",
            "tlv-floor-5",
            "--dry-run",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    result = payload["results"][0]
    assert result["floor"] == "tlv-floor-5"
    assert result["dry_run"] is True


def test_floors_validate_path_form_still_works(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Path-form invocations with the .svg suffix don't accidentally
    match a floor id (defensive against future ids that look like paths)."""
    rc = main(
        [
            "floors",
            "validate",
            "floors/tlv-floor-5.svg",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["results"][0]["ok"] is True


def test_floors_validate_ambiguous_id_raises(
    data_dir: Path, tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Floor id uniqueness is enforced within an office, not globally.
    If two offices declare the same id, the resolver must refuse to pick
    arbitrarily — especially important for `doctor`, which mutates in
    place. Qodo PR-#52 review."""
    # Stage a second office in offices.yaml that re-uses `tlv-floor-5`.
    yaml_path = data_dir / "data" / "offices.yaml"
    appended = yaml_path.read_text(encoding="utf-8") + (
        "\n  - id: dup\n"
        "    name: Duplicate Office\n"
        "    floors:\n"
        "      - id: tlv-floor-5\n"
        "        svg: floors/dup.svg\n"
        "        clusters:\n"
        "          T: { capacity: 1, type: open-space }\n"
    )
    yaml_path.write_text(appended, encoding="utf-8")
    # The dup SVG just needs to exist; content doesn't matter for resolver test.
    (data_dir / "floors" / "dup.svg").write_text(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080"/>\n',
        encoding="utf-8",
    )

    rc = main(["floors", "validate", "tlv-floor-5", "--json", "--data-dir", str(data_dir)])
    assert rc != 0
    err = capsys.readouterr().err
    assert "ambiguous" in err
    assert "tlv-floor-5" in err


def test_floors_validate_unknown_id_falls_back_to_path(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Unknown id falls through to path resolution; the resulting error
    is the existing 'not declared in offices.yaml' message — unchanged."""
    rc = main(
        [
            "floors",
            "validate",
            "no-such-floor",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "not declared in offices.yaml" in err


def test_floors_validate_requires_target(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = main(["floors", "validate", "--data-dir", str(data_dir)])
    assert rc == 1
    err = capsys.readouterr().err
    assert "pass an SVG path" in err or "--all" in err


def test_floors_refresh_when_cache_absent(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Issue #54: refresh is idempotent — succeeds even if the cache
    was never created. Operators run it as a precaution."""
    cache = tmp_path / "office-cli" / "drive"
    monkeypatch.setenv("OFFICE_DRIVE_CACHE_DIR", str(cache))
    rc = main(["floors", "refresh", "--json"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["removed"] is False
    assert payload["cache_dir"] == str(cache)


def test_floors_refresh_removes_existing_cache(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    cache = tmp_path / "office-cli" / "drive"
    (cache / "data").mkdir(parents=True)
    (cache / "data" / "offices.yaml").write_text("offices: []\n", encoding="utf-8")
    monkeypatch.setenv("OFFICE_DRIVE_CACHE_DIR", str(cache))

    rc = main(["floors", "refresh", "--json"])
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["removed"] is True
    assert not cache.exists()


def test_floors_refresh_refuses_unsafe_path(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #55 review: a mis-set OFFICE_DRIVE_CACHE_DIR (e.g. `/`
    or `$HOME`) must not be silently rmtree'd. The verb requires
    'office-cli' as a path component before deleting anything."""
    danger = tmp_path / "not-our-cache"
    danger.mkdir()
    (danger / "important.txt").write_text("don't lose me", encoding="utf-8")
    monkeypatch.setenv("OFFICE_DRIVE_CACHE_DIR", str(danger))

    rc = main(["floors", "refresh"])
    assert rc != 0
    err = capsys.readouterr().err
    assert "office-cli" in err
    assert "refusing" in err.lower()
    # Untouched.
    assert (danger / "important.txt").is_file()


def test_floors_refresh_surfaces_failure(
    tmp_path: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #55 review: rmtree errors must not be silently swallowed
    — operators kept serving stale Drive data on failure. Simulate by
    monkeypatching shutil.rmtree to raise."""
    cache = tmp_path / "office-cli" / "drive"
    cache.mkdir(parents=True)
    (cache / "blob").write_text("x", encoding="utf-8")
    monkeypatch.setenv("OFFICE_DRIVE_CACHE_DIR", str(cache))

    def boom(path):
        raise OSError("simulated permission error")

    from office_cli.cli._commands import floors as floors_mod

    monkeypatch.setattr(floors_mod.shutil, "rmtree", boom)
    rc = main(["floors", "refresh"])
    assert rc != 0
    err = capsys.readouterr().err
    assert "failed to remove" in err.lower()


def test_floors_validate_suggests_doctor_on_ctrld_cascade(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Issue #54: when ≥3 seat-id-format errors share a prefix, the
    text output includes a hint pointing at `office floors doctor`.
    The cascade pattern is the operator's most common reason for
    invalid seat ids."""
    polluted = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">\n'
        # Five Ctrl+D-cascade ids — all share the `5-T-` prefix but
        # fail the seat-id-format regex.
        '<rect id="5-T-06-7-2" class="seat" x="100" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-4" class="seat" x="160" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-0" class="seat" x="220" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-1" class="seat" x="280" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-3" class="seat" x="340" y="100" width="51" height="25"/>\n'
        "</svg>\n"
    )
    svg_path = data_dir / "floors" / "tlv-floor-5.svg"
    svg_path.write_text(polluted, encoding="utf-8")

    rc = main(["floors", "validate", "tlv-floor-5", "--data-dir", str(data_dir)])
    assert rc == 1
    err = capsys.readouterr().err
    assert "office floors doctor tlv-floor-5" in err
    assert "5-T-" in err


def test_floors_validate_no_doctor_hint_on_clean_file(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """Clean files must not get a doctor hint — would be noise."""
    rc = main(["floors", "validate", "tlv-floor-5", "--data-dir", str(data_dir)])
    assert rc == 0
    err = capsys.readouterr().err
    assert "office floors doctor" not in err


def test_floors_validate_doctor_hint_in_json(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """JSON output exposes the same hint via `doctor_hint` so agents
    can branch on it programmatically."""
    polluted = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">\n'
        '<rect id="5-T-06-7-2" class="seat" x="100" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-4" class="seat" x="160" y="100" width="51" height="25"/>\n'
        '<rect id="5-T-06-7-0" class="seat" x="220" y="100" width="51" height="25"/>\n'
        "</svg>\n"
    )
    svg_path = data_dir / "floors" / "tlv-floor-5.svg"
    svg_path.write_text(polluted, encoding="utf-8")

    rc = main(["floors", "validate", "tlv-floor-5", "--json", "--data-dir", str(data_dir)])
    assert rc == 1
    payload = json.loads(capsys.readouterr().out)
    hint = payload["results"][0]["doctor_hint"]
    assert "office floors doctor tlv-floor-5" in hint


def test_floors_scaffold_single_mode(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Single-floor scaffold writes to floors/<id>.svg with embedded PNG
    + one example seat + one example room."""
    from office_cli.floors import _scaffold as scaffold_mod

    fake_png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: fake_png)

    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    out = data_dir / "floors" / "tlv-floor-5.svg"
    rc = main(
        [
            "floors",
            "scaffold",
            "tlv-floor-5",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--force",  # fixture already has tlv-floor-5.svg
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    item = payload["results"][0]
    assert item["floor"] == "tlv-floor-5"
    assert item["page"] == 1
    assert item["bytes"] > 0
    assert out.is_file()
    body = out.read_text(encoding="utf-8")
    assert 'viewBox="0 0 1920 1080"' in body
    assert "5-T-01" in body


def test_floors_scaffold_refuses_overwrite_without_force(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    rc = main(
        [
            "floors",
            "scaffold",
            "tlv-floor-5",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "refusing to overwrite" in err


def test_floors_scaffold_unknown_floor_id(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    rc = main(
        [
            "floors",
            "scaffold",
            "no-such-floor",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "no-such-floor" in err
    assert "not declared" in err


def test_floors_scaffold_manifest_mode(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Manifest mode: one PDF, multiple {id, page} entries."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    manifest = data_dir / "boot.yaml"
    manifest.write_text(
        f"pdf: {pdf}\nfloors:\n  - {{ id: tlv-floor-5, page: 1 }}\n",
        encoding="utf-8",
    )
    rc = main(
        [
            "floors",
            "scaffold",
            "--manifest",
            str(manifest),
            "--force",
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert len(payload["results"]) == 1
    assert payload["results"][0]["floor"] == "tlv-floor-5"


def test_floors_scaffold_manifest_missing_pdf_field(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    manifest = data_dir / "boot.yaml"
    manifest.write_text("floors:\n  - { id: tlv-floor-5, page: 1 }\n", encoding="utf-8")
    rc = main(
        [
            "floors",
            "scaffold",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "missing the `pdf:` field" in err


def test_floors_scaffold_requires_args_or_manifest(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    rc = main(["floors", "scaffold", "--data-dir", str(data_dir)])
    assert rc != 0
    err = capsys.readouterr().err
    assert "manifest" in err or "floor id" in err


def test_floors_scaffold_ambiguous_floor_id(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #56 review: scaffold must refuse to pick when two
    offices declare the same floor id, the same way validate/doctor do."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    yaml_path = data_dir / "data" / "offices.yaml"
    yaml_path.write_text(
        yaml_path.read_text(encoding="utf-8")
        + (
            "\n  - id: dup\n"
            "    name: Duplicate Office\n"
            "    floors:\n"
            "      - id: tlv-floor-5\n"
            "        svg: floors/dup.svg\n"
            "        clusters:\n"
            "          T: { capacity: 1, type: open-space }\n"
        ),
        encoding="utf-8",
    )
    (data_dir / "floors" / "dup.svg").write_text(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080"/>\n',
        encoding="utf-8",
    )
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    rc = main(
        [
            "floors",
            "scaffold",
            "tlv-floor-5",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--force",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "ambiguous" in err
    assert "tlv-floor-5" in err


def test_floors_scaffold_out_resolves_against_data_dir(
    data_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #56 review: relative --out paths must resolve against
    --data-dir (not cwd), matching validate/doctor."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    # Run from an unrelated cwd so a cwd-relative resolution would
    # land somewhere else.
    other = data_dir.parent / "elsewhere"
    other.mkdir()
    monkeypatch.chdir(other)

    rc = main(
        [
            "floors",
            "scaffold",
            "tlv-floor-5",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--out",
            "floors/custom.svg",  # relative
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    # Resolved against data_dir, not cwd:
    assert (data_dir / "floors" / "custom.svg").is_file()
    assert not (other / "floors" / "custom.svg").exists()


def test_floors_scaffold_manifest_atomicity(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #56 review: a manifest with a bad job partway through
    must not leave files written by earlier jobs. The verb resolves
    every job before writing any SVG."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    manifest = data_dir / "boot.yaml"
    # First entry is valid; second is unknown — should fail before writing.
    manifest.write_text(
        f"pdf: {pdf}\n"
        "floors:\n"
        "  - { id: tlv-floor-5, page: 1 }\n"
        "  - { id: no-such-floor, page: 1 }\n",
        encoding="utf-8",
    )
    floor5_before = (data_dir / "floors" / "tlv-floor-5.svg").read_bytes()

    rc = main(
        [
            "floors",
            "scaffold",
            "--manifest",
            str(manifest),
            "--force",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    # The valid entry must NOT have been written:
    assert (data_dir / "floors" / "tlv-floor-5.svg").read_bytes() == floor5_before


def test_floors_copy_layout_happy_path(data_dir: Path, capsys: pytest.CaptureFixture[str]) -> None:
    """Add a draft tlv-floor-3 in offices.yaml + an empty scaffold-shaped
    SVG, then copy floor-5's layout into it."""
    from office_cli.offices import append_floor_entry

    # Append a draft floor-3 with the same cluster spec as floor-5.
    append_floor_entry(
        data_dir / "data" / "offices.yaml",
        "tlv",
        {
            "id": "tlv-floor-3",
            "svg": "floors/tlv-floor-3.svg",
            "clusters": {
                "T": {"capacity": 6, "type": "open-space"},
                "Z": {"capacity": 2, "type": "phone-room"},
            },
            "rooms": {
                "3.10": {"name": "Conf 3.10", "type": "meeting", "capacity": 8},
            },
        },
    )
    (data_dir / "floors" / "tlv-floor-3.svg").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">\n'
        '<image x="0" y="0" width="1920" height="1080" href="data:image/png;base64,X"/>\n'
        '<rect id="3-T-01" class="seat" x="100" y="100" width="51" height="25"/>\n'
        '<polygon id="placeholder" class="room" points="200,200 260,200 260,240 200,240"/>\n'
        "</svg>\n",
        encoding="utf-8",
    )

    rc = main(
        [
            "floors",
            "copy-layout",
            "tlv-floor-5",
            "tlv-floor-3",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["src_floor"] == "tlv-floor-5"
    assert payload["dst_floor"] == "tlv-floor-3"
    assert payload["seats_copied"] == 8


def test_floors_copy_layout_refuses_active_dst(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """floor-5 in the fixture is status: active. Copying onto it
    without --overwrite must fail."""
    from office_cli.offices import append_floor_entry

    # Add an active second floor we'll use as src.
    append_floor_entry(
        data_dir / "data" / "offices.yaml",
        "tlv",
        {
            "id": "tlv-floor-99",
            "svg": "floors/tlv-floor-99.svg",
            "status": "active",
            "clusters": {"T": {"capacity": 6, "type": "open-space"}},
            "rooms": {},
        },
    )
    (data_dir / "floors" / "tlv-floor-99.svg").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">\n'
        '<rect id="99-T-01" class="seat" x="100" y="100" width="51" height="25"/>\n'
        "</svg>\n",
        encoding="utf-8",
    )

    rc = main(
        [
            "floors",
            "copy-layout",
            "tlv-floor-5",
            "tlv-floor-99",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "refusing to clobber" in err


def test_floors_new_with_copy_from(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """`floors new --copy-from` runs the full chain: append YAML,
    scaffold, copy layout. The result must validate clean."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")

    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    rc = main(
        [
            "floors",
            "new",
            "tlv-floor-3",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--copy-from",
            "tlv-floor-5",
            "--json",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["floor"] == "tlv-floor-3"
    assert payload["office"] == "tlv"
    # 8 seats + 1 room from floor-5 carried over → no errors.
    assert payload["errors"] == []
    # offices.yaml updated.
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    assert "tlv-floor-3" in yaml_text
    # SVG written.
    assert (data_dir / "floors" / "tlv-floor-3.svg").is_file()


def test_floors_new_without_copy_from_uses_placeholder_cluster(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Without --copy-from, the new floor gets a placeholder T:1 cluster."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    rc = main(
        [
            "floors",
            "new",
            "tlv-floor-3",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    assert "tlv-floor-3" in yaml_text
    assert "T: { capacity: 1" in yaml_text


def test_floors_new_refuses_existing_floor_id(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    rc = main(
        [
            "floors",
            "new",
            "tlv-floor-5",  # already exists
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc != 0
    err = capsys.readouterr().err
    assert "already declared" in err


def test_floors_new_retargets_room_ids(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """`--copy-from` must retarget room ids to the destination floor's
    number — `5.18` (floor-5) becomes `3.18` (floor-3). Both the
    offices.yaml entry and the SVG polygon id must reflect the new id."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    rc = main(
        [
            "floors",
            "new",
            "tlv-floor-3",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--copy-from",
            "tlv-floor-5",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    # offices.yaml must have the retargeted room id, not the source's.
    assert '"3.18"' in yaml_text
    assert '"5.18"' not in yaml_text.split("tlv-floor-3")[1]  # not in floor-3's block
    # SVG polygon id must also be retargeted (copy_layout uses dst_floor.rooms keys).
    svg_text = (data_dir / "floors" / "tlv-floor-3.svg").read_text(encoding="utf-8")
    assert 'id="3.18"' in svg_text
    assert 'id="5.18"' not in svg_text


def test_retarget_room_id_passes_through_non_conforming(data_dir: Path) -> None:
    """Direct unit test: a custom-format room id (no `<floor>.<NN>`)
    is left alone rather than being mangled into something invalid."""
    from office_cli.cli._commands.floors import _retarget_room_id

    assert _retarget_room_id("5.18", "3") == "3.18"
    assert _retarget_room_id("12.18", "14") == "14.18"
    # Non-conforming forms pass through:
    assert _retarget_room_id("legacy-MR-A", "3") == "legacy-MR-A"
    assert _retarget_room_id("Conf 5.18", "3") == "Conf 5.18"


def test_floors_new_manifest_creates_multiple_floors(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Manifest mode: one PDF, multiple {id, page} entries, all created
    with retargeted ids."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    manifest = data_dir / "boot.yaml"
    manifest.write_text(
        f"pdf: {pdf}\n"
        "copy_from: tlv-floor-5\n"
        "floors:\n"
        "  - { id: tlv-floor-2, page: 7 }\n"
        "  - { id: tlv-floor-3, page: 8 }\n"
        "  - { id: tlv-floor-4, page: 9 }\n",
        encoding="utf-8",
    )

    rc = main(
        [
            "floors",
            "new",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert len(payload["results"]) == 3
    assert all(r["ok"] for r in payload["results"])
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    # Each new floor's room id is retargeted to its own floor number.
    assert '"2.18"' in yaml_text
    assert '"3.18"' in yaml_text
    assert '"4.18"' in yaml_text
    # Three SVGs written.
    for fid in ("tlv-floor-2", "tlv-floor-3", "tlv-floor-4"):
        assert (data_dir / "floors" / f"{fid}.svg").is_file()


def test_floors_new_manifest_per_entry_copy_from_override(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Per-entry `copy_from` overrides the manifest top-level default."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    # First create floor-3 with floor-5's layout — that becomes a
    # candidate stencil for further copies.
    rc = main(
        [
            "floors",
            "new",
            "tlv-floor-3",
            "--pdf",
            str(pdf),
            "--page",
            "1",
            "--copy-from",
            "tlv-floor-5",
            "--data-dir",
            str(data_dir),
        ]
    )
    assert rc == 0
    capsys.readouterr()  # drop output

    # Now manifest-create floor-4 (default copy_from = floor-5) and
    # floor-2 (override to floor-3).
    manifest = data_dir / "boot.yaml"
    manifest.write_text(
        f"pdf: {pdf}\n"
        "copy_from: tlv-floor-5\n"
        "floors:\n"
        "  - { id: tlv-floor-4, page: 9 }\n"
        "  - { id: tlv-floor-2, page: 7, copy_from: tlv-floor-3 }\n",
        encoding="utf-8",
    )
    rc = main(
        [
            "floors",
            "new",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc == 0
    capsys.readouterr()  # drain
    # Floor-2 used floor-3 (which itself derived from floor-5), so its
    # room id is `2.18` (retargeted from floor-3's `3.18`).
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    assert '"2.18"' in yaml_text


def test_floors_new_manifest_partial_failure(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """One bad entry must not block the others. Exit code is non-zero
    when any entry failed; the report distinguishes ok vs fail per entry."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    manifest = data_dir / "boot.yaml"
    # Second entry references an unknown copy_from id.
    manifest.write_text(
        f"pdf: {pdf}\n"
        "floors:\n"
        "  - { id: tlv-floor-2, page: 7, copy_from: tlv-floor-5 }\n"
        "  - { id: tlv-floor-3, page: 8, copy_from: no-such-floor }\n",
        encoding="utf-8",
    )

    rc = main(
        [
            "floors",
            "new",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc != 0
    payload = json.loads(capsys.readouterr().out)
    by_id = {r["floor"]: r for r in payload["results"]}
    assert by_id["tlv-floor-2"]["ok"] is True
    assert by_id["tlv-floor-3"]["ok"] is False
    assert "no-such-floor" in by_id["tlv-floor-3"]["error"]
    # Successful entry IS persisted (per-entry atomicity, not batch).
    yaml_text = (data_dir / "data" / "offices.yaml").read_text(encoding="utf-8")
    assert "tlv-floor-2" in yaml_text
    # Failed entry is NOT persisted.
    assert "tlv-floor-3" not in yaml_text or "id: tlv-floor-3" not in yaml_text


def test_floors_new_no_floor_id_no_manifest(
    data_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    rc = main(["floors", "new", "--pdf", str(pdf), "--page", "1", "--data-dir", str(data_dir)])
    assert rc != 0
    err = capsys.readouterr().err
    assert "floor id" in err or "manifest" in err


def test_floors_new_manifest_handles_yaml_nulls(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #58: YAML nulls (`copy_from: null`, `office: null`) must
    be treated as unset, not coerced to the literal string "None"."""
    from office_cli.floors import _scaffold as scaffold_mod

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", lambda *a, **kw: b"\x89PNG")
    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")
    manifest = data_dir / "boot.yaml"
    # Explicit YAML nulls — copy_from null at top, office null at top.
    manifest.write_text(
        f"pdf: {pdf}\n"
        "copy_from: null\n"
        "office: null\n"
        "floors:\n"
        "  - { id: tlv-floor-2, page: 7, copy_from: null }\n",
        encoding="utf-8",
    )
    rc = main(
        [
            "floors",
            "new",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    # Should succeed: no copy_from means use the placeholder T:1 cluster.
    # No office means single-office auto-detect (tlv).
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["results"][0]["ok"] is True
    assert payload["results"][0]["office"] == "tlv"


def test_floors_new_manifest_isolates_unexpected_exceptions(
    data_dir: Path, capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Qodo PR #58: a non-OfficeError exception (e.g. OSError) in one
    entry must not abort the batch. Other entries continue; the
    failure is captured per-entry."""
    from office_cli.floors import _scaffold as scaffold_mod

    pdf = data_dir / "fake.pdf"
    pdf.write_bytes(b"%PDF-1.4\n")

    call_count = {"n": 0}

    def fake_render(*a, **kw):
        call_count["n"] += 1
        if call_count["n"] == 1:
            return b"\x89PNG"
        raise OSError("simulated disk error")

    monkeypatch.setattr(scaffold_mod, "_render_pdf_page", fake_render)
    manifest = data_dir / "boot.yaml"
    manifest.write_text(
        f"pdf: {pdf}\n"
        "floors:\n"
        "  - { id: tlv-floor-2, page: 7 }\n"
        "  - { id: tlv-floor-3, page: 8 }\n",
        encoding="utf-8",
    )
    rc = main(
        [
            "floors",
            "new",
            "--manifest",
            str(manifest),
            "--data-dir",
            str(data_dir),
            "--json",
        ]
    )
    assert rc != 0
    payload = json.loads(capsys.readouterr().out)
    by_id = {r["floor"]: r for r in payload["results"]}
    assert by_id["tlv-floor-2"]["ok"] is True
    assert by_id["tlv-floor-3"]["ok"] is False
    assert "OSError" in by_id["tlv-floor-3"]["error"]
