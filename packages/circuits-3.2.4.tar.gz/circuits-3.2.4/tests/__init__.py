"""circuits tests"""
