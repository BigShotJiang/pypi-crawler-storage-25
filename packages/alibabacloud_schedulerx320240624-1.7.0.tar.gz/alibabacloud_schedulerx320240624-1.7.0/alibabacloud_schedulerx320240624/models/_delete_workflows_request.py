# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class DeleteWorkflowsRequest(DaraModel):
    def __init__(
        self,
        app_name: str = None,
        cluster_id: str = None,
        delete_jobs: bool = None,
        workflow_ids: List[int] = None,
    ):
        # This parameter is required.
        self.app_name = app_name
        # This parameter is required.
        self.cluster_id = cluster_id
        self.delete_jobs = delete_jobs
        # This parameter is required.
        self.workflow_ids = workflow_ids

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.app_name is not None:
            result['AppName'] = self.app_name

        if self.cluster_id is not None:
            result['ClusterId'] = self.cluster_id

        if self.delete_jobs is not None:
            result['DeleteJobs'] = self.delete_jobs

        if self.workflow_ids is not None:
            result['WorkflowIds'] = self.workflow_ids

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AppName') is not None:
            self.app_name = m.get('AppName')

        if m.get('ClusterId') is not None:
            self.cluster_id = m.get('ClusterId')

        if m.get('DeleteJobs') is not None:
            self.delete_jobs = m.get('DeleteJobs')

        if m.get('WorkflowIds') is not None:
            self.workflow_ids = m.get('WorkflowIds')

        return self

