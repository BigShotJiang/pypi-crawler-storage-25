<div align="center">

# Claude Switchboard

**Multi-account manager for Claude Code CLI**

[![npm](https://img.shields.io/npm/v/claude-switchboard?color=cb3837&label=npm)](https://www.npmjs.com/package/claude-switchboard)
[![PyPI](https://img.shields.io/pypi/v/claude-switchboard?color=3776ab&label=pip)](https://pypi.org/project/claude-switchboard/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)

<img src="images/demo.gif" alt="Demo" width="600">

</div>

---

## The Problem

Claude CLI stores everything in `~/.claude/` — one account at a time. Switching means logging out, logging in, and losing your flow.

## The Solution

**Claude Switchboard** gives you:

- **Multiple profiles** — `claude-work`, `claude-personal`, `claude-client` — each fully isolated
- **Direct launch** — type `claude-work` from anywhere, no menu needed
- **Shared settings** — define MCP servers and instructions once, sync everywhere
- **One-click transfer** — export/import profiles between machines

---

## Quick Start

### Step 1: Install

Choose one method:

```bash
# npm
npm install -g claude-switchboard

# pip
pip install claude-switchboard

# or one-liner (Linux/macOS)
curl -fsSL https://raw.githubusercontent.com/ApoorvDixitt/claude-switchboard/master/install.sh | bash
```

```powershell
# Windows PowerShell
irm https://raw.githubusercontent.com/ApoorvDixitt/claude-switchboard/master/install.ps1 | iex
```

### Step 2: Launch

```bash
claude-switchboard
```

### Step 3: Create your first profile

```
> Select: Create New Account
> Enter name: work
> Profile type: 1 (Separate Workspace)
> Login now? y
```

Done! Now you can run `claude-work` from any terminal.

---

## How It Works

```
You type:           What happens:
─────────────────────────────────────────────────────
claude-work    →    CLAUDE_CONFIG_DIR=~/.claude-work
                    claude starts with isolated config

claude-personal →   CLAUDE_CONFIG_DIR=~/.claude-personal  
                    completely separate account
```

Each profile gets:
- Own config directory (`~/.claude-<name>/`)
- Own credentials and login
- Own conversation history
- Shared MCP servers (optional)

---

## Features

### Core

| Feature | Description |
|---------|-------------|
| **Create Profile** | Isolated config directory, own credentials |
| **Direct Launch** | `claude-work` command works from any terminal |
| **Shared Settings** | MCP servers + CLAUDE.md sync to all profiles |
| **Export/Import** | Transfer profiles between machines via token |

### Profile Types

| Type | Best For | Config Dir | Authentication |
|------|----------|------------|----------------|
| **Separate Workspace** | Different accounts (work/personal) | `~/.claude-<name>/` | Each has own login |
| **Shared Workspace** | Same person, different API providers | `~/.claude/` | AWS Bedrock, GCP Vertex, or API Key |

**Shared Workspace** profiles share the same `~/.claude/` directory (conversations, memory, history) but use different authentication providers. Claude CLI handles the authentication automatically via environment variables.

### Menu Options

```
1. List Accounts        — see all profiles and status
2. Create New Account   — make a new profile  
3. Launch Account       — start a profile
4. Rename Account       — change profile name
5. Delete Account       — remove profile permanently
6. Shared Settings      — configure MCP servers, CLAUDE.md
7. Plugins & Marketplace — manage plugins
E. Export Profile       — generate transfer token
I. Import Profile       — restore from token
```

---

## Shared Settings

Define once, apply everywhere.

### Edit shared MCP servers:

```
Menu → 6 (Shared Settings) → 1 (Edit MCP + Settings)
```

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@anthropic-ai/mcp-filesystem", "/home/user"]
    }
  }
}
```

### Edit shared instructions:

```
Menu → 6 (Shared Settings) → 2 (Edit CLAUDE.md)
```

```markdown
Always respond concisely.
Use TypeScript for code examples.
```

These automatically apply to all profiles on launch.

---

## Export / Import

Transfer a profile to another machine:

**On source machine:**
```
Menu → E → select profile → copy the token
```

**On target machine:**
```
Menu → I → paste token → profile restored
```

The token includes credentials, settings, and launcher (~5KB).

---

## Folder Structure

```
~/
├── claude-accounts/           # Launcher scripts
│   ├── claude-work.sh
│   ├── claude-personal.sh
│   └── .profile-registry.json
│
├── claude-shared/             # Shared settings (syncs to all)
│   ├── settings.json          # MCP servers, env vars
│   └── CLAUDE.md              # Global instructions
│
├── .claude-work/              # Work profile config
├── .claude-personal/          # Personal profile config
└── .local/bin/                # Symlinks for direct launch
    ├── claude-work
    └── claude-personal
```

---

## Requirements

- [Claude CLI](https://docs.anthropic.com/en/docs/claude-code) installed
- **Linux/macOS:** Bash 3.2+, curl, jq (auto-installed on first run)
- **Windows:** PowerShell 5.1+
- **Optional:** [gum](https://github.com/charmbracelet/gum) for modern TUI (auto-offered)

---

## Documentation

- [Installation Guide](docs/installation.md)
- [Usage Guide](docs/usage.md)

---

## License

[MIT](LICENSE)

---

<div align="center">

Built by [Apoorv Dixit](https://github.com/ApoorvDixitt)

</div>
