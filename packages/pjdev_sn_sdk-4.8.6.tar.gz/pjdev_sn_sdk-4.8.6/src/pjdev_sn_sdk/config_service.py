from pathlib import Path
from typing import Optional

from pjdev_sn_sdk.models import Config

__ctx = {}


def get_config() -> Config:
    return __ctx["config"]


def init(env_path: Optional[Path] = None) -> None:
    Config.model_config.update(env_file=env_path)
    __ctx["config"] = Config()

    if __ctx["config"].output_path is None:
        __ctx["config"].output_path = env_path.parent / "output"

