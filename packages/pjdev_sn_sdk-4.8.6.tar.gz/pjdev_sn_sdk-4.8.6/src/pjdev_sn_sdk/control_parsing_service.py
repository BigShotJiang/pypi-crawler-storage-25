import re
from typing import Optional

from loguru import logger


def extract_control(ap: Optional[str]) -> Optional[str]:
    """
    Extract the NIST 800-53 control_id from an assessment procedure (ap) value.

    What it does:
    - Accepts a wide variety of AP formats (case-insensitive).
    - Removes [r5] revision markers (wherever they appear).
    - Parses the control family (e.g., AC) and control number (e.g., 2), removing leading zeros.
    - Captures only the immediate numeric enhancement in parentheses (e.g., (3)).
    - Ignores objective letters like (a), (b), roman numerals, dot suffixes like .01, and other notes.

    Examples:
    - "AC-2(3)(a)"        -> "AC-02(03)"
    - "[r5] ac-02 (03)"   -> "AC-02(03)"
    - "PM-16 (01) (b)"    -> "PM-16(01)"
    - "RA-5(5)(A)(1)"     -> "RA-05(05)"
    - "SC-7 (12).01(a)"   -> "SC-07(12)"
    - "AU-3"              -> "AU-03"
    - "invalid"           -> None

    :param ap: The assessment procedure string.
    :return: The related control_id (e.g., 'AC-2' or 'AC-2(3)') or None if it can't be parsed.
    """
    if not ap:
        return None

    s = ap.strip()
    if not s:
        return None

    # Remove revision markers like [r5] anywhere in the string (case-insensitive).
    s = re.sub(r"\[\s*r?\s*5\s*\]", "", s, flags=re.IGNORECASE)

    # Match the base control family and number (e.g., AC-2, CM-06, etc.)
    # NOTE: Use a negative lookahead to avoid requiring a word boundary after the number.
    # This allows inputs like "CA-05b" to match the base "CA-05" while excluding trailing digits.
    base_match = re.search(r"(?i)\b([A-Z]{2})\s*-\s*0*([0-9]{1,3})(?!\d)", s)

    if not base_match:
        logger.debug(f"Could not find control family and number in AP: {ap}")
        return None

    family = base_match.group(1).upper()
    number = str(int(base_match.group(2)))  # strip any leading zeros by int conversion
    control_id = f"{family}-{'0' if len(number) == 1 else ''}{number}"

    # Starting right after the base match, capture immediate numeric parentheses like (03) -> (3).
    idx = base_match.end()
    paren_token = re.compile(r"\s*\(\s*([^)]+)\s*\)")

    while True:
        m = paren_token.match(s, idx)
        if not m:
            break

        token = m.group(1)

        # Only accept purely numeric tokens as part of the control identifier.
        # Stop at the first non-numeric token (e.g., letters like (a), roman numerals, etc.).
        if re.fullmatch(r"0*\d+", token):
            sub_number = f"{int(token)}"
            control_id += f"({'0' if len(sub_number) == 1 else ''}{sub_number})"  # normalize 0-padded numbers
            idx = m.end()
            # Continue in case there is another numeric enhancement directly chained.
            continue
        else:
            break

    return control_id


def strip_leading_zeros_after_dash_or_dot(s: str) -> str:
    return re.sub(r"(?<=[-.(])0+(?=\d)", "", s)


def extract_control_requirement(ap: Optional[str]) -> Optional[str]:
    if not ap:
        return None

    control_id = extract_control(ap=ap)
    if not control_id:
        return None

    sn_control_id = strip_leading_zeros_after_dash_or_dot(control_id)
    stripped_ap = strip_leading_zeros_after_dash_or_dot(ap).upper()

    part = stripped_ap.removeprefix(sn_control_id).removeprefix(".").split(".")[0]

    if not part:
        return None

    return f"{sn_control_id}.{part.strip().lower()}"
