# pjdev-sn-sdk

[![PyPI - Version](https://img.shields.io/pypi/v/pjdev-sn-sdk.svg)](https://pypi.org/project/pjdev-sn-sdk)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pjdev-sn-sdk.svg)](https://pypi.org/project/pjdev-sn-sdk)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install pjdev-sn-sdk
```

## License

`pjdev-sn-sdk` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
