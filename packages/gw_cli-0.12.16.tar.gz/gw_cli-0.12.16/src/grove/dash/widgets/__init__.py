"""Dashboard TUI widgets."""
