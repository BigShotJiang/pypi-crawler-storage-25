from __future__ import annotations

from collections import defaultdict
import re
from typing import Any, Callable, Dict, List

from .. import debugging, errors


def _is_numeric_overflow(message: str, report: str) -> bool:
    message_l = message.lower()
    report_l = report.lower()
    return (
        "overflowed" in message_l
        or "overflowed" in report_l
        or "overflow" in message_l
        or "overflow" in report_l
    )


def _pyrel_group_key(source: debugging.SourceInfo, pyrel_id: str | None) -> tuple[Any, ...] | None:
    source_file = getattr(source, "file", None)
    source_line = getattr(source, "line", None)
    if source_file and source_line is not None:
        return ("source", source_file, source_line)
    if pyrel_id:
        return ("pyrel_id", pyrel_id)
    return None


def report_problems(
    problems: List[Dict[str, Any]],
    *,
    get_source: Callable[[Dict[str, Any]], debugging.SourceInfo | None],
    abort_on_error: bool = True,
    show_corerel_errors: bool = True,
) -> None:
    all_errors = []
    undefineds = []
    pyrel_errors: dict[tuple[Any, ...], list[Dict[str, Any]]] = defaultdict(list)
    pyrel_warnings: dict[tuple[Any, ...], list[Dict[str, Any]]] = defaultdict(list)

    for problem in problems:
        message = str(problem.get("message", ""))
        report = str(problem.get("report", ""))
        source = get_source(problem) or debugging.SourceInfo()
        severity = str(problem.get("severity", "warning")).lower()
        code = problem.get("code")
        props = problem.get("props", {})

        if _is_numeric_overflow(message, report):
            all_errors.append(errors.NumericOverflow(problem, source))
            continue

        if severity in ["error", "exception"]:
            if code == "UNDEFINED_IDENTIFIER":
                match = re.search(r'`(.+?)` is undefined', message)
                if match:
                    undefineds.append((match.group(1), source))
                else:
                    all_errors.append(errors.RelQueryError(problem, source))
            elif code == "PYREL_ERROR":
                pyrel_id = props.get("pyrel_id") if isinstance(props, dict) else None
                group_key = _pyrel_group_key(source, pyrel_id)
                if group_key:
                    pyrel_errors[group_key].append(problem)
                elif abort_on_error:
                    all_errors.append(errors.RelQueryError(problem, source))
            elif abort_on_error:
                all_errors.append(errors.RelQueryError(problem, source))
        else:
            if code == "ARITY_MISMATCH":
                errors.ArityMismatch(problem, source)
            elif code == "IC_VIOLATION":
                all_errors.append(errors.IntegrityConstraintViolation(problem, source))
            elif code == "PYREL_ERROR":
                pyrel_id = props.get("pyrel_id") if isinstance(props, dict) else None
                group_key = _pyrel_group_key(source, pyrel_id)
                if group_key:
                    pyrel_warnings[group_key].append(problem)
                else:
                    errors.RelQueryWarning(problem, source)
            elif "corerel" in message and not show_corerel_errors:
                pass
            else:
                errors.RelQueryWarning(problem, source)

    if abort_on_error and len(undefineds):
        all_errors.append(errors.UninitializedPropertyException(undefineds))

    if abort_on_error:
        for pyrel_problems in pyrel_errors.values():
            all_errors.append(errors.ModelError(pyrel_problems))

    for pyrel_problems in pyrel_warnings.values():
        errors.ModelWarning(pyrel_problems)

    if len(all_errors) == 1:
        raise all_errors[0]
    if len(all_errors) > 1:
        raise errors.RAIExceptionSet(all_errors)
