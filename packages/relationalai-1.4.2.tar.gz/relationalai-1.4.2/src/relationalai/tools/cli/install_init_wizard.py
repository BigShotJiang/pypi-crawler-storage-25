"""Wizard for the `rai init --install-mode` command.

Scaffolds a full install-mode starter project in a named subfolder.

Entry paths:
  1. <name>/raiconfig.yaml found → validate it (same as rai init path 1)
  2. Nothing found               → create <name>/ with all starter files

Output style is the "wizard chrome" defined in :mod:`._init_common`: a
``◆`` header followed by dim ``│`` connectors and per-step diamond
markers — filled ``◆`` for completed steps, hollow ``◇`` for steps that
still require user action.
"""

from __future__ import annotations

import os
from pathlib import Path

import rich

from ._init_common import (
    RAICONFIG_YAML,
    has_template_values,
    wizard_body,
    wizard_close,
    wizard_close_body,
    wizard_open,
    wizard_pipe,
    wizard_prompt,
    wizard_step,
)


def _using_uv() -> bool:
    # `UV` env var: set by `uv run` for its child process.
    # `uv.lock`: any ancestor → the user is inside a uv-managed project.
    if os.environ.get("UV"):
        return True
    cur = Path.cwd().resolve()
    while True:
        if (cur / "uv.lock").exists():
            return True
        if cur == cur.parent:
            return False
        cur = cur.parent


# ── Public entry point ───────────────────────────────────────────────────────

def run_install_wizard() -> None:
    """Entry point called from cli.py for `rai init --install-mode`."""
    wizard_open("Welcome to RelationalAI", "install-mode starter")
    _create_install_mode_project()


# ── Project scaffolding ───────────────────────────────────────────────────────

# Each entry: (filename, summary description, template attr on
# ``template_config``, needs ``{name}`` substitution). Order drives both
# the on-disk creation and the display summary. Templates are referenced
# by attribute name so this constant stays import-free at module level.
_PROJECT_FILES: tuple[tuple[str, str, str, bool], ...] = (
    ("raiconfig.yaml", "connection + install mode config", "INSTALL_MODE_CONFIG_TEMPLATE",        False),
    ("model.py",       "starter model",                    "INSTALL_MODE_MODEL_PY_TEMPLATE",      True),
    ("load_data.py",   "data loading script",              "INSTALL_MODE_LOAD_DATA_TEMPLATE",     False),
    ("queries.py",     "example queries",                  "INSTALL_MODE_QUERIES_PY_TEMPLATE",    False),
    ("pyproject.toml", "project metadata",                 "INSTALL_MODE_PYPROJECT_TOML_TEMPLATE", True),
    ("README.md",      "getting started guide",            "INSTALL_MODE_README_TEMPLATE",        True),
)


def _create_install_mode_project() -> None:
    """Scaffold a new install-mode project in a named subfolder (Next.js-style)."""
    from . import template_config as tpl

    name = wizard_prompt("Project name", default="starter")
    project_dir = Path(name)
    yaml_path = project_dir / RAICONFIG_YAML

    if yaml_path.exists():
        # Setup-flow check only — placeholder substring scan, no full
        # `create_config()` validation. Deeper diagnostics live in
        # `rai connect` / `rai config:explain`.
        wizard_pipe()
        if has_template_values(yaml_path):
            wizard_close(
                "[yellow]Your config still contains placeholder values.[/yellow]",
                style="yellow",
                pending=True,
            )
            wizard_close_body(
                f"[dim]Edit [bold]{yaml_path}[/bold] and replace the example values "
                f"with your own, then run [bold]rai init --install-mode[/bold] again.[/dim]"
            )
        else:
            wizard_close(f"[green][bold]{name}/[/bold] already exists and looks ready.[/green]")
            wizard_close_body(
                f"[dim]Run [bold]rai connect[/bold] from {name}/ to validate the connection.[/dim]"
            )
        rich.print()
        return

    project_dir.mkdir(exist_ok=True)
    for fname, _desc, attr, needs_name in _PROJECT_FILES:
        template: str = getattr(tpl, attr)
        content = template.format(name=name) if needs_name else template
        (project_dir / fname).write_text(content, encoding="utf-8")

    # Widest filename drives column alignment so the description column lines up.
    width = max(len(fname) for fname, *_ in _PROJECT_FILES)

    wizard_pipe()
    wizard_step(f"[green]Created[/green] [bold]{name}/[/bold]")
    for fname, desc, *_ in _PROJECT_FILES:
        wizard_body(f"[cyan]{fname:<{width}}[/cyan]  [dim]{desc}[/dim]")
    wizard_pipe()
    wizard_step(
        f"[yellow]Edit[/yellow] [bold]{name}/raiconfig.yaml[/bold] first "
        f"— fill in account, user, warehouse, role.",
        style="yellow",
        pending=True,
    )
    wizard_body(
        f"[dim]Default auth: externalbrowser (SSO). "
        f"For PAT or JWT, see {name}/README.md.[/dim]"
    )
    wizard_pipe()
    prefix = "uv run " if _using_uv() else ""
    wizard_close("[bold]Next steps:[/bold]", pending=True)
    wizard_close_body(f"[cyan]cd {name}[/cyan]")
    wizard_close_body(f"[cyan]{prefix}python load_data.py[/cyan]")
    wizard_close_body(f"[cyan]{prefix}rai models install[/cyan]")
    wizard_close_body(f"[cyan]{prefix}python queries.py[/cyan]")
    rich.print()
