"""Custom Click group that formats subcommands with colored names.

Pre-migration the root surface used colon-prefixed flat commands like
``jobs:list``, and this formatter grouped them into sections by the
prefix before the colon. Post-migration the colons live only on hidden
backward-compat aliases; the visible surface is a flat list of root
commands and noun subgroups (``jobs``, ``reasoners``, ``config``, ...).
The formatter still colors the names but no longer needs prefix grouping.
"""

from __future__ import annotations

import click

from .runtime import OutputFormat, color_enabled, get_runtime, normalize_output_format, resolve_no_color


class RaiSubGroup(click.Group):
    """Base group whose ``--help`` colors subcommand names.

    Visual contract: every level of the CLI renders subcommand names in
    the same accent color (``bright_blue``), so the user sees the same
    "this is something you can invoke" cue at the root, in subgroups
    (``rai jobs --help``), and in any future nested groups. Without this
    base class, only the root :class:`RaiGroup` would color its rows
    (because Click's default ``Group`` writes plain names) and subgroup
    help would render in white — visually inconsistent.

    The color state is read from the
    :class:`~relationalai.tools.cli.runtime.CliRuntime` attached to the
    Click context, so ``rai --no-color`` (or ``NO_COLOR=1``) produces
    plain output without ANSI escapes at every level.
    """

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        use_color = color_enabled(ctx)

        rows: list[tuple[str, str]] = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or getattr(cmd, "hidden", False):
                continue
            label = click.style(name, fg="bright_blue") if use_color else name
            rows.append((label, cmd.get_short_help_str()))

        if not rows:
            return

        with formatter.section("Commands"):
            formatter.write_dl(rows)


class RaiGroup(RaiSubGroup):
    """Root CLI group. Adds top-level-only behavior on top of :class:`RaiSubGroup`.

    Root-only responsibilities:

    - Pre-scans raw args for ``--json`` / ``--no-color`` so eager option
      callbacks (``--version``) see the right color/JSON state before
      :func:`cli` runs.
    - Injects a one-line version summary into ``rai --help``.

    Coloring of subcommand names is inherited from :class:`RaiSubGroup`
    so every level of the CLI looks the same.
    """

    @staticmethod
    def _output_format_from_args(args: list[str]) -> OutputFormat:
        # Eager priming only; Click's option parser performs authoritative
        # validation later. Defers the "yml -> yaml" alias and unknown-value
        # fallback to :func:`runtime.normalize_output_format` so the priming
        # path and the ``cli()`` body share one rule set.
        for idx, arg in enumerate(args):
            if arg.startswith("--output="):
                return normalize_output_format(arg.split("=", 1)[1])
            if arg == "--output" and idx + 1 < len(args):
                return normalize_output_format(args[idx + 1])
        return "table"

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        """Prime output / no-color flags from raw args before option parsing.

        Eager option callbacks (like ``--version``) fire from inside Click's
        parser, *before* :func:`cli` runs. Without this hook, those callbacks
        couldn't tell that the user also passed ``--json``, ``--yaml`` /
        ``--yml``, or ``--no-color``, so the upgrade panel could leak into
        machine-readable output or render with ANSI when the user asked for
        plain text. We do a cheap pre-scan here so the runtime is correct
        from the very first eager callback onward.

        ``cli()`` re-asserts these from the parsed ``ctx.params`` afterwards
        and is the source of truth for conflict detection (``--json`` +
        ``--yaml`` is rejected there); the priming values agree with the
        parsed values when the input is well-formed, so re-asserting is a
        no-op.
        """
        try:
            from .cli_output_prefs import set_cli_no_color

            # Shortcut flags win over ``--output X`` here so the eager
            # callbacks see the same effective format Click will pick
            # post-parse. ``--json`` takes precedence over ``--yaml`` /
            # ``--yml`` only because ``cli()`` rejects the combination
            # outright; that authoritative validation runs after this.
            json_flag = "--json" in args
            yaml_flag = "--yaml" in args or "--yml" in args
            if json_flag:
                output_format: OutputFormat = "json"
            elif yaml_flag:
                output_format = "yaml"
            else:
                output_format = self._output_format_from_args(args)

            no_color = resolve_no_color(flag="--no-color" in args)

            rt = get_runtime(ctx)
            rt.output_format = output_format
            rt.json_output = output_format == "json"
            rt.no_color = no_color
            set_cli_no_color(no_color)
            if no_color:
                ctx.color = False
        except Exception:
            # Never let priming fail the parse; ``cli()`` will populate
            # these correctly from ``ctx.params`` regardless.
            pass
        return super().parse_args(ctx, args)

    def format_help_text(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        """Inject a short version summary right under the command description.

        Uses the installed package version as formatted by
        :func:`update_check.format_version_summary`; it does not consult
        cached PyPI ``latest`` data here. The post-command panel rendered
        by :func:`update_check.maybe_print_notice` owns the upgrade nudge.
        """
        super().format_help_text(ctx, formatter)
        try:
            from . import update_check

            line = update_check.format_version_summary(use_color=color_enabled(ctx))
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(line)
        except Exception:
            # Never let a help-screen embellishment break ``rai --help``.
            return
