"""Shared list/detail rendering helpers for CLI commands.

Every list and get command follows the same pattern:

1. fetch items (with a spinner)
2. if a machine-readable output mode is set, serialize and print
3. otherwise, render a table (or a "not found" message)

These helpers capture that pattern so that command bodies stay tiny.
"""

from __future__ import annotations

import shlex
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any

from . import runtime


@dataclass(frozen=True)
class PaginationInfo:
    """Pagination context passed by ``--limit`` / ``--offset`` flags.

    Used by :func:`render_list` to print a small footer after the table that
    makes paging behavior explicit and suggests how to fetch the next page.

    Attributes
    ----------
    limit:
        The ``--limit`` value used for the request (max items per page).
    offset:
        The ``--offset`` value used for the request (items skipped).
    command:
        Command name to suggest in the "next page" hint, e.g. ``"jobs list"``.
    filter_args:
        Active CLI filter flags (already shell-quoted) to include in the
        suggested next-page command, e.g. ``("--type", "Logic", "--state",
        "RUNNING")``. Built by :func:`build_filter_args`.
    """

    limit: int | None
    offset: int
    command: str
    filter_args: tuple[str, ...] = field(default_factory=tuple)


def build_filter_args(opts: Sequence[tuple[str, Any]]) -> tuple[str, ...]:
    """Build a shell-safe argv fragment from active CLI filter options.

    Each entry in ``opts`` is a ``(flag, value)`` pair where:
    - ``value is None`` or an empty/whitespace-only string is skipped.
    - ``bool`` values emit just the flag when ``True``, nothing when ``False``.
    - sequences (``list``/``tuple``) emit the flag once per element.
    - everything else is stringified and ``shlex.quote``-ed.

    The returned tuple is suitable as :attr:`PaginationInfo.filter_args`.
    """
    args: list[str] = []
    for flag, value in opts:
        if value is None:
            continue
        if isinstance(value, bool):
            if value:
                args.append(flag)
            continue
        if isinstance(value, (list, tuple)):
            for v in value:
                if v is None:
                    continue
                s = str(v).strip()
                if not s:
                    continue
                args.append(flag)
                args.append(shlex.quote(s))
            continue
        s = str(value).strip()
        if not s:
            continue
        args.append(flag)
        args.append(shlex.quote(s))
    return tuple(args)


def _print_pagination_footer(
    *,
    shown: int,
    pagination: PaginationInfo,
) -> None:
    """Print a footer that makes ``--limit`` / ``--offset`` paging explicit.

    The footer is only rendered when paging is actually in effect:
    - ``offset > 0`` (the user is viewing a paginated slice), or
    - ``shown == limit`` (a full page was returned and there *might* be more).

    When ``offset == 0`` and fewer than ``limit`` items came back, the entire
    result set fits on one page and no footer is shown to avoid noise.

    Always emitted to **stderr** (via :data:`runtime.stderr_console`) so
    scripts piping ``rai ... | jq`` never see the footer mixed in with
    the primary table/JSON payload.
    """
    limit = pagination.limit
    offset = pagination.offset
    # ``limit > 0`` guards a degenerate edge case: if ``limit == 0`` and the
    # caller passes ``shown == 0`` we would otherwise treat that as a "full
    # page" and suggest a next-page command with ``--limit 0`` that loops on
    # itself. The CLI's ``--limit`` option already enforces ``IntRange(min=1)``
    # so this only matters for direct programmatic callers of ``render_list``.
    full_page = limit is not None and limit > 0 and shown == limit
    if offset == 0 and not full_page:
        return

    end_index = offset + shown
    range_label = f"{offset + 1}-{end_index}" if shown > 0 else f"offset {offset}"

    # Footers are printed with ``markup=False`` so that values flowing through
    # ``pagination.filter_args`` can never be interpreted as Rich markup. Some
    # user filter values (or future record-derived strings) may contain ``[``
    # or ``]`` even after :func:`shlex.quote`, since shell quoting does not
    # escape Rich's bracketed tags.
    if full_page:
        next_offset = end_index
        filter_part = (" " + " ".join(pagination.filter_args)) if pagination.filter_args else ""
        limit_hint = f" --limit {limit}" if limit is not None else ""
        runtime.stderr_console.print(
            f"Showing results {range_label} (paginated). "
            f"More results may be available — see next page with:",
            soft_wrap=True,
            style="dim",
            markup=False,
        )
        runtime.stderr_console.print(
            f"  rai {pagination.command}{filter_part} --offset {next_offset}{limit_hint}",
            soft_wrap=True,
            style="dim",
            markup=False,
        )
    else:
        runtime.stderr_console.print(
            f"Showing results {range_label} (paginated; --offset {offset}). "
            f"No further pages.",
            soft_wrap=True,
            style="dim",
            markup=False,
        )


def _render_payload(
    *,
    payload: Any,
    json_key: str,
    is_empty: bool,
    empty_renderer: Callable[[], None],
    nonempty_renderer: Callable[[], None],
) -> None:
    """Shared scaffold for both ``render_list`` and ``render_detail``.

    Centralizes the "machine output? emit `{json_key: payload}` and exit;
    otherwise hand off to the right human renderer" branch that previously
    lived (slightly differently) in both helpers.

    The ``payload`` is whatever has already been mapped to a JSON-friendly
    shape (a ``list[dict]`` for ``render_list``, a single ``dict`` /
    ``None`` for ``render_detail``); the caller is responsible for
    deciding shape and emptiness, this helper only orchestrates branches.

    Splitting ``empty_renderer`` and ``nonempty_renderer`` (rather than
    handing the renderer a single record/list) is what lets
    ``render_list`` defer printing the pagination footer until *after*
    the table while still going through the same scaffold.
    """
    if runtime.cli_wants_machine_output():
        runtime.emit_cli_output({json_key: payload})
        return

    if is_empty:
        empty_renderer()
        return

    nonempty_renderer()


def render_list(
    items: Iterable[Any],
    *,
    json_key: str,
    json_mapper: Callable[[Any], Any],
    renderer: Callable[[list[Any]], None],
    empty_message: str = "[yellow]No items found.[/yellow]",
    pagination: PaginationInfo | None = None,
) -> None:
    """Render a list of records in machine-readable or table mode.

    Parameters
    ----------
    items:
        The records to render.
    json_key:
        Top-level JSON key (e.g. ``"reasoners"``).
    json_mapper:
        Function that serializes a single record to a JSON-friendly dict.
    renderer:
        Callable that prints a table from a list of records.
    empty_message:
        Rich markup printed (to stdout) when ``items`` is empty and not in a
        machine-readable output mode.
    pagination:
        Optional :class:`PaginationInfo`. When provided and not in a
        machine-readable output mode, a short footer is printed after the table
        to make pagination explicit and to suggest the command for fetching the
        next page.
    """
    items_list = list(items)

    def _empty() -> None:
        if pagination is not None and pagination.offset > 0:
            # Paging hint goes to stderr (it's advisory, not the payload).
            runtime.stderr_console.print(
                f"No results at offset {pagination.offset}. "
                f"Try a smaller --offset to see earlier pages.",
                soft_wrap=True,
                style="dim",
                markup=False,
            )
        else:
            runtime.console.print(empty_message)

    def _nonempty() -> None:
        renderer(items_list)
        if pagination is not None:
            _print_pagination_footer(shown=len(items_list), pagination=pagination)

    _render_payload(
        payload=[json_mapper(r) for r in items_list] if runtime.cli_wants_machine_output() else None,
        json_key=json_key,
        is_empty=not items_list,
        empty_renderer=_empty,
        nonempty_renderer=_nonempty,
    )


def render_detail(
    record: Any | None,
    *,
    json_key: str,
    json_mapper: Callable[[Any], Any],
    renderer: Callable[[Any], None],
    not_found_message: str = "[yellow]Not found.[/yellow]",
) -> None:
    """Render a single record in machine-readable or detail mode."""
    _render_payload(
        payload=(
            json_mapper(record)
            if record is not None and runtime.cli_wants_machine_output()
            else None
        ),
        json_key=json_key,
        is_empty=record is None,
        empty_renderer=lambda: runtime.console.print(not_found_message),
        nonempty_renderer=lambda: renderer(record),
    )
