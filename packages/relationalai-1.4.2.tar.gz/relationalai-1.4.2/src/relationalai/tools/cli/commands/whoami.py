"""``rai whoami`` — identity from the active config, no session by default.

Sibling of ``gh auth status`` / ``gcloud auth list`` / ``op whoami``:
one-line headline answered locally; ``--resolve`` opens a session for
the server-resolved identity (catches SSO/JWT/OAuth user mappings).
``rai connect`` remains the diagnostic command on failure.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import click
from rich.table import Table
from rich.text import Text

from ....util.docutils import include_in_docs
from .. import runtime
from ..connection_validation import (
    IDENTITY_SQL_EXPRESSIONS,
    fetch_session_identity,
    identity_label_pairs,
)

if TYPE_CHECKING:
    from relationalai.config.config import Config


# Display order + labels for the verbose identity table. Derived from
# :data:`IDENTITY_FIELDS` (in :mod:`connection_validation`) so this
# module and the SQL probe share one definition — adding a ``CURRENT_*``
# scalar is a single-line edit there and ``rai whoami --verbose``
# automatically picks it up here without a coordinated change.
_IDENTITY_LABELS: tuple[tuple[str, str], ...] = identity_label_pairs()


def _config_payload(config: "Config") -> dict[str, Any]:
    """Config-side half of the whoami payload: ``source`` (discriminator
    literal), ``path`` (absolute file), ``profile``, plus the connection
    fields (``type``/``user``/``account``/...). Any field that isn't
    known is ``None``.
    """
    source_field = type(config).model_fields.get("source")
    # ``runtime.resolved_config_path`` reads the pydantic-private
    # ``_resolved_config_file`` slot via ``vars(...)`` (the config-usage
    # lint rejects ``getattr`` on ``Config``) and the ``resolve=True``
    # knob handles the ``Path.expanduser().resolve()`` defensively
    # (permission errors / broken symlinks / Windows ``MAX_PATH`` all
    # fall back to the raw string rather than crashing whoami).
    payload: dict[str, Any] = {
        "source": source_field.default if source_field is not None else None,
        "path": runtime.resolved_config_path(config, resolve=True),
        "profile": config.active_profile,
    }

    try:
        connection = config.get_default_connection()
    except Exception:
        connection = None

    if connection is not None:
        # ``schema`` lives on the connection as ``schema_`` because plain
        # ``schema`` shadows a pydantic-base attribute; expose it under
        # the user-facing ``schema`` key so the verbose table's Schema
        # row (and the JSON envelope) render the configured value.
        for payload_key, attr in (
            ("type", "type"),
            ("authenticator", "authenticator"),
            ("user", "user"),
            ("account", "account"),
            ("role", "role"),
            ("warehouse", "warehouse"),
            ("database", "database"),
            ("schema", "schema_"),
        ):
            value = getattr(connection, attr, None)
            payload[payload_key] = str(value) if value not in (None, "") else None

    return payload


def collect_whoami_info(
    config: "Config", session: Any | None
) -> dict[str, Any]:
    """Whoami payload (single source of truth for every renderer).

    Identity scalars come from ``session`` when ``--resolve`` was passed,
    otherwise they're left ``None`` and the human renderers fall back
    to the config-side identity. Keys are stable for scripts.
    """
    identity: dict[str, str | None] = (
        {key: None for key, _ in IDENTITY_SQL_EXPRESSIONS}
        if session is None
        else fetch_session_identity(session)
    )
    return {**identity, "config": _config_payload(config)}


def _effective_value(
    info: dict[str, Any], key: str, *, config_key: str | None = None
) -> str | None:
    """Server-resolved value if present; otherwise the config-side
    fallback. Powers the terse headline; the verbose renderer shows
    both sides independently so drift is visible.
    """
    server = info.get(key)
    if server:
        return str(server)
    cfg = info.get("config") or {}
    cfg_value = cfg.get(config_key or key)
    return str(cfg_value) if cfg_value else None


def _format_provenance_tail(info: dict[str, Any]) -> str | None:
    """Dim ``via <file> | profile <name>`` tail for the terse form;
    ``None`` when neither path nor profile is known. Profile name is
    rendered bold white so a misconfigured profile pops; the rest is
    dim so the headline stays grep-friendly on its own line.
    """
    cfg = info.get("config") or {}
    path = cfg.get("path")
    profile = cfg.get("profile")

    if not path and not profile:
        return None
    if path and profile:
        return (
            f"  [dim]via {path} | profile[/dim] "
            f"[bold white]{profile}[/bold white]"
        )
    if path:
        return f"  [dim]via {path}[/dim]"
    return f"  [dim]profile[/dim] [bold white]{profile}[/bold white]"


def _render_human_short(info: dict[str, Any]) -> None:
    """Default human form: ``You are <user> on <account> (role …,
    warehouse …)`` headline + a dim ``via <file> | profile <name>``
    follow-up. Headline lives on its own line so wrappers can
    ``grep "You are "`` without picking up provenance noise.
    """
    user = _effective_value(info, "user") or "<unknown user>"
    account = _effective_value(info, "account") or "<unknown account>"
    role = _effective_value(info, "role")
    warehouse = _effective_value(info, "warehouse")

    extras: list[str] = []
    if role:
        extras.append(f"role {role}")
    if warehouse:
        extras.append(f"warehouse {warehouse}")
    extras_tail = f" ({', '.join(extras)})" if extras else ""

    runtime.console.print(
        f"You are [bold]{user}[/bold] on [bold]{account}[/bold]{extras_tail}"
    )

    tail = _format_provenance_tail(info)
    if tail is not None:
        runtime.console.print(tail)


def _render_human_verbose(info: dict[str, Any], *, resolved: bool) -> None:
    """Two-section table: Identity + Authentication. Under ``--resolve``
    the identity rows show server-resolved values and config rows render
    ``ialexiev (resolved to IPALEXIEV)`` when the two differ.
    """
    cfg = info.get("config") or {}

    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
    table.add_column(style="dim cyan", no_wrap=True)
    table.add_column(style="white")

    section_title = (
        "Identity (server-resolved)" if resolved else "Identity (from config)"
    )
    table.add_row(Text(section_title, style="bold white not dim"), "")
    for key, label in _IDENTITY_LABELS:
        value = info.get(key) if resolved else cfg.get(key)
        table.add_row(f"  {label}", str(value) if value else "—")
    table.add_row("", "")

    table.add_row(Text("Authentication", style="bold white not dim"), "")
    table.add_row("  Authenticator", str(cfg.get("authenticator") or "—"))

    # Drift call-out (only meaningful under ``--resolve``): server-resolved
    # value differs from the config-asserted value.
    for key, label in (("user", "Config user"), ("role", "Config role")):
        asked = cfg.get(key)
        if not asked:
            continue
        got = info.get(key) if resolved else None
        if got and str(got).strip().upper() != str(asked).strip().upper():
            table.add_row(f"  {label}", f"{asked}    (resolved to {got})")
        else:
            table.add_row(f"  {label}", str(asked))

    table.add_row("  Connection", str(cfg.get("type") or "—"))

    # File path first, discriminator in parens; fall back to discriminator-
    # only when path is unknown (programmatic configs, ConfigFromActiveSession).
    config_path = cfg.get("path")
    config_source = cfg.get("source")
    if config_path and config_source:
        table.add_row("  Config file", f"{config_path}  ({config_source})")
    elif config_path:
        table.add_row("  Config file", str(config_path))
    elif config_source:
        table.add_row("  Config source", str(config_source))

    if cfg.get("profile"):
        table.add_row("  Profile", str(cfg.get("profile")))

    runtime.console.print(table)


def render_whoami(
    config: "Config",
    session: Any | None,
    *,
    verbose: bool,
) -> None:
    """Render whoami in whichever output format the runtime is in.

    Machine output always emits the full payload regardless of
    ``--verbose`` so scripts never need to set a display flag.
    """
    info = collect_whoami_info(config, session)
    resolved = session is not None

    if runtime.emit_cli_result("whoami", info):
        return

    if verbose:
        _render_human_verbose(info, resolved=resolved)
    else:
        _render_human_short(info)


def register(cli: click.Group) -> None:
    """Attach the ``whoami`` subcommand."""

    @cli.command(name="whoami")
    @click.option(
        "--verbose",
        "-v",
        is_flag=True,
        default=False,
        help="Show the full identity table with auth + config provenance.",
    )
    @click.option(
        "--resolve",
        is_flag=True,
        default=False,
        help=(
            "Open a session and report the server-resolved identity. "
            "Slower (one auth round-trip) but catches SSO / JWT / OAuth / "
            "PAT user mappings and other config-vs-server drift."
        ),
    )
    @include_in_docs
    def whoami_cmd(verbose: bool, resolve: bool) -> None:
        """Show who the active config says you are.

        Reads identity from the resolved :class:`Config` — no session,
        instant. Pass ``--resolve`` to open a session and report the
        server-resolved identity (catches SSO/JWT/OAuth user mappings;
        verbose form shows ``Config user: foo (resolved to BAR)`` on
        drift). ``--json`` / ``--output yaml`` emits a
        ``{"whoami": {...}}`` envelope with the full payload regardless
        of ``--verbose``.

        \b
        Examples:
          rai whoami
          rai whoami -v
          rai whoami --resolve
          rai whoami --json
          rai --profile dev whoami
        """
        config = runtime.load_config()

        if not resolve:
            render_whoami(config, None, verbose=verbose)
            return

        try:
            session = _open_session(config)
        except Exception as e:
            # Terse by design: point at ``rai connect`` for diagnostics
            # and at the default form for the offline answer.
            raise click.ClickException(
                f"Could not resolve identity from server: {e}\n"
                "  Drop `--resolve` for the config-only answer, or run "
                "`rai connect` for diagnostics."
            ) from e

        render_whoami(config, session, verbose=verbose)


def _open_session(config: "Config") -> Any:
    """Snowflake/Snowpark session for ``--resolve``.

    Uses ``config.get_default_connection().get_session()`` (same cheap
    path as ``rai connect``, no ``ClientSync``). Wraps cold auth in a
    spinner unless machine output is active — :func:`runtime.run_with_spinner`
    owns the gating so YAML and JSON consumers both stay spinner-free.
    """
    return runtime.run_with_spinner(
        "Resolving identity...",
        lambda: config.get_default_connection().get_session(),
    )
