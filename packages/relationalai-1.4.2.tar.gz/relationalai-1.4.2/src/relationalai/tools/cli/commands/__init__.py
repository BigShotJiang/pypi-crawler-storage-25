"""CLI command modules.

Each module defines a group of related ``@cli.command(...)`` callbacks and
exposes a ``register(cli)`` function that attaches them to the root Click
group. :func:`register_all` wires every subgroup in one call.
"""

from __future__ import annotations

import click

from . import (
    completion as completion_cmd,
    connect as connect_cmd,
    debugger as debugger_cmd,
    diagnose as diagnose_cmd,
    docs as docs_cmd,
    env_cmd,
    init as init_cmd,
    jobs as jobs_cmd,
    models as models_cmd,
    reasoners as reasoners_cmd,
    stubs as stubs_cmd,
    tree as tree_cmd,
    version as version_cmd,
    whoami as whoami_cmd,
)


def register_all(cli: click.Group) -> None:
    """Attach every command module's commands to ``cli``.

    Order matters in one place: ``env_cmd.register`` attaches its
    canonical command to the ``config`` subgroup created by
    ``init_cmd.register``, so ``init_cmd`` must run first. The
    ``env_cmd`` registration degrades gracefully if the group is
    missing, but reordering would leave ``rai config env`` quietly
    unregistered.
    """
    connect_cmd.register(cli)
    diagnose_cmd.register(cli)
    whoami_cmd.register(cli)
    init_cmd.register(cli)  # creates the `config` subgroup `env_cmd` attaches to
    reasoners_cmd.register(cli)
    jobs_cmd.register(cli)
    models_cmd.register(cli)
    docs_cmd.register(cli)
    debugger_cmd.register(cli)
    completion_cmd.register(cli)
    tree_cmd.register(cli)
    version_cmd.register(cli)
    env_cmd.register(cli)
    stubs_cmd.register(cli)


__all__ = ["register_all"]
