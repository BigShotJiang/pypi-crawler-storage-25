"""Pure-data helpers behind ``rai diagnose``.

Consumes a :class:`Config`, returns a plain dict — no Rich, no Click,
trivially unit-testable. Reuses :func:`collect_version_info` so adding
a field to ``rai version --verbose`` automatically flows into
``rai diagnose`` too.

Care is taken to keep this module's import tree free of Rich: the
upward-walk for ``raiconfig.yaml`` is delegated to
:func:`relationalai.tools.cli._paths.find_existing_yaml` (Rich-free)
rather than the same-named helper in :mod:`_init_common` (which pulls
Rich for the wizard chrome).
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

from ....config.constants import RAI_CONFIG_FILE_PATH_ENV_VAR
from .. import env as cli_env
from .._paths import find_existing_yaml
from ..connection_validation import (
    format_connection_info,
    get_connection_suggestion,
    validate_session,
)
from .version import collect_version_info

if TYPE_CHECKING:
    from relationalai.config.config import Config


# Action hint shown when no config file is found anywhere.
_NO_CONFIG_SUGGESTION: str = (
    "No config file was found in any expected location.\n\n"
    "Run `rai init` to create a `raiconfig.yaml` interactively, or set\n"
    "`RAI_CONFIG_FILE_PATH` to point at an existing config file.\n\n"
    "See https://docs.relational.ai/config for examples."
)

# Action hint shown when the config file *was* found but failed schema
# validation (missing required field, bad type, etc.). Single source of
# truth so the yellow human panel and the JSON envelope agree.
_INVALID_CONFIG_SUGGESTION: str = (
    "Your config file was found but failed validation. Open the file shown\n"
    "under \"Config file\" above, fix the field(s) listed under \"Validation\n"
    "errors\", and re-run `rai diagnose`.\n\n"
    "If you'd rather start fresh, `rai init` will write a new `raiconfig.yaml`\n"
    "in the current directory and `RAI_CONFIG_FILE_PATH` can point at it.\n\n"
    "See https://docs.relational.ai/config for examples."
)

# Generic catch-all suggestion for unexpected config load failures
# (e.g. permission errors, malformed YAML that escapes the wizard).
_GENERIC_LOAD_FAILURE_SUGGESTION: str = (
    "Configuration could not be loaded. See the error message above.\n\n"
    "Run `rai init` to create a fresh `raiconfig.yaml`, or set\n"
    "`RAI_CONFIG_FILE_PATH` to point at a known-good config file."
)


# Env vars that influence which config / profile gets loaded. Derived
# from the central registry (entries tagged ``"rai diagnose"``) so adding
# a new var on this surface is a single line in :mod:`env` rather than
# coordinated edits across modules; previously this list was a hand-
# maintained copy of a slice of :data:`KNOWN_ENV_VARS` and the two drifted.
# The order is the registry's declaration order ("what users typically
# need to see first when debugging" — output prefs, then identity, then
# discovery, then runtime gates).
_DIAGNOSE_ENV_VARS: tuple[str, ...] = tuple(
    var.name for var in cli_env.iter_for_surface(cli_env.SURFACE_DIAGNOSE)
)


# Connectivity-block shape for the ``--no-connect`` path. Defined once so
# the renderer, JSON consumers, and the collector can't drift on fields.
_SKIPPED_CONNECTIVITY: dict[str, Any] = {
    "checked": False,
    "ok": None,
    "error": None,
    "suggestion": None,
}


def _failed_connectivity(error: str) -> dict[str, Any]:
    """Connectivity-block shape for a failed probe (single source of truth)."""
    return {
        "checked": True,
        "ok": False,
        "error": error,
        "suggestion": get_connection_suggestion(error),
    }


def _read_config_source(config: "Config") -> str | None:
    """Return the ``source`` discriminator of the loaded config (e.g. ``"rai"``).

    Reads the field default to match the pattern in :func:`show_connect_panel`
    and to stay safe if a future config subclass omits the instance attr.
    """
    source_field = type(config).model_fields.get("source")
    if source_field is None:
        return None
    default = source_field.default
    return str(default) if default is not None else None


def _resolve_config_file_path(source: str | None) -> str | None:
    """Re-run :func:`_load_config`'s file-discovery to surface the resolved path.

    ``source`` constrains the lookup so a workspace with both a stray
    ``~/.dbt/profiles.yml`` and a ``raiconfig.yaml`` doesn't mis-attribute
    the path. Re-running here (rather than threading state onto
    :class:`Config`) keeps the model untouched; the result is purely
    diagnostic. Returns ``None`` for the active-session case.
    """
    env_override = os.environ.get(RAI_CONFIG_FILE_PATH_ENV_VAR)
    if env_override:
        return env_override

    if source in (None, "active_session"):
        return None

    if source == "rai":
        # Single source of truth in :mod:`_paths` (Rich-free), shared
        # with the wizard via :func:`_init_common.find_existing_yaml`'s
        # re-export.
        found = find_existing_yaml()
        return str(found) if found is not None else None

    if source == "raiconfig_toml":
        from ....config.external.utils import find_raiconfig_toml_file

        return find_raiconfig_toml_file()

    if source == "snowflake":
        from ....config.external.utils import find_snowflake_config_file

        return find_snowflake_config_file()

    if source == "dbt":
        from ....config.external.utils import find_dbt_profiles_file

        return find_dbt_profiles_file()

    return None


def _collect_env(env_var_names: tuple[str, ...] = _DIAGNOSE_ENV_VARS) -> dict[str, str | None]:
    """Snapshot the relevant env vars (``None`` when unset)."""
    out: dict[str, str | None] = {}
    for name in env_var_names:
        raw = os.environ.get(name)
        out[name] = raw if raw not in (None, "") else None
    return out


def _collect_connection(config: "Config") -> dict[str, Any]:
    """Resolve the default connection to a flat dict; never raises.

    On failure returns ``{"name": ..., "fields": {}, "error": "..."}`` so
    diagnose still prints the rest of the output before surfacing the
    issue.
    """
    try:
        connection = config.get_default_connection()
    except Exception as e:
        return {"name": config.default_connection, "fields": {}, "error": str(e)}

    fields: dict[str, str] = {}
    for label, value in format_connection_info(connection):
        fields[label.lower()] = value
    return {"name": config.default_connection, "fields": fields, "error": None}


def _check_connectivity(config: "Config") -> dict[str, Any]:
    """Run the same ``select 1`` probe ``rai connect`` runs; return structured data."""
    try:
        connection = config.get_default_connection()
    except Exception as e:
        return _failed_connectivity(str(e))

    try:
        session = connection.get_session()
        warehouse = getattr(connection, "warehouse", None)
        validate_session(session, warehouse=warehouse)
    except Exception as e:
        return _failed_connectivity(str(e))

    return {"checked": True, "ok": True, "error": None, "suggestion": None}


def collect_diagnose_info(
    config: "Config",
    *,
    with_connectivity: bool,
) -> dict[str, Any]:
    """Build the full diagnose payload (public contract for ``--json``).

    Add new fields rather than reshaping existing ones so scripts reading
    ``rai diagnose --json`` keep working.
    """
    source = _read_config_source(config)
    config_file = _resolve_config_file_path(source)

    payload: dict[str, Any] = {
        "version": collect_version_info(),
        "config": {
            "found": True,
            "source": source,
            "file_path": config_file,
            "active_profile": config.active_profile,
            "default_connection": config.default_connection,
            "direct_access": config.direct_access,
            "env": _collect_env(),
            "attempted_sources": [],
        },
        "connection": _collect_connection(config),
        "connectivity": (
            _check_connectivity(config)
            if with_connectivity
            else dict(_SKIPPED_CONNECTIVITY)
        ),
    }
    return payload


def _format_attempted_sources(error: BaseException | None) -> list[dict[str, str | None]]:
    """Render ``ConfigFileNotFoundError.attempted_sources`` as a JSON-friendly list."""
    out: list[dict[str, str | None]] = []
    for src in getattr(error, "attempted_sources", None) or []:
        out.append(
            {
                "source_name": getattr(src, "source_name", None),
                "error_message": getattr(src, "error_message", None),
                "file_path": (
                    str(getattr(src, "file_path", "") or "") or None
                ),
            }
        )
    return out


def _format_validation_errors(error: BaseException | None) -> list[dict[str, Any]]:
    """Render ``ConfigValidationError.pydantic_errors`` as a JSON-friendly list.

    Pydantic emits ``loc`` as a tuple, which doesn't round-trip through
    JSON cleanly; flatten it to a dotted-path string so consumers can
    grep / display it without unpacking. ``type`` and ``msg`` come
    through verbatim.
    """
    out: list[dict[str, Any]] = []
    for pyd_err in getattr(error, "pydantic_errors", None) or []:
        loc_parts = pyd_err.get("loc", []) if isinstance(pyd_err, dict) else []
        out.append(
            {
                "loc": " → ".join(str(part) for part in loc_parts),
                "msg": pyd_err.get("msg", "") if isinstance(pyd_err, dict) else "",
                "type": pyd_err.get("type", "") if isinstance(pyd_err, dict) else "",
            }
        )
    return out


def _build_load_error_block(error: BaseException | None) -> dict[str, Any]:
    """Build the ``config.load_error`` sub-envelope; uniform shape across error types.

    Every key is always present so JSON consumers can assume the shape
    and only branch on ``type`` when they want type-specific details.
    The empty-by-default lists ``attempted_sources`` /
    ``validation_errors`` only carry data for the error types that
    actually populate them.
    """
    from ....config.errors import ConfigFileNotFoundError, ConfigValidationError

    block: dict[str, Any] = {
        "type": type(error).__name__ if error is not None else "Exception",
        "message": str(getattr(error, "message", None) or error or "Configuration could not be loaded"),
        "file_path": None,
        "location": None,
        "attempted_sources": [],
        "validation_errors": [],
    }

    if isinstance(error, ConfigFileNotFoundError):
        block["attempted_sources"] = _format_attempted_sources(error)
        return block

    if isinstance(error, ConfigValidationError):
        block["validation_errors"] = _format_validation_errors(error)
        ctx = getattr(error, "context", None)
        if ctx is not None:
            try:
                block["location"] = ctx.format_location()
            except Exception:
                pass
            file_path = getattr(ctx, "file_path", None)
            if file_path is not None:
                block["file_path"] = str(file_path)
        return block

    return block


def _suggestion_for(error: BaseException | None) -> str:
    """Pick the right action hint for the load-error type."""
    from ....config.errors import ConfigFileNotFoundError, ConfigValidationError

    if isinstance(error, ConfigFileNotFoundError):
        return _NO_CONFIG_SUGGESTION
    if isinstance(error, ConfigValidationError):
        return _INVALID_CONFIG_SUGGESTION
    return _GENERIC_LOAD_FAILURE_SUGGESTION


def _connectivity_error_for(error: BaseException | None) -> str:
    """Short label used in ``connectivity.error`` (kept terse for log scrapers)."""
    from ....config.errors import ConfigFileNotFoundError, ConfigValidationError

    if isinstance(error, ConfigFileNotFoundError):
        return "No config file found"
    if isinstance(error, ConfigValidationError):
        return "Config validation failed"
    return "Config could not be loaded"


def collect_diagnose_info_load_failed(
    error: BaseException | None,
) -> dict[str, Any]:
    """Build the diagnose payload when ``runtime.load_config`` failed.

    Single entry point for every kind of config-load failure
    (``ConfigFileNotFoundError``, ``ConfigValidationError``, anything
    else). Mirrors :func:`collect_diagnose_info`'s envelope shape so
    script consumers can always parse ``rai diagnose --json``;
    ``config.found`` and ``config.load_error.type`` discriminate.

    The Tooling block (``version``) is always populated since it
    doesn't depend on a working config — that's the "paste this into
    bug reports" payoff. ``connection`` is ``null`` because there's
    nothing to resolve, and ``connectivity.suggestion`` carries the
    actionable hint appropriate to the error type.
    """
    load_error = _build_load_error_block(error)

    # Surface the file path at the top of the config block too — it's
    # what users grep / click in editors first, and we want it visible
    # without having to unpack ``load_error``.
    file_path = load_error.get("file_path")

    return {
        "version": collect_version_info(),
        "config": {
            "found": False,
            "source": None,
            "file_path": file_path,
            "active_profile": None,
            "default_connection": None,
            "direct_access": False,
            "env": _collect_env(),
            "load_error": load_error,
        },
        "connection": None,
        "connectivity": {
            "checked": False,
            "ok": False,
            "error": _connectivity_error_for(error),
            "suggestion": _suggestion_for(error),
        },
    }


__all__ = [
    "collect_diagnose_info",
    "collect_diagnose_info_load_failed",
    # Re-exported for tests; keeps the public surface explicit.
    "_DIAGNOSE_ENV_VARS",
    "_NO_CONFIG_SUGGESTION",
    "_INVALID_CONFIG_SUGGESTION",
    "_GENERIC_LOAD_FAILURE_SUGGESTION",
    "_resolve_config_file_path",
]
