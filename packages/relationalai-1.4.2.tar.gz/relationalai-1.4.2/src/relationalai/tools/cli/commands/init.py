"""``rai init`` and the ``rai config`` subgroup (currently just ``explain``)."""

from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path
from typing import Any

import click
import yaml
from rich.table import Table

from ....util.docutils import include_in_docs
from .. import env as cli_env
from .. import runtime
from .._group import RaiSubGroup
from ._common import add_colon_alias

# Env vars that shadow the YAML active_profile at runtime. Derived from
# the central registry (entries tagged ``"rai config use"``) so the
# AliasChoices set on ``BaseConfig.active_profile`` (in
# ``src/relationalai/config/config.py``) only needs to be mirrored in
# one place — :data:`relationalai.tools.cli.env.KNOWN_ENV_VARS` — rather
# than re-declared here. ``RAI_PROFILE`` is additionally wired to the
# ``--profile`` flag in :mod:`cli`.
_ACTIVE_PROFILE_ENV_VARS: tuple[str, ...] = tuple(
    var.name for var in cli_env.iter_for_surface(cli_env.SURFACE_CONFIG_USE)
)


def _load_raiconfig_yaml() -> tuple[Path, dict[str, Any]]:
    """Load the discovered YAML config file without validating connections."""
    from .._init_common import find_existing_yaml

    path = find_existing_yaml()
    if path is None:
        runtime.raise_missing_config_discovery_error()

    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise click.ClickException(f"{path} must contain a YAML mapping at the top level.")
    return path, data


def _profile_blocks(data: dict[str, Any]) -> dict[str, Any]:
    # Match confocal.utils.overlay_profile precedence: plural first, fall back
    # to singular. Keeps CLI display in sync with the keys the runtime overlays.
    profiles = data.get("profiles") or data.get("profile", {})
    if profiles is None:
        return {}
    if not isinstance(profiles, dict):
        raise click.ClickException(
            "Config field `profile`/`profiles` must be a mapping of profile names."
        )
    return profiles


def _active_profile(data: dict[str, Any]) -> str | None:
    # Mirror confocal.utils.overlay_profile: --profile/RAI_PROFILE first, then
    # YAML active_profile. We deliberately do not auto-default to a single
    # profile — the runtime does not, and silent CLI-only defaulting hides that.
    rt = runtime.get_runtime()
    if rt.profile:
        return rt.profile
    active = data.get("active_profile")
    if isinstance(active, str) and active.strip():
        return active.strip()
    return None


def _active_profile_env_override() -> tuple[str, str] | None:
    """Return ``(env_var, value)`` of the first env var that shadows YAML active_profile."""
    for var in _ACTIVE_PROFILE_ENV_VARS:
        value = os.environ.get(var, "").strip()
        if value:
            return var, value
    return None


def _config_path_in_cwd(path: Path) -> bool:
    """Return True if ``path`` lives in the current working directory."""
    try:
        return path.parent.resolve() == Path.cwd().resolve()
    except OSError:
        return False


def _profile_default_connection(profile_data: Any) -> str:
    if not isinstance(profile_data, dict):
        return ""
    value = profile_data.get("default_connection")
    return str(value) if value is not None else ""


def _yaml_scalar(value: str) -> str:
    """Serialize a scalar for inline YAML assignment."""
    lines = yaml.safe_dump(value, default_flow_style=True, explicit_end=False).splitlines()
    if lines and lines[-1] == "...":
        lines.pop()
    return "\n".join(lines).strip()


def _atomic_write_text(path: Path, text: str) -> None:
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as fh:
            tmp_path = Path(fh.name)
            fh.write(text)
        tmp_path.replace(path)
    finally:
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()


def _write_active_profile(path: Path, profile: str) -> None:
    """Set the top-level active_profile while preserving the rest of the file."""
    text = path.read_text(encoding="utf-8")
    replacement = f"active_profile: {_yaml_scalar(profile)}"
    new_text, count = re.subn(
        r"(?m)^active_profile\s*:\s*.*$",
        replacement,
        text,
        count=1,
    )
    if count == 0:
        new_text = f"{replacement}\n{text}" if text else f"{replacement}\n"
    _atomic_write_text(path, new_text)


def register(cli: click.Group) -> None:
    @cli.command()
    @click.option("--migrate", is_flag=True, default=False, help="Migrate raiconfig.toml to raiconfig.yaml immediately.")
    @click.option(
        "--install-mode",
        "install_mode",
        is_flag=True,
        default=False,
        hidden=True,
        help="Scaffold a new install-mode starter project.",
    )
    @include_in_docs
    def init(migrate: bool, install_mode: bool) -> None:
        """Create or validate raiconfig.yaml."""
        if install_mode:
            from ..install_init_wizard import run_install_wizard
            run_install_wizard()
            return
        from ..init_wizard import run_init_wizard
        run_init_wizard(migrate=migrate)

    @cli.group(name="config", cls=RaiSubGroup)
    def config_group() -> None:
        """Inspect and manage CLI configuration."""

    @config_group.command(name="explain", short_help="Show the active config and provenance.")
    @click.option("--verbose", "-v", is_flag=True, default=False, help="Show full provenance details.")
    @include_in_docs
    def config_explain(verbose: bool) -> None:
        """Show the active config and where each value comes from."""
        from ..init_wizard import run_explain
        config = runtime.load_config()
        run_explain(config, verbose=verbose)

    add_colon_alias(
        root=cli, canonical=config_explain,
        colon_name="config:explain", space_name="config explain",
    )

    @config_group.command(name="profiles", short_help="List profiles in raiconfig.yaml.")
    @include_in_docs
    def config_profiles() -> None:
        """List profiles in the active raiconfig.yaml/raiconfig.yml file."""
        path, data = _load_raiconfig_yaml()
        profiles = _profile_blocks(data)
        active = _active_profile(data)

        if not profiles:
            runtime.console.print(f"[yellow]No profiles found in {path}.[/yellow]")
            return

        if active is not None:
            runtime.console.print(f"Active profile: [bold green]{active}[/bold green]")

        table = Table(show_header=True, header_style="bold", border_style="dim")
        table.add_column("Current")
        table.add_column("Profile")
        table.add_column("Default Connection")

        for name in sorted(profiles):
            marker = "[green]→[/green]" if name == active else ""
            table.add_row(marker, str(name), _profile_default_connection(profiles[name]))

        runtime.console.print(table)
        runtime.console.print(f"[dim]Config: {path}[/dim]")
        if runtime.get_runtime().profile:
            runtime.console.print("[dim]Active profile is overridden for this invocation by --profile/RAI_PROFILE.[/dim]")

    @config_group.command(name="current", short_help="Show the active profile.")
    @include_in_docs
    def config_current() -> None:
        """Show the profile selected for this invocation."""
        path, data = _load_raiconfig_yaml()
        profiles = _profile_blocks(data)
        active = _active_profile(data)
        if active is None:
            if not profiles:
                raise click.ClickException(
                    f"No profiles found in {path}. Add a `profile:` block or run `rai init` to create one."
                )
            available = ", ".join(sorted(profiles)) or "none"
            raise click.ClickException(
                "No active profile is set and more than one profile is available. "
                f"Run `rai config use <profile>` or pass `--profile`. Available profiles: {available}"
            )

        runtime.console.print(f"[bold green]{active}[/bold green]")
        runtime.console.print(f"[dim]Config: {path}[/dim]")
        if runtime.get_runtime().profile:
            runtime.console.print("[dim]Source: --profile/RAI_PROFILE override[/dim]")
        else:
            runtime.console.print("[dim]Source: active_profile in config[/dim]")

    @config_group.command(name="use", short_help="Set the active profile.")
    @click.argument("profile", required=False)
    @click.option(
        "--yes",
        "-y",
        "assume_yes",
        is_flag=True,
        default=False,
        help="Skip confirmation prompts (e.g. when modifying a raiconfig.yaml outside the current directory).",
    )
    @include_in_docs
    def config_use(profile: str | None, assume_yes: bool) -> None:
        """Persistently set active_profile in raiconfig.yaml.

        Omit PROFILE when stdin is a TTY to choose interactively from the profile
        names in the config. In non-interactive use (pipes, CI), pass the name
        explicitly.
        """
        path, data = _load_raiconfig_yaml()
        profiles = _profile_blocks(data)
        if profile is None and not profiles:
            raise click.ClickException(
                f"No profiles found in {path}. Add a `profile:` block or run `rai init` to create one."
            )

        if profile is None:
            if runtime.is_interactive():
                from ..components import SelectOption, fuzzy_select

                sorted_names = sorted(profiles)
                opts: list[SelectOption] = []
                for name in sorted_names:
                    conn = _profile_default_connection(profiles[name])
                    label = f"{name} — {conn}" if conn.strip() else str(name)
                    opts.append(SelectOption(value=name, label=label))
                current = _active_profile(data)
                default = current if isinstance(current, str) and current in profiles else sorted_names[0]
                resolved = fuzzy_select("Select profile:", opts, default=default)
                profile = str(resolved)
            else:
                available = ", ".join(sorted(profiles)) or "none"
                raise click.ClickException(
                    "Profile name required when not running interactively. "
                    f"Run `rai config use <profile>`. Available profiles: {available}"
                )

        if profile not in profiles:
            available = ", ".join(sorted(profiles)) or "none"
            raise click.ClickException(
                f"Profile '{profile}' not found in {path}. Available profiles: {available}"
            )

        # Confirm before modifying a raiconfig.yaml outside the current directory.
        # ``find_existing_yaml`` walks upward from cwd, so the discovered file may
        # belong to a parent project rather than the one the user is iterating on.
        if not _config_path_in_cwd(path):
            if assume_yes:
                pass
            elif runtime.is_interactive():
                click.confirm(
                    f"{path} is not in the current directory. Modify it?",
                    abort=True,
                )
            else:
                raise click.ClickException(
                    f"Refusing to modify {path}: it is outside the current directory. "
                    "Re-run with --yes to confirm."
                )

        _write_active_profile(path, profile)
        runtime.console.print(f"[green]✓[/green] Active profile set to [bold green]{profile}[/bold green]")
        runtime.console.print(f"[dim]Updated {path}[/dim]")

        # Warn when a higher-precedence env var would shadow the just-written
        # YAML value at runtime, otherwise `rai config current` (and downstream
        # commands) will silently keep using the env-var profile.
        override = _active_profile_env_override()
        if override is not None:
            var, value = override
            if value != profile:
                runtime.console.print(
                    f"[yellow]Warning:[/yellow] {var}=[bold]{value}[/bold] is set in the environment "
                    f"and overrides active_profile from {path}."
                )
                runtime.console.print(
                    f"[dim]Run `unset {var}` (or change it) to use [bold]{profile}[/bold] from the config file.[/dim]"
                )
