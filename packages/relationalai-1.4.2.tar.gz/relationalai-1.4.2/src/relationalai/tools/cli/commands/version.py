"""``rai version`` (and the ``--version`` flag) — print version + runtime info.

Both entry points share :func:`render_version` so they cannot drift, matching
the industry idiom (git, cargo, terraform, stripe, databricks).
"""

from __future__ import annotations

import platform
import sys
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path
from typing import Any

import click
from rich.table import Table
from rich.text import Text

from ....util.docutils import include_in_docs
from .. import runtime, update_check

# Filename written by ``scripts/sync_vendor.py`` next to ``v0/relationalai``.
_UPSTREAM_FILENAME = "UPSTREAM.txt"

# RAI-authored runtime libs whose versions commonly explain backend behavior
# shifts; surfaced in the version block so bug reports include them by default.
# Resolved via ``importlib.metadata.version`` (reads ``.dist-info`` off disk
# without importing the package — keeps ``rai version`` cheap).
_RAI_DEP_PACKAGES: tuple[str, ...] = ("lqp", "confocal")


def _resolve_dep_versions() -> dict[str, str]:
    """Map :data:`_RAI_DEP_PACKAGES` → version string (``"not installed"`` if missing)."""
    out: dict[str, str] = {}
    for name in _RAI_DEP_PACKAGES:
        try:
            out[name] = _pkg_version(name)
        except PackageNotFoundError:
            out[name] = "not installed"
    return out


def _resolve_upstream_info() -> dict[str, str] | None:
    """Parse ``v0/relationalai/UPSTREAM.txt`` (vendor metadata); ``None`` when absent.

    Avoids importing the ``v0.relationalai`` tree (which drags in snowflake,
    OTEL, cryptography, InquirerPy — ~670ms of cold-start cost) by deriving
    the path from the already-loaded ``relationalai`` package.
    """
    try:
        import relationalai  # already in sys.modules; no import cost

        raw = getattr(relationalai, "__file__", "") or ""
        if not raw:
            return None
        rai_pkg_dir = Path(raw).resolve().parent
        upstream = rai_pkg_dir.parent / "v0" / "relationalai" / _UPSTREAM_FILENAME
        if not upstream.is_file():
            return None
        out: dict[str, str] = {}
        for line in upstream.read_text(encoding="utf-8").splitlines():
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            if key:
                out[key] = value.strip()
        return out or None
    except Exception:
        return None


def _format_upstream_value(upstream: dict[str, str] | None) -> str:
    """Render upstream info as ``<ref> (<commit>)`` with graceful fallbacks."""
    if not upstream:
        return "not vendored"
    ref = upstream.get("ref", "").strip()
    commit = upstream.get("commit", "").strip()
    local_dir = upstream.get("local_dir", "").strip()
    if ref and commit:
        return f"{ref} ({commit})"
    if ref:
        return ref
    if commit:
        return commit
    if local_dir:
        return f"local: {local_dir}"
    return "not vendored"


def _resolve_install_path() -> str:
    """Directory holding the installed ``relationalai`` package, or ``"unknown"``."""
    try:
        import relationalai

        raw = getattr(relationalai, "__file__", "") or ""
        if not raw:
            return "unknown"
        path = Path(raw).resolve()
        if path.name == "__init__.py":
            return str(path.parent)
        return str(path)
    except Exception:
        return "unknown"


def collect_version_info() -> dict[str, Any]:
    """Build the version payload (shared by human renderer and JSON/YAML emitters)."""
    try:
        installed = _pkg_version("relationalai")
    except PackageNotFoundError:
        installed = "unknown"

    return {
        "version": installed,
        "python": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "system": platform.system(),
        "machine": platform.machine(),
        "install_path": _resolve_install_path(),
        "executable": sys.executable,
        "upstream": _resolve_upstream_info(),
        "dependencies": _resolve_dep_versions(),
    }


def _render_human_short(info: dict[str, Any]) -> None:
    """Render the terse one-liner: ``rai <version>``.

    Mirrors the default form used by ``cargo``, ``git``, ``gh``, ``stripe``,
    ``python``, and ``node``. The verbose block (RAI components + diagnostics)
    is gated behind ``--verbose`` / ``-v``.
    """
    runtime.console.print(
        Text.assemble(
            ("rai", "bold white"),
            " ",
            (str(info["version"]), "bold white"),
        )
    )


def _render_human(info: dict[str, Any]) -> None:
    """Render a single three-section Rich table: headline / RAI components / diagnostics."""
    upstream = info.get("upstream")
    upstream_dict = upstream if isinstance(upstream, dict) else None
    deps = info.get("dependencies") or {}

    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
    table.add_column(style="dim cyan", no_wrap=True)
    table.add_column(style="white")

    # ``not dim`` overrides the column's ``dim cyan`` for the headline so the
    # ``rai`` row renders as bold-white instead of bold-but-dim. Honors
    # ``--no-color`` automatically (Rich drops styling on non-color consoles).
    table.add_row(
        Text("rai", style="bold white not dim"),
        Text(str(info["version"]), style="bold white not dim"),
    )
    table.add_row("", "")

    table.add_row("relationalai-python", _format_upstream_value(upstream_dict))
    for name in _RAI_DEP_PACKAGES:
        table.add_row(name, str(deps.get(name, "not installed")))
    table.add_row("", "")

    table.add_row("Python", f"{info['python']} ({info['python_implementation']})")
    table.add_row("Platform", str(info["platform"]))
    table.add_row("Install path", str(info["install_path"]))
    table.add_row("Executable", str(info["executable"]))
    runtime.console.print(table)


# Re-export for backward compat with the import from ``cli.py`` and any
# downstream test that patched the symbol in this module.
maybe_render_upgrade_panel_sync = update_check.maybe_render_upgrade_panel_sync


def render_version(verbose: bool = False) -> None:
    """Public entry point shared by ``rai version`` and ``rai --version``.

    By default emits the terse ``rai <version>`` one-liner (matches the default
    ``--version`` form used by ``cargo``, ``git``, ``gh``, ``stripe``, ``python``,
    ``node``). Pass ``verbose=True`` to render the full diagnostics block
    (RAI components, Python runtime, install path, executable).

    Machine-readable output (``--json`` / ``--output yaml``) is unaffected by
    ``verbose``: scripts always receive the full payload so they don't have to
    re-invoke with a different flag to get the data they need.

    This function does NOT render the "Update available" panel. Why: the
    standard subcommand path (``rai version``) already runs through the root
    ``cli()``'s ``ctx.call_on_close(maybe_print_notice)`` hook, so the panel
    gets rendered there once on exit. Rendering it here too would print it
    twice. The eager ``--version`` flag path bypasses ``cli()``'s body and
    therefore wires :func:`maybe_render_upgrade_panel_sync` itself.
    """
    info = collect_version_info()

    if runtime.emit_cli_result("version", info):
        return

    if verbose:
        _render_human(info)
    else:
        _render_human_short(info)


def register(cli: click.Group) -> None:
    """Attach the ``version`` subcommand."""

    @cli.command(name="version")
    @click.option(
        "--verbose",
        "-v",
        is_flag=True,
        default=False,
        help="Show Python runtime, install path, and dependency versions.",
    )
    @include_in_docs
    def version_cmd(verbose: bool) -> None:
        """Show the installed ``rai`` version.

        By default prints the terse ``rai <version>`` one-liner — the same
        thing ``rai --version`` shows. Pass ``--verbose`` / ``-v`` for the
        full diagnostics block (RAI components, Python runtime, install path,
        executable) suitable for bug reports.

        Honors ``--json`` / ``--output yaml`` to emit a ``{"version": {...}}``
        envelope for scripts; machine-readable output always includes the
        full payload regardless of ``--verbose``.

        \b
        Examples:
          rai version
          rai version --verbose
          rai version -v
          rai version --output json
          rai --output yaml version
        """
        render_version(verbose=verbose)
