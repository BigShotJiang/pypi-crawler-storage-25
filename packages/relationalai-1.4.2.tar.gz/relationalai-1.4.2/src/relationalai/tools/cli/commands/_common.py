"""Shared option decorators and small helpers used across command modules."""

from __future__ import annotations

import sys
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, TypeVar, cast

import click

if TYPE_CHECKING:
    from ..error_handlers import CliErrorParams

from .. import env, runtime

F = TypeVar("F", bound=Callable[..., Any])

_STUBS_ENV = "RAI_CLI_ENABLE_STUBS"

# Target release communicated to users when colon aliases (``jobs:list``, …)
# rotate out. Messaging intentionally avoids an absolute promise — bump this
# when the roadmap moves; tests pin only the substring "deprecated".
_COLON_ALIAS_REMOVAL_VERSION = "2.0"

# Env vars that suppress the deprecation hint for colon-style aliases.
# Anything truthy here counts as "non-interactive automation" — the hint
# would be useless noise in CI/build logs and could trip strict-stderr
# parsers in pipelines. The CI-detection portion is *sourced* from
# :data:`env.CI_ENV_VARS` so the two suppression surfaces (PyPI update
# check, colon-alias deprecation) share one canonical CI definition;
# a previous version of this module duplicated the list and the two
# drifted apart. The deprecation-specific opt-out
# (``RAI_NO_DEPRECATION_NOTICE``) is appended on top because it controls
# this hint specifically, distinct from ``RAI_NO_UPDATE_CHECK``.
def _deprecation_suppress_envs() -> tuple[str, ...]:
    """Return the CI/automation env-var allowlist for hint suppression.

    Resolved at call time (not at import) so tests that monkeypatch the
    canonical CI list see the change without a module reload.
    """
    return (*env.CI_ENV_VARS, "RAI_NO_DEPRECATION_NOTICE")


# Kept as a module attribute so existing tests that introspect it (and
# any future callers that want a stable name) keep working. It's a
# snapshot at import time; runtime suppression goes through
# :func:`_deprecation_suppress_envs` for fresh resolution.
_DEPRECATION_SUPPRESS_ENVS = _deprecation_suppress_envs()


def stubs_enabled() -> bool:
    """Return True when ``RAI_CLI_ENABLE_STUBS`` is set to a truthy value.

    Used by :mod:`commands.stubs` (analyze/build/deploy/explore/test/clean)
    to gate not-yet-implemented placeholder commands so they don't show up
    in help (or auto-generated docs) by default and can't be relied on in
    tests. Exposed at this level so other command modules can adopt the
    same gating convention if/when they grow placeholders.

    Truthiness is delegated to :func:`env.read_bool` so every env-var
    gate in the CLI shares one canonical falsy set
    (``"" | "0" | "false" | "no" | "off"``); without this delegation
    ``RAI_CLI_ENABLE_STUBS=off`` quietly behaved as *enabled* here while
    behaving as *disabled* in the env registry, which is exactly the
    kind of inconsistency users hit when copy-pasting between flags.
    """
    return env.read_bool(_STUBS_ENV)


def wait_options(*, default_timeout_s: int = 900) -> Callable[[F], F]:
    """Attach ``--wait`` and ``--timeout-s`` options to a command."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--timeout-s",
            type=int,
            default=default_timeout_s,
            show_default=True,
            help="Timeout in seconds while waiting until the reasoner is READY (used with --wait).",
        )(cmd)
        cmd = click.option(
            "--wait/--no-wait",
            default=False,
            show_default=True,
            help="Wait until the reasoner is READY before returning.",
        )(cmd)
        return cmd

    return decorator


def job_wait_options(*, default_timeout_s: float = 900.0, default_poll_s: float = 0.5) -> Callable[[F], F]:
    """``--timeout-s`` + ``--poll-interval-s`` options for job wait-style commands."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--poll-interval-s",
            type=float,
            default=default_poll_s,
            show_default=True,
            help="Polling interval in seconds while waiting until the job reaches a terminal state.",
        )(cmd)
        cmd = click.option(
            "--timeout-s",
            type=float,
            default=default_timeout_s,
            show_default=True,
            help="Timeout in seconds while waiting until the job reaches a terminal state.",
        )(cmd)
        return cmd

    return decorator


def pagination_options(
    *,
    default_limit: int = 100,
    limit_help: str = "Maximum results to display (must be >= 1).",
    offset_help: str = "Number of results to skip.",
) -> Callable[[F], F]:
    """Attach ``--limit`` and ``--offset`` options to a list command.

    Every ``list`` verb (jobs, reasoners, models, …) repeats the same
    ``IntRange(min=1)`` / ``IntRange(min=0)`` pair with identical help
    text; factor it out so changes (e.g. raising the default limit,
    adopting cursor-style ``--after``) flow through one place.

    The new options bind to the standard kwarg names ``limit`` and
    ``offset``. ``default_limit`` must be ``>= 1`` to satisfy the
    ``IntRange(min=1)`` constraint — passing ``0`` or a negative value
    would make Click reject every invocation that relied on the default,
    so we fail fast at decoration time with a clear ``ValueError`` rather
    than letting the bug surface as a confusing user-facing message.
    """

    if default_limit < 1:
        raise ValueError(
            f"pagination_options(default_limit=...) must be >= 1 to satisfy "
            f"IntRange(min=1); got {default_limit!r}."
        )

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--offset",
            type=click.IntRange(min=0),
            default=0,
            show_default=True,
            help=offset_help,
        )(cmd)
        cmd = click.option(
            "--limit",
            type=click.IntRange(min=1),
            default=default_limit,
            show_default=True,
            help=limit_help,
        )(cmd)
        return cmd

    return decorator


def job_options_type_id(
    *,
    type_required: bool = False,
    id_required: bool = False,
) -> Callable[[F], F]:
    """``--type`` + ``--id`` options shared by every jobs command."""

    def decorator(cmd: F) -> F:
        cmd = click.option(
            "--id",
            "job_id",
            required=id_required,
            default=None,
            help="Job id." if id_required else "Job id (optional).",
        )(cmd)
        cmd = click.option(
            "--type",
            "job_type",
            required=type_required,
            default=None,
            help="Job type (Logic/Prescriptive/Predictive)." + ("" if type_required else " (optional)"),
        )(cmd)
        return cmd

    return decorator


# ── Reusable params() functions for ``handle_cli_errors`` ────────────────────


def select_params(
    *keys: str,
    **aliases: str,
) -> Callable[..., "CliErrorParams"]:
    """Build a ``params=`` callback that picks ``kwargs`` values into a fixed dict.

    Each positional ``key`` is copied verbatim; each ``alias=src`` entry maps
    ``kwargs[src]`` to the output key ``alias`` (used to expose
    ``job_type`` as ``reasoner_type`` in error context).

    Return type is :class:`CliErrorParams` (a ``TypedDict`` over the
    canonical keys) so pyright catches typos at the call site. ``keys``
    and ``aliases`` themselves stay ``str`` rather than a ``Literal``
    union — Click's option names are the source of truth for which
    kwargs names exist, and we don't want to mirror every option name
    into the type signature.
    """
    def _extract(**kwargs: Any) -> "CliErrorParams":
        out: dict[str, Any] = {k: kwargs.get(k) for k in keys}
        out.update({dst: kwargs.get(src) for dst, src in aliases.items()})
        return cast("CliErrorParams", out)

    return _extract


# Pre-built selectors used by command modules; keep the names stable so
# renames of a command's kwargs break loudly.
params_reasoner_type_name = select_params("reasoner_type", "reasoner_name")
params_reasoner_type_name_size = select_params("reasoner_type", "reasoner_name", "reasoner_size")
params_reasoner_type_name_auto_suspend = select_params(
    "reasoner_type", "reasoner_name", "auto_suspend_mins"
)
params_job_type_id = select_params("job_type", "job_id")
params_jobs_list = select_params(
    "job_id", "state", "name", "created_by", reasoner_type="job_type"
)
params_job_events = select_params("job_type", "job_id", "stream_name")


# ── Backward-compat colon aliases ────────────────────────────────────────
#
# Migration from ``rai noun:verb`` to ``rai noun verb`` (subgroup style).
# Existing scripts still need to work, so we expose every legacy colon
# name as a hidden alias that dispatches to the canonical command after
# printing a one-line deprecation hint to stderr.


def _emit_colon_deprecation(*, colon_name: str, space_name: str) -> None:
    """Warn on stderr that the colon form is deprecated.

    Fires on every alias invocation in the current process when none of
    the suppression gates match. Each ``rai`` invocation is its own
    process, so in practice that's "once per command" already; we
    intentionally don't add a per-process "I already warned" flag
    because the only realistic intra-process repeat path is the test
    suite, where seeing the panel each time is the point.

    Suppressed under any of:

    - machine-readable output (``--json`` / ``--output json`` /
      ``--output yaml`` — never inject prose into output)
    - stderr is not a TTY (would pollute redirected logs)
    - any of the CI / suppression env vars in
      :data:`_DEPRECATION_SUPPRESS_ENVS` is set to a truthy value

    The hint is the single user-facing payoff of the alias: removing it
    would leave the colon form silently working and migrations would never
    happen. Keeping it loud-but-suppressible is the point.

    Rendered as a Rich panel (matching the ``Update available`` notice in
    :mod:`update_check`) so the visual contract for "advisory stderr
    messages bracketing command output" stays consistent across the CLI.
    A plain-text fallback handles environments where Rich isn't usable.
    """
    if runtime.cli_wants_machine_output():
        return
    if not runtime.stream_is_tty(sys.stderr):
        return
    for var in _deprecation_suppress_envs():
        if env.read_bool(var):
            return

    try:
        from rich.panel import Panel

        body = (
            f"[bold]'rai {colon_name}'[/bold] is deprecated; removal is planned "
            f"for rai {_COLON_ALIAS_REMOVAL_VERSION} "
            f"(schedule may shift — watch release notes).\n"
            f"Use [bold cyan]rai {space_name}[/bold cyan] instead."
        )
        panel = Panel(
            body,
            title="[bold yellow]Deprecated command[/bold yellow]",
            border_style="yellow",
            padding=(1, 2),
        )
        # The deprecation hint is emitted *before* the canonical command
        # runs (alias wrapper → emit → ``ctx.invoke(canonical)``), so the
        # panel is the first thing on screen after the user's prompt.
        # No leading blank line is wanted (it just creates dead space
        # under the prompt); a trailing blank separates the panel from
        # the table/output the canonical command is about to print.
        # This is the inverse of the ``Update available`` notice in
        # :mod:`update_check`, which runs at exit and needs the leading
        # blank to detach from preceding output.
        runtime.print_advisory_panel(panel)
        runtime.stderr_console.print()
    except Exception:
        # Fallback path: Rich unavailable for some reason. Keep the same
        # substrings the test contract pins ("deprecated", the colon
        # form, the canonical form) so consumers and tests don't have to
        # care which renderer ran. Resolve color preference defensively
        # so a partially-initialized output-prefs module doesn't propagate
        # out of an alias wrapper.
        try:
            from ..cli_output_prefs import cli_requests_no_color

            no_color = cli_requests_no_color()
        except Exception:
            no_color = True
        body = (
            f"deprecated: 'rai {colon_name}' — removal planned for rai "
            f"{_COLON_ALIAS_REMOVAL_VERSION} (schedule may shift); "
            f"use 'rai {space_name}' instead."
        )
        msg = click.style(body, fg="yellow") if not no_color else body
        click.echo(msg, err=True)
        click.echo("", err=True)


def add_colon_alias(
    *,
    root: click.Group,
    canonical: click.Command,
    colon_name: str,
    space_name: str,
) -> click.Command:
    """Attach a hidden, deprecated colon-style alias of ``canonical`` to ``root``.

    The alias mirrors ``canonical``'s parameters one-for-one (so flag
    parsing is identical) and forwards to the canonical callback via
    ``ctx.invoke``. That keeps a single source of truth for behavior:
    only the canonical command's body and decorators (``handle_cli_errors``,
    ``include_in_docs``) ever run.

    Parameters
    ----------
    root:
        Root Click group that already exposes the new noun subgroup. The
        alias is registered here (at the root) under ``colon_name``.
    canonical:
        The canonical command (e.g. the ``list`` command on the ``jobs``
        subgroup). Its ``params`` are reused verbatim.
    colon_name:
        Legacy name (``"jobs:list"``).
    space_name:
        Canonical user-facing name (``"jobs list"``). Only used in the
        deprecation message.
    """

    @click.pass_context
    def _alias(ctx: click.Context, **kwargs: Any) -> None:
        _emit_colon_deprecation(colon_name=colon_name, space_name=space_name)
        ctx.invoke(canonical, **kwargs)

    alias = click.Command(
        name=colon_name,
        callback=_alias,
        # Reuse the canonical Params so option help, types, defaults, and
        # multiple/required semantics stay in lockstep automatically.
        params=list(canonical.params),
        hidden=True,
        help=(
            f"(deprecated) Alias for `rai {space_name}`. "
            f"Prefer `rai {space_name}` — removal planned for "
            f"rai {_COLON_ALIAS_REMOVAL_VERSION} (schedule may shift)."
        ),
        short_help=f"(deprecated) Use `rai {space_name}`.",
    )
    root.add_command(alias)
    return alias
