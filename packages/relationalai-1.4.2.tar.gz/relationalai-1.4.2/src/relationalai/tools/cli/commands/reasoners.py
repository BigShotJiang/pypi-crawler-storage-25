"""``rai reasoners`` subgroup commands.

The user-facing surface is ``rai reasoners <verb>`` (e.g.
``rai reasoners list``). Each command also has a hidden, deprecated colon
alias (``reasoners:list``) for backward compatibility; see
:func:`_common.add_colon_alias`.
"""

from __future__ import annotations

from typing import Any

import click

from ....util.docutils import include_in_docs
from .. import runtime
from .._group import RaiSubGroup
from ..display import show_reasoner, show_reasoner_detail, show_reasoners
from ..errors import handle_cli_errors, set_error_params
from ..flows import ensure_reasoner_name, ensure_reasoner_size, ensure_reasoner_type
from ..long_running import should_use_live_status
from ..render import PaginationInfo, build_filter_args, render_detail, render_list
from ..serialize import reasoner_record_as_json
from ._common import (
    add_colon_alias,
    pagination_options,
    params_reasoner_type_name,
    params_reasoner_type_name_auto_suspend,
    params_reasoner_type_name_size,
    wait_options,
)
from ._reasoners_helpers import (
    print_reasoner_async_operation_started,
    reasoner_options_type_name_direct,
    reasoner_options_type_name_filter,
    reasoner_with_state,
    resolve_reasoner_target,
    run_reasoner_wait_with_guidance,
    wait_for_reasoner_ready_with_ui,
)


def _emit_reasoner_result(reasoner: Any) -> None:
    """Emit a reasoner record in the active machine format, else render the panel.

    Gates on :func:`runtime.cli_wants_machine_output` so JSON *and* YAML
    both emit the structured ``{"reasoner": …}`` envelope via
    :func:`runtime.emit_cli_output`. Pre-fix this used ``cli_wants_json``
    only, so ``--output yaml`` silently fell back to the human table —
    inconsistent with how list/get verbs behave under YAML.
    """
    if runtime.emit_cli_result("reasoner", reasoner_record_as_json(reasoner)):
        return
    show_reasoner(reasoner)


def register(cli: click.Group) -> None:
    """Wire the ``reasoners`` subgroup and its commands (plus colon aliases)."""

    @cli.group(name="reasoners", cls=RaiSubGroup)
    def reasoners_group() -> None:
        """Manage reasoners (create, list, get, alter, delete, suspend, resume, wait)."""

    _register_create(cli, reasoners_group)
    _register_delete(cli, reasoners_group)
    _register_alter(cli, reasoners_group)
    _register_suspend(cli, reasoners_group)
    _register_resume(cli, reasoners_group)
    _register_wait(cli, reasoners_group)
    _register_list(cli, reasoners_group)
    _register_get(cli, reasoners_group)


# ── reasoners create ─────────────────────────────────────────────────────────


def _register_create(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="create")
    @click.option(
        "--type",
        "reasoner_type",
        required=False,
        default=None,
        help="Reasoner type (Logic / Prescriptive / Predictive). If omitted, you'll be prompted to select.",
    )
    @click.option(
        "--name",
        "reasoner_name",
        default=None,
        help="Reasoner name. If omitted, you'll be prompted to enter one.",
    )
    @click.option(
        "--size",
        "reasoner_size",
        default=None,
        help="Reasoner size. If omitted, you can choose (or use config default).",
    )
    @click.option(
        "--auto-suspend-mins",
        type=int,
        default=None,
        help="Auto-suspend after N minutes of inactivity (optional).",
    )
    @click.option(
        "--await-storage-vacuum/--no-await-storage-vacuum",
        default=None,
        help="Wait for storage vacuum work before suspending the reasoner (use "
             "--await-storage-vacuum to enable, --no-await-storage-vacuum to disable).",
    )
    @wait_options(default_timeout_s=900)
    @include_in_docs
    @handle_cli_errors(
        name="reasoners create",
        message="Failed to create reasoner.",
        click_message="Reasoners create failed.",
        params=params_reasoner_type_name_size,
    )
    def reasoners_create(
        reasoner_type: str | None,
        reasoner_name: str | None,
        reasoner_size: str | None,
        auto_suspend_mins: int | None,
        await_storage_vacuum: bool | None,
        timeout_s: int,
        wait: bool,
    ) -> None:
        """Create a reasoner."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()

        # Step-by-step resolution. Each step stashes the latest resolved values
        # on the Click context so `handle_cli_errors` can include them even if
        # a later step fails.
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        set_error_params({"reasoner_type": t_norm, "reasoner_name": reasoner_name, "reasoner_size": reasoner_size})

        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        set_error_params({"reasoner_type": t_norm, "reasoner_name": name, "reasoner_size": reasoner_size})

        with runtime.cli_connect_sync(config) as client:
            size = ensure_reasoner_size(
                client.reasoners, reasoner_size, interactive=interactive, console=runtime.console
            )
            set_error_params({"reasoner_type": t_norm, "reasoner_name": name, "reasoner_size": size})

            size_display = size or "default"
            if wait:
                reasoner = run_reasoner_wait_with_guidance(
                    lambda: _create_reasoner_and_wait(
                        client=client,
                        t_norm=t_norm,
                        t_label=t_label,
                        name=name,
                        size=size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        timeout_s=timeout_s,
                    ),
                    reasoner_type_label=t_label,
                    reasoner_name=name,
                    timeout_s=timeout_s,
                )
                _emit_reasoner_result(reasoner)
                return

            op = runtime.run_with_spinner(
                f"Starting {t_label} reasoner create for '{name}' (size {size_display})...",
                lambda: client.reasoners.create(
                    reasoner_type=t_norm,
                    reasoner_name=name,
                    reasoner_size=size,
                    auto_suspend_mins=auto_suspend_mins,
                    await_storage_vacuum=await_storage_vacuum,
                    settings=None,
                ),
            )
            print_reasoner_async_operation_started(
                verb="create", operation_id=op.id, t_label=t_label, name=name
            )

    add_colon_alias(
        root=cli, canonical=reasoners_create,
        colon_name="reasoners:create", space_name="reasoners create",
    )


# ── reasoners delete ─────────────────────────────────────────────────────────


def _register_delete(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="delete")
    @reasoner_options_type_name_filter
    @include_in_docs
    @handle_cli_errors(
        name="reasoners delete",
        message="Failed to delete reasoner.",
        click_message="Reasoners delete failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_delete(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Delete a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                prompt="Select a reasoner to delete:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved

            def _delete() -> Any:
                before = client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)
                client.reasoners.delete(reasoner_type=t_norm, reasoner_name=name)
                return before

            before = runtime.run_with_spinner(f"Deleting {t_label} reasoner '{name}'...", _delete)
        show_reasoner(
            reasoner_with_state(
                reasoner=before, reasoner_type=t_norm, reasoner_name=name, state="DELETED"
            )
        )

    add_colon_alias(
        root=cli, canonical=reasoners_delete,
        colon_name="reasoners:delete", space_name="reasoners delete",
    )


# ── reasoners alter ──────────────────────────────────────────────────────────


def _register_alter(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="alter", short_help="Alter a reasoner's settings.")
    @reasoner_options_type_name_direct
    @click.option(
        "--auto-suspend-mins",
        type=int,
        default=None,
        help="New auto-suspend timeout in minutes.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="reasoners alter",
        message="Failed to alter reasoner.",
        click_message="Reasoners alter failed.",
        params=params_reasoner_type_name_auto_suspend,
    )
    def reasoners_alter(
        reasoner_type: str | None,
        reasoner_name: str | None,
        auto_suspend_mins: int | None,
    ) -> None:
        """Alter a reasoner's settings (e.g. auto-suspend timeout)."""
        if auto_suspend_mins is None:
            raise click.UsageError("At least one setting to alter must be provided (e.g. --auto-suspend-mins).")

        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                prompt="Select a reasoner to alter:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved
            runtime.run_with_spinner(
                f"Altering {t_label} reasoner '{name}'...",
                lambda: client.reasoners.alter_auto_suspend_mins(
                    reasoner_type=t_norm,
                    reasoner_name=name,
                    auto_suspend_mins=auto_suspend_mins,
                ),
            )
            r = client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)
            show_reasoner(r)

    add_colon_alias(
        root=cli, canonical=reasoners_alter,
        colon_name="reasoners:alter", space_name="reasoners alter",
    )


# ── reasoners suspend ────────────────────────────────────────────────────────


def _register_suspend(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="suspend")
    @reasoner_options_type_name_filter
    @include_in_docs
    @handle_cli_errors(
        name="reasoners suspend",
        message="Failed to suspend reasoner.",
        click_message="Reasoners suspend failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_suspend(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Suspend a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                exclude_states={"SUSPENDED"},
                prompt="Select a reasoner to suspend:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved

            def _suspend() -> Any:
                client.reasoners.suspend(reasoner_type=t_norm, reasoner_name=name)
                return client.reasoners.get(reasoner_type=t_norm, reasoner_name=name)

            r_after = runtime.run_with_spinner(f"Suspending {t_label} reasoner '{name}'...", _suspend)
        show_reasoner(
            reasoner_with_state(
                reasoner=r_after, reasoner_type=t_norm, reasoner_name=name, state="SUSPENDED"
            )
        )

    add_colon_alias(
        root=cli, canonical=reasoners_suspend,
        colon_name="reasoners:suspend", space_name="reasoners suspend",
    )


# ── reasoners resume ─────────────────────────────────────────────────────────


def _register_resume(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="resume")
    @reasoner_options_type_name_filter
    @wait_options(default_timeout_s=900)
    @include_in_docs
    @handle_cli_errors(
        name="reasoners resume",
        message="Failed to resume reasoner.",
        click_message="Reasoners resume failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_resume(
        reasoner_type: str | None,
        reasoner_name: str | None,
        timeout_s: int,
        wait: bool,
    ) -> None:
        """Resume a reasoner."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                state="SUSPENDED",
                prompt="Select a reasoner to resume:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved
            _resume_one(
                client=client,
                t_norm=t_norm,
                t_label=t_label,
                name=name,
                wait=wait,
                timeout_s=timeout_s,
            )

    add_colon_alias(
        root=cli, canonical=reasoners_resume,
        colon_name="reasoners:resume", space_name="reasoners resume",
    )


def _create_reasoner_and_wait(
    *,
    client: Any,
    t_norm: str,
    t_label: str,
    name: str,
    size: str | None,
    auto_suspend_mins: int | None,
    await_storage_vacuum: bool | None,
    timeout_s: int,
) -> Any:
    if not should_use_live_status():
        return client.reasoners.create_ready(
            reasoner_type=t_norm,
            reasoner_name=name,
            reasoner_size=size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            timeout_s=timeout_s,
        )

    op = runtime.run_with_spinner(
        f"Starting {t_label} reasoner create for '{name}'...",
        lambda: client.reasoners.create(
            reasoner_type=t_norm,
            reasoner_name=name,
            reasoner_size=size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=None,
        ),
    )
    # Some backends rewrite the reasoner name during create (e.g. user
    # supplies "TEST" → backend stores "test"); the operation surfaces the
    # canonical form via ``metadata["reasoner_name"]``. Fall back to the
    # caller-provided ``name`` when the metadata is absent, malformed, or
    # carries an empty value so the subsequent wait doesn't poll on an
    # empty identifier and surface a confusing 404.
    resolved_name = name
    metadata = getattr(op, "metadata", None)
    if isinstance(metadata, dict):
        candidate = metadata.get("reasoner_name")
        if isinstance(candidate, str) and candidate.strip():
            resolved_name = candidate.strip()
    return wait_for_reasoner_ready_with_ui(
        reasoners=client.reasoners,
        reasoner_type=t_norm,
        reasoner_type_label=t_label,
        reasoner_name=resolved_name,
        timeout_s=timeout_s,
    )


def _resume_reasoner_and_wait(
    *,
    client: Any,
    t_norm: str,
    t_label: str,
    name: str,
    timeout_s: int,
) -> Any:
    if not should_use_live_status():
        return client.reasoners.resume_ready(
            reasoner_type=t_norm,
            reasoner_name=name,
            timeout_s=timeout_s,
        )

    runtime.run_with_spinner(
        f"Starting {t_label} reasoner resume for '{name}'...",
        lambda: client.reasoners.resume(reasoner_type=t_norm, reasoner_name=name),
    )
    return wait_for_reasoner_ready_with_ui(
        reasoners=client.reasoners,
        reasoner_type=t_norm,
        reasoner_type_label=t_label,
        reasoner_name=name,
        timeout_s=timeout_s,
    )


def _resume_one(
    *,
    client: Any,
    t_norm: str,
    t_label: str,
    name: str,
    wait: bool,
    timeout_s: int,
) -> None:
    if wait:
        r = run_reasoner_wait_with_guidance(
            lambda: _resume_reasoner_and_wait(
                client=client,
                t_norm=t_norm,
                t_label=t_label,
                name=name,
                timeout_s=timeout_s,
            ),
            reasoner_type_label=t_label,
            reasoner_name=name,
            timeout_s=timeout_s,
        )
        _emit_reasoner_result(r)
        return

    op = runtime.run_with_spinner(
        f"Starting {t_label} reasoner resume for '{name}'...",
        lambda: client.reasoners.resume(reasoner_type=t_norm, reasoner_name=name),
    )
    print_reasoner_async_operation_started(
        verb="resume", operation_id=op.id, t_label=t_label, name=name
    )
    # Machine modes (JSON and YAML) already received the structured
    # operation payload from ``print_reasoner_async_operation_started``;
    # the synthetic "PENDING" detail row is human-only follow-up. Pre-fix
    # this gated on ``cli_wants_json`` only, so ``--output yaml`` would
    # render the synthetic row on top of the structured operation
    # payload and clobber it for downstream parsers.
    if runtime.cli_wants_machine_output():
        return

    r = runtime.run_with_spinner(
        f"Fetching {t_label} reasoner '{name}'...",
        lambda: client.reasoners.get(reasoner_type=t_norm, reasoner_name=name),
    )
    show_reasoner(
        reasoner_with_state(
            reasoner=r, reasoner_type=t_norm, reasoner_name=name, state="PENDING"
        )
    )


# ── reasoners wait ───────────────────────────────────────────────────────────


def _register_wait(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="wait")
    @reasoner_options_type_name_filter
    @click.option(
        "--timeout-s",
        type=int,
        default=900,
        show_default=True,
        help="Timeout in seconds while waiting until the reasoner is READY.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="reasoners wait",
        message="Failed to wait for reasoner.",
        click_message="Reasoners wait failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_wait(reasoner_type: str | None, reasoner_name: str | None, timeout_s: int) -> None:
        """Wait until a reasoner reaches READY state."""
        with runtime.cli_session() as (_config, interactive, client):
            resolved = resolve_reasoner_target(
                client.reasoners,
                reasoner_type=reasoner_type,
                reasoner_name=reasoner_name,
                interactive=interactive,
                exclude_states={"READY"},
                prompt="Select a reasoner to wait on:",
            )
            if resolved is None:
                return
            t_norm, t_label, name = resolved
            reasoner = run_reasoner_wait_with_guidance(
                lambda: wait_for_reasoner_ready_with_ui(
                    reasoners=client.reasoners,
                    reasoner_type=t_norm,
                    reasoner_type_label=t_label,
                    reasoner_name=name,
                    timeout_s=timeout_s,
                    stuck_states={"SUSPENDED"},
                ),
                reasoner_type_label=t_label,
                reasoner_name=name,
                timeout_s=timeout_s,
            )
            _emit_reasoner_result(reasoner)

    add_colon_alias(
        root=cli, canonical=reasoners_wait,
        colon_name="reasoners:wait", space_name="reasoners wait",
    )


# ── reasoners list ───────────────────────────────────────────────────────────


def _register_list(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="list")
    @click.option("--type", "reasoner_type", required=False, default=None,
                  help="Filter by reasoner type (Logic/Prescriptive/Predictive) (optional).")
    @click.option("--name", "reasoner_name", required=False, default=None, help="Filter by reasoner name (optional).")
    @click.option("--size", "reasoner_size", required=False, default=None, help="Filter by reasoner size (optional).")
    @click.option("--state", required=False, default=None, help="Filter by reasoner state (optional).")
    @click.option("--created-by", "created_by", required=False, default=None,
                  help="Filter by creator username (optional).")
    @pagination_options()
    @include_in_docs
    @handle_cli_errors(
        name="reasoners list",
        message="Failed to list reasoners.",
        click_message="Reasoners list failed.",
    )
    def reasoners_list(
        reasoner_type: str | None,
        reasoner_name: str | None,
        reasoner_size: str | None,
        state: str | None,
        created_by: str | None,
        limit: int,
        offset: int,
    ) -> None:
        """List reasoners with optional filters."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()

        t_norm: str | None = None
        t_label: str | None = None
        raw_type = (reasoner_type or "").strip()
        if raw_type:
            t_norm, t_label = ensure_reasoner_type(raw_type, interactive=interactive, console=runtime.console)

        with runtime.cli_connect_sync(config) as client:
            msg = "Fetching reasoners..." if not t_label else f"Fetching {t_label.lower()} reasoners..."
            items = runtime.run_with_spinner(
                msg,
                lambda: client.reasoners.list(
                    state=state,
                    reasoner_name=reasoner_name,
                    reasoner_type=t_norm,
                    reasoner_size=reasoner_size,
                    created_by=created_by,
                    limit=limit,
                    offset=offset,
                ),
            )

        filter_args = build_filter_args(
            [
                ("--type", t_label),
                ("--name", reasoner_name),
                ("--size", reasoner_size),
                ("--state", state),
                ("--created-by", created_by),
            ]
        )

        render_list(
            items,
            json_key="reasoners",
            json_mapper=reasoner_record_as_json,
            renderer=show_reasoners,
            empty_message="[yellow]No reasoners found.[/yellow]",
            pagination=PaginationInfo(
                limit=limit,
                offset=offset,
                command="reasoners list",
                filter_args=filter_args,
            ),
        )

    add_colon_alias(
        root=cli, canonical=reasoners_list,
        colon_name="reasoners:list", space_name="reasoners list",
    )


# ── reasoners get ────────────────────────────────────────────────────────────


def _register_get(cli: click.Group, reasoners_group: click.Group) -> None:
    @reasoners_group.command(name="get")
    @reasoner_options_type_name_direct
    @include_in_docs
    @handle_cli_errors(
        name="reasoners get",
        message="Failed to get reasoner.",
        click_message="Reasoners get failed.",
        params=params_reasoner_type_name,
    )
    def reasoners_get(reasoner_type: str | None, reasoner_name: str | None) -> None:
        """Get a reasoner by type and name."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)

        with runtime.cli_connect_sync(config) as client:
            r = runtime.run_with_spinner(
                f"Fetching {t_label} reasoner '{name}'...",
                lambda: client.reasoners.get(reasoner_type=t_norm, reasoner_name=name),
            )

        render_detail(
            r,
            json_key="reasoner",
            json_mapper=reasoner_record_as_json,
            renderer=show_reasoner_detail,
            not_found_message="[yellow]Reasoner not found.[/yellow]",
        )

    add_colon_alias(
        root=cli, canonical=reasoners_get,
        colon_name="reasoners:get", space_name="reasoners get",
    )
