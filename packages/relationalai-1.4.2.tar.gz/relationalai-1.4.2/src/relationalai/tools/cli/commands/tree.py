"""``rai commands`` — print the full command tree as a Rich tree.

After the ``noun:verb`` → ``noun verb`` migration the root ``rai --help``
output is short and clean (one line per subgroup) but loses the
"everything at a glance" view the colon-prefixed help used to provide
incidentally. Discovering ``rai jobs list`` from scratch now means
``rai --help`` → ``rai jobs --help`` instead of just ``rai``.

This command restores the bird's-eye view without bloating the default
help text, modeled on ``gcloud cheat-sheet`` (and the spirit of
``kubectl api-resources`` / ``aws --help``'s long form): a single
explicit command users can opt into when they want to see everything.

Layout choices:

- Tree shape rather than a flat list. Mirrors the actual subgroup
  structure so users build the right mental model of how to invoke
  things ("``rai`` → ``jobs`` → ``list``"), which is exactly the form
  they'll type. A flat ``noun verb`` table would re-introduce the
  ambiguity the migration removed.
- Hidden commands (the deprecated colon aliases, the still-hidden
  ``models`` group, internal stubs) are excluded by default. ``--all``
  surfaces them for power users / migration debugging without making
  them prominent in the normal output.
- ``--json`` / global ``--output`` emits a machine-readable shape so docs generation, shell
  hooks, or LLMs can consume the tree without scraping ANSI.
"""

from __future__ import annotations

from typing import Any

import click

from ....util.docutils import include_in_docs
from .. import runtime


def _command_entry(name: str, cmd: click.Command, *, show_hidden: bool) -> dict[str, Any]:
    """Recursively build a JSON-shaped dict for ``cmd``."""
    entry: dict[str, Any] = {
        "name": name,
        "help": cmd.get_short_help_str(limit=160) or "",
        "hidden": bool(getattr(cmd, "hidden", False)),
    }
    if isinstance(cmd, click.Group):
        children: list[dict[str, Any]] = []
        for child_name in sorted(cmd.commands):
            child = cmd.commands[child_name]
            if child.hidden and not show_hidden:
                continue
            children.append(_command_entry(child_name, child, show_hidden=show_hidden))
        entry["commands"] = children
    return entry


def _build_tree_node(
    parent_node: Any,
    cmd: click.Command,
    *,
    show_hidden: bool,
    use_color: bool,
) -> None:
    """Attach ``cmd``'s children to ``parent_node`` (a ``rich.tree.Tree`` node).

    All command names render with the same style (``[bold]``) regardless
    of whether the command is a subgroup or a leaf — the tree shape
    itself already conveys "expandable" (a subgroup has children rendered
    underneath it), so a separate color cue would be redundant noise. The
    ``bright_blue`` accent stays reserved for ``--help`` output, where
    it's the *only* affordance that says "this is invokable".

    Hidden entries, when ``show_hidden`` is set, are dimmed and tagged
    ``(hidden)`` so the eye can skip them when not relevant.
    """
    if not isinstance(cmd, click.Group):
        return

    for child_name in sorted(cmd.commands):
        child = cmd.commands[child_name]
        if child.hidden and not show_hidden:
            continue

        short = child.get_short_help_str(limit=80) or ""

        if use_color:
            name_part = f"[bold]{child_name}[/bold]"
            help_part = f" [dim]— {short}[/dim]" if short else ""
            tag = " [yellow](hidden)[/yellow]" if child.hidden else ""
        else:
            name_part = child_name
            help_part = f" — {short}" if short else ""
            tag = " (hidden)" if child.hidden else ""

        node = parent_node.add(f"{name_part}{tag}{help_part}")
        _build_tree_node(node, child, show_hidden=show_hidden, use_color=use_color)


def register(cli: click.Group) -> None:
    """Attach the ``commands`` tree-view command to ``cli``."""

    @cli.command(name="commands")
    @click.option(
        "--all",
        "-a",
        "show_all",
        is_flag=True,
        default=False,
        help=(
            "Include hidden commands (deprecated colon aliases, the "
            "internal `models` group, stubs)."
        ),
    )
    @click.option(
        "--json",
        "as_json",
        is_flag=True,
        default=False,
        help="Emit the command tree as JSON for scripts / docs tooling.",
    )
    @click.pass_context
    @include_in_docs
    def commands(ctx: click.Context, show_all: bool, as_json: bool) -> None:
        """Show the full command tree (subgroups + verbs) at a glance.

        Useful when you want to discover everything ``rai`` can do
        without walking ``--help`` per subgroup. Subgroups are rendered
        as branches; verbs as leaves with their short help.

        \b
        Examples:
          rai commands                # visible tree
          rai commands --all          # include hidden / deprecated
          rai commands --json | jq    # machine-readable
        """
        root = ctx.find_root().command
        # The root is always a Click Group at runtime (it's `cli` from
        # cli.py), but the type system surfaces it as the more general
        # ``Command`` because ``find_root().command`` is shape-polymorphic.
        # Narrow explicitly so pyright lets us reach into ``.commands``.
        assert isinstance(root, click.Group), (
            f"root command must be a click.Group (got {type(root).__name__})"
        )

        tree_data = {
            "name": "rai",
            "commands": [
                _command_entry(name, root.commands[name], show_hidden=show_all)
                for name in sorted(root.commands)
                if show_all or not root.commands[name].hidden
            ],
        }

        if as_json:
            runtime.emit_cli_json(tree_data)
            return

        # ``tree_data`` is itself the top-level envelope (``{"name": "rai",
        # "commands": [...]}``); ``emit_cli_result`` would re-wrap it as
        # ``{"commands": {"name": "rai", "commands": [...]}}`` and break
        # the documented JSON/YAML shape (and ``test_commands_global_output_*``
        # which pin ``data["name"] == "rai"`` at the top level).
        if runtime.cli_wants_machine_output():
            runtime.emit_cli_output(tree_data)
            return

        use_color = runtime.color_enabled(ctx)

        # Lazy-import Rich pieces so the JSON path stays Rich-free.
        from rich.tree import Tree

        root_label = "[bold]rai[/bold]" if use_color else "rai"
        tree = Tree(root_label, guide_style="dim" if use_color else "")
        _build_tree_node(tree, root, show_hidden=show_all, use_color=use_color)
        runtime.console.print(tree)

        if not show_all:
            hint = (
                "\nTip: pass [bold]--all[/bold] to include hidden / deprecated entries, "
                "or [bold]--output json[/bold] for a machine-readable tree."
                if use_color
                else (
                    "\nTip: pass --all to include hidden / deprecated entries, "
                    "or --output json for a machine-readable tree."
                )
            )
            # Tip goes to stderr so ``rai commands | jq`` (after a future
            # output-format unification) never sees the prose advisory line.
            runtime.stderr_console.print(hint)
