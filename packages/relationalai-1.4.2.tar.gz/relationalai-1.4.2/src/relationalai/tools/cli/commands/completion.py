"""``rai completion`` — shell completion script generation and installation.

Click ships shell completion machinery out of the box (see
``click.shell_completion``). At runtime, completion proposals are produced
by re-invoking the program with ``_RAI_COMPLETE=<shell>_complete``. The
shell needs a small "shim" script that knows how to call the program with
that env var and feed the proposals back. This command produces and
(optionally) installs that shim.

The shim itself is **stateless** with respect to the CLI's surface: it
just re-invokes ``rai`` whenever the user hits ``<TAB>``, so adding new
commands or options requires no re-install — they're picked up
automatically from the live command tree.

Modeled on the conventions used by ``gh completion``, ``kubectl
completion``, ``docker completion``, and ``databricks completion``: each
shell is a subcommand that prints its script to stdout, plus an
``install`` subcommand that writes the script to a per-user location and
wires up the user's rc file.

Notable side effect of the noun-verb migration that landed just before
this command: command names no longer contain ``:``, so we don't need
the colon-double-escape workaround that earlier prototypes required for
zsh's ``_describe`` parsing. Stock ``BashComplete`` / ``ZshComplete`` /
``FishComplete`` work out of the box.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import click
from click.shell_completion import (
    BashComplete,
    FishComplete,
    ShellComplete,
    ZshComplete,
)

from ....util.docutils import include_in_docs
from .. import runtime
from .._group import RaiSubGroup

_PROG_NAME = "rai"
_COMPLETE_VAR = f"_{_PROG_NAME.upper()}_COMPLETE"


# The three shells Click supports natively. PowerShell is intentionally
# excluded because Click does not ship a PowerShell completer; users on
# Windows should use the bash script under WSL/Git Bash.
SUPPORTED_SHELLS: dict[str, type[ShellComplete]] = {
    "bash": BashComplete,
    "zsh": ZshComplete,
    "fish": FishComplete,
}


# Resolved per-call (not at import time) so tests and per-user $HOME
# overrides work correctly. Bash and zsh load from arbitrary paths via
# ``source`` in the rc file; fish auto-discovers any ``*.fish`` file
# under ``~/.config/fish/completions/``.
def _install_path(shell: str) -> Path:
    home = Path.home()
    return {
        "bash": home / ".rai" / "completions" / "rai.bash",
        "zsh": home / ".rai" / "completions" / "_rai",
        "fish": home / ".config" / "fish" / "completions" / "rai.fish",
    }[shell]


def _rc_candidates(shell: str) -> list[Path]:
    """Candidate rc files per shell, tried in order. Fish has none — its
    install path is auto-discovered by the shell."""
    home = Path.home()
    return {
        "bash": [home / ".bashrc", home / ".bash_profile"],
        "zsh": [home / ".zshrc"],
        "fish": [],
    }.get(shell, [])


# Marker comment we write into the rc file so ``install`` is idempotent:
# we grep for this exact string before appending so re-running ``install``
# leaves the rc file untouched.
_RC_MARKER = "# rai CLI shell completion"


def _detect_shell() -> str | None:
    """Best-effort detection of the user's interactive shell.

    Reads ``$SHELL`` (set by login on every modern Unix). Returns ``None``
    when the shell is unknown or unsupported so callers can prompt or
    error with a useful message instead of silently picking the wrong
    target.
    """
    shell_path = os.environ.get("SHELL", "")
    if not shell_path:
        return None
    name = Path(shell_path).name.lower()
    return name if name in SUPPORTED_SHELLS else None


def _generate_script(shell: str, *, cli_obj: click.Command) -> str:
    """Render the completion shim script for ``shell``.

    Embeds ``_PROG_NAME`` and ``_COMPLETE_VAR`` so users who alias or
    rename the binary can still rely on a single, stable env-var
    contract. The returned string is suitable for piping into a file or
    sourcing directly.
    """
    cls = SUPPORTED_SHELLS[shell]
    inst = cls(
        cli=cli_obj,
        ctx_args={},
        prog_name=_PROG_NAME,
        complete_var=_COMPLETE_VAR,
    )
    return inst.source()


def _ensure_rc_source_line(rc_file: Path, install_path: Path, shell: str) -> bool:
    """Append a one-liner to ``rc_file`` that sources ``install_path``.

    Returns ``True`` if the rc file was modified, ``False`` if our marker
    line was already present (idempotent re-install). Creates the rc file
    if it doesn't exist so first-time users on a fresh shell still get
    wired up.

    Idempotency is keyed on :data:`_RC_MARKER` (the comment we wrote on a
    previous install) rather than the full source line, so users who
    move ``$HOME``, switch usernames, or upgrade across versions where
    ``_install_path`` changed don't end up with a duplicate ``source``
    line on the next ``install`` run.
    """
    if shell == "fish":
        # Fish auto-discovers; no rc edit needed.
        return False

    source_line = f'[ -f "{install_path}" ] && source "{install_path}"'

    if rc_file.exists():
        existing = rc_file.read_text(encoding="utf-8")
        if _RC_MARKER in existing:
            return False
        prefix = "" if existing == "" or existing.endswith("\n") else "\n"
    else:
        rc_file.parent.mkdir(parents=True, exist_ok=True)
        prefix = ""

    block = f"{prefix}{_RC_MARKER}\n{source_line}\n"
    with rc_file.open("a", encoding="utf-8") as fh:
        fh.write(block)
    return True


def _pick_rc_file(shell: str) -> Path | None:
    """Pick the rc file to edit, falling back to the first candidate.

    Returns the first existing candidate. If none exist, returns the
    first candidate so the caller can create it. Fish has no candidates
    and yields ``None`` (its install path is auto-discovered).
    """
    candidates = _rc_candidates(shell)
    if not candidates:
        return None
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def _resolve_shell(shell: str | None) -> str:
    """Resolve the requested shell, detecting from ``$SHELL`` when omitted.

    Raises :class:`click.ClickException` (not :class:`click.UsageError`)
    when auto-detect fails so the message flows through the CLI's
    standard diagnostic path with a stable exit code instead of Click's
    "Usage: ..." preamble.
    """
    if shell:
        normalized = shell.lower()
        if normalized not in SUPPORTED_SHELLS:
            raise click.BadParameter(
                f"unsupported shell: {shell!r}. "
                f"Supported: {', '.join(sorted(SUPPORTED_SHELLS))}."
            )
        return normalized

    detected = _detect_shell()
    if detected is None:
        raise click.ClickException(
            "Could not auto-detect your shell from $SHELL. "
            f"Pass --shell explicitly: {', '.join(sorted(SUPPORTED_SHELLS))}."
        )
    return detected


def _emit_script(cli_obj: click.Command, shell: str) -> None:
    """Print the completion script for ``shell`` to stdout (no extras).

    Output goes through ``click.echo`` so it respects ``--no-color`` and
    redirection. The script itself contains no ANSI sequences.
    """
    script = _generate_script(shell, cli_obj=cli_obj)
    click.echo(script)


def _install(cli_obj: click.Command, shell: str, *, force: bool) -> None:
    """Write the completion script to disk and wire up the rc file."""
    install_path = _install_path(shell)
    if install_path.exists() and not force:
        runtime.console.print(
            f"[yellow]→[/yellow] Completion script already exists at "
            f"[bold]{install_path}[/bold] — pass --force to overwrite."
        )
    else:
        install_path.parent.mkdir(parents=True, exist_ok=True)
        script = _generate_script(shell, cli_obj=cli_obj)
        # Click's shell completers don't guarantee a trailing newline on
        # ``source()``; normalize so we always end the file with exactly
        # one newline (without doubling it when one is already present).
        install_path.write_text(script.rstrip("\n") + "\n", encoding="utf-8")
        runtime.console.print(
            f"[bold green]✓[/bold green] Wrote completion script: "
            f"[bold]{install_path}[/bold]"
        )

    rc_file = _pick_rc_file(shell)
    if rc_file is None:
        # fish: nothing to edit; the install path is auto-discovered.
        runtime.console.print(
            "[bold green]✓[/bold green] Fish auto-loads completions from "
            f"[bold]{install_path.parent}/[/bold]. "
            "Restart your shell to activate."
        )
        return

    edited = _ensure_rc_source_line(rc_file, install_path, shell)
    if edited:
        runtime.console.print(
            f"[bold green]✓[/bold green] Updated [bold]{rc_file}[/bold] "
            f"to source the completion script."
        )
    else:
        runtime.console.print(
            f"[dim]→ {rc_file} already sources the completion script "
            f"(no changes).[/dim]"
        )

    runtime.console.print(
        "\n[bold]Next:[/bold] restart your shell, or run "
        f"[bold]source {rc_file}[/bold] to activate completion now."
    )


def register(cli: click.Group) -> None:
    """Attach the ``completion`` group and its subcommands to ``cli``."""

    @cli.group(invoke_without_command=True, cls=RaiSubGroup)
    @click.pass_context
    @include_in_docs
    def completion(ctx: click.Context) -> None:
        """Generate or install shell tab-completion for ``rai``.

        \b
        Examples:
          # Auto-detect shell and install (recommended):
          rai completion install

          # Install for a specific shell:
          rai completion install --shell zsh

          # Or print the script and wire it up by hand (paths shown
          # match what `rai completion install` would write):
          rai completion bash >> ~/.rai/completions/rai.bash && \\
              echo 'source ~/.rai/completions/rai.bash' >> ~/.bashrc

          # Activate without restarting your shell (use the rc file
          # for your shell — `install` edits the same one):
          source ~/.bashrc         # bash
          source ~/.zshrc          # zsh
          # fish auto-discovers its completion file — no source needed
        """
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # One subcommand per supported shell. Iterating keeps the surface in
    # lockstep with ``SUPPORTED_SHELLS`` so adding a new shell is a
    # one-line change rather than three near-identical function defs.
    def _make_shell_cmd(shell_name: str) -> Any:
        help_text = (
            f"Print the {shell_name} completion script to stdout.\n\n"
            "Pipe or redirect to a file, then source it from your rc file. "
            "For an automated setup, prefer 'rai completion install'."
        )

        @completion.command(
            name=shell_name,
            help=help_text,
            short_help=f"Print the {shell_name} completion script.",
        )
        @click.pass_context
        @include_in_docs
        def _shell_cmd(ctx: click.Context) -> None:
            cli_obj = ctx.find_root().command
            _emit_script(cli_obj, shell_name)

        return _shell_cmd

    for _shell in SUPPORTED_SHELLS:
        _make_shell_cmd(_shell)

    @completion.command("install")
    @click.option(
        "--shell",
        "shell_opt",
        type=click.Choice(sorted(SUPPORTED_SHELLS), case_sensitive=False),
        default=None,
        help="Target shell. Defaults to the shell detected from $SHELL.",
    )
    @click.option(
        "--force",
        is_flag=True,
        default=False,
        help="Overwrite an existing completion script if present.",
    )
    @click.pass_context
    @include_in_docs
    def install(ctx: click.Context, shell_opt: str | None, force: bool) -> None:
        """Install completion for your shell (writes script and updates rc).

        \b
        What this does:
          1. Writes the completion script under ~/.rai/completions/
             (or ~/.config/fish/completions/ for fish)
          2. Appends a `source ...` line to your shell's rc file
             (idempotent — safe to re-run)

        Re-run with --force to refresh the script after upgrading rai.
        """
        shell = _resolve_shell(shell_opt)
        cli_obj = ctx.find_root().command
        _install(cli_obj, shell, force=force)
