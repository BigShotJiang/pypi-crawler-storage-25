"""``rai jobs`` subgroup commands (list/get/events/wait/cancel/create).

The user-facing surface is ``rai jobs <verb>`` (e.g. ``rai jobs list``).
Every command also has a hidden, deprecated colon alias (``jobs:list``)
so existing scripts keep working; see :func:`_common.add_colon_alias`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import click

from ....util.docutils import include_in_docs
from .. import runtime
from .._group import RaiSubGroup
from ..display import print_job_expansions, show_job, show_job_detail, show_jobs
from ..errors import handle_cli_errors, set_error_params
from ..flows import ensure_job_type, ensure_reasoner_name
from ..job_types import JOB_TYPE_LOGIC, JOB_TYPE_ML, JOB_TYPE_SOLVER, normalize_job_type
from ..render import PaginationInfo, build_filter_args, render_detail, render_list
from ..serialize import job_record_as_json
from ._common import (
    add_colon_alias,
    job_options_type_id,
    job_wait_options,
    pagination_options,
    params_job_events,
    params_job_type_id,
    params_jobs_list,
)
from ._jobs_helpers import (
    build_payload,
    default_event_stream,
    ensure_job_identity,
    emit_job_result,
    job_get_include_from_flags,
    job_include_from_flags,
    parse_json_object,
    prompt_missing_logic_fields,
    run_job_wait_with_guidance,
    submit_and_maybe_wait,
    wait_for_job_with_ui,
)


def register(cli: click.Group) -> None:
    """Wire the ``jobs`` subgroup and its commands (plus colon aliases)."""

    @cli.group(name="jobs", cls=RaiSubGroup)
    def jobs_group() -> None:
        """Manage jobs (list, get, events, wait, cancel, create)."""

    _register_list(cli, jobs_group)
    _register_get(cli, jobs_group)
    _register_events(cli, jobs_group)
    _register_wait(cli, jobs_group)
    _register_cancel(cli, jobs_group)
    _register_create(cli, jobs_group)


# ── jobs list ────────────────────────────────────────────────────────────────


def _register_list(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="list")
    @click.option("--type", "job_type", required=False, default=None,
                  help="Filter by job type (Logic/Prescriptive/Predictive).")
    @click.option("--id", "job_id", required=False, default=None, help="Filter by job id (optional).")
    @click.option("--state", required=False, default=None, help="Filter by job state (optional).")
    @click.option("--name", required=False, default=None, help="Filter by reasoner name (optional).")
    @click.option("--created-by", "created_by", required=False, default=None,
                  help="Filter by creator username (optional).")
    @click.option("--only-active", is_flag=True, help="Only active jobs.")
    @pagination_options()
    @click.option(
        "--include",
        "includes",
        multiple=True,
        type=click.Choice(["details"], case_sensitive=False),
        help="Include optional `details` expansions (read_only and timeout_ms columns; full details JSON with `--json`).",
    )
    @include_in_docs
    @handle_cli_errors(
        name="jobs list",
        message="Failed to list jobs.",
        click_message="Jobs list failed.",
        params=params_jobs_list,
    )
    def jobs_list(
        job_type: str | None,
        job_id: str | None,
        state: str | None,
        name: str | None,
        created_by: str | None,
        only_active: bool,
        limit: int | None,
        offset: int,
        includes: tuple[str, ...],
    ) -> None:
        """List jobs with optional filters."""
        config = runtime.load_config()
        interactive = runtime.is_interactive()
        t_public: str | None = None
        t_label: str | None = None
        if job_type is not None and str(job_type).strip():
            t_public, t_label = ensure_job_type(job_type, interactive=interactive, console=runtime.console)

        include = job_include_from_flags(includes)
        include_details = bool(include.get("details")) if include is not None else False

        with runtime.cli_connect_sync(config) as client:
            msg = "Fetching jobs..." if t_label is None else f"Fetching {t_label} jobs..."
            items = runtime.run_with_spinner(
                msg,
                lambda: client.jobs.list(
                    t_public,
                    job_id=job_id,
                    state=state,
                    name=name,
                    created_by=created_by,
                    only_active=bool(only_active),
                    all_users=False,
                    limit=limit,
                    offset=offset,
                    include=include,
                ),
            )

        filter_args = build_filter_args(
            [
                ("--type", t_public),
                ("--id", job_id),
                ("--state", state),
                ("--name", name),
                ("--created-by", created_by),
                ("--only-active", only_active),
                ("--include", list(includes)),
            ]
        )

        render_list(
            items,
            json_key="jobs",
            json_mapper=job_record_as_json,
            renderer=lambda xs: show_jobs(xs, include_details=include_details),
            empty_message="[yellow]No jobs found.[/yellow]",
            pagination=PaginationInfo(
                limit=limit,
                offset=offset,
                command="jobs list",
                filter_args=filter_args,
            ),
        )

    add_colon_alias(root=cli, canonical=jobs_list, colon_name="jobs:list", space_name="jobs list")


# ── jobs get ─────────────────────────────────────────────────────────────────


def _register_get(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="get")
    @job_options_type_id()
    @click.option(
        "--include",
        "includes",
        multiple=True,
        type=click.Choice(["events", "artifacts", "problems", "raw"], case_sensitive=False),
        help="Optional extra expansions (repeatable). Job details are always fetched.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="jobs get",
        message="Failed to get job.",
        click_message="Jobs get failed.",
        params=params_job_type_id,
    )
    def jobs_get(job_type: str | None, job_id: str | None, includes: tuple[str, ...]) -> None:
        """Get a job by type and id."""
        include = job_get_include_from_flags(includes)

        with runtime.cli_session() as (config, interactive, client):
            picked = ensure_job_identity(
                client.jobs,
                config=config,
                job_type=job_type,
                job_id=job_id,
                interactive=interactive,
                prompt="Select a job:",
            )
            if picked is None:
                return
            jtype, jid = picked

            job = runtime.run_with_spinner(
                f"Fetching job {jid}...",
                lambda: client.jobs.get(str(jtype), str(jid), include=include),
            )

        def _render_job(j: Any) -> None:
            show_job_detail(j)
            print_job_expansions(j, skip_details=True)

        render_detail(
            job,
            json_key="job",
            json_mapper=job_record_as_json,
            renderer=_render_job,
            not_found_message="[yellow]Job not found.[/yellow]",
        )

    add_colon_alias(root=cli, canonical=jobs_get, colon_name="jobs:get", space_name="jobs get")


# ── jobs events ──────────────────────────────────────────────────────────────


def _register_events(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="events")
    @click.option("--type", "job_type", required=True, help="Job type (Logic/Prescriptive/Predictive).")
    @click.option("--id", "job_id", required=True, help="Job id.")
    @click.option(
        "--continuation-token",
        default="",
        show_default=False,
        help="Continuation token from a previous events call (optional).",
    )
    @click.option(
        "--stream-name",
        default=None,
        show_default=False,
        help="Events stream name (optional). Defaults to `profiler` for Direct Access Logic jobs and `progress` otherwise.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="jobs events",
        message="Failed to get job events.",
        click_message="Jobs events failed.",
        params=params_job_events,
    )
    def jobs_events(job_type: str, job_id: str, continuation_token: str, stream_name: str | None) -> None:
        """Get events for a job.

        Events have no human table form. Output is machine-readable:

        - Default table mode still prints the historical raw JSON events object,
          ``{"events": [...], "continuation_token": ...}``. This matches the
          historical pre-1.0 shape, so scripts that consume the default form
          continue to work unchanged.
        - ``--json`` / ``--output json`` wraps that object under a ``job_events`` key,
          ``{"job_events": {"events": [...], "continuation_token": ...}}``,
          to match the wrapper-key shape used by the rest of the CLI under
          machine-readable output modes (e.g. ``{"jobs": [...]}`` from
          ``jobs list``).
        - ``--output yaml`` uses the same ``job_events`` wrapper and emits YAML.

        Use ``--output json`` or ``--output yaml`` when piping into a tool that
        expects the consistent wrapped shape; otherwise the unwrapped default
        JSON form is fine.
        """
        config = runtime.load_config()

        raw = str(job_type or "").strip()
        if raw.upper() in {JOB_TYPE_LOGIC, JOB_TYPE_SOLVER, JOB_TYPE_ML}:
            jtype = raw.upper()
        else:
            jtype = normalize_job_type(raw)

        stream = (stream_name or "").strip()
        if not stream:
            stream = "profiler" if (config.direct_access and jtype == JOB_TYPE_LOGIC) else "progress"

        with runtime.cli_connect_sync(config) as client:
            ev = runtime.run_with_spinner(
                f"Fetching events for job {job_id}...",
                lambda: client.jobs.get_events(
                    str(jtype),
                    str(job_id),
                    continuation_token=str(continuation_token or ""),
                    stream_name=str(stream),
                ),
            )

        events_payload: dict[str, Any] = {
            "events": getattr(ev, "events", []),
            "continuation_token": getattr(ev, "continuation_token", None),
        }
        # See the command docstring above for why the default output and
        # explicit machine-readable output modes use different wrapper shapes.
        # The runtime emitters use ``click.echo`` and bypass Rich markup, so
        # bracketed sequences inside event payloads can't corrupt the output.
        #
        # Use ``lenient=True``: events come straight from the service layer
        # as ``dict[str, Any]`` and can contain types that Python's stdlib
        # ``json`` module doesn't know how to serialize (Decimal,
        # service-layer dataclasses, etc.). The pre-refactor code achieved
        # this with ``default=str``; the lenient JSON default preserves
        # that behavior so a successful ``get_events`` call never crashes
        # at print time.
        if not runtime.emit_cli_result("job_events", events_payload, lenient=True):
            runtime.emit_cli_json(events_payload, lenient=True)

    add_colon_alias(root=cli, canonical=jobs_events, colon_name="jobs:events", space_name="jobs events")


# ── jobs wait ────────────────────────────────────────────────────────────────


def _register_wait(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="wait")
    @job_options_type_id()
    @job_wait_options(default_timeout_s=900.0, default_poll_s=0.5)
    @include_in_docs
    @handle_cli_errors(
        name="jobs wait",
        message="Failed to wait for job.",
        click_message="Jobs wait failed.",
        params=params_job_type_id,
    )
    def jobs_wait(job_type: str | None, job_id: str | None, timeout_s: float, poll_interval_s: float) -> None:
        """Wait until a job reaches a terminal state."""
        with runtime.cli_session() as (config, interactive, client):
            picked = ensure_job_identity(
                client.jobs,
                config=config,
                job_type=job_type,
                job_id=job_id,
                interactive=interactive,
                prompt="Select a job to wait on:",
            )
            if picked is None:
                return
            jtype, jid = picked
            job_result = run_job_wait_with_guidance(
                lambda: wait_for_job_with_ui(
                    jobs=client.jobs,
                    job_type=str(jtype),
                    job_type_label=jtype,
                    job_id=str(jid),
                    timeout_s=timeout_s,
                    poll_interval_s=poll_interval_s,
                    stream_name=default_event_stream(
                        job_type=str(jtype), direct_access=config.direct_access
                    ),
                ),
                job_type_label=jtype,
                job_id=jid,
                timeout_s=float(timeout_s),
            )
            emit_job_result(job_result)

    add_colon_alias(root=cli, canonical=jobs_wait, colon_name="jobs:wait", space_name="jobs wait")


# ── jobs cancel ──────────────────────────────────────────────────────────────


def _register_cancel(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="cancel")
    @job_options_type_id()
    @include_in_docs
    @handle_cli_errors(
        name="jobs cancel",
        message="Failed to cancel job.",
        click_message="Jobs cancel failed.",
        params=params_job_type_id,
    )
    def jobs_cancel(job_type: str | None, job_id: str | None) -> None:
        """Cancel a job."""
        with runtime.cli_session() as (config, interactive, client):
            picked = ensure_job_identity(
                client.jobs,
                config=config,
                job_type=job_type,
                job_id=job_id,
                interactive=interactive,
                prompt="Select a job to cancel:",
                only_active=True,
            )
            if picked is None:
                return
            jtype, jid = picked

            runtime.run_with_spinner(
                f"Cancelling job {jid}...",
                lambda: client.jobs.cancel(str(jtype), str(jid)),
            )
            job = runtime.run_with_spinner(
                f"Fetching job {jid}...",
                lambda: client.jobs.get(str(jtype), str(jid), include=None),
            )
            if job is not None:
                show_job(job)

    add_colon_alias(root=cli, canonical=jobs_cancel, colon_name="jobs:cancel", space_name="jobs cancel")


# ── jobs create ──────────────────────────────────────────────────────────────


def _register_create(cli: click.Group, jobs_group: click.Group) -> None:
    @jobs_group.command(name="create")
    @click.option("--type", "job_type", required=False, default=None,
                  help="Job type (Logic/Prescriptive/Predictive).")
    @click.option("--reasoner-name", "--name", "reasoner_name", required=False, default=None,
                  help="Reasoner name to run on (optional).")
    @click.option("--database", default=None, help="Database (required for Logic when composing a payload).")
    @click.option("--raw-code", default=None, help="Raw code for payload construction.")
    @click.option("--raw-code-file", type=click.Path(exists=True, dir_okay=False, path_type=Path), default=None)
    @click.option("--inputs-json", default=None, help="Inputs JSON object (default: {}).")
    @click.option("--headers-json", default=None, help="Headers JSON object (optional).")
    @click.option("--language", default="rel", show_default=True)
    @click.option(
        "--payload-json",
        default="{}",
        show_default=True,
        help="JSON object to override/extend the composed payload; must decode to a dict.",
    )
    @click.option("--timeout-mins", type=int, default=None)
    @job_wait_options(default_timeout_s=900.0, default_poll_s=0.5)
    @click.option("--bypass-index", is_flag=True)
    @click.option("--gi-setup-skipped", is_flag=True)
    @click.option("--readonly/--readwrite", default=True, show_default=True)
    @click.option(
        "--wait/--no-wait",
        default=False,
        show_default=True,
        help="Wait until the job reaches a terminal state before returning.",
    )
    @include_in_docs
    @handle_cli_errors(
        name="jobs create",
        message="Failed to create job.",
        click_message="Jobs create failed.",
    )
    def jobs_create(
        job_type: str | None,
        reasoner_name: str | None,
        database: str | None,
        raw_code: str | None,
        raw_code_file: Path | None,
        inputs_json: str | None,
        headers_json: str | None,
        language: str,
        payload_json: str,
        timeout_mins: int | None,
        timeout_s: float,
        poll_interval_s: float,
        bypass_index: bool,
        gi_setup_skipped: bool,
        readonly: bool,
        wait: bool,
    ) -> None:
        """Create a job.

        ``--payload-json`` accepts a JSON object and is applied last, so it can
        override values composed from convenience flags such as ``--database``,
        ``--raw-code``, ``--inputs-json``, and ``--headers-json``.

        The composed payload always includes convenience keys such as:
        - ``raw_code``
        - ``inputs``
        - optionally ``headers`` and ``timeout_mins``

        For ``Logic``, it also adds transaction-style keys such as:
        - ``dbname``
        - ``query``
        - ``v1_inputs``

        Examples
        --------
        Logic:

        ``rai jobs create --type Logic --name TEST --database my_db --raw-code 'def output = 1'``

        Logic with explicit payload:

        ``rai jobs create --type Logic --name TEST --payload-json '{"dbname":"my_db","query":"def output = 1"}'``

        Prescriptive with explicit payload:

        ``rai jobs create --type Prescriptive --name TEST --payload-json '{"raw_code":"solve {}","inputs":{"x":1}}'``
        """
        config = runtime.load_config()
        interactive = runtime.is_interactive()

        t_public, t_label = ensure_job_type(job_type, interactive=interactive, console=runtime.console)
        reasoner_name_norm = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        set_error_params({"reasoner_type": t_public, "reasoner_name": reasoner_name_norm})

        if raw_code_file is not None:
            raw_code = raw_code_file.read_text(encoding="utf-8")

        payload_override = parse_json_object(payload_json, flag="--payload-json") or {}
        inputs = parse_json_object(inputs_json, flag="--inputs-json", allow_missing=True)
        headers = parse_json_object(headers_json, flag="--headers-json", allow_missing=True)

        raw_code, database = prompt_missing_logic_fields(
            t_public=t_public,
            raw_code=raw_code,
            database=database,
            payload_override=payload_override,
            interactive=interactive,
        )

        payload = build_payload(
            t_public=t_public,
            database=database,
            raw_code=raw_code,
            inputs=inputs,
            headers=headers,
            language=language,
            readonly=readonly,
            timeout_mins=timeout_mins,
            bypass_index=bypass_index,
            gi_setup_skipped=gi_setup_skipped,
            payload_override=payload_override,
        )

        with runtime.cli_connect_sync(config) as client:
            submit_and_maybe_wait(
                client=client,
                config=config,
                t_public=t_public,
                t_label=t_label,
                reasoner_name_norm=reasoner_name_norm,
                payload=payload,
                timeout_mins=timeout_mins,
                wait=wait,
                timeout_s=timeout_s,
                poll_interval_s=poll_interval_s,
            )

    add_colon_alias(root=cli, canonical=jobs_create, colon_name="jobs:create", space_name="jobs create")
