"""``rai config env`` — print the environment variables the CLI honors.

Lives under the ``config`` subgroup because the env-var registry is
part of the same configuration surface as ``rai config explain`` /
``rai config use``: profile selection, output preferences, and runtime
gates that resolve into the active :class:`Config`. Co-locating with
``rai config`` follows the dominant pattern in major CLIs
(``aws configure list``, ``pip config debug``, ``git config --list``)
where "what env vars / settings does this CLI honor?" is a member of
the configuration command tree rather than a top-level verb.

Consumes the registry in :mod:`relationalai.tools.cli.env` so there's
exactly one place to add a new env var; the table self-updates.

Honors the global ``--json`` / ``--output yaml`` like every other
list command (envelope: ``{"env": [...]}``) and uses ``render_list``
so paging conventions stay uniform (no pagination needed today, but
the renderer is the shared one).
"""

from __future__ import annotations

import click
from rich.markup import escape
from rich.table import Table

from .. import runtime
from ..env import KnownEnvVar, current_values
from ..render import render_list


def _env_record_as_json(entry: tuple[KnownEnvVar, str | None, bool]) -> dict[str, object]:
    """Map one ``current_values`` row to a JSON-friendly dict.

    Note ``value`` is the raw env content (or ``None`` when unset); we
    don't redact here because none of the registered vars are secrets —
    if a secret-bearing var is ever added, redact it inline.
    """
    var, raw, is_set = entry
    return {
        "name": var.name,
        "description": var.description,
        "kind": var.kind,
        "default": var.default,
        "set": is_set,
        "value": raw,
    }


def _render_env_table(items: list[tuple[KnownEnvVar, str | None, bool]]) -> None:
    """Render the env table for the human (table) output mode.

    ``default`` stays out of the table to avoid crowding narrow terminals,
    but each description is prefixed with ``[kind] `` so the expected value
    shape is visible next to prose. Structured output still exposes
    ``kind`` / ``default`` as separate JSON fields.
    """
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Variable", style="cyan", no_wrap=True)
    table.add_column("Set?", no_wrap=True)
    table.add_column("Value", overflow="fold")
    table.add_column("Description", overflow="fold")

    for var, raw, is_set in items:
        set_label = "[green]yes[/green]" if is_set else "[dim]no[/dim]"
        if raw is None:
            value_label = "[dim]—[/dim]"
        elif raw == "":
            value_label = "[dim](empty)[/dim]"
        else:
            value_label = raw
        # ``[kind]`` matches Rich's markup syntax unless escaped; without
        # escape the tag is swallowed and only the prose remains.
        desc = escape(f"[{var.kind}] {var.description}")
        table.add_row(var.name, set_label, value_label, desc)

    runtime.console.print(table)


def register(cli: click.Group) -> None:
    """Attach ``rai config env`` to the ``config`` subgroup.

    Resolves the ``config`` subgroup from the root at registration time
    rather than hard-importing the group object: keeps registration
    order explicit (``init_cmd.register`` must run first to create the
    group, see ``commands/__init__.py:register_all``) and degrades
    gracefully — if the group is missing for any reason, the env command
    is simply skipped rather than crashing every CLI invocation.
    """
    config_group = cli.commands.get("config")
    if not isinstance(config_group, click.Group):
        # ``init_cmd.register`` should have created this group already
        # (see ``commands/__init__.py:register_all`` for the order). If
        # it didn't, skipping the registration is preferable to
        # crashing every ``rai`` invocation; ``rai config env`` will
        # fail with the standard "no such command" message rather than
        # an AttributeError.
        return

    @config_group.command(name="env")
    def env_cmd() -> None:
        """Show the environment variables the CLI honors.

        Useful when troubleshooting: lists each known variable, whether
        it's currently set in the calling shell, and what the CLI will
        do with it.

        Add ``--output json`` / ``--json`` for ``{"env": [...]}`` with
        separate ``kind`` and ``default`` fields; in table mode the
        Description column is ``[kind] <text>``.
        """
        render_list(
            current_values(),
            json_key="env",
            json_mapper=_env_record_as_json,
            renderer=_render_env_table,
            empty_message="[yellow]No environment variables registered.[/yellow]",
        )
