"""Private helpers scoped to ``commands/reasoners.py``.

Kept in a sibling module so the command module stays focused on Click wiring.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

import click

from relationalai.services.reasoners import constants as reasoner_constants
from relationalai.services.reasoners.errors import ReasonerTimeoutError

from .. import runtime
from ..flows import ensure_reasoner_name, ensure_reasoner_type, select_reasoner
from ..long_running import poll_until_done, should_use_live_status
from ..markup import tip

F = TypeVar("F", bound=Callable[..., Any])


def reasoner_options_type_name(
    *,
    type_help: str = "Reasoner type (Logic/Prescriptive/Predictive) (optional).",
    name_help: str = "Reasoner name (optional).",
) -> Callable[[F], F]:
    """``--type`` / ``--name`` options shared by every reasoner command."""

    def decorator(cmd: F) -> F:
        cmd = click.option("--type", "reasoner_type", required=False, default=None, help=type_help)(cmd)
        cmd = click.option("--name", "reasoner_name", required=False, default=None, help=name_help)(cmd)
        return cmd

    return decorator


reasoner_options_type_name_filter = reasoner_options_type_name(
    type_help="Reasoner type filter (Logic/Prescriptive/Predictive) (optional).",
    name_help="Reasoner name (optional).",
)
reasoner_options_type_name_direct = reasoner_options_type_name(
    type_help="Reasoner type (Logic/Prescriptive/Predictive) (optional).",
    name_help="Reasoner name (optional).",
)


def print_reasoner_async_operation_started(
    *,
    verb: str,
    operation_id: str,
    t_label: str,
    name: str,
) -> None:
    """Emit the standard "operation accepted, running in background" message.

    Gates on :func:`runtime.cli_wants_machine_output` so JSON *and* YAML
    both emit the structured ``{"operation": …}`` envelope via
    :func:`runtime.emit_cli_output`. Pre-fix this used ``cli_wants_json``
    only — under ``--output yaml`` the helper silently fell through to
    the human "OK" + tips block, leaving callers without the structured
    operation id.
    """
    if runtime.emit_cli_result(
        "operation",
        {
            "id": operation_id,
            "verb": verb,
            "reasoner_type": t_label,
            "reasoner_name": name,
        },
    ):
        return
    # The "OK (operation_id=…)" headline is stdout — it's the success
    # signal a script might still want to capture. The follow-up
    # background-instructions block is advisory and goes to stderr.
    runtime.console.print(f"[green]{verb}: OK[/green] (operation_id={operation_id})")
    runtime.stderr_console.print("")
    if verb == "create":
        runtime.stderr_console.print("Reasoner creation has started and will continue in the background.")
    else:
        runtime.stderr_console.print("Reasoner resume has started and will continue in the background.")
    runtime.stderr_console.print(
        f"Check status: [green]rai reasoners get --type {t_label} --name {name}[/green]"
    )
    runtime.stderr_console.print(
        f"Wait until READY: [green]rai reasoners wait --type {t_label} --name {name}[/green]"
    )
    runtime.stderr_console.print(
        tip(f"pass [cyan]--wait[/cyan] to [cyan]rai reasoners {verb}[/cyan] next time to block until READY.")
    )


def reasoner_wait_guidance(
    headline: str,
    *,
    reasoner_type_label: str,
    reasoner_name: str,
    timeout_s: int | float | None = None,
) -> str:
    """Actionable message for local reasoner wait timeout/interrupt exits."""
    lines = [headline]
    if timeout_s is not None:
        lines.append(f"Waited for {timeout_s:g}s.")
    lines.extend(
        [
            "",
            "The remote reasoner operation may still be running.",
            "",
            "Resume waiting with:",
            f"  rai reasoners wait --type {reasoner_type_label} --name {reasoner_name}",
            "",
            "Check current status with:",
            f"  rai reasoners get --type {reasoner_type_label} --name {reasoner_name}",
        ]
    )
    return "\n".join(lines)


def run_reasoner_wait_with_guidance(
    fn: Callable[[], Any],
    *,
    reasoner_type_label: str,
    reasoner_name: str,
    timeout_s: int | float,
) -> Any:
    """Run ``fn`` and translate timeouts / Ctrl+C into reasoner wait guidance.

    Centralizes the boilerplate ``timeout_message`` / ``interrupted_message``
    / ``timeout_exceptions`` block that every ``reasoners`` wait call site
    would otherwise repeat verbatim.
    """
    return runtime.run_wait_with_guidance(
        fn,
        timeout_exceptions=(ReasonerTimeoutError,),
        timeout_message=reasoner_wait_guidance(
            "Timed out while waiting for the reasoner to become READY.",
            reasoner_type_label=reasoner_type_label,
            reasoner_name=reasoner_name,
            timeout_s=timeout_s,
        ),
        interrupted_message=reasoner_wait_guidance(
            "Stopped waiting because the command was interrupted.",
            reasoner_type_label=reasoner_type_label,
            reasoner_name=reasoner_name,
        ),
    )


def _reasoner_failed_message(
    *,
    state: str,
    reasoner_type_label: str,
    reasoner_name: str,
) -> str:
    """Actionable message when a reasoner enters a terminal failure state.

    Distinct from :func:`reasoner_stuck_state_message` (states the user can
    recover from with a single command) and from the generic timeout
    guidance: a ``FAILED`` / ``ERROR`` reasoner means the backend already
    decided the operation is over, so the user needs the inspect-and-act
    path, not "wait longer".
    """
    state_upper = state.upper()
    return "\n".join(
        [
            f"Reasoner entered terminal state {state_upper}.",
            "",
            "Inspect the reasoner with:",
            f"  rai reasoners get --type {reasoner_type_label} --name {reasoner_name}",
            "",
            "If the failure is recoverable, delete and recreate it with:",
            f"  rai reasoners delete --type {reasoner_type_label} --name {reasoner_name}",
            f"  rai reasoners create --type {reasoner_type_label} --name {reasoner_name} --wait",
        ]
    )


def reasoner_stuck_state_message(
    *,
    state: str,
    reasoner_type_label: str,
    reasoner_name: str,
) -> str:
    """Actionable message when ``reasoners wait`` observes a non-progressing state."""
    state_upper = state.upper()
    lines = [
        f"Reasoner is {state_upper}. It will not become READY without an explicit action.",
        "",
    ]
    if state_upper == reasoner_constants.REASONER_STATE_SUSPENDED:
        lines.extend(
            [
                "Resume the reasoner with:",
                f"  rai reasoners resume --type {reasoner_type_label} --name {reasoner_name} --wait",
                "",
                "Or check current status with:",
                f"  rai reasoners get --type {reasoner_type_label} --name {reasoner_name}",
            ]
        )
    else:
        lines.extend(
            [
                "Check current status with:",
                f"  rai reasoners get --type {reasoner_type_label} --name {reasoner_name}",
            ]
        )
    return "\n".join(lines)


def wait_for_reasoner_ready_with_ui(
    *,
    reasoners: Any,
    reasoner_type: str,
    reasoner_type_label: str,
    reasoner_name: str,
    timeout_s: int | float,
    poll_interval_s: float = 2.0,
    stuck_states: set[str] | None = None,
) -> Any:
    """Wait for READY with a live status panel in human mode.

    ``stuck_states`` lists reasoner states that should fail fast with actionable
    guidance instead of polling indefinitely (e.g. ``{"SUSPENDED"}`` for the
    standalone ``reasoners wait`` command — a suspended reasoner will never
    reach READY without an explicit resume).
    """
    if not should_use_live_status():
        # ``should_use_live_status`` already accounts for ``--json`` (returns
        # False under JSON output), so a single check covers both the
        # machine-readable and dumb-terminal paths. Service-level wait still
        # raises on the failed states it knows about; we additionally check
        # stuck states up front to avoid blocking on a state that will never
        # progress on its own.
        if stuck_states:
            initial = reasoners.get(reasoner_type=reasoner_type, reasoner_name=reasoner_name)
            initial_state = str(getattr(initial, "state", "") or "").upper()
            if initial_state in {s.upper() for s in stuck_states}:
                raise click.ClickException(
                    reasoner_stuck_state_message(
                        state=initial_state,
                        reasoner_type_label=reasoner_type_label,
                        reasoner_name=reasoner_name,
                    )
                )
        return reasoners.wait_until_ready(
            reasoner_type=reasoner_type,
            reasoner_name=reasoner_name,
            timeout_s=timeout_s,
        )

    stuck_upper = {s.upper() for s in (stuck_states or set())}

    def _done(reasoner: Any) -> bool:
        state = str(getattr(reasoner, "state", "") or "").upper()
        if state in reasoner_constants.REASONER_FAILED_STATES:
            # The reasoner reported a definitive failure. Raise a
            # ``ClickException`` with the actual state so the user sees
            # "FAILED" / "ERROR" verbatim — not the generic timeout
            # guidance that ``run_wait_with_guidance`` would attach if we
            # raised ``ReasonerTimeoutError`` here.
            raise click.ClickException(
                _reasoner_failed_message(
                    state=state,
                    reasoner_type_label=reasoner_type_label,
                    reasoner_name=reasoner_name,
                )
            )
        if state in stuck_upper:
            raise click.ClickException(
                reasoner_stuck_state_message(
                    state=state,
                    reasoner_type_label=reasoner_type_label,
                    reasoner_name=reasoner_name,
                )
            )
        return state == reasoner_constants.REASONER_STATE_READY

    return poll_until_done(
        label="Reasoner wait",
        subject=f"{reasoner_type_label} reasoner {reasoner_name}",
        poll=lambda: reasoners.get(reasoner_type=reasoner_type, reasoner_name=reasoner_name),
        state_of=lambda reasoner: str(getattr(reasoner, "state", "") or "waiting"),
        is_done=_done,
        timeout_s=float(timeout_s),
        poll_interval_s=float(poll_interval_s),
        timeout_error=lambda: ReasonerTimeoutError(f"Timed out after {timeout_s:g}s waiting for completion"),
    )


def _require_reasoner_identity_non_interactive(
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
) -> None:
    if interactive:
        return
    if not (reasoner_type or "").strip():
        raise click.ClickException("Reasoner type is required. Use --type.")
    if not (reasoner_name or "").strip():
        raise click.ClickException("Reasoner name is required. Use --name.")


def resolve_reasoner_target(
    reasoners: Any,
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
    prompt: str,
    state: str | None = None,
    exclude_states: set[str] | None = None,
) -> tuple[str, str, str] | None:
    """Resolve a reasoner target to ``(normalized_type, display_label, name)``."""
    _require_reasoner_identity_non_interactive(
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        interactive=interactive,
    )

    if reasoner_name and not reasoner_type:
        t_norm, t_label = ensure_reasoner_type(None, interactive=interactive, console=runtime.console)
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        return t_norm, t_label, name

    if reasoner_type and reasoner_name:
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=runtime.console)
        # Funnel through ``ensure_reasoner_name`` so whitespace stripping and
        # validation match the other branches before we hit the backend.
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=runtime.console)
        return t_norm, t_label, name

    picked = select_reasoner(
        reasoners,
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        state=state,
        exclude_states=exclude_states,
        interactive=interactive,
        console=runtime.console,
        prompt=prompt,
    )
    if picked is None:
        return None

    r_type, r_name = picked
    t_norm, t_label = ensure_reasoner_type(r_type, interactive=interactive, console=runtime.console)
    return t_norm, t_label, r_name


def reasoner_with_state(
    *,
    reasoner: Any | None,
    reasoner_type: str,
    reasoner_name: str,
    state: str,
) -> dict[str, Any]:
    """Return a displayable reasoner-like mapping with an overridden state."""
    data: dict[str, Any] = {
        "name": reasoner_name,
        "type": reasoner_type,
        "state": state,
    }
    if reasoner is not None:
        for key in (
            "id",
            "name",
            "type",
            "size",
            "state",
            "created_by",
            "created_on",
            "updated_on",
            "auto_suspend_mins",
            "suspends_at",
            "settings",
        ):
            value = getattr(reasoner, key, None)
            if value is not None:
                data[key] = value
        data["state"] = state
    return data
