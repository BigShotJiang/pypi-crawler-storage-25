"""``rai connect`` — validate config and database connection."""

from __future__ import annotations

import click
from rich.panel import Panel

from ....util.docutils import include_in_docs
from .. import runtime
from ..connection_validation import get_connection_suggestion, validate_session


def register(cli: click.Group) -> None:
    @cli.command()
    @include_in_docs
    def connect() -> None:
        """Validate config and database connection."""
        config = runtime.load_config()

        try:
            from ..display import show_connect_panel
            connection = show_connect_panel(config, runtime.console)
        except Exception as e:
            raise click.ClickException(f"Failed to resolve default connection: {e}") from e

        err: Exception | None = None
        try:
            session = connection.get_session()
            warehouse = getattr(connection, "warehouse", None)
            validate_session(session, warehouse=warehouse)
        except Exception as e:
            err = e

        if err is None:
            runtime.console.print("[bold green]✓[/bold green] Connected successfully\n")
            return

        runtime.console.print("[bold red]✗[/bold red] Connection failed\n")
        suggestion = get_connection_suggestion(str(err))
        if suggestion:
            runtime.console.print(
                Panel(
                    suggestion,
                    title="[bold yellow]Suggestion[/bold yellow]",
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
        runtime.console.print(
            "[dim]Run [bold]rai config explain[/bold] to inspect your active config "
            "and where each value comes from.[/dim]\n"
        )
        raise click.ClickException(str(err)) from err
