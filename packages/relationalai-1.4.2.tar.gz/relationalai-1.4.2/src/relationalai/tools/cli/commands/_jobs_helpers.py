"""Private helpers scoped to ``commands/jobs.py``.

Operational note: guidance lines that used to ride stdout now print through
:data:`runtime.stderr_console` so payloads stay pipe-friendly — release notes
should mention ``2>&1`` / ``stderr`` redirection for automation that scraped
those tips from stdout.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from typing import Any, TYPE_CHECKING

import click

from relationalai.services.jobs.constants import JOB_TERMINAL_STATES
from relationalai.services.jobs.errors import JobTimeoutError
from relationalai.services.jobs.util import JobIncludeDict

from .. import runtime
from ..display import show_job
from ..flows import select_job
from ..job_types import JOB_TYPE_LOGIC, job_type_label
from ..long_running import poll_until_done, should_use_live_status
from ..markup import tip
from ..serialize import job_record_as_json

if TYPE_CHECKING:
    from relationalai.config.config import Config


# ── Background-operation messaging ───────────────────────────────────────────


def print_job_background_instructions(
    *,
    job_type_label: str,
    job_id: str,
    created: bool = True,
) -> None:
    """Print the "job is now running in background" follow-up block.

    Routed to **stderr** (via :data:`runtime.stderr_console`) so the
    primary stdout payload (the job table or JSON envelope already
    emitted by :func:`emit_job_result`) stays clean for piping.
    """
    if created:
        runtime.stderr_console.print("")
        runtime.stderr_console.print("Job started and will continue running in the background.")
    runtime.stderr_console.print(
        f"Wait for completion: [green]rai jobs wait --type {job_type_label} --id {job_id}[/green]"
    )
    runtime.stderr_console.print(
        f"Inspect events: [green]rai jobs events --type {job_type_label} --id {job_id}[/green]"
    )
    runtime.stderr_console.print(
        f"Cancel job: [green]rai jobs cancel --type {job_type_label} --id {job_id}[/green]"
    )
    runtime.stderr_console.print(
        tip("pass [cyan]--wait[/cyan] to [cyan]rai jobs create[/cyan] next time to block until COMPLETED.")
    )


def job_wait_guidance(
    headline: str,
    *,
    job_type_label: str,
    job_id: str,
    timeout_s: float | None = None,
) -> str:
    """Actionable message for local wait timeout/interrupt exits."""
    lines = [headline]
    if timeout_s is not None:
        lines.append(f"Waited for {timeout_s:g}s.")
    lines.extend(
        [
            "",
            "The remote job may still be running.",
            "",
            "Resume waiting with:",
            f"  rai jobs wait --type {job_type_label} --id {job_id}",
            "",
            "Inspect events with:",
            f"  rai jobs events --type {job_type_label} --id {job_id}",
            "",
            "Cancel the job with:",
            f"  rai jobs cancel --type {job_type_label} --id {job_id}",
        ]
    )
    return "\n".join(lines)


def run_job_wait_with_guidance(
    fn: Callable[[], Any],
    *,
    job_type_label: str,
    job_id: str,
    timeout_s: float,
) -> Any:
    """Run ``fn`` and translate timeouts / Ctrl+C into job wait guidance.

    Centralizes the boilerplate ``timeout_message`` / ``interrupted_message``
    / ``timeout_exceptions`` block that every ``jobs`` wait call site would
    otherwise repeat verbatim.
    """
    return runtime.run_wait_with_guidance(
        fn,
        timeout_exceptions=(JobTimeoutError,),
        timeout_message=job_wait_guidance(
            "Timed out while waiting for job completion.",
            job_type_label=job_type_label,
            job_id=job_id,
            timeout_s=timeout_s,
        ),
        interrupted_message=job_wait_guidance(
            "Stopped waiting because the command was interrupted.",
            job_type_label=job_type_label,
            job_id=job_id,
        ),
    )


def emit_job_result(job: Any, *, key: str = "job") -> None:
    """Emit a job in the active machine output format, otherwise render the human table.

    Gates on :func:`runtime.cli_wants_machine_output` so JSON *and* YAML
    both emit the structured ``{key: job_record_as_json(job)}`` envelope
    via :func:`runtime.emit_cli_output`. Pre-fix this used
    ``cli_wants_json`` directly, which silently fell back to the human
    table under ``--output yaml`` — a documented papercut for any
    script piping reasoner / job mutation output through ``yq``.
    """
    if runtime.emit_cli_result(key, job_record_as_json(job)):
        return
    show_job(job)


def _event_summary(event: Any) -> str:
    """Render a one-line summary of a job event for the live status detail.

    Output is hard-capped at 120 characters because it has to fit on the
    same line as the rest of the live status indicator. ``default=str`` is
    a safety net for service-layer values whose types ``json.dumps``
    doesn't natively understand (e.g. datetimes, dataclasses) — without it
    a single odd type would crash the wait UI. The truncation guarantees
    the renderer never widens past the live region regardless of payload
    contents (the upstream service already controls what fields it emits,
    so there's no PII surface area introduced here).
    """
    if isinstance(event, Mapping):
        for key in ("message", "msg", "status", "state", "event", "type"):
            value = event.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return json.dumps(dict(event), default=str)[:120]
    return str(event).strip()[:120]


def default_event_stream(*, job_type: str, direct_access: bool) -> str:
    """Pick the default events stream name for ``wait_for_job_with_ui``.

    Mirrors :func:`commands.jobs.jobs_events`: Direct Access Logic jobs use
    the ``profiler`` stream; everything else uses ``progress``. Hard-coding
    ``"progress"`` would make the live wait UI silently miss events for
    Direct Access Logic jobs.
    """
    return "profiler" if (direct_access and job_type.upper() == JOB_TYPE_LOGIC) else "progress"


def wait_for_job_with_ui(
    *,
    jobs: Any,
    job_type: str,
    job_type_label: str,
    job_id: str,
    timeout_s: float,
    poll_interval_s: float,
    stream_name: str | None = None,
) -> Any:
    """Wait for a job with live status in human mode and clean service wait in JSON mode.

    ``stream_name`` overrides the events stream used to populate the
    "Last update" detail of the live status indicator. Callers should pass
    the same stream they would use for ``rai jobs events`` (typically
    derived from :func:`_default_event_stream`).
    """
    # ``should_use_live_status`` already returns False under ``--json`` (and
    # for non-TTY stdout), so this single check covers both the
    # machine-readable and dumb-terminal paths.
    if not should_use_live_status():
        return jobs.wait(job_type, job_id, timeout_s=timeout_s, poll_interval_s=poll_interval_s)

    continuation_token = ""
    last_event: str | None = None
    effective_stream = (stream_name or "progress").strip() or "progress"

    def _poll_job() -> Any:
        nonlocal continuation_token, last_event
        job = jobs.get(str(job_type), str(job_id), include=None)
        get_events = getattr(jobs, "get_events", None)
        if callable(get_events):
            try:
                ev = get_events(
                    str(job_type),
                    str(job_id),
                    continuation_token=continuation_token,
                    stream_name=effective_stream,
                )
            except Exception:
                # The "Last update" line is purely informational. Logging at
                # debug level (rather than warning) so we don't spam stderr
                # during normal polling for short-lived events streams that
                # haven't been provisioned yet, but keep the trace
                # recoverable when investigating empty status panels.
                import logging

                logging.getLogger(__name__).debug(
                    "wait_for_job_with_ui: get_events poll failed (job_type=%s job_id=%s stream=%s)",
                    job_type,
                    job_id,
                    effective_stream,
                    exc_info=True,
                )
            else:
                continuation_token = str(getattr(ev, "continuation_token", "") or continuation_token)
                events = list(getattr(ev, "events", []) or [])
                if events:
                    last_event = _event_summary(events[-1])
        return job

    return poll_until_done(
        label="Job wait",
        subject=f"{job_type_label} job {job_id}",
        poll=_poll_job,
        state_of=lambda job: str(getattr(job, "state", "") or "waiting"),
        is_done=lambda job: str(getattr(job, "state", "") or "").upper() in JOB_TERMINAL_STATES,
        timeout_s=float(timeout_s),
        poll_interval_s=float(poll_interval_s),
        timeout_error=lambda: JobTimeoutError(
            f"Timed out after {timeout_s:g}s waiting for completion: reasoner_type={job_type} job_id={job_id}"
        ),
        detail=lambda: last_event,
    )


# ── Job ``--include`` helpers ────────────────────────────────────────────────


def job_include_from_flags(includes: tuple[str, ...]) -> JobIncludeDict | None:
    """Convert repeated ``--include`` flags into a typed :class:`JobIncludeDict`."""
    if not includes:
        return None

    inc: JobIncludeDict = {}
    for k in includes:
        match str(k).strip().lower():
            case "details":
                inc["details"] = True
            case "events":
                inc["events"] = True
            case "artifacts":
                inc["artifacts"] = True
            case "problems":
                inc["problems"] = True
            case "raw":
                inc["raw"] = True
    return inc


def job_get_include_from_flags(includes: tuple[str, ...]) -> JobIncludeDict:
    """Include dict for ``jobs get``: always includes ``details``."""
    extra = job_include_from_flags(includes)
    return {**(extra or {}), "details": True}


# ── Job identity resolution ──────────────────────────────────────────────────


def ensure_job_identity(
    jobs: Any,
    *,
    config: "Config",
    job_type: str | None,
    job_id: str | None,
    interactive: bool,
    prompt: str,
    only_active: bool = False,
) -> tuple[str, str] | None:
    """Return ``(job_type, job_id)`` for a job, prompting when needed."""
    jtype = job_type
    jid = job_id

    if jid and not (jtype and str(jtype).strip()):
        xs: list[Any] = []
        try:
            xs = jobs.list(None, job_id=jid, limit=5)
        except Exception:
            xs = []
        if len(xs) == 1:
            jtype = getattr(xs[0], "reasoner_type", None)
        elif len(xs) > 1 and interactive:
            picked = select_job(
                jobs,
                config=config,
                reasoner_type=None,
                job_id=jid,
                interactive=interactive,
                console=runtime.console,
                prompt=prompt,
                only_active=only_active,
            )
            if picked is None:
                return None
            jtype, jid = picked

    if not (jtype and str(jtype).strip() and jid and str(jid).strip()):
        if not interactive:
            raise click.ClickException("--type and --id are required (or run interactively).")
        picked = select_job(
            jobs,
            config=config,
            reasoner_type=jtype,
            job_id=jid,
            interactive=interactive,
            console=runtime.console,
            prompt=prompt,
            only_active=only_active,
        )
        if picked is None:
            return None
        jtype, jid = picked

    t_public = job_type_label(str(jtype)) or str(jtype)
    return str(t_public), str(jid)


# ── jobs:create payload helpers ──────────────────────────────────────────────


def parse_json_object(
    text: str | None, *, flag: str, allow_missing: bool = False
) -> dict[str, Any] | None:
    """Decode JSON and require it to be an object (dict)."""
    if text is None:
        if allow_missing:
            return None
        raise click.ClickException(f"{flag} is required but was not provided.")
    try:
        value = json.loads(text or "{}")
    except json.JSONDecodeError as e:
        raise click.ClickException(f"{flag} must be valid JSON. {e}") from e
    if not isinstance(value, dict):
        raise click.ClickException(f"{flag} must decode to a JSON object (dict).")
    return value


def prompt_missing_logic_fields(
    *,
    t_public: str,
    raw_code: str | None,
    database: str | None,
    payload_override: dict[str, Any],
    interactive: bool,
) -> tuple[str | None, str | None]:
    """Prompt for ``raw_code`` / ``database`` when missing and interactive."""
    from ..components import text_prompt

    if raw_code is None and payload_override == {}:
        if interactive:
            raw_code = text_prompt("Raw code:", default=None)
            runtime.console.print()
        else:
            raise click.ClickException(
                "No payload provided. Pass `--payload-json '{...}'` or provide `--raw-code` "
                "(and `--database` for Logic)."
            )

    if str(t_public).strip().lower() == "logic" and raw_code is not None and not database:
        if interactive:
            database = text_prompt("Database:", default=None)
            runtime.console.print()
        else:
            raise click.ClickException(
                "--database is required for Logic when using --raw-code/--raw-code-file."
            )

    return raw_code, database


def build_payload(
    *,
    t_public: str,
    database: str | None,
    raw_code: str | None,
    inputs: dict[str, Any] | None,
    headers: dict[str, Any] | None,
    language: str,
    readonly: bool,
    timeout_mins: int | None,
    bypass_index: bool,
    gi_setup_skipped: bool,
    payload_override: dict[str, Any],
) -> dict[str, Any]:
    from relationalai.services.jobs.util import compose_payload

    composed: dict[str, Any] = {}
    if raw_code is not None:
        composed = compose_payload(
            reasoner_type=t_public,
            database=database,
            raw_code=raw_code,
            inputs=inputs,
            readonly=bool(readonly),
            language=language,
            headers=headers,
            timeout_mins=timeout_mins,
            bypass_index=bool(bypass_index),
            gi_setup_skipped=bool(gi_setup_skipped),
        )

    payload = dict(composed)
    payload.update(payload_override)
    return payload


def submit_and_maybe_wait(
    *,
    client: Any,
    config: "Config",
    t_public: str,
    t_label: str,
    reasoner_name_norm: str,
    payload: dict[str, Any],
    timeout_mins: int | None,
    wait: bool,
    timeout_s: float,
    poll_interval_s: float,
) -> None:
    def _create() -> str:
        op = client.jobs.create(t_public, reasoner_name_norm, payload, timeout_mins=timeout_mins)
        return op.id

    op_id = runtime.run_with_spinner(
        f"Starting {t_label} job on reasoner '{reasoner_name_norm}'...",
        _create,
    )
    if not op_id:
        raise click.ClickException("Job create did not return an id.")

    if not wait:
        job = runtime.run_with_spinner(
            f"Fetching job {op_id}...",
            lambda: client.jobs.get(str(t_public), str(op_id), include=None),
        )
        if job is None:
            # ``cli_wants_machine_output`` covers JSON *and* YAML; pre-fix this
            # gated on ``cli_wants_json`` only, so ``--output yaml`` printed the
            # human "create: OK" line on top of (broken) human output.
            if runtime.emit_cli_result(
                "job",
                {"id": op_id, "reasoner_type": t_public, "name": reasoner_name_norm},
            ):
                return
            runtime.console.print(f"[green]create: OK[/green] (id={op_id})")
        else:
            emit_job_result(job)
            if runtime.cli_wants_machine_output():
                return
        print_job_background_instructions(job_type_label=t_label, job_id=op_id, created=True)
        return

    job_result = run_job_wait_with_guidance(
        lambda: wait_for_job_with_ui(
            jobs=client.jobs,
            job_type=str(t_public),
            job_type_label=t_label,
            job_id=str(op_id),
            timeout_s=float(timeout_s),
            poll_interval_s=float(poll_interval_s),
            stream_name=default_event_stream(
                job_type=str(t_public), direct_access=config.direct_access
            ),
        ),
        job_type_label=t_label,
        job_id=op_id,
        timeout_s=float(timeout_s),
    )
    emit_job_result(job_result)
    state = str(getattr(job_result, "state", "") or "").upper()
    if state and state not in {"COMPLETED", "SUCCEEDED"}:
        raise click.ClickException(f"Job finished in state {state}.")
