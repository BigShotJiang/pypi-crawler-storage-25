"""``rai debugger`` command."""

from __future__ import annotations

from pathlib import Path

import click

from ....util.docutils import include_in_docs


def register(cli: click.Group) -> None:
    @cli.command()
    @click.option(
        "--file",
        "file",
        default=None,
        type=click.Path(exists=True, dir_okay=False, path_type=Path),
        help="Primary trace file (defaults to the latest install run's spans.jsonl).",
    )
    @click.argument(
        "comparison",
        required=False,
        default=None,
        metavar="[COMPARISON]",
        type=click.Path(exists=True, dir_okay=False, path_type=Path),
    )
    @click.option("--host", default="0.0.0.0", show_default=True, help="Host to bind to.")
    @click.option("--port", "-p", default=8080, show_default=True, type=int, help="Port to listen on.")
    @include_in_docs
    def debugger(file: Path | None, comparison: Path | None, host: str, port: int) -> None:
        """Launch the PyRel debugger UI."""
        import sys

        try:
            from relationalai.tools import rai_debugger
        except ImportError as e:
            if "nicegui" not in str(e).lower():
                raise
            raise click.ClickException(
                "nicegui is required for the debugger. "
                "Install it with: pip install relationalai[debugger]"
            )

        # NiceGUI rebuilds pages by calling runpy.run_path(sys.argv[0], run_name='__main__').
        # We must point sys.argv[0] at rai_debugger.py so NiceGUI re-runs that script
        # instead of the `rai` CLI entry point (which would crash on re-execution).
        # We also keep host/port and optional file in argv so that re-execution preserves
        # non-default CLI flags (e.g. `--port 8083`) instead of silently falling back.
        orig_argv = sys.argv[:]
        # If you add a new arg to main() below, also forward it via sys.argv so re-execs see it.
        forwarded = ["--host", host, "--port", str(port)]
        if file:
            forwarded += ["--file", str(file)]
        if comparison:
            forwarded.append(str(comparison))
        sys.argv = [rai_debugger.__file__] + forwarded
        try:
            rai_debugger.main(host=host, port=port, file=str(file) if file else None, file2=str(comparison) if comparison else None)
        finally:
            sys.argv = orig_argv
