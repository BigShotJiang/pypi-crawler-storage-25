"""``rai diagnose`` — one-shot version + config + connection diagnostics.

Mirrors ``dbt debug``: Local config / Connection details / Connection
check, plus the tooling block we already collect for ``rai version``.
Three things this surfaces that no other CLI command does:

1. The resolved config file path (where ``create_config()`` looked).
2. Snowflake ``database`` / ``schema`` (now also in ``rai connect`` via
   the shared :func:`format_connection_info` helper).
3. Relevant env vars that change which config gets loaded.

Honors ``--json`` / ``--output yaml`` (envelope ``{"diagnose": {...}}``).
The connectivity probe runs by default; ``--no-connect`` skips it so the
command remains useful when network / credentials are broken.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import click
from rich.markup import escape as rich_escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ....config.errors import ConfigError
from ....util.docutils import include_in_docs

if TYPE_CHECKING:
    from relationalai.config.config import Config
from .. import runtime
from ..components import WaitSpinner
from ..connection_validation import CONNECTION_INFO_FIELDS
# Dual import is intentional: ``collect_diagnose_info`` is bound directly
# for ergonomics; ``_diagnose_helpers`` is kept as a module alias so unit
# tests can ``monkeypatch.setattr(_diagnose_helpers, "_check_connectivity",
# ...)`` and intercept the probe. Don't consolidate without updating tests.
from . import _diagnose_helpers
from ._diagnose_helpers import collect_diagnose_info, collect_diagnose_info_load_failed
from .version import _RAI_DEP_PACKAGES, _format_upstream_value


# ── module-level constants ───────────────────────────────────────────────────

_DIAGNOSE_PREAMBLE = (
    "Version, config, and connection diagnostics. "
    "Paste this into bug reports."
)


# ── small render helpers ─────────────────────────────────────────────────────


def _na(value: Any) -> str:
    """Stringify, rendering ``None`` / empty as ``"N/A"`` (matches ``format_value``)."""
    if value is None:
        return "N/A"
    text = str(value).strip()
    return text if text else "N/A"


def _add_section_header(table: Table, label: str) -> None:
    """Blank-row spacer + bold non-dim section header (Rich has no native separator)."""
    table.add_row("", "")
    table.add_row(Text(label, style="bold white not dim"), "")


# ── full-section renderers ───────────────────────────────────────────────────


def _render_tooling_rows(table: Table, version: dict[str, Any]) -> None:
    """Add the Tooling section to ``table`` (used by both config-found and no-config paths)."""
    table.add_row(Text("Tooling", style="bold white not dim"), "")
    table.add_row("rai", str(version["version"]))
    upstream = version.get("upstream")
    upstream_dict = upstream if isinstance(upstream, dict) else None
    table.add_row("relationalai-python", _format_upstream_value(upstream_dict))
    deps = version.get("dependencies") or {}
    for name in _RAI_DEP_PACKAGES:
        table.add_row(name, str(deps.get(name, "not installed")))
    table.add_row("Python", f"{version['python']} ({version['python_implementation']})")
    table.add_row("Platform", str(version["platform"]))
    table.add_row("Install path", str(version["install_path"]))
    table.add_row("Executable", str(version["executable"]))


def _render_local_config_env_rows(table: Table, env: dict[str, Any] | None) -> None:
    """Add only the env-var rows that are actually set (keeps output uncluttered)."""
    set_env = {k: v for k, v in (env or {}).items() if v is not None}
    for name, value in set_env.items():
        table.add_row(name, str(value))


def _render_static_sections(info: dict[str, Any]) -> None:
    """Render preamble + the three non-connectivity sections (tooling / local / connection).

    Split from the connectivity status so the static block flushes
    *before* the slow Snowflake probe runs — user sees version + config
    while the spinner waits. Preamble lives outside the table so it
    isn't constrained by the table's two-column layout.
    """
    runtime.console.print(f"[dim]{_DIAGNOSE_PREAMBLE}[/dim]")
    runtime.console.print()  # spacer before the first section

    version = info["version"]
    config = info["config"]
    connection = info["connection"]

    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
    table.add_column(style="dim cyan", no_wrap=True)
    table.add_column(style="white")

    _render_tooling_rows(table, version)

    # ─── Local Configuration ─────────────────────────────────────────────────
    _add_section_header(table, "Local Configuration")
    table.add_row("Config source", _na(config.get("source")))
    table.add_row("Config file", _na(config.get("file_path")))
    table.add_row("Active profile", _na(config.get("active_profile")))
    table.add_row("Default connection", _na(config.get("default_connection")))
    table.add_row("Direct access", str(config.get("direct_access", False)).lower())

    _render_local_config_env_rows(table, config.get("env"))

    # ─── Connection ──────────────────────────────────────────────────────────
    conn_name = connection.get("name") or "<unresolved>"
    _add_section_header(table, f"Connection: {conn_name}")
    conn_error = connection.get("error")
    if conn_error:
        # Escape: error text comes from arbitrary exceptions (Snowflake error
        # strings frequently contain ``[`` / ``]``) and Rich would otherwise
        # interpret them as markup tags and silently mis-render.
        table.add_row("Error", Text(conn_error))
    else:
        # Iterate the shared :data:`CONNECTION_INFO_FIELDS` so the human
        # render here can't drift from ``rai connect`` / the JSON envelope
        # if a new field is added to the canonical list. The ``_attr``
        # element is unused at the renderer (the collector keys ``fields``
        # by lowercased label) but stays in the constant so
        # :func:`format_connection_info` keeps a single source of truth.
        conn_fields = connection.get("fields") or {}
        for label, _attr in CONNECTION_INFO_FIELDS:
            value = conn_fields.get(label.lower())
            if value:
                table.add_row(label, str(value))

    runtime.console.print(table)


# ── per-error-type human render branches ─────────────────────────────────────


# Headline status text + suggestion-panel title per ``load_error.type``.
# Single source of truth so the table cell, the panel banner, and the
# JSON envelope's hint can never drift.
_LOAD_ERROR_LABELS: dict[str, dict[str, str]] = {
    "ConfigFileNotFoundError": {
        "status": "not found",
        "panel_title": "No config file",
    },
    "ConfigValidationError": {
        "status": "validation failed",
        "panel_title": "Config validation failed",
    },
}
_LOAD_ERROR_DEFAULT_LABELS: dict[str, str] = {
    "status": "load failed",
    "panel_title": "Config load failed",
}


def _labels_for(load_error: dict[str, Any]) -> dict[str, str]:
    """Pick status / panel-title text for the given ``load_error`` block."""
    return _LOAD_ERROR_LABELS.get(
        load_error.get("type") or "", _LOAD_ERROR_DEFAULT_LABELS
    )


def _render_load_failed_sections(info: dict[str, Any]) -> None:
    """Render the human path when ``runtime.load_config`` failed.

    Keeps the Tooling block intact so the output is still useful for bug
    reports (Python / platform / install path don't depend on having a
    working config). The Local Configuration section reports the
    failure type, surfaces the file path / attempted sources / Pydantic
    validation errors when known, and skips the Connection / Connectivity
    sections (there's no Config object to resolve).

    Branches by ``config.load_error.type``:

    - ``ConfigFileNotFoundError``: render attempted sources block.
    - ``ConfigValidationError``: render file path + per-field error list.
    - Anything else: fall back to the raw error message.
    """
    runtime.console.print(f"[dim]{_DIAGNOSE_PREAMBLE}[/dim]")
    runtime.console.print()

    version = info["version"]
    config = info["config"]
    load_error = config.get("load_error") or {}
    labels = _labels_for(load_error)

    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0))
    table.add_column(style="dim cyan", no_wrap=True)
    table.add_column(style="white")

    _render_tooling_rows(table, version)

    _add_section_header(table, "Local Configuration")
    # Use a styled value for the headline cell so the failure state is
    # visually obvious without dropping the two-column layout — the rest
    # of the rows still align with Tooling above.
    table.add_row("Config source", Text(labels["status"], style="yellow not dim"))
    table.add_row("Config file", _na(load_error.get("file_path") or config.get("file_path")))
    for label in ("Active profile", "Default connection"):
        table.add_row(label, _na(None))

    _render_local_config_env_rows(table, config.get("env"))

    attempted = load_error.get("attempted_sources") or []
    if attempted:
        table.add_row("", "")
        table.add_row(Text("Attempted sources", style="dim white"), "")
        for src in attempted:
            name = src.get("source_name") or "<unknown>"
            err = src.get("error_message") or ""
            table.add_row(f"  {name}", err)

    validation_errors = load_error.get("validation_errors") or []
    if validation_errors:
        table.add_row("", "")
        table.add_row(Text("Validation errors", style="dim white"), "")
        for verr in validation_errors:
            loc = verr.get("loc") or "<unknown>"
            msg = verr.get("msg") or ""
            etype = verr.get("type") or ""
            # ``Text(...)`` rather than markup — pydantic messages and
            # field paths can contain ``[`` / ``]`` (e.g. list indices).
            detail = f"{msg}" + (f" (type: {etype})" if etype else "")
            table.add_row(f"  {loc}", Text(detail))

    runtime.console.print(table)


def _render_load_failed_suggestion(info: dict[str, Any]) -> None:
    """Render the yellow suggestion panel; title varies per error type."""
    load_error = (info.get("config") or {}).get("load_error") or {}
    title = _labels_for(load_error)["panel_title"]
    suggestion = info["connectivity"].get("suggestion") or ""
    runtime.console.print()
    runtime.console.print(
        Panel(
            Text(suggestion),
            title=f"[bold yellow]{title}[/bold yellow]",
            border_style="yellow",
            padding=(1, 2),
        )
    )


def _render_connectivity(connectivity: dict[str, Any]) -> None:
    """Render the trailing connectivity status (success line / failure + suggestion / skipped)."""
    if connectivity.get("checked"):
        if connectivity.get("ok"):
            runtime.console.print("\n[bold green]✓[/bold green] Connected successfully")
        else:
            # Escape ``error``/``suggestion`` before they reach Rich:
            # Snowflake errors and (future) suggestion strings can include
            # ``[`` / ``]`` which Rich would otherwise treat as markup.
            error = connectivity.get("error") or "unknown error"
            runtime.console.print(
                f"\n[bold red]✗[/bold red] Connection failed: {rich_escape(error)}"
            )
            suggestion = connectivity.get("suggestion")
            if suggestion:
                runtime.console.print(
                    Panel(
                        Text(suggestion),
                        title="[bold yellow]Suggestion[/bold yellow]",
                        border_style="yellow",
                        padding=(1, 2),
                    )
                )
    else:
        runtime.console.print(
            "\n[dim]Connectivity check skipped (--no-connect).[/dim]"
        )


def register(cli: click.Group) -> None:
    """Attach the ``diagnose`` subcommand."""

    @cli.command(name="diagnose")
    @click.option(
        "--no-connect",
        is_flag=True,
        default=False,
        help=(
            "Skip the connectivity check (offline-safe). The other sections "
            "are still printed."
        ),
    )
    @include_in_docs
    def diagnose_cmd(no_connect: bool) -> None:
        """Print version, config, and connection diagnostics for bug reports.

        Renders the installed ``rai`` version + Python runtime, the active
        config file and profile, the resolved default connection's fields,
        and (unless ``--no-connect``) a Snowflake ``select 1`` smoke test.

        Robust to *any* config-load failure (missing file, schema
        validation error, malformed YAML, etc.): the Tooling block plus a
        ``"Local Configuration: <status>"`` row are always rendered so the
        output remains useful in bug reports. The yellow suggestion panel
        adapts to the error type — missing file → ``rai init``; validation
        failure → "fix the listed fields"; any other error → "see the error
        above".

        Honors ``--json`` / ``--output yaml`` to emit a single
        ``{"diagnose": {...}}`` envelope; scripts always receive every
        section regardless of ``--no-connect`` (the ``connectivity.checked``
        flag tells consumers whether the probe ran). When config loading
        fails, ``config.found`` is ``false`` and ``config.load_error``
        carries a uniform ``{type, message, file_path, location,
        attempted_sources, validation_errors}`` block — branch on
        ``load_error.type`` for type-specific details.

        Exit codes:

        - ``0`` — diagnostics rendered cleanly *and* (a) connectivity probe
          succeeded, or (b) ``--no-connect`` was passed (report is the
          deliverable; user opted out of validation).
        - ``1`` — connectivity probe ran and failed, *or* config could not
          be loaded and ``--no-connect`` was not passed.

        \b
        Examples:
          rai diagnose
          rai diagnose --no-connect
          rai diagnose --json
          rai diagnose --output yaml
        """
        # Catch every config-load failure here — missing file, schema
        # validation, malformed YAML, etc. — so the rest of the command
        # can render a useful diagnostics block instead of bailing out
        # with an unparseable Click error. Recovery is gated on
        # ``ConfigError`` (the public base class for config-related
        # exceptions); anything else propagates so we don't silently
        # swallow real bugs.
        config: Config | None
        load_error: ConfigError | None = None
        try:
            config = runtime.load_config()
        except click.ClickException as e:
            cause = getattr(e, "__cause__", None)
            if isinstance(cause, ConfigError):
                config = None
                load_error = cause
            else:
                raise

        # ── Config-load-failed path ─────────────────────────────────────────
        if config is None:
            info = collect_diagnose_info_load_failed(load_error)
            if not runtime.emit_cli_result("diagnose", info):
                _render_load_failed_sections(info)
                _render_load_failed_suggestion(info)
            # ``--no-connect`` makes diagnose a pure reporting tool; user
            # explicitly opted out of validation so a missing/broken
            # config is not an exit-code-worthy event. Without
            # ``--no-connect`` the implicit connectivity check cannot
            # run, which mirrors a failed probe → exit 1.
            if not no_connect:
                raise click.ClickException(
                    info["connectivity"].get("error") or "Config could not be loaded"
                )
            return

        # Machine output: single envelope, no spinner (JSON/YAML consumers
        # parse stdout; spinner escape codes would corrupt that). The
        # gating check is folded into ``emit_cli_result`` itself — when
        # it returns True the envelope was emitted and we still need to
        # run the connectivity exit-code check before returning.
        if runtime.cli_wants_machine_output():
            info = collect_diagnose_info(config, with_connectivity=not no_connect)
            # Already in machine-readable mode — ``emit_cli_result`` emits and
            # returns ``True``. Return value intentionally unused; flow below
            # needs connectivity for exit-code parity.
            runtime.emit_cli_result("diagnose", info)
            connectivity = info["connectivity"]
            if connectivity.get("checked") and not connectivity.get("ok"):
                raise click.ClickException(
                    connectivity.get("error") or "Connection failed"
                )
            return

        # Human path: render the static block first so the user sees
        # version + config while the slow Snowflake probe runs under a
        # spinner. Without the split the terminal sits silent for several
        # seconds (cold JWT auth) and users assume it's hung.
        info = collect_diagnose_info(config, with_connectivity=False)
        _render_static_sections(info)

        if no_connect:
            _render_connectivity(info["connectivity"])
            return

        runtime.console.print()  # spacer before the spinner

        # Module-attr access (not the bound name) keeps the test
        # monkeypatch effective — see dual-import note at file top.
        with WaitSpinner("Checking Snowflake connection..."):
            connectivity = _diagnose_helpers._check_connectivity(config)

        _render_connectivity(connectivity)
        if not connectivity.get("ok"):
            # Match ``rai connect``'s exit-code semantics. Error +
            # suggestion are already rendered above; raise bare to drive
            # the non-zero exit without re-printing.
            raise click.ClickException(connectivity.get("error") or "Connection failed")
