"""``rai models`` subgroup commands.

Only ``models install`` is real today; the others are placeholder scaffolds
that print "Not implemented".

The whole ``models`` subgroup is registered with ``hidden=True`` because
the surface is still being designed and we don't want any of it to show
up in ``rai --help`` while that's in flight. The ``@include_in_docs``
decorator gates inclusion in auto-generated docs: it's applied only to
the real commands so the docs don't advertise placeholders as features.
When a placeholder becomes real, drop ``hidden=True`` (or remove all of
them at once when the surface is ready) and add ``@include_in_docs`` to
the corresponding command.

Each command also has a hidden colon alias (``models:install`` etc.) so
older scripts and demo READMEs that reference the colon form keep working
while we land the noun-verb migration.
"""

from __future__ import annotations

from pathlib import Path

import click

from ....util.docutils import include_in_docs
from .. import runtime
from .._group import RaiSubGroup
from ._common import add_colon_alias, pagination_options, stubs_enabled
from ._models_helpers import install_model


def register(cli: click.Group) -> None:
    @cli.group(name="models", hidden=True, cls=RaiSubGroup)
    def models_group() -> None:
        """Manage semantic model schemas (work in progress)."""

    @models_group.command(name="install", hidden=True)
    @click.option("--model-file-path", default=None, type=click.Path(exists=True, dir_okay=False, path_type=Path),
        help="Path to the model file to install. If omitted, will use the model_file_path from the config file."
    )
    @click.option("--name", "model_name", default=None,
        help="Name of the model to install. If omitted, will install the last model created by the target.",
    )
    @click.option("--schema", required=False, default=None,
        help="Target schema to install the model to (defaults to schema from the config file)."
    )
    @click.option("--force", is_flag=True, default=False, help="Force install, overriding divergence checks.")
    @include_in_docs
    def models_install(model_file_path: Path|None, model_name: str|None, schema: str|None, force: bool):
        """Install a model into a schema."""
        install_model(model_file_path, model_name, schema, force)

    @models_group.command(name="dump", hidden=True)
    @click.option(
        "--output", "-o",
        "output",
        type=click.Path(path_type=Path),
        default=None,
        help="Output zip file path, or a directory in which to write a timestamped zip. Defaults to a timestamped zip in the current directory.",
    )
    def models_dump(output: Path | None) -> None:
        """Collect diagnostic artifacts (spans, plan, log, config) into a zip for support."""
        from ..model_dump import run_model_dump

        out = run_model_dump(output_path=output)
        runtime.console.print(f"[green]✓ Wrote dump:[/green] {out}")

    # Aliases (deprecated colon form) for the *real* commands. These stay
    # registered unconditionally so older scripts (``rai models:install``,
    # ``rai models:dump``) keep working through the deprecation window.
    real_aliases: list[tuple[click.Command, str, str]] = [
        (models_install, "models:install", "models install"),
        (models_dump, "models:dump", "models dump"),
    ]

    # Stub / "Not implemented" commands. They're behind ``RAI_CLI_ENABLE_STUBS``
    # so they don't ship in user-facing builds (``rai models --help`` showed
    # them earlier even with ``hidden=True`` because Click still listed them
    # in completion and ``rai commands --all``, and users tab-completing into
    # a "Not implemented" was a constant source of "is this broken?" bug
    # reports). Local development still gets at them via the env var.
    if stubs_enabled():
        @models_group.command(name="list", hidden=True)
        @pagination_options()
        def models_list(limit: int, offset: int) -> None:
            """List model schemas."""
            runtime.console.print("[yellow]Not implemented[/yellow]")

        @models_group.command(name="pull", hidden=True)
        def models_pull() -> None:
            """Pull remote model changes into the local shared model file."""
            runtime.console.print("[yellow]Not implemented[/yellow]")

        @models_group.command(name="branch", hidden=True)
        @click.argument("name")
        @click.option("--ref", default=None, help="Source schema to branch from (defaults to current schema).")
        @click.option("--static", is_flag=True, default=False, help="Create a static (frozen) branch instead of live.")
        def models_branch(name: str, ref: str | None, static: bool) -> None:
            """Create a new model branch (schema)."""
            runtime.console.print("[yellow]Not implemented[/yellow]")

        @models_group.command(name="switch", hidden=True)
        @click.argument("name")
        def models_switch(name: str) -> None:
            """Switch the current schema to a different model schema."""
            runtime.console.print("[yellow]Not implemented[/yellow]")

        @models_group.command(name="delete", hidden=True)
        @click.argument("name")
        @click.option("--force", is_flag=True, default=False, help="Force delete even with downstream branches.")
        def models_delete(name: str, force: bool) -> None:
            """Delete a model schema."""
            runtime.console.print("[yellow]Not implemented[/yellow]")

        real_aliases.extend(
            [
                (models_list, "models:list", "models list"),
                (models_pull, "models:pull", "models pull"),
                (models_branch, "models:branch", "models branch"),
                (models_switch, "models:switch", "models switch"),
                (models_delete, "models:delete", "models delete"),
            ]
        )

    for canonical, colon, space in real_aliases:
        add_colon_alias(root=cli, canonical=canonical, colon_name=colon, space_name=space)
