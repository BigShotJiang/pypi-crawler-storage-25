from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import sys
import time
from typing import TypeVar

from rich.text import Text

from . import runtime
from .display import format_state_with_color

T = TypeVar("T")


@dataclass(frozen=True)
class WaitStatus:
    label: str
    subject: str
    state: str
    elapsed_s: float
    detail: str | None = None


def _elapsed_text(elapsed_s: float) -> str:
    if elapsed_s < 60:
        return f"{elapsed_s:.0f}s"
    mins, secs = divmod(int(elapsed_s), 60)
    return f"{mins}m {secs:02d}s"


def _render_status_line(status: WaitStatus) -> Text:
    """Render the wait status as a single Rich line.

    Single-line status is used because Rich's multi-line transient ``Live``
    cleanup can leave a partial frame on the terminal when the user hits
    Ctrl+C mid-render. ``console.status(...)`` (a single-line spinner) cleans
    up reliably across signals.
    """
    line = Text()
    line.append(status.label, style="bold")
    line.append(" · ")
    line.append(status.subject)
    line.append(" · ")
    line.append("Status: ")
    line.append_text(Text.from_markup(format_state_with_color(status.state or "waiting")))
    line.append(" · ")
    line.append(f"Elapsed {_elapsed_text(status.elapsed_s)}")
    if status.detail:
        # Keep the detail short so it fits on one line in typical terminals.
        snippet = status.detail.splitlines()[0]
        if len(snippet) > 80:
            snippet = snippet[:77] + "..."
        line.append(" · ")
        line.append(snippet, style="dim")
    return line


def should_use_live_status() -> bool:
    """Return True when the live status indicator should be drawn.

    False under any of:
    - machine-readable output (``--json`` *or* ``--output yaml``), so
      structured output isn't polluted with spinner frames (pre-fix this
      gated on ``cli_wants_json`` only, leaking spinner ANSI into YAML
      stdout capture);
    - ``sys.stdout`` missing or not a TTY (e.g. captured under CliRunner,
      piped to ``less``, or replaced with ``None`` in some embedded
      runtimes), so we don't emit ANSI control sequences into a
      non-terminal stream.
    """
    return not runtime.cli_wants_machine_output() and runtime.stream_is_tty(sys.stdout)


def poll_until_done(
    *,
    label: str,
    subject: str,
    poll: Callable[[], T],
    state_of: Callable[[T | None], str],
    is_done: Callable[[T], bool],
    timeout_s: float,
    poll_interval_s: float,
    timeout_error: Callable[[], BaseException],
    detail: Callable[[], str | None] | None = None,
) -> T:
    """Poll an operation while rendering a compact live status line when interactive."""
    start = time.monotonic()
    deadline = start + float(timeout_s)
    last: T | None = None

    def _status() -> WaitStatus:
        return WaitStatus(
            label=label,
            subject=subject,
            state=state_of(last),
            elapsed_s=time.monotonic() - start,
            detail=detail() if detail is not None else None,
        )

    def _poll_once() -> T | None:
        nonlocal last
        current = poll()
        if current is not None:
            last = current
            if is_done(current):
                return current
        return None

    def _sleep_until_next_poll() -> None:
        now = time.monotonic()
        if now >= deadline:
            raise timeout_error()
        # ``max(0.0, ...)`` defends against the deadline elapsing between the
        # check above and the subtraction below — ``time.monotonic()`` can
        # advance under load. Without the floor we'd ask ``time.sleep`` for a
        # negative duration, which raises ``ValueError`` on CPython.
        time.sleep(min(float(poll_interval_s), max(0.0, deadline - now)))

    if not should_use_live_status():
        while True:
            done = _poll_once()
            if done is not None:
                return done
            _sleep_until_next_poll()

    with runtime.console.status(_render_status_line(_status()), spinner="dots") as status_ctx:
        while True:
            done = _poll_once()
            status_ctx.update(_render_status_line(_status()))
            if done is not None:
                return done
            _sleep_until_next_poll()
