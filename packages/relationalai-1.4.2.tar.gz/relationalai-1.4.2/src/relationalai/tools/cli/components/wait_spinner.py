from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Literal

from rich.console import Console
from rich.text import Text

from relationalai.tools.cli.cli_output_prefs import cli_requests_no_color

# Spinner doesn't appear until the wrapped work has been running this long.
# Sub-threshold calls finish silently — eliminates the "spinner flash" that
# happens on warm-cache / cached-config paths where the work returns in
# 50-100ms (visible flash → no value, looks janky). gh / cargo / flyctl
# all use a similar threshold; 250ms is the well-trodden number.
_DEFAULT_SHOW_AFTER_MS = 250


@dataclass
class WaitSpinner:
    """A minimal spinner for "waiting" CLI operations.

    This is intended for operations where we don't have meaningful incremental
    progress to report (e.g. waiting on an async backend operation to complete).

    By default the spinner is *delayed*: it only becomes visible after
    ``show_after_ms`` milliseconds of work. Operations that finish before
    the threshold print nothing — no spinner flash for fast paths.

    Usage:
        with WaitSpinner("Creating reasoner...", "Reasoner created!"):
            do_work()

        # Show immediately (e.g. for known-slow operations):
        with WaitSpinner("Connecting...", show_after_ms=0):
            connect()
    """

    message: str | Text
    success_message: str | None = None
    failed_message: str | None = None
    spinner: str = "dots"
    console: Console | None = None
    show_after_ms: int = _DEFAULT_SHOW_AFTER_MS

    def __post_init__(self) -> None:
        if self.console is None:
            self.console = Console(no_color=cli_requests_no_color())

    def _resolved_message(self) -> Text:
        assert self.console is not None
        if isinstance(self.message, Text):
            return self.message
        if self.console.no_color or cli_requests_no_color():
            return Text(str(self.message))
        return Text(str(self.message), style="green")

    def _start_status(self) -> None:
        assert self.console is not None
        # Guard against double-start: the delay timer and __exit__ both
        # race to flip this on; the lock + sentinel keep the spinner
        # idempotent.
        with self._start_lock:
            if self._started or self._cancelled:
                return
            self._started = True
            self._status = self.console.status(self._resolved_message(), spinner=self.spinner)
            self._status.__enter__()

    def __enter__(self) -> "WaitSpinner":
        self._start_lock = threading.Lock()
        self._started = False
        self._cancelled = False
        self._status = None
        self._t0 = time.monotonic()

        delay_s = max(0.0, self.show_after_ms / 1000.0)
        if delay_s <= 0:
            self._start_status()
        else:
            # Daemon timer so a stuck spinner can't keep the process alive
            # past Click's exit; the cancel path in __exit__ disarms it
            # cleanly on the happy path.
            self._timer = threading.Timer(delay_s, self._start_status)
            self._timer.daemon = True
            self._timer.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> Literal[False]:
        # Disarm the delay timer *inside* the lock together with the
        # ``_cancelled = True`` flip so the timer callback (which acquires
        # the same lock in :meth:`_start_status`) can't squeeze in between
        # the cancel and the flag write and start a spinner we've already
        # decided to tear down. ``threading.Timer.cancel`` is itself a
        # no-op if the worker is already running, so a fired-but-not-yet-
        # executed timer simply blocks on the lock here, observes
        # ``_cancelled`` on entry, and bails. Snapshot ``_status`` under
        # the same lock so a status started by a racing timer is captured
        # for the post-lock cleanup.
        timer = getattr(self, "_timer", None)
        lock = getattr(self, "_start_lock", None)
        status_cm = None
        if lock is not None:
            with lock:
                if hasattr(self, "_cancelled"):
                    self._cancelled = True
                if timer is not None:
                    timer.cancel()
                status_cm = getattr(self, "_status", None)
        else:
            # ``__enter__`` never ran (or failed before allocating the lock) —
            # still disarm any timer without touching missing attributes.
            if timer is not None:
                try:
                    timer.cancel()
                except Exception:
                    pass
            status_cm = getattr(self, "_status", None)

        if status_cm is not None:
            try:
                status_cm.__exit__(exc_type, exc, tb)
            except Exception:
                pass

        assert self.console is not None
        if exc_type is None:
            if self.success_message:
                self.console.print(self.success_message)
            return False

        # Exception path: optionally print a friendly failure line.
        if self.failed_message:
            self.console.print(self.failed_message)
        return False
