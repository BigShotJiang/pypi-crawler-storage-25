"""Connection-level validation and Snowflake error → user suggestion mapping.

Used by ``rai connect`` and the connect info panel. Kept separate from the
backend-error → CLI-diagnostic chain in ``error_handlers.py`` because the two
modules don't share helpers and have different consumers.
"""

from __future__ import annotations

import re
from typing import Any


def _use_warehouse_sql(warehouse: str) -> str:
    """Build a ``USE WAREHOUSE`` statement that is injection-safe yet preserves
    Snowflake's case-insensitive unquoted-identifier semantics.

    We use Snowflake's built-in ``IDENTIFIER('...')`` construct. ``IDENTIFIER``
    is a Snowflake meta-function whose argument is parsed as a *string literal*
    (not as SQL), and which then resolves that string using the same rules as
    a bare identifier — so ``my_warehouse``, ``MY_WAREHOUSE`` and
    ``My_Warehouse`` all still resolve to the same warehouse. Because the
    argument is a string literal, the only delimiter we need to defend against
    is the single-quote that ends the literal; doubling any embedded ``'``
    keeps the literal well-formed and prevents SQL injection by design (no
    other character can break out of the literal). See:
    https://docs.snowflake.com/en/sql-reference/identifier-literal
    """
    literal = warehouse.replace("'", "''")
    return f"USE WAREHOUSE IDENTIFIER('{literal}')"


def validate_session(session: Any, warehouse: str | None = None) -> None:
    """Validate a Snowflake/Snowpark session by running a trivial query.

    Raises a :class:`RuntimeError` if the session object doesn't expose a known
    API. Caller maps the exception into a :class:`click.ClickException` for
    user output.
    """
    use_wh = _use_warehouse_sql(warehouse) if warehouse else None
    if hasattr(session, "execute"):
        cur = session.execute("select 1")
        if hasattr(cur, "fetchall"):
            cur.fetchall()
        if use_wh:
            session.execute(use_wh)
        return
    if hasattr(session, "sql"):
        out = session.sql("select 1")
        if hasattr(out, "collect"):
            out.collect()
        elif hasattr(out, "fetchall"):
            out.fetchall()
        if use_wh:
            session.sql(use_wh).collect()
        return
    raise RuntimeError(
        f"Unsupported session type {type(session).__name__!r}; expected .execute() or .sql()."
    )


# Ordered to match the verbose whoami table. Duplicated from
# ``relationalai.agent.cortex.diagnostics`` deliberately: the CLI must
# not import that module (cold-start cost; pulls in snowpark/OTEL/crypto).
#
# :data:`IDENTITY_FIELDS` is the single source of truth — each row is
# ``(payload key, display label, CURRENT_* SQL expression)``. The
# narrower :data:`IDENTITY_SQL_EXPRESSIONS` (just key + SQL) is derived
# from it for the ``fetch_session_identity`` SQL probe; the verbose
# whoami table derives its label list from the same source via
# :func:`identity_label_pairs`. This keeps ``rai whoami``'s renderer
# and the SQL probe on one definition so adding a new ``CURRENT_*``
# scalar (or renaming a label) is a single-line edit here.
IDENTITY_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("user", "User", "CURRENT_USER()"),
    ("account", "Account", "CURRENT_ACCOUNT()"),
    ("role", "Role", "CURRENT_ROLE()"),
    ("warehouse", "Warehouse", "CURRENT_WAREHOUSE()"),
    ("database", "Database", "CURRENT_DATABASE()"),
    ("schema", "Schema", "CURRENT_SCHEMA()"),
    ("region", "Region", "CURRENT_REGION()"),
    ("version", "Version", "CURRENT_VERSION()"),
)

IDENTITY_SQL_EXPRESSIONS: tuple[tuple[str, str], ...] = tuple(
    (key, sql) for key, _label, sql in IDENTITY_FIELDS
)


def identity_label_pairs() -> tuple[tuple[str, str], ...]:
    """``(payload key, display label)`` for the verbose whoami table.

    Derived from :data:`IDENTITY_FIELDS` so ``rai whoami`` and the SQL
    probe share one definition (previously the labels lived in a
    parallel ``_IDENTITY_LABELS`` tuple in ``commands/whoami.py`` that
    had to be kept in sync by hand).
    """
    return tuple((key, label) for key, label, _sql in IDENTITY_FIELDS)


def _first_scalar(row: Any) -> Any:
    """First cell of a row whose shape we don't know.

    ``.as_dict()`` MUST be tried first: snowpark ``Row`` is iterable
    but iteration yields field *names*, not values, so a tuple-style
    extraction would silently return the column name.
    """
    as_dict = getattr(row, "as_dict", None)
    if callable(as_dict):
        # Deliberately broad: a malformed Row-like (mock, custom shim,
        # or row class with a non-standard ``as_dict`` raising e.g.
        # ``NotImplementedError``) should fall through to the tuple /
        # dict branches rather than aborting the per-scalar fetch.
        try:
            mapping = as_dict()
        except Exception:
            mapping = None
        if isinstance(mapping, dict) and mapping:
            return next(iter(mapping.values()))
    if isinstance(row, (list, tuple)) and row:
        return row[0]
    if isinstance(row, dict) and row:
        return next(iter(row.values()))
    return None


def _scalar(rows: Any) -> str | None:
    """First cell of the first row as ``str | None``; ``None`` for
    empty result sets.
    """
    if not rows:
        return None
    value = _first_scalar(rows[0])
    return None if value is None else str(value)


def _scalar_from_execute(session: Any, expression: str) -> str | None:
    """Run ``SELECT <expression>`` via the connector API and return the scalar."""
    cur = session.execute(f"SELECT {expression}")
    if not hasattr(cur, "fetchall"):
        return None
    return _scalar(cur.fetchall())


def _scalar_from_sql(session: Any, expression: str) -> str | None:
    """Run ``SELECT <expression>`` via the Snowpark API and return the scalar."""
    out = session.sql(f"SELECT {expression}")
    if hasattr(out, "collect"):
        return _scalar(out.collect())
    if hasattr(out, "fetchall"):
        return _scalar(out.fetchall())
    return None


def fetch_session_identity(session: Any) -> dict[str, str | None]:
    """``CURRENT_*`` scalars resolved by the backend, keyed by
    :data:`IDENTITY_SQL_EXPRESSIONS`. Per-scalar isolation: a failing
    query yields ``None`` for that key without aborting the rest.
    Raises :class:`RuntimeError` only when ``session`` exposes neither
    ``.execute()`` nor ``.sql()``.
    """
    if hasattr(session, "execute"):
        fetch = _scalar_from_execute
    elif hasattr(session, "sql"):
        fetch = _scalar_from_sql
    else:
        raise RuntimeError(
            f"Unsupported session type {type(session).__name__!r}; "
            "expected .execute() or .sql()."
        )

    out: dict[str, str | None] = {}
    for key, expression in IDENTITY_SQL_EXPRESSIONS:
        try:
            out[key] = fetch(session, expression)
        except Exception:
            # Per-scalar isolation: a missing privilege on one CURRENT_* fn
            # (e.g. CURRENT_REGION restricted in some deployments) must not
            # blank out the rest of the identity payload.
            out[key] = None
    return out


# Error codes sourced from Snowflake docs and snowflake-connector-python.
_SNOWFLAKE_ERROR_SUGGESTIONS: list[tuple[str, str]] = [
    (
        r"390100|Incorrect username or password",
        "Wrong username or password (error 390100). Check 'user' and 'password' in your raiconfig.yaml.",
    ),
    (
        r"390144|JWT token is invalid",
        "JWT authentication failed (error 390144). Common causes:\n"
        "  • Wrong 'account' identifier — must match the 'iss' claim in your JWT\n"
        "  • Public key fingerprint mismatch — re-register your public key in Snowflake\n"
        "  • Clock skew > 60s — check your system clock is synced (NTP)\n"
        "  Check 'private_key_path' and 'private_key_passphrase' in raiconfig.yaml.",
    ),
    (
        r"390114|Authentication token has expired",
        "Authentication token has expired (error 390114). Refresh your token and "
        "update 'token' or 'token_file_path' in raiconfig.yaml.",
    ),
    (
        r"MFA authentication is required",
        "Your Snowflake account requires MFA but the current authenticator doesn't support it.\n"
        "Switch authenticator in raiconfig.yaml:\n"
        "  connections:\n"
        "    snowflake:\n"
        "      authenticator: programmatic_access_token\n"
        "      token: <your token>\n"
        "  or\n"
        "      authenticator: externalbrowser",
    ),
    (
        r"250001|Failed to connect to DB|Could not connect to Snowflake backend",
        "Could not reach Snowflake (error 250001). Check:\n"
        "  • 'account' identifier in raiconfig.yaml (e.g. myorg-myaccount)\n"
        "  • Network connectivity and firewall rules\n"
        "  • VPN if required by your organization",
    ),
    (
        r"002043|Object does not exist, or operation cannot be performed",
        "Warehouse not found or not accessible. Check the 'warehouse' value in raiconfig.yaml — "
        "it must exist and your role must have USAGE privilege on it.",
    ),
    (
        r"CERTIFICATE_VERIFY_FAILED|SSL|bad handshake",
        "SSL/TLS error. Your network proxy or firewall may be intercepting Snowflake traffic. "
        "Check your SSL certificates and proxy settings.",
    ),
]


def get_connection_suggestion(error_msg: str) -> str | None:
    """Return an actionable suggestion for known Snowflake error patterns."""
    for pattern, suggestion in _SNOWFLAKE_ERROR_SUGGESTIONS:
        if re.search(pattern, error_msg, re.IGNORECASE):
            return suggestion
    return None


# Single source of truth for the Snowflake connection rows surfaced by
# ``rai connect`` and ``rai diagnose``. Each entry is ``(display label,
# attribute name on the resolved connection instance)``; tuple order is
# the rendering order. ``schema_`` is the attribute name (alias
# ``schema`` on input) — see ``SnowflakeConnectionBase``.
CONNECTION_INFO_FIELDS: tuple[tuple[str, str], ...] = (
    ("Type", "type"),
    ("Authenticator", "authenticator"),
    ("Account", "account"),
    ("User", "user"),
    ("Warehouse", "warehouse"),
    ("Database", "database"),
    ("Schema", "schema_"),
    ("Role", "role"),
)


def format_connection_info(connection: Any) -> list[tuple[str, str]]:
    """Extract key connection fields for display (preserves display order).

    Iterates :data:`CONNECTION_INFO_FIELDS` so ``rai connect`` and the
    human renderer in ``rai diagnose`` can't drift on which fields show
    or in what order. Snowflake-shaped — DuckDB / Local fields don't apply.
    """
    rows: list[tuple[str, str]] = []
    for label, attr in CONNECTION_INFO_FIELDS:
        value = getattr(connection, attr, None)
        if value:
            rows.append((label, str(value)))
    return rows
