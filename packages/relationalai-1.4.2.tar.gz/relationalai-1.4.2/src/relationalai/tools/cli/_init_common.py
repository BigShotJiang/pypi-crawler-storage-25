"""Helpers shared between :mod:`init_wizard` and :mod:`install_init_wizard`.

Kept minimal — anything specific to one entry path stays in its own module.

The "wizard chrome" helpers below render multi-step output in the
``create-next-app`` / ``clack`` style:

* ``◆`` (green, filled) — opening header (``wizard_open``).
* ``│`` (dim) — vertical connector between sections (``wizard_pipe``).
* ``◆`` / ``◇`` — step markers. Filled (``◆``) for a step whose work is
  *complete*; hollow (``◇``) for a step that still requires user action
  (``pending=True`` on ``wizard_step`` / ``wizard_close``). Colour
  carries the secondary cue (cyan = neutral done, yellow = caution,
  red = error, green = wizard done / final next-steps).

Both wizards use this chrome — the older horizontal-divider banner has
been retired.
"""

from __future__ import annotations

import sys
from pathlib import Path

import click
import rich

# Re-export from the Rich-free :mod:`_paths` module so callers can keep
# importing these names from ``_init_common`` (where they originally
# lived) while ``_diagnose_helpers`` and other Rich-free modules import
# from ``_paths`` directly without dragging Rich into their import tree.
from ._paths import (  # noqa: F401  (re-exported for back-compat)
    RAICONFIG_YAML,
    RAICONFIG_YML,
    find_existing_yaml,
)

# Substrings that mark the canonical raiconfig template as still-unfilled.
TEMPLATE_PLACEHOLDERS: frozenset[str] = frozenset(
    {"myorg-myaccount", "you@example.com", "your_password"}
)


# ── Wizard chrome ────────────────────────────────────────────────────────────
#
# Glyphs chosen for cross-platform terminal coverage. They're common Unicode
# (also used by ``clack`` and ``create-next-app``) and degrade gracefully on
# legacy terminals. The pipe is rendered dim so it recedes; step glyphs carry
# the colour cue (green=open, cyan=step, yellow=caution, red=error, green=done).

# Filled diamond (◆) marks a step that has *completed* its work; hollow
# diamond (◇) marks a step that's *pending* (action the user still needs
# to take). Both are valid as step markers and as the final/closing step —
# pick by truth-of-the-state, not by position in the wizard.
_STEP_GLYPH = "◆"
_STEP_PENDING_GLYPH = "◇"
_PIPE_GLYPH = "│"
# Whitespace between the pipe column and the first character of body
# text. Four spaces puts body text two columns past the step's own text
# (since step headers are ``◆ + 2 spaces + label``), giving body lines
# the visible "nested under the step" look. ``wizard_close_body`` uses
# the same constant with a leading space in place of the pipe so its
# text column stays aligned with ``wizard_body``.
_BODY_INDENT = "    "


def wizard_open(title: str, subtitle: str | None = None) -> None:
    """Print the wizard header ``◆  title  · subtitle`` followed by a pipe."""
    tail = f"  [dim]· {subtitle}[/dim]" if subtitle else ""
    rich.print(f"\n[green]{_STEP_GLYPH}[/green]  [bold]{title}[/bold]{tail}")
    wizard_pipe()


def wizard_pipe() -> None:
    """Print the dim vertical connector line ``│`` (one row)."""
    rich.print(f"[dim]{_PIPE_GLYPH}[/dim]")


def wizard_step(label: str, *, style: str = "cyan", pending: bool = False) -> None:
    """Print a step header: ``◆  label`` (filled) or ``◇  label`` (hollow).

    ``style`` controls the glyph colour (cyan = neutral done, yellow =
    caution, red = error, green = success/done). ``pending=True`` swaps
    the filled diamond for the hollow one to signal "user action still
    required". The header is the same shape whether the step is
    intermediate or the final one in the flow — :func:`wizard_close` is
    just this with ``style="green"`` as the default.
    """
    glyph = _STEP_PENDING_GLYPH if pending else _STEP_GLYPH
    rich.print(f"[{style}]{glyph}[/{style}]  {label}")


def wizard_close(label: str, *, style: str = "green", pending: bool = False) -> None:
    """Final step of the wizard — :func:`wizard_step` with green default."""
    wizard_step(label, style=style, pending=pending)


def wizard_body(text: str) -> None:
    """Print ``│    text`` — body content indented under the pipe."""
    rich.print(f"[dim]{_PIPE_GLYPH}[/dim]{_BODY_INDENT}{text}")


def wizard_close_body(text: str) -> None:
    """Print ``     text`` — body after the close step (no pipe).

    A leading space takes the pipe column, then :data:`_BODY_INDENT`, so
    the text column lands at column 5 — same as :func:`wizard_body`.
    """
    rich.print(f" {_BODY_INDENT}{text}")


def _should_emit_ansi() -> bool:
    """``True`` when the wizard should emit raw ANSI escapes — a real TTY
    *and* no ``NO_COLOR`` override (the ``no-color.org`` convention, also
    honoured by Rich and click).

    Both halves are delegated: the TTY probe goes through
    :func:`runtime.stream_is_tty` (defensive against ``None``, missing
    ``isatty``, and closed/detached streams), and the ``NO_COLOR`` env
    contract goes through :func:`runtime.resolve_no_color` so the same
    ``no-color.org`` rule that gates Rich consoles also gates the raw
    ANSI we hand-roll for the wizard prompt.
    """
    from . import runtime

    if runtime.resolve_no_color(flag=False):
        return False
    return runtime.stream_is_tty(sys.stdout)


def wizard_prompt(label: str, *, default: str) -> str:
    """Render ``│  label [default]:`` as a click prompt, then echo the
    resolved value in green.

    Two visual problems with vanilla ``click.prompt``:
      1. When the user just hits Enter, click silently accepts the default
         but doesn't echo it — the line shows ``label [default]:`` with no
         visible answer, which is jarring inside the wizard chrome.
      2. Typed values render in the terminal's default colour, breaking
         the green/cyan emphasis used elsewhere.

    Fix: after click returns, rewrite the prompt line in place so it always
    reads ``│  label [default]: <value>`` with ``<value>`` in green,
    regardless of whether the user typed it or accepted the default. The
    rewrite is gated on :func:`_should_emit_ansi` (real TTY + no
    ``NO_COLOR``) so piped / captured / embedded / ``NO_COLOR=1`` runs
    stay clean.

    Implementation detail: the rewrite is written directly to
    ``sys.stdout`` rather than through ``rich.print``. Rich treats raw ESC
    bytes in its input as control characters to escape (the cursor-up
    sequence ``\\x1b[1A`` would render as the literal text ``[1A``),
    defeating the point. Hand-rolled SGR codes (``\\x1b[2m`` dim,
    ``\\x1b[32m`` green, ``\\x1b[0m`` reset) keep the chrome consistent
    with what Rich emits for ``[dim]`` / ``[green]`` markup.
    """
    value = click.prompt(f"{_PIPE_GLYPH}  {label}", default=default)
    if _should_emit_ansi():
        DIM, GREEN, RESET = "\x1b[2m", "\x1b[32m", "\x1b[0m"
        # \x1b[1A = cursor up 1 line; \r = column 0; \x1b[2K = erase line.
        sys.stdout.write(
            f"\x1b[1A\r\x1b[2K"
            f"{DIM}{_PIPE_GLYPH}{RESET}  {label} "
            f"{DIM}[{default}]{RESET}: {GREEN}{value}{RESET}\n"
        )
        sys.stdout.flush()
    return value


# ── Config-file discovery ────────────────────────────────────────────────────
#
# ``find_existing_yaml`` lives in :mod:`_paths` (Rich-free) and is
# re-exported above so existing callers (and tests that monkeypatch
# ``_init_common.find_existing_yaml``) keep working unchanged.


def has_template_values(yaml_path: Path) -> bool:
    """Return ``True`` if the file still contains any known template placeholder.

    This is a deliberately cheap substring check (no YAML parse). It's used
    solely to print a friendly nudge ("you still have template values") at the
    end of ``rai init`` — it never gates real behavior. Because the placeholder
    strings (``myorg-myaccount``, ``you@example.com``, ``your_password``) are
    distinctive and only appear in the canonical template, the false-positive
    rate is acceptably low; in the worst case the user just sees the nudge a
    bit longer than they should. If we ever start using more generic
    placeholders, switch to a YAML parse and field-level check.
    """
    content = yaml_path.read_text(encoding="utf-8")
    return any(placeholder in content for placeholder in TEMPLATE_PLACEHOLDERS)


def explain_existing_yaml(yaml_path: Path, *, rerun_hint: str) -> None:
    """Validate an existing ``raiconfig.yaml`` and print a status block.

    ``rerun_hint`` should describe how the user reruns the wizard (e.g.
    ``"rai init"`` or ``"rai init --install-mode"``). The wizard header
    is expected to already have been printed by the caller; this function
    prints the ``config.explain()`` output (free-form, outside the
    chrome) and then closes with a chrome-style status step.
    """
    try:
        from relationalai.config import create_config

        from .init_wizard import run_explain

        run_explain(create_config())
        wizard_pipe()
        if has_template_values(yaml_path):
            wizard_close(
                "[yellow]Your config still contains template placeholder values.[/yellow]",
                style="yellow",
                pending=True,
            )
            wizard_close_body(
                f"[dim]Edit [bold]{yaml_path}[/bold] and replace the example values "
                f"with your own, then run [bold]{rerun_hint}[/bold] again.[/dim]"
            )
        else:
            wizard_close("[green]You're all set![/green] Your config is valid and ready to use.")
        rich.print()
    except Exception as e:
        wizard_pipe()
        wizard_close(
            f"[yellow]Config has issues:[/yellow] {e}",
            style="yellow",
            pending=True,
        )
        wizard_close_body("[dim]Edit your raiconfig.yaml to fix the issues above.[/dim]")
        rich.print()
