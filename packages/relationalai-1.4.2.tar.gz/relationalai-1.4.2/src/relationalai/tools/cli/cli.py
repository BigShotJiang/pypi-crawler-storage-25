"""
RelationalAI CLI — tools for working with semantic models.

For full documentation visit https://docs.relational.ai.

Structure
---------

This module is intentionally small. It wires together:

- the :class:`~relationalai.tools.cli._group.RaiGroup` (help formatting)
- the two global flags ``--no-color`` and ``--json``
- every command group under :mod:`~relationalai.tools.cli.commands` via
  :func:`~relationalai.tools.cli.commands.register_all`.

Everything else (runtime context, config loading, client connection, JSON
serialization, rendering, error handling) lives in focused modules.
"""

from __future__ import annotations


import click

from . import runtime, update_check
from ._group import RaiGroup
from .commands import register_all
from .commands.version import collect_version_info, maybe_render_upgrade_panel_sync, render_version
from .runtime import flush_diagnostics_on_close


def _version_callback(ctx: click.Context, _param: click.Parameter, value: bool) -> None:
    """Eager handler for ``--version`` / ``-v``; delegates to :func:`render_version`.

    Eager callbacks fire before :func:`cli` runs. :meth:`RaiGroup.parse_args`
    primes ``rt.no_color`` / ``rt.output_format`` from raw args first, but the
    Rich console rebuild lives in ``cli()`` — so do it here too, otherwise
    ``runtime.console`` keeps its auto-detect default and ``--no-color`` is
    silently ignored on the eager path.

    Short alias rationale (``-v``): every short-form-version CLI users reach
    for first uses ``-v`` (``node -v``, ``npm -v``, ``ruby -v``, ``jq -V``).
    We mirror that. Click scopes short options per-group, so the global
    ``-v`` here does **not** collide with subcommand-level ``-v`` /
    ``--verbose`` flags (e.g. ``rai version -v``, ``rai init explain -v``):
    Click only consumes ``-v`` as the global eager version flag when it
    appears *before* a subcommand. ``rai version -v`` parses ``-v`` inside
    the subcommand context where it means ``--verbose``.

    The eager flag always renders the terse one-liner (``rai <version>``);
    use ``rai version --verbose`` (or ``rai version -v``) for the full
    diagnostics block. Adding ``--verbose`` directly to the eager flag
    would require either a global ``--verbose`` option (pollutes every
    subcommand) or rewriting ``RaiGroup.parse_args`` to strip the unknown
    token before parsing — both cures worse than the disease for a flag
    whose verbose form is one extra keystroke away via the subcommand.

    Because this callback calls :meth:`ctx.exit` before :func:`cli`'s body
    runs, the standard ``ctx.call_on_close(maybe_print_notice)`` hook never
    gets registered on the eager path. We therefore render the upgrade panel
    inline here via :func:`maybe_render_upgrade_panel_sync`. The ``version``
    *subcommand* path runs through :func:`cli`'s body and gets the panel
    from the on-close hook instead — so :func:`render_version` itself does
    not render the panel (otherwise the subcommand path would print it
    twice: once inline, once on close).
    """
    if not value or ctx.resilient_parsing:
        return

    rt = runtime.get_runtime(ctx)
    runtime.configure_console(no_color=rt.no_color)
    render_version()
    maybe_render_upgrade_panel_sync(str(collect_version_info()["version"]))
    ctx.exit()


@click.group(
    invoke_without_command=True,
    cls=RaiGroup,
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.option(
    "--version",
    "-v",
    is_flag=True,
    is_eager=True,
    expose_value=False,
    callback=_version_callback,
    help="Show the version and exit. Use `rai version --verbose` for the full diagnostics block.",
)
@click.option(
    "--no-color",
    is_flag=True,
    default=False,
    help="Disable colored terminal output. A non-empty NO_COLOR environment variable does the same.",
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Shortcut for `--output json`.",
)
@click.option(
    "--yaml",
    "--yml",
    "yaml_output",
    is_flag=True,
    help="Shortcut for `--output yaml` (also accepts `--yml`).",
)
@click.option(
    "--output",
    "output_format",
    type=click.Choice(["table", "json", "yaml", "yml"], case_sensitive=False),
    default="table",
    show_default=True,
    help="Output format for supported commands. ``yml`` is accepted as an alias for ``yaml``.",
)
@click.option(
    "--profile",
    "profile",
    envvar="RAI_PROFILE",
    default=None,
    metavar="NAME",
    help="Use a named config profile for this invocation. Can also be set with RAI_PROFILE.",
)
@click.pass_context
def cli(
    ctx: click.Context,
    no_color: bool,
    json_output: bool,
    yaml_output: bool,
    output_format: str,
    profile: str | None,
) -> None:
    """RelationalAI CLI - Tools for working with semantic models.

    For more documentation on these commands, visit: https://docs.relational.ai
    """
    rt = runtime.get_runtime(ctx)
    rt.output_format = runtime.resolve_output_format(
        json_output=json_output,
        yaml_output=yaml_output,
        output_format=output_format,
    )
    rt.json_output = rt.output_format == "json"
    rt.profile = profile.strip() if isinstance(profile, str) and profile.strip() else None

    no_color = runtime.resolve_no_color(flag=no_color)
    rt.no_color = no_color
    if no_color:
        ctx.color = False
    runtime.configure_console(no_color=no_color)

    flush_diagnostics_on_close(ctx)

    update_check.maybe_start_check()
    ctx.call_on_close(update_check.maybe_print_notice)

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


register_all(cli)


if __name__ == "__main__":
    cli()
