"""Single source of truth for environment variables the CLI reads.

Why a registry. Env vars were scattered across the codebase — each module
did its own ``os.environ.get(...)`` with its own default and its own
truthy-string interpretation, and the user had no single place to look up
"what does the CLI read from the environment?". The :func:`rai config env`
subcommand consumes this registry to print one canonical table.

How to add a new env var. Append to :data:`KNOWN_ENV_VARS` with a short
description, ``kind``, and the ``surfaces`` it shows up on (any subset of
``("rai config env", "rai diagnose", "rai config use")``). The bool
reader (:func:`read_bool`) is the canonical place to consult a boolean
gate; callers should go through it so the truthy-string convention
stays identical to ``update_check``'s historical behavior.

The registry intentionally only covers env vars **the CLI itself reads**.
Connection-string env vars consumed by config sources (e.g.
``SNOWFLAKE_USER``) live elsewhere and aren't enumerated here.
"""

from __future__ import annotations

import os
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Literal

from ...config.constants import RAI_CONFIG_FILE_PATH_ENV_VAR

EnvKind = Literal["bool", "string", "path", "list"]
EnvSurface = Literal["rai config env", "rai diagnose", "rai config use"]

# Surface tags. Use these constants so a typo in a registry entry trips
# pyright instead of silently dropping the var off a surface.
SURFACE_ENV: EnvSurface = "rai config env"
SURFACE_DIAGNOSE: EnvSurface = "rai diagnose"
SURFACE_CONFIG_USE: EnvSurface = "rai config use"

# Default surface set: every var lands on ``rai config env`` unless
# explicitly overridden, and the active-profile vars also feed ``rai
# config use``'s "would shadow at runtime" warning + ``rai diagnose``'s
# env block.


@dataclass(frozen=True)
class KnownEnvVar:
    """One environment variable the CLI honors at runtime.

    ``name`` is the literal variable. ``kind`` drives display in
    ``rai config env`` and (for ``bool``) hints at the expected
    truthy/falsy convention. ``description`` is what users see in the
    help table — keep it short, one line. ``surfaces`` declares which
    CLI commands consume it; consumers iterate via
    :func:`iter_for_surface`.
    """

    name: str
    description: str
    kind: EnvKind = "string"
    default: str | None = None
    surfaces: tuple[EnvSurface, ...] = field(default_factory=lambda: (SURFACE_ENV,))


# Order is the order ``rai config env`` will print. Group logically
# (output preferences first, then runtime gates, then storage paths).
KNOWN_ENV_VARS: tuple[KnownEnvVar, ...] = (
    # ── Output preferences ───────────────────────────────────────────────
    KnownEnvVar(
        name="NO_COLOR",
        description="Disable ANSI color (any non-empty value). See https://no-color.org/.",
        kind="bool",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE),
    ),
    KnownEnvVar(
        name="RAI_PROFILE",
        description="Default config profile (overridden by --profile).",
        kind="string",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE, SURFACE_CONFIG_USE),
    ),
    # Aliases honoured by ``BaseConfig.active_profile`` (mirrored from
    # ``AliasChoices`` in ``src/relationalai/config/config.py``). Surfaced
    # on ``rai config use`` so the "this env var would shadow your YAML"
    # warning sees the same set of names the runtime resolves.
    KnownEnvVar(
        name="RAI_ACTIVE_PROFILE",
        description="Alias for RAI_PROFILE, recognized by config.active_profile.",
        kind="string",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE, SURFACE_CONFIG_USE),
    ),
    KnownEnvVar(
        name="ACTIVE_PROFILE",
        description="Alias for RAI_PROFILE, recognized by config.active_profile.",
        kind="string",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE, SURFACE_CONFIG_USE),
    ),
    KnownEnvVar(
        name=RAI_CONFIG_FILE_PATH_ENV_VAR,
        description="Explicit path to the raiconfig file (overrides upward discovery).",
        kind="path",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE),
    ),
    # ── Runtime gates ────────────────────────────────────────────────────
    KnownEnvVar(
        name="RAI_NO_UPDATE_CHECK",
        description="Skip the background PyPI update check + 'Update available' panel.",
        kind="bool",
        surfaces=(SURFACE_ENV, SURFACE_DIAGNOSE),
    ),
    KnownEnvVar(
        name="RAI_NO_DEPRECATION_NOTICE",
        description="Skip the deprecation panel printed for colon-form aliases.",
        kind="bool",
    ),
    KnownEnvVar(
        name="RAI_CLI_ENABLE_STUBS",
        description="Expose hidden placeholder commands (analyze/build/...) for development.",
        kind="bool",
    ),
    KnownEnvVar(
        name="CI",
        description="Standard CI indicator; suppresses interactive prompts + update notices.",
        kind="bool",
    ),
    # ── Storage paths ────────────────────────────────────────────────────
    KnownEnvVar(
        name="XDG_CACHE_HOME",
        description="Base directory for the PyPI-version cache (default: ~/.cache).",
        kind="path",
    ),
    KnownEnvVar(
        name="RAI_DEBUG_LOG",
        description="Path to write debug log captured by ``rai models dump``.",
        kind="path",
        default="debug.jsonl",
    ),
)


# CI / build-system env vars that suppress the PyPI update check, the
# colon-alias deprecation panel, and any other "noisy in pipelines"
# advisory. Single source of truth here so the suppression surfaces in
# :mod:`update_check` and :mod:`commands._common` stay in lockstep
# (a previous version of the codebase duplicated this list and the two
# drifted apart). Not a registry entry because these are detection
# probes — none of them are configurable knobs the user would set just
# for ``rai`` — but they live here next to ``KNOWN_ENV_VARS`` so the
# whole CLI's env-var surface is in one file.
CI_ENV_VARS: tuple[str, ...] = (
    "CI",
    "CONTINUOUS_INTEGRATION",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "BUILDKITE",
    "CIRCLECI",
    "JENKINS_URL",
    "TF_BUILD",  # Azure Pipelines
)


_FALSY_LITERALS: frozenset[str] = frozenset({"", "0", "false", "no", "off"})


def read_bool(name: str) -> bool:
    """Truthy when set to anything other than ``""``, ``0``, ``false``, ``no``, ``off``.

    Mirrors :func:`update_check._read_truthy_env`'s historical contract so
    behavior stays identical when callers migrate to this helper.
    """
    val = (os.environ.get(name, "") or "").strip().lower()
    return val not in _FALSY_LITERALS


def iter_for_surface(surface: EnvSurface) -> Iterable[KnownEnvVar]:
    """Iterate the registry entries tagged for ``surface`` (declaration order).

    Lets each consumer (``rai config env``, ``rai diagnose``,
    ``rai config use``) derive its env list from the registry rather
    than hard-coding a parallel tuple. Adding a new var on a surface is
    then a single line in this module instead of N coordinated edits.
    """
    return (var for var in KNOWN_ENV_VARS if surface in var.surfaces)


def current_values() -> list[tuple[KnownEnvVar, str | None, bool]]:
    """Return ``(var, raw_value_or_None, set_in_env)`` per known env var.

    ``set_in_env`` distinguishes "set to empty string" (still considered
    "set") from "unset" — different semantics for the no_color contract
    and useful in the ``rai config env`` table.
    """
    out: list[tuple[KnownEnvVar, str | None, bool]] = []
    for var in KNOWN_ENV_VARS:
        raw = os.environ.get(var.name)
        out.append((var, raw, var.name in os.environ))
    return out
