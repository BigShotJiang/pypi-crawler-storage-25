"""Interactive wizard for the `rai init` command.

Three entry paths:
  1. Existing raiconfig.yaml / raiconfig.yml  → validate and confirm all is good
  2. raiconfig.toml found                      → offer migration or create template
  3. No config found                           → create raiconfig.yaml from template

Output style is the "wizard chrome" defined in :mod:`._init_common`: a
``◆`` header followed by dim ``│`` connectors and per-step diamond
markers — filled ``◆`` for completed steps, hollow ``◇`` for steps that
still require user action.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

import click
import rich

from ._init_common import (
    RAICONFIG_YAML,
    explain_existing_yaml as _existing_yaml_path,
    find_existing_yaml as _find_existing_yaml,
    wizard_body,
    wizard_close,
    wizard_close_body,
    wizard_open,
    wizard_pipe,
    wizard_step,
)

if TYPE_CHECKING:
    from relationalai.config.config import Config


# ── Public entry point ───────────────────────────────────────────────────────

def run_init_wizard(*, migrate: bool = False) -> None:
    """Entry point called from cli.py init command."""
    from relationalai.config.external.utils import find_raiconfig_toml_file

    wizard_open("Welcome to RelationalAI", "raiconfig setup")

    if migrate:
        toml_path = find_raiconfig_toml_file()
        if toml_path is not None:
            _migration_path(Path(toml_path))
        else:
            wizard_close(
                "[yellow]No raiconfig.toml found.[/yellow]",
                style="yellow",
                pending=True,
            )
            wizard_close_body(
                "[dim]Run [bold]rai init[/bold] to create a raiconfig.yaml from template "
                "or validate your existing config.[/dim]"
            )
            rich.print()
        return

    yaml_path = _find_existing_yaml()
    if yaml_path is not None:
        _existing_yaml_path(yaml_path, rerun_hint="rai init")
        return

    toml_path = find_raiconfig_toml_file()
    if toml_path is not None:
        wizard_step(
            f"Found existing config: [cyan]{toml_path}[/cyan]"
        )
        wizard_body("[bold]1.[/bold] Migrate your raiconfig.toml to raiconfig.yaml")
        wizard_body("[bold]2.[/bold] Create a fresh raiconfig.yaml from template")
        wizard_pipe()
        # Plain bar in click prompt (click can't render Rich markup); it still
        # visually aligns with the dim bars rendered above/below.
        idx = click.prompt("│  Choice", type=click.IntRange(1, 2), default=1)
        if idx == 1:
            _migration_path(Path(toml_path))
        else:
            _create_template()
    else:
        _create_template()


# ── Path 1: Existing YAML ────────────────────────────────────────────────────


def run_explain(config: Config, verbose: bool = False) -> None:
    """Print config explanation — file path is shown by ``config.explain()`` itself."""
    config.explain(verbose=verbose)


# ── Path 2: Migration from raiconfig.toml ───────────────────────────────────

def _load_toml(toml_path: Path) -> dict[str, Any] | None:
    """Read and parse a TOML file. Prints a chrome error and returns ``None``
    if the parser is unavailable on the running Python — caller should
    surface that as an exit signal."""
    if sys.version_info >= (3, 11):
        import tomllib  # Python 3.11+
    else:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            wizard_pipe()
            wizard_close(
                "[red]TOML parser not available.[/red] "
                "Requires Python 3.11+ or the 'tomli' package.",
                style="red",
                pending=True,
            )
            rich.print()
            return None
    with open(toml_path, "rb") as f:
        return tomllib.load(f)


def _dropped_field_hints(source: dict[str, Any], reasoner_name: str | None) -> list[str]:
    """Return ``rai reasoners …`` hint strings for any CLI-managed fields
    present in *source*. Empty list if nothing relevant is set."""
    name_part = f" --name {reasoner_name}" if reasoner_name else ""
    hints: list[str] = []
    if (mins := source.get("auto_suspend_mins")) is not None:
        hints.append(
            f"rai reasoners alter --type logic{name_part} --auto-suspend-mins {mins}"
        )
    if (vacuum := source.get("await_storage_vacuum")) is not None:
        flag = "--await-storage-vacuum" if vacuum else "--no-await-storage-vacuum"
        hints.append(
            f"rai reasoners create --type logic{name_part} {flag}"
            f"  [dim](--await-storage-vacuum = true, --no-await-storage-vacuum = false)[/dim]"
        )
    return hints


def _warn_dropped_fields(toml_data: dict[str, Any], profiles_to_migrate: list[str]) -> None:
    """Print actionable warnings for TOML fields dropped during migration (CLI-managed only)."""
    hints = _dropped_field_hints(toml_data, toml_data.get("engine"))
    for profile_name in profiles_to_migrate:
        profile_raw = toml_data.get("profile", {}).get(profile_name, {})
        hints.extend(_dropped_field_hints(profile_raw, profile_raw.get("engine")))

    if not hints:
        return
    wizard_pipe()
    wizard_step(
        "[yellow]Some fields were dropped during migration — manage them via the CLI:[/yellow]",
        style="yellow",
        pending=True,
    )
    for hint in hints:
        wizard_body(hint)


def _convert_profile(
    profile_raw: dict[str, Any],
    config_field_keys: set[str],
) -> tuple[dict[str, Any] | None, str | None]:
    """Convert one raw TOML profile dict into a YAML profile block.

    Pure: no IO, no logging. Returns ``(block, None)`` on success or
    ``(None, error_message)`` so the caller can render the failure.
    """
    from relationalai.config.external.raiconfig_converter import map_fields_to_nested_structure
    from relationalai.config.external.raiconfig_models import RAIConfigLocalProfile, RAIConfigSnowflakeProfile

    # Legacy raiconfig.toml profiles often omit ``platform`` and rely on
    # snowflake-as-default. Resolve here and inject back into the dict
    # so the Pydantic model — where ``platform`` is required — receives
    # the same value the branch picks below.
    platform = profile_raw.get("platform", "snowflake")
    if platform not in ("snowflake", "local"):
        return None, f"platform '{platform}' is not supported in raiconfig.yaml"
    profile_data = {**profile_raw, "platform": platform}

    try:
        model_cls = RAIConfigLocalProfile if platform == "local" else RAIConfigSnowflakeProfile
        connection = model_cls(**profile_data).convert()
    except Exception as e:
        return None, str(e)

    conn_name = platform  # "snowflake" or "local"
    block: dict[str, Any] = {
        "default_connection": conn_name,
        "connections": {conn_name: connection},
    }
    overrides = {k: v for k, v in profile_raw.items() if k in config_field_keys}
    if overrides:
        block.update(map_fields_to_nested_structure(overrides))
    return block, None


def _migration_path(toml_path: Path) -> None:
    """Convert raiconfig.toml → raiconfig.yaml preserving top-level vs profile structure."""
    toml_data = _load_toml(toml_path)
    if toml_data is None:
        sys.exit(1)

    from relationalai.config.external.raiconfig_converter import CONNECTION_FIELDS, FIELD_MAPPINGS, map_fields_to_nested_structure
    from relationalai.config.external.raiconfig_models import RAIConfigFile

    config_file = RAIConfigFile(**toml_data)
    profiles = config_file.profile
    profiles_to_migrate: list[str] = list(profiles.keys())

    wizard_pipe()
    if profiles_to_migrate:
        wizard_step(
            f"Migrating {len(profiles_to_migrate)} profile(s): "
            f"[bold]{', '.join(profiles_to_migrate)}[/bold]"
        )
    else:
        wizard_step("Migrating raiconfig.toml")

    active_profile = toml_data.get("active_profile") or (profiles_to_migrate[0] if profiles_to_migrate else "dev")

    # Top-level TOML fields → YAML top level (only explicitly set fields, not Pydantic defaults)
    explicitly_set = config_file.model_fields_set - {"profile", "active_profile"}
    toplevel_raw = config_file.model_dump(include=explicitly_set, exclude_none=True)
    yaml_data: dict[str, Any] = {
        "active_profile": active_profile,
        **map_fields_to_nested_structure(toplevel_raw),
        "profile": {},
    }

    out_path = Path(RAICONFIG_YAML)
    failed: list[str] = []
    config_field_keys = set(FIELD_MAPPINGS.keys()) - CONNECTION_FIELDS

    for profile_name in profiles_to_migrate:
        block, error = _convert_profile(profiles.get(profile_name, {}), config_field_keys)
        if error is not None:
            wizard_body(
                f"[yellow]⚠ Skipped '{profile_name}'[/yellow] [dim]({error})[/dim]"
            )
            failed.append(profile_name)
            continue
        assert block is not None  # narrowed by the error check above
        yaml_data["profile"][profile_name] = block
        wizard_body(
            f"[green]✓[/green] [bold]{profile_name}[/bold] "
            f"[dim](connection: {block['default_connection']})[/dim]"
        )

    if not yaml_data["profile"]:
        wizard_pipe()
        wizard_step(
            "[yellow]No profiles could be migrated.[/yellow]",
            style="yellow",
            pending=True,
        )
        wizard_pipe()
        # Plain bar in click confirm — see note in run_init_wizard.
        if click.confirm("│  Create a fresh raiconfig.yaml from template instead?", default=True):
            _create_template()
        return

    _write_yaml(yaml_data, out_path)

    # Field-drop warning prints its own step+body if any hints exist.
    _warn_dropped_fields(toml_data, profiles_to_migrate)

    wizard_pipe()
    wizard_close(
        f"[green]Migrated[/green] [cyan]{toml_path}[/cyan] → [cyan]{out_path}[/cyan]"
    )
    if failed:
        wizard_close_body(
            f"[yellow]⚠ Skipped profiles (errors above):[/yellow] "
            f"{', '.join(failed)}"
        )
    wizard_close_body(
        f"[dim]Tip: Review {out_path}, then remove {toml_path} when ready.[/dim]"
    )
    rich.print()


# ── Path 3: Create template ───────────────────────────────────────────────────

def _create_template() -> None:
    """Write raiconfig.yaml from the commented template."""
    from .template_config import CONFIG_TEMPLATE

    out_path = Path(RAICONFIG_YAML)
    out_path.write_text(CONFIG_TEMPLATE, encoding="utf-8")

    wizard_pipe()
    wizard_close(f"[green]Created[/green] [bold]{out_path}[/bold]")
    wizard_close_body("[dim]Open it and fill in your connection details.[/dim]")
    rich.print()


# ── YAML serialization ───────────────────────────────────────────────────────

def _write_yaml(config_dict: dict, path: Path) -> None:
    """Serialize config dict to YAML with clean formatting."""
    import yaml

    content = yaml.dump(
        config_dict,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        indent=2,
    )
    content = _add_block_spacing(content)
    path.write_text(content, encoding="utf-8")


def _add_block_spacing(content: str) -> str:
    """Insert blank lines between sibling entries inside profile and connections blocks."""
    SPACED_KEYS = {"profile", "connections"}
    lines = content.splitlines()
    result: list[str] = []
    # Maps entry_indent → True (waiting for first entry) / False (first seen)
    spaced_blocks: dict[int, bool] = {}

    for line in lines:
        stripped = line.lstrip()
        if not stripped:
            result.append(line)
            continue

        current_indent = len(line) - len(stripped)

        # Pop blocks that are deeper than the current indent (we've left them)
        spaced_blocks = {k: v for k, v in spaced_blocks.items() if k <= current_indent}

        # If this line opens a tracked block (e.g. "profile:" or "connections:"),
        # register its child indent so siblings get blank lines between them.
        key = stripped.split(":")[0]
        if key in SPACED_KEYS and stripped == f"{key}:":
            spaced_blocks[current_indent + 2] = True

        # If we're at a tracked indent, insert a blank line before every sibling
        # except the first.
        if current_indent in spaced_blocks:
            if not spaced_blocks[current_indent]:
                result.append("")
            spaced_blocks[current_indent] = False

        result.append(line)

    return "\n".join(result) + "\n"
