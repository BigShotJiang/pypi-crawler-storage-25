"""Rich-free CLI path / config-file discovery helpers.

Sits below :mod:`_init_common` and :mod:`commands._diagnose_helpers` in
the import graph: both modules need to walk the workspace upward for
``raiconfig.yaml`` (or its ``.yml`` sibling), but only one of them
(``_init_common``) is allowed to pull Rich into its import tree —
``_diagnose_helpers`` is intentionally Rich-free so the diagnose JSON
path stays light. Centralizing the walk here means a single
implementation that both can import without dragging Rich in.
"""

from __future__ import annotations

from pathlib import Path

RAICONFIG_YAML = "raiconfig.yaml"
RAICONFIG_YML = "raiconfig.yml"


def find_existing_yaml() -> Path | None:
    """Return path to ``raiconfig.yaml``/``raiconfig.yml`` searching upward from cwd.

    Matches the discovery behaviour of :func:`relationalai.config.create_config`.
    Returns ``None`` when neither exists in the current directory or any
    parent.
    """
    from confocal import find_upwards

    for name in (RAICONFIG_YAML, RAICONFIG_YML):
        found = find_upwards(Path(name))
        if found:
            return found
    return None
