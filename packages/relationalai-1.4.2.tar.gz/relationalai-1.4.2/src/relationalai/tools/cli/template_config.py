"""Template for raiconfig.yaml.

A commented-out starting point showing all three connection types in one profile.
Uncomment and fill in the sections you need.
"""


CONFIG_TEMPLATE = """\
# raiconfig.yaml — RelationalAI configuration
# Uncomment and fill in the sections you need.

active_profile: dev

profile:                              # add more profiles (e.g. staging, prod) as needed
  dev:
    default_connection: snowflake   # change to: duckdb  or  local

    connections:

      # ── Snowflake ────────────────────────────────────────────────────────────
      snowflake:
        type: snowflake
        account: myorg-myaccount      # format: <org>-<account>, e.g. acme-prod123
        warehouse: compute_wh
        rai_app_name: relationalai    # name of the RAI app in your Snowflake account
        user: you@example.com
        authenticator: externalbrowser   # SSO via browser. Alternatives: programmatic_access_token (CI), jwt (service accounts).
        # Snowflake is phasing out single-factor password sign-in:
        # https://docs.snowflake.com/en/user-guide/security-mfa-rollout

        # role: MY_ROLE               # optional
        # database: MY_DATABASE       # optional
        # schema: PUBLIC              # optional

      # ── DuckDB ───────────────────────────────────────────────────────────────
      # duckdb:
      #   type: duckdb
      #   path: ":memory:"            # or a file path, e.g. /tmp/mydb.duckdb

      # ── Local RAI server ─────────────────────────────────────────────────────
      # local:
      #   type: local
      #   host: localhost
      #   port: 8010

    # ── Reasoners (optional) ─────────────────────────────────────────────────
    # reasoners:
    #   logic:
    #     name: my_reasoner           # reasoner instance name (Snowflake)
    #     size: HIGHMEM_X64_S         # reasoner size
"""

INSTALL_MODE_MODEL_PY_TEMPLATE = """\
import relationalai.semantics as rai
from relationalai.config import create_config
from relationalai.semantics import Integer

config = create_config()
model = rai.Model("{name}", config=config)

# Source table — update the FQN to match your Snowflake table
connections = model.Table("RAI_DEMO.SIMPLE_START.CONNECTIONS")

# Concepts
Station = model.Concept("Station", identify_by={{"id": Integer}})
Connection = model.Concept("Connection", identify_by={{"src": Station, "dst": Station}})

# Define Station entities from source rows
model.define(
    Station.new(id=connections.station_1),
    Station.new(id=connections.station_2),
)

# Define Connection entities from source rows
model.define(
    Connection.new(
        src=Station.filter_by(id=connections.station_1),
        dst=Station.ref().filter_by(id=connections.station_2),
    )
)

# Define a relationship between connected stations
Station.connections = model.Relationship(f"{{Station}} is connected to {{Station:other_station}}")
model.where(Connection.src == Station).define(Station.connections(Connection.dst))
"""

INSTALL_MODE_LOAD_DATA_TEMPLATE = """\
from relationalai.config import create_config
from relationalai.config.connections.snowflake import SnowflakeConnection

config = create_config()
session = config.get_connection(SnowflakeConnection).get_session()

# Creates the schema and table, then inserts sample data.
# Update the schema/table name to match your raiconfig.yaml.
session.sql(\"\"\"
begin
    create schema if not exists RAI_DEMO.SIMPLE_START;

    create or replace table RAI_DEMO.SIMPLE_START.CONNECTIONS (
        station_1 int,
        station_2 int
    );

    insert into RAI_DEMO.SIMPLE_START.CONNECTIONS (station_1, station_2) values
        (1, 2), (1, 3), (3, 4), (1, 4), (4, 5),
        (5, 7), (6, 7), (6, 8), (7, 8);
end;
\"\"\").collect()

print("Data loaded successfully.")
"""

INSTALL_MODE_QUERIES_PY_TEMPLATE = """\
from relationalai.semantics.std import aggregates

from model import model, Station, Connection

if __name__ == "__main__":
    # List all stations
    print("Stations:")
    model.select(Station.id).inspect()

    # Count connections
    print("Total connections:")
    model.select(aggregates.count(Connection)).inspect()
"""

INSTALL_MODE_README_TEMPLATE = """\
# {name}

A RelationalAI install-mode starter project.

## Overview

This project demonstrates how to build a semantic model with RelationalAI
over your Snowflake data.

The example models a **power station network** — a set of stations connected
by transmission lines. The data is a single table called `CONNECTIONS` with
two integer columns (`station_1`, `station_2`), where each row represents a
connection between two stations.

## What you will learn

- How to define **Concepts** (`Station`, `Connection`) that map to Snowflake tables.
- How to define **Relationships** between concepts.
- How to query the installed model from a separate script.

## Project structure

```
{name}/
├── raiconfig.yaml    — connection config (dev + prod profiles)
├── model.py          — model definition (Station, Connection, relationships)
├── load_data.py      — creates the schema/table and inserts sample data
├── queries.py        — example queries: list stations, count connections
├── pyproject.toml    — project metadata
└── README.md         — this file
```

## Setup

Fill in your Snowflake connection details in `raiconfig.yaml`
(account, warehouse, user, schema, role). The default authenticator
is `externalbrowser` — no password needed; a browser opens for SSO
on first connect. To use PAT or key-pair instead, see
[Switching authenticator](#switching-authenticator) below.

## Switching authenticator

The default is `externalbrowser` (browser-based SSO). To switch, edit the
`connections.snowflake` block in `raiconfig.yaml` for each profile.

**Programmatic Access Token** — paste a token from Snowflake UI (Account →
Security → Programmatic Access Tokens). Good for CI / automation.

```yaml
authenticator: programmatic_access_token
token_file_path: ~/.snowflake/pat   # or  token: "your_pat_here"
user: you@example.com
```

**Key-pair JWT** — generate an RSA keypair and register the public key on
your Snowflake user. Most secure; good for service accounts.

```yaml
authenticator: jwt
private_key_path: ~/.ssh/sf_rsa.p8   # + optional `private_key_passphrase`
user: you@example.com
```

## Usage

**Step 1 — Load sample data into Snowflake:**
```bash
python load_data.py
```
This creates the `RAI_DEMO.SIMPLE_START` schema and populates the
`CONNECTIONS` table with 9 edges between 8 stations.

**Step 2 — Install the model:**
```bash
rai models install
```
This reads `model.py` (specified by `model_file_path` in `raiconfig.yaml`)
and installs the model's views and tables into your target schema.

**Step 3 — Run queries:**
```bash
python queries.py
```
This lists all stations and counts connections.

## Refreshing the model

By default, the starter doesn't schedule automatic refreshes. After
`rai models install`, the model runs a single full refresh to populate
its tables, then sits idle. To enable continuous refresh, add to
`raiconfig.yaml`:

```yaml
schedule:
  interval_s: 60      # refresh every 60s
```

This creates a scheduled task `<schema>_meta.REFRESH_TASK_60S` in
Snowflake that runs the model's refresh procedure on the given interval.

**Checking task state in Snowflake:**

```sql
SHOW TASKS IN SCHEMA <your_schema>_meta;
DESCRIBE TASK <your_schema>_meta.FULL_MODEL_REFRESH_TASK;
SELECT * FROM <your_schema>_meta.REFRESH_LOG ORDER BY ended_at DESC;
```

## The model

`model.py` defines two concepts:

- **Station** — identified by an integer `id`. Created from both `station_1`
  and `station_2` columns in the source table.
- **Connection** — identified by a `src` and `dst` Station pair. Represents
  a direct link between two stations.

A **Relationship** (`Station.connections`) is then defined so each station
knows which other stations it connects to. This relationship powers the
queries in `queries.py`.

## Profiles

`raiconfig.yaml` includes two profiles: `dev` and `prod`. Switch between them
by setting `active_profile`:
```yaml
active_profile: prod
```

To see more examples and analytics capabilities, visit the
[RelationalAI templates page](https://docs.relational.ai/build/templates/).
"""

INSTALL_MODE_PYPROJECT_TOML_TEMPLATE = """\
[project]
name = "{name}"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "relationalai",
]
"""

INSTALL_MODE_CONFIG_TEMPLATE = """\
# raiconfig.yaml — RelationalAI configuration (install mode)
# Switch profiles with: active_profile: dev  or  active_profile: prod

active_profile: dev
install_mode: true

profile:
  dev:
    default_connection: snowflake

    connections:
      snowflake:
        type: snowflake
        account: myorg-myaccount      # format: <org>-<account>, e.g. acme-prod123
        warehouse: compute_wh
        rai_app_name: relationalai    # name of the RAI app in your Snowflake account
        authenticator: externalbrowser   # SSO via browser; for PAT or JWT see README.md
        user: you@example.com

    model:
      schema: your_dev_schema         # schema where model views and tables are installed
      role: your_role                 # Snowflake role to use when installing the model
      model_file_path: model.py       # path to the model entry point script
      # auto_install: false           # set to true to auto-install the model before queries

  prod:
    default_connection: snowflake

    connections:
      snowflake:
        type: snowflake
        account: myorg-myaccount      # format: <org>-<account>, e.g. acme-prod123
        warehouse: compute_wh
        rai_app_name: relationalai
        authenticator: externalbrowser   # SSO via browser; for PAT or JWT see README.md
        user: you@example.com

    model:
      schema: your_prod_schema        # schema where model views and tables are installed
      role: your_role
      model_file_path: model.py
"""
