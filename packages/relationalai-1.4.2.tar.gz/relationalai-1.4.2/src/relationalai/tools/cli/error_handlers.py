"""Backend error → CLI diagnostic translation.

The handler chain takes an exception + messages collected from its cause/context
and produces a human-friendly ``Details:`` block for :func:`emit_cli_diagnostic`.

Each handler is either:

- A :class:`PatternHandler` — purely declarative (pattern + template). This
  covers most "recognize a backend phrase → render a fix-it block" cases.
- A full class implementing the :class:`CliErrorHandler` :class:`~typing.Protocol`
  — used when the handler needs custom regex capture or state-shaping.

The :data:`DEFAULT_CLI_ERROR_HANDLER_CHAIN` at the bottom of this module wires
them up in priority order.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol, TypedDict

from relationalai.client.errors.handlers import collect_error_messages
from rich.markup import escape as rich_escape


# ── Context + protocol ───────────────────────────────────────────────────────


class CliErrorParams(TypedDict, total=False):
    """The canonical, narrow set of keys that flow through CLI error params.

    Used as the typed shape for :func:`errors.set_error_params` and the
    :func:`commands._common.select_params` factory so the *callers* of
    the error pipeline get pyright-validated keys (no silent typos in
    ``set_error_params({"reasoner_naam": ...})``).

    Handler code still consumes the loose ``Mapping[str, Any]`` on
    :attr:`CliErrorContext.params` — exotic keys remain expressible
    when truly needed — but anything that flows through the standard
    ``set_error_params`` / ``select_params`` path is type-checked.

    Overlapping names (``reasoner_type`` and ``type``, ``job_id`` and ``id``, …)
    reflect kwargs produced by different command groups — not an invitation to
    pass both for the same value. Populate the keys your command's ``select_params``
    mapping emits; handlers should read the keyed field that matches the command.

    All keys are ``total=False`` because every command stashes a
    different subset (``reasoners create`` cares about size,
    ``jobs events`` about transaction/stream identifiers, ...).
    """

    reasoner_type: str
    reasoner_name: str
    reasoner_size: str
    job_type: str
    job_id: str
    type: str
    name: str
    id: str
    size: str
    state: str
    created_by: str
    operation: str
    stream_name: str
    auto_suspend_mins: int


@dataclass(frozen=True)
class CliErrorContext:
    """Generic context for formatting CLI errors.

    Keep :attr:`params` typed as ``Mapping[str, Any]`` (not the narrower
    :class:`CliErrorParams`) so handler code that needs to read uncommon
    keys via ``ctx.params.get(...)`` stays expressible. The TypedDict
    discipline is enforced at the *write* side
    (:func:`errors.set_error_params`, :func:`commands._common.select_params`).
    """

    command: str
    params: Mapping[str, Any]


class CliErrorHandler(Protocol):
    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool: ...
    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str: ...


# ── Diagnostic emitter ───────────────────────────────────────────────────────


def emit_cli_diagnostic(
    *,
    name: str,
    message: str,
    details: str | None = None,
    escape_details: bool = False,
) -> None:
    """Emit a Rich diagnostic to stderr (shared by ``cli`` and ``docs`` helpers)."""
    import sys

    from relationalai.util.error import Diagnostic, Part, RichEmitter

    if details is None:
        rendered: str | None = None
    elif escape_details:
        rendered = rich_escape(details)
    else:
        rendered = details
    if rendered == "":
        rendered = None
    parts: list[Part] = [rendered] if rendered else []
    diag = Diagnostic(name=name, message=message, parts=parts, severity="error")
    sys.stderr.write(RichEmitter().emit(diag).rstrip() + "\n")


# ── Small message helpers (used by handlers) ─────────────────────────────────


def _norm(s: str) -> str:
    """Whitespace-collapsed, lowercased string (robust to backend newlines)."""
    return " ".join(str(s or "").split()).lower()


def _contains_any(messages: list[str], needles: tuple[str, ...]) -> bool:
    ns = tuple(_norm(n) for n in needles if isinstance(n, str) and n)
    if not ns:
        return False
    for msg in messages:
        if not isinstance(msg, str) or not msg:
            continue
        m = _norm(msg)
        if any(n in m for n in ns):
            return True
    return False


def _first_message_matching(messages: list[str], needles: tuple[str, ...]) -> str | None:
    ns = tuple(_norm(n) for n in needles if isinstance(n, str) and n)
    if not ns:
        return None
    for msg in messages:
        if not isinstance(msg, str) or not msg.strip():
            continue
        if any(n in _norm(msg) for n in ns):
            return msg.strip()
    return None


def _extract_service_message(text: str) -> str | None:
    """Best-effort extract of the backend 'message' field."""
    if not text:
        return None
    m = re.search(r'"message"\s*:\s*"([^"]+)"', text, flags=re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r"bad request\s*-\s*([^\(\n]+)", text, flags=re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


def _replace_engine_words(text: str) -> str:
    """Rewrite internal 'engine'/'worker' words to user-facing 'reasoner'."""
    out = re.sub(r"\bengine\b", "reasoner", text, flags=re.IGNORECASE)
    out = re.sub(r"\bengines\b", "reasoners", out, flags=re.IGNORECASE)
    out = re.sub(r"\bworker\b", "reasoner", out, flags=re.IGNORECASE)
    return out


def _normalize_equivalent_message(text: str) -> str:
    """Normalize a message for loose equivalence checks (dedup ``Problem:``/``Details:``)."""
    s = _norm(text).strip()
    s = re.sub(r"[.!?,;:]+$", "", s).strip()
    return s


def _escape_detail(text: Any) -> str:
    """Escape user/backend-provided text for use in Rich markup strings."""
    return rich_escape("" if text is None else str(text))


def _green(cmd: str) -> str:
    return f"[green]{cmd}[/green]"


def _param(ctx: CliErrorContext, key: str) -> str | None:
    v = ctx.params.get(key)
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def _reasoner_type_name(ctx: CliErrorContext) -> tuple[str | None, str | None]:
    reasoner_type = _param(ctx, "job_type") or _param(ctx, "reasoner_type") or _param(ctx, "type")
    reasoner_name = _param(ctx, "reasoner_name") or _param(ctx, "name")
    return reasoner_type, reasoner_name


def _reasoner_type_label(reasoner_type: str | None) -> str | None:
    """Prefer CLI-facing reasoner type labels (Logic/Prescriptive/Predictive)."""
    from .job_types import cli_type_label

    return cli_type_label(reasoner_type)


# ── Declarative handler ──────────────────────────────────────────────────────


Template = Callable[[Exception, CliErrorContext, list[str]], str]


@dataclass(frozen=True)
class PatternHandler:
    """Declarative handler: ``commands`` × ``needles`` → ``template(error, ctx, messages)``.

    ``commands=None`` means "any command". ``needles`` must match at least one
    of the collected error messages (case-insensitive, whitespace-collapsed).
    """

    commands: tuple[str, ...] | None
    needles: tuple[str, ...]
    template: Template

    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool:
        if self.commands is not None:
            cmd = str(getattr(ctx, "command", "") or "").strip()
            if cmd not in self.commands:
                return False
        return _contains_any(messages, self.needles)

    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str:
        return self.template(error, ctx, messages)


# ── Templates for declarative handlers ───────────────────────────────────────


def _tmpl_snowflake_auth(error: Exception, ctx: CliErrorContext, messages: list[str]) -> str:
    needles = ("unable to authenticate to snowflake", "saml response is invalid", "matching user is not found")
    detail = _first_message_matching(messages, needles) or (str(error) or repr(error))
    detail = detail.replace('\\"', '"').strip()

    lines = ["Problem: unable to authenticate to Snowflake."]
    if detail and _normalize_equivalent_message(detail) != _normalize_equivalent_message(
        "unable to authenticate to snowflake"
    ):
        lines.append(f"Details: {_escape_detail(detail)}")
    lines.append("")
    lines.append("Fix: verify your Snowflake login/SSO works (try the Snowflake web UI).")
    lines.append("If you see a SAML error there too, contact your Snowflake admin to resolve the user/IdP mapping.")
    return "\n".join(lines)


def _tmpl_snowflake_auth_generic(error: Exception, ctx: CliErrorContext, messages: list[str]) -> str:
    raw = _replace_engine_words(str(error) or repr(error))
    lines = ["Problem: unable to authenticate to Snowflake."]
    if raw:
        # Backend text may contain ``[``/``]`` that Rich would interpret as markup.
        lines.append(f"Details: {_escape_detail(raw)}")
    return "\n".join(lines)


def _tmpl_transaction_payload_missing(error: Exception, ctx: CliErrorContext, messages: list[str]) -> str:
    reasoner_type, reasoner_name = _reasoner_type_name(ctx)
    reasoner_type_label = _reasoner_type_label(reasoner_type)

    lines = ["Problem: you selected Logic jobs (transactions) but the payload is missing required fields."]
    if reasoner_name:
        lines.append(f"Reasoner: {reasoner_name}")
    if reasoner_type_label:
        lines.append(f"Job type: {reasoner_type_label}")
    lines.append("")
    lines.append("Fix:")
    lines.append("- If you meant a Prescriptive job, use `--type Prescriptive`")
    lines.append("- If you meant a Logic transaction, provide `--database` and `--raw-code` (or a payload with dbname/query).")

    if reasoner_name:
        lines.append("")
        lines.append("Examples:")
        lines.append("  " + _green(f"rai jobs create --type Prescriptive --name {reasoner_name} --payload-json ..."))
        lines.append("  " + _green(f"rai jobs create --type Logic --name {reasoner_name} --database DB --raw-code '...'"))
    return "\n".join(lines)


def _tmpl_suspended_reasoner(error: Exception, ctx: CliErrorContext, messages: list[str]) -> str:
    raw = str(error) or repr(error)
    service_msg = _extract_service_message(raw) or "reasoner is suspended"
    service_msg = _replace_engine_words(service_msg)

    reasoner_type, reasoner_name = _reasoner_type_name(ctx)
    reasoner_type_label = _reasoner_type_label(reasoner_type)

    lines = [f"Problem: {_escape_detail(service_msg)}."]
    if reasoner_name:
        lines.append(f"Reasoner: {_escape_detail(reasoner_name)}")
    if reasoner_type_label:
        lines.append(f"Type: {_escape_detail(reasoner_type_label)}")

    if reasoner_type_label and reasoner_name:
        lines.append("")
        lines.append("Fix: resume the reasoner, then retry.")
        lines.append(
            "  " + _green(
                f"rai reasoners resume --type {_escape_detail(reasoner_type_label)} "
                f"--name {_escape_detail(reasoner_name)}"
            )
        )
    return "\n".join(lines)


def _tmpl_reasoner_not_found(error: Exception, ctx: CliErrorContext, messages: list[str]) -> str:
    raw = str(error) or repr(error)
    service_msg = _extract_service_message(raw) or "reasoner not found"
    service_msg = _replace_engine_words(service_msg)

    reasoner_type, reasoner_name = _reasoner_type_name(ctx)
    reasoner_type_label = _reasoner_type_label(reasoner_type)

    lines = [f"Problem: {_escape_detail(service_msg)}."]
    if reasoner_name:
        lines.append(f"Reasoner: {_escape_detail(reasoner_name)}")
    if reasoner_type_label:
        lines.append(f"Type: {_escape_detail(reasoner_type_label)}")

    lines.append("")
    lines.append("Fix: create the reasoner, then retry.")
    if reasoner_type_label and reasoner_name:
        lines.append(
            "  " + _green(
                f"rai reasoners create --type {_escape_detail(reasoner_type_label)} "
                f"--name {_escape_detail(reasoner_name)}"
            )
        )
    else:
        lines.append(f"  {_green('rai reasoners create')}")
    return "\n".join(lines)


# ── Classy handlers (kept for the few cases that need regex capture) ─────────


class TransactionEventsNotFoundForUserHandler:
    _NEEDLES = ("GET_TRANSACTION_EVENTS", "not found for user", '"status":"Not Found"')
    _TX_NOT_FOUND_RE = re.compile(
        r'transaction\s+"(?P<transaction_id>[^"]+)"\s+not found for user\s+"(?P<user>[^"]+)"',
        flags=re.IGNORECASE,
    )

    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool:
        # Accept both the canonical ``jobs events`` command name (post
        # noun-verb migration) and the legacy ``jobs:events`` colon name
        # so the handler still fires when someone invokes the deprecated
        # alias and ``handle_cli_errors`` records the alias's name.
        cmd = str(getattr(ctx, "command", "") or "").strip()
        if cmd not in ("jobs events", "jobs:events"):
            return False
        raw_norm = (str(error) or repr(error)).replace('\\"', '"')
        if self._TX_NOT_FOUND_RE.search(raw_norm):
            return True
        hay = " ".join(_norm(m) for m in messages if isinstance(m, str))
        return ("get_transaction_events" in hay) and ("not found for user" in hay)

    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str:
        del messages  # unused; details come from the raw error text
        raw_norm = (str(error) or repr(error)).replace('\\"', '"')
        m = self._TX_NOT_FOUND_RE.search(raw_norm)
        transaction_id = m.group("transaction_id").strip() if m else None
        user = m.group("user").strip() if m else None

        job_id = _param(ctx, "job_id") or _param(ctx, "id")
        reasoner_type, _ = _reasoner_type_name(ctx)
        reasoner_type_label = _reasoner_type_label(reasoner_type)

        lines = ["Problem: job events were not found for the current user."]
        if job_id:
            lines.append(f"Job ID: {_escape_detail(job_id)}")
        if reasoner_type_label:
            lines.append(f"Type: {_escape_detail(reasoner_type_label)}")
        if transaction_id:
            lines.append(f"Transaction: {_escape_detail(transaction_id)}")
        if user:
            lines.append(f"User: {_escape_detail(user)}")
        lines.append("")
        lines.append("Note: job IDs are only valid for the user that created the job.")
        lines.append("Fix: choose a job you created, then retry.")
        if user:
            lines.append("  " + _green(f"rai jobs list --created-by {_escape_detail(user)}"))
        else:
            lines.append("  " + _green("rai jobs list"))
        return "\n".join(lines)


class InvalidJobTypeForReasonerHandler:
    _NEEDLES = ("CREATE_JOB", "invalid job type")

    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool:
        hay = " ".join(_norm(m) for m in messages if isinstance(m, str))
        if "invalid job type" not in hay or "create_job" not in hay:
            return False
        # Don't overtake more specific reasoner resource errors.
        if ("engine not found" in hay) or ("reasoner not found" in hay):
            return False
        return True

    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str:
        del messages  # unused; details come from the raw error text
        raw = str(error) or repr(error)
        service_msg = _extract_service_message(raw) or "invalid job type"

        reasoner_type, reasoner_name = _reasoner_type_name(ctx)
        reasoner_type_label = _reasoner_type_label(reasoner_type)

        lines = [
            "Problem: job type does not match the reasoner type.",
            f"Details: {_escape_detail(service_msg)}.",
        ]
        if reasoner_name:
            lines.append(f"Reasoner: {_escape_detail(reasoner_name)}")
        if reasoner_type_label:
            lines.append(f"Job type: {_escape_detail(reasoner_type_label)}")
        lines.append("")
        lines.append("Fix: use the reasoner's actual type with `--type`.")
        if reasoner_name:
            lines.append("  " + _green(f"rai reasoners list --name {_escape_detail(reasoner_name)}"))
        lines.append("  " + _green("rai jobs create --type <Logic|Prescriptive|Predictive> --reasoner-name <name> ..."))
        return "\n".join(lines)


class JobCreateNotReadyHandler:
    """Narrow: backend "not ready" failures when trying to create a job.

    Matches a small set of backend phrases (e.g. "worker is not ready to accept
    jobs") and rewrites implementation words (``engine``/``worker``) to
    user-facing ``reasoner`` before showing details.
    """

    _NEEDLES = ("not ready to accept jobs", "job request could not be completed yet")

    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool:
        # See ``TransactionEventsNotFoundForUserHandler.matches`` for why
        # both the noun-verb and colon names are accepted here.
        cmd = str(getattr(ctx, "command", "") or "").strip()
        if cmd not in ("jobs create", "jobs:create"):
            return False
        return _contains_any(messages, self._NEEDLES)

    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str:
        del messages  # unused; details come from the raw error text
        raw = str(error) or repr(error)
        service_msg = (
            getattr(error, "details", None)
            or _extract_service_message(raw)
            or "reasoner is not ready to accept jobs"
        )
        service_msg = _replace_engine_words(service_msg)

        operation = getattr(error, "operation", None) or _param(ctx, "operation") or "create"
        reasoner_type, reasoner_name = _reasoner_type_name(ctx)
        reasoner_type_label = _reasoner_type_label(reasoner_type)

        lines = [
            "Problem: the reasoner is not ready to accept jobs yet.",
            f"Details: {_escape_detail(service_msg)}.",
        ]
        if reasoner_name:
            lines.append(f"Reasoner: {_escape_detail(reasoner_name)}")
        if reasoner_type_label:
            lines.append(f"Type: {_escape_detail(reasoner_type_label)}")
        if operation:
            lines.append(f"Operation: {_escape_detail(operation)}")

        lines.append("")
        lines.append("Fix: check whether the reasoner is still starting or suspended, then retry the job.")
        if reasoner_type_label and reasoner_name:
            lines.append(
                "  " + _green(
                    f"rai reasoners get --type {_escape_detail(reasoner_type_label)} "
                    f"--name {_escape_detail(reasoner_name)}"
                )
            )
            lines.append(
                "  " + _green(
                    f"rai reasoners resume --type {_escape_detail(reasoner_type_label)} "
                    f"--name {_escape_detail(reasoner_name)}"
                )
            )
        return "\n".join(lines)


class ReasonerAlreadyExistsHandler:
    """Matches several loosely-worded "already exists" responses with size hints."""

    def matches(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> bool:
        hay = " ".join(m for m in messages if isinstance(m, str)).lower()
        return ("reasoner already exists" in hay) or ("already exists but does not match requested" in hay)

    def format_details(self, error: Exception, messages: list[str], ctx: CliErrorContext) -> str:
        del messages  # unused; details come from the raw error text
        raw = str(error) or repr(error)
        reasoner_type, reasoner_name = _reasoner_type_name(ctx)
        reasoner_type_label = _reasoner_type_label(reasoner_type)
        requested_size = _param(ctx, "reasoner_size") or _param(ctx, "size")

        state = None
        m = re.search(r"\bstate=([A-Z_]+)\b", raw)
        if m:
            state = m.group(1).strip()

        lines = ["Problem: a reasoner with the same name and type already exists."]
        if reasoner_name:
            lines.append(f"Reasoner: {_escape_detail(reasoner_name)}")
        if reasoner_type_label:
            lines.append(f"Type: {_escape_detail(reasoner_type_label)}")
        if state:
            lines.append(f"State: {_escape_detail(state)}")

        lines.append("")
        if requested_size:
            lines.append(f"Requested size: {_escape_detail(requested_size)}")
        lines.append("Note: reasoner size cannot be changed in-place.")
        lines.append("Fix: delete the existing reasoner, then create it again with the desired size.")

        if reasoner_type_label and reasoner_name:
            lines.append(
                "  " + _green(
                    f"rai reasoners delete --type {_escape_detail(reasoner_type_label)} "
                    f"--name {_escape_detail(reasoner_name)}"
                )
            )
            if requested_size:
                lines.append(
                    "  " + _green(
                        f"rai reasoners create --type {_escape_detail(reasoner_type_label)} "
                        f"--name {_escape_detail(reasoner_name)} --size {_escape_detail(requested_size)}"
                    )
                )
            else:
                lines.append(
                    "  " + _green(
                        f"rai reasoners create --type {_escape_detail(reasoner_type_label)} "
                        f"--name {_escape_detail(reasoner_name)}"
                    )
                )
        return "\n".join(lines)


# ── Handler chain ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CliErrorHandlerChain:
    handlers: list[CliErrorHandler]

    def format_details(self, error: Exception, ctx: CliErrorContext) -> str:
        messages = collect_error_messages(error)
        for h in self.handlers:
            try:
                if h.matches(error, messages, ctx):
                    return h.format_details(error, messages, ctx)
            except Exception:
                continue
        return str(error) or repr(error)


DEFAULT_CLI_ERROR_HANDLER_CHAIN = CliErrorHandlerChain(
    handlers=[
        # Narrow / classy handlers first (they use regex capture or per-command context).
        TransactionEventsNotFoundForUserHandler(),
        InvalidJobTypeForReasonerHandler(),
        JobCreateNotReadyHandler(),
        ReasonerAlreadyExistsHandler(),
        # Declarative handlers covered by PatternHandler.
        PatternHandler(
            commands=None,
            needles=(
                "unable to authenticate to snowflake",
                "saml response is invalid",
                "matching user is not found",
            ),
            template=_tmpl_snowflake_auth,
        ),
        PatternHandler(
            commands=None,
            needles=(
                "saml response is invalid",
                "matching user is not found",
                "unable to authenticate to snowflake",
                "authentication",
                "sso",
            ),
            template=_tmpl_snowflake_auth_generic,
        ),
        PatternHandler(
            # Accept both the canonical noun-verb and the legacy colon name
            # so the handler still fires for users who invoked the deprecated
            # ``jobs:create`` alias.
            commands=("jobs create", "jobs:create"),
            needles=("transaction create requires payload",),
            template=_tmpl_transaction_payload_missing,
        ),
        PatternHandler(
            commands=None,
            needles=("engine is suspended", "reasoner is suspended"),
            template=_tmpl_suspended_reasoner,
        ),
        PatternHandler(
            commands=None,
            needles=("engine not found", "reasoner not found"),
            template=_tmpl_reasoner_not_found,
        ),
    ]
)


