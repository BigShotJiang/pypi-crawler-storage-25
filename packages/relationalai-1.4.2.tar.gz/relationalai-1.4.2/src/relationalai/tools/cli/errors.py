"""Unified CLI error handling.

Provides:

- :func:`emit_cli_error` — stderr diagnostic
- :func:`cli_fail` — emit diagnostic then raise ``ClickException``
- :func:`handle_cli_errors` — decorator that wraps a Click callback in ``cli_fail``
- :func:`set_error_params` — stash per-command error params on the Click context
  so handlers can extract them even from commands that fail mid-progress.
"""

from __future__ import annotations

import functools
from collections.abc import Callable, Mapping
from typing import Any, TypeVar, cast

import click

from .error_handlers import (
    CliErrorContext,
    CliErrorParams,
    DEFAULT_CLI_ERROR_HANDLER_CHAIN,
    emit_cli_diagnostic,
)

F = TypeVar("F", bound=Callable[..., Any])

_CTX_ERROR_PARAMS_KEY = "_error_params"


def emit_cli_error(*, name: str, message: str, details: str | None = None) -> None:
    """Emit a pretty diagnostic for CLI failures (stderr)."""
    emit_cli_diagnostic(name=name, message=message, details=details)


def _format_details(
    name: str, error: Exception, params: Mapping[str, Any] | None
) -> str:
    ctx = CliErrorContext(command=name, params=params or {})
    return DEFAULT_CLI_ERROR_HANDLER_CHAIN.format_details(error, ctx)


def cli_fail(
    *,
    name: str,
    message: str,
    error: Exception,
    click_message: str,
    params: CliErrorParams | dict[str, Any] | None = None,
) -> None:
    """Emit a handled error diagnostic and then raise a :class:`ClickException`."""
    if isinstance(error, click.Abort):
        raise click.exceptions.Exit(0) from error

    details = _format_details(name, error, params)
    emit_cli_error(name=name, message=message, details=details)
    raise click.ClickException(click_message) from error


def set_error_params(params: CliErrorParams | dict[str, Any]) -> None:
    """Stash per-command error params on the current Click context.

    Useful for commands that accumulate context during their execution (e.g.
    ``jobs create`` resolving the reasoner name before calling the gateway).
    ``handle_cli_errors`` will pick this up if set.

    Accepts either the typed :class:`CliErrorParams` (preferred — pyright
    catches typos in the canonical keys) or a plain dict for one-off
    callers that need a non-canonical key.
    """
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return
    # Use ``ctx.meta`` (always a ``dict``) rather than ``ctx.obj`` so we don't
    # stomp on the shared :class:`CliRuntime` that carries ``--json`` / ``--no-color``
    # / diagnostic-flush state.
    ctx.meta[_CTX_ERROR_PARAMS_KEY] = dict(params)


def _get_error_params_from_ctx() -> dict[str, Any] | None:
    ctx = click.get_current_context(silent=True)
    if ctx is None or not hasattr(ctx, "meta"):
        return None
    v = ctx.meta.get(_CTX_ERROR_PARAMS_KEY)
    return dict(v) if isinstance(v, dict) else None


def handle_cli_errors(
    *,
    name: str,
    message: str,
    click_message: str,
    params: Callable[..., CliErrorParams | dict[str, Any]] | None = None,
) -> Callable[[F], F]:
    """Decorator: uncaught exceptions become :func:`cli_fail`.

    ``params`` is an optional callable that produces structured error context
    from the command's keyword arguments. It receives the same ``**kwargs`` the
    Click callback was invoked with; return a dict to pass to error handlers.

    If the command has already stashed error context via :func:`set_error_params`
    on the Click context, those values take precedence (allowing partial-progress
    context such as a resolved reasoner name).

    :class:`click.ClickException` (including :class:`click.UsageError`) is
    re-raised unchanged so Click's own argument validation continues to
    produce its usual help text.
    """

    def decorator(f: F) -> F:
        @functools.wraps(f)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return f(*args, **kwargs)
            except click.ClickException:
                # ``UsageError`` is a subclass of ``ClickException``; both propagate
                # unchanged so Click produces its usual argument-validation output.
                raise
            except Exception as e:
                built: CliErrorParams | dict[str, Any] | None = _get_error_params_from_ctx()
                if built is None and params is not None:
                    # Click always invokes callbacks with keyword arguments; call
                    # ``params`` with ``**kwargs`` only so ``select_params``-style
                    # ``def _extract(**kw)`` callbacks don't trip on phantom positionals
                    # when commands use ``@click.pass_context`` / ``@click.pass_obj``.
                    try:
                        built = params(**kwargs)
                    except Exception:
                        built = None
                cli_fail(
                    name=name,
                    message=message,
                    error=e,
                    click_message=click_message,
                    params=built,
                )

        return cast(F, wrapper)

    return decorator


def exit_on_docs_subcommand_failure(exc: BaseException, *, headline: str) -> None:
    """Emit a diagnostic and ``sys.exit(1)`` for docs subcommands."""
    import sys

    if isinstance(exc, click.ClickException):
        emit_cli_diagnostic(
            name="docs",
            message=headline,
            details=exc.message,
            escape_details=True,
        )
    else:
        emit_cli_diagnostic(
            name="docs",
            message=headline,
            details=str(exc) or repr(exc),
            escape_details=True,
        )
    sys.exit(1)
