"""Manifest text for `rai models dump`.

Rendered into ``skill.md`` inside the zip. Designed to be readable by both
engineers and LLM agents.

The template is fully static — it lists every artifact the dump can produce
and refers consumers to ``collection_log.txt`` to see which were actually
collected for this specific run. Keeping it static means the manifest is a
stable contract that consumers can rely on.
"""

from __future__ import annotations

SKILL_MD: str = """\
# Model Dump — Manifest

This zip was produced by `rai models dump` and contains diagnostic artifacts
for a RelationalAI install-mode project. It captures the state needed for RAI
engineers to debug a model installation remotely.

## Triage — start here

1. **Open `collection_log.txt` first.** It shows OK / skip / ERROR for every
   collector with a reason. Anything missing or partial is explained there.
2. **Check `pyrel_version.txt`** — confirms the version that produced this dump.
3. **Open `spans.jsonl` with the debugger UI:** `rai debugger spans.jsonl`.

## Files

| File | Description | Always present? |
|---|---|---|
| `collection_log.txt` | Per-collector outcome (OK / skip / ERROR) | Yes |
| `spans.jsonl` | OTEL-shaped tracer output from the latest install run (`build/runs/<id>/spans.jsonl`) — install + any queries that adopted it | Almost always |
| `v0_debug.jsonl` | Legacy v0 debug log (renamed from `debug.jsonl`) | Only if present locally |
| `plan.csv` | Orchestrator PLAN table — what was installed | Snowflake only |
| `refresh_log.csv` | Orchestrator REFRESH_LOG — run history | Snowflake only |
| `raiconfig.yaml` | Active config, with secrets redacted | If a config file was found |
| `pyrel_version.txt` | `relationalai.__version__` | Yes |
| `skill.md` | This file | Yes |

## File reference

### `collection_log.txt`
Plain-text table. Statuses:
- `OK` — artifact was collected; detail is byte size.
- `skip` — soft-skip; artifact not applicable to this run (e.g. wrong backend, no schema configured, file absent). Detail explains.
- `ERROR` — collector raised; detail is the full exception type and message.

### `spans.jsonl`
Collected from the latest install run directory on disk
(`build/runs/<UTC>_install_<id>/spans.jsonl`). Query sessions adopt the
latest install dir, so their spans appear in the same file.

Line-delimited JSON, OTEL-shaped. Each span produces two records:
1. `span_start` — emitted when the span opens.
2. The full span — emitted when the span closes, with `end_time_unix_nano`, `status`, `attributes`, `events`.

Common span fields: `trace_id`, `span_id`, `parent_span_id`, `name`,
`start_time_unix_nano`, `end_time_unix_nano`, `status`, `attributes`, `events`.

Typical install trace (under a top-level `install` span):
- `Relation Analyzer`
- `Catalog Builder` — attribute `result` is the Catalog (entity/relation/data stores)
- `Stratifier` — attribute `result` is the SCC graph (the install DAG)
- `Reasoner Router`
- `Coalescer` — attribute `result` is the list of CoalescedBlocks
- Per-block SQL or Logic execution spans

Errors surface as `status: "ERROR"` with `record_exception()` info in `events`.

**Inspect with:** `rai debugger spans.jsonl` (NiceGUI tree UI on
`http://localhost:8080`). Requires `pip install relationalai[debugger]`.

### `v0_debug.jsonl`
Older debug format from the v0 executor. Less structured than `spans.jsonl`.
Only present when v0 also wrote a `debug.jsonl` in the working directory.

### `plan.csv`
Snowflake only. The orchestrator's `PLAN` table from the meta schema
(`{model.schema}_meta.PLAN`). One row per installed CoalescedBlock.

Columns: `entry_id`, `target_table_names`, `block_index`, `sql_statements`,
`reasoner`, `refresh_interval_seconds`.

If install never ran (or hit an error before the orchestrator finalized),
this artifact will be **ERROR** in `collection_log.txt`.

### `refresh_log.csv`
Snowflake only. The orchestrator's `REFRESH_LOG` table — one row per refresh
attempt. **Look here first for failed runs.**

Columns: `log_id`, `target_table_names`, `block_index`, `run_start_time`,
`run_end_time`, `state`, `error_message`.

### `raiconfig.yaml`
Sanitized copy of the user's active config. Sensitive fields (anything typed
`SecretStr` in the Pydantic models — `password`, `private_key_passphrase`,
`oauth_client_secret`, `token`) are replaced with `<redacted>`. Path-to-secret
fields (`private_key_path`, `token_file_path`) are also redacted.

### `pyrel_version.txt`
Single line: `relationalai.__version__`.

## Typical debugging workflow

1. Read `collection_log.txt` → know what's available and what failed.
2. Read `pyrel_version.txt` → confirm version.
3. Skim `raiconfig.yaml` → connection type, target schema, profile in use.
4. If `refresh_log.csv` is present → look for `state != 'SUCCESS'` rows; inspect `error_message`.
5. If `plan.csv` is present → see what CoalescedBlocks were installed.
6. Open `spans.jsonl` with `rai debugger` to walk through the trace.

## For LLM agents

- **Filenames are stable.** You can hardcode them. The mapping above is the contract.
- **`collection_log.txt` is the source of truth** for what's in the zip. Parse it before assuming any other file exists.
- **`spans.jsonl` is OTEL-shaped.** Use `parent_span_id` to reconstruct the call tree.
- **Typical span hierarchy under `install`:** Relation Analyzer → Catalog Builder → Stratifier → Reasoner Router → Coalescer → per-block execution.
- **Span `attributes.result`** often contains the structured output of the pass (Catalog, SCCGraph, CoalescedBlocks).
- **CSV files** can be parsed with standard CSV tools; column names are stable.
- **`raiconfig.yaml` is YAML** with secrets replaced by the literal string `<redacted>`.
"""
