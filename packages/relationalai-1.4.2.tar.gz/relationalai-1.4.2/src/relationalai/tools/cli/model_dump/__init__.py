"""`rai models dump` — collect a diagnostic zip of an installed model."""

from .dump import run_model_dump

__all__ = ["run_model_dump"]
