"""Constants for `rai models dump`.

Stable filenames for entries inside the dump zip. These are the names that
consumers (engineers, LLM agents, the `skill.md` manifest, tests) can rely on.
They are intentionally decoupled from upstream source filenames — if the tracer
ever renames `spans.jsonl` to something else, our collector adapts but the zip
layout stays the same.
"""

from __future__ import annotations

from typing import Final

SPANS_JSONL: Final[str] = "spans.jsonl"
V0_DEBUG_JSONL: Final[str] = "v0_debug.jsonl"
PYREL_VERSION_TXT: Final[str] = "pyrel_version.txt"
PLAN_CSV: Final[str] = "plan.csv"
REFRESH_LOG_CSV: Final[str] = "refresh_log.csv"
RAICONFIG_YAML: Final[str] = "raiconfig.yaml"
SKILL_MD: Final[str] = "skill.md"
COLLECTION_LOG_TXT: Final[str] = "collection_log.txt"
