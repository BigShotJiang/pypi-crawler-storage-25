"""Collectors for `rai models dump`.

Each collector returns either a ``(filename, bytes)`` tuple to add to the zip,
or ``None`` if the artifact is not available (e.g. file missing, DuckDB backend).

Most collectors soft-skip by returning ``None`` when an artifact is unavailable,
so one missing piece doesn't fail the whole dump. Some collectors that query
live backend metadata may still raise operational errors (for example, query
failures); the orchestrator is responsible for catching and recording those
failures in ``collection_log.txt``.

Zip entry names come from :mod:`.constants` (a stable contract for consumers).
Source paths are resolved at runtime from the live system (e.g. the tracer)
so we adapt automatically if upstream paths change.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .constants import (
    PLAN_CSV,
    PYREL_VERSION_TXT,
    RAICONFIG_YAML,
    REFRESH_LOG_CSV,
    SKILL_MD,
    SPANS_JSONL,
    V0_DEBUG_JSONL,
)

if TYPE_CHECKING:
    from relationalai.config.config import Config


Artifact = tuple[str, bytes]


def collect_spans_jsonl(config: "Config") -> Artifact | None:
    """``spans.jsonl`` from the latest ``build/runs/<id>/`` install dir.

    Works in both scenarios: collected in-process right after an install
    (the latest dir is the active run) and collected from a fresh ``rai
    models dump`` process (we look up the latest install dir on disk).
    """
    del config  # not needed — path comes from the runs/ layout
    from relationalai.observability.run_paths import spans_path as resolve_spans_path

    path = resolve_spans_path(None)
    if path is None or not path.is_file():
        return None
    return (SPANS_JSONL, path.read_bytes())


def collect_v0_debug_jsonl() -> Artifact | None:
    """Legacy `debug.jsonl` if it exists. Renamed in the zip to disambiguate."""
    import os
    from pathlib import Path

    debug_path = Path(os.environ.get("RAI_DEBUG_LOG", "debug.jsonl"))
    if not debug_path.is_file():
        return None
    return (V0_DEBUG_JSONL, debug_path.read_bytes())


def collect_plan_csv(config: "Config") -> Artifact | None:
    """The orchestrator's PLAN table as CSV (Snowflake only)."""
    from relationalai.semantics.backends.sql.orchestrator import PLAN_TABLE_NAME
    return _collect_meta_table_csv(config, table=PLAN_TABLE_NAME, zip_name=PLAN_CSV)


def collect_refresh_log_csv(config: "Config") -> Artifact | None:
    """The orchestrator's REFRESH_LOG table as CSV (Snowflake only)."""
    from relationalai.semantics.backends.sql.orchestrator import REFRESH_LOG_TABLE_NAME
    return _collect_meta_table_csv(config, table=REFRESH_LOG_TABLE_NAME, zip_name=REFRESH_LOG_CSV)


def _collect_meta_table_csv(config: "Config", *, table: str, zip_name: str) -> Artifact | None:
    """Read an orchestrator meta-schema table and return it as CSV bytes.

    Returns None (soft-skip) if the artifact is not applicable to this run:
    - The active backend is not Snowflake.
    - `model.schema` is not configured.

    Raises if the Snowflake query itself fails (e.g. meta schema missing,
    permission denied, network error). The orchestrator catches and records
    the error in `collection_log.txt`.
    """
    from relationalai.config.connections.snowflake import SnowflakeConnection
    from relationalai.semantics.backends.sql.orchestrator import META_SCHEMA_SUFFIX

    try:
        snowflake_conn = config.get_connection(SnowflakeConnection)
    except Exception:
        return None  # not a Snowflake backend, or no default connection

    schema = config.model.schema_
    if not schema:
        return None  # no model.schema configured — can't locate meta tables

    meta_schema = f"{schema}{META_SCHEMA_SUFFIX}"
    session = snowflake_conn.get_session()
    query = "SELECT * FROM IDENTIFIER(?)"
    params = [f"{meta_schema}.{table}"]
    try:
        result = session.sql(query, params=params)
    except TypeError:
        result = session.sql(query, params)
    df = result.to_pandas()
    csv_text = df.to_csv(index=False)
    return (zip_name, csv_text.encode("utf-8"))


def collect_sanitized_config(config: "Config") -> Artifact | None:
    """Active raiconfig.yaml with secrets redacted."""
    del config  # path resolution mirrors the same discovery `create_config()` uses
    from .._init_common import find_existing_yaml
    from .sanitize import sanitize_raiconfig

    yaml_path = find_existing_yaml()
    if yaml_path is None:
        return None

    raw = yaml_path.read_text(encoding="utf-8")
    sanitized = sanitize_raiconfig(raw)
    return (RAICONFIG_YAML, sanitized.encode("utf-8"))


def collect_pyrel_version() -> Artifact | None:
    """One-line file with `relationalai.__version__`."""
    import relationalai
    version = getattr(relationalai, "__version__", "unknown")
    return (PYREL_VERSION_TXT, f"{version}\n".encode("utf-8"))


def collect_skill_md() -> Artifact | None:
    """Manifest describing the zip contents — readable by both engineers and LLM agents.

    The body is fully static and lists every artifact the dump can produce.
    Consumers should read ``collection_log.txt`` to see which were actually
    collected for a given run.
    """
    from .skill_template import SKILL_MD as SKILL_MD_BODY

    return (SKILL_MD, SKILL_MD_BODY.encode("utf-8"))
