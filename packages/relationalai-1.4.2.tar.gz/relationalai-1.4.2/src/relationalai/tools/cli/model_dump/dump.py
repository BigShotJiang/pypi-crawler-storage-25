"""Orchestrator for `rai models dump` — collects artifacts and writes the zip."""

from __future__ import annotations

import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from .. import runtime
from . import collectors
from .constants import (
    COLLECTION_LOG_TXT,
    PLAN_CSV,
    PYREL_VERSION_TXT,
    RAICONFIG_YAML,
    REFRESH_LOG_CSV,
    SKILL_MD,
    SPANS_JSONL,
    V0_DEBUG_JSONL,
)


@dataclass
class _CollectorRun:
    """Outcome of running one collector. Used to build collection_log.txt."""
    label: str                       # human-readable name (e.g. "spans.jsonl")
    status: str                      # "OK" | "skip" | "ERROR"
    detail: str = ""                 # extra info (filename + size, skip reason, error message)


def run_model_dump(output_path: Path | None = None) -> Path:
    """Collect diagnostic artifacts and write them to a zip.

    Returns the path to the produced zip file.
    """
    from relationalai.config import create_config

    config = create_config()

    artifacts: list[tuple[str, bytes]] = []
    runs: list[_CollectorRun] = []

    # Each entry: (label = zip entry name, callable returning Artifact | None or raises)
    steps: list[tuple[str, Callable[[], collectors.Artifact | None]]] = [
        (SPANS_JSONL,       lambda: collectors.collect_spans_jsonl(config)),
        (V0_DEBUG_JSONL,    lambda: collectors.collect_v0_debug_jsonl()),
        (PLAN_CSV,          lambda: collectors.collect_plan_csv(config)),
        (REFRESH_LOG_CSV,   lambda: collectors.collect_refresh_log_csv(config)),
        (RAICONFIG_YAML,    lambda: collectors.collect_sanitized_config(config)),
        (PYREL_VERSION_TXT, lambda: collectors.collect_pyrel_version()),
    ]

    for label, fn in steps:
        try:
            result = fn()
        except Exception as e:
            msg = f"{type(e).__name__}: {e}"
            runs.append(_CollectorRun(label, "ERROR", msg))
            runtime.console.print(f"  [err ] {label}: {msg}")
            continue

        if result is None:
            runs.append(_CollectorRun(label, "skip", "not applicable"))
            runtime.console.print(f"  [skip] {label}")
            continue

        name, data = result
        artifacts.append(result)
        runs.append(_CollectorRun(label, "OK", _format_size(len(data))))
        runtime.console.print(f"  [ ok ] {label}")

    # skill.md last (depends on what was collected)
    try:
        skill = collectors.collect_skill_md()
    except Exception as e:
        msg = f"{type(e).__name__}: {e}"
        runs.append(_CollectorRun(SKILL_MD, "ERROR", msg))
        runtime.console.print(f"  [err ] {SKILL_MD}: {msg}")
    else:
        if skill is not None:
            artifacts.append(skill)
            runs.append(_CollectorRun(SKILL_MD, "OK", _format_size(len(skill[1]))))
            runtime.console.print(f"  [ ok ] {SKILL_MD}")
        else:
            runs.append(_CollectorRun(SKILL_MD, "skip", "not implemented yet"))
            runtime.console.print(f"  [skip] {SKILL_MD}")

    # Collection log is always last and always present
    log_text = _format_collection_log(runs)
    artifacts.append((COLLECTION_LOG_TXT, log_text.encode("utf-8")))

    # Resolve output path. Accepts either a file path (used literally) or a
    # directory (a timestamped zip is written inside it).
    if output_path is None:
        output_path = Path.cwd() / _default_zip_name()
    else:
        output_path = Path(output_path)
        if output_path.is_dir():
            output_path = output_path / _default_zip_name()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Write the zip
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in artifacts:
            zf.writestr(name, data)

    return output_path


def _default_zip_name() -> str:
    """Timestamped default name for the dump zip."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"model_dump_{timestamp}.zip"


def _format_size(num_bytes: int) -> str:
    """Format a byte count as a human-readable string."""
    size: float = num_bytes
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{num_bytes} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} GB"


def _format_collection_log(runs: list[_CollectorRun]) -> str:
    """Render the collection log as a fixed-width text table."""
    label_w = max((len(r.label) for r in runs), default=0)
    status_w = max((len(r.status) for r in runs), default=0)

    lines = [
        "Collection log",
        "=" * 50,
        "",
        f"{'Status':<{status_w}}  {'Item':<{label_w}}  Detail",
        f"{'-' * status_w}  {'-' * label_w}  {'-' * 6}",
    ]
    for r in runs:
        lines.append(f"{r.status:<{status_w}}  {r.label:<{label_w}}  {r.detail}")
    return "\n".join(lines) + "\n"
