"""Sanitize `raiconfig.yaml` for the dump zip.

Two-layer default-deny whitelist:

1. **Section whitelist** — applied at the YAML root and recursively inside
   each ``profile.<name>`` body. Only keys in ``SECTION_WHITELIST`` pass
   through; whitelisted sections are emitted verbatim (no recursion).
2. **Connection-field whitelist** — applied inside any ``connections`` dict
   (top-level or per-profile). Only fields in ``CONNECTION_FIELD_WHITELIST``
   pass through.
"""

from __future__ import annotations

from typing import Any

import yaml

REDACTED = "<redacted>"

# Keys allowed at the YAML root and inside each `profile.<name>` body
# (profiles can override any of these sections).
SECTION_WHITELIST: frozenset[str] = frozenset({
    "active_profile",
    "default_connection",
    "profile",
    "connections",
    "install_mode",
    "compiler",
    "data",
    "debug",
    "execution",
    "model",
    "reasoners",
    "schedule",
    "tables",
})

CONNECTION_FIELD_WHITELIST: frozenset[str] = frozenset({
    "type", "authenticator",
    # snowflake
    "account", "warehouse", "rai_app_name",
    "role", "database", "schema", "user",
    # duckdb
    "path", "read_only",
})


def _walk_connection_body(body: Any) -> Any:
    """Apply the connection-field whitelist to a single connection body."""
    if not isinstance(body, dict):
        return body
    return {
        k: (body[k] if str(k) in CONNECTION_FIELD_WHITELIST else REDACTED)
        for k in body
    }


def _walk_section_dict(node: Any) -> Any:
    """Apply the section whitelist to a root-or-profile dict.

    `connections` gets the connection-field whitelist; `profile` recurses
    each profile body through this same function; other whitelisted sections
    pass through verbatim; non-whitelisted keys → value redacted.
    """
    if not isinstance(node, dict):
        return node
    out: dict[Any, Any] = {}
    for k, v in node.items():
        key = str(k)
        if key not in SECTION_WHITELIST:
            out[k] = REDACTED
        elif key == "connections" and isinstance(v, dict):
            out[k] = {conn: _walk_connection_body(body) for conn, body in v.items()}
        elif key == "profile" and isinstance(v, dict):
            out[k] = {p: _walk_section_dict(body) for p, body in v.items()}
        else:
            out[k] = v
    return out


def sanitize_raiconfig(yaml_text: str) -> str:
    """Take YAML source text and return a sanitized version with secrets redacted.

    Note: comments and formatting are not preserved (standard `yaml` round-trip).
    Acceptable for a debug artifact.
    """
    data = yaml.safe_load(yaml_text)
    if data is None:
        return yaml_text  # empty file — nothing to do
    sanitized = _walk_section_dict(data)
    return yaml.safe_dump(sanitized, default_flow_style=False, sort_keys=False)
