"""CLI runtime: shared state and lifecycle helpers for every Click command.

This module is the single source of truth for:

- the shared Rich :class:`~rich.console.Console` (``console``, rebuilt by ``configure_console``)
- the :class:`CliRuntime` context object attached to ``ctx.obj`` (``--json``, ``--no-color``, config, interactivity)
- ``load_config`` (thin wrapper over ``create_config`` with friendlier errors)
- ``raise_missing_config_discovery_error`` (parity with ``load_config`` discovery failure when a command bypasses it)
- ``cli_connect_sync`` (context manager that also plumbs execution diagnostics)
- ``is_interactive`` / ``cli_wants_json`` / ``emit_cli_json`` (small context-aware helpers)

Commands in ``commands/*.py`` import this module by name and look helpers up at
runtime (``from relationalai.tools.cli import runtime`` → ``runtime.load_config()``).
That way tests can monkeypatch ``relationalai.tools.cli.runtime.load_config`` once
and affect every command without hunting for import-time rebindings.
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import sys
import warnings
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, NoReturn, TypeVar, cast

import click
from rich.console import Console

from .cli_output_prefs import cli_requests_no_color, set_cli_no_color
from .execution_diagnostics import (
    BufferedExecutionLogHandler,
    disable_execution_logging_buffer,
    enable_execution_logging_buffer,
    flush_execution_logging_buffer,
    print_execution_metrics_if_enabled,
)

if TYPE_CHECKING:
    from relationalai.client.client_sync import ClientSync
    from relationalai.config.config import Config

T = TypeVar("T")
OutputFormat = Literal["table", "json", "yaml"]


def normalize_output_format(value: str) -> OutputFormat:
    """Fold ``yml`` into ``yaml`` and accept only known modes.

    Single source of truth for the ``--output`` alias rules. Used by:

    * ``cli()`` body (authoritative path after Click's option parser).
    * ``RaiGroup.parse_args`` priming (eager scan of raw args before
      Click parses, so ``--version`` and other eager callbacks see the
      same effective format).

    Unknown / empty values degrade to ``"table"`` (the human default);
    Click's ``click.Choice`` already rejects unknown literals at the
    parse layer, so this fallback only matters for the eager priming
    path that doesn't have type validation yet.
    """
    v = (value or "").strip().lower()
    if v == "yml":
        v = "yaml"
    if v in ("table", "json", "yaml"):
        return cast(OutputFormat, v)
    return "table"


def resolve_output_format(
    *,
    json_output: bool,
    yaml_output: bool,
    output_format: str,
) -> OutputFormat:
    """Apply the ``--json`` / ``--yaml`` / ``--output`` interaction rules.

    Authoritative — call from ``cli()`` after Click has parsed the
    options. Raises :class:`click.UsageError` on the two conflict cases:
    ``--json`` *and* ``--yaml`` together, or a shortcut flag combined
    with a contradicting ``--output`` value. The priming path in
    ``_group.RaiGroup.parse_args`` does a relaxed version of this same
    walk so eager callbacks aren't surprised; that path can't raise
    UsageError (the user's intent might still be salvageable post-parse)
    so it short-circuits on ``--json`` over ``--yaml`` and otherwise
    delegates to :func:`normalize_output_format`.
    """
    normalized = normalize_output_format(output_format)
    if json_output and yaml_output:
        raise click.UsageError("Use only one of --json or --yaml.")
    if json_output:
        if normalized not in ("table", "json"):
            raise click.UsageError("Use either --json or --output, not both.")
        return "json"
    if yaml_output:
        if normalized not in ("table", "yaml"):
            raise click.UsageError("Use either --yaml or --output, not both.")
        return "yaml"
    return normalized


def resolve_no_color(*, flag: bool) -> bool:
    """Combine the ``--no-color`` flag with the ``NO_COLOR`` env contract.

    Per https://no-color.org/, any non-empty ``NO_COLOR`` value disables
    color; the explicit ``--no-color`` flag also wins. Both pre-parse
    priming and the post-parse ``cli()`` body call through here so the
    env-var contract is honored consistently.
    """
    return bool(flag) or os.environ.get("NO_COLOR", "").strip() != ""


# ── Shared Rich console ──────────────────────────────────────────────────────

console: Console = Console()
# Separate stderr console for *advisory* output (tips, pagination footers,
# deprecation notices, post-action guidance). Routing advisory content to
# stderr keeps stdout strictly reserved for the command's primary payload —
# scripts piping through ``jq`` / ``yq`` / ``grep`` then never have to
# filter our tips out. Both consoles share ``no_color`` state via
# :func:`configure_console`.
stderr_console: Console = Console(stderr=True)


def configure_console(*, no_color: bool) -> None:
    """Rebuild the module-level Rich :class:`Console` after parsing ``--no-color``."""
    set_cli_no_color(no_color)
    global console, stderr_console
    console = Console(no_color=no_color)
    stderr_console = Console(stderr=True, no_color=no_color)


def print_advisory(message: str, *, style: str | None = None) -> None:
    """Print a tip / footer / notice to stderr (never stdout).

    Use for content that's helpful context but isn't the command's
    primary payload (paging footers, "Tip:" lines, post-action guidance).
    Anything piped through ``jq`` / ``yq`` then ignores it for free.
    Honors the global ``--no-color`` via :data:`stderr_console`.
    """
    if style:
        stderr_console.print(message, style=style)
    else:
        stderr_console.print(message)


def print_advisory_panel(panel: Any, *, leading_blank: bool = False) -> None:
    """Render a Rich :class:`~rich.panel.Panel` to stderr with the canonical
    "advisory" chrome (no-color honoured, no Rich highlighting).

    Centralizes the construction that previously appeared verbatim in
    four places (config-load error, deprecated-TOML notice,
    update-available notice, deprecated-colon-alias notice). Build a
    fresh ``Console`` per call so it keeps its independence from the
    cached :data:`stderr_console` (some callers — namely
    :class:`_ConfigLoadError.show` — accept an arbitrary ``file`` from
    Click and need a one-shot console for that file). Each call site
    now collapses to ``runtime.print_advisory_panel(panel,
    leading_blank=...)`` and the no-color contract stays consistent.

    ``leading_blank=True`` prints an empty line before the panel; use
    when the panel should detach from preceding output (e.g. the
    update-available notice that runs at exit, the deprecated-TOML
    notice that runs after ``rai`` has already printed its banner).
    Leave default for panels that are the first thing on screen
    (e.g. the colon-alias hint emitted before the canonical command).
    """
    console = Console(stderr=True, no_color=cli_requests_no_color(), highlight=False)
    if leading_blank:
        console.print()
    console.print(panel)


def color_enabled(ctx: click.Context | None = None) -> bool:
    """``True`` when the current context should render Rich color cues.

    Combines two gates: the per-invocation ``--no-color`` flag (carried
    on :class:`CliRuntime`) and Click's own ``ctx.color`` attribute
    (which the ``parse_args`` priming sets to ``False`` whenever
    ``NO_COLOR`` or ``--no-color`` was active before any command runs).
    Centralizes the previously-repeated three-line expression at
    :class:`RaiSubGroup.format_commands`, :class:`RaiGroup.format_help_text`,
    and ``commands/tree.py``.
    """
    if ctx is None:
        ctx = click.get_current_context(silent=True)
    rt = get_runtime(ctx)
    return (not rt.no_color) and getattr(ctx, "color", None) is not False


# ── CliRuntime (attached to ``ctx.obj``) ─────────────────────────────────────


@dataclass
class CliRuntime:
    """Per-invocation runtime state, stored on ``click.Context.obj``.

    Commands should accept this via ``@click.pass_obj`` (or read it from
    ``click.get_current_context().obj``). It carries global flag values and
    the slots used by :func:`flush_diagnostics_on_close`.
    """

    json_output: bool = False
    output_format: OutputFormat = "table"
    no_color: bool = False
    profile: str | None = None
    diag_flush_registered: bool = False
    execution_diag_config: "Config | None" = None
    execution_log_handler: BufferedExecutionLogHandler | None = None
    execution_metrics: Any | None = None


def get_runtime(ctx: click.Context | None = None) -> CliRuntime:
    """Return the current :class:`CliRuntime`, creating one if necessary."""
    if ctx is None:
        ctx = click.get_current_context(silent=True)
    if ctx is None:
        # No Click context (unit tests); return a throwaway runtime.
        return CliRuntime()

    obj = ctx.ensure_object(dict) if not isinstance(ctx.obj, CliRuntime) else ctx.obj
    if isinstance(obj, CliRuntime):
        return obj

    # Legacy dict-based ctx.obj (older tests/wiring) — migrate values in place.
    legacy_json_output = bool(obj.get("json_output", False))
    output_format = obj.get("output_format")
    if output_format not in ("table", "json", "yaml"):
        output_format = "json" if legacy_json_output else "table"
    rt = CliRuntime(
        json_output=output_format == "json",
        output_format=cast(OutputFormat, output_format),
        no_color=bool(obj.get("no_color", False)),
        profile=obj.get("profile"),
        diag_flush_registered=bool(obj.get("_execution_diag_on_close_registered", False)),
        execution_diag_config=obj.get("_execution_diag_config"),
        execution_log_handler=obj.get("_execution_log_handler"),
        execution_metrics=obj.get("_execution_metrics"),
    )
    ctx.obj = rt
    return rt


# ── Small context-aware helpers ──────────────────────────────────────────────


def cli_wants_json() -> bool:
    """True when the current command was run with ``--json`` / ``--output json``.

    **Discouraged**: most call sites should use :func:`cli_wants_machine_output`
    instead. The two diverge only on ``--output yaml``: gating spinners or
    Rich panels on ``cli_wants_json`` lets the spinner ANSI bleed into
    YAML output. Reach for this helper only when the JSON encoder is
    being invoked directly (e.g. distinguishing JSON-string formatting
    from YAML-mapping serialization); for everything else (panels,
    spinners, live status, output suppression), prefer
    :func:`cli_wants_machine_output`.

    A unit test (``tests/unit/cli/test_cli_wants_json_audit.py``) enforces
    that no new in-tree call site outside this module reaches for it —
    add to the allowlist there only if you can articulate why JSON-only
    semantics are correct for the call site.
    """
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return False
    rt = get_runtime(ctx)
    return rt.output_format == "json" or rt.json_output


def cli_wants_machine_output() -> bool:
    """True when the current command should emit a machine-readable format.

    Covers both ``--json`` / ``--output json`` and ``--output yaml``.
    Prefer this over :func:`cli_wants_json` for all gating logic
    (panels, spinners, live status, suppression of human-only output).
    """
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return False
    rt = get_runtime(ctx)
    return rt.output_format in ("json", "yaml") or rt.json_output


def _json_default(obj: Any) -> Any:
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, timedelta):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _json_default_lenient(obj: Any) -> Any:
    """Like :func:`_json_default` but falls back to ``str(obj)`` for unknown
    types instead of raising.

    Used for CLI output that can carry arbitrary structured payloads from
    backend services (e.g. ``jobs events``), where a never-before-seen type
    in a value should still print rather than crash the command.
    """
    try:
        return _json_default(obj)
    except TypeError:
        return str(obj)


def emit_cli_json(data: Any, *, lenient: bool = False) -> None:
    """Print JSON to stdout (no Rich markup).

    With ``lenient=True``, unknown types (e.g. ``Decimal`` or service-layer
    objects without a JSON encoder) fall back to ``str(obj)`` rather than
    raising. Use lenient mode for outputs that can carry arbitrary
    backend-supplied payloads; leave it off for outputs whose schema we
    control so any type drift surfaces loudly.
    """
    default = _json_default_lenient if lenient else _json_default
    click.echo(json.dumps(data, indent=2, default=default))


def _to_jsonable(data: Any, *, lenient: bool) -> Any:
    """Normalize data through the JSON encoder so YAML uses the same scalar policy."""
    default = _json_default_lenient if lenient else _json_default
    return json.loads(json.dumps(data, default=default))


def emit_cli_result(
    json_key: str,
    payload: Any,
    *,
    lenient: bool = False,
) -> bool:
    """Emit ``{json_key: payload}`` if machine output is active.

    Replaces the recurring three-liner:

    .. code-block:: python

        if runtime.cli_wants_machine_output():
            runtime.emit_cli_output({"job": job_record_as_json(job)})
            return
        show_job(job)

    with:

    .. code-block:: python

        if runtime.emit_cli_result("job", job_record_as_json(job)):
            return
        show_job(job)

    Returns True when output was emitted (caller should ``return``);
    False when the caller should fall through to its human-render path.

    The single-call envelope guarantees every machine-readable single
    record across the CLI uses the same ``{key: payload}`` shape — list
    commands have ``render_list`` for that contract; detail / status /
    operation commands now have this helper as their dual.
    """
    if not cli_wants_machine_output():
        return False
    emit_cli_output({json_key: payload}, lenient=lenient)
    return True


def emit_cli_output(data: Any, *, lenient: bool = False) -> None:
    """Print data in the currently selected machine-readable output format.

    Branches on ``rt.output_format`` directly rather than going through
    :func:`cli_wants_json`: the YAML path is identified by
    ``output_format == "yaml"`` immediately below, and the JSON path is
    everything else under :func:`cli_wants_machine_output`.
    """
    ctx = click.get_current_context(silent=True)
    rt = get_runtime(ctx) if ctx is not None else CliRuntime()

    if rt.output_format == "yaml":
        import yaml

        click.echo(yaml.safe_dump(_to_jsonable(data, lenient=lenient), sort_keys=False).rstrip("\n"))
        return

    if rt.output_format == "json" or rt.json_output:
        emit_cli_json(data, lenient=lenient)
        return

    # Defensive guard: callers should only reach this helper after
    # `cli_wants_machine_output()` has selected JSON or YAML.
    raise click.ClickException("No machine-readable output format is active.")


def is_interactive() -> bool:
    """Return True when CLI can prompt interactively (stdin is a TTY).

    Defensive against stdin being replaced by something that doesn't
    quack like a stream (embedded runtimes, captured subprocesses): the
    ``isatty`` attribute is looked up dynamically and a missing/broken
    implementation degrades to "not interactive" rather than raising.
    """
    return stream_is_tty(sys.stdin)


def stream_is_tty(stream: object) -> bool:
    """True when ``stream.isatty()`` exists, is callable, and returns truthy.

    Centralizes the ``getattr(stream, "isatty", lambda: False)()`` pattern
    that previously appeared in ~four places, each with slightly different
    error handling. Narrows the return type to ``bool`` (previous form was
    inferred as ``Any`` by pyright because of the dynamic getattr).
    """
    try:
        isatty = getattr(stream, "isatty", None)
        if not callable(isatty):
            return False
        return bool(isatty())
    except Exception:
        return False


# ── Config + client lifecycle ────────────────────────────────────────────────


def _summarize_config_error(error: Exception) -> tuple[str, str | None]:
    """Decompose a config-load failure into ``(headline, location)``.

    Drops the multi-section "Attempted Sources" / "Validation errors"
    boilerplate from ``ConfigError.__str__``. Validation errors strip
    pydantic's ``Value error, `` decorator prefix (noise, not signal).
    Non-``ConfigError`` exceptions fall back to the first stripped
    line of ``str(error)``.
    """
    from relationalai.config.errors.exceptions import (
        ConfigError,
        ConfigValidationError,
    )

    if isinstance(error, ConfigValidationError):
        pyd_errors = error.pydantic_errors or []
        first_pyd = pyd_errors[0] if pyd_errors else None
        detail = (
            first_pyd.get("msg", "") if isinstance(first_pyd, dict) else ""
        )
        detail = detail.removeprefix("Value error, ").strip()
        headline = detail or error.message
        ctx = error.context
        location = ctx.format_location() if ctx is not None else None
        return headline, location

    if isinstance(error, ConfigError):
        return error.message, None

    first = (str(error).splitlines()[0] if str(error) else "").strip()
    return (first or "config could not be loaded"), None


class _ConfigLoadError(click.ClickException):
    """``ClickException`` whose ``show()`` paints the universal
    "No usable config" Rich panel on stderr instead of Click's default
    ``Error: <msg>``. The plain ``message`` is preserved as a fallback
    for non-Rich code paths (closed stderr, ``--no-color`` introspection,
    tests). Exit code is the standard ``ClickException`` value.
    """

    def __init__(self, headline: str, location: str | None) -> None:
        plain = headline
        if location:
            plain += f" ({location})"
        plain += "\n  Run `rai init` to create one."
        super().__init__(plain)
        self.headline = headline
        self.location = location

    def show(self, file: Any = None) -> None:
        from rich.panel import Panel
        from rich.text import Text

        body = Text()
        body.append(self.headline + "\n", style="white")
        if self.location:
            body.append(self.location + "\n", style="dim")
        body.append("\n")
        body.append("Run ", style="dim")
        body.append("rai init", style="bold cyan")
        body.append(" to create one.", style="dim")

        panel = Panel(
            body,
            title="[bold red]No usable config[/bold red]",
            title_align="left",
            border_style="red",
            padding=(0, 2),
        )

        # Click hands ``show`` an arbitrary ``file`` (defaults to
        # ``sys.stderr``); when it does, route through a one-shot console
        # bound to that file so test harnesses / wrapper scripts can
        # capture the panel. Otherwise share the canonical advisory
        # console so the no-color contract stays uniform.
        if file is not None:
            Console(file=file, no_color=cli_requests_no_color(), highlight=False).print(panel)
        else:
            print_advisory_panel(panel)


def raise_missing_config_discovery_error() -> NoReturn:
    """Raise the same UX as :func:`load_config` when no config file exists.

    For helpers that bypass ``create_config`` (such as YAML-only walks) but
    should surface the universal "No usable config" advisory panel consumers
    get from commands that call :func:`load_config` (including ``rai whoami``).
    """
    from relationalai.config.errors.exceptions import ConfigFileNotFoundError

    error = ConfigFileNotFoundError(
        message="No config file found in any expected location.",
        attempted_sources=[],
    )
    headline, location = _summarize_config_error(error)
    raise _ConfigLoadError(headline, location)


def resolved_config_path(config: "Config", *, resolve: bool = False) -> str | None:
    """Absolute path the config was loaded from, or ``None``.

    Read via ``vars(...)`` because ``_resolved_config_file`` is a
    pydantic-private slot (the config-usage lint forbids ``getattr`` on
    ``Config``). Degrades to ``None`` for stand-ins without ``__dict__``.

    With ``resolve=True``, the returned path is expanded
    (``~`` resolved) and made absolute via :meth:`Path.resolve`. That
    pass can raise on permission errors (no read on a parent dir),
    on broken symlinks pre-3.10's strict mode, and on Windows for
    paths exceeding ``MAX_PATH`` without long-path support; we fall
    back to the raw string in that case rather than failing the
    caller over a cosmetic provenance line.
    """
    try:
        resolved = vars(config).get("_resolved_config_file")
    except TypeError:
        return None
    if resolved is None:
        return None
    raw = str(resolved)
    if not resolve:
        return raw
    try:
        return str(Path(raw).expanduser().resolve())
    except Exception:
        return raw


def _render_deprecated_toml_panel(path: str) -> None:
    """Yellow-bordered Rich panel nudging users from ``raiconfig.toml``
    to ``rai init``. Mirrors
    :func:`relationalai.tools.cli.update_check.render_upgrade_panel`
    so the two "nudge" notices look like siblings. Goes through
    :func:`print_advisory_panel` so the no-color / stderr contract
    stays consistent across every advisory surface.
    """
    from rich.panel import Panel

    body = (
        f"[bold]{path}[/bold] is deprecated.\n"
        f"Migrate with: [bold cyan]rai init[/bold cyan]"
    )
    panel = Panel(
        body,
        title="[bold yellow]Deprecated config[/bold yellow]",
        title_align="left",
        border_style="yellow",
        padding=(1, 2),
    )
    print_advisory_panel(panel, leading_blank=True)


def load_config() -> "Config":
    """``create_config()`` wrapper with a CLI-friendly error surface.

    Adds three behaviours on top of ``create_config``:

    1. Captures stderr around the call to swallow the eager Rich panel
       :func:`~relationalai.config.errors.utils.print_and_raise` writes
       on TTYs *before* re-raising; on success the buffer is replayed
       so benign warnings still surface.
    2. On failure, raises :class:`_ConfigLoadError` with a compressed
       ``(headline, location)`` summary so every command shows the same
       "No usable config" panel.
    3. On success, if the resolved file is the deprecated
       ``raiconfig.toml``, emits a styled Rich deprecation panel
       (the library-level warning is silenced inside this wrapper
       only — non-CLI consumers keep the original warning).
    """
    try:
        from relationalai.config import create_config
        from relationalai.util.error import RAIWarning
    except ModuleNotFoundError as e:
        raise click.ClickException(
            "Failed to load config. Ensure optional config dependencies are installed "
            "(e.g. `pydantic-settings`) and that your configuration is valid."
        ) from e

    rt = get_runtime()
    buf = io.StringIO()
    try:
        with (
            contextlib.redirect_stderr(buf),
            warnings.catch_warnings(),
        ):
            # Silence the plain ``[DeprecatedConfig] raiconfig.toml …``
            # warning; we render a styled panel for it below.
            warnings.filterwarnings(
                "ignore",
                message=r"\[DeprecatedConfig\] raiconfig\.toml is deprecated.*",
                category=RAIWarning,
            )
            if rt.profile:
                config = create_config(active_profile=rt.profile)
            else:
                config = create_config()
    except Exception as e:
        headline, location = _summarize_config_error(e)
        raise _ConfigLoadError(headline, location) from e
    sys.stderr.write(buf.getvalue())

    resolved = resolved_config_path(config)
    # Match by basename (not ``endswith``) so ``foo/myraiconfig.toml``
    # does NOT false-trigger, and Snowflake's ``~/.snowflake/config.toml``
    # — a *different* TOML, not the deprecated raiconfig — stays silent.
    if resolved is not None and Path(resolved).name == "raiconfig.toml":
        _render_deprecated_toml_panel(resolved)

    return config


@contextmanager
def cli_connect_sync(config: "Config") -> Iterator["ClientSync"]:
    """Connect a sync client and plumb execution diagnostics through ``ctx.obj``.

    The connect step is wrapped in a spinner so the user gets immediate
    feedback on cold paths (first invocation after a long idle, token
    refresh, slow network). Without it the terminal sits silent for
    multiple seconds with no UI affordance, and users (justifiably)
    assume the command froze. The spinner cleanly tears down before any
    downstream code (interactive prompts, table rendering) runs.

    Skipped under ``--json`` so machine-readable output never has the
    spinner's animation lines bleed into stdout/stderr capture.
    """
    from relationalai.client import connect_sync
    from .components import WaitSpinner

    handler = enable_execution_logging_buffer(config)
    ctx = click.get_current_context(silent=True)
    rt = get_runtime(ctx) if ctx is not None else None
    if rt is not None:
        if handler is not None:
            rt.execution_log_handler = handler
        rt.execution_diag_config = config

    # ``cli_wants_machine_output()`` already covers both ``--json`` /
    # ``--output json`` and ``--output yaml``; the prior local
    # re-derivation (``rt.output_format != "table" or rt.json_output``)
    # was a literal hand-rolled clone of that helper. Going through the
    # canonical helper means a future "machine output" mode (e.g. NDJSON,
    # protobuf) automatically suppresses the spinner without needing to
    # update this site too.
    if cli_wants_machine_output():
        cm = connect_sync(config=config)
        client = cm.__enter__()
    else:
        with WaitSpinner("Connecting...", show_after_ms=0):
            cm = connect_sync(config=config)
            client = cm.__enter__()

    try:
        yield client
    finally:
        if rt is not None:
            rt.execution_metrics = getattr(client, "execution_metrics", None)
        # Drive the underlying ``connect_sync`` contextmanager's cleanup
        # ourselves (we held it open across yield to keep its semantics
        # identical to the previous ``with connect_sync(...) as client``).
        # We log-and-continue on close failure rather than let a
        # transport/cleanup error mask whatever the command was actually
        # trying to do, but we *do* surface the failure at debug level so
        # it's recoverable when investigating resource leaks.
        try:
            cm.__exit__(None, None, None)
        except Exception:
            import logging

            logging.getLogger(__name__).debug(
                "cli_connect_sync: client close raised", exc_info=True
            )


def cli_preamble() -> tuple["Config", bool]:
    """Run the connect-free portion of the standard CLI preamble.

    Returns ``(config, interactive)`` — load the active profile, then
    sample ``stdin.isatty()``. Use this for commands that need the
    config object but *do not* want to open a backend connection
    (``rai version``, ``rai diagnose`` partial paths, ``rai config env`` once
    landed). :func:`cli_session` is then the trivial composition that
    layers :func:`cli_connect_sync` on top.

    Splitting these out makes the dependency surface explicit: a
    "no-connect" command no longer carries the cli_session signature
    that says "I want a client" only to immediately throw it away.
    """
    return load_config(), is_interactive()


@contextmanager
def cli_session() -> Iterator[tuple["Config", bool, "ClientSync"]]:
    """Bundle the standard CLI command preamble: load config + interactivity + connect.

    Yields ``(config, interactive, client)``. Use this for commands whose only
    pre-connect work is ``load_config()`` and ``is_interactive()``; commands
    that validate user input *before* opening a connection (e.g. ``jobs list``)
    should keep using :func:`load_config` + :func:`cli_connect_sync` directly so
    bad arguments fail fast without touching the network.

    Exception behavior: this helper does no exception translation of its own.
    Errors raised by :func:`load_config` (bad/missing ``raiconfig.yaml``) and
    :func:`is_interactive` propagate *before* the connection is opened, so the
    standard ``handle_cli_errors`` decorator on each command sees them and
    renders the right diagnostic. Errors raised inside the ``cli_connect_sync``
    context follow that helper's own behavior — connection cleanup is handled
    by ``cli_connect_sync``, not by this wrapper.
    """
    config, interactive = cli_preamble()
    with cli_connect_sync(config) as client:
        yield config, interactive, client


# ── Spinner-wrapped call ─────────────────────────────────────────────────────


def run_with_spinner(message: str, fn: Callable[[], T]) -> T:
    """Run ``fn()`` under a :class:`WaitSpinner` and return its result.

    Eliminates the ``x: Any = None; with WaitSpinner(...): x = fn()`` dance
    that otherwise confuses type checkers about post-block bindings.

    Skip the spinner entirely under any machine-readable output
    (``--json`` *and* ``--output yaml``); pre-fix this used
    :func:`cli_wants_json` only, so YAML consumers still saw spinner
    escape codes leak into their stderr/stdout capture.
    """
    if cli_wants_machine_output():
        return fn()

    from .components import WaitSpinner

    with WaitSpinner(message):
        return fn()


def run_wait_with_guidance(
    fn: Callable[[], T],
    *,
    interrupted_message: str,
    timeout_message: str,
    timeout_exceptions: tuple[type[BaseException], ...],
) -> T:
    """Run a wait operation and replace common wait exits with actionable text.

    Wait flows drive their own live status indicator (see
    :mod:`long_running`); a wrapping spinner here would nest two live regions
    and never paint the inner one. This helper therefore only handles
    exception translation (``KeyboardInterrupt`` / configured
    ``timeout_exceptions`` → :class:`click.ClickException` with actionable
    body text). If you need a spinner around a non-wait call, use
    :func:`run_with_spinner` directly.
    """
    try:
        return fn()
    except KeyboardInterrupt as e:
        raise click.ClickException(interrupted_message) from e
    except Exception as e:
        if isinstance(e, timeout_exceptions):
            raise click.ClickException(timeout_message) from e
        raise


def flush_diagnostics_on_close(ctx: click.Context) -> None:
    """Register a one-shot ``call_on_close`` that flushes execution diagnostics.

    Idempotent: multiple invocations within the same context only register once.
    """
    rt = get_runtime(ctx)
    if rt.diag_flush_registered:
        return
    rt.diag_flush_registered = True

    def _flush() -> None:
        cfg = rt.execution_diag_config
        handler = rt.execution_log_handler

        flush_execution_logging_buffer(handler, cfg=cfg)
        disable_execution_logging_buffer(handler)

        if cfg is not None:
            print_execution_metrics_if_enabled(cfg, rt.execution_metrics)

        rt.execution_log_handler = None
        rt.execution_metrics = None
        rt.execution_diag_config = None

    ctx.call_on_close(_flush)
