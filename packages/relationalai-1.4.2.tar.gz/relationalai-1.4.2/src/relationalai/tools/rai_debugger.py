import argparse
import os
import re
from datetime import datetime, timezone
from typing import Any
from pathlib import Path
try:
    from nicegui import ui
except ImportError:
    raise ImportError("nicegui is required for the debugger. Install it with: pip install relationalai[debugger]")
import json
import time
import sys

from relationalai.observability.run_paths import spans_path
from relationalai.util.fs import get_build_dir

# --------------------------------------------------
# Get version from pyproject.toml
# --------------------------------------------------


def get_version():
    """Read version from pyproject.toml"""
    if sys.version_info >= (3, 11):
        import tomllib  # py311+
    else:
        import tomli as tomllib  # type: ignore
    try:
        pyproject_path = os.path.join(os.path.dirname(__file__), "..", "..", "..", "pyproject.toml")
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
            return data.get("project", {}).get("version", "unknown")
    except Exception:
        return "unknown"


VERSION = get_version()

# --------------------------------------------------
# Theme & Design System
# --------------------------------------------------

THEME = {
    # Backgrounds
    "bg_main": "#1a1b26",
    "bg_elevated": "#24283b",
    "bg_surface": "#414868",
    "bg_hover": "#545c7e",
    "bg_code": "#1f2335",
    # Text
    "text_primary": "#c0caf5",
    "text_secondary": "#9aa5ce",
    "text_tertiary": "#565f89",
    "text_muted": "#787c99",
    # Accents
    "accent_primary": "#7aa2f7",
    "accent_secondary": "#bb9af7",
    "accent_rule": "#9ece6a",
    "accent_query": "#7dcfff",
    "accent_compile": "#ff9e64",
    "accent_passes": "#bb9af7",
    # Status
    "success": "#9ece6a",
    "warning": "#e0af68",
    "error": "#f7768e",
    # Borders
    "border": "#3b4261",
    "border_light": "#545c7e",
}

THEME_LIGHT = {
    # Backgrounds - Light and airy
    "bg_main": "#f9fafb",           # Very light gray (almost white)
    "bg_elevated": "#ffffff",        # Pure white for elevated surfaces
    "bg_surface": "#e5e7eb",         # Light gray for surfaces
    "bg_hover": "#d1d5db",           # Medium-light gray for hover
    "bg_code": "#f3f4f6",            # Slightly off-white for code blocks

    # Text - Dark for readability
    "text_primary": "#1f2937",       # Near black
    "text_secondary": "#4b5563",     # Dark gray
    "text_tertiary": "#9ca3af",      # Medium gray
    "text_muted": "#6b7280",         # Muted gray

    # Accents - Vibrant colors
    "accent_primary": "#2563eb",     # Bright blue
    "accent_secondary": "#7c3aed",   # Purple
    "accent_rule": "#16a34a",        # Green
    "accent_query": "#0891b2",       # Cyan
    "accent_compile": "#ea580c",     # Orange
    "accent_passes": "#9333ea",      # Violet

    # Status
    "success": "#16a34a",            # Green
    "warning": "#d97706",            # Amber
    "error": "#dc2626",              # Red

    # Borders
    "border": "#d1d5db",             # Light gray
    "border_light": "#e5e7eb",       # Very light gray
}


def get_timing_color(elapsed):
    """Return color based on timing thresholds"""
    if elapsed is None:
        return THEME["text_muted"]
    if elapsed < 0.01:  # < 10ms
        return THEME["success"]
    elif elapsed < 0.1:  # < 100ms
        return THEME["warning"]
    else:
        return THEME["error"]


def get_span_icon(span_type):
    """Return emoji icon for span type"""
    icons = {
        "install": "⚡",
        "model": "⚡",
        "query": "🔍",
        "compile": "⚙️",
        "passes": "🔄",
        "v1": "1️⃣",
        "v1_v0": "🔀",
        "create_v2": "🚀",
    }
    return icons.get(span_type, "")


# Span types that get a top-level entry in the left sidebar. v1 nests these
# under a `program` span, so _find_sidebar_items walks the tree to find them
# at any depth. Compile-only dry-runs share the "query" type and are
# distinguished from real queries via the ``operation`` attribute
# ("prepare" vs absent) — see the sidebar label logic.
SIDEBAR_SPAN_TYPES = ("install", "query", "model")


def get_span_color(span_type):
    """Return accent color for span type"""
    colors = {
        "install": THEME["accent_query"],
        "query": THEME["accent_query"],
        "compile": THEME["accent_compile"],
        "passes": THEME["accent_passes"],
        "v1": THEME["accent_secondary"],
        "v1_v0": THEME["accent_primary"],
        "model": THEME["accent_query"],
    }
    return colors.get(span_type, THEME["accent_primary"])


# --------------------------------------------------
# Debug log helpers
# --------------------------------------------------

def _resolve_primary_path(explicit: Path | None) -> Path:
    """Where the debugger reads its primary trace from.

    Resolution order:
      1. ``--file <path>`` if given.
      2. else: latest run dir's ``spans.jsonl``, via
         :func:`run_paths.spans_path` — install dir preferred, falls
         back to the latest query dir for non-install-mode users
         (legacy LQP, dry-run-only sessions) whose ``start_run("query")``
         created a ``_query_`` typed dir.
      3. else: flat ``build/spans.jsonl`` — the Tracer's default
         ``out_path``. Pre-``start_run`` runs or backends that never
         redirected the tracer land here.
      4. else: legacy ``build/debug.jsonl`` (kept working as
         transitional support via the v0 back-compat layer).
    """
    if explicit is not None:
        return explicit
    p = spans_path(None)
    if p is not None and p.exists():
        return p
    flat_spans = get_build_dir() / "spans.jsonl"
    if flat_spans.exists():
        return flat_spans
    return get_build_dir() / "debug.jsonl"


# Set in `main()` once args are parsed.
DEBUG_LOG_PATH: Path | None = None
# Captures whether the user passed `--file` explicitly. When None, `poll()`
# re-resolves the latest install run on each tick so newer installs are
# picked up live; when set, the explicit path is honored and never swapped.
_EXPLICIT_FILE: Path | None = None


class SpanNode:
    def __init__(self, id, type, parent_id, start_timestamp, attrs=None):
        self.id = id
        self.type = type
        self.parent_id = parent_id
        self.start_timestamp = start_timestamp
        self.end_timestamp = None
        self.elapsed = None
        self.start_attrs = attrs or {}
        self.end_attrs = {}
        self.children = []

    def add_end_data(self, end_timestamp, elapsed, end_attrs=None):
        self.end_timestamp = end_timestamp
        self.elapsed = elapsed
        if end_attrs:
            # Merge end_attrs into attrs
            self.end_attrs.update(end_attrs)

    def add_child(self, child):
        self.children.append(child)

    def __str__(self, level=0):
        indent = "  " * level
        result = f"{indent}{self.type} ({self.id}):\n"
        result += f"{indent}  elapsed: {self.elapsed:.6f}s\n"

        if self.start_attrs or self.end_attrs:
            result += f"{indent}  start attributes:\n"
            for key, value in self.start_attrs.items():
                # Truncate long values for display
                if isinstance(value, str) and len(value) > 100:
                    value = value[:97] + "..."
                result += f"{indent}    {key}: {value}\n"
            result += f"{indent}  end attributes:\n"
            for key, value in self.end_attrs.items():
                # Truncate long values for display
                if isinstance(value, str) and len(value) > 100:
                    value = value[:97] + "..."
                result += f"{indent}    {key}: {value}\n"

        if self.children:
            result += f"{indent}  children:\n"
            for child in self.children:
                result += child.__str__(level + 2)

        return result


def find_span_by_id(spans, target_id):
    """Recursively search for a span by ID in a tree of spans"""
    for span in spans:
        if span.id == target_id:
            return span
        # Search in children
        if span.children:
            result = find_span_by_id(span.children, target_id)
            if result:
                return result
    return None


def find_txn_id(span: SpanNode) -> str | None:
    """Find txn_id from a create_v2 descendant."""
    if span.type == "create_v2":
        return span.end_attrs.get("txn_id")
    for child in span.children:
        result = find_txn_id(child)
        if result:
            return result
    return None


def parse_jsonl_to_tree(jsonl_content):
    """Parse JSONL content into a tree structure.

    Auto-detects v0 (``{"event": "span_start"|"span_end", ...}``) vs v1
    OTEL (``{"span_id": "...", ...}``) based on the first parseable record.
    """
    if not jsonl_content:
        return [], {}
    lines = jsonl_content.strip().split("\n")
    if _detect_format(lines) == "v1":
        return _parse_v1(lines)
    return _parse_v0(lines)


def _detect_format(lines):
    for line in lines:
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "event" in data:
            return "v0"
        if "span_id" in data:
            return "v1"
    return "v0"  # empty or unparseable → fall through to v0


def _parse_v0(lines):
    """Parse v0-shape records — paired ``span_start`` + ``span_end``."""
    nodes_by_id = {}
    root_nodes = []

    for line in lines:
        if not line:
            continue
        data = json.loads(line)
        event_type = data["event"]

        if event_type == "span_start":
            span = data["span"]
            if not isinstance(span, dict):
                continue
            node = SpanNode(
                id=span["id"],
                type=span["type"],
                parent_id=span["parent_id"],
                start_timestamp=span["start_timestamp"],
                attrs=span.get("attrs", {}),
            )
            nodes_by_id[node.id] = node
            if node.parent_id is None:
                root_nodes.append(node)

        elif event_type == "span_end":
            node_id = data["id"]
            node = nodes_by_id.get(node_id)
            if node:
                node.add_end_data(
                    end_timestamp=data["end_timestamp"],
                    elapsed=data.get("elapsed", 0),
                    end_attrs=data.get("end_attrs", {}),
                )

    for node in nodes_by_id.values():
        if node.parent_id and node.parent_id in nodes_by_id:
            nodes_by_id[node.parent_id].add_child(node)

    return root_nodes, nodes_by_id


def _parse_v1(lines):
    """Parse v1 OTEL-shape records.

    Two record types per span:
      - live ``{"type": "span_start", ...}`` (snapshot at open)
      - final span (no ``"type"`` field) emitted on close, with full attrs
        and ``end_time_unix_nano``

    ``start_attrs`` / ``end_attrs`` on ``SpanNode`` are derived from the
    pair: attrs in the ``span_start`` go to ``start_attrs``; attrs that
    are new or changed in the final record go to ``end_attrs``. If no
    ``span_start`` exists for a span (tracer with ``emit_span_start=False``
    or in-flight span), the final's attrs all go to ``start_attrs``.
    """
    starts = {}                 # span_id -> span_start record
    finals = {}                 # span_id -> final span record
    order: dict[str, None] = {} # span_ids in first-encounter order — used as
                                # an ordered set (dict insertion-order, Py3.7+;
                                # O(1) membership). Note: encounter order is
                                # NOT guaranteed chronological. With
                                # emit_span_start=True parents open before
                                # children, but in finals-only mode children
                                # finalize before parents. Parent-child
                                # linkage in phase 3 uses parent_span_id, not
                                # this ordering.

    for line in lines:
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        span_id = data.get("span_id")
        if not span_id:
            continue
        order[span_id] = None
        if data.get("type") == "span_start":
            starts[span_id] = data
        else:
            finals[span_id] = data

    nodes_by_id = {}
    for span_id in order:
        start_rec = starts.get(span_id)
        final_rec = finals.get(span_id)
        # Prefer the final record for metadata when both are present;
        # prefer the start record for the initial-attrs snapshot.
        meta = final_rec or start_rec
        initial_rec = start_rec or final_rec
        if meta is None or initial_rec is None:
            continue

        node = SpanNode(
            id=span_id,
            type=meta.get("name", ""),
            parent_id=_normalize_parent(meta.get("parent_span_id")),
            start_timestamp=_ns_to_iso(meta.get("start_time_unix_nano")),
            attrs=initial_rec.get("attributes", {}),
        )
        nodes_by_id[span_id] = node

        if final_rec is not None:
            start_attrs = (start_rec or {}).get("attributes", {})
            final_attrs = final_rec.get("attributes", {})
            if start_rec is not None:
                # New/changed attrs are what was added during the span. We
                # don't track removals — OTEL attrs accumulate; a key dropped
                # between start and final stays in start_attrs by design.
                end_attrs = {
                    k: v for k, v in final_attrs.items()
                    if start_attrs.get(k) != v
                }
            else:
                # No span_start → all attrs already on start_attrs, nothing to add.
                end_attrs = {}
            end_ns = final_rec.get("end_time_unix_nano")
            start_ns = final_rec.get("start_time_unix_nano")
            elapsed = (end_ns - start_ns) / 1e9 if end_ns is not None and start_ns is not None else 0
            node.add_end_data(
                end_timestamp=_ns_to_iso(end_ns),
                elapsed=elapsed,
                end_attrs=end_attrs,
            )

    root_nodes = []
    for node in nodes_by_id.values():
        if node.parent_id and node.parent_id in nodes_by_id:
            nodes_by_id[node.parent_id].add_child(node)
        else:
            # Roots: parent_id None, or parent not present in this file
            # (orphans are treated as roots, same convention as v0).
            root_nodes.append(node)

    return root_nodes, nodes_by_id


def _normalize_parent(parent):
    """OTEL parent_span_id may be missing, None, or empty string for roots."""
    if not parent:
        return None
    return parent


def _ns_to_iso(ns):
    """Convert ``start_time_unix_nano`` / ``end_time_unix_nano`` → ISO 8601 (UTC)."""
    if ns is None:
        return None
    return datetime.fromtimestamp(ns / 1e9, tz=timezone.utc).isoformat()


# --------------------------------------------------
# UI
# --------------------------------------------------

last_mod_time = None
last_file_content = None  # Cache file content
current_json_objects = []
is_loading = False  # Track loading state

# Second file support for comparison
last_mod_time_2 = None
last_file_content_2 = None
current_json_objects_2 = []
debug_file_2 = None
is_loading_2 = False

# this is more than toggles now that we accept regex for passes
toggles = {
    "v1": True,
    "v1_v0": True,
    "metamodel": False,
    "backend": True,
    "passes": True,
    "dsl": False,
    "type_graph": False,
    "show_stats": False,
    "pass_diff": False,
    "collapse_sidebar": False,
}

checkboxes = {}

# Pass filter state
filter_pass_names: "set[str] | None" = None
_filter_items: list = []
_filter_backend_cb_ref: list = [None]

# Custom file upload state
custom_file_name = None
use_custom_file = False

# Query selection state
selected_query_id = None
selected_query_index = None

# Pass expansion state
pass_expanded = {}  # pass_id -> boolean

# O(1) span lookup index, rebuilt on every file parse
span_index: dict = {}  # span_id -> SpanNode
_ui_state_restored = False


def _serialize_ui_state() -> dict[str, Any]:
    return {
        "toggles": toggles,
        "filter_pass_names": sorted(filter_pass_names) if filter_pass_names is not None else None,
        "pass_expanded": pass_expanded,
        "selected_query_id": selected_query_id,
        "selected_query_index": selected_query_index,
    }


def _persist_ui_state() -> None:
    ui.run_javascript(
        f"window.__pyrelDbgSaveState?.({json.dumps(_serialize_ui_state())});"
    )


async def _restore_ui_state() -> None:
    global filter_pass_names, pass_expanded, _ui_state_restored
    global selected_query_id, selected_query_index
    if _ui_state_restored:
        return
    try:
        state = await ui.run_javascript("window.__pyrelDbgLoadState?.() ?? null;", timeout=2.0)
    except TimeoutError as ex:
        print(f"Warning: failed to restore debugger UI state (timeout): {ex}")
        _ui_state_restored = True
        return
    except RuntimeError as ex:
        print(f"Warning: failed to restore debugger UI state: {ex}")
        _ui_state_restored = True
        return

    if state is not None and not isinstance(state, dict):
        print(f"Warning: ignoring invalid debugger UI state payload type: {type(state).__name__}")
    if not isinstance(state, dict):
        _ui_state_restored = True
        return

    saved_toggles = state.get("toggles")
    if isinstance(saved_toggles, dict):
        for key, value in saved_toggles.items():
            if key in toggles and isinstance(value, bool):
                toggles[key] = value
    elif saved_toggles is not None:
        print("Warning: ignoring invalid debugger toggles state.")

    saved_filter_names = state.get("filter_pass_names")
    if saved_filter_names is None:
        filter_pass_names = None
    elif isinstance(saved_filter_names, list):
        invalid_names = [name for name in saved_filter_names if not isinstance(name, str)]
        if invalid_names:
            print(f"Warning: ignoring {len(invalid_names)} invalid saved filter pass names.")
        filter_pass_names = {name for name in saved_filter_names if isinstance(name, str)}
    else:
        print("Warning: ignoring invalid debugger filter_pass_names state.")

    saved_expanded = state.get("pass_expanded")
    if isinstance(saved_expanded, dict):
        pass_expanded = {str(k): bool(v) for k, v in saved_expanded.items()}
    elif saved_expanded is not None:
        print("Warning: ignoring invalid debugger pass_expanded state.")

    saved_selected_id = state.get("selected_query_id")
    if isinstance(saved_selected_id, str):
        selected_query_id = saved_selected_id
    elif saved_selected_id is not None:
        print("Warning: ignoring invalid debugger selected_query_id state.")

    saved_selected_index = state.get("selected_query_index")
    if isinstance(saved_selected_index, int):
        selected_query_index = saved_selected_index
    elif saved_selected_index is not None:
        print("Warning: ignoring invalid debugger selected_query_index state.")

    _ui_state_restored = True
    main_layout.refresh()  # type: ignore[attr-defined]
    filter_indicator.refresh()  # type: ignore[attr-defined]
    sidebar.refresh()  # type: ignore[attr-defined]
    details.refresh()  # type: ignore[attr-defined]


def select_query(query_id, query_index):
    """Select a query to display in the main pane"""
    global selected_query_id, selected_query_index
    selected_query_id = query_id
    selected_query_index = query_index
    _persist_ui_state()
    query_list_sidebar.refresh()  # type: ignore[attr-defined]
    details.refresh()  # type: ignore[attr-defined]
    sidebar.refresh()  # type: ignore[attr-defined]


def to_ms(t):
    if not t:
        return "..."
    return f"{t * 1000:,.0f}"


def format_time(t):
    if not t:
        return "..."
    if t > 1:
        return f"{t:.1f}s"
    elif t > 0.001:
        return f"{t * 1000:.1f}ms"
    elif t > 0.0005:
        return f"{t * 1000:.2f}ms"
    else:
        return f"{t * 1000000:.0f}μs"


def replace_long_brace_contents(code_str):
    def replacement(match):
        string = match.group(0)
        if len(string) > 300:
            # Extract the first 50 and last 30 characters from the string within brackets
            return "{" + string[1:51] + "..." + string[-31:-1] + "}"
        else:
            # If the string is not longer than 300 characters, return it unchanged
            return string

    # This regex matches sequences of characters wrapped in { }
    brace_content_regex = r"\{[\s\S]*?\}"

    # Use the sub method to replace the matched strings with the result of the replacement function
    return re.sub(brace_content_regex, replacement, code_str)


def compute_line_diff(text1: str, text2: str):
    """
    Compute line-by-line diff with character-level highlighting.
    Returns list of tuples: (line_num, line_type, content, char_highlights)

    line_type can be: 'equal', 'insert', 'replace', or 'delete'
    """
    import difflib

    # Edge cases: empty inputs
    if not text1 and not text2:
        return []
    if not text1:
        return [(i, 'insert', line, []) for i, line in enumerate(text2.splitlines())]
    if not text2:
        return [(i, 'delete', line, []) for i, line in enumerate(text1.splitlines())]

    lines1 = text1.splitlines()
    lines2 = text2.splitlines()

    sm = difflib.SequenceMatcher(None, lines1, lines2)
    diff_result = []
    result_position = 0  # Track position in rendered output (not line numbers from either file)

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for idx, line in enumerate(lines2[j1:j2]):
                diff_result.append((result_position + idx, 'equal', line, []))
            result_position += (j2 - j1)

        elif tag == 'replace':
            # Handle replacements - may have unequal line counts
            num_lines1 = i2 - i1  # Lines in File 1
            num_lines2 = j2 - j1  # Lines in File 2
            max_lines = max(num_lines1, num_lines2)

            for idx in range(max_lines):
                if idx < num_lines1 and idx < num_lines2:
                    # Both files have this line - show as replace with char-level diff
                    line1 = lines1[i1 + idx]
                    line2 = lines2[j1 + idx]
                    char_highlights = compute_char_diff(line1, line2)
                    diff_result.append((result_position + idx, 'replace', line2, char_highlights))
                elif idx < num_lines1:
                    # Extra line in File 1 (deleted in File 2)
                    diff_result.append((result_position + idx, 'delete', lines1[i1 + idx], []))
                else:
                    # Extra line in File 2 (added from File 1)
                    diff_result.append((result_position + idx, 'insert', lines2[j1 + idx], []))
            result_position += max_lines

        elif tag == 'insert':
            # Lines only in File 2 (additions)
            for idx in range(j2 - j1):
                diff_result.append((result_position + idx, 'insert', lines2[j1 + idx], []))
            result_position += (j2 - j1)

        elif tag == 'delete':
            # Lines only in File 1 (deletions) - THIS WAS MISSING!
            for idx in range(i2 - i1):
                diff_result.append((result_position + idx, 'delete', lines1[i1 + idx], []))
            result_position += (i2 - i1)

    return diff_result


def compute_char_diff(str1: str, str2: str):
    """
    Compute character-level diff within a line.
    Returns list of (start, end, type) tuples for highlighting in str2.
    """
    import difflib

    sm = difflib.SequenceMatcher(None, str1, str2)
    highlights = []

    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ('replace', 'insert'):
            highlights.append((j1, j2, tag))

    return highlights


def apply_char_highlights(raw_text: str, highlights):
    """Apply character-level highlight spans to raw text, HTML-escaping each segment."""
    import html as _html

    if not highlights:
        return _html.escape(raw_text)

    result = []
    last_pos = 0

    for start, end, tag in sorted(highlights):
        result.append(_html.escape(raw_text[last_pos:start]))
        span_class = "char-insert" if tag == "insert" else "char-replace"
        result.append(f'<span class="{span_class}">{_html.escape(raw_text[start:end])}</span>')
        last_pos = end

    result.append(_html.escape(raw_text[last_pos:]))
    return "".join(result)


def render_diff_html(code: str, diff_data, language: str = "python"):
    """
    Render code with diff highlighting as HTML.
    """
    import html

    lines_html = []
    for line_num, line_type, content, char_highlights in diff_data:
        # Apply character-level highlights (skip for deleted lines)
        if char_highlights and line_type != 'delete':
            content_html = apply_char_highlights(content, char_highlights)
        else:
            content_html = html.escape(content)

        # Apply line-level styling
        line_class = f"diff-line diff-{line_type}"

        # Determine prefix based on line type
        if line_type in ('insert', 'replace'):
            prefix = "+"
        elif line_type == 'delete':
            prefix = "-"
        else:
            prefix = " "

        lines_html.append(
            f'<div class="{line_class}">'
            f'<span class="line-prefix">{prefix}</span>'
            f'<span class="line-content">{content_html}</span>'
            f'</div>'
        )

    # Wrap in code block
    html_output = f'''
    <div class="diff-code-block">
        <pre><code class="language-{language}">{"".join(lines_html)}</code></pre>
    </div>
    '''

    return html_output


def code(c, language="python"):
    # do not wrap text when outputting Rel
    if language != "rel":
        c = replace_long_brace_contents(c)
    # use python's syntax highlighting for Rel as well
    if language == "rel":
        language = "ruby"
    if language == "lqp":
        language = "python"

    code_element = (
        ui.code(c, language=language)
        .style(
            "border-radius: 6px; "
            "margin: 8px 0; "
            "padding: 12px 16px; "
            "font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; "
            "font-size: 0.9em; "
            "line-height: 1.6; "
            "box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2); "
            "overflow-x: auto; "
            "max-width: 100%;"
        )
        .classes("w-full code-block")
    )

    return code_element


def code_with_diff(c1, c2, language="python"):
    """
    Display code with git diff-style highlighting showing differences between c1 and c2.
    Only c2 is shown with highlighting indicating what changed from c1.
    """
    if not c2 or not c2.strip():
        return

    # Apply same transformations as code() function
    if language != "rel":
        c2 = replace_long_brace_contents(c2)
    if language == "rel":
        language = "ruby"
    if language == "lqp":
        language = "python"

    c1_stripped = c1.strip() if c1 else ""
    c2_stripped = c2.strip()

    # If identical, show regular code without diff highlighting
    if c1_stripped == c2_stripped:
        return code(c2_stripped, language=language)

    # Compute diff
    diff_data = compute_line_diff(c1_stripped, c2_stripped)

    # Render as HTML with diff highlighting
    html_content = render_diff_html(c2_stripped, diff_data, language=language)

    # Use ui.html() to display with same styling as code()
    ui.html(html_content, sanitize=False).style(
        "border-radius: 6px; "
        "margin: 8px 0; "
        "padding: 12px 16px; "
        "font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace; "
        "font-size: 0.9em; "
        "line-height: 1.6; "
        "box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2); "
        "overflow-x: auto; "
        "max-width: 100%;"
    ).classes("w-full code-block")


def code_with_header(header_text, c, language="python", c2=None, color=None):
    """Display code with header. If c2 is provided, show two columns side by side."""
    color = color or THEME["accent_primary"]
    if c2 is not None:
        # Check if both codes are identical
        c_stripped = c.strip() if c else ""
        c2_stripped = c2.strip() if c2 else ""

        if c_stripped and c2_stripped and c_stripped == c2_stripped:
            # Identical code - show single column with special header
            with ui.column().style(
                f"gap: 0; margin: 16px 0; border-left: 3px solid {THEME['success']}; padding-left: 12px;"
            ):
                ui.label(f"{header_text} (identical)").style(
                    f"font-size: 0.85em; "
                    f"font-weight: 600; "
                    f"letter-spacing: 0.05em; "
                    f"color: {THEME['text_secondary']}; "
                    f"margin-bottom: 8px;"
                )
                code(c_stripped, language=language)
        else:
            # Different code - show two columns
            with ui.row().style(
                "gap: 16px; margin: 16px 0; width: 100%;"
            ):
                # Left column
                with ui.column().style(
                    f"gap: 0; flex: 1; border-left: 3px solid {color}; padding-left: 12px; min-width: 0;"
                ):
                    ui.label(f"{header_text} (File 1)").style(
                        f"font-size: 0.85em; "
                        f"font-weight: 600; "
                        f"letter-spacing: 0.05em; "
                        f"color: {THEME['text_secondary']}; "
                        f"margin-bottom: 8px;"
                    )
                    if c and c.strip():
                        code(c.strip(), language=language)
                # Right column
                with ui.column().style(
                    f"gap: 0; flex: 1; border-left: 3px solid {THEME['accent_secondary']}; padding-left: 12px; min-width: 0;"
                ):
                    ui.label(f"{header_text} (File 2)").style(
                        f"font-size: 0.85em; "
                        f"font-weight: 600; "
                        f"letter-spacing: 0.05em; "
                        f"color: {THEME['text_secondary']}; "
                        f"margin-bottom: 8px;"
                    )
                    if c2 and c2.strip():
                        if c and c.strip():
                            code_with_diff(c.strip(), c2.strip(), language=language)
                        else:
                            code(c2.strip(), language=language)
    else:
        # Single column (original behavior)
        with ui.column().style(
            f"gap: 0; margin: 16px 0; border-left: 3px solid {color}; padding-left: 12px;"
        ):
            ui.label(header_text).style(
                f"font-size: 0.85em; "
                f"font-weight: 600; "
                f"letter-spacing: 0.05em; "
                f"color: {THEME['text_secondary']}; "
                f"margin-bottom: 8px;"
            )
            # Only show code block if there's content
            if c and c.strip():
                code(c.strip(), language=language)


def span_code(span: SpanNode, span2: SpanNode | None = None):
    if span.type in ("model", "install"):
        ui.label("Model changed — check passes for more").style(
            f"font-size: 1.1em; font-weight: 700; color: {THEME['accent_query']}; padding: 8px 0;"
        )
        with ui.column().style("gap: 8px; width: 100%; max-width: 100%;"):
            for i, child in enumerate(span.children):
                child2 = span2.children[i] if span2 and i < len(span2.children) else None
                span_code(child, child2)
    elif span.type == "query":
        if span.start_attrs.get("source"):
            with ui.column().style("width: fit-content; max-width: 100%;"):
                code(span.start_attrs["source"]).style(
                    f"transition: all 0.2s ease; border-color: {THEME['accent_query']};"
                )
            txn_id = find_txn_id(span)
            if txn_id:
                observe_url = f"https://171608476159.observeinc.com/workspace/41759331/log-explorer?datasetId=41832558&filter-rai_transaction_id={txn_id}"
                with ui.row().style("align-items: center; gap: 6px; margin: 4px 0 8px 0;"):
                    ui.label(f"txn: {txn_id}").style(
                        f"font-family: 'JetBrains Mono', monospace; font-size: 0.8em; "
                        f"color: {THEME['text_secondary']};"
                    )
                    ui.button(icon="open_in_new", on_click=lambda _e, url=observe_url: ui.navigate.to(url, new_tab=True)).props(
                        "flat round dense"
                    ).style(f"color: {THEME['text_muted']};")
        # Always show content when query is selected (no expand/collapse)
        with ui.column().style(
            "gap: 8px; width: 100%; max-width: 100%;"
        ):
            if toggles["dsl"]:
                dsl2 = span2.start_attrs.get("dsl") if span2 else None
                code_with_header("dsl", span.start_attrs["dsl"], c2=dsl2)
            for i, child in enumerate(span.children):
                child2 = span2.children[i] if span2 and i < len(span2.children) else None
                span_code(child, child2)
    elif span.type == "compile" and span.end_attrs.get("compile_type") in ("model", "model_v1"):
        if toggles["metamodel"]:
            metamodel2 = span2.start_attrs.get("metamodel") if span2 else None
            code_with_header("model metamodel", span.start_attrs["metamodel"], c2=metamodel2)
        for i, child in enumerate(span.children):
            child2 = span2.children[i] if span2 and i < len(span2.children) else None
            span_code(child, child2)
        if toggles["backend"]:
            if "rel" in span.end_attrs:
                rel2 = span2.end_attrs.get("rel") if span2 else None
                code_with_header("rel model", span.end_attrs["rel"], language="rel", c2=rel2, color=THEME["accent_compile"])
            elif "lqp" in span.end_attrs:
                lqp2 = span2.end_attrs.get("lqp") if span2 else None
                code_with_header("lqp model", span.end_attrs["lqp"], language="lqp", c2=lqp2, color=THEME["accent_compile"])
    elif span.type == "compile" and span.end_attrs.get("compile_type") == "query":
        if toggles["metamodel"]:
            metamodel2 = span2.start_attrs.get("metamodel") if span2 else None
            code_with_header("metamodel", span.start_attrs["metamodel"], c2=metamodel2)
        for i, child in enumerate(span.children):
            child2 = span2.children[i] if span2 and i < len(span2.children) else None
            span_code(child, child2)
        if toggles["backend"]:
            if "rel" in span.end_attrs:
                rel2 = span2.end_attrs.get("rel") if span2 else None
                code_with_header("rel query", span.end_attrs["rel"], language="rel", c2=rel2, color=THEME["accent_compile"])
            elif "lqp" in span.end_attrs:
                lqp2 = span2.end_attrs.get("lqp") if span2 else None
                code_with_header("lqp query", span.end_attrs["lqp"], language="lqp", c2=lqp2, color=THEME["accent_compile"])
    elif span.type == "passes":
        type_graph_shown = False
        if toggles["passes"]:
            previous_code = None
            previous_code_2 = None
            last_displayed_code = None
            for i, child in enumerate(span.children):
                if filter_pass_names is not None and child.type not in filter_pass_names:
                    continue
                current_code = ""
                if "metamodel" in child.end_attrs:
                    current_code = child.end_attrs["metamodel"]
                    if current_code == previous_code:
                        current_code = ""
                    else:
                        last_displayed_code = previous_code
                        previous_code = current_code

                # Find matching child in span2
                current_code_2 = None
                child2 = None
                if span2 and i < len(span2.children):
                    child2 = span2.children[i]
                    if "metamodel" in child2.end_attrs:
                        current_code_2 = child2.end_attrs["metamodel"]
                        if current_code_2 == previous_code_2:
                            current_code_2 = None
                        else:
                            previous_code_2 = current_code_2

                # Only make pass collapsible if it has content
                has_content = (current_code and current_code.strip()) or (current_code_2 and current_code_2.strip())
                pass_header = f"{get_span_icon(child.type)} {child.type} • {format_time(child.elapsed)}"
                if child2 and child2.elapsed is not None:
                    pass_header += f" ({format_time(child2.elapsed)})"

                # "AnnotateConstraints" passes use a distinct accent color to mark group boundaries
                is_marker = child.type == "AnnotateConstraints"
                pass_color = THEME["warning"] if is_marker else THEME["accent_primary"]

                if has_content:
                    # Default collapsed for lazy rendering
                    if child.id not in pass_expanded:
                        pass_expanded[child.id] = False

                    is_expanded = pass_expanded[child.id]

                    header_style = f"{'background: rgba(224, 175, 104, 0.2); border-radius: 4px; ' if is_marker else ''}color: {pass_color};"
                    with ui.expansion(pass_header, value=is_expanded).props(
                        f'id="pass-{child.id}" header-style="{header_style}"'
                    ).style(
                        f"margin: 16px 0; "
                        f"border-left: 3px solid {pass_color};"
                    ).classes("pass-expansion") as expansion:
                        def _on_expand(e, pass_id=child.id):
                            pass_expanded[pass_id] = e.args
                            _persist_ui_state()
                            if e.args:
                                details.refresh()  # type: ignore[attr-defined]
                        expansion.on('update:model-value', _on_expand)

                        # Only render content when expanded (lazy)
                        if is_expanded:
                            if current_code_2 is not None:
                                c_stripped = current_code.strip() if current_code else ""
                                c2_stripped = current_code_2.strip() if current_code_2 else ""

                                if c_stripped and c2_stripped and c_stripped == c2_stripped:
                                    if c_stripped:
                                        code(c_stripped)
                                else:
                                    with ui.row().style("gap: 16px; width: 100%;"):
                                        with ui.column().style("flex: 1; min-width: 0;"):
                                            if c_stripped:
                                                code(c_stripped)
                                        with ui.column().style("flex: 1; min-width: 0;"):
                                            if c2_stripped:
                                                if c_stripped:
                                                    code_with_diff(c_stripped, c2_stripped)
                                                else:
                                                    code(c2_stripped)
                            else:
                                if current_code and current_code.strip():
                                    if toggles["pass_diff"] and not span2 and last_displayed_code:
                                        code_with_diff(last_displayed_code, current_code.strip())
                                    else:
                                        code(current_code.strip())
                else:
                    # No content - just show header (non-collapsible) with "no changes" indicator
                    ui.label(f"{pass_header} • no changes").style(
                        f"font-size: 0.85em; "
                        f"font-weight: 600; "
                        f"color: {pass_color}; "
                        f"margin: 16px 0; "
                        f"padding-left: 12px; "
                        f"border-left: 3px solid {pass_color};"
                    ).props(f'id="pass-{child.id}"')

                if child.type == "InferTypes" and toggles["type_graph"]:
                    type_graph_shown = True
                    for child2 in child.children:
                        if child2.end_attrs.get("type_graph"):
                            ui.mermaid(child2.end_attrs["type_graph"], {"maxEdges": 10000}).style(
                                "display: flex; "
                                "padding: 16px; "
                                "border-radius: 8px; "
                                "margin: 12px 0; "
                                "gap: 30px; "
                                "overflow: auto;"
                            ).classes("mermaid-diagram")
        if toggles["type_graph"] and not type_graph_shown:
            for child in span.children:
                if child.type == "InferTypes":
                    for child2 in child.children:
                        if child2.end_attrs.get("type_graph"):
                            ui.mermaid(child2.end_attrs["type_graph"], {"maxEdges": 10000}).style(
                                "display: flex; "
                                "padding: 16px; "
                                "border-radius: 8px; "
                                "margin: 12px 0; "
                                "gap: 30px; "
                                "overflow: auto;"
                            ).classes("mermaid-diagram")
    elif span.type == "v1":
        if toggles["v1"]:
            previous_code = None
            previous_code_2 = None
            last_displayed_code = None
            for i, child in enumerate(span.children):
                if filter_pass_names is not None and child.type not in filter_pass_names:
                    continue
                current_code = ""
                current_code_2 = None
                child2 = None
                # if the span has a "result" attribute, it means the result of the pass is
                # not a metamodel. So we just print that as the current_code, but we don't
                # modify the previous_code so that if a subsequent pass does have a
                # metamodel, we can still compare it to the previous pass's metamodel.
                if "result" in child.end_attrs:
                    current_code = child.end_attrs["result"]
                    if current_code == previous_code:
                        current_code = ""
                    else:
                        last_displayed_code = previous_code
                        previous_code = current_code
                else:
                    if "metamodel" in child.end_attrs:
                        current_code = child.end_attrs["metamodel"]
                        if current_code == previous_code:
                            current_code = ""
                        else:
                            last_displayed_code = previous_code
                            previous_code = current_code

                    # Find matching child in span2
                    if span2 and i < len(span2.children):
                        child2 = span2.children[i]
                        if "metamodel" in child2.end_attrs:
                            current_code_2 = child2.end_attrs["metamodel"]
                            if current_code_2 == previous_code_2:
                                current_code_2 = None
                            else:
                                previous_code_2 = current_code_2

                # Only make pass collapsible if it has content
                has_content = (current_code and current_code.strip()) or (current_code_2 and current_code_2.strip())
                pass_header = f"{get_span_icon(child.type)} {child.type} • {format_time(child.elapsed)}"
                if child2 and child2.elapsed is not None:
                    pass_header += f" ({format_time(child2.elapsed)})"

                # "Original" passes use a distinct accent color to mark group boundaries
                is_original = child.type == "Original"
                pass_color = THEME["warning"] if is_original else THEME["accent_rule"]

                if has_content:
                    # Default collapsed for lazy rendering
                    if child.id not in pass_expanded:
                        pass_expanded[child.id] = False

                    is_expanded = pass_expanded[child.id]

                    header_style = f"{'background: rgba(224, 175, 104, 0.2); border-radius: 4px; ' if is_original else ''}color: {pass_color};"
                    with ui.expansion(pass_header, value=is_expanded).props(
                        f'id="pass-{child.id}" header-style="{header_style}"'
                    ).style(
                        f"margin: 16px 0; "
                        f"border-left: 3px solid {pass_color};"
                    ).classes("pass-expansion") as expansion:
                        def _on_expand(e, pass_id=child.id):
                            pass_expanded[pass_id] = e.args
                            _persist_ui_state()
                            if e.args:
                                details.refresh()  # type: ignore[attr-defined]
                        expansion.on('update:model-value', _on_expand)

                        # Only render content when expanded (lazy)
                        if is_expanded:
                            if current_code_2 is not None:
                                c_stripped = current_code.strip() if current_code else ""
                                c2_stripped = current_code_2.strip() if current_code_2 else ""

                                if c_stripped and c2_stripped and c_stripped == c2_stripped:
                                    if c_stripped:
                                        code(c_stripped)
                                else:
                                    with ui.row().style("gap: 16px; width: 100%;"):
                                        with ui.column().style("flex: 1; min-width: 0;"):
                                            if c_stripped:
                                                code(c_stripped)
                                        with ui.column().style("flex: 1; min-width: 0;"):
                                            if c2_stripped:
                                                if c_stripped:
                                                    code_with_diff(c_stripped, c2_stripped)
                                                else:
                                                    code(c2_stripped)
                            else:
                                if current_code and current_code.strip():
                                    if toggles["pass_diff"] and not span2 and last_displayed_code:
                                        code_with_diff(last_displayed_code, current_code.strip())
                                    else:
                                        code(current_code.strip())
                else:
                    # No content - just show header (non-collapsible) with "no changes" indicator
                    ui.label(f"{pass_header} • no changes").style(
                        f"font-size: 0.85em; "
                        f"font-weight: 600; "
                        f"color: {pass_color}; "
                        f"margin: 16px 0; "
                        f"padding-left: 12px; "
                        f"border-left: 3px solid {pass_color};"
                    ).props(f'id="pass-{child.id}"')
    elif span.type == "v1_v0":
        if toggles["v1_v0"]:
            previous_code = None
            previous_code_2 = None
            last_displayed_code = None
            for i, child in enumerate(span.children):
                if filter_pass_names is not None and child.type not in filter_pass_names:
                    continue
                current_code = ""
                if "metamodel" in child.end_attrs:
                    current_code = child.end_attrs["metamodel"]
                    if current_code == previous_code:
                        current_code = ""
                    else:
                        last_displayed_code = previous_code
                        previous_code = current_code

                # Find matching child in span2
                current_code_2 = None
                child2 = None
                if span2 and i < len(span2.children):
                    child2 = span2.children[i]
                    if "metamodel" in child2.end_attrs:
                        current_code_2 = child2.end_attrs["metamodel"]
                        if current_code_2 == previous_code_2:
                            current_code_2 = None
                        else:
                            previous_code_2 = current_code_2

                # Only make pass collapsible if it has content
                has_content = (current_code and current_code.strip()) or (current_code_2 and current_code_2.strip())
                pass_header = f"{get_span_icon(child.type)} {child.type} • {format_time(child.elapsed)}"
                if child2 and child2.elapsed is not None:
                    pass_header += f" ({format_time(child2.elapsed)})"

                pass_color = THEME["accent_primary"] if child.type == "v0 Translation" else THEME["accent_rule"]
                if has_content:
                    # Initialize expansion state for this pass (default: expanded)
                    if child.id not in pass_expanded:
                        pass_expanded[child.id] = True

                    # Use ui.expansion for collapsible pass
                    with ui.expansion(pass_header, value=pass_expanded[child.id]).props(
                        f'id="pass-{child.id}" header-style="color: {pass_color};"'
                    ).style(
                        f"margin: 16px 0; "
                        f"border-left: 3px solid {pass_color};"
                    ).classes("pass-expansion") as expansion:
                        def _on_expand(e, pass_id=child.id):
                            pass_expanded[pass_id] = e.args
                            _persist_ui_state()

                        expansion.on('update:model-value', _on_expand)

                        # Render code content inside expansion
                        if current_code_2 is not None:
                            # Two-column comparison
                            c_stripped = current_code.strip() if current_code else ""
                            c2_stripped = current_code_2.strip() if current_code_2 else ""

                            if c_stripped and c2_stripped and c_stripped == c2_stripped:
                                # Identical
                                if c_stripped:
                                    code(c_stripped)
                            else:
                                # Different - show two columns
                                with ui.row().style("gap: 16px; width: 100%;"):
                                    with ui.column().style("flex: 1; min-width: 0;"):
                                        if c_stripped:
                                            code(c_stripped)
                                    with ui.column().style("flex: 1; min-width: 0;"):
                                        if c2_stripped:
                                            if c_stripped:
                                                code_with_diff(c_stripped, c2_stripped)
                                            else:
                                                code(c2_stripped)
                        else:
                            # Single column
                            if current_code and current_code.strip():
                                if toggles["pass_diff"] and not span2 and last_displayed_code:
                                    code_with_diff(last_displayed_code, current_code.strip())
                                else:
                                    code(current_code.strip())
                else:
                    # No content - just show header (non-collapsible) with "no changes" indicator
                    ui.label(f"{pass_header} • no changes").style(
                        f"font-size: 0.85em; "
                        f"font-weight: 600; "
                        f"color: {pass_color}; "
                        f"margin: 16px 0; "
                        f"padding-left: 12px; "
                        f"border-left: 3px solid {pass_color};"
                    ).props(f'id="pass-{child.id}"')
    else:
        for i, child in enumerate(span.children):
            child2 = span2.children[i] if span2 and i < len(span2.children) else None
            span_code(child, child2)


@ui.refreshable
def details():
    if is_loading or is_loading_2:
        with ui.column().style("gap: 20px; padding: 16px; align-items: center;"):
            ui.spinner(size="xl", color=THEME["accent_primary"])
            ui.label("Loading debug data...").style(f"color: {THEME['text_secondary']};")
    elif selected_query_id is None:
        # Show nothing when no query is selected
        pass
    else:
        # Show only the selected query
        with ui.column().style("gap: 20px; padding: 16px; width: 100%; max-width: 100%; box-sizing: border-box;"):
            selected_query = span_index.get(selected_query_id)

            if selected_query:
                # Find matching query in second file if comparison mode
                selected_query_2 = None
                if selected_query_index is not None and selected_query_index < len(current_json_objects_2):
                    selected_query_2 = current_json_objects_2[selected_query_index]

                # Always expand the selected query (no toggle needed)
                span_code(selected_query, selected_query_2)
            else:
                ui.label("Selected query not found").style(
                    f"color: {THEME['error']}; "
                    f"padding: 16px;"
                )


def handle_body(span: SpanNode):
    if span.children and span.type not in ["rule_batch"]:
        for child in span.children:
            span_ui(child, True)


def span_ui(span: SpanNode, is_pass: bool = False):
    def jump_to_pass():
        global toggles
        toggles["passes"] = True
        _persist_ui_state()
        sidebar.refresh()  # type: ignore[attr-defined]
        details.refresh()  # type: ignore[attr-defined]
        ui.navigate.to(f"#pass-{span.id}")

    with ui.column().classes("w-full").style("padding: 0 0 0 15px; gap: 4px;"):
        timing_color = get_timing_color(span.elapsed)
        span_color = get_span_color(span.type)
        icon = get_span_icon(span.type)

        with (
            ui.row()
            .classes("w-full span-card")
            .style(
                f"padding: 8px 12px; "
                f"flex-wrap: nowrap; "
                f"margin: 0; "
                f"border-left: 3px solid {span_color}; "
                f"border-radius: 4px; "
                f"transition: all 0.2s ease; "
                f"box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);"
            ) as me
        ):
            name = span.type
            if name == "create_v2":
                name += " ➚"
            ui.label(f"{icon} {name}").style(
                "padding: 0; margin: 0; font-weight: 500; font-size: 0.9em;"
            ).classes("span-card-text")
            ui.space()
            ui.label(f"{to_ms(span.elapsed)}ms").style(
                f"padding: 4px 8px; "
                f"color: {timing_color}; "
                f"border-radius: 4px; "
                f"font-family: 'JetBrains Mono', monospace; "
                f"font-size: 0.85em; "
                f"font-weight: 600;"
            ).classes("timing-badge")
            if span.type == "create_v2":
                txn_id = span.end_attrs.get("txn_id")
                me.on(
                    "click",
                    lambda: ui.navigate.to(
                        f"https://171608476159.observeinc.com/workspace/41759331/log-explorer?datasetId=41832558&filter-rai_transaction_id={txn_id}",
                        new_tab=True,
                    ),
                )
                me.style("cursor: pointer;")
            elif is_pass:
                me.on("click", lambda: jump_to_pass())
                me.style("cursor: pointer;")

            # Add hover effect
            if span.type == "create_v2" or is_pass:
                me.style("add cursor: pointer;")
                me.classes("hover:brightness-110")

        handle_body(span)


def _find_sidebar_items(roots):
    """Walk the span tree, collecting spans worth a top-level sidebar entry.

    The set is defined by ``SIDEBAR_SPAN_TYPES`` (install / query / model).
    v0 emitted these as roots; v1 wraps them under a top-level ``program``
    span, so a roots-only filter misses them. DFS collects matches at any
    depth, and we stop descending into a match (these don't nest in
    practice).
    """
    # Stack used as a DFS frontier. Pop from the end (O(1)) and push children
    # in reverse so the leftmost child gets visited first — preserves the
    # original pre-order traversal while keeping the whole walk linear.
    found = []
    stack = list(reversed(roots))
    while stack:
        span = stack.pop()
        if span.type in SIDEBAR_SPAN_TYPES:
            found.append(span)
        else:
            stack.extend(reversed(span.children))
    return list(enumerate(found))


@ui.refreshable
def query_list_sidebar():
    """Left sidebar showing list of queries/rules for selection"""
    queries = _find_sidebar_items(current_json_objects)

    if not queries:
        # Check if we're in initial loading state
        if is_loading:
            with ui.column().style("gap: 12px; padding: 16px; align-items: center;"):
                ui.spinner(size="lg", color=THEME["accent_primary"])
                ui.label("Processing debug file...").style(
                    f"color: {THEME['text_secondary']}; "
                    f"font-size: 0.9em; "
                    f"text-align: center;"
                )
        else:
            ui.label("No queries or rules found").style(
                f"color: {THEME['text_muted']}; "
                f"padding: 16px; "
                f"text-align: center;"
            )
        return

    for i, query in queries:
        is_selected = query.id == selected_query_id
        span_color = get_span_color(query.type)
        icon = get_span_icon(query.type)

        # Get query name from source if available
        if query.type in ("install", "model"):
            query_name = "model installed"
        elif query.type == "query" and (
            query.start_attrs.get("operation") == "prepare"
            or query.end_attrs.get("operation") == "prepare"
        ):
            # Tolerate both attr locations: new code emits via kwargs (start_attrs),
            # older runs set them post-open and they land in end_attrs.
            query_name = "model prepared (compile-only)"
        else:
            source = query.start_attrs.get("source", "")
            query_name = " ".join(source.split())[:80] if source else f"{query.type} {i}"

        border_color = span_color if is_selected else 'transparent'
        item_class = "query-item-selected" if is_selected else "query-item"

        with (
            ui.row()
            .classes(f"w-full {item_class}")
            .style(
                f"padding: 10px 12px; "
                f"margin: 2px 0; "
                f"border-left: 3px solid {border_color}; "
                f"border-radius: 4px; "
                f"cursor: pointer; "
                f"transition: all 0.2s ease; "
                f"gap: 8px; "
                f"align-items: center;"
            )
            .classes("hover:brightness-110")
            as item
        ):
            ui.label(icon).style(
                "font-size: 1.2em; "
                "margin: 0;"
            )
            ui.label(query_name).style(
                "flex: 1; "
                "font-size: 0.85em; "
                "overflow: hidden; "
                "text-overflow: ellipsis; "
                "white-space: nowrap;"
            ).classes("query-item-text")
            if is_selected:
                ui.label("✓").style(
                    f"color: {span_color}; "
                    f"font-weight: bold;"
                )

            # Make clickable
            item.on("click", lambda idx=i, qid=query.id: select_query(qid, idx))


@ui.refreshable
def sidebar():
    with ui.column().style(
        "min-width: 300px; "
        "max-width: 300px; "
        "margin-top: 60px; "
        "height: calc(100vh - 70px); "
        "overflow-x: hidden; "
        "overflow-y: auto; "
        "position: fixed; "
        "top: 0; "
        "right: 0; "
        "z-index: 1000; "
        "padding: 16px 12px; "
        "gap: 8px;"
    ).classes("right-sidebar"):
        if selected_query_id is None:
            ui.label("No query selected").style(
                f"color: {THEME['text_muted']}; "
                f"padding: 16px; "
                f"text-align: center;"
            )
        else:
            selected_span = span_index.get(selected_query_id)
            if selected_span:
                span_ui(selected_span)
            else:
                ui.label("Stats not available").style(
                    f"color: {THEME['text_muted']}; "
                    f"padding: 16px; "
                    f"text-align: center;"
                )


def poll():
    global last_mod_time, last_file_content, is_loading
    global current_json_objects, span_index
    global last_mod_time_2, last_file_content_2, is_loading_2, current_json_objects_2
    global selected_query_id, selected_query_index
    global DEBUG_LOG_PATH

    # Skip polling when a custom uploaded file is active
    if use_custom_file:
        return

    # Re-resolve the watched path when no explicit --file was given, so a new
    # install dir (or first flat spans.jsonl) created mid-session is picked up
    # automatically. Only switch when the candidate file actually exists —
    # otherwise we'd briefly flicker through a fallback path.
    if _EXPLICIT_FILE is None:
        candidate = _resolve_primary_path(None)
        if candidate != DEBUG_LOG_PATH and candidate.exists():
            DEBUG_LOG_PATH = candidate
            last_mod_time = None
            last_file_content = ""

    if DEBUG_LOG_PATH is None:
        return

    # Check the last modification time of the first file
    try:
        mod_time = os.path.getmtime(DEBUG_LOG_PATH)
        if last_mod_time is None or mod_time > last_mod_time:
            # File has changed, read and parse the new content
            with open(DEBUG_LOG_PATH, "r") as file:
                content = file.read()
                # Only parse if content actually changed
                if content and content != last_file_content:
                    # Update mod time only when we actually process the content
                    last_mod_time = mod_time

                    # Show loading indicator for large files
                    if len(content) > 100000:  # 100KB threshold
                        is_loading = True
                        details.refresh()  # type: ignore[attr-defined]

                    start_time = time.time()
                    last_file_content = content
                    new_tree, new_index = parse_jsonl_to_tree(content)
                    parse_time = time.time() - start_time

                    # Log parsing time if it's slow
                    if parse_time > 0.1:
                        print(f"⏱️  Parsed file 1: {len(content)} bytes in {parse_time:.3f}s")

                    current_json_objects = new_tree
                    span_index = new_index
                    is_loading = False

                    if selected_query_id is None:
                        # Defer initial auto-selection until browser state restoration completes.
                        if _ui_state_restored:
                            queries = _find_sidebar_items(current_json_objects)
                            if queries:
                                if (
                                    isinstance(selected_query_index, int)
                                    and 0 <= selected_query_index < len(queries)
                                ):
                                    idx, query = queries[selected_query_index]
                                    selected_query_id = query.id
                                    selected_query_index = idx
                                else:
                                    first_idx, first_query = queries[0]
                                    selected_query_id = first_query.id
                                    selected_query_index = first_idx
                                _persist_ui_state()
                    elif selected_query_id not in span_index:
                        # Selected query disappeared. Try to preserve selection by index.
                        queries = _find_sidebar_items(current_json_objects)
                        if (
                            isinstance(selected_query_index, int)
                            and 0 <= selected_query_index < len(queries)
                        ):
                            idx, query = queries[selected_query_index]
                            selected_query_id = query.id
                            selected_query_index = idx
                        else:
                            selected_query_id = None
                            selected_query_index = None
                        _persist_ui_state()

                    # Refresh the UI with the new objects
                    query_list_sidebar.refresh()  # type: ignore[attr-defined]
                    sidebar.refresh()  # type: ignore[attr-defined]
                    details.refresh()  # type: ignore[attr-defined]
    except FileNotFoundError:
        pass

    # Check the second file if it exists
    if debug_file_2:
        try:
            mod_time_2 = os.path.getmtime(debug_file_2)
            if last_mod_time_2 is None or mod_time_2 > last_mod_time_2:
                last_mod_time_2 = mod_time_2
                with open(debug_file_2, "r") as file:
                    content = file.read()
                    if content and content != last_file_content_2:
                        if len(content) > 100000:
                            is_loading_2 = True
                            details.refresh()  # type: ignore[attr-defined]

                        start_time = time.time()
                        last_file_content_2 = content
                        new_tree_2, _ = parse_jsonl_to_tree(content)
                        parse_time = time.time() - start_time

                        if parse_time > 0.1:
                            print(f"⏱️  Parsed file 2: {len(content)} bytes in {parse_time:.3f}s")

                        current_json_objects_2 = new_tree_2
                        is_loading_2 = False

                        query_list_sidebar.refresh()  # type: ignore[attr-defined]
                        sidebar.refresh()  # type: ignore[attr-defined]
                        details.refresh()  # type: ignore[attr-defined]
        except FileNotFoundError:
            pass


def toggle(key):
    global toggles
    toggles[key] = not toggles[key]
    if key in ("show_stats", "collapse_sidebar"):
        main_layout.refresh()  # type: ignore[attr-defined]
    else:
        sidebar.refresh()  # type: ignore[attr-defined]
        details.refresh()  # type: ignore[attr-defined]
    _persist_ui_state()



@ui.refreshable
def main_layout():
    with ui.row().style(
        "margin-top: 70px; "
        "height: calc(100vh - 70px); "
        "width: 100%; "
        "flex-wrap: nowrap; "
        "gap: 0; "
        "overflow: hidden;"
    ):
        # Left sidebar: Query list
        if not toggles["collapse_sidebar"]:
            with ui.column().style(
                "width: 280px; "
                "min-width: 280px; "
                "max-width: 280px; "
                "flex-shrink: 0; "
                "height: 100%; "
                "overflow-x: hidden; "
                "overflow-y: auto; "
                "padding: 16px 12px; "
                "gap: 8px;"
            ).classes("left-sidebar"):
                query_list_sidebar()

        # Center: Main details pane
        with ui.column().style(
            "flex: 1 1 0; "
            "min-width: 0; "
            "width: 100%; "
            "padding: 0 2em; "
            "overflow-y: auto; "
            "overflow-x: hidden; "
            "height: 100%; "
            "box-sizing: border-box; "
            "scrollbar-width: none; "  # Firefox
            "-ms-overflow-style: none;"  # IE/Edge
        ).classes("hide-scrollbar main-content"):  # For webkit browsers
            details()

        # Right sidebar: Stats (optional, fixed position - always render outside the flex container)

    # Render stats outside the main flex row so it doesn't affect layout
    if toggles["show_stats"]:
        sidebar()


@ui.refreshable
def file_indicator():
    if custom_file_name:
        with ui.row().style("align-items: center; gap: 4px;"):
            ui.label(f"📄 {custom_file_name}").style(
                f"color: {THEME['accent_query']}; "
                f"font-size: 0.85em; "
                f"max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"
            )
            ui.button(icon="close", on_click=clear_custom_file).props("flat round dense").style(
                f"color: {THEME['text_muted']};"
            )


async def handle_file_upload(e):
    """Handle an uploaded .jsonl debug file."""
    global custom_file_name, use_custom_file
    global current_json_objects, span_index, selected_query_id, selected_query_index
    try:
        content = await e.file.text()
        custom_file_name = e.file.name
        use_custom_file = True

        new_tree, new_index = parse_jsonl_to_tree(content)
        current_json_objects = new_tree
        span_index = new_index

        selected_query_id = None
        selected_query_index = None
        _persist_ui_state()

        file_indicator.refresh()  # type: ignore[attr-defined]
        query_list_sidebar.refresh()  # type: ignore[attr-defined]
        sidebar.refresh()  # type: ignore[attr-defined]
        details.refresh()  # type: ignore[attr-defined]
    except Exception as ex:
        print(f"Error processing uploaded file: {ex}")


def clear_custom_file():
    """Clear the custom file and resume polling the default debug file."""
    global custom_file_name, use_custom_file, last_mod_time, last_file_content
    custom_file_name = None
    use_custom_file = False
    last_mod_time = None   # force re-read of default file
    last_file_content = None
    file_indicator.refresh()  # type: ignore[attr-defined]


def clear_filter():
    global filter_pass_names
    filter_pass_names = None
    for key in ("v1", "v1_v0", "passes", "backend"):
        toggles[key] = False
    _persist_ui_state()
    filter_indicator.refresh()  # type: ignore[attr-defined]
    details.refresh()  # type: ignore[attr-defined]


@ui.refreshable
def filter_indicator():
    if filter_pass_names is not None:
        with ui.row().style("align-items: center; gap: 4px;"):
            n = len(filter_pass_names)
            ui.label(f"{n} pass" if n == 1 else f"{n} passes").style(
                f"color: {THEME['accent_compile']}; font-size: 0.85em;"
            )
            ui.button(icon="close", on_click=clear_filter).props("flat round dense").style(
                f"color: {THEME['text_muted']};"
            )


def get_export_passes(span):
    """Walk a span tree and collect passes grouped by section, with content."""
    sections: dict[str, list[tuple[str, str]]] = {}

    def walk(node):
        if node.type == "v1":
            entries = sections.setdefault("v1 passes", [])
            for child in node.children:
                entries.append((child.type, child.end_attrs.get("metamodel", "")))
        elif node.type == "v1_v0":
            entries = sections.setdefault("v1→v0", [])
            for child in node.children:
                entries.append((child.type, child.end_attrs.get("metamodel", "")))
        elif node.type == "passes":
            entries = sections.setdefault("v0 passes", [])
            for child in node.children:
                entries.append((child.type, child.end_attrs.get("metamodel", "")))
        elif node.type == "compile":
            if "rel" in node.end_attrs or "lqp" in node.end_attrs:
                entries = sections.setdefault("backend", [])
                fmt = "rel" if "rel" in node.end_attrs else "lqp"
                ct = node.end_attrs.get("compile_type", "")
                if fmt == "lqp":
                    name = "LQP"
                else:
                    name = f"{fmt} ({ct})" if ct else fmt
                entries.append((name, node.end_attrs.get(fmt, "")))
            for child in node.children:
                walk(child)
        else:
            for child in node.children:
                walk(child)

    for child in span.children:
        walk(child)

    return sections


def _collect_filter_sections(span) -> dict[str, list[str]]:
    """Return {section_label: [pass_type, ...]} for v1/v1_v0/passes children."""
    sections: dict[str, list[str]] = {}
    label_map = {"v1": "v1 passes", "v1_v0": "v1→v0", "passes": "v0 passes"}

    def walk(node):
        if node.type in label_map:
            entries = sections.setdefault(label_map[node.type], [])
            for child in node.children:
                if child.type not in entries:
                    entries.append(child.type)
        else:
            for child in node.children:
                walk(child)

    for child in span.children:
        walk(child)
    return sections


@ui.refreshable
def filter_modal_content():
    global _filter_items
    _filter_items = []
    _filter_backend_cb_ref[0] = None

    if selected_query_id is None:
        ui.label("No query selected.").style(f"color: {THEME['text_muted']};")
        return

    span = span_index.get(selected_query_id)
    if span is None:
        ui.label("Query not found.").style(f"color: {THEME['text_muted']};")
        return

    sections = _collect_filter_sections(span)
    has_backend = bool(get_export_passes(span).get("backend"))

    if not sections and not has_backend:
        ui.label("No passes available.").style(f"color: {THEME['text_muted']};")
        return

    all_checkboxes: list = []
    section_checkboxes: dict[str, list] = {}
    section_all_cbs: dict[str, Any] = {}
    syncing = [False]
    all_v1v0_cb = None

    def toggle_all(value):
        if syncing[0]:
            return
        syncing[0] = True
        for cb in all_checkboxes:
            cb.set_value(value)
        for sec_cb in section_all_cbs.values():
            sec_cb.set_value(value)
        syncing[0] = False

    def toggle_section(section, value):
        if syncing[0]:
            return
        syncing[0] = True
        for cb in section_checkboxes.get(section, []):
            cb.set_value(value)
        all_cb.set_value(all(cb.value for cb in all_checkboxes))
        syncing[0] = False

    def sync_all(_):
        if syncing[0]:
            return
        syncing[0] = True
        all_cb.set_value(all(cb.value for cb in all_checkboxes))
        for sec, sec_cbs in section_checkboxes.items():
            if sec in section_all_cbs:
                section_all_cbs[sec].set_value(all(cb.value for cb in sec_cbs))
        syncing[0] = False

    def _passes_all_checked():
        for section, names in sections.items():
            if section == "v1→v0":
                if not toggles["v1_v0"]:
                    return False
            else:
                t = "v1" if section == "v1 passes" else "passes"
                if not toggles[t]:
                    return False
                if filter_pass_names is not None and not all(n in filter_pass_names for n in names):
                    return False
        return not has_backend or toggles["backend"]

    with ui.row().style("gap: 16px; margin-bottom: 4px; align-items: center;"):
        all_cb = ui.checkbox("all", value=_passes_all_checked(), on_change=lambda e: toggle_all(e.value))
        all_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
        if "v1 passes" in sections:
            v1_initial = toggles["v1"] and (filter_pass_names is None or all(n in filter_pass_names for n in sections["v1 passes"]))
            v1_cb = ui.checkbox("v1", value=v1_initial,
                                on_change=lambda e: toggle_section("v1 passes", e.value))
            v1_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            section_all_cbs["v1 passes"] = v1_cb
        if "v1→v0" in sections:
            all_v1v0_cb = ui.checkbox("v1→v0", value=toggles["v1_v0"], on_change=sync_all)
            all_v1v0_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            all_checkboxes.append(all_v1v0_cb)
        if "v0 passes" in sections:
            v0_cb = ui.checkbox("v0", value=toggles["passes"],
                                on_change=lambda e: toggle_section("v0 passes", e.value))
            v0_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            section_all_cbs["v0 passes"] = v0_cb
        if has_backend:
            all_backend_cb = ui.checkbox("Backend", value=toggles["backend"], on_change=sync_all)
            all_backend_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            all_checkboxes.append(all_backend_cb)
            _filter_backend_cb_ref[0] = all_backend_cb

    for section, pass_names_list in sections.items():
        if section == "v1→v0":
            # Single shared checkbox — no individual rows (same as export)
            if all_v1v0_cb is not None:
                for pass_name in pass_names_list:
                    _filter_items.append((section, pass_name, all_v1v0_cb))
            continue

        ui.label(section).style(
            f"font-size: 0.8em; font-weight: 600; color: {THEME['text_secondary']}; "
            f"margin-top: 12px; margin-bottom: 2px; text-transform: uppercase; letter-spacing: 0.05em;"
        )
        sec_cbs: list = []
        section_checkboxes[section] = sec_cbs
        section_toggle = {"v1 passes": "v1", "v0 passes": "passes"}.get(section, "v1")
        with ui.element("div").style(
            "display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 2px 8px;"
        ):
            for pass_name in pass_names_list:
                is_checked = toggles[section_toggle] and (
                    filter_pass_names is None or pass_name in filter_pass_names
                )
                cb = ui.checkbox(pass_name, value=is_checked, on_change=sync_all)
                cb.style(f"color: {THEME['text_primary']};")
                all_checkboxes.append(cb)
                sec_cbs.append(cb)
                _filter_items.append((section, pass_name, cb))


# Tracks (section, pass_name, content, checkbox) for the currently open export modal.
_export_items: list = []


@ui.refreshable
def export_modal_content():
    global _export_items
    _export_items = []

    if selected_query_id is None:
        ui.label("No query selected.").style(f"color: {THEME['text_muted']};")
        return

    span = span_index.get(selected_query_id)
    if span is None:
        ui.label("Query not found.").style(f"color: {THEME['text_muted']};")
        return

    sections = get_export_passes(span)
    if not sections:
        ui.label("No passes available.").style(f"color: {THEME['text_muted']};")
        return

    all_checkboxes: list = []
    section_checkboxes: dict[str, list] = {}
    section_all_cbs: dict[str, Any] = {}
    syncing = [False]

    def toggle_all(value):
        if syncing[0]:
            return
        syncing[0] = True
        for cb in all_checkboxes:
            cb.set_value(value)
        for sec_cb in section_all_cbs.values():
            sec_cb.set_value(value)
        syncing[0] = False

    def toggle_section(section, value):
        if syncing[0]:
            return
        syncing[0] = True
        for cb in section_checkboxes.get(section, []):
            cb.set_value(value)
        all_cb.set_value(all(cb.value for cb in all_checkboxes))
        syncing[0] = False

    def sync_all(_):
        if syncing[0]:
            return
        syncing[0] = True
        all_cb.set_value(all(cb.value for cb in all_checkboxes))
        for sec, sec_cbs in section_checkboxes.items():
            if sec in section_all_cbs:
                section_all_cbs[sec].set_value(all(cb.value for cb in sec_cbs))
        syncing[0] = False

    # Top-row section toggles for hidden sections (v1→v0, backend) are plain checkboxes
    # added to all_checkboxes so "all" can drive them.
    all_v1v0_cb = None
    all_backend_cb = None

    with ui.row().style("gap: 16px; margin-bottom: 4px; align-items: center;"):
        all_cb = ui.checkbox("all", value=False, on_change=lambda e: toggle_all(e.value))
        all_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
        if "v1 passes" in sections:
            all_v1_cb = ui.checkbox("v1", value=False,
                on_change=lambda e: toggle_section("v1 passes", e.value))
            all_v1_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            section_all_cbs["v1 passes"] = all_v1_cb
        if "v1→v0" in sections:
            all_v1v0_cb = ui.checkbox("v1→v0", value=False, on_change=sync_all)
            all_v1v0_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            all_checkboxes.append(all_v1v0_cb)
        if "v0 passes" in sections:
            all_v0_cb = ui.checkbox("v0", value=False,
                on_change=lambda e: toggle_section("v0 passes", e.value))
            all_v0_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            section_all_cbs["v0 passes"] = all_v0_cb
        if "backend" in sections:
            all_backend_cb = ui.checkbox("Backend", value=False, on_change=sync_all)
            all_backend_cb.style(f"font-weight: bold; color: {THEME['text_primary']};")
            all_checkboxes.append(all_backend_cb)

    for section, entries in sections.items():
        # v1→v0 and backend have no individual rows — the top-row cb is their sole toggle
        if section in ("v1→v0", "backend"):
            section_cb = all_v1v0_cb if section == "v1→v0" else all_backend_cb
            seen: set[str] = set()
            for pass_name, content in entries:
                if pass_name in seen:
                    continue
                seen.add(pass_name)
                _export_items.append((section, pass_name, content, section_cb))
            continue

        ui.label(section).style(
            f"font-size: 0.8em; font-weight: 600; color: {THEME['text_secondary']}; "
            f"margin-top: 12px; margin-bottom: 2px; text-transform: uppercase; letter-spacing: 0.05em;"
        )
        sec_cbs: list = []
        section_checkboxes[section] = sec_cbs
        seen = set()
        with ui.element("div").style(
            "display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 2px 8px;"
        ):
            for pass_name, content in entries:
                if pass_name in seen:
                    continue
                seen.add(pass_name)
                cb = ui.checkbox(pass_name, value=False, on_change=sync_all)
                cb.style(f"color: {THEME['text_primary']};")
                all_checkboxes.append(cb)
                sec_cbs.append(cb)
                _export_items.append((section, pass_name, content, cb))


def main(host="0.0.0.0", port=8080, file=None, file2=None):
    global checkboxes
    global toggles
    global debug_file_2
    global DEBUG_LOG_PATH, _EXPLICIT_FILE

    _EXPLICIT_FILE = Path(file) if file else None
    DEBUG_LOG_PATH = _resolve_primary_path(_EXPLICIT_FILE)
    debug_file_2 = file2

    # Turn off stats in comparison mode
    if debug_file_2:
        toggles["show_stats"] = False
        toggles["v1"] = True

    ui.dark_mode(None)

    # Add custom CSS for better styling with theme support
    ui.add_head_html("""
        <style>
            /* CSS Variables - Dark Theme (Default) */
            :root {
                /* Backgrounds */
                --bg-main: #1a1b26;
                --bg-elevated: #24283b;
                --bg-surface: #414868;
                --bg-hover: #545c7e;
                --bg-code: #1f2335;

                /* Text */
                --text-primary: #c0caf5;
                --text-secondary: #9aa5ce;
                --text-tertiary: #565f89;
                --text-muted: #787c99;

                /* Accents */
                --accent-primary: #7aa2f7;
                --accent-secondary: #bb9af7;
                --accent-rule: #9ece6a;
                --accent-query: #7dcfff;
                --accent-compile: #ff9e64;
                --accent-passes: #bb9af7;

                /* Status */
                --success: #9ece6a;
                --warning: #e0af68;
                --error: #f7768e;

                /* Borders */
                --border: #3b4261;
                --border-light: #545c7e;

                /* Diff colors - Dark theme */
                --diff-insert-bg: rgba(46, 160, 67, 0.15);
                --diff-replace-bg: rgba(229, 192, 123, 0.15);
                --diff-delete-bg: rgba(247, 118, 142, 0.15);
                --char-insert-bg: rgba(46, 160, 67, 0.35);
                --char-replace-bg: rgba(229, 192, 123, 0.35);
            }

            /* Light Theme Override */
            @media (prefers-color-scheme: light) {
                :root {
                    /* Backgrounds */
                    --bg-main: #f9fafb;
                    --bg-elevated: #ffffff;
                    --bg-surface: #e5e7eb;
                    --bg-hover: #d1d5db;
                    --bg-code: #f3f4f6;

                    /* Text */
                    --text-primary: #1f2937;
                    --text-secondary: #4b5563;
                    --text-tertiary: #9ca3af;
                    --text-muted: #6b7280;

                    /* Accents */
                    --accent-primary: #2563eb;
                    --accent-secondary: #7c3aed;
                    --accent-rule: #16a34a;
                    --accent-query: #0891b2;
                    --accent-compile: #ea580c;
                    --accent-passes: #9333ea;

                    /* Status */
                    --success: #16a34a;
                    --warning: #d97706;
                    --error: #dc2626;

                    /* Borders */
                    --border: #d1d5db;
                    --border-light: #e5e7eb;

                    /* Diff colors - Light theme */
                    --diff-insert-bg: rgba(22, 163, 74, 0.15);
                    --diff-replace-bg: rgba(217, 119, 6, 0.15);
                    --diff-delete-bg: rgba(220, 38, 38, 0.15);
                    --char-insert-bg: rgba(22, 163, 74, 0.35);
                    --char-replace-bg: rgba(217, 119, 6, 0.35);
                }
            }
            /* Ignore boxes around errors in code spans, because unicode chars are wrapped
                like that by nicegui.
             */
            body .codehilite .err {
                border: none !important;
            }

            /* Apply theme colors to base elements */
            body {
                background: var(--bg-main) !important;
                color: var(--text-primary) !important;
            }
            .nicegui-content {
                background: var(--bg-main) !important;
            }

            /* Layout components */
            .app-header {
                background: var(--bg-elevated) !important;
                color: var(--text-primary) !important;
                border-bottom: 1px solid var(--border) !important;
            }
            .left-sidebar {
                background: var(--bg-main) !important;
                border-right: 1px solid var(--border) !important;
            }
            .right-sidebar {
                background: var(--bg-main) !important;
                border-left: 1px solid var(--border) !important;
            }
            .main-content {
                background: var(--bg-main) !important;
            }

            /* Query list items */
            .query-item {
                background: var(--bg-elevated) !important;
            }
            .query-item-selected {
                background: var(--bg-surface) !important;
            }
            .query-item-text {
                color: var(--text-primary) !important;
            }

            /* Span cards */
            .span-card {
                background: var(--bg-elevated) !important;
            }
            .span-card-text {
                color: var(--text-primary) !important;
            }
            .timing-badge {
                background: var(--bg-code) !important;
            }

            /* Pass expansion */
            .pass-expansion {
                background: var(--bg-elevated) !important;
            }

            /* Code blocks */
            .code-block {
                background: var(--bg-code) !important;
                border: 1px solid var(--border) !important;
                color: var(--text-primary) !important;
            }
            .code-block pre,
            .code-block code {
                background: transparent !important;
                color: inherit !important;
            }

            /* Mermaid diagrams */
            .mermaid-diagram {
                background: var(--bg-elevated) !important;
                border: 1px solid var(--border) !important;
            }

            /* Prism.js syntax highlighting - adapt to theme */
            @media (prefers-color-scheme: light) {
                /* Light theme syntax colors */
                .token.comment,
                .token.prolog,
                .token.doctype,
                .token.cdata {
                    color: #6b7280 !important; /* gray */
                }
                .token.punctuation {
                    color: #4b5563 !important; /* dark gray */
                }
                .token.property,
                .token.tag,
                .token.boolean,
                .token.number,
                .token.constant,
                .token.symbol,
                .token.deleted {
                    color: #dc2626 !important; /* red */
                }
                .token.selector,
                .token.attr-name,
                .token.string,
                .token.char,
                .token.builtin,
                .token.inserted {
                    color: #16a34a !important; /* green */
                }
                .token.operator,
                .token.entity,
                .token.url,
                .language-css .token.string,
                .style .token.string {
                    color: #d97706 !important; /* amber */
                }
                .token.atrule,
                .token.attr-value,
                .token.keyword {
                    color: #2563eb !important; /* blue */
                }
                .token.function,
                .token.class-name {
                    color: #7c3aed !important; /* purple */
                }
                .token.regex,
                .token.important,
                .token.variable {
                    color: #ea580c !important; /* orange */
                }
            }

            /* Dark theme keeps Prism's default dark theme colors */

            /* Improve scrollbar styling */
            ::-webkit-scrollbar {
                width: 10px;
                height: 10px;
            }
            ::-webkit-scrollbar-track {
                background: var(--bg-main);
            }
            ::-webkit-scrollbar-thumb {
                background: var(--bg-surface);
                border-radius: 5px;
            }
            ::-webkit-scrollbar-thumb:hover {
                background: var(--bg-hover);
            }

            /* Hide scrollbar for main content pane */
            .hide-scrollbar::-webkit-scrollbar {
                display: none;
            }

            /* Improve checkbox styling */
            .q-checkbox__bg {
                border-color: var(--border-light) !important;
            }
            .q-checkbox__svg {
                color: var(--accent-primary) !important;
            }

            /* Improve input styling */
            .q-field__control {
                background: var(--bg-code) !important;
                border-radius: 6px !important;
            }
            .q-field__native {
                color: var(--text-primary) !important;
            }

            /* Diff highlighting styles */
            .diff-code-block {
                width: 100%;
            }
            .diff-code-block pre {
                margin: 0;
                padding: 0;
                background: transparent !important;
            }
            .diff-code-block code {
                background: transparent !important;
            }
            .diff-line {
                display: flex;
                padding: 2px 0;
            }
            .diff-insert {
                background-color: var(--diff-insert-bg);
            }
            .diff-replace {
                background-color: var(--diff-replace-bg);
            }
            .diff-delete {
                background-color: var(--diff-delete-bg);
            }
            .diff-equal {
                background-color: transparent;
            }
            .line-prefix {
                width: 20px;
                text-align: center;
                margin-right: 8px;
                color: var(--text-tertiary);
                user-select: none;
                flex-shrink: 0;
            }
            .char-insert {
                background-color: var(--char-insert-bg);
                border-radius: 2px;
                padding: 0 2px;
            }
            .char-replace {
                background-color: var(--char-replace-bg);
                border-radius: 2px;
                padding: 0 2px;
            }
            .line-content {
                flex: 1;
                white-space: pre;
            }
        </style>
        <script>
        (function() {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

            function handleThemeChange(e) {
                const isDark = e.matches;
                // Sync with Quasar's dark mode
                if (window.$q && window.$q.dark) {
                    window.$q.dark.set(isDark);
                }
            }

            mediaQuery.addEventListener('change', handleThemeChange);
            handleThemeChange(mediaQuery);  // Initial sync
        })();

        (function() {
            const normalizedPath = (location.pathname || '/').replace(/\\/+$/, '') || '/';
            const STATE_KEY = `pyrel-rai-debugger:${normalizedPath}`;

            window.__pyrelDbgLoadState = function() {
                try {
                    const raw = localStorage.getItem(STATE_KEY);
                    if (!raw) return null;
                    const parsed = JSON.parse(raw);
                    return typeof parsed === 'object' && parsed ? parsed : null;
                } catch (_) {
                    return null;
                }
            };

            window.__pyrelDbgSaveState = function(state) {
                try {
                    localStorage.setItem(STATE_KEY, JSON.stringify(state ?? {}));
                } catch (_) {
                }
            };
        })();
        </script>
    """)

    with ui.column():
        with ui.row().style(
            "flex-wrap: wrap; "
            "position: fixed; "
            "top: 0; "
            "left: 0; "
            "right: 0; "
            "z-index: 1000; "
            "padding: 12px 16px; "
            "gap: 16px; "
            "box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3); "
            "align-items: center;"
        ).classes("app-header"):
            # Sidebar toggle
            ui.button(
                icon="chevron_right" if toggles["collapse_sidebar"] else "chevron_left",
                on_click=lambda: toggle("collapse_sidebar")
            ).props("flat round dense").style("color: var(--text-secondary);")

            # Title
            title_text = f"PyRel (v{VERSION})"
            if debug_file_2:
                title_text += " • Comparison Mode"
            ui.label(title_text).style(
                "font-size: 1.3em; font-weight: 700; color: #ff9e64; margin-right: 8px;"
            )

            # Filter passes — button opens a dialog
            with ui.dialog() as filter_dialog, ui.card().style(
                f"background: {THEME['bg_elevated']}; "
                f"width: 80vw; max-width: 900px; max-height: 75vh; "
                f"display: flex; flex-direction: column; padding: 0; gap: 0;"
            ):
                ui.label("Filter Passes").style(
                    f"font-size: 1.1em; font-weight: 700; color: {THEME['text_primary']}; "
                    f"padding: 20px 20px 12px 20px; flex-shrink: 0;"
                )
                with ui.column().style("overflow-y: auto; flex: 1; padding: 0 20px; width: 100%; box-sizing: border-box;"):
                    filter_modal_content()
                with ui.row().style(
                    f"padding: 12px 20px; flex-shrink: 0; justify-content: center; "
                    f"width: 100%; box-sizing: border-box; "
                    f"border-top: 1px solid {THEME['border']};"
                ):
                    def apply_filter():
                        global filter_pass_names
                        selected = {name for sec, name, cb in _filter_items if cb.value}
                        all_names = {name for sec, name, _ in _filter_items}
                        filter_pass_names = None if selected == all_names else selected
                        toggles["v1"] = any(cb.value for sec, name, cb in _filter_items if sec == "v1 passes")
                        toggles["v1_v0"] = any(cb.value for sec, name, cb in _filter_items if sec == "v1→v0")
                        toggles["passes"] = any(cb.value for sec, name, cb in _filter_items if sec == "v0 passes")
                        if _filter_backend_cb_ref[0] is not None:
                            toggles["backend"] = _filter_backend_cb_ref[0].value
                        _persist_ui_state()
                        filter_indicator.refresh()  # type: ignore[attr-defined]
                        details.refresh()  # type: ignore[attr-defined]
                        filter_dialog.close()

                    ui.button("Apply", icon="filter_alt", on_click=apply_filter).props("dense")
                    ui.button("Clear", icon="filter_alt_off", on_click=lambda: (clear_filter(), filter_dialog.close())).props("flat dense").style(
                        f"color: {THEME['text_secondary']};"
                    )

            def open_filter():
                filter_modal_content.refresh()  # type: ignore[attr-defined]
                filter_dialog.open()

            ui.button(
                "Filter", icon="filter_alt", on_click=open_filter
            ).props("flat dense").style("font-size: 0.85em; color: var(--text-secondary);")
            filter_indicator()

            # Stats toggle
            if not debug_file_2:
                checkboxes["pass_diff"] = ui.switch(
                    "∆ passes", value=toggles["pass_diff"], on_change=lambda: toggle("pass_diff")
                ).style("font-size: 0.9em;")
            checkboxes["show_stats"] = ui.switch(
                "runtime", value=toggles["show_stats"], on_change=lambda: toggle("show_stats")
            ).style("font-size: 0.9em;")

            # Upload custom file — button opens a dialog
            with ui.dialog() as upload_dialog, ui.card().style(
                f"background: {THEME['bg_elevated']}; min-width: 400px;"
            ):
                ui.label("Upload debug file (.jsonl)").style(
                    f"font-weight: 600; color: {THEME['text_primary']}; margin-bottom: 8px;"
                )

                async def on_upload(e):
                    await handle_file_upload(e)
                    upload_dialog.close()

                ui.upload(
                    on_upload=on_upload,
                    auto_upload=True,
                    max_files=1,
                ).props('accept=".jsonl" flat').classes("w-full")

            ui.button(
                "Upload .jsonl", icon="upload_file", on_click=upload_dialog.open
            ).props("flat dense").style("font-size: 0.85em; color: var(--text-secondary);")
            file_indicator()

            with ui.dialog() as export_dialog, ui.card().style(
                f"background: {THEME['bg_elevated']}; "
                f"width: 80vw; "
                f"max-width: 900px; "
                f"max-height: 75vh; "
                f"display: flex; "
                f"flex-direction: column; "
                f"padding: 0; "
                f"gap: 0;"
            ):
                ui.label("Compilation Artifacts").style(
                    f"font-size: 1.1em; font-weight: 700; color: {THEME['text_primary']}; "
                    f"padding: 20px 20px 12px 20px; flex-shrink: 0;"
                )
                with ui.column().style("overflow-y: auto; flex: 1; padding: 0 20px; width: 100%; box-sizing: border-box;"):
                    export_modal_content()
                with ui.row().style(
                    f"padding: 12px 20px; flex-shrink: 0; justify-content: center; "
                    f"width: 100%; box-sizing: border-box; "
                    f"border-top: 1px solid {THEME['border']};"
                ):
                    def do_export():
                        parts = []
                        lqp_parts = []
                        for section, pass_name, content, cb in _export_items:
                            if not cb.value or not content:
                                continue
                            sep = "# " + "=" * 60
                            block = [sep, f"# {section} / {pass_name}", sep, content, ""]
                            if pass_name == "LQP":
                                lqp_parts.extend(block)
                            else:
                                parts.extend(block)
                        all_parts = parts + lqp_parts
                        if all_parts:
                            ui.download(("\n".join(all_parts)).encode(), filename="export.md")
                        else:
                            ui.notify("No passes selected.", type="warning")

                    ui.button("Export", icon="file_download", on_click=do_export).props("dense")

            def open_export():
                export_modal_content.refresh()  # type: ignore[attr-defined]
                export_dialog.open()

            ui.button(
                "Export", icon="file_download", on_click=open_export
            ).props("flat dense").style("font-size: 0.85em; color: var(--text-secondary);")

        main_layout()

    ui.timer(0.1, _restore_ui_state, once=True)

    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as _s:
        _s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            _s.bind(("127.0.0.1", port))
        except OSError:
            print(f"Error: port {port} is already in use. Stop the process using it or pick a different port.")
            return

    ui.timer(1, poll)
    favicon_path = Path(__file__).parent / "favicon.png"
    ui.run(reload=False, host=host, port=port, title="PyRel Debugger",
           favicon=favicon_path if favicon_path.exists() else None)


if __name__ in {"__main__", "__mp_main__"}:
    # NiceGUI can re-execute this file as __main__ after `rai debugger` starts it.
    # Without this block, re-execution renders a blank page. Argument shape must
    # stay aligned with what `commands/debugger.py` forwards via sys.argv.
    parser = argparse.ArgumentParser(
        add_help=False,
        description="PyRel debugger: visualize span traces from build/runs/.",
    )
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", "-p", type=int, default=8080)
    parser.add_argument(
        "--file",
        help="Primary trace file (defaults to the latest install run's spans.jsonl).",
    )
    parser.add_argument(
        "comparison",
        nargs="?",
        help="Optional second trace file to compare against the primary.",
    )
    args, _unknown = parser.parse_known_args(sys.argv[1:])
    main(host=args.host, port=args.port, file=args.file, file2=args.comparison)
