"""Public lookups over the ``build/runs/`` directory layout.

Run directories are written by :mod:`relationalai.observability.runs`. This
module exposes read-only helpers so other tools (the debugger, future
diagnostic CLIs) can locate runs without depending on internals.
"""

from __future__ import annotations

from pathlib import Path

from ..util.fs import get_build_dir

RUNS_DIRNAME = "runs"


def runs_dir() -> Path:
    return get_build_dir() / RUNS_DIRNAME


def latest_install_dir() -> Path | None:
    """Return the most recent ``_install_`` run directory, or None if none exist."""
    return _latest_dir_matching("_install_")


def latest_run_dir() -> Path | None:
    """Latest install dir if any exist, else latest query dir.

    Lets non-install-mode users (legacy LQP / local / DuckDB) and dry-run-only
    sessions still surface their traces — those flows only create
    ``_query_`` typed dirs because ``start_run("install")`` is never called.
    None if neither type exists.
    """
    return latest_install_dir() or _latest_dir_matching("_query_")


def _latest_dir_matching(token: str) -> Path | None:
    """Latest entry in ``runs/`` whose name contains ``token``.

    Run-id format starts with a UTC timestamp, so lexicographic ``max``
    gives chronological order.
    """
    d = runs_dir()
    if not d.is_dir():
        return None
    candidates = [c for c in d.iterdir() if c.is_dir() and token in c.name]
    if not candidates:
        return None
    return max(candidates, key=lambda c: c.name)


def spans_path(run_id: str | None) -> Path | None:
    """Resolve a ``spans.jsonl`` path.

    - ``run_id`` given: ``build/runs/<run_id>/spans.jsonl`` (not checked for
      existence — the caller decides how to handle a missing file).
    - ``run_id`` None: latest install dir's ``spans.jsonl``; if no install
      dir exists, the latest query dir's ``spans.jsonl``; None if neither.
    """
    if run_id:
        return runs_dir() / run_id / "spans.jsonl"
    latest = latest_run_dir()
    return (latest / "spans.jsonl") if latest is not None else None
