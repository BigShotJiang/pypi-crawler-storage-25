"""v0 → v1 logging bridge.

A ``logging.Handler`` subscribed to v0's ``pyrellogger`` that transforms
v0-shape span records (``{"event": "span_start"|"span_end", ...}``) into
OTEL-shape spans and writes them via the active ``Tracer``. Lets the
debugger eventually consume a single comprehensive ``spans.jsonl`` per run
without forcing every v0 emit site to be migrated upfront.

Retires when all v0 emit sites have been moved to ``Tracer`` directly.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Any

from .tracing import Tracer, _hex

V0_LOGGER_NAME = "pyrellogger"


def install_bridge(tracer: Tracer) -> "V0ToTracerBridgeHandler":
    """Attach the bridge handler to ``pyrellogger``. Idempotent.

    If a handler is already attached, retargets it at ``tracer`` so the
    bridge tracks the active tracer when callers swap it via
    :func:`relationalai.observability.tracing.set_tracer` (common in tests).
    Returns the (existing or newly-attached) handler.
    """
    logger = logging.getLogger(V0_LOGGER_NAME)
    for h in logger.handlers:
        if isinstance(h, V0ToTracerBridgeHandler):
            h._tracer = tracer
            return h
    handler = V0ToTracerBridgeHandler(tracer)
    logger.addHandler(handler)
    return handler


class V0ToTracerBridgeHandler(logging.Handler):
    """Translate v0 span records on ``pyrellogger`` into OTEL spans on ``tracer``."""

    def __init__(self, tracer: Tracer):
        super().__init__()
        self._tracer = tracer
        self._span_id_map: dict[str, str] = {}
        self._trace_id_map: dict[str, str] = {}
        self._open_spans: dict[str, dict[str, Any]] = {}

    def emit(self, record: logging.LogRecord) -> None:
        try:
            # Skip records originating from Tracer's v0 back-compat push to
            # avoid double-emitting (the span is already in spans.jsonl
            # natively). Removed in PR 2 alongside _v0_compat.
            from ._v0_compat import is_compat_active
            if is_compat_active():
                return
            msg = record.msg
            if not isinstance(msg, dict):
                return
            event = msg.get("event")
            if event == "span_start":
                v0_span = msg.get("span")
                if v0_span is not None:
                    self._on_span_start(v0_span)
            elif event == "span_end":
                self._on_span_end(msg)
        except Exception:
            self.handleError(record)  # standard logging contract — never crash the caller

    # ── span_start ───────────────────────────────────────────────────────────

    def _on_span_start(self, v0_span: Any) -> None:
        v0_span_uuid = str(v0_span.id)
        v0_trace_uuid = str(v0_span.trace_id)
        v0_parent_uuid = str(v0_span.parent.id) if getattr(v0_span, "parent", None) else None

        span_id = self._mint_span_id(v0_span_uuid)
        trace_id = self._mint_trace_id(v0_trace_uuid)
        parent_span_id = (
            self._span_id_map.get(v0_parent_uuid) if v0_parent_uuid else None
        )

        start_ns = _iso_to_ns(v0_span.start_timestamp.isoformat())
        attributes = dict(getattr(v0_span, "attrs", {}) or {})

        partial: dict[str, Any] = {
            "trace_id": trace_id,
            "span_id": span_id,
            "parent_span_id": parent_span_id,
            "name": getattr(v0_span, "type", ""),
            "kind": "INTERNAL",
            "start_time_unix_nano": start_ns,
            "attributes": attributes,
            "events": [],
            "resource": {"service.name": self._tracer.service},
        }
        self._open_spans[v0_span_uuid] = partial

        # Live progress record — mirrors Tracer._emit_span_start shape.
        live = {"type": "span_start", **partial}
        self._tracer.emit_raw_jsonl(json.dumps(live, separators=(",", ":"), default=str) + "\n")

    # ── span_end ─────────────────────────────────────────────────────────────

    def _on_span_end(self, msg: dict[str, Any]) -> None:
        v0_span_uuid = msg.get("id")
        if not isinstance(v0_span_uuid, str):
            return
        partial = self._open_spans.pop(v0_span_uuid, None)
        if partial is None:
            return  # span_end without a matching span_start — skip silently

        end_iso = msg.get("end_timestamp")
        if isinstance(end_iso, str):
            try:
                partial["end_time_unix_nano"] = _iso_to_ns(end_iso)
            except ValueError:
                # Malformed v0 timestamp; fall back to start so the span is
                # still emit-able rather than dropped silently by handleError.
                partial["end_time_unix_nano"] = partial["start_time_unix_nano"]
        else:
            # No timestamp; fall back to start so the span is still emit-able.
            partial["end_time_unix_nano"] = partial["start_time_unix_nano"]

        end_attrs = msg.get("end_attrs")
        if isinstance(end_attrs, dict):
            partial["attributes"].update(end_attrs)

        partial["status"] = "UNSET"  # v0 doesn't carry an explicit status concept
        self._tracer.emit_raw_jsonl(json.dumps(partial, separators=(",", ":"), default=str) + "\n")

    # ── id minting ───────────────────────────────────────────────────────────

    def _mint_span_id(self, v0_uuid: str) -> str:
        existing = self._span_id_map.get(v0_uuid)
        if existing is not None:
            return existing
        new_hex = _hex(64)
        self._span_id_map[v0_uuid] = new_hex
        return new_hex

    def _mint_trace_id(self, v0_uuid: str) -> str:
        existing = self._trace_id_map.get(v0_uuid)
        if existing is not None:
            return existing
        new_hex = _hex(128)
        self._trace_id_map[v0_uuid] = new_hex
        return new_hex


def _iso_to_ns(iso: str) -> int:
    """Convert an ISO 8601 datetime string to nanoseconds since Unix epoch."""
    return int(datetime.fromisoformat(iso).timestamp() * 1_000_000_000)
