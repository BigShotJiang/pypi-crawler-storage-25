"""Per-run build directory lifecycle.

`start_run` is the single entry point. Two run types, with different
semantics:

* ``start_run("install")`` — always creates a new ``build/runs/<UTC>_install_<id>/``
  directory and replaces the active run. Each call represents a fresh
  logical install. Called for real installs (CLI ``rai models install`` or
  auto-install with ``auto_install=True``).
* ``start_run("query")`` — idempotent: if a run is already active for this
  process, returns it unchanged. Otherwise adopts the most recent
  ``_install_`` directory on disk (Model B: queries piggyback on the latest
  install). If no install directory exists, falls back to creating a
  ``query``-typed directory. Called for compile-only prep
  (``force_dry_run=True``) when the user is querying against an existing
  install.

After resolving the run, ``start_run`` redirects the tracer to write into
the run's ``spans.jsonl`` and installs the v0→v1 bridge so any
un-migrated v0 emit sites also flow into the per-run file.

Run state is module-level — single run per process. Threading is not a
target today; if a multi-threaded use case appears, switch to a ContextVar.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from .run_paths import latest_install_dir, runs_dir

RunType = Literal["install", "query"]

_current_run: "Run | None" = None


@dataclass(frozen=True)
class Run:
    """A diagnostic run — a directory under ``build/runs/`` collecting trace
    files for one install (and any queries appended to it)."""

    id: str
    run_type: RunType
    dir: Path
    started_at: datetime


def start_run(run_type: RunType) -> Run:
    """Start (or adopt) a run for the given run type.

    - ``"install"``: always creates a new run directory and replaces the
      active run (each call = a fresh logical install).
    - ``"query"``: idempotent. Returns the active run if one exists; else
      adopts the latest install directory on disk; else creates a new
      ``"query"``-typed directory.
    """
    global _current_run

    if run_type == "install":
        _current_run = _create_run("install")
    elif run_type == "query":
        if _current_run is not None:
            return _current_run
        latest = latest_install_dir()
        if latest is not None:
            _current_run = _adopt(latest, "install")
        else:
            _current_run = _create_run("query")
    else:
        raise ValueError(f"Unknown run_type: {run_type!r}")

    # Redirect the active tracer to the run's spans file so all subsequent
    # spans land under build/runs/<id>/. Also attach the v0→v1 bridge so
    # any v0 emit sites we haven't migrated yet flow into the same file,
    # and the v0 back-compat layer so v1 spans also reach ``debug.jsonl``
    # while ``rai debugger`` is still on the v0 input (drop in PR 2).
    from ._v0_compat import install_v0_compat
    from .bridge import install_bridge
    from .tracing import StubTracer, get_tracer
    tracer = get_tracer()
    # Skip wiring on a StubTracer (read-only filesystem fallback): the stub
    # skips ``Tracer.__init__`` and so doesn't have the hook attributes that
    # ``install_v0_compat`` touches — wiring would either AttributeError or
    # be wasted work since no spans will be emitted.
    if isinstance(tracer, StubTracer):
        return _current_run

    tracer.use_run_path(_current_run.dir / "spans.jsonl")
    install_bridge(tracer)
    install_v0_compat(tracer)

    return _current_run


def current_run() -> "Run | None":
    """Return the run active for this process, or ``None`` if none started."""
    return _current_run


# ── internals ────────────────────────────────────────────────────────────────


def _new_run_id(run_type: RunType) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{timestamp}_{run_type}_{secrets.token_hex(2)}"


def _create_run(run_type: RunType) -> Run:
    started_at = datetime.now(timezone.utc)
    run_id = _new_run_id(run_type)
    run_dir = runs_dir() / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    return Run(id=run_id, run_type=run_type, dir=run_dir, started_at=started_at)


def _adopt(dir_path: Path, run_type: RunType) -> Run:
    """Wrap an existing on-disk run directory as a Run object."""
    return Run(
        id=dir_path.name,
        run_type=run_type,
        dir=dir_path,
        started_at=datetime.now(timezone.utc),
    )
