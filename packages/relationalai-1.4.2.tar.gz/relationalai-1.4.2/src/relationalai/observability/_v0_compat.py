"""V0 ``debug.jsonl`` back-compat layer for the Tracer.

Pushes each Tracer-emitted span through v0's ``pyrellogger`` so
``debug.jsonl`` stays comprehensive while ``rai debugger`` is still on the
v0 input. After the migrated install-mode stack now emits via
``tracing.span(...)``, ``debug.jsonl`` would otherwise be missing those
spans — this module restores that visibility without re-introducing v0
dependencies in the call sites.

**Removal in PR 2** (debugger reads ``spans.jsonl``):

1. ``rm`` this file.
2. Drop the ``install_v0_compat(tracer)`` call in ``observability/runs.py``.
3. Drop the ``is_compat_active`` import + guard in ``observability/bridge.py``.
4. Optionally clean up the unused ``_post_emit_*_hook`` attrs in
   ``observability/tracing.py`` (cosmetic).
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .tracing import Span, Tracer


# Thread-local guard. Set while Tracer is pushing a span through
# ``pyrellogger`` so the bridge handler skips the broadcast (otherwise the
# bridge would re-translate the same span back into ``spans.jsonl``,
# producing a duplicate record).
_in_compat_emit = threading.local()

# Maps v1 span_id → the v0 Span object created for it. Entries are added
# in the start hook and popped in the end hook, so the dict is bounded by
# the number of in-flight spans. We keep this here (instead of on the
# v1 Span) because v1 ``Span`` uses ``__slots__`` — extra attrs would error.
_v0_spans_by_id: dict = {}


def is_compat_active() -> bool:
    """Bridge handler reads this to skip Tracer-originated records."""
    return getattr(_in_compat_emit, "active", False)


def install_v0_compat(tracer: "Tracer") -> None:
    """Wire the Tracer's post-emit hooks to mirror spans into ``debug.jsonl``.

    Idempotent: hooks already in place are not replaced.
    """
    if tracer._post_emit_start_hook is not None or tracer._post_emit_full_hook is not None:
        return

    from v0.relationalai import debugging as v0_debug

    def on_span_start(span: "Span") -> None:
        _in_compat_emit.active = True
        try:
            # Pass the span name only; attrs are mirrored at end so dynamic
            # additions via ``add_to_span`` are included.
            v0_span = v0_debug.span_start(span.name)
            _v0_spans_by_id[span.span_id] = v0_span
        finally:
            _in_compat_emit.active = False

    def on_full_span(span: "Span") -> None:
        v0_span = _v0_spans_by_id.pop(span.span_id, None)
        if v0_span is None:
            return
        # Mirror v1 attrs into v0 end_attrs so the debugger sees them.
        v0_span.end_attrs.update(span.attrs)
        _in_compat_emit.active = True
        try:
            v0_debug.span_end(v0_span)
        finally:
            _in_compat_emit.active = False

    tracer._post_emit_start_hook = on_span_start
    tracer._post_emit_full_hook = on_full_span
