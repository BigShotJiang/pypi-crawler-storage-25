"""Pre-flight checks for Cortex agent deployment.

Probes Snowflake for required objects, grants, and roles in one pass and
returns every problem found. The goal is to give a deployer a single
list of "fix these things" instead of N sequential
``Object 'X' does not exist or is not authorized`` errors, each
discovered after another round trip with a Snowflake admin.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional

from snowflake import snowpark

from .setup_sql import deployer_setup_sql
from ..deployment_config import DeploymentConfig


@dataclass
class PreflightFinding:
    """A single issue detected by ``Preflight.run()``.

    Attributes
    ----------
    severity : str
        ``"error"`` (deployment will almost certainly fail),
        ``"warning"`` (likely fine but worth checking), or
        ``"info"`` (could not determine state).
    code : str
        Stable identifier (e.g. ``"MissingPyPiRole"``,
        ``"MissingExternalAccessIntegration"``).
    message : str
        Human-readable description.
    fix_sql : str, optional
        Copy-pasteable SQL or instructions to resolve the finding.
    detail : str, optional
        Additional diagnostic context (e.g. underlying SQL error).
    """
    severity: str
    code: str
    message: str
    fix_sql: Optional[str] = None
    detail: Optional[str] = None


@dataclass
class PreflightReport:
    """The result of a ``Preflight.run()`` invocation."""
    findings: List[PreflightFinding] = field(default_factory=list)
    role: Optional[str] = None
    user: Optional[str] = None

    @property
    def errors(self) -> List[PreflightFinding]:
        return [f for f in self.findings if f.severity == "error"]

    @property
    def warnings(self) -> List[PreflightFinding]:
        return [f for f in self.findings if f.severity == "warning"]

    @property
    def has_errors(self) -> bool:
        return any(f.severity == "error" for f in self.findings)

    def format(self, config: Optional[DeploymentConfig] = None, role: Optional[str] = None) -> str:
        """Render the report as a multi-line string suitable for an error message.

        Parameters
        ----------
        config : DeploymentConfig, optional
            If provided, the formatted output appends a ready-to-paste
            ``GRANT`` block for the deployer role.
        role : str, optional
            Override the role name in the SQL block. Defaults to the
            role observed during preflight.

        Returns
        -------
        str
            A multi-line, paste-ready report. ``"Preflight checks passed."``
            when there are no findings.
        """
        if not self.findings:
            return "Preflight checks passed."
        lines: List[str] = []
        if self.errors:
            lines.append(f"{len(self.errors)} blocking issue(s):")
            for f in self.errors:
                lines.append(f"  [{f.code}] {f.message}")
                if f.fix_sql:
                    for sub in f.fix_sql.splitlines():
                        lines.append(f"      {sub}")
                if f.detail:
                    lines.append(f"      detail: {f.detail}")
        if self.warnings:
            lines.append(f"{len(self.warnings)} warning(s):")
            for f in self.warnings:
                lines.append(f"  [{f.code}] {f.message}")
                if f.fix_sql:
                    for sub in f.fix_sql.splitlines():
                        lines.append(f"      {sub}")
        if config is not None:
            target_role = role or self.role or "<your_role>"
            lines.append("")
            lines.append("Copy-paste the following SQL block to your Snowflake admin to grant the deployer role:")
            lines.append("")
            lines.append(deployer_setup_sql(config, deployer_role=target_role))
        return "\n".join(lines)


class Preflight:
    """Run pre-flight checks against a deployment target.

    Each check is independent — one failure never short-circuits the rest.
    Checks are intentionally read-only (``SELECT``/``SHOW``/``DESCRIBE``)
    so running preflight has no side effects.

    Parameters
    ----------
    session : snowpark.Session
        Snowpark session to probe with. Should already have role/warehouse
        set the same way ``CortexAgentManager`` will use them.
    config : DeploymentConfig
        The intended deployment configuration.
    """

    def __init__(self, session: snowpark.Session, config: DeploymentConfig):
        self._session = session
        self._config = config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> PreflightReport:
        """Run all checks. Never raises; problems land in ``report.findings``.

        Returns
        -------
        PreflightReport
            A report aggregating every finding produced by the individual
            checks. ``report.has_errors`` indicates whether deployment
            should proceed.
        """
        report = PreflightReport()

        try:
            report.role = self._scalar("CURRENT_ROLE()")
            report.user = self._scalar("CURRENT_USER()")
        except Exception as e:
            report.findings.append(PreflightFinding(
                severity="error",
                code="SessionContextUnavailable",
                message="Could not read CURRENT_ROLE() / CURRENT_USER() from the session.",
                detail=str(e),
            ))
            return report

        # Object existence / USAGE
        report.findings.extend(self._check_database_access())
        report.findings.extend(self._check_schema_access())
        report.findings.extend(self._check_warehouse_access())

        # External integrations / repositories
        report.findings.extend(self._check_external_access_integration())

        # Database role memberships (the ones that surface as cryptic
        # "object does not exist" errors during sproc registration)
        report.findings.extend(self._check_database_role(
            "SNOWFLAKE.PYPI_REPOSITORY_USER",
            symptom_hint=(
                "Without it, sproc registration fails with: "
                "'snowflake.snowpark.pypi_shared_repository does not exist'."
            ),
        ))
        report.findings.extend(self._check_database_role(
            "SNOWFLAKE.CORTEX_USER",
            symptom_hint="Required to call Cortex services.",
        ))

        # Schema-level CREATE privileges
        report.findings.extend(self._check_schema_create_privileges())

        # Agent schema (only checked if it differs from the sproc schema)
        if self._config.agent_schema is not None:
            report.findings.extend(self._check_agent_schema_access())

        return report

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def _check_database_access(self) -> List[PreflightFinding]:
        db = self._config.database
        rows, err = self._safe_show(f"SHOW DATABASES LIKE '{db}'")
        if err is not None:
            return [PreflightFinding(
                severity="error",
                code="DatabaseNotAccessible",
                message=f"Database '{db}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON DATABASE {db} TO ROLE <your_role>;",
                detail=err,
            )]
        if not rows:
            return [PreflightFinding(
                severity="error",
                code="DatabaseNotAccessible",
                message=f"Database '{db}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON DATABASE {db} TO ROLE <your_role>;",
            )]
        return []

    def _check_schema_access(self) -> List[PreflightFinding]:
        db, schema = self._config.database, self._config.schema
        rows, err = self._safe_show(f"SHOW SCHEMAS LIKE '{schema}' IN DATABASE {db}")
        if err is not None:
            return [PreflightFinding(
                severity="error",
                code="SchemaNotAccessible",
                message=f"Schema '{db}.{schema}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON SCHEMA {db}.{schema} TO ROLE <your_role>;",
                detail=err,
            )]
        if not rows:
            return [PreflightFinding(
                severity="error",
                code="SchemaNotAccessible",
                message=f"Schema '{db}.{schema}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON SCHEMA {db}.{schema} TO ROLE <your_role>;",
            )]
        return []

    def _check_warehouse_access(self) -> List[PreflightFinding]:
        wh = self._config.warehouse
        if not wh:
            return []
        rows, err = self._safe_show(f"SHOW WAREHOUSES LIKE '{wh}'")
        if err is not None:
            return [PreflightFinding(
                severity="error",
                code="WarehouseNotAccessible",
                message=f"Warehouse '{wh}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON WAREHOUSE {wh} TO ROLE <your_role>;",
                detail=err,
            )]
        if not rows:
            return [PreflightFinding(
                severity="error",
                code="WarehouseNotAccessible",
                message=f"Warehouse '{wh}' does not exist or your role lacks USAGE.",
                fix_sql=f"GRANT USAGE ON WAREHOUSE {wh} TO ROLE <your_role>;",
            )]
        return []

    def _check_external_access_integration(self) -> List[PreflightFinding]:
        eai = self._config.external_access_integration
        rows, err = self._safe_show(f"SHOW EXTERNAL ACCESS INTEGRATIONS LIKE '{eai}'")
        if err is not None:
            return [PreflightFinding(
                severity="error",
                code="ExternalAccessIntegrationUnavailable",
                message=(
                    f"External access integration '{eai}' is not visible to your role. "
                    "Either it does not exist (the RAI Native App setup notebook was never run "
                    "in this account) or your role is missing USAGE on it."
                ),
                fix_sql=(
                    f"-- If the integration exists:\n"
                    f"GRANT USAGE ON INTEGRATION {eai} TO ROLE <your_role>;\n"
                    "-- If not, ask your Snowflake admin to run the RAI Native App\n"
                    "-- install notebook, which creates the integration."
                ),
                detail=err,
            )]
        if not rows:
            return [PreflightFinding(
                severity="error",
                code="ExternalAccessIntegrationUnavailable",
                message=(
                    f"External access integration '{eai}' is not visible to your role. "
                    "Either it does not exist (the RAI Native App setup notebook was never run "
                    "in this account) or your role is missing USAGE on it."
                ),
                fix_sql=(
                    f"-- If the integration exists:\n"
                    f"GRANT USAGE ON INTEGRATION {eai} TO ROLE <your_role>;\n"
                    "-- If not, ask your Snowflake admin to run the RAI Native App\n"
                    "-- install notebook, which creates the integration."
                ),
            )]
        return []

    def _check_database_role(
        self,
        db_role: str,
        symptom_hint: Optional[str] = None,
    ) -> List[PreflightFinding]:
        """Check whether a Snowflake database role is active in the session.

        Strategy:
        1. ``IS_DATABASE_ROLE_IN_SESSION`` — fast, but only checks the
           **primary** role chain. Returns FALSE for db roles activated
           via secondary roles, which is a common production setup.
        2. Fallback: ``SHOW GRANTS OF DATABASE ROLE <db_role>`` and
           cross-reference against ``CURRENT_AVAILABLE_ROLES()`` (which
           includes both primary and secondary roles).

        Reports an error only when *both* checks fail. A "false positive"
        from check (1) is recovered by check (2); a true missing grant
        fails both.
        """
        normalized = db_role.replace("'", "''")
        try:
            value = self._scalar(f"IS_DATABASE_ROLE_IN_SESSION('{normalized}')")
        except Exception as e:
            return [PreflightFinding(
                severity="warning",
                code=f"DatabaseRoleCheckFailed:{db_role}",
                message=f"Could not determine whether database role {db_role} is granted to your session.",
                detail=str(e),
            )]
        if value is True or str(value).upper() == "TRUE":
            return []

        # Primary-chain check failed. Try the secondary-role fallback.
        if self._db_role_in_available_roles(db_role):
            return []

        message = f"Database role {db_role} is not granted to your role."
        if symptom_hint:
            message += " " + symptom_hint
        return [PreflightFinding(
            severity="error",
            code=f"MissingDatabaseRole:{db_role}",
            message=message,
            fix_sql=f"GRANT DATABASE ROLE {db_role} TO ROLE <your_role>;",
        )]

    def _db_role_in_available_roles(self, db_role: str) -> bool:
        """Check whether any role in ``CURRENT_AVAILABLE_ROLES()`` has ``db_role``.

        Returns ``True`` if the database role is reachable through any
        active role (primary OR secondary). Returns ``False`` only when
        we are confident the role chain does not include it.
        """
        # Enumerate roles available in the session.
        try:
            raw = self._scalar("CURRENT_AVAILABLE_ROLES()")
        except Exception:
            return False
        if raw is None:
            return False
        available_roles = _parse_role_list(str(raw))
        if not available_roles:
            return False

        # Look up everyone who has the database role.
        rows, err = self._safe_show(f"SHOW GRANTS OF DATABASE ROLE {db_role}")
        if err is not None:
            # Likely no privilege to even show this — be conservative and
            # treat as "could not verify".
            return False

        grantees = set()
        for row in rows:
            d = _row_to_dict(row)
            granted_to = str(d.get("granted_to", "")).upper()
            grantee_name = str(d.get("grantee_name", "")).upper()
            if granted_to in {"ROLE", "DATABASE_ROLE"} and grantee_name:
                grantees.add(grantee_name)
            if granted_to == "PUBLIC":
                return True

        return any(role in grantees for role in available_roles)

    def _check_schema_create_privileges(self) -> List[PreflightFinding]:
        """Verify CREATE STAGE / PROCEDURE / AGENT on the deployment schema.

        Looks at ``SHOW GRANTS ON SCHEMA``. We only know about direct grants
        to the current role, so absence is reported as a warning rather
        than a hard error — the role chain may still satisfy them.
        """
        db, schema = self._config.database, self._config.schema
        rows, err = self._safe_show(f"SHOW GRANTS ON SCHEMA {db}.{schema}")
        if err is not None:
            return [PreflightFinding(
                severity="warning",
                code="SchemaGrantsUnreadable",
                message=f"Could not read SHOW GRANTS ON SCHEMA {db}.{schema}.",
                detail=err,
            )]

        role = (self._scalar_safe("CURRENT_ROLE()") or "").upper()
        present = set()
        for row in rows:
            d = _row_to_dict(row)
            grantee = str(d.get("grantee_name", "")).upper()
            privilege = str(d.get("privilege", "")).upper()
            if grantee == role:
                present.add(privilege)

        required = []
        if self._config.manage_stage:
            required.append(("CREATE STAGE", "MissingCreateStage"))
        required.append(("CREATE PROCEDURE", "MissingCreateProcedure"))
        # CREATE AGENT only required on the *agent* schema. If agent_schema
        # is unset, agent is created in the same schema.
        if self._config.agent_schema is None:
            required.append(("CREATE AGENT", "MissingCreateAgent"))

        findings: List[PreflightFinding] = []
        for priv, code in required:
            if priv in present:
                continue
            findings.append(PreflightFinding(
                severity="warning",
                code=code,
                message=(
                    f"{priv} on schema {db}.{schema} was not found among direct grants to {role}. "
                    "If the privilege is inherited via a parent role, this is a false alarm; "
                    "otherwise deployment will fail."
                ),
                fix_sql=f"GRANT {priv} ON SCHEMA {db}.{schema} TO ROLE <your_role>;",
            ))
        return findings

    def _check_agent_schema_access(self) -> List[PreflightFinding]:
        """If agent_schema differs from the sproc schema, check it exists + CREATE AGENT."""
        agent_db = self._config.agent_database
        agent_schema = self._config.agent_schema_name
        rows, err = self._safe_show(
            f"SHOW SCHEMAS LIKE '{agent_schema}' IN DATABASE {agent_db}"
        )
        if err is not None or not rows:
            return [PreflightFinding(
                severity="error",
                code="AgentSchemaNotAccessible",
                message=(
                    f"Agent schema '{agent_db}.{agent_schema}' does not exist or "
                    f"your role lacks USAGE."
                ),
                fix_sql=(
                    f"GRANT USAGE ON DATABASE {agent_db} TO ROLE <your_role>;\n"
                    f"GRANT USAGE ON SCHEMA {agent_db}.{agent_schema} TO ROLE <your_role>;\n"
                    f"GRANT CREATE AGENT ON SCHEMA {agent_db}.{agent_schema} TO ROLE <your_role>;"
                ),
                detail=err,
            )]

        rows2, err2 = self._safe_show(f"SHOW GRANTS ON SCHEMA {agent_db}.{agent_schema}")
        if err2 is not None:
            return [PreflightFinding(
                severity="warning",
                code="AgentSchemaGrantsUnreadable",
                message=f"Could not read SHOW GRANTS ON SCHEMA {agent_db}.{agent_schema}.",
                detail=err2,
            )]
        role = (self._scalar_safe("CURRENT_ROLE()") or "").upper()
        has_create_agent = any(
            str(_row_to_dict(r).get("grantee_name", "")).upper() == role
            and str(_row_to_dict(r).get("privilege", "")).upper() == "CREATE AGENT"
            for r in rows2
        )
        if has_create_agent:
            return []
        return [PreflightFinding(
            severity="warning",
            code="MissingCreateAgentOnAgentSchema",
            message=(
                f"CREATE AGENT on {agent_db}.{agent_schema} not found among direct grants to {role}. "
                "If inherited via a parent role this is a false alarm."
            ),
            fix_sql=f"GRANT CREATE AGENT ON SCHEMA {agent_db}.{agent_schema} TO ROLE <your_role>;",
        )]

    # ------------------------------------------------------------------
    # SQL helpers
    # ------------------------------------------------------------------

    def _scalar(self, expression: str) -> Any:
        rows = self._session.sql(f"SELECT {expression}").collect()
        if not rows:
            return None
        return next(iter(_row_to_dict(rows[0]).values()))

    def _scalar_safe(self, expression: str) -> Any:
        try:
            return self._scalar(expression)
        except Exception:
            return None

    def _safe_show(self, sql: str) -> tuple[List[Any], Optional[str]]:
        try:
            return self._session.sql(sql).collect(), None
        except Exception as e:
            return [], f"{type(e).__name__}: {e}"


def _parse_role_list(raw: str) -> set:
    """Parse the JSON-array string returned by ``CURRENT_AVAILABLE_ROLES()``.

    Snowflake returns a JSON-encoded list of role names. Falls back to
    a tolerant comma-split for unexpected encodings.
    """
    import json
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return {str(r).upper() for r in parsed}
    except (ValueError, TypeError):
        pass
    return {part.strip().strip('"').upper() for part in raw.split(",") if part.strip()}


def _row_to_dict(row: Any) -> dict:
    """Snowpark Row → dict, regardless of whether it has ``as_dict``."""
    as_dict = getattr(row, "as_dict", None)
    if callable(as_dict):
        d = as_dict()
        if isinstance(d, dict):
            return {str(k): v for k, v in d.items()}
    if isinstance(row, dict):
        return {str(k): v for k, v in row.items()}
    fields = getattr(row, "_fields", None)
    if fields is not None:
        return {str(k): getattr(row, k) for k in fields}
    return {}
