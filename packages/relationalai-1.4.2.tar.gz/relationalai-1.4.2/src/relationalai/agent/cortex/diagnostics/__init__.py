"""Pre-flight checks, error translation, and setup SQL emitters for Cortex deployment.

These tools let a deployer detect common permission/object problems
*before* attempting deployment, and translate cryptic Snowflake errors
("Object 'X' does not exist or not authorized") into specific named
GRANTs. They exist to collapse the multi-day round trips that happen
when a Snowflake admin has to fix one missing grant at a time.
"""

from .preflight import Preflight, PreflightFinding, PreflightReport
from .error_translate import explain_snowflake_error
from .setup_sql import deployer_setup_sql, si_user_setup_sql
from .collect import collect, DiagnosticsReport

__all__ = [
    "Preflight",
    "PreflightFinding",
    "PreflightReport",
    "explain_snowflake_error",
    "deployer_setup_sql",
    "si_user_setup_sql",
    "collect",
    "DiagnosticsReport",
]
