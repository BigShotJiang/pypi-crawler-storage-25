"""CLI entry: ``python -m relationalai.agent.cortex.diagnostics``.

Connects via Snowpark using flags (or env), then runs both ``Preflight``
and the deeper ``collect`` sweep against the target deployment.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from snowflake.snowpark import Session

from ..deployment_config import DeploymentConfig
from .collect import collect
from .preflight import Preflight


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m relationalai.agent.cortex.diagnostics",
        description=(
            "Probe Snowflake for the objects, grants, and integrations "
            "required to deploy a Cortex agent. Read-only."
        ),
    )
    parser.add_argument("--account", required=True)
    parser.add_argument("--user", required=True)
    parser.add_argument("--authenticator", default="externalbrowser")
    parser.add_argument("--role")
    parser.add_argument("--warehouse")
    parser.add_argument("--database", required=True)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--agent-name", default="DIAG_PROBE")
    parser.add_argument("--agent-schema", default=None,
                        help="Optional fully-qualified agent schema (DB.SCHEMA).")
    parser.add_argument("--stage-name", default="rai_sprocs")
    parser.add_argument("--external-access-integration",
                        default="S3_RAI_INTERNAL_BUCKET_EGRESS_INTEGRATION")
    parser.add_argument("--host", default=None,
                        help="Override Cortex REST host (e.g. for PrivateLink).")
    parser.add_argument("--no-rest", action="store_true",
                        help="Skip Cortex REST API probes.")
    parser.add_argument("--json-out", default=None,
                        help="Path to write the full diagnostic report as JSON.")
    parser.add_argument("--preflight-only", action="store_true",
                        help="Only run Preflight; skip the deep diagnostic sweep.")
    return parser


def _build_session(args: argparse.Namespace) -> Session:
    cfg = {
        "account": args.account,
        "user": args.user,
        "authenticator": args.authenticator,
        "role": args.role,
        "warehouse": args.warehouse,
        "database": args.database,
        "schema": args.schema,
    }
    cfg = {k: v for k, v in cfg.items() if v}
    return Session.builder.configs(cfg).create()


def _build_deployment_config(args: argparse.Namespace) -> DeploymentConfig:
    return DeploymentConfig(
        database=args.database,
        schema=args.schema,
        agent_name=args.agent_name,
        warehouse=args.warehouse,
        stage_name=args.stage_name,
        external_access_integration=args.external_access_integration,
        agent_schema=args.agent_schema,
    )


def main(argv: Optional[list] = None) -> int:
    args = _build_arg_parser().parse_args(argv)
    session = _build_session(args)
    config = _build_deployment_config(args)

    print("## Preflight")
    report = Preflight(session, config).run()
    print(report.format(config=config, role=report.role))

    if args.preflight_only:
        if args.json_out:
            with open(args.json_out, "w", encoding="utf-8") as fh:
                json.dump(
                    {"preflight": [f.__dict__ for f in report.findings]},
                    fh,
                    indent=2,
                    default=str,
                )
            print(f"\nWrote JSON report to {args.json_out}")
        return 1 if report.has_errors else 0

    print("\n## Diagnostics")
    diag = collect(session, config, host=args.host, include_rest=not args.no_rest)
    print(diag.format())

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(
                {
                    "preflight": [f.__dict__ for f in report.findings],
                    "diagnostics": diag.to_dict(),
                },
                fh,
                indent=2,
                default=str,
            )
        print(f"\nWrote JSON report to {args.json_out}")

    return 1 if report.has_errors else 0


if __name__ == "__main__":
    sys.exit(main())
