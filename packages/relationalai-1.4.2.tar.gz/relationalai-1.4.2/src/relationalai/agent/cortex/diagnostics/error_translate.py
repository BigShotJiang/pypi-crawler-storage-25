"""Translate Snowflake error text into specific named GRANT guidance.

The pattern is: Snowflake says
``Object 'X' does not exist or not authorized``, which equally describes
"missing object" and "missing privilege". For known cases we know which
GRANT actually fixes it. ``explain_snowflake_error`` returns one or more
hint strings naming the specific grant, so the deployer-facing diagnostic
points at the missing privilege instead of just listing every
possibility.
"""
from __future__ import annotations

import re
from typing import List, Optional


_ROLE_PLACEHOLDER = "<your_role>"


def explain_snowflake_error(
    err_text: str,
    role: Optional[str] = None,
    external_access_integration: Optional[str] = None,
    artifact_repository: Optional[str] = None,
) -> List[str]:
    """Return human-readable hints for known Snowflake error patterns.

    Parameters
    ----------
    err_text : str
        The raw error string from Snowflake (or a wrapping Python
        exception). Pattern-matched case-insensitively.
    role : str, optional
        Current Snowflake role; used to fill in named GRANT statements.
    external_access_integration : str, optional
        EAI name from ``DeploymentConfig``; used to fill in GRANT USAGE.
    artifact_repository : str, optional
        Artifact repository name from ``DeploymentConfig``; used to
        identify ``pypi_shared_repository`` mentions.

    Returns
    -------
    list of str
        Zero or more hint strings, each a self-contained explanation
        with a copy-pasteable fix. Returns ``[]`` if no patterns match.
    """
    if not err_text:
        return []
    role_name = role or _ROLE_PLACEHOLDER
    text = err_text
    text_lower = text.lower()
    hints: List[str] = []

    # ------------------------------------------------------------------
    # Missing snowflake.pypi_repository_user database role
    # Surfaces as: "snowflake.snowpark.pypi_shared_repository does not exist"
    # ------------------------------------------------------------------
    pypi_patterns = ["pypi_shared_repository", "pypi_repository_user"]
    if (artifact_repository and artifact_repository.lower() in text_lower) or any(
        p in text_lower for p in pypi_patterns
    ):
        hints.append(
            "This error means your role lacks the snowflake.pypi_repository_user "
            "database role, which controls access to the PyPI artifact "
            "repository used to install Python packages in stored procedures.\n"
            f"Fix:  GRANT DATABASE ROLE snowflake.pypi_repository_user TO ROLE {role_name};"
        )

    # ------------------------------------------------------------------
    # Missing external access integration (or USAGE on it)
    # ------------------------------------------------------------------
    eai = external_access_integration or "S3_RAI_INTERNAL_BUCKET_EGRESS_INTEGRATION"
    eai_pattern_hit = (
        eai.lower() in text_lower
        or "external access integration" in text_lower
        or "s3_rai_internal_bucket_egress_integration" in text_lower
    )
    if eai_pattern_hit:
        hints.append(
            f"This error means the external access integration '{eai}' is unavailable. "
            "Two possible causes:\n"
            f"  (a) The integration does not exist. The RAI Native App install\n"
            "      notebook creates it; ask your Snowflake admin to run that\n"
            "      notebook in this account.\n"
            "  (b) The integration exists but your role lacks USAGE.\n"
            f"      Fix:  GRANT USAGE ON INTEGRATION {eai} TO ROLE {role_name};\n\n"
            "Run manager.preflight() to disambiguate."
        )

    # ------------------------------------------------------------------
    # Missing snowflake.cortex_user database role (rarer — usually granted
    # to PUBLIC by default — but worth catching)
    # ------------------------------------------------------------------
    if "cortex_user" in text_lower or re.search(r"cortex.*not authorized", text_lower):
        hints.append(
            "This error suggests your role lacks the snowflake.cortex_user "
            "database role, which is required to call Cortex services.\n"
            f"Fix:  GRANT DATABASE ROLE snowflake.cortex_user TO ROLE {role_name};"
        )

    # ------------------------------------------------------------------
    # CREATE STAGE / PROCEDURE / AGENT
    # ------------------------------------------------------------------
    if "insufficient privileges" in text_lower or "does not have privilege" in text_lower:
        if "stage" in text_lower or "create stage" in text_lower:
            hints.append(
                "This error indicates your role lacks CREATE STAGE on the target schema.\n"
                f"Fix:  GRANT CREATE STAGE ON SCHEMA <db>.<schema> TO ROLE {role_name};\n"
                "Or set manage_stage=False on DeploymentConfig to use an existing stage."
            )
        if "procedure" in text_lower:
            hints.append(
                "This error indicates your role lacks CREATE PROCEDURE on the target schema.\n"
                f"Fix:  GRANT CREATE PROCEDURE ON SCHEMA <db>.<schema> TO ROLE {role_name};"
            )
        if "agent" in text_lower:
            hints.append(
                "This error indicates your role lacks CREATE AGENT on the target schema.\n"
                f"Fix:  GRANT CREATE AGENT ON SCHEMA <db>.<schema> TO ROLE {role_name};"
            )

    # ------------------------------------------------------------------
    # RAI Native App application role
    # ------------------------------------------------------------------
    if "relationalai.rai_user" in text_lower or "rai_developer" in text_lower:
        hints.append(
            "This error suggests your role lacks access to the RAI Native App. "
            "The Cortex sproc imports `relationalai`, which talks to the Native "
            "App via the `relationalai.rai_user` application role.\n"
            f"Fix:  GRANT APPLICATION ROLE relationalai.rai_user TO ROLE {role_name};\n"
            "If the application role does not exist, the RAI Native App has not "
            "been installed in this account."
        )

    return hints
