"""Deep diagnostic sweep for Cortex agent deployment failures.

Where ``Preflight`` is proactive (run before deploy), this module is for
*after* a failure: it surveys session context, target objects, role
grants, and the Cortex Agent REST API in detail so the output can be
captured and shared with support.

Programmatic use:

    from relationalai.agent.cortex.diagnostics.collect import collect

    report = collect(session, config, host=None, create_probe=False)
    print(report.format())

CLI use:

    python -m relationalai.agent.cortex.diagnostics \\
        --account ... --user ... --role ... --warehouse ... \\
        --database ... --schema ... --agent ...
"""
from __future__ import annotations

import importlib.metadata
import json
import platform
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from urllib.parse import quote

from snowflake import snowpark

from ..deployment_config import DeploymentConfig


@dataclass
class ProbeResult:
    """Outcome of a single SQL or REST probe."""
    ok: bool
    value: Any = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"ok": self.ok, "value": self.value, "error": self.error}


@dataclass
class DiagnosticsReport:
    environment: Dict[str, Any] = field(default_factory=dict)
    sql_context: Dict[str, Any] = field(default_factory=dict)
    connection_host: Optional[str] = None
    target_objects: Dict[str, Any] = field(default_factory=dict)
    relevant_grants: List[Dict[str, Any]] = field(default_factory=list)
    schema_grants: List[Dict[str, Any]] = field(default_factory=list)
    rest_results: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "environment": self.environment,
            "sql_context": self.sql_context,
            "connection_host": self.connection_host,
            "target_objects": self.target_objects,
            "relevant_grants": self.relevant_grants,
            "schema_grants": self.schema_grants,
            "rest_results": self.rest_results,
        }

    def format(self) -> str:
        return json.dumps(self.to_dict(), indent=2, default=str)


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

def _quote_ident(identifier: str) -> str:
    return '"' + identifier.replace('"', '""') + '"'


def _schema_fqn(database: str, schema: str) -> str:
    return f"{_quote_ident(database)}.{_quote_ident(schema)}"


def _row_to_dict(row: Any) -> Dict[str, Any]:
    as_dict = getattr(row, "as_dict", None)
    if callable(as_dict):
        d = as_dict()
        if isinstance(d, dict):
            return {str(k): v for k, v in d.items()}
    if isinstance(row, dict):
        return {str(k): v for k, v in row.items()}
    return {}


def _sql(session: snowpark.Session, query: str) -> ProbeResult:
    try:
        rows = session.sql(query).collect()
        return ProbeResult(ok=True, value=[_row_to_dict(r) for r in rows])
    except Exception as e:
        return ProbeResult(ok=False, error=f"{type(e).__name__}: {e}")


def _sql_scalar(session: snowpark.Session, expression: str) -> ProbeResult:
    result = _sql(session, f"SELECT {expression}")
    if not result.ok:
        return result
    rows = result.value or []
    if not rows:
        return ProbeResult(ok=True, value=None)
    return ProbeResult(ok=True, value=next(iter(rows[0].values())))


def _package_version(name: str) -> Optional[str]:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _filter_relevant_grants(
    rows: List[Dict[str, Any]],
    database: str,
    schema: str,
) -> List[Dict[str, Any]]:
    schema_name = f"{database}.{schema}".upper()
    important_names = {
        database.upper(),
        schema_name,
        "SNOWFLAKE.CORTEX_USER",
        "SNOWFLAKE.PYPI_REPOSITORY_USER",
        "SNOWFLAKE.AI_OBSERVABILITY_EVENTS_LOOKUP",
    }
    important_privileges = {
        "USAGE",
        "CREATE AGENT",
        "CREATE PROCEDURE",
        "CREATE STAGE",
        "USE AI FUNCTIONS",
    }
    relevant = []
    for row in rows:
        normalized = {str(k).lower(): v for k, v in row.items()}
        name = str(normalized.get("name", "")).upper()
        privilege = str(normalized.get("privilege", "")).upper()
        granted_on = str(normalized.get("granted_on", "")).upper()
        if (
            name in important_names
            or privilege in important_privileges
            or granted_on in {"DATABASE_ROLE", "APPLICATION_ROLE"}
        ):
            relevant.append(row)
    return relevant


def _redact_headers(headers: Dict[str, str]) -> Dict[str, str]:
    redacted = dict(headers)
    if "Authorization" in redacted:
        redacted["Authorization"] = "Snowflake Token=<redacted>"
    return redacted


def _agent_path(database: str, schema: str) -> str:
    return f"/api/v2/databases/{quote(database, safe='')}/schemas/{quote(schema, safe='')}/agents"


# ----------------------------------------------------------------------
# Main collection logic
# ----------------------------------------------------------------------

def collect(
    session: snowpark.Session,
    config: DeploymentConfig,
    *,
    host: Optional[str] = None,
    include_rest: bool = True,
) -> DiagnosticsReport:
    """Collect a diagnostic report for a Cortex deployment target.

    Read-only — never creates or drops resources.

    Parameters
    ----------
    session : snowpark.Session
        Connected Snowpark session.
    config : DeploymentConfig
        Deployment configuration whose targets to probe.
    host : str, optional
        Override the Cortex REST host (e.g. for unusual PrivateLink setups).
    include_rest : bool
        Whether to probe the Cortex Agent REST API. Default ``True``.

    Returns
    -------
    DiagnosticsReport
        A report aggregating environment, SQL context, target object
        existence, relevant grants, and (optionally) REST probe results.
    """
    report = DiagnosticsReport()

    # Environment
    report.environment = {
        "python": sys.version,
        "platform": platform.platform(),
        "relationalai": _package_version("relationalai"),
        "snowflake-snowpark-python": _package_version("snowflake-snowpark-python"),
        "snowflake-connector-python": _package_version("snowflake-connector-python"),
        "requests": _package_version("requests"),
    }

    # SQL context
    context_exprs = {
        "CURRENT_VERSION": "CURRENT_VERSION()",
        "CURRENT_ACCOUNT": "CURRENT_ACCOUNT()",
        "CURRENT_REGION": "CURRENT_REGION()",
        "CURRENT_USER": "CURRENT_USER()",
        "CURRENT_ROLE": "CURRENT_ROLE()",
        "CURRENT_DATABASE": "CURRENT_DATABASE()",
        "CURRENT_SCHEMA": "CURRENT_SCHEMA()",
        "CURRENT_WAREHOUSE": "CURRENT_WAREHOUSE()",
    }
    sql_context: Dict[str, Any] = {}
    for name, expr in context_exprs.items():
        result = _sql_scalar(session, expr)
        sql_context[name] = result.value if result.ok else {"error": result.error}
    report.sql_context = sql_context
    report.connection_host = getattr(session.connection, "host", None)

    # Target objects
    use_db = _sql(session, f"USE DATABASE {_quote_ident(config.database)}")
    use_schema = _sql(session, f"USE SCHEMA {_schema_fqn(config.database, config.schema)}")
    stage = _sql(
        session,
        f"SHOW STAGES LIKE '{config.stage_name}' "
        f"IN SCHEMA {_schema_fqn(config.database, config.schema)}",
    )
    procedures = _sql(
        session,
        f"SHOW PROCEDURES LIKE 'RAI_%' "
        f"IN SCHEMA {_schema_fqn(config.database, config.schema)}",
    )
    agents = _sql(
        session,
        f"SHOW AGENTS IN SCHEMA "
        f"{_schema_fqn(config.agent_database, config.agent_schema_name)}",
    )
    eai = _sql(
        session,
        f"SHOW EXTERNAL ACCESS INTEGRATIONS LIKE '{config.external_access_integration}'",
    )
    report.target_objects = {
        "use_database": use_db.to_dict(),
        "use_schema": use_schema.to_dict(),
        "stage": stage.to_dict(),
        "procedures": procedures.to_dict(),
        "agents": agents.to_dict(),
        "external_access_integration": eai.to_dict(),
    }

    # Grants
    role = sql_context.get("CURRENT_ROLE")
    if isinstance(role, str):
        grants_to_role = _sql(session, f"SHOW GRANTS TO ROLE {_quote_ident(role)}")
        if grants_to_role.ok:
            report.relevant_grants = _filter_relevant_grants(
                grants_to_role.value or [], config.database, config.schema
            )
    schema_grants = _sql(
        session, f"SHOW GRANTS ON SCHEMA {_schema_fqn(config.database, config.schema)}"
    )
    if schema_grants.ok:
        report.schema_grants = schema_grants.value or []

    # REST probes
    if include_rest:
        report.rest_results = _rest_probes(session, config, host=host)

    return report


def _rest_probes(
    session: snowpark.Session,
    config: DeploymentConfig,
    *,
    host: Optional[str],
) -> List[Dict[str, Any]]:
    try:
        from ..api.client import http_client
    except Exception as e:
        return [{"label": "http_client import", "ok": False, "error": str(e)}]

    try:
        client = http_client(session.connection, host=host)
    except Exception as e:
        return [{"label": "http_client construct", "ok": False, "error": str(e)}]

    path = _agent_path(config.agent_database, config.agent_schema_name)
    out: List[Dict[str, Any]] = []
    try:
        resp = client.get(path)
        headers_str: Dict[str, str] = {
            str(k): str(v) for k, v in dict(client.headers).items()
        }
        out.append({
            "label": "GET agents (default headers)",
            "method": "GET",
            "url": path,
            "headers": _redact_headers(headers_str),
            "ok": 200 <= resp.status_code < 300,
            "status_code": resp.status_code,
            "body": resp.text[:3000],
        })
    except Exception as e:
        out.append({
            "label": "GET agents (default headers)",
            "method": "GET",
            "url": path,
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
        })
    finally:
        try:
            client.close()
        except Exception:
            pass
    return out
