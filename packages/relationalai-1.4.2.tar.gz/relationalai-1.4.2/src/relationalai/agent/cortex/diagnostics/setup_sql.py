"""Generate copy-pasteable Snowflake setup SQL for Cortex deployment.

The block matches the privilege table in the Cortex skill but is
parameterized with the actual deployment values, so the deployer can
hand it to a Snowflake admin verbatim instead of building it from
scratch each time.
"""
from __future__ import annotations

from ..deployment_config import DeploymentConfig


def deployer_setup_sql(
    config: DeploymentConfig,
    deployer_role: str = "<your_role>",
    create_role: bool = False,
) -> str:
    """Emit the GRANT block for the deployer/admin role.

    Parameters
    ----------
    config : DeploymentConfig
        Deployment target. Database/schema/warehouse are interpolated.
    deployer_role : str
        Role to grant to. If left as the placeholder, the script is
        usable as a template.
    create_role : bool
        Prepend ``CREATE ROLE IF NOT EXISTS`` when ``True``.

    Returns
    -------
    str
        A multi-line SQL block ready to paste into a Snowflake worksheet.
    """
    lines = []
    lines.append("-- Cortex deployer role setup")
    if create_role:
        lines.append(f"CREATE ROLE IF NOT EXISTS {deployer_role};")
    # Native App access (use application role directly, not the convenience
    # rai_developer aggregator role — it may not exist on every account)
    lines.append(
        f"GRANT APPLICATION ROLE relationalai.rai_user TO ROLE {deployer_role};"
    )
    lines.append(f"GRANT DATABASE ROLE snowflake.cortex_user           TO ROLE {deployer_role};")
    lines.append(f"GRANT DATABASE ROLE snowflake.pypi_repository_user  TO ROLE {deployer_role};")
    lines.append(
        f"GRANT APPLICATION ROLE snowflake.ai_observability_events_lookup "
        f"TO ROLE {deployer_role};"
    )
    lines.append(f"GRANT USAGE ON DATABASE {config.database} TO ROLE {deployer_role};")
    lines.append(
        f"GRANT USAGE ON SCHEMA {config.database}.{config.schema} TO ROLE {deployer_role};"
    )
    if config.manage_stage:
        lines.append(
            f"GRANT CREATE STAGE     ON SCHEMA {config.database}.{config.schema} "
            f"TO ROLE {deployer_role};"
        )
    lines.append(
        f"GRANT CREATE PROCEDURE ON SCHEMA {config.database}.{config.schema} "
        f"TO ROLE {deployer_role};"
    )
    if config.agent_schema is None:
        lines.append(
            f"GRANT CREATE AGENT     ON SCHEMA {config.database}.{config.schema} "
            f"TO ROLE {deployer_role};"
        )
    else:
        lines.append(
            f"GRANT USAGE ON DATABASE {config.agent_database} TO ROLE {deployer_role};"
        )
        lines.append(
            f"GRANT USAGE ON SCHEMA {config.agent_database}.{config.agent_schema_name} "
            f"TO ROLE {deployer_role};"
        )
        lines.append(
            f"GRANT CREATE AGENT ON SCHEMA "
            f"{config.agent_database}.{config.agent_schema_name} TO ROLE {deployer_role};"
        )
    if config.warehouse:
        lines.append(
            f"GRANT USAGE ON WAREHOUSE {config.warehouse} TO ROLE {deployer_role};"
        )
    lines.append(
        f"GRANT USAGE ON INTEGRATION {config.external_access_integration} "
        f"TO ROLE {deployer_role};"
    )
    lines.append(
        "-- Note: the external access integration above is created by Step 4"
    )
    lines.append(
        "-- of the RAI Native App install notebook (Warehouse Notebooks subsection)."
    )
    lines.append(
        "-- If your admin says it does not exist, that step has not been run."
    )
    return "\n".join(lines)


def si_user_setup_sql(
    config: DeploymentConfig,
    si_role: str = "<si_user_role>",
    create_role: bool = False,
) -> str:
    """Emit the GRANT block for an SI (Snowflake Intelligence) end-user role.

    SI users execute the deployed sprocs under CALLER'S RIGHTS, so they
    need their own copy of these grants — distinct from what the deployer
    needs to deploy.

    Returns
    -------
    str
        A multi-line SQL block ready to paste into a Snowflake worksheet.
    """
    lines = []
    lines.append("-- Cortex SI-user role setup")
    if create_role:
        lines.append(f"CREATE ROLE IF NOT EXISTS {si_role};")
    lines.append(f"GRANT APPLICATION ROLE relationalai.rai_user TO ROLE {si_role};")
    lines.append(f"GRANT DATABASE ROLE snowflake.cortex_user           TO ROLE {si_role};")
    lines.append(f"GRANT DATABASE ROLE snowflake.pypi_repository_user  TO ROLE {si_role};")
    lines.append(
        f"GRANT USAGE ON INTEGRATION {config.external_access_integration} "
        f"TO ROLE {si_role};"
    )
    lines.append(f"GRANT USAGE ON DATABASE {config.database} TO ROLE {si_role};")
    lines.append(
        f"GRANT USAGE ON SCHEMA {config.database}.{config.schema} TO ROLE {si_role};"
    )
    lines.append(
        f"GRANT SELECT ON ALL TABLES IN SCHEMA {config.database}.{config.schema} "
        f"TO ROLE {si_role};"
    )
    lines.append(
        f"GRANT EXECUTE ON ALL PROCEDURES IN SCHEMA {config.database}.{config.schema} "
        f"TO ROLE {si_role};"
    )
    if config.warehouse:
        lines.append(f"GRANT USAGE ON WAREHOUSE {config.warehouse} TO ROLE {si_role};")
    if config.agent_schema is not None:
        lines.append(
            f"GRANT USAGE ON DATABASE {config.agent_database} TO ROLE {si_role};"
        )
        lines.append(
            f"GRANT USAGE ON SCHEMA {config.agent_database}.{config.agent_schema_name} "
            f"TO ROLE {si_role};"
        )
    return "\n".join(lines)
