"""
The ``cortex_agent_manager`` module provides a unified interface for managing
Cortex agents with RAI-powered tools.
"""
from typing import Callable, List, Tuple, Optional

from snowflake import snowpark

from relationalai.util.docutils import include_in_docs
from relationalai.util.error import exc, Part, RAIException
from relationalai.observability.tracing import span

from .api.agent import CortexAgentApi
from .chat import CortexAgentChat
from .cortex_tool_resources import CortexToolResources
from .deployment_config import DeploymentConfig, DeploymentStatus
from .api.client import http_client
from .diagnostics import (
    Preflight,
    PreflightReport,
    deployer_setup_sql,
    explain_snowflake_error,
    si_user_setup_sql,
)

__include_in_docs__ = True


@include_in_docs
class CortexAgentManager:
    """Deploy and manage Cortex AI agents powered by RAI semantic models.

    Handles the full lifecycle of a Snowflake Cortex agent that powers a
    Snowflake Intelligence (SI) experience. Non-technical SI users interact
    with the agent through the SI UI; this class is for the deployer/admin
    who creates and maintains the agent behind it.

    Managed Snowflake resources
    ---------------------------
    - **Stage** (``rai_sprocs`` by default): Stores sproc code and
      dependencies. Created/dropped automatically when ``manage_stage=True``.
    - **Stored procedures**: Four CALLER'S RIGHTS sprocs that power the
      agent's RAI tools: ``RAI_DISCOVER_MODELS``, ``RAI_VERBALIZE_MODEL``,
      ``RAI_EXPLAIN_CONCEPT``, and ``RAI_QUERY_MODEL`` (PREVIEW).
    - **Cortex agent**: The agent registered in the target database/schema,
      visible in the Snowflake Intelligence UI.

    Required privileges
    -------------------
    Some installations bundle most of these into a convenience role like
    ``rai_developer``. The lists below name the underlying privileges
    directly so they apply regardless of whether the convenience role
    exists. See ``manager.print_setup_sql()`` for a paste-ready GRANT
    block parameterized with the actual deployment.

    The deployer's role (the session's active role) must have:

    - ``CREATE STAGE`` on the target schema (if ``manage_stage=True``).
    - ``CREATE PROCEDURE`` on the target schema.
    - ``CREATE AGENT`` on the target schema (or on ``agent_schema`` if set).
    - ``USE AI FUNCTIONS`` on the account (granted to PUBLIC by default).
    - Database role ``snowflake.cortex_user`` (granted to PUBLIC by default).
    - Database role ``snowflake.pypi_repository_user``.
    - Application role ``snowflake.ai_observability_events_lookup``.
    - Application role ``relationalai.rai_user`` (RAI Native App access).
    - ``USAGE`` on the external access integration
      (``S3_RAI_INTERNAL_BUCKET_EGRESS_INTEGRATION`` by default).
    - ``USAGE`` on the target database, schema, and warehouse.

    SI end-users need (sprocs run with CALLER'S RIGHTS, so the SI user's
    own role is what matters at query time):

    - ``USAGE`` on the warehouse specified in ``DeploymentConfig``.
    - ``USE AI FUNCTIONS`` on the account (granted to PUBLIC by default).
    - Database role ``snowflake.cortex_user`` (granted to PUBLIC by default).
    - Database role ``snowflake.pypi_repository_user``.
    - Application role ``relationalai.rai_user``.
    - ``USAGE`` on the external access integration.
    - ``USAGE`` on the database and schema containing the agent.
    - ``SELECT`` on tables accessed by the model.
    - ``EXECUTE`` on the stored procedures.

    Parameters
    ----------
    session : snowpark.Session
        Authenticated ``snowpark.Session`` with access to the target database
        and schema.
    config : DeploymentConfig
        Configuration specifying where and how to deploy the agent.
    host : str, optional
        Override for the Cortex REST API base URL. Accepts a bare hostname
        (e.g. ``amd01.east-us-2.azure.snowflakecomputing.com``) or a full
        URL with scheme. When omitted, the host is derived from the
        Snowflake connection. Use this when the auto-detected host isn't
        reachable (e.g. unusual regional/PrivateLink setups).

    Examples
    --------

    >>> session = create_config().get_session(SnowflakeConnection)
    >>> manager = CortexAgentManager(
    ...     session=session,
    ...     config=DeploymentConfig(
    ...         agent_name="EXAMPLE_CORTEX",
    ...         database="EXAMPLE",
    ...         schema="CORTEX",
    ...         warehouse="DEMOWAREHOUSE",
    ...     ),
    ... )
    >>> def init_tools(model):
    ...     init_model(model)
    ...     return ToolRegistry().add(
    ...         model=model, description="Customers and orders")
    >>> manager.deploy(
    ...     init_tools=init_tools, imports=discover_imports())
    """

    def __init__(
        self,
        session: snowpark.Session,
        config: DeploymentConfig,
        host: Optional[str] = None,
    ):
        self._config = config
        self._session = session

        # Note: we deliberately do NOT call use_database / use_schema here.
        # Those calls fail if the role lacks USAGE — and a hard failure in
        # __init__ would short-circuit the consolidated preflight report.
        # Preflight handles missing-USAGE detection; deploy() calls
        # use_database / use_schema after preflight passes.

        self._conn = session.connection
        self._http_client = http_client(self._conn, host=host)

        # Pass database/schema explicitly so the resource layer doesn't need
        # the session to be already pointed at them.
        self._resources = CortexToolResources(
            session=self._session,
            stage_name=config.stage_name,
            manage_stage=config.manage_stage,
            database=config.database,
            schema=config.schema,
        )
        self._api = CortexAgentApi(self._http_client)

        self._agent_spec: Optional[CortexAgentApi.AgentSpec] = None

    @include_in_docs
    def preflight(self) -> PreflightReport:
        """Probe Snowflake for required objects and grants without deploying.

        Runs the same set of read-only checks that ``deploy()`` runs
        before attempting to create resources. Use this to surface every
        missing grant up front and hand a single fix-list to a Snowflake
        admin, instead of round-tripping one error at a time.

        Returns
        -------
        PreflightReport
            A report whose ``errors`` list collects blocking issues and
            whose ``format(config=manager.config)`` renders a paste-ready
            diagnostic with a SQL fix block.
        """
        return Preflight(self._session, self._config).run()

    @include_in_docs
    def print_setup_sql(
        self,
        deployer_role: str = "<your_role>",
        si_role: Optional[str] = None,
        create_role: bool = False,
    ) -> str:
        """Return a copy-pasteable SQL block granting the required privileges.

        The block matches the privilege table in the Cortex skill but is
        parameterized with this manager's actual database, schema,
        warehouse, agent_schema, and external_access_integration.

        Parameters
        ----------
        deployer_role : str
            Name of the deployer role. Defaults to a placeholder so
            callers can render a template.
        si_role : str, optional
            If given, also emit the SI-user GRANT block. Default: just
            the deployer block.
        create_role : bool
            Prepend ``CREATE ROLE IF NOT EXISTS`` for each role.

        Returns
        -------
        str
            A SQL block ready to paste into a Snowflake worksheet.
        """
        out = [deployer_setup_sql(self._config, deployer_role=deployer_role, create_role=create_role)]
        if si_role is not None:
            out.append("")
            out.append(si_user_setup_sql(self._config, si_role=si_role, create_role=create_role))
        return "\n".join(out)

    @include_in_docs
    def deploy(
        self,
        init_tools: Callable,  # Callable[[Model], ToolRegistry]
        imports: List[Tuple[str, str]],
        base_agent_spec: Optional[CortexAgentApi.AgentSpec] = None,
        extra_packages: Optional[List[str]] = None,
        skip_preflight: bool = False,
    ) -> CortexAgentApi.AgentSpec:
        """Deploy the agent and all required Snowflake resources.

        Creates a stage (if ``manage_stage=True``), registers RAI tool stored
        procedures, and deploys the Cortex agent. On failure, attempts cleanup
        of partially deployed resources before raising.

        Parameters
        ----------
        init_tools : Callable
            Callable returning a ``ToolRegistry``. Two forms are supported:

            **Recommended (0-param):** Import your model definition code
            inside the function body. The import must happen inside
            ``init_tools`` so the ``Model`` is created within the sproc's
            active Snowpark session::

                def init_tools():
                    from myproject.model import core
                    return ToolRegistry().add(
                        model=core.model, description='...')

            **Legacy (1-param):** Accept a ``Model`` from the framework::

                def init_tools(model):
                    return ToolRegistry().add(
                        model=model, description='...')

        imports : list of tuple of (str, str)
            Project code to upload to Snowflake. Use ``discover_imports()``
            for automatic recursive discovery. Format: list of
            ``(source_path, module_name)`` tuples.
        base_agent_spec : CortexAgentApi.AgentSpec, optional
            Base agent spec to extend with RAI tools. Default: ``None``
            (creates a new spec).
        extra_packages : list of str, optional
            Additional PyPI packages for the sproc environment.
            ``relationalai`` is included automatically.

        Returns
        -------
        CortexAgentApi.AgentSpec
            The deployed agent specification.

        Raises
        ------
        RAIException
            If deployment fails at any stage.
        """
        with span("cortex.deploy"):
            if not skip_preflight:
                report = self.preflight()
                if report.has_errors:
                    exc(
                        "PreflightFailed",
                        "Cortex deployment cannot proceed — pre-flight checks found "
                        f"{len(report.errors)} blocking issue(s).",
                        [report.format(config=self._config, role=report.role)],
                    )

            # Sproc registration needs the session pointed at the target
            # database/schema. Wrap each call so that failures here (e.g.
            # when skip_preflight=True bypassed the upfront probe) produce a
            # specific named GRANT instead of Snowflake's generic
            # "Object does not exist, or operation cannot be performed".
            self._use_database_or_raise()
            self._use_schema_or_raise()

            try:
                # Phase 1: Create Snowflake resources and build agent spec
                orchestration_config: Optional[CortexAgentApi.OrchestrationConfig] = None
                if base_agent_spec is None:
                    # Build orchestration config if budget parameters are specified
                    if self._config.budget_seconds is not None or self._config.budget_tokens is not None:
                        budget = CortexAgentApi.BudgetConfig(
                            seconds=self._config.budget_seconds,
                            tokens=self._config.budget_tokens
                        )
                        orchestration_config = CortexAgentApi.OrchestrationConfig(budget=budget)

                    base_agent_spec = CortexAgentApi.AgentSpec.from_dict({
                        "name": self._config.agent_name,
                        "models": {
                            "orchestration": self._config.llm,
                        }
                    })
                    assert base_agent_spec is not None

                    # Set orchestration config if we built one
                    if orchestration_config is not None:
                        base_agent_spec.orchestration = orchestration_config

                self._agent_spec = self._resources.create(
                    init_tools=init_tools,
                    imports=imports,
                    config=self._config,
                    agent_spec=base_agent_spec,
                    extra_packages=extra_packages,
                )

                # Phase 2: Deploy to Cortex
                with span("cortex.deploy.create_agent"):
                    self._api.create(
                        self._config.agent_database,
                        self._config.agent_schema_name,
                        self._agent_spec
                    )

                # Phase 3: Validate deployment
                with span("cortex.deploy.validate"):
                    result = self._api.describe(
                        self._config.agent_database,
                        self._config.agent_schema_name,
                        self._config.agent_name
                    )

                    if result.agent_spec is None:
                        exc("ValidationFailed", "Could not parse Agent description")

                return result.agent_spec

            except RAIException:
                raise
            except Exception as e:
                hints = explain_snowflake_error(
                    str(e),
                    role=self._current_role(),
                    external_access_integration=self._config.external_access_integration,
                    artifact_repository=self._config.artifact_repository,
                )
                parts: List[Part] = list(hints)
                exc("DeploymentFailed", f"Deployment failed: {e}", parts if parts else None)

    @include_in_docs
    def update(
        self,
        init_tools: Callable,
        imports: List[Tuple[str, str]],
        extra_packages: Optional[List[str]] = None,
    ) -> CortexAgentApi.AgentSpec:
        """Update the agent's tools without recreating the agent.

        Recreates stored procedures with updated tool definitions and updates
        the agent configuration in Cortex. The agent name and identity are
        preserved; existing SI conversations are unaffected.

        Parameters
        ----------
        init_tools : Callable
            Updated callable returning a ``ToolRegistry``.
            Same contract as ``deploy()`` — supports both 0-param
            (recommended) and 1-param (legacy) forms.
        imports : list of tuple of (str, str)
            Updated project code. Use ``discover_imports()``.
        extra_packages : list of str, optional
            Updated PyPI package list.

        Returns
        -------
        CortexAgentApi.AgentSpec
            Updated agent specification.

        Raises
        ------
        RAIException
            If agent is not deployed (call ``deploy()`` first).
        """
        with span("cortex.update"):
            if not self.status().fully_deployed():
                exc("NotDeployed", "Agent not deployed. Call deploy() first.")

            # Sproc registration needs the session in the target db/schema.
            self._use_database_or_raise()
            self._use_schema_or_raise()

            # Get current agent spec
            current = self._api.describe(
                self._config.agent_database,
                self._config.agent_schema_name,
                self._config.agent_name
            )

            # Recreate resources with updated tools
            updated_spec = self._resources.create(
                init_tools=init_tools,
                imports=imports,
                config=self._config,
                agent_spec=current.agent_spec,
                extra_packages=extra_packages,
            )

            # Update agent via API
            self._api.update(
                self._config.agent_database,
                self._config.agent_schema_name,
                self._config.agent_name,
                updated_spec
            )

            self._agent_spec = updated_spec
            return updated_spec

    @include_in_docs
    def chat(self) -> CortexAgentChat:
        """Get a programmatic chat interface for the deployed agent.

        Returns a ``CortexAgentChat`` that maintains conversation state across
        multiple ``send()`` calls. This is primarily useful for testing and
        automation -- SI users interact through the Snowflake Intelligence UI.

        Returns
        -------
        CortexAgentChat
            Chat interface instance.

        Raises
        ------
        RAIException
            If agent is not deployed (call ``deploy()`` first).
        """
        if not self.status().fully_deployed():
            exc("NotDeployed", "Agent not deployed. Call deploy() first.")

        return CortexAgentChat(
            client=self._http_client,
            db=self._config.agent_database,
            schema=self._config.agent_schema_name,
            name=self._config.agent_name,
        )

    @include_in_docs
    def status(self) -> DeploymentStatus:
        """Check deployment status of all agent components.

        Queries Snowflake and Cortex to verify existence of the agent, stage,
        and all stored procedures.

        Returns
        -------
        DeploymentStatus
            Use ``fully_deployed()``, ``partially_deployed()``, or ``clean()``
            for quick checks.
        """
        # Check Snowflake resources
        resource_status = self._resources.exists()

        # Check Cortex agent
        agent_exists = False
        try:
            self._api.describe(
                self._config.agent_database,
                self._config.agent_schema_name,
                self._config.agent_name
            )
            agent_exists = True
        except Exception:
            pass

        return DeploymentStatus(
            agent_exists=agent_exists,
            stage_exists=resource_status.stage_exists,
            sprocs=resource_status.sprocs,
        )

    @include_in_docs
    def cleanup(self, silent: bool = True) -> None:
        """Remove all agent resources from Snowflake and Cortex.

        Deletes the Cortex agent, all RAI tool stored procedures, and the
        stage (if ``manage_stage=True``). SI conversation history is
        permanently lost.

        Parameters
        ----------
        silent : bool
            Ignore errors for non-existent resources. Default: ``True``.

        Returns
        -------
        None
        """
        with span("cortex.cleanup"):
            # Delete Cortex agent first
            try:
                self._api.delete(
                    self._config.agent_database,
                    self._config.agent_schema_name,
                    self._config.agent_name,
                    silent=silent
                )
            except Exception:
                if not silent:
                    raise

            # Delete Snowflake resources
            self._resources.cleanup(silent=silent)

            # Close HTTP client to release connection pool resources
            try:
                self._http_client.close()
            except Exception:
                if not silent:
                    raise

            self._agent_spec = None

    def _current_role(self) -> Optional[str]:
        """Return the session's CURRENT_ROLE() if it can be read, else None."""
        try:
            rows = self._session.sql("SELECT CURRENT_ROLE()").collect()
            if rows:
                return next(iter(rows[0].as_dict().values()))
        except Exception:
            pass
        return None

    def _use_database_or_raise(self) -> None:
        """USE DATABASE with a specific named-grant failure mode."""
        try:
            self._session.use_database(self._config.database)
        except Exception as e:
            role_label = self._current_role() or "<your_role>"
            exc(
                "DatabaseNotAccessible",
                f"Cannot USE DATABASE '{self._config.database}': "
                f"the database does not exist or your role lacks USAGE.",
                [
                    f"Fix:  GRANT USAGE ON DATABASE {self._config.database} "
                    f"TO ROLE {role_label};",
                    "Run manager.preflight() to probe all required grants in "
                    "one pass before deploying.",
                    f"Underlying error: {e}",
                ],
            )

    def _use_schema_or_raise(self) -> None:
        """USE SCHEMA with a specific named-grant failure mode."""
        try:
            self._session.use_schema(self._config.schema)
        except Exception as e:
            role_label = self._current_role() or "<your_role>"
            exc(
                "SchemaNotAccessible",
                f"Cannot USE SCHEMA "
                f"'{self._config.database}.{self._config.schema}': "
                f"the schema does not exist or your role lacks USAGE.",
                [
                    f"Fix:  GRANT USAGE ON SCHEMA "
                    f"{self._config.database}.{self._config.schema} "
                    f"TO ROLE {role_label};",
                    "Run manager.preflight() to probe all required grants in "
                    "one pass before deploying.",
                    f"Underlying error: {e}",
                ],
            )

    @property
    def config(self) -> DeploymentConfig:
        """The ``DeploymentConfig`` used to initialize this manager."""
        return self._config

    @property
    def agent_spec(self) -> Optional[CortexAgentApi.AgentSpec]:
        """The deployed ``AgentSpec``, or ``None`` if not yet deployed."""
        return self._agent_spec

    @property
    def is_deployed(self) -> bool:
        """``True`` if fully deployed. Queries Snowflake."""
        return self.status().fully_deployed()
