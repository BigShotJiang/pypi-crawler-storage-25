from dataclasses import MISSING, fields
from typing import Any

from relationalai.util.error import warn


def init_dto(instance: Any, payload: dict[str, Any], positional: tuple[Any, ...] = ()) -> None:
    """Initialize a response DTO from a possibly wider REST payload."""
    raw_payload = payload.pop("raw_payload", None)
    known_fields = {
        field.name: field
        for field in fields(instance)
        if field.name != "raw_payload"
    }
    field_names = list(known_fields)
    if len(positional) > len(field_names):
        raise TypeError(
            f"{type(instance).__name__}.__init__() takes {len(field_names)} "
            f"positional arguments but {len(positional)} were given"
        )
    for name, value in zip(field_names, positional):
        if name in payload:
            raise TypeError(
                f"{type(instance).__name__}.__init__() got multiple values "
                f"for argument {name!r}"
            )
        payload[name] = value

    extra = {key: value for key, value in payload.items() if key not in known_fields}
    missing = []

    for name, field in known_fields.items():
        if name in payload:
            value = payload[name]
        elif field.default is not MISSING:
            value = field.default
        elif field.default_factory is not MISSING:  # type: ignore[attr-defined]
            value = field.default_factory()  # type: ignore[misc]
        else:
            missing.append(name)
            continue
        setattr(instance, name, value)

    if missing:
        plural = "s" if len(missing) > 1 else ""
        missing_args = ", ".join(repr(name) for name in missing)
        raise TypeError(
            f"{type(instance).__name__}.__init__() missing required "
            f"argument{plural}: {missing_args}"
        )

    setattr(instance, "raw_payload", raw_payload if raw_payload is not None else dict(payload))
    if extra:
        extra_names = ", ".join(sorted(extra))
        warn(
            "UnhandledApiAttribute",
            f"{type(instance).__name__} received unhandled attribute(s): {extra_names}. "
            "The full REST payload is available on raw_payload.",
        )
