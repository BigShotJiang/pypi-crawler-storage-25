import requests
from snowflake.connector import SnowflakeConnection

from relationalai.util.docutils import include_in_docs
from relationalai.util.error import exc


class _CortexSession(requests.Session):
    def __init__(self, base_url: str, timeout: int):
        super().__init__()
        self.base_url = base_url
        self._timeout = timeout

    def request(self, method, url, *args, **kwargs):  # type: ignore[override]
        if url and not url.startswith(("http://", "https://")):
            url = f"{self.base_url.rstrip('/')}/{url.lstrip('/')}"
        kwargs.setdefault("timeout", self._timeout)
        return super().request(method, url, *args, **kwargs)


@include_in_docs
def http_client(
    conn: SnowflakeConnection,
    timeout: int = 300,
    host: str | None = None,
) -> requests.Session:
    """Create an authenticated HTTP client for Snowflake Cortex API requests.

    Parameters
    ----------
    conn : SnowflakeConnection
        An active Snowflake connection used to extract the session token.
    timeout : int
        Request timeout in seconds. Default: 300.
    host : str, optional
        Override for the base URL host. Accepts a bare hostname
        (e.g. ``amd01.east-us-2.azure.snowflakecomputing.com``) or a full
        URL with scheme. When omitted, ``conn.host`` is used when it is a
        usable Snowflake hostname; otherwise the URL is built from
        ``CURRENT_ACCOUNT()``.

    Returns
    -------
    requests.Session
        A configured HTTP client with authentication headers and the
        correct Snowflake base URL. Relative URLs passed to the session's
        request methods are joined against the base URL.

    Examples
    --------

    >>> from relationalai.config import Config
    >>> conn = create_config().get_session().connection
    >>> client = http_client(conn)
    """
    base_url = _hostname(conn, host)

    if conn._rest is None:
        exc("SnowflakeConnection", "Connection has no REST client (_rest is None).")
    token_data = conn._rest._token_request('ISSUE')
    if token_data is None:
        exc("SnowflakeConnection", "Token request returned None.")
    token_extract = token_data['data']['sessionToken']
    token = f'\"{token_extract}\"'
    session = _CortexSession(base_url=base_url, timeout=timeout)
    session.headers.update({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f"Snowflake Token={token}",
    })
    return session


def _hostname(conn: SnowflakeConnection, override: str | None = None) -> str:
    if override:
        return _with_scheme(override)

    # Prefer the connector's host. It can be an account alias or org-qualified
    # hostname; deriving a classic account-locator URL from CURRENT_ACCOUNT()
    # can route REST object APIs to a host that returns Snowflake's generic 404.
    host = getattr(conn, "host", None)
    if host and _is_usable_snowflake_host(host):
        return _with_scheme(host)

    # Fallback: build the classic account-locator URL. Works for AWS
    # deployments whose connections were configured with the
    # org-qualified name.
    cursor = conn.cursor()
    if cursor is None:
        exc("SnowflakeConnection", "Could not get cursor from connection.")
    result = cursor.execute("select CURRENT_ACCOUNT()")
    if result is None:
        exc("SnowflakeConnection", "CURRENT_ACCOUNT() query returned None.")
    row = result.fetchone()
    if not row or len(row) != 1:
        exc("SnowflakeConnection", "Could not select CURRENT_ACCOUNT().")
    return f"https://{row[0]}.snowflakecomputing.com"


def _is_usable_snowflake_host(host: str) -> bool:
    if not host.endswith(".snowflakecomputing.com"):
        return False
    # Some Snowflake account identifiers contain underscores. Those are not
    # valid DNS host labels, so keep the CURRENT_ACCOUNT() fallback for them.
    return "_" not in host


def _is_regional_snowflake_host(host: str) -> bool:
    # Regional locator hosts carry a cloud segment (`.aws.`/`.azure.`/`.gcp.`).
    # PrivateLink hosts replace that segment with `.privatelink.`. Both must
    # be used verbatim — the generic `{locator}.snowflakecomputing.com` form
    # won't route PrivateLink traffic and doesn't work for non-default regions.
    if not host.endswith(".snowflakecomputing.com"):
        return False
    markers = ("aws", "azure", "gcp", "privatelink")
    return any(f".{marker}." in host for marker in markers)


def _with_scheme(host: str) -> str:
    if host.startswith("http://") or host.startswith("https://"):
        return host
    return f"https://{host}"
