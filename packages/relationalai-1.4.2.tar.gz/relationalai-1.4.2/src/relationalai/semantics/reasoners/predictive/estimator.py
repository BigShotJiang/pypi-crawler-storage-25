"""GNN estimator for training, loading, registering and predicting with Graph Neural Networks."""

import datetime
import inspect
import re
import sys
import time
from typing import Any, Optional

import json
from snowflake.ml.registry import Registry
from snowflake.snowpark.context import get_active_session

from relationalai.semantics import std
from relationalai.semantics.frontend import core
from relationalai.semantics.frontend.base import MetaRef
from relationalai.semantics.reasoners.graph import Graph
import relationalai.semantics as b

from relationalai_gnns import (
    JobMonitor, JobManager, ModelManager,
    Dataset, OutputConfig, TaskType
)
from relationalai_gnns.common.job_models import JobStatus
from relationalai.util.schema import get_provider
from v0.relationalai.clients.resources.snowflake import Resources as SnowflakeResources

from .task_info import validate_task, _task_train_test_schema_match, fields_of
from .data import (
    collect_all_queries, collect_task_query, PendingTable,
    export_tables_csv, export_tables_snowflake,
    csv_path_to_concept_map, TableType,
)
from .engine import create_gnn_connector, ensure_all_reasoners, ensure_logic_reasoner
from .preparation import prepare_gnn_task_and_tables, create_gnn_dataset, create_gnn_trainer, validate_train_params, validate_fit_params, validate_load_params, validate_time_col, validate_gnn_config, resolve_device
from .property_transformer import PropertyTransformer
from .metamodel_analysis import info_from_edge
from relationalai.semantics.reasoners.prescriptive.problem import _load_data_with_retry
from .utils import get_pipeline_flags
from relationalai.util.docutils import include_in_docs
from relationalai.client.wiring.wiring import default_config

# include this module in the docs
__include_in_docs__ = True


def _maybe_annotate_schema_cache_hint(exc: Exception) -> None:
    """Attach a cache-clearing note to exc if it looks like a schema type-mismatch.

    On Python 3.11+ uses Exception.add_note() so the hint appears after the
    traceback. On older versions prints the hint directly instead.
    """
    parts = [str(exc)]
    for attr in ('report', 'raw_content', 'content', 'message'):
        val = getattr(exc, attr, None)
        if val:
            parts.append(str(val))
    if exc.__cause__:
        parts.append(str(exc.__cause__))
    combined = ' '.join(parts).lower()
    if 'abortreason:runtime error' not in combined and 'unknown base relation' not in combined:
        return

    from relationalai.util.schema import CACHE_PATH

    lines = [
        "Hint: This error may be caused by a stale schema cache.",
        "  If you recently recreated or modified a Snowflake table (e.g. by re-running",
        "  a data-loading script), the cached column types may no longer match the RAI index.",
        "",
        f"  Schema cache: {CACHE_PATH}",
        "  Delete the file to clear all cached schemas.",
        "",
        "  Re-run your script — the schema will be re-fetched and re-indexed automatically.",
        "",
        "  Alternatively, if clearing the cache does not resolve the issue, the RAI engine may",
        "  have stale compiled relations from a previous run. Rename your Model(...) to a new",
        "  name (e.g. append '_v2') to force a fresh index on the engine side.",
    ]

    add_note = getattr(exc, 'add_note', None)
    if add_note is not None:
        add_note('\n'.join(lines))
    else:
        print('\n'.join(lines))


def _stream_logs_formatted(job: 'JobMonitor', path_to_concept: dict[str, str] | None = None) -> None:
    """Stream job logs with cleaner formatting (strips paths, names CSV loads)."""
    _LOG_RE = re.compile(r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d+ - \w+ - )(.*)')
    _CSV_RE = re.compile(r'Successfully loaded CSV file from path: (.+)')
    csv_count = [0]

    def _reformat(line: str) -> str:
        m = _LOG_RE.match(line)
        if not m:
            return line
        prefix, msg = m.group(1), m.group(2)
        csv_m = _CSV_RE.match(msg)
        if csv_m:
            csv_count[0] += 1
            path = csv_m.group(1).strip()
            concept = (path_to_concept or {}).get(path)
            label = concept if concept else f'table ({csv_count[0]})'
            return f'{prefix}Successfully loaded concept: {label}'
        return line

    class _Writer:
        def __init__(self, wrapped):
            self._wrapped = wrapped
            self._buf = ''

        def write(self, text):
            self._buf += text
            while '\n' in self._buf:
                line, self._buf = self._buf.split('\n', 1)
                self._wrapped.write(_reformat(line) + '\n')

        def flush(self):
            self._wrapped.flush()

    old_stdout = sys.stdout
    sys.stdout = _Writer(old_stdout)
    try:
        job.stream_logs()
    finally:
        sys.stdout = old_stdout


def _wait_obtain_model_run_id(train_job: JobMonitor, *, context: str = "proceed") -> str:
    job_status = train_job._wait_for_completion()
    if job_status["status"] != JobStatus.COMPLETED:
        training_error = job_status.get("error", "unknown error")
        raise RuntimeError(
            f"Cannot {context}: the training job failed before completing.\n"
            f"Fix the training error and call gnn.fit() again.\n"
            f"Training error: {training_error}"
        )
    print(f"  ✓ Training job (model_run_id = {train_job.model_run_id}) has completed")
    return train_job.model_run_id

def _validate_snowflake_identifier(value: str, param_name: str) -> None:
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_$]*$', value):
        raise ValueError(
            f"Invalid {param_name}: '{value}'. "
            f"Snowflake identifiers must start with a letter or underscore "
            f"and contain only alphanumeric characters and underscores."
        )


def _prediction_job_error(job_status: dict) -> RuntimeError:
    error_msg = job_status.get("error", "")
    if "expected a non-empty list of Tensors" in error_msg:
        return RuntimeError(
            "Prediction job failed: the test domain produced no valid instances.\n"
            "This usually means the node IDs in your test task table do not exist in "
            "the source concept table (e.g. the test split references IDs outside the "
            "range of the source table). Check that every ID in your test task table "
            "has a matching row in the corresponding source concept table."
        )
    return RuntimeError(f"Prediction job failed: {job_status}")


@include_in_docs
class GNN:
    """Train, load, register and predict with a Graph Neural Network.

    ``GNN`` supports two workflows:

    * **Fit workflow** — provide ``graph``, ``train``, ``validation``, and a
      ``task_type``, then call :meth:`fit` followed by :meth:`predictions`.
    * **Load workflow** — provide a previously trained model via
      ``model_run_id`` **or** the four registry parameters
      (``model_database``, ``model_schema``, ``model_name``,
      ``version_name``), then call :meth:`load` followed by
      :meth:`predictions`.

    In either workflow you can register the trained model in
    the Snowflake Model Registry using the :meth:`register_model` method.

    Parameters
    ----------
    exp_database : str
        Snowflake database for experiment storage.
    exp_schema : str
        Snowflake schema for experiment storage.
    database : str, optional
        Snowflake database to save predictions in.
    schema : str, optional
        Snowflake schema to save predictions in.
    graph : Graph, optional
        The knowledge graph with edges defined.  Required for the fit workflow.
    property_transformer : PropertyTransformer, optional
        Column-level semantic type annotations.  If omitted, all column types are auto-inferred.
    train : Relationship or Fragment, optional
        Training split relationship.  Required for the fit workflow.
    validation : Relationship or Fragment, optional
        Validation split relationship.  Required for the fit workflow.
    source_concept : Concept, optional
        Source concept for the load workflow (inferred from ``train`` in the fit workflow).
    target_concept : Concept, optional
        Target concept for link-prediction tasks in the load workflow (inferred from ``train`` in the fit workflow).
    task_type : str, optional
        One of ``"binary_classification"``,
        ``"multiclass_classification"``,
        ``"multilabel_classification"``, ``"regression"``,
        ``"link_prediction"``, or ``"repeated_link_prediction"``.
        Required for the fit workflow.  In the load workflow, inferred
        automatically from the registered model if not provided.
    eval_metric : str, optional
        Evaluation metric compatible with the chosen ``task_type``
        (e.g. ``"roc_auc"``, ``"accuracy"``, ``"rmse"``,
        ``"link_prediction_precision@5"``).
    use_current_time : bool, optional
        Use the current timestamp as the prediction time.  Default is
        ``True``.
    has_time_column : bool, optional
        Set to ``True`` when the task relationships use the ``at``
        keyword for temporal ordering.  In the load workflow, inferred
        automatically from the registered model if not provided.
    model_database : str, optional
        Snowflake database of a registered model (load workflow).
    model_schema : str, optional
        Snowflake schema of a registered model (load workflow).
    model_name : str, optional
        Name of the registered model (load workflow).
    version_name : str, optional
        Version of the registered model (load workflow).
    model_run_id : str, optional
        Run ID of a previously trained model (load workflow).
    test_batch_size : int, optional
        Batch size used during inference.
    stream_logs : bool, optional
        Stream training logs to stdout.  Default is ``True``.
    extract_embeddings : bool, optional
        Extract node embeddings during prediction.  Default is ``False``.
    dataset_alias : str, optional
        User chosen alias for the dataset.
    parallel_reasoners_init : bool, optional
        Initialize the Predictive and Logic reasoners in parallel. Default is ``True``.
    **train_params
        Additional hyperparameters forwarded to the GNN trainer (e.g.
        ``n_epochs``, ``lr``, ``train_batch_size``, ``device``,
        ``head_layers``).  Ignored in the load workflow.

    Examples
    --------
    Assuming the setup from the module-level Quick Start
    (:mod:`relationalai.semantics.reasoners.predictive`):

    >>> gnn = GNN(
    ...     exp_database="EXPERIMENTS_DB", exp_schema="EXPERIMENTS_SCHEMA",
    ...     graph=gnn_graph, property_transformer=property_transformer,
    ...     source_concept=Students,
    ...     train=Train, validation=Validation,
    ...     task_type="binary_classification",
    ...     eval_metric="roc_auc",
    ...     device="cuda", n_epochs=5,
    ... )
    >>> gnn.fit()
    >>> Students.predictions = gnn.predictions(domain=Test)

    Load a registered model and predict:

    >>> gnn = GNN(
    ...     exp_database="EXPERIMENTS_DB", exp_schema="EXPERIMENTS_SCHEMA",
    ...     model_database="MODELS_DB", model_schema="MODELS_SCHEMA",
    ...     model_name="MY_MODEL", version_name="V1",
    ...     source_concept=Students,
    ... )
    >>> gnn.load()
    >>> Students.predictions = gnn.predictions(domain=Test)
    """

    def __init__(
        self,
        *,
        exp_database: str,
        exp_schema: str,
        database: Optional[str] = None,
        schema: Optional[str] = None,
        graph: Optional[Graph] = None,
        property_transformer: Optional[PropertyTransformer] = None,
        train: Optional[b.Relationship | b.Fragment | b.Chain] = None,
        validation: Optional[b.Relationship | b.Fragment | b.Chain] = None,
        source_concept: Optional[b.Concept] = None,
        target_concept: Optional[b.Concept] = None,  
        task_type: Optional[str] = None,
        eval_metric: Optional[str] = None,
        use_current_time: bool = True,
        has_time_column: Optional[bool] = None,
        model_database: Optional[str] = None,
        model_schema: Optional[str] = None,
        model_name: Optional[str] = None, 
        version_name: Optional[str] = None,
        model_run_id: Optional[str] = None,
        test_batch_size: Optional[int] = None,
        stream_logs: bool = True,
        extract_embeddings: bool = False,
        dataset_alias:Optional[str] = None,
        parallel_reasoners_init: bool = True,
        **train_params: Any
    ) -> None:

        skip_cdc, export_csv = get_pipeline_flags()

        # ── 1. Type checks ────────────────────────────────────────────
        if graph is not None and not isinstance(graph, Graph):
            raise TypeError(f"`graph` must be a Graph or None, got {type(graph).__name__}.")
        if property_transformer is not None and not isinstance(property_transformer, PropertyTransformer):
            raise TypeError(f"`property_transformer` must be a PropertyTransformer or None, got {type(property_transformer).__name__}.")
        if property_transformer is not None and property_transformer._model is not None and graph is not None:
            if property_transformer._model is not graph._model:
                raise ValueError(
                    f"`property_transformer` was built from model '{property_transformer._model.name}' but `graph` uses model "
                    f"'{graph._model.name}'. Pass properties from the same model used by the graph."
                )
        if train is not None and not isinstance(train, (b.Relationship, b.Fragment)):
            raise TypeError(f"`train` must be a Relationship, Fragment, or None, got {type(train).__name__}.")
        if validation is not None and not isinstance(validation, (b.Relationship, b.Fragment)):
            raise TypeError(f"`validation` must be a Relationship, Fragment, or None, got {type(validation).__name__}.")
        if source_concept is not None and not isinstance(source_concept, b.Concept):
            raise TypeError(f"`source_concept` must be a Concept or None, got {type(source_concept).__name__}.")
        if target_concept is not None and not isinstance(target_concept, b.Concept):
            raise TypeError(f"`target_concept` must be a Concept or None, got {type(target_concept).__name__}.")
        if test_batch_size is not None and not isinstance(test_batch_size, int):
            raise TypeError(f"`test_batch_size` must be an int or None, got {type(test_batch_size).__name__}.")
        if dataset_alias is not None and not isinstance(dataset_alias, str):
            raise TypeError(f"`dataset_alias` must be a str or None, got {type(dataset_alias).__name__}.")

        required_str = {
            "exp_database": exp_database,
            "exp_schema": exp_schema,
        }
        for _name, _val in required_str.items():
            if not isinstance(_val, str) or not _val.strip():
                raise TypeError(f"`{_name}` must be a non-empty string, got {_val!r}.")

        optional_str = {
            "database": database,
            "schema": schema,
            "model_database": model_database,
            "model_schema": model_schema,
            "model_name": model_name,
            "version_name": version_name,
            "model_run_id": model_run_id,
        }
        for _name, _val in optional_str.items():
            if _val is not None and (not isinstance(_val, str) or not _val.strip()):
                raise TypeError(f"`{_name}` must be a non-empty string or None, got {_val!r}.")

        if not (skip_cdc and export_csv):
            if database is None:
                raise ValueError("`database` must not be None unless both `SKIP_CDC` env variable is set and `export_csv` is True.")
            if schema is None:
                raise ValueError("`schema` must not be None unless both `SKIP_CDC` env variable is set and `export_csv` is True.")

        # ── 2. Determine workflow mode ────────────────────────────────
        model_parts = [model_database, model_schema, model_name, version_name]
        n_provided = sum(p is not None for p in model_parts)

        if n_provided not in (0, 4):
            raise ValueError(
                "Provide all four of (model_database, model_schema, model_name, version_name) or none of them."
            )
        if n_provided == 4 and model_run_id is not None:
            raise ValueError(
                "Provide either `model_run_id` or (model_database, model_schema, model_name, version_name), not both."
            )

        is_load = n_provided == 4 or model_run_id is not None

        # ── 3. Validate workflow requirements ─────────────────────────
        if not is_load:
            validate_fit_params(graph, train, validation, task_type)
        else:
            validate_load_params(source_concept, target_concept, task_type)

        # Rebuild GNN tables whenever a graph is supplied (fit or load)
        self.create_dataset = graph is not None

        if self.create_dataset:
            if property_transformer is None:
                property_transformer = PropertyTransformer()     # default: auto-infer all column types
            if not is_load and not task_type and eval_metric:
                raise ValueError("`task_type` is required when `eval_metric` is provided.")

        # ── 4. Task validation ────────────────────────────────────────
        self._has_time_column_set = has_time_column is not None
        self._task_type_set = task_type is not None
        self.task_info = validate_task(
            graph, train, validation,
            source_concept, target_concept,
            task_type, eval_metric,
            use_current_time, has_time_column if has_time_column is not None else False,
        )

        # ── 5. Store attributes ───────────────────────────────────────
        self.database     = database.strip().upper() if database else None
        self.schema       = schema.strip().upper() if schema else None
        self.exp_database = exp_database.strip().upper()
        self.exp_schema   = exp_schema.strip().upper()

        self.is_load      = is_load
        self.model_run_id = model_run_id
        self.registered_model_key = None
        self.model_database = model_database.strip().upper() if model_database else None
        self.model_schema   = model_schema.strip().upper()   if model_schema   else None
        self.model_name     = model_name.strip().upper()     if model_name     else None
        self.version_name   = version_name.strip().upper()   if version_name   else None

        if n_provided == 4:
            assert model_name is not None and version_name is not None
            _validate_snowflake_identifier(model_name.strip().upper(), "model_name")
            _validate_snowflake_identifier(version_name.strip().upper(), "version_name")

        self.graph      = graph
        self.train      = train
        self.validation = validation
        self.property_transformer         = property_transformer
        self._model     = graph._model if graph is not None else self.task_info.src_concept._model

        self.export_csv              = export_csv
        self.stream_logs             = stream_logs
        self.skip_cdc                = skip_cdc
        self.extract_embeddings      = extract_embeddings
        self.test_batch_size         = test_batch_size
        self.dataset_alias           = dataset_alias
        self.train_params            = train_params
        self.parallel_reasoners_init = parallel_reasoners_init
        validate_train_params(
            train_params,
            frozenset(inspect.signature(GNN.__init__).parameters) - {"self", "train_params"},
        )

        if is_load and train_params:
            import warnings
            param_list = ", ".join(f"'{k}'" for k in sorted(train_params))
            warnings.warn(
                f"⚠️  Training parameter(s) {param_list} are ignored in a load workflow.\n"
                "These parameters only apply when calling gnn.fit().",
                UserWarning,
                stacklevel=2,
            )

        # Lazy state — populated by _ensure_connector / fit / load / predictions
        self.predictive_reasoner = None
        self.logic_reasoner      = None
        self.gnn_connector    = None
        self.gnn_tables_info  = None
        self.task_data_source = None
        self.dataset          = None
        self.train_job        = None
        self.trainer          = None
        self.job_manager      = None
        self.model_manager    = None
        self.prediction_concept: Optional[b.Concept] = None


    
    def _validate_against_model_metadata(self) -> None:
        """Warn if constructor args differ from what the registered model was trained with.

        Fetches training metadata from the backend (best-effort — silently skips if
        unreachable) and compares task_type, has_time_column, and source_concept.
        """
        import warnings
        from relationalai_gnns.common.job_models import ModelSelectionStrategy

        if self.trainer is None:
            return

        try:
            meta = self.trainer._get_dataset_metadata(
                model_run_id=self.model_run_id or None,
                registered_model_key=self.registered_model_key or None,
                model_selection_strategy=(
                    ModelSelectionStrategy.REGISTERED if self.registered_model_key
                    else ModelSelectionStrategy.CUSTOM_RUN
                ),
            )
        except Exception:
            return  # backend unreachable — skip validation

        task = meta.get("task", {})
        trained_task_type = task.get("task_type")
        trained_time_col  = task.get("time_column")
        trained_has_time  = trained_time_col is not None

        # source_link_to / target_link_to have format "ConceptName.column_name"
        # source_link_to is set for link tasks; target_link_to for node tasks
        trained_is_link = str(trained_task_type) in ("link_prediction", "repeated_link_prediction")
        link_to = task.get("source_link_to" if trained_is_link else "target_link_to")
        trained_concept_name = link_to.split(".")[0] if link_to else None

        # Populate task_type and has_time_column from metadata if not provided by the user
        if trained_task_type and self.task_info.task_type is None:
            from relationalai_gnns import TaskType as _TaskType
            self.task_info.task_type = _TaskType(trained_task_type)

        if not self._has_time_column_set:
            self.task_info.has_time_column = trained_has_time
            if trained_has_time:
                self.task_info.time_column = "timecolumn"

        mismatches = []

        if self._task_type_set and trained_task_type and self.task_info.task_type is not None:
            provided_task_type = self.task_info.task_type
            if hasattr(provided_task_type, "value"):
                provided_task_type = provided_task_type.value
            if str(trained_task_type) != str(provided_task_type):
                mismatches.append(
                    f"task_type: provided '{provided_task_type}' will be ignored — "
                    f"using '{trained_task_type}' from the registered model"
                )
                from relationalai_gnns import TaskType as _TaskType
                self.task_info.task_type = _TaskType(trained_task_type)

        if self._has_time_column_set and trained_has_time != self.task_info.has_time_column:
            mismatches.append(
                f"has_time_column: provided {self.task_info.has_time_column} will be ignored — "
                f"using has_time_column={trained_has_time} from the registered model"
            )
            self.task_info.has_time_column = trained_has_time
            if trained_has_time:
                self.task_info.time_column = "timecolumn"
            else:
                self.task_info.time_column = None

        if trained_concept_name:
            provided_concept = self.task_info.src_concept._name
            if trained_concept_name.lower() != provided_concept.lower():
                mismatches.append(
                    f"source_concept: model was trained on '{trained_concept_name}' "
                    f"but '{provided_concept}' was provided"
                )

        if mismatches:
            warnings.warn(
                "⚠️  Load-time configuration mismatch — the provided constructor arguments "
                "do not match the registered model:\n"
                + "\n".join(f"  - {m}" for m in mismatches)
                + "\n\nPredictions may fail or produce incorrect results.",
                UserWarning,
                stacklevel=3,
            )

    def _prepare_gnn_session(self) -> None:
        """Validate config and ensure reasoners are ready. Called at the start of fit() and load()."""
        cfg = default_config()
        validate_gnn_config(cfg)
        self.train_params = resolve_device(self.train_params, cfg)
        if self.parallel_reasoners_init and (self.predictive_reasoner is None or self.logic_reasoner is None):
            print("\n=== Ensuring reasoners are ready ===")
            t0 = time.time()
            self.predictive_reasoner, self.logic_reasoner = ensure_all_reasoners()
            print(f"=== Reasoners Ready ({time.time() - t0:.2f}s) ===")

    def _ensure_connector(self) -> None:
        """Ensure the Predictive reasoner is READY and create the GNN connector (idempotent)."""
        if self.gnn_connector is not None:
            return
        self.predictive_reasoner, self.gnn_connector = create_gnn_connector(export_csv=self.export_csv)
        self.job_manager   = JobManager(self.gnn_connector)
        self.model_manager = ModelManager(self.gnn_connector)

    def _prepare_dataset(
        self,
        task_relations: dict[str, b.Relationship | b.Fragment | b.Chain | None],
        *,
        include_gnn_tables: bool = True,
    ) -> Dataset | None:
        """Materialize graph tables and build an SDK Dataset.

        Collects task and GNN node/edge queries, then exports them all in
        a single batch call (CSV) or individually (Snowflake).

        Args:
            task_relations: Mapping of split name (e.g. ``"train"``,
                ``"validation"``, ``"test_<timestamp>"``) to the RAI
                relationship or fragment defining that split's rows.
            include_gnn_tables: If ``True`` (default), collect and export GNN
                node/edge tables alongside the task tables. Set to ``False``
                in the predict path when GNN tables are already materialized
                from a prior ``fit()`` call.
        """
        t0 = time.time()
        print("  ➜ Collecting queries...")
        if include_gnn_tables:
            assert self.graph is not None
            assert self.property_transformer is not None
            task_pending, gnn_pending, self.gnn_tables_info = collect_all_queries(
                self.graph.Edge, self.database, self.schema,
                task_relations, self.task_info, self.property_transformer,
            )
        else:
            task_pending = [
                PendingTable(query, table_name, split)
                for split, rel in task_relations.items() if rel is not None
                for query, table_name in [collect_task_query(rel, split, self.database, self.schema, self.task_info)]
            ]
            gnn_pending = []

        assert self.gnn_tables_info is not None
        n_total = len(task_pending) + len(gnn_pending)
        if self.export_csv:
            print(f"  ➜ Exporting {n_total} tables in parallel (CSV)...")
            exported = export_tables_csv(task_pending, gnn_pending, self.gnn_tables_info)
        else:
            assert self.database is not None
            assert self.schema is not None
            assert self.graph is not None
            print(f"  ➜ Exporting {n_total} tables to Snowflake...")
            exported = export_tables_snowflake(
                task_pending, gnn_pending, self.gnn_tables_info,
                self._model, self.graph.Edge._model,
            )
        print(f"  ✓ All tables exported ({time.time() - t0:.2f}s)")
        self.print_semantic_types(self.gnn_tables_info)

        self.task_data_source = {**(self.task_data_source or {}), **exported}

        if not include_gnn_tables:
            return None

        # Build SDK GNNTable objects + task, then wrap in a Dataset.
        # The SDK requires "train"/"validation"/"test" keys. When called from
        # predictions(), the split key is a timestamped alias (e.g. "test_20240421_123456")
        # — normalize it back to "test".
        sdk_task_data_source = {
            ("test" if k.startswith("test") else k): v
            for k, v in self.task_data_source.items()
        }
        self._ensure_connector()
        assert self.gnn_connector is not None
        t0 = time.time()
        gnn_tables, gnn_task = prepare_gnn_task_and_tables(
            self.gnn_connector, self.gnn_tables_info,
            sdk_task_data_source, self.task_info,
        )
        dataset = create_gnn_dataset(self.gnn_connector, gnn_tables, gnn_task, self.dataset_alias)
        print(f"  ✓ Dataset prepared ({time.time() - t0:.2f}s)")
        return dataset

    @include_in_docs
    def fit(self) -> 'GNN':
        """Train the GNN model.

        Materializes graph and task tables, creates a trainer, and submits a
        training job.  If training has already completed or is in progress,
        calling ``fit()`` again is a no-op.

        Returns
        -------
        GNN
            This instance, so that calls can be chained
            (e.g. ``gnn.fit().predictions(domain=Test)``).

        Raises
        ------
        ValueError
            If called in a load workflow.
        """
        if self.is_load:
            raise ValueError("Cannot call fit() in a load workflow.")

        # Idempotent: skip if a job already exists and is not failed
        if self.train_job:
            status = self.train_job.get_status()["status"]
            if status == JobStatus.COMPLETED:
                import warnings
                warnings.warn(
                    "Training has already completed — calling fit() again has no effect.\n"
                    "To retrain, create a new GNN instance.",
                    UserWarning,
                    stacklevel=2,
                )
                return self
            if status in (JobStatus.RUNNING, JobStatus.QUEUED):
                import warnings
                warnings.warn(
                    "A training job is already in progress — calling fit() again has no effect.\n"
                    "Wait for the current job to complete before calling fit() again.",
                    UserWarning,
                    stacklevel=2,
                )
                return self

        validate_time_col(self.task_info.has_time_column, self.property_transformer)

        print("\n=== Start GNN Training ===")

        self._prepare_gnn_session()

        print("Training comprises 3 steps:")
        print("  1. Prepare trainer configuration")
        print("  2. Prepare dataset and GNN tables")
        print("  3. Submit training job and stream logs")

        t_total = time.time()

        # ── Step 1/3: Create trainer ──────────────────────────────────
        print("\nStep 1/3: Preparing trainer configuration...")
        t0 = time.time()
        self._ensure_connector()
        assert self.gnn_connector is not None
        self.trainer = create_gnn_trainer(
            self.gnn_connector, self.exp_database, self.exp_schema, self.train_params,
        )
        print(f"  ✓ Step 1 completed ({time.time() - t0:.2f}s)")

        # ── Step 2/3: Materialize data ────────────────────────────────
        print("\nStep 2/3: Preparing dataset and GNN tables...")
        t0 = time.time()

        try:
            self.dataset = self._prepare_dataset(
                {"train": self.train, "validation": self.validation},
            )
        except Exception as e:
            _maybe_annotate_schema_cache_hint(e)
            raise
        print(f"  ✓ Step 2 completed ({time.time() - t0:.2f}s)")

        # ── Step 3/3: Submit training job ─────────────────────────────
        print("\nStep 3/3: Submitting training job...")
        t0 = time.time()
        assert self.dataset is not None
        self.train_job = self.trainer.fit(dataset=self.dataset)

        job_status = self.train_job.get_status()
        print("  ✓ Training job submitted")
        print(f"     • Job ID:     {self.train_job.job_id}")
        print(f"     • Experiment: {job_status.get('experiment_name', 'N/A')}")
        print(f"     • Location:   {self.exp_database}.{self.exp_schema}")

        if self.stream_logs:
            _path_map = csv_path_to_concept_map(self.gnn_tables_info or {}, self.task_data_source)
            _stream_logs_formatted(self.train_job, path_to_concept=_path_map)
            status = None
            try:
                self._print_train_status(self.train_job.get_status())
            except Exception:
                print("\n ℹ  Could not retrieve final training status.")

        print(f"  ✓ Step 3 completed ({time.time() - t0:.2f}s)")
        if self.stream_logs:
            print(f"\n=== GNN Training Complete ({time.time() - t_total:.2f}s) ===\n")
        else:
            print("\nJob submitted and running in background.\n")
        return self

    @staticmethod
    def _print_train_status(status: dict) -> None:
        """Pretty-print training job results (epochs, losses, metrics)."""
        print("\n ℹ  Train Job Status:")
        print(f"    Job ID:      {status.get('job_id', 'N/A')}")
        print(f"    Status:      {status.get('status', 'N/A')}")
        print(f"    Started at:  {status.get('started_at', 'N/A')}")
        print(f"    Finished at: {status.get('finished_at', 'N/A')}")

        if status.get('status') == 'FAILED':
            error = status.get('error') or status.get('message') or status.get('error_message')
            if error:
                print(f"    🔴 Error:    {error}")

        result = status.get('result', {})
        metrics = result.get('metrics', {})
        best_epoch = result.get('best_epoch')

        if best_epoch is not None:
            print(f"    Best epoch:  {best_epoch}")

        for epoch, epoch_data in metrics.items():
            print(f"\n    Epoch {epoch}:")

            train_loss = epoch_data.get('train_loss')
            val_loss = epoch_data.get('val_loss')
            print(f"      Train loss: {train_loss:.6f}" if train_loss is not None else "      Train loss: N/A")
            print(f"      Val loss:   {val_loss:.6f}" if val_loss is not None else "      Val loss:   N/A")

            val_metrics = epoch_data.get('val_metrics', {})
            if val_metrics:
                print("      Val metrics:")
                for k, v in val_metrics.items():
                    print(f"        {k:<20s} {v:.4f}" if isinstance(v, (int, float)) else f"        {k:<20s} {v}")

            train_metrics = epoch_data.get('train_metrics', {})
            if train_metrics:
                print("      Train metrics:")
                for k, v in train_metrics.items():
                    print(f"        {k:<20s} {v:.4f}" if isinstance(v, (int, float)) else f"        {k:<20s} {v}")
        print()

    @include_in_docs
    def load(self) -> 'GNN':
        """Load a previously trained model for prediction.

        Resolves the model from the Snowflake Model Registry (when
        ``model_database``, ``model_schema``, ``model_name``, and
        ``version_name`` were provided) or by ``model_run_id``, and
        prepares the trainer for prediction.  If the model is already
        loaded, calling ``load()`` again is a no-op.

        Returns
        -------
        GNN
            This instance, so that calls can be chained
            (e.g. ``gnn.load().predictions(domain=Test)``).

        Raises
        ------
        ValueError
            If called in a fit workflow, or if the specified model or
            version does not exist.
        """
        if not self.is_load:
            raise ValueError(
                "cannot perform load() in a fit workflow"
            )
        if self.trainer:
            return self

        self._prepare_gnn_session()
        self._ensure_connector()
        assert self.model_manager is not None

        if self.model_run_id:
            exists = any(
                self.model_run_id in run_ids
                for run_ids in self.model_manager.list_models().values()
            )
            if not exists:
                raise ValueError(f"There is no trained model with model_run_id: {self.model_run_id}")
        else:
            registry = Registry(
                session= get_active_session(),
                database_name=self.model_database,
                schema_name=self.model_schema,
            )
            registered_models = registry.show_models()
            if len(registered_models) == 0:
                raise ValueError(
                    f"There are no registered models in database {self.model_database} in schema {self.model_schema}."
                )
            matching_models = registered_models[registered_models["name"] == self.model_name]

            if not matching_models.empty:
                model_versions = matching_models["versions"].values
                versions_list = json.loads(model_versions[0])
                matching_version = next((v for v in versions_list if v == self.version_name), None)

                if matching_version:
                    self.registered_model_key = f"{self.model_database}.{self.model_schema}.{self.model_name}.{self.version_name}"
                else:
                    raise ValueError(
                        f"There is no version {self.version_name} for trained model {self.model_name}"
                        f" in database {self.model_database} in schema {self.model_schema}."
                    )
            else:
                raise ValueError(
                    f"There is no trained model with model_name: {self.model_name}"
                    f" in database {self.model_database} in schema {self.model_schema}."
                )

        # Prepare TrainerConfig and create Trainer
        assert self.gnn_connector is not None
        self.trainer = create_gnn_trainer(self.gnn_connector, self.exp_database, self.exp_schema, self.train_params)
        self._validate_against_model_metadata()
        return self

    @include_in_docs
    def predictions(
        self,
        domain: b.Relationship | b.Fragment | b.Chain,
    ) -> b.Relationship:
        """Generate predictions on a test domain.

        Materializes the test table, submits a prediction job, and returns a
        :class:`~relationalai.semantics.Relationship` that can be assigned to a
        concept field for downstream querying.

        The prediction attributes available on the returned relationship depend
        on the task type:

        * **Classification**: ``.probs``, ``.predicted_labels``
        * **Regression**: ``.predicted_value``
        * **Link prediction**: ``.rank``, ``.scores``, ``.predicted_<target>``

        Parameters
        ----------
        domain : Relationship or Fragment or Chain
            The test split relationship (e.g. the ``Test`` relationship
            defined during data modeling).

        Returns
        -------
        Relationship
            A prediction relationship to be assigned to the source concept
            (e.g. ``User.predictions = gnn.predictions(domain=Test)``).

        Raises
        ------
        TypeError
            If ``domain`` is not a Relationship, Fragment, or Chain.
        ValueError
            If the model has not been fitted or loaded, or if the test
            domain schema does not match the training schema.
        """
        print("\n=== Start GNN Prediction ===")
        if not isinstance(domain, (b.Relationship, b.Fragment, b.Chain)):
            raise TypeError(
                "The `domain` argument must be a `Relationship`, `Fragment`, or `Chain`,"
                f"but is a `{type(domain).__name__}`."
            )

        domain_fields = fields_of(domain)
        time_field_name = None
        if self.task_info.has_time_column:
            if len(domain_fields) != 2:
                raise ValueError(
                    "Expect arity=2 for test set which has_time_column = True"
                )
            time_field_name = domain_fields[1].name.lower()
            # self.task_info.time_column = domain_fields[1].name.lower()

        if not self.is_load and not self.train_job:
            raise ValueError("Model is not fitted, please call gnn.fit() first.")

        if self.is_load and not self.trainer:
            raise ValueError("Model is not loaded, please call gnn.load()")

        src_field = domain_fields[0]
        src_concept = src_field.type

        if src_concept._id == 0:     # if src_concept is not typed (i.e. is Any)
            src_concept = self.task_info.src_concept
        else:
            if src_concept._name != self.task_info.src_concept._name:
                raise ValueError(
                    f"concept '{src_concept._name}' is not the source concept of this GNN.\n"
                    f"The domain for predictions must use '{self.task_info.src_concept._name}', "
                    f"which is the source concept used during training."
                )

        if self.train is not None and not _task_train_test_schema_match(self.train, domain):
            raise ValueError("training and test sets must have the same schema")
        
        if self.graph is not None:
            concept_info = info_from_edge(self.graph.Edge)
            if src_concept._name not in concept_info.keys():
                raise ValueError(
                    f"The `domain` set {src_field.name} field has type {src_concept._name} is not found in the graph"
                )
        
        timestamp = datetime.datetime.now().strftime("%d%m%Y_%H%M%S")
        out_alias = f"test_{timestamp}"

        # Step 1: Prepare test table
        total_steps = 4 if self.skip_cdc else 3
        print(f"Prediction comprises {total_steps} steps:")
        print("  1. Prepare test table")
        print("  2. Prepare model for prediction")
        print("  3. Submit prediction job and stream logs")
        if self.skip_cdc:
            print("  4. Load results into the logic engine")

        t_total = time.time()

        t0 = time.time()
        print(f"\nStep 1/{total_steps}: Preparing test table...")
        try:
            test_dataset = self._prepare_dataset(
                {out_alias: domain},
                include_gnn_tables=self.is_load and self.create_dataset,
            )
        except Exception as e:
            _maybe_annotate_schema_cache_hint(e)
            raise
        assert self.task_data_source is not None
        test_table_name = self.task_data_source[out_alias]
        print(f"  ✓ Step 1 completed ({time.time() - t0:.2f}s)")

        # Step 2: Wait for training job / prepare model
        t0 = time.time()
        print(f"\nStep 2/{total_steps}: Preparing model for prediction...")
        extra_params = {}
        if self.is_load and self.create_dataset:
            extra_params["dataset"] = test_dataset
        else:
            extra_params["test_table"] = test_table_name
        
        if not self.is_load:   # fit workflow
            if not self.model_run_id:
                assert self.train_job is not None
                self.model_run_id = _wait_obtain_model_run_id(self.train_job, context="generate predictions")
            extra_params["model_run_id"] = self.model_run_id
        else:                  # load workflow
            if self.model_run_id:
                extra_params["model_run_id"] = self.model_run_id
            else:
                extra_params["registered_model_key"] = self.registered_model_key
        print(f"  ✓ Step 2 completed ({time.time() - t0:.2f}s)")

        # Step 3: Submit prediction job
        t0 = time.time()
        if self.skip_cdc:
            extra_params["output_config"] = None
            extra_params["materialize_results"] = False
        else:
            assert self.database is not None
            assert self.schema is not None
            extra_params["output_config"] = OutputConfig.snowflake(
                database_name=self.database,
                schema_name=self.schema
            )
            extra_params["materialize_results"] = True

        # todo: upadte to the new syntax of GNN SDK>1.0        
        if self.test_batch_size is not None:
            extra_params["test_batch_size"] = self.test_batch_size

        print(f"\nStep 3/{total_steps}: Submitting prediction job")
        assert self.trainer is not None
        job = self.trainer.predict(
            output_alias=out_alias,
            extract_embeddings=self.extract_embeddings,
            flatten_output=True,
            align_dtypes=True,
            **extra_params
        )
        
        if self.stream_logs:
            print(f"  ➜ Streaming logs for prediction job {job.job_id}...")
            _path_map = csv_path_to_concept_map(self.gnn_tables_info or {}, self.task_data_source)
            _stream_logs_formatted(job, path_to_concept=_path_map)
        
        job_status = job._wait_for_completion()
        print(f"  ✓ Step 3 completed ({time.time() - t0:.2f}s)")

        # Step 4: Process results
        if job_status['status'] == JobStatus.COMPLETED:
            return self._build_prediction_relation(
                job_status, out_alias, src_field, time_field_name, t_total, total_steps,
            )

        raise _prediction_job_error(job_status)

    def _build_prediction_relation(
        self,
        job_status: dict,
        out_alias: str,
        src_field: b.Field,
        time_field_name: Optional[str],
        t_total: float,
        total_steps: int,
    ) -> b.Relationship:
        """Register GNN results as a typed PyRel Relationship and set self.prediction_concept."""
        mdl = self._model
        t0 = time.time()
        results = job_status['export_paths']

        if self.skip_cdc:
            print(f"\nStep 4/{total_steps}: Loading results into the logic engine")
        else:
            print(f"  ✓ Predictions stored successfully at: {results['predictions']}")

        gnn_results = mdl.Concept(f"GNN_Results_{out_alias}")
        gnn_results_table = mdl.Table(
            self._get_predictions_secure_view_path(job_status) if self.skip_cdc else results['predictions']
        )
        if self.skip_cdc:
            gnn_results_table._skip_cdc = True
            t_start = time.time()
            self.execute_full_data_load(mdl, gnn_results_table)
            print(f"  ✓ Data load for predictions took {time.time() - t_start:.2f} seconds")
        mdl.define(gnn_results.new(gnn_results_table.to_schema()))

        src_col = self.task_info.src_foreign_key.column_name
        keep_cols = {  # all but src_col of gnn_results
            col: getattr(gnn_results, col) for col in gnn_results._relationships.keys()
                                           if col != src_col }

        src_concept_ref = self.task_info.src_concept.ref()
        constraints = [std.common.parse_uuid(getattr(gnn_results, src_col)) == core.cast(MetaRef(core.Hash), src_concept_ref)]

        new_predicted_target_col: Optional[str] = None
        is_link_prediction = self.task_info.task_type in (TaskType.LINK_PREDICTION, TaskType.REPEATED_LINK_PREDICTION)
        if is_link_prediction:
            assert self.task_info.tgt_concept is not None
            tgt_concept_ref = self.task_info.tgt_concept.ref()
            target_col = self.task_info.tgt_concept._name.lower()
            constraints.append(
                std.common.parse_uuid(gnn_results.predicted_labels) == core.cast(MetaRef(core.Hash), tgt_concept_ref)
            )
            del keep_cols['predicted_labels']   # replace predicted_labels with predicted target concept
            new_predicted_target_col = f"predicted_{target_col}"
            keep_cols[new_predicted_target_col] = tgt_concept_ref

        GNNPredictionResult = mdl.Concept(f"GNNPredictions_{out_alias}")

        time_chain = None
        if time_field_name is not None:
            assert self.task_info.time_column is not None
            time_chain = getattr(gnn_results, self.task_info.time_column)
            del keep_cols[self.task_info.time_column]

        for col_name in keep_cols.keys():   # strictly type all properties
            if is_link_prediction and col_name == new_predicted_target_col:
                assert self.task_info.tgt_concept is not None
                setattr(GNNPredictionResult, col_name,
                        mdl.Property(fields=[
                            b.Field(GNNPredictionResult._name, GNNPredictionResult),
                            b.Field(col_name, self.task_info.tgt_concept)]))
            else:
                setattr(GNNPredictionResult, col_name,
                        mdl.Property(fields=[
                            b.Field(GNNPredictionResult._name, GNNPredictionResult),
                            getattr(gnn_results_table, col_name)._fields[1]]))

        self.prediction_concept = GNNPredictionResult

        pred_relation_fields = [b.Field(src_field.name, src_concept_ref._concept)]
        if time_chain is not None:
            assert time_field_name is not None
            pred_relation_fields.append(b.Field(time_field_name, time_chain._next._fields[1].type))
        pred_relation_fields.append(b.Field("prediction", GNNPredictionResult))

        PredRelation = mdl.Relationship(fields=pred_relation_fields, short_name="prediction_relation")
        mdl.define(
            pred := GNNPredictionResult.new(**keep_cols),
            PredRelation(*[a for a in [src_concept_ref, time_chain, pred] if a is not None]),
        ).where(*constraints)

        if self.skip_cdc:
            print(f"  ✓ Created prediction relation: {PredRelation._short_name}")
            print(f"  ✓ Step 4 completed ({time.time() - t0:.2f}s)")

        print(f"\n=== GNN Prediction Complete ({time.time() - t_total:.2f}s) ===\n")

        return PredRelation
    
    @include_in_docs
    def register_model(
        self,
        model_database: str,
        model_schema: str,
        model_name: str,
        version_name: str,
        *,
        comment: Optional[str] = None,
    ) -> None:
        """Register a trained model in the Snowflake Model Registry.

        After registration the model can be loaded in a later session by
        passing the same ``model_database``, ``model_schema``,
        ``model_name``, and ``version_name`` to the :class:`GNN` constructor.

        Parameters
        ----------
        model_database : str
            Snowflake database for the model registry entry.
        model_schema : str
            Snowflake schema for the model registry entry.
        model_name : str
            Name under which to register the model.
        version_name : str
            Version label (e.g. ``"v1"``).
        comment : str, optional
            Free-text comment stored alongside the registry entry.

        Raises
        ------
        ValueError
            If the model is already registered, or has not been fitted /
            loaded.

        Examples
        --------
        >>> gnn.fit()
        >>> gnn.register_model(
        ...     model_database="MODELS_DB", model_schema="MODELS_SCHEMA",
        ...     model_name="STUDENT_CHURN", version_name="V1",
        ...     comment="First baseline model",
        ... )
        """
        _validate_snowflake_identifier(model_name, "model_name")
        _validate_snowflake_identifier(version_name, "version_name")

        if self.registered_model_key:
            if self.is_load:
                raise ValueError(
                    f"Model was loaded from the registry ({self.registered_model_key}) "
                    f"and cannot be re-registered. Re-registering a loaded model under "
                    f"a different version is not supported."
                )
            else:
                raise ValueError(
                    f"Model is already registered as {self.registered_model_key}."
                )
        if self.is_load:
            if not self.trainer:
                raise ValueError("Model is not loaded. Call gnn.load() first.")
            if not self.model_run_id:
                raise ValueError("Cannot register without a model_run_id.")
        else:
            if not self.train_job:
                raise ValueError("Model is not fitted. Call gnn.fit() first.")
            if not self.model_run_id:
                self.model_run_id = _wait_obtain_model_run_id(self.train_job, context="register model")

        db   = model_database.strip().upper()
        sch  = model_schema.strip().upper()
        name = model_name.strip().upper()
        ver  = version_name.strip().upper()

        from relationalai_gnns.common.exceptions import ModelManagerError

        assert self.model_manager is not None
        try:
            self.model_manager.register_model(
                model_run_id=self.model_run_id,
                model_name=name,
                version_name=ver,
                database_name=db,
                schema_name=sch,
                comment=comment,
            )
        except ModelManagerError as e:
            msg = str(e)
            if "already existed" in msg:
                raise ValueError(
                    f"Model '{name}' version '{ver}' already exists in the registry.\n"
                    f"Use a different version_name."
                ) from None
            raise
        self.registered_model_key = f"{db}.{sch}.{name}.{ver}"
    
    @include_in_docs
    def visualize_dataset(self, show_dtypes: bool = False):
        """Visualize the dataset graph.

        Returns a graph object that can be rendered in a notebook to
        inspect the node and edge structure of the prepared dataset.

        Parameters
        ----------
        show_dtypes : bool, optional
            Include column data types in the visualization.  Default is
            ``False``.

        Returns
        -------
        object
            A graph visualization object that can be rendered in a
            notebook.

        Raises
        ------
        ValueError
            If no dataset has been prepared yet (i.e. :meth:`fit` has
            not been called).

        Examples
        --------
        >>> from IPython.display import Image, display
        >>> gnn.fit()
        >>> graph = gnn.visualize_dataset(show_dtypes=True)
        >>> display(Image(graph.create_png()))
        """
        if not self.dataset:
            raise ValueError("No jobs exist yet.")
        return self.dataset.visualize_dataset(show_dtypes=show_dtypes)

    def execute_full_data_load(self, model, tbl):
            """Load a single table into the logic engine using experimental.load_data with retries."""
            resources = get_provider(config=model.config).resources
            if not isinstance(resources, SnowflakeResources):
                raise TypeError(f"Loading data requires Snowflake resources, got {type(resources).__name__}.")
            app_name = resources.get_app_name()
            engine_name = resources.get_default_engine_name()
            ensure_logic_reasoner()
            _load_data_with_retry(
                model,
                resources,
                app_name,
                [tbl._name],
                engine_name,
            )

    @staticmethod
    def print_semantic_types(gnn_tables_info: dict) -> None:
        """Print semantic types grouped by type for each node table in gnn_tables_info."""
        if not gnn_tables_info:
            print("No GNN tables info available.")
            return
        node_tables = {k: v for k, v in gnn_tables_info.items()
                       if v.type != TableType.EDGE and v.semantic_types}
        if not node_tables:
            return
        print("   ── Semantic Types ──────────────────────────────")
        for table_name, table_info in node_tables.items():
            print(f"      {table_name}:")
            by_stype: dict = {}
            for col, stype in table_info.semantic_types.items():
                by_stype.setdefault(stype, []).append(col)
            for stype, cols in by_stype.items():
                print(f"        {stype.value}: {', '.join(cols)}")
            print()
        print("   ────────────────────────────────────────────────")

    def _get_predictions_secure_view_path(self, job_status: dict) -> str:
        """Return the fully qualified secure view path for a job's predictions."""
        job_id = job_status["job_id"].replace("-", "_")
        export_paths = job_status["export_paths"]

        # Get all table paths
        predictions_path = export_paths["predictions"]

        table_name = predictions_path.split(".")[-1]
        view_name = f"job_{job_id}_{table_name}"
        assert self.gnn_connector is not None
        secure_view_path = f"{self.gnn_connector.app_name}.RESULTS.{view_name}"
        return secure_view_path
