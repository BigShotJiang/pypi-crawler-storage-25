import warnings
from dataclasses import dataclass
from typing import Optional, Sequence, cast

import relationalai.semantics as b
from relationalai.semantics.frontend.base import Ref as _Ref
from relationalai_gnns import TaskType, ForeignKey
from relationalai.semantics.reasoners.graph import Graph

from .metamodel_analysis import info_from_edge

# Compatible (eval_metric, TaskType) pairs
_metric_task = [
    ("average_precision",           TaskType.BINARY_CLASSIFICATION),
    ("accuracy",                    TaskType.BINARY_CLASSIFICATION),
    ("f1",                          TaskType.BINARY_CLASSIFICATION),
    ("roc_auc",                     TaskType.BINARY_CLASSIFICATION),

    ("multilabel_auprc_micro",      TaskType.MULTILABEL_CLASSIFICATION),
    ("multilabel_auroc_micro",      TaskType.MULTILABEL_CLASSIFICATION),
    ("multilabel_precision_micro",  TaskType.MULTILABEL_CLASSIFICATION),
    ("multilabel_auprc_macro",      TaskType.MULTILABEL_CLASSIFICATION),
    ("multilabel_auroc_macro",      TaskType.MULTILABEL_CLASSIFICATION),
    ("multilabel_precision_macro",  TaskType.MULTILABEL_CLASSIFICATION),

    ("accuracy",                    TaskType.MULTICLASS_CLASSIFICATION),
    ("macro_f1",                    TaskType.MULTICLASS_CLASSIFICATION),
    ("micro_f1",                    TaskType.MULTICLASS_CLASSIFICATION),

    ("r2",                          TaskType.REGRESSION),
    ("mae",                         TaskType.REGRESSION),
    ("rmse",                        TaskType.REGRESSION),

    ("link_prediction_precision",   TaskType.REPEATED_LINK_PREDICTION),
    ("link_prediction_recall",      TaskType.REPEATED_LINK_PREDICTION),
    ("link_prediction_map",         TaskType.REPEATED_LINK_PREDICTION),

    ("link_prediction_precision",   TaskType.LINK_PREDICTION),
    ("link_prediction_recall",      TaskType.LINK_PREDICTION),
    ("link_prediction_map",         TaskType.LINK_PREDICTION),
]

# Map task name → TaskType
_task_from_name = {
    "multiclass_classification": TaskType.MULTICLASS_CLASSIFICATION,
    "multilabel_classification": TaskType.MULTILABEL_CLASSIFICATION,
    "binary_classification":     TaskType.BINARY_CLASSIFICATION,
    "regression":                TaskType.REGRESSION,
    "link_prediction":           TaskType.LINK_PREDICTION,
    "repeated_link_prediction":  TaskType.REPEATED_LINK_PREDICTION,
}

@dataclass 
class TaskInfo:
    """
    Representation of a GNN learning task including relevant tables,
    connections to the knowledge graph, and task parameters.
    """
    name: str
    task_type: Optional[TaskType]
    use_current_time: bool
    has_time_column: bool
    src_concept: b.Concept
    tgt_concept: Optional[b.Concept]
    src_foreign_key: ForeignKey
    tgt_foreign_key: Optional[ForeignKey] = None
    eval_metric: Optional[str] = None
    at_k: Optional[int] = None    
    label_column: Optional[str] = None
    time_column: Optional[str] = None

def fields_of(x: b.Relationship | b.Chain | b.Fragment) -> list[b.Field]:
    """Extract the ordered list of ``Field`` objects from a task relation.

    Each ``Field`` carries a ``.name`` (column name) and a ``.type``
    (the ``Concept`` the column refers to).

    Supports three relation kinds:
      - ``Relationship`` → returns ``._fields`` directly.
      - ``Chain``        → follows ``._next`` recursively.
      - ``Fragment``     → unwraps each select-argument to find its
        underlying ``Field`` (handles ``Chain``, ``Alias``, ``FieldRef``,
        and bare ``Concept`` wrappers).
    """

    def _resolve_select_arg(select_arg) -> b.Field:
        """Unwrap a single Fragment select-argument to its ``Field``."""
        if isinstance(select_arg, b.Chain):
            return select_arg._next._fields[-1]
        if isinstance(select_arg, b.Alias):
            return _resolve_select_arg(select_arg._source_item)
        if isinstance(select_arg, b.FieldRef):
            f_name = select_arg._field
            for f in select_arg._root._fields:
                if f.name == f_name:
                    return cast(b.Field, f)
        if isinstance(select_arg, b.Concept):
            return b.Field(select_arg._name.lower(), select_arg)
        if isinstance(select_arg, _Ref):
            return _resolve_select_arg(select_arg._concept)
        raise TypeError(
            f"Unsupported select-argument type: {type(select_arg).__name__}"
        )

    if isinstance(x, b.Relationship):
        return x._fields
    if isinstance(x, b.Chain):
        return fields_of(x._next)
    if isinstance(x, b.Fragment):
        return [_resolve_select_arg(sa) for sa in x._select]
    raise TypeError(
        f"fields_of() requires a Relationship, Chain, or Fragment,"
        f" but got {type(x).__name__}."
    )


# ── Schema compatibility helpers ─────────────────────────────────

def _types_compatible(
    fields_a: Sequence[b.Field],
    fields_b: Sequence[b.Field],
) -> bool:
    """Check whether two field lists have the same names and compatible types.

    Type ID ``0`` is the ``Any`` wildcard and matches every other type.
    """
    names_a = [f.name.lower() for f in fields_a]
    names_b = [f.name.lower() for f in fields_b]
    if names_a != names_b:
        return False

    return all(
        a.type._id == 0 or b.type._id == 0 or a.type._id == b.type._id
        for a, b in zip(fields_a, fields_b)
    )


def _schema_mismatch_detail(
    fields_a: Sequence[b.Field],
    fields_b: Sequence[b.Field],
) -> str | None:
    """Return a human-readable mismatch description, or None if schemas are compatible."""
    names_a = [f.name.lower() for f in fields_a]
    names_b = [f.name.lower() for f in fields_b]
    if names_a != names_b:
        return (
            f"column names differ:\n"
            f"  train:      {names_a}\n"
            f"  validation: {names_b}"
        )
    for i, (fa, fb) in enumerate(zip(fields_a, fields_b)):
        if fa.type._id != 0 and fb.type._id != 0 and fa.type._id != fb.type._id:
            return (
                f"column {i} ({fa.name!r}) has incompatible types:\n"
                f"  train:      {fa.type}\n"
                f"  validation: {fb.type}"
            )
    return None


def _task_train_test_schema_match(
    train: b.Relationship | b.Chain | b.Fragment,
    test: b.Relationship | b.Chain | b.Fragment,
) -> bool:
    """Check that *train* (minus its last column) matches *test*.

    The last column of *train* is the label/target — which the test set
    does not have — so it is excluded from the comparison.
    """
    return _types_compatible(fields_of(train)[:-1], fields_of(test))

_LINK_PREDICTION_TASKS = (TaskType.LINK_PREDICTION, TaskType.REPEATED_LINK_PREDICTION)


def _make_foreign_key(concept: b.Concept, suffix: str = "") -> ForeignKey:
    """Build a ``ForeignKey`` that links a column to its concept's primary key."""
    name = concept._name.lower()
    return ForeignKey(column_name=f"{name}{suffix}", link_to=f"{concept._name}.{name}")


def validate_task(
    graph: Graph | None,
    train: b.Relationship | b.Chain | b.Fragment | None,
    validation: b.Relationship | b.Chain | b.Fragment | None,
    source_concept: b.Concept | None,
    target_concept: b.Concept | None,
    task_type: Optional[str],
    eval_metric: str | None,
    use_current_time: bool,
    has_time_column: bool,
) -> TaskInfo:
    """Validate user-supplied task parameters and resolve them into a ``TaskInfo``.

    The function handles two workflows:
      * **Fit** (``train is not None``): derives source/target concepts and
        foreign keys from the training relation's fields.
      * **Load** (``train is None``): requires ``source_concept`` (and
        ``target_concept`` for link-prediction) to be provided explicitly.

    Raises:
        ValueError: On schema mismatches, unknown task types, incompatible
            eval metrics, missing concepts, or invalid time-column arity.
    """

    # ── Schema compatibility ────────────────────────────────────
    if train is not None and validation is not None:
        detail = _schema_mismatch_detail(fields_of(train), fields_of(validation))
        if detail is not None:
            raise ValueError(
                f"training and validation sets must have the same schema — {detail}"
            )

    if (train is not None and validation is not None
            and isinstance(train, b.Relationship) and isinstance(validation, b.Relationship)):
        train_name = str(train)
        val_name   = str(validation)
        if train_name != val_name:
            warnings.warn(
                f"train relationship '{train_name}' and validation relationship "
                f"'{val_name}' are named differently. These represent the same task "
                f"— consider using the same name for clarity.",
                UserWarning,
                stacklevel=2,
            )

    # ── Resolve task type ───────────────────────────────────────
    if task_type is not None:
        _valid_task_types = ", ".join(f'"{t}"' for t in _task_from_name)
        if task_type not in _task_from_name:
            raise ValueError(
                f'"{task_type}" is not a valid task type. Valid task types are: {_valid_task_types}.'
            )
        task_type = _task_from_name[task_type]
        is_link_prediction = task_type in _LINK_PREDICTION_TASKS
    else:
        # load workflow with no task_type provided — infer structure from target_concept
        is_link_prediction = target_concept is not None

    # ── Parse eval metric ───────────────────────────────────────
    # Supports "metric@k" syntax (e.g. "link_prediction_precision@10").
    at_k = None
    if eval_metric:
        if "@" in eval_metric:
            eval_metric, at_k = eval_metric.lower().split("@")
            at_k = int(at_k)
        else:
            eval_metric = eval_metric.lower()

        if task_type is not None and (eval_metric, task_type) not in _metric_task:
            raise ValueError(
                f"evaluation metric {eval_metric} and task "
                f"{task_type} are not a valid combination"
            )

    # ── Graph info ──────────────────────────────────────────────
    concept_info = None
    if graph is not None:
        # task_name = f"{graph._EdgeConceptStr}_{task_type.value}"
        concept_info = info_from_edge(graph.Edge)
    # else:
    #     task_name = f"{task_type.value}"

    # ── Resolve concepts and foreign keys ───────────────────────
    label_column: str | None = None
    time_column: str | None = None
    src_concept: b.Concept | None = None
    tgt_concept: b.Concept | None = None
    tgt_foreign_key: ForeignKey | None = None

    if train is not None:
        # ── Fit workflow ────────────────────────────────────────
        train_fields = fields_of(train)
        src_field = train_fields[0]
        tgt_field = train_fields[-1]
        src_concept = src_field.type
        tgt_concept = tgt_field.type

        # Resolve untyped (Any) source concept.
        if src_concept._id == 0:
            if source_concept is None:
                kind = "link prediction" if is_link_prediction else "node prediction"
                raise ValueError(
                    f"Untyped source field in a {kind} task "
                    f"requires `source_concept` to be provided"
                )
            src_concept = source_concept

        # Resolve untyped (Any) target concept (link-prediction only).
        if tgt_concept._id == 0 and is_link_prediction:
            if target_concept is None:
                raise ValueError(
                    "Untyped target field in a link prediction task "
                    "requires `target_concept` to be provided"
                )
            tgt_concept = target_concept

        # Validate that concepts exist in the graph.
        if concept_info and src_concept._name not in concept_info:
            raise ValueError(
                f"training set {src_field.name} field has type "
                f"{src_concept._name} which is not found in the graph"
            )

        if is_link_prediction:
            if concept_info and tgt_concept._name not in concept_info:
                raise ValueError(
                    f"training set {tgt_field.name} field has type "
                    f"{tgt_concept._name} which is not found in the graph"
                )
            tgt_foreign_key = _make_foreign_key(tgt_concept, suffix="_tgt")
        else:
            label_column = tgt_field.name.lower()

        # Time-column validation.
        if has_time_column:
            if len(train_fields) != 3:
                raise ValueError(
                    "expect arity=3 for training/validation sets "
                    "with has_time_column = True"
                )
            time_column = "timecolumn"

    else:
        # ── Load workflow ───────────────────────────────────────
        # No training data → concepts must be provided explicitly.
        src_concept = source_concept

        if is_link_prediction:
            tgt_concept = target_concept
            if tgt_concept is None:
                raise ValueError("`target_concept` is required in a load workflow for link-prediction tasks.")
            tgt_foreign_key = _make_foreign_key(tgt_concept, suffix="_tgt")

        if has_time_column:
            time_column = "timecolumn"

    # Source foreign key is always needed.
    if src_concept is None:
        raise ValueError("`source_concept` is required in a load workflow.")
    src_foreign_key = _make_foreign_key(src_concept, suffix="_src")

    if is_link_prediction and tgt_concept is None:
        assert task_type is not None
        raise ValueError(
            f"`target_concept` must be resolved for {task_type.value}"
        )

    # ── Build TaskInfo ──────────────────────────────────────────
    return TaskInfo(
        name=src_concept._name.upper(),
        task_type=task_type,
        eval_metric=eval_metric,
        at_k=at_k,
        use_current_time=use_current_time,
        has_time_column=has_time_column,
        src_concept=src_concept,
        tgt_concept=tgt_concept,
        src_foreign_key=src_foreign_key,
        tgt_foreign_key=tgt_foreign_key,
        label_column=label_column,
        time_column=time_column,
    )
