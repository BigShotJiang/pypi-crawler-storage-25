import difflib
import inspect
import re
from typing import TYPE_CHECKING, Any, Dict, Union

if TYPE_CHECKING:
    from relationalai.config.config import Config

from relationalai_gnns import (
    SnowflakeConnector, GNNTable, CandidateKey,
    TaskType, NodeTask, LinkTask, EvaluationMetric, Dataset,
    Trainer, TrainerConfig, ExperimentConfig, ColumnDType
)

from .task_info import TaskInfo
from .data import GNNTableInfo, TableType

def prepare_gnn_tables(
    connector: SnowflakeConnector,
    sf_tables: dict[str, GNNTableInfo],
) -> dict[str, GNNTable]:
    """
    Build GNNTable metadata for concepts in the supplied sf_tables dictionary.

    Args:
        connector: Snowflake connector instance
        sf_tables: Dictionary mapping concept names to their GNNTableInfo

    Returns:
        Dictionary mapping concept names to their GNNTable instances
    """
    gnn_tables: dict[str, GNNTable] = {}

    for concept_name, n_info in sf_tables.items():
        # Use dot notation to access dataclass attributes
        table_name = n_info.source
        table_type = n_info.type
        print(f"  ✓ Creating GNN table for {concept_name} concept")

        extra_params = {}

        gle_types = {}
        if table_type == TableType.NODE:
            # Copy to avoid mutating GNNTableInfo metadata in-place.
            # This prevents dtype leakage if the same metadata object is reused.
            gle_types = dict(n_info.gle_types) if n_info.gle_types else {}
            gle_types[concept_name.lower()] = ColumnDType("text")
            # If the time field was SemanticType.INFER, it is absent from n_info.gle_types
            # but GNNTable still needs datetime so set_time_column can succeed.
            if n_info.time_col:
                gle_types[n_info.time_col.lower()] = ColumnDType("datetime")
            extra_params["column_dtypes"] = gle_types
            extra_params["time_column"] = n_info.time_col.lower() if n_info.time_col else None
            extra_params["candidate_keys"] = [CandidateKey(column_name=concept_name.lower())]

        # Set foreign keys — ensure the FK column dtype is known first
        foreign_keys = []
        for fk in n_info.foreign_keys:
            gle_types[fk.column_name] = ColumnDType("text")
            foreign_keys.append(fk)
        extra_params['foreign_keys'] = foreign_keys if foreign_keys else None
        # Edge tables only get FK entries in gle_types above; without column_dtypes the
        # GNN stack infers dtypes from data and may label key columns as category.
        if table_type == TableType.EDGE and gle_types:
            extra_params["column_dtypes"] = gle_types

        gnn_table = GNNTable(
            connector=connector,
            name=concept_name,
            type=table_type,
            source=table_name,
            **extra_params
        )

        gnn_tables[concept_name] = gnn_table

    return gnn_tables

def prepare_gnn_task_and_tables(
    connector: SnowflakeConnector,
    sf_tables: dict[str, GNNTableInfo],
    task_data_source: dict[str, str],
    task_info: TaskInfo,
) -> tuple[dict[str, GNNTable], NodeTask | LinkTask]:
    """Prepare GNN SDK tables and a task configuration from materialised metadata.

    Args:
        connector: Snowflake connector instance.
        sf_tables: Node/edge table metadata produced by ``materialize_gnn_tables_to_snowflake``.
        task_data_source: Mapping of role (``"train"``, ``"validation"``, …)
            to fully-qualified Snowflake table names.
        task_info: Validated task descriptor.

    Returns:
        A ``(sdk_tables, task)`` tuple where *sdk_tables* maps concept names
        to ``GNNTable`` instances and *task* is a ``NodeTask`` or ``LinkTask``.
    """
    sdk_tables = prepare_gnn_tables(connector, sf_tables)

    is_link_prediction = task_info.task_type in (
        TaskType.LINK_PREDICTION,
        TaskType.REPEATED_LINK_PREDICTION,
    )

    # ── Evaluation metric ──────────────────────────────
    extra_params: dict = {}
    if task_info.eval_metric:
        metric = EvaluationMetric(name=task_info.eval_metric)
        if is_link_prediction:
            metric.eval_at_k = task_info.at_k
        extra_params["evaluation_metric"] = metric

    # Inference-only link tasks (test split only) can omit target FK in SDK.
    is_inference_only = (
        task_data_source.get("test") is not None
        and task_data_source.get("train") is None
        and task_data_source.get("validation") is None
    )    
    
    # dtypes for source and target columns
    gle_types: dict = {}
    gle_types[task_info.src_foreign_key.column_name] = ColumnDType("text")

    # Time_column
    if task_info.time_column:
        extra_params["time_column"] = task_info.time_column
        gle_types[task_info.time_column] = ColumnDType("datetime")

    # ── Build the task object ───────────────────────────────────
    common = dict(
        connector=connector,
        name=task_info.name,
        task_type=task_info.task_type,
        current_time=task_info.use_current_time,
        task_data_source=task_data_source,
        **extra_params,
    )

    if is_link_prediction:
        if not is_inference_only:
            assert task_info.tgt_foreign_key is not None
            gle_types[task_info.tgt_foreign_key.column_name] = ColumnDType("text")
        task = LinkTask(
            source_entity_column=task_info.src_foreign_key,
            target_entity_column=(
                None if is_inference_only else task_info.tgt_foreign_key
            ),
            column_dtypes=gle_types,
            **common,  # type: ignore[call-arg]
        )
    else:
        if not is_inference_only and task_info.label_column:
            # Keep node-task labels even when GNN dtype inference cannot
            # determine them from sparse/constant task splits.
            label_dtype = (
                ColumnDType("float")
                if task_info.task_type == TaskType.REGRESSION
                else ColumnDType("category")
            )
            gle_types[task_info.label_column] = label_dtype
        task = NodeTask(
            target_entity_column=task_info.src_foreign_key,
            label_column=(
                None if is_inference_only else task_info.label_column
            ),
            column_dtypes=gle_types,
            **common,  # type: ignore[call-arg]
        )

    return sdk_tables, task

def create_gnn_dataset(
    connector: SnowflakeConnector,
    tables: Dict[str, GNNTable],
    task: Union[NodeTask, LinkTask],
    name: str | None
) -> Dataset:
    """
    Create a GNN Dataset from tables and task configuration.
    
    Args:
        connector: Snowflake connector instance
        tables: Dictionary mapping concept names to GNNTable instances
        task: Configured task object (NodeTask or LinkTask)
        name: Name for the dataset
        
    Returns:
        Configured Dataset object ready for training
    """
    dataset_name = name if name else f"{connector.user}_{connector.role}"
    if not dataset_name:
        dataset_name = "dataset"
    dataset_name = sanitize_snowflake_identifier(dataset_name)
    return Dataset(
        connector=connector,
        dataset_name=dataset_name,
        tables=list(tables.values()),
        task_description=task
    )

def sanitize_snowflake_identifier(identifier: str) -> str:
    """
    Converts a string into a valid Snowflake unquoted identifier.
    - Replaces invalid characters with underscores.
    - Ensures it starts with a letter or underscore.
    - Limits length to 255 characters.
    - Converts to uppercase (Snowflake default).
    """
    # 1. Replace all characters that are NOT letters, numbers, _, or $ with '_'
    # Regex: [^a-zA-Z0-9_$] means "anything not a letter, digit, underscore, or dollar sign"
    sanitized = re.sub(r'[^a-zA-Z0-9_$]', '_', identifier)
    
    # 2. Ensure it starts with a letter or underscore
    # If it starts with a number or $, prepend an underscore
    if not re.match(r'^[a-zA-Z_]', sanitized):
        sanitized = '_' + sanitized
        
    # 3. Truncate to the Snowflake limit of 255 characters
    sanitized = sanitized[:255]
    
    # 4. Convert to uppercase for consistency with Snowflake's internal storage
    return sanitized.upper()


_WORKFLOW_HINT = (
    "  Fit workflow — minimum required:\n"
    "    GNN(\n"
    "        exp_database=...,   # Snowflake database for experiment artifacts\n"
    "        exp_schema=...,     # Snowflake schema for experiment artifacts\n"
    "        graph=...,          # PyRel Graph with edges defined\n"
    "        train=...,          # PyRel Relationship defining the training split\n"
    "        validation=...,     # PyRel Relationship defining the validation split\n"
    "        task_type=...,      # e.g. 'binary_classification', 'regression', 'link_prediction'\n"
    "        has_time_column=True, # required when Relationships use the 'at' keyword (temporal splits)\n"
    "        # optional:\n"
    "        eval_metric=...,    # e.g. 'roc_auc', 'rmse', 'link_prediction_precision@5'\n"
    "        database=...,       # Snowflake database to save predictions (required for .predictions())\n"
    "        schema=...,         # Snowflake schema to save predictions (required for .predictions())\n"
    "    )\n\n"
    "  Load workflow — minimum required:\n"
    "    GNN(\n"
    "        exp_database=...,      # Snowflake database for experiment artifacts\n"
    "        exp_schema=...,        # Snowflake schema for experiment artifacts\n"
    "        graph=...,             # PyRel Graph with edges defined\n"
    "        source_concept=...,    # PyRel Concept used as source during training\n"
    "        model_run_id=...,      # or (model_database, model_schema, model_name, version_name)\n"
    "        # required for link prediction tasks only:\n"
    "        target_concept=...,    # PyRel Concept used as target during training\n"
    "        # optional — auto-populated from model metadata if not provided:\n"
    "        task_type=...,         # inferred from the registered model; only set to override\n"
    "        has_time_column=...,   # inferred from the registered model; only set to override\n"
    "        # optional:\n"
    "        database=...,          # Snowflake database to save predictions (required for .predictions())\n"
    "        schema=...,            # Snowflake schema to save predictions (required for .predictions())\n"
    "    )\n\n"
    "  Note: task_type, source_concept, and has_time_column are validated against the registered\n"
    "  model metadata at load() time. A warning is raised if any value does not match what the\n"
    "  model was trained with."
)


def validate_fit_params(graph, train, validation, task_type) -> None:
    """Raise a descriptive ValueError if any required fit-workflow parameter is missing."""
    missing = []
    if graph is None:
        missing.append("`graph`")
    if train is None:
        missing.append("`train`")
    if validation is None:
        missing.append("`validation`")
    if task_type is None:
        missing.append("`task_type`")
    if missing:
        raise ValueError(
            f"{', '.join(missing)} {'is' if len(missing) == 1 else 'are'} required in a fit workflow.\n"
            "If you intended a load workflow, also provide `model_run_id` or "
            "(model_database, model_schema, model_name, version_name).\n\n"
            + _WORKFLOW_HINT
        )


_LINK_PREDICTION_TASK_TYPES = {"link_prediction", "repeated_link_prediction"}


def validate_load_params(source_concept, target_concept, task_type) -> None:
    """Raise a descriptive ValueError if any required load-workflow parameter is missing."""
    missing = []
    if source_concept is None:
        missing.append("`source_concept`")
    if task_type in _LINK_PREDICTION_TASK_TYPES and target_concept is None:
        missing.append("`target_concept`")
    if missing:
        raise ValueError(
            f"{', '.join(missing)} {'is' if len(missing) == 1 else 'are'} required in a load workflow.\n\n"
            + _WORKFLOW_HINT
        )


def validate_time_col(has_time_column: bool, property_transformer) -> None:
    """Raise on time_col / has_time_column mismatches."""
    if property_transformer is not None:
        pt_has_time_col = any(
            "time_col" in annos
            for annos in property_transformer.concept_annos.values()
        )
    else:
        pt_has_time_col = False

    if has_time_column and not pt_has_time_col:
        raise ValueError(
            "`has_time_column=True` is set but `time_col` is not defined in the "
            "PropertyTransformer. Set `time_col=` on at least one concept to "
            "specify which datetime property represents the timestamp."
        )

    if not has_time_column and pt_has_time_col:
        raise ValueError(
            "`has_time_column` is not set but the PropertyTransformer has `time_col` annotations.\n"
            "The data tables will include a time column but the task will not, causing a pipeline failure.\n"
            "Add `has_time_column=True` to your GNN constructor."
        )



_RENAMED_PARAMS = {
    "pt": "property_transformer",
}
_REMOVED_PARAMS = {
    "export_csv": "set the CSV_EXPORT_ENABLED environment variable instead",
    "skip_cdc": "set the CDC_DISABLED environment variable instead",
}


def validate_train_params(train_params: dict, gnn_params: frozenset[str]) -> None:
    if not train_params:
        return
    valid = frozenset(
        inspect.signature(TrainerConfig.__init__).parameters
    ) - {"self", "connector", "experiment_config"}
    unknown = set(train_params) - valid
    if not unknown:
        return
    msgs = []
    for key in sorted(unknown):
        if key in _RENAMED_PARAMS:
            msgs.append(f"  '{key}' has been renamed — use '{_RENAMED_PARAMS[key]}' instead.")
        elif key in _REMOVED_PARAMS:
            msgs.append(f"  '{key}' has been removed — {_REMOVED_PARAMS[key]}.")
        elif key in gnn_params:
            msgs.append(f"  '{key}' is a GNN constructor parameter, not a trainer parameter.")
        else:
            suggestions = difflib.get_close_matches(key, valid | gnn_params, n=1, cutoff=0.6)
            hint = f" Did you mean '{suggestions[0]}'?" if suggestions else ""
            msgs.append(f"  '{key}' is not a valid parameter.{hint}")
    raise ValueError(
        "Unknown keyword argument(s) passed to GNN():\n"
        + "\n".join(msgs)
        + f"\nValid trainer parameters: {sorted(valid)}"
    )


def validate_gnn_config(cfg: "Config") -> None:
    """Warn about raiconfig settings that may cause GNN workflow failures."""
    import warnings

    try:
        cfg.get_default_connection()
    except ValueError as e:
        raise ValueError(
            f"{e}\n\n"
            "To fix this, update the 'default_connection' field in your raiconfig.yaml "
            "to match one of the connection names defined under 'connections'.\n\n"
            "Example:\n"
            "  default_connection: my_connection\n"
            "  connections:\n"
            "    my_connection:\n"
            "      type: snowflake\n"
            "      ..."
        ) from None
    except Exception:
        pass  # Snowflake not installed or other non-config error — skip

    missing_reasoners = []
    if not cfg.reasoners.logic.name:
        missing_reasoners.append("  - reasoners.logic.name")
    if not cfg.reasoners.predictive.name:
        missing_reasoners.append("  - reasoners.predictive.name")
    if missing_reasoners:
        warnings.warn(
            "⚠️  raiconfig is missing reasoner name(s):\n"
            + "\n".join(missing_reasoners)
            + "\n\nIf not explicitly set, default reasoner names and sizes will be used. "
            "To use specific reasoners, add the missing entries to your raiconfig.yaml under 'reasoners'.",
            UserWarning,
            stacklevel=2,
        )

    if not cfg.data.ensure_change_tracking:
        warnings.warn(
            "⚠️  raiconfig has 'data.ensure_change_tracking: false'.\n"
            "Importing Snowflake tables into PyRel requires change tracking to be enabled. "
            "GNN workflows using Snowflake tables will fail without it.\n"
            "Set 'data.ensure_change_tracking: true' in your raiconfig.yaml.",
            UserWarning,
            stacklevel=2,
        )


def resolve_device(train_params: dict, cfg: "Config") -> dict:
    """Infer device from engine size if not set; warn if user-supplied device mismatches the engine."""
    import warnings
    size = cfg.reasoners.predictive.size
    has_gpu = "gpu" in size.lower()
    engine_device = "cuda" if has_gpu else "cpu"

    if "device" not in train_params:
        return {**train_params, "device": engine_device}

    user_device = train_params["device"]
    if user_device not in ("cpu", "cuda"):
        raise ValueError(
            f"Invalid device=\"{user_device}\". Must be \"cpu\" or \"cuda\"."
        )
    user_wants_gpu = user_device == "cuda"
    if user_wants_gpu != has_gpu:
        warnings.warn(
            f"⚠️  device=\"{user_device}\" was requested but the configured predictive engine "
            f"(size: {size!r}) {'has no GPU' if not has_gpu else 'has a GPU'}. "
            f"Expected device=\"{engine_device}\" for this engine.",
            UserWarning,
            stacklevel=3,
        )
    return train_params


def create_gnn_trainer(
    connector: SnowflakeConnector,
    db: str,
    schema: str,
    trainer_params: dict[str, Any]
) -> Trainer:
    """
    Create a Trainer with specified configuration and hyperparameters.
    
    Args:
        connector: Snowflake connector instance
        db: Database name for experiment storage
        schema: Schema name for experiment storage
        trainer_params: Dictionary of trainer hyperparameters (e.g., n_epochs, device)
        
    Returns:
        Configured Trainer object ready to train models

    """
    # Set default hyperparameters and merge with provided parameters
    params = {"n_epochs": 10} | trainer_params

    # Database/schema for experiments
    experiment_cfg = ExperimentConfig(database=db, schema=schema)

    # Create TrainerConfig and Trainer objects
    trainer_config = TrainerConfig(
        connector=connector,
        experiment_config=experiment_cfg,
        **params  # type: ignore[call-arg]
    )
    trainer = Trainer(connector=connector, config=trainer_config)

    return trainer
