"""RelationalAI Predictive Reasoner using Graph Neural Networks (GNNs).

The Predictive Reasoner generates meaningful predictions from your relational data,
supporting decision-intelligence tasks like identifying potential churn, detecting fraud, and more.

It provides a declarative Python API for formulating prediction problems —
node classification, regression, or link prediction — and solving them with Graph Neural Networks.

Quick Start
-----------
Train a GNN for node binary classification:

>>> from relationalai.semantics import Model, select, define
>>> from relationalai.semantics.reasoners.graph import Graph
>>> from relationalai.semantics.reasoners.predictive import (
...    GNN, PropertyTransformer)

>>> model = Model("gnn_synthdb")
>>> Concept, Table = model.Concept, model.Table

>>> # Construct Knowledge Graph

>>> # Define concepts
>>> Classes = Concept("Classes")
>>> Students = Concept("Students")
>>> StudentTakesClass = Concept("TakesClass")

>>> # Populate concepts from snowflake tables
>>> classes_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.DATA.CLASSES")
>>> define(Classes.new(classes_table.to_schema()))
>>> students_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.DATA.STUDENTS")
>>> define(Students.new(students_table.to_schema()))
>>> takes_class_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.DATA.STUDENT_TAKES_CLASS")
>>> define(StudentTakesClass.new(takes_class_table.to_schema()))

>>> # Construct training/validation/test sets
>>> test_table_concept = Concept("SynthTestTable")
>>> train_table_concept = Concept("SynthTrainTable")
>>> validation_table_concept = Concept("SynthValidationTable")

>>> train_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.RANK.TRAIN")
>>> define(train_table_concept.new(train_table.to_schema()))
>>> val_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.RANK.VALIDATION")
>>> define(validation_table_concept.new(val_table.to_schema()))
>>> test_table = Table("SYNTHETIC_ACADEMIC_RANKING_DB.RANK.TEST")
>>> define(test_table_concept.new(test_table.to_schema()))

>>> Train = select(Students, train_table_concept.label).where(
...    train_table_concept.studentid == Students.studentid
... )
>>> Validation = select(Students, validation_table_concept.label).where(
...    validation_table_concept.studentid == Students.studentid
... )
>>> Test = select(Students).where(
...    test_table_concept.studentid == Students.studentid
... )

>>> # Construct Graph for GNN
>>> gnn_graph = Graph(model, directed=False, weighted=False)
>>> Edge = gnn_graph.Edge
>>> define(Edge.new(src=StudentTakesClass, dst=Students)).where(StudentTakesClass.studentid == Students.studentid)
>>> define(Edge.new(src=StudentTakesClass, dst=Classes)).where(StudentTakesClass.classid == Classes.classid)

>>> # Configure PropertyTransformer
>>> pt = PropertyTransformer(
...     continuous=[Students.participation, Classes.credits, StudentTakesClass.grade],
...     drop=[Students.studentid, Classes.classid, StudentTakesClass.studentid, StudentTakesClass.classid],
... )

>>> # GNN train and predict
>>> train_config = {
...     "device": "cuda",
...     "n_epochs": 5,
... }

>>> gnn = GNN(exp_database="EXPERIMENTS_DB", exp_schema="EXPERIMENTS_SCHEMA",
...           graph=gnn_graph, pt=pt,
...           source_concept=Students,
...           train=Train, validation=Validation,
...           task_type="binary_classification",
...           eval_metric="roc_auc",
...           stream_logs=True,
...           **train_config)
>>> gnn.fit()
>>> Students.predictions = gnn.predictions(domain=Test)

>>> # Inspect output
>>> ( select(Students.studentid, Students.predictions.predicted_labels, Students.predictions.probs)
...     .where(Students.predictions)
...     .inspect()
... )

Modules and Subpackages
-----------------------

This API exposes two classes for building GNN predictive pipelines
on RelationalAI semantic models:

- :class:`~relationalai.semantics.reasoners.predictive.estimator.GNN` —
  train a Graph Neural Network and generate predictions.
- :class:`~relationalai.semantics.reasoners.predictive.property_transformer.PropertyTransformer` —
  annotate concept fields with semantic types (category, continuous, text, etc.).
"""
import importlib

# include this package in the docs
__include_in_docs__ = True

# Define intuitive error message
_MISSING_DEP_MSG = (
    "The GNN functionality requires the optional 'relationalai_gnns' library.\n"
    "Please install it using:\n\n"
    "    pip install relationalai[gnn]"
)

# Map the classes/functions to the submodules they come from
# Format: "ExportName": ".submodule_name"
_IMPORT_MAP = {
    "GNN": ".estimator",
    "PropertyTransformer": ".property_transformer",
}

__all__ = list(_IMPORT_MAP.keys())

def __getattr__(name):
    if name in _IMPORT_MAP:
        submodule_name = _IMPORT_MAP[name]
        try:
            # Attempt to import the submodule (e.g., .estimator)
            module = importlib.import_module(submodule_name, package=__name__)
            return getattr(module, name)
        except ImportError as e:
            # Check if the failure is due to the optional dependency
            # Check both the error message and the module name attribute
            if "relationalai_gnns" in str(e) or getattr(e, "name", None) == "relationalai_gnns":
                raise ImportError(_MISSING_DEP_MSG) from e
            # If it's a different ImportError (bug in code), re-raise it
            raise

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    return sorted(__all__)
