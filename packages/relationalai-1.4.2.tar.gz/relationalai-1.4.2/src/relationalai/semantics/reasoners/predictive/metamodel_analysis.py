import warnings
from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from typing import cast

from relationalai.semantics.metamodel.rewriter import Walker
import relationalai.semantics as base
import relationalai.semantics.metamodel as mm


def _concept_name(concept_or_name: str | base.Concept) -> str:
    """Return the string name of a Concept or pass through a string."""
    return concept_or_name._name if isinstance(concept_or_name, base.Concept) else concept_or_name


def edge_concepts(mdl: mm.Model, edge_name: str | base.Concept) -> list[str]:
    """Return edge_name together with all its immediate subtypes."""
    name = _concept_name(edge_name)
    result = [name]
    for scalar_type in mdl.types:
        if isinstance(scalar_type, mm.ScalarType) and any(super_type.name == name for super_type in scalar_type.super_types):
            result.append(scalar_type.name)
    return result


class EdgeDefs(Walker):
    """Collect top-level Logical nodes whose body constructs an edge."""

    def __init__(self, edge_names: Sequence[str | base.Concept]) -> None:
        super().__init__()
        self.edge_defs: list[mm.Logical] = []
        self.edge_names = [_concept_name(n) for n in edge_names]

    def collect(self, node: mm.Node) -> list[mm.Logical]:
        self(node)
        return self.edge_defs

    def logical(self, node: mm.Logical):
        def edge_def(child: mm.Node) -> bool:
            return isinstance(child, mm.Logical) and any(
                isinstance(c, mm.Construct)
                and c.values
                and isinstance(c.values[0], mm.Literal)
                and c.values[0].value in self.edge_names
                for c in child.body
            )

        if node.scope and any(edge_def(ch) for ch in node.body):
            self.edge_defs.append(node)


class EdgeExtractor(Walker):
    """Single-pass walker: extracts src/dst/edge_type and join equalities/var origins."""

    def __init__(self, edge_names: Sequence[str | base.Concept], concepts: set[str], rels: set[str]) -> None:
        super().__init__()
        self.edge_names = [_concept_name(n) for n in edge_names]
        self.concepts = concepts
        self.rels = concepts | rels
        self.src: mm.Var | None = None
        self.dst: mm.Var | None = None
        self.edge_type: str | None = None
        self.var_eqs: set[tuple[mm.Var, mm.Var]] = set()
        self.var_origin: dict[mm.Var, tuple[str, str]] = {}

    def collect(self, node: mm.Node) -> tuple[mm.Var | None, mm.Var | None, str | None, set[tuple[mm.Var, mm.Var]], dict[mm.Var, tuple[str, str]]]:
        """Walk node and return (src_var, dst_var, edge_type, var_eqs, var_origin) for this node."""
        self.src, self.dst, self.edge_type = None, None, None
        self.var_eqs = set()
        self.var_origin = {}
        self(node)
        return self.src, self.dst, self.edge_type, self.var_eqs, self.var_origin

    def update(self, node: mm.Update):
        arg0 = cast(mm.Var, node.args[0])
        if arg0.type.name not in self.edge_names:
            return
        rel = node.relation.name
        if rel == 'src' and not self.src:
            self.src = cast(mm.Var, node.args[1])
        if rel == 'dst' and not self.dst:
            self.dst = cast(mm.Var, node.args[1])
        if rel in ('src', 'dst') and not self.edge_type:
            self.edge_type = arg0.type.name

    def lookup(self, node: mm.Lookup):
        args = node.args
        rel_name = node.relation.name

        # Equality constraints between vars
        if len(args) > 1 and rel_name == '=':
            if isinstance(args[0], mm.Var) and isinstance(args[1], mm.Var):
                self.var_eqs.add((args[0], args[1]))

        # Variable origin tracking: map each var to (concept, column)
        if rel_name in self.rels:
            if len(args) == 1:
                if isinstance(args[0], mm.Var):
                    self.var_origin[args[0]] = (args[0].type.name, rel_name)
            elif args:
                concept_name = cast(mm.Var, args[0]).type.name
                for arg in args[1:]:
                    if isinstance(arg, mm.Var):
                        self.var_origin[arg] = (concept_name, rel_name)


@dataclass
class EdgeConnectivity:
    """Raw topology extracted from the metamodel IR for a single edge concept."""
    links: defaultdict[str, list[tuple[str, str]]]
    join_cols: defaultdict[tuple[str, str], list[list[tuple[str, str]]]]
    direct_fks: dict[str, dict[str, str]]


def _resolve_var(
    var: mm.Var,
    var_origin: dict[mm.Var, tuple[str, str]],
    var_eqs: set[tuple[mm.Var, mm.Var]],
) -> tuple[str, str] | None:
    """Return (concept, column) for var, following equality chains transitively."""
    if var in var_origin:
        return var_origin[var]
    # adj[v] = variables constrained equal to v
    adj: defaultdict[mm.Var, list[mm.Var]] = defaultdict(list)
    for a, b in var_eqs:
        adj[a].append(b)
        adj[b].append(a)
    visited: set[mm.Var] = set()

    def recurse(v: mm.Var) -> tuple[str, str] | None:
        if v in visited:
            return None
        visited.add(v)
        if v in var_origin:
            return var_origin[v]
        for neighbor in adj[v]:
            result = recurse(neighbor)
            if result is not None:
                return result
        return None

    return recurse(var)


def directed_edge_names(
    mmir: mm.Model,
    edge: base.Concept | str,
) -> EdgeConnectivity:
    """Extract directed edge info from the metamodel IR.

    Returns (links, join_cols, direct_fks):
      - links[src]: list of (dst, edge_type) pairs
      - join_cols[(src, dst)]: list of [(concept, col), (concept, col)] join equalities
      - direct_fks[concept]: dict of property_name -> target_concept (implicit FKs)
    """
    core_lib = base.Library("").libraries[0]
    native_types = core_lib.concept_index.keys()
    native_rels = core_lib.relationship_index.keys()

    sub_edges = edge_concepts(mmir, edge)
    user_concepts = {c.name for c in mmir.types if not isinstance(c, mm.Table)} - native_types
    user_rels = {c.name for c in mmir.relations} - native_rels

    links: defaultdict[str, list[tuple[str, str]]] = defaultdict(list)
    join_cols: defaultdict[tuple[str, str], list[list[tuple[str, str]]]] = defaultdict(list)
    direct_fks: defaultdict[str, dict[str, str]] = defaultdict(dict)
    extractor = EdgeExtractor(sub_edges, user_concepts, user_rels)

    for logical_node in EdgeDefs(sub_edges).collect(mmir):
        src_var, dst_var, e_type, eqs, origin = extractor.collect(logical_node)
        if src_var is None:
            raise ValueError("Could not find 'src' in edge definition.")
        if dst_var is None:
            raise ValueError("Could not find 'dst' in edge definition.")
        assert e_type is not None, "edge_type must be set when src is set"

        src, dst = src_var.type.name, dst_var.type.name

        links[src].append((dst, e_type))
        if dst not in links:
            links[dst] = []

        join_cols[(src, dst)].extend(
            [origin[v] for v in var_pair]
            for var_pair in eqs
            if all(v in origin for v in var_pair)
        )

        for target_var, target_name in ((src_var, src), (dst_var, dst)):
            resolved = _resolve_var(target_var, origin, eqs)
            if resolved is not None:
                concept, col = resolved
                if col.lower() != concept.lower():   # don't add self references as FKs
                    direct_fks[concept][col] = target_name

    if not links:
        raise ValueError(
            "Graph has no edges defined. "
            "Add at least one Edge before constructing GNN:\n"
            "    define(Edge.new(src=ConceptA, dst=ConceptB)).where(...)"
        )

    return EdgeConnectivity(links=links, join_cols=join_cols, direct_fks=direct_fks)


def get_key_columns(
    join_cols: dict[tuple[str, str], list[list[tuple[str, str]]]],
    concept_names: Iterable[str],
    model: base.Model,
) -> tuple[defaultdict[str, set[str]], defaultdict[str, set[tuple[str, str]]]]:
    """Return primary-key and foreign-key columns for the given concepts.

    A column is primary if it is the sole column in identify_by.
    A column is foreign if it is equated to a primary key of another concept.

    Returns (pks, fks):
      - pks[concept]: set of primary-key column names
      - fks[concept]: set of (column, target_concept) foreign-key tuples
    """
    pks: defaultdict[str, set[str]] = defaultdict(set)
    for name in concept_names:
        concept = model.concept_index.get(name)
        if concept is not None:
            pks[name] = {col._short_name.lower() for col in concept._identify_by}

    fks: defaultdict[str, set[tuple[str, str]]] = defaultdict(set)
    for equalities in join_cols.values():
        for (concept_a, col_a_raw), (concept_b, col_b_raw) in equalities:
            col_a, col_b = col_a_raw.lower(), col_b_raw.lower()

            # A column matching its own concept name is a population lookup,
            # always treated as a key.
            is_concept_ref_a = col_a == concept_a.lower()
            is_concept_ref_b = col_b == concept_b.lower()

            is_pk_a = pks[concept_a] == {col_a} or is_concept_ref_a
            is_pk_b = pks[concept_b] == {col_b} or is_concept_ref_b

            if is_pk_a and not is_concept_ref_b:
                fks[concept_b].add((col_b, concept_a))
            if is_pk_b and not is_concept_ref_a:
                fks[concept_a].add((col_a, concept_b))

    return pks, fks


@dataclass
class ConceptInfo:
    """Information about a concept in an edge definition."""
    links: set[tuple[str, str]] = field(default_factory=set)
    primary_keys: set[str] = field(default_factory=set)
    foreign_keys: dict[str, str] = field(default_factory=dict)


def has_undirected_edge(info: dict[str, ConceptInfo]) -> tuple[str, str, str] | None:
    """Return (src, dst, edge_type) if the same edge type connects src->dst and dst->src
    (with src != dst), else None."""
    for src, src_info in info.items():
        for dst, edge_type in src_info.links:
            if src != dst and (dst_info := info.get(dst)) and (src, edge_type) in dst_info.links:
                return (src, dst, edge_type)
    return None


def info_from_edge(edge: base.Concept) -> dict[str, ConceptInfo]:
    """Return a ConceptInfo for each concept involved in the given edge.

    This is the main entry point for metamodel analysis. It extracts
    links, primary keys, and foreign keys for every concept participating
    in the edge definition.
    """
    mdl = edge._model

    ec = directed_edge_names(mdl.to_metamodel(), edge)

    for concept_name in ec.links.keys():
        if concept_name not in mdl.concept_index:
            raise ValueError(
                f"concept '{concept_name}' is not in model '{mdl.name}'. "
                f"Check that all src/dst concepts in your edge definitions "
                f"belong to the same model as the graph."
            )

    primary_key_cols, fk_cols = get_key_columns(ec.join_cols, ec.links.keys(), mdl)

    result: dict[str, ConceptInfo] = {}
    for concept_name, linked_concepts in ec.links.items():
        foreign_keys = ec.direct_fks.get(concept_name, {}).copy()
        if fk_cols[concept_name]:
            foreign_keys.update(dict(fk_cols[concept_name]))

        result[concept_name] = ConceptInfo(
            links=set(linked_concepts),
            primary_keys=primary_key_cols[concept_name],
            foreign_keys=foreign_keys,
        )

    if match := has_undirected_edge(result):
        src, dst, et = match
        warnings.warn(
            f"Undirected edge of type {et} detected from {src} to {dst}. "
            "This may cause incorrect GNN training.",
            stacklevel=2,
        )
    return result
