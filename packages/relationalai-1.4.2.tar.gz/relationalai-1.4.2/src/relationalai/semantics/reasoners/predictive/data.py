from dataclasses import dataclass, field
from enum import Enum
from typing import Any, NamedTuple
import re

from relationalai.shims.executor import export_to_csv
from relationalai.semantics import select
import relationalai.semantics as b
from relationalai.semantics.std import strings
from .metamodel_analysis import info_from_edge
from .task_info import TaskInfo, fields_of
from .property_transformer import PropertyTransformer, SemanticType
from .utils import dprint
from relationalai_gnns import (
    ColumnDType, ForeignKey
)


class TableType(str, Enum):
    """GNN table types."""
    NODE = "node"
    EDGE = "edge"


class PendingTable(NamedTuple):
    """A query ready to be exported, with its target table name and lookup key."""
    query: b.Fragment
    table_name: str
    key: str

@dataclass
class GNNTableInfo:
    """
    Bundle of information about a GNN table.
    """
    source: str
    type: TableType
    gle_types: dict[str, ColumnDType] | None = None    
    concept: b.Concept | None = None
    foreign_keys: list[ForeignKey] = field(default_factory=list)
    semantic_types: dict[str, SemanticType] | None = None
    time_col: str | None = None

def get_absolute_csv_path(table_name: str) -> str:
    """Return the absolute path for a CSV export file."""
    return f"/app/cache/export/{table_name}"


# ── Semantic type → GNN column type mapping ─────────────────────
_STYPE_TO_GLE = {
    SemanticType.CONTINUOUS:    ColumnDType("float"),
    SemanticType.INTEGER:       ColumnDType("integer"),
    SemanticType.CATEGORY:      ColumnDType("category"),
    SemanticType.TEXT:          ColumnDType("text"),
    SemanticType.DATETIME:      ColumnDType("datetime"),
    SemanticType.EMBEDDING:     ColumnDType("embedding"),
    SemanticType.MULTICATEGORY: ColumnDType("multi_categorical"),
}


#_INTERNAL_COL_RE = re.compile(r'__row_id_.+\..+\..+')
_INTERNAL_COL_RE = re.compile(r'^__row_id_.+')


def _normalize_text_column(column: b.Variable) -> b.Expression:
    """Apply CSV-safe lightweight normalization to text values for GNN export.

    We flatten multiline/control-whitespace text to reduce parser edge cases
    when exporting/importing through CSV and pandas.
    """
    cleaned = strings.replace(column, "\r\n", " ")
    cleaned = strings.replace(cleaned, "\r", " ")
    cleaned = strings.replace(cleaned, "\n", " ")
    cleaned = strings.replace(cleaned, "\t", " ")
    # A single pass to reduce obvious double spaces introduced by replacements.
    cleaned = strings.replace(cleaned, "  ", " ")
    return strings.lower(strings.strip(cleaned))



def _collect_node_columns(
    concept: b.Concept,
    pt: PropertyTransformer,
) -> tuple[list, dict[str, ColumnDType], dict[str, SemanticType], str|None]:
    """Return the columns to keep, their GNN types, semantic types, and time
    column name for a node concept.

    Returns:
        (keep_cols, gle_types, semantic_types, time_col_name) where *keep_cols*
        starts with the concept itself (primary key) followed by the selected
        column references, *gle_types* maps column names to explicit
        ``ColumnDType`` values (columns annotated as ``infer`` are kept but
        omitted from *gle_types*), *semantic_types* maps column names to their
        ``SemanticType``, and *time_col_name* is the name of the time column
        (or ``None`` if not set).
    """
    col_metadata = pt.field_annotations(concept)
    time_col_name = col_metadata[concept._name][0].get('time_col') # time column
    keep_cols: list[Any] = [concept]  # primary key is always first
    gle_types: dict[str, ColumnDType] = {}
    semantic_types: dict[str, SemanticType] = {}

    for col_name, rel in concept._relationships.items():
        # Skip internal row-id columns.
        if _INTERNAL_COL_RE.match(col_name) is not None:
            continue

        annotations = col_metadata.get(col_name)
        if not annotations:
            continue

        stype = annotations[0]["stype"]
        semantic_types[col_name] = stype
        if stype == SemanticType.DROP:
            continue

        col = getattr(concept, rel._short_name)
        if stype == SemanticType.TEXT:
            col = _normalize_text_column(col).alias(col_name)
        keep_cols.append(col)
        if stype != SemanticType.INFER:
            gle_types[col_name] = _STYPE_TO_GLE[stype]

    return keep_cols, gle_types, semantic_types, time_col_name



def collect_gnn_table_queries(
    edge: b.Concept,
    output_db: str | None,
    output_schema: str | None,
    name: str,
    pt: PropertyTransformer,
    *,
    ignore: list[str] | None = None,
) -> tuple[dict[str, 'GNNTableInfo'], list[PendingTable]]:
    """Collect GNN node/edge queries without executing them.

    Walks every concept in *edge*'s graph, builds one **node query** per
    concept and one **edge query** per directed link, then returns a
    metadata catalogue alongside the pending queries ready for batch export.

    Args:
        edge: The edge concept that defines the graph.
        output_db: Snowflake database for the output tables.
        output_schema: Snowflake schema for the output tables.
        name: Base name used in generated table names.
        pt: ``PropertyTransformer`` that decides which columns to keep
            and what GNN type each column should be.
        ignore: Concept names to skip entirely.

    Returns:
        (gnn_tables_info, pending) where gnn_tables_info has empty sources
        and pending is a list of PendingTable entries ready for batch export
        or individual Snowflake writes.
    """
    mdl = edge._model
    concept_info = info_from_edge(edge)
    ignore_set = set(ignore or [])

    gnn_tables_info: dict[str, GNNTableInfo] = {}
    pending: list[PendingTable] = []

    for concept_name, n_info in concept_info.items():
        if concept_name in ignore_set:
            continue

        concept = mdl.concept_index.get(concept_name)
        if concept is None:
            available = ", ".join(sorted(mdl.concept_index))
            raise ValueError(
                f"Unknown concept '{concept_name}' referenced in graph metadata. "
                f"Available concepts: {available}"
            )

        # ── Node table ───────────────────────────────────────────
        keep_cols, gle_types, semantic_types, time_col_name = _collect_node_columns(concept, pt)
        node_query = select(*keep_cols)
        node_table_name = (
            f"{output_db}.{output_schema}._GNN_{name}_{concept_name.upper()}"
            if output_db and output_schema else ""
        )
        pending.append(PendingTable(node_query, node_table_name, concept_name))
        gnn_tables_info[concept_name] = GNNTableInfo(
            source="",
            type=TableType.NODE,
            gle_types=gle_types,
            concept=concept,
            foreign_keys=[],
            semantic_types=semantic_types,
            time_col=time_col_name,
        )

        # ── Edge tables (one per outgoing link) ──────────────────
        for dst_name, edge_type in n_info.links:
            dst = mdl.concept_index[dst_name].ref()
            eref = mdl.concept_index[edge_type].ref()
            edge_key = f"{eref._name.upper()}_{concept_name.upper()}_{dst_name.upper()}"
            edge_query = select(eref.src, eref.dst).where(
                eref.src == concept, eref.dst == dst,
            )
            edge_table_name = (
                f"{output_db}.{output_schema}._GNN_{eref._name.upper()}_"
                f"{concept_name.upper()}_{dst_name.upper()}"
                if output_db and output_schema else ""
            )
            pending.append(PendingTable(edge_query, edge_table_name, edge_key))
            gnn_tables_info[edge_key] = GNNTableInfo(
                source="",
                type=TableType.EDGE,
                foreign_keys=[
                    ForeignKey(column_name="src", link_to=f"{concept_name}.{concept_name.lower()}"),
                    ForeignKey(column_name="dst", link_to=f"{dst_name}.{dst_name.lower()}"),
                ],
            )

    return gnn_tables_info, pending


def _build_task_query(
    rel_task_table: b.Relationship | b.Chain | b.Fragment,
) -> object:
    """Build a select query from a task relationship/fragment."""
    if isinstance(rel_task_table, b.Fragment):
        return rel_task_table
    all_cols = [rel_task_table[ix] for ix in range(len(fields_of(rel_task_table)))]
    return select(*all_cols)


def _alias_task_columns(query, task_info: TaskInfo) -> None:
    """Rename query columns in-place to match GNN conventions.

    The GNN service expects fixed column names:
      - Column 0 → source concept PK  (e.g. ``"customer"``)
      - Column 1 → time column         (only when ``task_info.time_column`` is set)
      - Last column → target concept FK (only for link-prediction tasks)
    """
    # Source concept primary key is always first.
    query._select[0] = query._select[0].alias(task_info.src_foreign_key.column_name)

    # Optional time column comes second.
    next_ix = 1
    if task_info.time_column:
        query._select[1] = query._select[1].alias(task_info.time_column)
        next_ix += 1

    # Target foreign key occupies the last position (link-prediction tasks).
    if task_info.tgt_foreign_key and next_ix == len(query._select) - 1:
        query._select[next_ix] = query._select[next_ix].alias(
            task_info.tgt_foreign_key.column_name
        )


def collect_task_query(
    rel_task_table: b.Relationship | b.Chain | b.Fragment,
    split_name: str,
    output_db: str | None,
    output_schema: str | None,
    task_info: TaskInfo,
) -> tuple:
    """Build and alias a task query without materializing it.

    Returns:
        (query, table_name) ready for batch export or individual Snowflake write.
    """
    query = _build_task_query(rel_task_table)
    _alias_task_columns(query, task_info)
    assert task_info.task_type is not None
    table_name = (
        f"{output_db}.{output_schema}._GNN_{task_info.name}_{task_info.task_type.value.upper()}_{split_name.upper()}"
        if output_db and output_schema else ""
    )
    return query, table_name



def collect_all_queries(
    edge: b.Concept,
    database: str | None,
    schema: str | None,
    task_relations: dict,
    task_info: TaskInfo,
    pt: PropertyTransformer,
) -> tuple[list[PendingTable], list[PendingTable], dict[str, 'GNNTableInfo']]:
    """Collect task and GNN node/edge queries without executing them.

    Builds one **task query** per split in *task_relations* and delegates to
    ``collect_gnn_table_queries`` for node and edge queries, returning all
    pending queries alongside the metadata catalogue the GNN SDK can consume.

    Args:
        edge: The edge concept that defines the graph.
        database: Snowflake database for the output tables.
        schema: Snowflake schema for the output tables.
        task_relations: Mapping of split name (e.g. ``"train"``, ``"validation"``)
            to the relationship or fragment defining that split's rows.
        task_info: ``TaskInfo`` that describes column layout and task type.
        pt: ``PropertyTransformer`` that decides which columns to keep
            and what GNN type each column should be.

    Returns:
        (task_pending, gnn_pending, gnn_tables_info) where each pending list
        contains PendingTable entries ready for batch export.
    """
    task_pending: list[PendingTable] = []
    for split_name, rel in task_relations.items():
        query, table_name = collect_task_query(rel, split_name, database, schema, task_info)
        task_pending.append(PendingTable(query, table_name, split_name))

    gnn_tables_info, gnn_pending = collect_gnn_table_queries(edge, database, schema, edge._name, pt)
    return task_pending, gnn_pending, gnn_tables_info


def export_tables_csv(
    task_pending: list[PendingTable],
    gnn_pending: list[PendingTable],
    gnn_tables_info: dict[str, 'GNNTableInfo'],
) -> dict[str, str]:
    """Export all pending queries in a single parallel ``export_to_csv`` call.

    Splits the returned paths back into task and GNN buckets, resolves each
    to an absolute path, and updates *gnn_tables_info* in-place.

    Args:
        task_pending: PendingTable entries for task (train/validation/test) tables.
        gnn_pending: PendingTable entries for GNN node and edge tables.
        gnn_tables_info: Metadata catalogue updated in-place with the exported CSV paths.

    Returns:
        Mapping of split name → absolute CSV path for each task table.
    """
    all_queries = [p.query for p in task_pending] + [p.query for p in gnn_pending]
    csv_paths = export_to_csv(all_queries)

    task_paths = csv_paths[:len(task_pending)]
    gnn_paths  = csv_paths[len(task_pending):]

    task_data_source = {}
    for path, pending in zip(task_paths, task_pending):
        task_data_source[pending.key] = get_absolute_csv_path(path)
        dprint(f"  ✓ Exported {pending.key} task table")

    for path, pending in zip(gnn_paths, gnn_pending):
        gnn_tables_info[pending.key].source = get_absolute_csv_path(path)
        dprint(f"  ✓ Exported {pending.key} table")

    return task_data_source


def export_tables_snowflake(
    task_pending: list[PendingTable],
    gnn_pending: list[PendingTable],
    gnn_tables_info: dict[str, 'GNNTableInfo'],
    task_model: 'b.Model',
    gnn_model: 'b.Model',
) -> dict[str, str]:
    """Write all pending queries individually to Snowflake.

    Executes each query with ``.into(...).exec()``, updating *gnn_tables_info*
    in-place with the fully-qualified table names.

    Args:
        task_pending: PendingTable entries for task (train/validation/test) tables.
        gnn_pending: PendingTable entries for GNN node and edge tables.
        gnn_tables_info: Metadata catalogue updated in-place with the Snowflake table names.
        task_model: RAI model used to create Snowflake table references for task tables.
        gnn_model: RAI model used to create Snowflake table references for GNN tables.

    Returns:
        Mapping of split name → fully-qualified Snowflake table name for each task table.
    """
    task_data_source = {}
    for pending in task_pending:
        pending.query.into(task_model.Table(pending.table_name)).exec()
        task_data_source[pending.key] = pending.table_name
        dprint(f"  ✓ Exported {pending.key} task table → {pending.table_name}")

    for pending in gnn_pending:
        pending.query.into(gnn_model.Table(pending.table_name)).exec()
        gnn_tables_info[pending.key].source = pending.table_name
        dprint(f"  ✓ Exported {pending.key} table → {pending.table_name}")

    return task_data_source


def csv_path_to_concept_map(
    gnn_tables_info: dict,
    task_data_source: dict | None = None,
) -> dict[str, str]:
    """Return a mapping from CSV path → human-readable concept/table name.

    Works by extracting the unique export-UUID directory from each stored path
    so we can match it against the path printed in the GNN engine log lines.
    """
    mapping: dict[str, str] = {}
    for key, info in gnn_tables_info.items():
        if info.source:
            mapping[info.source] = key
    if task_data_source:
        for split_name, path in task_data_source.items():
            if path:
                mapping[path] = split_name
    return mapping
