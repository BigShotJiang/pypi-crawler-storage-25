"""Semantic type annotations for GNN feature columns."""

import sys
if sys.version_info >= (3, 11):
    from enum import StrEnum
else:
    from enum import Enum
    class StrEnum(str, Enum):  # type: ignore[no-redef]
        pass
from typing import List, Optional
from collections import defaultdict

from relationalai.semantics import Concept, Chain, require, std, Property
from relationalai.util.docutils import include_in_docs

# include this module in the docs
__include_in_docs__ = True

class SemanticType(StrEnum):
    """Semantic types used by the predictive data preparation pipeline."""
    CONTINUOUS = "continuous"
    INTEGER = "integer"
    CATEGORY = "category"
    TEXT = "text"
    MULTICATEGORY = "multicategory"
    DATETIME = "datetime"
    EMBEDDING = "embedding"
    DROP = "drop"
    INFER = "infer"

@include_in_docs
class PropertyTransformer:
    """Annotate concept fields with semantic types for GNN data preparation.

    A ``PropertyTransformer`` tells the :class:`GNN` pipeline how to encode each
    column before training.  Pass lists of concept fields (``Concept.field``
    chains) or entire :class:`~relationalai.semantics.Concept` objects to the
    constructor, grouped by semantic type.

    Fields that are not mentioned are auto-inferred (``SemanticType.INFER``).
    Passing a :class:`~relationalai.semantics.Concept` instead of a field sets
    the default type for **all** unmentioned fields of that concept.

    Parameters
    ----------
    text : list of Chain or Concept, optional
        Fields containing free-form text, embedded via a language model
        (e.g. product names, descriptions).
    category : list of Chain or Concept, optional
        Fields with discrete categorical values — enum codes, boolean flags,
        status strings, or numeric IDs that represent categories.
    datetime : list of Chain or Concept, optional
        Date or timestamp fields.
    continuous : list of Chain or Concept, optional
        Numeric fields representing continuous measurements (e.g. price, age,
        rating).
    integer : list of Chain or Concept, optional
        Integer fields that should be kept as integers rather than treated as
        categorical.
    drop : list of Chain or Concept, optional
        Fields (or entire concepts) to exclude from the model.  Commonly used
        for primary keys, foreign keys, and target columns.
    time_col : Chain or list of Chain, optional
        The column(s) used for temporal ordering in temporal models.  Each
        concept may have at most one ``time_col``.  A ``time_col`` field cannot
        also be dropped.

    Examples
    --------
    >>> pt = PropertyTransformer(
    ...     category=[User.gender, Event.city, Event.country],
    ...     continuous=[User.age, Event.lat, Event.lng],
    ...     datetime=[Event.start_time],
    ...     drop=[User.user_id],
    ...     time_col=[Event.start_time],
    ... )

    Drop all fields of a concept by passing the concept itself:

    >>> pt = PropertyTransformer(
    ...     category=[Article.product_code],
    ...     drop=[Customer],
    ... )

    For columns with spaces or special characters (e.g. ``"weight(kg)"``,
    ``"fasting blood sugar"``), use :func:`getattr` to reference them:

    >>> pt = PropertyTransformer(
    ...     continuous=[
    ...         getattr(People, "weight(kg)"),
    ...         getattr(People, "fasting blood sugar"),
    ...     ]
    ... )
    """

    def __init__(
        self,
        *,
        text:Optional[list[Chain | Concept]] = None,
        category:Optional[list[Chain | Concept]] = None,
        datetime:Optional[list[Chain | Concept]] = None,
        continuous:Optional[list[Chain | Concept]] = None,
        integer:Optional[list[Chain | Concept]] = None,
        drop:Optional[list[Chain | Concept]] = None,
        time_col:Optional[Chain | List[Chain]] = None
    ) -> None:
        # Default annotation for unspecified fields.
        remainder = SemanticType.INFER
        self.concept_remainder = defaultdict(lambda: remainder)
        self.concept_fields = defaultdict(dict)
        self.concept_annos = defaultdict(dict)
        self._model = None  # bound to the first model seen

        if text:
            self.annotate_per_type(text, SemanticType.TEXT)
        if category:
            self.annotate_per_type(category, SemanticType.CATEGORY)
        if datetime:
            self.annotate_per_type(datetime, SemanticType.DATETIME)
        if continuous:
            self.annotate_per_type(continuous, SemanticType.CONTINUOUS)
        if integer:
            self.annotate_per_type(integer, SemanticType.INTEGER)
        if drop:
            self.annotate_per_type(drop, SemanticType.DROP)

        if time_col is not None:
            for tc in self._to_chain_list(time_col):
                self._set_time_col(tc)

    def _check_model(self, concept: Concept) -> None:
        if self._model is None:
            self._model = concept._model
        elif self._model is not concept._model:
            raise ValueError(
                f"property_transformer: concept '{concept._name}' belongs to model "
                f"'{concept._model.name}' but this PropertyTransformer is already bound "
                f"to model '{self._model.name}'. All concepts must come from the same model."
            )

    def _to_chain_list(self, time_col: Chain | List[Chain]) -> list[Chain]:
        if isinstance(time_col, list):
            return time_col
        return [time_col]

    def _effective_stype(self, concept_name: str, field_name: str) -> SemanticType:
        remainder = self.concept_remainder[concept_name]
        return self.concept_fields[concept_name].get(field_name, remainder)

    def _set_time_col(self, time_chain: Chain) -> None:
        """Attach a single time column annotation for a concept."""
        concept = time_chain._start
        if not isinstance(concept, Concept):
            raise ValueError(
                f"property_transformer: time_col '{repr(time_chain)}' does not start from a Concept"
            )
        self._check_model(concept)
        field_name = time_chain._next._short_name.lower()
        concept_name = concept._name

        stype = self._effective_stype(concept_name, field_name)
        if stype == SemanticType.DROP:
            raise ValueError(
                f"property_transformer: time_col {concept_name}.{field_name} cannot be dropped"
            )
        explicit_stype = self.concept_fields[concept_name].get(field_name)
        if explicit_stype is not None and explicit_stype != SemanticType.DATETIME:
            raise ValueError(
                f"property_transformer: conflicting annotations for {concept_name}.{field_name}: "
                f"time_col requires 'datetime' but field is annotated as '{explicit_stype.value}'"
            )

        existing = self.concept_annos[concept_name].get("time_col")
        if existing is not None:
            raise ValueError(
                "property_transformer: cannot specify more than one time_col for a concept\n"
                f"{concept_name}.{existing} and {concept_name}.{field_name} are time_col"
            )

        self.concept_annos[concept_name]["time_col"] = field_name
                
    def annotate_per_type(
        self,
        anno_fields:list[Chain | Concept],
        stype:SemanticType,
    ) -> None:
        """Map each Concept/field in ``anno_fields`` to ``stype``."""
        for concept_or_field in anno_fields:
            if isinstance(concept_or_field, Concept):
                self._check_model(concept_or_field)
                concept_name = concept_or_field._name
                existing = self.concept_remainder.get(concept_name)
                if existing is not None and existing != stype:
                    raise ValueError(
                        f"property_transformer: conflicting annotations for concept {concept_name}: "
                        f"'{existing.value}' and '{stype.value}'"
                    )
                self.concept_remainder[concept_name] = stype
                continue

            if not isinstance(concept_or_field, Chain):
                raise ValueError(
                    f"property_transformer: cannot annotate type {type(concept_or_field)}. "
                    f"Expected a Concept or property Chain (e.g. Driver.name), "
                    f"got a raw {type(concept_or_field).__name__}."
                )

            field_name = concept_or_field._next._short_name.lower()
            concept = concept_or_field._start
            if not isinstance(concept, Concept):
                raise ValueError(
                    f"property_transformer: '{repr(concept_or_field)}' does not start from a Concept"
                )
            self._check_model(concept)
            concept_name = concept._name
            if field_name not in concept._relationships:
                raise ValueError(
                    f"property_transformer: concept {concept_name} has no field '{field_name}'"
                )
            existing = self.concept_fields[concept_name].get(field_name)
            if existing is not None and existing != stype:
                raise ValueError(
                    f"property_transformer: conflicting annotations for {concept_name}.{field_name}: "
                    f"'{existing.value}' and '{stype.value}'"
                )
            self.concept_fields[concept_name][field_name] = stype

    def field_annotations(self, concept: Concept) -> dict[str, list]:
        """
        Return extracted annotations for a concept's fields and concept metadata.

        Output format:
            - each eligible relationship/property: ``{field_name: [{"stype": ...}]}``
            - concept-level annotations (e.g. ``time_col``): ``{concept_name: [anno_dict]}``
        """
        concept_name = concept._name

        # Resolve stype for each field with concept-level remainder fallback.
        resolved_stype = defaultdict(lambda: self.concept_remainder[concept_name])
        for field_name, stype in self.concept_fields[concept_name].items():
            resolved_stype[field_name] = stype

        annotations: dict[str, list] = {}
        for rel_name, rel in concept._relationships.items():
            # Only export binary relationships/properties.
            if len(rel._fields) != 2:
                continue

            # for Relationships (for which FDs are not defined) create entity -> property value FD
            if not isinstance(rel, Property):
                require(std.constraints.unique(rel[0]))
            annotations[rel_name] = [{"stype": resolved_stype[rel_name]}]

        return annotations | {concept_name: [self.concept_annos[concept_name]]}
