import os

def dprint(*args, **kwargs):
    """Print only if RAI_GNN_DEBUG environment variable is truthy."""
    if os.getenv("RAI_GNN_DEBUG", "false").lower() in ("1", "true", "yes"):
        print(*args, **kwargs)


def get_pipeline_flags():
    """Return (skip_cdc, export_csv) flags from environment variables."""
    skip_cdc = os.getenv("CDC_DISABLED", "true").lower() in ("1", "true", "yes")
    export_csv = os.getenv("CSV_EXPORT_ENABLED", "true").lower() in ("1", "true", "yes")

    dprint(f"  ➜ CDC_DISABLED: {skip_cdc}")
    dprint(f"  ➜ CSV_EXPORT_ENABLED: {export_csv}")

    return skip_cdc, export_csv