from relationalai.client import connect
from relationalai.config import create_config
from relationalai.config.connections import SnowflakeConnection
from relationalai.util.asyncio import run_sync
from relationalai.services.reasoners.models import Reasoner

import asyncio
import time

from relationalai_gnns import SnowflakeConnector


# ---- engine lifecycle ----------------------------------------------------

async def _ensure_reasoner(reasoner_type: str, timeout_s: int = 900) -> Reasoner:
    """Ensure a reasoner of the given type is ready (creates if missing, resumes if suspended)."""
    print(f"  ➜ Ensuring {reasoner_type} reasoner is READY...")
    st = time.time()
    async with await connect(config=create_config()) as client:
        reasoner = await client.reasoners.ensure_ready(reasoner_type, timeout_s=timeout_s)
    print(f"  ✓ {reasoner_type} reasoner {reasoner.name} is READY ({time.time() - st:.2f}s)")
    return reasoner


def ensure_predictive_reasoner(timeout_s: int = 900) -> Reasoner:
    """Ensure the Predictive reasoner is ready."""
    return run_sync(_ensure_reasoner("Predictive", timeout_s=timeout_s))


def ensure_logic_reasoner(timeout_s: int = 900) -> Reasoner:
    """Ensure the Logic reasoner is ready."""
    return run_sync(_ensure_reasoner("Logic", timeout_s=timeout_s))


def ensure_all_reasoners(timeout_s: int = 900) -> tuple[Reasoner, Reasoner]:
    """Ensure both Predictive and Logic reasoners are ready, running both in parallel.

    Returns:
        (predictive_reasoner, logic_reasoner)
    """
    async def _ensure_all():
        return await asyncio.gather(
            _ensure_reasoner("Predictive", timeout_s=timeout_s),
            _ensure_reasoner("Logic", timeout_s=timeout_s),
        )
    predictive, logic = run_sync(_ensure_all())
    return predictive, logic

def create_gnn_connector(
    *,
    export_csv: bool = True,
    timeout_s: int = 900,
) -> tuple[Reasoner, SnowflakeConnector]:
    """Ensure the Predictive reasoner is READY, then create and return a GNN connector.

    Returns:
        (reasoner, connector) — the ready Reasoner and its SnowflakeConnector.

    Raises:
        TimeoutError: if the reasoner does not become READY within timeout_s.
    """
    reasoner = ensure_predictive_reasoner(timeout_s=timeout_s)
    config = create_config()
    connection = config.get_connection(SnowflakeConnection)
    connector_kwargs = {
        "app_name": connection.rai_app_name,
        "role": connection.role,
        "auth_method": "active_session",
        "engine_name": reasoner.name,
    }
    if export_csv:
        connector_kwargs["connector_type"] = "csv"
    return reasoner, SnowflakeConnector(**connector_kwargs)
