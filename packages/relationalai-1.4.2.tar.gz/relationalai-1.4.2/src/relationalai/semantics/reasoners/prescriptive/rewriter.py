"""Expression compiler: DSL expressions → Hash-based AST nodes.

Compiles Python DSL expressions (arithmetic, comparisons, aggregates,
constraints) into Hash-based AST nodes stored as model defines. The solver
service deserializes these AST nodes to reconstruct the problem in MOI form.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, NoReturn, Optional

from relationalai.semantics.frontend import base as b
from relationalai.semantics.frontend.core import Hash
from relationalai.semantics import std

from .wire_format import (
    _bind_tuple_hash,
    _FIRST_ORDER_CODES,
    _COMPARISON_CODES,
    _HIGHER_ORDER_CODES,
    _UNSUPPORTED_OPS,
)

if TYPE_CHECKING:
    from .problem import Problem


class SymbolicNode:
    """Wrapper marking an expression as containing decision variables."""

    def __init__(self, expr: Any) -> None:
        # The guard catches rewrite paths that forget to extract ``.expr`` before
        # re-wrapping — a common mistake when a handler delegates to another handler
        # and then wraps the result again.
        if isinstance(expr, SymbolicNode):
            raise TypeError("Cannot double-wrap SymbolicNode.")
        self.expr = expr


def _expr_dict_key(expr: Any) -> int:
    """Get unique integer key for an expression."""
    key = expr.to_dict_key()
    if not isinstance(key, int):
        raise TypeError(f"Expression key must be int, got {type(key).__name__}.")
    return key


_DISTINCT_NOT_SUPPORTED_MSG = "`distinct` not yet supported in problem expressions."

# RAI-49989.
_MIXED_MATCH_ARMS_MSG = (
    "Prescriptive rewriter cannot handle a ``|`` (match) expression with "
    "mixed symbolic (decision-variable-bearing) and non-symbolic "
    "(constant / literal) arms. "
    "Workaround: drive both arms to a decision-variable-bearing aggregate "
    "so both rewrite the same way — e.g. replace "
    "``sum(X.v).where(X.i == 999) | 42.0`` with "
    "``sum(X.v).where(X.i == 999) | sum(X.v)`` (both arms over the same DV "
    "property). A literal-constant fallback isn't currently supported. "
    "Tracked as RAI-49989."
)

_MIXED_UNION_ARMS_MSG = (
    "Prescriptive rewriter cannot handle a ``model.union(...)`` with mixed "
    "symbolic (decision-variable-bearing) and non-symbolic (constant / "
    "literal) arms. "
    "Workaround: drive both arms to a decision-variable-bearing aggregate "
    "so both rewrite the same way — e.g. replace "
    "``model.union(sum(X.v).where(X.i == 999), 42.0)`` with "
    "``model.union(sum(X.v).where(X.i == 999), sum(X.v))`` (both arms over "
    "the same DV property). A literal-constant fallback isn't currently "
    "supported. Tracked as RAI-49989."
)

class ExpressionCompiler:
    """Compiles DSL expressions into Hash-based AST nodes for the solver service."""

    # Expression types not supported in problem expressions (checked by rewrite()).
    _UNSUPPORTED_EXPRS: list[tuple[type | tuple[type, ...], str]] = [
        (b.New, "Cannot use 'New' expressions in problem expressions."),
        (
            b.FieldRef,
            "Cannot use field indexing in problem expressions. "
            "Use an explicit ref binding: qty = Float.ref(); sum(qty * X.var).where(X.rel(Y, qty)).per(Y)",
        ),
        (b.MetaRef, "Cannot use meta-references in problem expressions."),
        (b.AsBool, "Cannot use 'as_bool()' in problem expressions. Use comparison operators directly."),
        ((b.Not, b.Group), "`not`/`group` not supported in problem expressions."),
        ((b.DerivedTable, b.DerivedColumn), "Cannot use derived tables/columns in problem expressions."),
    ]

    # Dispatch by *exact* type (``type(expr)``), not ``isinstance``. Entries appear
    # here for two reasons:
    #   1. The type needs a dedicated handler — e.g. Alias delegates to its source,
    #      Distinct rejects via ``NoReturn``.
    #   2. The type is a subclass of another dispatched type and must be listed
    #      explicitly to avoid silently routing to the parent's handler — e.g.
    #      Property → Relationship, Union → Match.
    # This prevents surprises when a new AST subclass is introduced and happens to
    # match a parent handler.
    _REWRITE_DISPATCH: dict[type, str] = {
        b.Alias: "_rewrite_alias",
        b.Distinct: "_rewrite_distinct",
        b.Concept: "_rewrite_variable_ref",
        b.Ref: "_rewrite_variable_ref",
        b.Chain: "_rewrite_chain",
        b.Relationship: "_rewrite_relationship",
        b.Property: "_rewrite_relationship",  # Property is subclass of Relationship
        b.Reading: "_rewrite_relationship",  # Shared handler; value-field check is a no-op for non-Readings
        b.Match: "_rewrite_match",
        b.Union: "_rewrite_match",
        b.FilterBy: "_rewrite_filter_by",
        b.Expression: "_compile_arithmetic",
        b.Aggregate: "_rewrite_aggregate",
        b.Fragment: "_rewrite_fragment",
    }

    # Each rewrite() frame adds ~2-3 Python frames (rewrite → _rewrite_inner → handler),
    # so 400 rewrite depth ≈ 800-1200 Python frames. Python's default recursion limit
    # is 1000, so this leaves headroom without reaching the interpreter limit. Users
    # hitting this should simplify their expression rather than raise sys.setrecursionlimit.
    # The annotation is explicit so tests can shadow it on an instance.
    _MAX_REWRITE_DEPTH: int = 400

    def __init__(self, problem: Problem) -> None:
        self.model = problem._model
        self.problem = problem
        self.bound_variables: dict[int, Any] = {}
        self.defines: list[Any] = []
        self.wheres: list[Any] = []
        self.children: list[ExpressionCompiler] = []
        self._rewrite_depth = 0
        # Index into ``defines`` marking where this scope's own contributions
        # begin. Entries before this index were copied from a parent scope for
        # internal grounding and must not be re-emitted by
        # ``Problem._emit_defines`` — the parent already owns them. (Wheres
        # don't need an equivalent cursor because ``_emit_defines`` emits
        # ``where(*compiler.wheres)`` for every compiler: each scope's full
        # wheres list is the gating clause the parent expects.)
        self._owned_defines_start = 0
        # Set whenever a rewrite in this scope returns a ``SymbolicNode`` or
        # pass-1 of ``rewrite_where`` binds a decision-variable entity.
        # Used in place of comparing rewritten sub-ASTs back to their
        # originals — Fragment ``__eq__`` raises on empty-column fragments,
        # which ``_bind_variable_entity`` can synthesize.
        #
        # The public-looking attribute is a property (below) that OR's this
        # backing field with every descendant scope's flag, so handlers that
        # create child scopes (``_rewrite_match`` branches, ``_rewrite_fragment``)
        # don't need to manually propagate DV activity back up — callers that
        # check ``scope._touched_variable`` see the full transitive signal.
        self._touched_variable_self = False

        # RAI-50087. Data-side DSL nodes (Concept/Ref) touched at THIS scope by
        # variable-ref rewriting. Used by ``_rewrite_aggregate`` to discriminate
        # outer iterations on the solver wire when the body walks to an inner
        # per-aggregate. NOT transitive to children — each scope's own anchors
        # discriminate that scope's iteration; child scopes discriminate their
        # own. Populated by ``_rewrite_variable_ref`` whenever a Concept/Ref
        # passes through, while ``_record_anchors`` is True.
        # ``_rewrite_aggregate`` flips the flag off around two slots that
        # would otherwise pollute the anchor set: ``rewrite_where`` (where
        # atoms are grounding guards, not iteration positions — recording
        # their entity refs would yield wire output with unbound vars), and
        # the synthetic auto-output Ref in ``rw_args`` for non-SOS
        # aggregates (an internal placeholder, not a user surface).
        self._data_anchors_self: list[Any] = []
        self._record_anchors: bool = True

        # RAI-50087. True iff this scope was spawned as the child of an
        # ``Aggregate`` with a non-empty ``.per(...)``. ``_rewrite_aggregate``
        # checks ``any(c._is_per_aggregate for c in self.children)`` to detect
        # the inner-per-over-outer-sum shape that needs the per-cell
        # discriminator. Set by ``_rewrite_aggregate`` right after
        # ``_create_scope`` on the child.
        self._is_per_aggregate = False

    @property
    def _touched_variable(self) -> bool:
        """True iff this scope or any descendant scope touched a decision variable.

        DV activity can happen at any scope depth — a fragment inside a match
        branch inside an aggregate can bind a DV entity via pass-1 of
        ``rewrite_where`` without the intermediate handlers returning a
        ``SymbolicNode``. The transitive OR ensures the outer aggregate's
        "pure-data pass-through vs. raise" decision sees the real signal.
        """
        return self._touched_variable_self or any(c._touched_variable for c in self.children)

    @_touched_variable.setter
    def _touched_variable(self, value: bool) -> None:
        self._touched_variable_self = value

    def _create_scope(self) -> ExpressionCompiler:
        """Create child scope for nested expressions (e.g., aggregates).

        Copies bound variables (so the child can reference outer variables),
        and wheres/defines (so the child's internal ``select().where()`` has
        access to outer grounding). The child's ``_owned_defines_start``
        tracks which slice of ``defines`` is its own contribution for
        emission purposes.

        ``_grounded(...)`` atoms are stripped from the inherited wheres:
        they are parent-only gates that discriminate which outer rows the
        outer identity binding fires on. Copying them into the child
        would put ``_grounded`` into the body of the child's own
        ``_grounded(node)`` derivation — an unnecessary self-reference
        that complicates backend stratification for no benefit. The
        strip keeps each scope's own-define for ``_grounded`` cleanly
        scoped. Note: a nested aggregate does append ``_grounded(inner)``
        to the parent scope's wheres *after* this copy, so the parent's
        own rule can reference inner groundedness — PyRel's LQP backend
        handles that relation-level self-reference fine.
        """
        child = ExpressionCompiler(self.problem)
        child.bound_variables = self.bound_variables.copy()
        child.defines = self.defines.copy()
        child.wheres = [w for w in self.wheres if not self._is_grounded_gate(w)]
        child._owned_defines_start = len(child.defines)
        child._rewrite_depth = self._rewrite_depth
        self.children.append(child)
        return child

    def _is_grounded_gate(self, where: Any) -> bool:
        """True if ``where`` is a ``_grounded(hash)`` atom emitted as a
        parent-side aggregate gate."""
        return isinstance(where, b.Expression) and where._op is self.problem._grounded

    # =========================================================================
    # Public Rewriting Methods
    # =========================================================================

    def rewrite_where(self, *exprs: Any, role: str = "where clause") -> list[Any]:
        """Rewrite where clauses in two passes: variable relationships first, then rest.

        ``role`` is threaded to ``_passthrough`` so that symbolic-in-data-slot
        errors name the specific slot (e.g. ``"aggregate where clause"``,
        ``"fragment where clause"``).
        """
        results: list[Any] = []

        # Pass 1: Variable relationships populate bound_variables.
        for expr in exprs:
            if isinstance(expr, b.Expression) and isinstance(expr._op, b.Relationship):
                self._check_reading_value_field(expr._op)
                if self._variable_lookup_key(expr._op) in self.problem._variable_relationships:
                    results.append(self._bind_variable_entity(expr))
                    continue
            results.append(None)

        # Pass 2: Rewrite remaining expressions (may reference pass 1 variables).
        for i, expr in enumerate(exprs):
            if results[i] is None:
                # Scalars/literals don't have to_dict_key(); skip bound_variables check.
                if hasattr(expr, "to_dict_key"):
                    key = _expr_dict_key(expr)
                    if key in self.bound_variables:
                        results[i] = expr
                        continue
                results[i] = self._passthrough(expr, role=role)

        return results

    def rewrite(self, expr: Any) -> Optional[SymbolicNode | Any]:
        """Rewrite expression using dispatch table.

        Returns
        -------
        SymbolicNode or Any or None
            ``SymbolicNode`` if expression contains decision variables,
            a rewritten expression if modified but not symbolic,
            or ``None`` if no rewriting was needed.
        """
        # Base cases: literals, None, and data sources (no rewriting needed).
        if expr is None or isinstance(expr, (int, float, str, b.Literal, b.Table, b.Data)):
            return None

        self._rewrite_depth += 1
        if self._rewrite_depth > self._MAX_REWRITE_DEPTH:
            raise RecursionError(
                f"Expression tree exceeds maximum depth ({self._MAX_REWRITE_DEPTH}). "
                f"Simplify the expression or break it into smaller sub-expressions."
            )
        try:
            result = self._rewrite_inner(expr)
            if isinstance(result, SymbolicNode):
                self._touched_variable = True
            return result
        finally:
            self._rewrite_depth -= 1

    def _rewrite_inner(self, expr: Any) -> Optional[SymbolicNode | Any]:
        handler_name = self._REWRITE_DISPATCH.get(type(expr))
        if handler_name is not None:
            return getattr(self, handler_name)(expr)
        for types, msg in self._UNSUPPORTED_EXPRS:
            if isinstance(expr, types):  # type: ignore[arg-type]
                raise ValueError(msg)
        raise NotImplementedError(f"Expression type '{type(expr).__name__}' not supported in problem expressions.")

    # -------------------------------------------------------------------------
    # Type-specific rewrite handlers
    # -------------------------------------------------------------------------

    def _rewrite_alias(self, expr: b.Alias) -> Optional[SymbolicNode | Any]:
        """Rewrite Alias by delegating to its source item."""
        return self.rewrite(expr._source_item)

    def _rewrite_distinct(self, _expr: b.Distinct) -> NoReturn:
        """Reject free-standing ``Distinct(...)`` outside an aggregate.

        Inside an aggregate the wrapper is consumed at construction time,
        leaving ``Aggregate._distinct=True``; ``_rewrite_aggregate`` raises
        the same error there via the shared ``_DISTINCT_NOT_SUPPORTED_MSG``.

        Raises ``NotImplementedError`` (previously ``ValueError`` when routed
        through ``_UNSUPPORTED_EXPRS``).
        """
        raise NotImplementedError(_DISTINCT_NOT_SUPPORTED_MSG)

    def _rewrite_variable_ref(self, expr: b.Concept | b.Ref) -> Optional[SymbolicNode]:
        """Rewrite Concept or Ref that may be a decision variable.

        Records ``expr`` as a data-side iteration anchor when it is not bound
        to a decision variable and ``_record_anchors`` is True.
        ``_rewrite_aggregate`` consults ``_data_anchors_self`` (RAI-50087)
        when the body walks to an inner per-aggregate, threading the anchors
        into the existing ``arg_hash`` material so distinct outer iterations
        get distinct wire identities. DV-bound value Refs (``v`` from
        ``.where(X.v(v))``) intentionally do NOT record — the wire's per-cell
        ``arg_hash`` would discriminate them by the DV's per-entity
        ``var_ref`` (one per X), giving bag-over-entities rather than
        PyRel's set-projection on body values; that residual divergence is
        pinned by ``test_e2e_rewriter_dv_bound_value_ref_minizinc``.
        """
        key = _expr_dict_key(expr)
        if key in self.bound_variables:
            return SymbolicNode(self.bound_variables[key])
        # Data-side anchor — Concept/Ref returned as ``None`` flows through
        # ``_passthrough`` unchanged into the wire. Recording the DSL node
        # here lets the outer ``_rewrite_aggregate`` include it in the
        # ``arg_hash`` tuple as a per-iteration discriminator.
        if self._record_anchors:
            self._data_anchors_self.append(expr)
        return None

    def _rewrite_chain(self, expr: b.Chain) -> Optional[SymbolicNode]:
        """Rewrite Chain (entity.relationship). Returns SymbolicNode if relationship is a decision variable."""
        start, next_expr = expr._start, expr._next

        # Handle nested chains (e.g., Factory.product.amount):
        # resolve intermediate chain's target concept and use it as parent for variable lookup.
        if isinstance(start, b.Chain):
            start_result = self.rewrite(start)
            if isinstance(start_result, SymbolicNode):
                raise ValueError("Chain start must not be symbolic.")
            if isinstance(next_expr, b.Relationship):
                self._check_reading_value_field(next_expr)
                result = self._get_variable_ref(next_expr, start)
                if result is not None:
                    key, var_ref = result
                    self.bound_variables[key] = var_ref
                    return SymbolicNode(var_ref)
            return start_result

        if not isinstance(start, (b.Concept, b.Ref)):
            raise TypeError(f"Chain start must be Concept or Ref, got {type(start).__name__}.")
        if isinstance(self.rewrite(start), SymbolicNode):
            raise ValueError("Chain start must not be symbolic.")

        # Check if the relationship part is a decision variable.
        if isinstance(next_expr, b.Relationship):
            self._check_reading_value_field(next_expr)
            result = self._get_variable_ref(next_expr, start)
            if result is not None:
                key, var_ref = result
                self.bound_variables[key] = var_ref
                return SymbolicNode(var_ref)
        return None

    @staticmethod
    def _variable_lookup_key(rel: b.Relationship) -> int:
        """Get the variable lookup key, resolving Readings to their parent.

        Readings reference the same underlying relationship as their parent,
        so variable lookups should use the parent's key.
        """
        parent = rel._relationship if isinstance(rel, b.Reading) else rel
        return _expr_dict_key(parent)

    def _check_reading_value_field(self, expr: b.Relationship) -> None:
        """Raise if a Reading moves the value field out of last position.

        Entity-field reordering is fine — the solver binds by field name,
        not position. But the last field is the decision variable value;
        moving it breaks variable binding.
        """
        if not isinstance(expr, b.Reading):
            return
        parent = expr._relationship
        key = self._variable_lookup_key(expr)
        if key in self.problem._variable_relationships or key in self.bound_variables:
            if expr._fields[-1] is not parent._fields[-1]:
                parent_name = parent._short_name or getattr(parent, "_name", None) or type(parent).__name__
                raise ValueError(
                    f"Cannot use alternative reading (`.alt()`) that reorders the value field "
                    f"of relationship '{parent_name}'. The last field of a decision-variable "
                    f"relationship must remain the value field. Use the original relationship "
                    f"or a reading that only reorders entity fields."
                )

    def _rewrite_relationship(self, expr: b.Relationship) -> Optional[SymbolicNode]:
        """Rewrite Relationship (or Reading) that may be a decision variable.

        ``_check_reading_value_field`` is a no-op for non-Readings, so a
        Reading and its parent share the same handler.
        """
        self._check_reading_value_field(expr)
        return self._lookup_or_bind_variable(expr)

    def _lookup_or_bind_variable(self, expr: b.Relationship) -> Optional[SymbolicNode]:
        """Return a cached SymbolicNode for *expr*, or bind it fresh if it's a variable.

        Uses ``_variable_lookup_key`` so Readings resolve to their parent's key, which
        ensures a Reading and its parent share one cache entry. Returns ``None`` if
        *expr* is not a decision variable.
        """
        key = self._variable_lookup_key(expr)
        if key in self.bound_variables:
            return SymbolicNode(self.bound_variables[key])
        result = self._get_variable_ref(expr, None)
        if result is not None:
            ret_key, var_ref = result
            self.bound_variables[ret_key] = var_ref
            return SymbolicNode(var_ref)
        return None

    def _rewrite_match(self, expr: b.Match) -> Optional[SymbolicNode | Any]:
        """Rewrite Match/Union expression.

        Each branch is rewritten in its own child scope so hash bindings
        from arithmetic expressions are isolated.  Symbolic branches are
        wrapped in a Fragment that carries the child's grounding
        conditions, keeping the result self-contained for the groundness
        checker.

        Aggregates over Union flow through here too: the enclosing
        ``_rewrite_aggregate`` emits a single args row whose body is the
        Union for multi-arm cases — ``_unordered_args_hash`` for non-SOS
        aggregates, ``_ordered_args_hash`` for SOS1/SOS2 — and PyRel's
        key-stripping Union semantics (set-on-projected-values) are
        preserved end-to-end. A single-arm symbolic Union flattens to
        the branch fragment directly (the Union wrapper is a no-op over
        one set), so the body in that case is the branch fragment rather
        than a Union.
        """
        items = expr._items
        rewritten: list[Any] = []
        has_symbolic = False
        has_non_symbolic = False
        any_rewrote = False

        for item in items:
            child = self._create_scope()
            result = child.rewrite(item)
            if isinstance(result, SymbolicNode):
                has_symbolic = True
                rewritten.append(self.model.select(result.expr).where(*child.wheres))
            else:
                has_non_symbolic = True
                if result is not None:
                    any_rewrote = True
                rewritten.append(result if result is not None else item)

        # RAI-49989 — mixed symbolic / non-symbolic Match arms aren't typer-
        # compatible: the symbolic arm becomes a Hash reference while the
        # non-symbolic arm passes through as its original (e.g. Number) type.
        # Raise early with a workaround so users see an actionable message
        # instead of a downstream ``TypeMismatch(expected=Number, actual=Hash)``.
        # The aggregate-default form (``sum(...) | sum(...)``) is fine because
        # both arms route through the rewriter and become Hash-typed.
        if has_symbolic and has_non_symbolic:
            msg = _MIXED_UNION_ARMS_MSG if isinstance(expr, b.Union) else _MIXED_MATCH_ARMS_MSG
            raise NotImplementedError(msg)

        if not has_symbolic and not any_rewrote:
            return None

        # Build the appropriate Match or Union. A single-arm symbolic Union
        # is semantically the projected branch relation itself — drop the
        # one-arm Union wrapper so the aggregate body grounds against the
        # branch's select directly.
        if isinstance(expr, b.Union):
            if has_symbolic and len(rewritten) == 1:
                return SymbolicNode(rewritten[0])
            combined = self.model.union(*rewritten)
        else:
            combined = b.Match(self.model, *rewritten)

        return SymbolicNode(combined) if has_symbolic else combined

    def _rewrite_filter_by(self, expr: b.FilterBy) -> Optional[Any]:
        """Rewrite FilterBy expression (symbolic values not allowed)."""
        new_kwargs, modified = {}, False
        for k, v in expr._kwargs.items():
            r = self.rewrite(v)
            if isinstance(r, SymbolicNode):
                raise ValueError(f"Cannot use symbolic value in FilterBy argument '{k}'.")
            new_kwargs[k] = r if r is not None else v
            modified = modified or r is not None

        return expr._params[0].filter_by(**new_kwargs) if modified else None

    def _compile_arithmetic(self, expr: b.Expression) -> Optional[SymbolicNode | Any]:
        """Compile arithmetic/comparison expression. Builds AST node if any arg is symbolic."""
        # Direct check: operator relations (+, <=, abs, ...) must never be decision
        # variables. Avoids a full rewrite() on the operator, which would pointlessly
        # burn recursion budget and could leak a where via _get_variable_ref.
        self._assert_not_variable(expr._op, "Expression operator")
        op = expr._op
        op_name = op._short_name

        args = expr._args
        # First-order ops carry an auto-filled output Ref as their LAST positional
        # arg (``b.Expression.__init__`` fills it with ``f.type.ref(f.name)``).
        # The rewrite below drops it via ``rewritten[:-1]``, so rewriting it is
        # wasted work — and it would land in ``_data_anchors_self`` as a spurious
        # iteration anchor (RAI-50087 wrapper's anchor collection). Skip it.
        skip_output_idx = len(args) - 1 if isinstance(op_name, str) and op_name in _FIRST_ORDER_CODES else -1

        rewritten: list[Any] = []
        has_symbolic = False
        any_rewrote = False
        for i, arg in enumerate(args):
            if i == skip_output_idx:
                rewritten.append(arg)
                continue
            result = self.rewrite(arg)
            if isinstance(result, SymbolicNode):
                has_symbolic = True
            if result is not None:
                any_rewrote = True
            rewritten.append(result if result is not None else arg)

        if not has_symbolic and not any_rewrote:
            return None
        if not has_symbolic:
            return b.Expression(op, rewritten)

        # Build symbolic AST node.
        if not isinstance(op_name, str):
            raise TypeError(f"Operator name must be str, got {type(op_name).__name__}.")

        if op_name in _FIRST_ORDER_CODES:
            op_code = _FIRST_ORDER_CODES[op_name]
            rewritten = rewritten[:-1]  # Drop auto-filled output arg.
        elif op_name in _COMPARISON_CODES:
            op_code = _COMPARISON_CODES[op_name]
        else:
            # Provide helpful error for unsupported operators
            if op_name in _UNSUPPORTED_OPS:
                msg = (
                    f"Operator '{op_name}' is not supported by any solver backend "
                    f"(not available in MOI/MiniZinc/Ipopt/HiGHS)."
                )
            else:
                supported = sorted(list(_FIRST_ORDER_CODES.keys()) + list(_COMPARISON_CODES.keys()))
                msg = (
                    f"Operator '{op_name}' is not supported by the solver engine. "
                    f"Supported operators: {', '.join(supported)}"
                )
            raise NotImplementedError(msg)

        # Create Hash node unique per (expr_id, args).
        hash_args = [a.expr if isinstance(a, SymbolicNode) else a for a in rewritten]
        node = Hash.ref()
        self.wheres.append(_bind_tuple_hash([expr._id, *hash_args], node))
        self.defines.append(self.problem._operator(node, op_code))

        for i, arg in enumerate(rewritten):
            if isinstance(arg, SymbolicNode):
                self.defines.append(self.problem._ordered_args_hash(node, i, arg.expr))
            else:
                self.defines.append(self.problem._ordered_args_data(node, i, arg))

        return SymbolicNode(node)

    def _extract_aggregate_args(self, expr: b.Aggregate, op_name: str) -> tuple[Any, list[Any], list[Any]]:
        """Extract (symbolic arg, other input args, projection args) based on operator type.

        The ``other_args`` slot holds any non-symbolic positional inputs that still need
        to be carried through — e.g. the SOS index. For most aggregates it is empty.
        """
        args, proj_args = list(expr._args), list(expr._projection_args)
        if op_name == "count":
            return proj_args.pop(), args, proj_args
        elif op_name == "rank":
            if not isinstance(args[0], b.TupleVariable):
                raise TypeError(
                    "rank expects a TupleVariable as its first argument; "
                    "aggregates.rank() should always wrap. "
                    f"Got {type(args[0]).__name__}."
                )
            return None, args[0]._items, []
        elif op_name in ("special_ordered_set_type_1", "special_ordered_set_type_2"):
            return args[1], args[:1], proj_args
        else:
            return args[0], args[1:], proj_args

    def _rewrite_aggregate(self, expr: b.Aggregate) -> Optional[SymbolicNode | Any]:
        """Rewrite aggregate (sum/min/max/count/etc).

        Union branches inside the aggregate body are not expanded here —
        they flow through ``_rewrite_match``. For a multi-arm symbolic
        Union the aggregate sees the Union as its body; for a single-arm
        symbolic Union ``_rewrite_match`` flattens the wrapper, so the
        aggregate sees the branch fragment directly. Either way, PyRel's
        ``union`` semantics (key-stripping / set-on-values) are preserved
        at the LQP layer and bag-style expansion (which would diverge
        from PyRel) is avoided.
        """
        if expr._distinct:
            raise NotImplementedError(_DISTINCT_NOT_SUPPORTED_MSG)

        self._assert_not_variable(expr._op, "Aggregate operator")
        op = expr._op
        op_name = op._short_name

        # Extract arguments based on operator type. The unsupported-aggregate
        # reject is deferred to after the ``_touched_variable`` pass-through
        # check — a pure-data ``avg``/``top``/``limit`` aggregate used as a
        # constant in a mixed expression (e.g. ``x >= avg(C.cost)``) must
        # pass through; only the variable-bearing symbolic path cannot lower
        # these aggregates.
        sym_arg, args, proj_args = self._extract_aggregate_args(expr, op_name)

        # Rewrite components in subcontext
        child = self._create_scope()
        # Mark per-aggregate scopes so an enclosing ``_rewrite_aggregate`` can
        # detect "outer ``sum`` over inner ``.per(...)``" via
        # ``any(c._is_per_aggregate for c in self.children)`` (RAI-50087).
        child._is_per_aggregate = bool(expr._group._args)
        # Where atoms are grounding guards, not iteration positions: their
        # entity refs constrain which rows fire, they don't enumerate outer
        # iterations. Recording them as anchors over-anchors the ``arg_hash``
        # material — for shapes like ``sum(v * inner).where(<DV-rel>(v))`` the
        # where-bound entity gets pulled in as a "discriminator" without a
        # corresponding grounding in the body, producing wire output the
        # engine can't ground (``UnboundVariableException``). Keep the
        # observer off during ``rewrite_where``; the body rewrite below
        # picks up the iteration variables (including DV-bound value Refs
        # like ``v`` from ``X.v(v)``) at the use site.
        prev_record = child._record_anchors
        child._record_anchors = False
        try:
            rw_where = child.rewrite_where(*expr._where._where, role=f"aggregate '{op_name}' where clause")
        finally:
            child._record_anchors = prev_record
        # Stage the outer .where() atoms into child.wheres *before* the body
        # rewrite so that nested aggregates (e.g. an inner ``.per(...)`` body)
        # inherit the outer filter via _create_scope's wheres-copy. Without
        # this, an outer ``.where(X.i == 0)`` over a body containing
        # ``sum(X.v).per(X.g)`` would leave the inner per evaluating over
        # the unfiltered X domain while PyRel evaluates it over the
        # filtered subset — silent solver/PyRel divergence.
        child.wheres.extend(rw_where)
        rw_proj = [child._passthrough(a, role=f"aggregate '{op_name}' projection slot") for a in proj_args]
        # For non-SOS aggregates, ``args`` is just the synthetic auto-output
        # Ref (``Aggregate.__init__`` fills ``_args[-num_inputs:]`` with
        # ``f.type.ref(f.name)`` placeholders, and ``_extract_aggregate_args``
        # returns the sym body as ``sym_arg`` and the rest as ``args``). That
        # Ref is not a user-supplied data entity and must not be recorded as
        # an iteration anchor — recording it would pollute the anchor set and
        # let the unanchored-per-aggregate gate skip cases it should catch.
        # For SOS aggregates ``args`` carries the user-supplied SOS index and
        # IS load-bearing for iteration identity, so anchor recording stays
        # on. The split mirrors ``_args``-vs-projection semantics: only user
        # surfaces participate in iteration identity.
        is_sos = op_name in ("special_ordered_set_type_1", "special_ordered_set_type_2")
        if is_sos:
            rw_args = [child._passthrough(a, role=f"aggregate '{op_name}' positional slot") for a in args]
        else:
            prev_record = child._record_anchors
            child._record_anchors = False
            try:
                rw_args = [child._passthrough(a, role=f"aggregate '{op_name}' positional slot") for a in args]
            finally:
                child._record_anchors = prev_record
        rw_group = [child._passthrough(a, role=f"aggregate '{op_name}' group key") for a in expr._group._args]

        # For rank, ``sym_arg`` is None (see ``_extract_aggregate_args``), so
        # ``rewrite(None)`` naturally returns None via the base-case early-return.
        rw_sym = child.rewrite(sym_arg)

        # No decision-variable activity anywhere in this aggregate's scope:
        # body, projection, positional, and where are all pure data. Pass
        # through unchanged so the caller keeps the original aggregate.
        # This covers both ``rw_sym is None`` (nothing rewrote) and
        # ``rw_sym is not None`` but pure-data-rewritten (e.g. a FilterBy
        # inside the body rewrote its kwargs). ``_touched_variable`` is the
        # authoritative signal because comparing rewritten sub-ASTs back to
        # the originals fails on Fragment ``__eq__`` (see
        # ``_touched_variable_self`` init).
        if not child._touched_variable:
            return None

        # DV activity reached this scope, so this aggregate must be lowered
        # to the solver AST. Unsupported aggregates (avg, top, limit, rank,
        # ...) can't be lowered — reject now that we know the symbolic path
        # is required. A pure-data use of the same aggregate as a constant
        # in a mixed expression would have passed through above.
        #
        # ``rank`` lands here when its ``.where(...)`` clause binds a
        # decision-variable entity; the unsupported-aggregate message is
        # the right diagnosis (rank's first arg is a TupleVariable, not a
        # body expression, so the "non-symbolic body" path below would
        # mis-advise users to "move the variable into the body").
        if op_name not in _HIGHER_ORDER_CODES:
            supported_aggs = list(_HIGHER_ORDER_CODES.keys())
            msg = (
                f"Aggregate '{op_name}' cannot be lowered to the solver engine "
                f"because its body references a decision variable. "
            )
            if op_name in ("avg", "string_join", "limit", "top", "bottom", "rank"):
                msg += (
                    f"'{op_name}' is allowed as a pure-data constant in a mixed "
                    f"expression (e.g. ``x >= {op_name}(C.cost)`` with ``C.cost`` a "
                    f"plain property) — but not over a decision variable. "
                    f"Aggregates solvable over decision variables: "
                    f"{', '.join(sorted(supported_aggs))}."
                )
            else:
                msg += f"Supported aggregates: {', '.join(sorted(supported_aggs))}."
            raise NotImplementedError(msg)

        # DV reached this scope but not the body — it must be in a
        # projection, positional, or where slot the solver can't consume
        # cleanly (e.g. a decision-variable relationship used as an
        # aggregate filter). Fail fast rather than build a malformed AST.
        if not isinstance(rw_sym, SymbolicNode):
            raise NotImplementedError(
                f"Aggregate '{op_name}' has a non-symbolic body but its projection/"
                f"positional/where sub-parts depend on a decision variable. "
                f"Move the decision variable into the aggregate body "
                f"(e.g. `sum(cond_expr * body_expr)`), or express the dependency "
                f"as a separate constraint."
            )

        sym_expr = rw_sym.expr

        # RAI-50087. When the body walks to an inner per-aggregate, the body's
        # wire ``sym_expr`` is the inner per-aggregate's node Hash. Distinct
        # outer iterations that share that inner Hash collide on the solver's
        # ``(node, arg_hash, sym_expr)`` dedup and silently bag-collapse to
        # one. The fix is a per-iteration discriminator folded into the
        # existing ``arg_hash`` material — the ``_unordered_args_hash``
        # schema's ``i:Hash`` slot is designed for exactly this.
        #
        # The discriminator is the set of data-side DSL nodes (Concept/Ref)
        # touched by variable-ref rewriting at THIS scope, as observed via
        # ``_rewrite_variable_ref`` populating ``_data_anchors_self``. That
        # set is the rewriter's own answer to "what data entities does this
        # iteration depend on" — the same answer PyRel uses to fix the
        # iteration cardinality. Order is rewrite-order; we dedup on
        # ``_expr_dict_key`` to keep first-occurrence and avoid emitting
        # duplicate hash material from repeated chain starts.
        #
        # Why the observer beats the previous ``find_keys`` walk:
        #   - ``find_keys`` synthesized ``FieldRef`` for multi-field Chain
        #     bodies; ``child.rewrite(FieldRef)`` raised a misleading error.
        #     The observer never synthesizes — it records what the rewriter
        #     actually traverses.
        #   - ``find_keys`` walked ``_args`` only, not ``_kwargs`` —
        #     asymmetric with the rewrite path. The observer is symmetric
        #     because it hooks the rewrite path itself.
        # The observer hooks ``_rewrite_variable_ref`` directly: every
        # unbound Concept/Ref that flows through proj/args/group/body slots
        # records itself once.
        #
        # DV-bound value Refs (``v`` from ``.where(X.v(v))``) are NOT
        # recorded — the wire's per-cell ``arg_hash`` discriminates by the
        # DV's per-entity ``var_ref`` (one Hash per X), giving bag-over-
        # entities rather than PyRel's set-projection on body values.
        # That residual divergence is independent of capture and is pinned
        # by ``test_e2e_rewriter_dv_bound_value_ref_minizinc``.
        #
        # Threaded only on outer ``sum`` — ``count``/``min``/``max`` over a
        # per-aggregate body have different semantics under a per-cell
        # discriminator (``count`` would change the counted quantity;
        # ``min``/``max`` can change under duplicates with different
        # multipliers). For those, fall back to the unwrapped wire — same
        # as the pre-RAI-50087 baseline; their residual divergence is
        # tracked separately if/when it surfaces.
        cell_keys: list[Any] = []
        if op_name == "sum" and any(c._is_per_aggregate for c in child.children):
            seen: set[int] = set()
            for anchor in child._data_anchors_self:
                key = _expr_dict_key(anchor)
                if key not in seen:
                    seen.add(key)
                    cell_keys.append(anchor)
            # Empty ``cell_keys`` falls through unchanged: the body's own
            # ``sym_expr`` is the only discriminator. That matches the
            # pre-RAI-50087 baseline — correct when distinct outer cells
            # already produce distinct ``sym_expr`` values (the common case
            # for an inner ``.per(...)`` keyed by entity properties),
            # divergent only when per-values collide. The collision-only
            # residual is pinned by
            # ``test_e2e_rewriter_multi_key_per_grouping_minizinc``.

        node = Hash.ref()
        # The child emits ``node = hash(expr_id, *group)`` guarded by its
        # own wheres (identity binding + user filters) and populates
        # ``_grounded(node)`` alongside its operator/args defines — so
        # ``_grounded`` fires exactly for the groupings where this
        # aggregate actually contributes a row.
        #
        # User wheres (``rw_where``) stay in the child and never reach
        # the parent — keeps sibling aggregates in the same arithmetic
        # expression independent (see RAI-49485). Already staged into
        # child.wheres above so nested aggregates inherit them.
        hash_binding = _bind_tuple_hash([expr._id, *rw_group], node)
        child.wheres.append(hash_binding)

        # Binding ``arg_hash`` in wheres (rather than computing it as a
        # scalar in the define tuple) forces every own-define in this
        # compiler to share the ``sym_expr`` grounding dependency. When
        # ``sym_expr`` produces zero rows — e.g. ``sum(union(select(X.v)
        # .where(empty)))`` or ``sum(select(X.v).where(empty))`` — the
        # tuple-hash bind fails and the whole own-rule (operator +
        # grounded + args) drops together. Matches PyRel semantics
        # (empty ``sum`` = empty relation).
        #
        # Roles of ``arg_hash`` by aggregate kind:
        #   non-SOS: BOTH the body-grounding gate AND the
        #            ``_unordered_args_hash`` key (distinct per
        #            ``(*rw_proj, sym_expr)`` tuple).
        #   SOS:     ONLY the body-grounding gate. The
        #            ``_ordered_args_hash`` key is the user-supplied
        #            SOS index (``rw_args[0]``), not ``arg_hash``.
        arg_hash = Hash.ref()
        child.wheres.append(_bind_tuple_hash([*rw_proj, *cell_keys, sym_expr], arg_hash))

        child.defines.append(self.problem._operator(node, _HIGHER_ORDER_CODES[op_name]))
        child.defines.append(self.problem._grounded(node))

        if op_name in ("special_ordered_set_type_1", "special_ordered_set_type_2"):
            if len(rw_proj) != 0 or len(rw_args) != 1:
                label = "SOS1" if op_name == "special_ordered_set_type_1" else "SOS2"
                raise ValueError(f"{label} expects exactly 2 arguments (index, variable).")
            # SOS: ordered args carry the user-supplied index for distinct
            # iteration tuples. SOS2 uses it for adjacency ordering; SOS1's
            # index is a disambiguator (solver reassigns weights on Julia side).
            # ``arg_hash`` stays in wheres for body grounding; the define
            # uses the user-supplied index as the ordered-args key.
            child.defines.append(self.problem._ordered_args_hash(node, rw_args[0], sym_expr))
        else:
            # Non-SOS: ``rw_args`` are auto-generated placeholders, not user
            # inputs — don't hash them. Iteration uniqueness comes from
            # ``rw_group`` folded into ``node``. ``arg_hash`` is now bound
            # in the wheres so the same reference flows into the define.
            child.defines.append(self.problem._unordered_args_hash(node, arg_hash, sym_expr))

        # Parent grounds ``node`` via the identity binding, gated on
        # ``_grounded(node)`` — so the parent (and anything that
        # references it, up to ``Expression.root``) only sees Hash refs
        # the child actually materialised. A child whose own body is
        # non-empty can still emit its own operator/arg rows even when
        # an enclosing expression drops, leaving those rows unreferenced
        # from any ``Expression.root`` — display and the solver service
        # walk from ``Expression.root`` and ignore them.
        self.wheres.append(hash_binding)
        self.wheres.append(self.problem._grounded(node))
        return SymbolicNode(node)

    def _rewrite_fragment(self, expr: b.Fragment) -> Optional[SymbolicNode | Any]:
        """Rewrite inline select/where fragment."""
        if expr._define or expr._require:
            raise ValueError("Fragments with define/require not supported.")
        if len(expr._select) != 1:
            raise ValueError(f"Fragment must have exactly 1 select, got {len(expr._select)}.")

        child = self._create_scope()
        rw_where = child.rewrite_where(*expr._where, role="fragment where clause")
        rw_select = child.rewrite(expr._select[0])
        wheres = self.model.where(*rw_where, *child.wheres)

        if isinstance(rw_select, SymbolicNode):
            return SymbolicNode(wheres.select(rw_select.expr))
        if rw_select is not None:
            return wheres.select(rw_select)
        return None

    # =========================================================================
    # Private Helper Methods
    # =========================================================================

    def _bind_variable_entity(self, expr: b.Expression) -> Any:
        """Bind entity ref to a variable: store ref in bound_variables, return field bindings.

        The caller (``rewrite_where``) already checks ``isinstance(expr._op, b.Relationship)``
        before invoking this method, so we narrow via ``assert`` rather than raise.
        """
        # Pass-1 binding of a decision-variable entity counts as
        # decision-variable activity for the enclosing aggregate's
        # "pass through vs. raise" decision.
        self._touched_variable = True
        relationship = expr._op
        assert isinstance(relationship, b.Relationship), (
            f"_bind_variable_entity expects Relationship op (caller-enforced); got {type(relationship).__name__}"
        )

        params = expr._args
        if len(params) != len(relationship._fields):
            raise ValueError(f"Parameter count {len(params)} != field count {len(relationship._fields)}.")

        # The last parameter is the output variable (the symbolic value).
        last_param = params[-1]
        if isinstance(last_param, b.Alias):
            last_param = last_param._source_item
        if not isinstance(last_param, (b.Concept, b.Ref)):
            raise TypeError(f"Last parameter must be Concept or Ref, got {type(last_param).__name__}.")

        # Build field bindings (grounding conditions).
        # Field names come from relationship (possibly a Reading) — they match
        # the user's argument order regardless of entity-field reordering.
        fields: dict[str, Any] = {}
        for i, param in enumerate(params[:-1]):
            rewritten = self.rewrite(param)
            if isinstance(rewritten, SymbolicNode):
                raise ValueError(f"Variable relationship parameter {i} cannot be symbolic.")
            fields[relationship._fields[i].name] = rewritten if rewritten is not None else param

        lookup_key = self._variable_lookup_key(relationship)
        var_ref = self.problem._variable_relationships[lookup_key].ref()
        self.bound_variables[_expr_dict_key(last_param)] = std.common.cast(Hash, var_ref)

        return self.problem._model.where(*[getattr(var_ref, name) == val for name, val in fields.items()])

    def _passthrough(self, expr: Any, role: str = "this expression slot") -> Any:
        """Rewrite expression, raising if result is unexpectedly symbolic.

        Used for slots that expect data-level values and can't carry decision
        variables: aggregate projection args, positional args, and group keys
        (via direct calls in ``_rewrite_aggregate``) and where-clause atoms
        (via ``rewrite_where``). ``role`` names the specific slot in the
        error message so the user can locate the offending expression.
        """
        result = self.rewrite(expr)
        if isinstance(result, SymbolicNode):
            if "where clause" in role:
                advice = (
                    "Where clauses iterate over data rows and can't reference "
                    "decision variables. Express the dependency as a separate "
                    "constraint (e.g. `p.satisfy(model.require(<dv expression> "
                    "<comparison>))`) rather than filtering inside this slot."
                )
            else:
                advice = (
                    "Move the symbolic expression into an aggregate body — e.g. "
                    "`sum(<dv expression>).where(<data grounding>)` rather than "
                    "`sum(<dv expression>, <data>)`."
                )
            raise ValueError(f"Decision-variable-dependent expression not supported in {role}: {expr!r}. {advice}")
        return result if result is not None else expr

    def _assert_not_variable(self, rel: Any, role: str) -> None:
        """Raise if ``rel`` is registered as a decision variable.

        Used to guard against operator/aggregate relations accidentally being
        registered as variables. Direct lookup avoids the side effects of a
        full ``rewrite()`` on the relation (which could leak a where clause).
        """
        if isinstance(rel, b.Relationship):
            key = self._variable_lookup_key(rel)
            if key in self.problem._variable_relationships or key in self.bound_variables:
                raise ValueError(f"{role} cannot be a decision variable.")

    def _get_variable_ref(
        self, relationship: b.Relationship, parent: b.Concept | b.Ref | b.Chain | None
    ) -> Optional[tuple[int, Any]]:
        """Get (lookup_key, Hash-cast var ref) if relationship is a variable, else None.

        Uses ``_variable_lookup_key`` to resolve Readings to their parent for
        the dict lookup, but ``relationship`` for field names (so entity binding
        matches the user's argument order, even for Readings).
        """
        key = self._variable_lookup_key(relationship)
        VarConcept = self.problem._variable_relationships.get(key)
        if VarConcept is None:
            return None

        var_ref = VarConcept.ref()
        if parent is not None:
            self.wheres.append(getattr(var_ref, relationship._fields[0].name)(parent))
        return (key, std.common.cast(Hash, var_ref))
