"""The RelationalAI Semantics Reasoners.

This package groups higher-level reasoning libraries: `graph` for running
graph algorithms, and `prescriptive` for formulating and solving decision problems.
"""

# Mark this package's docstrings for inclusion
# in automatically generated web documentation,
# by default as early access.

__include_in_docs__ = True
