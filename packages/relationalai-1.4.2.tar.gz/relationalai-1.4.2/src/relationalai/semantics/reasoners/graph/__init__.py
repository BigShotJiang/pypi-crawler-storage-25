"""Graph reasoning: model graphs and run graph algorithms in PyRel.

Provides a declarative Python API for constructing directed or undirected,
weighted or unweighted graphs in a ``Model`` and running algorithms
over them.

This package is intentionally lightweight at the import surface: ``Graph`` is
the main entry point, and algorithm-level details are documented on each
``Graph`` method.

## Quick Start

Build a small directed graph and compute node outdegree.

```python
from relationalai.semantics import Model, Integer
from relationalai.semantics.reasoners.graph import Graph

model = Model("quick_start")
graph = Graph(model, directed=True, weighted=False)
Node, Edge = graph.Node, graph.Edge

n1 = Node.new(id=1)
n2 = Node.new(id=2)
n3 = Node.new(id=3)
n4 = Node.new(id=4)

model.define(n1, n2, n3, n4)

model.define(
    Edge.new(src=n1, dst=n2),
    Edge.new(src=n2, dst=n3),
    Edge.new(src=n3, dst=n1),
    Edge.new(src=n3, dst=n4),
)

outdegree = graph.outdegree()
model.select(Node.id, Integer).where(outdegree(Node, Integer)).inspect()
```
"""

__version__ = "0.1.0"
# Mark this package's docstrings for inclusion
# in automatically generated web documentation.
__include_in_docs__ = True

from .core import Graph


# Finally make this package's core functionality publicly available.
__all__ = [
    "Graph",
]
