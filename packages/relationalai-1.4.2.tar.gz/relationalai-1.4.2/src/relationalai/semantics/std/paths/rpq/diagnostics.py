from typing import NoReturn
from relationalai.util.error import warn, exc

# -----------------------------------------------------------------------------------------
# All User-facing diagnostic messages: Warnings and Errors
# -----------------------------------------------------------------------------------------

def warn_pathfinder_parameter(message: str) -> None:
    warn("PathfinderParameterWarning", message)


def warn_pathfinder_size(pattern, prune_states_only: bool) -> None:
    from .rpq import RPQ
    assert isinstance(pattern, RPQ)

    message = f"WARNING: RPQ pattern is prohibitively large {len(pattern)} >= 50"
    if prune_states_only:
        message += "\nSkipping transitions pruning"
        message += "\nUse 'force_transition_pruning=True' to force transition pruning"
    warn("PathfinderSizeWarning", message)


def warn_pathfinder_non_determinism(pattern, a, prune_states_only: bool) -> None:
    from .rpq import RPQ
    from .automaton import Automaton
    assert isinstance(pattern, RPQ)
    assert isinstance(a, Automaton)

    message = "WARNING: RPQ pattern is non-deterministic\n"
    if prune_states_only:
        message += "Using 'force_transition_pruning=True' may solve this issue\n"
    message += str(pattern)
    message += "\n"
    for reason in a.determinism_report():
        message += " *" + reason + '\n'
    message += "Pathfinder may return duplicate results"
    warn("PathfinderNonDeterminismWarning", message)


def raise_pathfinder_ungrounded_pattern(pattern) -> NoReturn:
    from .rpq import RPQ
    assert isinstance(pattern, RPQ)

    message = "ERROR: Input RPQ pattern is ungrounded\n"
    message += "Pattern potentially admits an infinite number of single-node paths\n"
    message += str(pattern)
    exc("PathfinderUngroundedPatternError", message)


def raise_pathfinder_void_pattern(pattern) -> NoReturn:
    from .rpq import RPQ
    assert isinstance(pattern, RPQ)

    message = "ERROR: Input RPQ pattern is void (admits no paths)\n"
    message += str(pattern)
    exc("PathfinderVoidPatternError", message)
