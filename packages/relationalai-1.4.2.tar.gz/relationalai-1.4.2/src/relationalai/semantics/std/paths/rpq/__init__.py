import typing

from relationalai.semantics import Concept
from relationalai.semantics.std.paths.rpq.rpq import RPQ

__all__ = [
    'node_filter',
    'node',
    'edge',
    'path',
    'optional',
    'plus',
    'star',
    'union',
    'RPQ',
]

#-----------------------------------------------------------------------------
# Parsing RPQ elements specified with strings (node and edge labels).
#-----------------------------------------------------------------------------

Segment = typing.Union[str, Concept, RPQ]

def _process_segment(s: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.filter import NodeLabel, parse_label
    from relationalai.semantics.std.paths.rpq.rpq import Node, Edge

    if isinstance(s, str):
        label = parse_label(s)
        if isinstance(label, NodeLabel):
            return Node(label)
        else:
            return Edge(label)
    elif isinstance(s, Concept):
        return Node(NodeLabel(s._name))
    elif isinstance(s, RPQ):
        return s
    else:
        raise Exception(f"Incorrect type {type(s)} of segment '{s}'")


#-----------------------------------------------------------------------------
# User-facing RPQ constructors
#-----------------------------------------------------------------------------

# (filter)
def node_filter(filter: typing.Callable) -> RPQ:
    from relationalai.semantics.std.paths.rpq.filter import AnonymousNodeFilter
    from relationalai.semantics.std.paths.rpq.rpq import Node

    return Node(label = None, filter = AnonymousNodeFilter(filter))


# (node_lab {∧ filter})
def node(node_lab: typing.Union[str,Concept],
         filter: typing.Optional[typing.Callable] = None) -> RPQ:
    from relationalai.semantics.std.paths.rpq.filter import (
        NodeLabel, AnonymousNodeFilter, parse_label
    )
    from relationalai.semantics.std.paths.rpq.rpq import Node

    filter = AnonymousNodeFilter(filter) if filter is not None else None

    if isinstance(node_lab, Concept):
        label = NodeLabel(node_lab._name)
    else:
        label = parse_label(node_lab)
    assert isinstance(label, NodeLabel), f"Expected a node label, got {label}"

    return Node(label, filter)

# -[edge_lab {∧ filter}]- or <-[edge_lab {∧ filter}]-
def edge(edge_lab:str, filter: typing.Optional[typing.Callable] = None) -> RPQ:
    from relationalai.semantics.std.paths.rpq.filter import (
        EdgeLabel, AnonymousEdgeFilter, parse_label
    )
    from relationalai.semantics.std.paths.rpq.rpq import Edge

    label = parse_label(edge_lab)
    assert isinstance(label, EdgeLabel), f"Expected an edge label, either `-[...]->` or `<-[...]-`, got {label}"
    filter = AnonymousEdgeFilter(filter) if filter is not None else None
    return Edge(label, filter)


# (expr₁ ⋅ ... ⋅ exprₙ)
def path(segment: Segment, *segments: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.rpq import Concat

    pattern = _process_segment(segment)
    for seg in segments:
        pattern = Concat(pattern, _process_segment(seg))

    return pattern

# (expr₁ ⋅ ... ⋅ exprₙ)?
def optional(*segments: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.rpq import Optional

    return Optional(path(*segments))

# (expr₁ ⋅ ... ⋅ exprₙ)+
def plus(segment: Segment, *segments: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.rpq import Plus

    return Plus(path(segment, *segments))

# (expr₁ ⋅ ... ⋅ exprₙ)*
def star(segment: Segment, *segments: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.rpq import Star

    return Star(path(segment, *segments))

# (expr₁ | ... | exprₙ)
def union(segment: Segment, *segments: Segment) -> RPQ:
    from relationalai.semantics.std.paths.rpq.rpq import Union

    pattern = _process_segment(segment)
    for seg in segments:
        pattern = Union(pattern, _process_segment(seg))

    return pattern
