"""
Core functionality for the paths library.
"""

from __future__ import annotations

from relationalai.semantics.backends.legacy_lqp.annotations import track as track_annotation
from relationalai.semantics.frontend.base import Expression, Chain, DerivedColumn, Relationship, Library, Concept, Ref
from relationalai.semantics.frontend.core import Integer, String, AnyEntity, Hash

ALLOW_UNIMPLEMENTED = False

def throw_if_not_implemented(msg):
    if not ALLOW_UNIMPLEMENTED:
        raise NotImplementedError(msg)

def _is_node(arg) -> bool:
    """True if the argument is a node — i.e., a ``Concept`` or a ``Ref``.
    """
    # NOTE: This will become more permissive over time, as we implement
    # more and more of the paths syntax design.
    return isinstance(arg, (Concept, Ref))

def _is_not_node(arg) -> bool:
    """True if the argument is not a node — i.e., a ``Chain`` (single-edge
    traversal) or a nested ``PathPattern`` (sub-path), as opposed to an
    endpoint like a ``Ref`` or ``Concept``.
    """
    # NOTE: This will become more permissive over time, as we implement
    # more and more of the paths syntax design.
    return isinstance(arg, (Chain, PathPattern))

def _normalize_repeat_args(
    min_or_exact: int | None,
    max: int | None,
    min: int | None,
) -> tuple[int, int]:
    """Validate and normalize ``repeat(...)``-style args into ``(min, max)``.

    Calling conventions (shared by ``PathPattern.repeat`` and ``Chain.repeat``):
        (3,)                  → (3, 3)
        (1, 20)               → (1, 20)
        (min=1, max=20)       → (1, 20)
        (max=20)              → (1, 20)   # min defaults to 1
        (min=1)               → ValueError
    """
    if max is None and min is None:
        if min_or_exact is None:
            raise ValueError("repeat() requires at least one argument")
        if min_or_exact < 0:
            raise ValueError(f"repeat() count must be non-negative; got {min_or_exact}")
        return (min_or_exact, min_or_exact)

    if min is not None and min_or_exact is not None:
        raise ValueError(
            "repeat() cannot accept both a positional min and the min= kwarg"
        )
    min_val = min if min is not None else min_or_exact

    if max is None:
        raise ValueError("repeat(min=...) requires an explicit max")
    if min_val is None:
        min_val = 1
    if min_val < 0 or max < 0:
        raise ValueError(
            f"repeat() bounds must be non-negative; got min={min_val}, max={max}"
        )
    if min_val > max:
        raise ValueError(
            f"repeat() requires min <= max; got min={min_val}, max={max}"
        )
    return (min_val, max)

def path(*args):
    from relationalai.semantics import _check_model
    model = _check_model()
    return PathPattern(*args, model=model)

class PathPattern:
    """A path pattern describing an alternating sequence of nodes and edges.

    Positional arguments are classified as:
    - Edges: ``Chain`` or nested ``PathPattern`` (relationship traversals)
    - Nodes: anything else (``Ref``, ``Concept``, ``Fragment``, etc.)

    The first and last positional args — if not edges — act as the explicit
    ``src`` and ``dst`` endpoints of the path. At least one edge is required;
    edgeless and empty patterns are rejected at construction.

    Optional arguments:
    - ``model``: pins the pattern to a specific ``Model``. When omitted, the
      active model is resolved via ``_check_model()``, which errors when
      multiple Models exist globally.

    Examples
    --------
        path(Concept.relationship)
        path(source.relationship)
        path(source.relationship, destination)
        path(source.relationship.repeat(1, 10))
        path(source.relationship.repeat(1, 10), destination)
        path(Concept.relationship).repeat(max=3)
        path(Concept.relationship).repeat(min=3, max=5)

    The two repeat forms have different semantics:
    - ``path(C.r.repeat(N))``  — only the source must be of type ``C``.
    - ``path(C.r).repeat(N)``   — every intermediate node must be of type ``C``.
    """

    def __init__(self, *args, model=None):
        from relationalai.semantics import _check_model

        if len(args) == 0:
            raise ValueError("path(...) must have at least one argument.")
        if not any(_is_not_node(a) for a in args):
            raise ValueError(
                "path(...) must contain at least one edge (Chain or nested PathPattern)."
            )
        # Reject two adjacent node args at either endpoint — implicit
        # unification between adjacent nodes is not supported.
        if len(args) >= 2 and _is_node(args[0]) and _is_node(args[1]):
            raise NotImplementedError(
                "path() received two adjacent node arguments at the start; "
                "implicit unification between adjacent nodes is not yet supported."
            )
        if len(args) >= 2 and _is_node(args[-2]) and _is_node(args[-1]):
            raise NotImplementedError(
                "path() received two adjacent node arguments at the end; "
                "implicit unification between adjacent nodes is not yet supported."
            )

        self._model = _check_model() if model is None else model

        self.pattern_exprs = args
        self.filters = []
        self.repeat_count = None

    def where(self, *args) -> PathPattern:
        self.filters.extend(args)
        return self

    def repeat(
        self,
        min_or_exact: int | None = None,
        max: int | None = None,
        *,
        min: int | None = None
    ) -> PathPattern:
        """Set the repeat count for this path pattern.

        Calling conventions:
            repeat(3)              → exactly 3 times: (3, 3)
            repeat(1, 20)          → between 1 and 20: (1, 20)
            repeat(min=1, max=20)  → between 1 and 20: (1, 20)
            repeat(max=20)         → between 1 and 20: (1, 20); min defaults to 1
            repeat(min=1)          → ValueError; an explicit max is required
        """
        # `path(x, edge, y).repeat(...)` conflates two intended semantics —
        # "every hop is a y" vs. "only the final hop is a y" — and the current
        # implementation can't disambiguate. Reject it until the distinction
        # is designed (RAI-49957); callers should move `.repeat()` onto the
        # inner chain (`path(x, edge.repeat(...), y)`) for now.
        if self._is_dst_explicit():
            raise NotImplementedError(
                "Applying .repeat() to a path pattern with an explicit dst "
                "node is not supported."
            )

        self.repeat_count = _normalize_repeat_args(min_or_exact, max, min)
        return self

    def _find_edge_chain(self) -> Chain:
        """Find the single Chain edge among pattern_exprs.

        For the current scope (single-edge patterns), expects exactly one
        Chain either directly in pattern_exprs or inside a nested PathPattern.
        """
        chains = []
        for arg in self.pattern_exprs:
            if isinstance(arg, Chain):
                if isinstance(arg._start, Chain):
                    raise ValueError(
                        "path() received a multi-step chain (e.g., A.b.c). "
                        "Only single-step chains (e.g., A.b) are supported. "
                        "To repeat a single edge, use `.repeat(...)`."
                    )
                chains.append(arg)
            elif isinstance(arg, PathPattern):
                chains.append(arg._find_edge_chain())
        if len(chains) == 0:
            raise ValueError("path() must contain at least one edge (Chain).")
        if len(chains) > 1:
            raise NotImplementedError(
                "Composite edges (multiple Chains in a single path) are not yet supported. "
                "Use a single N-arity relationship instead."
            )
        return chains[0]

    def _compile_edge(self) -> tuple[Chain | Relationship, tuple[int, int]]:
        """Compile the edge into ``(per_hop_edge, src_dst_fields)``.

        The per-hop edge encodes the intermediate-node semantics of the path:

        - ``Chain.repeat`` (``Concept.relationship.repeat(N)``):
          return the bare underlying ``Relationship`` so per-hop indexing
          does not re-apply the chain's start filter to intermediate nodes.
        - ``PathPattern.repeat`` (``path(Concept.r).repeat(N)``) or
          no repeat: return the typed ``Chain``. ``Chain[src_field]``
          re-applies its start filter at each hop's source — i.e., every
          intermediate node is constrained to match.

        Computes src/dst field indices as the first and last fields of the
        underlying Relationship.
        """
        chain = self._find_edge_chain()
        num_fields = len(chain._next._fields)
        src_dst_fields = (0, num_fields - 1)

        if chain._repeat_bounds is not None:
            edge = chain._next
        else:
            edge = chain

        return edge, src_dst_fields

    def _is_src_explicit(self) -> bool:
        """True iff the caller supplied an explicit src node as the first arg.

        Assumes the pattern has at least one edge, which ``__init__`` enforces.
        """
        return _is_node(self.pattern_exprs[0])

    def _is_dst_explicit(self) -> bool:
        """True iff the caller supplied an explicit dst node as the last arg.

        Assumes the pattern has at least one edge, which ``__init__`` enforces.
        """
        return _is_node(self.pattern_exprs[-1])

    def _extract_src(self):
        """Return the src ref to unify with the path's start node.

        Always present in a valid pattern: either the explicit first-arg
        node, the chain's ``_start`` if the first arg is a ``Chain``, or
        recursed from a leading nested ``PathPattern``.
        """
        first = self.pattern_exprs[0]
        if _is_node(first):
            return first
        if isinstance(first, PathPattern):
            return first._extract_src()
        return self._find_edge_chain()._start

    def _collect_repeats(self) -> tuple[int, int] | None:
        """Walk the pattern tree and return its single effective repeat.

        Returns the unique ``(min, max)`` tuple set anywhere in the tree —
        on this pattern's ``repeat_count``, on a ``Chain`` argument's
        ``_repeat_bounds``, or on a nested ``PathPattern`` (recursively).
        Returns ``None`` if no repeat is set at any depth.

        Raises ``ValueError`` if more than one repeat is set anywhere — the
        design forbids nested repeats.
        """
        conflict_msg = (
            "Multiple repeat counts specified in a single path pattern. "
            "Nested repeat counts are not supported."
        )
        found = self.repeat_count
        for arg in self.pattern_exprs:
            if isinstance(arg, PathPattern):
                inner = arg._collect_repeats()
            elif isinstance(arg, Chain) and arg._repeat_bounds is not None:
                inner = arg._repeat_bounds
            else:
                inner = None
            if inner is None:
                continue
            if found is not None:
                raise ValueError(conflict_msg)
            found = inner
        return found

    def _parse_path(self) -> tuple:
        """Parse the alternating node/edge sequence.

        Returns ``(src, dst, repeats)``. src/dst are the Variables passed to
        the BFS; callers that need to know whether each endpoint was explicit
        should consult ``_is_src_explicit`` / ``_is_dst_explicit`` directly.
        """
        repeats = self._collect_repeats() or (1, 1)
        src = self.pattern_exprs[0] if self._is_src_explicit() else self._find_edge_chain()._start
        dst = self.pattern_exprs[-1] if self._is_dst_explicit() else None
        return src, dst, repeats

    def all_paths(self) -> DerivedColumn | Relationship:
        """Compile the path pattern and enumerate all matching paths via BFS.

        Returns a unary ``DerivedColumn`` or ``Relationship`` of ``PathTraversal`` values.
        The BFS result is wrapped in a post-filter Fragment that unifies the
        path's start node with the pattern's src ref (always present —
        either the explicit first-arg node, or the leading Chain's start
        Concept), unifies the end node with any explicit dst, and applies
        any ``.where()`` filters. This wrapping lets endpoint Refs and user
        filters unify with outer uses at the caller's scope, applying constraints.
        """
        from relationalai.semantics.std.paths.algorithms.linked_list_bfs import (
            enumerate_all_paths_via_filtered_bfs,
        )

        src, dst, repeats = self._parse_path()
        edge, src_dst_fields = self._compile_edge()

        if src is None:
            raise ValueError(
                "Could not determine a source for the path. "
                "Provide an explicit start node or use a Chain with a known start Concept."
            )

        bfs_paths = enumerate_all_paths_via_filtered_bfs(
            self._model, edge, src_dst_fields, src, dst, repeats,
        )
        # Track annotation to enable logging
        bfs_paths.annotate(track_annotation("paths", "enumerate_all_paths_via_filtered_bfs"))

        # Currently, a post-filter is necessary to unify the BFS results
        # and any filter passed in through .where.
        # This can cause performance issues if the graph is highly connected
        # and the filter heavily restricts paths.
        # Tracked in RAI-49932.
        p = PathTraversal.ref()
        post_filters = [bfs_paths(p)]
        # Currently supported path patterns always have a src variable to
        # unify via post-filters; make more fine grained once we
        # admit patterns with no src ref. Tracked in RAI-50307
        src_needs_unification = True
        if src_needs_unification:
            post_filters.append(p.nodes(0) == self._extract_src())
        if self._is_dst_explicit():
            post_filters.append(p.nodes(p.length) == dst)
        post_filters.extend(self.filters)
        return self._model.where(*post_filters).select(p)[0]

    def shortest_paths(self):
        return ShortestPathsTraversalExpr(self)

class AbstractPathTraversalExpr(Expression):
    def __init__(self, pattern, semantics):
        self.path_pattern = pattern
        self.semantics = semantics
        throw_if_not_implemented(f"{semantics}_paths() is not implemented yet.")
        # super().__init__(...)

# Not hooked up to PathPattern.all_paths() yet as we don't support methods on top of it.
# Tracked in RAI-49958.
class AllPathsTraversalExpr(AbstractPathTraversalExpr):
    def __init__(self, pattern):
        super().__init__(pattern, "all")

class ShortestPathsTraversalExpr(AbstractPathTraversalExpr):
    def __init__(self, pattern):
        super().__init__(pattern, "shortest")

    def per(self, *args):
        throw_if_not_implemented("shortest_paths().per() is not implemented yet.")
        self.group_by_args = args
        return self

def undirected(expr):
    throw_if_not_implemented("undirected(Concept.relationship) is not implemented yet.")
    return expr

def reverse(expr):
    throw_if_not_implemented("reverse(Concept.relationship) is not implemented yet.")
    return expr

PathsLibrary = Library("paths")
PathTraversal = PathsLibrary.Type("PathTraversal", super_types=[Hash])
PathTraversal.length = PathsLibrary.Property(f"{PathTraversal} is {Integer:length} hops long")
PathTraversal.nodes = PathsLibrary.Relationship(f"{PathTraversal} at {Integer:index} has {AnyEntity:concept}")
PathTraversal.relationships = PathsLibrary.Relationship(f"{PathTraversal} at {Integer:index} has {String:relationship}")
# We constrain all Edge labels to be an entity, as this unifies the types to be a Hash in the backend.
# This is to circumvent the lack of support for Any that resolves to a union of multiple types;
# see Slack discussion: https://relationalai.slack.com/archives/C09UD406MH7/p1776524916638569
PathTraversal.relationship_fields = \
    PathsLibrary.Relationship(f"{PathTraversal} has edge number {Integer:index} with field number {Integer:field_index} and value {AnyEntity:field}")

# Track annotations to enable logging
PathTraversal.length.annotate(track_annotation("paths", "PathTraversal.length"))
PathTraversal.nodes.annotate(track_annotation("paths", "PathTraversal.nodes"))
PathTraversal.relationships.annotate(track_annotation("paths", "PathTraversal.relationships"))
PathTraversal.relationship_fields.annotate(track_annotation("paths", "PathTraversal.relationship_fields"))
