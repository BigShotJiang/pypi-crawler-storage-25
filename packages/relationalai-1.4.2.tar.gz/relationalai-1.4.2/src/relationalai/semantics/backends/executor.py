"""Base Executor class for all PyRel backends."""

from __future__ import annotations

import json

from typing import Iterable, TypeVar, Callable
from pandas import DataFrame

from ...config.config import Config
from ...util.error import Part, exc, source, warn

from .install_readiness import InstallReadinessResult, InstallReadinessStatus

from ..metamodel import metamodel as mm
from ..metamodel.metamodel_analyzer import normalize, Lowering, Groundness
from ..metamodel.typer import Typer
from ..frontend import base as dsl

from ...observability import tracing

#------------------------------------------------------
# Executor and MetamodelExecutor (base)
#------------------------------------------------------

class Executor:
    """Backend-agnostic executor."""

    def execute_query(self, model: "dsl.Model", fragment: "dsl.Fragment", **kwargs) -> DataFrame:
        """ Execute a query fragment against the model, returning a DataFrame.

        Executors may keep track of whether the model is already installed, and install it
        if necessary. """
        raise NotImplementedError(f"execute_query: {self}")

    def install(self, model: "dsl.Model", **kwargs) -> InstallReadinessResult:
        """ Install the model. """
        raise NotImplementedError(f"install: {self}")

class MetamodelExecutor:
    """Executor that operates directly on the metamodel. This is the interface that all
    executors must implement, and it is used by the ModelManagerExecutor to execute
    queries against the installed model.
    """

    def execute_query(self, model: mm.Model, query: mm.Task, **kwargs) -> DataFrame:
        raise NotImplementedError(f"execute_query: {self}")

    def install(self, model: mm.Model, **kwargs) -> InstallReadinessResult:
        raise NotImplementedError(f"install: {self}")

    def wait_for_initial_refresh(self) -> None:
        """Block until the most recent install has completed populating data."""
        raise NotImplementedError(f"wait_for_initial_refresh: {self}")


#------------------------------------------------------
# Model Manager Executor
#------------------------------------------------------

class ModelManagerExecutor(Executor):
    """Executor that manages the state of the installed model.

    This class wraps a MetamodelExecutor to actually perform installation and query
    execution. The current implementation keeps track of the model in memory, but in the
    future it may use persistence.

    Handles DSL -> metamodel translation with caching: the model is only retranslated
    (and reinstalled) when its version token changes. The fragment is always retranslated.

    Also handles the common metamodel passes that need to be executed prior to installation
    and query execution.
    """

    def __init__(self, executor: MetamodelExecutor, config: Config):
        # wrapped executor and config
        self._executor = executor
        self._config = config
        # cache of model state
        self._installed_model_token: tuple[int, int] | None = None
        self._cached_mm_model: mm.Model | None = None
        # stateful typer is created when a model is installed, and reused for queries
        self._typer: Typer | None = None
        # common passes
        self._lowering = Lowering()
        self._groundness = Groundness()

    @property
    def inner_executor(self) -> MetamodelExecutor:
        return self._executor

    def _add_to_span(self, span, item, key: str = "metamodel", transform: Callable = str) -> None:
        """Attach ``item`` (transformed to a string) to ``span[key]``, gated on ``debug.enabled``.

        Skips both the transformation and the span write when debug is off — so the
        ``str()`` cost of large metamodel nodes is paid only when the user asked for it.
        """
        if not self._config.debug.enabled or not item:
            return
        if isinstance(item, Iterable) and not isinstance(item, (str, bytes)):
            span[key] = "[\n" + "\n".join(transform(i) for i in item) + "\n]"
        else:
            span[key] = transform(item)

    def _with_source(self, item: mm.Node) -> dict:
        """Extract source location info for ``item``, gated on ``debug.enabled``.

        With debug on, returns ``file``/``line``/``source`` (full source text). With
        debug off, returns just ``file``/``line`` to skip the cost of reading source.
        Empty dict when the item has no source set.
        """
        if not hasattr(item, "source"):
            raise ValueError(f"Item {item} has no source")
        if item.source is None:
            return {}
        if self._config.debug.enabled:
            source = item.source.block
            if source:
                return {"file": source.file, "line": source.line, "source": source.source}
        return {"file": item.source.file, "line": item.source.line}

    def execute_query(self, model: "dsl.Model", fragment: "dsl.Fragment", **kwargs) -> DataFrame:
        token = self._model_token(model)
        if self._cached_mm_model is None or self._installed_model_token != token:
            # we force dry run if we are in install model and auto_install is false
            dry_run = self._config.install_mode and not self._config.model.auto_install
            readiness = self.install(model, force_dry_run=dry_run, **kwargs)
            self._wait_until_queryable(readiness)
        assert self._cached_mm_model is not None

        # translate dsl to metamodel
        mm_query = fragment.to_metamodel()
        assert isinstance(mm_query, mm.Task) # TODO: raise if false?

        # unpack kwargs for debugging span
        meta=kwargs.get("meta")
        dsl_query_string = format(fragment)

        source_attrs = self._with_source(mm_query)
        # If there's no source file, use the query_string as the source so it shows up in the debugger
        if not source_attrs.get("source"):
            source_attrs["source"] = dsl_query_string

        with tracing.span("query", tag=None, dsl=dsl_query_string, meta=meta, **source_attrs) as query_span:
            with tracing.span("compile", metamodel=mm_query) as compile_span:
                compile_span["compile_type"] = "query"
                with tracing.span("v1") as span:
                    with tracing.span("Original") as span:
                        self._add_to_span(span, mm_query)

                    # execute the common passes
                    mm_query = self._common_metamodel_passes(mm_query)
                    self._add_to_span(compile_span, mm_query, key="metamodel_grounded")

                    # finally execute the query and add the results to the original query span
                    try:
                        results = self._executor.execute_query(self._cached_mm_model, mm_query, **kwargs)
                        query_span["results"] = results
                        return results
                    except Exception as e:
                        query_span["results"] = str(e)
                        exc("Query execution failed", "Internal error executing query", [str(e), source(fragment)])


    def install(self, model: "dsl.Model", force_dry_run: bool = False, **kwargs) -> InstallReadinessResult:
        """ Install the model if it is not already installed, or if the version token has changed.

        The force_dry_run flag is used to force dry run mode, in which case the model will
        be compiled but will not be actually installed. This is used for queries in install
        mode, where the model should be pre-installed but executing the query requires
        model compilation.
        """
        # Establish the run before any spans are emitted: creates / adopts
        # build/runs/<id>/, redirects the tracer, attaches the v0 bridge.
        # A real install (force_dry_run=False) always starts a fresh
        # install run. A dry-run install — compile-only prep before a
        # query when auto_install is off — adopts the latest install dir
        # on disk so the query session writes into the install it's
        # targeting.
        from relationalai.observability import start_run
        start_run("query" if force_dry_run else "install")

        # always reset the typer when installing a model
        self._typer = Typer(enforce=not self._config.compiler.soft_type_errors)
        # Dry-run installs are compile-only prep for queries (no DB writes).
        # Keep the outer span name aligned with the run/debugger categories
        # ("install" / "query" / "model") so dry-run-only traces still show
        # up in the sidebar and downstream consumers that key off the top-level
        # span name continue to see the work. Record the "prepare" distinction
        # as metadata instead of changing the root span name.
        outer_span_name = "query" if force_dry_run else "install"
        with tracing.span(
            outer_span_name,
            dry_run=force_dry_run,
            operation="prepare" if force_dry_run else "install",
        ) as span:
            # translate dsl to metamodel
            mm_model = model.to_metamodel()
            with tracing.span("compile", metamodel=mm_model) as compile_span:
                compile_span["compile_type"] = "model"
                with tracing.span("v1") as span:
                    with tracing.span("Original") as span:
                        self._add_to_span(span, mm_model.root)
                    # execute the common passes
                    mm_model = self._common_metamodel_passes(mm_model)
                    self._add_to_span(compile_span, mm_model.root, key="metamodel_grounded")

                    # finally install the model and cache the result if successful
                    result = self._executor.install(mm_model, force_dry_run=force_dry_run, **kwargs)
                    self._cached_mm_model = mm_model
                    self._installed_model_token = self._model_token(model)
                    return result

    def _wait_until_queryable(self, readiness: InstallReadinessResult) -> None:
        """Block until the installed model is ready to serve queries, or raise/warn based on
        install state.
        """
        detail: list[Part] = [readiness.detail] if readiness.detail else []

        if readiness.status == InstallReadinessStatus.READY:
            return
        elif readiness.status == InstallReadinessStatus.MATCHING_INSTALL_IN_PROGRESS:
            try:
                from ...tools.cli.components.wait_spinner import WaitSpinner
                with WaitSpinner("Waiting for initial model refresh..."):
                    self._executor.wait_for_initial_refresh()
            except TimeoutError as e:
                exc(
                    "Installed model not ready",
                    "Timed out waiting for the installed model to become ready.",
                    [str(e)],
                )
            return
        elif readiness.status == InstallReadinessStatus.FINGERPRINT_MISMATCH:
            warn(
                "Installed model mismatch",
                "The installed model does not match the current model configuration or PyRel version. Continuing query execution against the currently installed schema; the query may fail or return stale results.",
                detail,
            )
            return
        elif readiness.status == InstallReadinessStatus.INSTALL_PREPARED:
            exc(
                "Incomplete model installation",
                "The model installation has been prepared but did never run. Run 'rai models install' to retry the installation.",
            )
        elif readiness.status == InstallReadinessStatus.NO_INSTALL_STATE:
            exc(
                "No install state",
                "Could not verify installed model readiness because no install state was found for this schema. Run 'rai models install' or enable auto_install.",
                detail,
            )
        elif readiness.status == InstallReadinessStatus.MATCHING_INSTALL_FAILED:
            exc(
                "Model installation failed",
                "The installed model matching the current configuration failed during initial refresh.",
                detail,
            )
        else:
            raise RuntimeError(f"Unexpected install readiness status: {readiness.status}")


    #------------------------------------------------------
    # Common metamodel passes and helpers
    #------------------------------------------------------

    T = TypeVar("T", bound=mm.Model | mm.Task)
    def _common_metamodel_passes(self, node: T) -> T:
        assert(self._typer is not None)

        with tracing.span("Typer") as span:
            # execute the appropriate typer method and capture which node to process in the
            # other passes (either the node itself for a query, or the root for a model)
            if isinstance(node, mm.Model):
                typed_model = self._typer.infer_model(node)
                task = typed_model.root
            else:
                typed_model = None # to appease the type checker
                task = self._typer.infer_query(node)
            self._add_to_span(span, task)
            if self._config.debug.enabled:
                assert self._typer.model_net is not None
                self._add_to_span(span, json.dumps(
                    {
                        "id": "model_net",
                        "content": str(self._typer.model_net.to_mermaid()),
                    }
                ), "typer_network")

        with tracing.span("Normalizer") as span:
            task = normalize(task)
            self._add_to_span(span, task)

        with tracing.span("Lowering") as span:
            task = Lowering().normalize(task)
            self._add_to_span(span, task)

        with tracing.span("Groundness") as span:
            self._groundness.enforce(task)

        if isinstance(node, mm.Model):
            # mutate the typed model with the new root
            assert typed_model is not None
            return typed_model.mut(root=task)
        else:
            # just return the lowered task
            return task # type: ignore


    def _model_token(self, model: "dsl.Model") -> tuple[int, int]:
        """ Generate a token for the model based on its identity and version. """
        return (id(model), model._version)


#------------------------------------------------------
# Factory
#------------------------------------------------------

def create_executor(config: Config, model: "dsl.Model") -> Executor:
    # TODO: model should not be a parameter here, but older executors still require it
    if config.install_mode:
        from relationalai.semantics.backends.multi_reasoner_executor import MultiReasonerExecutor
        return ModelManagerExecutor(MultiReasonerExecutor(config), config)
    elif config.reasoners.logic.use_lqp:
        from relationalai.semantics.backends.legacy_lqp.legacy_executor import LegacyLQPExecutor
        return LegacyLQPExecutor(model)
    else:
        from relationalai.semantics.backends.legacy_executor import LegacyExecutor
        return LegacyExecutor(model)

