CREATE OR REPLACE TASK {task_name}
  {warehouse_clause}
  {schedule_clause}
  USER_TASK_TIMEOUT_MS = 0
AS CALL {proc_name}({call_arg})
