"""Catalog pass for the isolated sql9 backend."""
from __future__ import annotations

from collections.abc import Iterable
import re

from relationalai.semantics.metamodel.metamodel_analyzer import RelationAnalysis
from relationalai.util.naming import Namer

from ....config.config_fields import RefreshTaskConfig
from ...metamodel.builtins import builtins as builtin_registry, is_entity_type, is_primitive, is_table_type
from ...metamodel import metamodel as mm

from .artifacts import Catalog, DataStore, EntityStore, RelationStore, StoreColumn, create_catalog
from ._utils import resolve_by_table_name


#------------------------------------------------------
# Catalog builder
#------------------------------------------------------

class CatalogBuilder:
    def __init__(self) -> None:
        self._builtin_relation_names = {
            relation.name
            for library in builtin_registry._libraries.values()
            for relation in library.data.values()
        }

    def build(self, model: mm.Model, relation_analysis: RelationAnalysis, schema_name: str, schedule_cfg: RefreshTaskConfig | None = None) -> Catalog:
        store_namer = Namer()
        folded_property_relation_to_owner_entity_type: dict[int, int] = {}
        data_column_relation_to_store_type_id: dict[int, int] = {}
        target_refresh_intervals: dict[str, int] = {
            k.lower(): v
            for k, v in (schedule_cfg.table_intervals if schedule_cfg else {}).items()
        }
        default_refresh_interval: int = (schedule_cfg.interval_s if schedule_cfg else None) or 0

        entity_stores: list[EntityStore] = []
        for entity_type in self._user_entity_types(model):
            property_relations = tuple(
                relation
                for relation in model.relations
                if self._should_fold_property_relation(relation_analysis, relation, entity_type)
            )
            for relation in property_relations:
                folded_property_relation_to_owner_entity_type[relation.id] = entity_type.id
            columns = [
                StoreColumn(name="_id", sql_type="VARCHAR", semantic_name=entity_type.name),
                *(
                    StoreColumn(
                        name=relation.name,
                        sql_type=self._sql_type_name(relation.fields[1].type),
                        semantic_name=relation.fields[1].type.name,
                    )
                    for relation in property_relations
                ),
            ]
            entity_object_name = self._qualified_name(schema_name, store_namer.get_name(entity_type.name))
            entity_stores.append(
                EntityStore(
                    type_id=entity_type.id,
                    type_name=entity_type.name,
                    object_name=entity_object_name,
                    columns=tuple(columns),
                    interval_s=resolve_by_table_name(entity_object_name, target_refresh_intervals, default_refresh_interval),
                )
            )

        data_stores: list[DataStore] = []
        for table_type in (type_ for type_ in model.types if is_table_type(type_)):
            assert(isinstance(table_type, mm.Table))
            columns = [StoreColumn(name="__rowid", sql_type="BIGINT")]
            for column_relation in table_type.columns:
                data_column_relation_to_store_type_id[column_relation.id] = table_type.id
                columns.append(
                    StoreColumn(
                        name=column_relation.name,
                        sql_type=self._sql_type_name(column_relation.fields[1].type),
                        semantic_name=column_relation.fields[1].type.name,
                    )
                )
            rows = []
            source_name: str | None = None
            if isinstance(table_type, mm.Data):
                frame = table_type.data
                # itertuples preserves per-column dtypes; iterrows collapses a
                # row into a single-dtype Series, silently promoting ints to
                # floats whenever any column in the row is a float.
                for index, row in enumerate(frame.reset_index(drop=True).itertuples(index=False, name=None)):
                    rows.append((index, *row))
            else:
                uri = getattr(table_type, "uri", "")
                source_name = uri[len("table://"):] if uri.startswith("table://") else table_type.name
            data_stores.append(
                DataStore(
                    type_id=table_type.id,
                    type_name=table_type.name,
                    object_name=self._qualified_name(
                        schema_name,
                        f"{self._safe_identifier(table_type.name)}__source__t{table_type.id}",
                    ),
                    columns=tuple(columns),
                    source_name=source_name,
                    rows=tuple(rows),
                )
            )

        relation_stores: list[RelationStore] = []
        for relation in model.relations:
            if relation.id in folded_property_relation_to_owner_entity_type or relation.name in self._builtin_relation_names:
                continue
            if isinstance(relation, (mm.Table, mm.Data)):
                continue
            if relation.id in data_column_relation_to_store_type_id:
                continue
            columns = tuple(
                StoreColumn(
                    name=field.name,
                    sql_type=self._sql_type_name(field.type),
                    semantic_name=getattr(field.type, "name", None),
                )
                for field in relation.fields
            )
            object_name = self._qualified_name(schema_name, store_namer.get_name(self._relation_table_name(relation)))
            relation_stores.append(
                RelationStore(
                    relation_id=relation.id,
                    relation_name=relation.name,
                    object_name=object_name,
                    columns=columns,
                    key_columns=(),
                    interval_s=resolve_by_table_name(object_name, target_refresh_intervals, default_refresh_interval),
                )
            )

        return create_catalog(
            entity_stores=entity_stores,
            relation_stores=relation_stores,
            data_stores=data_stores,
            folded_property_relation_to_owner_entity_type=folded_property_relation_to_owner_entity_type,
            data_column_relation_to_store_type_id=data_column_relation_to_store_type_id,
        )

    def _user_entity_types(self, model: mm.Model) -> tuple[mm.ScalarType, ...]:
        return tuple(
            type_
            for type_ in model.types
            if isinstance(type_, mm.ScalarType)
            and is_entity_type(type_)
            and not isinstance(type_, mm.Table)
        )

    def _should_fold_property_relation(self, relation_analysis: RelationAnalysis, relation: mm.Relation, owner_type: mm.ScalarType) -> bool:
        if not is_entity_type(owner_type):
            return False
        # properties are binary
        if len(relation.fields) != 2:
            return False
        # there is a functional dependency from the entity to the value
        if relation_analysis is None or not relation_analysis.is_property(relation):
            return False
        # the first field must be the owner entity
        if relation.fields[0].type is not owner_type:
            return False
        # the type of the value is not another entity nor a union
        value_type = relation.fields[1].type
        if is_entity_type(value_type) or isinstance(value_type, mm.UnionType):
            return False
        return True

    def _relation_table_name(self, relation: mm.Relation) -> str:
        # Get the name of the table to use for this relation. Note that the actual name used
        # will go through a Namer to avoid collisions, so this is just a hint for the base
        # name to use.

        # currently just use the type of the first field + the relation name, which follows
        # the common case in PyRel where we attach the relation to a concept.
        return self._safe_identifier(f"{relation.fields[0].type.name}_{relation.name}")

    def _qualified_name(self, schema_name: str | None, base_name: str) -> str:
        safe_base_name = self._safe_identifier(base_name)
        if schema_name:
            return f"{schema_name}.{safe_base_name}"
        return f"SANDBOX_MODEL.{safe_base_name}"

    def _sql_type_name(self, type_ref) -> str | None:
        if isinstance(type_ref, mm.NumberType):
            return f"DECIMAL({type_ref.precision},{type_ref.scale})"
        numeric_sql_type = self._numeric_sql_type(type_ref)
        if numeric_sql_type is not None:
            return numeric_sql_type
        if isinstance(type_ref, mm.ScalarType):
            if (is_entity_type(type_ref) or type_ref in (builtin_registry.core.Any, builtin_registry.core.AnyEntity)) and not is_primitive(type_ref):
                return "VARCHAR"
            for candidate in self._type_lineage(type_ref):
                name = candidate.name.lower()
                if name in {"string", "symbol", "uuid", "hash"}:
                    return "VARCHAR"
                if name in {"bool", "boolean"}:
                    return "BOOLEAN"
                if name in {"float", "double"}:
                    return "DOUBLE"
                if name == "date":
                    return "DATE"
                if name in {"datetime", "timestamp"}:
                    return "TIMESTAMP"
        elif isinstance(type_ref, mm.UnionType):
            child_types = [self._sql_type_name(t) for t in type_ref.types]
            if child_types and all(t == "VARCHAR" for t in child_types):
                return "VARCHAR"
        return None

    def _numeric_sql_type(self, type_ref) -> str | None:
        seen: set[int] = set()
        stack = [type_ref]
        while stack:
            candidate = stack.pop()
            if isinstance(candidate, mm.NumberType):
                return f"DECIMAL({candidate.precision},{candidate.scale})"
            candidate_id = getattr(candidate, "id", None)
            if isinstance(candidate_id, int):
                if candidate_id in seen:
                    continue
                seen.add(candidate_id)
            stack.extend(getattr(candidate, "super_types", ()))
        return None

    def _type_lineage(self, type_ref: mm.ScalarType) -> Iterable[mm.ScalarType]:
        seen: set[int] = set()
        stack = [type_ref]
        while stack:
            candidate = stack.pop()
            if candidate.id in seen:
                continue
            seen.add(candidate.id)
            yield candidate
            stack.extend(
                super_type
                for super_type in getattr(candidate, "super_types", ())
                if isinstance(super_type, mm.ScalarType)
            )

    def _safe_identifier(self, token: str) -> str:
        normalized = re.sub(r"[^0-9A-Za-z_]+", "_", token)
        normalized = re.sub(r"_+", "_", normalized).strip("_")
        return normalized or "obj"


__all__ = [
    "Catalog",
    "CatalogBuilder",
    "DataStore",
    "EntityStore",
    "RelationStore",
    "StoreColumn",
]
