var exportSpecs = parseJsonArray(EXPORT_SPECS_JSON, "EXPORT_SPECS_JSON");

executeSql(
    "CALL " + META_SCHEMA + ".POLL_USE_INDEX_UNTIL_READY("
    + sqlStringLiteral(APP_NAME) + ", "
    + sqlStringLiteral(SOURCE_TABLES_JSON == null || SOURCE_TABLES_JSON === "" ? "[]" : SOURCE_TABLES_JSON) + ", "
    + sqlStringLiteral(MODEL_DATABASE) + ", "
    + sqlStringLiteral(ENGINE_NAME) + ", "
    + sqlNullableStringLiteral(ENGINE_SIZE) + ", "
    + sqlBooleanLiteral(WAIT_FOR_STREAM_SYNC, "WAIT_FOR_STREAM_SYNC") + ", "
    + "1, 10)"
);

executeSql(
    "CALL " + APP_NAME + ".api.exec_async_v2("
    + sqlStringLiteral(LQP_PAYLOAD_B64) + ", "
    + "OBJECT_CONSTRUCT_KEEP_NULL("
    + "'database', " + sqlStringLiteral(MODEL_DATABASE) + ", "
    + "'engine', " + sqlStringLiteral(ENGINE_NAME) + ", "
    + "'inputs', PARSE_JSON('{}'), "
    + "'readonly', FALSE, "
    + "'nowait_durable', TRUE, "
    + "'headers', NULL, "
    + "'language', 'lqp', "
    + "'timeout_mins', " + sqlNullableIntLiteral(QUERY_TIMEOUT_MINS)
    + "))"
);

var txnResult = queryLastResultObject();
var txnId = txnResult["ID"];
if (txnId == null || txnId === "") {
    throw new Error("Failed to create LQP transaction for block " + String(BLOCK_INDEX));
}
txnId = String(txnId);

var txnState = null;
var abortReason = null;
var pollWaitSeconds = 1;
while (true) {
    executeSql(
        "CALL " + APP_NAME + ".api.get_transaction("
        + sqlStringLiteral(txnId)
        + ", PARSE_JSON('{}'))"
    );

    var txnStatusResult = queryLastResultObject();
    txnState = txnStatusResult["STATE"];
    abortReason = txnStatusResult["ABORT_REASON"];

    if (txnState === "COMPLETED" || txnState === "ABORTED") {
        break;
    }

    executeSql("SELECT SYSTEM$WAIT(" + String(pollWaitSeconds) + ")");
    pollWaitSeconds = Math.min(pollWaitSeconds * 2, 10);
}

if (txnState === "ABORTED") {
    throw new Error(
        "LQP transaction aborted for block "
        + String(BLOCK_INDEX)
        + (abortReason ? ": " + String(abortReason) : "")
    );
}

for (var exportIndex = 0; exportIndex < exportSpecs.length; exportIndex += 1) {
    var exportSpec = exportSpecs[exportIndex] || {};
    var exportFilename = exportSpec.export_filename;
    if (exportFilename == null || exportFilename === "") {
        throw new Error("Missing export filename for LQP block " + String(BLOCK_INDEX) +
            ", exportSpec = " + JSON.stringify(exportSpec));
    }
    exportFilename = String(exportFilename);

    var destinationFqn = exportSpec.destination_fqn;
    if (destinationFqn == null || destinationFqn === "") {
        throw new Error("Missing destination_fqn for export " + exportFilename + ".");
    }
    destinationFqn = String(destinationFqn);

    var columnFields = Array.isArray(exportSpec.column_fields) ? exportSpec.column_fields : [];
    var actualCols = Array.isArray(exportSpec.actual_cols) ? exportSpec.actual_cols : [];
    var declaredCols = Array.isArray(exportSpec.declared_cols) ? exportSpec.declared_cols : [];
    var resultTableName = exportFilename + "_table";
    var resultFqn = APP_NAME + ".results." + resultTableName;
    var tempTableReady = false;

    try {
        executeSql(
            "CALL " + APP_NAME + ".api.persist_from_stage("
            + sqlStringLiteral(txnId) + ", "
            + sqlStringLiteral(exportFilename) + ", "
            + sqlStringLiteral(resultTableName) + ", "
            + "PARSE_JSON(" + sqlStringLiteral(JSON.stringify(columnFields)) + "))"
        );
        tempTableReady = true;

        var projectionParts = [];
        var columnIndex = 0;
        for (var declaredIndex = 0; declaredIndex < declaredCols.length; declaredIndex += 1) {
            var declaredCol = String(declaredCols[declaredIndex]);
            if (arrayContainsString(actualCols, declaredCol)) {
                var columnField = columnFields[columnIndex] || [];
                var physicalCol = String(columnField[0] ?? "");
                columnIndex += 1;
                projectionParts.push(physicalCol + " as " + quotedIdentifier(declaredCol));
            } else {
                projectionParts.push("NULL as " + quotedIdentifier(declaredCol));
            }
        }

        var hasResultRows = querySingleValue("SELECT 1 FROM " + resultFqn + " LIMIT 1") !== null;

        var projection = projectionParts.join(", ");
        var refreshSql =
            "BEGIN\n"
            + "    -- Table exists: atomically replace contents.\n"
            + "    INSERT OVERWRITE INTO " + destinationFqn + "\n"
            + "    SELECT " + projection + "\n"
            + "    FROM " + resultFqn + "\n"
            + "    " + (hasResultRows ? "" : "WHERE 1=0") + ";\n"
            + "END;";
        
        executeSql(refreshSql)
    } finally {
        if (tempTableReady) {
            executeSql("CALL " + APP_NAME + ".api.drop_result_table(" + sqlStringLiteral(resultTableName) + ")");
        }
    }
}

return "LQP block refreshed: " + String(BLOCK_INDEX);
