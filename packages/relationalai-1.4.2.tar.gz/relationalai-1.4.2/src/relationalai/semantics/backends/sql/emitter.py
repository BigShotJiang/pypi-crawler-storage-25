from __future__ import annotations

from .sql_backend import SQLBackend
from ...std.datetime_format import DateFormatField, parse_julia_datetime_format

from sqlglot import parse_one

from .artifacts import View
from .sql_ir import (
    SQLBinaryOp,
    SQLCase,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLCreateView,
    SQLExists,
    SQLExpr,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLLiteral,
    SQLNot,
    SQLOrderItem,
    SQLPlaceholder,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSingletonSource,
    SQLSource,
    SQLStar,
    SQLSubquerySource,
    SQLTableSource,
    SQLTableFunctionSource,
    SQLTryCast,
    SQLUnboundVar,
    SQLUnionQuery,
    SQLValuesSource,
    SQLWindowCall,
)

_TZ_PATTERN_KINDS = frozenset({"tz_offset", "tz_name"})
_DATE_INVALID_FORMAT_KINDS = frozenset(
    {
        "second_unpadded",
        "second_padded",
        "millisecond",
        "hour24_unpadded",
        "hour24_padded",
        "minute_unpadded",
        "minute_padded",
        "tz_offset",
        "tz_name",
        "hour12_unpadded",
        "hour12_padded",
        "ampm",
    }
)
_SIMPLE_FUNCTION_TEMPLATES = {
    "like": (2, "({0} LIKE {1})"),
    "starts_with": (2, "({0} LIKE CONCAT({1}, '%'))"),
    "startswith": (2, "({0} LIKE CONCAT({1}, '%'))"),
    "ends_with": (2, "({0} LIKE CONCAT('%', {1}))"),
    "endswith": (2, "({0} LIKE CONCAT('%', {1}))"),
    "contains": (2, "({0} LIKE CONCAT('%', {1}, '%'))"),
    "strip": (1, "TRIM({0})"),
    "trim": (1, "TRIM({0})"),
    "natural_log": (1, "LN({0})"),
    "ln": (1, "LN({0})"),
    "parse_float": (1, "TRY_CAST({0} AS DOUBLE)"),
    "parse_uuid": (1, "TRY_CAST({0} AS UUID)"),
    "uuid_to_string": (1, "CAST({0} AS VARCHAR)"),
    "string": (1, "CAST({0} AS VARCHAR)"),
    "isinf": (1, "COALESCE(ISINF({0}), FALSE)"),
    "isnan": (1, "COALESCE(ISNAN({0}), FALSE)"),
    "acot": (1, "(CASE WHEN ({0}) = 0 THEN PI() / 2 ELSE ATAN(1.0 / CAST({0} AS DOUBLE)) END)"),
    "cot": (1, "(1.0 / TAN({0}))"),
    "factorial": (1, "FACTORIAL(CAST({0} AS INTEGER))"),
    "levenshtein": (2, "LEVENSHTEIN({0}, {1})"),
    "pow": (2, "POWER({0}, {1})"),
    "power": (2, "POWER({0}, {1})"),
    "log": (2, "LOG({0}, {1})"),
    "dates_period_days": (2, "DATE_DIFF('day', {0}, {1})"),
    "datetimes_period_milliseconds": (2, "DATE_DIFF('millisecond', {0}, {1})"),
    "date_year": (1, "YEAR({0})"),
    "date_month": (1, "MONTH({0})"),
    "date_day": (1, "DAY({0})"),
    "date_week": (1, "WEEK({0})"),
    "date_quarter": (1, "QUARTER({0})"),
    "date_dayofyear": (1, "DAYOFYEAR({0})"),
    "date_weekday": (1, "DATE_PART('isodow', {0})"),
    "date_isoweekday": (1, "DATE_PART('isodow', {0})"),
    "day": (1, "{0}"),
    "week": (1, "{0}"),
    "month": (1, "{0}"),
    "year": (1, "{0}"),
    "hour": (1, "{0}"),
    "minute": (1, "{0}"),
    "second": (1, "{0}"),
    "millisecond": (1, "{0}"),
    "microsecond": (1, "{0}"),
    "nanosecond": (1, "{0}"),
}
_DATETIME_EXTRACT_FUNCTIONS = {
    "year": "YEAR",
    "month": "MONTH",
    "day": "DAY",
    "week": "WEEK",
    "quarter": "QUARTER",
    "dayofyear": "DAYOFYEAR",
    "hour": "HOUR",
    "minute": "MINUTE",
    "second": "SECOND",
}


def _single_field_kind(fmt: str) -> str | None:
    parts = parse_julia_datetime_format(fmt)
    if len(parts) == 1 and isinstance(parts[0], DateFormatField):
        return parts[0].kind
    return None


class SQLEmitter:
    def __init__(self, backend: "SQLBackend"):
        self._backend = backend

    def pretty(self, op: object) -> str:
        sql = self.emit(op)
        dialect = self._backend.dialect_name()
        try:
            return parse_one(sql, read=dialect).sql(dialect=dialect, pretty=True)
        except Exception:
            return sql

    def emit(self, op: object) -> str:
        # View/SQLCreateView deliberately emit only the inner SELECT here:
        # deciding the DDL wrapper (CREATE VIEW vs DYNAMIC TABLE vs typed-empty
        # TABLE) is the backend's responsibility, via emit_install_ddl /
        # emit_refresh_sql, which take the body as a string argument.
        if isinstance(op, (View, SQLCreateView)):
            return self.emit_query(op.query)
        if isinstance(op, SQLQuery):
            return self.emit_query(op)
        if isinstance(op, str):
            return op
        raise TypeError(f"SQLEmitter cannot emit object of type {type(op).__name__}.")

    def emit_query(self, query: SQLQuery) -> str:
        if isinstance(query, SQLSelectQuery):
            return self._emit_select_query(query)
        if isinstance(query, SQLUnionQuery):
            return f"\n{query.operator}\n".join(self._emit_wrapped_query(child) for child in query.queries)
        raise TypeError(f"SQLEmitter cannot emit query of type {type(query).__name__}.")

    def _emit_select_query(self, query: SQLSelectQuery) -> str:
        select_sql = ", ".join(self._emit_select_item(item) for item in query.select) if query.select else "1"
        prefix = "SELECT DISTINCT" if query.distinct else "SELECT"
        parts = [f"{prefix} {select_sql}"]
        if query.from_item is not None:
            src = query.from_item.source
            alias = query.from_item.alias
            if isinstance(src, SQLValuesSource) and src.rows and src.column_names:
                cols = ", ".join(self._quote_identifier(c) for c in src.column_names)
                parts.append(f"FROM {self._emit_source(src)} AS {self._quote_identifier(alias)}({cols})")
            else:
                parts.append(f"FROM {self._emit_source(src)} AS {self._quote_identifier(alias)}")
        for join in query.joins:
            # Comma-LATERAL emission for column-ref array unnest. Snowflake
            # rejects ``LEFT JOIN LATERAL FLATTEN(...) ... ON`` syntax; both
            # SF and DuckDB accept the comma-LATERAL form with explicit
            # column-alias list. No ``ON`` predicate (caller arranges
            # correlation via the wrapper subquery's row alignment).
            if (
                isinstance(join.source, SQLTableFunctionSource)
                and join.source.function_name.upper() == "ARRAY_UNNEST"
                and join.source.unnest
            ):
                source_sql = self._emit_source(join.source)
                alias_q = self._quote_identifier(join.alias)
                value_col = (join.source.column_names or ("value",))[0]
                value_q = self._quote_identifier(value_col)
                alias_clause = self._backend.format_array_column_unnest_alias(alias_q, value_q)
                parts.append(f", LATERAL {source_sql} {alias_clause}")
                continue
            on_sql = " AND ".join(self._emit_condition(c) for c in join.conditions) if join.conditions else "TRUE"
            parts.append(f"{join.kind} {self._emit_source(join.source)} AS {self._quote_identifier(join.alias)} ON {on_sql}")
        if query.where:
            parts.append(f"WHERE {' AND '.join(self._emit_condition(c) for c in query.where)}")
        if query.group_by:
            parts.append(f"GROUP BY {', '.join(self.emit_expr(expr) for expr in query.group_by)}")
        if query.order_by:
            parts.append(f"ORDER BY {', '.join(self._emit_order_item(item) for item in query.order_by)}")
        if query.limit is not None:
            parts.append(f"LIMIT {query.limit}")
        return " ".join(parts)

    def _emit_wrapped_query(self, query: SQLQuery) -> str:
        return f"(\n{self.emit_query(query)}\n)"

    def _emit_source(self, source: SQLSource) -> str:
        if isinstance(source, SQLTableSource):
            return self._backend.quote_table_name(source.name)
        if isinstance(source, SQLSubquerySource):
            return f"(\n{self.emit_query(source.query)}\n)"
        if isinstance(source, SQLValuesSource):
            if source.rows:
                row_sql = ", ".join(
                    "(" + ", ".join(self.emit_expr(expr) for expr in row) + ")"
                    for row in source.rows
                )
                return f"(VALUES {row_sql})"
            nulls = ", ".join(f"NULL AS {self._quote_identifier(name)}" for name in source.column_names)
            return f"(SELECT {nulls} WHERE FALSE)"
        if isinstance(source, SQLSingletonSource):
            return "(SELECT 1)"
        if isinstance(source, SQLTableFunctionSource):
            return self._emit_table_function_source(source)
        raise TypeError(f"SQLEmitter cannot emit source of type {type(source).__name__}.")

    def _emit_select_item(self, item: SQLSelectItem) -> str:
        expr_sql = self.emit_expr(item.expr)
        if item.alias is None:
            return expr_sql
        return f"{expr_sql} AS {self._quote_identifier(item.alias)}"

    def _emit_order_item(self, item: SQLOrderItem) -> str:
        sql = self.emit_expr(item.expr)
        return f"{sql} DESC" if item.descending else sql

    def _emit_condition(self, expr: SQLExpr) -> str:
        """Emit a top-level condition (WHERE / ON clause) without outer parentheses."""
        if isinstance(expr, SQLBinaryOp):
            return f"{self.emit_expr(expr.left)} {expr.operator} {self.emit_expr(expr.right)}"
        return self.emit_expr(expr)

    def emit_expr(self, expr: SQLExpr) -> str:
        if isinstance(expr, SQLStar):
            return "*"
        if isinstance(expr, SQLLiteral):
            return self._emit_literal(expr.value)
        if isinstance(expr, SQLColumnRef):
            if expr.table_alias is None:
                return self._quote_identifier(expr.column_name)
            return f"{self._quote_identifier(expr.table_alias)}.{self._quote_identifier(expr.column_name)}"
        if isinstance(expr, SQLBinaryOp):
            return f"({self.emit_expr(expr.left)} {expr.operator} {self.emit_expr(expr.right)})"
        if isinstance(expr, SQLFunctionCall):
            return self._emit_function_call(expr)
        if isinstance(expr, SQLCast):
            return f"CAST({self.emit_expr(expr.expr)} AS {expr.type_name})"
        if isinstance(expr, SQLTryCast):
            return f"TRY_CAST({self.emit_expr(expr.expr)} AS {expr.type_name})"
        if isinstance(expr, SQLWindowCall):
            partition_sql = ""
            if expr.partition_by:
                partition_sql = "PARTITION BY " + ", ".join(self.emit_expr(item) for item in expr.partition_by)
            order_sql = ""
            if expr.order_by:
                order_sql = "ORDER BY " + ", ".join(
                    f"{self.emit_expr(item.expr)} {'DESC' if item.descending else 'ASC'}"
                    for item in expr.order_by
                )
            over_sql = " ".join(part for part in (partition_sql, order_sql) if part)
            return f"{expr.function_name.upper()}() OVER ({over_sql})"
        if isinstance(expr, SQLIsNotNull):
            return f"{self.emit_expr(expr.expr)} IS NOT NULL"
        if isinstance(expr, SQLExists):
            return f"EXISTS ({self.emit_query(expr.query)})"
        if isinstance(expr, SQLNot):
            if isinstance(expr.expr, SQLExists):
                return f"NOT EXISTS ({self.emit_query(expr.expr.query)})"
            return f"NOT ({self.emit_expr(expr.expr)})"
        if isinstance(expr, SQLConcat):
            return " || ".join(self.emit_expr(arg) for arg in expr.args)
        if isinstance(expr, SQLCase):
            whens = " ".join(
                f"WHEN {self.emit_expr(cond)} THEN {self.emit_expr(val)}"
                for cond, val in expr.branches
            )
            else_sql = "" if expr.else_expr is None else f" ELSE {self.emit_expr(expr.else_expr)}"
            return f"CASE {whens}{else_sql} END"
        if isinstance(expr, SQLPlaceholder):
            return expr.name
        if isinstance(expr, SQLUnboundVar):
            return f"NULL /* unbound {expr.name} */"
        raise TypeError(f"SQLEmitter cannot emit expression of type {type(expr).__name__}.")

    def _emit_literal(self, value: object | None) -> str:
        import datetime as dt
        import math

        if value is None:
            return "NULL"
        if isinstance(value, str):
            return "'" + value.replace("'", "''") + "'"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, float):
            if math.isnan(value):
                return "CAST('nan' AS DOUBLE)"
            if math.isinf(value):
                return "CAST('inf' AS DOUBLE)" if value > 0 else "CAST('-inf' AS DOUBLE)"
            return f"CAST({float(value)!r} AS DOUBLE)"
        if isinstance(value, dt.datetime):
            if value.tzinfo is not None and value.utcoffset() is not None:
                utc_value = value.astimezone(dt.timezone.utc).replace(tzinfo=None)
                return "TIMESTAMP '" + utc_value.isoformat(sep=" ") + "'"
            return "TIMESTAMP '" + value.isoformat(sep=" ") + "'"
        if isinstance(value, dt.date):
            return "DATE '" + value.isoformat() + "'"
        return str(value)

    def _emit_function_call(self, expr: SQLFunctionCall) -> str:
        name = expr.name.lower()
        args_sql = [self.emit_expr(arg) for arg in expr.args]

        # Dialect-aware overrides for templates that hard-code DuckDB-only names.
        if name == "dates_period_days" and len(args_sql) == 2:
            return f"{self._backend.function_name('DATE_DIFF')}('day', {args_sql[0]}, {args_sql[1]})"
        if name == "datetimes_period_milliseconds" and len(args_sql) == 2:
            return f"{self._backend.function_name('DATE_DIFF')}('millisecond', {args_sql[0]}, {args_sql[1]})"
        if name == "levenshtein" and len(args_sql) == 2:
            return f"{self._backend.function_name('LEVENSHTEIN')}({args_sql[0]}, {args_sql[1]})"
        if name in {"date_weekday", "date_isoweekday"} and len(args_sql) == 1:
            return self._backend.emit_isoweekday(args_sql[0])
        if name == "regex_match" and len(args_sql) == 2:
            # Args are (pattern, string); the backend hook takes (string, pattern).
            return self._backend.emit_regex_match(args_sql[1], args_sql[0])
        if name == "range_array" and len(args_sql) == 3:
            # Scalar array-construction for the per-row outer-materialization
            # rewrite. Dialect dispatch: DuckDB ``range(...)`` returning
            # ``LIST<BIGINT>``; Snowflake ``ARRAY_GENERATE_RANGE(...)``.
            return self._backend.emit_range_array_expr(args_sql[0], args_sql[1], args_sql[2])

        simple = _SIMPLE_FUNCTION_TEMPLATES.get(name)
        if simple is not None and len(args_sql) == simple[0]:
            return simple[1].format(*args_sql)
        if name in {"parse_number", "parse_decimal"} and len(args_sql) == 1:
            return f"TRY_CAST({args_sql[0]} AS {expr.sql_type or 'DECIMAL(38,14)'})"
        if name in {"parse_number", "parse_decimal"} and len(args_sql) >= 3:
            return f"TRY_CAST({args_sql[0]} AS DECIMAL({args_sql[1]}, {args_sql[2]}))"
        if name == "parse_int" and len(args_sql) == 1:
            return f"TRY_CAST({args_sql[0]} AS {expr.sql_type or 'DECIMAL(38,0)'})"
        if name == "hash" and args_sql:
            return f"CAST(HASH({', '.join(args_sql)}) AS VARCHAR)"
        if name == "clip" and len(args_sql) == 3:
            return f"LEAST(GREATEST({args_sql[0]}, {args_sql[1]}), {args_sql[2]})"
        if name.startswith("datetime_") and args_sql:
            base_sql = args_sql[0]
            if len(args_sql) >= 2:
                base_sql = self._backend.convert_naive_utc_to_tz(base_sql, args_sql[1])
            suffix = name.removeprefix("datetime_")
            if suffix in {"weekday", "isoweekday"}:
                return self._backend.emit_isoweekday(base_sql)
            sql_fn = _DATETIME_EXTRACT_FUNCTIONS.get(suffix)
            if sql_fn is not None:
                return f"{sql_fn}({base_sql})"
        if name in {"date_diff", "datetime_diff"} and len(args_sql) == 3:
            return f"{self._backend.function_name('DATE_DIFF')}({args_sql[0]}, {args_sql[1]}, {args_sql[2]})"
        if name in {"date_add", "date_subtract", "datetime_add", "datetime_subtract"} and len(expr.args) == 2:
            period = self._extract_period(expr.args[1])
            if period is not None:
                value_sql, unit = period
                return self._emit_date_add_or_subtract(
                    op_name=name,
                    base_sql=args_sql[0],
                    value_sql=value_sql,
                    unit=unit,
                )
        if name in {"date_format", "datetime_format"} and len(expr.args) >= 2:
            value_sql = args_sql[0]
            fmt_arg = expr.args[1]
            value_kind = "date" if name == "date_format" else "datetime"
            if name == "datetime_format" and len(expr.args) >= 3:
                value_sql = self._backend.convert_naive_utc_to_tz(value_sql, args_sql[2])
            if isinstance(fmt_arg, SQLLiteral) and isinstance(fmt_arg.value, str):
                # Semantic edge cases (dialect-agnostic) short-circuit here.
                single_kind = _single_field_kind(fmt_arg.value)
                if value_kind == "date" and single_kind in _DATE_INVALID_FORMAT_KINDS:
                    return "NULL"
                if value_kind == "datetime" and single_kind == "tz_name":
                    return "'UTC'"
                if value_kind == "datetime" and single_kind == "tz_offset":
                    return "'+00:00'"
                parts = parse_julia_datetime_format(fmt_arg.value)
                if value_kind == "datetime" and {p.kind for p in parts if isinstance(p, DateFormatField)} & _TZ_PATTERN_KINDS:
                    return "NULL"
                return self._backend.emit_format_datetime(
                    value_sql, parts, value_kind=value_kind,
                )
            # Non-literal format string: callers don't actually exercise this
            # path today, but preserve old behavior via the default backend.
            fmt_sql = args_sql[1]
            return f"{self._backend.function_name('STRFTIME')}({value_sql}, {fmt_sql})"
        if name in {"parse_date", "parse_datetime"} and len(expr.args) == 2:
            fmt_arg = expr.args[1]
            target = "date" if name == "parse_date" else "datetime"
            if isinstance(fmt_arg, SQLLiteral) and isinstance(fmt_arg.value, str):
                parts = parse_julia_datetime_format(fmt_arg.value)
                has_tz = bool(
                    {p.kind for p in parts if isinstance(p, DateFormatField)} & _TZ_PATTERN_KINDS
                )
                return self._backend.emit_parse_datetime(
                    args_sql[0], parts, target=target, has_tz=has_tz,
                )
            # Non-literal format string fallback.
            fmt_sql = args_sql[1]
            cast_to = "DATE" if target == "date" else "TIMESTAMP"
            return f"CAST({self._backend.function_name('STRPTIME')}({args_sql[0]}, {fmt_sql}) AS {cast_to})"
        if name == "construct_date" and len(args_sql) == 3:
            return (
                f"{self._backend.function_name('MAKE_DATE')}("
                f"CAST({args_sql[0]} AS BIGINT), "
                f"CAST({args_sql[1]} AS BIGINT), "
                f"CAST({args_sql[2]} AS BIGINT))"
            )
        if name == "construct_date_from_datetime" and len(args_sql) == 2:
            return f"CAST({self._backend.convert_naive_utc_to_tz(args_sql[0], args_sql[1])} AS DATE)"
        if name == "construct_datetime_ms_tz" and len(args_sql) == 8:
            local_ts = self._backend.emit_construct_timestamp_ms(
                year_sql=args_sql[0],
                month_sql=args_sql[1],
                day_sql=args_sql[2],
                hour_sql=args_sql[3],
                minute_sql=args_sql[4],
                second_sql=args_sql[5],
                millisecond_sql=args_sql[6],
            )
            return f"CAST({self._backend.convert_naive_tz_to_utc(local_ts, args_sql[7])} AS TIMESTAMP)"
        if name == "substring" and len(args_sql) in {2, 3}:
            start_sql = f"CAST({args_sql[1]} AS BIGINT)"
            if len(args_sql) == 2:
                return f"SUBSTRING({args_sql[0]}, ({start_sql} + 1))"
            stop_sql = f"CAST({args_sql[2]} AS BIGINT)"
            return f"SUBSTRING({args_sql[0]}, ({start_sql} + 1), ({stop_sql} - {start_sql}))"
        if name in {"split_part", "split", "str_split"} and len(args_sql) == 3:
            index_sql = f"(CAST({args_sql[2]} AS BIGINT) + 1)"
            return f"SPLIT_PART({args_sql[0]}, {args_sql[1]}, {index_sql})"

        rendered_args = ", ".join(args_sql)
        return f"{expr.name.upper()}({rendered_args})"

    def _emit_table_function_source(self, source: SQLTableFunctionSource) -> str:
        # Dialect dispatch for RANGE: Snowflake has no `RANGE` table function;
        # use a recursive CTE there. DuckDB keeps the native RANGE.
        if (
            source.function_name.upper() == "RANGE"
            and len(source.args) == 3
            and not source.unnest
            and not source.with_ordinality
            and source.column_names
        ):
            start_sql, stop_sql, step_sql = (self.emit_expr(arg) for arg in source.args)
            return self._backend.emit_range_table_function(
                start_sql, stop_sql, step_sql, source.column_names[0]
            )

        # Dialect dispatch for column-ref array unnest. The lowerer's per-row
        # outer-materialization rewrite emits this with a single column-ref
        # arg and ``unnest=True``; DuckDB emits ``UNNEST(col)``, Snowflake
        # emits ``FLATTEN(input => col)``. The enclosing JOIN is rendered
        # comma-LATERAL by ``_emit_select_query``.
        if (
            source.function_name.upper() == "ARRAY_UNNEST"
            and len(source.args) == 1
            and source.unnest
            and not source.with_ordinality
            and source.column_names
        ):
            col_sql = self.emit_expr(source.args[0])
            return self._backend.emit_array_column_unnest_source(
                col_sql, source.column_names[0]
            )

        # Dialect dispatch for STRING_SPLIT: DuckDB unnests STRING_SPLIT with
        # ordinality; Snowflake's parser rejects STRING_SPLIT and uses the
        # SPLIT_TO_TABLE table function.
        if (
            source.function_name.upper() == "STRING_SPLIT"
            and len(source.args) == 2
            and source.unnest
            and source.with_ordinality
            and source.zero_based_ordinality
            and len(source.column_names) == 2
        ):
            string_sql, sep_sql = (self.emit_expr(arg) for arg in source.args)
            value_col, index_col = source.column_names
            return self._backend.emit_split_to_table(
                string_sql, sep_sql, value_col, index_col
            )

        args_sql = ", ".join(self.emit_expr(arg) for arg in source.args)
        call_sql = f"{source.function_name}({args_sql})"
        base_sql = f"UNNEST({call_sql})" if source.unnest else call_sql

        if source.with_ordinality:
            value_name = source.column_names[0] if source.column_names else "value"
            ord_name = source.column_names[1] if len(source.column_names) > 1 else "index"
            ord_expr = "(ord - 1)" if source.zero_based_ordinality else "ord"
            return (
                "(\nSELECT "
                f"value AS {self._quote_identifier(value_name)}, {ord_expr} AS {self._quote_identifier(ord_name)} "
                f"FROM {base_sql} WITH ORDINALITY AS table_fn(value, ord)\n)"
            )

        if source.column_names:
            columns = ", ".join(self._quote_identifier(name) for name in source.column_names)
            return f"(\nSELECT * FROM {base_sql} AS table_fn({columns})\n)"
        return f"(\nSELECT * FROM {base_sql}\n)"

    def _quote_identifier(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def _qid_path(self, path: str) -> str:
        return ".".join(self._quote_identifier(part) for part in path.split("."))

    def _extract_period(self, period_expr: SQLExpr) -> tuple[str, str] | None:
        while isinstance(period_expr, SQLCast):
            period_expr = period_expr.expr
        if not isinstance(period_expr, SQLFunctionCall) or len(period_expr.args) != 1:
            return None
        unit = period_expr.name.upper()
        allowed_units = {
            "NANOSECOND",
            "MICROSECOND",
            "MILLISECOND",
            "SECOND",
            "MINUTE",
            "HOUR",
            "DAY",
            "WEEK",
            "MONTH",
            "YEAR",
        }
        if unit not in allowed_units:
            return None
        return self.emit_expr(period_expr.args[0]), unit

    def _emit_date_add_or_subtract(self, *, op_name: str, base_sql: str, value_sql: str, unit: str) -> str:
        # Dialect-dispatch: DuckDB uses ``base + n * INTERVAL 1 unit``;
        # Snowflake rejects that form for runtime ``n`` and needs ``DATEADD(unit, n, base)``.
        # The MILLISECOND case is identical in both forms — no special-case needed.
        signed_value = value_sql if op_name in {"date_add", "datetime_add"} else f"-({value_sql})"
        return self._backend.emit_date_arithmetic(
            base_sql=base_sql, signed_value_sql=signed_value, unit=unit,
        )
