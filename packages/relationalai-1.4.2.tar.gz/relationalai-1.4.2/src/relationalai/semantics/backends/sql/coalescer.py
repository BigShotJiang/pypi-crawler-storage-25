"""Coalescing pass for sql9 model contributions."""
from __future__ import annotations


from ...metamodel import metamodel as mm
from .artifacts import Target, PlannedTarget, CoalescedBlock, Catalog, ExecutionBlock
from .reasoner_router import DEFAULT_REASONER_TYPE




class Coalescer:
    def plan(
        self,
        model: mm.Model,
        catalog: Catalog,
        blocks: tuple[ExecutionBlock, ...],
        forced_reasoners: dict[int, str] | None = None,
    ) -> tuple[CoalescedBlock, ...]:
        # ``forced_reasoners`` is a per-relation forcing already propagated
        # across SCC members upstream (see ``_resolve_forced_reasoners``), so a
        # rule writing any SCC member sees the SCC's forced reasoner here and
        # lands in the bucket the ReasonerRouter routed the block to.
        relation_to_reasoner = {
            **model.reasoner_type_by_relation_id(),
            **(forced_reasoners or {}),
        }
        sql_contributions, sql_targets_by_relation_id = (
            self._gather_reasoner_contributions(model, catalog, "sql", relation_to_reasoner)
        )
        logic_contributions, logic_targets_by_relation_id = (
            self._gather_reasoner_contributions(model, catalog, "logic", relation_to_reasoner)
        )

        planned: list[CoalescedBlock] = []
        for exec_block in blocks:
            if exec_block.reasoner_type == "logic":
                contributions_by_target = logic_contributions
                targets_by_relation_id = logic_targets_by_relation_id
            else:
                contributions_by_target = sql_contributions
                targets_by_relation_id = sql_targets_by_relation_id
            coalesced = self._coalesce_block(
                exec_block, contributions_by_target, targets_by_relation_id
            )
            if coalesced is not None:
                planned.append(coalesced)

        return tuple(planned)

    def _gather_rule_block_contributions(
        self,
        model: mm.Model,
        catalog: Catalog,
        reasoner_type: str,
        relation_to_reasoner: dict[int, str],
    ) -> tuple[dict[Target, list[mm.Task]], dict[int, set[Target]]]:
        contributions_by_target: dict[Target, list[mm.Task]] = {}
        targets_by_relation_id: dict[int, set[Target]] = {}

        for rule_block in self._rule_blocks(model.root):
            for target in self._targets_for_block(rule_block, catalog, model):
                projected = self._project_block(rule_block, target, catalog)
                if projected is None:
                    continue
                written_reasoners = {
                    relation_to_reasoner.get(rid, DEFAULT_REASONER_TYPE)
                    for rid in self._written_relation_ids(projected)
                }
                if written_reasoners != {reasoner_type}:
                    continue
                contributions_by_target.setdefault(target, []).append(projected)
                for rid in target.relation_ids:
                    targets_by_relation_id.setdefault(rid, set()).add(target)
        return contributions_by_target, targets_by_relation_id

    def _written_relation_ids(self, task: mm.Task) -> set[int]:
        """Collect relation ids written by the Update and Construct nodes in ``task``."""
        written: set[int] = set()
        for update in self._updates(task):
            rid = getattr(update.relation, "id", None)
            if isinstance(rid, int):
                written.add(rid)
        for construct in self._constructs(task):
            type_id = getattr(construct.id_var.type, "id", None)
            if isinstance(type_id, int):
                written.add(type_id)
        return written

    def _gather_reasoner_contributions(
        self,
        model: mm.Model,
        catalog: Catalog,
        reasoner_type: str,
        relation_to_reasoner: dict[int, str],
    ) -> tuple[dict[Target, list[mm.Task]], dict[int, set[Target]]]:
        """Gather contributions for ``reasoner_type``.

        Two sources are merged: plain rule blocks whose writes resolve to this
        reasoner, and procedures pinned to a reasoner of this type via
        ``model.reasoners``.
        """
        contributions_by_target, targets_by_relation_id = (
            self._gather_rule_block_contributions(
                model, catalog, reasoner_type, relation_to_reasoner
            )
        )
        for reasoner in model.reasoners:
            if reasoner.type.lower() != reasoner_type:
                continue
            tasks = self._find_tasks_for_reasoner(model.root, reasoner)
            if not tasks:
                continue

            reasoner_targets: list[Target] = []
            seen_keys: set[tuple[str, int]] = set()
            for relation in reasoner.relations:
                result = self._target_for_relation(relation, model, catalog)
                if result is None:
                    continue
                key, target = result
                if key in seen_keys:
                    continue
                seen_keys.add(key)
                reasoner_targets.append(target)
                for rid in target.relation_ids:
                    targets_by_relation_id.setdefault(rid, set()).add(target)

            if not reasoner_targets:
                continue

            local_target_by_relation_id: dict[int, Target] = {}
            for target in reasoner_targets:
                for rid in target.relation_ids:
                    local_target_by_relation_id.setdefault(rid, target)

            # Attach each task to every target it writes to. Procedures are one
            # execution unit that may write to multiple targets (e.g. a folded
            # property and a relation); each target needs the task so that
            # blocks containing different subsets of targets all install the
            # procedure. LogicBlockBuilder dedupes by task identity when
            # multiple targets in the same block carry the same task.
            for task in tasks:
                written = self._written_relation_ids(task)
                matching_targets: list[Target] = []
                seen_object_names: set[str] = set()
                for rid in sorted(written & local_target_by_relation_id.keys()):
                    target = local_target_by_relation_id[rid]
                    if target.object_name in seen_object_names:
                        continue
                    seen_object_names.add(target.object_name)
                    matching_targets.append(target)
                if not matching_targets:
                    matching_targets = [reasoner_targets[0]]
                for owner in matching_targets:
                    contributions_by_target.setdefault(owner, []).append(task)
        return contributions_by_target, targets_by_relation_id


    @staticmethod
    def _find_tasks_for_reasoner(root: mm.Task, reasoner: mm.Reasoner) -> list[mm.Task]:
        result: list[mm.Task] = []
        stack: list[mm.Task] = [root]
        while stack:
            node = stack.pop()
            if node.reasoner is not None and node.reasoner.id == reasoner.id:
                result.append(node)
            body = getattr(node, "body", None)
            if isinstance(body, mm.Task):
                stack.append(body)
            elif body is not None:
                stack.extend(body)
            tasks = getattr(node, "tasks", None)
            if tasks is not None:
                stack.extend(tasks)
            check = getattr(node, "check", None)
            if isinstance(check, mm.Task):
                stack.append(check)
        return result

    def _coalesce_block(
        self,
        exec_block: ExecutionBlock,
        contributions_by_target: dict[Target, list[mm.Task]],
        targets_by_relation_id: dict[int, set[Target]],
    ) -> CoalescedBlock | None:
        seen_targets: set[Target] = set()
        for relation_id in exec_block.relation_ids:
            seen_targets.update(targets_by_relation_id.get(relation_id, ()))

        if not seen_targets:
            return None

        targets = []
        for target in seen_targets:
            contribs = contributions_by_target.get(target, ())
            recursive_component_relation_ids = next(
                (
                    component
                    for component in exec_block.recursive_component_relation_ids
                    if set(component) & set(target.relation_ids)
                ),
                (),
            )
            targets.append(
                PlannedTarget(
                    target=target,
                    tasks=tuple(contribs),
                    recursive=bool(recursive_component_relation_ids),
                    recursive_component_relation_ids=recursive_component_relation_ids,
                )
            )

        return CoalescedBlock(
            index=exec_block.index,
            reasoner_type=exec_block.reasoner_type,
            # sorted for a stable execution order
            targets=tuple(sorted(targets, key=lambda pt: pt.target.object_name)),
            recursive=exec_block.recursive,
            input_relation_ids=exec_block.input_relation_ids,
            output_relation_ids=exec_block.output_relation_ids,
            interval_s=exec_block.interval_s,
        )

    def _rule_blocks(self, task: mm.Task, inherited_context: tuple[mm.Task, ...] = ()):
        if not isinstance(task, mm.Logical):
            return
        if self._has_direct_model_write(task):
            yield mm.Logical(body=(*inherited_context, *task.body), optional=task.optional, scope=task.scope)
            return

        local_context = tuple(child for child in task.body if not isinstance(child, mm.Logical))
        for child in task.body:
            if isinstance(child, mm.Logical):
                yield from self._rule_blocks(child, inherited_context=(*inherited_context, *local_context))
            elif isinstance(child, mm.Sequence):
                yield from self._rule_blocks(child, inherited_context=(*inherited_context, *local_context))

    def _has_direct_model_write(self, task: mm.Logical) -> bool:
        return any(isinstance(child, (mm.Update, mm.Construct)) for child in task.body)

    def _targets_for_block(self, block: mm.Logical, catalog: Catalog, model: mm.Model) -> tuple[Target, ...]:
        targets: dict[tuple[str, int], Target] = {}
        constructs = self._constructs(block)
        updates = self._updates(block)
        ignored_update_keys = self._ignored_entity_update_keys(block, constructs)

        for construct in constructs:
            if not self._is_primary_construct(
                construct,
                constructs,
                updates,
                ignored_update_keys,
            ):
                continue
            entity_type = construct.id_var.type
            if isinstance(entity_type, mm.ScalarType):
                try:
                    store = catalog.entity_store(entity_type)
                except KeyError:
                    continue
                targets[("entity", store.type_id)] = Target(
                    kind="entity",
                    object_name=store.object_name,
                    column_names=tuple(column.name for column in store.columns),
                    key_columns=store.key_columns,
                    anchor_id=store.type_id,
                    relation_ids=self._entity_target_relation_ids(entity_type, model, catalog),
                )

        for update in updates:
            is_entity = catalog.is_folded_property(update.relation)
            if not is_entity:
                try:
                    catalog.entity_store(update.relation)
                    is_entity = True
                except KeyError:
                    pass
            if is_entity and self._is_ignored_entity_update(update, ignored_update_keys):
                continue
            result = self._target_for_relation(update.relation, model, catalog)
            if result is not None:
                key, target = result
                targets[key] = target

        return tuple(targets.values())

    def _entity_target_relation_ids(
        self,
        entity_ref: mm.ScalarType | int,
        model: mm.Model,
        catalog: Catalog,
    ) -> tuple[int, ...]:
        entity_type_id = entity_ref if isinstance(entity_ref, int) else getattr(entity_ref, "id", None)
        if not isinstance(entity_type_id, int):
            return ()
        relation_ids = [entity_type_id]
        for relation in model.relations:
            if not catalog.is_folded_property(relation):
                continue
            if catalog.owner_store_for_property(relation).type_id == entity_type_id:
                relation_ids.append(relation.id)
        return tuple(relation_ids)

    def _target_for_relation(
        self,
        relation,
        model: mm.Model,
        catalog: Catalog,
    ) -> tuple[tuple[str, int], Target] | None:
        if catalog.is_folded_property(relation):
            store = catalog.owner_store_for_property(relation)
            return ("entity", store.type_id), Target(
                kind="entity",
                object_name=store.object_name,
                column_names=tuple(c.name for c in store.columns),
                key_columns=store.key_columns,
                anchor_id=store.type_id,
                relation_ids=self._entity_target_relation_ids(store.type_id, model, catalog),
            )
        try:
            entity_store = catalog.entity_store(relation)
            return ("entity", entity_store.type_id), Target(
                kind="entity",
                object_name=entity_store.object_name,
                column_names=tuple(c.name for c in entity_store.columns),
                key_columns=entity_store.key_columns,
                anchor_id=entity_store.type_id,
                relation_ids=self._entity_target_relation_ids(entity_store.type_id, model, catalog),
            )
        except KeyError:
            pass
        try:
            rel_store = catalog.relation_store(relation)
            return ("relation", rel_store.relation_id), Target(
                kind="relation",
                object_name=rel_store.object_name,
                column_names=tuple(c.name for c in rel_store.columns),
                key_columns=rel_store.key_columns,
                anchor_id=rel_store.relation_id,
                relation_ids=(rel_store.relation_id,),
            )
        except KeyError:
            return None

    def _is_primary_construct(
        self,
        construct: mm.Construct,
        constructs: tuple[mm.Construct, ...],
        updates: tuple[mm.Update, ...],
        ignored_update_keys: set[tuple[int, int]],
    ) -> bool:
        construct_var_id = construct.id_var.id
        construct_type_id = getattr(construct.id_var.type, "id", None)
        if isinstance(construct_type_id, int) and (construct_type_id, construct_var_id) in ignored_update_keys:
            return False
        if any(
            update.args
            and isinstance(update.args[0], mm.Var)
            and update.args[0].id == construct_var_id
            and not self._is_ignored_entity_update(update, ignored_update_keys)
            for update in updates
        ):
            return True
        return not any(
            other is not construct
            and any(isinstance(value, mm.Var) and value.id == construct_var_id for value in other.values)
            for other in constructs
        )

    def _binding_lookup_keys(self, task: mm.Task) -> set[tuple[int, int]]:
        binding_keys: set[tuple[int, int]] = set()

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Lookup):
                relation_id = getattr(node.relation, "id", None)
                if (
                    isinstance(relation_id, int)
                    and node.args
                    and isinstance(node.args[0], mm.Var)
                ):
                    binding_keys.add((relation_id, node.args[0].id))
                return
            if isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)
                return
            if isinstance(node, mm.Sequence):
                for child in node.tasks:
                    walk(child)
                return
            if isinstance(node, (mm.Union, mm.Match)):
                for child in node.tasks:
                    walk(child)
                return
            if isinstance(node, mm.Not):
                walk(node.task)
                return
            if isinstance(node, mm.Aggregate):
                walk(node.body)

        walk(task)
        return binding_keys

    def _ignored_entity_update_keys(
        self,
        task: mm.Task,
        constructs: tuple[mm.Construct, ...],
    ) -> set[tuple[int, int]]:
        binding_lookup_keys = self._binding_lookup_keys(task)
        ignored_update_keys: set[tuple[int, int]] = set(binding_lookup_keys)
        for construct in constructs:
            relation_id = getattr(construct.id_var.type, "id", None)
            if not isinstance(relation_id, int) or (relation_id, construct.id_var.id) not in binding_lookup_keys:
                continue
            owner_type = construct.id_var.type
            identify_by = tuple(getattr(owner_type, "identify_by", ()))
            ignored_update_keys.update(
                (identify_relation.id, construct.id_var.id)
                for identify_relation in identify_by
            )
        return ignored_update_keys

    def _is_ignored_entity_update(
        self,
        update: mm.Update,
        ignored_update_keys: set[tuple[int, int]],
    ) -> bool:
        relation_id = getattr(update.relation, "id", None)
        if not isinstance(relation_id, int) or not update.args:
            return False
        owner = update.args[0]
        if not isinstance(owner, mm.Var):
            return False
        return (relation_id, owner.id) in ignored_update_keys

    def _project_block(self, block: mm.Logical, target: Target, catalog: Catalog) -> mm.Logical | None:
        all_constructs = tuple(self._constructs(block))
        ignored_update_keys = self._ignored_entity_update_keys(block, all_constructs)
        kept_updates = []
        for update in self._updates(block):
            if target.kind == "entity":
                if catalog.is_folded_property(update.relation):
                    if self._is_ignored_entity_update(update, ignored_update_keys):
                        continue
                    owner_store = catalog.owner_store_for_property(update.relation)
                    if owner_store.object_name == target.object_name:
                        kept_updates.append(update)
                    continue
                if self._is_ignored_entity_update(update, ignored_update_keys):
                    continue
                try:
                    entity_store = catalog.entity_store(update.relation)
                except KeyError:
                    entity_store = None
                if entity_store is not None and entity_store.object_name == target.object_name:
                    kept_updates.append(update)
            elif target.kind == "relation":
                try:
                    store = catalog.relation_store(update.relation)
                except KeyError:
                    continue
                if store.object_name == target.object_name:
                    kept_updates.append(update)

        kept_constructs = self._constructs_for_target(all_constructs, tuple(kept_updates), target, catalog)
        if not kept_constructs and not kept_updates:
            return None

        other_tasks = [
            pruned
            for child in block.body
            if not isinstance(child, mm.Update)
            and not isinstance(child, mm.Construct)
            and (pruned := self._strip_writes(child)) is not None
        ]
        return mm.Logical(body=(*kept_constructs, *other_tasks, *kept_updates))

    def _constructs_for_target(
        self,
        all_constructs: tuple[mm.Construct, ...],
        kept_updates: tuple[mm.Update, ...],
        target: Target,
        catalog: Catalog,
    ) -> tuple[mm.Construct, ...]:
        if target.kind != "entity":
            return all_constructs

        construct_by_var_id = {construct.id_var.id: construct for construct in all_constructs}
        required_ids = {
            construct.id_var.id
            for construct in all_constructs
            if self._construct_targets_match(construct, target, catalog)
        }
        pending = list(required_ids)

        while pending:
            construct = construct_by_var_id[pending.pop()]
            for value in construct.values:
                if isinstance(value, mm.Var) and value.id in construct_by_var_id and value.id not in required_ids:
                    required_ids.add(value.id)
                    pending.append(value.id)

        for update in kept_updates:
            for arg in update.args:
                if isinstance(arg, mm.Var) and arg.id in construct_by_var_id and arg.id not in required_ids:
                    required_ids.add(arg.id)
                    pending.append(arg.id)
                    while pending:
                        construct = construct_by_var_id[pending.pop()]
                        for value in construct.values:
                            if isinstance(value, mm.Var) and value.id in construct_by_var_id and value.id not in required_ids:
                                required_ids.add(value.id)
                                pending.append(value.id)

        return tuple(construct for construct in all_constructs if construct.id_var.id in required_ids)

    def _construct_targets_match(self, construct: mm.Construct, target: Target, catalog: Catalog) -> bool:
        if target.kind != "entity":
            return True
        construct_type = construct.id_var.type
        if not isinstance(construct_type, mm.ScalarType):
            return False
        try:
            store = catalog.entity_store(construct_type)
        except KeyError:
            return False
        return store.object_name == target.object_name

    def _strip_writes(self, task: mm.Task) -> mm.Task | None:
        if isinstance(task, (mm.Update, mm.Construct)):
            return None
        if isinstance(task, mm.Logical):
            body = tuple(
                pruned
                for child in task.body
                if (pruned := self._strip_writes(child)) is not None
            )
            return task.mut(body=body)
        if isinstance(task, (mm.Union, mm.Match)):
            tasks = tuple(
                pruned
                for child in task.tasks
                if (pruned := self._strip_writes(child)) is not None
            )
            return task.mut(tasks=tasks)
        if isinstance(task, mm.Sequence):
            tasks = tuple(
                pruned
                for child in task.tasks
                if (pruned := self._strip_writes(child)) is not None
            )
            return task.mut(tasks=tasks)
        if isinstance(task, mm.Not):
            inner = self._strip_writes(task.task)
            return task.mut(task=inner) if inner is not None else None
        if isinstance(task, mm.Aggregate):
            body = self._strip_writes(task.body)
            return task.mut(body=body) if body is not None else None
        return task

    def _constructs(self, task: mm.Task) -> tuple[mm.Construct, ...]:
        found: list[mm.Construct] = []

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Construct):
                found.append(node)
            elif isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)
            elif isinstance(node, mm.Sequence):
                for child in node.tasks:
                    walk(child)

        walk(task)
        return tuple(found)

    def _updates(self, task: mm.Task) -> tuple[mm.Update, ...]:
        found: list[mm.Update] = []

        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Update):
                found.append(node)
            elif isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)
            elif isinstance(node, mm.Sequence):
                for child in node.tasks:
                    walk(child)

        walk(task)
        return tuple(found)


__all__ = ["Coalescer", "CoalescedBlock", "PlannedTarget", "Target"]
