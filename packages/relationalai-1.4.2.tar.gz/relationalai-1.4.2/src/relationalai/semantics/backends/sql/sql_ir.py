from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SQLExpr:
    pass


@dataclass(frozen=True, slots=True)
class SQLStar(SQLExpr):
    pass


@dataclass(frozen=True, slots=True)
class SQLLiteral(SQLExpr):
    value: object | None


@dataclass(frozen=True, slots=True)
class SQLColumnRef(SQLExpr):
    column_name: str
    table_alias: str | None = None


@dataclass(frozen=True, slots=True)
class SQLBinaryOp(SQLExpr):
    left: SQLExpr
    operator: str
    right: SQLExpr


@dataclass(frozen=True, slots=True)
class SQLFunctionCall(SQLExpr):
    name: str
    args: tuple[SQLExpr, ...] = ()
    sql_type: str | None = None


@dataclass(frozen=True, slots=True)
class SQLCast(SQLExpr):
    expr: SQLExpr
    type_name: str


@dataclass(frozen=True, slots=True)
class SQLTryCast(SQLExpr):
    expr: SQLExpr
    type_name: str


@dataclass(frozen=True, slots=True)
class SQLIsNotNull(SQLExpr):
    expr: SQLExpr


@dataclass(frozen=True, slots=True)
class SQLExists(SQLExpr):
    query: SQLQuery


@dataclass(frozen=True, slots=True)
class SQLNot(SQLExpr):
    expr: SQLExpr


@dataclass(frozen=True, slots=True)
class SQLConcat(SQLExpr):
    args: tuple[SQLExpr, ...] = ()


@dataclass(frozen=True, slots=True)
class SQLCase(SQLExpr):
    """``CASE WHEN cond THEN value [WHEN ...]+ [ELSE else_value] END``."""
    branches: tuple[tuple[SQLExpr, SQLExpr], ...]
    else_expr: SQLExpr | None = None


@dataclass(frozen=True, slots=True)
class SQLPlaceholder(SQLExpr):
    name: str


@dataclass(frozen=True, slots=True)
class SQLUnboundVar(SQLExpr):
    name: str


@dataclass(frozen=True, slots=True)
class SQLSelectItem:
    expr: SQLExpr
    alias: str | None = None



@dataclass(frozen=True, slots=True)
class SQLOrderItem:
    expr: SQLExpr
    descending: bool = False



@dataclass(frozen=True, slots=True)
class SQLWindowCall(SQLExpr):
    function_name: str
    partition_by: tuple[SQLExpr, ...] = ()
    order_by: tuple[SQLOrderItem, ...] = ()


@dataclass(frozen=True, slots=True)
class SQLSource:
    pass


@dataclass(frozen=True, slots=True)
class SQLTableSource(SQLSource):
    name: str


@dataclass(frozen=True, slots=True)
class SQLSubquerySource(SQLSource):
    query: SQLQuery


@dataclass(frozen=True, slots=True)
class SQLValuesSource(SQLSource):
    column_names: tuple[str, ...]
    rows: tuple[tuple[SQLExpr, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class SQLSingletonSource(SQLSource):
    pass


@dataclass(frozen=True, slots=True)
class SQLTableFunctionSource(SQLSource):
    function_name: str
    args: tuple[SQLExpr, ...] = ()
    column_names: tuple[str, ...] = ()
    with_ordinality: bool = False
    zero_based_ordinality: bool = False
    unnest: bool = False


@dataclass(frozen=True, slots=True)
class SQLFromItem:
    source: SQLSource
    alias: str


@dataclass(frozen=True, slots=True)
class SQLJoin:
    kind: str
    source: SQLSource
    alias: str
    conditions: tuple[SQLExpr, ...] = ()


@dataclass(frozen=True, slots=True)
class SQLQuery:
    pass


@dataclass(frozen=True, slots=True)
class SQLSelectQuery(SQLQuery):
    from_item: SQLFromItem | None = None
    joins: tuple[SQLJoin, ...] = ()
    where: tuple[SQLExpr, ...] = ()
    select: tuple[SQLSelectItem, ...] = ()
    group_by: tuple[SQLExpr, ...] = ()
    order_by: tuple[SQLOrderItem, ...] = ()
    distinct: bool = False
    limit: int | None = None


@dataclass(frozen=True, slots=True)
class SQLUnionQuery(SQLQuery):
    queries: tuple[SQLQuery, ...] = ()
    operator: str = "UNION"


@dataclass(frozen=True, slots=True)
class SQLCreateView:
    name: str
    query: SQLQuery


__all__ = [
    "SQLBinaryOp",
    "SQLCase",
    "SQLCast",
    "SQLColumnRef",
    "SQLConcat",
    "SQLCreateView",
    "SQLExists",
    "SQLExpr",
    "SQLFromItem",
    "SQLFunctionCall",
    "SQLIsNotNull",
    "SQLJoin",
    "SQLLiteral",
    "SQLNot",
    "SQLOrderItem",
    "SQLPlaceholder",
    "SQLQuery",
    "SQLSelectItem",
    "SQLSelectQuery",
    "SQLSingletonSource",
    "SQLSource",
    "SQLStar",
    "SQLSubquerySource",
    "SQLTableSource",
    "SQLTableFunctionSource",
    "SQLTryCast",
    "SQLUnboundVar",
    "SQLUnionQuery",
    "SQLValuesSource",
    "SQLWindowCall",
]
