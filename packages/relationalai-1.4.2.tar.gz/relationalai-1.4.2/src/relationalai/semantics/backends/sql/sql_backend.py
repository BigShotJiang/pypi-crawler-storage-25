from __future__ import annotations

from typing import TYPE_CHECKING, Sequence
from pandas import DataFrame

from ...std.datetime_format import DateFormatField, DateFormatLiteral, DateFormatPart

if TYPE_CHECKING:
    from .artifacts import SemiNaiveLoop, StoreColumn, View
    from .emitter import SQLEmitter


# DuckDB strftime tokens for each Julia format field kind. Used by the default
# SQLBackend.emit_format_datetime / emit_parse_datetime implementations.
_DUCKDB_FORMAT_BY_KIND: dict[str, str] = {
    "year_2": "%y",
    "year_4": "%Y",
    "month_unpadded": "%-m",
    "month_padded": "%m",
    "day_unpadded": "%-d",
    "day_padded": "%d",
    "hour24_unpadded": "%-H",
    "hour24_padded": "%H",
    "minute_unpadded": "%-M",
    "minute_padded": "%M",
    "second_unpadded": "%-S",
    "second_padded": "%S",
    "millisecond": "%g",
    "weekday_abbr": "%a",
    "weekday_full": "%A",
    "month_abbr": "%b",
    "month_full": "%B",
    "tz_offset": "%z",
    "tz_name": "%Z",
    "hour12_unpadded": "%-I",
    "hour12_padded": "%I",
    "ampm": "%p",
}


def _join_duckdb_format(parts: list[DateFormatPart]) -> str:
    out: list[str] = []
    for p in parts:
        if isinstance(p, DateFormatLiteral):
            out.append(p.text.replace("%", "%%"))
        else:
            assert isinstance(p, DateFormatField)
            mapped = _DUCKDB_FORMAT_BY_KIND.get(p.kind)
            if mapped is None:
                raise ValueError(f"Unsupported datetime format token kind {p.kind!r}")
            out.append(mapped)
    return "".join(out)


class SQLBackend:

    # Per-dialect SQL function name overrides. Keys are canonical (DuckDB-style)
    # names used in the emitter; values are the dialect's spelling. Subclasses
    # override this to swap names without touching emitter call sites.
    _function_aliases: dict[str, str] = {}

    def __init__(self, database: str, schema_name: str):
        self._database = database
        # Normalize exactly once, at construction. Every consumer reads
        # ``self.schema_name`` thereafter — no caller should normalize again.
        self._schema_name = self.normalize_schema_name(schema_name)

    def function_name(self, canonical: str) -> str:
        """Return the dialect-specific name for a canonical SQL function."""
        return self._function_aliases.get(canonical, canonical)

    def emit_isoweekday(self, value_sql: str) -> str:
        """Extract ISO weekday (Mon=1..Sun=7) from a date/timestamp.

        DuckDB accepts ``DATE_PART('isodow', x)``. Snowflake rejects that
        unit name and exposes the same value via ``DAYOFWEEKISO(x)``.
        """
        return f"DATE_PART('isodow', {value_sql})"

    def emit_construct_timestamp_ms(
        self,
        *,
        year_sql: str,
        month_sql: str,
        day_sql: str,
        hour_sql: str,
        minute_sql: str,
        second_sql: str,
        millisecond_sql: str,
    ) -> str:
        """Construct a TIMESTAMP from integer year/month/day/hour/minute/second
        plus a millisecond component (0..999). Default uses DuckDB's
        ``MAKE_TIMESTAMP`` which accepts fractional seconds; dialects whose
        constructor takes integer seconds + a separate sub-second precision
        argument override this (Snowflake's ``TIMESTAMP_FROM_PARTS`` takes
        integer nanoseconds as a 7th argument)."""
        sec_with_fraction = (
            f"(CAST({second_sql} AS DOUBLE) + CAST({millisecond_sql} AS DOUBLE) / 1000.0)"
        )
        return (
            "MAKE_TIMESTAMP("
            f"CAST({year_sql} AS BIGINT), "
            f"CAST({month_sql} AS BIGINT), "
            f"CAST({day_sql} AS BIGINT), "
            f"CAST({hour_sql} AS BIGINT), "
            f"CAST({minute_sql} AS BIGINT), "
            f"{sec_with_fraction})"
        )

    def emit_date_arithmetic(
        self,
        *,
        base_sql: str,
        signed_value_sql: str,
        unit: str,
    ) -> str:
        """Return SQL for ``base ± n * 1 unit`` date/time arithmetic.

        ``signed_value_sql`` already carries the sign (``"n"`` for add or
        ``"-(n)"`` for subtract). Default uses DuckDB's ``base + n * INTERVAL 1 unit``
        form; dialects without that form (Snowflake) override with ``DATEADD``.
        Caller normalizes ``unit`` to one of NANOSECOND, MICROSECOND, MILLISECOND,
        SECOND, MINUTE, HOUR, DAY, WEEK, MONTH, YEAR.
        """
        if unit == "NANOSECOND":
            # ns → us: divide first, then add MICROSECOND interval.
            return f"({base_sql} + ({signed_value_sql}) * INTERVAL 1 MICROSECOND / 1000)"
        if unit == "MILLISECOND":
            # Split a large signed millisecond delta into days + remainder to
            # avoid overflowing DuckDB's INTERVAL representation.
            day_part = f"CAST(({signed_value_sql}) / 86400000 AS BIGINT)"
            ms_part = f"CAST(({signed_value_sql}) % 86400000 AS BIGINT)"
            return (
                f"({base_sql} + ({day_part}) * INTERVAL 1 DAY "
                f"+ ({ms_part}) * INTERVAL 1 MILLISECOND)"
            )
        return f"({base_sql} + ({signed_value_sql}) * INTERVAL 1 {unit})"

    #------------------------------------------------------
    # Date/time formatting & timezone conversion
    #------------------------------------------------------
    # Each backend owns the full SQL fragment for these operations because the
    # *shape* (not just the function name) differs across dialects: format
    # strings use different token grammars, and Snowflake's CONVERT_TIMEZONE
    # has different arity from DuckDB's TIMEZONE. Emitter-level shortcuts for
    # *semantic* edge cases (e.g. tz_name on a naive value) fire before these.

    def emit_format_datetime(
        self,
        value_sql: str,
        parts: list[DateFormatPart],
        *,
        value_kind: str,
    ) -> str:
        """Format a date/datetime value to a string per a parsed Julia format."""
        del value_kind
        fmt = _join_duckdb_format(parts)
        fmt_sql = "'" + fmt.replace("'", "''") + "'"
        return f"STRFTIME({value_sql}, {fmt_sql})"

    def emit_parse_datetime(
        self,
        value_sql: str,
        parts: list[DateFormatPart],
        *,
        target: str,
        has_tz: bool,
    ) -> str:
        """Parse a string into a date/datetime per a parsed Julia format."""
        fmt = _join_duckdb_format(parts)
        fmt_sql = "'" + fmt.replace("'", "''") + "'"
        parsed = f"STRPTIME({value_sql}, {fmt_sql})"
        if target == "date":
            return f"CAST({parsed} AS DATE)"
        if has_tz:
            return f"CAST({self.convert_tz_aware_to_utc(parsed)} AS TIMESTAMP)"
        return f"CAST({parsed} AS TIMESTAMP)"

    def convert_naive_utc_to_tz(self, value_sql: str, tz_sql: str) -> str:
        """Naive-UTC TIMESTAMP -> naive TIMESTAMP at *tz_sql*."""
        return f"TIMEZONE({tz_sql}, TIMEZONE('UTC', {value_sql}))"

    def convert_naive_tz_to_utc(self, value_sql: str, tz_sql: str) -> str:
        """Naive-in-*tz_sql* TIMESTAMP -> naive TIMESTAMP at UTC."""
        return f"TIMEZONE('UTC', TIMEZONE({tz_sql}, {value_sql}))"

    def convert_tz_aware_to_utc(self, value_sql: str) -> str:
        """TZ-aware TIMESTAMP -> naive TIMESTAMP at UTC."""
        return f"TIMEZONE('UTC', {value_sql})"

    def emit_range_table_function(
        self,
        start_sql: str,
        stop_sql: str,
        step_sql: str,
        value_col: str,
    ) -> str:
        """Return the SQL fragment for ``RANGE(start, stop, step)`` as a row source.

        The result is wrapped as ``(SELECT ... AS <value_col>)``-style subquery
        ready to drop into a FROM clause. Default emits DuckDB's native
        ``RANGE(...)`` table function; dialects without it (Snowflake) override.
        Semantics: emit rows ``start, start+step, start+2*step, ...`` while the
        value is strictly less than ``stop`` (Python ``range`` semantics; empty
        when ``start >= stop`` for positive ``step``).
        """
        col = '"' + value_col.replace('"', '""') + '"'
        return f"(\nSELECT * FROM RANGE({start_sql}, {stop_sql}, {step_sql}) AS table_fn({col})\n)"

    def emit_range_array_expr(
        self,
        start_sql: str,
        stop_sql: str,
        step_sql: str,
    ) -> str:
        """Return an array-typed scalar expression containing
        ``start, start+step, ...`` while strictly less than ``stop`` (Python
        ``range`` semantics; empty when ``start >= stop`` for positive step).
        Used by the per-row outer-materialization rewrite for ``range``: the
        array is projected as a column in a wrapper subquery and then expanded
        by ``emit_array_column_unnest_source`` — a shape Snowflake's optimizer
        accepts because the unnest input is a column reference, not a
        correlated function call. Default uses DuckDB's scalar ``range(...)``
        returning ``LIST<BIGINT>``; Snowflake overrides with
        ``ARRAY_GENERATE_RANGE``.
        """
        return f"range({start_sql}, {stop_sql}, {step_sql})"

    def emit_array_column_unnest_source(self, col_sql: str, value_col: str) -> str:
        """Return the bare table-function call that expands an array-typed
        column reference into one row per element. The emitter joins this via
        comma-LATERAL with an explicit column alias clause; never wrap in an
        outer SELECT (Snowflake rejects nested ``LATERAL FLATTEN`` inside a
        ``LEFT JOIN LATERAL ... ON`` shape). Default emits DuckDB's
        ``UNNEST(col)``; Snowflake overrides with ``FLATTEN(input => col)``.
        """
        return f"UNNEST({col_sql})"

    def format_array_column_unnest_alias(self, alias_q: str, value_col_q: str) -> str:
        """Return the ``AS <alias>(<cols>)`` column-aliasing clause for the
        column-ref unnest source. Default exposes a single column named
        ``value_col`` (matches DuckDB's UNNEST output). Snowflake overrides
        to alias the full FLATTEN row (SEQ, KEY, PATH, INDEX, VALUE, THIS)
        so the caller's quoted-lowercase reference resolves to the VALUE
        column."""
        return f"AS {alias_q}({value_col_q})"

    def emit_regex_match(self, string_sql: str, pattern_sql: str) -> str:
        """Return SQL for ``regex_match(string, pattern)`` with *partial-match*
        semantics (matches anywhere in the string).

        Default emits DuckDB's ``REGEXP_MATCHES(string, pattern)``. Snowflake
        overrides — ``REGEXP_MATCHES`` is unknown there, and its native
        ``REGEXP_LIKE`` requires a full-string match, so the SF override uses
        ``REGEXP_INSTR`` to preserve partial-match semantics.
        """
        return f"REGEXP_MATCHES({string_sql}, {pattern_sql})"

    def emit_split_to_table(
        self,
        string_sql: str,
        sep_sql: str,
        value_col: str,
        index_col: str,
    ) -> str:
        """Return the SQL fragment for ``split(string, sep)`` as a row source
        with one row per piece, exposing the piece value and its 0-based index.

        Default emits DuckDB's ``UNNEST(STRING_SPLIT(...)) WITH ORDINALITY``.
        Snowflake overrides — its parser rejects ``STRING_SPLIT(...)`` and
        instead provides the ``SPLIT_TO_TABLE`` table function.
        """
        value_q = '"' + value_col.replace('"', '""') + '"'
        index_q = '"' + index_col.replace('"', '""') + '"'
        return (
            "(\nSELECT "
            f"value AS {value_q}, (ord - 1) AS {index_q} "
            f"FROM UNNEST(STRING_SPLIT({string_sql}, {sep_sql})) "
            "WITH ORDINALITY AS table_fn(value, ord)\n)"
        )

    @property
    def database(self) -> str:
        """ Return the name of the database/catalog that this backend is connected to. """
        return self._database

    @property
    def schema_name(self) -> str:
        """The canonical (normalized) schema in which this backend's install artifacts live."""
        return self._schema_name

    @property
    def meta_schema(self) -> str:
        """Schema holding RAI metadata (procedures, plan table, refresh log)."""
        from .orchestrator import META_SCHEMA_SUFFIX
        return f"{self._schema_name}{META_SCHEMA_SUFFIX}"

    #------------------------------------------------------
    # Dialect handling
    #------------------------------------------------------
    def dialect_name(self) -> str:
        raise NotImplementedError

    def normalize_schema_name(self, name) -> str:
        return name

    def normalize_column_name(self, name: str) -> str:
        if name.startswith('"') and name.endswith('"'):
            return name[1:-1]
        return name

    def format_table_name(self, name: str) -> str:
        return name

    def quote_table_name(self, name: str) -> str:
        # Quote each path component so reserved-word table names (e.g. 'Order',
        # 'Any') don't lex as SQL keywords on stricter dialects (Snowflake).
        return self.quote_path(name)

    def quote_identifier(self, name: str) -> str:
        escaped = name.replace('"', '""')
        return f'"{escaped}"'

    def quote_path(self, path: str) -> str:
        return ".".join(self.quote_identifier(part) for part in path.split("."))

    def materialize_install_views_as_tables(self) -> bool:
        """Return True to emit install-time views as CREATE TABLE instead of CREATE VIEW."""
        return False

    def emit_install_ddl(self, view: "View", query_sql: str) -> str | None:
        """DDL run once at install time. ``None`` means nothing to install
        separately — population happens via :meth:`emit_refresh_sql`.

        Default: nothing to install separately; the refresh statement does
        all the work (DuckDB-shaped).
        """
        return None

    def emit_refresh_sql(self, view: "View", query_sql: str) -> str | None:
        """SQL run on every refresh. ``None`` means nothing to do at refresh.

        Default: a single ``CREATE OR REPLACE TABLE/VIEW … AS <body>`` that
        both initializes and populates the output (DuckDB-shaped).
        """
        ddl = "TABLE" if self.materialize_install_views_as_tables() else "VIEW"
        return f"CREATE OR REPLACE {ddl} {self.quote_table_name(view.name)} AS\n{query_sql}"

    def install_table_ddl(
        self, table_name: str, columns: "Sequence[StoreColumn]"
    ) -> str:
        """Return DDL that creates an empty table with the given typed columns.

        Used at async-install time to materialize empty output tables before any
        upstream dynamic table has been refreshed — so the DDL must be
        independent of any source-table state.
        """
        parts = []
        for c in columns:
            if c.sql_type is None:
                raise ValueError(f"No SQL type for column {c.name!r} in {table_name}")
            parts.append(f"{self.quote_identifier(c.name)} {c.sql_type}")
        col_defs = ", ".join(parts)
        return f"CREATE OR REPLACE TABLE {self.quote_table_name(table_name)} ({col_defs})"

    #------------------------------------------------------
    # Metadata fetching
    #------------------------------------------------------

    def fetch_schema(self, database: str, schema: str, table: str) -> dict[str, type | str]:
        """ Fetch information about the columns of the given table. Return a dict mapping
        column names to their types.
        Note that the database queried here is not necessarily the same as that this backend
        is connected to (which is returned by the `database` property)
        """
        raise NotImplementedError

    #------------------------------------------------------
    # SQL execution
    #------------------------------------------------------

    def execute_sql(self, sql: str) -> DataFrame:
        raise NotImplementedError

    def execute_sql_batch(self, statements: list[str]) -> None:
        raise NotImplementedError

    #------------------------------------------------------
    # Semi-naive execution
    #------------------------------------------------------

    def build_semi_naive_plan(self, loop: "SemiNaiveLoop", emitter: "SQLEmitter") -> object:
        """Emit a dialect-specific plan object which specifies how to execute a semi-naive
        loop."""
        raise NotImplementedError(
            f"build_semi_naive_plan is not supported for dialect '{self.dialect_name()}'."
        )

    def execute_semi_naive(self, plan: object) -> None:
        """Execute a pre-built semi-naive plan."""
        raise NotImplementedError(
            f"execute_semi_naive is not supported for dialect '{self.dialect_name()}'."
        )
