CREATE OR REPLACE PROCEDURE {proc_name}(interval_seconds INTEGER)
RETURNS STRING
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
  c1 CURSOR FOR
    SELECT ENTRY_ID, TARGET_TABLE_NAMES, BLOCK_INDEX, SQL_STATEMENTS FROM {meta_schema}.PLAN
    WHERE (? = -1 OR REFRESH_INTERVAL_SECONDS = ?)
    ORDER BY ENTRY_ID;
  v_entry_id INTEGER;
  v_target_tables VARCHAR;
  v_block_index INTEGER;
  v_start TIMESTAMP_LTZ;
  v_end TIMESTAMP_LTZ;
  v_err VARCHAR;
  v_run_id INTEGER := 0;
  v_run0_complete INTEGER DEFAULT 0;
  v_run0_started INTEGER DEFAULT 0;
  v_fingerprint VARCHAR DEFAULT NULL;
  v_run_started BOOLEAN DEFAULT FALSE;
  manual_full_refresh_not_allowed EXCEPTION (-20001, 'Manual full-model refresh is not supported after the initial install. Re-install the model to trigger a fresh full-model refresh.');
BEGIN
  ALTER SESSION SET STATEMENT_TIMEOUT_IN_SECONDS = 0;
  v_start := CURRENT_TIMESTAMP();

  -- Read fingerprint from the install sentinel written by the client before triggering the task.
  SELECT fingerprint INTO :v_fingerprint
  FROM {meta_schema}.REFRESH_LOG
  WHERE run_id = 0
    AND entry_type = 'RUN_PREPARED'
  ORDER BY log_id DESC
  LIMIT 1;

  -- Check whether the initial install (run_id=0) has already completed.
  SELECT COUNT(*) INTO :v_run0_complete
  FROM {meta_schema}.REFRESH_LOG
  WHERE run_id = 0 AND entry_type = 'RUN_COMPLETE';

  -- Check whether the initial install (run_id=0) has already been claimed by a running task.
  SELECT COUNT(*) INTO :v_run0_started
  FROM {meta_schema}.REFRESH_LOG
  WHERE run_id = 0 AND entry_type = 'RUN_STARTED';

  -- nothing else should run while the initial install task is running
  -- TODO: known recovery hole — if a prior FULL_MODEL_REFRESH_TASK invocation wrote
  -- RUN_STARTED and then died before its EXCEPTION handler could write RUN_COMPLETE
  -- (e.g. task killed by Snowflake), this guard blocks every subsequent invocation.
  -- A new install will also short-circuit on the Python side: finalize() reads the
  -- orphan RUN_STARTED as MATCHING_INSTALL_IN_PROGRESS and never re-triggers, so the
  -- caller polls until the timeout. Recovery currently requires manual cleanup
  -- of REFRESH_LOG.
  IF (v_run0_started > 0 and v_run0_complete = 0) THEN
    RETURN 'Skipped: initial install (run_id=0) not yet complete';
  END IF;

  -- get run id
  IF (v_run0_started = 0) THEN
    v_run_id := 0;
  ELSE
    SELECT COALESCE(MAX(run_id), 0) + 1 INTO :v_run_id
    FROM {meta_schema}.REFRESH_LOG;
  END IF;

  -- Full-model refresh (interval_seconds < 0) is reserved for the initial install (run_id=0).
  -- Manually re-triggering it after install is not supported.
  IF (interval_seconds < 0 AND v_run_id != 0) THEN
    RAISE manual_full_refresh_not_allowed;
  END IF;

  -- Log run start; for run_id=0 this transitions RUN_PREPARED → RUN_STARTED and claims ownership.
  INSERT INTO {meta_schema}.REFRESH_LOG
    (run_id, entry_type, target_table_names, interval_seconds, fingerprint, run_start_time, state)
    VALUES (:v_run_id, 'RUN_STARTED', NULL, :interval_seconds, :v_fingerprint, :v_start, 'RUNNING');
  v_run_started := TRUE;

  OPEN c1 USING (interval_seconds, interval_seconds);
  FOR rec IN c1 DO
    v_entry_id := rec.ENTRY_ID;
    v_target_tables := rec.TARGET_TABLE_NAMES;
    v_block_index := rec.BLOCK_INDEX;
    v_start := CURRENT_TIMESTAMP();

    BEGIN
      -- Add a log entry to indicate running state
      INSERT INTO {meta_schema}.REFRESH_LOG
        (run_id, entry_type, target_table_names, block_index, interval_seconds, fingerprint, run_start_time, run_end_time, state, error_message)
        VALUES (:v_run_id, 'BLOCK', :v_target_tables, :v_block_index, :interval_seconds, :v_fingerprint, :v_start, NULL, 'RUNNING', NULL);

      -- Execute the plan step (wrap in BEGIN...END so multiple statements
      -- separated by semicolons within SQL_STATEMENTS run as one scripting block)
      EXECUTE IMMEDIATE 'BEGIN\n' || rec.SQL_STATEMENTS || '\nEND;';
      v_end := CURRENT_TIMESTAMP();

      -- Add a log entry on success
      INSERT INTO {meta_schema}.REFRESH_LOG
        (run_id, entry_type, target_table_names, block_index, interval_seconds, fingerprint, run_start_time, run_end_time, state, error_message)
        VALUES (:v_run_id, 'BLOCK', :v_target_tables, :v_block_index, :interval_seconds, :v_fingerprint, :v_start, :v_end, 'SUCCESS', NULL);

    -- In case of a failure add a log entry
    EXCEPTION
      WHEN OTHER THEN
        v_err := SQLERRM;
        v_end := CURRENT_TIMESTAMP();
        INSERT INTO {meta_schema}.REFRESH_LOG
          (run_id, entry_type, target_table_names, block_index, interval_seconds, fingerprint, run_start_time, run_end_time, state, error_message)
          VALUES (:v_run_id, 'BLOCK', :v_target_tables, :v_block_index, :interval_seconds, :v_fingerprint, :v_start, :v_end, 'FAILURE', :v_err);
        RAISE;
    END;
  END FOR;

  -- Mark run complete once all blocks have finished successfully.
  IF (v_fingerprint IS NOT NULL) THEN
    INSERT INTO {meta_schema}.REFRESH_LOG
      (run_id, entry_type, target_table_names, interval_seconds, fingerprint, run_start_time, run_end_time, state)
      VALUES (:v_run_id, 'RUN_COMPLETE', NULL, :interval_seconds, :v_fingerprint, :v_start, CURRENT_TIMESTAMP(), 'SUCCESS');
  END IF;

  RETURN 'Refresh complete';

EXCEPTION
  WHEN OTHER THEN
    -- On failure, write COMPLETE/FAILURE so waiters can surface the error.
    -- Only write if RUN_STARTED was committed; otherwise there is no run to close out.
    v_err := SQLERRM;
    IF (v_run_started AND v_fingerprint IS NOT NULL) THEN
      INSERT INTO {meta_schema}.REFRESH_LOG
        (run_id, entry_type, target_table_names, interval_seconds, fingerprint, run_start_time, run_end_time, state, error_message)
        VALUES (:v_run_id, 'RUN_COMPLETE', NULL, :interval_seconds, :v_fingerprint, :v_start, CURRENT_TIMESTAMP(), 'FAILURE', LEFT(:v_err, 1000));
    END IF;
    RAISE;
END;
$$
