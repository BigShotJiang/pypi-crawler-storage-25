"""SQL IR-level optimizations for the sql backend.

Optimizations applied after lowering, before emitting:

  Plan-level passes (applied once per execution step):
    SingleConsumerInline    — Inline views that are consumed by exactly one other view

  View-level passes (applied bottom-up inside each view's query, iterated to fixpoint):
    SingleBranchUnionElim   — Remove double-paren wrapper from a single-branch UNION ALL
    UnionToValuesLift       — Singleton UNION ALL of same-structure branches → single SELECT over VALUES
    AggSubqueryFlatten      — Push MAX through a pure-projection subquery into the subquery itself
    ProjectOverAggregateFold — Inline a pure projection on top of an aggregating subquery into it
    SingletonFromLift       — Eliminate FROM (SELECT 1) when the singleton contributes no columns
    DecorrelateLateral      — Rewrite LEFT JOIN LATERAL (correlated subquery) into non-lateral forms
    DeadLeftJoinElim        — Drop LEFT JOINs whose alias is never referenced anywhere in the query
    DeadSubqueryColumnPrune — Remove SELECT items from subqueries that the outer query never references
    DistinctBeforeGroupByElim — Drop DISTINCT from an inner subquery consumed by an outer GROUP BY with no aggregates
    DoubleNegElim+TrivialConditionElim — Eliminate NOT(NOT(x)), drop trivially-true IS NOT NULL guards,
                              and drop WHERE/JOIN ON conditions that are always TRUE (SQLLiteral(True))
    JoinImpliedNullGuardElim — Drop IS NOT NULL WHERE guards already implied by a JOIN equi-condition
    RedundantCastElim       — Drop CAST(expr AS T) when expr already has type T
    RedundantDistinctElim   — Drop SELECT DISTINCT when uniqueness is already guaranteed (VALUES rows, UNION source, GROUP BY, or entity-store _id)
    DistinctWrapperElim     — Inline a pass-through SELECT DISTINCT wrapper into its inner subquery
"""
from __future__ import annotations

import re

from .artifacts import ExecutionPlan, SQLExecutionStep, SemiNaiveLoop, SemiNaiveTable, View
from . import name_scheme
from .sql_ir import (
    SQLBinaryOp,
    SQLCast,
    SQLColumnRef,
    SQLConcat,
    SQLExpr,
    SQLFromItem,
    SQLFunctionCall,
    SQLIsNotNull,
    SQLJoin,
    SQLLiteral,
    SQLNot,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSingletonSource,
    SQLSource,
    SQLSubquerySource,
    SQLTableFunctionSource,
    SQLTableSource,
    SQLTryCast,
    SQLUnionQuery,
    SQLValuesSource,
)
from .sql_ir_traversal import (
    fold,
    node_is_closed,
    substitute_outer_with_inner_in_expr,
    transform,
    try_transform,
)


# SQL reserved keywords that are unsafe to use as unquoted column names in VALUES clauses.
_SQL_RESERVED_KEYWORDS: frozenset[str] = frozenset({
    "all", "alter", "and", "any", "as", "asc", "between", "by", "case",
    "check", "constraint", "create", "cross", "current", "default", "delete",
    "desc", "distinct", "drop", "else", "end", "except", "exists", "false",
    "first", "following", "foreign", "from", "full", "group", "having",
    "in", "index", "inner", "insert", "intersect", "into", "is", "join",
    "key", "last", "left", "like", "limit", "natural", "not", "null",
    "offset", "on", "or", "order", "outer", "over", "partition", "preceding",
    "primary", "range", "references", "right", "row", "rows", "select",
    "set", "some", "table", "then", "true", "unbounded", "union", "unique",
    "update", "using", "values", "view", "when", "where", "window", "with",
})


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


class SQLOptimizer:
    """SQL IR-level optimization pass; runs after lowering, before emitting.

    Set ``enabled = False`` (or the env var ``PYREL__OPTIMIZER=0``) to
    bypass all optimizations and emit raw lowered SQL.
    """

    enabled: bool = True

    def __init__(self) -> None:
        import os
        env = os.environ.get("PYREL__OPTIMIZER", "").strip()
        if env == "0":
            self.enabled = False

    def optimize_query(self, query: SQLQuery) -> SQLQuery:
        """Apply view-level optimizations to a fragment query, iterated to
        fixpoint so a pass whose output exposes new opportunities for the same
        or another pass is applied as many times as needed."""
        if not self.enabled:
            return query
        for _ in range(50):
            prev = query
            query = _apply_query_opts(query)
            if query is prev:
                return query
        return query

    def optimize_plan(self, plan: ExecutionPlan) -> ExecutionPlan:
        if not self.enabled:
            return plan
        # For each step, collect view names that are referenced from outside it.
        external_refs_per_step = _compute_external_refs(plan)
        return ExecutionPlan(
            steps=tuple(
                _optimize_step(step, external_refs) if isinstance(step, SQLExecutionStep) else step
                for step, external_refs in zip(plan.steps, external_refs_per_step)
            )
        )


# ---------------------------------------------------------------------------
# Program-level driver
# ---------------------------------------------------------------------------


def _optimize_semi_naive_table(t: SemiNaiveTable) -> SemiNaiveTable:
    """Apply query optimizations to every query of a SemiNaiveTable."""
    return SemiNaiveTable(
        table_name=t.table_name,
        columns=t.columns,
        base_query=_apply_query_opts(t.base_query),
        delta_query=_apply_query_opts(t.delta_query),
        merge_query=_apply_query_opts(t.merge_query),
        next_delta_query=_apply_query_opts(t.next_delta_query),
        final_query=_apply_query_opts(t.final_query),
        accum_view_name=t.accum_view_name,
        delta_view_name=t.delta_view_name,
        next_accum_view_name=t.next_accum_view_name,
        next_delta_view_name=t.next_delta_view_name,
        column_types=t.column_types,
    )


def _optimize_step(
    step: SQLExecutionStep, external_refs: set[str]
) -> SQLExecutionStep:
    """Apply all optimizer passes to a single execution step until no further changes."""
    views = list(step.views)
    # Belt-and-suspenders: cap fixpoint iterations so that any future
    # not-yet-stable optimizer pass can't silently spin forever. The
    # bound is generous; reaching it indicates a real bug to fix.
    _MAX_OPT_ITERATIONS = 50
    for _ in range(_MAX_OPT_ITERATIONS):
        prev = views

        # UnionToValuesLift, AggSubqueryFlatten, ProjectOverAggregateFold, etc.: applied bottom-up inside each view's query
        views = [View(name=v.name, query=_apply_query_opts(v.query), column_types=v.column_types) for v in views]

        # SingleConsumerInline: inline single-consumer views
        views = _inline_single_consumer_views(views, external_refs)

        if views == prev:
            break
    else:
        import warnings
        warnings.warn(
            f"SQL optimizer did not reach a fixpoint after {_MAX_OPT_ITERATIONS} "
            f"iterations on step views={[v.name for v in views]}. Emitting last-iteration "
            f"output. This indicates a non-converging pass and should be filed.",
            stacklevel=2,
        )

    semi_naive_loops = tuple(
        SemiNaiveLoop(tables=tuple(_optimize_semi_naive_table(t) for t in loop.tables))
        for loop in step.semi_naive_loops
    )
    return SQLExecutionStep(views=tuple(views), semi_naive_loops=semi_naive_loops)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# RedundantDistinctElim — Drop redundant DISTINCT when inner subquery GROUP BY guarantees uniqueness
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Uniqueness oracle — _id semantic guarantees
# ---------------------------------------------------------------------------

# Entity-store views are named <TypeName>_t<id> (no "rel_" prefix, ends _t<digits>).
# Relation stores are named rel_<name>_<Type>_<Type>.
# The _id column is a reserved name for entity identity: always an MD5 hash, always non-null,
# and guaranteed unique within any entity-store view (deduped by GROUP BY "_id" at write time).
_ENTITY_TABLE_RE = re.compile(r"(?:.*\.)?[A-Za-z]\w*_t\d+$")


def _is_entity_store_table(name: str) -> bool:
    """Return True if name is an entity-store table (TypeName_tNNN pattern).

    Entity stores have a unique, non-null _id column. Relation stores use the
    rel_<name>_<Type>_<Type> naming convention and are excluded.
    """
    return bool(_ENTITY_TABLE_RE.match(name))


def _source_has_unique_id(source: SQLSource) -> bool:
    """Return True if source guarantees that its _id column values are unique.

    Two cases:
    - A direct entity-store table reference (_id is the deduplication key).
    - A subquery whose own GROUP BY includes "_id" (the group key is unique).
    """
    if isinstance(source, SQLTableSource):
        return _is_entity_store_table(source.name)
    if isinstance(source, SQLSubquerySource):
        q = source.query
        if isinstance(q, SQLSelectQuery):
            return any(
                isinstance(g, SQLColumnRef) and g.column_name == "_id"
                for g in q.group_by
            )
    return False


def _columns_are_unique(query: SQLSelectQuery) -> bool:
    """Return True if the query's SELECT output is guaranteed to contain unique rows.

    Three cases:

    1. GROUP BY on non-constant keys when every SELECT item is a group key or
       aggregate — GROUP BY already produces one row per unique key combination.

    2. _id from an entity-store source with only LEFT JOINs — entity stores
       guarantee unique _id, and LEFT JOINs never multiply the left-hand rows.

    3. _id from a subquery that itself groups by _id (same argument as case 2
       but the uniqueness comes from the subquery's own GROUP BY).
    """
    # Case 1: GROUP BY uniqueness (mirrors RedundantDistinctElim Case 2)
    if query.group_by and not all(isinstance(g, SQLLiteral) for g in query.group_by):
        if all(
            any(item.expr == g for g in query.group_by) or _is_aggregate_expr(item.expr)
            for item in query.select
        ):
            return True

    # Cases 2 & 3: _id from a unique source, no row-multiplying joins
    id_aliases: set[str | None] = {
        item.expr.table_alias
        for item in query.select
        if isinstance(item.expr, SQLColumnRef) and item.expr.column_name == "_id"
    }
    if not id_aliases:
        return False

    # Build alias → source map for FROM + all JOINs
    alias_to_source: dict[str | None, SQLSource] = {}
    if query.from_item is not None:
        alias_to_source[query.from_item.alias] = query.from_item.source
    for j in query.joins:
        alias_to_source[j.alias] = j.source

    # At least one _id alias must point to a source with guaranteed unique _id
    entity_id_aliases = {
        alias
        for alias in id_aliases
        if alias in alias_to_source and _source_has_unique_id(alias_to_source[alias])
    }
    if not entity_id_aliases:
        return False

    # The FROM item must itself be the entity source (or a subquery we trust).
    # If FROM is a different table, it acts as an implicit INNER JOIN that can
    # multiply rows for each entity row.
    if query.from_item is not None and query.from_item.alias not in entity_id_aliases:
        return False

    # Every join that is not one of our unique-id sources must be a LEFT JOIN
    # (LEFT JOINs never multiply left-hand rows; INNER JOINs may).
    for j in query.joins:
        if j.alias in entity_id_aliases:
            continue
        if "LEFT" not in j.kind.upper():
            return False

    return True


# ---------------------------------------------------------------------------
# Aggregate helper
# ---------------------------------------------------------------------------

_AGGREGATE_FUNCTION_NAMES = frozenset({"COUNT", "SUM", "AVG", "MIN", "MAX"})


def _is_aggregate_expr(expr: SQLExpr) -> bool:
    """Return True if expr is an aggregate function call, possibly wrapped in CAST/TRY_CAST."""
    while isinstance(expr, (SQLCast, SQLTryCast)):
        expr = expr.expr
    return isinstance(expr, SQLFunctionCall) and expr.name.upper() in _AGGREGATE_FUNCTION_NAMES


def _drop_redundant_distinct(query: SQLQuery) -> SQLQuery:
    """RedundantDistinctElim: Remove DISTINCT when row uniqueness is already guaranteed.

    Case 1 — FROM is a VALUES source whose rows are all syntactically distinct:
      Each SELECT expression (MD5, CAST, etc.) produces a unique output row,
      so DISTINCT is a no-op. Only fires with no JOINs, WHERE, or GROUP BY.

    Case 2 — FROM is a UNION (not UNION ALL) subquery, full pass-through projection:
      UNION already deduplicates. An outer DISTINCT over a full column-ref pass-through
      adds nothing. All outer SELECT items must be column refs and the outer must select
      all columns of the inner.

    Case 3 — DISTINCT with no own GROUP BY, FROM subquery has GROUP BY all-constants:
      GROUP BY on a constant collapses all rows into one group (at most one output row),
      so DISTINCT on that one row is always a no-op.

    Case 4 — DISTINCT on a query that itself has GROUP BY on non-constant keys:
      GROUP BY guarantees exactly one row per unique combination of group-key values.
      When every projected column is either a GROUP BY expression or an aggregate
      function call (possibly CAST-wrapped), the output is already unique per group,
      so DISTINCT is redundant.

    Case 5 — DISTINCT on a query whose SELECT includes _id from an entity-store source
      with only LEFT JOINs:
      Entity stores guarantee unique _id; LEFT JOINs never multiply left-hand rows,
      so the output rows are already unique on _id and therefore overall.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.distinct:
        return query

    # Case 1: VALUES source with all-unique rows
    if not query.joins and not query.where and not query.group_by:
        if query.from_item is not None and isinstance(query.from_item.source, SQLValuesSource):
            rows = query.from_item.source.rows
            if len(rows) == len(set(rows)):
                return SQLSelectQuery(
                    from_item=query.from_item, joins=query.joins, where=query.where,
                    select=query.select, group_by=query.group_by, order_by=query.order_by,
                    distinct=False, limit=query.limit,
                )

    # Case 2: full pass-through over a UNION subquery
    if not query.group_by and not query.where and not query.joins and query.from_item is not None:
        if isinstance(query.from_item.source, SQLSubquerySource):
            inner = query.from_item.source.query
            if isinstance(inner, SQLUnionQuery) and inner.operator == "UNION":
                outer_alias = query.from_item.alias
                all_col_refs = all(
                    isinstance(item.expr, SQLColumnRef) and
                    (item.expr.table_alias is None or item.expr.table_alias == outer_alias)
                    for item in query.select
                )
                first_branch = inner.queries[0]
                if (all_col_refs and isinstance(first_branch, SQLSelectQuery)
                        and len(query.select) == len(first_branch.select)):
                    return SQLSelectQuery(
                        from_item=query.from_item, joins=query.joins, where=query.where,
                        select=query.select, group_by=query.group_by, order_by=query.order_by,
                        distinct=False, limit=query.limit,
                    )

    # Case 3: no own GROUP BY; FROM subquery groups by all-constants
    if not query.group_by and not query.joins and not query.where:
        if query.from_item is not None and isinstance(query.from_item.source, SQLSubquerySource):
            inner = query.from_item.source.query
            if isinstance(inner, SQLSelectQuery) and inner.group_by:
                if all(isinstance(g, SQLLiteral) for g in inner.group_by):
                    return SQLSelectQuery(
                        from_item=query.from_item, joins=query.joins, where=query.where,
                        select=query.select, group_by=query.group_by, order_by=query.order_by,
                        distinct=False, limit=query.limit,
                    )

    # Cases 4 & 5: delegate to the uniqueness oracle
    if _columns_are_unique(query):
        return SQLSelectQuery(
            from_item=query.from_item, joins=query.joins, where=query.where,
            select=query.select, group_by=query.group_by, order_by=query.order_by,
            distinct=False, limit=query.limit,
        )

    return query


# ---------------------------------------------------------------------------
# JoinImpliedNullGuardElim — Drop IS NOT NULL guards made redundant by JOIN equi-conditions
# ---------------------------------------------------------------------------


def _drop_join_constrained_null_guards(query: SQLQuery) -> SQLQuery:
    """JoinImpliedNullGuardElim: Remove WHERE `col IS NOT NULL` conditions that are already implied
    by a JOIN equi-condition on the same column.

    A JOIN ON (a.x = b.y) guarantees both sides are non-NULL (NULL fails =),
    so any `IS NOT NULL(a.x)` or `IS NOT NULL(b.y)` in WHERE is redundant.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.where or not query.joins:
        return query

    # Collect (table_alias, column_name) pairs from JOIN equi-conditions
    join_eq_cols: set[tuple[str | None, str]] = set()
    for j in query.joins:
        for cond in j.conditions:
            if isinstance(cond, SQLBinaryOp) and cond.operator == "=":
                for side in (cond.left, cond.right):
                    if isinstance(side, SQLColumnRef):
                        join_eq_cols.add((side.table_alias, side.column_name))

    if not join_eq_cols:
        return query

    def _redundant(expr: SQLExpr) -> bool:
        if isinstance(expr, SQLIsNotNull) and isinstance(expr.expr, SQLColumnRef):
            col = expr.expr
            return (col.table_alias, col.column_name) in join_eq_cols
        return False

    new_where = tuple(c for c in query.where if not _redundant(c))
    if new_where == query.where:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=query.joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# DistinctWrapperElim — Inline redundant pass-through SELECT DISTINCT wrapper
# ---------------------------------------------------------------------------


def _inline_passthrough_wrapper(query: SQLQuery) -> SQLQuery:
    """DistinctWrapperElim: Remove an outer SELECT DISTINCT that is a pure pass-through over an
    inner SQLSelectQuery subquery.

    Pattern:
        SELECT DISTINCT merged."c1" AS "c1", merged."c2" AS "c2", ...
        FROM (inner_select) AS merged

    When:
      - No JOINs, WHERE, GROUP BY, ORDER BY, LIMIT on the outer query
      - All SELECT items are SQLColumnRef(name) AS name  (identity projections)
      - The inner query is a SQLSelectQuery

    Action: return inner_select with distinct=True, discarding the wrapper.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if (
        query.joins
        or query.where
        or query.group_by
        or query.order_by
        or query.limit is not None
        or not query.distinct
        or query.from_item is None
    ):
        return query
    if not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query

    # Verify every outer SELECT item is an identity column ref
    outer_alias = query.from_item.alias
    for item in query.select:
        if not isinstance(item.expr, SQLColumnRef):
            return query
        col = item.expr
        # Must reference the subquery alias (or no alias) and match output alias
        if col.table_alias is not None and col.table_alias != outer_alias:
            return query
        expected_alias = item.alias if item.alias is not None else col.column_name
        if col.column_name != expected_alias:
            return query

    # Safe to inline: return inner with distinct forced on
    if inner.distinct:
        return inner
    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=inner.select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=True,
        limit=inner.limit,
    )


# ---------------------------------------------------------------------------
# UnionToValuesLift, AggSubqueryFlatten, ProjectOverAggregateFold — applied together via recursive bottom-up query walk
# ---------------------------------------------------------------------------


def _apply_local_query_opts(query: SQLQuery) -> SQLQuery:
    """Apply every optimization pass once at this query level. Children are
    handled by the caller's `transform` recursion."""
    query = _materialize_correlated_row_generator(query)  # RowGeneratorOuterMaterialize
    query = _unwrap_single_branch_union(query)         # SingleBranchUnionElim
    query = _singleton_union_to_values(query)          # UnionToValuesLift
    query = _aggregate_subquery_flatten(query)         # AggSubqueryFlatten
    query = _project_over_aggregate_fold(query)        # ProjectOverAggregateFold
    query = _lift_singleton_from(query)                # SingletonFromLift
    query = _unwrap_redundant_lateral(query)           # UnwrapRedundantLateral
    query = _reorder_lateral_joins(query)              # LateralJoinReorder
    query = _decorrelate_lateral(query)                # DecorrelateLateral
    query = _drop_redundant_lateral_keyword(query)     # RedundantLateralKeywordElim
    query = _drop_dead_left_joins(query)               # DeadLeftJoinElim
    query = _prune_dead_subquery_columns(query)        # DeadSubqueryColumnPrune
    query = _drop_distinct_before_group_by(query)      # DistinctBeforeGroupByElim
    query = _simplify_negations_in_query(query)        # DoubleNegElim+TrivialConditionElim
    query = _drop_join_constrained_null_guards(query)  # JoinImpliedNullGuardElim
    query = _simplify_casts_in_query(query)            # RedundantCastElim
    query = _drop_redundant_distinct(query)            # RedundantDistinctElim
    query = _inline_passthrough_wrapper(query)         # DistinctWrapperElim
    return query


def _apply_query_opts(query: SQLQuery) -> SQLQuery:
    """Apply every optimization pass post-order to `query` and every IR node
    reachable from it (sub-queries via FROM/JOIN sources, UNION branches, and
    EXISTS subquery bodies — the last of which the legacy `_map_subqueries`
    walker did not reach)."""
    return transform(query, query_fn=_apply_local_query_opts)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# SingleBranchUnionElim — Unwrap UNION ALL with a single branch
# ---------------------------------------------------------------------------


def _unwrap_single_branch_union(query: SQLQuery) -> SQLQuery:
    """SingleBranchUnionElim: Replace a UNION ALL (or UNION) with exactly one branch
    with the branch itself.

    A single-branch union is semantically identical to its sole member.
    Unwrapping it eliminates double-paren artifacts ((SELECT...)) that the
    printer emits when a SQLUnionQuery is nested inside a SQLSubquerySource,
    unblocking DistinctWrapperElim and RedundantDistinctElim Case 1.
    """
    if isinstance(query, SQLUnionQuery) and len(query.queries) == 1:
        return query.queries[0]
    return query


# ---------------------------------------------------------------------------
# UnionToValuesLift — Singleton UNION ALL → VALUES lift
# ---------------------------------------------------------------------------


def _singleton_union_to_values(query: SQLQuery) -> SQLQuery:
    """
    UnionToValuesLift: Replace a UNION ALL of singleton-source branches with a compact form
    by grouping structurally compatible branches into VALUES blocks.

    Branches that share identical expression structure (only literal values differ) are
    grouped together and lifted into a single SELECT over VALUES. Branches with different
    structures (e.g. different-arity MD5 concatenations from entities with different fields)
    form separate groups: groups of ≥2 are lifted, singletons are left as-is.

    The outer SELECT wrapper (including any GROUP BY / MAX) is preserved; only
    the inner union is replaced.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    fi = query.from_item
    if fi is None or not isinstance(fi.source, SQLSubquerySource):
        return query

    union = fi.source.query
    if not isinstance(union, SQLUnionQuery) or union.operator != "UNION ALL":
        return query
    if len(union.queries) < 2:
        return query

    branches = union.queries

    # Every branch must be a singleton-source SELECT with no JOIN / GROUP BY.
    # A WHERE clause is allowed only if every condition is a provably-always-true
    # NOT <non-null-expr> IS NULL guard (emitted by the lowerer for MD5 outputs).
    for b in branches:
        if not isinstance(b, SQLSelectQuery):
            return query
        if b.joins or b.group_by or b.distinct:
            return query
        if b.from_item is None or not isinstance(b.from_item.source, SQLSingletonSource):
            return query
        if b.where and not _all_trivially_true(b.where):
            return query

    # All branches must expose the same column aliases (same output schema)
    aliases = tuple(item.alias for item in branches[0].select) #type: ignore
    for b in branches[1:]:
        if tuple(item.alias for item in b.select) != aliases: #type: ignore
            return query

    # Group branches by structural compatibility (different-arity expressions form
    # separate groups; each group is lifted independently)
    groups = _group_singleton_branches(list(branches), aliases) #type: ignore

    result_parts: list[SQLQuery] = []
    any_lifted = False
    for group_indices in groups:
        group_branches = [branches[i] for i in group_indices]
        if len(group_indices) >= 2:
            lifted = _lift_branch_group_to_values(group_branches, aliases) #type: ignore
            if lifted is not None:
                result_parts.append(lifted)
                any_lifted = True
                continue
        result_parts.extend(group_branches)

    if not any_lifted:
        return query

    if len(result_parts) == 1:
        new_inner: SQLSource = SQLSubquerySource(result_parts[0])
    else:
        new_inner = SQLSubquerySource(
            SQLUnionQuery(queries=tuple(result_parts), operator="UNION ALL")
        )
    new_fi = SQLFromItem(source=new_inner, alias=fi.alias)
    return SQLSelectQuery(
        from_item=new_fi,
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _group_singleton_branches(
    branches: list[SQLSelectQuery], aliases: tuple[str | None, ...]
) -> list[list[int]]:
    """Group branch indices by structural expression compatibility.

    Two branches are compatible if their SELECT expressions can be anti-unified
    (same shape, only literal values differ). Uses the first branch in each group
    as the representative for compatibility checks.
    """
    groups: list[list[int]] = []
    for i, b in enumerate(branches):
        placed = False
        for g in groups:
            rep = branches[g[0]]
            compatible = all(
                _anti_unify_literals(
                    [rep.select[col_idx].expr, b.select[col_idx].expr], []
                ) is not None
                for col_idx in range(len(aliases))
            )
            if compatible:
                g.append(i)
                placed = True
                break
        if not placed:
            groups.append([i])
    return groups


def _lift_branch_group_to_values(
    branches: list[SQLSelectQuery], aliases: tuple[str | None, ...]
) -> SQLSelectQuery | None:
    """Anti-unify a group of compatible branches into a single SELECT-over-VALUES query.

    Returns None if anti-unification fails or produces no holes (all branches identical).
    """
    holes: list[list[object]] = []
    template_items: list[SQLSelectItem] = []
    for col_idx, alias in enumerate(aliases):
        col_exprs = [b.select[col_idx].expr for b in branches] #type: ignore
        template_expr = _anti_unify_literals(col_exprs, holes)
        if template_expr is None:
            return None
        template_items.append(SQLSelectItem(template_expr, alias=alias))

    if not holes:
        return None  # all branches identical — nothing to lift

    # Deduplicate holes: merge holes that carry identical value sequences
    canonical_idx = list(range(len(holes)))
    for i in range(1, len(holes)):
        for j in range(i):
            if holes[j] == holes[i]:
                canonical_idx[i] = j
                break
    seen_canonical: set[int] = set()
    kept_order: list[int] = []
    for i in range(len(holes)):
        ci = canonical_idx[i]
        if ci not in seen_canonical:
            seen_canonical.add(ci)
            kept_order.append(ci)
    final_idx = {orig: new for new, orig in enumerate(kept_order)}
    rename_map = {
        f"__p{i}": f"__p{final_idx[canonical_idx[i]]}"
        for i in range(len(holes))
    }
    if any(v != k for k, v in rename_map.items()):
        template_items = [
            SQLSelectItem(_rename_col_refs_batch(item.expr, rename_map), alias=item.alias)
            for item in template_items
        ]
    holes = [holes[i] for i in kept_order]

    # Semantic hole naming
    item_hole_sets = [_holes_in_expr(item.expr) for item in template_items]
    used_names: set[str] = set()
    hole_names_list: list[str] = []
    for i in range(len(holes)):
        candidates = [
            template_items[j].alias
            for j in range(len(template_items))
            if i in item_hole_sets[j]
            and len(item_hole_sets[j]) == 1
            and template_items[j].alias is not None
        ]
        if len(candidates) == 1 and candidates[0] not in used_names and candidates[0].lower() not in _SQL_RESERVED_KEYWORDS:  # type: ignore[union-attr]
            name = candidates[0]
        else:
            name = f"__p{i}"
        assert isinstance(name, str)
        hole_names_list.append(name)
        used_names.add(name)
    for i, new_name in enumerate(hole_names_list):
        old_name = f"__p{i}"
        if new_name != old_name:
            template_items = [
                SQLSelectItem(
                    _rename_col_ref_in_expr(item.expr, old_name, new_name),
                    alias=item.alias,
                )
                for item in template_items
            ]
    hole_names = tuple(hole_names_list)
    rows = tuple(
        tuple(SQLLiteral(holes[i][bi]) for i in range(len(holes)))
        for bi in range(len(branches))
    )
    return SQLSelectQuery(
        from_item=SQLFromItem(source=SQLValuesSource(column_names=hole_names, rows=rows), alias="t"),
        select=tuple(template_items),
    )


def _anti_unify_literals(
    exprs: list[SQLExpr], holes: list[list[object]]
) -> SQLExpr | None:
    """
    Anti-unify a list of expressions (one per branch) by extracting varying
    SQLLiteral nodes as holes.

    Returns a template expression where each hole is represented by
    SQLColumnRef("__p{i}"), or None if the expressions differ at a non-literal
    node (structurally incompatible).

    New holes are appended to `holes`; holes[i] is the list of per-branch
    literal values for placeholder __p{i}.
    """
    # Identical everywhere — no hole needed
    if all(e == exprs[0] for e in exprs):
        return exprs[0]

    first = exprs[0]

    # If first is SQLCast, normalize any SQLLiteral(None) entries (produced by R4)
    # to SQLCast(NULL, T) so they are structurally compatible.
    if isinstance(first, SQLCast):
        normalized: list[SQLCast] = []
        for e in exprs:
            if isinstance(e, SQLLiteral) and e.value is None:
                normalized.append(SQLCast(e, first.type_name))
            elif isinstance(e, SQLCast):
                normalized.append(e)
            else:
                return None
        if not all(e.type_name == first.type_name for e in normalized):
            return None
        inner = _anti_unify_literals([e.expr for e in normalized], holes)
        return None if inner is None else SQLCast(inner, first.type_name)

    # All must share the same concrete type to unify structurally
    if not all(type(e) is type(first) for e in exprs):
        return None

    if isinstance(first, SQLLiteral):
        values = [e.value for e in exprs]  # type: ignore[union-attr]
        # Bail if literal values have mixed Python types within the same column —
        # DuckDB cannot combine e.g. VARCHAR and INTEGER_LITERAL in a VALUES clause
        # without an explicit cast.  The original UNION branches may have had CASTs
        # that resolved this; preserving the UNION is safer.
        value_types = {type(v) for v in values if v is not None}
        if len(value_types) > 1:
            return None
        idx = len(holes)
        holes.append(values)
        return SQLColumnRef(f"__p{idx}")

    if isinstance(first, SQLTryCast):
        casts2: list[SQLTryCast] = exprs  # type: ignore[assignment]
        if not all(e.type_name == first.type_name for e in casts2):
            return None
        inner = _anti_unify_literals([e.expr for e in casts2], holes)
        return None if inner is None else SQLTryCast(inner, first.type_name)

    if isinstance(first, SQLFunctionCall):
        fns: list[SQLFunctionCall] = exprs  # type: ignore[assignment]
        if not all(
            e.name == first.name
            and len(e.args) == len(first.args)
            and e.sql_type == first.sql_type
            for e in fns
        ):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in fns], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLFunctionCall(first.name, tuple(new_args), first.sql_type)

    if isinstance(first, SQLConcat):
        concats: list[SQLConcat] = exprs  # type: ignore[assignment]
        if not all(len(e.args) == len(first.args) for e in concats):
            return None
        new_args = []
        for i in range(len(first.args)):
            arg = _anti_unify_literals([e.args[i] for e in concats], holes)
            if arg is None:
                return None
            new_args.append(arg)
        return SQLConcat(tuple(new_args))

    if isinstance(first, SQLBinaryOp):
        ops: list[SQLBinaryOp] = exprs  # type: ignore[assignment]
        if not all(e.operator == first.operator for e in ops):
            return None
        left = _anti_unify_literals([e.left for e in ops], holes)
        if left is None:
            return None
        right = _anti_unify_literals([e.right for e in ops], holes)
        return None if right is None else SQLBinaryOp(left, first.operator, right)

    if isinstance(first, SQLIsNotNull):
        nodes: list[SQLIsNotNull] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nodes], holes)
        return None if inner is None else SQLIsNotNull(inner)

    if isinstance(first, SQLNot):
        nots: list[SQLNot] = exprs  # type: ignore[assignment]
        inner = _anti_unify_literals([e.expr for e in nots], holes)
        return None if inner is None else SQLNot(inner)

    # Any other node type that isn't a literal and isn't handled above:
    # if all are equal we already returned above, so they must differ — can't unify
    return None


# ---------------------------------------------------------------------------
# UnionToValuesLift helpers — hole introspection and renaming
# ---------------------------------------------------------------------------


def _holes_in_expr(expr: SQLExpr) -> frozenset[int]:
    """Return the set of hole indices (__p{i}) referenced anywhere in expr."""
    def step(node: object, acc: set[int]) -> set[int]:
        if isinstance(node, SQLColumnRef):
            n = node.column_name
            if n.startswith("__p") and n[3:].isdigit():
                acc.add(int(n[3:]))
        return acc
    return frozenset(fold(expr, step, set()))


def _rename_col_refs_batch(expr: SQLExpr, rename_map: dict[str, str]) -> SQLExpr:
    """Rename multiple column refs in one pass using a name→name map."""
    def rewrite_expr(node: object) -> object:
        if isinstance(node, SQLColumnRef):
            new_name = rename_map.get(node.column_name)
            if new_name is not None:
                return SQLColumnRef(new_name, node.table_alias)
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _rename_col_ref_in_expr(expr: SQLExpr, old: str, new: str) -> SQLExpr:
    """Rename every SQLColumnRef(column_name=old) to SQLColumnRef(new) in expr."""
    def rewrite_expr(node: object) -> object:
        if isinstance(node, SQLColumnRef) and node.column_name == old:
            return SQLColumnRef(new, node.table_alias)
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# UnionToValuesLift helpers — trivially-true guard detection
# ---------------------------------------------------------------------------


# Base facts: SQL functions that always return a non-null value.
_NONNULL_FUNCTIONS: frozenset[str] = frozenset({"MD5"})

# Base facts: column names that are pipeline-guaranteed non-null.
# "_id" is always MD5(CONCAT(...)) — derivable with data-flow, asserted here as a domain fact.
_NONNULL_COLUMNS: frozenset[str] = frozenset({"_id"})


def _is_always_nonnull(expr: SQLExpr) -> bool:
    """Return True if expr can never evaluate to NULL at runtime.

    Base facts  (domain assertions, not derivable from each other at this level):
      SQLLiteral(v)          v is not None
      SQLFunctionCall(f)     f in _NONNULL_FUNCTIONS
      SQLColumnRef(col)      col in _NONNULL_COLUMNS

    Inference rules  (propagate non-nullability structurally):
      CAST/TRY_CAST(x)       non-null iff x is non-null
      SQLConcat(a, b, ...)   non-null iff every arg is non-null
    """
    if isinstance(expr, SQLLiteral):
        return expr.value is not None
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return _is_always_nonnull(expr.expr)
    if isinstance(expr, SQLFunctionCall):
        return expr.name in _NONNULL_FUNCTIONS
    if isinstance(expr, SQLConcat):
        return all(_is_always_nonnull(a) for a in expr.args)
    if isinstance(expr, SQLColumnRef):
        return expr.column_name in _NONNULL_COLUMNS
    return False


def _is_trivially_true_condition(expr: SQLExpr) -> bool:
    """Return True if a single WHERE/JOIN condition is always true and can be dropped.

    The lowerer emits `NOT x IS NULL` as SQLIsNotNull(x) in the IR — i.e.
    "x IS NOT NULL". This is trivially true whenever x is always non-null.
    SQLLiteral(True) (emitted as TRUE) is trivially true by definition.
    """
    if isinstance(expr, SQLLiteral) and expr.value is True:
        return True
    if isinstance(expr, SQLIsNotNull):
        return _is_always_nonnull(expr.expr)
    return False


def _all_trivially_true(conditions: tuple) -> bool:
    """Return True if every condition in a WHERE tuple is trivially always true."""
    return all(_is_trivially_true_condition(c) for c in conditions)


# ---------------------------------------------------------------------------
# DoubleNegElim — Double-negation elimination
# ---------------------------------------------------------------------------


def _simplify_negation_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively eliminate NOT(NOT(x)) → x throughout an expression."""
    def rewrite_expr(node: object) -> object:
        # Children are already simplified (post-order); collapse double-negation here.
        if isinstance(node, SQLNot) and isinstance(node.expr, SQLNot):
            return node.expr.expr
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _simplify_negations_in_query(query: SQLQuery) -> SQLQuery:
    """DoubleNegElim: Eliminate NOT(NOT(x)) and drop trivially-true IS NOT NULL guards
    throughout all WHERE / JOIN conditions."""
    if not isinstance(query, SQLSelectQuery):
        return query
    new_where = tuple(
        _simplify_negation_expr(c)
        for c in query.where
        if not _is_trivially_true_condition(c)
    )
    new_joins = tuple(
        SQLJoin(
            kind=j.kind,
            source=j.source,
            alias=j.alias,
            conditions=tuple(
                _simplify_negation_expr(c)
                for c in j.conditions
                if not _is_trivially_true_condition(c)
            ),
        )
        for j in query.joins
    )
    if new_where == query.where and new_joins == query.joins:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=new_joins,
        where=new_where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# SingleConsumerInline — Single-consumer view inlining
# ---------------------------------------------------------------------------


def _inline_single_consumer_views(
    views: list[View], external_refs: set[str]
) -> list[View]:
    """
    SingleConsumerInline: Inline a view into its one consumer when it has no external consumers.

    A view V is inlinable when:
    - Exactly one other view in this step references V by name.
    - V's name is not in external_refs (not referenced from outside this step).
    - V is an internal staging view (base name contains "__"), not a public final view.
      Public views (entity tables, relation tables) may be referenced by queries compiled
      separately and must therefore remain as named views.
    """
    step_names = {v.name for v in views}

    # Count how many views within this step reference each step-local name
    ref_counts: dict[str, int] = {name: 0 for name in step_names}
    for v in views:
        for name in _collect_table_refs_in_query(v.query):
            if name in ref_counts:
                ref_counts[name] += 1


    inlinable = {
        name
        for name, count in ref_counts.items()
        if count == 1 and name not in external_refs and name_scheme.is_synthesized_internal(name)
    }
    if not inlinable:
        return views

    inline_map = {v.name: v.query for v in views if v.name in inlinable}
    return [
        View(name=v.name, query=_substitute_table_sources(v.query, inline_map), column_types=v.column_types)
        for v in views
        if v.name not in inlinable
    ]


# ---------------------------------------------------------------------------
# AggSubqueryFlatten — Aggregate-subquery flatten
# ---------------------------------------------------------------------------


def _aggregate_subquery_flatten(query: SQLQuery) -> SQLQuery:
    """
    AggSubqueryFlatten: Push MAX aggregates through a pure-projection subquery.

    Pattern:
      SELECT key_col, MAX(col1), MAX(col2), ...
      FROM (SELECT expr_k AS key_col, expr1 AS col1, expr2 AS col2, ... FROM src) AS t
      GROUP BY key_col
    →
      SELECT expr_k AS key_col, MAX(expr1) AS col1, MAX(expr2) AS col2, ...
      FROM src
      GROUP BY expr_k

    Preconditions:
    - Outer has GROUP BY and no WHERE, no DISTINCT, no extra joins.
    - Outer SELECT contains only the key column (direct col-ref) and MAX(col-ref) items.
    - Inner is a pure projection: no GROUP BY, no DISTINCT, no extra joins.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.group_by or query.where or query.joins or query.distinct:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if inner.group_by or inner.distinct or inner.joins or inner.from_item is None:
        return query

    # outer_alias = query.from_item.alias

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Rewrite GROUP BY: each col-ref must resolve through inner_map
    new_group_by: list[SQLExpr] = []
    for gb_expr in query.group_by:
        if not isinstance(gb_expr, SQLColumnRef):
            return query
        if gb_expr.column_name not in inner_map:
            return query
        new_group_by.append(inner_map[gb_expr.column_name])

    # Rewrite SELECT: key col-ref or MAX(col-ref), both resolved through inner_map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        expr = item.expr
        if isinstance(expr, SQLColumnRef):
            col_name = expr.column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(inner_map[col_name], alias=item.alias))
        elif (
            isinstance(expr, SQLFunctionCall)
            and expr.name == "MAX"
            and len(expr.args) == 1
            and isinstance(expr.args[0], SQLColumnRef)
        ):
            col_name = expr.args[0].column_name
            if col_name not in inner_map:
                return query
            new_select.append(SQLSelectItem(
                SQLFunctionCall("MAX", (inner_map[col_name],)),
                alias=item.alias,
            ))
        else:
            return query  # non-MAX, non-key expression in outer — can't flatten

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# ProjectOverAggregateFold — Project-over-aggregate fold
# ---------------------------------------------------------------------------


def _project_over_aggregate_fold(query: SQLQuery) -> SQLQuery:
    """
    ProjectOverAggregateFold: Fold a pure projection over an aggregating subquery directly into it.

    Pattern:
      SELECT f(carry.col1), carry.col2, ...
      FROM (SELECT expr1 AS col1, MAX(col2) AS col2, ... FROM src GROUP BY key) AS carry
    →
      SELECT f(expr1) AS ..., MAX(col2) AS col2, ...
      FROM src
      GROUP BY key

    Preconditions:
    - Outer is a pure projection: no GROUP BY, no WHERE, no extra joins.
      DISTINCT is allowed and is propagated into the folded result.
    - Outer SELECT contains no aggregate functions.
    - Inner is an aggregating query with GROUP BY.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if query.group_by or query.where or query.joins:
        return query
    if query.from_item is None or not isinstance(query.from_item.source, SQLSubquerySource):
        return query

    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery):
        return query
    if not inner.group_by or inner.from_item is None:
        return query
    # Skip if inner uses positional GROUP BY (integer literals like GROUP BY 1):
    # after rewriting the SELECT list the positions would refer to different columns.
    if any(isinstance(g, SQLLiteral) and isinstance(g.value, int) for g in inner.group_by):
        return query

    outer_alias = query.from_item.alias

    # Outer SELECT must not contain aggregates (would create illegal nested aggs)
    for item in query.select:
        if _contains_aggregate(item.expr):
            return query

    # Build inner projection map: alias → expr
    inner_map: dict[str, SQLExpr] = {}
    for item in inner.select:
        alias = item.alias
        if alias is None:
            if isinstance(item.expr, SQLColumnRef):
                alias = item.expr.column_name
            else:
                return query
        inner_map[alias] = item.expr

    # Substitute col-refs in each outer SELECT item using the inner map
    new_select: list[SQLSelectItem] = []
    for item in query.select:
        new_expr = _substitute_col_refs(item.expr, inner_map, outer_alias)
        if new_expr is None:
            return query
        # If the outer item had no explicit alias but was a bare column ref, keep
        # that name as the alias so the folded result still names its columns
        # correctly when embedded in a UNION ALL / wrapped by GROUP BY.
        alias = item.alias
        if alias is None and isinstance(item.expr, SQLColumnRef):
            alias = item.expr.column_name
        new_select.append(SQLSelectItem(new_expr, alias=alias))

    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=tuple(new_select),
        group_by=inner.group_by,
        order_by=query.order_by or inner.order_by,
        distinct=query.distinct or inner.distinct,
        limit=query.limit if query.limit is not None else inner.limit,
    )


def _contains_aggregate(expr: SQLExpr) -> bool:
    """Return True if expr contains any aggregate function call (MAX, MIN, etc.)."""
    def step(node: object, acc: bool) -> bool:
        if acc:
            return acc
        return isinstance(node, SQLFunctionCall) and node.name in ("MAX", "MIN", "SUM", "COUNT", "AVG")
    return fold(expr, step, False)


# ---------------------------------------------------------------------------
# RedundantCastElim — Redundant CAST elimination (type-aware)
# ---------------------------------------------------------------------------


def _infer_sql_type(expr: SQLExpr) -> str | None:
    """
    Infer the SQL type of expr where determinable.

    Rules:
    - CAST(_, T) / TryCast(_, T)  → T
    - MAX(e) / MIN(e)             → type of e  (aggregate preserves element type)
    - MD5(...)                    → VARCHAR
    - Otherwise                   → None (unknown)
    """
    if isinstance(expr, (SQLCast, SQLTryCast)):
        return expr.type_name
    if isinstance(expr, SQLFunctionCall):
        if expr.name in ("MAX", "MIN") and len(expr.args) == 1:
            return _infer_sql_type(expr.args[0])
        if expr.name == "MD5":
            return "VARCHAR"
    if isinstance(expr, SQLLiteral) and isinstance(expr.value, str):
        return "TEXT"
    return None


def _simplify_casts_in_query(query: SQLQuery) -> SQLQuery:
    """RedundantCastElim: Remove CAST(expr AS T) when type(expr) is already T throughout a query."""
    if not isinstance(query, SQLSelectQuery):
        return query
    changed = False

    new_select = []
    for item in query.select:
        s = _simplify_cast_expr(item.expr)
        new_select.append(SQLSelectItem(s, alias=item.alias))
        if s is not item.expr:
            changed = True

    new_where = []
    for w in query.where:
        s = _simplify_cast_expr(w)
        new_where.append(s)
        if s is not w:
            changed = True

    new_group_by = []
    for g in query.group_by:
        s = _simplify_cast_expr(g)
        new_group_by.append(s)
        if s is not g:
            changed = True

    new_joins = []
    for j in query.joins:
        new_conds = tuple(_simplify_cast_expr(c) for c in j.conditions)
        if new_conds != j.conditions:
            new_joins.append(SQLJoin(kind=j.kind, source=j.source, alias=j.alias, conditions=new_conds))
            changed = True
        else:
            new_joins.append(j)

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(new_joins),
        where=tuple(new_where),
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _simplify_cast_expr(expr: SQLExpr) -> SQLExpr:
    """Recursively remove CAST(expr AS T) when the type of expr is already T,
    and simplify CAST(NULL AS T) → NULL."""
    def rewrite_expr(node: object) -> object:
        # Children already simplified (post-order); fold redundant casts here.
        if isinstance(node, (SQLCast, SQLTryCast)):
            inner = node.expr
            if isinstance(inner, SQLLiteral) and inner.value is None:
                return inner
            if _infer_sql_type(inner) == node.type_name:
                return inner
        return node
    return transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


def _substitute_col_refs(
    expr: SQLExpr,
    sub_map: dict[str, SQLExpr],
    outer_alias: str | None,
) -> SQLExpr | None:
    """
    Replace SQLColumnRef(col, outer_alias) with sub_map[col] throughout expr.
    Returns None if a col-ref targeting outer_alias is missing from sub_map.
    Col-refs targeting other aliases are left unchanged.
    """
    def rewrite_expr(node: object) -> object | None:
        if isinstance(node, SQLColumnRef) and node.table_alias in (None, outer_alias):
            if node.column_name in sub_map:
                return sub_map[node.column_name]
            return None
        return node
    return try_transform(expr, expr_fn=rewrite_expr)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# SingletonFromLift — Eliminate a FROM (SELECT 1) that contributes no columns
# ---------------------------------------------------------------------------


def _is_trivial_join_condition(conditions: tuple) -> bool:
    """Return True if a join condition is effectively unconditional (TRUE or empty)."""
    return not conditions or (len(conditions) == 1 and isinstance(conditions[0], SQLLiteral) and conditions[0].value is True)


def _alias_used_in_expr(alias: str, expr: SQLExpr) -> bool:
    """Return True if any SQLColumnRef anywhere in expr references the given table alias."""
    return _alias_used_in_query(alias, expr)


def _alias_used_in_query(alias: str, root: object) -> bool:
    """True if `alias` appears anywhere in the IR subtree rooted at `root` (queries, exprs, sources)."""
    def step(node: object, acc: bool) -> bool:
        if acc:
            return acc
        return isinstance(node, SQLColumnRef) and node.table_alias == alias
    return fold(root, step, False)


def _lift_singleton_from(query: SQLQuery) -> SQLQuery:
    """SingletonFromLift: Eliminate a FROM (SELECT 1) singleton when it contributes no columns.

    Pattern:
        SELECT ...
        FROM (SELECT 1) AS a        -- singleton, alias 'a' unreferenced
        JOIN source AS b ON TRUE    -- INNER JOIN only (LEFT JOIN would change semantics)
        [more joins...]

    The (SELECT 1) always returns exactly one row. An INNER JOIN with it on TRUE
    is a no-op — it doesn't filter or multiply rows. When the singleton alias is
    unreferenced elsewhere in the query, it can be removed and the first INNER
    JOIN promoted to the FROM item.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if query.from_item is None or not query.joins:
        return query
    if not isinstance(query.from_item.source, SQLSingletonSource):
        return query

    singleton_alias = query.from_item.alias

    # Safety: singleton alias must not be referenced anywhere in the query
    if _alias_used_in_query(singleton_alias, query):
        return query

    # Find the first INNER JOIN with a trivial condition to promote
    first_join = query.joins[0]
    if "LEFT" in first_join.kind.upper() or "RIGHT" in first_join.kind.upper():
        return query
    if not _is_trivial_join_condition(first_join.conditions):
        return query

    return SQLSelectQuery(
        from_item=SQLFromItem(source=first_join.source, alias=first_join.alias),
        joins=query.joins[1:],
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )



# ---------------------------------------------------------------------------
# LateralJoinReorder — Move LATERAL joins up next to their correlation anchor
# ---------------------------------------------------------------------------


def _aliases_referenced_by_join(join: SQLJoin, candidate_aliases: set[str]) -> set[str]:
    """Outer aliases referenced by a join's ON conditions and (for LATERAL) its subquery body."""
    refs: set[str] = set()
    for cond in join.conditions:
        for a in candidate_aliases:
            if _alias_used_in_expr(a, cond):
                refs.add(a)
    if "LATERAL" in join.kind.upper() and isinstance(join.source, SQLSubquerySource):
        inner = join.source.query
        for a in candidate_aliases:
            if _alias_used_in_query(a, inner):
                refs.add(a)
    return refs


def _reorder_lateral_joins(query: SQLQuery) -> SQLQuery:
    """Move each LATERAL join up to immediately after its latest referenced alias.

    DuckDB's decorrelator OOMs on ``LEFT JOIN LATERAL (...)`` placed after an
    INNER-JOIN chain it doesn't correlate with. LATERALs only move up, never
    down; non-LATERAL joins keep relative order.

    Lives here, not in the Lowerer. The bad shape originates in
    ``_lower_logical``'s IR-order body walk, but that walk is also
    semantically ordered (``=``/cast binding-arrival, ``body[index+1:]``
    lookahead, deferral state, aggregate ``rowset_query`` snapshots), so
    reordering it is a substantial refactor. Join reordering is canonical
    optimizer territory; correctness stays in the Lowerer, plan shape
    stays here.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.joins or not any("LATERAL" in j.kind.upper() for j in query.joins):
        return query
    if query.from_item is None:
        return query

    all_aliases = {query.from_item.alias, *(j.alias for j in query.joins)}

    result: list[SQLJoin] = []
    changed = False
    for join in query.joins:
        if "LATERAL" not in join.kind.upper():
            result.append(join)
            continue
        refs = _aliases_referenced_by_join(join, all_aliases)
        # A LATERAL can't correlate against itself from the outside.
        refs.discard(join.alias)
        latest_dep_pos = -1
        for i, r in enumerate(result):
            if r.alias in refs:
                latest_dep_pos = i
        # Default to "append" — preserves input order, which is the stable
        # tiebreaker among sibling LATERALs that have identical dependency
        # sets. Only pull this LATERAL *earlier* than its natural append
        # position when there's a NON-LATERAL join sitting between its
        # latest dependency and the end. That preserves the documented
        # "move past INNER-JOIN chain" behavior while never displacing
        # another LATERAL — which is what previously caused the pass to
        # oscillate forever and never reach a fixpoint.
        insert_pos = len(result)
        for i in range(latest_dep_pos + 1, len(result)):
            if "LATERAL" not in result[i].kind.upper():
                insert_pos = i
                break
        if insert_pos != len(result):
            changed = True
        result.insert(insert_pos, join)

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(result),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# UnwrapRedundantLateral — Splice a ``LEFT JOIN LATERAL`` wrapper whose body
# is ``FROM (SELECT 1) <only LEFT JOIN LATERAL inner joins>`` directly into
# the outer query. The wrapper is structural (the lowerer emits it to give
# a Match expression a stable projection alias in select context) but it
# hides each inner LATERAL's true correlation parent from the catch-net
# ``DecorrelateLateral`` pass — references like ``s5.person = s1._id``
# inside an inner LATERAL would resolve at the *grandparent* once the
# wrapper is unwrapped, which is exactly what ``parent_aliases`` expects.
#
# Pattern unwrapped:
#
#     LEFT JOIN LATERAL (
#         SELECT <exprs over inner-LATERAL aliases only> AS v...
#         FROM (SELECT 1) AS <singleton>
#         LEFT JOIN LATERAL (<branch_1>) AS <inner_1> ON TRUE
#         LEFT JOIN LATERAL (<branch_2>) AS <inner_2> ON TRUE
#         ...
#     ) AS <wrapper> ON TRUE
#
# Splices each inner LATERAL into the outer ``joins`` list and rewrites every
# ``wrapper.X`` reference in the outer query to the corresponding SELECT
# expression from the wrapper body. The singleton FROM and the wrapper
# itself vanish.
#
# Preconditions (structural, all required):
#   * wrapper ``kind == "LEFT JOIN LATERAL"`` and its ON is trivial (TRUE)
#   * wrapper body's ``from_item.source`` is ``SQLSingletonSource``
#   * wrapper body has no WHERE / GROUP BY / DISTINCT / LIMIT / ORDER BY
#   * every wrapper body inner join is ``LEFT JOIN`` (LATERAL or non-LATERAL)
#     with a trivial ON — preserves row-count semantics of the wrapper itself
#   * wrapper body's SELECT items are uniquely aliased and reference only
#     the inner-join aliases (not the singleton — it has no columns)
#
# Why a LEFT JOIN LATERAL with a singleton FROM and only-LEFT-JOIN inners
# (LATERAL or not) is row-count-preserving: the singleton always returns
# one row; each inner LEFT JOIN ON TRUE multiplies the running row count
# by its body size, with LEFT JOIN preserving outer rows when the body is
# empty. So the wrapper produces the same per-outer-row contribution as
# the inner joins do when spliced directly into outer scope.
# ---------------------------------------------------------------------------


def _try_unwrap_wrapper_lateral(
    j: SQLJoin,
) -> tuple[tuple[SQLJoin, ...], dict[str, SQLExpr]] | None:
    """Match the wrapper shape and return ``(inner_joins_to_splice,
    wrapper_alias_substitutions)``. None if ``j`` is not a wrapper."""
    if j.kind.upper() != "LEFT JOIN LATERAL":
        return None
    if not _is_trivial_join_condition(j.conditions):
        return None
    if not isinstance(j.source, SQLSubquerySource):
        return None
    body = j.source.query
    if not isinstance(body, SQLSelectQuery):
        return None
    if body.from_item is None or not isinstance(body.from_item.source, SQLSingletonSource):
        return None
    if body.where or body.group_by or body.distinct or body.limit is not None or body.order_by:
        return None
    if not body.joins:
        return None  # nothing to splice
    for inner_j in body.joins:
        # Accept LEFT JOIN (LATERAL or non-LATERAL) with trivial ON. Both
        # forms preserve outer row count when spliced; the non-LATERAL form
        # arises after ``DecorrelateLateral``'s strip-LATERAL branch fires on
        # a self-contained inner body before this pass sees the wrapper.
        kind_parts = set(inner_j.kind.upper().split())
        if "LEFT" not in kind_parts or "JOIN" not in kind_parts:
            return None
        if not _is_trivial_join_condition(inner_j.conditions):
            return None
    inner_join_aliases = {inner_j.alias for inner_j in body.joins}
    aliases_seen: set[str] = set()
    substitutions: dict[str, SQLExpr] = {}
    for item in body.select:
        if item.alias is None or item.alias in aliases_seen:
            return None
        aliases_seen.add(item.alias)
        # SELECT expressions must reference only inner-join aliases — not
        # the singleton (which has no columns) and not anything outside the
        # wrapper body. Refs into inner-join bodies are validated by
        # ``node_is_closed``'s scope tracking (each inner join extends the
        # visible set with its own body's aliases).
        if not node_is_closed(item.expr, inner_join_aliases):
            return None
        substitutions[item.alias] = item.expr
    return tuple(body.joins), substitutions


def _unwrap_redundant_lateral(query: SQLQuery) -> SQLQuery:
    """Splice every redundant ``LEFT JOIN LATERAL`` wrapper in ``query.joins``
    into the outer query, rewriting outer references to the wrapper's
    projection columns into the inlined expressions."""
    if not isinstance(query, SQLSelectQuery) or not query.joins:
        return query
    new_joins: list[SQLJoin] = []
    substitutions_by_wrapper: dict[str, dict[str, SQLExpr]] = {}
    for j in query.joins:
        unwrap = _try_unwrap_wrapper_lateral(j)
        if unwrap is None:
            new_joins.append(j)
            continue
        inner_joins, subs = unwrap
        new_joins.extend(inner_joins)
        substitutions_by_wrapper[j.alias] = subs
    if not substitutions_by_wrapper:
        return query

    def expr_fn(e: object) -> object:
        if isinstance(e, SQLColumnRef) and e.table_alias in substitutions_by_wrapper:
            mapping = substitutions_by_wrapper[e.table_alias]
            replacement = mapping.get(e.column_name)
            if replacement is not None:
                return replacement
        return e

    rewritten = SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(new_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )
    return transform(rewritten, expr_fn=expr_fn)


# ---------------------------------------------------------------------------
# RowGeneratorOuterMaterialize — Hoist correlated row-generator JOINs into a
# wrapping subquery's SELECT list, then expand via comma-LATERAL UNNEST against
# the resulting column reference.
# ---------------------------------------------------------------------------
#
# A ``JoinItem`` whose source is ``SQLTableFunctionSource("RANGE", args)``
# (with ``unnest=False``) and whose args reference any alias defined earlier
# in the enclosing ``SQLSelectQuery`` (``from_item`` or a preceding join)
# emits as a correlated table-function LATERAL — a shape Snowflake's optimizer
# refuses to evaluate (errno 2031). DuckDB compiles it fine but the same
# rewrite is harmless there.
#
# The rewrite wraps the pre-range scope (``from_item`` + joins before the
# range) as a derived subquery whose SELECT projects every referenced outer
# column plus a synthesized ``_gen_arr = range_array(args)`` column, then
# replaces the range JOIN with a comma-LATERAL ``ARRAY_UNNEST(wrapper._gen_arr)``
# source. References elsewhere in the query (``select``/``where``/later
# joins/group_by/order_by) are rewritten in lockstep:
#   * ``outer_alias.col`` → ``wrapper_alias.<synthetic_col>``
#   * ``range_alias.value`` → ``unnest_alias.value``
#
# All-or-nothing: if any referenced column can't be projected (e.g., reference
# to an alias outside the enclosing query) the pass leaves the join alone.
# Iterated to fixpoint by the optimizer's outer loop, so multiple correlated
# row-generators in a query are handled one at a time.
_ROW_GENERATOR_FUNCTIONS = {"RANGE"}


_GEN_VALUE_COL = "_gen_value"
_GEN_ARR_COL = "_gen_arr"


def _materialize_correlated_row_generator(query: SQLQuery) -> SQLQuery:
    if not isinstance(query, SQLSelectQuery) or query.from_item is None or not query.joins:
        return query
    scope_aliases: set[str] = {query.from_item.alias}
    range_idx: int | None = None
    range_source: SQLTableFunctionSource | None = None
    range_alias: str | None = None
    for idx, j in enumerate(query.joins):
        candidate = _row_generator_source(j.source)
        if candidate is not None and any(
            _node_refs_alias(arg, scope_aliases) for arg in candidate.args
        ):
            range_idx = idx
            range_source = candidate
            range_alias = j.alias
            break
        scope_aliases.add(j.alias)
    if range_idx is None or range_source is None or range_alias is None:
        return query
    range_join = query.joins[range_idx]

    pre_joins = query.joins[:range_idx]
    post_joins = query.joins[range_idx + 1 :]

    # Discover every outer-column reference downstream of the range join.
    # Each such ref must be carried by the wrapper's SELECT so post-rewrite
    # references resolve at the new wrapper alias.
    step = _collect_outer_ref_step(scope_aliases)
    referenced: set[tuple[str, str]] = set()
    for group in (post_joins, query.where, query.select,
                  query.group_by, query.order_by, range_join.conditions):
        for node in group:
            referenced = fold(node, step, referenced)

    # Aliases must be unique across the whole query tree, not just locally —
    # this pass may fire multiple times at different nesting levels, and a
    # collision between an outer-scope wrapper alias and a name used inside a
    # previously-generated nested subquery confuses SF's name resolver.
    taken_aliases = _all_aliases_in(query)
    inner_alias = _fresh_alias(taken_aliases)
    unnest_alias = _fresh_alias(taken_aliases | {inner_alias})
    wrapper_alias = _fresh_alias(taken_aliases | {inner_alias, unnest_alias})

    # Inner subquery: project carried outer columns + the array column. The
    # array is built from the original range args, evaluable here because
    # ``scope_aliases`` are still in scope inside the inner subquery's FROM.
    sorted_refs = sorted(referenced)
    rename_map = {(a, c): f"{a}__{c}" for a, c in sorted_refs}
    inner_select: list[SQLSelectItem] = [
        SQLSelectItem(expr=SQLColumnRef(c, a), alias=rename_map[(a, c)])
        for a, c in sorted_refs
    ]
    inner_select.append(
        SQLSelectItem(
            expr=SQLFunctionCall("range_array", range_source.args),
            alias=_GEN_ARR_COL,
        )
    )

    # WHERE conjuncts that only reference pre-range scope move into the inner
    # subquery (where those aliases are still defined). Conjuncts that
    # reference post-range aliases stay at the outer level (rewritten later).
    inner_where: list[SQLExpr] = []
    outer_where_kept: list[SQLExpr] = []
    for c in query.where:
        refs = fold(c, _aliases_used, set())
        if refs and refs <= scope_aliases:
            inner_where.append(c)
        else:
            outer_where_kept.append(c)

    inner_query = SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(pre_joins),
        where=tuple(inner_where),
        select=tuple(inner_select),
    )

    # Wrapper subquery: cross-join the inner subquery against a column-ref
    # UNNEST/FLATTEN of its ``_gen_arr`` column, projecting every carried
    # outer column passthrough plus the unnest's value as ``_gen_value``.
    # Emitting wrapper+unnest INSIDE a single subquery (rather than as two
    # siblings of the outer query) keeps the comma-LATERAL from ever sitting
    # to the left of an outer LEFT JOIN — a shape Snowflake rejects.
    wrapper_passthrough: list[SQLSelectItem] = [
        SQLSelectItem(expr=SQLColumnRef(s.alias, inner_alias), alias=s.alias)
        for s in inner_select
        if s.alias is not None and s.alias != _GEN_ARR_COL
    ]
    wrapper_passthrough.append(
        SQLSelectItem(
            expr=SQLColumnRef((range_source.column_names or ("value",))[0], unnest_alias),
            alias=_GEN_VALUE_COL,
        )
    )
    unnest_source = SQLTableFunctionSource(
        function_name="ARRAY_UNNEST",
        args=(SQLColumnRef(_GEN_ARR_COL, inner_alias),),
        column_names=range_source.column_names or ("value",),
        unnest=True,
    )
    wrapper_query = SQLSelectQuery(
        from_item=SQLFromItem(source=SQLSubquerySource(inner_query), alias=inner_alias),
        joins=(
            SQLJoin(kind="JOIN", source=unnest_source, alias=unnest_alias, conditions=()),
        ),
        select=tuple(wrapper_passthrough),
    )

    def rewrite_ref(node: object) -> object:
        if not isinstance(node, SQLColumnRef) or node.table_alias is None:
            return node
        key = (node.table_alias, node.column_name)
        if key in rename_map:
            return SQLColumnRef(rename_map[key], wrapper_alias)
        if node.table_alias == range_alias:
            return SQLColumnRef(_GEN_VALUE_COL, wrapper_alias)
        return node

    new_post_joins: list[SQLJoin] = [transform(j, expr_fn=rewrite_ref) for j in post_joins]
    new_outer_where: list[SQLExpr] = [transform(c, expr_fn=rewrite_ref) for c in outer_where_kept]
    new_select: list[SQLSelectItem] = [transform(item, expr_fn=rewrite_ref) for item in query.select]
    new_group_by: list[SQLExpr] = [transform(g, expr_fn=rewrite_ref) for g in query.group_by]
    new_order_by = [transform(o, expr_fn=rewrite_ref) for o in query.order_by]

    # Honor any ``ON`` conditions that today's emit attached to the range
    # LATERAL (e.g., ``range_alias.value = bound_expr``). Push them to the
    # outer WHERE with ``range_alias`` references rewritten to the wrapper.
    for c in range_join.conditions:
        new_outer_where.append(transform(c, expr_fn=rewrite_ref))

    return SQLSelectQuery(
        from_item=SQLFromItem(source=SQLSubquerySource(wrapper_query), alias=wrapper_alias),
        joins=tuple(new_post_joins),
        where=tuple(new_outer_where),
        select=tuple(new_select),
        group_by=tuple(new_group_by),
        order_by=tuple(new_order_by),
        distinct=query.distinct,
        limit=query.limit,
    )


def _collect_outer_ref_step(scope_aliases: set[str]):
    def step(node: object, acc: set[tuple[str, str]]) -> set[tuple[str, str]]:
        if isinstance(node, SQLColumnRef) and node.table_alias in scope_aliases:
            acc.add((node.table_alias, node.column_name))
        return acc
    return step


def _row_generator_source(source: SQLSource) -> SQLTableFunctionSource | None:
    """Return the underlying row-generator ``SQLTableFunctionSource`` if
    ``source`` represents one — either directly or via a passthrough
    subquery wrapper produced by ``_lower_optional``'s lift path
    (``SQLSubquerySource(SELECT [* | <col>] FROM SQLTableFunctionSource(RANGE, ...))``).
    Otherwise None.
    """
    if isinstance(source, SQLTableFunctionSource):
        if (
            source.function_name.upper() in _ROW_GENERATOR_FUNCTIONS
            and not source.unnest
            and not source.with_ordinality
        ):
            return source
        return None
    if isinstance(source, SQLSubquerySource):
        inner = source.query
        if (
            isinstance(inner, SQLSelectQuery)
            and inner.from_item is not None
            and not inner.joins
            and not inner.where
            and not inner.group_by
            and not inner.order_by
            and not inner.distinct
            and isinstance(inner.from_item.source, SQLTableFunctionSource)
            and inner.from_item.source.function_name.upper() in _ROW_GENERATOR_FUNCTIONS
            and not inner.from_item.source.unnest
            and not inner.from_item.source.with_ordinality
        ):
            return inner.from_item.source
    return None


def _node_refs_alias(node: object, aliases: set[str]) -> bool:
    def step(n: object, acc: bool) -> bool:
        if acc:
            return True
        if isinstance(n, SQLColumnRef) and n.table_alias in aliases:
            return True
        return acc
    return fold(node, step, False)


def _aliases_used(node: object, acc: set[str]) -> set[str]:
    if isinstance(node, SQLColumnRef) and node.table_alias is not None:
        acc.add(node.table_alias)
    return acc


def _fresh_alias(taken: set[str]) -> str:
    counter = 1
    while True:
        candidate = f"_w{counter}"
        if candidate not in taken:
            return candidate
        counter += 1


def _all_aliases_in(query: SQLQuery) -> set[str]:
    """Collect every FROM-item / JOIN alias reachable from ``query``,
    descending into nested subqueries. Used so freshly-generated wrapper
    aliases never collide with aliases produced by an earlier pass run that
    is now buried inside a derived subquery."""
    def step(node: object, acc: set[str]) -> set[str]:
        if isinstance(node, SQLFromItem):
            acc.add(node.alias)
        elif isinstance(node, SQLJoin):
            acc.add(node.alias)
        return acc
    return fold(query, step, set())


# ---------------------------------------------------------------------------
# DecorrelateLateral — Rewrite ``LEFT JOIN LATERAL (subq) ON TRUE`` whose body
# correlates to outer scope only via equality predicates into a plain
# ``LEFT JOIN``.
#
# The single shape this pass handles (the only one we have observed and
# verified end-to-end):
#
#   body has a real FROM/joins; every outer-column reference appears as one
#   side of a top-level WHERE conjunct of the form ``inner_expr = outer_expr``
#   (an "equality correlation key"). The lift removes those conjuncts from
#   the body WHERE, projects each inner side as ``__jkN``, and replaces the
#   LATERAL with a plain LEFT JOIN whose ON is ``__jkN = outer_expr``.
#
# Skips (deferred to other mechanisms):
#   * ``INNER JOIN LATERAL`` — row-dropping semantics that LEFT JOIN can't
#     preserve.
#   * Bodies with GROUP BY / DISTINCT / LIMIT / ORDER BY — would need a
#     keyed-pre-aggregate variant of the lift.
#   * Bodies where outer refs appear in SELECT items, JOIN ONs, or as
#     non-equality WHERE predicates — can't be expressed as join keys.
#   * Bodies with no real FROM (purely scalar LATERALs) — the lowerer's
#     ``_optional_can_inline`` already handles these.
#
# Gate structurally mirrors the lowerer's ``_try_lift_match_branch`` (one
# ``node_is_closed`` predicate decides both): the post-lift body must be
# closed under its own bound aliases, and every lifted ``outer_expr`` must
# resolve at the immediate parent (not a grandparent).
#
# Semantics: moving ``inner.k = outer.k`` from a body WHERE to the JOIN ON
# preserves match semantics; LEFT JOIN keeps unmatched outer rows with NULL
# inner cols just like the original LATERAL ON TRUE did when the body
# produced zero rows. Monotone-decreasing in LATERAL count, so the pass
# terminates under the optimizer's fixpoint loop and composes with
# LateralJoinReorder.
# ---------------------------------------------------------------------------


def _collect_inner_aliases(body: SQLSelectQuery) -> set[str]:
    """All table aliases bound *inside* the LATERAL body."""
    aliases: set[str] = set()
    if body.from_item is not None:
        aliases.add(body.from_item.alias)
    for j in body.joins:
        aliases.add(j.alias)
    return aliases


def _split_correlation_eq(
    cond: SQLExpr, inner_aliases: set[str], parent_aliases: set[str]
) -> tuple[SQLExpr, SQLExpr] | None:
    """If ``cond`` is ``inner_expr = outer_expr`` (or vice versa) where
    ``inner_expr`` references only inner aliases and ``outer_expr`` resolves
    at ``parent_aliases`` (immediate parent — not a grandparent), and both
    contain at least one column ref, return ``(inner_expr, outer_expr)``.
    Otherwise None."""
    if not isinstance(cond, SQLBinaryOp) or cond.operator != "=":
        return None
    left_inner = node_is_closed(cond.left, inner_aliases)
    right_inner = node_is_closed(cond.right, inner_aliases)
    left_has_ref = _has_any_col_ref(cond.left)
    right_has_ref = _has_any_col_ref(cond.right)
    if not (left_has_ref and right_has_ref):
        return None
    if left_inner and not right_inner and node_is_closed(cond.right, parent_aliases):
        return cond.left, cond.right
    if right_inner and not left_inner and node_is_closed(cond.left, parent_aliases):
        return cond.right, cond.left
    return None


def _has_any_col_ref(node: object) -> bool:
    return fold(node, lambda n, acc: acc or isinstance(n, SQLColumnRef), False)


def _strip_lateral(kind: str) -> str:
    """``LEFT JOIN LATERAL`` → ``LEFT JOIN``."""
    parts = [p for p in kind.upper().split() if p != "LATERAL"]
    if "LEFT" not in parts:
        parts = ["LEFT"] + [p for p in parts if p != "JOIN"] + ["JOIN"]
    return " ".join(parts)


def _try_lift(j: SQLJoin, parent_aliases: set[str]) -> SQLJoin | None:
    """If ``j`` is a ``LEFT JOIN LATERAL`` whose body is scope-closed (with
    correlations expressible as equality conjuncts in WHERE resolving at
    ``parent_aliases``), return the equivalent non-correlated ``LEFT JOIN``.

    Dispatch order:

    1. **Constant-pick union** — :func:`_try_lift_constant_pick_union` first,
       since it recognizes a more specific shape (sourceless branches with
       only literal projections + outer-only WHERE) that the general
       union-body lift would reject for lack of equality correlation.
    2. ``SQLSelectQuery`` body — :func:`_try_lift_select_body`.
    3. ``SQLUnionQuery`` body — :func:`_try_lift_union_body`.

    Otherwise None (leave the LATERAL alone)."""
    kind = j.kind.upper()
    if "LATERAL" not in kind or "LEFT" not in kind:
        return None
    if not _is_trivial_join_condition(j.conditions):
        return None
    if not isinstance(j.source, SQLSubquerySource):
        return None
    body = j.source.query
    constant_pick = _try_lift_constant_pick_union(j, body, parent_aliases)
    if constant_pick is not None:
        return constant_pick
    if isinstance(body, SQLSelectQuery):
        return _try_lift_select_body(j, body, parent_aliases, substitute_outer_in_select=False)
    if isinstance(body, SQLUnionQuery):
        return _try_lift_union_body(j, body, parent_aliases)
    return None


def _build_conjunction(conjuncts: list[SQLExpr]) -> SQLExpr:
    if not conjuncts:
        return SQLLiteral(True)
    result = conjuncts[0]
    for c in conjuncts[1:]:
        result = SQLBinaryOp(left=result, operator="AND", right=c)
    return result


def _build_disjunction(disjuncts: list[SQLExpr]) -> SQLExpr:
    if not disjuncts:
        return SQLLiteral(False)
    result = disjuncts[0]
    for d in disjuncts[1:]:
        result = SQLBinaryOp(left=result, operator="OR", right=d)
    return result


def _try_lift_constant_pick_union(
    j: SQLJoin, body: SQLQuery, parent_aliases: set[str],
) -> SQLJoin | None:
    """Recognize a ``LATERAL`` whose body is a UNION of sourceless branches
    each projecting only literals (or casts of literals) and gated by
    outer-only WHERE predicates. Optionally the UNION is wrapped in a
    passthrough SELECT (column-rename only).

    Rewrite: each branch becomes ``SELECT i AS __idx, lit1 AS a1, ... FROM
    (SELECT 1)`` in a ``UNION ALL`` derived table, and the LATERAL is
    replaced by ``LEFT JOIN <derived> ON (__idx=1 AND p1) OR (__idx=2 AND p2)
    OR ...``. Per-outer-row row count is identical: each branch contributes
    its row iff its predicate fires.

    Soundness: ``UNION(SELECT v_i WHERE p_i(outer)) ≡ JOIN({(i, v_i)}) ON
    OR_i(idx=i ∧ p_i(outer))`` is a pure algebraic identity — both produce
    exactly the set ``{v_i | p_i(outer)}`` per outer row.

    Preconditions (all required):
      * body is ``SQLUnionQuery`` directly, or a passthrough ``SQLSelectQuery``
        (no joins/WHERE/GROUP BY/DISTINCT/LIMIT/ORDER, identity-projection
        SELECT items only) wrapping one
      * the UNION's operator is ``UNION`` or ``UNION ALL``
      * every branch is a ``SQLSelectQuery`` with no joins/aggregation/etc.
      * every branch has either no FROM or a singleton FROM
      * every branch's SELECT item is a literal or a cast of a literal
      * every branch's WHERE conjunct references only outer aliases (no
        inner-bound references; sourceless branches have no inner aliases
        anyway)
      * all branches agree on SELECT-item aliases (same column shape)
    """
    rename_map: dict[str, str] = {}
    union: SQLUnionQuery
    if isinstance(body, SQLSelectQuery):
        # Passthrough wrapper around a UNION? Identify-and-extract.
        if body.joins or body.where or body.group_by or body.distinct or body.order_by or body.limit is not None:
            return None
        if body.from_item is None:
            return None
        if not isinstance(body.from_item.source, SQLSubquerySource):
            return None
        inner = body.from_item.source.query
        if not isinstance(inner, SQLUnionQuery):
            return None
        inner_alias = body.from_item.alias
        for item in body.select:
            if item.alias is None or not isinstance(item.expr, SQLColumnRef):
                return None
            col = item.expr
            if col.table_alias is not None and col.table_alias != inner_alias:
                return None
            rename_map[col.column_name] = item.alias
        union = inner
    elif isinstance(body, SQLUnionQuery):
        union = body
    else:
        return None

    if union.operator.upper() not in ("UNION", "UNION ALL"):
        return None
    if not union.queries:
        return None

    common_aliases: list[str] | None = None
    per_branch: list[tuple[list[SQLExpr], list[SQLSelectItem]]] = []
    for q in union.queries:
        if not isinstance(q, SQLSelectQuery):
            return None
        if q.joins or q.group_by or q.distinct or q.order_by or q.limit is not None:
            return None
        if q.from_item is not None and not isinstance(q.from_item.source, SQLSingletonSource):
            return None
        # WHERE conjuncts must be outer-only (or trivially constant). Since
        # the branch is sourceless / singleton-FROM, no inner aliases exist;
        # node_is_closed under parent_aliases catches outer refs only.
        for c in q.where:
            if not _has_any_col_ref(c):
                continue
            if not node_is_closed(c, parent_aliases):
                return None
        # SELECT items must be literals (possibly wrapped in CAST).
        for item in q.select:
            if item.alias is None:
                return None
            expr_inner: object = item.expr
            while isinstance(expr_inner, (SQLCast, SQLTryCast)):
                expr_inner = expr_inner.expr
            if not isinstance(expr_inner, SQLLiteral):
                return None
        # alias non-None already enforced above; cast for the type checker.
        aliases: list[str] = [item.alias for item in q.select if item.alias is not None]
        if len(aliases) != len(q.select):
            return None
        if common_aliases is None:
            common_aliases = aliases
        elif aliases != common_aliases:
            return None
        per_branch.append((list(q.where), list(q.select)))

    if not per_branch:
        return None

    new_branches: list[SQLQuery] = []
    join_disjuncts: list[SQLExpr] = []
    for i, (where_conjuncts, select_items) in enumerate(per_branch):
        idx_val = i + 1
        new_select: list[SQLSelectItem] = [
            SQLSelectItem(expr=SQLLiteral(idx_val), alias="__idx"),
        ]
        for item in select_items:
            assert item.alias is not None  # enforced by the precondition loop above
            out_alias: str = rename_map.get(item.alias, item.alias) if rename_map else item.alias
            new_select.append(SQLSelectItem(expr=item.expr, alias=out_alias))
        new_branches.append(SQLSelectQuery(
            from_item=SQLFromItem(source=SQLSingletonSource(), alias=f"__cp{i}"),
            select=tuple(new_select),
        ))
        idx_eq = SQLBinaryOp(
            left=SQLColumnRef(column_name="__idx", table_alias=j.alias),
            operator="=",
            right=SQLLiteral(idx_val),
        )
        if where_conjuncts:
            pred = _build_conjunction(list(where_conjuncts))
            disjunct: SQLExpr = SQLBinaryOp(left=idx_eq, operator="AND", right=pred)
        else:
            disjunct = idx_eq
        join_disjuncts.append(disjunct)

    new_union = SQLUnionQuery(queries=tuple(new_branches), operator="UNION ALL")
    new_on = _build_disjunction(join_disjuncts)
    return SQLJoin(
        kind=_strip_lateral(j.kind),
        source=SQLSubquerySource(query=new_union),
        alias=j.alias,
        conditions=(new_on,),
    )


def _try_lift_select_body(
    j: SQLJoin,
    body: SQLSelectQuery,
    parent_aliases: set[str],
    *,
    substitute_outer_in_select: bool,
) -> SQLJoin | None:
    """Lift logic for a single ``SQLSelectQuery`` body. When
    ``substitute_outer_in_select`` is True, outer references in SELECT items
    are rewritten to their inner-side counterparts under the WHERE equality
    keys (used by the union-branch path; outer refs in SELECT are otherwise
    a hard rejection)."""
    if body.group_by or body.distinct or body.limit is not None or body.order_by:
        return None
    if not all(item.alias is not None for item in body.select):
        return None

    inner_aliases = _collect_inner_aliases(body)

    # Split WHERE conjuncts: inner-only stay; equality correlations lift.
    keep_where: list[SQLExpr] = []
    lift_keys: list[tuple[SQLExpr, SQLExpr]] = []
    for c in body.where:
        if node_is_closed(c, inner_aliases):
            keep_where.append(c)
            continue
        eq = _split_correlation_eq(c, inner_aliases, parent_aliases)
        if eq is None:
            return None
        lift_keys.append(eq)

    # Optionally rewrite SELECT items to use inner-side equalities. Only used
    # by the union-branch path — see :func:`_try_lift_union_body`.
    select_items: tuple[SQLSelectItem, ...] = tuple(body.select)
    if substitute_outer_in_select and lift_keys:
        select_items = tuple(
            SQLSelectItem(
                expr=substitute_outer_with_inner_in_expr(item.expr, lift_keys),
                alias=item.alias,
            )
            for item in body.select
        )

    # Closed-body invariant — the post-extraction (and possibly
    # post-substitution) body must be scope-closed under its own bound
    # aliases. Any free outer ref anywhere means the lift would produce a
    # still-correlated form.
    hypothetical = SQLSelectQuery(
        from_item=body.from_item,
        joins=tuple(body.joins),
        where=tuple(keep_where),
        select=select_items,
    )
    if not node_is_closed(hypothetical, inner_aliases):
        return None

    # Strip-LATERAL branch: no top-level WHERE correlation AND body is fully
    # closed. The ``LATERAL`` keyword is redundant — a non-LATERAL derived
    # table joined ``ON TRUE`` has identical row-count semantics. Works for
    # any body shape, including purely scalar (no FROM, no joins).
    if not lift_keys:
        return SQLJoin(
            kind=_strip_lateral(j.kind),
            source=SQLSubquerySource(query=hypothetical),
            alias=j.alias,
            conditions=j.conditions,
        )

    # Correlation-lift branch: needs a real source to attach the ``__jkN``
    # projection. A purely scalar body with a correlation in WHERE could only
    # arise from oddly-shaped lowering and isn't observed; reject it.
    has_real_source = (
        body.from_item is not None
        and not isinstance(body.from_item.source, SQLSingletonSource)
    ) or bool(body.joins)
    if not has_real_source:
        return None

    extra_items: list[SQLSelectItem] = []
    new_join_conds: list[SQLExpr] = []
    for i, (inner_expr, outer_expr) in enumerate(lift_keys):
        jk_alias = f"__jk{i}"
        extra_items.append(SQLSelectItem(expr=inner_expr, alias=jk_alias))
        new_join_conds.append(
            SQLBinaryOp(
                left=SQLColumnRef(column_name=jk_alias, table_alias=j.alias),
                operator="=",
                right=outer_expr,
            )
        )
    new_body = SQLSelectQuery(
        from_item=body.from_item,
        joins=tuple(body.joins),
        where=tuple(keep_where),
        select=select_items + tuple(extra_items),
    )
    return SQLJoin(
        kind=_strip_lateral(j.kind),
        source=SQLSubquerySource(query=new_body),
        alias=j.alias,
        conditions=tuple(new_join_conds),
    )


def _try_lift_union_body(
    j: SQLJoin, body: SQLUnionQuery, parent_aliases: set[str]
) -> SQLJoin | None:
    """Lift a ``LATERAL`` whose body is a ``UNION`` / ``UNION ALL`` of
    ``SQLSelectQuery`` branches. Each branch is lifted via
    :func:`_try_lift_select_body` with outer-ref substitution enabled in
    SELECT items (typical when the original SELECT projects the outer var
    itself, e.g. ``SELECT s2.any AS o0 ... WHERE s2.any = s3._id``). All
    branches must produce identical JOIN ON conditions (same outer key
    structure). The lifted branches are recombined into one non-correlated
    UNION joined on the shared ``__jkN`` keys."""
    if body.operator.upper() not in ("UNION", "UNION ALL"):
        return None
    if not body.queries:
        return None
    if not all(isinstance(q, SQLSelectQuery) for q in body.queries):
        return None
    lifted_branches: list[SQLJoin] = []
    for q in body.queries:
        synthetic = SQLJoin(
            kind=j.kind,
            source=SQLSubquerySource(query=q),
            alias=j.alias,
            conditions=j.conditions,
        )
        assert isinstance(q, SQLSelectQuery)
        lifted = _try_lift_select_body(synthetic, q, parent_aliases, substitute_outer_in_select=True)
        if lifted is None:
            return None
        lifted_branches.append(lifted)
    # All branches must agree on the JOIN ON shape — otherwise we can't
    # consolidate them under one shared ``__jkN = outer_expr`` set.
    first_conds = lifted_branches[0].conditions
    for lb in lifted_branches[1:]:
        if lb.conditions != first_conds:
            return None
    new_branch_bodies: list[SQLQuery] = []
    for lb in lifted_branches:
        assert isinstance(lb.source, SQLSubquerySource)
        new_branch_bodies.append(lb.source.query)
    new_union = SQLUnionQuery(queries=tuple(new_branch_bodies), operator=body.operator)
    return SQLJoin(
        kind=_strip_lateral(j.kind),
        source=SQLSubquerySource(query=new_union),
        alias=j.alias,
        conditions=first_conds,
    )


def _decorrelate_lateral(query: SQLQuery) -> SQLQuery:
    """Lift each correlated LEFT JOIN LATERAL whose preconditions hold to a
    plain LEFT JOIN with the correlation moved into the JOIN ON clause.
    Joins that don't match the pattern are left untouched.

    ``parent_aliases`` is computed incrementally per join: each join sees
    the query's ``from_item`` plus every preceding join's alias as the
    immediate parent scope. The lifted ``outer_expr`` of an equality
    correlation must resolve at this set — references to grandparents (or
    further) abort the lift, since a plain LEFT JOIN would no longer see
    them after the LATERAL is stripped."""
    if not isinstance(query, SQLSelectQuery) or not query.joins:
        return query
    parent_aliases: set[str] = set()
    if query.from_item is not None:
        parent_aliases.add(query.from_item.alias)
    new_joins: list[SQLJoin] = []
    changed = False
    for j in query.joins:
        lifted = _try_lift(j, parent_aliases)
        if lifted is None:
            new_joins.append(j)
        else:
            new_joins.append(lifted)
            changed = True
        parent_aliases.add(j.alias)
    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(new_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# RedundantLateralKeywordElim — Drop ``LATERAL`` from a JOIN whose source body
# has no outer-correlation. The ``LATERAL`` keyword is a parser hint declaring
# that the source can reference sibling aliases; when the body is closed, the
# keyword carries no semantics, and Snowflake additionally rejects several
# ``LEFT JOIN LATERAL <table-function-or-wrapper> ON <pred>`` shapes that are
# perfectly valid as plain ``LEFT JOIN``.
#
# Complements ``DecorrelateLateral`` (which handles correlated bodies via
# equality lift to ON) and ``UnwrapRedundantLateral`` (which strips a specific
# structural wrapper pattern). Together they cover: correlated → lift to ON;
# uncorrelated → drop keyword; pattern-shaped wrapper → splice.
#
# Detection uses ``sql_ir_traversal.node_is_closed`` with an empty ``allowed``
# set — the helper already extends scope through nested ``SQLSelectQuery``
# from-items and joins, so a body that defines all its own scope is reported
# closed; a body that references any outer alias is not.
# ---------------------------------------------------------------------------


def _drop_redundant_lateral_keyword(query: SQLQuery) -> SQLQuery:
    if not isinstance(query, SQLSelectQuery) or not query.joins:
        return query
    new_joins: list[SQLJoin] = []
    changed = False
    for j in query.joins:
        if "LATERAL" in j.kind.upper() and _source_is_uncorrelated(j.source):
            new_joins.append(
                SQLJoin(
                    kind=_strip_lateral(j.kind),
                    source=j.source,
                    alias=j.alias,
                    conditions=j.conditions,
                )
            )
            changed = True
        else:
            new_joins.append(j)
    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(new_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


def _source_is_uncorrelated(source: SQLSource) -> bool:
    """True iff ``source``'s body references no aliases outside its own local
    scope — i.e., wrapping its enclosing JOIN with the ``LATERAL`` keyword is
    redundant. Reuses ``node_is_closed`` (which already does proper scope
    tracking through nested ``SQLSelectQuery`` nodes): a SubquerySource is
    closed when ``node_is_closed(source.query, set())`` because the helper
    extends ``allowed`` with the inner query's own FROM/JOIN aliases as it
    descends; a TableFunctionSource is closed iff every arg is."""
    if isinstance(source, SQLSubquerySource):
        return node_is_closed(source.query, set())
    if isinstance(source, SQLTableFunctionSource):
        return all(node_is_closed(arg, set()) for arg in source.args)
    return True


# ---------------------------------------------------------------------------
# DeadLeftJoinElim — Drop LEFT JOINs whose columns are never referenced
# ---------------------------------------------------------------------------


def _drop_dead_left_joins(query: SQLQuery) -> SQLQuery:
    """DeadLeftJoinElim: Remove LEFT JOINs whose alias is never referenced in the query.

    A LEFT JOIN does not filter rows from the base relation. When the joined
    table's alias appears in no SELECT item, WHERE condition, GROUP BY, ORDER BY,
    or other JOIN condition, the join has no observable effect and can be removed.

    Only LEFT JOINs are eligible — INNER JOINs can filter rows, so removing them
    would change semantics even when their columns are unreferenced.
    """
    if not isinstance(query, SQLSelectQuery):
        return query

    live_joins = []
    changed = False
    for join in query.joins:
        if "LEFT" not in join.kind.upper():
            live_joins.append(join)
            continue
        if _alias_used_in_query(join.alias, query):
            live_joins.append(join)
            continue
        # Check the alias isn't used in other joins' conditions that we've already kept
        # (covered by _alias_used_in_query scanning all join conditions including this join's own)
        changed = True  # this join is dead — drop it

    if not changed:
        return query
    return SQLSelectQuery(
        from_item=query.from_item,
        joins=tuple(live_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )




# ---------------------------------------------------------------------------
# DistinctBeforeGroupByElim — Remove DISTINCT from a subquery consumed by an outer GROUP BY
# ---------------------------------------------------------------------------


def _drop_distinct_before_group_by(query: SQLQuery) -> SQLQuery:
    """DistinctBeforeGroupByElim: Remove DISTINCT from a subquery when the only consumer is
    an outer query with GROUP BY and no aggregate functions.

    Pattern:
        SELECT <key cols only, no aggregates>
        FROM (SELECT DISTINCT <key cols>, <other cols> ...) AS s
        GROUP BY <key cols>

    The outer GROUP BY already deduplicates on the key columns. Since the outer SELECT
    uses no aggregate functions, the non-key columns from the inner are irrelevant to the
    result. Removing the inner DISTINCT unblocks DeadSubqueryColumnPrune to prune them.
    """
    if not isinstance(query, SQLSelectQuery):
        return query
    if not query.group_by or query.where or query.joins or query.from_item is None:
        return query
    if not isinstance(query.from_item.source, SQLSubquerySource):
        return query
    inner = query.from_item.source.query
    if not isinstance(inner, SQLSelectQuery) or not inner.distinct:
        return query
    # All outer SELECT items must be simple column refs (no aggregate functions)
    for item in query.select:
        if not isinstance(item.expr, SQLColumnRef):
            return query
    # Safe: remove DISTINCT from inner
    new_inner = SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=inner.select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=False,
        limit=inner.limit,
    )
    return SQLSelectQuery(
        from_item=SQLFromItem(SQLSubquerySource(new_inner), query.from_item.alias),
        joins=query.joins,
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# DeadSubqueryColumnPrune — Remove unused output columns from subqueries
# ---------------------------------------------------------------------------


def _used_cols_for_alias(alias: str | None, root: object) -> set[str]:
    """Collect every column name referenced via `alias` anywhere in `root`.

    Accepts any IR subtree (expr or query). Generic fold: visits every
    reachable node — SELECT, WHERE, GROUP BY, ORDER BY, JOIN conditions,
    LATERAL bodies (whether the body is a SELECT or a UNION), nested EXISTS
    subqueries, SQLValuesSource rows, table-function args, and any future IR
    node containing column refs — uniformly. The visibility analysis is
    therefore correct by construction.
    """
    def step(node: object, acc: set[str]) -> set[str]:
        if isinstance(node, SQLColumnRef) and node.table_alias == alias:
            acc.add(node.column_name)
        return acc
    return fold(root, step, set())


def _try_prune_inner(inner: SQLSelectQuery, used_cols: set[str]) -> SQLSelectQuery | None:
    """Return a pruned copy of inner with unused SELECT items removed, or None if unchanged.

    Refuses to prune if:
    - inner has DISTINCT (every column participates in deduplication — removing one changes the row set)
    - inner has positional GROUP BY (removing items would shift positions)
    - pruning would leave an empty SELECT list
    """
    if inner.distinct:
        return None
    if any(isinstance(g, SQLLiteral) and isinstance(g.value, int) for g in inner.group_by):
        return None
    new_select = tuple(item for item in inner.select if item.alias in used_cols)
    if not new_select or len(new_select) == len(inner.select):
        return None
    return SQLSelectQuery(
        from_item=inner.from_item,
        joins=inner.joins,
        where=inner.where,
        select=new_select,
        group_by=inner.group_by,
        order_by=inner.order_by,
        distinct=inner.distinct,
        limit=inner.limit,
    )


def _prune_dead_subquery_columns(query: SQLQuery) -> SQLQuery:
    """DeadSubqueryColumnPrune: Remove SELECT items from subqueries that are never
    referenced by the outer query.

    Applies to both the FROM subquery and any JOIN subqueries.  Only prunes
    SQLSubquerySource nodes (table sources have no SELECT list to trim).
    Refuses to prune subqueries that still have positional GROUP BY items, as
    removing columns would shift positions.
    """
    if not isinstance(query, SQLSelectQuery):
        return query

    changed = False

    # Prune FROM subquery
    new_from_item = query.from_item
    if (
        query.from_item is not None
        and isinstance(query.from_item.source, SQLSubquerySource)
        and isinstance(query.from_item.source.query, SQLSelectQuery)
    ):
        used = _used_cols_for_alias(query.from_item.alias, query)
        pruned = _try_prune_inner(query.from_item.source.query, used)
        if pruned is not None:
            new_from_item = SQLFromItem(source=SQLSubquerySource(query=pruned), alias=query.from_item.alias)
            changed = True

    # Prune JOIN subqueries
    new_joins = list(query.joins)
    for i, j in enumerate(query.joins):
        if not isinstance(j.source, SQLSubquerySource):
            continue
        if "LATERAL" in j.kind.upper():
            # LATERAL joins have outer-reference semantics; pruning projected
            # columns can change row counts, so skip them entirely.
            continue
        if not isinstance(j.source.query, SQLSelectQuery):
            continue
        used = _used_cols_for_alias(j.alias, query)
        pruned = _try_prune_inner(j.source.query, used)
        if pruned is not None:
            new_joins[i] = SQLJoin(kind=j.kind, source=SQLSubquerySource(query=pruned), alias=j.alias, conditions=j.conditions)
            changed = True

    if not changed:
        return query

    return SQLSelectQuery(
        from_item=new_from_item,
        joins=tuple(new_joins),
        where=query.where,
        select=query.select,
        group_by=query.group_by,
        order_by=query.order_by,
        distinct=query.distinct,
        limit=query.limit,
    )


# ---------------------------------------------------------------------------
# Query traversal helpers
# ---------------------------------------------------------------------------


def _collect_table_refs_in_query(query: SQLQuery) -> set[str]:
    """Collect all SQLTableSource names referenced anywhere in query."""
    def step(node: object, acc: set[str]) -> set[str]:
        if isinstance(node, SQLTableSource):
            acc.add(node.name)
        return acc
    return fold(query, step, set())


def _substitute_table_sources(query: SQLQuery, subs: dict[str, SQLQuery]) -> SQLQuery:
    """Replace every SQLTableSource(name) where name is in subs with a subquery.

    Substituted bodies are themselves walked so any nested SQLTableSource
    that's also in `subs` is inlined transitively.
    """
    if not subs:
        return query

    def rewrite_source(node: object) -> object:
        if isinstance(node, SQLTableSource) and node.name in subs:
            return SQLSubquerySource(_substitute_table_sources(subs[node.name], subs))
        return node
    return transform(query, source_fn=rewrite_source)  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Plan-level reference analysis
# ---------------------------------------------------------------------------


def _compute_external_refs(plan: ExecutionPlan) -> list[set[str]]:
    """
    For each step, return the set of view names that are referenced from
    *outside* that step (other steps' views, any semi-naive loop queries).
    """
    # Collect all refs per step (views + loops within the step itself)
    step_all_refs: list[set[str]] = []
    for step in plan.steps:
        if not isinstance(step, SQLExecutionStep):
            raise TypeError(f"_compute_external_refs expects only SQLExecutionStep, got {type(step)}")
        refs: set[str] = set()
        for v in step.views:
            refs |= _collect_table_refs_in_query(v.query)
        for loop in step.semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.next_delta_query, t.final_query):
                    refs |= _collect_table_refs_in_query(q)
        step_all_refs.append(refs)

    total = len(plan.steps)
    external: list[set[str]] = []
    for i in range(total):
        ext: set[str] = set()
        for j in range(total):
            if j != i:
                ext |= step_all_refs[j]
        # Also include semi-naive loop refs from the current step (they are not
        # rewritten by the optimizer so they count as external consumers)
        current_step = plan.steps[i]
        assert isinstance(current_step, SQLExecutionStep)
        for loop in current_step.semi_naive_loops:
            for t in loop.tables:
                for q in (t.base_query, t.delta_query, t.merge_query, t.next_delta_query, t.final_query):
                    ext |= _collect_table_refs_in_query(q)
        external.append(ext)

    return external


__all__ = ["SQLOptimizer"]
