


import re

import pandas as pd
from pandas import DataFrame
import pyarrow as pa
from dataclasses import dataclass
from typing import Any


from ...std.datetime_format import DateFormatField, DateFormatPart
from .sql_backend import SQLBackend
from .artifacts import SemiNaiveLoop
from .emitter import SQLEmitter

from v0.relationalai.clients.result_helpers import Int128Dtype


@dataclass(frozen=True, slots=True)
class _DuckDBTablePlan:
    accum_view_name: str
    delta_view_name: str
    next_accum_view_name: str
    next_delta_view_name: str
    view_name: str
    state_table_fqn: str
    base_sql: str
    merge_sql: str
    next_delta_sql: str
    final_sql: str


@dataclass(frozen=True, slots=True)
class _DuckDBSemiNaivePlan:
    tables: tuple[_DuckDBTablePlan, ...]

class DuckDBBackend(SQLBackend):

    def __init__(self, session, path: str = ":memory:", schema_name: str = "") -> None:
        super().__init__(path, schema_name)
        self._session = session
        self._last_iter_count: int = 0

    #------------------------------------------------------
    # Dialect handling
    #------------------------------------------------------

    def dialect_name(self) -> str:
        return "duckdb"

    def emit_format_datetime(
        self,
        value_sql: str,
        parts: list[DateFormatPart],
        *,
        value_kind: str,
    ) -> str:
        # DuckDB's STRFTIME with '%g' (millisecond) can return
        # seconds*1000 + ms; legacy snapshots are pinned to the explicit
        # DATE_PART expansion. Apply that only for the single-millisecond
        # token; everything else uses the default STRFTIME path.
        if (
            value_kind == "datetime"
            and len(parts) == 1
            and isinstance(parts[0], DateFormatField)
            and parts[0].kind == "millisecond"
        ):
            return f"CAST((CAST(DATE_PART('milliseconds', {value_sql}) AS BIGINT) % 1000) AS VARCHAR)"
        return super().emit_format_datetime(value_sql, parts, value_kind=value_kind)

    def normalize_schema_name(self, name) -> str:
        # do not use the catalog name when using in-memory databases
        if self.database.startswith(":memory:") and "." in name:
            return name.split(".")[-1]
        return name

    #------------------------------------------------------
    # Metadata fetching
    #------------------------------------------------------

    def fetch_schema(self, database: str, schema: str, table: str) -> dict[str, type | str]:
        # DuckDB's information_schema stores the schema name without the database prefix.
        query = f"""
            SELECT column_name, data_type
            FROM information_schema.columns
            WHERE table_schema = '{schema}'
              AND table_name = '{table}'
            ORDER BY ordinal_position
        """
        try:
            result = self._session.execute(query).fetchall()
            return {row[0]: _map_duckdb_type(row[1]) for row in result}
        except Exception:
            # If INFORMATION_SCHEMA query fails, return empty dict
            return {}

    #------------------------------------------------------
    # SQL execution
    #------------------------------------------------------

    def execute_sql(self, sql: str) -> DataFrame:
        arrow_table = self._session.execute(sql).fetch_arrow_table()

        def _types_mapper(pa_type: pa.DataType):
            if pa.types.is_decimal(pa_type):
                return pd.ArrowDtype(pa_type)
            return None

        try:
            df = arrow_table.to_pandas(types_mapper=_types_mapper)
            return _format_duckdb_columns(df, arrow_table.schema)
        except ValueError as exc:
            # PyArrow rejects duplicate column labels in some queries.
            # Build the frame manually so we preserve duplicate aliases.
            if "non-unique column index" not in str(exc):
                raise
            data_by_position = {
                f"c_{ix}": arrow_table.column(ix).to_pylist()
                for ix in range(arrow_table.num_columns)
            }
            df = pd.DataFrame(data_by_position)
            df.columns = list(arrow_table.column_names)
            return df

    def execute_sql_batch(self, statements: list[str]) -> None:
        if not statements:
            return
        script = ";\n".join(stmt.rstrip().rstrip(";") for stmt in statements) + ";"
        self._session.execute(script)


    #------------------------------------------------------
    # Semi-naive execution
    #------------------------------------------------------

    def build_semi_naive_plan(self, loop: SemiNaiveLoop, emitter: SQLEmitter) -> _DuckDBSemiNaivePlan:
        def _append_suffix(path: str, suffix: str) -> str:
            if "." not in path:
                return f"{path}{suffix}"
            prefix, table = path.rsplit(".", 1)
            return f"{prefix}.{table}{suffix}"

        table_plans = []
        for table in loop.tables:
            formatted = self.format_table_name(table.table_name)
            view_name = emitter._qid_path(formatted)
            state_fqn = emitter._qid_path(_append_suffix(formatted, "__sql2_rec_state"))
            table_plans.append(_DuckDBTablePlan(
                accum_view_name=table.accum_view_name,
                delta_view_name=table.delta_view_name,
                next_accum_view_name=table.next_accum_view_name,
                next_delta_view_name=table.next_delta_view_name,
                view_name=view_name,
                state_table_fqn=state_fqn,
                base_sql=emitter.emit(table.base_query),
                merge_sql=emitter.emit(table.merge_query),
                next_delta_sql=emitter.emit(table.next_delta_query),
                final_sql=emitter.emit(table.final_query),
            ))
        return _DuckDBSemiNaivePlan(tables=tuple(table_plans))

    def execute_semi_naive(self, plan: object) -> None:
        assert isinstance(plan, _DuckDBSemiNaivePlan)
        max_iterations = 1000
        conn = self._session

        def _qid(name: str) -> str:
            escaped = name.replace('"', '""')
            return f'"{escaped}"'

        def _temp_table(name: str, query: str) -> None:
            conn.execute(f"CREATE OR REPLACE TEMP TABLE {_qid(name)} AS\n{query}")

        def _swap_table(name: str, next_name: str) -> None:
            conn.execute(f"DROP TABLE IF EXISTS {_qid(name)}")
            conn.execute(f"ALTER TABLE {_qid(next_name)} RENAME TO {_qid(name)}")

        for tp in plan.tables:
            _temp_table(tp.accum_view_name, tp.base_sql)
            _temp_table(tp.delta_view_name, tp.base_sql)

        # `_last_iter_count` records the number of iterations the most
        # recent semi-naive loop ran (useful for convergence regression
        # tests; the loop is otherwise opaque from outside the call).
        iter_count = 0
        for iter_count in range(1, max_iterations + 1):
            total_rows = 0
            for tp in plan.tables:
                _temp_table(tp.next_accum_view_name, tp.merge_sql)
                _temp_table(tp.next_delta_view_name, tp.next_delta_sql)
                row = conn.execute(f"SELECT COUNT(*) FROM {_qid(tp.next_delta_view_name)}").fetchone()
                if row is not None:
                    total_rows += int(row[0])

            if total_rows == 0:
                break

            for tp in plan.tables:
                _swap_table(tp.accum_view_name, tp.next_accum_view_name)
                _swap_table(tp.delta_view_name, tp.next_delta_view_name)
        self._last_iter_count = iter_count

        for tp in plan.tables:
            conn.execute(f"CREATE OR REPLACE TABLE {tp.state_table_fqn} AS\n{tp.final_sql}")
            conn.execute(f"CREATE OR REPLACE VIEW {tp.view_name} AS\nSELECT * FROM {tp.state_table_fqn}")
            conn.execute(f"DROP TABLE IF EXISTS {_qid(tp.accum_view_name)}")
            conn.execute(f"DROP TABLE IF EXISTS {_qid(tp.delta_view_name)}")
            conn.execute(f"DROP TABLE IF EXISTS {_qid(tp.next_accum_view_name)}")
            conn.execute(f"DROP TABLE IF EXISTS {_qid(tp.next_delta_view_name)}")

#------------------------------------------------------
# Helpers
#------------------------------------------------------

_SIGNED_INT_DTYPES = {
    False: {8: "int8", 16: "int16", 32: "int32", 64: "int64"},
    True: {8: "Int8", 16: "Int16", 32: "Int32", 64: "Int64"},
}
_UNSIGNED_INT_DTYPES = {
    False: {8: "uint8", 16: "uint16", 32: "uint32", 64: "uint64"},
    True: {8: "UInt8", 16: "UInt16", 32: "UInt32", 64: "UInt64"},
}

def _format_duckdb_columns(result_frame: pd.DataFrame, arrow_schema: pa.Schema) -> pd.DataFrame:
    for field in arrow_schema:
        col = field.name
        series = result_frame[col]
        mask = series.isna()
        if bool(mask.all()):
            result_frame[col] = series.astype("float64")
            continue
        any_null = bool(mask.any())
        pa_type = field.type
        if pa.types.is_decimal(pa_type):
            if pa_type.scale == 0:  # integer-like
                series = _cast_integer_column(series, pa_type.precision, any_null=any_null)
        elif pa.types.is_integer(pa_type):
            series = _cast_arrow_integer_column(series, pa_type, any_null=any_null)
        result_frame[col] = series
    return result_frame

def _cast_integer_column(series: pd.Series, precision: int, *, any_null: bool) -> pd.Series:
    """Cast a numeric pandas Series to Int64 or Int128 depending on precision."""
    if any_null:
        return series.astype(Int128Dtype())
    if precision <= 19:
        return series.astype("int64")
    return series.astype(Int128Dtype())

def _cast_arrow_integer_column(series: pd.Series, pa_type: pa.DataType, *, any_null: bool) -> pd.Series:
    """Cast a pandas Series to a nullable integer dtype that matches the Arrow type."""
    if any_null:
        return series.astype(Int128Dtype())
    bit_width = getattr(pa_type, "bit_width", 64)
    if bit_width > 64:
        return series.astype(Int128Dtype())
    if pa.types.is_unsigned_integer(pa_type):
        unsigned_dtype: Any = _UNSIGNED_INT_DTYPES[False].get(bit_width, "uint64")
        return series.astype(unsigned_dtype)
    signed_dtype: Any = _SIGNED_INT_DTYPES[False].get(bit_width, "int64")
    return series.astype(signed_dtype)


# Type mapping from DuckDB types to Python types
DUCKDB_TYPE_MAP: dict[str, type | str] = {
    'VARCHAR': str,
    'TEXT': str,
    'CHAR': str,
    'STRING': str,
    'INTEGER': int,
    'BIGINT': int,
    'SMALLINT': int,
    'TINYINT': int,
    'INT': int,
    'INT4': int,
    'INT8': int,
    'HUGEINT': int,
    'DOUBLE': float,
    'FLOAT': float,
    'REAL': float,
    'FLOAT4': float,
    'FLOAT8': float,
    'BOOLEAN': bool,
    'BOOL': bool,
    'DATE': 'Date',
    'TIMESTAMP': 'DateTime',
    'TIMESTAMPTZ': 'DateTime',
    'TIMESTAMP WITH TIME ZONE': 'DateTime',
    'TIMESTAMP_NS': 'DateTime',
    'TIME': 'DateTime',
    'DECIMAL': 'Decimal',
    'NUMERIC': 'Decimal',
}

def _map_duckdb_type(dtype: str) -> type | str:
    base_type = dtype.upper()

    # Handle DECIMAL with precision/scale
    if base_type.startswith('DECIMAL'):
        pattern = r'^([a-zA-Z0-9_]+)\(\s*([0-9]+)\s*,\s*([0-9]+)\s*\)$'
        match = re.search(pattern, dtype)
        if match:
            _, precision, scale = match.group(1), match.group(2), match.group(3)
            return f"Decimal({precision},{scale})"
        raise ValueError(f"Invalid decimal type name: {dtype}.")

    return DUCKDB_TYPE_MAP.get(base_type, str)
