from __future__ import annotations

from dataclasses import dataclass, field
from ...metamodel import metamodel as mm
from .sql_ir import SQLCreateView, SQLQuery

#------------------------------------------------------
# Common abstractions
#------------------------------------------------------

class CompilationArtifact:
    """ Common abstraction for all artifacts produced during compilation. """
    def __str__(self) -> str:
        try:
            from .pprint import pprint
            return pprint(self)
        except Exception as e:
            print(e)
            return object.__repr__(self)


#------------------------------------------------------
# Catalog
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class StoreColumn(CompilationArtifact):
    name: str
    sql_type: str | None
    semantic_name: str | None = None


@dataclass(frozen=True, slots=True)
class EntityStore(CompilationArtifact):
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ("_id",)
    interval_s: int = 0


@dataclass(frozen=True, slots=True)
class RelationStore(CompilationArtifact):
    relation_id: int
    relation_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    key_columns: tuple[str, ...] = ()
    interval_s: int = 0


@dataclass(frozen=True, slots=True)
class DataStore(CompilationArtifact):
    """ Represents a metamodel Table (which can also be a Data node). """
    # id of the mm.Table node from which this DataStore was derived.
    type_id: int
    type_name: str
    object_name: str
    columns: tuple[StoreColumn, ...]
    # the uri of the actual SQL table represented by the mm.Table (if it is not a Data node)
    source_name: str | None = None
    # if mm.Table is a Data node, this contains the rows of data; each element of the tuple
    # is a row that contains a row index plus the remaining data.
    rows: tuple[tuple[object | None, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class Catalog(CompilationArtifact):
    entity_stores: dict[int, EntityStore]
    entity_store_by_name: dict[str, EntityStore]
    relation_stores: dict[int, RelationStore]
    relation_store_by_name: dict[str, RelationStore]
    data_stores: dict[int, DataStore]
    data_store_by_name: dict[str, DataStore]

    # Catalog building (aka denormalization) folds certain property relations into their
    # owner entity's store (i.e. the relation becomes a column in the entity's table). This
    # maps the property relation.id to the id of the entity type that owns it.
    folded_property_relation_to_owner_entity_type: dict[int, int]
    # Metamodel Table columns are relations. This maps those column relation ids to the
    # type id of the DataStore that the CatalogBuilder creates for that metamodel Table.
    # Note that those relations map to StoreColumns in the DataStore.
    data_column_relation_to_store_type_id: dict[int, int]

    def entity_store(self, ref: str | mm.Relation) -> EntityStore:
        if isinstance(ref, mm.Relation) and ref.id in self.entity_stores:
            return self.entity_stores[ref.id]
        type_name = ref if isinstance(ref, str) else ref.name
        if type_name in self.entity_store_by_name:
            return self.entity_store_by_name[type_name]
        raise KeyError(f"Unknown entity store for {type_name!r}.")

    def relation_store(self, ref: mm.Relation | str) -> RelationStore:
        if isinstance(ref, mm.Relation) and self.is_data_column(ref):
            raise KeyError(f"Data column relation {ref.name!r} does not have a sql9 relation store.")
        if isinstance(ref, mm.Relation) and ref.id in self.relation_stores:
            return self.relation_stores[ref.id]
        relation_name = ref if isinstance(ref, str) else ref.name
        if relation_name in self.relation_store_by_name:
            return self.relation_store_by_name[relation_name]
        raise KeyError(f"Unknown relation store for {relation_name!r}.")

    def data_store(self, ref: mm.Data | mm.Table | str) -> DataStore:
        if isinstance(ref, mm.Table) and ref.id in self.data_stores:
            return self.data_stores[ref.id]
        type_name = ref if isinstance(ref, str) else ref.name
        if type_name in self.data_store_by_name:
            return self.data_store_by_name[type_name]
        raise KeyError(f"Unknown data store for {type_name!r}.")

    def is_folded_property(self, relation: mm.Relation) -> bool:
        return relation.id in self.folded_property_relation_to_owner_entity_type

    def owner_store_for_property(self, relation: mm.Relation) -> EntityStore:
        owner_type_id = self.folded_property_relation_to_owner_entity_type[relation.id]
        if owner_type_id in self.entity_stores:
            return self.entity_stores[owner_type_id]
        raise KeyError(f"Missing owner store for folded property {relation.name!r}.")

    def is_data_column(self, relation: mm.Relation) -> bool:
        return relation.id in self.data_column_relation_to_store_type_id

    def data_store_for_column(self, relation: mm.Relation) -> DataStore:
        store_type_id = self.data_column_relation_to_store_type_id[relation.id]
        if store_type_id in self.data_stores:
            return self.data_stores[store_type_id]
        raise KeyError(f"Missing data store for column relation {relation.name!r}.")

    def physical_anchor_id(self, relation_id: int, model: mm.Model) -> int:
        """Storage-level anchor: folded properties/data columns → owner type_id; else self."""
        relation = next((r for r in model.relations if r.id == relation_id), None)
        if relation is not None:
            if relation.id in self.folded_property_relation_to_owner_entity_type:
                return self.folded_property_relation_to_owner_entity_type[relation.id]
            if relation.id in self.data_column_relation_to_store_type_id:
                return self.data_column_relation_to_store_type_id[relation.id]
        return relation_id

    def store_for_relation(self, relation: mm.Relation) -> EntityStore | RelationStore | DataStore | None:
        if relation.id in self.data_stores:
            return self.data_stores[relation.id]
        if relation.id in self.folded_property_relation_to_owner_entity_type:
            owner_type_id = self.folded_property_relation_to_owner_entity_type[relation.id]
            if owner_type_id in self.entity_stores:
                return self.entity_stores[owner_type_id]
        if relation.id in self.entity_stores:
            return self.entity_stores[relation.id]
        if relation.id in self.relation_stores:
            return self.relation_stores[relation.id]
        return None

def create_catalog(
        entity_stores: list[EntityStore] = [],
        relation_stores: list[RelationStore] = [],
        data_stores: list[DataStore] = [],
        folded_property_relation_to_owner_entity_type: dict[int, int] = {},
        data_column_relation_to_store_type_id: dict[int, int] = {}
) -> Catalog:
    """Helper to create an empty catalog with the correct types."""
    return Catalog(
        entity_stores={ store.type_id: store for store in entity_stores },
        entity_store_by_name={ store.object_name: store for store in entity_stores },
        relation_stores={ store.relation_id: store for store in relation_stores },
        relation_store_by_name={ store.object_name: store for store in relation_stores },
        data_stores={ store.type_id: store for store in data_stores },
        data_store_by_name={ store.object_name: store for store in data_stores },
        folded_property_relation_to_owner_entity_type=folded_property_relation_to_owner_entity_type,
        data_column_relation_to_store_type_id=data_column_relation_to_store_type_id,
    )

#------------------------------------------------------
# Stratifier
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SCCGraph(CompilationArtifact):
    """SCC-level dependency graph exposed for backend routing.

    ``sccs[i]`` is the set of relation_ids in SCC i.
    ``dependencies[i]`` is the set of SCC indexes that SCC i depends on
    (i.e. must be computed before SCC i).
    ``has_self_loop[i]`` is True when SCC i has a recursive self-edge.
    ``stratum_index_by_scc[i]`` maps each SCC to its containing stratum index.
    """

    sccs: tuple[tuple[int, ...], ...]
    dependencies: tuple[frozenset[int], ...]
    has_self_loop: tuple[bool, ...]
    stratum_index_by_scc: tuple[int, ...]

#------------------------------------------------------
# Reasoner Router
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class ExecutionBlock(CompilationArtifact):
    """A maximal run of same-reasoner SCCs with no forced boundary between them.

    SQL blocks never cross a stratum boundary (negation requires sequential
    SQL execution).  Logic blocks may span multiple strata.

    ``input_relation_ids``  — relation_ids produced by a *different*-reasoner
    block that this block reads.  Populated for future parallel dispatch; unused
    during sequential execution.

    ``output_relation_ids`` — relation_ids produced by this block that a
    *different*-reasoner block reads.

    ``interval_s`` — refresh interval in seconds; 0 means no scheduled
    refresh.  Derived from the catalog passed to :meth:`ReasonerRouter.route`
    and used as a block-splitting criterion so that tables with distinct refresh
    cadences land in separate plan entries.
    """

    index: int
    reasoner_type: str  # lowercased reasoner type, e.g. "sql", "logic"
    relation_ids: tuple[int, ...]
    recursive: bool
    recursive_component_relation_ids: tuple[tuple[int, ...], ...]
    input_relation_ids: tuple[int, ...]
    output_relation_ids: tuple[int, ...]
    interval_s: int = 0

#------------------------------------------------------
# Coalescer
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class Target(CompilationArtifact):
    kind: str # "entity" or "relation"
    object_name: str # the table/view name this target writes to
    column_names: tuple[str, ...]
    key_columns: tuple[str, ...]
    anchor_id: int # type id (if kind is entity) or relation id
    relation_ids: tuple[int, ...]

@dataclass(frozen=True, slots=True)
class PlannedTarget(CompilationArtifact):
    target: Target
    tasks: tuple[mm.Task, ...] # tasks that write into this target
    recursive: bool
    recursive_component_relation_ids: tuple[int, ...] = ()

@dataclass(frozen=True, slots=True)
class CoalescedBlock(CompilationArtifact):
    """Coalescer output for one execution block (SQL or Logic)."""
    index: int
    reasoner_type: str  # lowercased reasoner type, e.g. "sql", "logic"
    targets: tuple[PlannedTarget, ...]
    recursive: bool
    input_relation_ids: tuple[int, ...]
    output_relation_ids: tuple[int, ...]
    interval_s: int = 0

#------------------------------------------------------
# Storage Normalizer
#------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TargetPlan(CompilationArtifact):
    target: Target
    tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True

@dataclass(frozen=True, slots=True)
class RecursiveTargetPlan(CompilationArtifact):
    target: Target
    seed_tasks: tuple[mm.Logical, ...]
    recursive_tasks: tuple[mm.Logical, ...]
    output_table: mm.Table
    marker_table: mm.Table
    prior_table: mm.Table | None = None
    requires_coalesce: bool = True

@dataclass(frozen=True, slots=True)
class RecursiveComponentPlan(CompilationArtifact):
    relation_ids: tuple[int, ...]
    targets: tuple[RecursiveTargetPlan, ...]


@dataclass(slots=True)
class BlockVersionState(CompilationArtifact):
    latest_tables_by_relation_id: dict[int, mm.Table]
    entry_tables_by_relation_id: dict[int, mm.Table]
    materialized_tables_by_object_name: dict[str, mm.Table] = field(default_factory=dict)
    stage_numbers_by_object_name: dict[str, int] = field(default_factory=dict)

    def latest_table_for(self, relation_id: int) -> mm.Table | None:
        return self.latest_tables_by_relation_id.get(relation_id)

    def entry_table_for(self, relation_id: int) -> mm.Table | None:
        return self.entry_tables_by_relation_id.get(relation_id)

    def prior_table_for(self, object_name: str) -> mm.Table | None:
        return self.materialized_tables_by_object_name.get(object_name)

    def next_output_name(self, object_name: str) -> int:
        next_stage = self.stage_numbers_by_object_name.get(object_name, 0) + 1
        self.stage_numbers_by_object_name[object_name] = next_stage
        return next_stage

    def materialize_object(self, object_name: str, output_table: mm.Table) -> None:
        self.materialized_tables_by_object_name[object_name] = output_table

    def bind_relation_table(self, relation_id: int, table: mm.Table) -> None:
        self.latest_tables_by_relation_id[relation_id] = table


@dataclass(frozen=True, slots=True)
class NormalizedSQLBlock(CompilationArtifact):
    """One SQL execution unit.

    ``items`` contains ``TargetPlan`` / ``RecursiveComponentPlan`` entries
    produced by the storage normalizer.
    """

    index: int
    items: tuple[TargetPlan | RecursiveComponentPlan, ...]
    recursive: bool = False
    input_relation_ids: tuple[int, ...] = ()
    output_relation_ids: tuple[int, ...] = ()


#------------------------------------------------------
# Lowerer
#------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SemiNaiveTable(CompilationArtifact):
    """Semi-naive evaluation plan for one recursive target.

    Invariant
    ---------
    ``delta_i = accum_{i+1} \\ accum_i`` — the delta at iteration ``i`` is, by
    definition, the new tuples that this iteration adds to ``accum``. The
    lowerer encodes this directly: ``next_delta_query`` is constructed as
    ``next_accum EXCEPT accum`` over views the runtime materializes. Runtime
    code never re-derives the difference, so backends inherit the convergence
    semantics for free and partial-column rule variants (e.g. NULL-padded
    aggregate-only branches) cannot leak through a full-row set comparison.

    Fields
    ------
    base_query
        Initial accumulation (seeds + recursive-rule branches against empty
        recursive inputs).
    delta_query
        Raw recursive rule output. May produce partial-column rows when a
        target has multiple rules with disjoint column subsets — those rows
        are reconciled into accum's column shape inside ``merge_query``. Kept
        as a field so the optimizer can walk it independently; not consumed
        directly by the runtime convergence loop.
    merge_query
        ``next_accum`` — existing accum coalesced with ``delta_query``. Has
        the same column shape as accum.
    next_delta_query
        ``next_accum EXCEPT accum`` — the actual change between accum states.
        This is what the runtime counts to detect a fixpoint and what gets
        swapped into ``delta_view`` for the next iteration's rule firings.
    final_query
        How to project the finalized accum into the public view.
    """
    table_name: str
    columns: tuple[str, ...]
    base_query: SQLQuery
    delta_query: SQLQuery
    merge_query: SQLQuery
    next_delta_query: SQLQuery
    final_query: SQLQuery
    accum_view_name: str
    delta_view_name: str
    next_accum_view_name: str
    next_delta_view_name: str
    # Typed columns for the table_name target — used to emit schema-only DDL at
    # async-install time without depending on upstream tables. Same length and
    # order as `columns`.
    column_types: tuple["StoreColumn", ...] = ()


@dataclass(frozen=True, slots=True)
class SemiNaiveLoop(CompilationArtifact):
    tables: tuple[SemiNaiveTable, ...] = ()

@dataclass(frozen=True, slots=True)
class View(SQLCreateView):
    # Typed columns of this View's output — used to emit schema-only DDL at
    # async-install time without resolving the inner SELECT against upstream
    # tables. Empty when the View doesn't write to a catalog store (e.g. seed
    # views built via VALUES, which never need schema-only materialization).
    column_types: tuple["StoreColumn", ...] = ()

@dataclass(frozen=True, slots=True)
class PlannedSemiNaiveLoop(CompilationArtifact):
    table_names: tuple[str, ...]
    plan: object  # opaque, dialect-specific — each orchestrator knows how to consume it
    install_sql: tuple[str, ...] = ()  # DDL to create empty output tables at schema-install time

@dataclass(frozen=True, slots=True)
class PlannedSQLStep(CompilationArtifact):
    view_names: tuple[str, ...]
    # ``None`` entries mean "no refresh needed" (e.g. logical views).
    # Aligned with ``view_names`` / ``fqns``.
    refresh_sql_batch: tuple[str | None, ...]
    fqns: tuple[str, ...]
    semi_naive_loops: tuple[PlannedSemiNaiveLoop, ...]
    install_sql_batch: tuple[str, ...] = ()

@dataclass(frozen=True, slots=True)
class SQLExecutionStep(CompilationArtifact):
    views: tuple[View, ...] = ()
    semi_naive_loops: tuple[SemiNaiveLoop, ...] = ()


@dataclass(frozen=True, slots=True)
class LogicBlock(CompilationArtifact):
    """All information the logic reasoner needs to compile and execute a block.

    ``install_root``         — task subtree compiled and installed into the LR backend.
    ``export_query``         — task that reads results back out of the LR backend.
    ``output_table_names``   — catalog object names the LR backend materializes.
    """

    install_root: mm.Task
    export_query: mm.Task
    output_table_names: tuple[str, ...]


# A step targets exactly one backend: SQL engine or logic reasoner.
ExecutionStep = SQLExecutionStep | LogicBlock

@dataclass(frozen=True, slots=True)
class ExecutionPlan(CompilationArtifact):
    steps: tuple[ExecutionStep, ...] = ()


@dataclass(frozen=True, slots=True)
class ModelPlan(CompilationArtifact):
    catalog: Catalog
    blocks: tuple[CoalescedBlock, ...]
    version_state: BlockVersionState
    seed_object_names: tuple[str, ...] = ()
