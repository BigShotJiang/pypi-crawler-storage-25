"""Reasoner-aware execution block routing for the SQL/Logic mixed pipeline."""
from __future__ import annotations

from bisect import insort
from typing import TYPE_CHECKING

from ...metamodel import metamodel as mm
from .artifacts import ExecutionBlock
from .stratifier import SCCGraph

if TYPE_CHECKING:
    from .artifacts import Catalog

# Lowercased name of the implicit reasoner: any relation not explicitly pinned to a
# specific reasoner will be computed by this one (unless escalated by the WriterUnifier).
DEFAULT_REASONER_TYPE = "sql"

# Reasoner types that must not cross negation-stratum boundaries during block grouping.
_STRATUM_BOUNDED = {"sql"}


class ReasonerRouter:
    """Partitions the SCC dependency graph into maximal same-reasoner blocks.

    Uses a reasoner-aware Kahn's topological sort: when choosing the next SCC
    from the ready queue, SCCs of the current reasoner (and, for SQL, the
    current stratum) are preferred over switching to a different reasoner.
    This maximizes logic block size while preserving all dependency constraints.
    """

    def route(
        self,
        scc_graph: SCCGraph,
        model: mm.Model,
        catalog: "Catalog",
        forced_reasoners: dict[int, str] | None = None,
    ) -> tuple[ExecutionBlock, ...]:
        scc_reasoner_types = self._label_reasoner_types(
            scc_graph, model, forced_reasoners or {}
        )
        scc_interval_labels = self._label_scc_intervals(scc_graph, catalog)
        order = self._reasoner_aware_kahn(scc_graph, scc_reasoner_types, scc_interval_labels)
        return self._build_blocks(order, scc_graph, scc_reasoner_types, scc_interval_labels)

    def _label_reasoner_types(
        self,
        scc_graph: SCCGraph,
        model: mm.Model,
        forced_reasoners: dict[int, str],
    ) -> tuple[str, ...]:
        """Return a reasoner type label for every SCC in scc_graph.

        ``forced_reasoners`` is a relation_id → reasoner map already propagated
        across SCC members (see ``_resolve_forced_reasoners`` in the executor),
        so a forced rid implies every member of its SCC has the same forcing.
        Merging it on top of the model's pinning therefore preserves the
        mixed-reasoner invariant.
        """
        relation_to_type = {**model.reasoner_type_by_relation_id(), **forced_reasoners}

        result: list[str] = []
        for scc in scc_graph.sccs:
            reasoner_types = {relation_to_type.get(rid, DEFAULT_REASONER_TYPE).lower() for rid in scc}
            if len(reasoner_types) > 1:
                raise ValueError(
                    f"SCC contains relation_ids with mixed reasoner types {scc}. "
                    "All relations in a strongly-connected component must target "
                    "the same reasoner."
                )
            result.append(reasoner_types.pop())
        return tuple(result)

    def _label_scc_intervals(
        self,
        scc_graph: SCCGraph,
        catalog: "Catalog",
    ) -> tuple[int, ...]:
        """Return a refresh interval label (seconds) for every SCC in scc_graph.

        For each SCC the interval is the minimum non-zero interval among its
        relation_ids, or 0 if all are 0 / no intervals are configured.
        Mutually-recursive SCCs spanning stores with conflicting intervals get
        the tightest (smallest) non-zero value — conservative but correct.
        A warning is emitted when this override occurs.
        """
        interval_map = self._build_interval_map(catalog)
        result: list[int] = []
        for scc in scc_graph.sccs:
            non_zero = {rid: interval_map[rid] for rid in scc if rid in interval_map}
            chosen = min(non_zero.values()) if non_zero else 0
            if len(set(non_zero.values())) > 1:
                self._warn_conflicting_intervals(non_zero, chosen, catalog)
            result.append(chosen)
        return tuple(result)

    def _reasoner_aware_kahn(
        self,
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
        scc_interval_labels: tuple[int, ...],
    ) -> list[int]:
        """Return a topological ordering of SCC indices that minimizes reasoner switches.

        Identical to standard Kahn's algorithm except that _pick_next replaces
        the usual "pop any ready node" step with a reasoner- and stratum-aware
        selection.  The ready list is kept sorted so that tie-breaking is
        deterministic.
        """
        n = len(scc_graph.sccs)
        indegree = [len(deps) for deps in scc_graph.dependencies]

        # adjacency[j] = SCCs that depend on j (successors)
        adjacency: dict[int, list[int]] = {i: [] for i in range(n)}
        for i, deps in enumerate(scc_graph.dependencies):
            for j in deps:
                adjacency[j].append(i)

        ready: list[int] = sorted(i for i in range(n) if indegree[i] == 0)
        order: list[int] = []

        while ready:
            chosen = self._pick_next(ready, order, scc_graph, scc_reasoner_types, scc_interval_labels)
            ready.remove(chosen)
            order.append(chosen)
            for succ in adjacency[chosen]:
                indegree[succ] -= 1
                if indegree[succ] == 0:
                    insort(ready, succ)

        return order

    def _pick_next(
        self,
        ready: list[int],
        order: list[int],
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
        scc_interval_labels: tuple[int, ...],
    ) -> int:
        """Choose the next SCC to emit from the ready list.

        Prefers a candidate that continues the current reasoner run:
        - Must match the reasoner type of the last emitted SCC.
        - For SQL, must also stay within the same stratum (negation stratification
          requires all SCCs in a stratum to be fully computed before the next stratum
          begins; The logic reasoner handles stratification internally so this constraint is
          not applied there).
        - Must share the same refresh interval so different cadences land in separate blocks.

        Falls back to ready[0] (lowest index) when no compatible candidate exists,
        which forces a block boundary and starts a new run deterministically.
        """
        if not order:
            return ready[0]

        current_reasoner_type = scc_reasoner_types[order[-1]]
        current_stratum = scc_graph.stratum_index_by_scc[order[-1]]
        current_interval = scc_interval_labels[order[-1]]

        # Prefer same reasoner; for stratum-bounded reasoners also require same stratum;
        # always require same refresh interval so different cadences land in separate blocks.
        for candidate in ready:
            if scc_reasoner_types[candidate] != current_reasoner_type:
                continue
            if current_reasoner_type in _STRATUM_BOUNDED and scc_graph.stratum_index_by_scc[candidate] != current_stratum:
                continue
            if scc_interval_labels[candidate] != current_interval:
                continue
            return candidate

        # No compatible candidate — must start a new block; pick lowest index.
        return ready[0]

    def _build_blocks(
        self,
        order: list[int],
        scc_graph: SCCGraph,
        scc_reasoner_types: tuple[str, ...],
        scc_interval_labels: tuple[int, ...],
    ) -> tuple[ExecutionBlock, ...]:
        """Convert the ordered SCC list into maximal same-reasoner ExecutionBlocks.

        Consecutive SCCs that share a reasoner type (and, for SQL, a stratum) are
        merged into a single block.  For each block the method also computes:
        - relation_ids: flat list of all relation IDs owned by the block.
        - recursive / recursive_component_relation_ids: whether the block
          contains any recursive SCC and which relation groups participate.
        - input_relation_ids / output_relation_ids: relations that cross a
          reasoner boundary, used for future parallel dispatch between engines.
        """
        if not order:
            return ()

        # Group consecutive compatible SCCs into blocks.
        raw_blocks: list[list[int]] = [[order[0]]]
        for scc_idx in order[1:]:
            last_block = raw_blocks[-1]
            last_scc = last_block[-1]
            last_reasoner_type = scc_reasoner_types[last_scc]
            last_stratum = scc_graph.stratum_index_by_scc[last_scc]
            last_interval = scc_interval_labels[last_scc]

            reasoner_type = scc_reasoner_types[scc_idx]
            stratum = scc_graph.stratum_index_by_scc[scc_idx]
            interval = scc_interval_labels[scc_idx]

            same_reasoner = reasoner_type == last_reasoner_type
            # Stratum-bounded reasoners (e.g. SQL) must not cross stratum boundaries.
            same_stratum_or_unbounded = reasoner_type not in _STRATUM_BOUNDED or stratum == last_stratum
            same_interval = interval == last_interval

            if same_reasoner and same_stratum_or_unbounded and same_interval:
                last_block.append(scc_idx)
            else:
                raw_blocks.append([scc_idx])

        # Map SCC index → block index for cross-block wiring.
        scc_to_block: dict[int, int] = {
            scc_idx: block_idx
            for block_idx, scc_indexes in enumerate(raw_blocks)
            for scc_idx in scc_indexes
        }

        # Compute cross-reasoner input/output relation sets.
        block_inputs: list[set[int]] = [set() for _ in raw_blocks]
        block_outputs: list[set[int]] = [set() for _ in raw_blocks]

        for i, deps in enumerate(scc_graph.dependencies):
            block_i = scc_to_block[i]
            for j in deps:
                block_j = scc_to_block[j]
                if block_i != block_j and scc_reasoner_types[i] != scc_reasoner_types[j]:
                    # SCC j is in a different-reasoner block that block_i reads.
                    block_j_relation_ids = set(scc_graph.sccs[j])
                    block_inputs[block_i].update(block_j_relation_ids)
                    block_outputs[block_j].update(block_j_relation_ids)

        blocks: list[ExecutionBlock] = []
        for block_idx, scc_indexes in enumerate(raw_blocks):
            reasoner_type = scc_reasoner_types[scc_indexes[0]]
            all_relation_ids: list[int] = [
                rid
                for scc_idx in scc_indexes
                for rid in scc_graph.sccs[scc_idx]
            ]

            # Each recursive SCC's component is exactly the SCC itself
            # (already sorted by Tarjan's algorithm).
            seen_components: set[tuple[int, ...]] = set()
            recursive_components: list[tuple[int, ...]] = []
            is_recursive = False
            for scc_idx in scc_indexes:
                if not (scc_graph.has_self_loop[scc_idx] or len(scc_graph.sccs[scc_idx]) > 1):
                    continue
                is_recursive = True
                component_t = scc_graph.sccs[scc_idx]
                if component_t not in seen_components:
                    recursive_components.append(component_t)
                    seen_components.add(component_t)

            blocks.append(ExecutionBlock(
                index=block_idx,
                reasoner_type=reasoner_type,
                relation_ids=tuple(sorted(all_relation_ids)),
                recursive=is_recursive,
                recursive_component_relation_ids=tuple(recursive_components),
                input_relation_ids=tuple(sorted(block_inputs[block_idx])),
                output_relation_ids=tuple(sorted(block_outputs[block_idx])),
                interval_s=scc_interval_labels[scc_indexes[0]],
            ))

        return tuple(blocks)

    @staticmethod
    def _build_interval_map(catalog: "Catalog") -> dict[int, int]:
        """Map every SCC-graph node ID to the refresh interval of its target store.

        Node IDs are relation_ids (regular and folded-property relations) and
        entity type_ids (construct nodes). Returns only entries with non-zero
        intervals so callers can short-circuit with ``if interval_map``.
        """
        entity_intervals: dict[int, int] = {s.type_id: s.interval_s for s in catalog.entity_stores.values()}
        result: dict[int, int] = {s.relation_id: s.interval_s for s in catalog.relation_stores.values()}
        result.update(entity_intervals)
        for rid, type_id in catalog.folded_property_relation_to_owner_entity_type.items():
            result[rid] = entity_intervals[type_id]
        return {k: v for k, v in result.items() if v != 0}

    @staticmethod
    def _warn_conflicting_intervals(
        rid_to_interval: dict[int, int],
        chosen: int,
        catalog: "Catalog",
    ) -> None:
        from relationalai.util.error import warn
        name_by_rid: dict[int, str] = {}
        for s in catalog.relation_stores.values():
            name_by_rid[s.relation_id] = s.relation_name
        for s in catalog.entity_stores.values():
            name_by_rid[s.type_id] = s.type_name
        names_with_intervals = ", ".join(
            f"{name_by_rid.get(rid, f'node_{rid}')} ({iv} s)"
            for rid, iv in sorted(rid_to_interval.items(), key=lambda x: name_by_rid.get(x[0], ""))
        )
        warn(
            "ConflictingRefreshIntervals",
            f"Mutually recursive relations have conflicting refresh intervals: {names_with_intervals}. "
            f"They must be refreshed together; using the minimum interval of {chosen} seconds for all.",
        )


__all__ = ["ReasonerRouter", "ExecutionBlock"]
