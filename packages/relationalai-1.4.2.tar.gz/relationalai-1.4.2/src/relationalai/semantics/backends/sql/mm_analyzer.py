"""SQL-backend-specific metamodel analyzers.

Hosts MM-level analyses whose only consumer today is the SQL backend.
Kept here (rather than in ``metamodel/metamodel_analyzer.py``) because
the design pressure for these analyses originates in SQL lowering
concerns; other backends do not currently use them.
"""

from __future__ import annotations
from collections import defaultdict

from ...metamodel.metamodel import (
    Aggregate, Construct, Logical, Lookup, Match, Task, Union, Update, Var,
)
from ...metamodel.rewriter import NO_WALK
from ...metamodel.builtins import builtins as b
from ...metamodel.metamodel_analyzer import (
    Groundness,
    VarFinder,
    _extend_outputs_via_equality,
)


#------------------------------------------------------
# Per-key anchoring (keyed pre-aggregate gate)
#------------------------------------------------------


class PerKeyAnchoring(Groundness):
    """Determine which of an aggregate's ``per`` keys are *anchored* by the
    aggregate body alone — i.e., the body re-grounds them without depending
    on their outer bindings. Used by the SQL lowerer's keyed-pre-aggregate
    emit path to decide which outer per-key bindings can be safely stripped
    before the body is lowered.

    Inherits ``Groundness``'s complete groundedness logic: fixed-point
    bidirectional-equality propagation in ``enter_logical``, functional-Lookup
    output grounding, Aggregate / Construct handling. Overrides only
    ``enter_union`` / ``enter_match`` to *intersect* the per-branch grounded
    sets, so the answer to "anchored in every branch" has the right semantics
    for the lowerer's keyed-pre-aggregate decision (stripping a per-key is
    only safe when every branch of the body re-grounds it).

    A per-key K is reported anchored iff the body's groundedness analysis,
    seeded with ``seed_grounded_ids`` (typically: outer-bound var ids
    minus the per-keys), would re-ground K in every branch.

    NULL-semantics note: anchoring is a purely structural / scope property
    about variable bindings; it does NOT make claims about NULL safety of
    the resulting SQL. Callers that consume the anchored set must still
    respect NULL semantics at their emission site (e.g., LEFT JOIN vs
    INNER JOIN choices, COALESCE-vs-CASE for Match-with-default).
    """

    def analyze_anchoring(
        self,
        body: Task,
        seed_grounded_ids: set[int],
        per_key_ids: set[int],
    ) -> set[int]:
        """Return the subset of ``per_key_ids`` anchored in every branch of
        ``body`` when starting with the vars in ``seed_grounded_ids`` already
        grounded. A per-key id ``k`` is anchored iff every branch grounds
        the corresponding Var via Lookup output, fixed-point equality, or
        any other Groundness rule — independently of its outer binding."""
        # Seed must be set[Var]; resolve from body since Var equality is
        # structural and Var objects for the same var-id appear identically
        # in every reference site within a single MM tree.
        body_vars = VarFinder().find_vars(body)
        seed_grounded = {v for v in body_vars if v.id in seed_grounded_ids}
        self.grounded = set(seed_grounded)
        self.ungrounded_uses = defaultdict(list)
        self.in_isolating_scope = 0
        self.saved_grounded_stack = []
        # Intersection across branches accumulates here when the body is
        # (or contains) a Union/Match. None means "no Union/Match seen
        # yet"; fall back to the linear grounded set in that case.
        self._anchored_grounded: set[Var] | None = None
        self(body)
        final: set[Var] = (
            self._anchored_grounded if self._anchored_grounded is not None
            else self.grounded
        )
        return {k_id for k_id in per_key_ids if any(v.id == k_id for v in final)}

    # Override Groundness's exit / per-task handlers to no-ops. Our
    # ``enter_logical`` below already does all the grounding work we need;
    # the inherited handlers do error-reporting and redundant grounding
    # that also indexes ``fields[i]`` directly and so crashes on the
    # property-shape Lookups (``len(args) == len(fields) + 1``) that arise
    # in lowering-time MM trees. No-oping them makes the analyzer robust
    # against the same shape mismatch and limits this class's contract to
    # "what is grounded by enter_logical only".
    def lookup(self, lookup: Lookup):  # type: ignore[override]
        return None

    def update(self, update: Update):  # type: ignore[override]
        return None

    def construct(self, construct: Construct):  # type: ignore[override]
        return None

    def aggregate(self, aggregate: Aggregate):  # type: ignore[override]
        return None

    def enter_logical(self, logical: Logical):
        """Defensive variant of ``Groundness.enter_logical``: tolerates
        Lookup ``args``/``fields`` arity mismatches that arise in
        lowering-time MM trees (PyRel emits property-style lookups as
        ``Lookup(rel, [entity, value])`` where the relation has only the
        value field declared). Maps the trailing args onto the declared
        fields (property convention: ``args[0]`` is the implicit entity
        input); when no clean mapping exists, treats the lookup as
        ungrounding-only (conservative)."""
        if logical.scope or logical.optional:
            self.saved_grounded_stack.append(self.grounded.copy())
            self.in_isolating_scope += 1

        grounded_here: set[Var] = set()
        changed = True
        while changed:
            changed = False
            prev_size = len(grounded_here)
            for task in logical.body:
                if isinstance(task, Lookup):
                    # Equality: bidirectional grounding (same as Groundness).
                    if task.relation.id == b.core.eq.id and len(task.args) == 2:
                        left, right = task.args
                        left_is_var = isinstance(left, Var)
                        right_is_var = isinstance(right, Var)
                        left_grounded = not left_is_var or left in self.grounded or left in grounded_here
                        right_grounded = not right_is_var or right in self.grounded or right in grounded_here
                        if left_grounded and right_is_var and right not in grounded_here:
                            grounded_here.add(right)  # type: ignore[arg-type]
                        if right_grounded and left_is_var and left not in grounded_here:
                            grounded_here.add(left)  # type: ignore[arg-type]
                    else:
                        # Normal lookup. Map args onto fields with the
                        # property-shape rule (args[0] implicit input
                        # when args has one extra entry vs fields).
                        n_args = len(task.args)
                        n_fields = len(task.relation.fields)
                        if n_args == n_fields:
                            arg_offset = 0
                        elif n_args == n_fields + 1:
                            # Property convention: args[0] is the implicit
                            # entity input; args[1..] align with fields[0..].
                            arg_offset = 1
                        else:
                            # Arity unknown — skip this lookup for
                            # anchoring purposes (conservative).
                            continue
                        for i, arg in enumerate(task.args):
                            if not isinstance(arg, Var):
                                continue
                            if i < arg_offset:
                                # Implicit-input arg; skip (no grounding).
                                continue
                            field_index = i - arg_offset
                            if not task.relation.fields[field_index].input:
                                grounded_here.add(arg)
                elif isinstance(task, Aggregate):
                    for var in task.group:
                        if isinstance(var, Var):
                            grounded_here.add(var)
                    for i, arg in enumerate(task.args):
                        if isinstance(arg, Var) and i < len(task.aggregation.fields):
                            if not task.aggregation.fields[i].input:
                                grounded_here.add(arg)
                elif isinstance(task, Construct):
                    if isinstance(task.id_var, Var):
                        grounded_here.add(task.id_var)
                # Deliberately skip ``_extend_outputs_via_equality`` for
                # Match/Union sub-tasks here. Groundness uses it as a
                # workaround for a metamodel generator bug that omits
                # output vars from Match/Union ``.outputs``; pre-grounding
                # them via equality chains *across branches* would defeat
                # the per-branch isolation our ``enter_union`` / ``enter_match``
                # overrides need to compute the "anchored in every branch"
                # intersection. Match/Union outputs still escape into the
                # outer scope when ``enter_union`` / ``enter_match`` run
                # the workaround themselves *after* per-branch analysis.
            if len(grounded_here) > prev_size:
                changed = True
        self._ground_vars(grounded_here)

    def enter_union(self, union: Union):
        # Per-branch isolation (mirrors Groundness.enter_union) plus the
        # cross-branch intersection that gives "anchored in every branch".
        saved = self.grounded.copy()
        per_branch_grounded: list[set[Var]] = []
        for branch in union.tasks:
            self.grounded = saved.copy()
            # Reset per-branch anchored capture so nested Union/Match
            # compose correctly (intersection of branch results, not
            # carry-over from a sibling).
            saved_anchored = self._anchored_grounded
            self._anchored_grounded = None
            self(branch)
            per_branch_grounded.append(
                self._anchored_grounded.copy()
                if self._anchored_grounded is not None
                else self.grounded.copy()
            )
            self._anchored_grounded = saved_anchored
        if per_branch_grounded:
            intersection = per_branch_grounded[0].copy()
            for s in per_branch_grounded[1:]:
                intersection &= s
            if self._anchored_grounded is None:
                self._anchored_grounded = intersection
            else:
                self._anchored_grounded &= intersection
        # Same outward contract as Groundness.enter_union: restore the
        # pre-union grounded state and ground only the Union's outputs.
        self.grounded = saved
        self._ground_vars(_extend_outputs_via_equality(union))
        return NO_WALK

    def enter_match(self, match: Match):
        # Identical pattern to enter_union — see comments there.
        saved = self.grounded.copy()
        per_branch_grounded: list[set[Var]] = []
        for branch in match.tasks:
            self.grounded = saved.copy()
            saved_anchored = self._anchored_grounded
            self._anchored_grounded = None
            self(branch)
            per_branch_grounded.append(
                self._anchored_grounded.copy()
                if self._anchored_grounded is not None
                else self.grounded.copy()
            )
            self._anchored_grounded = saved_anchored
        if per_branch_grounded:
            intersection = per_branch_grounded[0].copy()
            for s in per_branch_grounded[1:]:
                intersection &= s
            if self._anchored_grounded is None:
                self._anchored_grounded = intersection
            else:
                self._anchored_grounded &= intersection
        self.grounded = saved
        self._ground_vars(_extend_outputs_via_equality(match))
        return NO_WALK


__all__ = ["PerKeyAnchoring"]
