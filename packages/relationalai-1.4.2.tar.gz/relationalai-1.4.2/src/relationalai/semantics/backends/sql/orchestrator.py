"""Orchestrator: metadata plan table management and Snowflake refresh task support.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path

import rich

from ..install_readiness import InstallReadinessResult, InstallReadinessStatus
from ....config.config_fields import RefreshTaskConfig
from typing import TYPE_CHECKING, Callable

from pandas import DataFrame

try:
    from .... import __version__ as _PACKAGE_VERSION
except Exception:
    _PACKAGE_VERSION = "unknown"

if TYPE_CHECKING:
    import snowflake.snowpark
    from v0.relationalai.clients.resources.snowflake.snowflake import Resources as _SnowflakeResources
    from .artifacts import LogicBlock, PlannedSQLStep
    from ..sql_executor import SQLExecutor



@dataclass
class InstallState:
    fingerprint: str
    state: str  # STATUS_RUNNING, STATUS_READY, or STATUS_FAILED
    error: str

# ---------------------------------------------------------------------------
# Public names of metadata objects created by the orchestrator.
#
# These are the source of truth for the meta-schema layout. If you rename any
# of these, also update the matching SQL template files in `sql_templates/`
# (e.g. `refresh_procedure.sql`) and any other consumer.
# ---------------------------------------------------------------------------
META_SCHEMA_SUFFIX: str = "_meta"
PLAN_TABLE_NAME: str = "PLAN"
REFRESH_LOG_TABLE_NAME: str = "REFRESH_LOG"
_PYREL_ROOT_DB: str = "pyrel_root_db"

_SQL_TEMPLATES_DIR = Path(__file__).parent / "sql_templates"
_JS_PROCEDURES_DIR = _SQL_TEMPLATES_DIR / "js_procedures"


def _load_sql_template(name: str, **kwargs: str) -> str:
    return (_SQL_TEMPLATES_DIR / name).read_text().format(**kwargs)


def _load_js_procedure(name: str, **kwargs: str) -> str:
    lib_path = _JS_PROCEDURES_DIR / "lib.js"
    js_parts: list[str] = []
    if lib_path.exists():
        js_parts.append(lib_path.read_text())
    js_parts.append((_JS_PROCEDURES_DIR / f"{name}.js").read_text())
    js_body = "\n\n".join(part.rstrip() for part in js_parts if part)
    return _load_sql_template(f"js_procedures/{name}.sql", js_body=js_body, **kwargs)


# ---------------------------------------------------------------------------
# PlanTable
# ---------------------------------------------------------------------------

# Each entry: (target_table_names, block_index, sql_statements, reasoner, refresh_interval_seconds)
# refresh_interval_seconds == 0 means "no scheduled refresh".
PlanEntry = tuple[str, int, str, str, int]


class PlanTable:

    def __init__(self, execute_sql: Callable[[str], DataFrame]) -> None:
        self._execute_sql = execute_sql

    def create(self, meta_schema: str) -> None:
        """Create the plan (and refresh log) tables in *meta_schema*.

        Recreates the PLAN table from scratch on every install so that stale
        entries from a previous version of the model are removed.
        """
        self._execute_sql(f"CREATE SCHEMA IF NOT EXISTS {meta_schema}")
        self._execute_sql(
            f"CREATE OR REPLACE HYBRID TABLE {meta_schema}.{PLAN_TABLE_NAME} ("
            "entry_id INTEGER PRIMARY KEY, "
            "target_table_names VARCHAR, "
            "block_index INTEGER, "
            "sql_statements VARCHAR, "
            "reasoner VARCHAR, "
            "refresh_interval_seconds INTEGER)"
        )
        self._execute_sql(
            f"CREATE OR REPLACE HYBRID TABLE {meta_schema}.{REFRESH_LOG_TABLE_NAME} ("
            "log_id INTEGER AUTOINCREMENT PRIMARY KEY, "
            "run_id INTEGER NOT NULL, "
            "entry_type VARCHAR NOT NULL, "
            "target_table_names VARCHAR, "
            "block_index INTEGER, "
            "interval_seconds INTEGER, "
            "fingerprint VARCHAR, "
            "run_start_time TIMESTAMP_LTZ NOT NULL, "
            "run_end_time TIMESTAMP_LTZ, "
            "state VARCHAR NOT NULL, "
            "error_message VARCHAR)"
        )

    def write_entries(self, meta_schema: str, entries: list[PlanEntry]) -> None:
        self.create(meta_schema)
        if not entries:
            return

        def _esc(s: str) -> str:
            return "'" + s.replace("'", "''") + "'"

        rows = ", ".join(
            f"({idx}, {_esc(e[0])}, {e[1]}, {_esc(e[2])}, {_esc(e[3])}, {e[4]})"
            for idx, e in enumerate(entries)
        )
        self._execute_sql(f"INSERT INTO {meta_schema}.{PLAN_TABLE_NAME} VALUES {rows}")


# ---------------------------------------------------------------------------
# Orchestrator (no-op base — used for DuckDB)
# ---------------------------------------------------------------------------

class Orchestrator:
    """No-op orchestrator used for backends that do not support plan tables or refresh tasks."""

    def __init__(
        self,
        sql_executor: SQLExecutor,
    ) -> None:
        self._sql_executor = sql_executor
        self._install_actions: list[Callable[[], None]] = []

    def register_sql_block(
        self,
        block_index: int,
        steps: "list[PlannedSQLStep]",
        interval_s: int = 0,
    ) -> None:
        sql_executor = self._sql_executor
        if sql_executor is None or not steps:
            return
        plan = list(steps)
        self._install_actions.append(lambda plan=plan, sql_executor=sql_executor: sql_executor.execute_block(plan))

    def register_logic_block(
        self,
        block_index: int,
        block: LogicBlock,
        run_sql: str,
        schema_only_sql: tuple[str, ...] = (),
        interval_s: int = 0,
        source_tables: tuple[str, ...] = (),
    ) -> None:
        raise NotImplementedError(
            "Logic blocks are not supported in the base Orchestrator. Use SnowflakeOrchestrator instead.",
        )

    def finalize(self) -> InstallReadinessResult:
        for action in self._install_actions:
            action()
        return InstallReadinessResult(InstallReadinessStatus.READY)

    def compute_pending_install_fingerprint(self) -> str | None:
        return None

    def wait_for_initial_refresh(self) -> None:
        """No-op for backends without async install."""
        return

    def check_readiness(self) -> InstallReadinessResult:
        """Return READY immediately; no async install to inspect for this backend."""
        return InstallReadinessResult(InstallReadinessStatus.READY)


# ---------------------------------------------------------------------------
# SnowflakeOrchestrator
# ---------------------------------------------------------------------------

class SnowflakeOrchestrator(Orchestrator):
    """Orchestrator for Snowflake backends: writes plan entries and manages refresh tasks."""

    ENTRY_TYPE_BLOCK = "BLOCK"
    ENTRY_TYPE_RUN_PREPARED = "RUN_PREPARED"
    ENTRY_TYPE_RUN_STARTED = "RUN_STARTED"
    ENTRY_TYPE_RUN_COMPLETE = "RUN_COMPLETE"
    FULL_MODEL_REFRESH_TASK = "FULL_MODEL_REFRESH_TASK"

    STATUS_PREPARED = "PREPARED"
    STATUS_RUNNING = "RUNNING"
    STATUS_READY = "READY"
    STATUS_FAILED = "FAILED"

    # Install log poll parameters
    _POLL_TIMEOUT_SECONDS = 1200.0
    _POLL_BACKOFF_INITIAL = 0.05
    _POLL_BACKOFF_MAX = 2.0

    def __init__(
        self,
        session: "snowflake.snowpark.Session",
        app_name: str,
        sql_executor: SQLExecutor,
        meta_schema: str,
        schedule_cfg: RefreshTaskConfig | None,
        resources: _SnowflakeResources | None = None,
    ) -> None:
        super().__init__(sql_executor)
        self._plan_table = PlanTable(execute_sql=sql_executor.execute_sql)
        self._snowflake_task_manager = SnowflakeTaskManager(session, app_name)
        self._app_name = app_name
        self._meta_schema = meta_schema
        self._refresh_cfg = schedule_cfg
        self._plan_entries: list[PlanEntry] = []
        self._install_sql: list[str] = []
        self._pending_fingerprint: str | None = None
        self._logic_block_sources: list[tuple[str, ...]] = []
        # v0 Snowflake Resources handle used to classify stale CDC streams via
        # ``_check_source_updates``. May be ``None`` in tests / non-Snowflake
        # paths, in which case stale-stream cleanup is skipped (best-effort).
        self._resources = resources

    def register_sql_block(
        self,
        block_index: int,
        steps: "list[PlannedSQLStep]",
        interval_s: int = 0,
    ) -> None:
        """Accumulate a single plan entry for an entire SQL block (Snowflake only).

        Combines all SQL steps and semi-naive loops belonging to one execution
        block into one :data:`PlanEntry` in their original execution order, so
        the refresh procedure can replay the whole block atomically.

        Args:
            block_index: Index of the execution block.
            steps: Planned SQL steps for the block.
            interval_s: Refresh interval for this block in seconds (0 = no schedule).
                Determined at routing time so that each block contains only tables
                sharing the same refresh cadence.
        """
        if self._snowflake_task_manager is None:
            return
        if not steps:
            return

        all_sql: list[str] = []
        all_names: list[str] = []

        for step in steps:
            self._install_sql.extend(stmt for stmt in step.install_sql_batch if stmt)
            # Track every output in target_table_names (so block affiliation is
            # visible in the plan table) but only include views with actual
            # refresh-time SQL in the plan body. ``None`` entries are outputs
            # with nothing to do at refresh (e.g. logical views).
            for refresh_sql, view_name in zip(step.refresh_sql_batch, step.view_names):
                all_names.append(view_name)
                if refresh_sql is None:
                    continue
                all_sql.append(refresh_sql)
            for loop in step.semi_naive_loops:
                self._install_sql.extend(stmt for stmt in loop.install_sql if stmt)
                assert isinstance(loop.plan, str), "In Snowflake, semi-naive plans must be SQL strings."
                all_sql.append(loop.plan)
                all_names.append(", ".join(loop.table_names))

        if not all_sql:
            # Block had only view-typed outputs — nothing to refresh, no plan entry.
            return

        self._plan_entries.append((
            ", ".join(all_names), block_index,
            "\n".join(s.rstrip().rstrip(";") + ";" for s in all_sql), "sql", interval_s,
        ))

    def register_logic_block(
        self,
        block_index: int,
        block: LogicBlock,
        run_sql: str,
        schema_only_sql: tuple[str, ...] = (),
        interval_s: int = 0,
        source_tables: tuple[str, ...] = (),
    ) -> None:
        """Accumulate a plan entry for a logic-reasoner block execution.

        The ``reasoner`` column is set to ``"logic"`` so the refresh procedure can dispatch
        back to the logic reasoner rather than re-executing SQL. One entry is written per
        logic block; ``block_index`` equals the block index (one step per block).

        Args:
            block_index: Block index — equals the execution block's index.
            interval_s: Refresh interval for this block in seconds (0 = no schedule).
                Determined at routing time so that each block contains only tables
                sharing the same refresh cadence.
            source_tables: Block input source-table FQNs; consumed at finalize time
                to clean up stale CDC streams before kicking off the async install.
        """
        if self._snowflake_task_manager is None:
            return
        self._install_sql.extend(stmt for stmt in schema_only_sql if stmt)
        self._plan_entries.append(
            (",".join(block.output_table_names), block_index,
             run_sql.rstrip().rstrip(";") + ";", "logic", interval_s,
        ))
        self._logic_block_sources.append(source_tables)

    def finalize(self) -> InstallReadinessResult:
        """Commit the install: write the plan table, create refresh procedures and tasks,
        and kick off the async initial-install task.

        Short-circuits if a matching install fingerprint is already READY or RUNNING.
        Returns READY if no wait is needed, MATCHING_INSTALL_IN_PROGRESS if the caller
        must poll/wait.
        """
        # Fast path: short-circuit if already READY or RUNNING. Any other status (FAILED,
        # mismatch, no state, install prepared) falls through to a full (re-)install.
        result = self.check_readiness()
        if result.status in (InstallReadinessStatus.READY, InstallReadinessStatus.MATCHING_INSTALL_IN_PROGRESS):
            return result

        fingerprint = self.compute_pending_install_fingerprint()
        assert fingerprint is not None

        self._sql_executor.execute_sql(f"CREATE SCHEMA IF NOT EXISTS {self._meta_schema}")
        try:
            self._plan_table.write_entries(self._meta_schema, self._plan_entries)
            self._create_refresh_procedures()
            if self._install_sql:
                # Two-phase ordering: self-contained TABLE/CTAS first, ref-bearing
                # DT/VIEW second. Snowflake parses CREATE DT/VIEW bodies at install
                # time, so any object they reference must already exist.
                self._sql_executor.execute_sql_batch(self._partition_install_sql(self._install_sql))
            self._delete_stale_logic_streams()
            self._snowflake_task_manager.create_full_model_refresh_task(self._meta_schema)
            self._insert_run_prepared_marker(fingerprint)
            self._snowflake_task_manager.trigger_full_model_refresh(self._meta_schema)
            self._create_refresh_tasks_if_configured()
        except Exception as exc:
            self._insert_run_complete_marker(fingerprint, self.STATUS_FAILED, str(exc))
            raise
        return InstallReadinessResult(InstallReadinessStatus.MATCHING_INSTALL_IN_PROGRESS)

    def compute_pending_install_fingerprint(self) -> str | None:
        """Return a fingerprint covering: all install SQL statements, all plan
        entries (block index, reasoner, SQL/LQP payload, and schedule metadata),
        and the current package version."""
        if self._pending_fingerprint is None:
            h = hashlib.sha256()
            for stmt in self._install_sql:
                h.update(stmt.encode("utf-8"))
            for entry in self._plan_entries:
                h.update(json.dumps(list(entry), separators=(",", ":")).encode("utf-8"))
            h.update(_PACKAGE_VERSION.encode("utf-8"))
            self._pending_fingerprint = h.hexdigest()
        return self._pending_fingerprint

    # ------------------------------------------------------------------
    # Wait / readiness path
    # ------------------------------------------------------------------

    def wait_for_initial_refresh(self) -> None:
        """Block until the initial refresh is complete."""
        deadline = time.monotonic() + self._POLL_TIMEOUT_SECONDS
        backoff = self._POLL_BACKOFF_INITIAL
        while True:
            result = self.check_readiness()
            if result.status == InstallReadinessStatus.READY:
                return
            if result.status == InstallReadinessStatus.MATCHING_INSTALL_FAILED:
                raise RuntimeError(f"Install failed: {result.detail or 'no message'}")
            if result.status not in (
                InstallReadinessStatus.MATCHING_INSTALL_IN_PROGRESS,
                InstallReadinessStatus.INSTALL_PREPARED,
            ):
                raise RuntimeError(
                    f"Install sentinel disappeared while waiting for {self._meta_schema} to become READY."
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Timed out after {self._POLL_TIMEOUT_SECONDS:.0f}s waiting for "
                    f"{self._meta_schema} install to become READY."
                )
            time.sleep(backoff)
            backoff = min(backoff * 2, self._POLL_BACKOFF_MAX)

    def check_readiness(self) -> InstallReadinessResult:
        fingerprint = self.compute_pending_install_fingerprint()
        assert fingerprint is not None

        try:
            install_state = self._get_current_install_state()
        except Exception as e:
            return InstallReadinessResult(InstallReadinessStatus.NO_INSTALL_STATE, str(e))

        if install_state is None:
            return InstallReadinessResult(
                InstallReadinessStatus.NO_INSTALL_STATE,
                f"No install sentinel found in {self._meta_schema}.REFRESH_LOG.",
            )
        if install_state.fingerprint != fingerprint:
            return InstallReadinessResult(
                InstallReadinessStatus.FINGERPRINT_MISMATCH,
                f"Installed fingerprint {install_state.fingerprint} does not match current fingerprint {fingerprint}.",
            )
        if install_state.state == self.STATUS_READY:
            return InstallReadinessResult(InstallReadinessStatus.READY)
        if install_state.state == self.STATUS_FAILED:
            return InstallReadinessResult(InstallReadinessStatus.MATCHING_INSTALL_FAILED, install_state.error)
        if install_state.state == self.STATUS_RUNNING:
            return InstallReadinessResult(InstallReadinessStatus.MATCHING_INSTALL_IN_PROGRESS)
        if install_state.state == self.STATUS_PREPARED:
            return InstallReadinessResult(InstallReadinessStatus.INSTALL_PREPARED)
        raise RuntimeError(
            f"Unrecognized install status '{install_state.state}' in {self._meta_schema}.REFRESH_LOG. "
            "The table may have been written by a newer version of this package."
        )

    # ------------------------------------------------------------------
    # REFRESH_LOG run marker helpers
    # ------------------------------------------------------------------

    def _get_current_install_state(self) -> "InstallState | None":
        """Return the install state derived from the latest run-level row in REFRESH_LOG, or None."""
        sql = (
            f"SELECT entry_type, state, error_message, fingerprint "
            f"FROM {self._meta_schema}.REFRESH_LOG "
            f"WHERE run_id = 0 "
            f"  AND entry_type IN "
            f"    ('{self.ENTRY_TYPE_RUN_PREPARED}', '{self.ENTRY_TYPE_RUN_STARTED}', '{self.ENTRY_TYPE_RUN_COMPLETE}') "
            f"ORDER BY log_id DESC "
            f"LIMIT 1"
        )
        rows = self._snowflake_task_manager.session.sql(sql).collect()
        if not rows:
            return None
        row = rows[0]
        entry_type = str(row[0])
        raw_state = str(row[1])
        error = "" if row[2] is None else str(row[2])
        fingerprint = "" if row[3] is None else str(row[3])
        if entry_type == self.ENTRY_TYPE_RUN_COMPLETE:
            state = self.STATUS_READY if raw_state == "SUCCESS" else self.STATUS_FAILED
        elif entry_type == self.ENTRY_TYPE_RUN_PREPARED:
            state = self.STATUS_PREPARED
        else:
            state = self.STATUS_RUNNING
        return InstallState(fingerprint=fingerprint, state=state, error=error)

    def _insert_run_complete_marker(
        self, fingerprint: str, state: str, error_message: str | None = None
    ) -> None:
        """Best-effort INSERT of a run-complete row for the initial install (run_id=0)."""
        try:
            msg = "" if error_message is None else error_message[:1000].replace("'", "''")
            msg_col = "NULL" if error_message is None else f"'{msg}'"
            self._snowflake_task_manager.session.sql(
                f"INSERT INTO {self._meta_schema}.REFRESH_LOG "
                f"(run_id, entry_type, target_table_names, interval_seconds, fingerprint, run_start_time, run_end_time, state, error_message) "
                f"VALUES (0, '{self.ENTRY_TYPE_RUN_COMPLETE}', NULL, -1, '{fingerprint}', "
                f"CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), '{state}', {msg_col})"
            ).collect()
        except Exception:
            pass  # Best-effort; don't mask the original exception.

    def _insert_run_prepared_marker(self, fingerprint: str) -> None:
        """INSERT a RUN_PREPARED sentinel for the initial install (run_id=0).

        Written before EXECUTE TASK so pollers immediately see INSTALL_PREPARED.
        The task itself transitions this to RUN_STARTED when it begins executing,
        which lets concurrent full-refresh invocations detect that run_id=0 is
        already claimed and skip.
        """
        self._snowflake_task_manager.session.sql(
            f"INSERT INTO {self._meta_schema}.REFRESH_LOG "
            f"(run_id, entry_type, target_table_names, interval_seconds, fingerprint, run_start_time, state) "
            f"VALUES (0, '{self.ENTRY_TYPE_RUN_PREPARED}', NULL, -1, '{fingerprint}', CURRENT_TIMESTAMP(), 'PREPARED')"
        ).collect()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _partition_install_sql(stmts: "list[str]") -> "list[str]":
        """Order install statements so reference-bearing DDLs run after the
        objects they reference exist. ``CREATE [OR REPLACE] DYNAMIC TABLE`` and
        ``CREATE [OR REPLACE] VIEW`` parse their body at CREATE time and may
        reference other model objects; everything else is self-contained.
        Within each partition, original order is preserved.

        The regex assumes the emitter places the ``CREATE ... DYNAMIC TABLE`` or
        ``CREATE ... VIEW`` tokens on a single line (which our SF emitter does:
        the header is line 1, body follows after ``\\n``). The ``[^\\n]*`` is
        intentional — switching to DOTALL would let an embedded body subquery's
        own ``CREATE ... VIEW`` literal misclassify the outer statement.
        """
        ref_bearing = re.compile(r'\bCREATE\b[^\n]*\b(?:DYNAMIC\s+TABLE|VIEW)\b', re.IGNORECASE)
        self_contained: list[str] = []
        deferred: list[str] = []
        for s in stmts:
            (deferred if ref_bearing.search(s) else self_contained).append(s)
        return self_contained + deferred

    def _delete_stale_logic_streams(self) -> None:
        """Drop CDC streams whose source table has been altered since the
        stream was created, so the subsequent ``use_index`` call recreates
        them cleanly.

        Runs once per install, after install SQL but before scheduling the
        async refresh task. Streams are classified via a single
        ``INFORMATION_SCHEMA.TABLES``-joined-against-``api.data_streams``
        query per source database — no per-source round-trips.

        Race window: deletion runs here synchronously, but ``use_index``
        (which recreates the stream) runs later inside
        ``FULL_MODEL_REFRESH_TASK``. A DDL on a source table in between will
        re-stale the recreated stream and surface as a stream-validation
        error on refresh. Putting the deletion here keeps the entire
        install sequence visible in :meth:`finalize`.

        Simplification vs. v0: we only check the DDL timestamp, not the
        column-hash false-positive filter v0 layers on top. That can
        over-delete a stream when a table got a no-op ``ALTER TABLE`` since
        the stream was created (e.g. comment/owner change with the same
        column shape). ``use_index`` will then recreate the stream and
        replay CDC, which is correct but slower than necessary.
        """
        if not self._logic_block_sources:
            return
        # Flatten per-block FQN tuples into a single deduped set.
        sources = {fqn for block_sources in self._logic_block_sources for fqn in block_sources}
        if not sources:
            return
        stale = self._classify_stale_sources(sources)
        if not stale:
            return
        self._snowflake_task_manager.session.sql(
            f"CALL {self._app_name}.api.delete_data_streams(PARSE_JSON(?), ?)",
            params=[json.dumps(list(stale)), _PYREL_ROOT_DB],
        ).collect()

    def _classify_stale_sources(self, sources: set[str]) -> list[str]:
        """Return the subset of ``sources`` whose CDC stream is stale per v0.

        Delegates to v0's :meth:`Resources._check_source_updates`, which runs
        an ``INFORMATION_SCHEMA``-joined-against-``api.data_streams`` query
        per source database, classifies each as ``STALE`` / ``CURRENT`` based
        on DDL timestamps, then refines with a column-hash recheck. We keep
        only the ``STALE`` set; the additional column-hash metadata it
        returns isn't needed here.

        If no Resources handle is available (e.g. tests or non-Snowflake
        connections), returns ``[]`` — stale-stream cleanup is best-effort
        and ``use_index`` will surface the real error at refresh time.
        """
        if self._resources is None or not sources:
            rich.print("Skipping stale-stream cleanup: no Snowflake resources handle")
            return []
        info = self._resources._check_source_updates(sources)
        return [fqn for fqn, si in info.items() if si.get("state") == "STALE"]

    def _create_refresh_procedures(self) -> None:
        # TODO: batch procedure creation into a single sql call
        self._snowflake_task_manager.create_poll_until_done_procedure(self._meta_schema)
        self._snowflake_task_manager.create_poll_use_index_until_ready_procedure(self._meta_schema)
        self._snowflake_task_manager.create_run_lqp_block_procedure(self._meta_schema)
        self._snowflake_task_manager.create_refresh_procedure(self._meta_schema)

    def _create_refresh_tasks_if_configured(self) -> None:
        if self._refresh_cfg is None or self._refresh_cfg.interval_s is None:
            return
        self._snowflake_task_manager.drop_refresh_tasks(meta_schema=self._meta_schema)
        unique_intervals: set[int] = {e[4] for e in self._plan_entries if e[4] != 0}
        for interval in unique_intervals:
            self._snowflake_task_manager.create_refresh_task(
                meta_schema=self._meta_schema,
                interval_s=interval,
            )


# ---------------------------------------------------------------------------
# SnowflakeTaskManager
# ---------------------------------------------------------------------------

class SnowflakeTaskManager:

    def __init__(self, session: "snowflake.snowpark.Session", app_name: str) -> None:
        self.session = session
        self._app_name = app_name

    # ------------------------------------------------------------------
    # Dynamic tables
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_fqn(table_name: str) -> list[str]:
        """Split a (possibly quoted) Snowflake FQN into unquoted component strings."""
        parts = []
        for part in table_name.split("."):
            part = part.strip()
            if part.startswith('"') and part.endswith('"'):
                part = part[1:-1].replace('""', '"')
            parts.append(part)
        return parts

    @staticmethod
    def dynamic_table_refresh_sql(table_name: str, meta_schema: str) -> str:
        """Return a Snowflake Scripting block that triggers a dynamic table refresh
        and polls until a terminal state is reached.

        Using ``SCHEDULER = DISABLE`` means no automatic cascade, so each refresh
        must be triggered and awaited explicitly.

        Args:
            table_name: Fully-qualified table name.
            meta_schema: Fully-qualified meta schema (e.g. ``MY_DB.MY_SCHEMA_META``).
        """
        parts = SnowflakeTaskManager._parse_fqn(table_name)

        if len(parts) >= 3:
            db, schema, tbl = parts[0], parts[1], parts[2]
            info_schema = f'{db}.INFORMATION_SCHEMA'
            history_args = f"NAME => '{db}.{schema}.{tbl}'"
        elif len(parts) == 2:
            schema, tbl = parts[0], parts[1]
            info_schema = 'INFORMATION_SCHEMA'
            history_args = f"NAME => '{schema}.{tbl}'"
        else:
            info_schema = 'INFORMATION_SCHEMA'
            history_args = f"NAME => '{parts[0]}'"

        # Single-quotes inside history_args are embedded in a SQL string literal
        # inside the template, so they must be escaped as ''.
        return _load_sql_template(
            "dynamic_table_refresh.sql",
            table_name=table_name,
            info_schema=info_schema,
            history_args=history_args.replace("'", "''"),
            meta_schema=meta_schema,
        )

    # ------------------------------------------------------------------
    # Refresh task
    # ------------------------------------------------------------------

    @staticmethod
    def _procedure_name(meta_schema: str) -> str:
        return f"{meta_schema}.REFRESH_MODEL"

    @staticmethod
    def _get_run_lqp_block_procedure_name(meta_schema: str) -> str:
        return f"{meta_schema}.RUN_LQP_BLOCK"

    @staticmethod
    def _task_name(meta_schema: str, interval_s: int) -> str:
        return f"{meta_schema}.REFRESH_TASK_{interval_s}S"

    def create_poll_until_done_procedure(self, meta_schema: str) -> None:
        """Create the ``POLL_UNTIL_DONE`` JavaScript stored procedure.

        The procedure polls a query with capped exponential backoff until the
        result matches one of the provided terminal states.

        Args:
            meta_schema: Fully-qualified meta schema (e.g. ``MY_DB.MY_SCHEMA_META``).
        """
        proc_sql = _load_js_procedure("poll_until_done", schema=meta_schema)
        self.session.sql(proc_sql).collect()

    def create_poll_use_index_until_ready_procedure(self, meta_schema: str) -> None:
        proc_sql = _load_js_procedure("poll_use_index_until_ready", schema=meta_schema)
        self.session.sql(proc_sql).collect()

    def create_run_lqp_block_procedure(self, meta_schema: str) -> str:
        proc_name = self._get_run_lqp_block_procedure_name(meta_schema)
        proc_sql = _load_js_procedure(
            "run_lqp_block",
            schema=meta_schema,
            app_name=self._app_name,
        )
        self.session.sql(proc_sql).collect()
        return proc_name

    def create_refresh_procedure(self, meta_schema: str) -> str:
        """Create the ``REFRESH_MODEL`` stored procedure.

        Args:
            meta_schema: Fully-qualified meta schema.

        Returns:
            The fully-qualified procedure name.
        """
        proc_name = self._procedure_name(meta_schema)
        proc_sql = _load_sql_template(
            "refresh_procedure.sql",
            proc_name=proc_name,
            meta_schema=meta_schema,
        )
        self.session.sql(proc_sql).collect()
        return proc_name

    def _warehouse_clause(self) -> str:
        """Return the WAREHOUSE clause for a CREATE TASK using the session's current
        warehouse, falling back to serverless if none is set.
        """
        warehouse = self.session.get_current_warehouse()
        return (
            f"WAREHOUSE = {warehouse}"
            if warehouse
            else "USER_TASK_MANAGED_INITIAL_WAREHOUSE_SIZE = 'XSMALL'"
        )

    def create_refresh_task(self, meta_schema: str, interval_s: int) -> None:
        """Create and resume a Snowflake scheduled task that calls the refresh procedure.

        Args:
            meta_schema: Fully-qualified meta schema.
            interval_s: How often the task runs, in seconds.
        """
        proc_name = self._procedure_name(meta_schema)
        task_name = self._task_name(meta_schema, interval_s)
        task_sql = _load_sql_template(
            "refresh_task.sql",
            task_name=task_name,
            warehouse_clause=self._warehouse_clause(),
            schedule_clause=f"SCHEDULE = '{interval_s} SECONDS'",
            call_arg=str(interval_s),
            proc_name=proc_name,
        )
        self.session.sql(task_sql).collect()
        self.session.sql(f"ALTER TASK {task_name} RESUME").collect()

    def create_full_model_refresh_task(self, meta_schema: str) -> None:
        """Create task that refreshes all blocks.
        Used during install to run the initial full-model refresh asynchronously.
        """
        proc_name = self._procedure_name(meta_schema)
        task_name = f"{meta_schema}.FULL_MODEL_REFRESH_TASK"
        task_sql = _load_sql_template(
            "refresh_task.sql",
            task_name=task_name,
            warehouse_clause=self._warehouse_clause(),
            schedule_clause="",
            call_arg="-1",
            proc_name=proc_name,
        )
        self.session.sql(task_sql).collect()

    def trigger_full_model_refresh(self, meta_schema: str) -> None:
        task_name = f"{meta_schema}.FULL_MODEL_REFRESH_TASK"
        self.session.sql(f"EXECUTE TASK {task_name}").collect()

    def drop_refresh_tasks(self, meta_schema: str) -> None:
        """Drop all refresh tasks and the refresh procedure.

        Called before recreating them so that changed intervals take effect.

        Args:
            meta_schema: Fully-qualified meta schema.
        """
        rows = self.session.sql(
            f"SHOW TASKS LIKE 'REFRESH_TASK_%' IN SCHEMA {meta_schema}"
        ).collect()
        for row in rows:
            task_name = f"{meta_schema}.{row['name']}"
            self.session.sql(f"DROP TASK IF EXISTS {task_name}").collect()
