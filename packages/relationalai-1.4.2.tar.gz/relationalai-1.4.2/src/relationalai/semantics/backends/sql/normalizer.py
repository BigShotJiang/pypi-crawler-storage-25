"""Canonical metamodel normalization for sql9 lowering."""
from __future__ import annotations

from dataclasses import dataclass, field
from collections import defaultdict

from ...metamodel import metamodel as mm
from ...metamodel.rewriter import Rewriter
from ...metamodel.metamodel_analyzer import task_var_ids
from .artifacts import (
    NormalizedSQLBlock,
    RecursiveComponentPlan,
    RecursiveTargetPlan,
    BlockVersionState,
    TargetPlan,
)
from .catalog_builder import Catalog
from .coalescer import CoalescedBlock, PlannedTarget, Target
from . import name_scheme


@dataclass(slots=True)
class StratumVersionState():
    latest_tables_by_relation_id: dict[int, mm.Table]
    entry_tables_by_relation_id: dict[int, mm.Table]
    materialized_tables_by_object_name: dict[str, mm.Table] = field(default_factory=dict)
    stage_numbers_by_object_name: dict[str, int] = field(default_factory=dict)

    def latest_table_for(self, relation_id: int) -> mm.Table | None:
        return self.latest_tables_by_relation_id.get(relation_id)

    def entry_table_for(self, relation_id: int) -> mm.Table | None:
        return self.entry_tables_by_relation_id.get(relation_id)

    def prior_table_for(self, object_name: str) -> mm.Table | None:
        return self.materialized_tables_by_object_name.get(object_name)

    def note_output_name(self, object_name: str) -> int:
        next_stage = self.stage_numbers_by_object_name.get(object_name, 0) + 1
        self.stage_numbers_by_object_name[object_name] = next_stage
        return next_stage

    def materialize_object(self, object_name: str, output_table: mm.Table) -> None:
        self.materialized_tables_by_object_name[object_name] = output_table

    def bind_relation_table(self, relation_id: int, table: mm.Table) -> None:
        self.latest_tables_by_relation_id[relation_id] = table


class SQLNormalizer(Rewriter):
    def __init__(self) -> None:
        super().__init__()
        self._aggregate_union_outputs = _AggregateUnionOutputExtender()
        self._aggregate_demand = _AggregateDemandRewriter()
        self._aggregate_scope = _AggregateScopeRewriter()
        self._aggregate_packing = _AggregatePackingRewriter()

    def normalize(self, task: mm.Task) -> mm.Task:
        return self._aggregate_packing(self._aggregate_scope(self._aggregate_demand(self._aggregate_union_outputs(self(task)))))

    def logical(self, node: mm.Logical):
        body: list[mm.Task] = []
        hoisted_updates: list[mm.Update] = []

        for child in node.body:
            if isinstance(child, mm.Logical) and not child.optional:
                body.extend(child.body)
                continue
            if isinstance(child, mm.Logical) and child.optional:
                child_body: list[mm.Task] = []
                for grandchild in child.body:
                    if isinstance(grandchild, mm.Update):
                        hoisted_updates.append(grandchild)
                    else:
                        child_body.append(grandchild)
                body.append(child.mut(body=tuple(child_body)))
                continue
            body.append(child)

        constructs = [child for child in body if isinstance(child, mm.Construct)]
        required = [
            child
            for child in body
            if not isinstance(child, (mm.Construct, mm.Update))
            and not (isinstance(child, mm.Logical) and child.optional)
        ]
        optional = [child for child in body if isinstance(child, mm.Logical) and child.optional]
        updates = [child for child in body if isinstance(child, mm.Update)]
        updates.extend(hoisted_updates)

        new_body = tuple((*constructs, *required, *optional, *updates))
        return node.mut(body=new_body) if new_body != node.body else node

def _first_aggregate_index(tasks: tuple[mm.Task, ...]) -> int | None:
    return next((index for index, child in enumerate(tasks) if isinstance(child, mm.Aggregate)), None)


def _logical_aggregate_run(task: mm.Task, *, allow_scope: bool) -> tuple[mm.Aggregate, ...]:
    if not isinstance(task, mm.Logical) or not task.optional or (task.scope and not allow_scope):
        return ()
    first_aggregate_index = _first_aggregate_index(task.body)
    if first_aggregate_index is None:
        return ()
    if any(not isinstance(child, mm.Aggregate) for child in task.body[first_aggregate_index:]):
        return ()
    return tuple(child for child in task.body[first_aggregate_index:] if isinstance(child, mm.Aggregate))


def _aggregate_scope_prefix(task: mm.Task) -> tuple[mm.Task, ...]:
    if not isinstance(task, mm.Logical) or not task.optional:
        return ()
    first_aggregate_index = _first_aggregate_index(task.body)
    if first_aggregate_index is None:
        return ()
    return tuple(task.body[:first_aggregate_index])


def _aggregate_signature_ids(task: mm.Task) -> tuple[tuple[int, ...], tuple[int, ...]] | None:
    if not isinstance(task, mm.Aggregate):
        return None
    return (
        tuple(var.id for var in task.group if isinstance(var, mm.Var)),
        tuple(var.id for var in task.projection if isinstance(var, mm.Var)),
    )


def _aggregate_signature_vars(aggregate: mm.Aggregate) -> tuple[tuple[mm.Var, ...], tuple[mm.Var, ...]]:
    return (
        tuple(var for var in aggregate.group if isinstance(var, mm.Var)),
        tuple(var for var in aggregate.projection if isinstance(var, mm.Var)),
    )


class _AggregateDemandRewriter(Rewriter):
    _ARITHMETIC = {"+", "-", "*", "/", "//", "%", "^"}
    _PREDICATES = {"=", "!=", "<", "<=", ">", ">="}

    def logical(self, node: mm.Logical):
        body = tuple(self._rewrite(node.body)) #type: ignore
        if body != node.body:
            node = node.mut(body=body)
        rewritten_body = self._rewrite_aggregate_dependencies(node.body)
        return node.mut(body=rewritten_body) if rewritten_body != node.body else node

    def _rewrite_aggregate_dependencies(self, body: tuple[mm.Task, ...]) -> tuple[mm.Task, ...]:
        tasks = list(body)
        changed = True
        while changed:
            changed = False
            var_ids_by_task = [task_var_ids(task) for task in tasks]
            for index, task in enumerate(tasks):
                produced_var_id = self._aggregate_output_var_id(task)
                if produced_var_id is None:
                    continue
                consumer_indexes = [i for i, var_ids in enumerate(var_ids_by_task) if i != index and produced_var_id in var_ids]
                if len(consumer_indexes) != 1:
                    continue
                consumer_index = consumer_indexes[0]
                consumer_aggregate = self._aggregate_node(tasks[consumer_index])
                if consumer_aggregate is None:
                    continue
                nested_consumer = self._nest_dependency(tasks[consumer_index], task)
                if nested_consumer is tasks[consumer_index]:
                    continue
                tasks[consumer_index] = nested_consumer
                tasks.pop(index)
                changed = True
                break
        changed = True
        while changed:
            changed = False
            producer_outputs_by_task = [self._task_output_var_ids(task) for task in tasks]
            for index, task in enumerate(tasks):
                consumed_var_ids = task_var_ids(task) - producer_outputs_by_task[index]
                if not consumed_var_ids:
                    continue
                later_producer_indexes = [
                    later_index
                    for later_index, output_var_ids in enumerate(producer_outputs_by_task[index + 1 :], start=index + 1)
                    if consumed_var_ids & output_var_ids
                ]
                if not later_producer_indexes:
                    continue
                consumer = tasks.pop(index)
                insert_index = max(later_producer_indexes)
                tasks.insert(insert_index, consumer)
                changed = True
                break
        return tuple(tasks)

    def _aggregate_output_var_id(self, task: mm.Task) -> int | None:
        output_var_ids = self._aggregate_output_var_ids(task)
        return next(iter(output_var_ids)) if len(output_var_ids) == 1 else None

    def _aggregate_node(self, task: mm.Task) -> mm.Aggregate | None:
        aggregates = self._aggregate_tasks(task)
        return aggregates[0] if len(aggregates) == 1 else None

    def _nest_dependency(self, consumer_task: mm.Task, dependency_task: mm.Task) -> mm.Task:
        if dependency_task is consumer_task:
            return consumer_task
        aggregate = self._aggregate_node(consumer_task)
        if aggregate is None:
            return consumer_task
        inner = aggregate.body if isinstance(aggregate.body, mm.Logical) else mm.Logical(body=(aggregate.body,))
        if dependency_task in inner.body:
            return consumer_task
        new_inner = inner.mut(body=tuple((*inner.body, dependency_task)))
        new_aggregate = aggregate.mut(body=new_inner)
        if isinstance(consumer_task, mm.Aggregate):
            return new_aggregate
        assert isinstance(consumer_task, mm.Logical)
        aggregate_index = next(
            index for index, child in enumerate(consumer_task.body) if isinstance(child, mm.Aggregate)
        )
        body = list(consumer_task.body)
        body[aggregate_index] = new_aggregate
        return consumer_task.mut(body=tuple(body), scope=True)

    def _aggregate_tasks(self, task: mm.Task) -> tuple[mm.Aggregate, ...]:
        if isinstance(task, mm.Aggregate):
            return (task,)
        return _logical_aggregate_run(task, allow_scope=False)

    def _aggregate_output_var_ids(self, task: mm.Task) -> set[int]:
        output_var_ids: set[int] = set()
        for aggregate in self._producer_aggregates(task):
            if aggregate.args and isinstance(aggregate.args[-1], mm.Var):
                output_var_ids.add(aggregate.args[-1].id)
        return output_var_ids

    def _task_output_var_ids(self, task: mm.Task) -> set[int]:
        output_var_ids = set(self._aggregate_output_var_ids(task))
        if isinstance(task, mm.Construct):
            output_var_ids.add(task.id_var.id)
        if isinstance(task, mm.Lookup):
            relation_name = task.relation.name if isinstance(task.relation, mm.Relation) else ""
            if relation_name == "cast" and len(task.args) >= 3 and isinstance(task.args[2], mm.Var):
                output_var_ids.add(task.args[2].id)
            elif relation_name in self._ARITHMETIC and task.args and isinstance(task.args[-1], mm.Var):
                output_var_ids.add(task.args[-1].id)
            elif relation_name and relation_name not in self._PREDICATES and task.args and isinstance(task.args[-1], mm.Var):
                output_var_ids.add(task.args[-1].id)
        return output_var_ids

    def _producer_aggregates(self, task: mm.Task) -> tuple[mm.Aggregate, ...]:
        if isinstance(task, mm.Aggregate):
            return (task,)
        return _logical_aggregate_run(task, allow_scope=True)


class _AggregateScopeRewriter(Rewriter):
    def logical(self, node: mm.Logical):
        if node.optional and _logical_aggregate_run(node, allow_scope=True):
            return node
        body = tuple(self._rewrite(node.body)) #type: ignore
        if body != node.body:
            node = node.mut(body=body)
        scoped_body = self._wrap_aggregate_scopes(node.body)
        return node.mut(body=scoped_body) if scoped_body != node.body else node

    def _wrap_aggregate_scopes(self, body: tuple[mm.Task, ...]) -> tuple[mm.Task, ...]:
        support_by_aggregate, claimed_indexes = self._aggregate_support_indexes(body)
        if not support_by_aggregate:
            return body

        rebuilt: list[mm.Task] = []
        index = 0
        while index < len(body):
            if index in claimed_indexes:
                index += 1
                continue

            support_indexes = support_by_aggregate.get(index)
            if support_indexes is None:
                rebuilt.append(body[index])
                index += 1
                continue

            support_tasks = tuple(body[support_index] for support_index in support_indexes)
            aggregates = [body[index]]
            end = index + 1
            signature = _aggregate_signature_ids(body[index])
            while end < len(body):
                next_support_indexes = support_by_aggregate.get(end)
                if next_support_indexes != support_indexes:
                    break
                if _aggregate_signature_ids(body[end]) != signature:
                    break
                aggregates.append(body[end])
                end += 1

            rebuilt.append(mm.Logical(body=(*support_tasks, *aggregates), optional=True, scope=True))
            index = end

        return tuple(rebuilt)

    def _aggregate_support_indexes(self, body: tuple[mm.Task, ...]) -> tuple[dict[int, tuple[int, ...]], set[int]]:
        support_by_aggregate: dict[int, tuple[int, ...]] = {}
        claimed_indexes: set[int] = set()
        for index, task in enumerate(body):
            if not isinstance(task, mm.Aggregate):
                continue
            group_var_ids = self._aggregate_group_var_ids(task)
            support_var_ids = self._aggregate_internal_var_ids(task) - group_var_ids
            if not support_var_ids:
                continue

            moved_indexes: set[int] = set()
            live_support_var_ids = set(support_var_ids)
            progress = True
            while progress:
                progress = False
                for prior_index, prior_task in enumerate(body[:index]):
                    if prior_index in claimed_indexes or prior_index in moved_indexes:
                        continue
                    prior_var_ids = task_var_ids(prior_task)
                    if not (prior_var_ids & live_support_var_ids):
                        continue
                    moved_indexes.add(prior_index)
                    live_support_var_ids.update(prior_var_ids - group_var_ids)
                    progress = True
            if not moved_indexes:
                continue

            moved_var_ids = self._body_var_ids(body[prior_index] for prior_index in moved_indexes) - group_var_ids
            outer_var_ids = self._body_var_ids(
                task
                for task_index, task in enumerate(body)
                if task_index != index and task_index not in claimed_indexes and task_index not in moved_indexes
            )
            ordered_indexes = tuple(sorted(moved_indexes))
            if moved_var_ids & outer_var_ids:
                if not all(isinstance(body[support_index], mm.Aggregate) for support_index in ordered_indexes):
                    continue
                support_by_aggregate[index] = ordered_indexes
                continue

            support_by_aggregate[index] = ordered_indexes
            claimed_indexes |= moved_indexes

        return support_by_aggregate, claimed_indexes

    def _aggregate_internal_var_ids(self, task: mm.Aggregate) -> set[int]:
        var_ids = task_var_ids(task.body if isinstance(task.body, mm.Task) else mm.Logical(body=(task.body,)))
        for value in (*task.projection, *task.args[:-1]):
            if isinstance(value, mm.Var):
                var_ids.add(value.id)
        return var_ids

    def _aggregate_group_var_ids(self, task: mm.Aggregate) -> set[int]:
        return {value.id for value in task.group if isinstance(value, mm.Var)}

    def _body_var_ids(self, tasks) -> set[int]:
        var_ids: set[int] = set()
        for task in tasks:
            var_ids |= task_var_ids(task)
        return var_ids


class _AggregatePackingRewriter(Rewriter):
    def logical(self, node: mm.Logical):
        body = tuple(self._rewrite(node.body)) #type: ignore
        if body != node.body:
            node = node.mut(body=body)
        packed_body = self._pack_aggregate_runs(node.body)
        return node.mut(body=packed_body) if packed_body != node.body else node

    def _pack_aggregate_runs(self, body: tuple[mm.Task, ...]) -> tuple[mm.Task, ...]:
        packed: list[mm.Task] = []
        index = 0
        while index < len(body):
            aggregates = self._pack_aggregates(body[index])
            if not aggregates:
                packed.append(body[index])
                index += 1
                continue

            support_prefix = _aggregate_scope_prefix(body[index])
            signature = _aggregate_signature_vars(aggregates[0])
            run_aggregates = list(aggregates)
            end = index + 1
            while end < len(body):
                next_aggregates = self._pack_aggregates(body[end])
                if not next_aggregates:
                    break
                if _aggregate_scope_prefix(body[end]) != support_prefix:
                    break
                if any(_aggregate_signature_vars(aggregate) != signature for aggregate in next_aggregates):
                    break
                run_aggregates.extend(next_aggregates)
                end += 1

            if len(run_aggregates) == 1 and isinstance(body[index], mm.Logical):
                packed.append(body[index])
            elif len(run_aggregates) == 1:
                packed.append(mm.Logical(optional=True, body=(run_aggregates[0],)))
            else:
                packed.append(mm.Logical(optional=True, scope=True, body=tuple((*support_prefix, *run_aggregates))))
            index = end
        return tuple(packed)

    def _pack_aggregates(self, task: mm.Task) -> tuple[mm.Aggregate, ...]:
        aggregates = _logical_aggregate_run(task, allow_scope=True)
        if not aggregates:
            return ()
        if any(aggregate.aggregation.name.strip().lower() == "rank" for aggregate in aggregates):
            return ()
        return aggregates


class _RelationVersionRewriter(Rewriter):
    def __init__(
        self,
        version_state: BlockVersionState,
        *,
        target: Target | None = None,
        recursive_relation_tables: dict[int, mm.Table] | None = None,
    ) -> None:
        super().__init__()
        self._version_state = version_state
        self._target = target
        self._recursive_relation_tables = recursive_relation_tables or {}

    def rewrite_task(self, task: mm.Task) -> mm.Task:
        return self(task)

    def lookup(self, node: mm.Lookup):
        table = None
        relation = node.relation
        relation_id = getattr(relation, "id", None)
        if isinstance(relation_id, int):
            table = self._recursive_relation_tables.get(relation_id)
        if (
            table is None
            and
            self._target is not None
            and self._target.kind == "entity"
            and isinstance(relation, mm.ScalarType)
            and not isinstance(relation, mm.Table)
            and getattr(relation, "id", None) != self._target.anchor_id
        ):
            table = self._version_state.entry_table_for(relation.id)
        if table is None:
            table = self._version_state.latest_table_for(node.relation.id)
        if table is None:
            return node
        return node.mut(relation=table)


class StorageVersionNormalizer:
    def __init__(self) -> None:
        self._canonical = SQLNormalizer()
        self._table_cache: dict[tuple[int, str], mm.Table] = {}

    def normalize_sql_block(
        self,
        planned_block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
    ) -> NormalizedSQLBlock | None:
        block_version_state = BlockVersionState(
            latest_tables_by_relation_id=dict(version_state.latest_tables_by_relation_id),
            entry_tables_by_relation_id=dict(version_state.latest_tables_by_relation_id),
            materialized_tables_by_object_name={},
            stage_numbers_by_object_name={},
        )
        ordered_targets = self._ordered_targets(planned_block.targets, catalog)
        remaining_per_object = defaultdict(int)
        for planned_target in ordered_targets:
            remaining_per_object[planned_target.target.object_name] += len(planned_target.tasks)
            if planned_target.recursive:
                continue

        plan_items: list[TargetPlan | RecursiveComponentPlan] = []
        seen_recursive_components: set[tuple[int, ...]] = set()
        for planned_target in ordered_targets:
            recursive_component_relation_ids = tuple(planned_target.recursive_component_relation_ids)
            if recursive_component_relation_ids:
                if recursive_component_relation_ids in seen_recursive_components:
                    continue
                recursive_targets = tuple(
                    candidate
                    for candidate in ordered_targets
                    if tuple(candidate.recursive_component_relation_ids) == recursive_component_relation_ids
                )
                recursive_plan = self._build_recursive_component_plan(
                    recursive_component_relation_ids,
                    recursive_targets,
                    model,
                    catalog,
                    block_version_state,
                )
                if recursive_plan is not None:
                    plan_items.append(recursive_plan)
                seen_recursive_components.add(recursive_component_relation_ids)
                continue

            self._append_target_plans_smart(
                planned_target,
                model,
                catalog,
                block_version_state,
                remaining_per_object,
                plan_items,
            )

        if not plan_items:
            return None

        return NormalizedSQLBlock(
            index=planned_block.index,
            items=tuple(plan_items),
            recursive=any(target.recursive for target in planned_block.targets),
            input_relation_ids=planned_block.input_relation_ids,
            output_relation_ids=planned_block.output_relation_ids,
        )

    def bind_fragment(self, task: mm.Task, relation_tables: dict[int, mm.Table]) -> mm.Task:
        normalized = self._canonical.normalize(task)
        version_state = BlockVersionState(
            latest_tables_by_relation_id=dict(relation_tables),
            entry_tables_by_relation_id=dict(relation_tables),
        )
        return _RelationVersionRewriter(version_state).rewrite_task(normalized)

    def _contribution_reads_target(
        self,
        contribution_task: mm.Task,
        planned_target: PlannedTarget,
        catalog: Catalog,
    ) -> bool:
        """Return True if this contribution's task reads from the target entity's own store."""
        source_objects: set[str] = set()
        self._collect_source_objects(contribution_task, source_objects, catalog)
        return planned_target.target.object_name in source_objects

    def _append_target_plans_smart(
        self,
        planned_target: PlannedTarget,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        remaining_per_object: dict[str, int],
        plan_items: list[TargetPlan | RecursiveComponentPlan],
    ) -> None:
        """Emit the optimal mix of batched and chained stage views for a self-dependent target.

        Contributions that don't read from the target entity are independent — they
        can all be collapsed into a single UNION ALL stage regardless of their source
        order. Contributions that do read from the target must chain: each one gets
        its own stage view whose prior_table points to the previous stage, ensuring
        it sees all rows written so far before it executes.

        """
        object_name = planned_target.target.object_name
        independent = [
            c for c in planned_target.tasks
            if not self._contribution_reads_target(c, planned_target, catalog)
        ]
        self_dependent = [
            c for c in planned_target.tasks
            if self._contribution_reads_target(c, planned_target, catalog)
        ]

        # Batch all independent contributions into one stage view first.
        # Self-reading rules will chain off this stage and see all independent rows.
        if independent:
            for _ in independent:
                remaining_per_object[object_name] -= 1
            output_name = self._next_output_name(object_name, remaining_per_object, version_state)
            self._append_target_plan_item(
                planned_target,
                tuple(
                    stage_task
                    for c in independent
                    for stage_task in self._rewrite_target_tasks(
                        c, planned_target.target, version_state, output_name, model, catalog,
                    )
                ),
                output_name,
                model,
                catalog,
                version_state,
                plan_items,
            )

        # Chain each self-reading contribution separately: each stage carries
        # forward the prior stage's rows and appends its own derived rows.
        for contribution in self_dependent:
            remaining_per_object[object_name] -= 1
            output_name = self._next_output_name(object_name, remaining_per_object, version_state)
            self._append_target_plan_item(
                planned_target,
                self._rewrite_target_tasks(
                    contribution, planned_target.target, version_state, output_name, model, catalog,
                ),
                output_name,
                model,
                catalog,
                version_state,
                plan_items,
            )

    def _append_target_plan_item(
        self,
        planned_target: PlannedTarget,
        stage_tasks: tuple[mm.Task, ...],
        output_name: str,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        plan_items: list[TargetPlan | RecursiveComponentPlan],
    ) -> None:
        if not stage_tasks:
            return
        object_name = planned_target.target.object_name
        prior_table = version_state.prior_table_for(object_name)
        output_table = self._output_table_for_target(planned_target.target, output_name, model, catalog)
        plan_items.append(
            TargetPlan(
                target=planned_target.target,
                tasks=stage_tasks, #type: ignore
                output_table=output_table,
                prior_table=prior_table,
                requires_coalesce=not self._can_skip_target_coalesce(
                    planned_target.target,
                    stage_tasks, #type: ignore
                    prior_table,
                    catalog,
                ),
            )
        )
        self._bind_target_relations(planned_target.target, model, catalog, version_state, output_name)
        version_state.materialize_object(object_name, output_table)

    def _build_recursive_component_plan(
        self,
        recursive_component_relation_ids: tuple[int, ...],
        planned_targets: tuple[PlannedTarget, ...],
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
    ) -> RecursiveComponentPlan | None:
        marker_tables_by_relation_id: dict[int, mm.Table] = {}
        marker_output_tables_by_object_name: dict[str, mm.Table] = {}
        for planned_target in planned_targets:
            marker_name = name_scheme.recursive_marker_name(planned_target.target.object_name)
            marker_output_tables_by_object_name[planned_target.target.object_name] = self._output_table_for_target(
                planned_target.target,
                marker_name,
                model,
                catalog,
            )
            for relation in self._relations_for_target(planned_target.target, model, catalog):
                marker_tables_by_relation_id[relation.id] = self._read_table_for_relation(relation, marker_name)

        # `reads_recursive_component` decides whether to apply marker rewriting
        # to a contribution's reads. The set of relations that actually get
        # rewritten is precisely the keys of `marker_tables_by_relation_id`
        # (concept + properties of every recursive target). Using the SCC-level
        # `relation_id_set` (concept only) under-counts: a rule like
        # ``T.new(p=T2.q)`` reads property relations, not the concept relation,
        # and would incorrectly be treated as a seed.
        # Keys cover both concept relations and their property relations
        # (every relation that has a marker table).
        recursive_relation_ids = marker_tables_by_relation_id.keys()
        recursive_target_plans: list[RecursiveTargetPlan] = []
        for planned_target in planned_targets:
            output_name = planned_target.target.object_name
            prior_table = version_state.prior_table_for(output_name)
            output_table = self._output_table_for_target(planned_target.target, output_name, model, catalog)
            marker_table = marker_output_tables_by_object_name[output_name]
            seed_tasks: list[mm.Logical] = []
            recursive_tasks: list[mm.Logical] = []
            for contribution in planned_target.tasks:
                reads_recursive_component = bool(self._task_read_relation_ids(contribution) & recursive_relation_ids)
                rewritten_tasks = self._rewrite_target_tasks(
                    contribution,
                    planned_target.target,
                    version_state,
                    output_name,
                    model,
                    catalog,
                    recursive_relation_tables=marker_tables_by_relation_id if reads_recursive_component else None,
                )
                if reads_recursive_component:
                    recursive_tasks.extend(rewritten_tasks)
                else:
                    seed_tasks.extend(rewritten_tasks)
            all_tasks = tuple((*seed_tasks, *recursive_tasks))
            if not all_tasks and prior_table is None:
                continue
            recursive_target_plans.append(
                RecursiveTargetPlan(
                    target=planned_target.target,
                    seed_tasks=tuple(seed_tasks),
                    recursive_tasks=tuple(recursive_tasks),
                    output_table=output_table,
                    marker_table=marker_table,
                    prior_table=prior_table,
                    requires_coalesce=bool(recursive_tasks)
                    or not self._can_skip_target_coalesce(
                        planned_target.target,
                        all_tasks,
                        prior_table,
                        catalog,
                    ),
                )
            )

        if not recursive_target_plans:
            return None

        for recursive_target in recursive_target_plans:
            output_name = recursive_target.output_table.uri or recursive_target.output_table.name
            self._bind_target_relations(recursive_target.target, model, catalog, version_state, output_name)
            version_state.materialize_object(recursive_target.target.object_name, recursive_target.output_table)

        return RecursiveComponentPlan(
            relation_ids=recursive_component_relation_ids,
            targets=tuple(recursive_target_plans),
        )

    def _rewrite_target_tasks(
        self,
        task: mm.Task,
        target: Target,
        version_state: BlockVersionState,
        output_name: str,
        model: mm.Model,
        catalog: Catalog,
        recursive_relation_tables: dict[int, mm.Table] | None = None,
    ) -> tuple[mm.Logical, ...]:
        normalized_task = self._canonical.normalize(task)
        rewritten_task = _RelationVersionRewriter(
            version_state,
            target=target,
            recursive_relation_tables=recursive_relation_tables,
        ).rewrite_task(normalized_task)
        if not isinstance(rewritten_task, mm.Logical):
            return ()
        output_table = self._output_table_for_target(target, output_name, model, catalog)
        split_tasks = self._split_entity_task(rewritten_task, output_table) if target.kind == "entity" else (rewritten_task,)
        return tuple(self._bind_output_task(split_task, target, output_table) for split_task in split_tasks)

    def _bind_target_relations(
        self,
        target: Target,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        output_name: str,
    ) -> None:
        for relation in self._relations_for_target(target, model, catalog):
            version_state.bind_relation_table(relation.id, self._read_table_for_relation(relation, output_name))

    def _can_skip_target_coalesce(
        self,
        target: Target,
        stage_tasks: tuple[mm.Logical, ...],
        prior_table: mm.Table | None,
        catalog: Catalog,
    ) -> bool:
        if target.kind != "entity" or prior_table is not None or len(stage_tasks) != 1:
            return False
        return self._is_direct_source_import_task(stage_tasks[0], target, catalog)

    def _is_direct_source_import_task(self, task: mm.Logical, target: Target, catalog: Catalog) -> bool:
        body = tuple(task.body)
        updates = tuple(child for child in body if isinstance(child, mm.Update))
        constructs = tuple(child for child in body if isinstance(child, mm.Construct))
        lookups = tuple(child for child in body if isinstance(child, mm.Lookup))
        optional_logicals = tuple(
            child for child in body if isinstance(child, mm.Logical) and child.optional
        )
        other_children = tuple(
            child
            for child in body
            if child not in updates and child not in constructs and child not in lookups and child not in optional_logicals
        )

        if other_children or len(updates) != 1 or len(constructs) != 1 or len(lookups) != 1:
            return False
        source_lookup = lookups[0]
        try:
            catalog.data_store(source_lookup.relation) #type: ignore
        except KeyError:
            return False
        source_var = source_lookup.args[0] if source_lookup.args else None
        if not isinstance(source_var, mm.Var):
            return False
        update = updates[0]
        update_name = getattr(update.relation, "uri", None) or getattr(update.relation, "name", None)
        if update_name != target.object_name or len(update.args) != len(target.column_names):
            return False
        if not isinstance(update.args[0], mm.Var):
            return False

        allowed_value_vars = {arg.id for arg in update.args if isinstance(arg, mm.Var)}
        for logical in optional_logicals:
            nested_body = tuple(logical.body)
            if not nested_body:
                continue
            if len(nested_body) != 1 or not isinstance(nested_body[0], mm.Lookup):
                return False
            nested_lookup = nested_body[0]
            if len(nested_lookup.args) != 2:
                return False
            owner_arg, value_arg = nested_lookup.args
            if not isinstance(owner_arg, mm.Var) or owner_arg.id != source_var.id:
                return False
            if isinstance(value_arg, mm.Var) and value_arg.id not in allowed_value_vars:
                return False
        return True

    def _next_output_name(
        self,
        object_name: str,
        remaining_per_object: dict[str, int],
        version_state: BlockVersionState,
    ) -> str:
        stage_index = version_state.next_output_name(object_name)
        if remaining_per_object[object_name] == 0:
            return object_name
        return name_scheme.stage_view_name(object_name, stage_index)

    def _is_self_dependent_target(self, planned_target: PlannedTarget, catalog: Catalog) -> bool:
        return planned_target.target.object_name in self._target_source_objects(planned_target, catalog)

    def initial_version_state(self, model: mm.Model, catalog: Catalog) -> BlockVersionState:
        relation_tables: dict[int, mm.Table] = {}
        for type_ in model.types:
            if not isinstance(type_, mm.ScalarType):
                continue
            if isinstance(type_, mm.Table) and getattr(type_, "uri", "").startswith("table://"):
                continue
            try:
                store = catalog.entity_store(type_)
            except KeyError:
                continue
            relation_tables[type_.id] = self._read_table_for_relation(type_, store.object_name)
        for relation in model.relations:
            if isinstance(relation, mm.Table) and getattr(relation, "uri", "").startswith("table://"):
                continue
            if catalog.is_data_column(relation):
                continue
            if catalog.is_folded_property(relation):
                owner_store = catalog.owner_store_for_property(relation)
                relation_tables[relation.id] = self._read_table_for_relation(relation, owner_store.object_name)
                continue
            try:
                store = catalog.relation_store(relation)
            except KeyError:
                continue
            relation_tables[relation.id] = self._read_table_for_relation(relation, store.object_name)
        return BlockVersionState(
            latest_tables_by_relation_id=relation_tables,
            entry_tables_by_relation_id=dict(relation_tables),
        )

    def compute_seed_object_names(
        self,
        catalog: Catalog,
        coalesced: tuple[CoalescedBlock, ...],
    ) -> tuple[str, ...]:
        written: set[str] = set()
        self_dependent: set[str] = set()
        for block in coalesced:
            for planned_target in block.targets:
                written.add(planned_target.target.object_name)
                if not planned_target.recursive and self._is_self_dependent_target(planned_target, catalog):
                    self_dependent.add(planned_target.target.object_name)
        all_store_object_names = {
            *(s.object_name for s in catalog.entity_stores.values()),
            *(s.object_name for s in catalog.relation_stores.values()),
        }
        return tuple(sorted((all_store_object_names - written) | self_dependent))

    def _ordered_targets(self, targets: tuple[PlannedTarget, ...], catalog: Catalog) -> tuple[PlannedTarget, ...]:
        grouped_targets: dict[str, list[PlannedTarget]] = {}
        first_index: dict[str, int] = {}
        for index, planned_target in enumerate(targets):
            object_name = planned_target.target.object_name
            grouped_targets.setdefault(object_name, []).append(planned_target)
            first_index.setdefault(object_name, index)

        object_names = tuple(grouped_targets)
        dependencies: dict[str, set[str]] = {object_name: set() for object_name in object_names}
        for object_name, object_targets in grouped_targets.items():
            for planned_target in object_targets:
                for source_name in self._target_source_objects(planned_target, catalog):
                    if source_name in dependencies and source_name != object_name:
                        dependencies[object_name].add(source_name)

        available = sorted(
            (object_name for object_name, deps in dependencies.items() if not deps),
            key=lambda name: first_index[name],
        )
        pending = {name: set(deps) for name, deps in dependencies.items()}
        ordered_object_names: list[str] = []

        while available:
            current = available.pop(0)
            ordered_object_names.append(current)
            for candidate in object_names:
                if current in pending[candidate]:
                    pending[candidate].remove(current)
                    if not pending[candidate] and candidate not in ordered_object_names and candidate not in available:
                        available.append(candidate)
            available.sort(key=lambda name: first_index[name])

        for object_name in object_names:
            if object_name not in ordered_object_names:
                ordered_object_names.append(object_name)

        ordered_targets: list[PlannedTarget] = []
        for object_name in ordered_object_names:
            ordered_targets.extend(grouped_targets[object_name])
        return tuple(ordered_targets)

    def _target_source_objects(self, planned_target: PlannedTarget, catalog: Catalog) -> set[str]:
        source_objects: set[str] = set()
        for contribution in planned_target.tasks:
            self._collect_source_objects(contribution, source_objects, catalog)
        return source_objects

    def _collect_source_objects(self, task: mm.Task, source_objects: set[str], catalog: Catalog) -> None:
        if isinstance(task, mm.Lookup):
            source_name = self._source_object_name_for_relation(task.relation, catalog)
            if source_name is not None:
                source_objects.add(source_name)
            return
        if isinstance(task, mm.Logical):
            for child in task.body:
                self._collect_source_objects(child, source_objects, catalog)
            return
        if isinstance(task, (mm.Union, mm.Match)):
            for child in task.tasks:
                self._collect_source_objects(child, source_objects, catalog)
            return
        if isinstance(task, mm.Not):
            self._collect_source_objects(task.task, source_objects, catalog)
            return
        if isinstance(task, mm.Aggregate):
            self._collect_source_objects(task.body, source_objects, catalog)

    def _task_read_relation_ids(self, task: mm.Task) -> set[int]:
        relation_ids: set[int] = set()

        def collect(node: mm.Task) -> None:
            if isinstance(node, mm.Lookup):
                relation_id = getattr(node.relation, "id", None)
                if isinstance(relation_id, int):
                    relation_ids.add(relation_id)
                return
            if isinstance(node, mm.Logical):
                for child in node.body:
                    collect(child)
                return
            if isinstance(node, (mm.Union, mm.Match)):
                for child in node.tasks:
                    collect(child)
                return
            if isinstance(node, mm.Not):
                collect(node.task)
                return
            if isinstance(node, mm.Aggregate):
                collect(node.body if isinstance(node.body, mm.Task) else mm.Logical(body=tuple(node.body)))

        collect(task)
        return relation_ids

    def _source_object_name_for_relation(self, relation: mm.Relation, catalog: Catalog) -> str | None:
        try:
            data_store = catalog.data_store(relation) #type: ignore
        except KeyError:
            data_store = None
        if data_store is not None:
            return data_store.object_name
        if catalog.is_folded_property(relation):
            return catalog.owner_store_for_property(relation).object_name
        try:
            store = catalog.entity_store(relation)
        except KeyError:
            store = None
        if store is not None:
            return store.object_name
        try:
            store = catalog.relation_store(relation)
        except KeyError:
            return None
        return store.object_name

    def _relations_for_target(self, target: Target, model: mm.Model, catalog: Catalog) -> tuple[mm.Relation, ...]:
        if target.kind == "relation":
            for relation in model.relations:
                try:
                    store = catalog.relation_store(relation)
                except KeyError:
                    continue
                if store.object_name == target.object_name:
                    return (relation,)
            return ()

        owner_type = next(
            (
                type_
                for type_ in model.types
                if isinstance(type_, mm.ScalarType)
                and getattr(type_, "id", None) == target.anchor_id
            ),
            None,
        )
        if owner_type is None:
            owner_store = next(
                (store for store in catalog.entity_stores.values() if store.object_name == target.object_name),
                None,
            )
            if owner_store is None:
                return ()
            owner_type = next(
                (
                    type_
                    for type_ in model.types
                    if isinstance(type_, mm.ScalarType)
                    and getattr(type_, "id", None) == owner_store.type_id
                ),
                None,
            )
        if owner_type is None:
            return ()

        folded_properties = tuple(
            relation
            for relation in model.relations
            if catalog.is_folded_property(relation)
            and catalog.owner_store_for_property(relation).object_name == target.object_name
        )
        return (owner_type, *folded_properties)

    def _read_table_for_relation(self, relation: mm.Relation, source_name: str) -> mm.Table:
        cache_key = (relation.id, source_name)
        table = self._table_cache.get(cache_key)
        if table is not None:
            return table
        source_token = source_name.rsplit(".", 1)[-1]
        table = mm.Table(name=f"{relation.name}__{source_token}", uri=source_name)
        table._force_columns((relation,))
        self._table_cache[cache_key] = table
        return table

    def _output_table_for_target(self, target: Target, output_name: str, model: mm.Model, catalog: Catalog) -> mm.Table:
        table = mm.Table(name=output_name.rsplit(".", 1)[-1], uri=output_name)
        table._force_columns(self._relations_for_target(target, model, catalog))
        return table

    def _bind_output_task(self, task: mm.Logical, target: Target, output_table: mm.Table) -> mm.Logical:
        updates = tuple(child for child in task.body if isinstance(child, mm.Update))
        body = [child for child in task.body if not isinstance(child, mm.Update)]
        row_update = self._output_update_for_target(task, target, output_table, updates)
        body.append(row_update)
        return task.mut(body=tuple(body))

    def _output_update_for_target(
        self,
        task: mm.Logical,
        target: Target,
        output_table: mm.Table,
        updates: tuple[mm.Update, ...],
    ) -> mm.Update:
        if target.kind == "relation":
            update = updates[0] if updates else None
            args = tuple(update.args) if update is not None else tuple(mm.Literal(None) for _ in target.column_names) #type: ignore
            return mm.Update(relation=output_table, args=args)

        constructs = tuple(child for child in task.body if isinstance(child, mm.Construct))
        values_by_column: dict[str, mm.Value] = {column_name: mm.Literal(None) for column_name in target.column_names} #type: ignore
        target_construct = self._target_construct_for_output(output_table, constructs)
        owner_arg = updates[0].args[0] if updates and updates[0].args else None
        if isinstance(owner_arg, mm.Var):
            values_by_column["_id"] = owner_arg
        elif target_construct is not None:
            values_by_column["_id"] = target_construct.id_var
        elif owner_arg is not None:
            values_by_column["_id"] = owner_arg
        for update in updates:
            relation = update.relation
            if relation.name in values_by_column and update.args:
                values_by_column[relation.name] = update.args[-1]
        # Identifying-property columns may not have an Update — e.g. a rule
        # using `Node.id == X` to denote the entity carries the column value
        # only in a Lookup. Surface that value into the Table-update so the
        # column is populated instead of NULL.
        target_column_relation_ids = {
            getattr(column, "id", None) for column in output_table.columns
        }
        for child in task.body:
            if not isinstance(child, mm.Lookup) or len(child.args) != 2:
                continue
            relation = child.relation
            if isinstance(relation, mm.Table) and len(relation.columns) == 1:
                column0 = relation.columns[0]
                if isinstance(column0, mm.Relation):
                    relation = column0
            if not isinstance(relation, mm.Relation):
                continue
            if relation.id not in target_column_relation_ids:
                continue
            if relation.name in values_by_column:
                current = values_by_column[relation.name]
                if isinstance(current, mm.Literal) and current.value is None:
                    values_by_column[relation.name] = child.args[-1]  # type: ignore[assignment]
        return mm.Update(
            relation=output_table,
            args=tuple(values_by_column[column_name] for column_name in target.column_names),
        )

    def _target_construct_for_output(
        self,
        output_table: mm.Table,
        constructs: tuple[mm.Construct, ...],
    ) -> mm.Construct | None:
        target_type = output_table.columns[0] if output_table.columns else None
        target_type_id = getattr(target_type, "id", None)
        if isinstance(target_type_id, int):
            for construct in constructs:
                if getattr(construct.id_var.type, "id", None) == target_type_id:
                    return construct
        return constructs[0] if constructs else None

    def _split_entity_task(self, task: mm.Logical, output_table: mm.Table) -> tuple[mm.Logical, ...]:
        constructs = tuple(child for child in task.body if isinstance(child, mm.Construct))
        updates = tuple(child for child in task.body if isinstance(child, mm.Update))
        if not constructs and not updates:
            return (task,)

        owner_var_ids: list[int] = []
        for update in updates:
            if update.args and isinstance(update.args[0], mm.Var) and update.args[0].id not in owner_var_ids:
                owner_var_ids.append(update.args[0].id)
        if not owner_var_ids:
            for construct in constructs:
                if self._construct_matches_output(construct, output_table) and construct.id_var.id not in owner_var_ids:
                    owner_var_ids.append(construct.id_var.id)
        if not owner_var_ids:
            return (task,)

        construct_by_var_id = {construct.id_var.id: construct for construct in constructs}
        passthrough = tuple(child for child in task.body if not isinstance(child, (mm.Construct, mm.Update)))
        split_tasks: list[mm.Logical] = []
        for owner_var_id in owner_var_ids:
            required_construct_ids = self._construct_dependency_ids({owner_var_id}, construct_by_var_id)
            kept_updates = tuple(
                update
                for update in updates
                if update.args and isinstance(update.args[0], mm.Var) and update.args[0].id == owner_var_id
                and self._update_matches_entity_output(update, output_table)
            )
            for update in kept_updates:
                referenced_ids = {
                    arg.id
                    for arg in update.args
                    if isinstance(arg, mm.Var) and arg.id in construct_by_var_id
                }
                required_construct_ids |= self._construct_dependency_ids(referenced_ids, construct_by_var_id)
            kept_constructs = tuple(
                construct
                for construct in constructs
                if construct.id_var.id in required_construct_ids
            )
            needed_var_ids = task_var_ids(tuple((*kept_constructs, *kept_updates)))
            kept_passthrough = self._prune_passthrough_tasks(passthrough, needed_var_ids)
            split_tasks.append(mm.Logical(body=(*kept_constructs, *kept_passthrough, *kept_updates), optional=task.optional, scope=task.scope))
        return tuple(split_tasks)

    def _update_matches_entity_output(self, update: mm.Update, output_table: mm.Table) -> bool:
        relation_id = getattr(update.relation, "id", None)
        return any(getattr(column, "id", None) == relation_id for column in output_table.columns)

    def _prune_passthrough_tasks(
        self,
        tasks: tuple[mm.Task, ...],
        needed_var_ids: set[int],
    ) -> tuple[mm.Task, ...]:
        kept_indices: set[int] = set()
        live_var_ids = set(needed_var_ids)

        changed = True
        while changed:
            changed = False
            for index in range(len(tasks) - 1, -1, -1):
                if index in kept_indices:
                    continue
                current_var_ids = task_var_ids(tasks[index])
                if current_var_ids & live_var_ids:
                    kept_indices.add(index)
                    live_var_ids.update(current_var_ids)
                    changed = True

        for index, child in enumerate(tasks):
            if index in kept_indices:
                continue
            if self._is_filter_task(child) and task_var_ids(child) <= live_var_ids:
                kept_indices.add(index)

        return tuple(child for index, child in enumerate(tasks) if index in kept_indices)

    def _is_filter_task(self, task: mm.Task) -> bool:
        if isinstance(task, mm.Lookup):
            relation_name = task.relation.name
            return relation_name in {"=", "!=", "<", "<=", ">", ">="}
        if isinstance(task, mm.Not):
            return True
        if isinstance(task, (mm.Union, mm.Match)):
            return len(task.outputs) == 0
        if isinstance(task, mm.Logical):
            return all(self._is_filter_task(child) for child in task.body)
        return False

    def _construct_dependency_ids(
        self,
        seed_ids: set[int],
        construct_by_var_id: dict[int, mm.Construct],
    ) -> set[int]:
        required_ids = {var_id for var_id in seed_ids if var_id in construct_by_var_id}
        pending = list(required_ids)
        while pending:
            construct = construct_by_var_id[pending.pop()]
            for value in construct.values:
                if isinstance(value, mm.Var) and value.id in construct_by_var_id and value.id not in required_ids:
                    required_ids.add(value.id)
                    pending.append(value.id)
        return required_ids

    def _construct_matches_output(self, construct: mm.Construct, output_table: mm.Table) -> bool:
        target_type = output_table.columns[0] if output_table.columns else None
        target_type_id = getattr(target_type, "id", None)
        current = construct.id_var.type
        seen: set[int] = set()
        while isinstance(current, mm.ScalarType):
            current_id = getattr(current, "id", None)
            if current_id == target_type_id:
                return True
            if not isinstance(current_id, int) or current_id in seen:
                break
            seen.add(current_id)
            super_types = tuple(
                super_type
                for super_type in getattr(current, "super_types", ())
                if isinstance(super_type, mm.ScalarType)
            )
            current = super_types[0] if super_types else None
        return False


class _AggregateUnionOutputExtender(Rewriter):
    """Rewrite ``Aggregate(group=Ks, body=Logical([Union(tasks=Bs, outputs=Os), ...]))``
    so the Union also outputs each per-key, with universe Lookups injected
    into branches that fail to ground a per-key internally.

    Motivation: the SQL lowerer's Union-lift can decorrelate a Union into a
    plain JOIN only when each branch is scope-closed and per-keys reach outer
    scope via the Union's outputs. When a branch grounds per-keys only by
    parent-correlation (e.g., recursion's ``select(0).where(u == v)`` base
    case), the lowerer falls back to ``JOIN LATERAL``, which Snowflake refuses
    to evaluate.

    After this rewrite:
      * Every per-key has an inner anchor in every branch (existing typed
        Lookup, or an injected ``Lookup(k.type, (k,))`` population lookup).
      * The Union projects each per-key as an output. The lowerer binds the
        per-keys to the Union's output columns post-lift, ``PerKeyAnchoring``
        strips them, ``_emit_group_keys`` groups on those output columns, and
        the outer aggregate joins on them. No LATERAL.

    All-or-nothing: if any per-key in any branch can't be anchored, the rule
    aborts for that Aggregate and the lowerer emits LATERAL as today.

    NULL-semantics: injected population Lookups are inner constraints (only
    entities in the population). The aggregate's input multiset is identical
    to the LATERAL-emitted form; only the SQL shape changes.
    """

    _EQ_REL = "="

    def aggregate(self, node: mm.Aggregate):
        if not isinstance(node.body, mm.Logical):
            return node
        per_keys = tuple(var for var in node.group if isinstance(var, mm.Var))
        if not per_keys:
            return node
        new_body = self._rewrite_body(node.body, per_keys)
        return node.mut(body=new_body) if new_body is not node.body else node

    def _rewrite_body(
        self, body: mm.Logical, per_keys: tuple[mm.Var, ...]
    ) -> mm.Logical:
        new_children: list[mm.Task] = []
        changed = False
        for child in body.body:
            if isinstance(child, mm.Union):
                rewritten = self._try_rewrite_union(child, per_keys)
                if rewritten is not child:
                    changed = True
                new_children.append(rewritten)
            else:
                new_children.append(child)
        return body.mut(body=tuple(new_children)) if changed else body

    def _try_rewrite_union(
        self, union: mm.Union, per_keys: tuple[mm.Var, ...]
    ) -> mm.Union:
        existing_output_ids = {var.id for var in union.outputs}
        missing_per_keys = tuple(k for k in per_keys if k.id not in existing_output_ids)
        if not missing_per_keys:
            return union  # already projects every per-key
        if not all(self._is_population_typable(k.type) for k in per_keys):
            return union  # at least one per-key has no injectable universe; abort
        new_branches: list[mm.Task] = []
        for branch in union.tasks:
            if not isinstance(branch, mm.Logical):
                return union  # unsupported branch shape; abort
            injected = tuple(mm.Lookup(relation=k.type, args=(k,)) for k in per_keys)
            new_branches.append(branch.mut(body=tuple((*injected, *branch.body))))
        new_outputs = tuple((*union.outputs, *missing_per_keys))
        return union.mut(tasks=tuple(new_branches), outputs=new_outputs)

    @staticmethod
    def _is_population_typable(vtype: mm.Type) -> bool:
        """True iff ``Lookup(vtype, (v,))`` is a valid population lookup —
        a concept-like ScalarType. Excludes primitive number/union/list/tuple
        types and Table/Data sources (no natural universe)."""
        if not isinstance(vtype, mm.TypeNode):
            return False
        if isinstance(vtype, (mm.NumberType, mm.UnionType, mm.ListType, mm.TupleType, mm.Table)):
            return False
        return bool(vtype.fields)


__all__ = ["SQLNormalizer", "StorageVersionNormalizer"]
