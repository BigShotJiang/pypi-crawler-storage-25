import json
import re
from decimal import Decimal
from math import isnan
from typing import TYPE_CHECKING, Any, Mapping, cast, Sequence
import pandas as pd

from v0.relationalai.clients.result_helpers import Int128Dtype

if TYPE_CHECKING:
    import snowflake.snowpark
    from .artifacts import SemiNaiveLoop, StoreColumn, View

from ....config.config_fields import DEFAULT_TABLE_MATERIALIZATION, TableMaterialization
from ...std.datetime_format import DateFormatField, DateFormatLiteral, DateFormatPart
from ._utils import resolve_by_table_name
from .sql_ir_traversal import query_has_base_table
from ....util.error import warn as _warn
from .sql_backend import SQLBackend
from .artifacts import SemiNaiveTable
from .emitter import SQLEmitter


# Per-token mapping for Snowflake's TO_VARCHAR / TO_TIMESTAMP format strings.
# Tokens absent here have no native single-format-element spelling on Snowflake
# (typically because Snowflake's TO_VARCHAR has no FM-style "no padding"
# modifier); those are emitted as concatenated per-token sub-expressions.
_SF_NATIVE_FORMAT_BY_KIND: dict[str, str] = {
    "year_4":          "YYYY",
    "year_2":          "YY",
    "month_padded":    "MM",
    "day_padded":      "DD",
    "hour24_padded":   "HH24",
    "hour12_padded":   "HH12",
    "minute_padded":   "MI",
    "second_padded":   "SS",
    "millisecond":     "FF3",
    "weekday_abbr":    "DY",
    "month_abbr":      "MON",
    "ampm":            "AM",
    "tz_offset":       "TZH:TZM",
    "tz_name":         "TZD",
}

# EXTRACT field names for the unpadded fallback path. Same field names work
# for both DuckDB and Snowflake at the call sites below.
_SF_EXTRACT_UNIT_BY_KIND: dict[str, str] = {
    "month_unpadded":     "MONTH",
    "day_unpadded":       "DAY",
    "hour24_unpadded":    "HOUR",
    "minute_unpadded":    "MINUTE",
    "second_unpadded":    "SECOND",
    "hour12_unpadded":    "HOUR",
}


class SnowflakeBackend(SQLBackend):
    # Snowflake spellings for SQL functions emitted with DuckDB-style names.
    # Date/time format and timezone conversion go through dedicated backend
    # methods (emit_format_datetime / emit_parse_datetime / convert_*_tz)
    # because the SQL *shape* — not just the function name — differs.
    _function_aliases = {
        "DATE_DIFF":      "DATEDIFF",
        "MAKE_DATE":      "DATE_FROM_PARTS",
        "MAKE_TIMESTAMP": "TIMESTAMP_FROM_PARTS",
        "LEVENSHTEIN":    "EDITDISTANCE",
    }

    def __init__(
        self,
        session,
        database: str,
        table_materialization_default: TableMaterialization = DEFAULT_TABLE_MATERIALIZATION,
        table_materialization: Mapping[str, TableMaterialization] | None = None,
        schema_name: str = "",
    ) -> None:
        super().__init__(database, schema_name)
        self._session = session
        self._table_materialization_default = table_materialization_default
        self._warehouse: str | None = None  # lazily fetched from session
        self._table_materialization: dict[str, TableMaterialization] = {
            k.lower(): v for k, v in (table_materialization or {}).items()
        }

    #------------------------------------------------------
    # Dialect handling
    #------------------------------------------------------
    _UNQUOTED_IDENTIFIER_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_$]*$")
    # Conservative reserved-word set for object identifiers in Snowflake paths.
    _RESERVED_IDENTIFIERS = frozenset(
        {
            "ALL",
            "ALTER",
            "AND",
            "ANY",
            "AS",
            "BETWEEN",
            "BY",
            "CASE",
            "CAST",
            "CHECK",
            "COLUMN",
            "CONNECT",
            "CONSTRAINT",
            "CREATE",
            "CROSS",
            "CURRENT",
            "CURRENT_DATE",
            "CURRENT_TIME",
            "CURRENT_TIMESTAMP",
            "CURRENT_USER",
            "DATABASE",
            "DELETE",
            "DISTINCT",
            "DROP",
            "ELSE",
            "EXISTS",
            "FALSE",
            "FOLLOWING",
            "FOR",
            "FROM",
            "FULL",
            "GRANT",
            "GROUP",
            "HAVING",
            "ILIKE",
            "IN",
            "INCREMENT",
            "INNER",
            "INSERT",
            "INTERSECT",
            "INTO",
            "IS",
            "ISSUE",
            "JOIN",
            "LATERAL",
            "LEFT",
            "LIKE",
            "LOCALTIME",
            "LOCALTIMESTAMP",
            "MINUS",
            "NATURAL",
            "NOT",
            "NULL",
            "OF",
            "ON",
            "OR",
            "ORDER",
            "QUALIFY",
            "REGEXP",
            "REVOKE",
            "RIGHT",
            "RLIKE",
            "ROW",
            "ROWS",
            "SAMPLE",
            "SCHEMA",
            "SELECT",
            "SET",
            "SOME",
            "START",
            "TABLE",
            "TABLESAMPLE",
            "THEN",
            "TO",
            "TRIGGER",
            "TRUE",
            "TRY_CAST",
            "UNION",
            "UNIQUE",
            "UPDATE",
            "USING",
            "VALUES",
            "VIEW",
            "WHEN",
            "WHENEVER",
            "WHERE",
            "WITH",
        }
    )
    _IS_DYNAMIC_TABLE_RE = re.compile(
        r'^\s*CREATE\s+OR\s+REPLACE\s+DYNAMIC\s+TABLE\b', re.IGNORECASE
    )
    _IS_VIEW_RE = re.compile(
        r'^\s*CREATE\s+OR\s+REPLACE\s+VIEW\b', re.IGNORECASE
    )
    # Matches FROM/JOIN followed by a (possibly qualified, possibly quoted) table reference.
    _TABLE_REF_RE = re.compile(
        r'\b(FROM|JOIN)\s+((?:"[^"]*"|\w+)(?:\.(?:"[^"]*"|\w+))*)',
        re.IGNORECASE,
    )

    def dialect_name(self) -> str:
        return "snowflake"

    #------------------------------------------------------
    # Date/time formatting & timezone conversion
    #------------------------------------------------------

    def emit_format_datetime(
        self,
        value_sql: str,
        parts: list[DateFormatPart],
        *,
        value_kind: str,
    ) -> str:
        del value_kind
        pieces = [self._sf_format_piece(value_sql, p) for p in parts]
        if not pieces:
            return "''"
        if len(pieces) == 1:
            return pieces[0]
        return "(" + " || ".join(pieces) + ")"

    def emit_parse_datetime(
        self,
        value_sql: str,
        parts: list[DateFormatPart],
        *,
        target: str,
        has_tz: bool,
    ) -> str:
        # Snowflake's TO_TIMESTAMP wants a Snowflake format string. The set of
        # tokens that show up in parse-format strings is small (the public
        # std.datetime.ISO.* constants), all of which map natively.
        fmt = "".join(self._sf_parse_token(p) for p in parts)
        fmt_sql = "'" + fmt.replace("'", "''") + "'"
        # TO_TIMESTAMP returns TIMESTAMP_NTZ even when the format includes TZH/
        # TZM tokens — the offset is parsed but discarded, leaving a value that
        # CONVERT_TIMEZONE then re-interprets as session-local. Use
        # TO_TIMESTAMP_TZ for TZ-bearing formats so the offset is preserved.
        parse_fn = "TO_TIMESTAMP_TZ" if has_tz else "TO_TIMESTAMP"
        parsed = f"{parse_fn}({value_sql}, {fmt_sql})"
        if target == "date":
            return f"CAST({parsed} AS DATE)"
        if has_tz:
            return f"CAST({self.convert_tz_aware_to_utc(parsed)} AS TIMESTAMP)"
        return f"CAST({parsed} AS TIMESTAMP)"

    def convert_naive_utc_to_tz(self, value_sql: str, tz_sql: str) -> str:
        # 3-arg form: treat *value* as in 'UTC', convert to *tz_sql*.
        return f"CONVERT_TIMEZONE('UTC', {tz_sql}, {value_sql})"

    def convert_naive_tz_to_utc(self, value_sql: str, tz_sql: str) -> str:
        # 3-arg form: treat *value* as in *tz_sql*, convert to 'UTC'.
        return f"CONVERT_TIMEZONE({tz_sql}, 'UTC', {value_sql})"

    def convert_tz_aware_to_utc(self, value_sql: str) -> str:
        # 2-arg form: requires a TIMESTAMP_TZ input; converts to UTC.
        return f"CONVERT_TIMEZONE('UTC', {value_sql})"

    @staticmethod
    def _sf_format_piece(value_sql: str, part: DateFormatPart) -> str:
        if isinstance(part, DateFormatLiteral):
            # Snowflake recognizes backslash escape sequences in string
            # literals (e.g. ``'\y'`` collapses to ``'y'``); double any
            # backslashes so user-provided literal characters survive.
            text = part.text.replace("\\", "\\\\").replace("'", "''")
            return "'" + text + "'"
        assert isinstance(part, DateFormatField)
        kind = part.kind
        if kind == "millisecond":
            # SF's ``FF3`` zero-pads to three digits (``000``); the unpadded
            # Julia ``s`` token maps to DuckDB's ``%g`` (no padding). Extract
            # the millisecond component as an integer and stringify.
            ms_int = f"CAST(EXTRACT(NANOSECOND FROM {value_sql}) / 1000000 AS BIGINT)"
            return f"CAST({ms_int} AS VARCHAR)"
        native = _SF_NATIVE_FORMAT_BY_KIND.get(kind)
        if native is not None:
            return f"TO_VARCHAR({value_sql}, '{native}')"
        if kind == "weekday_full":
            # Snowflake's TO_VARCHAR ``'DAY'`` token is only recognized as part
            # of a broader date format; on its own it round-trips as the literal
            # string 'DAY'. Materialize the English day name via DAYOFWEEKISO.
            iso_dow = f"DAYOFWEEKISO({value_sql})"
            return (
                f"CASE {iso_dow} "
                "WHEN 1 THEN 'Monday' "
                "WHEN 2 THEN 'Tuesday' "
                "WHEN 3 THEN 'Wednesday' "
                "WHEN 4 THEN 'Thursday' "
                "WHEN 5 THEN 'Friday' "
                "WHEN 6 THEN 'Saturday' "
                "WHEN 7 THEN 'Sunday' END"
            )
        if kind == "month_full":
            # Snowflake's TO_VARCHAR ``'MMMM'`` token has the same gotcha as
            # ``'DAY'``: round-trips as the literal string. Materialize the
            # English month name via EXTRACT(MONTH ...).
            month_num = f"EXTRACT(MONTH FROM {value_sql})"
            return (
                f"CASE {month_num} "
                "WHEN 1 THEN 'January' "
                "WHEN 2 THEN 'February' "
                "WHEN 3 THEN 'March' "
                "WHEN 4 THEN 'April' "
                "WHEN 5 THEN 'May' "
                "WHEN 6 THEN 'June' "
                "WHEN 7 THEN 'July' "
                "WHEN 8 THEN 'August' "
                "WHEN 9 THEN 'September' "
                "WHEN 10 THEN 'October' "
                "WHEN 11 THEN 'November' "
                "WHEN 12 THEN 'December' END"
            )
        unit = _SF_EXTRACT_UNIT_BY_KIND.get(kind)
        if unit is not None:
            extracted = f"EXTRACT({unit} FROM {value_sql})"
            if kind == "hour12_unpadded":
                hr = extracted
                extracted = (
                    f"CASE WHEN MOD({hr}, 12) = 0 THEN 12 "
                    f"ELSE MOD({hr}, 12) END"
                )
            return f"CAST({extracted} AS VARCHAR)"
        raise ValueError(
            f"Unsupported datetime format token kind {kind!r} for Snowflake"
        )

    @staticmethod
    def _sf_parse_token(part: DateFormatPart) -> str:
        if isinstance(part, DateFormatLiteral):
            # Snowflake parse format strings treat unknown chars literally;
            # quote with double quotes to be safe.
            text = part.text.replace('"', '""')
            return f'"{text}"'
        assert isinstance(part, DateFormatField)
        native = _SF_NATIVE_FORMAT_BY_KIND.get(part.kind)
        if native is None:
            raise ValueError(
                f"Unsupported parse-format token kind {part.kind!r} for Snowflake"
            )
        return native

    def emit_date_arithmetic(
        self,
        *,
        base_sql: str,
        signed_value_sql: str,
        unit: str,
    ) -> str:
        # Snowflake rejects DuckDB's ``base + n * INTERVAL 1 unit`` form when
        # ``n`` is a runtime expression (the unquoted INTERVAL value is a
        # syntax error). Use ``DATEADD(unit, n, base)`` which Snowflake supports.
        if unit == "NANOSECOND":
            return f"DATEADD('MICROSECOND', CAST(({signed_value_sql}) / 1000 AS BIGINT), {base_sql})"
        return f"DATEADD('{unit}', ({signed_value_sql}), {base_sql})"

    def emit_isoweekday(self, value_sql: str) -> str:
        # Snowflake rejects ``DATE_PART('isodow', x)`` (unknown unit). The
        # equivalent value is exposed via ``DAYOFWEEKISO(x)``.
        return f"DAYOFWEEKISO({value_sql})"

    def emit_construct_timestamp_ms(
        self,
        *,
        year_sql: str,
        month_sql: str,
        day_sql: str,
        hour_sql: str,
        minute_sql: str,
        second_sql: str,
        millisecond_sql: str,
    ) -> str:
        # Snowflake's TIMESTAMP_FROM_PARTS takes integer seconds; passing a
        # fractional value truncates and loses sub-second precision. The
        # 7th argument is integer nanoseconds — convert ms to ns there.
        nanos_sql = f"CAST(({millisecond_sql}) * 1000000 AS BIGINT)"
        return (
            "TIMESTAMP_FROM_PARTS("
            f"CAST({year_sql} AS BIGINT), "
            f"CAST({month_sql} AS BIGINT), "
            f"CAST({day_sql} AS BIGINT), "
            f"CAST({hour_sql} AS BIGINT), "
            f"CAST({minute_sql} AS BIGINT), "
            f"CAST({second_sql} AS BIGINT), "
            f"{nanos_sql})"
        )

    def emit_range_table_function(
        self,
        start_sql: str,
        stop_sql: str,
        step_sql: str,
        value_col: str,
    ) -> str:
        # Snowflake has no `RANGE(...)` table function. Two viable
        # equivalents exist; we use ``ARRAY_GENERATE_RANGE`` + ``LATERAL
        # FLATTEN`` because — unlike ``WITH RECURSIVE`` — its array
        # argument is evaluated per outer row, so outer-correlated
        # ``start`` / ``stop`` / ``step`` work without tripping SF's
        # ``errno 2031`` decorrelator (which the recursive-CTE form does
        # whenever the bounds reference outer aliases). Semantics match
        # Python ``range(start, stop, step)``: the array is empty when
        # ``start >= stop`` for positive step; the lowerer currently
        # casts step to BIGINT and assumes positive.
        #
        # SF limit: ``ARRAY_GENERATE_RANGE`` caps array size at ~1M
        # elements. PyRel range queries (date ranges, integer ranges in
        # tests) are well under that bound.
        col = self._always_quote(value_col)
        return (
            "(\n"
            f"  SELECT CAST(value AS BIGINT) AS {col}\n"
            f"  FROM LATERAL FLATTEN(input => ARRAY_GENERATE_RANGE({start_sql}, {stop_sql}, {step_sql}))\n"
            ")"
        )

    def emit_range_array_expr(self, start_sql: str, stop_sql: str, step_sql: str) -> str:
        # ``ARRAY_GENERATE_RANGE(start, stop, step)`` matches Python ``range``
        # semantics (half-open). Caps at ~1M elements; PyRel range workloads
        # stay well under that.
        return f"ARRAY_GENERATE_RANGE({start_sql}, {stop_sql}, {step_sql})"

    def emit_array_column_unnest_source(self, col_sql: str, value_col: str) -> str:
        # ``FLATTEN(input => col)`` is SF's table-valued function for
        # expanding arrays. The emitter joins this via ``, LATERAL FLATTEN(...)``
        # because SF rejects the ``LEFT JOIN LATERAL ... ON`` shape for
        # table-function laterals (errno 1304/0904).
        return f"FLATTEN(input => {col_sql})"

    def format_array_column_unnest_alias(self, alias_q: str, value_col_q: str) -> str:
        # SF's FLATTEN exposes (SEQ, KEY, PATH, INDEX, VALUE, THIS). Aliasing
        # them as quoted lowercase columns lets the caller reference
        # ``alias."value"`` consistently across dialects.
        return f'AS {alias_q}("seq", "key", "path", "idx", {value_col_q}, "this")'

    def emit_regex_match(self, string_sql: str, pattern_sql: str) -> str:
        # Snowflake's parser rejects ``REGEXP_MATCHES``. ``REGEXP_LIKE`` exists
        # but matches the whole string; for the partial-match semantics the
        # caller expects, use ``REGEXP_INSTR(...) > 0`` (returns 0 when the
        # pattern does not occur anywhere in the input).
        return f"(REGEXP_INSTR({string_sql}, {pattern_sql}) > 0)"

    def emit_split_to_table(
        self,
        string_sql: str,
        sep_sql: str,
        value_col: str,
        index_col: str,
    ) -> str:
        # Snowflake's parser rejects ``STRING_SPLIT(...)``. The equivalent
        # row-producing form is the SPLIT_TO_TABLE table function, which
        # exposes (SEQ, INDEX, VALUE) where INDEX is 1-based; subtract one
        # to match the 0-based ordinality the lowerer expects.
        value_q = self._always_quote(value_col)
        index_q = self._always_quote(index_col)
        return (
            "(\n"
            f"  SELECT VALUE AS {value_q}, (INDEX - 1) AS {index_q}\n"
            f"  FROM TABLE(SPLIT_TO_TABLE({string_sql}, {sep_sql}))\n"
            ")"
        )

    def materialize_install_views_as_tables(self) -> bool:
        return True

    def _resolve_kind(self, view: "View") -> "TableMaterialization":
        """Return the effective materialization for ``view`` after fallback rules.

        ``DYNAMIC_TABLE`` materializations whose body has no base-table reference
        fall back to plain ``TABLE`` — Snowflake rejects DTs whose only sources
        are derived (row generators, VALUES literals, singleton selects). The
        base-table check is symbolic (walks the IR via
        ``sql_ir_traversal.query_has_base_table``), not a regex on the emitted
        SQL — so it correctly classifies ``FROM (VALUES ...)`` / ``FROM
        <table_function>`` / ``FROM (SELECT 1)`` as derived-only.
        """
        materialization = resolve_by_table_name(
            view.name, self._table_materialization, self._table_materialization_default,
        )
        if materialization != TableMaterialization.DYNAMIC_TABLE:
            return materialization
        if query_has_base_table(view.query):
            return materialization
        _warn(
            "Dynamic table fallback",
            f"Table {view.name!r} was configured as a DYNAMIC TABLE but its query has no "
            f"base-table reference. Snowflake requires dynamic tables to reference at "
            f"least one stored relation. Falling back to a plain TABLE.",
        )
        return TableMaterialization.TABLE

    def emit_install_ddl(self, view: "View", query_sql: str) -> str | None:
        quoted = self.quote_table_name(view.name)
        materialization = self._resolve_kind(view)

        if materialization == TableMaterialization.VIEW:
            return f"CREATE OR REPLACE VIEW {quoted} AS\n{query_sql}"

        # Seeds carry their data as VALUES in the query body and that data is constant. So
        # we install once, and do nothing at refresh.
        if not view.column_types:
            return f"CREATE OR REPLACE TABLE {quoted}\n  CHANGE_TRACKING = TRUE\nAS\n{query_sql}"

        if materialization == TableMaterialization.DYNAMIC_TABLE:
            if self._warehouse is None:
                self._warehouse = self._session.get_current_warehouse() or ""
            body = self._wrap_view_refs_with_refresh_boundary(query_sql)
            return (
                f"CREATE OR REPLACE DYNAMIC TABLE {quoted}\n"
                f"  WAREHOUSE = {self._warehouse}\n"
                f"  SCHEDULER = DISABLE\n"
                f"  INITIALIZE = ON_SCHEDULE\nAS\n{body}"
            )

        # Plain TABLE: install a typed empty shell, which is then populated by the refresh
        return self.install_table_ddl(view.name, view.column_types)

    def emit_refresh_sql(self, view: "View", query_sql: str) -> str | None:
        materialization = self._resolve_kind(view)

        # Views require no refresh
        if materialization == TableMaterialization.VIEW:
            return None

        # Seeds require no refresh
        if not view.column_types:
            return None

        # Dynamic tables: trigger a refresh
        quoted = self.quote_table_name(view.name)
        if materialization == TableMaterialization.DYNAMIC_TABLE:
            assert self.schema_name, (
                "SnowflakeBackend must be constructed with schema_name before "
                "refresh SQL is emitted for a dynamic-table-materialized view."
            )
            # Late import to avoid a cycle with orchestrator (which imports backend).
            from .orchestrator import SnowflakeTaskManager
            return SnowflakeTaskManager.dynamic_table_refresh_sql(quoted, self.meta_schema)


        # Plain tables: atomically replace contents with INSERT OVERWRITE
        cols = ", ".join(self._always_quote(c.name) for c in view.column_types)
        return f"INSERT OVERWRITE INTO {quoted} ({cols})\n{query_sql}"

    def _wrap_view_refs_with_refresh_boundary(self, query_sql: str) -> str:
        """Wrap references to view-materialized tables in DYNAMIC_TABLE_REFRESH_BOUNDARY().

        Snowflake rejects dynamic tables that read from views containing other dynamic
        tables unless the view is wrapped in DYNAMIC_TABLE_REFRESH_BOUNDARY().

        *query_sql* is always machine-generated relational SQL from ``emit_query`` — it
        contains no string literals with SQL keywords or comments, so the regex match
        against FROM/JOIN clauses will not produce false positives.
        """
        def _replace(m: re.Match) -> str:
            keyword, table_ref = m.group(1), m.group(2)
            materialization = resolve_by_table_name(
                table_ref, self._table_materialization, self._table_materialization_default,
            )
            if materialization == TableMaterialization.VIEW:
                return f"{keyword} DYNAMIC_TABLE_REFRESH_BOUNDARY({table_ref})"
            return m.group(0)

        return self._TABLE_REF_RE.sub(_replace, query_sql)

    def install_table_ddl(
        self, table_name: str, columns: "Sequence[StoreColumn]"
    ) -> str:
        parts = []
        for c in columns:
            if c.sql_type is None:
                raise ValueError(f"No SQL type for column {c.name!r} in {table_name}")
            parts.append(f"{self._always_quote(c.name)} {c.sql_type}")
        col_defs = ", ".join(parts)
        # For now, we enable change tracking on all standard tables in Snowflake. We need
        # change tracking when a dynamic table references a standard table. In the future,
        # we might want to enable change tracking only when the table is actually referenced
        # by a dynamic table or by a logic reasoner.
        return f"CREATE OR REPLACE TABLE {self.quote_table_name(table_name)} ({col_defs})\n  CHANGE_TRACKING = TRUE"

    def normalize_schema_name(self, name) -> str:
        return name

    def normalize_column_name(self, name: str) -> str:
        if name.startswith('"') and name.endswith('"'):
            return name[1:-1]
        return name


    def _always_quote(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def quote_identifier(self, name: str) -> str:
        token = name.strip()
        if token == "*":
            return token
        if token.startswith('"') and token.endswith('"'):
            return token
        upper = token.upper()
        if self._UNQUOTED_IDENTIFIER_RE.fullmatch(token) and upper not in self._RESERVED_IDENTIFIERS:
            return upper
        escaped = token.replace('"', '""')
        return f'"{escaped}"'

    #------------------------------------------------------
    # Metadata fetching
    #------------------------------------------------------

    def fetch_schema(self, database: str, schema: str, table: str) -> dict[str, type | str]:
        try:
            # Use SHOW COLUMNS which works with Snowflake permissions
            show_query = f"SHOW COLUMNS IN {database}.{schema}.{table}"
            self._session.sql(show_query).collect()

            # Get results from result_scan
            result_query = """
                SELECT "column_name", "data_type"
                FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
            """
            rows = self._session.sql(result_query).collect()

            result: dict[str, type | str] = {}
            for row in rows:
                column_name = str(row[0])
                data_type_json = row[1]
                if not isinstance(data_type_json, (str, bytes, bytearray)):
                    continue

                # Parse the JSON data type info
                type_info = json.loads(data_type_json)
                sf_type = type_info.get("type", "TEXT")

                result[column_name] = _map_snowflake_type(sf_type, type_info)

            return result
        except Exception:
            # If schema fetch fails, return empty dict
            return {}

    #------------------------------------------------------
    # SQL execution
    #------------------------------------------------------

    def execute_sql(self, sql: str) -> pd.DataFrame:
        self._drop_view_if_exists_for_create_table(sql)
        snow_df = self._session.sql(sql)
        column_names = [self.normalize_column_name(name) for name in snow_df.columns]
        rows = [tuple(row) for row in snow_df.collect()]
        df = pd.DataFrame(rows, columns=column_names)
        formatted_df = self._format_snowflake_columns(df, snow_df)
        formatted_df.attrs["sql_output_types"] = self._collect_sql_output_types(snow_df, column_names)
        return formatted_df

    def execute_sql_batch(self, statements: list[str]) -> None:
        if not statements:
            return
        for statement in statements:
            self._drop_view_if_exists_for_create_table(statement)
        body = "\n".join(stmt.rstrip().rstrip(";") + ";" for stmt in statements)
        script = "BEGIN\n" + body + "\nEND;"
        self._session.sql(script).collect()

    def _drop_view_if_exists_for_create_table(self, sql: str) -> None:
        target = self._create_table_target(sql)
        if not target:
            return
        is_view = bool(self._IS_VIEW_RE.match(sql))
        is_dynamic_table = bool(self._IS_DYNAMIC_TABLE_RE.match(sql))
        if not is_view:
            # CREATE [DYNAMIC] TABLE replaces a same-named TABLE/DYNAMIC TABLE in
            # place, but Snowflake errors if a VIEW exists at that name; drop it.
            try:
                self._session.sql(f"DROP VIEW IF EXISTS {target}").collect()
            except Exception:
                pass
        if is_view:
            # CREATE VIEW won't replace a TABLE or DYNAMIC TABLE; drop both.
            try:
                self._session.sql(f"DROP TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
            try:
                self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
        elif is_dynamic_table:
            # When upgrading a plain table to a dynamic table, drop the old plain table.
            try:
                self._session.sql(f"DROP TABLE IF EXISTS {target}").collect()
            except Exception:
                pass
        else:
            # When creating a plain table, drop any pre-existing dynamic table.
            try:
                self._session.sql(f"DROP DYNAMIC TABLE IF EXISTS {target}").collect()
            except Exception:
                pass

    def _create_table_target(self, sql: str) -> str | None:
        # Matches CREATE OR REPLACE [DYNAMIC] TABLE / VIEW in these forms:
        #   CREATE OR REPLACE TABLE name AS <query>
        #   CREATE OR REPLACE DYNAMIC TABLE name WAREHOUSE = ... AS <query>
        #   CREATE OR REPLACE TABLE name (col TYPE, ...)   ← schema-only DDL
        #   CREATE OR REPLACE VIEW name AS <query>
        match = re.match(
            r'^\s*CREATE\s+OR\s+REPLACE\s+(?:DYNAMIC\s+TABLE|TABLE|VIEW)\s+(.+?)\s*(?:\(|WAREHOUSE\b|SCHEDULER\b|AS\b)',
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if not match:
            return None
        return match.group(1).strip()

    def _format_snowflake_columns(
            self,
            result_frame: pd.DataFrame,
            snow_df: "snowflake.snowpark.DataFrame",
        ) -> pd.DataFrame:
        """Schema-driven DataFrame formatting for Snowflake results."""
        if result_frame.shape[0] == 0:
            return result_frame

        from snowflake.snowpark.types import (
            DecimalType,
            ByteType,
            ShortType,
            IntegerType,
            LongType,
            StringType,
        )

        int64_min = -(1 << 63)
        int64_max = (1 << 63) - 1

        def _is_null(value: object) -> bool:
            if value is None or value is pd.NA:
                return True
            if isinstance(value, float):
                try:
                    return isnan(value)
                except Exception:
                    return False
            return False

        def _requires_int128(series: pd.Series) -> bool:
            for value in series:
                if _is_null(value):
                    continue
                int_value = int(value)
                if int_value < int64_min or int_value > int64_max:
                    return True
            return False

        def _cast_integer_series(series: pd.Series) -> pd.Series:
            if _requires_int128(series):
                return series.astype(Int128Dtype())
            if bool(series.isna().any()):
                return series.astype("Int64")
            return series.astype("int64")

        def _to_decimal(value: object, *, scale: int) -> Decimal | None:
            if _is_null(value):
                return None
            quant = Decimal(1).scaleb(-scale)
            if isinstance(value, Decimal):
                return value.quantize(quant)
            return Decimal(str(value)).quantize(quant)

        def _cast_bool_string_series(series: pd.Series) -> pd.Series:
            normalized = series.map(lambda v: None if _is_null(v) else str(v).strip().lower())
            valid = {v for v in normalized.tolist() if v is not None}
            if not valid.issubset({"true", "false"}):
                return series
            return normalized.map(lambda v: None if v is None else (v == "true")).astype("boolean")

        for field_ix, field in enumerate(snow_df.schema.fields):
            if field_ix >= len(result_frame.columns):
                break
            series = result_frame.iloc[:, field_ix]
            def _assign(series_value: pd.Series) -> None:
                # Use positional assignment so extension dtypes (e.g. Int128) survive.
                result_frame.isetitem(field_ix, cast(Any, series_value))

            if isinstance(field.datatype, (ByteType, ShortType, IntegerType, LongType)):
                _assign(_cast_integer_series(series))
                continue

            if not isinstance(field.datatype, DecimalType):
                if isinstance(field.datatype, StringType):
                    _assign(_cast_bool_string_series(series))
                continue

            scale = field.datatype.scale
            if scale == 0:
                _assign(_cast_integer_series(series))
                continue
            _assign(series.map(lambda value: _to_decimal(value, scale=scale)))

        return result_frame

    def _collect_sql_output_types(
            self,
            snow_df: "snowflake.snowpark.DataFrame",
            column_names: list[str],
        ) -> tuple[dict[str, int | str | None], ...]:
        out: list[dict[str, int | str | None]] = []
        for ix, field in enumerate(snow_df.schema.fields):
            col_name = column_names[ix] if ix < len(column_names) else self.normalize_column_name(field.name)
            out.append(
                {
                    "name": col_name,
                    "snowflake_type": type(field.datatype).__name__,
                    "precision": getattr(field.datatype, "precision", None),
                    "scale": getattr(field.datatype, "scale", None),
                }
            )
        return tuple(out)

    #------------------------------------------------------
    # Semi-naive execution
    #------------------------------------------------------

    def build_semi_naive_plan(self, loop: "SemiNaiveLoop", emitter: "SQLEmitter") -> str:
        max_iterations = 1000
        schema_context: str | None = None
        if loop.tables:
            first_table_name = loop.tables[0].table_name
            parts = first_table_name.split(".")
            if len(parts) >= 3:
                # db.schema.table  →  USE SCHEMA db.schema
                schema_context = ".".join(parts[:2])
            elif len(parts) == 2:
                # schema.table  →  USE SCHEMA schema
                schema_context = parts[0]

        def qcol(name: str) -> str:
            token = name.strip()
            if (
                re.fullmatch(r"[A-Za-z_][A-Za-z0-9_$]*", token)
                and token.upper() == token
                and token.upper() not in SnowflakeBackend._RESERVED_IDENTIFIERS
            ):
                return token
            return emitter._quote_identifier(token)

        def cols_sql(table: SemiNaiveTable) -> str:
            return ", ".join(qcol(c) for c in table.columns)

        # Initialize accum_view and delta_view from base_query for each
        # target. Both views share base_query: at iteration 0 the delta
        # *is* the seed.
        init_stmts = []
        cols_by_table = {table.table_name: cols_sql(table) for table in loop.tables}
        for table in loop.tables:
            base_sql = emitter.emit(table.base_query)
            cols = cols_by_table[table.table_name]
            init_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.accum_view_name} AS\n"
                f"SELECT {cols} FROM ({base_sql}) AS base"
            )
            init_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.delta_view_name} AS\n"
                f"SELECT {cols} FROM ({base_sql}) AS base"
            )

        # Loop body: mirrors DuckDB's two-phase loop so multi-table SCCs see
        # consistent cross-table state during a single iteration.
        #   Phase 1: compute next_accum and next_delta for ALL tables, using
        #            the iteration's *current* accum/delta. (A's merge_query
        #            may JOIN B's accum and vice versa — neither has been
        #            swapped yet, so both reads are at iteration N.)
        #   Phase 2: count total_rows added across the SCC.
        #   Phase 3: if any progress, swap accum<-next_accum and
        #            delta<-next_delta for ALL tables atomically.
        # No EXCEPT or store-with-_gen logic here — encoded by lowerer.
        compute_stmts: list[str] = []
        count_stmts: list[str] = []
        swap_stmts: list[str] = []
        for table in loop.tables:
            cols = cols_by_table[table.table_name]
            merge_sql = emitter.emit(table.merge_query)
            next_delta_sql = emitter.emit(table.next_delta_query)
            compute_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.next_accum_view_name} AS\n"
                f"SELECT {cols} FROM ({merge_sql}) AS merged;"
            )
            compute_stmts.append(
                f"CREATE OR REPLACE TEMP TABLE {table.next_delta_view_name} AS\n"
                f"SELECT {cols} FROM ({next_delta_sql}) AS diff;"
            )
            count_stmts.append(
                f"total_rows := total_rows + (SELECT COUNT(*) FROM {table.next_delta_view_name});"
            )
            swap_stmts.append(
                f"DROP TABLE IF EXISTS {table.accum_view_name};\n"
                f"ALTER TABLE {table.next_accum_view_name} RENAME TO {table.accum_view_name};\n"
                f"DROP TABLE IF EXISTS {table.delta_view_name};\n"
                f"ALTER TABLE {table.next_delta_view_name} RENAME TO {table.delta_view_name};"
            )
        # Wrap swaps in a single IF so all tables advance together (or none).
        swap_block = (
            "IF (total_rows > 0) THEN\n"
            + "\n".join("  " + line for stmt in swap_stmts for line in stmt.splitlines())
            + "\nEND IF;"
        )
        loop_body = compute_stmts + count_stmts + [swap_block]

        # Materialize the public view from accum.
        final_stmts = []
        for table in loop.tables:
            final_sql = emitter.emit(table.final_query)
            view_name = self.quote_table_name(table.table_name)
            _mat = resolve_by_table_name(
                table.table_name, self._table_materialization, self._table_materialization_default,
            )
            if _mat != TableMaterialization.TABLE:
                _warn(
                    "Recursive table fallback",
                    f"Table {table.table_name!r} was configured as {_mat.value!r} but it is part "
                    f"of a recursive (semi-naive) computation. Recursive tables cannot use that "
                    f"materialization. Falling back to a plain TABLE.",
                )
            final_stmts.append(
                f"INSERT OVERWRITE INTO {view_name} ({cols_by_table[table.table_name]})\n"
                f"{final_sql}"
            )

        script = "\n".join([
            "DECLARE",
            "  iter INTEGER := 0;",
            "  total_rows INTEGER := 1;",
            "  max_iter INTEGER := " + str(max_iterations) + ";",
            "BEGIN",
            *([f"  USE SCHEMA {schema_context};"] if schema_context else []),
            *[f"  {stmt};" for stmt in init_stmts],
            "  WHILE (total_rows > 0 AND iter < max_iter) DO",
            "    total_rows := 0;",
            *["    " + line for stmt in loop_body for line in stmt.splitlines()],
            "    iter := iter + 1;",
            "  END WHILE;",
            *[f"  {stmt};" for stmt in final_stmts],
            "END;",
        ])

        return script

    def execute_semi_naive(self, plan: object) -> None:
        assert isinstance(plan, str)
        self._session.sql(plan).collect()


#------------------------------------------------------
# Helpers
#------------------------------------------------------
# Type mapping from Snowflake types to Python/RAI types
SNOWFLAKE_TYPE_MAP: dict[str, type | str] = {
    'TEXT': str,
    'VARCHAR': str,
    'CHAR': str,
    'STRING': str,
    'BINARY': bytes,
    'NUMBER': 'Decimal',
    'FIXED': 'Decimal',
    'FLOAT': float,
    'REAL': float,
    'DOUBLE': float,
    'BOOLEAN': bool,
    'DATE': 'Date',
    'TIME': 'DateTime',
    'TIMESTAMP': 'DateTime',
    'TIMESTAMP_LTZ': 'DateTime',
    'TIMESTAMP_NTZ': 'DateTime',
    'TIMESTAMP_TZ': 'DateTime',
}

def _map_snowflake_type(sf_type: str, type_info: dict) -> type | str:
    base_type = sf_type.upper()

    # Handle FIXED/NUMBER with precision/scale
    if base_type in ('FIXED', 'NUMBER'):
        precision = type_info.get('precision', 38)
        scale = type_info.get('scale', 0)

        if scale == 0:
            # Integer types
            if precision <= 18:
                return 'Decimal(18,0)'
            else:
                return 'Decimal(38,0)'
        else:
            return f'Decimal({precision},{scale})'

    return SNOWFLAKE_TYPE_MAP.get(base_type, str)
