from __future__ import annotations

import re
from typing import TypeVar

_T = TypeVar("_T")

# Entity-store tables are emitted as ``<concept>_t<digits>``. A config keyed on
# the bare concept name should match every per-store table for that concept.
_ENTITY_STORE_SUFFIX = re.compile(r"_t\d+$")


def resolve_by_table_name(name: str, lookup: dict[str, _T], default: _T) -> _T:
    """Resolve a config value keyed by table name, accepting fully-qualified or bare names.

    *name* may be a fully-qualified object name (e.g. ``"myschema"."connection"``) or a
    bare name. The function strips the schema prefix and surrounding quotes, then tries an
    exact case-insensitive match against *lookup*. If that misses, it retries with the
    PyRel entity-store ``_t<digits>`` suffix removed — so a key of ``"connection"`` matches
    a per-store table named ``connection_t806``.
    """
    if not lookup:
        return default
    unqualified = name.split(".")[-1].strip('"').lower()
    if unqualified in lookup:
        return lookup[unqualified]
    stripped = _ENTITY_STORE_SUFFIX.sub("", unqualified)
    return lookup.get(stripped, default)
