function escapeSqlString(value) {
    return String(value ?? "")
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "''");
}

function sqlStringLiteral(value) {
    return "'" + escapeSqlString(value) + "'";
}

function sqlNullableStringLiteral(value) {
    if (value === null || value === undefined) {
        return "NULL";
    }
    return sqlStringLiteral(value);
}

function sqlNullableIntLiteral(value) {
    if (value === null || value === undefined || value === "") {
        return "NULL";
    }
    var parsed = Number(value);
    if (!Number.isFinite(parsed)) {
        throw new Error("Expected integer-compatible value, got: " + JSON.stringify(value));
    }
    return String(Math.trunc(parsed));
}

function normalizeBoolean(value, name) {
    if (value === true || value === false) {
        return value;
    }
    if (value === 1 || value === "1" || value === "true") {
        return true;
    }
    if (value === 0 || value === "0" || value === "false") {
        return false;
    }
    throw new Error(name + " must be a boolean-compatible value, got: " + JSON.stringify(value));
}

function sqlBooleanLiteral(value, name) {
    return normalizeBoolean(value, name) ? "TRUE" : "FALSE";
}

function parseJsonArray(value, name) {
    var raw = value == null || value === "" ? "[]" : String(value);
    var parsed;
    try {
        parsed = JSON.parse(raw);
    } catch (e) {
        throw new Error(name + " must be valid JSON: " + e.message);
    }
    if (!Array.isArray(parsed)) {
        throw new Error(name + " must be a JSON array.");
    }
    return parsed;
}

function quotedIdentifier(name) {
    return '"' + String(name ?? "").replace(/"/g, '""') + '"';
}

function executeSql(sqlText) {
    try {
        return snowflake.execute({ sqlText: sqlText });
    } catch (e) {
        throw new Error("Query failed: " + e.message + "\nQuery: " + sqlText);
    }
}

function querySingleValue(sqlText) {
    var rs = executeSql(sqlText);
    if (!rs.next()) {
        return null;
    }
    return rs.getColumnValue(1);
}

function objectFromVariant(value) {
    if (value == null) {
        return {};
    }
    if (typeof value === "string") {
        try {
            return JSON.parse(value);
        } catch (e) {
            return {};
        }
    }
    if (typeof value === "object") {
        return value;
    }
    return {};
}

function queryLastResultObject() {
    return objectFromVariant(
        querySingleValue("SELECT OBJECT_CONSTRUCT(*) FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())) LIMIT 1")
    );
}

function arrayContainsString(values, expected) {
    return values.some(function(value) {
        return String(value) === expected;
    });
}