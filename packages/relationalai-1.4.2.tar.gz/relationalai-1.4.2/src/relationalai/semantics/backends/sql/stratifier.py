"""Dependency graph and stratification for sql9."""
from __future__ import annotations

from dataclasses import dataclass

from ...metamodel import metamodel as mm
from .artifacts import Catalog, SCCGraph

@dataclass(frozen=True, slots=True)
class DependencyEdge():
    writer_relation_id: int
    reader_relation_id: int
    negated: bool


class DependencyCollector:
    def collect(self, root: mm.Task) -> tuple[DependencyEdge, ...]:
        edges: list[DependencyEdge] = []
        for block in self._rule_blocks(root):
            writer_relation_ids = tuple(
                update.relation.id for update in self._block_updates(block)
            )
            if not writer_relation_ids:
                continue
            for reader_relation_id, negated in self._block_read_edges(block):
                for writer_relation_id in writer_relation_ids:
                    edges.append(
                        DependencyEdge(
                            writer_relation_id=writer_relation_id,
                            reader_relation_id=reader_relation_id,
                            negated=negated,
                        )
                    )
        return tuple(edges)

    def _block_updates(self, task: mm.Task) -> tuple[mm.Update, ...]:
        """Collect every Update (including nested in child Logicals) — mirrors Coalescer._updates."""
        result: list[mm.Update] = []
        def walk(node: mm.Task) -> None:
            if isinstance(node, mm.Update):
                result.append(node)
                return
            if isinstance(node, mm.Logical):
                for child in node.body:
                    walk(child)
            elif isinstance(node, mm.Sequence):
                for child in node.tasks:
                    walk(child)
        walk(task)
        return tuple(result)

    def _rule_blocks(self, task: mm.Task, inherited_context: tuple[mm.Task, ...] = ()):
        if isinstance(task, mm.Sequence):
            for child in task.tasks:
                yield from self._rule_blocks(child, inherited_context=inherited_context)
            return
        if not isinstance(task, mm.Logical):
            return
        if self._has_direct_model_write(task):
            yield mm.Logical(body=(*inherited_context, *task.body), optional=task.optional, scope=task.scope)
            return

        local_context = tuple(
            child for child in task.body
            if not isinstance(child, (mm.Logical, mm.Sequence))
        )
        for child in task.body:
            if isinstance(child, (mm.Logical, mm.Sequence)):
                yield from self._rule_blocks(child, inherited_context=(*inherited_context, *local_context))

    def _has_direct_model_write(self, task: mm.Logical) -> bool:
        return any(isinstance(child, (mm.Update, mm.Construct)) for child in task.body)

    def _block_read_edges(self, task: mm.Task, *, negated: bool = False):
        if isinstance(task, mm.Lookup):
            relation_id = task.relation.id
            if isinstance(relation_id, int):
                yield relation_id, negated
            return
        if isinstance(task, mm.Logical):
            for child in task.body:
                if isinstance(child, (mm.Update, mm.Construct)):
                    continue
                yield from self._block_read_edges(child, negated=negated)
            return
        if isinstance(task, mm.Sequence):
            for child in task.tasks:
                if isinstance(child, (mm.Update, mm.Construct)):
                    continue
                yield from self._block_read_edges(child, negated=negated)
            return
        if isinstance(task, (mm.Union, mm.Match)):
            for child in task.tasks:
                yield from self._block_read_edges(child, negated=negated)
            return
        if isinstance(task, mm.Not):
            yield from self._block_read_edges(task.task, negated=True)
            return
        if isinstance(task, mm.Aggregate):
            if isinstance(task.body, mm.Task):
                yield from self._block_read_edges(task.body, negated=negated)
            else:
                if not isinstance(task.body, (mm.Update, mm.Construct)):
                    yield from self._block_read_edges(task.body, negated=negated)
            return


class Stratifier:
    def build_scc_graph(self, model: mm.Model, catalog: Catalog) -> SCCGraph:
        collector = DependencyCollector()
        edges = collector.collect(model.root)

        # Anchor edges to storage-level ids so folded-property cycles are visible.
        def anchor(rid: int) -> int:
            return catalog.physical_anchor_id(rid, model)

        # Non-SQL relations must not be folded into their SQL entity anchor: they require
        # their own SCC so the router can label them as, e.g., "logic" without conflating
        # them with the SQL entity SCC.
        non_sql_relation_ids: set[int] = {
            relation.id
            for reasoner in model.reasoners
            if reasoner.type.lower() != "sql"
            for relation in reasoner.relations
        }

        def anchor_sql_only(rid: int) -> int:
            """Anchor SQL relations only; logic relations keep their own ID."""
            if rid in non_sql_relation_ids:
                return rid
            return anchor(rid)

        # Drop same-anchor edges where both sides are folded cousins (neither is
        # the entity type id): the reader is materialized in a prior stratum,
        # so it isn't a true physical self-loop.
        anchor_edges: list[DependencyEdge] = []
        for edge in edges:
            writer_anchor = anchor_sql_only(edge.writer_relation_id)
            reader_anchor = anchor_sql_only(edge.reader_relation_id)
            if (
                writer_anchor == reader_anchor
                and edge.writer_relation_id != writer_anchor
                and edge.reader_relation_id != reader_anchor
            ):
                continue
            anchor_edges.append(
                DependencyEdge(
                    writer_relation_id=writer_anchor,
                    reader_relation_id=reader_anchor,
                    negated=edge.negated,
                )
            )

        # Negation check runs on the un-anchored graph so negation between
        # folded-cousin properties is not false-flagged as a negation cycle.
        self._check_no_recursive_negation(edges, model)

        relation_ids: set[int] = {
            anchor_sql_only(relation.id)
            for relation in model.relations
        }
        relation_ids.update(anchor(rid) for rid in self._collect_construct_type_ids(model.root))
        for edge in anchor_edges:
            relation_ids.add(edge.writer_relation_id)
            relation_ids.add(edge.reader_relation_id)

        sccs = self._tarjan(tuple(relation_ids), list(anchor_edges))
        scc_index = {
            relation_id: index
            for index, component in enumerate(sccs)
            for relation_id in component
        }

        # component_edges[dep_scc] = set of SCCs that depend on dep_scc (i.e. must run after it)
        component_edges: dict[int, set[int]] = {index: set() for index in range(len(sccs))}
        component_has_self_loop: dict[int, bool] = {index: False for index in range(len(sccs))}
        indegree: dict[int, int] = {index: 0 for index in range(len(sccs))}
        level: dict[int, int] = {index: 0 for index in range(len(sccs))}

        for edge in anchor_edges:
            writer_scc = scc_index[edge.writer_relation_id]
            reader_scc = scc_index[edge.reader_relation_id]
            if writer_scc == reader_scc:
                # Negated self-loops at anchor level are safe — vetted above.
                component_has_self_loop[writer_scc] = True
                continue
            if writer_scc not in component_edges[reader_scc]:
                component_edges[reader_scc].add(writer_scc)
                indegree[writer_scc] += 1

        queue = sorted(index for index, degree in indegree.items() if degree == 0)
        topo: list[int] = []
        while queue:
            current = queue.pop(0)
            topo.append(current)
            for nxt in sorted(component_edges[current]):
                indegree[nxt] -= 1
                if indegree[nxt] == 0:
                    queue.append(nxt)

        for edge in anchor_edges:
            writer_scc = scc_index[edge.writer_relation_id]
            reader_scc = scc_index[edge.reader_relation_id]
            if writer_scc == reader_scc:
                continue
            increment = 1 if edge.negated else 0
            level[writer_scc] = max(level[writer_scc], level[reader_scc] + increment)

        by_level: dict[int, list[int]] = {}
        for component_index in topo:
            by_level.setdefault(level[component_index], []).append(component_index)

        stratum_index_by_scc: dict[int, int] = {}
        for index, stratum_level in enumerate(sorted(by_level)):
            for component_index in by_level[stratum_level]:
                stratum_index_by_scc[component_index] = index

        # Build SCCGraph: dependencies[writer_scc] = frozenset of reader_sccs it depends on
        n = len(sccs)
        scc_dependencies: list[set[int]] = [set() for _ in range(n)]
        for reader_scc, writer_sccs in component_edges.items():
            for writer_scc in writer_sccs:
                scc_dependencies[writer_scc].add(reader_scc)

        scc_graph = SCCGraph(
            sccs=sccs,
            dependencies=tuple(frozenset(deps) for deps in scc_dependencies),
            has_self_loop=tuple(component_has_self_loop[i] for i in range(n)),
            stratum_index_by_scc=tuple(stratum_index_by_scc.get(i, 0) for i in range(n)),
        )

        return scc_graph

    def _check_no_recursive_negation(
        self, edges: tuple[DependencyEdge, ...], model: mm.Model
    ) -> None:
        # Check at the relation-id level (not anchored) so negation between
        # folded-cousin properties is not false-flagged as a negation cycle.
        if not any(edge.negated for edge in edges):
            return

        relation_ids: set[int] = {relation.id for relation in model.relations}
        relation_ids.update(self._collect_construct_type_ids(model.root))
        for edge in edges:
            relation_ids.add(edge.writer_relation_id)
            relation_ids.add(edge.reader_relation_id)

        sccs = self._tarjan(tuple(relation_ids), list(edges))
        scc_index = {
            rid: idx for idx, component in enumerate(sccs) for rid in component
        }
        for edge in edges:
            if not edge.negated:
                continue
            if scc_index[edge.writer_relation_id] == scc_index[edge.reader_relation_id]:
                raise NotImplementedError("sql9 does not yet support recursive negation.")

    def _collect_construct_type_ids(self, task: mm.Task) -> set[int]:
        # Seed Tarjan with type ids from pure-construct rules that contribute no edges.
        ids: set[int] = set()
        stack: list[mm.Task] = [task]
        while stack:
            node = stack.pop()
            if isinstance(node, mm.Construct):
                tid = getattr(getattr(node.id_var, "type", None), "id", None)
                if isinstance(tid, int):
                    ids.add(tid)
            elif isinstance(node, mm.Logical):
                stack.extend(node.body)
            elif isinstance(node, mm.Sequence):
                stack.extend(node.tasks)
            elif isinstance(node, (mm.Union, mm.Match)):
                stack.extend(node.tasks)
            elif isinstance(node, mm.Not):
                stack.append(node.task)
            elif isinstance(node, mm.Aggregate):
                if isinstance(node.body, mm.Task):
                    stack.append(node.body)
        return ids

    def _tarjan(self, relation_ids: tuple[int, ...], edges: list[DependencyEdge]) -> tuple[tuple[int, ...], ...]:
        adjacency: dict[int, list[int]] = {relation_id: [] for relation_id in relation_ids}
        for edge in edges:
            adjacency.setdefault(edge.writer_relation_id, []).append(edge.reader_relation_id)

        index_counter = 0
        index_by_node: dict[int, int] = {}
        lowlink_by_node: dict[int, int] = {}
        stack: list[int] = []
        on_stack: set[int] = set()
        components: list[tuple[int, ...]] = []

        def strongconnect(node: int) -> None:
            nonlocal index_counter
            index_by_node[node] = index_counter
            lowlink_by_node[node] = index_counter
            index_counter += 1
            stack.append(node)
            on_stack.add(node)

            for neighbor in adjacency.get(node, ()):
                if neighbor not in index_by_node:
                    strongconnect(neighbor)
                    lowlink_by_node[node] = min(lowlink_by_node[node], lowlink_by_node[neighbor])
                elif neighbor in on_stack:
                    lowlink_by_node[node] = min(lowlink_by_node[node], index_by_node[neighbor])

            if lowlink_by_node[node] == index_by_node[node]:
                component: list[int] = []
                while stack:
                    candidate = stack.pop()
                    on_stack.remove(candidate)
                    component.append(candidate)
                    if candidate == node:
                        break
                components.append(tuple(sorted(component)))

        for relation_id in relation_ids:
            if relation_id not in index_by_node:
                strongconnect(relation_id)

        return tuple(components)


__all__ = ["DependencyEdge", "SCCGraph", "Stratifier"]
