"""Build the LR (logic-reasoner) payload for a single coalesced block.

Pipeline context
----------------
The compiler splits a model into ``CoalescedBlock``s. Blocks whose reasoner
type is ``"logic"`` are handed to this builder; the SQL-typed blocks go through
the storage normalizer + lowerer instead. For each logic block we must produce
a :class:`LogicBlock` that the LR executor understands, which has three pieces:

* ``install_root``      — the program to compile and install into the LR backend.
                          It *writes* the block's results into the physical
                          output relations owned by this block.
* ``export_query``      — a small read-back program we hand to the v0
                          ``LegacyExecutor``. It reads from the physical
                          output relations and writes into an output binding
                          shaped the way v0's executor expects, which is how
                          results actually land in the Snowflake tables
                          downstream (SQL-typed) blocks consume.
* ``output_table_names``— the catalog names the LR backend materializes, so
                          the orchestrator can stitch LR outputs back into the
                          shared ``BlockVersionState`` and let later blocks
                          find them.

Terminology
-----------
Throughout this file "legacy" means **v0-shaped**: the output-binding
convention the v0 ``LegacyExecutor`` understands (one ``Table`` plus one
``Relation`` per column, keyed on a row ``Var``). It is not "deprecated" —
it is the interop shape for the still-active v0 execution path.
"""

from __future__ import annotations

from relationalai.semantics import metamodel as mm
from relationalai.semantics.backends.sql.artifacts import (
    BlockVersionState,
    Catalog,
    CoalescedBlock,
    LogicBlock,
    PlannedTarget,
    Target,
)
from relationalai.semantics.backends.sql.normalizer import StorageVersionNormalizer
from relationalai.semantics.metamodel.metamodel_analyzer import VarFinder
from relationalai.semantics.metamodel.builtins import builtins as bt
from relationalai.semantics.metamodel.rewriter import Rewriter, Walker


class _ConstructIdVarFinder(Walker):
    """Collect ``id(node)`` of every ``Construct.id_var`` reachable from a task.

    Construct outputs are entity ids the body produces — they must NOT be
    rewritten to point at the upstream entity-id Var of an input concept.
    """

    __slots__ = ("output_var_object_ids",)

    def __init__(self) -> None:
        super().__init__()
        self.output_var_object_ids: set[int] = set()

    def construct(self, node: mm.Construct) -> None:
        if isinstance(node.id_var, mm.Var):
            self.output_var_object_ids.add(id(node.id_var))


class _PhysicalInputRewriter(Rewriter):
    """Rewrite logic-block install tasks to read from materialized Snowflake
    tables instead of concept-population/concept-property relations.

    For each concept whose entity-store is bound in ``BlockVersionState`` (i.e.
    materialized by an upstream block), this synthesizes:

    * a fresh ``mm.Table`` ``T`` whose ``name``/``uri`` match the storage
      table's FQN and whose ``super_types`` include the concept ``ScalarType``
      so the typer accepts a ``T``-typed Var where the concept is expected.
    * a per-concept ``row_var`` (``T``-typed) that coordinates reads from the
      same Snowflake row across multiple property-column lookups, and stands
      in for the concept-typed Var the body originally referenced.

    The walker then:

    * substitutes every concept-typed ``Var`` with that concept's ``row_var``
      (skipping ``Construct.id_var`` — those are *outputs* of new entity
      construction and must not be aliased to an upstream entity). Because
      ``T`` is a subtype of the concept, ``Update`` / ``=`` accept the row_var
      where a concept was expected, and the row_var is itself the entity-hash
      key bound by the CDC source lookup;
    * rewrites concept-population lookups (``Lookup(concept, (var,))``) to
      ``Lookup(T, (row_var,))`` — registers ``T`` as a CDC source;
    * rewrites concept-property lookups (``Lookup(prop, (var, value))``) to
      ``Lookup(T_prop, (row_var, value))`` with a Table-attached property, so
      v0's CDC translator emits a column read of ``T``;
    * injects, at the innermost ``Logical`` containing every use of a
      concept's ``row_var``, a ``Lookup(T, (row_var,))`` source registration.

    Updates and Constructs are not rewritten directly; their ``args`` get
    substituted through the ``Var`` walker (subject to the Construct guard
    above). The relations they reference (this block's outputs, not yet
    bound) pass through untouched so the LR backend can materialize them
    into freshly-allocated physical tables.
    """

    __slots__ = (
        "_version_state",
        "_input_relation_ids",
        "_sf_database",
        "_concept_to_table",
        "_concept_to_row_var",
        "_concept_to_synth_relations",
        "_property_to_table_relation",
        "_construct_output_var_object_ids",
    )

    def __init__(
        self,
        version_state: BlockVersionState,
        input_relation_ids: tuple[int, ...],
        sf_database: str,
    ) -> None:
        super().__init__()
        self._version_state = version_state
        self._input_relation_ids: frozenset[int] = frozenset(input_relation_ids)
        self._sf_database = sf_database
        # concept ScalarType id -> synthetic input Table (T)
        self._concept_to_table: dict[int, mm.Table] = {}
        # concept ScalarType id -> Var(type=T, name="<tail>__row")
        self._concept_to_row_var: dict[int, mm.Var] = {}
        # concept ScalarType id -> list of synthesized table-attached property
        # relations owned by that concept's input Table. Used to populate
        # ``input_table.columns`` so v0's CDC translator (which checks
        # ``r in r.fields[0].type.columns``) treats each as a CDC column read.
        self._concept_to_synth_relations: dict[int, list[mm.Relation]] = {}
        # original concept-property relation id -> table-attached relation
        self._property_to_table_relation: dict[int, mm.Relation] = {}
        # Python id() of every Construct.id_var Var node — these are outputs
        # and var() must not substitute them.
        self._construct_output_var_object_ids: set[int] = set()

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def rewrite_install_tasks(self, tasks: tuple[mm.Task, ...]) -> tuple[mm.Task, ...]:
        """Rewrite each task and prepend table-source lookups at its top Logical."""
        # Pre-pass: locate every Construct.id_var so var() leaves them alone.
        finder = _ConstructIdVarFinder()
        for task in tasks:
            finder(task)
        self._construct_output_var_object_ids = finder.output_var_object_ids

        rewritten: list[mm.Task] = []
        for task in tasks:
            new_task = self(task)
            rewritten.append(self._prepend_table_sources(new_task))
        # Publish every synthesized relation we attached to a concept's input
        # Table as a column of that Table, so v0's CDC translator
        # (``r in r.fields[0].type.columns`` — see
        # :func:`mm2v0.rewrite_cdc_args` and ``mm2v0.translate_relation``)
        # recognizes it as an external table-column read and emits a
        # ``rel_atom`` instead of a plain ``atom``.
        for cid, table in self._concept_to_table.items():
            relations = tuple(self._concept_to_synth_relations.get(cid, ()))
            if relations:
                table._force_columns(relations)
        return tuple(rewritten)

    # ------------------------------------------------------------------
    # Var / Lookup substitution (Rewriter overrides)
    # ------------------------------------------------------------------

    def var(self, node: mm.Var):
        if id(node) in self._construct_output_var_object_ids:
            return None
        if not isinstance(node.type, mm.ScalarType) or isinstance(node.type, mm.Table):
            return None
        concept = node.type
        bound_table = self._bound_table_for_relation_id(concept.id)
        if bound_table is None:
            return None
        self._ensure_concept_state(concept, bound_table)
        # The input Table's ``super_types`` include the concept, so the typer
        # accepts row_var where the concept is expected — and the row_var is
        # the entity-hash key bound by the CDC source lookup, which means
        # Updates and equalities resolve directly with no extra binding chain.
        return self._concept_to_row_var[concept.id]

    def lookup(self, node: mm.Lookup):
        relation = node.relation
        if not isinstance(relation, mm.Relation):
            return None
        relation_id = getattr(relation, "id", None)
        if relation_id is None:
            return None

        # Concept-population lookup: replace with Lookup(T, (row_var,)) so v0
        # registers the input table as a CDC source.
        if isinstance(relation, mm.ScalarType) and not isinstance(relation, mm.Table):
            bound = self._bound_table_for_relation_id(relation.id)
            if bound is None:
                return None
            self._ensure_concept_state(relation, bound)
            input_table = self._concept_to_table[relation.id]
            row_var = self._concept_to_row_var[relation.id]
            return node.mut(relation=input_table, args=(row_var,))

        # Concept-property lookup: build the input table from the OWNER
        # concept's bound table (not the property's), so all properties of
        # one concept share the same row_var. Set args[0] = row_var
        # explicitly to be robust to whatever var() left in that slot.
        owner_concept = self._owner_concept_for_property(relation)
        if owner_concept is None:
            return None
        owner_bound = self._bound_table_for_relation_id(owner_concept.id)
        if owner_bound is None:
            owner_bound = self._bound_table_for_relation_id(relation_id)
            if owner_bound is None:
                return None
        self._ensure_concept_state(owner_concept, owner_bound)
        input_table = self._concept_to_table[owner_concept.id]
        row_var = self._concept_to_row_var[owner_concept.id]
        new_relation = self._table_attached_property(relation, input_table)
        new_args = (row_var, *node.args[1:])
        return node.mut(relation=new_relation, args=new_args)

    # ------------------------------------------------------------------
    # Table-source insertion
    # ------------------------------------------------------------------

    def _prepend_table_sources(self, task: mm.Task) -> mm.Task:
        """Inject each concept's source-table Lookup at the innermost Logical
        that actually uses its ``row_var``.

        For a procedure ``Sequence`` whose third inner ``Logical`` is the only
        one referencing ``person__row``, the ``Lookup(Person, person__row)``
        source registration goes inside that third ``Logical``, not at the
        outermost Sequence/Logical — otherwise v0's CDC translator binds the
        source in a scope that does not contain the property reads.
        """
        if not self._concept_to_row_var:
            return task
        return self._inject_walk(task, set(self._concept_to_row_var.keys()))

    def _source_lookups_for_concept(self, concept_id: int) -> list[mm.Task]:
        """Return the source-table registration Lookup for ``concept_id``."""
        input_table = self._concept_to_table[concept_id]
        row_var = self._concept_to_row_var[concept_id]
        return [
            mm.Lookup(relation=input_table, args=(row_var,)),
        ]

    def _used_concepts_in(self, task: mm.Task, candidates: set[int]) -> set[int]:
        """Return the subset of ``candidates`` whose ``row_var`` appears
        anywhere in ``task``'s subtree."""
        if not candidates:
            return set()
        found_vars = VarFinder().find_vars(task)
        used: set[int] = set()
        for cid in candidates:
            rv = self._concept_to_row_var.get(cid)
            if rv is None:
                continue
            for v in found_vars:
                if v is rv:
                    used.add(cid)
                    break
        return used

    def _inject_walk(self, task: mm.Task, candidates: set[int]) -> mm.Task:
        """Walk ``task`` and inject each candidate concept's source Lookup
        at the innermost ``Logical`` containing every use of its ``row_var``.

        - If exactly one nested Logical child uses a concept's row_var (and
          the concept is not also used in this Logical's non-Logical body),
          push the injection down into that child.
        - Otherwise (used directly here, or used across multiple children),
          inject at this level.
        """
        if not candidates:
            return task
        if isinstance(task, mm.Logical):
            body = list(task.body)
            child_uses: list[set[int]] = []
            direct_use: set[int] = set()
            for child in body:
                if isinstance(child, mm.Logical):
                    child_uses.append(self._used_concepts_in(child, candidates))
                else:
                    child_uses.append(set())
                    direct_use |= self._used_concepts_in(child, candidates)
            inject_here: list[int] = []
            for cid in candidates:
                children_with_use = [i for i, s in enumerate(child_uses) if cid in s]
                if cid in direct_use:
                    inject_here.append(cid)
                elif len(children_with_use) == 1:
                    idx = children_with_use[0]
                    body[idx] = self._inject_walk(body[idx], {cid})
                elif len(children_with_use) >= 2:
                    inject_here.append(cid)
                # else: not used in this subtree at all — skip.
            if inject_here:
                sources: list[mm.Task] = []
                # Stable ordering by concept id for deterministic output.
                for cid in sorted(inject_here):
                    sources.extend(self._source_lookups_for_concept(cid))
                body = sources + body
            return task.mut(body=tuple(body))
        if isinstance(task, mm.Sequence):
            new_tasks = tuple(self._inject_walk(sub, candidates) for sub in task.tasks)
            return task.mut(tasks=new_tasks)
        return task

    # ------------------------------------------------------------------
    # Table / Var / Property synthesis (cached)
    # ------------------------------------------------------------------

    def _bound_table_for_relation_id(self, relation_id: int) -> mm.Table | None:
        if relation_id not in self._input_relation_ids:
            return None
        return (
            self._version_state.entry_table_for(relation_id)
            or self._version_state.latest_table_for(relation_id)
        )

    def _qualify_uri(self, uri: str) -> str:
        if uri.count(".") >= 2:
            return uri
        return f"{self._sf_database}.{uri}"

    def _ensure_concept_state(self, concept: mm.ScalarType, bound_table: mm.Table) -> None:
        """Build (once per concept) the input Table and row Var the rewriter uses.

        The input Table reuses ``bound_table.uri`` as both ``name`` and
        ``uri`` so v0's source-table collection (which parses ``table.name``
        as a FQN — see :meth:`LegacyExecutor._collect_refresh_source_tables`)
        sees the materialized Snowflake table. ``super_types=(concept,)``
        makes the Table a subtype of the concept, which lets the typer
        accept Table-typed Vars where the concept is expected (see
        ``type_matches`` at typer.py:1348).
        """
        if concept.id in self._concept_to_table:
            return
        qualified_uri = self._qualify_uri(bound_table.uri)
        input_table = mm.Table(
            name=qualified_uri,
            uri=qualified_uri,
            skip_cdc=bound_table.skip_cdc,
            super_types=(concept, *bound_table.super_types),
        )
        tail = input_table.name.rsplit(".", 1)[-1].lower()
        row_var = mm.Var(type=input_table, name=f"{tail}__row")
        self._concept_to_table[concept.id] = input_table
        self._concept_to_row_var[concept.id] = row_var
        self._concept_to_synth_relations[concept.id] = []

    def _table_attached_property(self, original: mm.Relation, input_table: mm.Table) -> mm.Relation:
        """Synthesize a copy of ``original`` whose ``fields[0].type`` is ``input_table``.

        Caches per original-relation id and registers the synthesized relation
        as a column of ``input_table`` (via ``_concept_to_synth_relations``)
        so v0's CDC translator (see :func:`mm2v0.rewrite_cdc_args`) treats the
        lookup as a column read of the source table.
        """
        cached = self._property_to_table_relation.get(original.id)
        if cached is not None:
            return cached
        if not original.fields:
            return original
        old_first = original.fields[0]
        new_first = mm.Field(name=old_first.name, type=input_table, input=old_first.input)
        new_rel = mm.Relation(
            name=original.name,
            fields=(new_first, *original.fields[1:]),
            requires=original.requires,
            readings=original.readings,
            overloads=original.overloads,
        )
        self._property_to_table_relation[original.id] = new_rel
        # Register on the owning concept so the post-rewrite finalizer attaches
        # this relation to ``input_table.columns``. The owning concept is the
        # type whose ``input_table`` we received — since the rewriter only
        # creates one input_table per concept, we can find it via identity.
        for cid, table in self._concept_to_table.items():
            if table is input_table:
                self._concept_to_synth_relations.setdefault(cid, []).append(new_rel)
                break
        return new_rel

    def _owner_concept_for_property(self, relation: mm.Relation) -> mm.ScalarType | None:
        if not relation.fields:
            return None
        first_type = relation.fields[0].type
        if isinstance(first_type, mm.ScalarType) and not isinstance(first_type, mm.Table):
            return first_type
        return None


class LogicBlockBuilder:
    """Build a ``LogicBlock`` from a single ``CoalescedBlock``.

    Reuses ``StorageVersionNormalizer`` for shared concerns:
      * resolving the physical output ``mm.Table`` for a target,
      * splitting per-owner entity writes when ``target.kind == "entity"``,
      * binding output relations into ``BlockVersionState`` so later blocks
        can find them by relation id.
    """

    def __init__(self, normalizer: StorageVersionNormalizer, sf_database: str) -> None:
        self._normalizer = normalizer
        self._sf_database = sf_database

    def build(
        self,
        block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
    ) -> LogicBlock | None:
        if not block.targets:
            return None

        install_tasks: list[mm.Task] = []
        export_tasks: list[mm.Logical] = []
        bound_object_names: set[str] = set()
        seen_install_ids: set[int] = set()

        # ``version_state`` carries bindings registered by upstream blocks —
        # i.e. the materialized Snowflake tables for concepts/properties this
        # block reads from. We rewrite each install task against this snapshot
        # so concept-population/concept-property reads become Table-bound reads
        # in the v0/CDC shape v0 expects. This block's own outputs aren't
        # bound until after the install loop, so writes to them pass through.
        input_rewriter = _PhysicalInputRewriter(
            version_state, block.input_relation_ids, self._sf_database,
        )

        for planned_target in block.targets:
            target = planned_target.target
            object_name = target.object_name

            output_table = self._normalizer._output_table_for_target(
                target, object_name, model, catalog,
            )

            target_install_tasks: list[mm.Task] = []
            for task in self._install_tasks_for_target(planned_target, output_table):
                # The same procedure-style task may be attached to multiple
                # targets by the coalescer; dedup by identity so the LR
                # program runs each install task once.
                if id(task) in seen_install_ids:
                    continue
                seen_install_ids.add(id(task))
                target_install_tasks.append(task)

            install_tasks.extend(
                input_rewriter.rewrite_install_tasks(tuple(target_install_tasks))
            )

            export_tasks.append(self._build_export_task(target, output_table))

            if object_name not in bound_object_names:
                self._normalizer._bind_target_relations(
                    target, model, catalog, version_state, object_name,
                )
                bound_object_names.add(object_name)

        if not install_tasks or not export_tasks:
            return None

        install_root = mm.Logical(body=tuple(install_tasks), scope=True)
        export_query = mm.Logical(body=tuple(export_tasks), scope=True)

        return LogicBlock(
            install_root=install_root,
            export_query=export_query,
            output_table_names=tuple(sorted(bound_object_names)),
        )

    # ------------------------------------------------------------------
    # Install side
    # ------------------------------------------------------------------

    def _install_tasks_for_target(
        self,
        planned_target: PlannedTarget,
        output_table: mm.Table,
    ) -> tuple[mm.Task, ...]:
        """Produce the install tasks the LR backend will run for one target.

        Contributions come in two shapes:

        * ``mm.Logical`` — a rule body. Entity targets get split per owner
          via the normalizer so each owner's writes form one atomic block.
        * ``mm.Sequence`` — a procedure body, already atomic; passed through.

        Lookups inside contributions are *not* rewritten to physical tables:
        the LR/v0 path resolves relations from the model and catalog itself.
        """
        target = planned_target.target
        out: list[mm.Task] = []
        for task in planned_target.tasks:
            if isinstance(task, mm.Logical):
                if target.kind == "entity":
                    out.extend(self._normalizer._split_entity_task(task, output_table))
                else:
                    out.append(task)
            elif isinstance(task, mm.Sequence):
                out.append(task)
            # Other shapes are not produced by the coalescer for logic blocks.
        return tuple(out)

    # ------------------------------------------------------------------
    # Export side
    # ------------------------------------------------------------------

    def _build_export_task(self, target: Target, output_table: mm.Table) -> mm.Logical:
        """Read every cell the LR backend wrote and bind it into the v0 shape.

        Mirrors the frontend ``select(...).into(table)`` lowering in
        ``front_compiler.py``: the outer ``Logical`` carries only the
        identity-binding lookups, the row ``Construct``, and the row's
        ``Update``; each column's read+update lives in its own
        ``Logical(optional=True)`` so the v0 LQP backend recognises the tree
        as a table export.
        """
        trunk_lookups, key_values, column_slots = self._read_trunk_and_columns(
            target, output_table,
        )
        return self._bind_legacy_output_task(
            trunk_lookups, key_values, column_slots, target, output_table,
        )

    def _read_trunk_and_columns(
        self,
        target: Target,
        output_table: mm.Table,
    ) -> tuple[
        tuple[mm.Task, ...],
        tuple[mm.Value, ...],
        dict[str, tuple[tuple[mm.Task, ...], mm.Value]],
    ]:
        """Split physical reads into trunk vs per-column.

        Returns ``(trunk_lookups, key_values, column_slots)`` where:

        * ``trunk_lookups`` go in the outer ``Logical`` (visible to every
          column's optional sub-block);
        * ``key_values`` are the args fed to ``Construct`` to derive the row
          identity;
        * ``column_slots[col_name] = (lookups, value)`` describes the
          column-specific read(s) and the value to write — empty ``lookups``
          means the value is already bound by the trunk.

        Layout of ``output_table.columns`` (set by
        ``StorageVersionNormalizer._relations_for_target``):

        * ``relation`` kind → one wide relation; the trunk lookup binds every
          column var, so each column has no extra lookup.
        * ``entity`` kind   → ``relations[0]`` is the owner; each subsequent
          ``(owner, value)`` relation belongs to one column and its lookup is
          deferred into that column's optional block.
        """
        relations = tuple(output_table.columns)
        if not relations:
            raise ValueError(
                f"output_table for target {target.object_name!r} has no relations"
            )

        if target.kind == "relation":
            relation = relations[0]
            args = tuple(
                mm.Var(type=field.type, name=field.name or f"arg_{i}")
                for i, field in enumerate(relation.fields, start=1)
            )
            if len(args) != len(target.column_names):
                raise ValueError(
                    f"relation-kind target {target.object_name!r} has "
                    f"{len(target.column_names)} column names but its relation "
                    f"{relation.name!r} has {len(args)} fields"
                )
            trunk = (mm.Lookup(relation=relation, args=args),)
            slots: dict[str, tuple[tuple[mm.Task, ...], mm.Value]] = {
                col_name: ((), args[i])
                for i, col_name in enumerate(target.column_names)
            }
            return trunk, args, slots

        if target.kind == "entity":
            owner_relation = relations[0]
            owner_field = owner_relation.fields[-1]
            owner_var = mm.Var(
                type=owner_field.type,
                name=owner_field.name or owner_relation.name.lower(),
            )
            trunk = (mm.Lookup(relation=owner_relation, args=(owner_var,)),)
            slots = {"_id": ((), owner_var)}
            for relation in relations[1:]:
                value_field = relation.fields[-1]
                value_var = mm.Var(
                    type=value_field.type,
                    name=value_field.name or relation.name.lower(),
                )
                slots[relation.name] = (
                    (mm.Lookup(relation=relation, args=(owner_var, value_var)),),
                    value_var,
                )
            # Entity rows are keyed by owner identity alone — property values are
            # column slots, not part of the row key. Contrast with the relation
            # case above, where every field participates in the key.
            return trunk, (owner_var,), slots

        raise ValueError(f"Unknown target kind {target.kind!r} for {target.object_name!r}.")

    def _bind_legacy_output_task(
        self,
        trunk_lookups: tuple[mm.Task, ...],
        key_values: tuple[mm.Value, ...],
        column_slots: dict[str, tuple[tuple[mm.Task, ...], mm.Value]],
        target: Target,
        output_table: mm.Table,
    ) -> mm.Logical:
        """Wrap the trunk + per-column reads in v0's row-keyed export shape.

        v0 represents a row as a row-typed ``Var`` plus one ``(row_var, value)``
        relation per column. ``Construct`` accepts only ``Var`` inputs as
        id-generator keys, so any non-``Var`` key is first bound to a fresh
        ``Var`` via an ``eq`` lookup.

        The outer ``Logical`` carries the trunk identity-binding lookups, the
        ``eq`` key bindings, the row ``Construct``, and the row ``Update``.
        Each column's read(s) and ``Update`` then live in their own
        ``mm.Logical(body=..., optional=True)`` sub-block, mirroring how
        ``select(...).into(table)`` lowers in
        :class:`FrontCompiler` so the v0 LQP backend recognises the tree as a
        table export.
        """
        table = self._build_legacy_output_table(target, output_table)
        row_var = mm.Var(
            type=table,
            name=f"{table.name.rsplit('.', 1)[-1].lower()}__row",
        )

        eq_bindings, construct_keys = self._coerce_keys_to_vars(key_values, row_var.name)

        body: list[mm.Task] = [
            *trunk_lookups,
            *eq_bindings,
            mm.Construct(values=construct_keys, id_var=row_var),
            mm.Update(relation=table, args=(row_var,)),
        ]
        for column_relation, col_name in zip(table.columns, target.column_names):
            col_lookups, col_value = column_slots[col_name]
            col_body = (
                *col_lookups,
                mm.Update(relation=column_relation, args=(row_var, col_value)),
            )
            body.append(mm.Logical(body=col_body, optional=True))
        # ``scope=True`` keeps each per-target output binding in its own Logical scope.
        # Without it the v1 normalizer flattens these sibling Logicals into a single parent
        # Logical, which then makes the v0 shim's ``_merge_outputs`` collapse all per-table
        # Output bindings into one, which breaks the LR export.
        return mm.Logical(body=tuple(body), scope=True)

    def _coerce_keys_to_vars(
        self,
        row_values: tuple[mm.Value, ...],
        row_var_name: str,
    ) -> tuple[tuple[mm.Lookup, ...], tuple[mm.Value, ...]]:
        """Bind any non-``Var`` row value to a fresh ``Var`` via ``eq``.

        Returns ``(eq_lookups, key_values)`` where ``key_values`` is in
        ``row_values`` order.
        """
        bindings: list[mm.Lookup] = []
        keys: list[mm.Value] = []
        for i, value in enumerate(row_values, start=1):
            if isinstance(value, mm.Var):
                keys.append(value)
                continue
            bound = mm.Var(
                type=getattr(value, "type", mm.TypeNode()),
                name=f"{row_var_name}__key_{i}",
            )
            bindings.append(mm.Lookup(relation=bt.core.eq, args=(bound, value)))
            keys.append(bound)
        return tuple(bindings), tuple(keys)

    def _build_legacy_output_table(self, target: Target, output_table: mm.Table) -> mm.Table:
        """Mirror the physical output as a v0-shaped table (one relation/column).

        Column value types come from:
          * ``relation`` kind → fields of the single physical relation.
          * ``entity`` kind   → last field of each per-property relation.
        """
        physical_columns = output_table.columns
        if target.kind == "relation":
            assert len(physical_columns) == 1, (
                f"relation target {target.object_name!r} expects 1 physical "
                f"relation; got {len(physical_columns)}"
            )
            column_types = tuple(field.type for field in physical_columns[0].fields)
        else:
            column_types = tuple(rel.fields[-1].type for rel in physical_columns)

        table = mm.Table(name=target.object_name, uri=f"table://{target.object_name}")
        columns = tuple(
            mm.Relation(
                name=column_name,
                fields=(
                    mm.Field(name="table", type=table),
                    mm.Field(name=column_name, type=value_type),
                ),
            )
            for column_name, value_type in zip(target.column_names, column_types)
        )
        table._force_columns(columns)
        return table
