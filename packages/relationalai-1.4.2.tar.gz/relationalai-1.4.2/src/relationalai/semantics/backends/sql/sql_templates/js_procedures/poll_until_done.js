// Polls POLL_QUERY until it returns a value that is in DONE_STATES.
// Waits MIN_WAIT_SEC before the first check, then doubles the wait each
// iteration up to MAX_WAIT_SEC (capped exponential backoff).
// POLL_QUERY must return a single state string in its first column.
// Returns the terminal state value.

var waitSec = MIN_WAIT_SEC;
var state = "";
var terminalStates = new Set(DONE_STATES.split(',').map(function(s) { return s.trim(); }));

while (!terminalStates.has(state)) {
    var seconds = Math.max(1, Math.ceil(waitSec));
    snowflake.execute({ sqlText: "SELECT SYSTEM$WAIT(" + seconds + ")" });

    try {
        var result = snowflake.execute({ sqlText: POLL_QUERY });
        if (result.next()) {
            state = result.getColumnValue(1) || "";
        }
    } catch (e) {
        throw new Error("Poll query failed: " + e.message + "\nQuery: " + POLL_QUERY);
    }

    waitSec = Math.min(waitSec * 1.2, MAX_WAIT_SEC);
}

return state;
