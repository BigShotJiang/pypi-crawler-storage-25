function sourceReferenceSql(fqName, objectType) {
    var objectTypeEsc = escapeSqlString(objectType);
    var objectFqName = escapeSqlString(fqName);
    return "{ 'objectType':'" + objectTypeEsc + "', "
        + "'objectFqName':'" + objectFqName + "', "
        + "'referenceAlias':SYSTEM$REFERENCE('"
        + objectTypeEsc + "', '"
        + objectFqName + "', 'PERSISTENT', 'SELECT') }";
}

function normalizeTableType(tableType, fqName) {
    // use_index accepts only 'BASE TABLE' or 'VIEW'. Other types are not supported.
    if (tableType === "BASE TABLE") return "TABLE";
    if (tableType === "VIEW") return "VIEW";
    throw new Error("Unsupported table type for " + fqName + ": " + tableType);
}

function fetchObjectTypes(sources) {
    // Batched ``fqName -> 'TABLE' | 'VIEW'`` lookup over INFORMATION_SCHEMA.TABLES.
    // Each source is ``{ fqName, db, schema, name }`` with db/schema/name in
    // stored, unquoted case (matching INFORMATION_SCHEMA columns).
    // Requires every source to share the same ``(db, schema)`` pair; issues
    // a single query.
    var result = {};
    if (sources.length === 0) return result;

    var db = sources[0].db;
    var schema = sources[0].schema;
    for (var i = 1; i < sources.length; i++) {
        if (sources[i].db !== db || sources[i].schema !== schema) {
            throw new Error(
                "All sources must share database.schema; got "
                + db + "." + schema + " and "
                + sources[i].db + "." + sources[i].schema
            );
        }
    }

    var names = sources.map(function (e) {
        return "'" + escapeSqlString(e.name) + "'";
    }).join(", ");
    var sql =
        "SELECT TABLE_NAME, TABLE_TYPE "
        + "FROM " + quotedIdentifier(db) + ".INFORMATION_SCHEMA.TABLES "
        + "WHERE TABLE_SCHEMA = '" + escapeSqlString(schema) + "' "
        + "AND TABLE_NAME IN (" + names + ")";
    var stmt = snowflake.createStatement({ sqlText: sql });
    var rs;
    try {
        rs = stmt.execute();
    } catch (e) {
        throw new Error("Failed to resolve object types from " + db + "." + schema + ": " + e.message);
    }
    var byName = {};
    while (rs.next()) {
        var n = String(rs.getColumnValue(1) || "");
        var t = String(rs.getColumnValue(2) || "").toUpperCase();
        byName[n] = t;
    }
    for (var j = 0; j < sources.length; j++) {
        var src = sources[j];
        var tableType = byName[src.name];
        if (tableType === undefined) {
            throw new Error("Object not found in INFORMATION_SCHEMA.TABLES: " + src.fqName);
        }
        result[src.fqName] = normalizeTableType(tableType, src.fqName);
    }
    return result;
}

function formatUseIndexErrors(errors) {
    if (!Array.isArray(errors) || errors.length === 0) {
        return "use_index returned an unknown error";
    }
    return errors.map(function(err) {
        if (typeof err === "string") {
            return err;
        }
        if (!err || typeof err !== "object") {
            return JSON.stringify(err);
        }
        return String(err.message || err.error || JSON.stringify(err));
    }).join("; ");
}

var sources = JSON.parse(SOURCES_JSON || "[]");

// TODO: set them the same as v0 UseIndexPoller
var params = {
    model: MODEL_DATABASE,
    engine: ENGINE_NAME,
    default_engine_size: ENGINE_SIZE,
    // user_agent:,
    use_index_id: String(MODEL_DATABASE || "model") + "_" + Date.now().toString(), // check how it's set
    // pyrel_program_id:,
    wait_for_stream_sync: normalizeBoolean(WAIT_FOR_STREAM_SYNC, "WAIT_FOR_STREAM_SYNC"),
    should_check_cdc: true, // check
    init_engine_async: false, // check
    language: "lqp",
    data_freshness_mins: null, // check,
    check_data_stream_health: true //check
};

// TODO: eventually we will need the headers in the second json
var objectTypes = fetchObjectTypes(sources);
var sqlText = "CALL " + APP_NAME + ".api.use_index(["
    + sources.map(function (src) {
        return sourceReferenceSql(src.fqName, objectTypes[src.fqName]);
    }).join(", ")
    + "], PARSE_JSON('" + escapeSqlString(JSON.stringify(params)) + "'), PARSE_JSON('{}'));";

var waitSec = MIN_WAIT_SEC;
while (true) {
    var payload = "";
    try {
        var result = snowflake.execute({ sqlText: sqlText });
        if (result.next()) {
        payload = result.getColumnValue(1) || "";
        }
    } catch(e) {
        throw new Error("Poll query failed: " + e.message + "\nQuery: " + sqlText);
    }
    
    var parsed;
    try {
        payload = JSON.stringify(payload);
        parsed = JSON.parse(payload);
    } catch (e) {
        throw new Error("Invalid JSON response from use_index: " + e.message);
    }

    if (Array.isArray(parsed.errors) && parsed.errors.length > 0) {
        throw new Error(formatUseIndexErrors(parsed.errors));
    }
    if (parsed.ready) {
        return JSON.stringify(parsed);
    } 

    var seconds = Math.max(1, Math.ceil(waitSec));
    snowflake.execute({ sqlText: "SELECT SYSTEM$WAIT(" + seconds + ")" });
    waitSec = Math.min(waitSec * 1.2, MAX_WAIT_SEC);
}
