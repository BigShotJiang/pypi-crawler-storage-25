"""Single source of truth for synthesized table-name conventions in the SQL backend.

The normalizer fabricates auxiliary table names for intermediate stages and
recursion markers. Backends and optimizers occasionally need to reverse the
convention (e.g. to map a staged name back to its canonical target). Both
directions live here so the format is defined once.
"""
from __future__ import annotations

import re


_STAGE_SUFFIX_PREFIX = "__stage_"
_RECURSIVE_MARKER_SUFFIX = "__recursive_marker"

_STAGE_SUFFIX_RE = re.compile(re.escape(_STAGE_SUFFIX_PREFIX) + r"\d+$")


def stage_view_name(object_name: str, stage_index: int) -> str:
    """Name for the N-th intermediate stage of a target."""
    return f"{object_name}{_STAGE_SUFFIX_PREFIX}{stage_index}"


def recursive_marker_name(object_name: str) -> str:
    """Name for the recursive-marker auxiliary table of a target."""
    return f"{object_name}{_RECURSIVE_MARKER_SUFFIX}"


def canonical_from(name: str) -> str:
    """Strip schema/quoting and the stage suffix to return the canonical object name.

    Does NOT strip the recursive_marker suffix: a recursive-marker table is a
    distinct object from its canonical target.
    """
    base = name.rsplit(".", 1)[-1]
    if base.startswith('"') and base.endswith('"'):
        base = base[1:-1]
    return _STAGE_SUFFIX_RE.sub("", base)


def is_synthesized_internal(name: str) -> bool:
    """True if *name* looks like an internally-synthesized intermediate view.

    Matches any name whose last component contains a double underscore — covers
    `__stage_N`, `__recursive_marker`, and any other `__`-bearing helper.
    """
    local = name.rsplit(".", 1)[-1].strip('"')
    return "__" in local
