"""ASCII visualization of the install-mode block DAG.

Renders a ``ModelPlan``'s blocks and their data-flow dependencies as plain
text, without contacting any backend. Intended to be printed at the start of
``MultiReasonerExecutor.install`` so the developer can see the planned
execution graph before any Snowflake calls go out.
"""
from __future__ import annotations

from collections import defaultdict

from .artifacts import Catalog, CoalescedBlock, ModelPlan


def format_model_plan_install_dag(model_plan: ModelPlan) -> str:
    return format_install_dag(model_plan.catalog, model_plan.blocks)

def format_install_dag(catalog: Catalog, blocks: tuple[CoalescedBlock, ...]) -> str:
    rid_to_name = _relation_id_to_name(catalog)
    rid_to_producer = _relation_id_to_producer_block(blocks)

    out: list[str] = []
    out.append("")
    out.append("╔══════════════════════════════════════════════════════════════╗")
    out.append("║                    INSTALL DAG                               ║")
    out.append("╚══════════════════════════════════════════════════════════════╝")
    out.append("")

    sources = _collect_sources(blocks, rid_to_producer, rid_to_name)
    if sources:
        out.append("Sources (read-only inputs):")
        for name in sorted(sources):
            out.append(f"  • {name}")
        out.append("")

    if not blocks:
        out.append("(no execution blocks)")
        out.append("")
        return "\n".join(out)

    levels = _topological_levels(blocks, rid_to_producer)
    blocks_by_level: dict[int, list[CoalescedBlock]] = defaultdict(list)
    for block in blocks:
        blocks_by_level[levels[block.index]].append(block)

    for level in sorted(blocks_by_level):
        for block in blocks_by_level[level]:
            out.extend(_render_block(block, blocks, rid_to_producer, rid_to_name))
            out.append("")
        if level + 1 in blocks_by_level:
            out.append("                            │")
            out.append("                            ▼")
            out.append("")

    out.extend(_render_legend(blocks))
    return "\n".join(out)


def _relation_id_to_name(cat: Catalog) -> dict[int, str]:
    """Build a relation_id → human-readable label map from the catalog."""
    out: dict[int, str] = {}
    for s in cat.entity_stores.values():
        out[s.type_id] = f"{s.object_name} (entity)"
    for s in cat.relation_stores.values():
        out[s.relation_id] = f"{s.object_name} (relation)"
    for s in cat.data_stores.values():
        label = s.source_name or s.object_name
        out[s.type_id] = f"{label} (source)"
    return out


def _relation_id_to_producer_block(blocks: tuple[CoalescedBlock, ...]) -> dict[int, int]:
    """Which block index produces each relation_id."""
    out: dict[int, int] = {}
    for block in blocks:
        for rid in block.output_relation_ids:
            out[rid] = block.index
    return out


def _collect_sources(
    blocks: tuple[CoalescedBlock, ...],
    rid_to_producer: dict[int, int],
    rid_to_name: dict[int, str],
) -> set[str]:
    """Relations read by some block but produced by none — i.e., upstream sources."""
    sources: set[str] = set()
    for block in blocks:
        for rid in block.input_relation_ids:
            if rid in rid_to_producer:
                continue
            sources.add(rid_to_name.get(rid, f"<rel#{rid}>"))
    return sources


def _topological_levels(
    blocks: tuple[CoalescedBlock, ...],
    rid_to_producer: dict[int, int],
) -> dict[int, int]:
    """Assign each block a level = max(upstream block levels) + 1, sources at 0."""
    block_by_index = {b.index: b for b in blocks}
    levels: dict[int, int] = {}

    def level_of(idx: int) -> int:
        if idx in levels:
            return levels[idx]
        block = block_by_index[idx]
        upstream = {
            rid_to_producer[rid]
            for rid in block.input_relation_ids
            if rid in rid_to_producer and rid_to_producer[rid] != idx
        }
        levels[idx] = (1 + max((level_of(u) for u in upstream), default=-1))
        return levels[idx]

    for block in blocks:
        level_of(block.index)
    return levels


def _render_block(
    block: CoalescedBlock,
    all_blocks: tuple[CoalescedBlock, ...],
    rid_to_producer: dict[int, int],
    rid_to_name: dict[int, str],
) -> list[str]:
    target_lines = [
        f"      {pt.target.object_name}  ({pt.target.kind}{', recursive' if pt.recursive else ''})"
        for pt in block.targets
    ]
    upstream_indices = sorted({
        rid_to_producer[rid]
        for rid in block.input_relation_ids
        if rid in rid_to_producer and rid_to_producer[rid] != block.index
    })
    source_reads = sorted({
        rid_to_name.get(rid, f"<rel#{rid}>")
        for rid in block.input_relation_ids
        if rid not in rid_to_producer
    })

    interval = f", interval={block.interval_s}s" if block.interval_s else ""
    rec = ", RECURSIVE" if block.recursive else ""
    header = f"┌─ Block {block.index}  [{block.reasoner_type}{interval}{rec}]"
    lines = [header]
    lines.append("│  writes:")
    if target_lines:
        lines.extend(f"│{line}" for line in target_lines)
    else:
        lines.append("│      (none)")
    if upstream_indices:
        lines.append("│  reads from blocks: " + ", ".join(f"#{i}" for i in upstream_indices))
    if source_reads:
        lines.append("│  reads sources:")
        for name in source_reads:
            lines.append(f"│      {name}")
    lines.append("└─")
    return lines


def _render_legend(blocks: tuple[CoalescedBlock, ...]) -> list[str]:
    counts: dict[str, int] = defaultdict(int)
    for b in blocks:
        counts[b.reasoner_type] += 1
    summary = ", ".join(f"{n} {t}" for t, n in sorted(counts.items()))
    return [
        f"Total: {len(blocks)} blocks ({summary})",
        "",
    ]
