"""Pre-pass that enforces *one writer per target table*.

When a single output table would have its columns supplied by both the SQL default and the
logic reasoner, the WriterUnifier escalates every contributing SQL relation to logic. Logic
strictly subsumes SQL's expressiveness, so this escalation never loses the ability to
compute something.

The pass is a pure metamodel transformation: it rewrites ``model.reasoners`` so the logic
reasoner now claims all relations materialising into the affected target.
"""
from __future__ import annotations

from dataclasses import dataclass

import rich

from ...metamodel import metamodel as mm
from .artifacts import Catalog
from .reasoner_router import DEFAULT_REASONER_TYPE


_LOGIC_REASONER_TYPE = "logic"


@dataclass(frozen=True, slots=True)
class _TargetGroup:
    """Internal: a catalog target plus the relation ids that fill it."""

    object_name: str
    relation_ids: tuple[int, ...]


class WriterUnifier:
    """Make sure every output table has exactly one writing reasoner."""

    def unify(self, model: mm.Model, catalog: Catalog, show_debug_logs: bool = False) -> mm.Model:
        """Return ``model`` with every multi-writer target escalated to logic.

        Idempotent: a model with no mixed targets is returned unchanged.
        """
        relation_to_reasoner = model.reasoner_type_by_relation_id()

        escalated_ids: set[int] = set()
        for group in self._target_groups(catalog):
            sql_ids = []
            logic_ids = []
            for rid in group.relation_ids:
                if relation_to_reasoner.get(rid, DEFAULT_REASONER_TYPE) == _LOGIC_REASONER_TYPE:
                    logic_ids.append(rid)
                else:
                    sql_ids.append(rid)
            if not sql_ids or not logic_ids:
                # Single writer target, we are good to go
                continue
            escalated_ids.update(sql_ids)
            if show_debug_logs:
                self._log_escalation(model, group, sql_ids, logic_ids)

        if not escalated_ids:
            return model
        return self._apply_escalations(model, escalated_ids)

    @staticmethod
    def _log_escalation(
        model: mm.Model,
        group: _TargetGroup,
        sql_ids: list[int],
        logic_ids: list[int],
    ) -> None:
        name_by_id = {r.id: r.name for r in model.relations}
        for type_ in model.types:
            name_by_id.setdefault(type_.id, type_.name)
        triggers = ", ".join(sorted(name_by_id[rid] for rid in logic_ids))
        escalated = ", ".join(sorted(name_by_id[rid] for rid in sql_ids))
        rich.print("\n[magenta]--------------------------------------------------------------[/magenta]")
        rich.print(
            f"[magenta]note:[/magenta] target {group.object_name!r} escalated to logic "
            f"(triggered by {triggers}; escalated from sql: {escalated})."
        )

    @staticmethod
    def _target_groups(catalog: Catalog) -> tuple[_TargetGroup, ...]:
        """Every writeable target paired with the relations that fill it.

        Data stores are intentionally excluded: they're read-only sources
        materialised from external systems, not the output of any reasoner,
        so escalation never applies to them.
        """
        groups: list[_TargetGroup] = []

        owner_to_property_ids: dict[int, list[int]] = {}
        for relation_id, owner_type_id in (
            catalog.folded_property_relation_to_owner_entity_type.items()
        ):
            owner_to_property_ids.setdefault(owner_type_id, []).append(relation_id)

        for store in catalog.entity_stores.values():
            relation_ids = (store.type_id, *owner_to_property_ids.get(store.type_id, ()))
            groups.append(_TargetGroup(store.object_name, tuple(relation_ids)))

        for store in catalog.relation_stores.values():
            groups.append(_TargetGroup(store.object_name, (store.relation_id,)))

        return tuple(groups)

    @staticmethod
    def _apply_escalations(model: mm.Model, escalated_ids: set[int]) -> mm.Model:
        """Rebuild ``model.reasoners`` so the logic reasoner now owns every escalated relation.
        """

        # Entity types live in ``model.types``, not ``model.relations``, but
        # ScalarType extends Relation so a Reasoner can legitimately hold one
        # in its relations list. Look both up so we can escalate the entity
        # type's own row alongside its folded properties.
        relations_by_id: dict[int, mm.Relation] = {r.id: r for r in model.relations}
        for type_ in model.types:
            relations_by_id.setdefault(type_.id, type_)

        added = tuple(relations_by_id[rid] for rid in escalated_ids if rid in relations_by_id)

        new_reasoners: list[mm.Reasoner] = []
        for reasoner in model.reasoners:
            if reasoner.type.lower() == _LOGIC_REASONER_TYPE:
                reasoner = reasoner.mut(relations=tuple(reasoner.relations) + added)
            new_reasoners.append(reasoner)

        return model.mut(reasoners=tuple(new_reasoners))


__all__ = ["WriterUnifier"]
