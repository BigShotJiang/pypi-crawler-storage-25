"""Generic traversal toolkit for SQL IR trees.

Two operations:

- `fold(node, step, acc)` — read-only post-order walk. Visits every IR node
  reachable from `node` (`SQLExpr`, `SQLSource`, `SQLQuery`, plus the glue
  records `SQLFromItem`/`SQLJoin`/`SQLSelectItem`/`SQLOrderItem`) and threads
  an accumulator through `step(node, acc) -> acc`.

- `transform(node, *, expr_fn, source_fn, query_fn)` — bottom-up rewrite.
  Children are rewritten first, then each `*_fn` (when provided) fires on its
  respective IR-base category. Returns the same instance when nothing
  changed (structural sharing), so callers can detect "did anything change
  this pass" with cheap `is` checks.

Both operations are dataclass-fields-driven: any field whose value is
itself an IR node is descended into, as is every IR-node element of a
tuple or list field. Leaf primitives (str, int, bool, None) are ignored.
Nested containers (e.g. `SQLValuesSource.rows: tuple[tuple[SQLExpr, ...], ...]`)
are handled uniformly. New IR node types added to sql_ir.py are picked up
automatically as long as their fields are typed as ordinary IR nodes or
tuples/lists thereof — there is nothing here to keep in sync.
"""
from __future__ import annotations

from dataclasses import fields, is_dataclass, replace
from typing import Callable, TypeVar, cast

from .sql_ir import (
    SQLColumnRef,
    SQLExpr,
    SQLFromItem,
    SQLJoin,
    SQLOrderItem,
    SQLQuery,
    SQLSelectItem,
    SQLSelectQuery,
    SQLSource,
    SQLTableSource,
    SQLUnionQuery,
)

A = TypeVar("A")
T = TypeVar("T")
Step = Callable[[object, A], A]
Rewrite = Callable[[object], object]

_IR_BASES = (SQLExpr, SQLSource, SQLQuery, SQLFromItem, SQLJoin, SQLSelectItem, SQLOrderItem)


# ---------------------------------------------------------------------------
# Fold: read-only post-order walk
# ---------------------------------------------------------------------------


def _walk_value(value: object, step: Step, acc: A) -> A:
    if isinstance(value, _IR_BASES):
        return _walk_node(value, step, acc)
    if isinstance(value, (tuple, list)):
        for elem in value:
            acc = _walk_value(elem, step, acc)
    return acc


def _walk_node(node: object, step: Step, acc: A) -> A:
    if is_dataclass(node):
        for f in fields(node):
            acc = _walk_value(getattr(node, f.name), step, acc)
    return step(node, acc)


def fold(node: object, step: Step[A], acc: A) -> A:
    """Post-order fold: visit every IR node reachable from `node`, returning the final accumulator."""
    return _walk_node(node, step, acc)


# ---------------------------------------------------------------------------
# Transform / try_transform: bottom-up rewrite with structural sharing
# ---------------------------------------------------------------------------
#
# Both share one internal walker. The only difference is what a callback
# returning `None` means:
#   - transform     : None is impossible (callbacks promise to return a node).
#   - try_transform : None aborts the whole rewrite, propagating up.
# Internally the walker uses an `_ABORT` sentinel for the abort signal —
# Python `None` is reserved for legitimate field values (e.g.
# `SQLLiteral(None)`), so we can't use it as the abort marker too.

TryRewrite = Callable[[object], object | None]
_ABORT = object()


def _rewrite_value(value: object,
                   expr_fn: TryRewrite | None,
                   source_fn: TryRewrite | None,
                   query_fn: TryRewrite | None) -> object:
    if isinstance(value, _IR_BASES):
        return _rewrite_node(value, expr_fn, source_fn, query_fn)
    if isinstance(value, (tuple, list)):
        new_elems: list[object] = []
        any_changed = False
        for elem in value:
            new_elem = _rewrite_value(elem, expr_fn, source_fn, query_fn)
            if new_elem is _ABORT:
                return _ABORT
            if new_elem is not elem:
                any_changed = True
            new_elems.append(new_elem)
        if not any_changed:
            return value
        return tuple(new_elems) if isinstance(value, tuple) else new_elems
    return value


def _rewrite_node(node: object,
                  expr_fn: TryRewrite | None,
                  source_fn: TryRewrite | None,
                  query_fn: TryRewrite | None) -> object:
    # Bottom-up: rewrite every field's value first, reconstruct the node only
    # if any field actually changed, then apply the matching user fn.
    rewritten = node
    if is_dataclass(node) and not isinstance(node, type):
        changes: dict[str, object] = {}
        for f in fields(node):
            old = getattr(node, f.name)
            new = _rewrite_value(old, expr_fn, source_fn, query_fn)
            if new is _ABORT:
                return _ABORT
            if new is not old:
                changes[f.name] = new
        if changes:
            rewritten = replace(node, **changes)

    for fn, base in ((expr_fn, SQLExpr), (source_fn, SQLSource), (query_fn, SQLQuery)):
        if fn is not None and isinstance(rewritten, base):
            result = fn(rewritten)
            if result is None:
                return _ABORT
            rewritten = result
    return rewritten


def transform(node: T,
              *,
              expr_fn: Rewrite | None = None,
              source_fn: Rewrite | None = None,
              query_fn: Rewrite | None = None) -> T:
    """Bottom-up rewrite. Each `*_fn`, when given, fires on every reachable
    node of its IR base category (post-order — children rewritten first).

    Returns the same instance when nothing changed (structural sharing).
    Callbacks must return a node — None is reserved for `try_transform`.
    """
    result = _rewrite_node(node, expr_fn, source_fn, query_fn)
    assert result is not _ABORT, "transform callback returned None; use try_transform for fail-stop semantics"
    return cast(T, result)


def try_transform(node: T, *, expr_fn: TryRewrite) -> T | None:
    """Bottom-up rewrite with fail-stop semantics: if `expr_fn` returns None
    for any expression, the whole rewrite aborts and `None` propagates up.

    Used by passes that need to substitute column references but must back
    out atomically when one ref can't be resolved.
    """
    result = _rewrite_node(node, expr_fn, None, None)
    if result is _ABORT:
        return None
    return cast(T, result)


# ---------------------------------------------------------------------------
# Common predicate built on `fold`: every qualified column ref is in `allowed`
# ---------------------------------------------------------------------------


def node_is_closed(node: object, allowed: set[str]) -> bool:
    """True iff every qualified ``SQLColumnRef`` reachable from ``node``
    targets an alias in ``allowed``, **with proper SQL scope tracking**:
    a nested ``SQLSelectQuery`` introduces its own ``FROM``/``JOIN``
    aliases into the visible set for its subtree (and refs in correlated
    sub-positions still see the enclosing scope). Unqualified refs are
    accepted — SQL scoping resolves them at the nearest enclosing FROM.

    Used by both the lowerer (to gate emit-time decorrelation of Match
    branches) and the optimizer (to gate the post-hoc DecorrelateLateral
    rewrite). Returns True iff the subtree could be evaluated in a
    context where exactly ``allowed`` is in scope — i.e. detaching it from
    its current parent would not leak any free column ref."""
    return _node_is_closed_scoped(node, allowed)


def _node_is_closed_scoped(node: object, allowed: set[str]) -> bool:
    if isinstance(node, SQLColumnRef):
        return node.table_alias is None or node.table_alias in allowed
    if isinstance(node, SQLSelectQuery):
        # The subquery binds its own FROM/JOIN aliases. Those names extend
        # ``allowed`` for everything reachable from this query node — so a
        # ref like ``s2.x`` inside a derived table is fine when ``s2`` is
        # the table this query joins, even if ``s2`` isn't visible at the
        # outer level. Correlated sub-positions still see ``allowed`` from
        # above (we don't shrink the set when descending).
        extended = set(allowed)
        if node.from_item is not None:
            extended.add(node.from_item.alias)
        for j in node.joins:
            extended.add(j.alias)
        for f in fields(node):
            if not _value_is_closed_scoped(getattr(node, f.name), extended):
                return False
        return True
    if isinstance(node, SQLUnionQuery):
        return all(_node_is_closed_scoped(q, allowed) for q in node.queries)
    if is_dataclass(node):
        for f in fields(node):
            if not _value_is_closed_scoped(getattr(node, f.name), allowed):
                return False
        return True
    return True


def _value_is_closed_scoped(value: object, allowed: set[str]) -> bool:
    if isinstance(value, _IR_BASES):
        return _node_is_closed_scoped(value, allowed)
    if isinstance(value, (tuple, list)):
        return all(_value_is_closed_scoped(v, allowed) for v in value)
    return True


# ---------------------------------------------------------------------------
# Base-table presence — predicate used by backends whose DDL forms require
# that the query body actually reference some real table (e.g., Snowflake
# Dynamic Tables reject bodies whose only source is a row generator or a
# VALUES literal).
# ---------------------------------------------------------------------------


def substitute_outer_with_inner_in_expr(
    expr: SQLExpr, lift_keys: "list[tuple[SQLExpr, SQLExpr]]"
) -> SQLExpr:
    """For each ``(inner_expr, outer_expr)`` in ``lift_keys``, replace every
    structurally-equal occurrence of ``outer_expr`` in ``expr`` with
    ``inner_expr``. Sound because the equality is asserted by a WHERE
    conjunct that the caller is about to lift into the JOIN ON, so the two
    are interchangeable within the body's row scope.

    Structural equality is exact here because both ``outer_expr`` and the
    expressions it targets in ``expr`` come from the same un-reordered
    lowered IR — no commutative or associative rewrites have run between
    the source of the WHERE conjunct and its consumers.

    Shared by the lowerer's lift gate and the SQL optimizer's
    ``DecorrelateLateral`` pass so both layers do the same substitution
    when they extract equality correlations."""
    result = expr
    for inner_expr, outer_expr in lift_keys:
        def rewrite(node: object, _outer: SQLExpr = outer_expr, _inner: SQLExpr = inner_expr) -> object:
            if isinstance(node, SQLExpr) and node == _outer:
                return _inner
            return node
        result = transform(result, expr_fn=rewrite)  # type: ignore[arg-type]
    return result


def query_has_base_table(query: SQLQuery) -> bool:
    """True iff any node reachable from ``query`` is an ``SQLTableSource``.

    Recurses through every IR field via the standard ``fold`` walker —
    including subqueries (``SQLSubquerySource.query``) and union branches
    (``SQLUnionQuery.queries``) — so a base-table reference buried inside a
    derived table is still detected. ``SQLTableFunctionSource``,
    ``SQLValuesSource``, and ``SQLSingletonSource`` are derived sources and
    deliberately do NOT count: they produce rows without referencing any
    stored relation, which is exactly the shape Snowflake rejects as a DT
    body."""
    def step(node: object, acc: bool) -> bool:
        return acc or isinstance(node, SQLTableSource)
    return fold(query, step, False)
