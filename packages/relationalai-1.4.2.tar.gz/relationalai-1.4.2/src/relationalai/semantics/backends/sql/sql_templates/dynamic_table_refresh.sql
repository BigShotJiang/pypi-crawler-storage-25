DECLARE
  v_refresh_start VARCHAR;
  v_poll_query    VARCHAR;
  v_state         VARCHAR;
  refresh_failed  EXCEPTION (-20001, 'Dynamic table refresh did not succeed');
BEGIN
  -- Capture the time before the ALTER so we can filter the refresh history
  -- to entries that started on or after this moment, avoiding stale results.
  v_refresh_start := TO_VARCHAR(CURRENT_TIMESTAMP());
  ALTER DYNAMIC TABLE {table_name} REFRESH;

  v_poll_query :=
    'SELECT STATE FROM TABLE({info_schema}.DYNAMIC_TABLE_REFRESH_HISTORY({history_args}))'
    || ' WHERE REFRESH_START_TIME >= TO_TIMESTAMP_LTZ(''' || :v_refresh_start || ''')'
    || ' ORDER BY REFRESH_START_TIME DESC LIMIT 1';

  v_state := (CALL {meta_schema}.POLL_UNTIL_DONE(
    :v_poll_query,
    'SUCCEEDED,FAILED,CANCELLED,UPSTREAM_FAILED',
    1,
    10
  ));

  IF (v_state != 'SUCCEEDED') THEN
    RAISE refresh_failed;
  END IF;
END
