from __future__ import annotations

import json
from dataclasses import asdict
from typing import TYPE_CHECKING

import rich

from relationalai.config.config import Config
from relationalai.config.config_fields import TableMaterialization
from relationalai.semantics.backends.sql._utils import resolve_by_table_name
from relationalai.semantics.backends.sql.normalizer import StorageVersionNormalizer
from relationalai.semantics.metamodel import metamodel as mm
from relationalai.util.error import warn as _warn
from relationalai.util.identifiers import IdentityParser

from .sql.logic_block_builder import LogicBlockBuilder
from .sql.artifacts import Catalog, LogicBlock
from .legacy_executor import LegacyExecutor


if TYPE_CHECKING:
    from .sql.artifacts import BlockVersionState
    from .sql.coalescer import CoalescedBlock

def _sql_string_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"

def _sql_nullable_int_literal(value: int | None) -> str:
    return "NULL" if value is None else str(value)

def _sql_bool_literal(value: bool) -> str:
    return "TRUE" if value else "FALSE"

def _col_def(col, table_name: str) -> str:
    if col.sql_type is None:
        raise ValueError(f"No SQL type for column {col.name!r} in {table_name}")
    return f'"{col.name}" {col.sql_type}'

class LogicExecutor:
    """Submits LQP blobs to the Snowflake-hosted logic reasoner.

    This executor is only instantiated on Snowflake connections. Any
    :class:`~sql.artifacts.LogicBlock` in the execution plan is routed
    here rather than to the SQL executor.
    """

    def __init__(self, config: Config, sf_database: str) -> None:
        self._config = config
        self._sf_database = sf_database
        self._legacy_executor = LegacyExecutor(config = self._config, database = self._sf_database)

    def plan_block(
        self,
        block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        storage_normalizer: StorageVersionNormalizer,
    ) -> LogicBlock | None:
        """Compile a logic block into the execution payload the LR backend needs.

        Called during model install (inside the Lowerer) to produce the plan
        that is stored in the plan table and passed to :meth:`execute`.
        """
        block_builder = LogicBlockBuilder(storage_normalizer, self._sf_database)
        return block_builder.build(
            block,
            model,
            catalog,
            version_state,
        )


    def execute_block(self, block: LogicBlock, mm_model: mm.Model) -> None:
        """Execute a single LQP step against the logic reasoner."""

        execution_model = mm_model.mut(root=block.install_root)
        self._legacy_executor.execute_mm(
            dsl_query_string="LQP block",
            mm_query=block.export_query,
            mm_model=execution_model,
        )


    def plan_refresh_sql(self, meta_schema: str, block_index: int, block: LogicBlock, mm_model: mm.Model, show_debug_logs: bool = False) -> tuple[str, tuple[str, ...]]:
        """Return the SQL/call that the refresh procedure uses to re-run this block,
        along with the block's input source-table FQNs (used by the orchestrator
        to clean up stale CDC streams before kicking off the install)."""

        execution_model = mm_model.mut(root=block.install_root)
        compiled = self._legacy_executor.build_lqp_refresh_spec(
            mm_query=block.export_query,
            mm_model=execution_model,
        )

        sources_payload = []
        for fq in compiled.source_tables:
            parser = IdentityParser(fq, require_all_parts=True)
            sources_payload.append({
                "fqName": parser.identity or fq,
                "db": parser.db,
                "schema": parser.schema,
                "name": parser.entity,
            })
        source_tables_json = json.dumps(sources_payload)
        export_specs_json = json.dumps([asdict(e) for e in compiled.export_specs])

        model_database = compiled.model_database
        engine_name = compiled.engine_name
        engine_size = compiled.engine_size
        query_timeout_mins = compiled.query_timeout_mins
        wait_for_stream_sync = compiled.wait_for_stream_sync
        lqp_payload_b64 = compiled.lqp_payload_b64

        run_sql = (
            f"CALL {meta_schema}.RUN_LQP_BLOCK("
            f"{_sql_nullable_int_literal(block_index)}, "
            f"{_sql_string_literal(model_database)}, "
            f"{_sql_string_literal(engine_name)}, "
            f"{_sql_string_literal(engine_size)}, "
            f"{_sql_nullable_int_literal(query_timeout_mins)}, "
            f"{_sql_bool_literal(wait_for_stream_sync)}, "
            f"{_sql_string_literal(source_tables_json)}, "
            f"{_sql_string_literal(lqp_payload_b64)}, "
            f"{_sql_string_literal(export_specs_json)})"
        )
        if show_debug_logs:
            rich.print("\n[yellow]--------------------------------------------------------------[/yellow]")
            rich.print(run_sql)
        return run_sql, tuple(compiled.source_tables)

    def get_snowflake_resources(self):
        """Expose the v0 Snowflake ``Resources`` handle for the orchestrator."""
        return self._legacy_executor.get_snowflake_resources()

    def plan_install_sql(
        self,
        block: LogicBlock,
        catalog: Catalog,
        show_debug_logs: bool = False,
    ) -> tuple[str, ...]:
        store_by_name = {
            s.object_name: s
            for s in (
                *catalog.entity_store_by_name.values(),
                *catalog.relation_stores.values(),
                *catalog.data_stores.values(),
            )
        }
        statements: list[str] = []
        mat_map = {k.lower(): v for k, v in (self._config.schedule.table_materialization or {}).items()}
        mat_default = self._config.schedule.table_materialization_default
        for table_name in block.output_table_names:
            store = store_by_name.get(table_name)
            if store is None:
                continue
            col_defs = ", ".join(
                _col_def(c, table_name) for c in store.columns
            )
            _mat = resolve_by_table_name(table_name, mat_map, mat_default)
            if _mat != TableMaterialization.TABLE:
                _warn(
                    "Logic block table fallback",
                    f"Table {table_name!r} was configured as {_mat.value!r} but it is produced "
                    f"by the logic reasoner. Logic block outputs cannot use that materialization. "
                    f"Falling back to a plain TABLE.",
                )
            statements.append(f"CREATE OR REPLACE TABLE {table_name} ({col_defs})")
        if show_debug_logs:
            for sql in statements:
                rich.print("\n[yellow]--------------------------------------------------------------[/yellow]")
                rich.print(sql)
        return tuple(statements)
