from __future__ import annotations

from pandas import DataFrame

from relationalai.semantics.backends.sql.sql_backend import SQLBackend
from .sql_executor import SQLExecutor
from relationalai.semantics.metamodel.metamodel_analyzer import RelationAnalyzer

from ...config.connections.duckdb import DuckDBConnection
from ...config.connections.snowflake import SnowflakeConnection

from collections.abc import Callable, Iterable

from .executor import MetamodelExecutor
from ...config.config import Config
from ..metamodel import metamodel as mm
from ...observability import tracing

from .sql.artifacts import Catalog, CoalescedBlock, ModelPlan, SCCGraph
from .sql.orchestrator import Orchestrator, SnowflakeOrchestrator
from .logic_executor import LogicExecutor
from .sql.dag_visualizer import format_install_dag

from .sql.catalog_builder import CatalogBuilder
from .sql.stratifier import Stratifier
from .sql.reasoner_router import ReasonerRouter
from .sql.coalescer import Coalescer
from .sql.normalizer import StorageVersionNormalizer
from .install_readiness import InstallReadinessResult
from .sql.writer_unifier import WriterUnifier


class MultiReasonerExecutor(MetamodelExecutor):
    """Executor that owns the compilation pipeline, install loop, and query execution."""

    #------------------------------------------------------
    # Public API
    #------------------------------------------------------

    def __init__(self, config: Config) -> None:
        self._config = config
        self._show_debug_logs = config.debug.show_debug_logs
        self._dry_run = config.compiler.dry_run
        self._install_result: ModelPlan | None = None

        self._sql_backend = self._create_sql_backend(self._resolve_model_schema(config))
        self._sql_executor = SQLExecutor(self._sql_backend, self._config)
        self._logic_executor: LogicExecutor = LogicExecutor(self._config, self._sql_backend.database)
        self._relation_analyzer = RelationAnalyzer()
        self._catalog_builder = CatalogBuilder()
        self._writer_unifier = WriterUnifier()
        self._stratifier = Stratifier()
        self._reasoner_router = ReasonerRouter()
        self._coalescer = Coalescer()
        self._orchestrator: Orchestrator = self._create_orchestrator()

    def install(self, model: mm.Model, force_dry_run: bool = False, **kwargs) -> InstallReadinessResult:
        storage_normalizer, model_plan = self._create_model_plan(model)
        dry_run = force_dry_run or self._dry_run

        # Reset per-install accumulation state.
        self._orchestrator = self._create_orchestrator()

        if not dry_run:
            self._sql_executor.ensure_schema_exists(self._sql_backend.schema_name)

        # Seed views (always SQL)
        seed_plan = self._sql_executor.plan_seed_views(
            self._seed_object_names_for_install(
                model_plan.seed_object_names,
                model_plan.blocks,
            ),
            model_plan.catalog,
        )
        if seed_plan:
            self._orchestrator.register_sql_block(-1, seed_plan)

        for block in model_plan.blocks:
            if block.reasoner_type == "sql":
                sql_plan = self._sql_executor.plan_block(
                    block, model, model_plan.catalog, model_plan.version_state,
                    storage_normalizer, self._show_debug_logs,
                )
                self._orchestrator.register_sql_block(block.index, sql_plan, interval_s=block.interval_s)
            elif block.reasoner_type == "logic":
                logic_block = self._logic_executor.plan_block(
                    block,
                    model,
                    model_plan.catalog,
                    model_plan.version_state,
                    storage_normalizer
                )
                if logic_block is not None:
                    schema_only_sql = self._logic_executor.plan_install_sql(
                        logic_block, model_plan.catalog, self._show_debug_logs,
                    )
                    run_sql, source_tables = self._logic_executor.plan_refresh_sql(
                        self._sql_backend.meta_schema,
                        block.index,
                        logic_block,
                        model,
                        self._show_debug_logs,
                    )
                    self._orchestrator.register_logic_block(
                        block_index=block.index,
                        block=logic_block,
                        run_sql=run_sql,
                        schema_only_sql=schema_only_sql,
                        interval_s=block.interval_s,
                        source_tables=source_tables,
                    )
            else:
                raise RuntimeError(
                    f"Unsupported reasoner '{block.reasoner_type}'. "
                    "Supported reasoners are 'sql' and 'logic'."
                )

        self._install_result = model_plan

        if dry_run:
            # No finalize — query the current install state from REFRESH_LOG.
            return self._orchestrator.check_readiness()

        return self._orchestrator.finalize()

    def wait_for_initial_refresh(self) -> None:
        """Block until the async initial refresh call completes."""
        self._orchestrator.wait_for_initial_refresh()

    def execute_query(self, model: mm.Model, query: mm.Task, **kwargs) -> DataFrame:
        assert self._install_result is not None, "Model must be installed before executing queries."
        return self._sql_executor.execute_query(
            query,
            self._install_result,
            StorageVersionNormalizer(),
            dry_run=self._dry_run,
            show_debug_logs=self._show_debug_logs,
        )

    #------------------------------------------------------
    # Implementation Details
    #------------------------------------------------------

    def _add_to_span(self, span, item, key: str = "metamodel", transform: Callable = str) -> None:
        """Attach ``item`` (transformed to a string) to ``span[key]``, gated on ``debug.enabled``.

        Skips both the transformation and the span write when debug is off — so the
        ``str()`` cost of large structures is paid only when the user asked for it.
        """
        if not self._config.debug.enabled or not item:
            return
        if isinstance(item, Iterable) and not isinstance(item, (str, bytes)):
            span[key] = "[\n" + "\n".join(transform(i) for i in item) + "\n]"
        else:
            span[key] = transform(item)

    @staticmethod
    def _seed_object_names_for_install(
        seed_object_names: tuple[str, ...],
        blocks: tuple[CoalescedBlock, ...],
    ) -> tuple[str, ...]:
        # Only seed stores that are never written by any execution block. Stores that
        # read from themselves (self-dependent) also need an empty bootstrap seed, but
        # only at query/refresh time — at install time their execution block already
        # creates the same table via DDL, so seeding them here would create them twice.
        written_object_names = {
            planned_target.target.object_name
            for block in blocks
            for planned_target in block.targets
        }
        return tuple(
            object_name
            for object_name in seed_object_names
            if object_name not in written_object_names
        )


    def _create_sql_backend(self, schema_name: str) -> SQLBackend:
        """ Create the appropriate instance of SQLBackend based on the default connection
        type in the configuration. Ideally this is the only place where we distingush
        between different SQL backends.

        ``schema_name`` is the raw (pre-normalize) install-schema name; each backend
        normalizes it internally and exposes the canonical value via
        ``schema_name`` (and, for Snowflake, ``meta_schema``).
        """
        conn = self._config.get_default_connection()
        if isinstance(conn, DuckDBConnection):
            from relationalai.semantics.backends.sql.duckdb_backend import DuckDBBackend
            return DuckDBBackend(conn.get_session(), conn.path, schema_name=schema_name)
        elif isinstance(conn, SnowflakeConnection):
            from .sql.snowflake_backend import SnowflakeBackend
            session = conn.get_session()
            schedule_cfg = self._config.schedule
            return SnowflakeBackend(
                session,
                conn.database or "default",
                table_materialization_default=schedule_cfg.table_materialization_default,
                table_materialization=schedule_cfg.table_materialization,
                schema_name=schema_name,
            )
        else:
            raise ValueError(
                f"Unsupported connection type: {type(conn)}. "
                "Supported connections are 'snowflake' and 'duckdb'."
            )

    def _create_orchestrator(self) -> Orchestrator:
        """ Create the appropriate Orchestrator instance based on the SQL backend. """
        # TODO: this eventually should be moved to the backend itself.
        conn = self._config.get_default_connection()
        if isinstance(conn, SnowflakeConnection):
            resources = None if self._dry_run else self._logic_executor.get_snowflake_resources()
            return SnowflakeOrchestrator(
                session=conn.get_session(),
                app_name=conn.rai_app_name,
                sql_executor=self._sql_executor,
                meta_schema=self._sql_backend.meta_schema,
                schedule_cfg=self._config.schedule,
                resources=resources,
            )
        return Orchestrator(sql_executor=self._sql_executor)


    def _resolve_model_schema(self, config) -> str:
        """ Find the model schema name from the config, raising an error if it's not
        specified or invalid. """
        schema_name = config.model.schema_
        if schema_name is None or not schema_name.strip():
            raise ValueError("Configuration must specify a non-empty schema name.")
        return schema_name.strip()


    def _create_model_plan(self, model: mm.Model) -> tuple[StorageVersionNormalizer, ModelPlan]:
        with tracing.span("Relation Analyzer"):
            relation_analysis = self._relation_analyzer.analyze(model)
        with tracing.span("Catalog Builder") as span:
            catalog = self._catalog_builder.build(
                model, relation_analysis, schema_name=self._sql_backend.schema_name,
                schedule_cfg=self._config.schedule,
            )
            self._add_to_span(span, catalog, "result")
        with tracing.span("Writer Unifier"):
            model = self._writer_unifier.unify(model, catalog, self._show_debug_logs)
        with tracing.span("Stratifier") as span:
            scc_graph = self._stratifier.build_scc_graph(model, catalog)
            self._add_to_span(span, scc_graph, "result")
        forced_reasoners = _resolve_forced_reasoners(
            self._config.outputs.force_reasoner, catalog, scc_graph,
        )
        with tracing.span("Reasoner Router") as span:
            blocks = self._reasoner_router.route(
                scc_graph, model, catalog=catalog, forced_reasoners=forced_reasoners,
            )
            self._add_to_span(span, blocks, "result")
        with tracing.span("Coalescer") as span:
            coalesced_blocks = self._coalescer.plan(
                model, catalog, blocks, forced_reasoners=forced_reasoners,
            )
            self._add_to_span(span, True, "result", lambda _: format_install_dag(catalog, coalesced_blocks))

        storage_normalizer = StorageVersionNormalizer()
        version_state = storage_normalizer.initial_version_state(model, catalog)
        seed_object_names = storage_normalizer.compute_seed_object_names(catalog, coalesced_blocks)
        return storage_normalizer, ModelPlan(
            catalog=catalog,
            blocks=tuple(coalesced_blocks),
            version_state=version_state,
            seed_object_names=seed_object_names,
        )


def _resolve_forced_reasoners(
    raw: dict[str, str],
    catalog: Catalog,
    scc_graph: SCCGraph,
) -> dict[int, str]:
    """Resolve ``outputs.force_reasoner`` (object name → reasoner) into a
    per-relation_id forcing map, propagated across SCC members.

    Matching uses Snowflake identifier semantics via ``IdentityParser``:
    unquoted identifiers fold to uppercase (so ``cancel_chain`` matches
    ``CANCEL_CHAIN``), while quoted identifiers preserve case and special
    characters (so ``'"my.table"'`` is a distinct, dot-containing name).
    Both the config key and the catalog ``object_name`` are reduced to their
    bare (last-segment) form for comparison.

    An SCC must run on a single reasoner, so a forcing on any member is
    propagated to all members. Conflicting forcings within one SCC raise.

    Unmatched config keys emit a ``UnknownForceReasonerKey`` warning and are
    otherwise ignored (e.g. property names folded into an entity's store as
    columns, or names the model doesn't use).
    """
    if not raw:
        return {}
    from relationalai.util.identifiers import IdentityParser
    normalized = {IdentityParser(k).bare_name: v for k, v in raw.items()}

    out: dict[int, str] = {}
    matched_keys: set[str] = set()
    for store in catalog.entity_stores.values():
        key = IdentityParser(store.object_name).bare_name
        r = normalized.get(key)
        if r is not None:
            out[store.type_id] = r
            matched_keys.add(key)
    for store in catalog.relation_stores.values():
        key = IdentityParser(store.object_name).bare_name
        r = normalized.get(key)
        if r is not None:
            out[store.relation_id] = r
            matched_keys.add(key)

    unmatched = sorted(set(normalized) - matched_keys)
    if unmatched:
        from relationalai.util.error import warn
        warn(
            "UnknownForceReasonerKey",
            f"force_reasoner config keys did not match any store and were ignored: "
            f"{unmatched}. Keys must be unqualified object names (case-insensitive); "
            f"check spelling.",
        )

    for scc in scc_graph.sccs:
        forced = {out[rid] for rid in scc if rid in out}
        if len(forced) > 1:
            raise ValueError(
                f"force_reasoner: SCC {scc} has conflicting forced reasoners "
                f"{forced}; all forcings within a strongly-connected component must agree."
            )
        if forced:
            single = forced.pop()
            for rid in scc:
                out[rid] = single
    return out
