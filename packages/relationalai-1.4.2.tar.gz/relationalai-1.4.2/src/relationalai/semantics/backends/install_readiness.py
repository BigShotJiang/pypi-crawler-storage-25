from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class InstallReadinessStatus(str, Enum):
    READY = "ready"
    MATCHING_INSTALL_IN_PROGRESS = "matching_install_in_progress"
    INSTALL_PREPARED = "install_prepared"
    NO_INSTALL_STATE = "no_install_state"
    FINGERPRINT_MISMATCH = "fingerprint_mismatch"
    MATCHING_INSTALL_FAILED = "matching_install_failed"


@dataclass(frozen=True)
class InstallReadinessResult:
    status: InstallReadinessStatus
    detail: str | None = None
