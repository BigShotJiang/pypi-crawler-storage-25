"""SQL-specific executor — lowers, emits, and executes SQL blocks."""

from __future__ import annotations

import rich
from collections.abc import Callable, Iterable
from pandas import DataFrame

from ...config.config import Config
from ...util.error import exc
from ..metamodel import metamodel as mm
from ...observability import tracing

from .sql.artifacts import BlockVersionState, Catalog, ExecutionPlan, PlannedSemiNaiveLoop, PlannedSQLStep, SQLExecutionStep
from .sql.coalescer import CoalescedBlock
from .sql.sql_backend import SQLBackend

# SQL-specific passes
from .sql.normalizer import SQLNormalizer, StorageVersionNormalizer
from .sql.lowerer import Lowerer
from .sql.sql_optimizer import SQLOptimizer
from .sql.emitter import SQLEmitter
from .sql.pprint import pprint as sql_pprint


class SQLExecutor:
    """Handles SQL-specific planning and execution: schema,
    seed views, SQL block compilation, and SQL step execution."""

    def __init__(self, sql_backend: SQLBackend, config: Config) -> None:
        self._sql_backend = sql_backend
        self._config = config
        self._ensured_schema: str | None = None
        self._sql_normalizer = SQLNormalizer()
        self._optimizer = SQLOptimizer()
        self._emitter = SQLEmitter(self._sql_backend)

    def _add_to_span(self, span, item, key: str = "metamodel", transform: Callable = str) -> None:
        """Attach ``item`` (transformed to a string) to ``span[key]``, gated on ``debug.enabled``.

        Skips both the transformation and the span write when debug is off — so the
        ``str()`` cost of large structures is paid only when the user asked for it.
        """
        if not self._config.debug.enabled or not item:
            return
        if isinstance(item, Iterable) and not isinstance(item, (str, bytes)):
            span[key] = "[\n" + "\n".join(transform(i) for i in item) + "\n]"
        else:
            span[key] = transform(item)

    def execute_query(
        self,
        query: mm.Task,
        install_result,
        storage_normalizer,
        *,
        dry_run: bool,
        show_debug_logs: bool,
    ) -> DataFrame:
        with tracing.span("SQL Normalizer") as span:
            canonical = self._sql_normalizer.normalize(query)
            self._add_to_span(span, canonical)
        with tracing.span("Storage Normalizer") as span:
            canonical = storage_normalizer.bind_fragment(
                canonical,
                install_result.version_state.latest_tables_by_relation_id,
            )
            self._add_to_span(span, canonical)
        if not isinstance(canonical, mm.Task):
            return DataFrame()

        with tracing.span("Lowerer") as span:
            lowered = Lowerer(install_result.catalog).lower_fragment(canonical)
            self._add_to_span(span, lowered, "result", lambda ir: self._emitter.pretty(ir))
        if lowered is None:
            return DataFrame()

        with tracing.span("Optimizer") as span:
            lowered = self._optimizer.optimize_query(lowered)
            self._add_to_span(span, lowered, "result", lambda ir: self._emitter.pretty(ir))

        with tracing.span("Emitter") as span:
            frag_sql = self._emitter.emit(lowered)
            if dry_run:
                self._add_to_span(span, frag_sql, "result")
            if show_debug_logs:
                rich.print("\n[cyan]--------------------------------------------------------------[/cyan]")
                rich.print(self._emitter.pretty(frag_sql))

        if dry_run:
            return DataFrame()

        with tracing.span("Execute SQL Query") as span:
            self._add_to_span(span, frag_sql, "result")
            result = self._sql_backend.execute_sql(frag_sql)
            span["sort_results"] = True
        return result

    def ensure_schema_exists(self, schema_name: str) -> None:
        if self._ensured_schema == schema_name:
            return
        try:
            with tracing.span("Schema Exists Check"):
                self._sql_backend.execute_sql(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")
        except Exception as e:
            exc(
                "Schema setup failed",
                f"Failed to ensure install schema '{schema_name}' exists.",
                [str(e)],
            )
        self._ensured_schema = schema_name

    @property
    def execute_sql(self) -> Callable[[str], DataFrame]:
        return self._sql_backend.execute_sql

    @property
    def execute_sql_batch(self) -> Callable[[list[str]], None]:
        return self._sql_backend.execute_sql_batch

    def plan_seed_views(
        self,
        seed_object_names: tuple[str, ...],
        catalog: Catalog,
    ) -> list[PlannedSQLStep]:
        lowerer = Lowerer(catalog)
        seed_views = lowerer._seed_views(seed_object_names)
        if not seed_views:
            return []
        bodies = tuple(self._emitter.emit_query(v.query) for v in seed_views)
        install_sql_batch = tuple(
            sql for v, body in zip(seed_views, bodies)
            if (sql := self._sql_backend.emit_install_ddl(v, body)) is not None
        )
        refresh_sql_batch = tuple(
            self._sql_backend.emit_refresh_sql(v, body)
            for v, body in zip(seed_views, bodies)
        )
        fqns = tuple(self._sql_backend.quote_table_name(v.name) for v in seed_views)
        view_names = tuple(v.name for v in seed_views)
        return [PlannedSQLStep(
            view_names=view_names,
            refresh_sql_batch=refresh_sql_batch,
            fqns=fqns,
            semi_naive_loops=(),
            install_sql_batch=install_sql_batch,
        )]

    def plan_block(
        self,
        block: CoalescedBlock,
        model: mm.Model,
        catalog: Catalog,
        version_state: BlockVersionState,
        storage_normalizer: StorageVersionNormalizer,
        show_debug_logs: bool,
    ) -> list[PlannedSQLStep]:
        lowerer = Lowerer(catalog)
        with tracing.span("Storage Normalizer") as span:
            normalized = storage_normalizer.normalize_sql_block(
                block, model, catalog, version_state
            )
            self._add_to_span(span, normalized, "result")
        if normalized is None:
            return []
        with tracing.span("Lowerer") as span:
            lowered = lowerer.lower_block(normalized)
            self._add_to_span(span, lowered, "result", sql_pprint)
        with tracing.span("Optimizer") as span:
            optimized = self._optimizer.optimize_plan(ExecutionPlan(steps=tuple(lowered)))
            self._add_to_span(span, optimized, "result", sql_pprint)
        with tracing.span("Emitter") as span:
            planned_steps: list[PlannedSQLStep] = []
            pretty_stmts: list[str] = []
            for sql_step in optimized.steps:
                assert isinstance(sql_step, SQLExecutionStep)
                bodies = tuple(self._emitter.emit_query(view.query) for view in sql_step.views)
                fqns = tuple(self._sql_backend.quote_table_name(view.name) for view in sql_step.views)
                view_names = tuple(view.name for view in sql_step.views)
                install_sql_batch = tuple(
                    sql for view, body in zip(sql_step.views, bodies)
                    if (sql := self._sql_backend.emit_install_ddl(view, body)) is not None
                )
                refresh_sql_batch = tuple(
                    self._sql_backend.emit_refresh_sql(view, body)
                    for view, body in zip(sql_step.views, bodies)
                )
                pretty_stmts.extend(self._emitter.pretty(s) for s in install_sql_batch)
                pretty_stmts.extend(self._emitter.pretty(s) for s in refresh_sql_batch if s)
                semi_naive: list[PlannedSemiNaiveLoop] = []
                for loop in sql_step.semi_naive_loops:
                    table_names = tuple(t.table_name for t in loop.tables)
                    plan = self._sql_backend.build_semi_naive_plan(loop, self._emitter)
                    install_sql = tuple(
                        self._sql_backend.install_table_ddl(t.table_name, t.column_types)
                        for t in loop.tables
                        if t.column_types
                    )
                    semi_naive.append(PlannedSemiNaiveLoop(table_names, plan, install_sql))
                    if isinstance(plan, str):
                        pretty_stmts.append(plan) # no pretty printing for now because sqlglot doesn't support scripting blocks
                planned_steps.append(PlannedSQLStep(
                    view_names=view_names,
                    refresh_sql_batch=refresh_sql_batch,
                    fqns=fqns,
                    semi_naive_loops=tuple(semi_naive),
                    install_sql_batch=install_sql_batch,
                ))
            if show_debug_logs:
                for sql in pretty_stmts:
                    rich.print("\n[yellow]--------------------------------------------------------------[/yellow]")
                    rich.print(sql)
        return planned_steps

    def execute_block(self, plan: list[PlannedSQLStep]) -> None:
        for planned in plan:
            refresh = [s for s in planned.refresh_sql_batch if s is not None]
            if refresh:
                try:
                    with tracing.span("Execute SQL Batch") as span:
                        self._add_to_span(span, tuple(refresh), "result")
                        self._sql_backend.execute_sql_batch(refresh)
                except Exception as e:
                    exc(
                        "Model install failed",
                        "Failed to execute model-install SQL batch.",
                        [str(e)],
                    )
            for planned_loop in planned.semi_naive_loops:
                try:
                    with tracing.span("Execute Semi-Naive Loop") as span:
                        self._add_to_span(span, ", ".join(planned_loop.table_names), "result")
                        self._sql_backend.execute_semi_naive(planned_loop.plan)
                except Exception as e:
                    exc(
                        "Model install failed",
                        "Failed to execute recursive model-install loop.",
                        [str(e)],
                    )
