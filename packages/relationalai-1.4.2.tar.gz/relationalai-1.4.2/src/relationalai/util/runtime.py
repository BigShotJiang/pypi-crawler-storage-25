import os
import sys
import threading
import warnings
import importlib
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Callable

import more_itertools
from ..observability.tracing import get_tracer
from .error import Diagnostic, RAIWarning, RichEmitter, HTMLEmitter, RAIException, diagnostic_to_plain_text

_ORIGINAL_FORMATWARNING = warnings.formatwarning

# Thread-local storage for passing rich-rendered output from Env.warn() to
# _formatwarning_for_rai.  Using threading.local() ensures that concurrent
# threads emitting warnings cannot corrupt each other's rich output.
# The lifecycle is: set before warnings.warn(), consumed by formatwarning
# (if the warning is not filtered), cleared in a finally block.
_tls = threading.local()
_cell_start_observers: list[Callable[["ExecutionOrigin"], None]] = []
_snowbook_process_origin: "ExecutionOrigin | None" = None
_snowbook_origin_thread_id: int | None = None


@dataclass(frozen=True, slots=True)
class ExecutionOrigin:
    runtime: str
    cell_id: str


def current_execution_origin() -> ExecutionOrigin | None:
    thread_origin = getattr(_tls, "execution_origin", None)
    if thread_origin is not None:
        return thread_origin

    # Snowbook compiles cells on one thread and executes user Python on another.
    # Preserve the active cell origin process-wide so the execution thread can
    # still observe it, but do not reflect that fallback back to the compiler
    # thread after it has already exited the wrapped compile call.
    if (
        _snowbook_process_origin is not None
        and threading.get_ident() != _snowbook_origin_thread_id
    ):
        return _snowbook_process_origin

    return None


def register_cell_start_observer(fn: Callable[[ExecutionOrigin], None]) -> None:
    if fn not in _cell_start_observers:
        _cell_start_observers.append(fn)


def _set_current_execution_origin(origin: ExecutionOrigin | None) -> None:
    _tls.execution_origin = origin


def _clear_current_execution_origin() -> None:
    _tls.execution_origin = None


def _notify_cell_start(origin: ExecutionOrigin | None) -> None:
    if origin is None:
        return
    for observer in list(_cell_start_observers):
        observer(origin)


def _enter_cell_execution(origin: ExecutionOrigin | None) -> None:
    global _snowbook_process_origin, _snowbook_origin_thread_id
    if origin is not None and origin.runtime == "snowbook":
        _snowbook_process_origin = origin
        _snowbook_origin_thread_id = threading.get_ident()
    try:
        ENV.on_cell_start(origin)
    except Exception:
        pass
    _set_current_execution_origin(origin)
    _notify_cell_start(origin)


def _exit_cell_execution() -> None:
    _clear_current_execution_origin()


def _warning_message(diag: Diagnostic) -> str:
    return f"[{diag.name}] {diag.message}"


def _formatwarning_for_rai(
    message,
    category,
    filename,
    lineno,
    line=None,
):
    """Format SDK diagnostics through the standard warnings machinery.

    When a rich-rendered string is pending (set by an Env.warn() call),
    return it so that the pretty output is written by showwarning instead
    of being written directly to stderr.  This keeps all output gated on
    warnings.filters, so ``warnings.filterwarnings("ignore", ...)`` works
    for RAIWarning in every environment.

    When no rich output is pending (e.g. File env, or non-TTY), return
    the plain ``[name] message`` string without Python's filename/lineno
    preamble.

    Test frameworks that replace ``showwarning`` (e.g. pytest.warns /
    catch_warnings(record=True)) never call ``formatwarning``, so the
    pending output is harmlessly cleared by the caller.
    """
    try:
        if issubclass(category, RAIWarning):
            pending = getattr(_tls, "pending_rich_output", None)
            if pending is not None:
                _tls.pending_rich_output = None
                return pending.rstrip() + "\n"
            return f"{message}\n"
    except Exception:
        pass
    return _ORIGINAL_FORMATWARNING(message, category, filename, lineno, line=line)


warnings.formatwarning = _formatwarning_for_rai

#------------------------------------------------------
# Base Env
#------------------------------------------------------

class EnvBase:
    """Decides renderer and how to deliver the string. Override to suit your runtime."""
    # Which renderer to use for this env
    prefers_html: bool = False

    def __init__(self):
        # Keep duplicate suppression scoped to this env instance.
        self.seen_diagnostics: list[str] = []

    def is_active(self) -> bool:  # override
        return False

    def activate(self) -> None:
        pass

    def on_cell_start(self, origin: "ExecutionOrigin | None") -> None:
        pass

    def renderer(self):
        return HTMLEmitter() if self.prefers_html else RichEmitter()

    # Delivery hooks — override as needed
    def info(self, diag: Diagnostic):
        """Default: print info diagnostics without warnings integration."""
        rendered = self.renderer().emit(diag)
        if rendered in self.seen_diagnostics:
            return  # avoid duplicate output
        if self.prefers_html:
            # In notebook-y envs, try to display inline
            try:
                from IPython.display import display, HTML as _HTML  # type: ignore[import-not-found]
                display(_HTML(rendered))
            except Exception:
                sys.stderr.write(rendered.rstrip() + "\n")
        else:
            sys.stdout.write(rendered.rstrip() + "\n")
        self._trace(diag)
        self.seen_diagnostics.append(rendered)

    def warn(self, diag: Diagnostic):
        """Integrate with Python warnings and print rich output for terminals.

        All output is routed through ``warnings.warn()`` so that
        ``warnings.filterwarnings("ignore", ...)`` suppresses both the
        rich and plain representations.
        """
        category = RAIWarning
        rendered = self.renderer().emit(diag)
        if rendered in self.seen_diagnostics:
            return  # avoid duplicate output
        # For TTY envs, pass rich output through warnings so it respects filters.
        if not self.prefers_html and sys.stderr and sys.stderr.isatty():
            _tls.pending_rich_output = rendered
        try:
            warnings.warn(_warning_message(diag), category=category, stacklevel=3)
        finally:
            _tls.pending_rich_output = None  # clear if not consumed (filtered/captured/raised)
        self._trace(diag)
        self.seen_diagnostics.append(rendered)


    def err(self, diag: Diagnostic, exception: bool = False):
        """Default: print (or display) and raise a diagnostic exception."""
        # Echo before raising for better UX in terminals/CI
        rendered = self.renderer().emit(diag)
        if rendered in self.seen_diagnostics:
            return  # avoid duplicate output
        if self.prefers_html:
            # In notebook-y envs, try to display inline
            try:
                from IPython.display import display, HTML as _HTML  # type: ignore[import-not-found]
                display(_HTML(rendered))
            except Exception:
                sys.stderr.write("[HTML diagnostic suppressed]\n")
        else:
            sys.stderr.write(rendered.rstrip() + "\n")

        self._trace(diag, error=True)
        self.seen_diagnostics.append(rendered)
        if exception:
            raise RAIException(diag)

    def _trace(self, diag: Diagnostic, error: bool = False):
        try:
            tracer = get_tracer()
            payload = diag.to_dict()
            tracer.add_event("diagnostic", diagnostic=payload)
            if error:
                tracer.set_status(ok=False, message=diag.message)
        except Exception:
            pass

#------------------------------------------------------
# Envs
#------------------------------------------------------

class CI(EnvBase):
    def is_active(self) -> bool:
        return any(os.getenv(k) for k in ("CI", "GITHUB_ACTIONS", "BUILD_NUMBER", "TEAMCITY_VERSION"))

    def info(self, diag: Diagnostic):
        rendered = self.renderer().emit(diag)
        sys.stdout.write(rendered.rstrip() + "\n")
        self._trace(diag)

    def warn(self, diag: Diagnostic):
        # keep CI logs plain and controllable via warnings
        rendered = self.renderer().emit(diag)
        _tls.pending_rich_output = rendered
        try:
            warnings.warn(_warning_message(diag), category=RAIWarning, stacklevel=3)
        finally:
            _tls.pending_rich_output = None
        self._trace(diag)

    def err(self, diag: Diagnostic, exception: bool = False):
        rendered = self.renderer().emit(diag)
        sys.stderr.write(rendered.rstrip() + "\n")
        self._trace(diag)
        if exception:
            raise RAIException(diag)

class Terminal(EnvBase):
    def is_active(self) -> bool:
        try:
            return sys.stderr.isatty()
        except Exception:
            return False


class File(EnvBase):
    """Non-interactive file/script run."""
    def is_active(self) -> bool:
        # If stderr is not a TTY and not a known notebook runtime, treat as file.
        return (
            (not sys.stderr.isatty())
            and ("snowbook" not in sys.modules)
            and ("snowbooks" not in sys.modules)
            and ("ipykernel" not in sys.modules)
            and ("google.colab" not in sys.modules)
            and (not os.getenv("HEX_RUN"))
            and ("hex" not in sys.modules)
        )

    def info(self, diag: Diagnostic):
        # output info to stdout for file/script runs
        rendered = self.renderer().emit(diag)
        sys.stdout.write(rendered.rstrip() + "\n")
        self._trace(diag)

    def warn(self, diag: Diagnostic):
        # Keep non-interactive runs readable without Python's filename/lineno prefix.
        warnings.warn(_warning_message(diag), category=RAIWarning, stacklevel=3)
        self._trace(diag)

    def err(self, diag: Diagnostic, exception: bool = False):
        # Plain text (no ANSI) so script/agent stderr stays readable when piped or captured.
        sys.stderr.write(diagnostic_to_plain_text(diag) + "\n")
        self._trace(diag, error=True)
        if exception:
            raise RAIException(diag)

class NotebookBase(EnvBase):
    """ Base class for all notebook environments.

    Notebook environments prefer inline HTML display and reset per-cell duplicate
    suppression so rerunning a cell surfaces the same diagnostic again.
    """
    def on_cell_start(self, origin: ExecutionOrigin | None) -> None:
        # Keep duplicate suppression scoped to one notebook cell execution.
        self.seen_diagnostics.clear()

    def err(self, diag: Diagnostic, exception: bool = False):
        # Attempt inline display first, but surface a normal diagnostic exception
        # to notebook users instead of a generic Exception containing rendered HTML.
        super().err(diag, exception=False)
        if exception:
            raise RAIException(diag)

class Jupyter(NotebookBase):
    prefers_html = True
    _hooks_installed = False

    def is_active(self) -> bool:
        try:
            from IPython import get_ipython #type: ignore
            ip = get_ipython()
            return bool(ip and ip.__class__.__name__.lower().endswith("zmqinteractiveshell"))
        except Exception:
            return False

    def activate(self) -> None:
        if type(self)._hooks_installed:
            return
        try:
            from IPython import get_ipython  # type: ignore[import-not-found]
        except Exception:
            return
        ip = get_ipython()
        if ip is None:
            return
        self.ipython = ip
        ip.events.register("pre_run_cell", self._on_pre_run_cell)
        ip.events.register("post_run_cell", self._on_post_run_cell)
        type(self)._hooks_installed = True

    def _on_pre_run_cell(self, info) -> None:
        _enter_cell_execution(self._origin_from_info(info))

    def _on_post_run_cell(self, result) -> None:
        _exit_cell_execution()

    def _origin_from_info(self, info) -> ExecutionOrigin | None:
        cell_id = getattr(info, "cell_id", None) or getattr(info, "cellId", None)
        if not cell_id:
            parent = getattr(self, "ipython", SimpleNamespace(get_parent=lambda: {})).get_parent()
            metadata = parent.get("metadata", {}) if isinstance(parent, dict) else {}
            cell_id = metadata.get("cellId") or metadata.get("cell_id")
        if not cell_id:
            return None
        return ExecutionOrigin(runtime="jupyter", cell_id=str(cell_id))

class Colab(NotebookBase):
    prefers_html = True
    def is_active(self) -> bool:
        return "google.colab" in sys.modules

class Hex(NotebookBase):
    prefers_html = True
    def is_active(self) -> bool:
        # Hex notebooks expose 'HEX_RUN' env or similar; keep flexible
        return bool(os.getenv("HEX_RUN") or "hex" in sys.modules)


class Snowbook(NotebookBase):
    prefers_html = True
    _hooks_installed = False
    _wrapper_attr = "_pyrel_compile_and_run_cell_wrapped"

    def is_active(self) -> bool:
        return "snowbook" in sys.modules or "snowbooks" in sys.modules

    def activate(self) -> None:
        if type(self)._hooks_installed:
            return
        compiler = self._find_notebook_compiler()
        if compiler is None or not hasattr(compiler, "compile_and_run_cell"):
            return

        original = compiler.compile_and_run_cell
        if getattr(original, self._wrapper_attr, False):
            type(self)._hooks_installed = True
            return
        env = self

        def wrapped(instance, cell, *args, **kwargs):
            origin = env._origin_from_cell(cell)
            _enter_cell_execution(origin)
            try:
                return original(instance, cell, *args, **kwargs)
            finally:
                _exit_cell_execution()

        setattr(wrapped, self._wrapper_attr, True)
        compiler.compile_and_run_cell = wrapped
        type(self)._hooks_installed = True

    def _find_notebook_compiler(self):
        for package_name in ("snowbooks", "snowbook"):
            package = sys.modules.get(package_name)
            if package is None:
                try:
                    package = importlib.import_module(package_name)
                except Exception:
                    package = None

            compiler = getattr(
                getattr(getattr(package, "executor", None), "notebook_compiler", None),
                "NotebookCompiler",
                None,
            )
            if compiler is not None:
                return compiler

            try:
                module = importlib.import_module(f"{package_name}.executor.notebook_compiler")
            except Exception:
                continue
            compiler = getattr(module, "NotebookCompiler", None)
            if compiler is not None:
                return compiler
        return None

    def _origin_from_cell(self, cell) -> ExecutionOrigin | None:
        content = getattr(cell, "cell_content", None)
        cell_id = getattr(content, "id", None)
        if not cell_id:
            return None
        return ExecutionOrigin(runtime="snowbook", cell_id=str(cell_id))

#------------------------------------------------------
# find env
#------------------------------------------------------

def find_env():
    env = more_itertools.first_true(
        [
            CI(),
            Terminal(),
            Snowbook(),
            Jupyter(),
            Colab(),
            Hex(),
            File(),
        ],
        pred=lambda k: k.is_active(),
        default=File(),
    )
    env.activate()
    return env


def _reset_runtime_state_for_tests() -> None:
    global _snowbook_process_origin, _snowbook_origin_thread_id
    _clear_current_execution_origin()
    _cell_start_observers.clear()
    _snowbook_process_origin = None
    _snowbook_origin_thread_id = None
    Jupyter._hooks_installed = False
    Snowbook._hooks_installed = False

ENV = find_env()
