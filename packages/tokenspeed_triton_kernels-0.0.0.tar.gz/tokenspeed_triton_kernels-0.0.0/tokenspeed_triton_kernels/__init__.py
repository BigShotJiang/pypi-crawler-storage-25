"""Placeholder package for TokenSpeed Triton kernels."""

__version__ = "0.0.0"
