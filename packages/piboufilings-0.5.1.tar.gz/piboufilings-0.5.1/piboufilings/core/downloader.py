"""
Core functionality for downloading SEC filings.
"""

import contextlib
import os
import re
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from tqdm import tqdm
from urllib3.util.retry import Retry

from .._version import __version__ as _PACKAGE_VERSION
from ..config.settings import (
    BACKOFF_FACTOR,
    DATA_DIR,
    DEFAULT_HEADERS,
    MAX_RETRIES,
    RATE_LIMIT_LOG_THRESHOLD_SECONDS,
    REQUEST_DELAY,
    RETRY_STATUS_CODES,
    SAFETY_FACTOR,
    SEC_CONNECT_TIMEOUT,
    SEC_MAX_REQ_PER_SEC,
    SEC_READ_TIMEOUT,
)
from .logger import FilingLogger
from .rate_limiter import GlobalRateLimiter

SECTION16_ALIAS = "SECTION-6"
SECTION16_BASE_FORMS = ("3", "4", "5")


def resolve_io_paths(
    base_dir: Optional[Union[str, Path]],
    log_dir: Optional[Union[str, Path]],
    raw_data_dir: Optional[Union[str, Path]],
    default_base: Path = Path.cwd() / "data_parsed",
) -> Tuple[Path, Path, Path]:
    """Resolve and create base/log/raw paths once (no import-time side effects)."""
    base_dir_path = (
        Path(base_dir if base_dir is not None else os.getenv("PIBOUFILINGS_BASE_DIR", default_base))
        .expanduser()
        .resolve()
    )
    log_dir_path = (
        Path(log_dir if log_dir is not None else os.getenv("PIBOUFILINGS_LOG_DIR", Path.cwd() / "logs"))
        .expanduser()
        .resolve()
    )
    raw_dir_path = (
        Path(raw_data_dir if raw_data_dir is not None else os.getenv("PIBOUFILINGS_DATA_DIR", DATA_DIR))
        .expanduser()
        .resolve()
    )

    for p in (base_dir_path, log_dir_path, raw_dir_path):
        p.mkdir(parents=True, exist_ok=True)

    return base_dir_path, log_dir_path, raw_dir_path


def normalize_filters(
    form_types: Optional[Union[str, List[str]]], cik_values: Optional[Union[str, List[str]]]
) -> Tuple[Optional[List[str]], Optional[List[str]]]:
    """Normalize form and CIK filters (CIK padded to 10 digits)."""
    form_filters: Optional[List[str]]
    if form_types is None:
        form_filters = None
    elif isinstance(form_types, str):
        form_filters = [form_types]
    else:
        form_filters = [str(ft) for ft in form_types]

    cik_filters: Optional[List[str]]
    if cik_values is None:
        cik_filters = None
    elif isinstance(cik_values, str):
        cik_filters = [str(cik_values).zfill(10)]
    else:
        cik_filters = [str(c).zfill(10) for c in cik_values]

    return form_filters, cik_filters


def _make_skip_stub(
    cik: str, accession_number: str, form_type: str, raw_path: Optional[str]
) -> Dict[str, Any]:
    """Return a result dict shaped like ``_download_single_filing``'s output,
    used by the resume/recovery skip paths. ``raw_path`` is None when the
    raw file isn't on disk (Level A skip with ``keep_raw_files=False`` in a
    prior run)."""
    clean_accession = accession_number.replace("-", "")
    url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{clean_accession}/{accession_number}.txt"
    return {
        "cik": cik,
        "accession_number": accession_number,
        "form_type": form_type,
        "download_date": datetime.now().strftime("%Y-%m-%d"),
        "raw_path": raw_path,
        "url": url,
    }


class SECDownloader:
    """A class to handle downloading SEC EDGAR filings."""

    def __init__(
        self,
        user_name: str,
        user_agent_email: str,
        package_version: str = _PACKAGE_VERSION,
        log_dir: Union[str, Path] = "./logs",
        max_workers: int = 5,
        data_dir: Union[str, Path] = DATA_DIR,
    ):
        """
        Initialize the SEC downloader.

        Args:
            user_name: Name of the user or organization (required, non-empty)
            user_agent_email: Contact email address for SEC's fair access rules (required, non-empty)
            package_version: Version of the piboufilings package
            log_dir: Directory to store log files (defaults to './logs')
            max_workers: Maximum number of parallel download workers (defaults to 5)
            data_dir: Base directory for storing raw data (defaults to DATA_DIR)
        """
        if not user_name or not user_agent_email:
            raise ValueError("user_name and user_agent_email are required for SEC User-Agent compliance.")

        self.session = self._setup_session()

        # Create headers with the provided user_agent
        self.headers = DEFAULT_HEADERS.copy()
        self.headers["User-Agent"] = (
            f"piboufilings/{package_version} ({user_name}; contact: {user_agent_email})"
        )

        log_dir_path = Path(log_dir).expanduser().resolve()
        log_dir_path.mkdir(parents=True, exist_ok=True)
        self.logger = FilingLogger(log_dir=log_dir_path)
        self.last_request_time = time.time() - REQUEST_DELAY  # Initialize to allow immediate first request
        self.max_workers = max_workers
        self.data_dir = Path(data_dir).expanduser().resolve()

        self.raw_root = self.data_dir
        self.raw_root.mkdir(parents=True, exist_ok=True)
        self.cache_dir = self.data_dir / "cache"

        # Initialize the global rate limiter
        self.rate_limiter = GlobalRateLimiter(rate=SEC_MAX_REQ_PER_SEC, safety_factor=SAFETY_FACTOR)

    def download_filings(
        self,
        cik: str,
        form_type: str,
        start_year: int,
        end_year: Optional[int] = None,
        save_raw: bool = True,
        show_progress: bool = True,
        index_data_subset: Optional[pd.DataFrame] = None,
        known_accessions: Optional[set] = None,
        raw_index: Optional[Dict[str, str]] = None,
    ) -> pd.DataFrame:
        """
        Download all filings of a specific type for a company within a date range.

        Args:
            cik: Company CIK number (will be zero-padded to 10 digits)
            form_type: Type of form to download (e.g., '13F-HR')
            start_year: Starting year for the search
            end_year: Ending year (defaults to current year)
            save_raw: Whether to save raw filing data (defaults to True)
            show_progress: Whether to show progress bars (defaults to True)
            index_data_subset: Optional pre-filtered DataFrame of index entries for this specific CIK and form type.
                               If provided, skips fetching and filtering the main index.
            known_accessions: Optional set of accession numbers already
                persisted in the storage backend. When provided, matching
                accessions are synthesized as stub results (no HTTP call, no
                raw save) so downstream parsing can decide whether to skip.
            raw_index: Optional mapping from accession number to an existing
                raw-file path on disk. When an accession is present here but
                not in ``known_accessions``, we skip the HTTP download and
                re-parse from the on-disk copy (partial-recovery path).

        Returns:
            pd.DataFrame: DataFrame containing information about downloaded filings

        Notes:
            Download execution is always partitioned by independent time buckets to reduce
            worker contention:
            - 13F filings => quarter buckets (YYYY-Qn)
            - Section 16 filings => month buckets (YYYY-MM)
            - NPORT filings => month buckets (YYYY-MM)
        """
        known_accessions = known_accessions or set()
        raw_index = raw_index or {}
        try:
            # Normalize CIK
            cik = str(cik).zfill(10)
            form_type_str = str(form_type)
            is_section16_alias_request = form_type_str.upper() == SECTION16_ALIAS

            company_filings: pd.DataFrame

            if index_data_subset is not None and not index_data_subset.empty:
                # Use the provided subset directly
                company_filings = index_data_subset
                # Ensure the subset is indeed for the given CIK and form_type as a safeguard, though
                # the caller should ideally ensure this.
                # This filtering on the subset is a light check.
                company_filings = company_filings[company_filings["CIK"] == cik]
                if is_section16_alias_request:
                    company_filings = company_filings[
                        company_filings["Form Type"]
                        .astype(str)
                        .str.strip()
                        .str.startswith(SECTION16_BASE_FORMS, na=False)
                    ]
                else:
                    company_filings = company_filings[
                        company_filings["Form Type"].str.contains(form_type_str, na=False)
                    ]
                if company_filings.empty:
                    self.logger.log_operation(
                        cik=cik,
                        operation_type="SUBSET_VALIDATION_ERROR",
                        download_success=False,
                        download_error_message=f"Provided index_data_subset for {form_type} and {cik} resulted in no filings after re-check.",
                    )
                    return pd.DataFrame()

            else:
                # Fetch index data if subset is not provided or is empty
                index_data = self.get_sec_index_data(
                    start_year, end_year, form_filters=[form_type_str], cik_filters=[cik]
                )

                if index_data.empty:
                    self.logger.log_operation(
                        cik=cik,
                        operation_type="INDEX_FETCH_NO_RESULTS_FOR_DOWNLOAD",
                        download_success=False,
                        download_error_message=f"Failed to get index data for years {start_year}-{end_year} (when attempting to download for CIK {cik}, form {form_type})",
                    )
                    return pd.DataFrame()

                # Filter for the specific company and form type
                company_filings = index_data[index_data["CIK"] == cik]
                if is_section16_alias_request:
                    company_filings = company_filings[
                        company_filings["Form Type"]
                        .astype(str)
                        .str.strip()
                        .str.startswith(SECTION16_BASE_FORMS, na=False)
                    ]
                else:
                    company_filings = company_filings[
                        company_filings["Form Type"].str.contains(form_type_str, na=False)
                    ]

            if company_filings.empty:
                self.logger.log_operation(
                    cik=cik,
                    operation_type="NO_FILINGS_FOUND_FOR_CIK_FORM_IN_INDEX",
                    download_success=False,
                    download_error_message=f"No {form_type} filings found for {cik} (date range {start_year}-{end_year or 'current year'})",
                )
                return pd.DataFrame()

            # Partition filings into independent time buckets and process bucket-per-worker.
            bucketed_filings = self._partition_filings_by_period(
                filings=company_filings, form_type=form_type_str, cik=cik
            )

            if not bucketed_filings:
                self.logger.log_operation(
                    cik=cik,
                    operation_type="NO_FILINGS_WITH_VALID_PERIOD_BUCKET",
                    download_success=False,
                    download_error_message=(
                        f"No {form_type} filings for {cik} had a valid Date Filed value "
                        "for period partitioning"
                    ),
                )
                return pd.DataFrame()

            # Download filings in parallel (one worker per period bucket)
            downloaded_filings_info = []  # Renamed to avoid conflict

            # Create progress bars: one global + one per bucket/worker
            progress_lock = threading.Lock()
            global_pbar = None
            worker_pbars: Dict[str, tqdm] = {}
            if show_progress:
                total_partitioned_rows = sum(len(df_bucket) for _, df_bucket in bucketed_filings)
                global_pbar = tqdm(
                    total=total_partitioned_rows,
                    desc=f"Downloading filings for CIK {cik} (all buckets)",
                    position=0,
                    leave=True,
                )

                for idx, (bucket_key, bucket_df) in enumerate(bucketed_filings, start=1):
                    worker_pbars[bucket_key] = tqdm(
                        total=len(bucket_df), desc=f"Bucket {bucket_key}", position=idx, leave=True
                    )

            def update_progress(bucket_key: str) -> None:
                """Safely update per-worker and global progress bars from worker threads."""
                if not show_progress:
                    return
                with progress_lock:
                    bucket_bar = worker_pbars.get(bucket_key)
                    if bucket_bar is not None:
                        bucket_bar.update(1)
                    if global_pbar is not None:
                        global_pbar.update(1)

            def download_bucket_wrapper(bucket_key: str, filings_in_bucket: pd.DataFrame):
                """Download one period bucket sequentially inside a worker."""
                self.logger.log_operation(
                    cik=cik,
                    operation_type="DOWNLOAD_BUCKET_START",
                    download_success=True,
                    custom_identifier=bucket_key,
                    download_error_message=(
                        f"Starting bucket {bucket_key} with {len(filings_in_bucket)} filings"
                    ),
                )

                bucket_results: List[Dict[str, Any]] = []
                for _, filing in filings_in_bucket.iterrows():
                    try:
                        accession_match = re.search(r"edgar/data/\d+/([0-9\-]+)\.txt", filing["Filename"])
                        if not accession_match:
                            self.logger.log_operation(
                                cik=cik,
                                operation_type="FILENAME_PARSE_ERROR_IN_BUCKET_WORKER",
                                download_success=False,
                                custom_identifier=bucket_key,
                                download_error_message=f"Invalid filename format: {filing['Filename']}",
                            )
                            continue

                        accession_number = accession_match.group(1)
                        detected_form_type = form_type
                        if "Form Type" in filing and pd.notna(filing["Form Type"]):
                            detected_form_type = str(filing["Form Type"]).strip() or form_type

                        # Level A: accession already in the storage backend →
                        # skip download AND parse. Synthesize a stub result so
                        # downstream code can short-circuit on the accession.
                        if accession_number in known_accessions:
                            self.logger.log_operation(
                                cik=cik,
                                accession_number=accession_number,
                                operation_type="DOWNLOAD_SKIPPED_KNOWN",
                                download_success=True,
                                level="INFO",
                                custom_identifier=bucket_key,
                                download_error_message="Already in storage backend (resume).",
                            )
                            bucket_results.append(
                                _make_skip_stub(
                                    cik=cik,
                                    accession_number=accession_number,
                                    form_type=detected_form_type,
                                    raw_path=raw_index.get(accession_number),
                                )
                            )
                            continue

                        # Level B: raw file already on disk but storage backend
                        # missing a row → re-parse from disk, skip the HTTP GET.
                        existing_path = raw_index.get(accession_number)
                        if existing_path:
                            self.logger.log_operation(
                                cik=cik,
                                accession_number=accession_number,
                                operation_type="DOWNLOAD_SKIPPED_RAW_EXISTS",
                                download_success=True,
                                level="INFO",
                                custom_identifier=bucket_key,
                                download_error_message=(
                                    f"Raw file present on disk; skipping HTTP GET. Path={existing_path}"
                                ),
                            )
                            bucket_results.append(
                                _make_skip_stub(
                                    cik=cik,
                                    accession_number=accession_number,
                                    form_type=detected_form_type,
                                    raw_path=existing_path,
                                )
                            )
                            continue

                        filing_info = self._download_single_filing(
                            cik=cik,
                            accession_number=accession_number,
                            form_type=detected_form_type,
                            save_raw=save_raw,
                        )
                        if filing_info:
                            bucket_results.append(filing_info)
                    except Exception as e:
                        self.logger.log_operation(
                            cik=cik,
                            operation_type="DOWNLOAD_BUCKET_WORKER_ERROR",
                            download_success=False,
                            custom_identifier=bucket_key,
                            download_error_message=f"Error downloading filing in bucket {bucket_key}: {str(e)}",
                        )
                    finally:
                        update_progress(bucket_key)

                self.logger.log_operation(
                    cik=cik,
                    operation_type="DOWNLOAD_BUCKET_END",
                    download_success=True,
                    custom_identifier=bucket_key,
                    download_error_message=(
                        f"Finished bucket {bucket_key}. Successful downloads: {len(bucket_results)}"
                    ),
                )
                return bucket_key, bucket_results, len(filings_in_bucket)

            # Use ThreadPoolExecutor to download buckets in parallel
            try:
                with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    future_to_bucket = {
                        executor.submit(download_bucket_wrapper, bucket_key, bucket_df): (
                            bucket_key,
                            bucket_df,
                        )
                        for bucket_key, bucket_df in bucketed_filings
                    }

                    for future in as_completed(future_to_bucket):
                        _, bucket_results, _ = future.result()
                        downloaded_filings_info.extend(bucket_results)
            finally:
                if show_progress:
                    with progress_lock:
                        for bucket_bar in worker_pbars.values():
                            bucket_bar.close()
                        if global_pbar is not None:
                            global_pbar.close()

            self.logger.log_operation(
                cik=cik,
                operation_type="DOWNLOAD_FILINGS_BATCH_PROCESSED",
                download_success=True,
                download_error_message=f"Successfully processed {len(downloaded_filings_info)} filings for download",
                error_code=200,
            )
            return pd.DataFrame(downloaded_filings_info)  # Use the collected list

        except Exception as e:
            self.logger.log_operation(
                cik=cik,
                operation_type="DOWNLOAD_FILINGS_UNHANDLED_EXCEPTION",
                download_success=False,
                download_error_message=f"Error downloading filings: {str(e)}",
            )
            return pd.DataFrame()

    def _partition_filings_by_period(
        self, filings: pd.DataFrame, form_type: str, cik: str
    ) -> List[Tuple[str, pd.DataFrame]]:
        """Partition filings by form frequency (13F=quarter, NPORT/Section16=month)."""
        if filings is None or filings.empty:
            return []

        granularity = self._period_partition_granularity(form_type)
        bucket_rows: Dict[str, List[pd.Series]] = defaultdict(list)

        for _, filing in filings.iterrows():
            date_raw = filing.get("Date Filed")
            filed_at = pd.to_datetime(date_raw, errors="coerce")
            if pd.isna(filed_at):
                self.logger.log_operation(
                    cik=cik,
                    operation_type="PARTITION_SKIP_INVALID_DATE_FILED",
                    download_success=False,
                    form_type_processed=form_type,
                    accession_number=filing.get("accession_number"),
                    download_error_message=f"Could not parse Date Filed value '{date_raw}'",
                )
                continue

            if granularity == "month":
                bucket_key = f"{filed_at.year}-{filed_at.month:02d}"
            else:
                quarter = ((filed_at.month - 1) // 3) + 1
                bucket_key = f"{filed_at.year}-Q{quarter}"

            bucket_rows[bucket_key].append(filing)

        if not bucket_rows:
            return []

        sorted_bucket_keys = sorted(bucket_rows.keys())
        return [
            (bucket_key, pd.DataFrame(bucket_rows[bucket_key]).reset_index(drop=True))
            for bucket_key in sorted_bucket_keys
        ]

    def _period_partition_granularity(self, form_type: str) -> str:
        """Return period granularity for mandatory auto-partitioning."""
        normalized = (form_type or "").upper().strip()
        if "NPORT" in normalized:
            return "month"
        if normalized == SECTION16_ALIAS or normalized.startswith(SECTION16_BASE_FORMS):
            return "month"
        if "13F" in normalized:
            return "quarter"
        # Keep unknown forms isolated by quarter by default.
        return "quarter"

    def _respect_rate_limit(self) -> float:
        """Ensure requests comply with SEC rate limits using the global rate limiter."""
        # Use the global rate limiter to control request rate
        start = time.perf_counter()
        self.rate_limiter.acquire(block=True)
        return time.perf_counter() - start

    def _get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: Union[int, float, Tuple[float, float]] = (SEC_CONNECT_TIMEOUT, SEC_READ_TIMEOUT),
    ) -> requests.Response:
        """Unified GET with rate limit and timeout."""
        rate_wait_seconds = self._respect_rate_limit() or 0.0
        if rate_wait_seconds >= RATE_LIMIT_LOG_THRESHOLD_SECONDS:
            self.logger.log_operation(
                operation_type="RATE_LIMIT_WAIT",
                download_success=True,
                level="INFO",
                download_error_message=(
                    f"Waited {rate_wait_seconds:.2f}s for SEC rate-limit token before GET {url}"
                ),
            )
        return self.session.get(url, headers=headers or self.headers, timeout=timeout)

    def _download_single_filing(
        self, cik: str, accession_number: str, form_type: str, save_raw: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Download a single filing and save it if requested.

        Args:
            cik: Company CIK number
            accession_number: Filing accession number
            form_type: Type of form
            save_raw: Whether to save the raw filing

        Returns:
            Optional[Dict[str, Any]]: Information about the downloaded filing
        """
        try:
            # Construct the URL
            # The accession number might contain hyphens, which need to be removed for the URL
            clean_accession = accession_number.replace("-", "")
            url = (
                f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{clean_accession}/{accession_number}.txt"
            )

            request_started_at = time.perf_counter()
            self.logger.log_operation(
                cik=cik,
                accession_number=accession_number,
                operation_type="DOWNLOAD_SINGLE_FILING_REQUEST_START",
                download_success=True,
                level="INFO",
                download_error_message=f"Starting GET {url}",
            )

            response = self._get(url)
            request_elapsed_seconds = time.perf_counter() - request_started_at
            self.logger.log_operation(
                cik=cik,
                accession_number=accession_number,
                operation_type="DOWNLOAD_SINGLE_FILING_REQUEST_END",
                download_success=response.status_code == 200,
                level="INFO" if response.status_code == 200 else "ERROR",
                download_error_message=(
                    f"Finished GET in {request_elapsed_seconds:.2f}s with HTTP {response.status_code}: {url}"
                ),
                error_code=response.status_code,
            )
            # Log the request details regardless of success/failure
            # self.logger.log_operation( ... ) # Consider adding a generic request log here if needed

            if response.status_code != 200:
                self.logger.log_operation(
                    cik=cik,
                    accession_number=accession_number,
                    operation_type="DOWNLOAD_SINGLE_FILING_HTTP_ERROR",
                    download_success=False,
                    download_error_message=f"HTTP error {response.status_code} for {url}",
                    error_code=response.status_code,
                )
                return None

            # Save raw filing if requested
            raw_path = None
            if save_raw:
                try:
                    form_13f_file_number_for_save = None
                    if "13F" in form_type:  # Check if it's a 13F type filing
                        match = re.search(r"form13FFileNumber>([^<]+)</", response.text)
                        if match:
                            form_13f_file_number_for_save = match.group(1).strip()
                        else:
                            form_13f_file_number_for_save = "unknown_13F_file_number"  # Placeholder

                    raw_path = self._save_raw_filing(
                        cik=cik,
                        form_type=form_type,
                        accession_number=accession_number,
                        content=response.text,
                        form_13f_file_number_for_path=form_13f_file_number_for_save,
                    )
                except OSError as e:
                    self.logger.log_operation(
                        cik=cik,
                        accession_number=accession_number,
                        operation_type="SAVE_RAW_FILING_IO_ERROR",
                        download_success=True,
                        parse_success=False,
                        download_error_message=f"Failed to save raw filing: {str(e)}",
                    )

            self.logger.log_operation(
                cik=cik,
                accession_number=accession_number,
                operation_type="DOWNLOAD_SINGLE_FILING_SUCCESS",
                download_success=True,
            )

            return {
                "cik": cik,
                "accession_number": accession_number,
                "form_type": form_type,
                "download_date": datetime.now().strftime("%Y-%m-%d"),
                "raw_path": raw_path,
                "url": url,
            }
        except requests.RequestException as e:
            request_elapsed_seconds = None
            if "request_started_at" in locals():
                request_elapsed_seconds = time.perf_counter() - request_started_at
            status_code = None
            if hasattr(e, "response") and e.response is not None:
                status_code = e.response.status_code
            elapsed_msg = (
                f" after {request_elapsed_seconds:.2f}s" if request_elapsed_seconds is not None else ""
            )
            self.logger.log_operation(
                cik=cik,
                accession_number=accession_number,
                operation_type="DOWNLOAD_SINGLE_FILING_REQUEST_EXCEPTION",
                download_success=False,
                download_error_message=f"Request error{elapsed_msg}: {type(e).__name__}: {str(e)}; url={url}",
                error_code=status_code,  # Log status_code if available from exception
            )
            return None
        except Exception as e:
            self.logger.log_operation(
                cik=cik,
                accession_number=accession_number,
                operation_type="DOWNLOAD_SINGLE_FILING_UNEXPECTED_ERROR",
                download_success=False,
                download_error_message=f"Unexpected error: {str(e)}",
            )
            return None

    def _save_raw_filing(
        self,
        cik: str,
        form_type: str,
        accession_number: str,
        content: str,
        form_13f_file_number_for_path: Optional[str] = None,
    ) -> Optional[str]:
        """
        Save a raw filing to disk.

        Args:
            cik: Company CIK number
            form_type: Type of form
            accession_number: Filing accession number
            content: Raw filing content
            form_13f_file_number_for_path: Optional form 13F file number for directory and filename

        Returns:
            Path to the saved file, or ``None`` when the filing is an exhibit
            (exhibits are intentionally not persisted).

        Raises:
            IOError: If there is an error creating directories or writing the file.
        """
        raw_root = self.raw_root

        # Determine primary directory based on form type
        primary_identifier_dir: str
        if (
            "13F" in form_type
            and form_13f_file_number_for_path
            and form_13f_file_number_for_path != "unknown_13F_file_number"
        ):
            # Sanitize form_13f_file_number_for_path for use as a directory name
            sane_form_13f_fn = form_13f_file_number_for_path.replace("-", "_").replace("/", "_")
            primary_identifier_dir = os.path.join(raw_root, sane_form_13f_fn)
        else:
            primary_identifier_dir = os.path.join(raw_root, cik)

        # Check if this is an exhibit filing
        is_exhibit = "EX" in form_type
        if is_exhibit:
            # Exhibits are intentionally not persisted; callers must handle None.
            return None
        # Check if this is an amendment filing
        is_amendment = form_type.endswith("/A") or "/A" in form_type

        # Handle the form type path correctly
        base_form_type = form_type.split("/A")[0] if is_amendment else form_type
        # The form_dir is now relative to the primary_identifier_dir
        form_dir = os.path.join(primary_identifier_dir, base_form_type)
        os.makedirs(form_dir, exist_ok=True)

        # If it's an amendment, create an A subfolder
        if is_amendment:
            a_dir = os.path.join(form_dir, "A")
            os.makedirs(a_dir, exist_ok=True)
            output_dir = a_dir
        else:
            output_dir = form_dir

        # Create an accession-specific directory for SEC file number storage to avoid overwrites
        accession_specific_dir = output_dir
        if (
            "13F" in form_type
            and form_13f_file_number_for_path
            and form_13f_file_number_for_path != "unknown_13F_file_number"
        ):
            safe_accession_dir = accession_number.replace("/", "_")
            accession_specific_dir = os.path.join(output_dir, safe_accession_dir)
            os.makedirs(accession_specific_dir, exist_ok=True)

        # Determine filename based on form type
        filename: str
        if (
            "13F" in form_type
            and form_13f_file_number_for_path
            and form_13f_file_number_for_path != "unknown_13F_file_number"
        ):
            # Sanitize form_13f_file_number_for_path for use as a filename
            sane_form_13f_fn_for_file = form_13f_file_number_for_path.replace("/", "_")
            filename = f"{sane_form_13f_fn_for_file}_{accession_number}.txt"
        else:
            # Sanitize form_type for filename
            sane_form_type = form_type.replace("/", "_")
            filename = f"{cik}_{sane_form_type}_{accession_number}.txt"

        output_path = os.path.join(accession_specific_dir, filename)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)

        return output_path

    def get_sec_index_data(
        self,
        start_year: int = 1999,
        end_year: Optional[int] = None,
        form_filters: Optional[List[str]] = None,
        cik_filters: Optional[List[str]] = None,
        show_progress: bool = False,
    ) -> pd.DataFrame:
        """
        Get SEC EDGAR index data for the specified year range.

        Args:
            start_year: Starting year for the index data
            end_year: Ending year for the index data (defaults to current year)

        Returns:
            pd.DataFrame: DataFrame containing the index data
        """
        try:
            if end_year is None:
                end_year = datetime.today().year

            form_filters, cik_filters = normalize_filters(form_filters, cik_filters)

            current_year = datetime.today().year
            current_quarter = (datetime.today().month - 1) // 3 + 1
            quarters_to_fetch = [
                (year, quarter)
                for year in range(start_year, end_year + 1)
                for quarter in range(1, 5)
                if not (year > current_year or (year == current_year and quarter > current_quarter))
            ]

            all_reports = []
            quarter_iter = (
                tqdm(
                    quarters_to_fetch,
                    desc=f"Fetching SEC index {start_year}-{end_year}",
                    unit="qtr",
                )
                if show_progress and end_year > start_year
                else quarters_to_fetch
            )
            for year, quarter in quarter_iter:
                df = self._parse_form_idx(year, quarter, form_filters=form_filters, cik_filters=cik_filters)
                if not df.empty:
                    all_reports.append(df)

            if not all_reports:
                self.logger.log_operation(
                    operation_type="INDEX_FETCH_NO_REPORTS_FOUND",
                    download_success=False,
                    download_error_message=f"No index data found for years {start_year}-{end_year}",
                )
                return pd.DataFrame(
                    columns=["CIK", "Name", "Date Filed", "Form Type", "accession_number", "Filename"]
                )

            df_all = pd.concat(all_reports).reset_index(drop=True)

            # Extract CIK and accession number from Filename
            df_all[["CIK_extracted", "accession_number"]] = df_all["Filename"].str.extract(
                r"edgar/data/(\d+)/([0-9\-]+)\.txt"
            )

            # Zero-pad CIK to 10 digits
            df_all["CIK"] = df_all["CIK_extracted"].str.zfill(10)

            self.logger.log_operation(
                operation_type="INDEX_FETCH_SUCCESS",
                download_success=True,
                download_error_message=f"Retrieved index data with {len(df_all)} entries",
            )

            return df_all[["CIK", "Name", "Date Filed", "Form Type", "accession_number", "Filename"]]
        except Exception as e:
            self.logger.log_operation(
                operation_type="INDEX_FETCH_UNHANDLED_EXCEPTION",
                download_success=False,
                download_error_message=f"Error retrieving index data: {str(e)}",
            )
            return pd.DataFrame(
                columns=["CIK", "Name", "Date Filed", "Form Type", "accession_number", "Filename"]
            )

    def _parse_form_idx(
        self,
        year: int,
        quarter: int,
        form_filters: Optional[List[str]] = None,
        cik_filters: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """
        Parse a specific quarter's form index file.

        Args:
            year: Year to retrieve index for
            quarter: Quarter (1-4) to retrieve index for

        Returns:
            pd.DataFrame: DataFrame containing the parsed index data
        """
        try:
            url = f"https://www.sec.gov/Archives/edgar/full-index/{year}/QTR{quarter}/form.idx"
            cache_path = self.cache_dir / f"form_{year}_Q{quarter}.idx"
            text_data = None

            if cache_path.exists():
                try:
                    text_data = cache_path.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    text_data = None

            if text_data is None:
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                response = self._get(url)

                if response.status_code != 200:
                    self.logger.log_operation(
                        operation_type="INDEX_FETCH_PARTIAL_HTTP_ERROR",
                        download_success=False,
                        download_error_message=f"Failed to retrieve index for {year} Q{quarter}: HTTP {response.status_code}",
                        error_code=response.status_code,
                    )
                    return pd.DataFrame()
                text_data = response.text
                with contextlib.suppress(OSError):
                    # Cache failures are non-fatal.
                    cache_path.write_text(text_data, encoding="utf-8")

            lines = text_data.splitlines()
            try:
                start_idx = next(i for i, line in enumerate(lines) if set(line.strip()) == {"-"})
            except StopIteration:
                self.logger.log_operation(
                    operation_type="INDEX_PARSE_UNEXPECTED_FORMAT_ERROR",
                    download_success=False,
                    download_error_message=f"Unexpected format in index file for {year} Q{quarter}",
                )
                return pd.DataFrame()

            entries = []
            for line in lines[start_idx + 1 :]:
                try:
                    if len(line) < 98:  # Ensure minimum line length
                        continue

                    form_type_val = line[0:12].strip()
                    cik_val_raw = line[74:86].strip()
                    cik_val_padded = cik_val_raw.zfill(10)

                    # Form filter handling (Section16 alias uses prefix match)
                    if form_filters:
                        matches_form = False
                        for f in form_filters:
                            if f is None:
                                continue
                            f_upper = str(f).upper()
                            if f_upper == SECTION16_ALIAS:
                                if form_type_val.startswith(SECTION16_BASE_FORMS):
                                    matches_form = True
                                    break
                            elif f_upper in form_type_val.upper():
                                matches_form = True
                                break
                        if not matches_form:
                            continue

                    if cik_filters and cik_val_padded not in cik_filters:
                        continue

                    entry = {
                        "Form Type": form_type_val,
                        "Name": line[12:74].strip(),
                        "CIK": cik_val_padded,
                        "Date Filed": line[86:98].strip(),
                        "Filename": line[98:].strip(),
                    }
                    entries.append(entry)
                except Exception:
                    # Skip individual entries that can't be parsed
                    continue

            if not entries:
                self.logger.log_operation(
                    operation_type="INDEX_PARSE_NO_VALID_ENTRIES_FOUND",
                    download_success=False,
                    download_error_message=f"No valid entries found in index for {year} Q{quarter}",
                )
                return pd.DataFrame()

            self.logger.log_operation(
                operation_type="INDEX_PARSE_SUCCESS",
                download_success=True,
                download_error_message=f"Successfully parsed {len(entries)} entries from {year} Q{quarter}",
            )
            return pd.DataFrame(entries)
        except Exception as e:
            self.logger.log_operation(
                operation_type="INDEX_PARSE_UNHANDLED_EXCEPTION",
                download_success=False,
                download_error_message=f"Error parsing index for {year} Q{quarter}: {str(e)}",
            )
            return pd.DataFrame()

    def _setup_session(self) -> requests.Session:
        """Set up a requests session with retry logic."""
        session = requests.Session()
        retry_strategy = Retry(
            total=MAX_RETRIES,
            connect=MAX_RETRIES,  # Retry on connection errors
            read=MAX_RETRIES,  # Retry on read errors (like IncompleteRead)
            backoff_factor=BACKOFF_FACTOR,
            status_forcelist=RETRY_STATUS_CODES,
            respect_retry_after_header=True,
            allowed_methods={"GET"},
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        return session
