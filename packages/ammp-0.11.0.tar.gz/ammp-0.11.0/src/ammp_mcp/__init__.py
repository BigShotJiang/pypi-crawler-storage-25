"""AMMP MCP — reference implementation of the Agentic Mentor-Mentee Protocol (Mentoring track)."""

__version__ = "0.11.0"
__ammp_draft__ = "draft-ammp-01"

__all__ = ["__ammp_draft__", "__version__"]
