def hello():
    print("Hello from akkritin package!")