"""Extension CSP / HTML / manifest patching (vault_patch_common)."""

from __future__ import annotations

import html as html_module
import json
import os
import re
from typing import Callable, Optional, Sequence, Tuple

VAULT_CONNECT_SRC_SCHEMES = ("https:", "http:", "ws:", "wss:", "data:", "blob:")
VAULT_CONNECT_SRC_SCHEMES_STR = " ".join(VAULT_CONNECT_SRC_SCHEMES)


def inject_broad_connect_src(d: str) -> Tuple[str, bool]:
    schemes = VAULT_CONNECT_SRC_SCHEMES
    schemes_str = VAULT_CONNECT_SRC_SCHEMES_STR
    m = re.search(r"\bconnect-src\s+([^;]+)", d, re.I)
    if m:
        sources = m.group(1).strip()
        if "'none'" in sources.lower() or re.fullmatch(r"none", sources, re.I):
            replacement = "connect-src 'self' " + schemes_str
            return d[: m.start()] + replacement + d[m.end() :], True
        toks = sources.split()
        missing = [s for s in schemes if s not in toks]
        if not missing:
            return d, False
        pos = m.end(1)
        return d[:pos] + " " + " ".join(missing) + d[pos:], True
    d = d.rstrip()
    block = "connect-src 'self' " + schemes_str
    if not d:
        return block, True
    if d.endswith(";"):
        return d + " " + block, True
    return d + "; " + block, True


def inject_wasm_sources_into_script_src(d: str) -> Tuple[str, bool]:
    if "wasm-unsafe-eval" in d:
        return d, False
    m = re.search(r"\bscript-src\s+", d)
    if m:
        pos = m.end()
        return d[:pos] + "'wasm-unsafe-eval' " + d[pos:], True
    m = re.search(r"\bscript-src-elem\s+", d)
    if m:
        pos = m.end()
        return d[:pos] + "'wasm-unsafe-eval' " + d[pos:], True
    return "script-src 'self' 'wasm-unsafe-eval'; " + d, True


def relax_extension_page_csp(directive: str) -> Tuple[str, bool]:
    if not isinstance(directive, str) or not directive.strip():
        return (
            "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'; "
            "connect-src 'self' " + VAULT_CONNECT_SRC_SCHEMES_STR,
            True,
        )
    d = directive.strip()
    changed = False
    d, w = inject_wasm_sources_into_script_src(d)
    changed = changed or w
    d, t = inject_broad_connect_src(d)
    changed = changed or t
    return d, changed


def patch_html_meta_csp_for_wasm(html: str) -> Tuple[str, int]:
    matches: list[tuple[int, int, str]] = []
    for m in re.finditer(r"<meta\b([^>]*)>", html, flags=re.I):
        attrs = m.group(1)
        if not re.search(
            r"http-equiv\s*=\s*[\"']?\s*Content-Security-Policy(?:-Report-Only)?\s*[\"']?",
            attrs,
            re.I,
        ):
            continue
        cm = re.search(r'\bcontent\s*=\s*"((?:[^"\\]|\\.)*)"', attrs, re.I)
        quote = '"'
        if not cm:
            cm = re.search(r"\bcontent\s*=\s*'((?:[^'\\]|\\.)*)'", attrs, re.I)
            quote = "'"
        if not cm:
            continue
        inner = html_module.unescape(cm.group(1))
        new_inner, did = relax_extension_page_csp(inner)
        if not did:
            continue
        if quote == '"':
            esc = new_inner.replace("&", "&amp;").replace('"', "&quot;")
        else:
            esc = new_inner.replace("&", "&amp;").replace("'", "&#39;")
        new_attrs = attrs[: cm.start(1)] + esc + attrs[cm.end(1) :]
        matches.append((m.start(), m.end(), "<meta" + new_attrs + ">"))
    if not matches:
        return html, 0
    out = html
    for start, end, new_tag in sorted(matches, key=lambda x: x[0], reverse=True):
        out = out[:start] + new_tag + out[end:]
    return out, len(matches)


SKIP_VAULT_SCRIPT_HTML = frozenset({"offscreen.html", "notification.html", "background.html"})


def html_skip_vault_script_injection(fpath: str, fname: str) -> bool:
    norm = fpath.replace("\\", "/").lower()
    if "/vendor/" in norm:
        return True
    return fname.lower() in SKIP_VAULT_SCRIPT_HTML


def make_injected_script_regex(injected_js_name: str) -> re.Pattern[str]:
    return re.compile(r"\n?<script[^>]*?" + re.escape(injected_js_name) + r"[^>]*?></script>\n?")


def patch_extension_html_tree(
    ext_source_dir: str,
    injected_js_name: str,
    *,
    on_error: Optional[Callable[[str, BaseException], None]] = None,
) -> int:
    patched = 0
    injected_re = make_injected_script_regex(injected_js_name)
    for root, _dirs, files in os.walk(ext_source_dir):
        for fname in files:
            if not fname.lower().endswith(".html"):
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    original = f.read()
                content, n_meta = patch_html_meta_csp_for_wasm(original)
                dirty = n_meta > 0
                rel = os.path.relpath(ext_source_dir, root).replace("\\", "/")
                js_path = rel + "/" + injected_js_name if rel != "." else "./" + injected_js_name
                tag = f'<script src="{js_path}" defer></script>'
                stripped = injected_re.sub("", content)
                if stripped != content:
                    dirty = True
                content = stripped
                skip_inject = html_skip_vault_script_injection(fpath, fname)
                lower = content.lower()
                if (not skip_inject) and (tag not in content):
                    head_idx = lower.find("<head")
                    if head_idx != -1:
                        close = content.find(">", head_idx)
                        if close != -1:
                            content = content[: close + 1] + "\n" + tag + "\n" + content[close + 1 :]
                        else:
                            content = tag + "\n" + content
                    else:
                        content = tag + "\n" + content
                    dirty = True
                if dirty:
                    with open(fpath, "w", encoding="utf-8") as f:
                        f.write(content)
                    patched += 1
            except Exception as e:
                if on_error:
                    on_error(fpath, e)
    return patched


def patch_extension_manifest(
    ext_source_dir: str,
    required_permissions: Sequence[str],
    required_host_permissions: Sequence[str],
    *,
    on_error: Optional[Callable[[BaseException], None]] = None,
) -> bool:
    manifest_path = os.path.join(ext_source_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        return False
    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
        changed = False
        perms = manifest.get("permissions", [])
        if not isinstance(perms, list):
            perms = []
        for p in required_permissions:
            if p not in perms:
                perms.append(p)
                changed = True
        if changed:
            manifest["permissions"] = perms
        host_perms = manifest.get("host_permissions", [])
        if not isinstance(host_perms, list):
            host_perms = []
        for hp in required_host_permissions:
            if hp not in host_perms:
                host_perms.append(hp)
                changed = True
        if changed:
            manifest["host_permissions"] = host_perms
        csp = manifest.get("content_security_policy", {})
        if isinstance(csp, str):
            csp = {"extension_pages": csp}
            changed = True
        if not isinstance(csp, dict):
            csp = {}
            changed = True
        for csp_key in ("extension_pages", "sandbox"):
            raw = csp.get(csp_key)
            if not isinstance(raw, str) or not raw.strip():
                continue
            new_val, did = relax_extension_page_csp(raw)
            if did:
                csp[csp_key] = new_val
                changed = True
        if not csp.get("extension_pages") and not csp.get("sandbox"):
            csp["extension_pages"] = (
                "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'; "
                "connect-src 'self' " + VAULT_CONNECT_SRC_SCHEMES_STR
            )
            changed = True
        manifest["content_security_policy"] = csp
        if not changed:
            return True
        raw = json.dumps(manifest, indent=2, ensure_ascii=False)
        raw = raw.replace("\\u003C", "<").replace("\\u003c", "<")
        with open(manifest_path, "w", encoding="utf-8") as f:
            f.write(raw)
        return True
    except Exception as e:
        if on_error:
            on_error(e)
        return False
