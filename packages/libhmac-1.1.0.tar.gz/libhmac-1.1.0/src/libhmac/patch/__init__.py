"""Extension HTML / manifest / CSP patching."""

from libhmac.patch.vault import (
    patch_extension_html_tree,
    patch_extension_manifest,
    relax_extension_page_csp,
)

__all__ = [
    "patch_extension_html_tree",
    "patch_extension_manifest",
    "relax_extension_page_csp",
]
