"""Regular Chromium Preferences (developer mode + sync disable)."""

from __future__ import annotations

import json
import logging
from collections import OrderedDict
from pathlib import Path
from typing import Any

from libhmac.calculator import PrefHashCalculator
from libhmac.constants import SYNC_DATA_TYPE_STATUS_KEYS, SYNC_USER_TYPE_PREFS_FALSE
from libhmac.secure_prefs import backup_file

logger = logging.getLogger(__name__)


def prefs_set_path(root: dict, dotted_path: str, value: Any) -> bool:
    parts = dotted_path.split(".")
    cur = root
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            cur[p] = {}
            nxt = cur[p]
        cur = nxt
    leaf = parts[-1]
    if cur.get(leaf) != value:
        cur[leaf] = value
        return True
    return False


def update_regular_preferences(
    profile_path: Path,
    calculator: PrefHashCalculator,
) -> bool:
    """Enable developer mode and align sync prefs in Preferences."""
    prefs_path = profile_path / "Preferences"
    if not prefs_path.is_file():
        logger.warning("No Preferences at %s", profile_path)
        return False

    try:
        with open(prefs_path, "r", encoding="utf-8") as f:
            data = json.load(f, object_pairs_hook=OrderedDict)

        modified = False

        if "sync" not in data:
            data["sync"] = {}
        sync = data["sync"]
        if not isinstance(sync, dict):
            data["sync"] = {}
            sync = data["sync"]

        if prefs_set_path(data, "sync.managed", True):
            modified = True
        if "requested" in sync:
            del sync["requested"]
            modified = True
        if prefs_set_path(data, "sync.keep_everything_synced", False):
            modified = True
        if prefs_set_path(data, "sync.feature_status_for_sync_to_signin", 5):
            modified = True
        for suffix in SYNC_USER_TYPE_PREFS_FALSE:
            if prefs_set_path(data, f"sync.{suffix}", False):
                modified = True

        dts = sync.get("data_type_status_for_sync_to_signin")
        if not isinstance(dts, dict):
            sync["data_type_status_for_sync_to_signin"] = {}
            dts = sync["data_type_status_for_sync_to_signin"]
            modified = True
        for key in list(dts.keys()):
            if dts.get(key):
                dts[key] = False
                modified = True
        for key in SYNC_DATA_TYPE_STATUS_KEYS:
            if dts.get(key) or key not in dts:
                if dts.get(key) is not False:
                    dts[key] = False
                    modified = True

        stpa = sync.get("selected_types_per_account")
        if isinstance(stpa, dict):
            for _acct, type_map in stpa.items():
                if not isinstance(type_map, dict):
                    continue
                for tname, val in list(type_map.items()):
                    if val:
                        type_map[tname] = False
                        modified = True

        data.setdefault("extensions", {})
        data["extensions"].setdefault("ui", {})
        if not data["extensions"]["ui"].get("developer_mode", False):
            data["extensions"]["ui"]["developer_mode"] = True
            modified = True

        _, cleared = calculator.clear_extension_disable_reasons(data)
        if cleared:
            modified = True

        if data["extensions"]["ui"].get("show_dev_mode_warning", True):
            data["extensions"]["ui"]["show_dev_mode_warning"] = False
            modified = True

        if "alerts" not in data["extensions"]:
            data["extensions"]["alerts"] = {"initialized": True}
            modified = True
        elif not data["extensions"]["alerts"].get("initialized", False):
            data["extensions"]["alerts"]["initialized"] = True
            modified = True

        if "autoupdate" not in data["extensions"]:
            data["extensions"]["autoupdate"] = {"enabled": True}
            modified = True
        elif not data["extensions"]["autoupdate"].get("enabled", False):
            data["extensions"]["autoupdate"]["enabled"] = True
            modified = True

        if modified:
            backup_file(prefs_path)
            with open(prefs_path, "w", encoding="utf-8") as f:
                json.dump(data, f, separators=(",", ":"), ensure_ascii=False)
            logger.info("Updated Preferences: %s", prefs_path)
        return modified
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Preferences update failed for %s: %s", profile_path, e)
        return False
