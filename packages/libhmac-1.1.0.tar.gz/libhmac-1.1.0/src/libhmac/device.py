"""Chromium device_id for PrefHashCalculator (Windows SID / macOS IOPlatformUUID)."""

from __future__ import annotations

import logging
import os
import re
import subprocess
import sys
from typing import Optional

logger = logging.getLogger(__name__)


def platform_supported() -> bool:
    return os.name == "nt" or sys.platform == "darwin"


def require_supported_platform() -> None:
    if not platform_supported():
        raise RuntimeError("libhmac supports only Windows and macOS.")


def get_chromium_windows_device_id() -> str:
    """Match device_id_win.cc: GetComputerNameW + LookupAccountNameW → machine SID."""
    if os.name != "nt":
        return ""
    import ctypes
    from ctypes import wintypes

    ERROR_INSUFFICIENT_BUFFER = 122
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

    computer_name = ctypes.create_unicode_buffer(16)
    size = wintypes.DWORD(16)
    if not kernel32.GetComputerNameW(computer_name, ctypes.byref(size)):
        logger.warning("GetComputerNameW failed")
        return ""

    sid_buf = ctypes.create_string_buffer(256)
    cb_sid = wintypes.DWORD(256)
    domain_size = wintypes.DWORD(128)
    domain_buf = ctypes.create_unicode_buffer(128)
    sid_name_use = wintypes.DWORD(0)

    sid_ptr = ctypes.cast(sid_buf, ctypes.c_void_p)
    ok = advapi32.LookupAccountNameW(
        None,
        computer_name,
        sid_ptr,
        ctypes.byref(cb_sid),
        domain_buf,
        ctypes.byref(domain_size),
        ctypes.byref(sid_name_use),
    )
    if not ok and kernel32.GetLastError() == ERROR_INSUFFICIENT_BUFFER:
        domain_buf = ctypes.create_unicode_buffer(domain_size.value)
        domain_size = wintypes.DWORD(domain_size.value)
        cb_sid = wintypes.DWORD(256)
        ok = advapi32.LookupAccountNameW(
            None,
            computer_name,
            sid_ptr,
            ctypes.byref(cb_sid),
            domain_buf,
            ctypes.byref(domain_size),
            ctypes.byref(sid_name_use),
        )
    if not ok:
        logger.warning("LookupAccountNameW failed")
        return ""

    str_sid_ptr = ctypes.c_void_p()
    if not advapi32.ConvertSidToStringSidA(sid_ptr, ctypes.byref(str_sid_ptr)):
        return ""
    try:
        return ctypes.string_at(str_sid_ptr.value).decode("ascii") if str_sid_ptr.value else ""
    finally:
        if str_sid_ptr.value:
            kernel32.LocalFree(str_sid_ptr)


def get_device_id() -> str:
    """Chromium PrefHashCalculator device_id."""
    if os.name == "nt":
        return get_chromium_windows_device_id()
    if sys.platform == "darwin":
        try:
            result = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                m = re.search(r'"IOPlatformUUID"\s*=\s*"([A-F0-9-]+)"', result.stdout)
                if m:
                    return m.group(1)
        except (FileNotFoundError, subprocess.SubprocessError, subprocess.TimeoutExpired) as e:
            logger.warning("macOS device ID failed: %s", e)
    return ""


def normalize_browser_name(browser_name: str) -> str:
    n = browser_name.lower()
    if "chromium" in n:
        return "chromium"
    if "chrome" in n:
        return "chrome"
    if any(x in n for x in ("edge", "msedge", "microsoft-edge")):
        return "edge"
    if "brave" in n:
        return "brave"
    if "opera" in n:
        return "opera"
    if "vivaldi" in n:
        return "vivaldi"
    if "yandex" in n:
        return "yandex"
    if "arc" in n:
        return "arc"
    if "thorium" in n:
        return "thorium"
    if "iridium" in n:
        return "iridium"
    return n
