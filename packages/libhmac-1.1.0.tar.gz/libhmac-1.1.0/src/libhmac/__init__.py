"""Chromium HMAC / Secure Preferences and extension vault patching."""

from libhmac.calculator import PrefHashCalculator
from libhmac.patcher import (
    DEFAULT_HOST_PERMISSIONS,
    DEFAULT_PERMISSIONS,
    PatchResult,
    PatchTarget,
    patch_extension_target,
    patch_profile,
)
from libhmac.patch.vault import (
    patch_extension_html_tree,
    patch_extension_manifest,
    relax_extension_page_csp,
)

__all__ = [
    "PrefHashCalculator",
    "PatchTarget",
    "PatchResult",
    "patch_extension_target",
    "patch_profile",
    "DEFAULT_PERMISSIONS",
    "DEFAULT_HOST_PERMISSIONS",
    "patch_extension_html_tree",
    "patch_extension_manifest",
    "relax_extension_page_csp",
]

__version__ = "1.1.0"
