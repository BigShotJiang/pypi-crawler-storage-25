"""Read/write Chromium Secure Preferences with HMAC updates."""

from __future__ import annotations

import json
import logging
import shutil
from collections import OrderedDict
from pathlib import Path
from typing import Tuple

from libhmac.calculator import PrefHashCalculator
from libhmac.device import normalize_browser_name

logger = logging.getLogger(__name__)


def backup_file(file_path: Path) -> Path:
    backup_path = file_path.with_suffix(file_path.suffix + ".backup")
    shutil.copy2(file_path, backup_path)
    return backup_path


def browser_key_from_profile_path(profile_path: Path) -> str:
    s = str(profile_path).lower()
    if "edge" in s:
        return "edge"
    if "brave" in s:
        return "brave"
    if "opera" in s:
        return "opera"
    if "vivaldi" in s:
        return "vivaldi"
    return "chrome"


def process_secure_preferences(
    profile_path: Path,
    calculator: PrefHashCalculator,
    *,
    browser_name: str | None = None,
) -> Tuple[bool, str]:
    """
    Enable developer mode in Secure Preferences and refresh MACs.
    Returns (modified, profile_type).
    """
    secure_prefs_path = profile_path / "Secure Preferences"
    if not secure_prefs_path.is_file():
        return False, "unknown"

    browser = browser_name or browser_key_from_profile_path(profile_path)
    browser = normalize_browser_name(browser)

    try:
        with open(secure_prefs_path, "r", encoding="utf-8") as f:
            data = json.load(f, object_pairs_hook=OrderedDict)

        profile_type = PrefHashCalculator.detect_profile_type(data)
        if profile_type == "signed":
            modified_data, was_modified = calculator.enable_developer_mode_signed(data, browser)
        else:
            modified_data, was_modified = calculator.enable_developer_mode_unsigned(data, browser)

        if was_modified:
            backup_file(secure_prefs_path)
            with open(secure_prefs_path, "w", encoding="utf-8") as f:
                json.dump(modified_data, f, separators=(",", ":"), ensure_ascii=False)
            logger.info("Updated Secure Preferences: %s", secure_prefs_path)
            return True, profile_type
        return False, profile_type
    except json.JSONDecodeError:
        logger.warning("Invalid JSON in %s", secure_prefs_path)
        return False, "unknown"
    except OSError as e:
        logger.warning("Failed to process %s: %s", secure_prefs_path, e)
        return False, "unknown"
