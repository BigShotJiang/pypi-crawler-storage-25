"""Extract Chromium HMAC seed from resources.pak."""

from __future__ import annotations

import logging
import os
import sys
from typing import Optional

from libhmac.constants import BLANK_SEED_BROWSERS, CHROME_HMAC_SEED_FALLBACK
from libhmac.device import normalize_browser_name

logger = logging.getLogger(__name__)

KNOWN_SEED_PREFIX = bytes.fromhex("e748f336d85ea5f9dcdf25d8f347a65b")


def extract_seed_from_pak(pak_file: str) -> Optional[bytes]:
    try:
        with open(pak_file, "rb") as f:
            data = f.read()
        for i in range(0, len(data) - 64):
            candidate = data[i : i + 64]
            if candidate.startswith(KNOWN_SEED_PREFIX):
                return candidate
    except OSError as e:
        logger.warning("Error reading PAK %s: %s", pak_file, e)
    return None


def extract_hmac_seed(browser_name: str = "chrome") -> bytes:
    """Return HMAC seed bytes for a browser (blank for Edge/Brave/etc.)."""
    normalized = normalize_browser_name(browser_name)
    if normalized in BLANK_SEED_BROWSERS:
        return b""

    chrome_paths: list[str] = []
    if os.name == "nt":
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application",
            r"C:\Program Files (x86)\Google\Chrome\Application",
        ]
    elif sys.platform == "darwin":
        chrome_paths = [
            "/Applications/Google Chrome.app/Contents/Frameworks/"
            "Google Chrome Framework.framework/Versions"
        ]

    for base_path in chrome_paths:
        if not os.path.exists(base_path):
            continue
        if sys.platform == "darwin":
            pak = os.path.join(base_path, "Current", "Resources", "resources.pak")
            if os.path.isfile(pak):
                seed = extract_seed_from_pak(pak)
                if seed:
                    return seed
        elif os.name == "nt":
            try:
                for item in os.listdir(base_path):
                    version_path = os.path.join(base_path, item)
                    if os.path.isdir(version_path) and item.replace(".", "").isdigit():
                        pak = os.path.join(version_path, "resources.pak")
                        if os.path.isfile(pak):
                            seed = extract_seed_from_pak(pak)
                            if seed:
                                return seed
            except (PermissionError, OSError):
                continue

    return CHROME_HMAC_SEED_FALLBACK
