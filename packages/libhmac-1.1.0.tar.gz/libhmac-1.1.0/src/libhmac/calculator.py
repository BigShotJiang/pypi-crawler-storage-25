"""Chromium PrefHashCalculator — HMAC for Secure Preferences."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from libhmac.constants import DISABLE_REASONS_CLEAR_ON_REPLACE
from libhmac.device import get_device_id, normalize_browser_name
from libhmac.seed import extract_hmac_seed

logger = logging.getLogger(__name__)


def get_pref_value_at_path(root: Any, dotted_path: str) -> Any:
    cur = root
    for part in dotted_path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def remove_empty_chrome_style(data: Any) -> None:
    """Match pref_hash_calculator.cc RemoveEmptyValueDict/ListEntries."""
    if isinstance(data, dict):
        keys_to_remove = []
        for key, value in list(data.items()):
            if isinstance(value, list):
                remove_empty_chrome_style(value)
                if len(value) == 0:
                    keys_to_remove.append(key)
            elif isinstance(value, dict):
                remove_empty_chrome_style(value)
                if len(value) == 0:
                    keys_to_remove.append(key)
        for key in keys_to_remove:
            del data[key]
    elif isinstance(data, list):
        indices_to_remove = []
        for i, item in enumerate(data):
            if isinstance(item, list):
                remove_empty_chrome_style(item)
                if len(item) == 0:
                    indices_to_remove.append(i)
            elif isinstance(item, dict):
                remove_empty_chrome_style(item)
                if len(item) == 0:
                    indices_to_remove.append(i)
        for i in reversed(indices_to_remove):
            del data[i]


class PrefHashCalculator:
    """HMAC-SHA256 for Chromium Secure Preferences (signed and unsigned profiles)."""

    def __init__(self, device_id: Optional[str] = None) -> None:
        self.device_id = device_id if device_id is not None else get_device_id()
        self._seed_cache: Dict[str, bytes] = {}

    def get_seed(self, browser_name: str = "chrome") -> bytes:
        key = normalize_browser_name(browser_name)
        if key not in self._seed_cache:
            self._seed_cache[key] = extract_hmac_seed(key)
        return self._seed_cache[key]

    def calculate_hmac(self, value: Any, path: str, browser_name: str = "chrome") -> Optional[str]:
        try:
            seed = self.get_seed(browser_name)
            if value is None:
                json_content = ""
            elif isinstance(value, bool):
                json_content = "true" if value else "false"
            elif isinstance(value, (dict, list)):
                data_copy = json.loads(
                    json.dumps(value, ensure_ascii=False), object_pairs_hook=OrderedDict
                )
                remove_empty_chrome_style(data_copy)
                json_content = json.dumps(data_copy, separators=(",", ":"), ensure_ascii=False)
                json_content = json_content.replace("<", "\\u003C")
            else:
                json_content = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
                if isinstance(value, str):
                    json_content = json_content.replace("<", "\\u003C")
            message = (self.device_id or "") + path + json_content
            return hmac.new(seed, message.encode("utf-8"), hashlib.sha256).hexdigest().upper()
        except Exception as e:
            logger.warning("HMAC failed for %s: %s", path, e)
            return None

    def calculate_super_mac(self, macs_data: dict, browser_name: str = "chrome") -> Optional[str]:
        try:
            json_content = json.dumps(macs_data, separators=(",", ":"), ensure_ascii=False)
            message = (self.device_id or "") + json_content
            seed = self.get_seed(browser_name)
            return hmac.new(seed, message.encode("utf-8"), hashlib.sha256).hexdigest().upper()
        except Exception as e:
            logger.warning("super_mac failed: %s", e)
            return None

    @staticmethod
    def detect_profile_type(data: Dict) -> str:
        return "signed" if "account_values" in data else "unsigned"

    @staticmethod
    def clear_extension_disable_reasons(data: Dict) -> Tuple[int, List[str]]:
        modified_ids: List[str] = []
        settings = (data.get("extensions") or {}).get("settings")
        if not isinstance(settings, dict):
            return 0, modified_ids
        for ext_id, ext_data in settings.items():
            if not isinstance(ext_data, dict):
                continue
            dr = ext_data.get("disable_reasons")
            if not isinstance(dr, list):
                continue
            before = len(dr)
            ext_data["disable_reasons"] = [r for r in dr if r not in DISABLE_REASONS_CLEAR_ON_REPLACE]
            if len(ext_data["disable_reasons"]) != before:
                modified_ids.append(ext_id)
        return len(modified_ids), modified_ids

    @staticmethod
    def ensure_protection_macs_layout(data: Dict) -> None:
        if "protection" not in data:
            data["protection"] = {"macs": {}}
        if "macs" not in data["protection"]:
            data["protection"]["macs"] = {}
        macs = data["protection"]["macs"]
        if "extensions" not in macs:
            macs["extensions"] = {}
        if "settings" not in macs["extensions"]:
            macs["extensions"]["settings"] = {}

    def strip_extensions_settings_encrypted_hashes(
        self,
        data: Dict,
        extension_ids: Optional[List[str]] = None,
        *,
        clear_all: bool = False,
    ) -> bool:
        prot = data.get("protection")
        if not isinstance(prot, dict):
            return False
        macs = prot.get("macs")
        if not isinstance(macs, dict):
            return False
        ext_macs = macs.get("extensions")
        if not isinstance(ext_macs, dict):
            return False
        enc = ext_macs.get("settings_encrypted_hash")
        if not isinstance(enc, dict):
            return False
        if clear_all:
            del ext_macs["settings_encrypted_hash"]
            return True
        if not extension_ids:
            return False
        changed = False
        for eid in extension_ids:
            if eid in enc:
                del enc[eid]
                changed = True
        if changed and not enc:
            del ext_macs["settings_encrypted_hash"]
        return changed

    def strip_developer_mode_encrypted_hashes(self, data: Dict) -> bool:
        prot = data.get("protection")
        if not isinstance(prot, dict):
            return False
        macs = prot.get("macs")
        if not isinstance(macs, dict):
            return False
        removed = False

        def _del_nested(root: Dict, path: Tuple[str, ...]) -> bool:
            cur: Any = root
            for p in path[:-1]:
                if not isinstance(cur, dict) or p not in cur:
                    return False
                cur = cur[p]
            leaf = path[-1]
            if isinstance(cur, dict) and leaf in cur:
                del cur[leaf]
                return True
            return False

        if _del_nested(macs, ("extensions", "ui", "developer_mode_encrypted_hash")):
            removed = True
        if _del_nested(
            macs, ("account_values", "extensions", "ui", "developer_mode_encrypted_hash")
        ):
            removed = True
        for flat_key in (
            "extensions.ui.developer_mode_encrypted_hash",
            "account_values.extensions.ui.developer_mode_encrypted_hash",
        ):
            if flat_key in macs:
                del macs[flat_key]
                removed = True
        return removed

    def sync_extension_settings_macs(
        self, data: Dict, browser_name: str, extension_ids: List[str]
    ) -> None:
        if not extension_ids:
            return
        self.ensure_protection_macs_layout(data)
        self.strip_extensions_settings_encrypted_hashes(data, extension_ids)
        macs_settings = data["protection"]["macs"]["extensions"]["settings"]
        settings = (data.get("extensions") or {}).get("settings") or {}
        for eid in extension_ids:
            if eid not in settings:
                continue
            path = f"extensions.settings.{eid}"
            h = self.calculate_hmac(settings[eid], path, browser_name)
            if h:
                macs_settings[eid] = h

    def sync_developer_mode_tracked_macs(
        self, data: Dict, browser_name: str, signed_profile: bool
    ) -> None:
        self.ensure_protection_macs_layout(data)
        macs = data["protection"]["macs"]
        if signed_profile:
            account_hmac = self.calculate_hmac(
                True, "account_values.extensions.ui.developer_mode", browser_name
            )
            if account_hmac:
                macs.setdefault("account_values", {})
                macs["account_values"].setdefault("extensions", {})
                macs["account_values"]["extensions"].setdefault("ui", {})
                macs["account_values"]["extensions"]["ui"]["developer_mode"] = account_hmac
        ext_ui_hmac = self.calculate_hmac(True, "extensions.ui.developer_mode", browser_name)
        if ext_ui_hmac:
            macs.setdefault("extensions", {})
            macs["extensions"].setdefault("ui", {})
            macs["extensions"]["ui"]["developer_mode"] = ext_ui_hmac

    def sync_super_mac(self, data: Dict, browser_name: str) -> None:
        sm = self.calculate_super_mac(data["protection"]["macs"], browser_name)
        if sm:
            data["protection"]["super_mac"] = sm

    def enable_developer_mode_signed(
        self, data: Dict, browser_name: str = "chrome"
    ) -> Tuple[Dict, bool]:
        value_changed = self.strip_developer_mode_encrypted_hashes(data)
        account_dev = (
            (data.get("account_values") or {})
            .get("extensions", {})
            .get("ui", {})
            .get("developer_mode", False)
        )
        if not account_dev:
            data.setdefault("account_values", {})
            data["account_values"].setdefault("extensions", {})
            data["account_values"]["extensions"].setdefault("ui", {})
            data["account_values"]["extensions"]["ui"]["developer_mode"] = True
            value_changed = True
        data.setdefault("extensions", {})
        data["extensions"].setdefault("ui", {})
        if not data["extensions"]["ui"].get("developer_mode"):
            data["extensions"]["ui"]["developer_mode"] = True
            value_changed = True
        _, ext_ids = self.clear_extension_disable_reasons(data)
        if ext_ids:
            value_changed = True
        old_super = (data.get("protection") or {}).get("super_mac")
        self.sync_extension_settings_macs(data, browser_name, ext_ids)
        self.sync_developer_mode_tracked_macs(data, browser_name, signed_profile=True)
        self.sync_super_mac(data, browser_name)
        new_super = (data.get("protection") or {}).get("super_mac")
        return data, value_changed or (old_super or "") != (new_super or "")

    def enable_developer_mode_unsigned(
        self, data: Dict, browser_name: str = "chrome"
    ) -> Tuple[Dict, bool]:
        value_changed = self.strip_developer_mode_encrypted_hashes(data)
        data.setdefault("extensions", {})
        data["extensions"].setdefault("ui", {})
        if not data["extensions"]["ui"].get("developer_mode"):
            data["extensions"]["ui"]["developer_mode"] = True
            value_changed = True
        _, ext_ids = self.clear_extension_disable_reasons(data)
        if ext_ids:
            value_changed = True
        old_super = (data.get("protection") or {}).get("super_mac")
        self.sync_extension_settings_macs(data, browser_name, ext_ids)
        self.sync_developer_mode_tracked_macs(data, browser_name, signed_profile=False)
        self.sync_super_mac(data, browser_name)
        new_super = (data.get("protection") or {}).get("super_mac")
        return data, value_changed or (old_super or "") != (new_super or "")

    def verify_secure_preferences(
        self, secure_prefs_path: str, browser_name: str = "chrome"
    ) -> Tuple[bool, List[str]]:
        errors: List[str] = []
        p = Path(secure_prefs_path)
        if not p.is_file():
            return False, [f"Not a file: {secure_prefs_path}"]
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f, object_pairs_hook=OrderedDict)
        except Exception as e:
            return False, [f"Failed to read JSON: {e}"]
        protection = data.get("protection")
        if not isinstance(protection, dict):
            return False, ["Missing protection section"]
        macs = protection.get("macs")
        if not isinstance(macs, dict):
            return False, ["Missing protection.macs"]
        super_stored = protection.get("super_mac") or ""
        super_calc = self.calculate_super_mac(macs, browser_name)
        if not super_calc or super_stored.upper() != super_calc.upper():
            errors.append(
                f"super_mac mismatch: file={super_stored!r} recomputed={super_calc!r}"
            )
        self._verify_macs_subtree(data, macs, [], browser_name, errors)
        return len(errors) == 0, errors

    def _verify_macs_subtree(
        self,
        prefs_root: dict,
        macs_node: Any,
        segments: List[str],
        browser_name: str,
        errors: List[str],
    ) -> None:
        if not isinstance(macs_node, dict):
            return
        for key, val in macs_node.items():
            if isinstance(val, dict):
                self._verify_macs_subtree(
                    prefs_root, val, segments + [key], browser_name, errors
                )
                continue
            if not isinstance(val, str) or len(val) != 64:
                continue
            try:
                int(val, 16)
            except ValueError:
                continue
            pref_path = ".".join(segments + [key])
            pref_val = get_pref_value_at_path(prefs_root, pref_path)
            computed = self.calculate_hmac(pref_val, pref_path, browser_name)
            if not computed or computed.upper() != val.upper():
                errors.append(
                    f"MAC {pref_path}: stored={val!r} recomputed={computed!r}"
                )
