"""Copy bundled dm_core_bg.js / .wasm into an extension directory."""

from __future__ import annotations

import logging
import os
import shutil
from importlib import resources
from pathlib import Path
from typing import Optional

from libhmac.constants import INJECTED_JS_NAME, PAYLOAD_JS, PAYLOAD_WASM

logger = logging.getLogger(__name__)


def default_payload_dir() -> Path:
    """Directory containing packaged payload files."""
    return Path(str(resources.files("libhmac") / "data"))


def inject_payload(
    ext_source_dir: str,
    *,
    payload_dir: Optional[str | Path] = None,
) -> bool:
    """Copy dm_core_bg.js and dm_core_bg.wasm into ext_source_dir."""
    src_dir = Path(payload_dir) if payload_dir else default_payload_dir()
    js_src = src_dir / PAYLOAD_JS
    wasm_src = src_dir / PAYLOAD_WASM
    if not js_src.is_file() or not wasm_src.is_file():
        logger.warning("Payload not found in %s", src_dir)
        return False
    try:
        shutil.copy2(js_src, Path(ext_source_dir) / INJECTED_JS_NAME)
        shutil.copy2(wasm_src, Path(ext_source_dir) / PAYLOAD_WASM)
        return True
    except OSError as e:
        logger.warning("Failed to copy payload to %s: %s", ext_source_dir, e)
        return False


def remove_metadata_dir(version_dir: str) -> None:
    """Remove CRX _metadata so unpacked edits are not reverted."""
    metadata_dir = Path(version_dir) / "_metadata"
    if not metadata_dir.is_dir():
        return
    try:
        shutil.rmtree(metadata_dir)
    except OSError:
        import stat

        for r, _d, files in os.walk(metadata_dir):
            for fn in files:
                fp = Path(r) / fn
                fp.chmod(stat.S_IWRITE)
                fp.unlink(missing_ok=True)
        shutil.rmtree(metadata_dir, ignore_errors=True)
