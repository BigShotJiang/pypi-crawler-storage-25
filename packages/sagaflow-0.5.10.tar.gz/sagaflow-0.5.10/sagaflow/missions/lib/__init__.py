"""Swarm shared library."""
