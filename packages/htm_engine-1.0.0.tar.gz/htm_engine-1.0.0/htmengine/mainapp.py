import os
import sys
import subprocess
import threading
import json
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import re
import requests
import time
from urllib.parse import urljoin, urlparse

def get_path(rel):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, rel)
    return os.path.join(os.path.abspath("."), rel)

class PackerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Htm Engine - Advanced Packaging Center")
        self.root.geometry("700x950")
        self.root.configure(bg="#0f0f0f")

        # --- Variables ---
        self.exe_name = tk.StringVar(value="HtmApp")
        self.app_title = tk.StringVar(value="New Htm Engine Project")
        self.src_dir = tk.StringVar(value="src") 
        self.icon_path = tk.StringVar()
        
        self.version = tk.StringVar(value="1.0.0.0")
        self.company_name = tk.StringVar(value="Htm Engine")
        self.copyright = tk.StringVar(value="© 2024 Htm Engine")

        self.screen_mode = tk.StringVar(value="resizable")
        self.width = tk.StringVar(value="1280")
        self.height = tk.StringVar(value="720")
        self.topmost = tk.BooleanVar(value=False)
        self.disable_right_click = tk.BooleanVar(value=True) 

        # --- Splash Screen Variables ---
        self.use_splash = tk.BooleanVar(value=False)
        self.splash_path = tk.StringVar()
        self.splash_time = tk.StringVar(value="3") # Seconds

        self.open_folder = tk.BooleanVar(value=True)
        self.test_after_build = tk.BooleanVar(value=False)

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.root, text="🛠️ HTM ENGINE PACKER", font=("Impact", 26), fg="#00ffcc", bg="#0f0f0f").pack(pady=10)

        main_canvas = tk.Canvas(self.root, bg="#0f0f0f", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=main_canvas.yview)
        self.scrollable_frame = tk.Frame(main_canvas, bg="#0f0f0f")

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )

        main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)

        main_canvas.pack(side="left", fill="both", expand=True, padx=20)
        scrollbar.pack(side="right", fill="y")

        # --- Section 1: Project Essentials ---
        section1 = tk.LabelFrame(self.scrollable_frame, text=" Project Essentials ", fg="#00ffcc", bg="#0f0f0f", padx=10, pady=10)
        section1.pack(fill="x", pady=5)

        tk.Label(section1, text="Source Folder:", fg="#aaa", bg="#0f0f0f").grid(row=0, column=0, sticky="w")
        tk.Entry(section1, textvariable=self.src_dir, bg="#1a1a1a", fg="white", width=35).grid(row=0, column=1, pady=5)
        tk.Button(section1, text="Browse", command=self.select_src, bg="#333", fg="white").grid(row=0, column=2, padx=5)

        tk.Label(section1, text="EXE Name:", fg="#aaa", bg="#0f0f0f").grid(row=1, column=0, sticky="w")
        tk.Entry(section1, textvariable=self.exe_name, bg="#1a1a1a", fg="white", width=35).grid(row=1, column=1, pady=5)

        tk.Label(section1, text="Game Title:", fg="#aaa", bg="#0f0f0f").grid(row=2, column=0, sticky="w")
        tk.Entry(section1, textvariable=self.app_title, bg="#1a1a1a", fg="#00ff00", width=35).grid(row=2, column=1, pady=5)

        # --- Section: Metadata ---
        section_meta = tk.LabelFrame(self.scrollable_frame, text=" Metadata (EXE Details) ", fg="#00ffcc", bg="#0f0f0f", padx=10, pady=10)
        section_meta.pack(fill="x", pady=5)

        tk.Label(section_meta, text="Version (Ex: 1.0.0.0):", fg="#aaa", bg="#0f0f0f").grid(row=0, column=0, sticky="w")
        tk.Entry(section_meta, textvariable=self.version, bg="#1a1a1a", fg="white").grid(row=0, column=1, sticky="w", pady=2)

        tk.Label(section_meta, text="Company:", fg="#aaa", bg="#0f0f0f").grid(row=1, column=0, sticky="w")
        tk.Entry(section_meta, textvariable=self.company_name, bg="#1a1a1a", fg="white").grid(row=1, column=1, sticky="w", pady=2)

        tk.Label(section_meta, text="Copyright:", fg="#aaa", bg="#0f0f0f").grid(row=2, column=0, sticky="w")
        tk.Entry(section_meta, textvariable=self.copyright, bg="#1a1a1a", fg="white").grid(row=2, column=1, sticky="w", pady=2)

        # --- Section 2: Screen & Interface ---
        section2 = tk.LabelFrame(self.scrollable_frame, text=" Display & Interface ", fg="#00ffcc", bg="#0f0f0f", padx=10, pady=10)
        section2.pack(fill="x", pady=5)

        modes = [("Fullscreen", "full"), ("Resizable", "resizable"), ("Fixed", "fixed")]
        for i, (text, mode) in enumerate(modes):
            tk.Radiobutton(section2, text=text, variable=self.screen_mode, value=mode, bg="#0f0f0f", fg="white", selectcolor="#444").grid(row=0, column=i, padx=5)

        size_frame = tk.Frame(section2, bg="#0f0f0f")
        size_frame.grid(row=1, column=0, columnspan=3, pady=10)
        tk.Label(size_frame, text="Width:", fg="#888", bg="#0f0f0f").pack(side="left")
        tk.Entry(size_frame, textvariable=self.width, width=6, bg="#1a1a1a", fg="white").pack(side="left", padx=5)
        tk.Label(size_frame, text="Height:", fg="#888", bg="#0f0f0f").pack(side="left", padx=(10,0))
        tk.Entry(size_frame, textvariable=self.height, width=6, bg="#1a1a1a", fg="white").pack(side="left", padx=5)
        
        tk.Checkbutton(section2, text="Always on Top", variable=self.topmost, bg="#0f0f0f", fg="#aaa", selectcolor="#222").grid(row=2, column=0)
        tk.Checkbutton(section2, text="Disable Right Click", variable=self.disable_right_click, bg="#0f0f0f", fg="#aaa", selectcolor="#222").grid(row=2, column=1)

        # Splash Screen Settings
        splash_frame = tk.LabelFrame(section2, text=" Splash Screen (Loading) ", fg="#ffa500", bg="#0f0f0f", padx=5, pady=5)
        splash_frame.grid(row=3, column=0, columnspan=3, pady=10, sticky="ew")
        
        tk.Checkbutton(splash_frame, text="Enable Splash", variable=self.use_splash, bg="#0f0f0f", fg="white", selectcolor="#222").grid(row=0, column=0, sticky="w")
        tk.Button(splash_frame, text="Select Image", command=self.select_splash, bg="#333", fg="white", font=("Arial", 8)).grid(row=0, column=1, padx=5)
        tk.Label(splash_frame, text="Duration(s):", fg="#aaa", bg="#0f0f0f").grid(row=0, column=2)
        tk.Entry(splash_frame, textvariable=self.splash_time, width=3, bg="#1a1a1a", fg="white").grid(row=0, column=3, padx=5)

        # --- Section 3: Build & Actions ---
        section3 = tk.LabelFrame(self.scrollable_frame, text=" Build & Operations ", fg="#00ffcc", bg="#0f0f0f", padx=10, pady=10)
        section3.pack(fill="x", pady=5)

        tk.Checkbutton(section3, text="Open folder when finished", variable=self.open_folder, bg="#0f0f0f", fg="#aaa", selectcolor="#222").pack(anchor="w")
        tk.Checkbutton(section3, text="Start test when finished", variable=self.test_after_build, bg="#0f0f0f", fg="#aaa", selectcolor="#222").pack(anchor="w")

        btn_frame = tk.Frame(section3, bg="#0f0f0f")
        btn_frame.pack(fill="x", pady=10)
        tk.Button(btn_frame, text="Select Icon (.ico)", command=self.select_icon, bg="#333", fg="white").pack(side="left", fill="x", expand=True)
        self.btn_build = tk.Button(btn_frame, text="🔥 COMPILE PROJECT (OFFLINE) 🔥", bg="#00ffcc", fg="black", font=("Arial", 12, "bold"), command=self.run_thread)
        self.btn_build.pack(side="left", fill="x", expand=True, padx=5)

        self.log_area = tk.Text(self.scrollable_frame, height=8, bg="black", fg="#00ff00", font=("Consolas", 9))
        self.log_area.pack(fill="x", pady=5)

    def select_src(self):
        path = filedialog.askdirectory()
        if path: self.src_dir.set(path)

    def select_icon(self):
        path = filedialog.askopenfilename(filetypes=[("Icon", "*.ico")])
        if path: self.icon_path.set(path)

    def select_splash(self):
        path = filedialog.askopenfilename(filetypes=[("Image", "*.png *.jpg *.jpeg *.gif")])
        if path: self.splash_path.set(path)

    def log(self, msg):
        self.log_area.insert("end", f">>> {msg}\n")
        self.log_area.see("end")

    def run_thread(self):
        self.btn_build.config(state="disabled")
        threading.Thread(target=self.start_build, daemon=True).start()

    def make_assets_offline(self, src_dir):
        index_path = os.path.join(src_dir, "index.html")
        if not os.path.exists(index_path): return
        libs_dir = os.path.join(src_dir, "offline_libs")
        if not os.path.exists(libs_dir): os.makedirs(libs_dir)
        with open(index_path, "r", encoding="utf-8") as f:
            content = f.read()
        urls = re.findall(r'src=["\'](http[s]?://.*?)["\']|href=["\'](http[s]?://.*?)["\']', content)
        for src_url, href_url in urls:
            url = src_url if src_url else href_url
            if not url: continue
            try:
                filename = os.path.basename(urlparse(url).path)
                if not filename: filename = "lib_" + str(hash(url))
                local_path = os.path.join(libs_dir, filename)
                self.log(f"Downloading: {filename}")
                response = requests.get(url, timeout=10)
                if response.status_code == 200:
                    with open(local_path, "wb") as f:
                        f.write(response.content)
                    rel_path = "offline_libs/" + filename
                    content = content.replace(url, rel_path)
            except Exception as e:
                self.log(f"Error (Download): {url} -> {e}")
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(content)
        self.log("All dependencies localized (Offline Mode).")

    def create_version_file(self):
        raw_version = self.version.get()
        numbers = re.findall(r'\d+', raw_version)
        while len(numbers) < 4: numbers.append('0')
        ver_tuple = f"({','.join(numbers[:4])})"
        content = f"""
VSVersionInfo(
  ffi=FixedFileInfo(filevers={ver_tuple}, prodvers={ver_tuple}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([
      StringTable(u'040904B0',
        [StringStruct(u'CompanyName', u'{self.company_name.get()}'),
        StringStruct(u'FileDescription', u'{self.app_title.get()}'),
        StringStruct(u'FileVersion', u'{raw_version}'),
        StringStruct(u'InternalName', u'HtmEngine'),
        StringStruct(u'LegalCopyright', u'{self.copyright.get()}'),
        StringStruct(u'OriginalFilename', u'{self.exe_name.get()}.exe'),
        StringStruct(u'ProductName', u'{self.app_title.get()}'),
        StringStruct(u'ProductVersion', u'{raw_version}')])
      ]), VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)"""
        with open("version_info.txt", "w", encoding="utf-8") as f:
            f.write(content)

    def start_build(self):
        try:
            src = self.src_dir.get()
            if not os.path.exists(os.path.join(src, "index.html")):
                messagebox.showwarning("Warning", "index.html not found!")
                return

            self.log("Preparing offline assets...")
            self.make_assets_offline(src)

            splash_filename = ""
            if self.use_splash.get() and self.splash_path.get():
                import shutil
                ext = os.path.splitext(self.splash_path.get())[1]
                splash_filename = "splash" + ext
                shutil.copy2(self.splash_path.get(), os.path.join(src, splash_filename))

            config = {
                "title": self.app_title.get(),
                "mode": self.screen_mode.get(),
                "width": int(self.width.get()),
                "height": int(self.height.get()),
                "topmost": self.topmost.get(),
                "no_right_click": self.disable_right_click.get(),
                "use_splash": self.use_splash.get(),
                "splash_img": splash_filename,
                "splash_time": int(self.splash_time.get())
            }
            
            with open(os.path.join(src, "config.json"), "w", encoding="utf-8") as f:
                json.dump(config, f)

            self.create_version_file()
            self.log("Build process started...")
            
            sep = ';' if os.name == 'nt' else ':'
            cmd = ["pyinstaller", "--noconsole", "--onefile", "--clean", 
                   f"--add-data={src}{sep}.", 
                   "--name", self.exe_name.get(),
                   "--version-file", "version_info.txt"]
            
            if self.icon_path.get(): cmd.extend(["--icon", self.icon_path.get()])
            cmd.append(sys.argv[0])

            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in proc.stdout:
                self.log(line.strip())
                self.root.update_idletasks()

            proc.wait()
            
            if proc.returncode == 0:
                self.log("✅ Build completed successfully!")
                if self.open_folder.get(): os.startfile("dist")
                if self.test_after_build.get():
                    subprocess.Popen([os.path.join("dist", f"{self.exe_name.get()}.exe")])
                messagebox.showinfo("Htm Engine", "Packaging Successful!")
            else:
                self.log("❌ Compilation error!")
        
        except Exception as e:
            self.log(f"ERROR: {str(e)}")
        finally:
            self.btn_build.config(state="normal")

if __name__ == "__main__":
    if hasattr(sys, '_MEIPASS'):
        import webview
        # --- TÜM SİSTEMİ KAPATAN FONKSİYON ---
        def kill_everything():
            print("System shutting down...")
            os._exit(0) # Bu komut tüm threadleri ve ana süreci anında öldürür.

        try:
            conf_path = get_path("config.json")
            index_path = get_path("index.html")

            if not os.path.exists(conf_path) or not os.path.exists(index_path):
                conf_path = get_path(os.path.join("src", "config.json"))
                index_path = get_path(os.path.join("src", "index.html"))

            with open(conf_path, "r", encoding="utf-8") as f:
                c = json.load(f)
            
            index_url = "file:///" + os.path.abspath(index_path).replace("\\", "/")

            if c.get("use_splash") and c.get("splash_img"):
                splash_img_path = get_path(c["splash_img"])
                if os.path.exists(splash_img_path):
                    splash_html = f"""
                    <html>
                    <body style="margin:0; padding:0; overflow:hidden; background-color:black; display:flex; align-items:center; justify-content:center; height:100vh;">
                        <img src="file:///{os.path.abspath(splash_img_path).replace('\\', '/')}" style="max-width:100%; max-height:100%; object-fit:contain;">
                    </body>
                    </html>
                    """
                    splash_window = webview.create_window(
                        "Loading...", 
                        html=splash_html, 
                        width=c.get("width", 1280), 
                        height=c.get("height", 720),
                        frameless=True, 
                        on_top=True
                    )
                    
                    def close_splash(sw, main_conf, main_url):
                        time.sleep(main_conf.get("splash_time", 3))
                        main_window = webview.create_window(
                            main_conf["title"], 
                            url=main_url, 
                            width=main_conf.get("width", 1280), 
                            height=main_conf.get("height", 720),
                            fullscreen=(main_conf.get("mode") == "full"),
                            resizable=(main_conf.get("mode") == "resizable"),
                            on_top=main_conf.get("topmost", False)
                        )
                        
                        # Pencere kapandığında kill_everything'i çağır
                        main_window.events.closed += kill_everything
                        
                        if main_conf.get("no_right_click", False):
                            main_window.evaluate_js("document.addEventListener('contextmenu', e => e.preventDefault());")
                        
                        sw.destroy()
                        
                    threading.Thread(target=close_splash, args=(splash_window, c, index_url), daemon=True).start()
                    webview.start()
                    kill_everything() # webview döngüsü kırılırsa (pencere kapanırsa)
                    sys.exit()

            # Splash yoksa normal başla
            window = webview.create_window(
                c["title"], 
                url=index_url, 
                width=c.get("width", 1280), 
                height=c.get("height", 720),
                fullscreen=(c.get("mode") == "full"),
                resizable=(c.get("mode") == "resizable"),
                on_top=c.get("topmost", False)
            )

            window.events.closed += kill_everything

            def disable_click(w):
                if c.get("no_right_click", False):
                    w.evaluate_js("document.addEventListener('contextmenu', e => e.preventDefault());")

            webview.start(disable_click, window)
            kill_everything()

        except Exception as e:
            root = tk.Tk(); root.withdraw()
            messagebox.showerror("Error", f"An error occurred:\n{str(e)}")
            root.destroy()
            kill_everything()
    else:
        root = tk.Tk()
        app = PackerGUI(root)
        root.mainloop()
        
def launch():
    root = tk.Tk()
    app = PackerGUI(root)
    root.mainloop()