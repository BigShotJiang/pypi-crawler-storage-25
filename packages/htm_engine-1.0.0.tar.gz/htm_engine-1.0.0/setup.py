from setuptools import setup, find_packages

setup(
    name="htmengine",
    version="1.0.1",
    author="YAVUX STUDIOS",
    packages=find_packages(),
    install_requires=[
        "pyinstaller",
        "pywebview",
        "requests",
    ],
    entry_points={
        'console_scripts': [
            'htmengine=htmengine.mainapp:launch', # htmengine yazınca launch() çalışır
        ],
    },
)