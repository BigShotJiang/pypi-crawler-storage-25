This library is intended to streamline certain processes in machine learning workflows that seem to be missing
Currently it only contains 2 major components:
1. Cross Validating an ARIMA statsmodel instead of relying on bic or aic, which are tentative 
2. An drastically simplified version of playwright for web scraping