
from inspect import signature
from numpy import arange
from statsmodels.tsa.arima.model import ARIMA
import warnings
warnings.filterwarnings("ignore")
class ARIMA_with_cv(ARIMA):

    #Perform cross validation on ARIMA model
    #Intended to copy model hyperparameters including pdq and exog; endog is dynamic inside method
    #Folds are automatically created based on sample size e.g. roughly speaking, 100 samples ~ 100 folds
    #This method skips runs which trigger errors due to training sample size

    #only current argument is a scoring function

    #returns a dictionary that includes:
        #final_score (average score across all folds)
        #num_folds (number of folds)
        #score_list (a list of the score at each fold; if skipped, score = None)
        #success_flags (a list indicating if a sample size was applied or skipped)
        #error_type (a list containing the error type that occured if skipped; 
            #if not skipped, the type is None;
            #Currently only indicates Linear algorthim error or index error;
            #other error types just fall under 'Other')

    def cross_validate(self, scoring_function, cv = 'all'):
        score_sum = 0
        num_folds_passed = 0
        num_total_samples = len(self.endog)
        if cv == 'all':
            cv = num_total_samples
            training_lengths = arange(1, num_total_samples)
        else:
            cv+=1
            training_lengths = arange(1, cv)*num_total_samples/cv
            training_lengths = training_lengths.astype(int)

        using_exog = self.exog is not None
        exog_test_set = None
        success_flags = []
        scores = []
        error_type = []
        args_in = {}
        for param in signature(ARIMA).parameters:
            if hasattr(self, param):
                args_in[param] = getattr(self, param)

        args_in = {'trend':'n'}

        for train_length in training_lengths:
            print("train length:", train_length)
            args_in['endog'] = self.endog[:train_length]
            test_set = self.endog[train_length:]
            if using_exog:
                args_in['exog'] = self.exog[:train_length]
                exog_test_set = self.exog[train_length:]

            print("exog:", args_in['trend'])
            model = ARIMA( **args_in)
            try:
                trained_model = model.fit()
                score = scoring_function(test_set, trained_model.forecast(steps=len(test_set), exog = exog_test_set))
                scores.append(score)
                score_sum += score
                num_folds_passed += 1
                success_flags.append(True)
                error_type.append(None)
            except Exception as e:
                success_flags.append(False)
                error_type.append(e)
                scores.append(None)
                continue

        return {
                'final_score': score_sum/(cv - 1),
                'num_folds_passed': num_folds_passed,
                'scores': scores,
                'success_flags': success_flags,
                'error_type': error_type,
                }
