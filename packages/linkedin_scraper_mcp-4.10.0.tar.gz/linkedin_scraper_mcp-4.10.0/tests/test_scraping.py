"""Tests for the LinkedInExtractor scraping engine."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from linkedin_mcp_server.callbacks import ProgressCallback
from linkedin_mcp_server.core.exceptions import (
    AuthenticationError,
    LinkedInScraperException,
)
from linkedin_mcp_server.scraping.connection import (
    ActionSignals,
    detect_connection_state,
)
from linkedin_mcp_server.scraping.extractor import (
    ExtractedSection,
    LinkedInExtractor,
    _RATE_LIMITED_MSG,
    _truncate_linkedin_noise,
    strip_linkedin_noise,
)
from linkedin_mcp_server.scraping.link_metadata import Reference


def extracted(
    text: str,
    references: list[Reference] | None = None,
    error: dict | None = None,
) -> ExtractedSection:
    """Create an ExtractedSection for tests."""
    return ExtractedSection(text=text, references=references or [], error=error)


class TestBuildJobSearchUrl:
    """Tests for _build_job_search_url URL construction."""

    def test_keywords_only(self):
        url = LinkedInExtractor._build_job_search_url("python developer")
        assert url == "https://www.linkedin.com/jobs/search/?keywords=python+developer"

    def test_with_location(self):
        url = LinkedInExtractor._build_job_search_url("python", location="Remote")
        assert "keywords=python" in url
        assert "location=Remote" in url

    def test_date_posted_normalization(self):
        url = LinkedInExtractor._build_job_search_url("python", date_posted="past_week")
        assert "f_TPR=r604800" in url

    def test_date_posted_passthrough(self):
        url = LinkedInExtractor._build_job_search_url("python", date_posted="r3600")
        assert "f_TPR=r3600" in url

    def test_experience_level_normalization(self):
        url = LinkedInExtractor._build_job_search_url(
            "python", experience_level="entry"
        )
        assert "f_E=2" in url

    def test_experience_level_csv(self):
        url = LinkedInExtractor._build_job_search_url(
            "python", experience_level="entry,director"
        )
        assert "f_E=2,5" in url

    def test_work_type_normalization(self):
        url = LinkedInExtractor._build_job_search_url("python", work_type="remote")
        assert "f_WT=2" in url

    def test_work_type_csv(self):
        url = LinkedInExtractor._build_job_search_url(
            "python", work_type="on_site,hybrid"
        )
        assert "f_WT=1,3" in url

    def test_easy_apply(self):
        url = LinkedInExtractor._build_job_search_url("python", easy_apply=True)
        assert "f_EA=true" in url

    def test_easy_apply_false_omitted(self):
        url = LinkedInExtractor._build_job_search_url("python", easy_apply=False)
        assert "f_EA" not in url

    def test_sort_by_normalization(self):
        url = LinkedInExtractor._build_job_search_url("python", sort_by="date")
        assert "sortBy=DD" in url

    def test_job_type_normalization(self):
        url = LinkedInExtractor._build_job_search_url("python", job_type="full_time")
        assert "f_JT=F" in url

    def test_job_type_csv(self):
        url = LinkedInExtractor._build_job_search_url(
            "python", job_type="full_time,contract"
        )
        assert "f_JT=F,C" in url

    def test_job_type_passthrough(self):
        url = LinkedInExtractor._build_job_search_url("python", job_type="F")
        assert "f_JT=F" in url

    def test_all_filters_combined(self):
        url = LinkedInExtractor._build_job_search_url(
            "python",
            location="Berlin",
            date_posted="past_week",
            experience_level="entry,mid_senior",
            work_type="remote",
            easy_apply=True,
            sort_by="date",
        )
        assert "keywords=python" in url
        assert "location=Berlin" in url
        assert "f_TPR=r604800" in url
        assert "f_E=2,4" in url
        assert "f_WT=2" in url
        assert "f_EA=true" in url
        assert "sortBy=DD" in url


@pytest.fixture
def mock_page():
    """Create a mock Patchright page."""
    page = MagicMock()
    page.goto = AsyncMock()
    page.title = AsyncMock(return_value="LinkedIn")
    page.wait_for_selector = AsyncMock()
    page.wait_for_function = AsyncMock()
    page.evaluate = AsyncMock(
        return_value={"source": "root", "text": "Sample page text", "references": []}
    )
    page.url = "https://www.linkedin.com/in/testuser/"
    page.locator = MagicMock()
    # Default: no modals, no CAPTCHA
    mock_locator = MagicMock()
    mock_locator.count = AsyncMock(return_value=0)
    mock_locator.is_visible = AsyncMock(return_value=False)
    mock_locator.first = mock_locator
    mock_locator.inner_text = AsyncMock(return_value="normal page content")
    mock_locator.filter = MagicMock(return_value=mock_locator)
    page.locator.return_value = mock_locator
    page.main_frame = object()
    page.on = MagicMock()
    page.remove_listener = MagicMock()
    return page


class TestExtractPage:
    async def test_extract_page_returns_text(self, mock_page):
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Sample profile text",
                "references": [],
            }
        )
        extractor = LinkedInExtractor(mock_page)
        # Patch scroll_to_bottom and detect_rate_limit to avoid complex mock chains
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor.extract_page(
                "https://www.linkedin.com/in/testuser/",
                section_name="main_profile",
            )

        assert result.text == "Sample profile text"
        assert result.references == []
        mock_page.goto.assert_awaited_once()

    async def test_root_content_filters_empty_href_before_resolution(self, mock_page):
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Sample profile text",
                "references": [],
            }
        )
        extractor = LinkedInExtractor(mock_page)

        await extractor._extract_root_content(["main"])

        await_args = mock_page.evaluate.await_args
        assert await_args is not None
        script = await_args.args[0]
        assert "MAX_HEADING_CONTAINERS = 300" in script
        assert "MAX_REFERENCE_ANCHORS = 500" in script
        assert "const getPreviousHeading = node =>" in script
        assert "index < 3" in script
        assert "if (!rawHref || rawHref === '#')" in script
        assert ".slice(0, MAX_REFERENCE_ANCHORS)" in script
        assert "in_list" not in script
        assert ".filter(Boolean);" in script

    async def test_extract_page_returns_empty_on_failure(self, mock_page):
        mock_page.goto = AsyncMock(side_effect=Exception("Network error"))
        extractor = LinkedInExtractor(mock_page)

        with patch(
            "linkedin_mcp_server.scraping.extractor.build_issue_diagnostics",
            return_value={"issue_template_path": "/tmp/issue.md"},
        ):
            result = await extractor.extract_page(
                "https://www.linkedin.com/in/bad/",
                section_name="main_profile",
            )
        assert result.text == ""
        assert result.references == []
        assert result.error == {"issue_template_path": "/tmp/issue.md"}

    async def test_extract_page_raises_auth_error_for_account_picker(self, mock_page):
        mock_page.goto = AsyncMock(side_effect=Exception("net::ERR_TOO_MANY_REDIRECTS"))
        extractor = LinkedInExtractor(mock_page)

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_auth_barrier",
                new_callable=AsyncMock,
                return_value="auth barrier text: welcome back + sign in using another account",
            ),
            pytest.raises(AuthenticationError, match="--login"),
        ):
            await extractor.extract_page(
                "https://www.linkedin.com/in/testuser/",
                section_name="main_profile",
            )

    async def test_rate_limit_detected(self, mock_page):
        from linkedin_mcp_server.core.exceptions import RateLimitError

        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
                side_effect=RateLimitError("Rate limited", suggested_wait_time=3600),
            ),
            pytest.raises(RateLimitError),
        ):
            await extractor.extract_page(
                "https://www.linkedin.com/in/testuser/",
                section_name="main_profile",
            )

    async def test_returns_rate_limited_msg_after_retry(self, mock_page):
        """When both attempts return only noise, surface rate limit message."""
        noise_only = (
            "More profiles for you\n\n"
            "You've approached your profile search limit\n\n"
            "About\nAccessibility\nTalent Solutions"
        )
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": noise_only, "references": []}
        )
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.extract_page(
                "https://www.linkedin.com/in/testuser/details/experience/",
                section_name="experience",
            )

        assert result.text == _RATE_LIMITED_MSG
        # goto called twice (initial + retry)
        assert mock_page.goto.await_count == 2

    async def test_retry_succeeds_after_rate_limit(self, mock_page):
        """When first attempt is rate-limited but retry succeeds, return content."""
        noise_only = "More profiles for you\n\nAbout\nAccessibility\nTalent Solutions"
        call_count = 0

        async def evaluate_side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                return noise_only
            return "Education\nHarvard University\n1973 – 1975"

        async def root_content_side_effect(*args, **kwargs):
            return {
                "source": "root",
                "text": await evaluate_side_effect(),
                "references": [],
            }

        mock_page.evaluate = AsyncMock(side_effect=root_content_side_effect)
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.extract_page(
                "https://www.linkedin.com/in/testuser/details/education/",
                section_name="education",
            )

        assert result.text == "Education\nHarvard University\n1973 – 1975"

    async def test_media_only_controls_are_not_misclassified_as_rate_limited(
        self, mock_page
    ):
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Play\nLoaded: 100.00%\nRemaining time 0:07\nShow captions",
                "references": [],
            }
        )
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor._extract_page_once(
                "https://www.linkedin.com/in/testuser/recent-activity/all/",
                section_name="posts",
            )

        assert result.text == ""
        assert result.references == []

    async def test_extract_search_page_raises_auth_error_for_login_barrier(
        self, mock_page
    ):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_navigate_to_page",
                new_callable=AsyncMock,
                side_effect=AuthenticationError("Run with --login"),
            ),
            pytest.raises(AuthenticationError, match="--login"),
        ):
            await extractor._extract_search_page_once(
                "https://www.linkedin.com/jobs/search/?keywords=test",
                section_name="search_results",
            )


class TestNavigationDiagnostics:
    async def test_goto_with_auth_checks_clicks_remember_me_and_retries(
        self, mock_page
    ):
        extractor = LinkedInExtractor(mock_page)

        async def goto_side_effect(*args, **kwargs):
            if mock_page.goto.await_count == 1:
                raise Exception("net::ERR_TOO_MANY_REDIRECTS")
            return None

        mock_page.goto = AsyncMock(side_effect=goto_side_effect)

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.resolve_remember_me_prompt",
                new_callable=AsyncMock,
                side_effect=[True],
            ) as mock_resolve,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_auth_barrier_quick",
                new_callable=AsyncMock,
                return_value=None,
            ),
        ):
            await extractor._goto_with_auth_checks(
                "https://www.linkedin.com/in/testuser/"
            )

        assert mock_page.goto.await_count == 2
        mock_resolve.assert_awaited_once()

    async def test_goto_with_auth_checks_unhooks_outer_listener_before_retry(
        self, mock_page
    ):
        extractor = LinkedInExtractor(mock_page)
        listener_events: list[str] = []

        def record_on(event_name, callback):
            listener_events.append(f"on:{event_name}")

        def record_remove(event_name, callback):
            listener_events.append(f"off:{event_name}")

        mock_page.on.side_effect = record_on
        mock_page.remove_listener.side_effect = record_remove

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.resolve_remember_me_prompt",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_auth_barrier_quick",
                new_callable=AsyncMock,
                side_effect=["account picker", None],
            ),
        ):
            await extractor._goto_with_auth_checks(
                "https://www.linkedin.com/in/testuser/"
            )

        assert listener_events == [
            "on:framenavigated",
            "off:framenavigated",
            "on:framenavigated",
            "off:framenavigated",
        ]

    async def test_goto_with_auth_checks_records_original_failure_before_retry(
        self, mock_page
    ):
        extractor = LinkedInExtractor(mock_page)
        mock_page.goto = AsyncMock(
            side_effect=[
                Exception("net::ERR_TOO_MANY_REDIRECTS"),
                Exception("retry failed"),
            ]
        )

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.resolve_remember_me_prompt",
                new_callable=AsyncMock,
                side_effect=[True, False],
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.record_page_trace",
                new_callable=AsyncMock,
            ) as mock_trace,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_auth_barrier",
                new_callable=AsyncMock,
                return_value=None,
            ),
            pytest.raises(Exception, match="retry failed"),
        ):
            await extractor._goto_with_auth_checks(
                "https://www.linkedin.com/in/testuser/"
            )

        trace_steps = [call.args[1] for call in mock_trace.await_args_list]
        assert "extractor-navigation-error-before-remember-me-retry" in trace_steps

        trace_call = next(
            call
            for call in mock_trace.await_args_list
            if call.args[1] == "extractor-navigation-error-before-remember-me-retry"
        )
        assert (
            trace_call.kwargs["extra"]["error"]
            == "Exception: net::ERR_TOO_MANY_REDIRECTS"
        )

    async def test_goto_with_auth_checks_logs_failure_context(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        mock_page.goto = AsyncMock(side_effect=Exception("net::ERR_TOO_MANY_REDIRECTS"))

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.resolve_remember_me_prompt",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_auth_barrier",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch.object(
                extractor,
                "_log_navigation_failure",
                new_callable=AsyncMock,
            ) as mock_log_failure,
            pytest.raises(Exception, match="ERR_TOO_MANY_REDIRECTS"),
        ):
            await extractor._goto_with_auth_checks(
                "https://www.linkedin.com/in/testuser/"
            )

        mock_log_failure.assert_awaited_once()
        mock_page.on.assert_called_once()
        mock_page.remove_listener.assert_called_once()


class TestScrapePersonUrls:
    """Test that scrape_person visits the correct URLs per section set."""

    async def test_baseline_always_included(self, mock_page):
        """Passing only experience still visits main profile."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"experience"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert "main_profile" in result["sections"]
        assert any(u.endswith("/in/testuser/") for u in urls)
        assert any("/details/experience/" in u for u in urls)

    async def test_basic_info_only_visits_main_profile(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("profile text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"main_profile"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert len(urls) == 1
        assert urls[0].endswith("/in/testuser/")
        assert set(result["sections"]) == {"main_profile"}

    async def test_scrape_person_returns_section_errors(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                side_effect=[
                    extracted("profile text"),
                    extracted("", error={"issue_template_path": "/tmp/issue.md"}),
                ],
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"posts"})

        assert result["sections"]["main_profile"] == "profile text"
        assert (
            result["section_errors"]["posts"]["issue_template_path"] == "/tmp/issue.md"
        )

    async def test_experience_education_visits_correct_urls(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person(
                "testuser", {"main_profile", "experience", "education"}
            )

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert len(urls) == 3
        assert any(u.endswith("/in/testuser/") for u in urls)
        assert any("/details/experience/" in u for u in urls)
        assert any("/details/education/" in u for u in urls)
        assert set(result["sections"]) == {"main_profile", "experience", "education"}

    async def test_all_sections_visit_all_urls(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        all_sections = {
            "main_profile",
            "experience",
            "education",
            "interests",
            "honors",
            "languages",
            "certifications",
            "skills",
            "projects",
            "contact_info",
            "posts",
        }
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted("contact text"),
            ) as mock_overlay,
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", all_sections)

        page_urls = [call.args[0] for call in mock_extract.call_args_list]
        overlay_urls = [call.args[0] for call in mock_overlay.call_args_list]
        all_urls = page_urls + overlay_urls
        # 10 full-page sections + 1 overlay (contact_info)
        assert len(page_urls) == 10
        assert len(overlay_urls) == 1
        # Verify each expected suffix was navigated
        assert any(u.endswith("/in/testuser/") for u in all_urls)
        assert any("/details/experience/" in u for u in all_urls)
        assert any("/details/education/" in u for u in all_urls)
        assert any("/details/interests/" in u for u in all_urls)
        assert any("/details/honors/" in u for u in all_urls)
        assert any("/details/languages/" in u for u in all_urls)
        assert any("/details/certifications/" in u for u in all_urls)
        assert any("/details/skills/" in u for u in all_urls)
        assert any("/details/projects/" in u for u in all_urls)
        assert any("/overlay/contact-info/" in u for u in overlay_urls)
        assert any("/recent-activity/all/" in u for u in all_urls)
        assert set(result["sections"]) == all_sections

    async def test_posts_visits_recent_activity(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("Post 1\nPost 2"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("test-user", {"posts"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert any("/recent-activity/all/" in url for url in urls)
        assert "posts" in result["sections"]

    async def test_certifications_visits_details_page(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("Python for Data Science\nIBM"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("test-user", {"certifications"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert any("/details/certifications/" in url for url in urls)
        assert "certifications" in result["sections"]

    async def test_skills_visits_details_page(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("Python\nData Analysis"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("test-user", {"skills"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert any("/details/skills/" in url for url in urls)
        assert "skills" in result["sections"]

    async def test_projects_visits_details_page(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("Portfolio Website\nBuilt with React"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("test-user", {"projects"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert any("/details/projects/" in url for url in urls)
        assert "projects" in result["sections"]

    async def test_scrape_person_passes_max_scrolls(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            await extractor.scrape_person(
                "test-user", {"certifications"}, max_scrolls=15
            )

        for call in mock_extract.call_args_list:
            assert call.kwargs.get("max_scrolls") == 15


class TestDetectConnectionState:
    """Tests for locale-independent connection-state detection.

    All states except incoming_request are decided purely from the
    structural ActionSignals; profile_text is passed empty for those.
    Incoming-request is the one AGENTS.md-sanctioned text fallback,
    so its test passes both signals (all False) and a profile_text
    containing Accept/Ignore labels. The two priority-ordering tests
    intentionally pass non-empty text to verify that URL/attribute
    signals win over text fallbacks regardless of what's in the text.
    """

    @staticmethod
    def _signals(
        invite: bool = False,
        compose_in_root: bool = False,
        edit: bool = False,
        labeled_action: bool = False,
        labeled_anchor: bool = False,
    ) -> ActionSignals:
        return ActionSignals(
            has_invite_anchor=invite,
            has_compose_anchor_in_action_root=compose_in_root,
            has_edit_intro_anchor=edit,
            has_labeled_action_button=labeled_action,
            has_labeled_action_anchor=labeled_anchor,
        )

    def test_self_profile(self):
        assert detect_connection_state("", self._signals(edit=True)) == "self_profile"

    def test_connectable(self):
        assert detect_connection_state("", self._signals(invite=True)) == "connectable"

    def test_already_connected(self):
        # 1st-degree: Message anchor in action root, but no Follow/Connect/Pending
        # button (no aria-label on any action-root button).
        assert (
            detect_connection_state(
                "", self._signals(compose_in_root=True, labeled_action=False)
            )
            == "already_connected"
        )

    def test_follow_only(self):
        # No invite anchor anywhere, but a primary action <button> (Follow
        # / Save in Sales Navigator) is present alongside the Message
        # anchor.
        assert (
            detect_connection_state(
                "", self._signals(compose_in_root=True, labeled_action=True)
            )
            == "follow_only"
        )

    def test_pending_via_labeled_anchor(self):
        # Pending is rendered as <a aria-label="Pending, click to ..."> in
        # the action root — distinct from Follow's <button aria-label=...>.
        assert (
            detect_connection_state(
                "",
                self._signals(compose_in_root=True, labeled_anchor=True),
            )
            == "pending"
        )

    def test_pending_takes_priority_over_already_connected(self):
        # If the labeled anchor is present alongside compose-in-root with
        # no labeled button, pending wins over the already_connected
        # fallthrough that would otherwise apply.
        assert (
            detect_connection_state(
                "",
                self._signals(compose_in_root=True, labeled_anchor=True),
            )
            == "pending"
        )

    def test_incoming_request_via_text_fallback_en(self):
        # Locale-table fallback per AGENTS.md — Accept+Ignore (en) appear
        # within the top-card prefix.
        text = "Aklasur Rahman\n\n--\n\nDhaka\n\nAccept\nIgnore\nMore"
        assert detect_connection_state(text, self._signals()) == "incoming_request"

    def test_incoming_request_text_outside_top_card_ignored(self):
        # Accept/Ignore far past the 600-char top-card budget must not match.
        prefix = "X" * 700
        text = prefix + "\nAccept\nIgnore\n"
        assert detect_connection_state(text, self._signals()) == "unavailable"

    def test_incoming_request_takes_priority_over_already_connected(self):
        # If the profile somehow has both compose anchor and Accept/Ignore
        # labels (edge case), incoming_request wins per resolution order.
        text = "Aklasur\n\nAccept\nIgnore\nMore"
        assert (
            detect_connection_state(text, self._signals(compose_in_root=True))
            == "incoming_request"
        )

    def test_connectable_takes_priority_over_text_signals(self):
        # vanityName invite anchor wins even if the page also has
        # text that would otherwise match a fallback.
        text = "Jane\n\nAccept\nIgnore\n"
        assert (
            detect_connection_state(text, self._signals(invite=True)) == "connectable"
        )

    def test_unavailable_when_no_signals_or_text(self):
        assert detect_connection_state("", self._signals()) == "unavailable"

    def test_unavailable_when_compose_missing_and_no_text(self):
        # Restricted profile: no compose anchor, no labels, no invite.
        assert (
            detect_connection_state(
                "Some name\n\nFollow\n", self._signals(labeled_action=True)
            )
            == "unavailable"
        )


class TestConnectWithPerson:
    def _mock_scrape(
        self, profile_text: str, *, follow_up_text: str | None = None
    ) -> AsyncMock:
        """Return a mock for scrape_person.

        When ``follow_up_text`` is given, the second call returns that text
        — used to simulate verification re-reads after an action.
        """
        first = {
            "url": "https://www.linkedin.com/in/testuser/",
            "sections": {"main_profile": profile_text},
        }
        if follow_up_text is None:
            return AsyncMock(return_value=first)
        second = {
            "url": "https://www.linkedin.com/in/testuser/",
            "sections": {"main_profile": follow_up_text},
        }
        return AsyncMock(side_effect=[first, second])

    @staticmethod
    def _signals(
        invite: bool = False,
        compose: bool = False,
        edit: bool = False,
        labeled_action: bool = False,
        labeled_anchor: bool = False,
    ) -> ActionSignals:
        return ActionSignals(
            has_invite_anchor=invite,
            has_compose_anchor_in_action_root=compose,
            has_edit_intro_anchor=edit,
            has_labeled_action_button=labeled_action,
            has_labeled_action_anchor=labeled_anchor,
        )

    async def test_connectable_navigates_deeplink_and_verifies(self, mock_page):
        """Connect via deeplink: dialog opens, submit succeeds, anchor disappears."""
        extractor = LinkedInExtractor(mock_page)
        text = "Jane\n\n· 3rd\n\nEngineer\n\nConnect\nMore\nAbout\n"
        post_text = "Jane\n\n· 3rd\n\nEngineer\n\nMessage\nPending\nMore\nAbout\n"

        with (
            patch.object(
                extractor,
                "scrape_person",
                self._mock_scrape(text, follow_up_text=post_text),
            ),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                side_effect=[self._signals(invite=True), self._signals()],
            ),
            patch.object(
                extractor,
                "_navigate_to_page",
                new_callable=AsyncMock,
            ) as mock_nav,
            patch.object(
                extractor,
                "_dialog_is_open",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_click_dialog_primary_button",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connected"
        mock_nav.assert_awaited_once()
        await_args = mock_nav.await_args
        assert await_args is not None
        assert "preload/custom-invite" in await_args.args[0]

    async def test_connectable_send_failed_when_anchor_persists(self, mock_page):
        """Dialog submitted but profile still exposes Connect → send_failed."""
        extractor = LinkedInExtractor(mock_page)
        text = "Jane\n\n· 3rd\n\nEngineer\n\nConnect\nMore\nAbout\n"

        with (
            patch.object(
                extractor, "scrape_person", self._mock_scrape(text, follow_up_text=text)
            ),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                side_effect=[self._signals(invite=True), self._signals(invite=True)],
            ),
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch.object(
                extractor, "_dialog_is_open", new_callable=AsyncMock, return_value=True
            ),
            patch.object(
                extractor,
                "_click_dialog_primary_button",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "send_failed"

    async def test_connectable_no_dialog_returns_connect_unavailable(self, mock_page):
        """Deeplink opened but no dialog appeared → connect_unavailable."""
        extractor = LinkedInExtractor(mock_page)
        text = "Jane\n\n· 3rd\n\nEngineer\n\nConnect\nMore\nAbout\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(invite=True),
            ),
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch.object(
                extractor, "_dialog_is_open", new_callable=AsyncMock, return_value=False
            ),
            patch.object(extractor, "_dismiss_dialog", new_callable=AsyncMock),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connect_unavailable"

    async def test_returns_already_connected_via_anchor(self, mock_page):
        """1st-degree detected via /messaging/compose anchor."""
        extractor = LinkedInExtractor(mock_page)
        text = "Collin\n\n· 1st\n\nEngineer\n\nMessage\nMore\nAbout\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(compose=True),
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "already_connected"

    async def test_returns_self_profile_via_edit_intro_anchor(self, mock_page):
        """Editing-your-own-profile anchor blocks connect attempts."""
        extractor = LinkedInExtractor(mock_page)
        text = "Daniel\n\nEdit profile\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(edit=True),
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connect_unavailable"
        assert "own profile" in result["message"]

    async def test_connect_via_more_menu(self, mock_page):
        """Follow-primary profile with Connect under More: detection sees
        no invite anchor initially, _open_more_menu surfaces it, deeplink
        fires."""
        extractor = LinkedInExtractor(mock_page)
        # Pre-More: Follow primary, Connect hidden under the More dropdown.
        pre = "Christian\n\n· 2nd\n\nFounder\n\nFollow\nMessage\nMore\n"
        post = "Christian\n\n· 2nd\n\nFounder\n\nMessage\nPending\nMore\n"

        with (
            patch.object(
                extractor,
                "scrape_person",
                self._mock_scrape(pre, follow_up_text=post),
            ),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                # 1st: follow_only (compose+labeled, no invite).
                # 2nd: post-More reread reveals invite anchor.
                # 3rd: post-deeplink verification — invite anchor gone.
                side_effect=[
                    self._signals(compose=True, labeled_action=True),
                    self._signals(invite=True, compose=True, labeled_action=True),
                    self._signals(),
                ],
            ),
            patch.object(
                extractor,
                "_open_more_menu",
                new_callable=AsyncMock,
                return_value=True,
            ) as mock_open_more,
            patch.object(
                extractor, "_navigate_to_page", new_callable=AsyncMock
            ) as mock_nav,
            patch.object(
                extractor,
                "_dialog_is_open",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_click_dialog_primary_button",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connected"
        mock_open_more.assert_awaited_once()
        # Deeplink fired exactly once.
        assert mock_nav.await_count == 1
        await_args = mock_nav.await_args
        assert await_args is not None
        assert "preload/custom-invite" in await_args.args[0]

    async def test_follow_only_after_more_does_not_send(self, mock_page):
        """Pending or genuinely follow-only profile: invite anchor never
        appears even after More-menu open. Critical write-gate guardrail —
        no deeplink fires, no connection request goes out."""
        extractor = LinkedInExtractor(mock_page)
        text = "Public Figure\n\n· 3rd+\n\nCEO\n\nFollow\nMessage\nMore\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                # Both reads (initial + post-More) show no invite anchor.
                side_effect=[
                    self._signals(compose=True, labeled_action=True),
                    self._signals(compose=True, labeled_action=True),
                ],
            ),
            patch.object(
                extractor,
                "_open_more_menu",
                new_callable=AsyncMock,
                return_value=True,
            ) as mock_open_more,
            patch.object(
                extractor, "_navigate_to_page", new_callable=AsyncMock
            ) as mock_nav,
            patch.object(
                extractor, "_submit_invite_dialog", new_callable=AsyncMock
            ) as mock_submit,
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connect_unavailable"
        assert result.get("note_sent") is False or "note_sent" not in result
        mock_open_more.assert_awaited_once()
        # Critical: deeplink must NOT fire and dialog must NOT be submitted.
        mock_nav.assert_not_awaited()
        mock_submit.assert_not_awaited()

    async def test_more_menu_unavailable_does_not_send(self, mock_page):
        """Action root present but no More button (unusual but possible):
        _open_more_menu returns False, no retry, no deeplink fires."""
        extractor = LinkedInExtractor(mock_page)
        text = "Public Figure\n\n· 3rd+\n\nCEO\n\nFollow\nMessage\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(compose=True, labeled_action=True),
            ),
            patch.object(
                extractor,
                "_open_more_menu",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch.object(
                extractor, "_navigate_to_page", new_callable=AsyncMock
            ) as mock_nav,
            patch.object(
                extractor, "_submit_invite_dialog", new_callable=AsyncMock
            ) as mock_submit,
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "connect_unavailable"
        mock_nav.assert_not_awaited()
        mock_submit.assert_not_awaited()

    async def test_returns_pending(self, mock_page):
        """Profile with a pending invitation: detected via labeled <a> in
        the action root. Returns status='pending' without firing the
        deeplink (LinkedIn would only show 'already invited' anyway)."""
        extractor = LinkedInExtractor(mock_page)
        text = "Frank\n\n· 3rd\n\nFounder\n\nMessage\nPending\nMore\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(compose=True, labeled_anchor=True),
            ),
            patch.object(
                extractor, "_navigate_to_page", new_callable=AsyncMock
            ) as mock_nav,
            patch.object(
                extractor, "_submit_invite_dialog", new_callable=AsyncMock
            ) as mock_submit,
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "pending"
        # No write-path side effects.
        mock_nav.assert_not_awaited()
        mock_submit.assert_not_awaited()

    async def test_returns_incoming_request_accepted(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        pre = "Aklasur\n\n--\n\nDhaka\n\nAccept\nIgnore\nMore\nAbout\n"
        post = "Aklasur\n\n· 1st\n\nDhaka\n\nMessage\nMore\nAbout\n"

        with (
            patch.object(
                extractor,
                "scrape_person",
                self._mock_scrape(pre, follow_up_text=post),
            ),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                side_effect=[self._signals(), self._signals(compose=True)],
            ),
            patch.object(
                extractor,
                "click_button_by_text",
                new_callable=AsyncMock,
                return_value=True,
            ) as mock_click,
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "accepted"
        mock_click.assert_awaited_once_with("Accept", scope="main")

    async def test_incoming_request_send_failed_when_no_first_degree(self, mock_page):
        """Accept clicked but profile never transitions to 1st-degree."""
        extractor = LinkedInExtractor(mock_page)
        pre = "Aklasur\n\n--\n\nDhaka\n\nAccept\nIgnore\nMore\nAbout\n"

        with (
            patch.object(
                extractor,
                "scrape_person",
                self._mock_scrape(pre, follow_up_text=pre),
            ),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                side_effect=[self._signals(), self._signals()],
            ),
            patch.object(
                extractor,
                "click_button_by_text",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "send_failed"

    async def test_returns_unavailable_when_no_signals_and_text(self, mock_page):
        """No structural signals, no actionable text → connect_unavailable."""
        extractor = LinkedInExtractor(mock_page)
        text = "Public Figure\n\n· 3rd+\n\nCEO\n\nFollow\nMore\nAbout\n"

        with (
            patch.object(extractor, "scrape_person", self._mock_scrape(text)),
            patch.object(
                extractor,
                "_read_action_signals",
                new_callable=AsyncMock,
                return_value=self._signals(),
            ),
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch.object(
                extractor, "_dialog_is_open", new_callable=AsyncMock, return_value=False
            ),
            patch.object(extractor, "_dismiss_dialog", new_callable=AsyncMock),
        ):
            result = await extractor.connect_with_person("testuser")

        # follow_only path goes through deeplink; no dialog opens → unavailable
        assert result["status"] == "connect_unavailable"

    async def test_returns_unavailable_on_empty_page(self, mock_page):
        extractor = LinkedInExtractor(mock_page)

        with patch.object(
            extractor,
            "scrape_person",
            AsyncMock(
                return_value={
                    "url": "https://www.linkedin.com/in/testuser/",
                    "sections": {},
                }
            ),
        ):
            result = await extractor.connect_with_person("testuser")

        assert result["status"] == "unavailable"

    async def test_references_are_grouped_by_section(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                side_effect=[
                    extracted(
                        "profile text",
                        [
                            {
                                "kind": "person",
                                "url": "/in/testuser/",
                                "text": "Test User",
                            }
                        ],
                    ),
                    extracted(
                        "post text",
                        [
                            {
                                "kind": "article",
                                "url": "/pulse/test-post/",
                                "text": "Test post",
                            }
                        ],
                    ),
                ],
            ),
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"posts"})

        assert result["references"] == {
            "main_profile": [
                {"kind": "person", "url": "/in/testuser/", "text": "Test User"}
            ],
            "posts": [
                {"kind": "article", "url": "/pulse/test-post/", "text": "Test post"}
            ],
        }

    async def test_error_isolation(self, mock_page):
        """One section failing doesn't block others."""

        async def extract_with_failure(url, *args, **kwargs):
            if "experience" in url:
                raise Exception("Simulated failure")
            return extracted(f"text for {url}")

        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                side_effect=extract_with_failure,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_issue_diagnostics",
                return_value={"issue_template_path": "/tmp/issue.md"},
            ),
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person(
                "testuser", {"main_profile", "experience", "education"}
            )

        # main_profile and education should have sections, experience should not
        assert "main_profile" in result["sections"]
        assert "education" in result["sections"]
        assert "experience" not in result["sections"]
        assert result["section_errors"]["experience"]["issue_template_path"] == (
            "/tmp/issue.md"
        )

    async def test_rate_limited_sections_are_omitted(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                side_effect=[
                    extracted(_RATE_LIMITED_MSG),
                    extracted("Post text"),
                ],
            ),
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"posts"})

        assert "main_profile" not in result["sections"]
        assert result["sections"]["posts"] == "Post text"


class TestScrapeCompany:
    async def test_company_baseline_always_included(self, mock_page):
        """Passing only posts still visits about page."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_company("testcorp", {"posts"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert any("/about/" in u for u in urls)
        assert any("/posts/" in u for u in urls)
        assert "about" in result["sections"]
        assert "posts" in result["sections"]

    async def test_about_only_visits_about(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("about text"),
            ) as mock_extract,
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_company("testcorp", {"about"})

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert len(urls) == 1
        assert "/about/" in urls[0]
        assert set(result["sections"]) == {"about"}

    async def test_all_sections_visit_correct_urls(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_company(
                "testcorp", {"about", "posts", "jobs"}
            )

        urls = [call.args[0] for call in mock_extract.call_args_list]
        assert len(urls) == 3
        assert any("/about/" in u for u in urls)
        assert any("/posts/" in u for u in urls)
        assert any("/jobs/" in u for u in urls)
        assert set(result["sections"]) == {"about", "posts", "jobs"}

    async def test_rate_limited_company_sections_are_omitted(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                side_effect=[
                    extracted(_RATE_LIMITED_MSG),
                    extracted("Posts text"),
                ],
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_company("testcorp", {"posts"})

        assert "about" not in result["sections"]
        assert result["sections"]["posts"] == "Posts text"


class TestScrapeJob:
    async def test_scrape_job(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with patch.object(
            extractor,
            "extract_page",
            new_callable=AsyncMock,
            return_value=extracted("Job: Software Engineer"),
        ):
            result = await extractor.scrape_job("12345")

        assert result["url"] == "https://www.linkedin.com/jobs/view/12345/"
        assert "job_posting" in result["sections"]
        assert "pages_visited" not in result
        assert "sections_requested" not in result

    async def test_scrape_job_omits_rate_limited_sentinel(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with patch.object(
            extractor,
            "extract_page",
            new_callable=AsyncMock,
            return_value=extracted(_RATE_LIMITED_MSG),
        ):
            result = await extractor.scrape_job("12345")

        assert result["sections"] == {}

    async def test_scrape_job_omits_orphaned_references_when_text_empty(
        self, mock_page
    ):
        extractor = LinkedInExtractor(mock_page)
        with patch.object(
            extractor,
            "extract_page",
            new_callable=AsyncMock,
            return_value=extracted(
                "",
                [{"kind": "job", "url": "/jobs/view/12345/", "text": "Engineer"}],
            ),
        ):
            result = await extractor.scrape_job("12345")

        assert result["sections"] == {}
        assert "references" not in result


class TestSearchJobs:
    """Tests for search_jobs with job ID extraction and pagination."""

    @pytest.fixture(autouse=True)
    def _set_search_url(self, mock_page):
        mock_page.url = "https://www.linkedin.com/jobs/search/?keywords=python"

    async def test_returns_job_ids(self, mock_page):
        """search_jobs should return a job_ids list extracted from hrefs."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("Job 1\nJob 2\nJob 3"),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=["111", "222", "333"],
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=1)

        assert result["job_ids"] == ["111", "222", "333"]
        assert "search_results" in result["sections"]

    async def test_returns_references(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted(
                    "Job 1",
                    [{"kind": "job", "url": "/jobs/view/111/", "text": "Job 1"}],
                ),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=["111"],
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=1)

        assert result["references"] == {
            "search_results": [
                {"kind": "job", "url": "/jobs/view/111/", "text": "Job 1"}
            ]
        }

    async def test_pagination_uses_fixed_page_size(self, mock_page):
        """Pages use &start= with fixed 25-per-page offset."""
        extractor = LinkedInExtractor(mock_page)
        page1_ids = ["100", "200", "300"]
        page2_ids = ["400", "500"]
        id_pages = iter([page1_ids, page2_ids])
        text_pages = iter(["Page 1 text", "Page 2 text"])
        urls_visited: list[str] = []

        async def mock_extract(url, *args, **kwargs):
            urls_visited.append(url)
            return extracted(next(text_pages))

        with (
            patch.object(extractor, "_extract_search_page", side_effect=mock_extract),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                side_effect=lambda: next(id_pages),
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=2)

        assert result["job_ids"] == ["100", "200", "300", "400", "500"]
        assert len(urls_visited) == 2
        assert "&start=25" in urls_visited[1]

    async def test_deduplication_across_pages(self, mock_page):
        """Duplicate job IDs across pages should be deduplicated."""
        extractor = LinkedInExtractor(mock_page)
        id_pages = iter([["100", "200"], ["200", "300"]])
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                side_effect=lambda: next(id_pages),
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=2)

        assert result["job_ids"] == ["100", "200", "300"]
        assert mock_extract.await_count == 2

    async def test_early_stop_no_new_ids(self, mock_page):
        """Should stop early when a page yields no new job IDs."""
        extractor = LinkedInExtractor(mock_page)
        # Page 2 returns same IDs as page 1
        id_pages = iter([["100", "200"], ["100", "200"]])
        extract_call_count = 0

        async def mock_extract(url, *args, **kwargs):
            nonlocal extract_call_count
            extract_call_count += 1
            if extract_call_count == 1:
                return extracted(
                    "text",
                    [{"kind": "job", "url": "/jobs/view/100/", "text": "Job 100"}],
                )
            return extracted(
                "text",
                [{"kind": "job", "url": "/jobs/view/200/", "text": "Job 200"}],
            )

        with (
            patch.object(extractor, "_extract_search_page", side_effect=mock_extract),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                side_effect=lambda: next(id_pages),
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=5)

        assert result["job_ids"] == ["100", "200"]
        assert extract_call_count == 2
        assert result["references"] == {
            "search_results": [
                {"kind": "job", "url": "/jobs/view/100/", "text": "Job 100"},
                {"kind": "job", "url": "/jobs/view/200/", "text": "Job 200"},
            ]
        }

    async def test_stops_at_total_pages(self, mock_page):
        """Should stop when total_pages from pagination state is reached."""
        extractor = LinkedInExtractor(mock_page)
        # Distinct IDs per page so the no-new-IDs guard never fires
        id_pages = iter([["100"], ["200"]])
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                side_effect=lambda: next(id_pages),
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=2,
            ) as mock_total_pages,
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=10)

        # Should only visit 2 pages despite max_pages=10
        assert mock_extract.await_count == 2
        assert mock_total_pages.await_count == 1
        assert result["job_ids"] == ["100", "200"]

    async def test_zero_max_pages_fetches_nothing(self, mock_page):
        """max_pages=0 should fetch zero pages (validation at tool boundary)."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=[],
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=0)

        assert result["job_ids"] == []
        assert mock_extract.await_count == 0

    async def test_single_page(self, mock_page):
        """max_pages=1 should only visit one page; filters appear in URL."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("Job posting text"),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=["42"],
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs(
                "python",
                "Remote",
                max_pages=1,
                date_posted="past_week",
                work_type="remote",
                easy_apply=True,
            )

        assert result["job_ids"] == ["42"]
        assert "keywords=python" in result["url"]
        assert "location=Remote" in result["url"]
        assert "f_TPR=r604800" in result["url"]
        assert "f_WT=2" in result["url"]
        assert "f_EA=true" in result["url"]
        assert mock_extract.await_count == 1

    async def test_page_texts_joined_with_separator(self, mock_page):
        """Multiple pages should join text with --- separator."""
        extractor = LinkedInExtractor(mock_page)
        text_pages = iter(["Page 1 content", "Page 2 content"])
        id_pages = iter([["100"], ["200"]])
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                side_effect=lambda url, *args, **kwargs: extracted(next(text_pages)),
            ) as mock_extract,
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                side_effect=lambda: next(id_pages),
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=2)

        assert "\n---\n" in result["sections"]["search_results"]
        assert "Page 1 content" in result["sections"]["search_results"]
        assert "Page 2 content" in result["sections"]["search_results"]
        assert mock_extract.await_count == 2

    async def test_empty_results(self, mock_page):
        """Should handle empty results gracefully and skip ID extraction."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted(""),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=[],
            ) as mock_ids,
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("nonexistent_xyz")

        assert result["job_ids"] == []
        assert result["sections"] == {}
        # Empty text should skip ID extraction to avoid stale DOM
        mock_ids.assert_not_awaited()

    async def test_no_ids_on_first_page_captures_text(self, mock_page):
        """Non-empty text with zero job IDs should be returned in sections."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted("No matching jobs found"),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=[],
            ),
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("xyzzy123", max_pages=1)

        assert result["job_ids"] == []
        assert result["sections"]["search_results"] == "No matching jobs found"

    async def test_url_redirect_skips_id_extraction(self, mock_page):
        """Unexpected page URL should skip ID extraction but capture text."""
        extractor = LinkedInExtractor(mock_page)
        mock_page.url = "https://www.linkedin.com/uas/login"
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted(
                    "Login page content",
                    [{"kind": "person", "url": "/in/testuser/", "text": "Test User"}],
                ),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=[],
            ) as mock_ids,
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=2)

        mock_ids.assert_not_awaited()
        assert result["job_ids"] == []
        assert result["sections"]["search_results"] == "Login page content"
        assert result["references"] == {
            "search_results": [
                {"kind": "person", "url": "/in/testuser/", "text": "Test User"}
            ]
        }

    async def test_rate_limited_skips_ids_and_text(self, mock_page):
        """Rate-limited pages should yield no IDs or text."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_extract_search_page",
                new_callable=AsyncMock,
                return_value=extracted(_RATE_LIMITED_MSG),
            ),
            patch.object(
                extractor,
                "_extract_job_ids",
                new_callable=AsyncMock,
                return_value=["100"],
            ) as mock_ids,
            patch.object(
                extractor,
                "_get_total_search_pages",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.search_jobs("python", max_pages=1)

        assert result["job_ids"] == []
        assert result["sections"] == {}
        mock_ids.assert_not_awaited()

    async def test_search_people_omits_orphaned_references(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        with patch.object(
            extractor,
            "extract_page",
            new_callable=AsyncMock,
            return_value=extracted(
                "",
                [
                    {
                        "kind": "person",
                        "url": "/in/testuser/",
                        "text": "Test User",
                    }
                ],
            ),
        ):
            result = await extractor.search_people("python")

        assert result["sections"] == {}
        assert "references" not in result


class TestStripLinkedInNoise:
    def test_strips_footer(self):
        text = "Bill Gates\nChair, Gates Foundation\n\nAbout\nAccessibility\nTalent Solutions\nCareers"
        assert strip_linkedin_noise(text) == "Bill Gates\nChair, Gates Foundation"

    def test_strips_footer_with_talent_solutions_variant(self):
        text = "Profile content here\n\nAbout\nTalent Solutions\nMore footer"
        assert strip_linkedin_noise(text) == "Profile content here"

    def test_strips_sidebar_recommendations(self):
        text = "Experience\nCo-chair\nGates Foundation\n\nMore profiles for you\nSundar Pichai\nCEO at Google"
        assert strip_linkedin_noise(text) == "Experience\nCo-chair\nGates Foundation"

    def test_strips_premium_upsell(self):
        text = "Education\nHarvard University\n\nExplore premium profiles\nRandom Person\nSoftware Engineer"
        assert strip_linkedin_noise(text) == "Education\nHarvard University"

    def test_picks_earliest_marker(self):
        text = "Content\n\nExplore premium profiles\nStuff\n\nMore profiles for you\nMore stuff\n\nAbout\nAccessibility"
        assert strip_linkedin_noise(text) == "Content"

    def test_no_noise_returns_unchanged(self):
        text = "Clean content with no LinkedIn chrome"
        assert strip_linkedin_noise(text) == "Clean content with no LinkedIn chrome"

    def test_empty_string(self):
        assert strip_linkedin_noise("") == ""

    def test_truncate_noise_preserves_media_controls_for_rate_limit_detection(self):
        text = "Play\nLoaded: 100.00%\nRemaining time 0:07\nShow captions"
        assert _truncate_linkedin_noise(text) == text
        assert strip_linkedin_noise(text) == ""

    def test_about_in_profile_content_not_stripped(self):
        """'About' followed by actual content (not 'Accessibility') should be preserved."""
        text = "About\nChair of the Gates Foundation.\n\nFeatured\nPost"
        assert (
            strip_linkedin_noise(text)
            == "About\nChair of the Gates Foundation.\n\nFeatured\nPost"
        )

    def test_real_footer_with_languages(self):
        text = (
            "Company info\n\n"
            "About\nAccessibility\nTalent Solutions\nCareers\n"
            "Select language\nEnglish (English)\nDeutsch (German)"
        )
        assert strip_linkedin_noise(text) == "Company info"

    def test_preserves_real_careers_content(self):
        text = "Careers\nWe're hiring globally.\nOpen roles in engineering and design."
        assert strip_linkedin_noise(text) == text

    def test_preserves_real_questions_content(self):
        text = "Questions?\nReach out to our recruiting team for details."
        assert strip_linkedin_noise(text) == text

    def test_strips_media_controls_lines(self):
        text = (
            "Feed post number 1\n"
            "Play\n"
            "Loaded: 100.00%\n"
            "Remaining time 0:07\n"
            "Playback speed\n"
            "Actual post content\n"
            "Show captions\n"
            "Close modal window"
        )
        assert strip_linkedin_noise(text) == "Feed post number 1\nActual post content"


class TestActivityFeedExtraction:
    """Tests for activity page detection and wait behavior in _extract_page_once."""

    async def test_activity_page_waits_for_content_and_uses_slow_scroll(
        self, mock_page
    ):
        """Activity URLs should call wait_for_function and use slower scroll params."""
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Post content " * 50,
                "references": [],
            }
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ) as mock_scroll,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/recent-activity/all/",
                section_name="posts",
            )

        mock_page.wait_for_function.assert_awaited_once()
        mock_scroll.assert_awaited_once()
        _, kwargs = mock_scroll.call_args
        assert kwargs["pause_time"] == 1.0
        assert kwargs["max_scrolls"] == 10
        assert len(result.text) > 200

    async def test_non_activity_non_details_page_skips_wait_and_uses_fast_scroll(
        self, mock_page
    ):
        """Plain profile URLs (not activity, search, or details) skip wait_for_function."""
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": "Profile text", "references": []}
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ) as mock_scroll,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/",
                section_name="main_profile",
            )

        mock_page.wait_for_function.assert_not_awaited()
        mock_scroll.assert_awaited_once()
        _, kwargs = mock_scroll.call_args
        assert kwargs["pause_time"] == 0.5
        assert kwargs["max_scrolls"] == 5

    async def test_details_page_waits_for_panel_content(self, mock_page):
        """Detail pages (/details/experience/ etc.) call wait_for_function to wait for the panel."""
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Experience\nSoftware Engineer",
                "references": [],
            }
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ) as mock_scroll,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/details/experience/",
                section_name="experience",
            )

        mock_page.wait_for_function.assert_awaited_once()
        mock_scroll.assert_awaited_once()
        _, kwargs = mock_scroll.call_args
        assert kwargs["pause_time"] == 0.5
        assert kwargs["max_scrolls"] == 5

    async def test_max_scrolls_override_passed_to_scroll_to_bottom(self, mock_page):
        """Custom max_scrolls on a detail page overrides the default of 5."""
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Experience\nSoftware Engineer",
                "references": [],
            }
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ) as mock_scroll,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/details/certifications/",
                section_name="certifications",
                max_scrolls=20,
            )

        mock_scroll.assert_awaited_once()
        _, kwargs = mock_scroll.call_args
        assert kwargs["max_scrolls"] == 20

    async def test_default_scrolls_without_max_scrolls_override(self, mock_page):
        """Without max_scrolls, detail pages use the default of 5."""
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Experience\nSoftware Engineer",
                "references": [],
            }
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ) as mock_scroll,
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/details/certifications/",
                section_name="certifications",
            )

        mock_scroll.assert_awaited_once()
        _, kwargs = mock_scroll.call_args
        assert kwargs["max_scrolls"] == 5

    async def test_details_page_clicks_show_more_until_gone(self, mock_page):
        """Detail pages click 'Show more' in a loop until the button disappears."""
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": "text", "references": []}
        )
        mock_page.wait_for_function = AsyncMock()

        show_more = MagicMock()
        # count() returns 1, 1, 0 across iterations — button disappears on 3rd check
        show_more.count = AsyncMock(side_effect=[1, 1, 0])
        show_more.is_visible = AsyncMock(return_value=True)
        show_more.scroll_into_view_if_needed = AsyncMock()
        show_more.click = AsyncMock()
        show_more.first = show_more
        show_more.filter = MagicMock(return_value=show_more)

        def locator_side_effect(selector):
            if selector == "main button":
                return show_more
            return MagicMock(count=AsyncMock(return_value=0))

        mock_page.locator = MagicMock(side_effect=locator_side_effect)
        extractor = LinkedInExtractor(mock_page)

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/details/certifications/",
                section_name="certifications",
            )

        assert show_more.click.await_count == 2

    async def test_details_page_show_more_respects_max_scrolls_budget(self, mock_page):
        """When 'Show more' never disappears, loop exits after max_scrolls clicks."""
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": "text", "references": []}
        )
        mock_page.wait_for_function = AsyncMock()

        show_more = MagicMock()
        show_more.count = AsyncMock(return_value=1)  # always present
        show_more.is_visible = AsyncMock(return_value=True)
        show_more.scroll_into_view_if_needed = AsyncMock()
        show_more.click = AsyncMock()
        show_more.first = show_more
        show_more.filter = MagicMock(return_value=show_more)

        def locator_side_effect(selector):
            if selector == "main button":
                return show_more
            return MagicMock(count=AsyncMock(return_value=0))

        mock_page.locator = MagicMock(side_effect=locator_side_effect)
        extractor = LinkedInExtractor(mock_page)

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/details/experience/",
                section_name="experience",
                max_scrolls=3,
            )

        assert show_more.click.await_count == 3

    async def test_non_details_page_does_not_click_show_more(self, mock_page):
        """Non-details URLs (main profile, activity) skip the Show more loop."""
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": "text", "references": []}
        )
        mock_page.wait_for_function = AsyncMock()

        show_more = MagicMock()
        show_more.count = AsyncMock(return_value=1)
        show_more.click = AsyncMock()
        show_more.first = show_more
        show_more.filter = MagicMock(return_value=show_more)

        def locator_side_effect(selector):
            if selector == "main button":
                return show_more
            return MagicMock(count=AsyncMock(return_value=0))

        mock_page.locator = MagicMock(side_effect=locator_side_effect)
        extractor = LinkedInExtractor(mock_page)

        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/",
                section_name="main_profile",
            )

        show_more.click.assert_not_awaited()

    async def test_activity_page_timeout_proceeds_gracefully(self, mock_page):
        """When activity feed content never loads, extraction proceeds with available text."""
        from patchright.async_api import TimeoutError as PlaywrightTimeoutError

        tab_headers = "All activity\nPosts\nComments\nVideos\nImages"
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": tab_headers, "references": []}
        )
        mock_page.wait_for_function = AsyncMock(
            side_effect=PlaywrightTimeoutError("Timeout")
        )
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/recent-activity/all/",
                section_name="posts",
            )

        # Should return whatever text is available, not crash
        assert result.text == tab_headers


class TestSearchResultsExtraction:
    """Tests for search results page detection and wait behavior in _extract_page_once."""

    async def test_search_results_page_waits_for_content(self, mock_page):
        """Search results URLs should call wait_for_function to wait for content."""
        mock_page.evaluate = AsyncMock(
            return_value={
                "source": "root",
                "text": "Search results for John Doe. " * 10,
                "references": [],
            }
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor._extract_page_once(
                "https://www.linkedin.com/search/results/people/?keywords=John+Doe",
                section_name="search_results",
            )

        mock_page.wait_for_function.assert_awaited_once()
        assert len(result.text) > 100

    async def test_non_search_page_does_not_wait_for_search_content(self, mock_page):
        """Non-search URLs should not trigger the search results wait."""
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": "Profile text", "references": []}
        )
        mock_page.wait_for_function = AsyncMock()
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            await extractor._extract_page_once(
                "https://www.linkedin.com/in/billgates/",
                section_name="main_profile",
            )

        mock_page.wait_for_function.assert_not_awaited()

    async def test_search_results_timeout_proceeds_gracefully(self, mock_page):
        """When search results never load, extraction proceeds with available text."""
        from patchright.async_api import TimeoutError as PlaywrightTimeoutError

        placeholder = "Search results for John Doe. No results found"
        mock_page.evaluate = AsyncMock(
            return_value={"source": "root", "text": placeholder, "references": []}
        )
        mock_page.wait_for_function = AsyncMock(
            side_effect=PlaywrightTimeoutError("Timeout")
        )
        extractor = LinkedInExtractor(mock_page)
        with (
            patch(
                "linkedin_mcp_server.scraping.extractor.scroll_to_bottom",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor._extract_page_once(
                "https://www.linkedin.com/search/results/people/?keywords=John+Doe",
                section_name="search_results",
            )

        assert result.text == placeholder


class TestScrapePersonCallbacks:
    """Test that scrape_person invokes callbacks at each stage."""

    async def test_scrape_person_calls_callbacks(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        cb = MagicMock(spec=ProgressCallback)
        cb.on_start = AsyncMock()
        cb.on_progress = AsyncMock()
        cb.on_complete = AsyncMock()
        cb.on_error = AsyncMock()

        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ),
            patch.object(
                extractor,
                "_extract_overlay",
                new_callable=AsyncMock,
                return_value=extracted("overlay text"),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            await extractor.scrape_person(
                "testuser", {"experience", "education"}, callbacks=cb
            )

        cb.on_start.assert_awaited_once()
        assert cb.on_start.call_args[0][0] == "person profile"

        # 3 sections: main_profile (always) + experience + education
        assert cb.on_progress.await_count == 3
        messages = [c.args[0] for c in cb.on_progress.call_args_list]
        assert messages == [
            "Scraped main_profile (1/3)",
            "Scraped experience (2/3)",
            "Scraped education (3/3)",
        ]
        # Last section should be at 95%
        assert cb.on_progress.call_args_list[-1].args[1] == 95

        cb.on_complete.assert_awaited_once()
        assert cb.on_complete.call_args[0][0] == "person profile"
        cb.on_error.assert_not_awaited()

    async def test_scrape_person_no_callbacks_by_default(self, mock_page):
        """Without callbacks, scrape_person works identically to before."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"main_profile"})

        assert "main_profile" in result["sections"]

    async def test_scrape_person_calls_on_error(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        cb = MagicMock(spec=ProgressCallback)
        cb.on_start = AsyncMock()
        cb.on_progress = AsyncMock()
        cb.on_complete = AsyncMock()
        cb.on_error = AsyncMock()

        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                side_effect=LinkedInScraperException("boom"),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            with pytest.raises(LinkedInScraperException):
                await extractor.scrape_person(
                    "testuser", {"main_profile"}, callbacks=cb
                )

        cb.on_start.assert_awaited_once()
        cb.on_error.assert_awaited_once()
        error_arg = cb.on_error.call_args[0][0]
        assert isinstance(error_arg, LinkedInScraperException)
        assert "boom" in str(error_arg)
        cb.on_complete.assert_not_awaited()


class TestScrapeCompanyCallbacks:
    """Test that scrape_company invokes callbacks at each stage."""

    async def test_scrape_company_calls_callbacks(self, mock_page):
        extractor = LinkedInExtractor(mock_page)
        cb = MagicMock(spec=ProgressCallback)
        cb.on_start = AsyncMock()
        cb.on_progress = AsyncMock()
        cb.on_complete = AsyncMock()
        cb.on_error = AsyncMock()

        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("text"),
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            await extractor.scrape_company(
                "testcorp", {"about", "posts", "jobs"}, callbacks=cb
            )

        cb.on_start.assert_awaited_once()
        assert cb.on_start.call_args[0][0] == "company profile"

        # 3 sections: about + posts + jobs
        assert cb.on_progress.await_count == 3
        messages = [c.args[0] for c in cb.on_progress.call_args_list]
        assert messages == [
            "Scraped about (1/3)",
            "Scraped posts (2/3)",
            "Scraped jobs (3/3)",
        ]
        assert cb.on_progress.call_args_list[-1].args[1] == 95

        cb.on_complete.assert_awaited_once()
        assert cb.on_complete.call_args[0][0] == "company profile"
        cb.on_error.assert_not_awaited()


class TestGetSidebarProfiles:
    async def test_returns_sidebar_profiles_from_all_sections(self, mock_page):
        """Happy path: extracts profiles from all sections, merges Show all results."""
        sidebar_js_result = {
            "sections": {
                "more_profiles_for_you": ["/in/alice/", "/in/bob/"],
                "explore_premium_profiles": ["/in/carol/"],
                "people_you_may_know": ["/in/dave/"],
            },
            "showAllUrls": {
                "more_profiles_for_you": "https://www.linkedin.com/search/results/people/?keywords=test",
            },
        }
        show_all_js_result = ["/in/alice/", "/in/eve/", "/in/frank/"]

        mock_page.evaluate = AsyncMock(
            side_effect=[sidebar_js_result, show_all_js_result]
        )
        mock_page.url = "https://www.linkedin.com/in/testuser/"

        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.get_sidebar_profiles("testuser")

        assert result["url"] == "https://www.linkedin.com/in/testuser/"
        mpfy = result["sidebar_profiles"]["more_profiles_for_you"]
        # sidebar links first, then show_all expansion, deduped
        assert mpfy == ["/in/alice/", "/in/bob/", "/in/eve/", "/in/frank/"]
        assert result["sidebar_profiles"]["explore_premium_profiles"] == ["/in/carol/"]
        assert result["sidebar_profiles"]["people_you_may_know"] == ["/in/dave/"]

    async def test_skips_show_all_when_url_contains_premium(self, mock_page):
        """Show all URL containing /premium is skipped without navigation."""
        sidebar_js_result = {
            "sections": {"explore_premium_profiles": ["/in/carol/"]},
            "showAllUrls": {
                "explore_premium_profiles": "https://www.linkedin.com/premium/products/"
            },
        }
        mock_page.evaluate = AsyncMock(return_value=sidebar_js_result)
        mock_page.url = "https://www.linkedin.com/in/testuser/"

        extractor = LinkedInExtractor(mock_page)
        navigate_mock = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", navigate_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor.get_sidebar_profiles("testuser")

        navigate_mock.assert_awaited_once()  # only the initial profile navigation
        mock_page.evaluate.assert_awaited_once()  # no show_all JS call
        assert result["sidebar_profiles"]["explore_premium_profiles"] == ["/in/carol/"]

    async def test_skips_show_all_when_page_redirects_to_premium(self, mock_page):
        """If navigating to Show all lands on a /premium URL, skip that section."""
        sidebar_js_result = {
            "sections": {"more_profiles_for_you": ["/in/alice/"]},
            "showAllUrls": {
                "more_profiles_for_you": "https://www.linkedin.com/search/results/people/?keywords=test"
            },
        }
        mock_page.evaluate = AsyncMock(return_value=sidebar_js_result)
        mock_page.url = "https://www.linkedin.com/in/testuser/"

        navigate_call_count = 0

        async def fake_navigate(url: str) -> None:
            nonlocal navigate_call_count
            navigate_call_count += 1
            if navigate_call_count >= 2:
                mock_page.url = "https://www.linkedin.com/premium/grow-your-network/"

        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", side_effect=fake_navigate),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.get_sidebar_profiles("testuser")

        mock_page.evaluate.assert_awaited_once()  # sidebar JS only, no show_all expansion
        assert result["sidebar_profiles"]["more_profiles_for_you"] == ["/in/alice/"]

    async def test_returns_empty_sidebar_profiles_when_no_sections_found(
        self, mock_page
    ):
        """No matching sidebar headings -> empty sidebar_profiles dict."""
        mock_page.evaluate = AsyncMock(return_value={"sections": {}, "showAllUrls": {}})
        mock_page.url = "https://www.linkedin.com/in/testuser/"

        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await extractor.get_sidebar_profiles("testuser")

        assert result == {
            "url": "https://www.linkedin.com/in/testuser/",
            "sidebar_profiles": {},
        }


class TestExtractProfileUrn:
    async def test_returns_urn_from_compose_href(self, mock_page):
        """Extracts the recipient URN from the messaging compose link."""
        mock_page.evaluate = AsyncMock(
            return_value="/messaging/compose/?recipient=ACoAAB1IelEBLEkqTkNbZ-a1D8mq5R-6C1ihSEk&lipi=urn..."
        )

        extractor = LinkedInExtractor(mock_page)
        result = await extractor._extract_profile_urn()

        assert result == "ACoAAB1IelEBLEkqTkNbZ-a1D8mq5R-6C1ihSEk"

    async def test_returns_none_when_no_compose_button(self, mock_page):
        """Returns None when no messaging compose link is found."""
        mock_page.evaluate = AsyncMock(return_value=None)

        extractor = LinkedInExtractor(mock_page)
        result = await extractor._extract_profile_urn()

        assert result is None

    async def test_returns_none_when_no_recipient_param(self, mock_page):
        """Returns None when the compose href has no recipient query param."""
        mock_page.evaluate = AsyncMock(
            return_value="/messaging/compose/?someOtherParam=value"
        )

        extractor = LinkedInExtractor(mock_page)
        result = await extractor._extract_profile_urn()

        assert result is None


class TestScrapePersonProfileUrn:
    async def test_includes_profile_urn_in_result_when_found(self, mock_page):
        """scrape_person includes profile_urn in result when _extract_profile_urn returns a value."""
        urn = "ACoAAB1IelEBLEkqTkNbZ-a1D8mq5R-6C1ihSEk"
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("profile text"),
            ),
            patch.object(
                extractor,
                "_extract_profile_urn",
                new_callable=AsyncMock,
                return_value=urn,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"main_profile"})

        assert result["profile_urn"] == urn

    async def test_omits_profile_urn_when_not_found(self, mock_page):
        """scrape_person omits profile_urn key when _extract_profile_urn returns None."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "extract_page",
                new_callable=AsyncMock,
                return_value=extracted("profile text"),
            ),
            patch.object(
                extractor,
                "_extract_profile_urn",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.scrape_person("testuser", {"main_profile"})

        assert "profile_urn" not in result


class TestGetInbox:
    async def test_returns_inbox_section(self, mock_page):
        """get_inbox returns sections with inbox key."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(
                extractor,
                "_navigate_to_page",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_wait_for_main_text",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_scroll_main_scrollable_region",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={
                    "text": "Conversation A\nConversation B",
                    "references": [],
                },
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="Conversation A\nConversation B",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=[],
            ),
        ):
            result = await extractor.get_inbox(limit=10)

        assert "sections" in result
        assert "inbox" in result["sections"]
        assert "Conversation A" in result["sections"]["inbox"]

    async def test_empty_inbox(self, mock_page):
        """get_inbox returns empty sections when page has no content."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor, "_scroll_main_scrollable_region", new_callable=AsyncMock
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="",
            ),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=[],
            ),
        ):
            result = await extractor.get_inbox(limit=5)

        assert result["sections"] == {}

    async def test_includes_conversation_thread_refs(self, mock_page):
        """get_inbox prepends conversation thread references from click extraction."""
        extractor = LinkedInExtractor(mock_page)
        thread_refs = [
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-abc123/",
                "text": "Tony Chan",
                "context": "inbox",
            },
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-def456/",
                "text": "Paul Jasper",
                "context": "inbox",
            },
        ]
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor, "_scroll_main_scrollable_region", new_callable=AsyncMock
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={
                    "text": "Tony Chan\nPaul Jasper",
                    "references": [],
                },
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="Tony Chan\nPaul Jasper",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=thread_refs,
            ),
        ):
            result = await extractor.get_inbox(limit=10)

        assert "references" in result
        refs = result["references"]["inbox"]
        assert len(refs) == 2
        assert refs[0]["kind"] == "conversation"
        assert refs[0]["url"] == "/messaging/thread/2-abc123/"
        assert refs[0]["text"] == "Tony Chan"


class TestGetConversation:
    async def test_returns_conversation_by_thread_id(self, mock_page):
        """get_conversation with thread_id navigates directly to thread URL."""
        extractor = LinkedInExtractor(mock_page)
        nav_mock = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", nav_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor, "_scroll_main_scrollable_region", new_callable=AsyncMock
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "Hello!\nHi there!", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="Hello!\nHi there!",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
        ):
            result = await extractor.get_conversation(thread_id="abc123")

        nav_mock.assert_awaited_once_with(
            "https://www.linkedin.com/messaging/thread/abc123/"
        )
        assert result["sections"]["conversation"] == "Hello!\nHi there!"

    async def test_raises_when_no_identifier(self, mock_page):
        """get_conversation raises LinkedInScraperException with no args."""
        extractor = LinkedInExtractor(mock_page)
        with pytest.raises(LinkedInScraperException):
            await extractor.get_conversation()

    async def test_by_username_default_index_picks_first_thread(self, mock_page):
        """get_conversation by username opens the 0th matching thread by default."""
        extractor = LinkedInExtractor(mock_page)
        nav_mock = AsyncMock()
        mock_page.wait_for_selector = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", nav_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor, "_scroll_main_scrollable_region", new_callable=AsyncMock
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Jacki McMahan",
            ),
            patch.object(
                extractor,
                "_resolve_conversation_thread_urls",
                new_callable=AsyncMock,
                return_value=[
                    "https://www.linkedin.com/messaging/thread/2-newer/",
                    "https://www.linkedin.com/messaging/thread/2-older/",
                ],
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "msg", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="msg",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
        ):
            await extractor.get_conversation(linkedin_username="jacki-old")

        target_calls = [
            c.args[0]
            for c in nav_mock.call_args_list
            if c.args and "/messaging/thread/" in c.args[0]
        ]
        assert target_calls == ["https://www.linkedin.com/messaging/thread/2-newer/"]

    async def test_by_username_index_picks_specified_thread(self, mock_page):
        """get_conversation by username + index opens the i-th matching thread."""
        extractor = LinkedInExtractor(mock_page)
        nav_mock = AsyncMock()
        mock_page.wait_for_selector = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", nav_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor, "_scroll_main_scrollable_region", new_callable=AsyncMock
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Jacki McMahan",
            ),
            patch.object(
                extractor,
                "_resolve_conversation_thread_urls",
                new_callable=AsyncMock,
                return_value=[
                    "https://www.linkedin.com/messaging/thread/2-newer/",
                    "https://www.linkedin.com/messaging/thread/2-older/",
                ],
            ),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "msg", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="msg",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
        ):
            await extractor.get_conversation(linkedin_username="jacki-old", index=1)

        target_calls = [
            c.args[0]
            for c in nav_mock.call_args_list
            if c.args and "/messaging/thread/" in c.args[0]
        ]
        assert target_calls == ["https://www.linkedin.com/messaging/thread/2-older/"]

    async def test_by_username_index_out_of_range_raises(self, mock_page):
        """get_conversation raises when index exceeds the number of threads."""
        extractor = LinkedInExtractor(mock_page)
        mock_page.wait_for_selector = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Jacki McMahan",
            ),
            patch.object(
                extractor,
                "_resolve_conversation_thread_urls",
                new_callable=AsyncMock,
                return_value=[
                    "https://www.linkedin.com/messaging/thread/2-only/",
                ],
            ),
        ):
            with pytest.raises(LinkedInScraperException, match="out of range"):
                await extractor.get_conversation(linkedin_username="jacki-old", index=5)

    async def test_by_username_no_threads_raises_could_not_find(self, mock_page):
        """get_conversation raises 'Could not find a conversation' when none exist."""
        extractor = LinkedInExtractor(mock_page)
        mock_page.wait_for_selector = AsyncMock()
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Jacki McMahan",
            ),
            patch.object(
                extractor,
                "_resolve_conversation_thread_urls",
                new_callable=AsyncMock,
                return_value=[],
            ),
        ):
            with pytest.raises(
                LinkedInScraperException, match="Could not find a conversation"
            ):
                await extractor.get_conversation(linkedin_username="jacki-old")


class TestStripSelectConversationPrefix:
    def test_strips_en_us_prefix(self):
        """Best-effort strip removes the en-US 'Select conversation with ' prefix."""
        assert (
            LinkedInExtractor._strip_select_conversation_prefix(
                "Select conversation with Jacki McMahan"
            )
            == "Jacki McMahan"
        )

    def test_case_insensitive(self):
        assert (
            LinkedInExtractor._strip_select_conversation_prefix(
                "select conversation with jacki mcmahan"
            )
            == "jacki mcmahan"
        )

    def test_returns_full_aria_when_prefix_absent(self):
        """In a non-en-US locale the verb prefix won't match; return as-is so
        downstream matching can endsWith / endswith on the participant name."""
        assert (
            LinkedInExtractor._strip_select_conversation_prefix(
                "Konversation auswählen mit Jacki McMahan"
            )
            == "Konversation auswählen mit Jacki McMahan"
        )

    def test_empty_input(self):
        assert LinkedInExtractor._strip_select_conversation_prefix("") == ""


class TestResolveConversationThreadUrls:
    async def test_url_driven_search_and_exact_aria_match(self, mock_page):
        """_resolve_conversation_thread_urls drives search via URL parameter
        and matches participant by exact aria-label rather than substring."""
        extractor = LinkedInExtractor(mock_page)
        nav_mock = AsyncMock()
        thread_refs = [
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-aaa/",
                "text": "Jacki McMahan",  # exact match
                "context": "search",
            },
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-bbb/",
                "text": "Jacki McMahan-Group",  # extra suffix → not exact
                "context": "search",
            },
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-ccc/",
                "text": "Jacki McMahan",  # second exact match (multi-thread case)
                "context": "search",
            },
        ]
        with (
            patch.object(extractor, "_navigate_to_page", nav_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=thread_refs,
            ),
        ):
            urls = await extractor._resolve_conversation_thread_urls("Jacki McMahan")

        nav_mock.assert_awaited_once_with(
            "https://www.linkedin.com/messaging/?searchTerm=Jacki+McMahan"
        )
        assert urls == [
            "https://www.linkedin.com/messaging/thread/2-aaa/",
            "https://www.linkedin.com/messaging/thread/2-ccc/",
        ]


class TestSearchConversations:
    async def test_returns_search_results(self, mock_page):
        """search_conversations returns search_results section."""
        extractor = LinkedInExtractor(mock_page)
        nav_mock = AsyncMock()

        with (
            patch.object(extractor, "_navigate_to_page", nav_mock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "Result 1\nResult 2", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="Result 1\nResult 2",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=[],
            ),
        ):
            result = await extractor.search_conversations("hello world")

        assert "search_results" in result["sections"]
        assert "Result 1" in result["sections"]["search_results"]
        # Search must be driven by the searchTerm URL parameter, not by typing
        # into the searchbox -- the URL form is reliable across SPA mounts and
        # preserves the search filter across click-to-capture navigations.
        nav_mock.assert_awaited_once_with(
            "https://www.linkedin.com/messaging/?searchTerm=hello+world"
        )

    async def test_includes_conversation_thread_refs(self, mock_page):
        """search_conversations exposes per-result thread URLs as references."""
        extractor = LinkedInExtractor(mock_page)
        thread_refs = [
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-abc/",
                "text": "Jacki McMahan",
                "context": "search_results",
            },
            {
                "kind": "conversation",
                "url": "/messaging/thread/2-def/",
                "text": "Jacki McMahan",
                "context": "search_results",
            },
        ]
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(extractor, "_wait_for_main_text", new_callable=AsyncMock),
            patch.object(
                extractor,
                "_extract_root_content",
                new_callable=AsyncMock,
                return_value={"text": "Jacki McMahan\nJacki McMahan", "references": []},
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.strip_linkedin_noise",
                return_value="Jacki McMahan\nJacki McMahan",
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.build_references",
                return_value=[],
            ),
            patch.object(
                extractor,
                "_extract_conversation_thread_refs",
                new_callable=AsyncMock,
                return_value=thread_refs,
            ) as mock_refs,
        ):
            result = await extractor.search_conversations("Jacki")

        mock_refs.assert_awaited_once_with(limit=20, context="search_results")
        refs = result["references"]["search_results"]
        assert len(refs) == 2
        assert {ref["url"] for ref in refs} == {
            "/messaging/thread/2-abc/",
            "/messaging/thread/2-def/",
        }


class TestSendMessage:
    async def test_dry_run_returns_confirmation_required(self, mock_page):
        """send_message with confirm_send=False returns confirmation_required status."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Test User",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_href",
                new_callable=AsyncMock,
                return_value="https://www.linkedin.com/messaging/compose/?recipient=ACoAAB",
            ),
            patch.object(
                extractor,
                "_wait_for_message_surface",
                new_callable=AsyncMock,
                return_value="composer",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_box",
                new_callable=AsyncMock,
                return_value=MagicMock(),
            ),
            patch.object(
                extractor,
                "_compose_page_matches_recipient",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_dismiss_message_ui",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.send_message(
                "testuser", "Hello!", confirm_send=False
            )

        assert result["status"] == "confirmation_required"
        assert result["sent"] is False

    async def test_message_unavailable_when_no_compose_href(self, mock_page):
        """send_message returns message_unavailable when no compose URL found."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Test User",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_href",
                new_callable=AsyncMock,
                return_value=None,
            ),
        ):
            result = await extractor.send_message(
                "testuser", "Hello!", confirm_send=True
            )

        assert result["status"] == "message_unavailable"
        assert result["sent"] is False

    async def test_uses_profile_urn_when_provided(self, mock_page):
        """send_message builds compose URL from profile_urn without Message-button lookup."""
        extractor = LinkedInExtractor(mock_page)
        with (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Test User",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_href",
                new_callable=AsyncMock,
                return_value=None,
            ) as mock_resolve_href,
            patch.object(
                extractor,
                "_wait_for_message_surface",
                new_callable=AsyncMock,
                return_value="composer",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_box",
                new_callable=AsyncMock,
                return_value=MagicMock(),
            ),
            patch.object(
                extractor,
                "_compose_page_matches_recipient",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_dismiss_message_ui",
                new_callable=AsyncMock,
            ),
        ):
            result = await extractor.send_message(
                "testuser",
                "Hello!",
                confirm_send=False,
                profile_urn="ACoAAB1IelEB",
            )

        # _resolve_message_compose_href should NOT be called when profile_urn given
        mock_resolve_href.assert_not_awaited()
        assert result["status"] == "confirmation_required"

    async def test_profile_urn_compose_url_includes_full_params(self, mock_page):
        """send_message with profile_urn builds URL with profileUrn, screenContext, interop."""
        extractor = LinkedInExtractor(mock_page)
        navigate_calls = []

        async def capture_navigate(url):
            navigate_calls.append(url)

        with (
            patch.object(
                extractor,
                "_navigate_to_page",
                new_callable=AsyncMock,
                side_effect=capture_navigate,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Test User",
            ),
            patch.object(
                extractor,
                "_wait_for_message_surface",
                new_callable=AsyncMock,
                return_value="composer",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_box",
                new_callable=AsyncMock,
                return_value=MagicMock(),
            ),
            patch.object(
                extractor,
                "_compose_page_matches_recipient",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_dismiss_message_ui",
                new_callable=AsyncMock,
            ),
        ):
            await extractor.send_message(
                "testuser",
                "Hello!",
                confirm_send=False,
                profile_urn="ACoAAB1IelEB",
            )

        # Second navigate call is the compose URL (first is the profile page)
        compose_url = navigate_calls[1]
        assert "profileUrn=" in compose_url
        assert "urn%3Ali%3Afsd_profile%3AACoAAB1IelEB" in compose_url
        assert "recipient=ACoAAB1IelEB" in compose_url
        assert "screenContext=NON_SELF_PROFILE_VIEW" in compose_url
        assert "interop=msgOverlay" in compose_url


class TestResolveMessageComposeBox:
    async def test_returns_locator_when_count_positive(self, mock_page):
        """_resolve_message_compose_box returns locator.last when count() > 0."""
        extractor = LinkedInExtractor(mock_page)
        mock_locator = MagicMock()
        mock_locator.count = AsyncMock(return_value=1)
        sentinel = MagicMock(name="last_locator")
        sentinel.wait_for = AsyncMock()
        mock_locator.last = sentinel
        mock_locator.wait_for = AsyncMock()
        mock_page.locator = MagicMock(return_value=mock_locator)

        result = await extractor._resolve_message_compose_box()

        assert result is sentinel
        # wait_for should NOT be called on the early-return path
        sentinel.wait_for.assert_not_called()
        mock_locator.wait_for.assert_not_called()

    async def test_returns_none_when_all_selectors_miss(self, mock_page):
        """_resolve_message_compose_box returns None when no selector matches."""
        from patchright.async_api import TimeoutError as PlaywrightTimeoutError

        extractor = LinkedInExtractor(mock_page)
        mock_locator = MagicMock()
        mock_locator.count = AsyncMock(return_value=0)
        mock_locator.last = MagicMock()
        mock_locator.last.wait_for = AsyncMock(
            side_effect=PlaywrightTimeoutError("timeout")
        )
        mock_page.locator = MagicMock(return_value=mock_locator)

        result = await extractor._resolve_message_compose_box()

        assert result is None

    async def test_falls_through_when_count_raises(self, mock_page):
        """_resolve_message_compose_box handles count() exceptions gracefully."""
        from patchright.async_api import TimeoutError as PlaywrightTimeoutError

        extractor = LinkedInExtractor(mock_page)
        mock_locator = MagicMock()
        mock_locator.count = AsyncMock(side_effect=Exception("detached"))
        mock_locator.last = MagicMock()
        mock_locator.last.wait_for = AsyncMock(
            side_effect=PlaywrightTimeoutError("timeout")
        )
        mock_page.locator = MagicMock(return_value=mock_locator)

        result = await extractor._resolve_message_compose_box()

        assert result is None


class TestSendMessageComposerInteraction:
    """Tests for the page.evaluate + keyboard.type send path (patchright workaround)."""

    def _patch_send_message_to_compose(self, extractor, mock_page):
        """Return a context manager that patches send_message up to the compose step."""
        return (
            patch.object(extractor, "_navigate_to_page", new_callable=AsyncMock),
            patch(
                "linkedin_mcp_server.scraping.extractor.detect_rate_limit",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.handle_modal_close",
                new_callable=AsyncMock,
            ),
            patch.object(
                extractor,
                "_read_profile_display_name",
                new_callable=AsyncMock,
                return_value="Test User",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_href",
                new_callable=AsyncMock,
                return_value="https://www.linkedin.com/messaging/compose/?recipient=ACoAAB",
            ),
            patch.object(
                extractor,
                "_wait_for_message_surface",
                new_callable=AsyncMock,
                return_value="composer",
            ),
            patch.object(
                extractor,
                "_resolve_message_compose_box",
                new_callable=AsyncMock,
                return_value=MagicMock(),
            ),
            patch.object(
                extractor,
                "_compose_page_matches_recipient",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(
                extractor,
                "_dismiss_message_ui",
                new_callable=AsyncMock,
            ),
            patch(
                "linkedin_mcp_server.scraping.extractor.asyncio.sleep",
                new_callable=AsyncMock,
            ),
        )

    async def test_focus_and_type_via_evaluate_and_keyboard(self, mock_page):
        """send_message uses page.evaluate to focus and page.keyboard.type to type."""
        extractor = LinkedInExtractor(mock_page)
        mock_keyboard = MagicMock()
        mock_keyboard.type = AsyncMock()
        mock_keyboard.press = AsyncMock()
        mock_page.keyboard = mock_keyboard
        # evaluate returns: True (focus), True (send button click)
        mock_page.evaluate = AsyncMock(side_effect=[True, True])
        patches = self._patch_send_message_to_compose(extractor, mock_page)

        with (
            patches[0],
            patches[1],
            patches[2],
            patches[3],
            patches[4],
            patches[5],
            patches[6],
            patches[7],
            patches[8],
            patches[9],
            patch.object(
                extractor,
                "_message_text_visible",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.send_message(
                "testuser", "Hello!", confirm_send=True
            )

        assert result["status"] == "sent"
        assert result["sent"] is True
        # Verify keyboard.type was used (not press_sequentially)
        mock_keyboard.type.assert_awaited_once_with("Hello!", delay=15)

    async def test_compose_interact_failed_when_focus_fails(self, mock_page):
        """send_message returns compose_interact_failed when JS focus fails."""
        extractor = LinkedInExtractor(mock_page)
        mock_keyboard = MagicMock()
        mock_keyboard.type = AsyncMock()
        mock_page.keyboard = mock_keyboard
        # evaluate returns False (focus failed)
        mock_page.evaluate = AsyncMock(return_value=False)
        patches = self._patch_send_message_to_compose(extractor, mock_page)

        with (
            patches[0],
            patches[1],
            patches[2],
            patches[3],
            patches[4],
            patches[5],
            patches[6],
            patches[7],
            patches[8],
            patches[9],
        ):
            result = await extractor.send_message(
                "testuser", "Hello!", confirm_send=True
            )

        assert result["status"] == "compose_interact_failed"
        assert result["sent"] is False

    async def test_enter_fallback_when_send_button_not_found(self, mock_page):
        """send_message falls back to Enter key when JS cannot find send button."""
        extractor = LinkedInExtractor(mock_page)
        mock_keyboard = MagicMock()
        mock_keyboard.type = AsyncMock()
        mock_keyboard.press = AsyncMock()
        mock_page.keyboard = mock_keyboard
        # evaluate returns: True (focus), False (no send button found)
        mock_page.evaluate = AsyncMock(side_effect=[True, False])
        patches = self._patch_send_message_to_compose(extractor, mock_page)

        with (
            patches[0],
            patches[1],
            patches[2],
            patches[3],
            patches[4],
            patches[5],
            patches[6],
            patches[7],
            patches[8],
            patches[9],
            patch.object(
                extractor,
                "_message_text_visible",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await extractor.send_message(
                "testuser", "Hello!", confirm_send=True
            )

        assert result["status"] == "sent"
        # Enter was pressed as fallback
        mock_keyboard.press.assert_awaited_once_with("Enter")
