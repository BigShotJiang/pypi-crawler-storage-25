"""
Базовая схема сообщений app-event: тело сообщения — весь JSON (без обёртки ``data``).

- Время события в UTC (``timestamp``).
- Версия контракта (``schema_version``) — для миграций и совместимости читателей.
- Доменный тип события (``event_type``) — обязателен для любого app-event.
- ``model_config``: ``extra="allow"`` — в теле Kafka могут быть поля, которых ещё нет в модели
  (постепенное развёртывание); наследник может сузить контракт до ``extra="ignore"`` / ``forbid``.
- ``populate_by_name=True`` — устойчивость к переименованию полей через алиасы в наследниках.

"""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, ConfigDict, Field


class BaseAppEventMessage(BaseModel):
    """
    Базовое сообщение: тело Kafka — весь JSON (поля модели напрямую).
    Для результатов обработки (не CRUD before/after). Поле ``event_type`` обязательно.
    """

    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Момент формирования события (UTC).",
    )
    schema_version: str = Field(
        default="1",
        min_length=1,
        max_length=64,
        description="Версия схемы полезной нагрузки для совместимости потребителей.",
    )
    event_type: str = Field(
        ...,
        min_length=1,
        max_length=256,
        description="Доменный тип события (обязательное поле app-event).",
    )

    model_config = ConfigDict(populate_by_name=True)
