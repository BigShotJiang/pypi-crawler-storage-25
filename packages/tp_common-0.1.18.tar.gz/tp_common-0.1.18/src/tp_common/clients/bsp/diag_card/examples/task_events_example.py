from __future__ import annotations

import argparse
import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from tp_common.base_client.exceptions import (
    ClientResourceNotFoundException,
    ClientTimeoutException,
)
from tp_common.clients.bsp.diag_card.client import BspDiagCardClient
from tp_common.clients.bsp.diag_card.schemas import EventsRequest, VehicleCreateRequest
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

DEFAULT_DIAG_CARD_URL = "http://localhost:8080/api/v1"

VIN = "Y3M643028P0001319"


def make_dump_dir() -> Path:
    dump_dir = Path("/tmp") / (
        "bsp-diag-card-task-events-" + datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    )
    dump_dir.mkdir(parents=True, exist_ok=True)
    return dump_dir


def dump_response(dump_dir: Path, name: str, response: Any) -> None:
    if hasattr(response, "model_dump"):
        payload = response.model_dump(mode="json")
    else:
        payload = response

    dump_path = dump_dir / f"{name}.json"
    dump_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"dumped_{name}:", dump_path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="BSP diag-card task events example")
    parser.add_argument(
        "--keycloak-url",
        required=True,
        help="Keycloak URL with client credentials",
    )
    parser.add_argument(
        "--diag-card-url",
        default=DEFAULT_DIAG_CARD_URL,
        help=(
            "BSP diag-card API base URL (столько же, сколько в сервисе с root_path; "
            "по умолчанию: %(default)s)"
        ),
    )
    parser.add_argument(
        "--first-timeout",
        type=float,
        default=120.0,
        help="Long-poll timeout for the first events request, seconds (default: 120.0)",
    )
    parser.add_argument(
        "--second-timeout",
        type=float,
        default=30.0,
        help="Long-poll timeout for the second events request, seconds (default: 30.0)",
    )
    return parser.parse_args()


async def main() -> None:
    args = parse_args()
    dump_dir = make_dump_dir()
    print("dump_dir:", dump_dir)
    logger_factory = TpLoggerFactory(EnvironmentType.LOCAL)
    logger_factory.setup_standard_loggers()
    logger = logger_factory.get_logger("bsp-diag-card-task-events-example")

    client = BspDiagCardClient(
        diag_card_url=args.diag_card_url,
        logger=logger,
        keycloak_url=args.keycloak_url,
        env_type=EnvironmentType.LOCAL,
    )

    try:
        try:
            vehicle = await client.get_vehicle(VIN)
            print("vehicle_exists:", vehicle.vin)
            dump_response(dump_dir, "vehicle_get", vehicle)
        except ClientResourceNotFoundException:
            vehicle = await client.create_vehicle(VehicleCreateRequest(vin=VIN))
            print("vehicle_created:", vehicle.vin)
            dump_response(dump_dir, "vehicle_create", vehicle)

        first_batch = await client.get_task_events(
            EventsRequest(
                offset=None,
                limit=100,
                timeout=args.first_timeout,
            )
        )
        print("first_batch_count:", len(first_batch.messages))
        dump_response(dump_dir, "task_events_first_batch", first_batch)

        if not first_batch.messages:
            print("second_batch_count: skipped (first batch is empty)")
            return

        next_offset = first_batch.next_offset
        if next_offset is None:
            print("second_batch_count: skipped (nextOffset is null)")
            return
        try:
            second_batch = await client.get_task_events(
                EventsRequest(
                    offset=next_offset,
                    limit=100,
                    timeout=args.second_timeout,
                )
            )
        except ClientTimeoutException:
            print(
                "second_batch_count: skipped (request timed out, "
                f"timeout={args.second_timeout}s)"
            )
            return

        print("next_offset:", next_offset)
        print("second_batch_count:", len(second_batch.messages))
        dump_response(dump_dir, "task_events_second_batch", second_batch)
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
