from __future__ import annotations

import argparse
import asyncio

from tp_common.clients.bsp.diag_card.client import BspDiagCardClient
from tp_common.clients.bsp.diag_card.schemas import (
    EventsRequest,
    TaskEnsureRequest,
    VehicleCreateRequest,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

DEFAULT_DIAG_CARD_URL = "http://localhost:8080/api/v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="BSP diag-card client example")
    parser.add_argument(
        "--keycloak-url",
        required=True,
        help="Keycloak URL with client credentials",
    )
    parser.add_argument(
        "--diag-card-url",
        default=DEFAULT_DIAG_CARD_URL,
        help=(
            "BSP diag-card API base URL (столько же, сколько в сервисе с root_path; "
            "по умолчанию: %(default)s)"
        ),
    )
    return parser.parse_args()


async def main() -> None:
    args = parse_args()
    logger_factory = TpLoggerFactory(EnvironmentType.LOCAL)
    logger_factory.setup_standard_loggers()
    logger = logger_factory.get_logger("bsp-diag-card-client-example")

    client = BspDiagCardClient(
        diag_card_url=args.diag_card_url,
        logger=logger,
        keycloak_url=args.keycloak_url,
        env_type=EnvironmentType.LOCAL,
    )

    try:
        # 1) Создаём ТС: service_id извлекается сервисом из Keycloak-токена.
        vehicle = await client.create_vehicle(
            VehicleCreateRequest(vin="Y3M643028P0001319")
        )
        print("vehicle:", vehicle.model_dump(mode="json"))

        # 2) Создаём/обновляем задачу по VIN (если есть активная — priority += 10).
        task = await client.ensure_task(TaskEnsureRequest(vin=vehicle.vin))
        print("task:", task.model_dump(mode="json"))

        # 3) Читаем диагностические карты для VIN.
        cards = await client.get_vehicle_diagnostic_cards(vehicle.vin)
        print("vehicle_cards_count:", len(cards.items))

        # 4) Читаем события задач: сначала committed-позиция (offset=None).
        task_events_first = await client.get_task_events(
            EventsRequest(
                offset=None,
                limit=100,
                timeout=10.0,
            )
        )
        print("task_events_first_count:", len(task_events_first.messages))

        # 5) Второй запрос: читаем с nextOffset из предыдущего ответа.
        if task_events_first.next_offset is not None:
            task_events_next = await client.get_task_events(
                EventsRequest(
                    offset=task_events_first.next_offset,
                    limit=100,
                    timeout=10.0,
                )
            )
            print("task_events_next_count:", len(task_events_next.messages))
        else:
            print("task_events_next_count: skipped (no first batch)")
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
