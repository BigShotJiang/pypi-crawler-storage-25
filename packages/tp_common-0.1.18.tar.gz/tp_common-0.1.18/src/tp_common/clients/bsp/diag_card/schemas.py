from __future__ import annotations

import uuid
from datetime import date, datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, RootModel, field_validator
from pydantic.alias_generators import to_camel

from tp_common.kafka.app_event import BaseAppEventMessage
from tp_common.route.schemes import BaseAppEventMessagesResponse, BaseResponse


class ApiModel(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class AccountStatus(StrEnum):
    IN_WORK = "in_work"
    IDLE = "idle"


class TaskStatus(StrEnum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ABANDONED = "abandoned"


class DcOperatorStatus(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    CANCELLED = "cancelled"


def _normalize_vin(value: str) -> str:
    vin = value.strip().upper()
    if len(vin) != 17:
        msg = "VIN must contain exactly 17 characters"
        raise ValueError(msg)
    return vin


class AccountCreateRequest(ApiModel):
    cookies: str = ""


class AccountReplaceRequest(ApiModel):
    cookies: str = Field(
        ...,
        description="Строка Cookie для провайдеров (допустима пустая строка).",
    )
    status: AccountStatus = Field(
        ...,
        description="Статус использования аккаунта воркером.",
    )
    next_usage_at: datetime | None = Field(
        ...,
        description="Время следующего использования; null — аккаунт не использовать.",
    )


class AccountsListRequest(ApiModel):
    limit: int = Field(default=100, ge=1, le=500)
    offset: int = Field(default=0, ge=0)
    status: AccountStatus | None = None


class AccountResponse(ApiModel):
    account_id: uuid.UUID
    cookies: str
    status: AccountStatus
    next_usage_at: datetime | None
    created_at: datetime
    updated_at: datetime


class AccountsResponse(RootModel[list[AccountResponse]]):
    pass


class VehicleCreateRequest(ApiModel):
    vin: str = Field(min_length=17, max_length=17)

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str) -> str:
        return _normalize_vin(value)


class VehicleByVinQuery(ApiModel):
    """Query для GET /vehicle (см. bsp-diag-card: параметр ``vin``)."""

    vin: str = Field(min_length=17, max_length=17)

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str) -> str:
        return _normalize_vin(value)


class VehicleSyncRequest(ApiModel):
    vins: list[str] = Field(default_factory=list)

    @field_validator("vins")
    @classmethod
    def normalize_vins(cls, value: list[str]) -> list[str]:
        return list({_normalize_vin(vin) for vin in value})


class VehicleBulkCreateRequest(ApiModel):
    vins: list[str] = Field(default_factory=list)

    @field_validator("vins")
    @classmethod
    def normalize_vins(cls, value: list[str]) -> list[str]:
        return list({_normalize_vin(vin) for vin in value})


class VehicleDiagnosticCardResponse(ApiModel):
    card_id: uuid.UUID
    card_number: int
    task_id: uuid.UUID
    vin: str
    start_date: date
    end_date: date
    odometer_value: int
    operator_id: int
    created_at: datetime
    updated_at: datetime


class VehicleResponse(ApiModel):
    vehicle_id: uuid.UUID
    vin: str
    next_retry_at: datetime | None
    diagnostic_cards: list[VehicleDiagnosticCardResponse] = Field(default_factory=list)


class VehicleSyncResponse(ApiModel):
    added: int
    deleted: int


class VehicleBulkCreateResponse(ApiModel):
    added: int
    skipped: int


class VehicleDiagnosticCardsResponse(ApiModel):
    items: list[VehicleDiagnosticCardResponse]


class VehicleOperatorResponse(ApiModel):
    operator_id: int
    status: DcOperatorStatus
    name: str | None
    address_line: str | None
    phone_number: str | None
    email: str | None
    website: str | None
    cancelled_date: date | None


class VehicleDiagnosticCardWithOperatorResponse(VehicleDiagnosticCardResponse):
    operator: VehicleOperatorResponse | None = None


class VehicleFullResponse(ApiModel):
    vehicle_id: uuid.UUID
    vin: str
    next_retry_at: datetime | None
    diagnostic_cards: list[VehicleDiagnosticCardWithOperatorResponse]


class TaskEnsureRequest(ApiModel):
    vin: str = Field(min_length=17, max_length=17)

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str) -> str:
        return _normalize_vin(value)


class TaskEnsureResponse(BaseResponse):
    task_id: uuid.UUID
    vin: str
    priority: int
    status: TaskStatus
    started_at: datetime | None
    completed_at: datetime | None
    error_message: str | None
    created_at: datetime
    updated_at: datetime


class EventsRequest(ApiModel):
    offset: int | None = Field(default=None, ge=0)
    limit: int | None = Field(default=None, ge=1, le=10_000)
    timeout: float = Field(default=25.0, ge=1.0, le=120.0)


class AppTaskEventMessage(BaseAppEventMessage):
    task_id: uuid.UUID
    vin: str


class TaskEventMessage(BaseResponse, AppTaskEventMessage):
    pass


class TaskEventsResponse(BaseAppEventMessagesResponse[TaskEventMessage]):
    pass
