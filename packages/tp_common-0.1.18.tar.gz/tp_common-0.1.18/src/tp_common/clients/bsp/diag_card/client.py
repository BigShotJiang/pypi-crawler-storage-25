from __future__ import annotations

import uuid

from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger

from .schemas import (
    AccountCreateRequest,
    AccountReplaceRequest,
    AccountResponse,
    AccountsListRequest,
    AccountsResponse,
    EventsRequest,
    TaskEnsureRequest,
    TaskEnsureResponse,
    TaskEventsResponse,
    VehicleBulkCreateRequest,
    VehicleBulkCreateResponse,
    VehicleByVinQuery,
    VehicleCreateRequest,
    VehicleDiagnosticCardsResponse,
    VehicleFullResponse,
    VehicleResponse,
    VehicleSyncRequest,
    VehicleSyncResponse,
)


class BspDiagCardClient(KeycloakClient):
    """HTTP-клиент bsp-diag-card для межсервисной интеграции."""

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        diag_card_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        resolved_base_url = self._build_base_url(
            diag_card_url=diag_card_url, env_type=env_type
        )
        super().__init__(
            base_url=resolved_base_url,
            logger=logger,
            audience="bsp-diag-card",
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(
        cls, *, diag_card_url: str | None, env_type: EnvironmentType
    ) -> str:
        base = (diag_card_url or cls._base_url_by_env_type(env_type)).rstrip("/")
        version_path = cls._api_version_path().rstrip("/")
        if base.endswith(version_path):
            return f"{base}/"
        return f"{base}{version_path}/"

    @staticmethod
    def _api_version_path() -> str:
        return "/v1"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.STAGING:
                return "https://diag-card.bsp-staging.bz/api"
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/diag-card/api"
            case _:
                return "https://diag-card.bsp-dev.bz/api"

    async def list_accounts(
        self, request: AccountsListRequest
    ) -> list[AccountResponse]:
        response = await self.get(
            "/account",
            AccountsResponse,
            params=request,
        )
        return response.root

    async def get_account(self, account_id: uuid.UUID) -> AccountResponse:
        return await self.get(f"/account/{account_id}", AccountResponse)

    async def create_account(self, request: AccountCreateRequest) -> AccountResponse:
        return await self.post(
            "/account",
            AccountResponse,
            body=request,
        )

    async def replace_account(
        self, account_id: uuid.UUID, request: AccountReplaceRequest
    ) -> AccountResponse:
        return await self.put(
            f"/account/{account_id}",
            AccountResponse,
            body=request,
        )

    async def create_vehicle(self, request: VehicleCreateRequest) -> VehicleResponse:
        return await self.post(
            "/vehicle",
            VehicleResponse,
            body=request,
        )

    async def get_vehicle(self, vin: str) -> VehicleResponse:
        return await self.get(
            "/vehicle",
            VehicleResponse,
            params=VehicleByVinQuery(vin=vin),
        )

    async def get_vehicle_full(self, vehicle_id: uuid.UUID) -> VehicleFullResponse:
        return await self.get(f"/vehicle/{vehicle_id}", VehicleFullResponse)

    async def get_vehicle_diagnostic_cards(
        self, vin: str
    ) -> VehicleDiagnosticCardsResponse:
        return await self.get(
            f"/vehicle/{vin.strip().upper()}/diagnostic-cards",
            VehicleDiagnosticCardsResponse,
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> VehicleSyncResponse:
        return await self.post(
            "/vehicle/sync",
            VehicleSyncResponse,
            body=request,
        )

    async def create_vehicles_bulk(
        self, request: VehicleBulkCreateRequest
    ) -> VehicleBulkCreateResponse:
        return await self.post(
            "/vehicle/bulk",
            VehicleBulkCreateResponse,
            body=request,
        )

    async def delete_vehicle(self, vin: str) -> None:
        await self.delete_response(f"/vehicle/{vin.strip().upper()}")

    async def ensure_task(self, request: TaskEnsureRequest) -> TaskEnsureResponse:
        return await self.post(
            "/vehicle/ensure",
            TaskEnsureResponse,
            body=request,
        )

    async def get_task_events(self, request: EventsRequest) -> TaskEventsResponse:
        return await self.get(
            "/events/tasks",
            TaskEventsResponse,
            params=request,
            timeout=request.timeout,
        )
