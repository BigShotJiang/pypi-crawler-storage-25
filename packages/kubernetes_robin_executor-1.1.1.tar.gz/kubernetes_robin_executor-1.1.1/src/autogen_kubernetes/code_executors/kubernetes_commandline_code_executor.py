from __future__ import annotations

import atexit
import base64
import logging
import sys
import time
import uuid
from hashlib import md5
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Tuple, Type, Union
import os
import shlex
import signal
from kubernetes import client, config, stream
from kubernetes.client.exceptions import ApiException
from autogen_kubernetes.code_executors.base import (
    CodeBlock,
    CodeExecutor,
    CodeExtractor,
    CommandLineCodeResult,
    TIMEOUT_MSG,
    _cmd,
)
from autogen_kubernetes.code_executors.markdown_code_extractor import MarkdownCodeExtractor
import json
import random
import string
import re
if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

__all__ = ("KubernetesCommandLineCodeExecutor",)

# Dispatcher written to the pod by install_pod_dispatcher(); JSON schema matches execute_tool_function.
_POD_DISPATCHER_TEMPLATE = '''# Uploaded by KubernetesCommandLineCodeExecutor.install_pod_dispatcher()
import importlib
import json
import sys


def main() -> None:
    param_path = sys.argv[1]
    with open(param_path, encoding="utf-8") as f:
        payload = json.load(f)
    module_name = payload.get("module", "{default_module}")
    function_name = payload["function"]
    arguments = payload.get("arguments") or {{}}
    mod = importlib.import_module(module_name)
    fn = getattr(mod, function_name)
    result = fn(**arguments)
    if result is not None:
        print(result)


if __name__ == "__main__":
    main()
'''

filename_patterns = [
    re.compile(r"^<!-- (filename:)?(.+?) -->", re.DOTALL),
    re.compile(r"^/\* (filename:)?(.+?) \*/", re.DOTALL),
    re.compile(r"^// (filename:)?(.+?)$", re.DOTALL),
    re.compile(r"^# (filename:)?(.+?)$", re.DOTALL),
]


def silence_pip(code: str, lang: str) -> str:
    """Apply -qqq flag to pip install commands."""
    if lang == "python":
        regex = r"^! ?pip install"
    elif lang in ["bash", "shell", "sh", "pwsh", "powershell", "ps1"]:
        regex = r"^pip install"
    else:
        return code

    # Find lines that start with pip install and make sure "-qqq" flag is added.
    lines = code.split("\n")
    for i, line in enumerate(lines):
        # use regex to find lines that start with pip install.
        match = re.search(regex, line)
        if match is not None:
            if "-qqq" not in line:
                lines[i] = line.replace(match.group(0), match.group(0) + " -qqq")
    return "\n".join(lines)


# Raises ValueError if the file is not in the workspace
def _get_file_name_from_content(code: str, workspace_path: Path) -> Optional[str]:
    first_line = code.split("\n")[0].strip()
    # TODO - support other languages
    for pattern in filename_patterns:
        matches = pattern.match(first_line)
        if matches is not None:
            filename = matches.group(2).strip()

            # Handle relative paths in the filename
            path = Path(filename)
            if not path.is_absolute():
                path = workspace_path / path
            path = path.resolve()
            # Throws an error if the file is not in the workspace
            relative = path.relative_to(workspace_path.resolve())
            return str(relative)
    return None

class KubernetesCommandLineCodeExecutor(CodeExecutor):
    DEFAULT_EXECUTION_POLICY: ClassVar[Dict[str, bool]] = {
        "bash": True,
        "shell": True,
        "sh": True,
        "pwsh": True,
        "powershell": True,
        "ps1": True,
        "python": True,
        "javascript": False,
        "html": False,
        "css": False,
    }
    LANGUAGE_ALIASES: ClassVar[Dict[str, str]] = {"py": "python", "js": "javascript"}

    def __init__(
        self,
        image: str = "python:3-slim",
        pod_name: Optional[str] = None,
        namespace: str = "test-namespace",
        timeout: int = 60,
        work_dir: Union[Path, str] = Path("."),
        execution_policies: Optional[Dict[str, bool]] = None,
        remote_control_plane: Optional[str] = None,
        kube_token: Optional[str] = None,
        shared_pvc_name: Optional[str] = None,
        node: Optional[str] = None,
        shared_resources = True,
        env_vars: Optional[List[Dict[str, str]]] = []
    ):
        """(Experimental) A code executor class that executes code through
        a command line environment in a Kubernetes pod.

        The executor first saves each code block in a file in the pod's workspace,
        and then executes the code file in the pod.
        The executor executes the code blocks in the order they are received.
        Currently, the executor only supports Python and shell scripts.
        For Python code, use the language "python" for the code block.
        For shell scripts, use the language "bash", "shell", or "sh" for the code
        block.

        Args:
            image (str, optional): Docker image to use for code execution.
                Defaults to "python:3-slim".
            pod_name (Optional[str], optional): Name of the Kubernetes pod
                which is created. If None, will autogenerate a name. Defaults to None.
            namespace (str, optional): Kubernetes namespace to create the pod in.
                Defaults to "default".
            timeout (int, optional): The timeout for code execution. Defaults to 60.
                Must be greater than or equal to 1.
            work_dir (Union[Path, str], optional): The working directory path in the pod.
                Defaults to Path(".").
            execution_policies (Optional[Dict[str, bool]], optional): Execution policies
                for different languages. Defaults to None.
            remote_control_plane (Optional[str], optional): URL of the remote Kubernetes control plane.
                If provided, the executor will connect to the specified remote cluster.
            kube_token (Optional[str], optional): Bearer token for the API server when using
                ``remote_control_plane``. If omitted, ``KUBE_TOKEN`` from the environment is used.
                One of these must be set when ``remote_control_plane`` is set.
            shared_pvc_name (Optional[str], optional): Name of a shared PersistentVolumeClaim to use
                for persistent storage in the pod. Defaults to None.
            node (Optional[str], optional): Specific Kubernetes node on which to schedule the pod.
                Defaults to None, which allows Kubernetes to select any available node.
            shared_resources (bool, optional): Whether to use shared resources (e.g., shared PVC) for the namespace.
                Defaults to True.
            env_vars (List[Dict[str, str]], optional): List of environment variables to set in the pod.

        Raises:
            ValueError: On argument error, such as an invalid timeout value (must be >= 1).
            EnvironmentError: If neither ``kube_token`` nor the ``KUBE_TOKEN`` environment variable
                is set when connecting to a remote Kubernetes cluster.
            RuntimeError: If the pod fails to start due to insufficient resources or other issues.
        """
        # Load Kubernetes configuration
        self.resources_pod = client.V1ResourceRequirements(
            requests={
                "cpu": "20m",      # ~0.02 CPU
                "memory": "30Mi"   # Memoria mínima solicitada
            },
            limits={
                "cpu": "100m",     # ~0.1 CPU como máximo
                "memory": "200Mi"   # Límite máximo de memoria
            }
        )
        self.remote_control_plane = remote_control_plane
        self._kube_token: Optional[str] = None
        if self.remote_control_plane:
            resolved = kube_token if kube_token is not None else os.environ.get("KUBE_TOKEN")
            if resolved is None or (isinstance(resolved, str) and not resolved.strip()):
                raise EnvironmentError(
                    "Kubernetes bearer token is required when remote_control_plane is set: "
                    "pass kube_token=... or set the KUBE_TOKEN environment variable."
                )
            resolved = resolved.strip()
            self._kube_token = resolved
            configuration = client.Configuration()
            configuration.host = self.remote_control_plane
            configuration.verify_ssl = False
            configuration.api_key = {"authorization": f"Bearer {resolved}"}
            self.api_client = client.ApiClient(configuration)
            self.api_instance = client.CoreV1Api(self.api_client)
        else:
            try:
                config.load_kube_config()
                self.api_client = None
            except config.ConfigException:
                config.load_incluster_config()
            #Local cluster
            self.api_instance = client.CoreV1Api()

        self.node = node
        self.shared_pvc_name = shared_pvc_name

        if timeout < 1:
            raise ValueError("Timeout must be greater than or equal to 1.")

        if isinstance(work_dir, str):
            work_dir = Path(work_dir)
        self._work_dir: Path = work_dir
        str_path_posix = self._work_dir.as_posix()
        self._work_dir_str = str_path_posix
        self.shared_resources = shared_resources
        self.image = image
        self.namespace = namespace
        self._timeout = timeout
        self.execution_policies = self.DEFAULT_EXECUTION_POLICY.copy()


        if execution_policies is not None:
            self.execution_policies.update(execution_policies)

        if pod_name is None:
            pod_name = f"robin-code-exec-{uuid.uuid4()}"
        self.pod_name = pod_name
        self.remote_control_plane = remote_control_plane

        pod_name = self.is_pod_running_with_image()
        if pod_name and self.shared_resources:
            self.pod_name = pod_name
        else:
            self.create_resources()

        self.add_env_vars_to_bashrc(env_vars=env_vars)


        def cleanup() -> None:
            try:
                print(f"Deleting pod {self.pod_name} in namespace {self.namespace}")
                #self.api_instance.delete_namespaced_pod(name=self.pod_name, namespace=self.namespace)
            except ApiException as e:
                if e.status != 404:
                    raise e
            atexit.unregister(cleanup)

        # Registrar el manejador de señales para la interrupción
        signal.signal(signal.SIGINT, self.handle_sigint)

        atexit.register(cleanup)
        self._cleanup = cleanup

    def handle_sigint(self, signum, frame):
        print("Interrupción recibida, limpiando recursos...")
        self.cleanup()
        exit(0)  

    def add_env_vars_to_bashrc(self, env_vars):
        if env_vars != []:
            # Construir el comando para agregar todas las variables al archivo ~/.bashrc
            command_string = " && ".join([f'echo "export {var["key"]}={var["value"]}" >> ~/.bashrc' for var in env_vars])
            
            # Ejecutar el comando completo
            command = ["sh", "-c", command_string]
            self._exec_command_with_exit_code(command)

    def is_pod_running_with_image(self) -> bool:
        """
        Verifica si existe un pod corriendo con una imagen específica en un namespace.

        :param namespace: El namespace donde buscar el pod.
        :param image: La imagen a buscar en los pods.
        :return: True si existe un pod corriendo con la imagen, False en caso contrario.
        """
        try: 
            # Obtiene todos los pods en el namespace
            pods = self.api_instance.list_namespaced_pod(self.namespace)
            
            for pod in pods.items:
                # Verifica si el pod está en estado "Running"
                if pod.status.phase != "Running":
                    continue
                
                # Itera sobre los contenedores del pod
                for container in pod.spec.containers:
                    if container.image == self.image:
                        return pod.metadata.name  # Devolver el nombre del pod
            
            return None

        except client.exceptions.ApiException as e:
            print(f"Error al acceder a la API de Kubernetes: {e}")
            return None

    def get_pod_resource_usage(self):
        """
        Obtiene el uso de CPU y memoria de un pod específico en el namespace configurado.

        :return: Un diccionario con el uso de CPU y memoria del pod, o None si no se puede obtener.
        """
        try:
            # Cargar configuración de Kubernetes
            config.load_kube_config()  # Usa load_incluster_config() dentro del clúster
            
            # Cliente para acceder a la API de métricas
            metrics_client = client.CustomObjectsApi()
            
            # Listar pods en el namespace
            core_client = client.CoreV1Api()
            pods = core_client.list_namespaced_pod(self.namespace)

            # Buscar el pod que coincida con la imagen
            pod_name = None
            for pod in pods.items:
                for container in pod.spec.containers:
                    if container.image == self.image:
                        pod_name = pod.metadata.name
                        break
                if pod_name:
                    break
            
            if not pod_name:
                print(f"No se encontró un pod con la imagen '{self.image}' en el namespace '{self.namespace}'.")
                return None

            # Obtener métricas del pod
            metrics = metrics_client.get_namespaced_custom_object(
                group="metrics.k8s.io",
                version="v1beta1",
                namespace=self.namespace,
                plural="pods",
                name=pod_name
            )
            
            # Parsear métricas
            usage = {}
            for container in metrics["containers"]:
                usage[container["name"]] = {
                    "cpu": container["usage"]["cpu"],
                    "memory": container["usage"]["memory"]
                }
            
            return usage

        except ApiException as e:
            print(f"Error al obtener métricas: {e}")
            return None


    def create_resources(self):

        # Cadena vacía "" no es None pero no es un hostname válido: provoca nodeSelector
        # kubernetes.io/hostname="" y el pod queda Unschedulable.
        if self.node:
            node_selector = {"kubernetes.io/hostname": self.node}
        else:
            node_selector = {}
        

        if self.shared_pvc_name:
        # Define the pod spec with shared pvc volume for the differents pods
            pod = client.V1Pod(
                metadata=client.V1ObjectMeta(name=self.pod_name),
                spec=client.V1PodSpec(
                    containers=[
                        client.V1Container(
                            name="robin-executor",
                            image=self.image,
                            command=["/bin/sh"],
                            tty=True,
                            stdin=True,
                            resources=self.resources_pod,
                            image_pull_policy="Always",
                            volume_mounts=[
                                client.V1VolumeMount(
                                    mount_path=self._work_dir_str,
                                    name="shared-storage"
                                )
                            ]
                        )
                    ],

                    node_selector= node_selector,  # Nodo específico
                    volumes=[
                        client.V1Volume(
                            name="shared-storage",
                            persistent_volume_claim=client.V1PersistentVolumeClaimVolumeSource(
                                claim_name=self.shared_pvc_name
                            )
                        )
                    ],
                    dns_policy="None",  # Permite sobrescribir la configuración DNS predeterminada
                    dns_config=client.V1PodDNSConfig(
                        nameservers=["8.8.8.8", "8.8.4.4"],  # DNS de Google o puedes agregar otros
                        searches=["custom-domain.local"],  # Opcional, si necesitas una búsqueda específica
                        options=[client.V1PodDNSConfigOption(name="ndots", value="5")]  # Opcional
                    ),
                    restart_policy="Never"
                )
            )
        else:
            # Define the pod spec
            pod = client.V1Pod(
                metadata=client.V1ObjectMeta(name=self.pod_name),
                spec=client.V1PodSpec(
                    containers=[
                        client.V1Container(
                            name="robin-executor",
                            image=self.image,
                            command=["/bin/sh"],
                            tty=True,
                            stdin=True,
                            resources=self.resources_pod,
                            image_pull_policy="Always",
                            volume_mounts=[
                                client.V1VolumeMount(
                                    mount_path=self._work_dir_str,
                                    name="workspace-volume"
                                )
                            ]
                        )
                    ],
                    node_selector = node_selector,  # Nodo específico
                    volumes=[
                        client.V1Volume(
                            name="workspace-volume",
                            empty_dir=client.V1EmptyDirVolumeSource()
                        )
                    ],
                    dns_policy="None",  # Permite sobrescribir la configuración DNS predeterminada
                    dns_config=client.V1PodDNSConfig(
                        nameservers=["8.8.8.8", "8.8.4.4"],  # DNS de Google o puedes agregar otros
                        searches=["custom-domain.local"],  # Opcional, si necesitas una búsqueda específica
                        options=[client.V1PodDNSConfigOption(name="ndots", value="5")]  # Opcional
                    ),
                    restart_policy="Never"
                )
            )

        # Create the pod
        try:
            self.api_instance.create_namespaced_pod(
                namespace=self.namespace,
                body=pod
            )
        except ApiException as e:
            raise ValueError(f"Failed to create pod: {e}")

        # Wait for the pod to be running
        self._wait_for_pod_ready(40)

    def cleanup(self) -> None:
        try:
            self.api_instance.delete_namespaced_pod(name=self.pod_name, namespace=self.namespace)
        except ApiException as e:
            if e.status != 404:
                raise e
        atexit.unregister(self.cleanup) 

    def _wait_for_pod_ready(self, timeout: int = 60) -> None:
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                pod = self.api_instance.read_namespaced_pod(name=self.pod_name, namespace=self.namespace)
                if pod.status.phase == "Running":
                    return
                elif pod.status.phase in ["Failed", "Unknown", "Succeeded"]:
                    raise ValueError(f"Pod failed to start. Status: {pod.status.phase}")
            except ApiException as e:
                if e.status != 404:
                    raise e
            time.sleep(1)
        raise TimeoutError(f"Timed out waiting for pod {self.pod_name} to be running.")

    @property
    def timeout(self) -> int:
        """(Experimental) The timeout for code execution."""
        return self._timeout

    @property
    def work_dir(self) -> Path:
        """(Experimental) The working directory for the code execution."""
        return self._work_dir

    @property
    def code_extractor(self) -> CodeExtractor:
        """(Experimental) Export a code extractor that can be used by an agent."""
        return MarkdownCodeExtractor()

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CommandLineCodeResult:
        """(Experimental) Execute the code blocks and return the result.

        Args:
            code_blocks (List[CodeBlock]): The code blocks to execute.

        Returns:
            CommandLineCodeResult: The result of the code execution."""
        if len(code_blocks) == 0:
            raise ValueError("No code blocks to execute.")

        outputs = []
        last_exit_code = 0
        files = []
        for code_block in code_blocks:
            lang = self.LANGUAGE_ALIASES.get(code_block.language.lower(), code_block.language.lower())
            if lang not in self.DEFAULT_EXECUTION_POLICY:
                outputs.append(f"Unsupported language {lang}\n")
                last_exit_code = 1
                break

            execute_code = self.execution_policies.get(lang, False)
            code = silence_pip(code_block.code, lang)

            # Determine filename
            try:
                filename = _get_file_name_from_content(code, Path('/workspace'))
            except ValueError:
                outputs.append("Filename is not in the workspace")
                last_exit_code = 1
                break

            if not filename:
                filename = f"tmp_code_{md5(code.encode()).hexdigest()}.{lang}"
            code_path = f"{self._work_dir_str.rstrip('/')}/{filename}"
            files.append(code_path)

            # Upload the code to the pod
            self._upload_file_to_pod(code, code_path)

            if not execute_code:
                outputs.append(f"Code saved to {code_path}\n")
                continue

            # Execute the code
            exec_command = [_cmd(lang), code_path]
            exit_code, output = self._exec_command_with_exit_code(exec_command)
            outputs.append(output)

            last_exit_code = exit_code
            if exit_code != 0:
                break
        code_file = files[0] if files else None
        return CommandLineCodeResult(exit_code=last_exit_code, output="".join(outputs), code_file=code_file)

    def upload_file_content(self, relative_path: Union[str, Path], content: str) -> str:
        """Write ``content`` into the pod under :attr:`work_dir` at ``relative_path``.

        Returns the absolute path in the pod (POSIX) where the file was written.
        Use this for single modules or generated source before calling :meth:`execute_tool_function`.
        """
        rel = Path(relative_path).as_posix().lstrip("/")
        remote = f"{self._work_dir_str.rstrip('/')}/{rel}"
        self._upload_file_to_pod(content, remote)
        return remote

    def upload_from_disk(
        self,
        local_path: Union[Path, str],
        *,
        remote_prefix: str = "",
        encoding: str = "utf-8",
    ) -> List[str]:
        """Upload a local file or every file under a directory tree into :attr:`work_dir`.

        Skips ``__pycache__`` directories and hidden names (``.*``). Only text
        files are supported (read with ``encoding``).

        Args:
            local_path: File or directory on the client machine.
            remote_prefix: Optional subdirectory under ``work_dir`` (no leading slash).

        Returns:
            List of POSIX paths written in the pod.
        """
        root = Path(local_path).expanduser().resolve()
        if not root.exists():
            raise FileNotFoundError(f"Local path does not exist: {root}")

        prefix = remote_prefix.strip("/").replace("\\", "/")
        written: List[str] = []

        def should_skip(path: Path) -> bool:
            if "__pycache__" in path.parts:
                return True
            return any(part.startswith(".") for part in path.parts)

        if root.is_file():
            if should_skip(root):
                return written
            rel_name = root.name
            rel = f"{prefix}/{rel_name}" if prefix else rel_name
            remote = f"{self._work_dir_str.rstrip('/')}/{rel}"
            self._upload_file_to_pod(root.read_text(encoding=encoding), remote)
            written.append(remote)
            return written

        for file_path in root.rglob("*"):
            if not file_path.is_file() or should_skip(file_path):
                continue
            rel_under_root = file_path.relative_to(root).as_posix()
            rel = f"{prefix}/{rel_under_root}" if prefix else rel_under_root
            remote = f"{self._work_dir_str.rstrip('/')}/{rel}"
            self._upload_file_to_pod(file_path.read_text(encoding=encoding), remote)
            written.append(remote)
        return written

    def install_pod_dispatcher(
        self,
        *,
        default_module: str = "robin_user",
        runner_filename: str = "executor.py",
    ) -> str:
        """Upload a small ``executor.py`` that runs functions by name on the pod.

        The dispatcher reads JSON with ``function``, ``arguments``, and optional
        ``module`` keys (same payload as :meth:`execute_tool_function`). Default import is
        ``default_module`` when ``module`` is omitted in the JSON.

        Call :meth:`upload_from_disk` or :meth:`upload_file_content` first to place
        your code (e.g. ``robin_user.py`` or a package) under :attr:`work_dir`.
        """
        rel = Path(runner_filename).as_posix().lstrip("/")
        source = _POD_DISPATCHER_TEMPLATE.format(default_module=default_module)
        return self.upload_file_content(rel, source)

    def execute_tool_function(
        self,
        arguments: Any,
        func_name: str,
        *,
        module: Optional[str] = None,
        runner_script: str = "executor.py",
    ) -> CommandLineCodeResult:
        """Build a JSON payload, upload it to the pod, and run ``runner_script``.

        The runner (e.g. from :meth:`install_pod_dispatcher`) loads ``module``
        (or the dispatcher default), gets ``func_name``, and calls ``func_name(**arguments)``.

        Args:
            arguments: Dict or JSON string of keyword arguments for the function.
            func_name: Name of the callable on the target module.
            module: Dotted module path inside :attr:`work_dir` (e.g. ``my_pkg.tools``).
                If omitted, the dispatcher uses its ``default_module``.
            runner_script: Path under :attr:`work_dir` (default ``executor.py``).

        Returns:
            CommandLineCodeResult: exit code and stdout/stderr from the pod.
        """
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError as e:
                raise ValueError("La cadena de argumentos no es un JSON válido") from e

        if not isinstance(arguments, dict):
            raise TypeError("Los argumentos deben ser un diccionario o una cadena JSON válida")

        json_data: Dict[str, Any] = {"function": func_name, "arguments": arguments}
        if module is not None:
            json_data["module"] = module

        json_content = json.dumps(json_data, indent=2)
        param_name = "".join(random.choices(string.ascii_letters + string.digits, k=10)) + ".json"
        parameters_path = f"{self._work_dir_str.rstrip('/')}/{param_name}"
        self._upload_file_to_pod(json_content, parameters_path)

        runner_rel = Path(runner_script).as_posix().lstrip("/")
        code_path = f"{self._work_dir_str.rstrip('/')}/{runner_rel}"
        exec_command = ["python", code_path, parameters_path]
        exit_code, output = self._exec_command_with_exit_code(exec_command)
        return CommandLineCodeResult(exit_code=exit_code, output=output)


    def _upload_file_to_pod(self, content: str, remote_path: str) -> None:
        parent = Path(remote_path).parent.as_posix()
        exec_command = [
            "sh",
            "-c",
            f"mkdir -p {shlex.quote(parent)} && cat > {shlex.quote(remote_path)}",
        ]
        resp = stream.stream(
            self.api_instance.connect_get_namespaced_pod_exec,
            name=self.pod_name,
            namespace=self.namespace,
            command=exec_command,
            stderr=True, stdin=True,
            stdout=True, tty=False,
            _preload_content=False
        )
        try:
            resp.write_stdin(content)
            resp.update(timeout=5)
        except Exception as e:
            resp.close()
            raise e
        resp.close()

    def _exec_command_with_exit_code(self, command: List[str], output_file= "./output_script.txt") -> Tuple[int, str]:
      cmd_str = ' '.join(shlex.quote(arg) for arg in command)
      # Load the bashrc file to set the environment variables
      cmd_str = f'. ~/.bashrc && {cmd_str}'
      # Wrap the command to capture the exit code
      wrapped_command = ['sh', '-c', f'{cmd_str}; echo $?']
      try:
          resp = stream.stream(
              self.api_instance.connect_get_namespaced_pod_exec,
              name=self.pod_name,
              namespace=self.namespace,
              command=wrapped_command,
              stderr=True,
              stdin=False,
              stdout=True,
              tty=False,
              _preload_content=False,
              _request_timeout=self._timeout  # Set the timeout here
          )
          output = ""
          while resp.is_open():
              resp.update(timeout=1)
              if resp.peek_stdout():
                line = resp.read_stdout()
                output += line
                # Write output to file
                with open(output_file, 'w') as f:
                    f.write(line)  # Append output to the file
              if resp.peek_stderr():
                line = resp.read_stderr()
                output += line
                # Write error output to file
                with open(output_file, 'w') as f:
                    f.write(line)  # Append error output to the file
          resp.close()
      except Exception as e:
          # Handle timeout exception
          if isinstance(e, ApiException) and e.status == 504:
              output += "\n" + TIMEOUT_MSG
              exit_code = 124  # Similar to Unix timeout exit code
          else:
              raise e
      else:
          # Parse the exit code from the output
          output_lines = output.strip().splitlines()
          if output_lines:
              exit_code_str = output_lines[-1]
              try:
                  exit_code = int(exit_code_str)
                  output = '\n'.join(output_lines[:-1])
              except ValueError:
                  # Could not parse exit code
                  exit_code = 1
          else:
              exit_code = 1
      return exit_code, output

    def restart(self) -> None:
        """(Experimental) Restart the code executor."""
        self.stop()
        # Recreate the pod
        self.__init__(
            image=self.image,
            pod_name=self.pod_name,
            namespace=self.namespace,
            timeout=self._timeout,
            work_dir=self._work_dir,
            execution_policies=self.execution_policies,
            remote_control_plane=self.remote_control_plane,
            kube_token=self._kube_token,
            shared_pvc_name=self.shared_pvc_name,
            node=self.node,
            shared_resources=self.shared_resources,
        )

    def stop(self) -> None:
        """(Experimental) Stop the code executor."""
        self._cleanup()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self, exc_type: Optional[Type[BaseException]], exc_val: Optional[BaseException], exc_tb: Optional[Any]
    ) -> None:
        self.stop()
