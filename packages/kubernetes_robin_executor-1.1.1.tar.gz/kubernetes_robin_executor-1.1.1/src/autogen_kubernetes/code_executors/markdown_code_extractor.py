import re
from typing import Any, Dict, List, Optional, Union

 
from autogen_kubernetes.code_executors.base import (
    CODE_BLOCK_PATTERN,
    UNKNOWN,
    CodeBlock,
    CodeExtractor,
    UserMessageImageContentPart,
    UserMessageTextContentPart,
    content_str,
    infer_lang,
)

__all__ = ("MarkdownCodeExtractor",)


import re
import ast



def is_python_code(codigo):
    try:
        ast.parse(codigo)
        return True
    except SyntaxError:
        return False

def fix_code(texto):
    inicio = 0
    while "```tool_code" in texto[inicio:]:
        inicio = texto.find("```tool_code", inicio)
        fin = texto.find("```", inicio + len("```tool_code"))
        if fin == -1:
            break
        
        codigo = texto[inicio + len("```tool_code"):fin]
        
        if is_python_code(codigo):
            texto = texto[:inicio] + "```python" + codigo + texto[fin:]
        
        inicio = fin + 3  # Avanzar para evitar un bucle infinito
    
    return texto

class MarkdownCodeExtractor(CodeExtractor):
    """(Experimental) A class that extracts code blocks from a message using Markdown syntax."""

    def extract_code_blocks(
        self, message: Union[str, List[Union[UserMessageTextContentPart, UserMessageImageContentPart]], None]
    ) -> List[CodeBlock]:
        """(Experimental) Extract code blocks from a message. If no code blocks are found,
        return an empty list.

        Args:
            message (str): The message to extract code blocks from.

        Returns:
            List[CodeBlock]: The extracted code blocks or an empty list.
        """

        text = content_str(message)
        text = fix_code(text)
        match = re.findall(CODE_BLOCK_PATTERN, text, flags=re.DOTALL)
        if not match:
            return []
        code_blocks = []
        for lang, code in match:
            if lang == "":
                lang = infer_lang(code)
            if lang == UNKNOWN:
                lang = ""
            code_blocks.append(CodeBlock(code=code, language=lang))
        return code_blocks
