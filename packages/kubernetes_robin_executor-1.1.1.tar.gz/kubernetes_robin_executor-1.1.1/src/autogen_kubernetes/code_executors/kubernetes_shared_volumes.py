
from kubernetes import client, stream, config
import shlex
import os 
import uuid
import signal
import atexit
from kubernetes.client.exceptions import ApiException
import time
import re


from pydantic import BaseModel
from typing import Optional

class PVCValidationResult(BaseModel):
    pvc_name: Optional[str] = None
    pv_name: Optional[str] = None
    pvc_has_uuid: bool = False
    pv_has_uuid: bool = False
    is_valid: bool = False



__all__ = ("KubernetesVolumeManager",)

class KubernetesVolumeManager:
    def __init__(
                self, 
                *,
                namespace: str,
                node:str = None, 
                remote_control_plane: str= None, 
                pv_name: str = None,
                pvc_name: str = None,
                storage_size: str = None 
            ):

        # Load Kubernetes configuration
        if remote_control_plane:
            kube_token = os.environ.get('KUBE_TOKEN')
            print(kube_token)
            print(kube_token)
            print(kube_token)
            if kube_token is None:
                raise EnvironmentError("Environment variable 'KUBE_TOKEN' is missing and is mandatory for remote kubernetes cluster.")
            configuration = client.Configuration()
            configuration.host = remote_control_plane
            configuration.verify_ssl = False
            configuration.api_key = {
                'authorization': f'Bearer {kube_token}'  # Reemplaza con tu token de acceso
            }
            self.api_client = client.ApiClient(configuration)
            self.api_instance = client.CoreV1Api(self.api_client)
        else:
            try:
                config.load_kube_config()
                self.api_client = None
            except config.ConfigException:
                config.load_incluster_config()
            #Local cluster
            self.api_instance = client.CoreV1Api()

        if node is not None:
            self.node_selector = {
                "kubernetes.io/hostname": node
            }
        else:
            # Omite el node_selector o no lo incluyas en la configuración
            self.node_selector = {}  # Esto puede ser vacío o simplemente no asignarlo
        

        self.node = node
        self.namespace = namespace

        if pv_name is None:
            pv_name = f"{namespace}-pv-{uuid.uuid4()}"
        self.pv_name = pv_name

        if pvc_name is None:
            pvc_name = f"{namespace}-pvc-{uuid.uuid4()}"
        self.pvc_name = pvc_name

        if storage_size is None:
            storage_size = "1Gi"
        self.storage_size = storage_size

            # Convertir el tamaño a un valor numérico en GiB para validar
        try:
            # Extraer la parte numérica del tamaño (asumiendo que está en Gi)
            size_value = float(storage_size[:-2])  # Eliminar 'Gi' y convertir a float
            unit = storage_size[-2:]  # Obtener la unidad (Gi)

            # Verificar que la unidad sea correcta
            if unit != "Gi":
                raise ValueError("Unidad de almacenamiento inválida. Debe ser 'Gi'.")

            # Verificar si el tamaño es negativo o mayor a 10Gi
            if size_value > 10:
                raise ValueError("El tamaño de almacenamiento no puede ser mayor a 10Gi.")
            elif size_value <= 0:
                raise ValueError("El tamaño de almacenamiento debe ser un valor positivo.")
        except ValueError as e:
            # Manejar cualquier error de conversión o validación
            raise ValueError(f"Error al procesar el tamaño de almacenamiento: {str(e)}")
        self.storage_size = storage_size


        def cleanup() -> None:
            try:
                self.delete_volumen_resourses()
            except ApiException as e:
                if e.status != 404:
                    raise e
            atexit.unregister(cleanup)

        # Registrar el manejador de señales para la interrupción
        signal.signal(signal.SIGINT, self.handle_sigint)

        atexit.register(cleanup)
        self._cleanup = cleanup


    def handle_sigint(self, signum, frame):
        print("Interrupción recibida, limpiando recursos...")
        self.cleanup()
        exit(0)
        
    def cleanup(self) -> None:
            try:
                self.delete_volumen_resourses()
            except ApiException as e:
                if e.status != 404:
                    raise e
            atexit.unregister(self.cleanup)

    def create_persistent_volume(self):

        # Verificar si el PersistentVolume ya existe
        try:
            existing_pv = self.api_instance.read_persistent_volume(name=self.pv_name)
            print(f"PersistentVolume '{self.pv_name}' ya existe. No se creará uno nuevo.")
            return  # Salir de la función si el PV ya existe
        except client.exceptions.ApiException as e:
            if e.status != 404:  # Si el error no es 404 (No encontrado), relanzar la excepción
                print(f"Error al verificar el PersistentVolume: {str(e)}")
                raise
        # Crear el PersistentVolume
        pv_spec = client.V1PersistentVolumeSpec(
            capacity={"storage": self.storage_size},  # Especifica el tamaño del almacenamiento
            access_modes=["ReadWriteMany"],  # Modo de acceso
            persistent_volume_reclaim_policy="Retain",  # Política de retención
            host_path=client.V1HostPathVolumeSource(path="/mnt/data")  # Ajusta según tu directorio
        )

        # Solo agregar `node_affinity` si `self.node` está definido
        if self.node:
            pv_spec.node_affinity = client.V1VolumeNodeAffinity(
                required=client.V1NodeSelector(
                    node_selector_terms=[
                        client.V1NodeSelectorTerm(
                            match_expressions=[
                                client.V1NodeSelectorRequirement(
                                    key="kubernetes.io/hostname",
                                    operator="In",
                                    values=[self.node]
                                )
                            ]
                        )
                    ]
                )
            )

        pv = client.V1PersistentVolume(
            metadata=client.V1ObjectMeta(name=self.pv_name),
            spec=pv_spec
        )

        # Intentar crear el PersistentVolume
        try:
            self.api_instance.create_persistent_volume(body=pv)
            self.wait_for_persistent_volume() 
            print(f"PersistentVolume '{self.pv_name}' creado exitosamente.")
        except client.exceptions.ApiException as e:
            print(f"Error al crear el PersistentVolume: {str(e)}")
            raise
    
    def wait_for_persistent_volume(self, timeout=10):
        """Esperar hasta que el PersistentVolume esté disponible."""
        start_time = time.time()
        while True:
            try:
                pv = self.api_instance.read_persistent_volume(name=self.pv_name)
                if pv.status.phase == "Available":
                    print(f"El PersistentVolume '{self.pv_name}' está disponible.")
                    return
            except ApiException as e:
                if e.status == 404:
                    print(f"Esperando la creación de PersistentVolume '{self.pv_name}'...")
                else:
                    raise
            
            if time.time() - start_time > timeout:
                raise TimeoutError(f"No se pudo crear el PersistentVolume '{self.pv_name}' en {timeout} segundos.")
            
            time.sleep(1)  # Espera 5 segundos antes de volver a verificar


    def wait_for_persistent_volume_claim(self, timeout=10):
        """Esperar hasta que el PersistentVolumeClaim esté vinculado a un PersistentVolume."""
        start_time = time.time()
        while True:
            try:
                pvc = self.api_instance.read_namespaced_persistent_volume_claim(name=self.pvc_name, namespace=self.namespace)
                if pvc.status.phase == "Bound":
                    print(f"El PersistentVolumeClaim '{self.pvc_name}' está vinculado a un PersistentVolume.")
                    return
            except ApiException as e:
                if e.status == 404:
                    print(f"Esperando la creación de PersistentVolumeClaim '{self.pvc_name}'...")
                else:
                    raise
            
            if time.time() - start_time > timeout:
                raise TimeoutError(f"No se pudo vincular el PersistentVolumeClaim '{self.pvc_name}' en {timeout} segundos.")
            
            time.sleep(1)  # Espera 5 segundos antes de volver a verificar


    def create_persistent_volume_claim(self):
        pvc = client.V1PersistentVolumeClaim(
            metadata=client.V1ObjectMeta(name=self.pvc_name),
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=["ReadWriteMany"],  # Debe coincidir con el acceso del PV
                resources=client.V1ResourceRequirements(
                    requests={"storage": self.storage_size}
                )
            )
        )

        try:
            self.api_instance.create_namespaced_persistent_volume_claim(namespace=self.namespace, body=pvc)
            self.wait_for_persistent_volume_claim()
            print(f"PersistentVolumeClaim '{self.pvc_name}' creado exitosamente en el namespace '{self.namespace}'.")
        except client.exceptions.ApiException as e:
            print(f"Error al crear el PersistentVolumeClaim: {str(e)}")
        
        return self.pvc_name

    def delete_persistent_volume(self):
        """Eliminar el PersistentVolume."""
        try:
            self.api_instance.delete_persistent_volume(name=self.pv_name)
            print(f"PersistentVolume '{self.pv_name}' eliminado exitosamente.")
        except client.exceptions.ApiException as e:
            print(f"Error al eliminar el PersistentVolume: {str(e)}")
            raise

    def delete_persistent_volume_claim(self):
        """Eliminar el PersistentVolumeClaim."""
        try:
            self.api_instance.delete_namespaced_persistent_volume_claim(name=self.pvc_name, namespace=self.namespace)
            print(f"PersistentVolumeClaim '{self.pvc_name}' eliminado exitosamente en el namespace '{self.namespace}'.")
        except client.exceptions.ApiException as e:
            print(f"Error al eliminar el PersistentVolumeClaim: {str(e)}")
            raise

    
    def delete_volumen_resourses(self):
        self.delete_persistent_volume_claim()
        self.delete_persistent_volume()
    

    def create_pod_with_volume(self, pod_name: str, image: str, pvc_name: str):
        pod = client.V1Pod(
            metadata=client.V1ObjectMeta(name=pod_name),
            spec=client.V1PodSpec(
                containers=[
                    client.V1Container(
                        name="shared-container",
                        command=["/bin/sh"],
                        tty=True,
                        stdin=True,
                        image=image,
                        volume_mounts=[
                            client.V1VolumeMount(
                                name="shared-storage",
                                mount_path="/mnt/shared"  # Ruta donde se montará el volumen en el contenedor
                            )
                        ]
                    )
                ],
                node_selector=self.node_selector,  # Nodo específico
                volumes=[
                    client.V1Volume(
                        name="shared-storage",
                        persistent_volume_claim=client.V1PersistentVolumeClaimVolumeSource(
                            claim_name=pvc_name
                        )
                    )
                ]
            )
        )

        try:
            self.api_instance.create_namespaced_pod(namespace=self.namespace, body=pod)
            print(f"Pod '{pod_name}' creado exitosamente en el namespace '{self.namespace}'.")
        except client.exceptions.ApiException as e:
            print(f"Error al crear el pod: {str(e)}")

    def _upload_file_to_pod(self, content: str, remote_path: str, pod_name) -> None:
        exec_command = ['sh', '-c', f'cat > {shlex.quote(remote_path)}']
        resp = stream.stream(
            self.api_instance.connect_get_namespaced_pod_exec,
            name=pod_name,
            namespace=self.namespace,
            command=exec_command,
            stderr=True, stdin=True,
            stdout=True, tty=False,
            _preload_content=False
        )
        try:
            resp.write_stdin(content)
            resp.update(timeout=5)
        except Exception as e:
            resp.close()
            raise e
        resp.close()


    def check_pv_pvc_association_pod(self) -> PVCValidationResult:
        """
        Función para validar el PVC y el PV relacionados con el pod.
        :return: PVCValidationResult con los datos del PVC y PV.
        """
        try:
            # Obtener el pod
            pod = self.api_instance.read_namespaced_pod(name=self.pod, namespace=self.namespace)

            # Buscar el nombre del PVC en la definición del pod
            pvc_name = None
            for vol in pod.spec.volumes:
                if vol.persistent_volume_claim:
                    pvc_name = vol.persistent_volume_claim.claim_name
                    break

            if not pvc_name:
                raise Exception("No se encontró ningún PersistentVolumeClaim en la definición del pod.")

            # Obtener información del PVC
            pvc = self.core_api.read_namespaced_persistent_volume_claim(name=pvc_name, namespace=self.namespace)

            pvc_result = {
                "pvc_name": pvc.metadata.name,
                "pvc_status": pvc.status.phase,
                "pvc_access_modes": pvc.spec.access_modes,
                "pvc_requested_storage": pvc.spec.resources.requests,
                "pv_name": None,
                "pv_status": None,
                "pv_capacity": None,
                "pv_access_modes": None,
            }

            # Validar la información del PV
            if pvc.spec.volume_name:
                pv = self.core_api.read_persistent_volume(name=pvc.spec.volume_name)
                pvc_result["pv_name"] = pv.metadata.name
                pvc_result["pv_status"] = pv.status.phase
                pvc_result["pv_capacity"] = pv.spec.capacity
                pvc_result["pv_access_modes"] = pv.spec.access_modes

            return PVCValidationResult(**pvc_result)

        except Exception as e:
            raise Exception(f"Error durante la validación del PVC/PV: {e}")
        
    def check_pv_pvc_association(self) -> PVCValidationResult:
        """
        Verifica si ya existe un PV y/o PVC asociado al nodo específico.

        Args:
            node_name (str): Nombre del nodo asociado al pod.
            namespace (str): Espacio de nombres donde se encuentran los recursos.

        Returns:
            dict: Diccionario con detalles del PV y PVC si existen, de lo contrario, valores vacíos.
        """
           # Patrón para detectar un UUID en el nombre
        uuid_pattern = re.compile(r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")

        # Buscar PVCs en el namespace
        pvcs = self.api_instance.list_namespaced_persistent_volume_claim(namespace=self.namespace)
        for pvc in pvcs.items:
            pv_name = pvc.spec.volume_name
                        # Validar si los nombres contienen un UUID
            pvc_has_uuid = bool(uuid_pattern.search(pvc.metadata.name))
            pv_has_uuid = bool(uuid_pattern.search(pv_name)) if pv_name else False

            values=  {
                "pvc_name": pvc.metadata.name,
                "pv_name": pv_name,
                "pvc_has_uuid": pvc_has_uuid,
                "pv_has_uuid": pv_has_uuid,
                "is_valid": pvc_has_uuid and pv_has_uuid
            }
            return PVCValidationResult(**values)



        # Si no se encuentra un PVC asociado al nodo
        values = {
            "pvc_name": None,
            "pv_name": None,
            "pvc_has_uuid": False,
            "pv_has_uuid": False,
            "is_valid": False
        }
        return PVCValidationResult(**values)