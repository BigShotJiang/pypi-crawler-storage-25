# Publicar este paquete en PyPI (solo uso local)

Este archivo **puede estar en `.gitignore`** del repo padre. Copia o renómbralo si cambias de máquina.

## Nombre en PyPI (definido en el proyecto)

El paquete se publica como **`kubernetes-robin-executor`** (`[project] name` en `pyproject.toml`).

El nombre **`autogen-kubernetes`** en PyPI sigue siendo el paquete oficial de AutoGen; **no** lo reutilices.

**Imports en Python:** sigue siendo `autogen_kubernetes...` (módulo bajo `src/autogen_kubernetes/`). El nombre en pip (`kubernetes-robin-executor`) es solo el identificador de distribución.

**README en PyPI:** `readme` en `pyproject.toml` apunta a  
`src/autogen_kubernetes/code_executors/README-KubernetesCommandLineCodeExecutor.md`  
(inglés, documentación del `KubernetesCommandLineCodeExecutor`).

Ruta del manifiesto:

`autogen-kubernetes/python/packages/autogen-kubernetes/pyproject.toml`

## Cuenta y token (no commitear nunca)

1. Cuenta en [pypi.org](https://pypi.org) (prueba en [test.pypi.org](https://test.pypi.org)).
2. Crear **API token**; usar usuario `__token__` y el token como contraseña con Twine (o `~/.pypirc`).

## Script automático (versión + build + subida)

Desde `autogen-kubernetes/python`:

```bash
python scripts/publish_kubernetes_robin_executor.py 1.0.3
python scripts/publish_kubernetes_robin_executor.py 1.0.3 --testpypi
python scripts/publish_kubernetes_robin_executor.py --dry-run
```

El script edita `version` en `pyproject.toml`, ejecuta `uv lock`, vacía `dist/`, `uv build`, y pide el token con entrada oculta antes de `twine upload`.

## Construir y subir

**Raíz del workspace Python en esta máquina** (donde está `uv.lock` y el `pyproject.toml` del workspace):

`/home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python`

Si tu clon está en otra ruta, cambia solo ese prefijo en los `cd`. Si el `cd` falla, `python -m build` puede correr con otro intérprete y dar `No module named build` o `dist/*` inexistente.

**Paquete** ( `pyproject.toml` del wheel):

`/home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python/packages/autogen-kubernetes`

### Opción recomendada: `uv` (mismo entorno que el proyecto)

```bash
cd /home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python
uv build --package kubernetes-robin-executor --out-dir dist
uvx twine check dist/*
```

Los artefactos quedan en  
`/home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python/dist/`  
(`.whl` y `.tar.gz`).

**TestPyPI:**

```bash
cd /home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python
uvx twine upload --repository testpypi dist/*
```

**PyPI:**

```bash
cd /home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python
uvx twine upload dist/*
```

### Opción clásica: `pip` + `python -m` (mismo intérprete siempre)

Instala y construye con **el mismo** `python` (evita mezclar con otro venv, p. ej. `autrain`):

```bash
cd /home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python/packages/autogen-kubernetes
python3 -m pip install build twine
python3 -m build
python3 -m twine check dist/*
```

Aquí `dist/` queda en:

`/home/wgomez/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/python/packages/autogen-kubernetes/dist/`

**TestPyPI / PyPI:** `twine upload ... dist/*` desde esa misma carpeta (`packages/autogen-kubernetes`), donde se creó `dist/`.

## Usar en otro proyecto

```bash
pip install kubernetes-robin-executor
```

```python
from autogen_kubernetes.code_executors.kubernetes_commandline_code_executor import (
    KubernetesCommandLineCodeExecutor,
)
```

## Artefactos locales

Los directorios `dist/` y `*.egg-info` suelen ignorarse en git; no hace falta subirlos.
