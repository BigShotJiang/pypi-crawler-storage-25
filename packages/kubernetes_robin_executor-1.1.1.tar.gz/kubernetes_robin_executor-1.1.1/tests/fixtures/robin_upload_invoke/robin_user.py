"""Fixture module uploaded from disk in ``test_upload_from_disk_and_invoke_long_function``.

Not imported by the test host; only read as text and pushed to the pod.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata
from typing import Any, Dict, List, Tuple


def _normalize_line(line: str) -> str:
    """Fold unicode, strip noise; keep tests deterministic across pod images."""
    s = unicodedata.normalize("NFKC", line)
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def _tokenize(paragraph: str) -> List[str]:
    if not paragraph:
        return []
    cleaned = re.sub(r"[^\w\s]", " ", paragraph, flags=re.UNICODE)
    return [t for t in cleaned.split() if t]


def _rolling_hash(tokens: List[str], rounds: int) -> str:
    """Cheap CPU work so the function is non-trivial without extra deps."""
    acc = hashlib.sha256()
    for r in range(max(1, rounds)):
        for i, tok in enumerate(tokens):
            piece = f"{r}:{i}:{tok}".encode("utf-8", errors="replace")
            acc.update(piece)
    return acc.hexdigest()


def run_heavy_pipeline(
    text: str,
    rounds: int = 2,
    max_lines: int = 500,
) -> Dict[str, Any]:
    """
    Summarize *text*: lines, token counts, top tokens, rolling hash.

    Kept intentionally verbose so the uploaded file is "relatively long"
    and exercises a realistic multi-step local module on the pod.
    """
    raw_lines = text.splitlines()
    lines = raw_lines[: max(1, max_lines)]
    normalized = [_normalize_line(L) for L in lines if L.strip()]

    all_tokens: List[str] = []
    for para in normalized:
        all_tokens.extend(_tokenize(para))

    freq: Dict[str, int] = {}
    for tok in all_tokens:
        freq[tok] = freq.get(tok, 0) + 1

    top_n = 12
    ranking: List[Tuple[str, int]] = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))[:top_n]

    digest = _rolling_hash(all_tokens, rounds=rounds)

    return {
        "line_count": len(lines),
        "non_empty_line_count": len(normalized),
        "token_count": len(all_tokens),
        "unique_tokens": len(freq),
        "top_tokens": ranking,
        "digest": digest,
        "rounds_used": max(1, rounds),
    }


def greet(name: str) -> str:
    """Tiny helper to sanity-check imports without heavy work."""
    return f"robin_fixture_ok:{name}"
