# Pruebas de `autogen-kubernetes`

## Publicar el paquete en PyPI

Las instrucciones de build/upload y el aviso sobre el nombre `autogen-kubernetes` en PyPI están en **`PYPI-publish.local.md`** (misma carpeta que este README). Ese archivo **no se sube a GitHub** (`.gitignore` en la raíz del repo). Si no lo ves, créalo copiando el contenido que tengas en tu máquina o pide el archivo a quien lo mantenga.

---

## Tests de integración Robin (`KubernetesCommandLineCodeExecutor`)

Estos tests **no son unit tests**: llaman al API real del clúster (crean o reutilizan pods, ejecutan código dentro del pod). Si algo “no funciona”, casi siempre es **red**, **token**, **namespace** o **RBAC**.

### 1. Dónde debe estar el `.env` (muy importante)

El archivo `load_dotenv` busca:

`autogen-kubernetes/.env` (o el primero que se encuentre subiendo carpetas desde el test).

Para forzar una ruta concreta (recomendado):

```env
ROBIN_ENV_FILE=/home/TU_USUARIO/Documents/GitHub/KubernetesRobinExecutor/autogen-kubernetes/.env
```

También acepta la variable `AUTOGEN_KUBERNETES_ENV_FILE`. Sin ellas, se busca el primer `.env` en ancestros del archivo de test (normalmente la raíz del clon `autogen-kubernetes`).

Ejemplo de ruta si el clon está dentro de otro repo:

```text
.../KubernetesRobinExecutor/autogen-kubernetes/.env   ← aquí
.../KubernetesRobinExecutor/autogen-kubernetes/python/...
```

Si el `.env` está en otro sitio, los tests se saltarán o el token no se cargará.

### 2. Variables mínimas en `.env`

```env
KUBE_TOKEN=<token del ServiceAccount o usuario, una sola línea>
REMOTE_CONTROL_PLANE=https://<IP-o-host>:6443
```

Opcionales (sobrescriben valores por defecto del test):

| Variable | Ejemplo | Notas |
|----------|---------|--------|
| `ROBIN_NAMESPACE` | `alitasciudad-f5534ed4-3185-40ca-8985-9e752ad0dd93` | Si no se define, el test usa este namespace por defecto (véase `test_kubernetes_commandline_executor.py`). |
| `ROBIN_IMAGE` | `williamgomez712/robin_executor_python:latest` | Debe coincidir con la imagen del pod si usas `shared_resources`. |
| `ROBIN_WORK_DIR` | `/tmp/robin_executor_test` | Directorio de trabajo **dentro** del pod. |
| `ROBIN_TIMEOUT` | `120` | Segundos. |
| `ROBIN_SHARED_RESOURCES` | `false` (default en tests) | `true`: reutiliza un pod con la misma imagen (riesgo si ese pod usó otro `work_dir`). `false`: suele crear un pod alineado con `ROBIN_WORK_DIR`. |
| `ROBIN_NODE` | `mi-nodo` | Solo si quieres fijar `nodeSelector`; déjalo sin definir para no limitar nodo. |

**Evita** tener `KUBE_TOKEN` repetido dos veces en el mismo `.env`: `python-dotenv` deja el valor de la **última** aparición y puede parecer “raro” si esperabas la primera.

En estos tests se usa `load_dotenv(..., override=True)` para que el `.env` **gane** sobre variables que ya tengas exportadas en la terminal (`export KUBE_TOKEN=...`). Si antes parecía que “no leía el .env”, prueba `unset KUBE_TOKEN REMOTE_CONTROL_PLANE` y vuelve a correr pytest.

### 3. Entorno Python

Desde la carpeta **`autogen-kubernetes/python`** (donde están `pyproject.toml` y `.venv`):

```bash
cd /ruta/al/autogen-kubernetes/python
uv sync --all-extras
```

### 4. Comandos recomendados (copiar y pegar)

Ejecutar **solo** los tests Robin, **un proceso** (evita carreras si varios tests crean pods a la vez):

```bash
cd /ruta/al/autogen-kubernetes/python
uv run pytest packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py -m robin_remote -v -s -n0
```

Solo **un** test:

```bash
uv run pytest packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py::test_execute_python_print -v -s -n0
```

Ver por qué algo se saltó:

```bash
uv run pytest packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py -m robin_remote -v -ra -n0
```

Sin `uv` (venv ya activado):

```bash
cd /ruta/al/autogen-kubernetes/python
source .venv/bin/activate
pytest packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py -m robin_remote -v -s -n0
```

### 5. Comportamiento del executor (por qué puede parecer “raro”)

- Con **`shared_resources=true`**: si ya existe un pod **Running** con **la misma** `image` en el namespace, **reutiliza** ese nombre de pod. Al hacer `stop()` / salir del `with`, el código puede **eliminar** ese pod.
- Con **`shared_resources=false`**: suele **crear** un pod nuevo (`robin-code-exec-<uuid>` por defecto) y también lo borra al cerrar.

Si “nada funciona”, prueba en `.env`:

```env
ROBIN_SHARED_RESOURCES=false
```

así cada run es más aislado (más pods creados/borrados, pero menos colisión con un pod compartido).

### 6. Comprobar credenciales fuera de pytest

Sustituye namespace y URL por los tuyos:

```bash
export KUBE_TOKEN="..."   # o source manual del .env
curl -k -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $KUBE_TOKEN" \
  "https://TU_API_SERVER:6443/api/v1/namespaces/TU_NAMESPACE/pods"
```

Un `200` o JSON con lista de pods indica que token + URL + namespace son al menos alcanzables. `401`/`403` = token o permisos.

### 6.1 Si ves `403 Forbidden` y un `User "system:serviceaccount:..."`

El API server está rechazando **RBAC**, no pytest. Ejemplo:

`pods is forbidden: User "system:serviceaccount:mi-ns:mi-sa" cannot create resource "pods" in ... namespace "alitasciudad-..."`

Significa: el **JWT en `KUBE_TOKEN`** corresponde a ese ServiceAccount, y ese SA **no tiene** permisos para `list` / `create` / `delete` pods (y exec) en el namespace que usas (`ROBIN_NAMESPACE`).

**Qué hacer en el clúster (no en Python):**

- Dar al SA un `Role` / `ClusterRoleBinding` o `RoleBinding` en ese namespace con verbos típicos: `get`, `list`, `watch`, `create`, `delete` sobre `pods` y a menudo `pods/exec` para `kubectl exec` / stream; o
- Cambiar `ROBIN_NAMESPACE` al namespace donde ese SA **sí** tenga esos permisos; o
- Sustituir `KUBE_TOKEN` por el token de **otro** SA o usuario con esos permisos.

Si tienes **dos** líneas `KUBE_TOKEN` en `.env`, `python-dotenv` aplica la **última**: puede que estés usando el token equivocado.

El aviso `Using inCluster Config` suele venir de otro módulo al importar; lo relevante es el cuerpo del `403`, que identifica al usuario real del token.

### 7. Resto de tests del paquete (kubeconfig local)

Los otros tests en esta carpeta usan `PodCommandLineCodeExecutor` y `config.load_kube_config()`: requieren **kubeconfig** válido en la máquina, no el `.env` de Robin.

```bash
cd /ruta/al/autogen-kubernetes/python
uv run pytest packages/autogen-kubernetes/tests/ -v --ignore=packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py
```

---

Si tras esto sigue fallando, el siguiente dato útil es el **primer error** de pytest (línea `ApiException`, `403`, `404 namespace`, timeout al pod `Running`, etc.) y confirmar que el `.env` está en la raíz `autogen-kubernetes/` como en la sección 1.
