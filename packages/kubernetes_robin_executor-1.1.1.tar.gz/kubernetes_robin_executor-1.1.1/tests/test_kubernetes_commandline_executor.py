"""Integration tests for KubernetesCommandLineCodeExecutor (remote API via bearer token).

Loads ``.env`` in este orden:

1. Archivo en ``ROBIN_ENV_FILE`` o ``AUTOGEN_KUBERNETES_ENV_FILE`` (ruta absoluta recomendada).
2. El primer ``.env`` encontrado subiendo directorios desde este archivo (suele ser
   ``.../autogen-kubernetes/.env``).

Usa ``python-dotenv`` con ``override=True``. Variables: ``KUBE_TOKEN``, ``REMOTE_CONTROL_PLANE``.

Default namespace is ``alitasciudad-f5534ed4-3185-40ca-8985-9e752ad0dd93``; override with ``ROBIN_NAMESPACE``.
Optional overrides: ``ROBIN_IMAGE``, ``ROBIN_WORK_DIR``, ``ROBIN_TIMEOUT``, ``ROBIN_SHARED_RESOURCES`` (``true``/``false``).
Set ``ROBIN_NODE`` only if you want to pin the pod to a node hostname.

Run (from ``autogen-kubernetes/python``)::

    uv run pytest packages/autogen-kubernetes/tests/test_kubernetes_commandline_executor.py -m robin_remote -s"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from dotenv import load_dotenv

from autogen_kubernetes.code_executors.base import CodeBlock, CommandLineCodeResult
from autogen_kubernetes.code_executors.kubernetes_commandline_code_executor import (
    KubernetesCommandLineCodeExecutor,
)
from autogen_kubernetes.code_executors.markdown_code_extractor import MarkdownCodeExtractor


def _repo_root_autogen_kubernetes() -> Path:
    """``tests`` -> package -> ``packages`` -> ``python`` -> ``autogen-kubernetes`` clone root."""
    return Path(__file__).resolve().parents[4]


def _dotenv_file() -> Path | None:
    """Ruta al .env: explícita por env, o la primera encontrada hacia arriba desde este test."""
    for key in ("ROBIN_ENV_FILE", "AUTOGEN_KUBERNETES_ENV_FILE"):
        raw = (os.environ.get(key) or "").strip()
        if raw:
            p = Path(raw).expanduser().resolve()
            return p if p.is_file() else None
    here = Path(__file__).resolve().parent
    for d in [here, *here.parents]:
        candidate = d / ".env"
        if candidate.is_file():
            return candidate
    fallback = _repo_root_autogen_kubernetes() / ".env"
    return fallback if fallback.is_file() else None


def _load_dotenv() -> Path | None:
    env_path = _dotenv_file()
    if env_path is not None:
        # Sin override=True, variables ya exportadas en el shell ganan y el .env parece "no aplicar".
        load_dotenv(env_path, override=True)
        return env_path
    return None


def _remote_robin_configured() -> bool:
    _load_dotenv()
    return bool(os.environ.get("KUBE_TOKEN") and os.environ.get("REMOTE_CONTROL_PLANE"))


_REMOTE_OK = _remote_robin_configured()


def _env_bool(key: str, default: bool) -> bool:
    v = os.environ.get(key)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _node_from_env() -> str | None:
    """No node pinning unless ``ROBIN_NODE`` is set to a non-empty hostname."""
    raw = os.environ.get("ROBIN_NODE", "").strip()
    return raw if raw else None


def _robin_upload_fixture_dir() -> Path:
    """Directory with ``robin_user.py`` for :func:`test_upload_from_disk_and_invoke_long_function`."""
    return Path(__file__).resolve().parent / "fixtures" / "robin_upload_invoke"


def _make_executor() -> KubernetesCommandLineCodeExecutor:
    _load_dotenv()
    executor = KubernetesCommandLineCodeExecutor(
        image=os.environ.get("ROBIN_IMAGE", "williamgomez712/robin_executor_python:latest"),
        timeout=int(os.environ.get("ROBIN_TIMEOUT", "120")),
        work_dir=os.environ.get("ROBIN_WORK_DIR", "/tmp/robin_executor_test"),
        namespace=os.environ.get(
            "ROBIN_NAMESPACE", "alitasciudad-f5534ed4-3185-40ca-8985-9e752ad0dd93"
        ),
        node=_node_from_env(),
        remote_control_plane=os.environ["REMOTE_CONTROL_PLANE"],
        # false evita reutilizar un pod creado con otro work_dir (archivo "no encontrado").
        shared_resources=_env_bool("ROBIN_SHARED_RESOURCES", False),
    )
    print(
        f"[robin_remote] namespace={executor.namespace!r} pod={executor.pod_name!r}",
        flush=True,
    )
    return executor


def _print_exec_result(result: CommandLineCodeResult) -> None:
    print(f"[robin_remote] exit_code={result.exit_code} code_file={result.code_file!r}", flush=True)
    print(f"[robin_remote] output:\n{result.output}", flush=True)


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_code_extractor_is_markdown_extractor() -> None:
    with _make_executor() as executor:
        assert isinstance(executor.code_extractor, MarkdownCodeExtractor)


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_execute_python_print() -> None:
    with _make_executor() as executor:
        result = executor.execute_code_blocks(
            [CodeBlock(language="python", code="print('robin_py_ok')")]
        )
    _print_exec_result(result)
    assert result.exit_code == 0
    assert "robin_py_ok" in result.output


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_execute_shell_echo() -> None:
    with _make_executor() as executor:
        result = executor.execute_code_blocks(
            [CodeBlock(language="sh", code="echo robin_sh_ok")]
        )
    _print_exec_result(result)
    assert result.exit_code == 0
    assert "robin_sh_ok" in result.output


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_save_without_execute_policy() -> None:
    with _make_executor() as executor:
        executor.execution_policies["python"] = False
        result = executor.execute_code_blocks(
            [CodeBlock(language="python", code="print('should_not_run')")]
        )
    _print_exec_result(result)
    assert result.exit_code == 0
    assert "Code saved to" in result.output
    assert "should_not_run" not in result.output


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_execute_tool_function_smoke() -> None:
    """Requires ``executor.py`` in the container image (Robin image)."""
    with _make_executor() as executor:
        result = executor.execute_tool_function(
            {"x": 1},
            func_name="nonexistent_tool_smoke",
        )
    _print_exec_result(result)
    assert isinstance(result.exit_code, int)
    assert isinstance(result.output, str)


@pytest.mark.robin_remote
@pytest.mark.skipif(not _REMOTE_OK, reason="Set KUBE_TOKEN and REMOTE_CONTROL_PLANE in autogen-kubernetes/.env")
def test_upload_from_disk_and_invoke_long_function() -> None:
    """Upload local ``fixtures/robin_upload_invoke/`` then call ``run_heavy_pipeline`` on the pod."""
    fixture_dir = _robin_upload_fixture_dir()
    assert fixture_dir.is_dir(), f"Missing fixture dir: {fixture_dir}"

    sample = ("Hello world.\n" * 25) + "world world banana\n" + ("noise line\n" * 10)

    with _make_executor() as executor:
        executor.install_pod_dispatcher(default_module="robin_user")
        written = executor.upload_from_disk(fixture_dir)
        assert written, "expected upload_from_disk to write at least one file"
        print(f"[robin_remote] uploaded {len(written)} file(s) from {fixture_dir}", flush=True)

        r_greet = executor.execute_tool_function(
            {"name": "upload_invoke"},
            "greet",
            module="robin_user",
        )
        _print_exec_result(r_greet)
        assert r_greet.exit_code == 0
        assert "robin_fixture_ok:upload_invoke" in r_greet.output

        result = executor.execute_tool_function(
            {"text": sample, "rounds": 4, "max_lines": 200},
            "run_heavy_pipeline",
            module="robin_user",
        )

    _print_exec_result(result)
    assert result.exit_code == 0
    assert "digest" in result.output
    assert "line_count" in result.output
    assert "token_count" in result.output
