# 发布流程 (publish)

发布 todo.md 中的指定条目，完成功能开发闭环。

## 发布流程

### 步骤 1：确认目标

在 `todo.md` 中找到要发布的条目，确认其"验收标准"。

### 步骤 2：更新版本

修改 `pyproject.toml` 版本号（第4位 +1）。

例如：当前版本 `0.1.3.1`，发布后变为 `0.1.3.2`。

### 步骤 3：提交代码

```
git add .
git commit -m "feat: 发布 {功能名称}"
git push
```

### 步骤 4：构建发布

```bash
uv build && uv publish
```

### 步骤 5：本地安装测试

```bash
pip install zcyclaw
zcyclaw --version
```

根据本次发布的功能，执行对应的功能测试命令。

### 步骤 5：验收判断

- **验收成功** → 进入发布记录步骤
- **验收失败** → 进入失败记录步骤

### 步骤 6：发布记录

验收成功后：

1. 在 `docs/publish/` 下创建 `publish-{版本号}.md`
2. 将 `todo.md` 条目移至 `done.md`，填入完成时间
3. 提交 todo/done 变更
4. `git push`

### 步骤 7：失败记录

验收失败后：

1. 在 `docs/publish/` 下创建 `publish-{版本号}-fail.md`，记录失败原因和修复方向
2. 继续修改代码后重新发布

---

## 发布记录文件格式

### 成功：`docs/publish/publish-{版本号}.md`

```markdown
# 发布记录 v{版本号}

## 发布内容

| 条目 | 模块 | 验收标准 | 验收结果 |
|------|------|----------|----------|
| 1 | tui | zcyclaw tui 命令可正常启动 | ✅ 通过 |

## 安装测试

### 通用测试
- [x] `pip install zcyclaw` 安装成功
- [x] `zcyclaw --version` 输出 `{版本号}`

### 功能测试
- [x] `zcyclaw tui` 启动正常，界面显示无异常
- [x] 在 TUI 中输入问题，收到回答

## 发布信息

- 发布版本：v{版本号}
- 发布日期：{YYYY-MM-DD}
- 发布人：Claude
```

### 失败：`docs/publish/publish-{版本号}-fail.md`

```markdown
# 发布记录 v{版本号} (验收失败)

## 发布内容

| 条目 | 模块 | 验收标准 | 验收结果 |
|------|------|----------|----------|
| 1 | tui | zcyclaw tui 命令可正常启动 | ❌ 失败 |

## 安装测试

### 通用测试
- [x] `pip install zcyclaw` 安装成功
- [x] `zcyclaw --version` 输出 `{版本号}`

### 功能测试
- [ ] `zcyclaw tui` 启动正常，界面显示无异常 ❌

## 问题描述

{描述验收失败的具体问题}

## 修复方向

{描述下一步修复方向}

## 发布信息

- 发布版本：v{版本号}
- 发布日期：{YYYY-MM-DD}
- 发布人：Claude
```

---

## 版本号规范

- 格式：`MAJOR.MINOR.PATCH.BUILD`（如 `0.1.3.1`）
- 发版时仅递增第4位 BUILD 号
