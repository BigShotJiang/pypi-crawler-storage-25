# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Skills 触发条件

| Skill | 触发语句 | 说明 |
|-------|----------|------|
| develop | 开发和发布todo里面的[序号]、[序号]功能 | plan + Ralph Loop + publish 完整闭环 |
| plan | 用plan模式开始任务 | 使用 planning-with-files 进行任务规划 |
| commit | 每次提交代码时自动触发 | 提交代码流程（单元测试→提交→todo/done联动） |
| review | 每次项目复盘时自动触发 | 生成复盘报告并同步问题到 todo.md |
| publish | 发布todo里面的[序号]、[序号]的功能 | 执行功能发布和验收闭环 |
| self-test | 自测自优化[测试命令] | 启动测试→失败修复发布→循环直到通过 |

---

## 语言要求

本项目所有沟通、文档、代码注释、commit message 均使用**中文**。

## 开发规范

1. **专业准确优先**: 所有回答必须标注法条来源，可追溯，不知道就直说
2. 编码前先思考：不确定时要询问，不要默认选一种解释就开始实现。
3. 简约至上：避免过度设计。
4. 精确编辑：只改与任务相关的代码。
5. 目标驱动：先把模糊需求落成可验证的目标。
6. 测试同步（硬约束）：所有代码都必须写单元测试。覆盖率门槛：方法覆盖率 ≥85%、行覆盖率 ≥75%。
