"""
Mimir auto-instrumentation for the raw Anthropic Python client.

Patches messages.create (sync and async) on the class level
so every Anthropic client instance is automatically instrumented.

    import mimir
    mimir.instrument_anthropic()
"""

from __future__ import annotations

import time
from typing import Any

from .sdk import Task, Run, _safe_serialize, get_active_run

# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

_instrumented = False
_original_create = None
_original_async_create = None
_task_cache: dict[str, Task] = {}  # model -> Task


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_task(model: str, tools: list[str] | None = None) -> Task:
    if model not in _task_cache:
        _task_cache[model] = Task(
            name=model,
            config=model,
            tools=tools or [],
            model=model,
        )
    return _task_cache[model]


def _extract_prompt(messages) -> str:
    """Walk backward through messages to find the last user message."""
    if not messages:
        return ""
    for msg in reversed(messages):
        if isinstance(msg, dict):
            role = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user" and isinstance(content, str) and content:
                return content[:500]
            # Handle content blocks
            if role == "user" and isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text = block.get("text", "")
                        if text:
                            return text[:500]
    return ""


def _extract_tool_names(tools) -> list[str]:
    """Extract tool names from the tools parameter."""
    if not tools:
        return []
    names = []
    for t in tools:
        if isinstance(t, dict):
            name = t.get("name", "")
            if name:
                names.append(name)
    return names


def _process_response(run: Run, response, duration_ms: float) -> None:
    """Extract tool use, usage, and content from an Anthropic response."""
    # Usage
    usage = getattr(response, "usage", None)
    if usage:
        inp = getattr(usage, "input_tokens", 0) or 0
        out = getattr(usage, "output_tokens", 0) or 0
        run.set_usage(inp, out)

    # Process content blocks
    content = getattr(response, "content", []) or []
    for block in content:
        block_type = getattr(block, "type", "")

        if block_type == "tool_use":
            name = getattr(block, "name", "unknown")
            inp = _safe_serialize(getattr(block, "input", {}))
            run.tool(name, inp, None, 0)

        elif block_type == "text":
            text = getattr(block, "text", "")
            if text and text.strip():
                run.reasoning(text[:2000])

        elif block_type == "thinking":
            thinking = getattr(block, "thinking", "")
            if thinking:
                run.reasoning(f"[thinking] {thinking[:2000]}")

    # Stop reason
    stop = getattr(response, "stop_reason", None)
    if stop and stop not in ("end_turn", "stop_sequence"):
        run.reasoning(f"[stop_reason: {stop}]")


# ---------------------------------------------------------------------------
# Patching
# ---------------------------------------------------------------------------


def instrument_anthropic() -> None:
    """Patch Anthropic messages.create to auto-capture every call."""
    global _instrumented, _original_create, _original_async_create

    if _instrumented:
        return

    try:
        from anthropic.resources.messages.messages import Messages, AsyncMessages
    except ImportError:
        raise ImportError(
            "Could not import 'anthropic'. Install it: pip install anthropic"
        )

    _original_create = Messages.create
    _original_async_create = AsyncMessages.create

    def _patched_create(self, *, max_tokens, messages, model, **kwargs):
        active = get_active_run()
        start = time.time()

        if active:
            # Inside an existing run — add steps, don't create a new run
            try:
                result = _original_create(self, max_tokens=max_tokens, messages=messages, model=model, **kwargs)
            except Exception as e:
                active.tool_error("messages.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            _process_response(active, result, (time.time() - start) * 1000)
            return result
        else:
            # No active run — create one (single-call use case)
            tools = kwargs.get("tools")
            task = _get_task(model, _extract_tool_names(tools))
            prompt = _extract_prompt(messages)
            with task.run(input={"prompt": prompt}) as run:
                try:
                    result = _original_create(self, max_tokens=max_tokens, messages=messages, model=model, **kwargs)
                except Exception as e:
                    run.tool_error("messages.create", {"model": model}, str(e), (time.time() - start) * 1000)
                    raise
                _process_response(run, result, (time.time() - start) * 1000)
                run.set_output(_safe_serialize([
                    {"type": getattr(b, "type", ""), "text": getattr(b, "text", "")[:200]}
                    for b in (getattr(result, "content", []) or [])
                ]))
                return result

    async def _patched_async_create(self, *, max_tokens, messages, model, **kwargs):
        active = get_active_run()
        start = time.time()

        if active:
            try:
                result = await _original_async_create(self, max_tokens=max_tokens, messages=messages, model=model, **kwargs)
            except Exception as e:
                active.tool_error("messages.create", {"model": model}, str(e), (time.time() - start) * 1000)
                raise
            _process_response(active, result, (time.time() - start) * 1000)
            return result
        else:
            tools = kwargs.get("tools")
            task = _get_task(model, _extract_tool_names(tools))
            prompt = _extract_prompt(messages)
            with task.run(input={"prompt": prompt}) as run:
                try:
                    result = await _original_async_create(self, max_tokens=max_tokens, messages=messages, model=model, **kwargs)
                except Exception as e:
                    run.tool_error("messages.create", {"model": model}, str(e), (time.time() - start) * 1000)
                    raise
                _process_response(run, result, (time.time() - start) * 1000)
                run.set_output(_safe_serialize([
                    {"type": getattr(b, "type", ""), "text": getattr(b, "text", "")[:200]}
                    for b in (getattr(result, "content", []) or [])
                ]))
                return result

    Messages.create = _patched_create
    AsyncMessages.create = _patched_async_create
    _instrumented = True


def uninstrument_anthropic() -> None:
    """Restore original Anthropic client methods."""
    global _instrumented, _original_create, _original_async_create

    if not _instrumented:
        return

    try:
        from anthropic.resources.messages.messages import Messages, AsyncMessages
    except ImportError:
        return

    if _original_create is not None:
        Messages.create = _original_create
    if _original_async_create is not None:
        AsyncMessages.create = _original_async_create

    _instrumented = False
    _original_create = None
    _original_async_create = None
    _task_cache.clear()
