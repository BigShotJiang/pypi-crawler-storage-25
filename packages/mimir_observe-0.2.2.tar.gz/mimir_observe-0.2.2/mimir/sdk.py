"""
Mimir SDK — core primitives for agent observability.

Zero external dependencies (stdlib only).
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from http.client import HTTPConnection
from typing import Any
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_DASHBOARD_URL = "http://localhost:9847"


def configure(dashboard_url: str | None = None) -> None:
    """Override the dashboard URL (default: http://localhost:9847)."""
    global _DASHBOARD_URL
    if dashboard_url is not None:
        _DASHBOARD_URL = dashboard_url.rstrip("/")


# ---------------------------------------------------------------------------
# HTTP helpers — fire-and-forget via daemon threads, stdlib only
# ---------------------------------------------------------------------------


def _post(path: str, payload: dict, *, sync: bool = False, timeout: float = 5.0) -> None:
    """POST JSON to the dashboard.  Fire-and-forget unless *sync* is True."""

    def _do():
        try:
            parsed = urlparse(_DASHBOARD_URL)
            conn = HTTPConnection(parsed.hostname, parsed.port or 80, timeout=timeout)
            body = json.dumps(payload).encode()
            conn.request("POST", path, body=body, headers={"Content-Type": "application/json"})
            conn.getresponse().read()
            conn.close()
        except Exception:
            pass  # dashboard down — never break the agent

    if sync:
        _do()
    else:
        t = threading.Thread(target=_do, daemon=True)
        t.start()


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


class Task:
    """Represents an agent identity.  Stable across runs via config_hash."""

    def __init__(self, name: str, config: str, tools: list[str] | None = None, model: str = ""):
        self.name = name
        self.config = config
        self.tools = tools or []
        self.model = model

        self.config_hash = hashlib.sha256(config.encode()).hexdigest()[:12]
        self.task_type_id = f"tg_{self.config_hash}"
        self._registered = False

    def _register(self) -> None:
        if self._registered:
            return
        _post("/api/task/register", {
            "task_type_id": self.task_type_id,
            "name": self.name,
            "config": self.config,
            "config_hash": self.config_hash,
            "tools": self.tools,
            "model": self.model,
        })
        self._registered = True

    def run(self, input: dict[str, Any] | None = None) -> Run:
        """Create a Run context manager for a single agent execution."""
        self._register()
        return Run(task=self, input=input or {})


# ---------------------------------------------------------------------------
# Active run context — lets raw client instrumentation detect agentic loops
# ---------------------------------------------------------------------------

_context = threading.local()


def get_active_run() -> Run | None:
    """Return the Run currently open on this thread, or None."""
    return getattr(_context, "active_run", None)


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------


class Run:
    """Brackets a single agent execution.  Use as a context manager."""

    def __init__(self, task: Task, input: dict[str, Any]):
        self.task = task
        self.input = input
        self.run_id = uuid.uuid4().hex[:16]
        self.steps: list[dict] = []
        self.usage: dict[str, int] = {"input_tokens": 0, "output_tokens": 0}
        self.cost_usd: float | None = None
        self.output: Any = None
        self.status = "running"
        self._start_time: float = 0.0
        self._parent_run: Run | None = None  # for nesting

    def __enter__(self) -> Run:
        self._start_time = time.time()
        # Push onto the context stack
        self._parent_run = getattr(_context, "active_run", None)
        _context.active_run = self
        _post("/api/run/start", {
            "run_id": self.run_id,
            "task_type_id": self.task.task_type_id,
            "task_name": self.task.name,
            "input": self.input,
            "started_at": self._start_time,
        })
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        # Pop from the context stack
        _context.active_run = self._parent_run
        elapsed = time.time() - self._start_time
        self.status = "error" if exc_type else "success"
        # Brief sleep to let pending daemon threads flush
        time.sleep(0.2)
        _post("/api/run/end", {
            "run_id": self.run_id,
            "task_type_id": self.task.task_type_id,
            "task_name": self.task.name,
            "status": self.status,
            "duration_s": round(elapsed, 3),
            "steps": self.steps,
            "usage": self.usage,
            "cost_usd": self.cost_usd,
            "output": _safe_serialize(self.output),
            "ended_at": time.time(),
        }, sync=True)

    # --- step recorders ---

    def tool(self, name: str, args: Any = None, result: Any = None, duration_ms: float = 0) -> None:
        step = {
            "type": "tool",
            "tool": name,
            "args": _safe_serialize(args),
            "result": _safe_serialize(result),
            "duration_ms": round(duration_ms, 1),
            "ts": time.time(),
        }
        self.steps.append(step)
        _post("/api/run/step", {"run_id": self.run_id, **step})

    def tool_error(self, name: str, args: Any = None, error: str = "", duration_ms: float = 0) -> None:
        step = {
            "type": "tool_error",
            "tool": name,
            "args": _safe_serialize(args),
            "error": str(error),
            "duration_ms": round(duration_ms, 1),
            "ts": time.time(),
        }
        self.steps.append(step)
        _post("/api/run/step", {"run_id": self.run_id, **step})

    def reasoning(self, text: str, tokens: int = 0) -> None:
        step = {
            "type": "reasoning",
            "text": text[:2000],
            "tokens": tokens,
            "ts": time.time(),
        }
        self.steps.append(step)
        _post("/api/run/step", {"run_id": self.run_id, **step})

    def set_usage(self, input_tokens: int, output_tokens: int) -> None:
        self.usage = {"input_tokens": input_tokens, "output_tokens": output_tokens}

    def set_cost(self, cost_usd: float) -> None:
        self.cost_usd = cost_usd

    def set_output(self, output: Any) -> None:
        self.output = output


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_serialize(obj: Any) -> Any:
    """Best-effort JSON-safe conversion."""
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): _safe_serialize(v) for k, v in obj.items()}
    # Fall back to str repr, truncated
    return str(obj)[:1000]
