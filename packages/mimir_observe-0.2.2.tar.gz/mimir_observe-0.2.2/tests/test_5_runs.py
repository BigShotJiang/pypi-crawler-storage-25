"""
Run the research agent 5 times with varied prompts to populate the dashboard.
"""

import asyncio
import os
from pathlib import Path

# Load .env
env_path = Path(__file__).parent.parent / "mimir" / ".env"
if env_path.exists():
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())

from agents import Agent, Runner, WebSearchTool, function_tool

import mimir
mimir.configure(dashboard_url="http://localhost:9847")
mimir.instrument_openai_agents()
print("[mimir] instrumented\n")


@function_tool
def save_findings(section: str, content: str) -> str:
    """Save research findings to a named section."""
    p = Path("/tmp/mimir_research") / f"{section.replace(' ', '_').lower()}.md"
    p.parent.mkdir(exist_ok=True)
    p.write_text(content)
    return f"Saved {len(content)} chars to '{section}'"


@function_tool
def compile_report(title: str, sections: list[str]) -> str:
    """Compile saved sections into a final report."""
    d = Path("/tmp/mimir_research")
    parts = [f"# {title}\n"]
    for s in sections:
        p = d / f"{s.replace(' ', '_').lower()}.md"
        parts.append(f"\n## {s}\n{p.read_text() if p.exists() else 'No data.'}")
    report = "\n".join(parts)
    (d / "final_report.md").write_text(report)
    return f"Report compiled: {len(report)} chars, {len(sections)} sections"


agent = Agent(
    name="Competitive Research Analyst",
    model="gpt-4o-mini",
    instructions="""You are a competitive intelligence analyst for AI developer tools.

Research the agent observability landscape, compare competitors to Mimir, and produce findings.

Mimir's capabilities: auto-instrumentation (2 lines), local-first dashboard, trajectory tracking,
run diffing, divergence detection, token/cost tracking, zero dependencies, fire-and-forget telemetry.

Be thorough. Search the web, save findings per competitor, then compile a report.""",
    tools=[WebSearchTool(), save_findings, compile_report],
)

PROMPTS = [
    "Research LangSmith, Arize Phoenix, and LangFuse. Compare their features and pricing against Mimir. Save findings for each and compile a report.",

    "Focus on AgentOps, Braintrust, and Helicone. What do they offer for agent tracing and debugging? How does Mimir compare on developer experience? Write a report.",

    "Research the open-source agent observability tools — specifically Arize Phoenix and LangFuse. How do they compare to Mimir's local-first approach? Compile findings.",

    "Look at LangSmith and Braintrust from the angle of enterprise readiness — team collaboration, access controls, deployment options. Where does Mimir fall short? Write a report.",

    "Do a broad sweep of agent visibility tools released in 2025-2026. Find any new entrants beyond the usual suspects (LangSmith, Arize, etc). Compare against Mimir and identify gaps. Compile a report.",
]


async def main():
    for i, prompt in enumerate(PROMPTS):
        n = i + 1
        print(f"{'='*70}")
        print(f"  Run #{n}/5")
        print(f"  {prompt[:80]}...")
        print(f"{'='*70}")

        result = await Runner.run(agent, prompt)
        output = str(result.final_output)
        print(f"  Done. Output: {len(output)} chars\n")

    print(f"\n{'='*70}")
    print(f"  All 5 runs complete! Dashboard: http://localhost:9847")
    print(f"{'='*70}\n")

    import urllib.request, json
    overview = json.loads(urllib.request.urlopen("http://localhost:9847/api/overview").read())
    groups = json.loads(urllib.request.urlopen("http://localhost:9847/api/task-groups").read())
    div = json.loads(urllib.request.urlopen("http://localhost:9847/api/divergence").read())
    print(f"  Runs: {overview['total_runs']}")
    print(f"  Trajectories: {overview['trajectories']}")
    for g in groups:
        print(f"  Agent: {g['name']} — {g['run_count']} runs")
    if div:
        for d in div:
            print(f"  Divergence: {d['task_name']} — {len(d['fingerprints'])} patterns")
    else:
        print("  No divergence detected")


if __name__ == "__main__":
    asyncio.run(main())
