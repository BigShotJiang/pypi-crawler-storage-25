#
# Copyright 2026 Tabs Data Inc.
#

from __future__ import annotations

import logging

DEFAULT_SERVER_ID = 512

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
