# Tribulnation Gateio SDK

> An SDK to connect Gateio with the Tribulnation ecosystem.

🚧 Under construction.