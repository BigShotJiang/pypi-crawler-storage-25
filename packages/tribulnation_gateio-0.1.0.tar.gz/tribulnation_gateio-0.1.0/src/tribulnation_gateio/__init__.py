"""
### Tribulnation Gateio
> An SDK to connect Gateio with the Tribulnation ecosystem.

- Details
"""