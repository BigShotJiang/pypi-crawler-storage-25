from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, Protocol

from fastmcp import Client
from fastmcp.client.transports import StdioTransport

if TYPE_CHECKING:
    from collections.abc import Sequence
    from types import TracebackType

ROOT = Path(__file__).resolve().parents[1]
CORE_TOOLS = frozenset({"get_toolkit_status", "list_inbox", "list_events"})
EMAIL_SUMMARY_FORBIDDEN = frozenset(
    {"body_content", "to", "cc", "bcc", "conversation_id", "folder_id"}
)
EVENT_SUMMARY_FORBIDDEN = frozenset({"body_content", "attendees"})
TEAMS_MESSAGE_SUMMARY_FORBIDDEN = frozenset({"body_content", "attachments"})

Status = Literal["PASS", "FAIL", "SKIP"]
DetailValue = bool | int | str


class SmokeAssertionError(AssertionError):
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


class ToolClient(Protocol):
    async def list_tools(self) -> list[Any]: ...

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | int | None = None,
    ) -> Any: ...


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: Status
    details: dict[str, DetailValue] = field(default_factory=dict)


class _ClientContext(Protocol):
    async def __aenter__(self) -> ToolClient: ...

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool | None: ...


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)
    try:
        results = asyncio.run(
            run_smoke(
                profile=args.profile,
                timeout=args.timeout,
                root=args.root,
            )
        )
    except Exception as exc:
        results = [CheckResult("mcp_connect", "FAIL", {"error": _safe_error(exc)})]
    print_report(results)
    return exit_code(results)


async def run_smoke(
    *,
    profile: str,
    timeout: float,
    root: Path,
    client_context: _ClientContext | None = None,
) -> list[CheckResult]:
    results: list[CheckResult] = []
    context = client_context or _stdio_client(profile=profile, timeout=timeout, root=root)
    async with context as client:
        tools = await client.list_tools()
        results.append(_validate_tools(tools))

        await _required_tool(
            client,
            results,
            "get_toolkit_status",
            {"include_latest": False},
            _validate_toolkit_status,
            timeout=timeout,
        )

        inbox_args = {"mailbox_filter": "all", "top": 5, "max_chars": 2_000}
        inbox = await _required_tool(
            client,
            results,
            "list_inbox",
            inbox_args,
            lambda payload: _validate_collection(
                payload, key="messages", forbidden=EMAIL_SUMMARY_FORBIDDEN
            ),
            timeout=timeout,
        )
        if inbox is not None:
            await _continue_if_present(
                client,
                results,
                "list_inbox",
                inbox,
                inbox_args,
                lambda payload: _validate_collection(
                    payload, key="messages", forbidden=EMAIL_SUMMARY_FORBIDDEN
                ),
                timeout=timeout,
                required=True,
            )

        event_args = _event_window_args()
        events = await _required_tool(
            client,
            results,
            "list_events",
            event_args,
            lambda payload: _validate_collection(
                payload, key="events", forbidden=EVENT_SUMMARY_FORBIDDEN
            ),
            timeout=timeout,
        )
        if events is not None:
            await _continue_if_present(
                client,
                results,
                "list_events",
                events,
                event_args,
                lambda payload: _validate_collection(
                    payload, key="events", forbidden=EVENT_SUMMARY_FORBIDDEN
                ),
                timeout=timeout,
                required=True,
            )

        await _run_optional_teams_checks(client, results, timeout=timeout)
        await _run_optional_meeting_checks(client, results, events or {}, timeout=timeout)

    return results


def print_report(results: list[CheckResult], stream: Any = sys.stdout) -> None:
    for result in results:
        print(format_result(result), file=stream)


def format_result(result: CheckResult) -> str:
    suffix = ""
    if result.details:
        suffix = " " + " ".join(f"{key}={value}" for key, value in result.details.items())
    return f"{result.status} {result.name}{suffix}"


def exit_code(results: list[CheckResult]) -> int:
    return 1 if any(result.status == "FAIL" for result in results) else 0


async def _required_tool(
    client: ToolClient,
    results: list[CheckResult],
    name: str,
    args: dict[str, Any],
    validator: Any,
    *,
    timeout: float,
) -> dict[str, Any] | None:
    return await _run_tool(
        client,
        results,
        name,
        args,
        validator,
        timeout=timeout,
        required=True,
    )


async def _optional_tool(
    client: ToolClient,
    results: list[CheckResult],
    name: str,
    args: dict[str, Any],
    validator: Any,
    *,
    timeout: float,
) -> dict[str, Any] | None:
    return await _run_tool(
        client,
        results,
        name,
        args,
        validator,
        timeout=timeout,
        required=False,
    )


async def _run_tool(
    client: ToolClient,
    results: list[CheckResult],
    name: str,
    args: dict[str, Any],
    validator: Any,
    *,
    timeout: float,
    required: bool,
    report_name: str | None = None,
) -> dict[str, Any] | None:
    try:
        payload = await _call_structured(client, name, args, timeout=timeout)
    except Exception as exc:
        status: Status = "FAIL" if required else "SKIP"
        results.append(CheckResult(report_name or name, status, {"error": _safe_error(exc)}))
        return None
    try:
        details = validator(payload)
    except SmokeAssertionError as exc:
        results.append(CheckResult(report_name or name, "FAIL", {"reason": exc.reason}))
        return None
    results.append(CheckResult(report_name or name, "PASS", details))
    return payload


async def _continue_if_present(
    client: ToolClient,
    results: list[CheckResult],
    name: str,
    payload: dict[str, Any],
    base_args: dict[str, Any],
    validator: Any,
    *,
    timeout: float,
    required: bool,
) -> dict[str, Any] | None:
    continuation_args = _continuation_args(payload, base_args)
    if continuation_args is None:
        return None
    return await _run_tool(
        client,
        results,
        name,
        continuation_args,
        validator,
        timeout=timeout,
        required=required,
        report_name=f"{name}:continue",
    )


async def _run_optional_teams_checks(
    client: ToolClient,
    results: list[CheckResult],
    *,
    timeout: float,
) -> None:
    chats = await _optional_tool(
        client,
        results,
        "list_chats",
        {"top": 3, "max_chars": 3_000},
        lambda payload: _validate_collection(payload, key="chats", forbidden=frozenset()),
        timeout=timeout,
    )
    chat_id = _first_id(chats, "chats")
    if chat_id is None:
        results.append(CheckResult("list_chat_messages", "SKIP", {"reason": "no_chats"}))
    else:
        await _optional_tool(
            client,
            results,
            "list_chat_messages",
            {"chat_id": chat_id, "top": 3, "max_chars": 3_000},
            lambda payload: _validate_collection(
                payload, key="messages", forbidden=TEAMS_MESSAGE_SUMMARY_FORBIDDEN
            ),
            timeout=timeout,
        )

    teams = await _optional_tool(
        client,
        results,
        "list_teams",
        {},
        lambda payload: _validate_collection(payload, key="teams", forbidden=frozenset()),
        timeout=timeout,
    )
    team_id = _first_id(teams, "teams")
    if team_id is None:
        results.append(CheckResult("list_channels", "SKIP", {"reason": "no_teams"}))
        results.append(CheckResult("list_channel_messages", "SKIP", {"reason": "no_channels"}))
        return

    channels = await _optional_tool(
        client,
        results,
        "list_channels",
        {"team_id": team_id},
        lambda payload: _validate_collection(payload, key="channels", forbidden=frozenset()),
        timeout=timeout,
    )
    channel_id = _first_id(channels, "channels")
    if channel_id is None:
        results.append(CheckResult("list_channel_messages", "SKIP", {"reason": "no_channels"}))
        return

    await _optional_tool(
        client,
        results,
        "list_channel_messages",
        {"team_id": team_id, "channel_id": channel_id, "top": 3, "max_chars": 3_000},
        lambda payload: _validate_collection(
            payload, key="messages", forbidden=TEAMS_MESSAGE_SUMMARY_FORBIDDEN
        ),
        timeout=timeout,
    )


async def _run_optional_meeting_checks(
    client: ToolClient,
    results: list[CheckResult],
    events: dict[str, Any],
    *,
    timeout: float,
) -> None:
    event_args = _first_online_event_args(events)
    if event_args is None:
        results.append(
            CheckResult("list_meeting_transcripts", "SKIP", {"reason": "no_online_event"})
        )
        results.append(CheckResult("read_meeting_transcript", "SKIP", {"reason": "no_transcripts"}))
        results.append(CheckResult("read_meeting_notes", "SKIP", {"reason": "no_online_event"}))
        return

    transcripts = await _optional_tool(
        client,
        results,
        "list_meeting_transcripts",
        {**event_args, "top": 3},
        lambda payload: _validate_collection(
            payload, key="transcripts", forbidden=frozenset(), include_continuation=False
        ),
        timeout=timeout,
    )
    transcript_id = _first_id(transcripts, "transcripts")
    if transcript_id is None:
        results.append(CheckResult("read_meeting_transcript", "SKIP", {"reason": "no_transcripts"}))
    else:
        await _optional_tool(
            client,
            results,
            "read_meeting_transcript",
            {**event_args, "transcript_id": transcript_id, "max_chars": 2_000},
            _validate_transcript_read,
            timeout=timeout,
        )

    await _optional_tool(
        client,
        results,
        "read_meeting_notes",
        event_args,
        _validate_meeting_notes,
        timeout=timeout,
    )


async def _call_structured(
    client: ToolClient,
    name: str,
    args: dict[str, Any],
    *,
    timeout: float,
) -> dict[str, Any]:
    result = await client.call_tool(name, args, timeout=timeout)
    payload = getattr(result, "structured_content", None)
    if payload is None:
        payload = getattr(result, "data", None)
    if not isinstance(payload, dict):
        raise SmokeAssertionError("missing_structured_content")
    return payload


def _validate_tools(tools: list[Any]) -> CheckResult:
    names = {name for tool in tools if isinstance((name := getattr(tool, "name", None)), str)}
    missing = sorted(CORE_TOOLS - names)
    if missing:
        return CheckResult("list_tools", "FAIL", {"missing": ",".join(missing)})
    return CheckResult("list_tools", "PASS", {"count": len(names)})


def _validate_toolkit_status(payload: dict[str, Any]) -> dict[str, DetailValue]:
    version = payload.get("version")
    if not isinstance(version, str) or not version:
        raise SmokeAssertionError("missing_version")
    return {"version": version}


def _validate_collection(
    payload: dict[str, Any],
    *,
    key: str,
    forbidden: frozenset[str],
    include_continuation: bool = True,
) -> dict[str, DetailValue]:
    items = payload.get(key)
    if not isinstance(items, list):
        raise SmokeAssertionError(f"missing_{key}")
    _assert_forbidden_absent(items, forbidden)
    details: dict[str, DetailValue] = {
        "count": len(items),
        "id_hashes": _redacted_ids(items),
    }
    if include_continuation:
        details["truncated"] = bool(payload.get("truncated", False))
        details["next_offset"] = (
            "next_offset" in payload and payload.get("next_offset") is not None
        )
        details["next_cursor"] = bool(payload.get("next_cursor"))
    return details


def _validate_transcript_read(payload: dict[str, Any]) -> dict[str, DetailValue]:
    text = payload.get("text_content")
    if not isinstance(text, str):
        raise SmokeAssertionError("missing_text_content")
    return {
        "text_chars": len(text),
        "is_truncated": bool(payload.get("is_truncated", False)),
    }


def _validate_meeting_notes(payload: dict[str, Any]) -> dict[str, DetailValue]:
    notes = payload.get("meeting_notes")
    action_items = payload.get("action_items")
    mention_events = payload.get("mention_events")
    if not isinstance(notes, list):
        raise SmokeAssertionError("missing_meeting_notes")
    if not isinstance(action_items, list):
        raise SmokeAssertionError("missing_action_items")
    if not isinstance(mention_events, list):
        raise SmokeAssertionError("missing_mention_events")
    return {
        "notes": len(notes),
        "action_items": len(action_items),
        "mention_events": len(mention_events),
    }


def _assert_forbidden_absent(items: list[Any], forbidden: frozenset[str]) -> None:
    if not forbidden:
        return
    found: set[str] = set()
    for item in items:
        if isinstance(item, dict):
            found.update(field for field in forbidden if field in item)
    if found:
        raise SmokeAssertionError("forbidden_fields:" + ",".join(sorted(found)))


def _continuation_args(
    payload: dict[str, Any],
    base_args: dict[str, Any],
) -> dict[str, Any] | None:
    next_offset = payload.get("next_offset")
    if isinstance(next_offset, int):
        return {**base_args, "offset": next_offset}
    next_cursor = payload.get("next_cursor")
    if isinstance(next_cursor, str) and next_cursor:
        return {**base_args, "cursor": next_cursor}
    return None


def _first_id(payload: dict[str, Any] | None, key: str) -> str | None:
    if not isinstance(payload, dict):
        return None
    items = payload.get(key)
    if not isinstance(items, list) or not items:
        return None
    first = items[0]
    if not isinstance(first, dict):
        return None
    value = first.get("id")
    return value if isinstance(value, str) and value else None


def _first_online_event_args(events: dict[str, Any]) -> dict[str, str] | None:
    items = events.get("events")
    if not isinstance(items, list):
        return None
    for item in items:
        if not isinstance(item, dict) or not item.get("is_online_meeting"):
            continue
        event_id = item.get("id")
        if isinstance(event_id, str) and event_id:
            return {"event_id": event_id}
        join_url = item.get("join_url")
        if isinstance(join_url, str) and join_url:
            return {"join_web_url": join_url}
    return None


def _event_window_args(now: datetime | None = None) -> dict[str, Any]:
    current = now or datetime.now(UTC)
    start = current - timedelta(days=1)
    end = current + timedelta(days=7)
    return {
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": end.isoformat().replace("+00:00", "Z"),
        "max_chars": 4_000,
    }


def _redacted_ids(items: list[Any]) -> str:
    hashes: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        value = item.get("id")
        if isinstance(value, str) and value:
            hashes.append(_hash_id(value))
    return ",".join(hashes[:3]) if hashes else "none"


def _hash_id(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]


def _safe_error(exc: BaseException) -> str:
    return type(exc).__name__


def _stdio_client(*, profile: str, timeout: float, root: Path) -> Client:
    env = os.environ.copy()
    env.setdefault("UV_CACHE_DIR", "/tmp/ms365-toolkit-uv-cache")
    env.setdefault("UV_TOOL_DIR", "/tmp/ms365-toolkit-uv-tools")
    transport = StdioTransport(
        command="uv",
        args=[
            "run",
            "--directory",
            str(root),
            "--extra",
            "mcp",
            "ms365-toolkit-mcp",
            "--profile",
            profile,
        ],
        env=env,
        cwd=str(root),
        keep_alive=False,
        log_file=Path(os.devnull),
    )
    return Client(transport, timeout=timeout, init_timeout=timeout)


def _parse_args(argv: Sequence[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="smoke_mcp")
    parser.add_argument("--profile", default="default")
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--root", type=Path, default=ROOT)
    return parser.parse_args(argv)


if __name__ == "__main__":
    raise SystemExit(main())
