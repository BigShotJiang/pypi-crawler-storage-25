# ms365-toolkit-mcp

Installable MCP entrypoint for [`ms365-toolkit`](https://github.com/sadhiappan/ms365-toolkit).

This wrapper package depends on the matching `ms365-toolkit[mcp]` release and exposes:

```bash
ms365-toolkit-mcp
```

Most users should install it through Codex or Claude MCP registration with `ms365-toolkit-mcp@latest`. See the root project README for setup, authentication, permissions, and safety guidance.
