# Contributing

## Development Setup

Install dependencies:

```bash
uv sync --extra mcp --extra dev
```

Run tests and lint:

```bash
uv run ruff check src tests scripts
uv run mypy src/ms365_toolkit/
uv run pytest -q tests/unit
```

Run local security checks before public-facing changes:

```bash
uvx bandit -q -r src scripts
uv run --with pip-audit pip-audit --local
```

For MCP behavior changes, also run the opt-in real-world smoke test with a local authenticated profile:

```bash
uv run --extra mcp python scripts/smoke_mcp.py --profile default
```

## Pull Request Expectations

- Keep changes focused and aligned with existing patterns.
- Add or update tests for behavior changes.
- Update `README.md` and `CHANGELOG.md` for user-facing changes.
- Never commit secrets, profile directories, token caches, mailbox indexes, downloaded files, or private Microsoft 365 content.
- Use commit prefixes such as `feat:`, `fix:`, `docs:`, `test:`, or `refactor:`.

## Security and Privacy

Avoid pasting real mailbox data, Teams messages, transcript text, access tokens, tenant-private IDs, or customer content into issues, tests, commits, or PR descriptions.
