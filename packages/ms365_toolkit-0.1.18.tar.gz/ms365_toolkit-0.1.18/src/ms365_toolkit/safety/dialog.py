from __future__ import annotations

import ctypes
import subprocess  # nosec B404
import sys
from typing import TYPE_CHECKING

from ms365_toolkit.safety.canonical import canonicalize_body
from ms365_toolkit.safety.gate import DialogPreview, SafetyResult

OSASCRIPT_PATH = "/usr/bin/osascript"
OSASCRIPT_TIMEOUT_SECONDS = 10.0

if TYPE_CHECKING:
    from collections.abc import Callable


def can_show_dialog(
    *,
    platform: str | None = None,
    session_check: Callable[[], bool] | None = None,
    smoke_test: Callable[[], bool] | None = None,
) -> bool:
    effective_platform = platform or sys.platform
    if effective_platform != "darwin":
        return False
    session_checker = session_check or _default_session_check
    smoke_tester = smoke_test or _default_smoke_test
    return session_checker() and smoke_tester()


def show_confirmation_dialog(
    preview: DialogPreview,
    *,
    platform: str | None = None,
    session_check: Callable[[], bool] | None = None,
    smoke_test: Callable[[], bool] | None = None,
    runner: Callable[[list[str]], int] | None = None,
) -> SafetyResult:
    if not can_show_dialog(
        platform=platform,
        session_check=session_check,
        smoke_test=smoke_test,
    ):
        return SafetyResult(False, "dialog_preflight_failed")
    try:
        exit_code = (runner or _run_dialog_command)(_dialog_command(preview))
    except (OSError, subprocess.TimeoutExpired):
        return SafetyResult(False, "dialog_cancelled")
    if exit_code != 0:
        return SafetyResult(False, "dialog_cancelled")
    return SafetyResult(True, "dialog_approved")


def _dialog_command(preview: DialogPreview) -> list[str]:
    title = _escape_applescript(preview.title)
    body = _escape_applescript(canonicalize_body(preview.body))
    script = (
        f'display dialog "{body}" '
        f'with title "{title}" '
        'buttons {"Cancel", "Confirm"} '
        'default button "Confirm" '
        'cancel button "Cancel"'
    )
    return [OSASCRIPT_PATH, "-e", script]


def _escape_applescript(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _default_session_check() -> bool:
    try:
        core_graphics = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
        )
        core_graphics.CGSessionCopyCurrentDictionary.restype = ctypes.c_void_p
        return bool(core_graphics.CGSessionCopyCurrentDictionary())
    except OSError:
        return False


def _default_smoke_test() -> bool:
    return _run_dialog_command([OSASCRIPT_PATH, "-e", 'return "ok"']) == 0


def _run_dialog_command(command: list[str]) -> int:
    try:
        completed = subprocess.run(  # nosec B603
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=OSASCRIPT_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired):
        return 1
    return completed.returncode
