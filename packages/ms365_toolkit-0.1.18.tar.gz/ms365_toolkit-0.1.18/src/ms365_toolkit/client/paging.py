from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Generic, TypeVar

T = TypeVar("T")


@dataclass(frozen=True)
class GraphPage(Generic[T]):
    items: list[T]
    next_link: str | None


def graph_next_link(response: dict[str, Any]) -> str | None:
    value = response.get("@odata.nextLink")
    if isinstance(value, str) and value:
        return value
    return None
