from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast
from urllib import parse, request
from urllib.error import HTTPError, URLError

from ms365_toolkit.client.exceptions import AuthenticationError, GraphAPIError, RateLimitedError
from ms365_toolkit.usage import record_graph_request

if TYPE_CHECKING:
    from ms365_toolkit.config.loader import ToolkitConfig

GRAPH_ROOT = "https://graph.microsoft.com/v1.0"
ALLOWED_GRAPH_HOSTS = frozenset({"graph.microsoft.com"})
GLOBAL_ENDPOINT_PREFIXES = ("me/", "users/", "teams/", "shares/", "drives/")


@dataclass(frozen=True)
class GraphClient:
    config: ToolkitConfig
    token: str
    timeout: float = 30.0
    max_retries: int = 3
    backoff_factor: float = 0.5
    transport: Any | None = None
    sleeper: Any | None = None

    def get(
        self,
        path: str,
        query: dict[str, Any] | None = None,
        *,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request_json("GET", path, query=query, headers=headers)

    def get_bytes(
        self,
        path: str,
        query: dict[str, Any] | None = None,
        *,
        headers: dict[str, str] | None = None,
    ) -> bytes:
        return self._request_bytes("GET", path, query=query, headers=headers)

    def post(
        self,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._request_json("POST", path, query=query, body=body, headers=headers)

    def patch(self, path: str, *, body: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request_json("PATCH", path, body=body)

    def delete(self, path: str, *, query: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request_json("DELETE", path, query=query)

    async def async_get(
        self,
        path: str,
        query: dict[str, Any] | None = None,
        *,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(self.get, path, query, headers=headers)

    async def async_post(
        self,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return await asyncio.to_thread(self.post, path, query=query, body=body, headers=headers)

    def build_url(self, path: str, query: dict[str, Any] | None = None) -> str:
        if path.startswith("https://"):
            url = _validate_absolute_graph_url(path)
            query_string = build_odata_query(query or {})
            if query_string:
                separator = "&" if "?" in url else "?"
                return f"{url}{separator}{query_string}"
            return url
        normalized_path = path.lstrip("/")
        if not normalized_path.startswith(GLOBAL_ENDPOINT_PREFIXES):
            normalized_path = f"{self._endpoint_prefix()}/{normalized_path}"
        url = f"{GRAPH_ROOT}/{normalized_path}"
        query_string = build_odata_query(query or {})
        if query_string:
            return f"{url}?{query_string}"
        return url

    def _endpoint_prefix(self) -> str:
        if self.config.user.endpoint == "users":
            return f"users/{parse.quote(self.config.user.user_principal_name, safe='')}"
        return "me"

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        url = self.build_url(path, query)
        data = None if body is None else json.dumps(body).encode("utf-8")
        request_headers = {"Authorization": f"Bearer {self.token}", "Accept": "application/json"}
        if headers:
            request_headers.update(headers)
        if data is not None:
            request_headers["Content-Type"] = "application/json"
        graph_request = request.Request(url=url, data=data, headers=request_headers, method=method)
        attempt = 0
        start = time.perf_counter()
        while True:
            try:
                with self._send(graph_request) as response:
                    payload = response.read()
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=_response_status(response),
                        error_code=None,
                    )
                    if not payload:
                        return {}
                    return cast("dict[str, Any]", json.loads(payload.decode("utf-8")))
            except HTTPError as exc:
                if exc.code == 401:
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=exc.code,
                        error_code="Unauthorized",
                    )
                    raise AuthenticationError("Graph API request was not authorized") from exc
                if exc.code in {429, 503} and attempt < self.max_retries:
                    retry_after = _parse_retry_after(exc.headers.get("Retry-After"))
                    self._sleep(retry_after or (self.backoff_factor * (2**attempt)))
                    attempt += 1
                    continue
                if exc.code == 429:
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=exc.code,
                        error_code="TooManyRequests",
                    )
                    raise RateLimitedError(
                        _parse_retry_after(exc.headers.get("Retry-After"))
                    ) from exc
                error = _graph_error_from_http_error(exc)
                _record_graph_request(
                    method=method,
                    url=url,
                    start=start,
                    retry_count=attempt,
                    status_code=error.status_code,
                    error_code=error.error_code,
                )
                raise error from exc
            except URLError as exc:
                _record_graph_request(
                    method=method,
                    url=url,
                    start=start,
                    retry_count=attempt,
                    status_code=0,
                    error_code="NetworkError",
                )
                raise GraphAPIError(0, "NetworkError", str(exc.reason)) from exc

    def _request_bytes(
        self,
        method: str,
        path: str,
        *,
        query: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> bytes:
        url = self.build_url(path, query)
        data = None if body is None else json.dumps(body).encode("utf-8")
        request_headers = {"Authorization": f"Bearer {self.token}"}
        if headers:
            request_headers.update(headers)
        if data is not None:
            request_headers["Content-Type"] = "application/json"
        graph_request = request.Request(url=url, data=data, headers=request_headers, method=method)
        attempt = 0
        start = time.perf_counter()
        while True:
            try:
                with self._send(graph_request) as response:
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=_response_status(response),
                        error_code=None,
                    )
                    return cast("bytes", response.read())
            except HTTPError as exc:
                if exc.code == 401:
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=exc.code,
                        error_code="Unauthorized",
                    )
                    raise AuthenticationError("Graph API request was not authorized") from exc
                if exc.code in {429, 503} and attempt < self.max_retries:
                    retry_after = _parse_retry_after(exc.headers.get("Retry-After"))
                    self._sleep(retry_after or (self.backoff_factor * (2**attempt)))
                    attempt += 1
                    continue
                if exc.code == 429:
                    _record_graph_request(
                        method=method,
                        url=url,
                        start=start,
                        retry_count=attempt,
                        status_code=exc.code,
                        error_code="TooManyRequests",
                    )
                    raise RateLimitedError(
                        _parse_retry_after(exc.headers.get("Retry-After"))
                    ) from exc
                error = _graph_error_from_http_error(exc)
                _record_graph_request(
                    method=method,
                    url=url,
                    start=start,
                    retry_count=attempt,
                    status_code=error.status_code,
                    error_code=error.error_code,
                )
                raise error from exc
            except URLError as exc:
                _record_graph_request(
                    method=method,
                    url=url,
                    start=start,
                    retry_count=attempt,
                    status_code=0,
                    error_code="NetworkError",
                )
                raise GraphAPIError(0, "NetworkError", str(exc.reason)) from exc

    def _send(self, graph_request: request.Request) -> Any:
        if self.transport is not None:
            return self.transport(graph_request, self.timeout)
        return request.urlopen(graph_request, timeout=self.timeout)  # nosec B310

    def _sleep(self, seconds: float) -> None:
        if self.sleeper is not None:
            self.sleeper(seconds)
            return
        time.sleep(seconds)


def build_odata_query(query: dict[str, Any]) -> str:
    params: list[tuple[str, str]] = []
    for key, value in query.items():
        if value is None:
            continue
        if isinstance(value, bool):
            params.append((key, "true" if value else "false"))
        elif isinstance(value, (list, tuple)):
            params.append((key, ",".join(str(item) for item in value)))
        else:
            params.append((key, str(value)))
    return parse.urlencode(params, safe="(),'$: ")


def _graph_error_from_http_error(exc: HTTPError) -> GraphAPIError:
    payload = _read_error_payload(exc)
    error = payload.get("error", {}) if isinstance(payload, dict) else {}
    error_code = error.get("code", "GraphAPIError")
    message = error.get("message", exc.reason)
    return GraphAPIError(exc.code, str(error_code), str(message))


def _read_error_payload(exc: HTTPError) -> dict[str, Any]:
    try:
        payload = exc.read()
    except OSError:
        return {}
    if not payload:
        return {}
    try:
        return cast("dict[str, Any]", json.loads(payload.decode("utf-8")))
    except json.JSONDecodeError:
        return {}


def _record_graph_request(
    *,
    method: str,
    url: str,
    start: float,
    retry_count: int,
    status_code: int,
    error_code: str | None,
) -> None:
    duration_ms = max(0, int((time.perf_counter() - start) * 1000))
    record_graph_request(
        method=method,
        url=url,
        status=_graph_status_label(status_code, error_code),
        duration_ms=duration_ms,
        retry_count=retry_count,
    )


def _graph_status_label(status_code: int, error_code: str | None) -> str:
    if 200 <= status_code < 300:
        return "2xx"
    if error_code:
        return f"{status_code}:{error_code}"
    if status_code == 0:
        return "0:NetworkError"
    return str(status_code)


def _response_status(response: Any) -> int:
    status = getattr(response, "status", None)
    if isinstance(status, int):
        return status
    getcode = getattr(response, "getcode", None)
    if callable(getcode):
        value = getcode()
        if isinstance(value, int):
            return value
    return 200


def _parse_retry_after(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _validate_absolute_graph_url(path: str) -> str:
    parsed = parse.urlparse(path)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_GRAPH_HOSTS:
        raise ValueError("absolute Graph URL must use an allowed Graph host over https")
    return path
