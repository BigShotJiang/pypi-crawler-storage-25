from __future__ import annotations

import base64
import html
import re
from urllib.parse import parse_qs, parse_qsl, unquote, urlencode, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from ms365_toolkit.models.email import EmailShareLink

_INVISIBLE_TRANSLATION = str.maketrans(
    "",
    "",
    "\u200b\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2060\ufeff",
)
_URL_RE = re.compile(r"https?://[^\s<>'\"]+", re.IGNORECASE)
_FILE_NAME_RE = re.compile(
    r"[^\\/\r\n\t<>]+?\.(?:docx|xlsx|pptx|pdf|doc|xls|ppt|txt|csv)\b",
    re.IGNORECASE,
)
_TRAILING_URL_CHARS = ".,;:)]}"
_DEDUP_QUERY_DENYLIST = {
    "at",
    "ct",
    "e",
    "fromshare",
    "openshare",
    "or",
    "sdata",
    "sharingv2",
    "web",
    "xsdata",
}


def extract_email_share_links(body_content: str) -> tuple[EmailShareLink, ...]:
    if not body_content:
        return ()
    soup = BeautifulSoup(body_content, "html.parser")
    candidates: list[tuple[str, str]] = []
    for anchor in soup.find_all("a"):
        href = anchor.get("href")
        if isinstance(href, str):
            candidates.append((href, anchor.get_text(" ", strip=True)))
    for text in (body_content, soup.get_text(" ")):
        for match in _URL_RE.finditer(_strip_invisible(text)):
            candidates.append((match.group(0), ""))

    links: list[EmailShareLink] = []
    seen: set[str] = set()
    for raw_url, raw_label in candidates:
        url = normalize_share_url(raw_url)
        dedupe_key = _share_link_dedupe_key(url)
        if not url or not _is_share_url(url) or dedupe_key in seen:
            continue
        label = _clean_text(raw_label)
        filename = _filename_from_label_or_url(label, url)
        if not filename:
            continue
        seen.add(dedupe_key)
        links.append(
            EmailShareLink(
                url=url,
                filename=filename,
                host=urlsplit(url).netloc.lower(),
                source_text=label,
            )
        )
    return tuple(links)


def normalize_share_url(value: str) -> str:
    normalized = _strip_invisible(html.unescape(value)).strip().strip("<>")
    normalized = normalized.rstrip(_TRAILING_URL_CHARS)
    if not normalized:
        return ""
    parsed = urlsplit(normalized)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        return ""
    if parsed.netloc.lower().endswith("safelinks.protection.outlook.com"):
        wrapped = parse_qs(parsed.query).get("url", [""])[0]
        if wrapped:
            return normalize_share_url(wrapped)
    return normalized


def _share_link_dedupe_key(url: str) -> str:
    parsed = urlsplit(url)
    query = urlencode(
        sorted(
            (key.lower(), value)
            for key, value in parse_qsl(parsed.query, keep_blank_values=True)
            if key.lower() not in _DEDUP_QUERY_DENYLIST
        ),
        doseq=True,
    )
    path = unquote(parsed.path).rstrip("/")
    return urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), path, query, ""))


def share_token_from_url(url: str) -> str:
    normalized = normalize_share_url(url)
    if not normalized:
        raise ValueError("share URL must be a non-empty http(s) URL")
    encoded = base64.urlsafe_b64encode(normalized.encode("utf-8")).decode("ascii").rstrip("=")
    return f"u!{encoded}"


def _filename_from_label_or_url(label: str, url: str) -> str:
    for value in (label, unquote(urlsplit(url).path)):
        match = _FILE_NAME_RE.search(value)
        if match is not None:
            return match.group(0).strip()
    return ""


def _is_share_url(url: str) -> bool:
    host = urlsplit(url).netloc.lower()
    return (
        host == "1drv.ms"
        or host == "onedrive.live.com"
        or host.endswith(".sharepoint.com")
    )


def _clean_text(value: str) -> str:
    return " ".join(_strip_invisible(html.unescape(value)).split())


def _strip_invisible(value: str) -> str:
    return value.translate(_INVISIBLE_TRANSLATION)
