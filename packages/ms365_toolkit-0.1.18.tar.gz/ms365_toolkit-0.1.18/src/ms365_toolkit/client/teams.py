from __future__ import annotations

import base64
import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from urllib.parse import quote

import jwt

from ms365_toolkit.client.attachment_text import extract_attachment_text
from ms365_toolkit.client.exceptions import GraphAPIError
from ms365_toolkit.client.paging import GraphPage, graph_next_link
from ms365_toolkit.client.sanitize import strip_html
from ms365_toolkit.models.email import EmailAttachment
from ms365_toolkit.models.teams import (
    ChannelSummary,
    DownloadedTeamsFile,
    ExtractedTeamsFile,
    TeamsChat,
    TeamsMessage,
    TeamsMessageAttachment,
    TeamsMessageSearchHit,
    TeamsMessageSearchPage,
    TeamsParticipant,
    TeamsReplyPage,
    TeamsSender,
    TeamsThread,
    TeamSummary,
)

if TYPE_CHECKING:
    from ms365_toolkit.client.graph import GraphClient


class TeamsClient:
    def __init__(
        self,
        graph: GraphClient,
        *,
        channel_graph: GraphClient | None = None,
        files_graph: GraphClient | None = None,
    ) -> None:
        self.graph = graph
        self.channel_graph = channel_graph or graph
        self.files_graph = files_graph or graph
        self.viewer_user_id, self.viewer_email = _viewer_identity(
            graph.token,
            graph.config.user.user_principal_name,
        )

    def list_chats(self, *, top: int = 25) -> list[TeamsChat]:
        return self.list_chats_page(top=top).items

    def list_chats_page(
        self,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsChat]:
        self._ensure_supported_endpoint()
        response = (
            self.graph.get(next_link, query=None)
            if next_link
            else self.graph.get(
                "chats",
                query={"$top": _bounded_top(top, maximum=50), "$expand": "members"},
            )
        )
        return GraphPage(
            items=[self._chat_from_item(item) for item in response.get("value", [])],
            next_link=graph_next_link(response),
        )

    def search_chats(self, query: str, *, top: int = 10) -> list[TeamsChat]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, int, float], TeamsChat]] = []
        for chat in self.list_chats(top=50):
            score = _chat_search_score(chat, normalized_query)
            if score is None:
                continue
            matches.append((score, chat))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [chat for _, chat in matches[:limit]]

    def list_chat_messages(self, chat_id: str, *, top: int = 25) -> list[TeamsMessage]:
        return self.list_chat_messages_page(chat_id, top=top).items

    def list_chat_messages_page(
        self,
        chat_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsMessage]:
        self._ensure_supported_endpoint()
        response = (
            self.graph.get(next_link, query=None)
            if next_link
            else self.graph.get(
                f"chats/{_path_segment('chat_id', chat_id)}/messages",
                query={"$top": _bounded_top(top, maximum=50), "$orderby": "createdDateTime desc"},
            )
        )
        return GraphPage(
            items=[
                self._message_from_item(item, chat_id=chat_id)
                for item in response.get("value", [])
            ],
            next_link=graph_next_link(response),
        )

    def search_chat_messages(
        self,
        chat_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, float], TeamsMessage]] = []
        for message in self.list_chat_messages(chat_id, top=50):
            score = _message_search_score(message, normalized_query)
            if score is None:
                continue
            matches.append((score, message))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [message for _, message in matches[:limit]]

    def search_teams_messages(
        self,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessageSearchHit]:
        return self.search_teams_messages_page(query, top=top).items

    def search_teams_messages_page(
        self,
        query: str,
        *,
        top: int = 10,
        from_index: int = 0,
    ) -> TeamsMessageSearchPage:
        self._ensure_supported_endpoint()
        normalized_query = query.strip()
        if not normalized_query:
            raise ValueError("query must be a non-empty string")
        normalized_from = _non_negative_int(from_index, "from_index")
        size = _bounded_top(top, maximum=25)
        try:
            response = self.channel_graph.post(
                "https://graph.microsoft.com/v1.0/search/query",
                body={
                    "requests": [
                        {
                            "entityTypes": ["chatMessage"],
                            "query": {"queryString": normalized_query},
                            "from": normalized_from,
                            "size": size,
                            "enableTopResults": True,
                        }
                    ]
                },
            )
        except GraphAPIError as exc:
            raise _teams_search_permission_error(exc) from exc
        hits: list[TeamsMessageSearchHit] = []
        more_results = False
        for result in response.get("value", []):
            if not isinstance(result, dict):
                continue
            for container in result.get("hitsContainers", []):
                if not isinstance(container, dict):
                    continue
                more_results = more_results or bool(container.get("moreResultsAvailable"))
                for hit in container.get("hits", []):
                    if not isinstance(hit, dict):
                        continue
                    resource = hit.get("resource")
                    if not isinstance(resource, dict):
                        continue
                    hits.append(self._search_hit_from_item(hit, resource))
        return TeamsMessageSearchPage(
            items=hits,
            next_from=normalized_from + size if more_results else None,
        )

    def get_chat_message(self, chat_id: str, message_id: str) -> TeamsMessage:
        self._ensure_supported_endpoint()
        response = self._message_item(chat_id=chat_id, message_id=message_id)
        return self._message_from_item(response, chat_id=chat_id)

    def list_teams(self) -> list[TeamSummary]:
        return self.list_teams_page().items

    def list_teams_page(self, *, next_link: str | None = None) -> GraphPage[TeamSummary]:
        self._ensure_supported_endpoint()
        response = (
            self.graph.get(next_link, query=None)
            if next_link
            else self.graph.get("me/joinedTeams")
        )
        return GraphPage(
            items=[self._team_from_item(item) for item in response.get("value", [])],
            next_link=graph_next_link(response),
        )

    def list_channels(self, team_id: str) -> list[ChannelSummary]:
        return self.list_channels_page(team_id).items

    def list_channels_page(
        self,
        team_id: str,
        *,
        next_link: str | None = None,
    ) -> GraphPage[ChannelSummary]:
        self._ensure_supported_endpoint()
        response = (
            self.graph.get(next_link, query=None)
            if next_link
            else self.graph.get(f"teams/{_path_segment('team_id', team_id)}/channels")
        )
        return GraphPage(
            items=[self._channel_from_item(item) for item in response.get("value", [])],
            next_link=graph_next_link(response),
        )

    def list_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
    ) -> list[TeamsMessage]:
        return self.list_channel_messages_page(team_id, channel_id, top=top).items

    def list_channel_messages_page(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsMessage]:
        self._ensure_supported_endpoint()
        try:
            response = (
                self.channel_graph.get(next_link, query=None)
                if next_link
                else self.channel_graph.get(
                    "teams/"
                    f"{_path_segment('team_id', team_id)}/channels/"
                    f"{_path_segment('channel_id', channel_id)}/messages",
                    query={"$top": _bounded_top(top, maximum=50), "$expand": "replies"},
                )
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        return GraphPage(
            items=[
                self._message_from_item(item, team_id=team_id, channel_id=channel_id)
                for item in response.get("value", [])
            ],
            next_link=graph_next_link(response),
        )

    def search_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        normalized_query = _normalized_query(query)
        limit = _bounded_top(top, maximum=50)
        matches: list[tuple[tuple[int, float], TeamsMessage]] = []
        for message in self.list_channel_messages(team_id, channel_id, top=50):
            score = _message_search_score(message, normalized_query)
            if score is None:
                continue
            matches.append((score, message))
        matches.sort(key=lambda item: item[0], reverse=True)
        return [message for _, message in matches[:limit]]

    def get_channel_message(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
    ) -> TeamsMessage:
        response = self._message_item(
            team_id=team_id,
            channel_id=channel_id,
            message_id=message_id,
        )
        return self._message_from_item(response, team_id=team_id, channel_id=channel_id)

    def list_message_attachments(
        self,
        *,
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[TeamsMessageAttachment]:
        item = self._message_item(
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
            message_id=message_id,
        )
        return [
            attachment
            for attachment in self._attachments_from_item(item)
            if attachment.content_url
        ]

    def download_message_attachment(
        self,
        *,
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> DownloadedTeamsFile:
        attachment = self._require_message_attachment(
            message_id=message_id,
            attachment_id=attachment_id,
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
        )
        share_token = _share_token_from_url(attachment.content_url)
        try:
            drive_item = self.files_graph.get(
                f"https://graph.microsoft.com/v1.0/shares/{share_token}/driveItem"
            )
            content = self.files_graph.get_bytes(
                f"https://graph.microsoft.com/v1.0/shares/{share_token}/driveItem/content"
            )
        except GraphAPIError as exc:
            raise _teams_file_permission_error(exc) from exc
        drive_name = _string_value(drive_item.get("name"))
        return DownloadedTeamsFile(
            attachment_id=attachment.id,
            name=drive_name or attachment.name,
            content_type=_drive_item_content_type(drive_item) or attachment.content_type,
            content_url=attachment.content_url,
            content=content,
        )

    def read_message_attachment_text(
        self,
        *,
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedTeamsFile:
        if max_chars <= 0:
            raise ValueError("max_chars must be a positive integer")
        attachment = self._require_message_attachment(
            message_id=message_id,
            attachment_id=attachment_id,
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
        )
        downloaded = self.download_message_attachment(
            message_id=message_id,
            attachment_id=attachment_id,
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
        )
        extracted = extract_attachment_text(
            _email_attachment_from_teams_attachment(attachment, size=len(downloaded.content)),
            downloaded.content,
            max_chars=max_chars,
        )
        return ExtractedTeamsFile(
            attachment=attachment,
            format=extracted.format,
            text_content=extracted.text_content,
            is_truncated=extracted.is_truncated,
            warnings=extracted.warnings,
        )

    def list_channel_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
    ) -> TeamsReplyPage:
        return self.list_channel_replies_page(
            team_id,
            channel_id,
            message_id,
            top=top,
        )

    def list_channel_replies_page(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> TeamsReplyPage:
        self._ensure_supported_endpoint()
        try:
            response = (
                self.channel_graph.get(next_link, query=None)
                if next_link
                else self.channel_graph.get(
                    "teams/"
                    f"{_path_segment('team_id', team_id)}/channels/"
                    f"{_path_segment('channel_id', channel_id)}/messages/"
                    f"{_path_segment('message_id', message_id)}/replies",
                    query={"$top": _bounded_top(top, maximum=50)},
                )
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        next_page = graph_next_link(response)
        replies = tuple(
            _sort_messages_oldest_first(
                [
                    self._message_from_item(item, team_id=team_id, channel_id=channel_id)
                    for item in response.get("value", [])
                ]
            )
        )
        return TeamsReplyPage(
            replies=replies,
            has_more_replies=bool(next_page),
            next_link=next_page,
        )

    def read_channel_thread(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        replies_top: int = 25,
    ) -> TeamsThread:
        root_message = self.get_channel_message(team_id, channel_id, message_id)
        reply_page = self.list_channel_replies(
            team_id,
            channel_id,
            message_id,
            top=replies_top,
        )
        return TeamsThread(
            root_message=root_message,
            replies=reply_page.replies,
            has_more_replies=reply_page.has_more_replies,
        )

    def _ensure_supported_endpoint(self) -> None:
        if self.graph.config.user.endpoint != "me":
            raise ValueError("Teams tools only support user.endpoint='me'")

    def _chat_from_item(self, item: dict[str, Any]) -> TeamsChat:
        other_participants = self._other_participants(item)
        return TeamsChat(
            id=_string_value(item.get("id")),
            topic=_string_value(item.get("topic")),
            display_label=_chat_display_label(item, other_participants),
            chat_type=_string_value(item.get("chatType")),
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            last_updated_at=_parse_graph_datetime(item.get("lastUpdatedDateTime")),
            last_message_read_at=_parse_graph_datetime(item.get("lastMessageReadDateTime")),
            web_url=_string_value(item.get("webUrl")),
            is_hidden=bool(item.get("isHidden", False)),
            is_hidden_for_all_members=bool(item.get("isHiddenForAllMembers", False)),
            other_participants=other_participants,
        )

    def _team_from_item(self, item: dict[str, Any]) -> TeamSummary:
        return TeamSummary(
            id=_string_value(item.get("id")),
            display_name=_string_value(item.get("displayName")),
            description=_string_value(item.get("description")),
            is_archived=bool(item.get("isArchived", False)),
            tenant_id=_string_value(item.get("tenantId")),
        )

    def _channel_from_item(self, item: dict[str, Any]) -> ChannelSummary:
        return ChannelSummary(
            id=_string_value(item.get("id")),
            display_name=_string_value(item.get("displayName")),
            description=_string_value(item.get("description")),
            membership_type=_string_value(item.get("membershipType")),
            web_url=_string_value(item.get("webUrl")),
        )

    def _message_from_item(
        self,
        item: dict[str, Any],
        *,
        chat_id: str = "",
        team_id: str = "",
        channel_id: str = "",
    ) -> TeamsMessage:
        body = item.get("body", {})
        content_type = _string_value(body.get("contentType"))
        content = _string_value(body.get("content"))
        reply_count = 0
        replies = item.get("replies")
        if isinstance(replies, list):
            reply_count = len(replies)
        from_value = item.get("from")
        sender_root = from_value if isinstance(from_value, dict) else {}
        sender_identity = sender_root.get("user")
        if not isinstance(sender_identity, dict):
            sender_identity = (
                sender_root.get("application")
                or sender_root.get("device")
                or {}
            )
        return TeamsMessage(
            id=_string_value(item.get("id")),
            body_content=_normalize_body(content, content_type),
            content_type=content_type,
            created_at=_parse_graph_datetime(item.get("createdDateTime")),
            last_modified_at=_parse_graph_datetime(item.get("lastModifiedDateTime")),
            last_edited_at=_parse_graph_datetime(item.get("lastEditedDateTime")),
            deleted_at=_parse_graph_datetime(item.get("deletedDateTime")),
            subject=_string_value(item.get("subject")),
            summary=_string_value(item.get("summary")),
            importance=_string_value(item.get("importance")),
            message_type=_string_value(item.get("messageType")),
            reply_to_id=_string_value(item.get("replyToId")),
            reply_count=reply_count,
            web_url=_string_value(item.get("webUrl")),
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
            sender=TeamsSender(
                display_name=_string_value(sender_identity.get("displayName")),
                email=_string_value(sender_identity.get("email")),
                user_id=_string_value(sender_identity.get("id")),
                kind=_sender_kind(sender_root),
            ),
            attachments=self._attachments_from_item(item),
        )

    def _search_hit_from_item(
        self,
        hit: dict[str, Any],
        resource: dict[str, Any],
    ) -> TeamsMessageSearchHit:
        channel_identity = resource.get("channelIdentity")
        if not isinstance(channel_identity, dict):
            channel_identity = {}
        sender_name, sender_email = _search_hit_sender(resource)
        channel_id = _string_value(channel_identity.get("channelId"))
        return TeamsMessageSearchHit(
            id=_string_value(resource.get("id")),
            summary=_string_value(hit.get("summary")),
            created_at=_parse_graph_datetime(resource.get("createdDateTime")),
            last_modified_at=_parse_graph_datetime(resource.get("lastModifiedDateTime")),
            subject=_string_value(resource.get("subject")),
            importance=_string_value(resource.get("importance")),
            web_url=_string_value(resource.get("webUrl") or resource.get("webLink")),
            chat_id=_string_value(resource.get("chatId")),
            team_id=_string_value(channel_identity.get("teamId")),
            channel_id=channel_id,
            sender_name=sender_name,
            sender_email=sender_email,
            location_kind="channel" if channel_id else "chat",
        )

    def _other_participants(self, item: dict[str, Any]) -> tuple[TeamsParticipant, ...]:
        members = item.get("members")
        if not isinstance(members, list):
            return ()
        participants: list[TeamsParticipant] = []
        for member in members:
            if not isinstance(member, dict):
                continue
            participant = TeamsParticipant(
                display_name=_string_value(member.get("displayName")),
                email=_string_value(member.get("email")),
                user_id=_string_value(member.get("userId")),
            )
            if self._is_viewer_participant(participant):
                continue
            participants.append(participant)
        return tuple(participants)

    def _is_viewer_participant(self, participant: TeamsParticipant) -> bool:
        if not self.viewer_user_id and not self.viewer_email:
            return False
        if self.viewer_user_id and participant.user_id == self.viewer_user_id:
            return True
        return bool(self.viewer_email and participant.email.lower() == self.viewer_email)

    def _message_item(
        self,
        *,
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> dict[str, Any]:
        self._ensure_supported_endpoint()
        if chat_id is not None and chat_id.strip():
            response = self.graph.get(
                "chats/"
                f"{_path_segment('chat_id', chat_id)}/messages/"
                f"{_path_segment('message_id', message_id)}"
            )
            if not isinstance(response, dict):
                raise GraphAPIError(0, "InvalidTeamsMessage", "message lookup failed")
            return response
        if team_id is None or channel_id is None:
            raise ValueError("provide chat_id or both team_id and channel_id")
        try:
            response = self.channel_graph.get(
                "teams/"
                f"{_path_segment('team_id', team_id)}/channels/"
                f"{_path_segment('channel_id', channel_id)}/messages/"
                f"{_path_segment('message_id', message_id)}"
            )
        except GraphAPIError as exc:
            raise _channel_permission_error(exc) from exc
        if not isinstance(response, dict):
            raise GraphAPIError(0, "InvalidTeamsMessage", "message lookup failed")
        return response

    def _attachments_from_item(self, item: dict[str, Any]) -> tuple[TeamsMessageAttachment, ...]:
        attachments = item.get("attachments")
        if not isinstance(attachments, list):
            return ()
        parsed: list[TeamsMessageAttachment] = []
        for value in attachments:
            if not isinstance(value, dict):
                continue
            parsed.append(
                TeamsMessageAttachment(
                    id=_string_value(value.get("id")),
                    name=_string_value(value.get("name")),
                    content_type=_string_value(value.get("contentType")),
                    content_url=_string_value(value.get("contentUrl")),
                    thumbnail_url=_string_value(value.get("thumbnailUrl")),
                    teams_app_id=_string_value(value.get("teamsAppId")),
                )
            )
        return tuple(parsed)

    def _require_message_attachment(
        self,
        *,
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> TeamsMessageAttachment:
        normalized_attachment_id = attachment_id.strip()
        if not normalized_attachment_id:
            raise ValueError("attachment_id must be a non-empty string")
        attachments = self.list_message_attachments(
            message_id=message_id,
            chat_id=chat_id,
            team_id=team_id,
            channel_id=channel_id,
        )
        for attachment in attachments:
            if attachment.id == normalized_attachment_id:
                return attachment
        raise ValueError("attachment_id was not found for the specified Teams message")


def _parse_graph_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _normalize_body(content: str, content_type: str) -> str:
    if content_type.lower() == "html":
        return strip_html(content)
    return content.strip()


def _sender_kind(value: dict[str, Any]) -> str:
    if "user" in value:
        return "user"
    if "application" in value:
        return "application"
    if "device" in value:
        return "device"
    return "unknown"


def _channel_permission_error(error: GraphAPIError) -> GraphAPIError:
    return _permission_error(
        error,
        message="Teams channel reads require admin-approved ChannelMessage.Read.All consent",
    )


def _teams_search_permission_error(error: GraphAPIError) -> GraphAPIError:
    return _permission_error(
        error,
        message=(
            "Teams global search requires admin-approved ChannelMessage.Read.All consent; "
            "run auth login --teams-channel-messages"
        ),
    )


def _teams_file_permission_error(error: GraphAPIError) -> GraphAPIError:
    if error.status_code != 403:
        return error
    return GraphAPIError(
        403,
        error.error_code,
        (
            "Teams file reads require Files.Read consent and access to the underlying file; "
            "run auth login --teams-files"
        ),
    )


def _permission_error(error: GraphAPIError, *, message: str) -> GraphAPIError:
    if error.status_code != 403:
        return error
    normalized_message = error.message.lower()
    if not any(
        marker in normalized_message
        for marker in (
            "channelmessage.read.all",
            "missing role permissions",
            "insufficient privileges",
        )
    ):
        return error
    return GraphAPIError(
        403,
        error.error_code,
        message,
    )


def _bounded_top(value: int, *, maximum: int) -> int:
    if value <= 0:
        raise ValueError("top must be a positive integer")
    return min(value, maximum)


def _non_negative_int(value: int, name: str) -> int:
    if value < 0:
        raise ValueError(f"{name} must be zero or greater")
    return value


def _path_segment(name: str, value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{name} must be a non-empty string")
    return quote(normalized, safe="")


def _string_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    return ""


def _search_hit_sender(resource: dict[str, Any]) -> tuple[str, str]:
    from_value = resource.get("from")
    if not isinstance(from_value, dict):
        return "", ""
    email_address = from_value.get("emailAddress")
    if isinstance(email_address, dict):
        return (
            _string_value(email_address.get("name")),
            _string_value(email_address.get("address")),
        )
    sender_identity = from_value.get("user")
    if isinstance(sender_identity, dict):
        return (
            _string_value(sender_identity.get("displayName")),
            _string_value(sender_identity.get("email")),
        )
    return "", ""


def _viewer_identity(token: str, configured_upn: str) -> tuple[str, str]:
    try:
        payload = jwt.decode(token, options={"verify_signature": False, "verify_aud": False})
    except jwt.PyJWTError:
        payload = {}
    user_id = _string_value(payload.get("oid"))
    email = _string_value(
        payload.get("preferred_username") or payload.get("upn") or payload.get("email")
    )
    if not email and configured_upn:
        email = configured_upn
    return user_id, email.lower()


def _chat_display_label(item: dict[str, Any], participants: tuple[TeamsParticipant, ...]) -> str:
    topic = _string_value(item.get("topic"))
    if topic:
        return topic
    labels = [
        label
        for participant in participants
        for label in (_participant_label(participant),)
        if label
    ]
    if labels:
        return ", ".join(labels)
    return _string_value(item.get("id"))


def _participant_label(participant: TeamsParticipant) -> str:
    return participant.display_name or participant.email


def _share_token_from_url(url: str) -> str:
    normalized = url.strip()
    if not normalized:
        raise ValueError("attachment does not have a content URL")
    encoded = base64.urlsafe_b64encode(normalized.encode("utf-8")).decode("ascii").rstrip("=")
    return f"u!{encoded}"


def _drive_item_content_type(item: dict[str, Any]) -> str:
    file_value = item.get("file")
    if not isinstance(file_value, dict):
        return ""
    return _string_value(file_value.get("mimeType"))


def _email_attachment_from_teams_attachment(
    attachment: TeamsMessageAttachment,
    *,
    size: int,
) -> EmailAttachment:
    return EmailAttachment(
        id=attachment.id,
        name=attachment.name,
        content_type=attachment.content_type,
        size=size,
        is_inline=False,
        is_reference=False,
        odata_type="#microsoft.graph.fileAttachment",
    )


def _normalized_query(query: str) -> str:
    normalized = query.strip().lower()
    if not normalized:
        raise ValueError("query must be a non-empty string")
    return normalized


def _chat_search_score(chat: TeamsChat, query: str) -> tuple[int, int, float] | None:
    query_terms = _search_terms(query)
    exact_email = any(participant.email.lower() == query for participant in chat.other_participants)
    if exact_email:
        return _chat_rank_tuple(chat, 4)
    exact_name = any(
        query_terms and _search_terms(participant.display_name) == query_terms
        for participant in chat.other_participants
    )
    if exact_name:
        return _chat_rank_tuple(chat, 3)
    participant_match = any(
        query in participant.display_name.lower()
        or query in participant.email.lower()
        or _contains_search_terms(participant.display_name, query_terms)
        or _contains_search_terms(participant.email, query_terms)
        for participant in chat.other_participants
    )
    if participant_match:
        return _chat_rank_tuple(chat, 2)
    topic = _searchable_text(chat.topic)
    display_label = _searchable_text(chat.display_label)
    if query in topic or query in display_label:
        return _chat_rank_tuple(chat, 1)
    return None


def _chat_rank_tuple(chat: TeamsChat, bucket: int) -> tuple[int, int, float]:
    is_one_on_one = 1 if chat.chat_type == "oneOnOne" else 0
    last_updated = chat.last_updated_at.timestamp() if chat.last_updated_at is not None else 0.0
    return bucket, is_one_on_one, last_updated


def _message_search_score(message: TeamsMessage, query: str) -> tuple[int, float] | None:
    sender_display = message.sender.display_name.lower()
    sender_email = message.sender.email.lower()
    subject = _searchable_text(message.subject)
    summary = _searchable_text(message.summary)
    body = _searchable_text(message.body_content)
    combined = " ".join(
        part
        for part in (
            sender_display,
            sender_email,
            subject,
            summary,
            body,
        )
        if part
    )
    if sender_email == query:
        return _message_rank_tuple(message, 4)
    if query and _search_terms(message.sender.display_name) == _search_terms(query):
        return _message_rank_tuple(message, 3)
    if query in subject or query in summary:
        return _message_rank_tuple(message, 2)
    if query in body or query in combined:
        return _message_rank_tuple(message, 1)
    if _contains_search_terms(combined, _search_terms(query)):
        return _message_rank_tuple(message, 1)
    return None


def _message_rank_tuple(message: TeamsMessage, bucket: int) -> tuple[int, float]:
    created_at = message.created_at.timestamp() if message.created_at is not None else 0.0
    return bucket, created_at


def _search_terms(value: str) -> tuple[str, ...]:
    return tuple(sorted(re.findall(r"[a-z0-9]+", value.lower())))


def _searchable_text(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", value.lower()))


def _contains_search_terms(value: str, query_terms: tuple[str, ...]) -> bool:
    if not query_terms:
        return False
    value_terms = set(_search_terms(value))
    return set(query_terms).issubset(value_terms)


def _sort_messages_oldest_first(messages: list[TeamsMessage]) -> list[TeamsMessage]:
    indexed_messages = list(enumerate(messages))
    indexed_messages.sort(
        key=lambda item: (
            item[1].created_at is None,
            item[1].created_at.timestamp() if item[1].created_at is not None else 0.0,
            item[0],
        )
    )
    return [message for _, message in indexed_messages]
