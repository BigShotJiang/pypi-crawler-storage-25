from __future__ import annotations

import json
import os
import shlex
import urllib.request
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from typing import Any

from packaging.version import InvalidVersion, Version

from ms365_toolkit import __version__
from ms365_toolkit.config.loader import get_profile_dir

PACKAGE_NAMES = ("ms365-toolkit", "ms365-toolkit-mcp")
MCP_PACKAGE_NAME = "ms365-toolkit-mcp"
PYPI_URL_TEMPLATE = "https://pypi.org/pypi/{package}/json"
DEFAULT_TIMEOUT_SECONDS = 2.0


@dataclass(frozen=True)
class PackageVersionStatus:
    package: str
    current_version: str
    latest_version: str | None
    is_stale: bool | None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "package": self.package,
            "current_version": self.current_version,
            "latest_version": self.latest_version,
            "is_stale": self.is_stale,
        }
        if self.error is not None:
            payload["error"] = self.error
        return payload


@dataclass(frozen=True)
class ToolkitVersionStatus:
    version: str
    is_stale: bool | None
    source: str
    checked_at: str | None
    cache_path: str
    packages: tuple[PackageVersionStatus, ...]
    update_commands: dict[str, str]
    check_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "version": self.version,
            "is_stale": self.is_stale,
            "source": self.source,
            "checked_at": self.checked_at,
            "cache_path": self.cache_path,
            "packages": [item.to_dict() for item in self.packages],
            "update_commands": self.update_commands,
        }
        if self.check_error is not None:
            payload["check_error"] = self.check_error
        return payload


def get_toolkit_status(
    profile: str,
    *,
    include_latest: bool = True,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> ToolkitVersionStatus:
    if not include_latest:
        return _build_status(
            profile=profile,
            packages=tuple(_unchecked_package_status(package) for package in PACKAGE_NAMES),
            source="installed",
            checked_at=None,
            check_error=None,
        )

    live_status = _check_live_status(profile, timeout=timeout)
    if any(package.latest_version is not None for package in live_status.packages):
        return live_status

    cached_status = read_cached_toolkit_status(profile)
    if cached_status is None:
        return live_status
    return replace(cached_status, check_error=live_status.check_error)


def read_cached_toolkit_status(profile: str) -> ToolkitVersionStatus | None:
    path = version_status_cache_path(profile)
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as handle:
            payload = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None

    checked_at = payload.get("checked_at")
    packages_payload = payload.get("packages")
    if not isinstance(checked_at, str) or not isinstance(packages_payload, list):
        return None

    packages: list[PackageVersionStatus] = []
    for item in packages_payload:
        if not isinstance(item, dict):
            return None
        package = item.get("package")
        latest_version = item.get("latest_version")
        if not isinstance(package, str) or not isinstance(latest_version, str):
            return None
        packages.append(_package_status(package, latest_version))

    return _build_status(
        profile=profile,
        packages=tuple(packages),
        source="cache",
        checked_at=checked_at,
        check_error=None,
    )


def stale_warning_from_cache(profile: str) -> str | None:
    status = read_cached_toolkit_status(profile)
    if status is None:
        return None
    return stale_warning_from_status(status)


def stale_warning_from_live(
    profile: str,
    *,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> str | None:
    return stale_warning_from_status(get_toolkit_status(profile, timeout=timeout))


def stale_warning_from_status(status: ToolkitVersionStatus | None) -> str | None:
    if status is None or status.is_stale is not True:
        return None
    latest_version = _latest_mcp_version(status)
    if latest_version is None:
        return None
    return (
        f"ms365-toolkit {__version__} is stale; latest {MCP_PACKAGE_NAME} is "
        f"{latest_version}. Run `ms365-toolkit doctor` for update commands."
    )


def version_status_cache_path(profile: str) -> str:
    return str(get_profile_dir(profile) / "status" / "latest_version.json")


def fetch_latest_package_version(
    package: str,
    *,
    timeout: float = DEFAULT_TIMEOUT_SECONDS,
) -> str:
    url = PYPI_URL_TEMPLATE.format(package=package)
    with urllib.request.urlopen(url, timeout=timeout) as response:  # nosec B310
        payload = json.load(response)
    info = payload.get("info") if isinstance(payload, dict) else None
    latest_version = info.get("version") if isinstance(info, dict) else None
    if not isinstance(latest_version, str) or not latest_version.strip():
        raise ValueError(f"PyPI response for {package} did not include info.version")
    return latest_version


def _check_live_status(profile: str, *, timeout: float) -> ToolkitVersionStatus:
    packages = tuple(_check_package(package, timeout=timeout) for package in PACKAGE_NAMES)
    check_error = _combined_errors(packages)
    status = _build_status(
        profile=profile,
        packages=packages,
        source="live",
        checked_at=_utc_now(),
        check_error=check_error,
    )
    if all(package.latest_version is not None for package in packages):
        try:
            _write_status_cache(profile, status)
        except OSError as exc:
            status = replace(
                status,
                check_error=f"cache write failed: {type(exc).__name__}: {exc}",
            )
    return status


def _check_package(package: str, *, timeout: float) -> PackageVersionStatus:
    try:
        return _package_status(package, fetch_latest_package_version(package, timeout=timeout))
    except (OSError, ValueError) as exc:
        return PackageVersionStatus(
            package=package,
            current_version=__version__,
            latest_version=None,
            is_stale=None,
            error=f"{type(exc).__name__}: {exc}",
        )


def _package_status(package: str, latest_version: str) -> PackageVersionStatus:
    return PackageVersionStatus(
        package=package,
        current_version=__version__,
        latest_version=latest_version,
        is_stale=_is_stale(__version__, latest_version),
        error=None,
    )


def _unchecked_package_status(package: str) -> PackageVersionStatus:
    return PackageVersionStatus(
        package=package,
        current_version=__version__,
        latest_version=None,
        is_stale=None,
        error=None,
    )


def _build_status(
    *,
    profile: str,
    packages: tuple[PackageVersionStatus, ...],
    source: str,
    checked_at: str | None,
    check_error: str | None,
) -> ToolkitVersionStatus:
    is_stale = _combined_stale(packages)
    latest_version = _latest_mcp_version_from_packages(packages)
    return ToolkitVersionStatus(
        version=__version__,
        is_stale=is_stale,
        source=source,
        checked_at=checked_at,
        cache_path=version_status_cache_path(profile),
        packages=packages,
        update_commands=_update_commands(profile, latest_version) if is_stale is True else {},
        check_error=check_error,
    )


def _write_status_cache(profile: str, status: ToolkitVersionStatus) -> None:
    path = version_status_cache_path(profile)
    os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
    payload = {
        "checked_at": status.checked_at,
        "packages": [
            {
                "package": package.package,
                "latest_version": package.latest_version,
            }
            for package in status.packages
            if package.latest_version is not None
        ],
    }
    encoded = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, encoded)
    finally:
        os.close(fd)
    os.chmod(path, 0o600)


def _is_stale(current_version: str, latest_version: str) -> bool | None:
    try:
        return bool(Version(current_version) < Version(latest_version))
    except InvalidVersion:
        return None


def _combined_stale(packages: tuple[PackageVersionStatus, ...]) -> bool | None:
    stale_values = [package.is_stale for package in packages]
    if any(value is True for value in stale_values):
        return True
    if stale_values and all(value is False for value in stale_values):
        return False
    return None


def _combined_errors(packages: tuple[PackageVersionStatus, ...]) -> str | None:
    errors = [
        f"{package.package}: {package.error}"
        for package in packages
        if package.error is not None
    ]
    return "; ".join(errors) or None


def _latest_mcp_version(status: ToolkitVersionStatus) -> str | None:
    return _latest_mcp_version_from_packages(status.packages)


def _latest_mcp_version_from_packages(packages: tuple[PackageVersionStatus, ...]) -> str | None:
    for package in packages:
        if package.package == MCP_PACKAGE_NAME and package.latest_version is not None:
            return package.latest_version
    for package in packages:
        if package.latest_version is not None:
            return package.latest_version
    return None


def _update_commands(profile: str, latest_version: str | None) -> dict[str, str]:
    if latest_version is None:
        return {}
    codex_env = " ".join(f"--env {shlex.quote(item)}" for item in _mcp_env(profile))
    claude_env = " ".join(f"-e {shlex.quote(item)}" for item in _mcp_env(profile))
    launcher = shlex.quote(f"cd /tmp && exec uvx {MCP_PACKAGE_NAME}@latest")
    return {
        "codex": f"codex mcp add ms365 {codex_env} -- sh -lc {launcher}",
        "claude": f"claude mcp add -s user ms365 {claude_env} -- sh -lc {launcher}",
    }


def _mcp_env(profile: str) -> tuple[str, ...]:
    return (
        f"MS365_TOOLKIT_PROFILE={profile}",
        "MS365_TOOLKIT_WARN_STALE=1",
        "UV_CACHE_DIR=/tmp/ms365-toolkit-uv-cache",
        "UV_TOOL_DIR=/tmp/ms365-toolkit-uv-tools",
    )


def _utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")
