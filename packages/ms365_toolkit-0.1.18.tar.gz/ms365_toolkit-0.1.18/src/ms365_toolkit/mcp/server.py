from __future__ import annotations

import os
import sys

from fastmcp import FastMCP

from ms365_toolkit import __version__
from ms365_toolkit.mcp.runtime import ReadRuntime
from ms365_toolkit.mcp.tools import register_tools
from ms365_toolkit.version_status import stale_warning_from_live

_STARTUP_STALE_CHECK_TIMEOUT_SECONDS = 1.0


def create_server(profile: str = "default", runtime: ReadRuntime | None = None) -> FastMCP:
    active_runtime = runtime or ReadRuntime.load(profile=profile)
    _warn_if_stale(active_runtime, fallback_profile=profile)
    mcp = FastMCP(
        name="ms365-toolkit",
        instructions=(
            "Microsoft 365 mailbox, calendar, and Teams tools with guarded email draft and send "
            "support. "
            "All datetimes must be timezone-aware ISO 8601 strings."
        ),
        version=__version__,
    )
    register_tools(mcp, active_runtime)
    return mcp


def _warn_if_stale(runtime: ReadRuntime, *, fallback_profile: str) -> None:
    if os.environ.get("MS365_TOOLKIT_WARN_STALE") != "1":
        return
    profile = getattr(runtime, "profile", fallback_profile)
    if not isinstance(profile, str):
        profile = fallback_profile
    warning = stale_warning_from_live(
        profile,
        timeout=_STARTUP_STALE_CHECK_TIMEOUT_SECONDS,
    )
    if warning is not None:
        print(warning, file=sys.stderr)
