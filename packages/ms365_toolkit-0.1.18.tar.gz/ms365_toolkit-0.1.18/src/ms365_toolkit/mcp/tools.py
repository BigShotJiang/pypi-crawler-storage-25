from __future__ import annotations

import json
from datetime import UTC, datetime
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, ParamSpec, TypeVar, cast

from ms365_toolkit.client.exceptions import (
    AuthenticationError,
    GraphAPIError,
    RateLimitedError,
    SafetyDeniedError,
)
from ms365_toolkit.config.loader import get_profile_dir
from ms365_toolkit.mcp.cursors import (
    OffsetCursor,
    PageCursor,
    decode_offset_cursor,
    decode_page_cursor,
    encode_offset_cursor,
    encode_page_cursor,
)
from ms365_toolkit.mcp.planner import find_open_windows
from ms365_toolkit.mcp.serializers import (
    serialize_channel,
    serialize_chat_summary,
    serialize_email,
    serialize_email_attachment,
    serialize_email_draft,
    serialize_email_share_link,
    serialize_email_summary,
    serialize_event,
    serialize_event_summary,
    serialize_extracted_attachment,
    serialize_extracted_meeting_transcript,
    serialize_extracted_teams_file,
    serialize_meeting_ai_insight,
    serialize_meeting_transcript,
    serialize_share_link_drive_item,
    serialize_team,
    serialize_teams_attachment,
    serialize_teams_message,
    serialize_teams_message_search_hit_summary,
    serialize_teams_message_summary,
    serialize_teams_thread,
    serialize_windows,
)
from ms365_toolkit.usage import (
    GraphUsageMetrics,
    UsageLogger,
    build_usage_event,
    start_usage_recording,
    stop_usage_recording,
    usage_error_code,
    usage_error_type,
    usage_start,
)
from ms365_toolkit.version_status import (
    get_toolkit_status as build_toolkit_status,
)
from ms365_toolkit.version_status import (
    stale_warning_from_cache,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from fastmcp import FastMCP

    from ms365_toolkit.mcp.runtime import ReadRuntime

P = ParamSpec("P")
R = TypeVar("R")


def register_tools(mcp: FastMCP, runtime: ReadRuntime) -> None:
    _tool_errors = _build_tool_errors(runtime)

    @mcp.tool(description="Return installed toolkit version and latest-version status.")
    @_tool_errors
    def get_toolkit_status(include_latest: bool = True) -> dict[str, Any]:
        profile = getattr(runtime, "profile", "default")
        if not isinstance(profile, str):
            profile = "default"
        return build_toolkit_status(profile, include_latest=include_latest).to_dict()

    @mcp.tool(description="List inbox message summaries from the current mailbox.")
    @_tool_errors
    def list_inbox(
        mailbox_filter: str = "all",
        top: int = 10,
        skip: int = 0,
        max_chars: int = 20_000,
        offset: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        if cursor:
            page_cursor = decode_page_cursor("list_inbox", cursor)
            normalized_offset = _non_negative_int(offset or 0, "offset")
            page = runtime.email_client().list_inbox_page(
                top=normalized_top,
                summary_only=True,
                next_link=page_cursor.next_link,
            )
            absolute_offset = None
        else:
            normalized_filter = _normalize_mailbox_filter(mailbox_filter)
            normalized_offset = (
                _non_negative_int(offset, "offset")
                if offset is not None
                else _non_negative_int(skip, "skip")
            )
            page = runtime.email_client().list_inbox_page(
                mailbox_filter=normalized_filter,
                top=normalized_top,
                skip=normalized_offset,
                summary_only=True,
            )
            absolute_offset = normalized_offset
        return _serialize_email_summary_page(
            page.items,
            max_chars=max_chars,
            offset=0 if absolute_offset is not None else normalized_offset,
            absolute_offset=absolute_offset,
            next_cursor=encode_page_cursor("list_inbox", page.next_link),
        )

    @mcp.tool(description="Search mailbox message summaries by query.")
    @_tool_errors
    def search_emails(
        query: str = "",
        mailbox_filter: str = "all",
        top: int = 10,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_page_cursor("search_emails", cursor)
            normalized_filter = _mailbox_filter_from_cursor(page_cursor)
            page = runtime.email_client().search_emails_page(
                "",
                mailbox_filter=normalized_filter,
                top=normalized_top,
                summary_only=True,
                next_link=page_cursor.next_link,
            )
        else:
            if not query.strip():
                raise ValueError("query must be a non-empty string")
            normalized_filter = _normalize_mailbox_filter(mailbox_filter)
            page = runtime.email_client().search_emails_page(
                query=query,
                mailbox_filter=normalized_filter,
                top=_candidate_limit(normalized_top, normalized_offset),
                summary_only=True,
            )
        return _serialize_email_summary_page(
            page.items,
            max_chars=max_chars,
            offset=normalized_offset,
            next_cursor=encode_page_cursor(
                "search_emails",
                page.next_link,
                context={"mailbox_filter": normalized_filter},
            ),
        )

    @mcp.tool(description="Read a single email message by id.")
    @_tool_errors
    def read_email(message_id: str) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_email(runtime.email_client().read_email(message_id))

    @mcp.tool(description="Read a full email thread by conversation id in chronological order.")
    @_tool_errors
    def read_conversation_thread(
        conversation_id: str,
        top: int = 100,
    ) -> dict[str, Any]:
        normalized_conversation_id = conversation_id.strip()
        if not normalized_conversation_id:
            raise ValueError("conversation_id must be a non-empty string")
        messages = runtime.email_client().read_conversation_thread(
            normalized_conversation_id,
            top=_positive_int(top, "top"),
        )
        return {
            "conversation_id": normalized_conversation_id,
            "messages": [serialize_email(item) for item in messages],
        }

    @mcp.tool(description="List downloadable email attachments by message id.")
    @_tool_errors
    def list_email_attachments(
        message_id: str,
        include_inline: bool = False,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        attachments = runtime.email_client().list_attachments(
            message_id,
            include_inline=include_inline,
        )
        return {"attachments": [serialize_email_attachment(item) for item in attachments]}

    @mcp.tool(description="Read supported email attachment text by attachment id.")
    @_tool_errors
    def read_email_attachment(
        message_id: str,
        attachment_id: str,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        if not attachment_id.strip():
            raise ValueError("attachment_id must be a non-empty string")
        return serialize_extracted_attachment(
            runtime.email_client().read_attachment_text(
                message_id,
                attachment_id,
                max_chars=_positive_int(max_chars, "max_chars"),
            )
        )

    @mcp.tool(description="List SharePoint/OneDrive share links found in an email body.")
    @_tool_errors
    def list_email_share_links(message_id: str) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        links = runtime.email_client().list_email_share_links(message_id)
        return {"share_links": [serialize_email_share_link(item) for item in links]}

    @mcp.tool(description="Download a SharePoint/OneDrive share link to a local path.")
    @_tool_errors
    def download_share_link(
        url: str,
        dest_path: str | None = None,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        if not url.strip():
            raise ValueError("url must be a non-empty string")
        email_client = runtime.email_client(include_share_links=True)
        downloaded = email_client.download_share_link(url)
        output_path = _share_download_path(
            dest_path=dest_path,
            profile=getattr(runtime, "profile", "default"),
            name=downloaded.drive_item.name,
            share_id=downloaded.drive_item.item_id or downloaded.drive_item.share_id,
        )
        output_path.write_bytes(downloaded.content)
        extracted_payload: dict[str, Any] | None = None
        text_path: Path | None = None
        warnings: list[str] = []
        try:
            extracted = email_client.extract_downloaded_share_link_text(
                downloaded,
                max_chars=_positive_int(max_chars, "max_chars"),
            )
        except ValueError as exc:
            warnings.append(f"Text extraction skipped: {exc}")
        else:
            text_path = _unique_file_path(output_path.with_name(f"{output_path.name}.txt"))
            text_path.write_text(extracted.text_content, encoding="utf-8")
            extracted_payload = serialize_extracted_attachment(extracted)
        return {
            "url": downloaded.url,
            "path": str(output_path),
            "text_path": str(text_path) if text_path is not None else None,
            "drive_item": serialize_share_link_drive_item(downloaded.drive_item),
            "extracted": extracted_payload,
            "warnings": warnings,
        }

    @mcp.tool(description="Download all SharePoint/OneDrive share links found in an email body.")
    @_tool_errors
    def download_email_share_links(
        message_id: str,
        output_dir: str | None = None,
        max_chars: int = 20_000,
    ) -> dict[str, Any]:
        normalized_message_id = message_id.strip()
        if not normalized_message_id:
            raise ValueError("message_id must be a non-empty string")
        email_client = runtime.email_client(include_share_links=True)
        links = email_client.list_email_share_links(normalized_message_id)
        downloads: list[dict[str, Any]] = []
        skipped_duplicates = 0
        seen_items: set[str] = set()
        for link in links:
            drive_item = email_client.resolve_share_link(link.url)
            item_key = drive_item.item_id or drive_item.share_id
            if item_key in seen_items:
                skipped_duplicates += 1
                continue
            seen_items.add(item_key)
            downloaded = email_client.download_resolved_share_link(link.url, drive_item)
            output_path = _share_download_path(
                dest_path=output_dir,
                profile=getattr(runtime, "profile", "default"),
                name=downloaded.drive_item.name or link.filename,
                share_id=item_key,
            )
            output_path.write_bytes(downloaded.content)
            extracted_payload: dict[str, Any] | None = None
            text_path: Path | None = None
            warnings: list[str] = []
            try:
                extracted = email_client.extract_downloaded_share_link_text(
                    downloaded,
                    max_chars=_positive_int(max_chars, "max_chars"),
                )
            except ValueError as exc:
                warnings.append(f"Text extraction skipped: {exc}")
            else:
                text_path = _unique_file_path(output_path.with_name(f"{output_path.name}.txt"))
                text_path.write_text(extracted.text_content, encoding="utf-8")
                extracted_payload = serialize_extracted_attachment(extracted)
            downloads.append(
                {
                    "url": downloaded.url,
                    "path": str(output_path),
                    "text_path": str(text_path) if text_path is not None else None,
                    "drive_item": serialize_share_link_drive_item(downloaded.drive_item),
                    "extracted": extracted_payload,
                    "warnings": warnings,
                }
            )
        return {
            "message_id": normalized_message_id,
            "downloads": downloads,
            "skipped_duplicates": skipped_duplicates,
        }

    @mcp.tool(description="Create a guarded email draft in the signed-in mailbox.")
    @_tool_errors
    def create_email_draft(
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        reply_to: list[str] | None = None,
        importance: str = "normal",
    ) -> dict[str, Any]:
        draft = runtime.email_client(write=True).create_email_draft(
            to=_non_empty_emails(to, "to"),
            cc=_optional_emails(cc),
            bcc=_optional_emails(bcc),
            subject=subject,
            body=body,
            reply_to=_optional_emails(reply_to),
            importance=_normalize_importance(importance),
        )
        return serialize_email_draft(draft)

    @mcp.tool(description="Create a guarded reply draft for an existing email message.")
    @_tool_errors
    def create_reply_draft(
        message_id: str,
        body: str,
        importance: str | None = None,
    ) -> dict[str, Any]:
        normalized_message_id = message_id.strip()
        if not normalized_message_id:
            raise ValueError("message_id must be a non-empty string")
        draft = runtime.email_client(write=True).create_reply_draft(
            message_id=normalized_message_id,
            body=body,
            importance=_normalize_importance(importance) if importance is not None else None,
        )
        return serialize_email_draft(draft)

    @mcp.tool(description="Send a previously created draft after hash verification.")
    @_tool_errors
    def send_email_draft(draft_id: str, content_hash: str) -> dict[str, Any]:
        normalized_draft_id = draft_id.strip()
        if not normalized_draft_id:
            raise ValueError("draft_id must be a non-empty string")
        normalized_hash = content_hash.strip()
        if not normalized_hash:
            raise ValueError("content_hash must be a non-empty string")
        runtime.email_client(write=True).send_email_draft(
            draft_id=normalized_draft_id,
            content_hash=normalized_hash,
        )
        return {"status": "sent", "draft_id": normalized_draft_id}

    @mcp.tool(description="List downloadable Teams files from a chat or channel message.")
    @_tool_errors
    def list_teams_message_files(
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        attachments = runtime.teams_client(
            include_channel_messages=team_id is not None and team_id.strip() != "",
        ).list_message_attachments(
            message_id=message_id,
            **_teams_message_locator(
                chat_id=chat_id,
                team_id=team_id,
                channel_id=channel_id,
            ),
        )
        return {"attachments": [serialize_teams_attachment(item) for item in attachments]}

    @mcp.tool(description="Read supported Teams file text from a chat or channel message.")
    @_tool_errors
    def read_teams_message_file(
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
        max_chars: int = 50_000,
    ) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        if not attachment_id.strip():
            raise ValueError("attachment_id must be a non-empty string")
        extracted = runtime.teams_client(
            include_channel_messages=team_id is not None and team_id.strip() != "",
            include_files=True,
        ).read_message_attachment_text(
            message_id=message_id,
            attachment_id=attachment_id,
            max_chars=_positive_int(max_chars, "max_chars"),
            **_teams_message_locator(
                chat_id=chat_id,
                team_id=team_id,
                channel_id=channel_id,
            ),
        )
        return serialize_extracted_teams_file(extracted)

    @mcp.tool(description="List available mail folders.")
    @_tool_errors
    def list_folders() -> dict[str, Any]:
        return {"folders": runtime.email_client().list_folders()}

    @mcp.tool(description="List calendar events in a time window.")
    @_tool_errors
    def list_events(
        start: str = "",
        end: str = "",
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        if cursor:
            page_cursor = decode_page_cursor("list_events", cursor)
            page = runtime.calendar_client().list_events_page(next_link=page_cursor.next_link)
        else:
            start_dt, end_dt = _parse_window(start, end)
            page = runtime.calendar_client().list_events_page(
                start=start_dt,
                end=end_dt,
                calendar_id=_optional_str(calendar_id),
                calendar_filter=_optional_str(calendar_filter),
            )
        return _serialize_collection(
            page.items,
            key="events",
            serializer=serialize_event_summary,
            max_chars=max_chars,
            offset=_non_negative_int(offset, "offset"),
            next_cursor=encode_page_cursor("list_events", page.next_link),
        )

    @mcp.tool(description="Get a single calendar event by id.")
    @_tool_errors
    def get_event(event_id: str) -> dict[str, Any]:
        if not event_id.strip():
            raise ValueError("event_id must be a non-empty string")
        return serialize_event(runtime.calendar_client().get_event(event_id))

    @mcp.tool(description="List meeting transcripts for an event, join URL, or online meeting id.")
    @_tool_errors
    def list_meeting_transcripts(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 5,
    ) -> dict[str, Any]:
        transcripts = runtime.calendar_client(
            include_meeting_transcripts=True
        ).list_meeting_transcripts(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            top=_positive_int(top, "top"),
        )
        return {"transcripts": [serialize_meeting_transcript(item) for item in transcripts]}

    @mcp.tool(
        description="Read meeting transcript text for an event, join URL, or online meeting id."
    )
    @_tool_errors
    def read_meeting_transcript(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        transcript_id: str | None = None,
        max_chars: int = 20_000,
    ) -> dict[str, Any]:
        extracted = runtime.calendar_client(
            include_meeting_transcripts=True
        ).read_meeting_transcript(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            transcript_id=_optional_str(transcript_id),
            max_chars=_positive_int(max_chars, "max_chars"),
        )
        return serialize_extracted_meeting_transcript(extracted)

    @mcp.tool(
        description=(
            "Read Copilot-generated meeting notes for an event, join URL, or online "
            "meeting id."
        )
    )
    @_tool_errors
    def read_meeting_notes(
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        ai_insight_id: str | None = None,
    ) -> dict[str, Any]:
        insight = runtime.calendar_client(
            include_meeting_notes=True
        ).read_meeting_ai_insight(
            event_id=_optional_str(event_id),
            join_web_url=_optional_str(join_web_url),
            online_meeting_id=_optional_str(online_meeting_id),
            ai_insight_id=_optional_str(ai_insight_id),
        )
        return serialize_meeting_ai_insight(insight)

    @mcp.tool(description="Search calendar events by subject.")
    @_tool_errors
    def search_events(
        query: str = "",
        start: str | None = None,
        end: str | None = None,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        if cursor:
            page_cursor = decode_page_cursor("search_events", cursor)
            page = runtime.calendar_client().search_events_page(
                query="",
                next_link=page_cursor.next_link,
            )
        else:
            if not query.strip():
                raise ValueError("query must be a non-empty string")
            start_dt = _parse_datetime(start, "start") if start is not None else None
            end_dt = _parse_datetime(end, "end") if end is not None else None
            if start_dt is not None and end_dt is not None and end_dt <= start_dt:
                raise ValueError("end must be later than start")
            page = runtime.calendar_client().search_events_page(
                query=query,
                start=start_dt,
                end=end_dt,
            )
        return _serialize_collection(
            page.items,
            key="events",
            serializer=serialize_event_summary,
            max_chars=max_chars,
            offset=_non_negative_int(offset, "offset"),
            next_cursor=encode_page_cursor("search_events", page.next_link),
        )

    @mcp.tool(description="List available calendars.")
    @_tool_errors
    def list_calendars(cursor: str | None = None) -> dict[str, Any]:
        next_link = decode_page_cursor("list_calendars", cursor).next_link if cursor else None
        page = runtime.calendar_client().list_calendars_page(next_link=next_link)
        result: dict[str, Any] = {"calendars": page.items}
        next_cursor = encode_page_cursor("list_calendars", page.next_link)
        if next_cursor:
            result["next_cursor"] = next_cursor
        return result

    @mcp.tool(description="Find open windows across attendees using Microsoft 365 free/busy.")
    @_tool_errors
    def find_free_slots(
        attendees: list[str],
        start: str,
        end: str,
        duration_minutes: int,
        ignore_subject_terms: list[str] | None = None,
    ) -> dict[str, Any]:
        normalized_attendees = [item.strip() for item in attendees if item.strip()]
        if not normalized_attendees:
            raise ValueError("attendees must contain at least one email address")
        start_dt, end_dt = _parse_window(start, end)
        response = runtime.graph_client().post(
            "calendar/getSchedule",
            body={
                "schedules": normalized_attendees,
                "startTime": {
                    "dateTime": start_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "endTime": {
                    "dateTime": end_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "availabilityViewInterval": _positive_int(duration_minutes, "duration_minutes"),
            },
        )
        windows = find_open_windows(
            response,
            start=start_dt,
            end=end_dt,
            duration_minutes=duration_minutes,
            ignore_subject_terms=ignore_subject_terms or [],
        )
        return {"windows": serialize_windows(windows)}

    @mcp.tool(description="List Teams chats for the current user.")
    @_tool_errors
    def list_chats(
        top: int = 25,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_page_cursor("list_chats", cursor)
            page = runtime.teams_client(include_channel_messages=False).list_chats_page(
                top=normalized_top,
                next_link=page_cursor.next_link,
            )
        else:
            page = runtime.teams_client(include_channel_messages=False).list_chats_page(
                top=_candidate_limit(normalized_top, normalized_offset)
            )
        return _serialize_collection(
            page.items,
            key="chats",
            serializer=serialize_chat_summary,
            max_chars=max_chars,
            offset=normalized_offset,
            next_cursor=encode_page_cursor("list_chats", page.next_link),
        )

    @mcp.tool(description="Search Teams chats by participant name, email, or topic.")
    @_tool_errors
    def search_chats(
        query: str,
        top: int = 10,
        max_chars: int = 20_000,
        offset: int = 0,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        chats = runtime.teams_client(include_channel_messages=False).search_chats(
            query=query,
            top=_candidate_limit(normalized_top, normalized_offset),
        )
        return _serialize_collection(
            chats,
            key="chats",
            serializer=serialize_chat_summary,
            max_chars=max_chars,
            offset=normalized_offset,
        )

    @mcp.tool(description="List messages from a Teams chat.")
    @_tool_errors
    def list_chat_messages(
        chat_id: str = "",
        top: int = 25,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_page_cursor("list_chat_messages", cursor)
            normalized_chat_id = _cursor_required_context(page_cursor, "chat_id")
            page = runtime.teams_client(include_channel_messages=False).list_chat_messages_page(
                chat_id=normalized_chat_id,
                top=normalized_top,
                next_link=page_cursor.next_link,
            )
        else:
            normalized_chat_id = _required_str(chat_id, "chat_id")
            page = runtime.teams_client(include_channel_messages=False).list_chat_messages_page(
                chat_id=normalized_chat_id,
                top=_candidate_limit(normalized_top, normalized_offset),
            )
        return _serialize_collection(
            page.items,
            key="messages",
            serializer=serialize_teams_message_summary,
            max_chars=max_chars,
            offset=normalized_offset,
            next_cursor=encode_page_cursor(
                "list_chat_messages",
                page.next_link,
                context={"chat_id": normalized_chat_id},
            ),
        )

    @mcp.tool(description="Search messages in a Teams chat.")
    @_tool_errors
    def search_chat_messages(
        chat_id: str,
        query: str,
        top: int = 10,
        max_chars: int = 20_000,
        offset: int = 0,
    ) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        messages = runtime.teams_client(include_channel_messages=False).search_chat_messages(
            chat_id=chat_id,
            query=query,
            top=_candidate_limit(normalized_top, normalized_offset),
        )
        return _serialize_collection(
            messages,
            key="messages",
            serializer=serialize_teams_message_summary,
            max_chars=max_chars,
            offset=normalized_offset,
        )

    @mcp.tool(description="Search Teams messages across chats and channels.")
    @_tool_errors
    def search_teams_messages(
        query: str = "",
        top: int = 5,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_offset_cursor("search_teams_messages", cursor)
            normalized_query = _cursor_required_context(page_cursor, "query")
            page = runtime.teams_client(
                include_channel_messages=True
            ).search_teams_messages_page(
                query=normalized_query,
                top=normalized_top,
                from_index=page_cursor.offset,
            )
        else:
            normalized_query = _required_str(query, "query")
            page = runtime.teams_client(
                include_channel_messages=True
            ).search_teams_messages_page(
                query=normalized_query,
                top=normalized_top,
                from_index=normalized_offset,
            )
        return _serialize_collection(
            page.items,
            key="messages",
            serializer=serialize_teams_message_search_hit_summary,
            max_chars=max_chars,
            offset=0,
            next_cursor=encode_offset_cursor(
                "search_teams_messages",
                page.next_from,
                context={"query": normalized_query},
            ),
        )

    @mcp.tool(description="Read a single Teams chat message by id.")
    @_tool_errors
    def read_chat_message(chat_id: str, message_id: str) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=False).get_chat_message(
                chat_id,
                message_id,
            )
        )

    @mcp.tool(description="List Teams joined teams for the current user.")
    @_tool_errors
    def list_teams(cursor: str | None = None) -> dict[str, Any]:
        next_link = decode_page_cursor("list_teams", cursor).next_link if cursor else None
        page = runtime.teams_client(include_channel_messages=False).list_teams_page(
            next_link=next_link
        )
        result: dict[str, Any] = {"teams": [serialize_team(item) for item in page.items]}
        next_cursor = encode_page_cursor("list_teams", page.next_link)
        if next_cursor:
            result["next_cursor"] = next_cursor
        return result

    @mcp.tool(description="List channels in a Teams team.")
    @_tool_errors
    def list_channels(team_id: str = "", cursor: str | None = None) -> dict[str, Any]:
        if cursor:
            page_cursor = decode_page_cursor("list_channels", cursor)
            normalized_team_id = _cursor_required_context(page_cursor, "team_id")
            next_link = page_cursor.next_link
        else:
            normalized_team_id = _required_str(team_id, "team_id")
            next_link = None
        page = runtime.teams_client(include_channel_messages=False).list_channels_page(
            normalized_team_id,
            next_link=next_link,
        )
        result: dict[str, Any] = {"channels": [serialize_channel(item) for item in page.items]}
        next_cursor = encode_page_cursor(
            "list_channels",
            page.next_link,
            context={"team_id": normalized_team_id},
        )
        if next_cursor:
            result["next_cursor"] = next_cursor
        return result

    @mcp.tool(description="List top-level messages in a Teams channel.")
    @_tool_errors
    def list_channel_messages(
        team_id: str = "",
        channel_id: str = "",
        top: int = 25,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_page_cursor("list_channel_messages", cursor)
            normalized_team_id = _cursor_required_context(page_cursor, "team_id")
            normalized_channel_id = _cursor_required_context(page_cursor, "channel_id")
            page = runtime.teams_client(include_channel_messages=True).list_channel_messages_page(
                team_id=normalized_team_id,
                channel_id=normalized_channel_id,
                top=normalized_top,
                next_link=page_cursor.next_link,
            )
        else:
            normalized_team_id = _required_str(team_id, "team_id")
            normalized_channel_id = _required_str(channel_id, "channel_id")
            page = runtime.teams_client(include_channel_messages=True).list_channel_messages_page(
                team_id=normalized_team_id,
                channel_id=normalized_channel_id,
                top=_candidate_limit(normalized_top, normalized_offset),
            )
        return _serialize_collection(
            page.items,
            key="messages",
            serializer=serialize_teams_message_summary,
            max_chars=max_chars,
            offset=normalized_offset,
            next_cursor=encode_page_cursor(
                "list_channel_messages",
                page.next_link,
                context={
                    "team_id": normalized_team_id,
                    "channel_id": normalized_channel_id,
                },
            ),
        )

    @mcp.tool(description="Search top-level messages in a Teams channel.")
    @_tool_errors
    def search_channel_messages(
        team_id: str,
        channel_id: str,
        query: str,
        top: int = 10,
        max_chars: int = 20_000,
        offset: int = 0,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        messages = runtime.teams_client(include_channel_messages=True).search_channel_messages(
            team_id=team_id,
            channel_id=channel_id,
            query=query,
            top=_candidate_limit(normalized_top, normalized_offset),
        )
        return _serialize_collection(
            messages,
            key="messages",
            serializer=serialize_teams_message_summary,
            max_chars=max_chars,
            offset=normalized_offset,
        )

    @mcp.tool(description="List replies to a Teams channel message.")
    @_tool_errors
    def list_channel_replies(
        team_id: str = "",
        channel_id: str = "",
        message_id: str = "",
        top: int = 25,
        max_chars: int = 20_000,
        offset: int = 0,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        normalized_top = _positive_int(top, "top")
        normalized_offset = _non_negative_int(offset, "offset")
        if cursor:
            page_cursor = decode_page_cursor("list_channel_replies", cursor)
            normalized_team_id = _cursor_required_context(page_cursor, "team_id")
            normalized_channel_id = _cursor_required_context(page_cursor, "channel_id")
            normalized_message_id = _cursor_required_context(page_cursor, "message_id")
            reply_page = runtime.teams_client(
                include_channel_messages=True
            ).list_channel_replies_page(
                team_id=normalized_team_id,
                channel_id=normalized_channel_id,
                message_id=normalized_message_id,
                top=normalized_top,
                next_link=page_cursor.next_link,
            )
        else:
            normalized_team_id = _required_str(team_id, "team_id")
            normalized_channel_id = _required_str(channel_id, "channel_id")
            normalized_message_id = _required_str(message_id, "message_id")
            reply_page = runtime.teams_client(
                include_channel_messages=True
            ).list_channel_replies_page(
                team_id=normalized_team_id,
                channel_id=normalized_channel_id,
                message_id=normalized_message_id,
                top=_candidate_limit(normalized_top, normalized_offset),
            )
        return _serialize_collection(
            reply_page.replies,
            key="replies",
            serializer=serialize_teams_message_summary,
            max_chars=max_chars,
            offset=normalized_offset,
            extra={"has_more_replies": reply_page.has_more_replies},
            next_cursor=encode_page_cursor(
                "list_channel_replies",
                reply_page.next_link,
                context={
                    "team_id": normalized_team_id,
                    "channel_id": normalized_channel_id,
                    "message_id": normalized_message_id,
                },
            ),
        )

    @mcp.tool(description="Read a single Teams channel message by id.")
    @_tool_errors
    def read_channel_message(team_id: str, channel_id: str, message_id: str) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=True).get_channel_message(
                team_id,
                channel_id,
                message_id,
            )
        )

    @mcp.tool(description="Read a Teams channel thread, including replies.")
    @_tool_errors
    def read_channel_thread(
        team_id: str,
        channel_id: str,
        message_id: str,
        top: int = 25,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        thread = runtime.teams_client(include_channel_messages=True).read_channel_thread(
            team_id,
            channel_id,
            message_id,
            replies_top=_positive_int(top, "top"),
        )
        return serialize_teams_thread(thread)


def _build_tool_errors(runtime: ReadRuntime) -> Callable[[Callable[P, R]], Callable[P, R]]:
    version_warning: str | None | bool = False

    def cached_version_warning() -> str | None:
        nonlocal version_warning
        if version_warning is False:
            profile = getattr(runtime, "profile", None)
            version_warning = (
                stale_warning_from_cache(profile) if isinstance(profile, str) else None
            )
        return version_warning if isinstance(version_warning, str) else None

    def tool_errors(func: Callable[P, R]) -> Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            start = usage_start()
            recorder_token = start_usage_recording()
            try:
                result = func(*args, **kwargs)
            except ValueError as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=type(exc).__name__,
                    error_code=None,
                    graph_metrics=graph_metrics,
                )
                raise
            except AuthenticationError as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=usage_error_type(exc),
                    error_code=usage_error_code(exc),
                    graph_metrics=graph_metrics,
                )
                raise RuntimeError(f"Authentication failed: {exc}") from exc
            except RateLimitedError as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=usage_error_type(exc),
                    error_code=usage_error_code(exc),
                    graph_metrics=graph_metrics,
                )
                raise RuntimeError(str(exc)) from exc
            except SafetyDeniedError as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=usage_error_type(exc),
                    error_code=usage_error_code(exc),
                    graph_metrics=graph_metrics,
                )
                raise RuntimeError(str(exc)) from exc
            except GraphAPIError as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=usage_error_type(exc),
                    error_code=usage_error_code(exc),
                    graph_metrics=graph_metrics,
                )
                raise RuntimeError(
                    f"Microsoft Graph error {exc.status_code} ({exc.error_code}): {exc.message}"
                ) from exc
            except Exception as exc:
                graph_metrics = stop_usage_recording(recorder_token)
                _log_mcp_usage(
                    runtime,
                    func.__name__,
                    start=start,
                    success=False,
                    error_type=type(exc).__name__,
                    error_code=None,
                    graph_metrics=graph_metrics,
                )
                raise RuntimeError("Internal MCP server error") from exc
            result = _with_version_warning(result, cached_version_warning())
            graph_metrics = stop_usage_recording(recorder_token)
            _log_mcp_usage(
                runtime,
                func.__name__,
                start=start,
                success=True,
                result=result,
                graph_metrics=graph_metrics,
            )
            return result

        return wrapper

    return tool_errors


def _with_version_warning(result: R, warning: str | None) -> R:
    if warning is None or not isinstance(result, dict) or "version_warning" in result:
        return result
    updated = dict(result)
    updated["version_warning"] = warning
    return cast("R", updated)


def _normalize_mailbox_filter(value: str) -> str | None:
    normalized = value.strip().lower()
    if normalized not in {"all", "focused"}:
        raise ValueError("filter must be 'all' or 'focused'")
    return None if normalized == "all" else normalized


def _mailbox_filter_from_cursor(cursor: PageCursor) -> str | None:
    value = cursor.context.get("mailbox_filter")
    if value is None or value == "focused":
        return value
    raise ValueError("cursor mailbox filter is invalid")


def _cursor_required_context(cursor: PageCursor | OffsetCursor, key: str) -> str:
    value = cursor.context.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"cursor is missing {key}")
    return value.strip()


def _required_str(value: str, field_name: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} must be a non-empty string")
    return normalized


def _parse_window(start: str, end: str) -> tuple[datetime, datetime]:
    start_dt = _parse_datetime(start, "start")
    end_dt = _parse_datetime(end, "end")
    if end_dt <= start_dt:
        raise ValueError("end must be later than start")
    return start_dt, end_dt


def _parse_datetime(value: str, field_name: str) -> datetime:
    raw = value.strip()
    if not raw:
        raise ValueError(f"{field_name} must be a non-empty ISO 8601 datetime")
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field_name} must be a valid ISO 8601 datetime") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone offset")
    return parsed.astimezone(UTC)


def _positive_int(value: int, field_name: str) -> int:
    if value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _non_negative_int(value: int, field_name: str) -> int:
    if value < 0:
        raise ValueError(f"{field_name} must be zero or greater")
    return value


def _log_mcp_usage(
    runtime: ReadRuntime,
    name: str,
    *,
    start: float,
    success: bool,
    result: Any = None,
    error_type: str | None = None,
    error_code: str | None = None,
    graph_metrics: GraphUsageMetrics | None = None,
) -> None:
    profile = getattr(runtime, "profile", None)
    if not isinstance(profile, str):
        return
    try:
        UsageLogger.for_profile(profile).log(
            build_usage_event(
                profile=profile,
                surface="mcp",
                name=name,
                start=start,
                success=success,
                error_type=error_type,
                error_code=error_code,
                write_intent=name
                in {"create_email_draft", "create_reply_draft", "send_email_draft"},
                result=result,
                graph_metrics=graph_metrics,
            )
        )
    except OSError:
        return


def _serialize_email_summary_page(
    messages: list[Any],
    *,
    max_chars: int,
    offset: int = 0,
    absolute_offset: int | None = None,
    next_cursor: str | None = None,
) -> dict[str, Any]:
    return _serialize_collection(
        messages,
        key="messages",
        serializer=serialize_email_summary,
        max_chars=max_chars,
        offset=offset,
        absolute_offset=absolute_offset,
        next_cursor=next_cursor,
    )


def _serialize_collection(
    items: list[Any] | tuple[Any, ...],
    *,
    key: str,
    serializer: Callable[[Any], dict[str, Any]],
    max_chars: int,
    offset: int = 0,
    absolute_offset: int | None = None,
    extra: dict[str, Any] | None = None,
    next_cursor: str | None = None,
) -> dict[str, Any]:
    normalized_max_chars = _positive_int(max_chars, "max_chars")
    normalized_offset = _non_negative_int(offset, "offset")
    next_offset_base = normalized_offset if absolute_offset is None else absolute_offset
    serialized_items: list[dict[str, Any]] = []
    result: dict[str, Any] = {key: serialized_items, "truncated": False}
    if extra:
        result.update(extra)
    for item in items[normalized_offset:]:
        payload = serializer(item)
        candidate = dict(result)
        candidate[key] = [*serialized_items, payload]
        if _json_size(candidate) > normalized_max_chars:
            result["truncated"] = True
            if serialized_items:
                result["next_offset"] = next_offset_base + len(serialized_items)
            else:
                result["next_offset"] = None
                result["warnings"] = [
                    "max_chars is too small to include one item; increase max_chars."
                ]
            break
        serialized_items.append(payload)
    if not result["truncated"] and next_cursor:
        result["next_cursor"] = next_cursor
    return result


def _json_size(payload: Any) -> int:
    return len(json.dumps(payload, separators=(",", ":"), ensure_ascii=False))


def _candidate_limit(top: int, offset: int) -> int:
    return top + offset


def _optional_str(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None


def _normalize_importance(value: str) -> str:
    normalized = value.strip().lower()
    if normalized not in {"low", "normal", "high"}:
        raise ValueError("importance must be one of: low, normal, high")
    return normalized


def _non_empty_emails(values: list[str], field_name: str) -> tuple[str, ...]:
    emails = _optional_emails(values)
    if not emails:
        raise ValueError(f"{field_name} must contain at least one email address")
    return emails


def _optional_emails(values: list[str] | None) -> tuple[str, ...]:
    if not values:
        return ()
    normalized = tuple(value.strip() for value in values if value.strip())
    if len(normalized) != len(values):
        raise ValueError("email lists must not contain empty values")
    return normalized


def _share_download_path(
    *,
    dest_path: str | None,
    profile: str,
    name: str,
    share_id: str,
) -> Path:
    if dest_path is None or not dest_path.strip():
        output_dir = get_profile_dir(profile) / "downloads" / "share-links"
        output_dir.mkdir(parents=True, exist_ok=True)
        return _unique_file_path(output_dir / _safe_download_name(name, share_id))
    target = Path(dest_path).expanduser()
    if target.exists() and target.is_dir():
        return _unique_file_path(target / _safe_download_name(name, share_id))
    if target.suffix:
        target.parent.mkdir(parents=True, exist_ok=True)
        return _unique_file_path(target)
    target.mkdir(parents=True, exist_ok=True)
    return _unique_file_path(target / _safe_download_name(name, share_id))


def _safe_download_name(name: str, fallback_id: str) -> str:
    filename = Path(name).name
    if filename in {"", ".", ".."}:
        return f"share-link-{fallback_id}"
    return filename


def _unique_file_path(candidate: Path) -> Path:
    if not candidate.exists():
        return candidate
    stem = candidate.stem
    suffix = candidate.suffix
    index = 1
    while True:
        deduped = candidate.with_name(f"{stem}-{index}{suffix}")
        if not deduped.exists():
            return deduped
        index += 1


def _teams_message_locator(
    *,
    chat_id: str | None,
    team_id: str | None,
    channel_id: str | None,
) -> dict[str, str]:
    normalized_chat_id = _optional_str(chat_id)
    normalized_team_id = _optional_str(team_id)
    normalized_channel_id = _optional_str(channel_id)
    if normalized_chat_id is not None:
        if normalized_team_id is not None or normalized_channel_id is not None:
            raise ValueError("provide chat_id or both team_id and channel_id, not both")
        return {"chat_id": normalized_chat_id}
    if normalized_team_id is None or normalized_channel_id is None:
        raise ValueError("provide chat_id or both team_id and channel_id")
    return {
        "team_id": normalized_team_id,
        "channel_id": normalized_channel_id,
    }
