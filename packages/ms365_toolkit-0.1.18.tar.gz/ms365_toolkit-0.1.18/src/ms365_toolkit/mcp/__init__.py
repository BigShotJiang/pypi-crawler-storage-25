from __future__ import annotations

from typing import TYPE_CHECKING

from ms365_toolkit.mcp.server import create_server

if TYPE_CHECKING:
    from collections.abc import Sequence

__all__ = ["create_server", "main"]


def main(argv: Sequence[str] | None = None) -> int:
    from ms365_toolkit.mcp.__main__ import main as _main

    return _main(argv)
