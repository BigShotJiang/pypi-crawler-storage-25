from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from typing import Any

_CURSOR_VERSION = 1


@dataclass(frozen=True)
class PageCursor:
    tool: str
    next_link: str
    context: dict[str, Any]


@dataclass(frozen=True)
class OffsetCursor:
    tool: str
    offset: int
    context: dict[str, Any]


def encode_page_cursor(
    tool: str,
    next_link: str | None,
    *,
    context: dict[str, Any] | None = None,
) -> str | None:
    if not next_link:
        return None
    payload = {
        "v": _CURSOR_VERSION,
        "tool": tool,
        "next_link": next_link,
        "context": context or {},
    }
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def encode_offset_cursor(
    tool: str,
    offset: int | None,
    *,
    context: dict[str, Any] | None = None,
) -> str | None:
    if offset is None:
        return None
    if offset < 0:
        raise ValueError("offset must be zero or greater")
    payload = {
        "v": _CURSOR_VERSION,
        "tool": tool,
        "offset": offset,
        "context": context or {},
    }
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def decode_page_cursor(tool: str, cursor: str) -> PageCursor:
    payload = _decode_payload(tool, cursor)
    next_link = payload.get("next_link")
    if not isinstance(next_link, str) or not next_link:
        raise ValueError("cursor is missing a continuation link")
    context = payload.get("context")
    if not isinstance(context, dict):
        raise ValueError("cursor context is invalid")
    return PageCursor(tool=tool, next_link=next_link, context=context)


def decode_offset_cursor(tool: str, cursor: str) -> OffsetCursor:
    payload = _decode_payload(tool, cursor)
    offset = payload.get("offset")
    if not isinstance(offset, int) or offset < 0:
        raise ValueError("cursor is missing a continuation offset")
    context = payload.get("context")
    if not isinstance(context, dict):
        raise ValueError("cursor context is invalid")
    return OffsetCursor(tool=tool, offset=offset, context=context)


def _decode_payload(tool: str, cursor: str) -> dict[str, Any]:
    try:
        raw = base64.urlsafe_b64decode(_padded(cursor.strip()))
        payload = json.loads(raw.decode("utf-8"))
    except (binascii.Error, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("cursor is invalid") from exc
    if not isinstance(payload, dict):
        raise ValueError("cursor is invalid")
    if payload.get("v") != _CURSOR_VERSION:
        raise ValueError("cursor version is not supported")
    if payload.get("tool") != tool:
        raise ValueError("cursor does not match this tool")
    return payload


def _padded(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return f"{value}{padding}".encode("ascii")
