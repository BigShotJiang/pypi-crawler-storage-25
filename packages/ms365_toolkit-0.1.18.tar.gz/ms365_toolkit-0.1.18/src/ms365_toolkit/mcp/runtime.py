from __future__ import annotations

from dataclasses import dataclass

from ms365_toolkit.auth.credentials import CredentialStore
from ms365_toolkit.auth.tokens import TokenManager
from ms365_toolkit.cli.auth import build_public_client_application
from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.client.teams import TeamsClient
from ms365_toolkit.config.loader import ToolkitConfig, get_profile_dir, load_config
from ms365_toolkit.models.enums import (
    CHANNEL_MESSAGE_READ_SCOPES,
    MEETING_AI_INSIGHT_READ_SCOPES,
    MEETING_TRANSCRIPT_READ_SCOPES,
    SHARE_LINK_READ_SCOPES,
    TEAMS_FILE_READ_SCOPES,
)
from ms365_toolkit.safety.audit import AuditLogger
from ms365_toolkit.safety.dialog import show_confirmation_dialog
from ms365_toolkit.safety.gate import ConfiguredSafetyGate, DialogPreview, SafetyResult
from ms365_toolkit.safety.rate_limiter import RateLimiter


@dataclass(frozen=True)
class ReadRuntime:
    profile: str
    config: ToolkitConfig

    @classmethod
    def load(cls, profile: str = "default") -> ReadRuntime:
        return cls(profile=profile, config=load_config(profile=profile))

    def graph_client(
        self,
        *,
        write: bool = False,
        extra_scopes: frozenset[str] | None = None,
    ) -> GraphClient:
        store = CredentialStore(profile=self.profile)
        manager = TokenManager(
            config=self.config,
            credential_store=store,
            app_factory=lambda cache: build_public_client_application(self.config, cache),
        )
        bundle = manager.get_access_token(write=write, extra_scopes=extra_scopes)
        return GraphClient(config=self.config, token=bundle.access_token)

    def email_client(
        self,
        *,
        write: bool = False,
        include_share_links: bool = False,
    ) -> EmailClient:
        return EmailClient(
            self.graph_client(
                write=write,
                extra_scopes=SHARE_LINK_READ_SCOPES if include_share_links else None,
            ),
            safety_gate=self.safety_gate() if write else None,
        )

    def calendar_client(
        self,
        *,
        include_meeting_transcripts: bool = False,
        include_meeting_notes: bool = False,
    ) -> CalendarClient:
        online_meeting_graph = None
        if include_meeting_transcripts:
            online_meeting_graph = self.graph_client(extra_scopes=MEETING_TRANSCRIPT_READ_SCOPES)
        elif include_meeting_notes:
            online_meeting_graph = self.graph_client(extra_scopes=MEETING_AI_INSIGHT_READ_SCOPES)
        ai_insights_graph = (
            self.graph_client(extra_scopes=MEETING_AI_INSIGHT_READ_SCOPES)
            if include_meeting_notes
            else None
        )
        return CalendarClient(
            self.graph_client(),
            online_meeting_graph=online_meeting_graph,
            transcript_graph=online_meeting_graph,
            ai_insights_graph=ai_insights_graph,
        )

    def teams_client(
        self,
        *,
        include_channel_messages: bool = False,
        include_files: bool = False,
    ) -> TeamsClient:
        graph = self.graph_client()
        channel_graph = (
            self.graph_client(extra_scopes=CHANNEL_MESSAGE_READ_SCOPES)
            if include_channel_messages
            else graph
        )
        files_graph = (
            self.graph_client(extra_scopes=TEAMS_FILE_READ_SCOPES) if include_files else graph
        )
        return TeamsClient(graph, channel_graph=channel_graph, files_graph=files_graph)

    def safety_gate(self) -> ConfiguredSafetyGate:
        safety_dir = get_profile_dir(self.profile) / "safety"
        return ConfiguredSafetyGate(
            config=self.config,
            rate_limiter=RateLimiter(
                profile=self.profile,
                rate_limits=self.config.safety.rate_limits,
                path=safety_dir / "rate_limits.sqlite3",
            ),
            audit_logger=AuditLogger(path=safety_dir / "audit.jsonl"),
            dialog=_confirmation_dialog,
        )


def _confirmation_dialog(preview: DialogPreview) -> SafetyResult:
    result = show_confirmation_dialog(preview)
    if result.reason == "dialog_preflight_failed":
        return SafetyResult(True, "dialog_skipped")
    return result
