from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import pytest
from fastmcp.exceptions import ToolError

from ms365_toolkit.client.exceptions import AuthenticationError
from ms365_toolkit.client.paging import GraphPage
from ms365_toolkit.mcp import create_server
from ms365_toolkit.mcp.__main__ import main
from ms365_toolkit.models.calendar import (
    Attendee,
    CalendarEvent,
    ExtractedMeetingTranscript,
    MeetingActionItem,
    MeetingAiInsight,
    MeetingMentionEvent,
    MeetingNotePoint,
    MeetingTranscript,
)
from ms365_toolkit.models.email import (
    DownloadedShareLink,
    EmailAttachment,
    EmailDraft,
    EmailMessage,
    EmailShareLink,
    ExtractedAttachment,
    ShareLinkDriveItem,
)
from ms365_toolkit.models.teams import (
    ChannelSummary,
    ExtractedTeamsFile,
    TeamsChat,
    TeamsMessage,
    TeamsMessageAttachment,
    TeamsMessageSearchHit,
    TeamsMessageSearchPage,
    TeamsParticipant,
    TeamsReplyPage,
    TeamsSender,
    TeamsThread,
    TeamSummary,
)
from ms365_toolkit.version_status import PackageVersionStatus, ToolkitVersionStatus

_MAX_CHARS_TOO_SMALL_WARNING = "max_chars is too small to include one item; increase max_chars."


@pytest.mark.asyncio
async def test_create_server_registers_expected_tool_names() -> None:
    server = create_server(runtime=_FakeRuntime())

    tools = await server.list_tools()

    assert [tool.name for tool in tools] == [
        "get_toolkit_status",
        "list_inbox",
        "search_emails",
        "read_email",
        "read_conversation_thread",
        "list_email_attachments",
        "read_email_attachment",
        "list_email_share_links",
        "download_share_link",
        "download_email_share_links",
        "create_email_draft",
        "create_reply_draft",
        "send_email_draft",
        "list_teams_message_files",
        "read_teams_message_file",
        "list_folders",
        "list_events",
        "get_event",
        "list_meeting_transcripts",
        "read_meeting_transcript",
        "read_meeting_notes",
        "search_events",
        "list_calendars",
        "find_free_slots",
        "list_chats",
        "search_chats",
        "list_chat_messages",
        "search_chat_messages",
        "search_teams_messages",
        "read_chat_message",
        "list_teams",
        "list_channels",
        "list_channel_messages",
        "search_channel_messages",
        "list_channel_replies",
        "read_channel_message",
        "read_channel_thread",
    ]


@pytest.mark.asyncio
async def test_get_toolkit_status_returns_structured_content(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    status = ToolkitVersionStatus(
        version="0.1.10",
        is_stale=False,
        source="installed",
        checked_at=None,
        cache_path="/tmp/latest_version.json",
        packages=(
            PackageVersionStatus(
                package="ms365-toolkit",
                current_version="0.1.10",
                latest_version=None,
                is_stale=None,
            ),
        ),
        update_commands={},
    )
    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.build_toolkit_status",
        lambda profile, include_latest=True: status,
    )

    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("get_toolkit_status", {"include_latest": False})

    assert result.structured_content == {
        "version": "0.1.10",
        "is_stale": False,
        "source": "installed",
        "checked_at": None,
        "cache_path": "/tmp/latest_version.json",
        "packages": [
            {
                "package": "ms365-toolkit",
                "current_version": "0.1.10",
                "latest_version": None,
                "is_stale": None,
            }
        ],
        "update_commands": {},
    }


@pytest.mark.asyncio
async def test_list_inbox_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert result.structured_content == {
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "body_preview": "Preview",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "importance": "high",
                "has_attachments": False,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_emails_returns_truncated_message_summaries() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("search_emails", {"query": "hello", "top": 10})

    assert result.structured_content == {
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "body_preview": "Preview",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "importance": "high",
                "has_attachments": False,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_mcp_tool_logs_usage_event(monkeypatch: pytest.MonkeyPatch) -> None:
    events: list[Any] = []

    class FakeLogger:
        def log(self, event: Any) -> None:
            events.append(event)

    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.UsageLogger.for_profile",
        lambda profile: FakeLogger(),
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    server = create_server(runtime=RuntimeWithProfile())

    await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert len(events) == 1
    assert events[0].profile == "default"
    assert events[0].surface == "mcp"
    assert events[0].name == "list_inbox"
    assert events[0].success is True
    assert events[0].result_item_count == 1
    assert events[0].write_intent is False


@pytest.mark.asyncio
async def test_mcp_usage_logging_failure_is_non_fatal(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FailingLogger:
        def log(self, event: Any) -> None:
            raise PermissionError("readonly")

    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.UsageLogger.for_profile",
        lambda profile: FailingLogger(),
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    server = create_server(runtime=RuntimeWithProfile())

    result = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert result.structured_content["messages"][0]["subject"] == "Hello"


@pytest.mark.asyncio
async def test_list_inbox_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_inbox",
        {"mailbox_filter": "all", "top": 5, "max_chars": 120},
    )

    assert result.structured_content == {
        "messages": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_list_inbox_offset_overrides_skip() -> None:
    email_client = _FakeEmailClient()
    server = create_server(runtime=_FakeRuntime(email=email_client))

    await server.call_tool(
        "list_inbox",
        {"mailbox_filter": "all", "top": 5, "skip": 9, "offset": 2},
    )

    assert email_client.list_inbox_calls[-1]["skip"] == 2


@pytest.mark.asyncio
async def test_list_inbox_returns_and_uses_next_cursor() -> None:
    next_link = "https://graph.microsoft.com/v1.0/me/messages?$skiptoken=abc"
    email_client = _FakeEmailClient(next_link=next_link)
    server = create_server(runtime=_FakeRuntime(email=email_client))

    first = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})
    cursor = first.structured_content["next_cursor"]

    await server.call_tool("list_inbox", {"cursor": cursor})

    assert email_client.list_inbox_calls[-1]["next_link"] == next_link
    assert email_client.list_inbox_calls[-1]["skip"] == 0


@pytest.mark.asyncio
async def test_list_inbox_suppresses_next_cursor_when_budget_truncates() -> None:
    email_client = _FakeEmailClient(
        next_link="https://graph.microsoft.com/v1.0/me/messages?$skiptoken=abc"
    )
    server = create_server(runtime=_FakeRuntime(email=email_client))

    result = await server.call_tool(
        "list_inbox",
        {"mailbox_filter": "all", "top": 5, "max_chars": 120},
    )

    assert result.structured_content["truncated"] is True
    assert "next_cursor" not in result.structured_content


@pytest.mark.asyncio
async def test_search_emails_fetches_offset_candidate_pool() -> None:
    email_client = _FakeEmailClient()
    server = create_server(runtime=_FakeRuntime(email=email_client))

    await server.call_tool("search_emails", {"query": "hello", "top": 5, "offset": 2})

    assert email_client.search_calls[-1]["top"] == 7


@pytest.mark.asyncio
async def test_search_emails_cursor_preserves_mailbox_filter() -> None:
    next_link = "https://graph.microsoft.com/v1.0/me/messages?$skiptoken=search"
    email_client = _FakeEmailClient(next_link=next_link)
    server = create_server(runtime=_FakeRuntime(email=email_client))

    first = await server.call_tool(
        "search_emails",
        {"query": "hello", "mailbox_filter": "focused"},
    )

    await server.call_tool("search_emails", {"cursor": first.structured_content["next_cursor"]})

    assert email_client.search_calls[-1]["query"] == ""
    assert email_client.search_calls[-1]["mailbox_filter"] == "focused"
    assert email_client.search_calls[-1]["next_link"] == next_link


@pytest.mark.asyncio
async def test_cursor_rejects_wrong_tool() -> None:
    email_client = _FakeEmailClient(
        next_link="https://graph.microsoft.com/v1.0/me/messages?$skiptoken=abc"
    )
    server = create_server(runtime=_FakeRuntime(email=email_client))
    first = await server.call_tool("list_inbox", {"mailbox_filter": "all"})

    with pytest.raises(ToolError, match="cursor does not match this tool"):
        await server.call_tool("search_emails", {"cursor": first.structured_content["next_cursor"]})


@pytest.mark.asyncio
async def test_list_chat_messages_returns_next_offset_when_budget_truncates() -> None:
    first = _teams_message()
    second = _teams_message(message_id="teams-msg-2", body_content="Second Teams message")
    first_payload = _teams_message_summary_payload()
    max_chars = (
        len(
            json.dumps(
                {"messages": [first_payload], "truncated": False},
                separators=(",", ":"),
                ensure_ascii=False,
            )
        )
        + 10
    )
    server = create_server(runtime=_FakeRuntime(teams=_FakeTeamsClient(messages=[first, second])))

    result = await server.call_tool(
        "list_chat_messages",
        {"chat_id": "chat-1", "top": 2, "max_chars": max_chars},
    )

    assert result.structured_content == {
        "messages": [first_payload],
        "truncated": True,
        "next_offset": 1,
    }


@pytest.mark.asyncio
async def test_list_chat_messages_offset_returns_next_item_without_duplication() -> None:
    teams_client = _FakeTeamsClient(
        messages=[
            _teams_message(),
            _teams_message(message_id="teams-msg-2", body_content="Second Teams message"),
        ]
    )
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    result = await server.call_tool(
        "list_chat_messages",
        {"chat_id": "chat-1", "top": 2, "offset": 1},
    )

    assert result.structured_content == {
        "messages": [
            _teams_message_summary_payload(
                message_id="teams-msg-2",
                body_preview="Second Teams message",
                summary="Second Teams message",
            )
        ],
        "truncated": False,
    }
    assert teams_client.list_chat_messages_calls[-1]["top"] == 3


@pytest.mark.asyncio
async def test_list_chat_messages_cursor_allows_cursor_only_continuation() -> None:
    next_link = "https://graph.microsoft.com/v1.0/me/chats/chat-1/messages?$skiptoken=abc"
    teams_client = _FakeTeamsClient(next_link=next_link)
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    first = await server.call_tool("list_chat_messages", {"chat_id": "chat-1", "top": 5})

    await server.call_tool(
        "list_chat_messages",
        {"cursor": first.structured_content["next_cursor"]},
    )

    assert teams_client.list_chat_messages_calls[-1]["chat_id"] == "chat-1"
    assert teams_client.list_chat_messages_calls[-1]["next_link"] == next_link


@pytest.mark.asyncio
async def test_list_chat_messages_rejects_negative_offset() -> None:
    server = create_server(runtime=_FakeRuntime())

    with pytest.raises(ToolError, match="offset must be zero or greater"):
        await server.call_tool("list_chat_messages", {"chat_id": "chat-1", "offset": -1})


@pytest.mark.asyncio
async def test_read_conversation_thread_returns_full_messages() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_conversation_thread",
        {"conversation_id": "conversation-1", "top": 25},
    )

    assert result.structured_content == {
        "conversation_id": "conversation-1",
        "messages": [
            {
                "id": "msg-1",
                "subject": "Hello",
                "sender": "sender@example.com",
                "to": ["to@example.com"],
                "cc": [],
                "bcc": [],
                "body_preview": "Preview",
                "body_content": "<untrusted-email-content>Hello</untrusted-email-content>",
                "received_at": "2026-04-03T12:00:00Z",
                "is_read": False,
                "is_flagged": True,
                "importance": "high",
                "has_attachments": False,
                "attachments": [],
                "conversation_id": "conversation-1",
                "folder_id": "folder-1",
                "share_links": [],
            }
        ],
    }


@pytest.mark.asyncio
async def test_list_email_attachments_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_email_attachments",
        {"message_id": "msg-1", "include_inline": False},
    )

    assert result.structured_content == {
        "attachments": [
            {
                "id": "att-1",
                "name": "brief.docx",
                "content_type": (
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                ),
                "size": 128,
                "is_inline": False,
                "is_reference": False,
                "odata_type": "#microsoft.graph.fileAttachment",
            }
        ]
    }


@pytest.mark.asyncio
async def test_read_email_attachment_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_email_attachment",
        {"message_id": "msg-1", "attachment_id": "att-1", "max_chars": 50000},
    )

    assert result.structured_content == {
        "attachment": {
            "id": "att-1",
            "name": "brief.docx",
            "content_type": (
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            "size": 128,
            "is_inline": False,
            "is_reference": False,
            "odata_type": "#microsoft.graph.fileAttachment",
        },
        "format": "docx",
        "text_content": "Quarterly review",
        "is_truncated": False,
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_list_email_share_links_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_email_share_links", {"message_id": "msg-1"})

    assert result.structured_content == {
        "share_links": [
            {
                "url": "https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx",
                "filename": "Planning Brief.docx",
                "host": "contoso.sharepoint.com",
                "source_text": "Planning Brief.docx",
            }
        ]
    }


@pytest.mark.asyncio
async def test_download_share_link_writes_file_and_extracted_text(
    tmp_path,
) -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "download_share_link",
        {
            "url": "https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx",
            "dest_path": str(tmp_path),
            "max_chars": 50000,
        },
    )

    assert (tmp_path / "Planning Brief.docx").read_bytes() == b"docx-bytes"
    assert (tmp_path / "Planning Brief.docx.txt").read_text(encoding="utf-8") == (
        "Quarterly review"
    )
    assert result.structured_content == {
        "url": "https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx",
        "path": str(tmp_path / "Planning Brief.docx"),
        "text_path": str(tmp_path / "Planning Brief.docx.txt"),
        "drive_item": {
            "share_id": "share-1",
            "drive_id": "drive-1",
            "item_id": "item-1",
            "name": "Planning Brief.docx",
            "content_type": (
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            "size": 9,
            "web_url": "https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx",
        },
        "extracted": {
            "attachment": {
                "id": "item-1",
                "name": "Planning Brief.docx",
                "content_type": (
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                ),
                "size": 9,
                "is_inline": False,
                "is_reference": True,
                "odata_type": "#microsoft.graph.driveItem",
            },
            "format": "docx",
            "text_content": "Quarterly review",
            "is_truncated": False,
            "warnings": [],
        },
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_download_email_share_links_dedupes_resolved_items(tmp_path) -> None:
    email_client = _FakeDuplicateShareLinkEmailClient()
    server = create_server(runtime=_FakeRuntime(email=email_client))

    result = await server.call_tool(
        "download_email_share_links",
        {
            "message_id": "msg-1",
            "output_dir": str(tmp_path),
            "max_chars": 20000,
        },
    )

    assert email_client.share_download_count == 1
    assert (tmp_path / "Planning Brief.docx").read_bytes() == b"docx-bytes"
    assert (tmp_path / "Planning Brief.docx.txt").read_text(encoding="utf-8") == (
        "Quarterly review"
    )
    assert result.structured_content["message_id"] == "msg-1"
    assert result.structured_content["skipped_duplicates"] == 1
    assert len(result.structured_content["downloads"]) == 1


@pytest.mark.asyncio
async def test_create_email_draft_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "create_email_draft",
        {
            "to": ["to@example.com"],
            "subject": "Hello",
            "body": "<p>Hello</p>",
            "importance": "high",
        },
    )

    assert result.structured_content == {
        "draft_id": "draft-1",
        "content_hash": "hash-1",
        "to": ["to@example.com"],
        "cc": [],
        "bcc": [],
        "subject": "Hello",
        "body": "<p>Hello</p>",
        "attachments": [],
        "reply_to": [],
        "importance": "high",
        "created_at": "2026-04-03T12:00:00Z",
    }


@pytest.mark.asyncio
async def test_create_reply_draft_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "create_reply_draft",
        {"message_id": " msg-1 ", "body": "<p>Reply</p>"},
    )

    assert result.structured_content == {
        "draft_id": "draft-1",
        "content_hash": "hash-1",
        "to": ["to@example.com"],
        "cc": [],
        "bcc": [],
        "subject": "Hello",
        "body": "<p>Hello</p>",
        "attachments": [],
        "reply_to": [],
        "importance": "high",
        "created_at": "2026-04-03T12:00:00Z",
    }


@pytest.mark.asyncio
async def test_send_email_draft_returns_confirmation() -> None:
    runtime = _FakeRuntime()
    server = create_server(runtime=runtime)

    result = await server.call_tool(
        "send_email_draft",
        {"draft_id": " draft-1 ", "content_hash": " hash-1 "},
    )

    assert result.structured_content == {"status": "sent", "draft_id": "draft-1"}
    assert runtime.sent_drafts == [("draft-1", "hash-1")]


@pytest.mark.asyncio
async def test_list_teams_message_files_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_teams_message_files",
        {"message_id": "msg-1", "chat_id": "chat-1"},
    )

    assert result.structured_content == {
        "attachments": [
            {
                "id": "teams-att-1",
                "name": "brief.docx",
                "content_type": "reference",
                "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
                "thumbnail_url": "",
                "teams_app_id": "",
            }
        ]
    }


@pytest.mark.asyncio
async def test_read_teams_message_file_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_teams_message_file",
        {
            "message_id": "msg-1",
            "attachment_id": "teams-att-1",
            "chat_id": "chat-1",
            "max_chars": 50000,
        },
    )

    assert result.structured_content == {
        "attachment": {
            "id": "teams-att-1",
            "name": "brief.docx",
            "content_type": "reference",
            "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
            "thumbnail_url": "",
            "teams_app_id": "",
        },
        "format": "docx",
        "text_content": "Quarterly review",
        "is_truncated": False,
        "warnings": [],
    }


@pytest.mark.asyncio
async def test_list_events_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_events",
        {"start": "2026-04-03T09:00:00Z", "end": "2026-04-03T10:00:00Z"},
    )

    assert result.structured_content == {
        "events": [
            {
                "id": "event-1",
                "subject": "Planning",
                "start": "2026-04-03T09:00:00Z",
                "end": "2026-04-03T09:30:00Z",
                "timezone": "UTC",
                "location": "Room A",
                "is_online_meeting": False,
                "is_cancelled": False,
                "importance": "normal",
                "categories": ["Work"],
                "organizer": "owner@example.com",
                "response_status": "accepted",
                "calendar_id": "calendar-1",
                "join_url": "https://teams.microsoft.com/l/meetup-join/meeting-1",
                "ical_uid": "ical-1",
                "attendee_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_events_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_events",
        {
            "start": "2026-04-03T09:00:00Z",
            "end": "2026-04-03T10:00:00Z",
            "max_chars": 80,
        },
    )

    assert result.structured_content == {
        "events": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_list_events_cursor_allows_cursor_only_continuation() -> None:
    next_link = "https://graph.microsoft.com/v1.0/me/calendarView?$skiptoken=abc"
    calendar_client = _FakeCalendarClient(next_link=next_link)
    server = create_server(runtime=_FakeRuntime(calendar=calendar_client))

    first = await server.call_tool(
        "list_events",
        {"start": "2026-04-03T09:00:00Z", "end": "2026-04-03T10:00:00Z"},
    )

    await server.call_tool("list_events", {"cursor": first.structured_content["next_cursor"]})

    assert calendar_client.list_events_calls[-1]["start"] is None
    assert calendar_client.list_events_calls[-1]["end"] is None
    assert calendar_client.list_events_calls[-1]["next_link"] == next_link


@pytest.mark.asyncio
async def test_list_meeting_transcripts_returns_structured_content() -> None:
    calendar_client = _FakeCalendarClient()
    server = create_server(runtime=_FakeRuntime(calendar=calendar_client))

    result = await server.call_tool(
        "list_meeting_transcripts",
        {"event_id": "event-1", "top": 10},
    )

    assert result.structured_content == {
        "transcripts": [
            {
                "id": "transcript-1",
                "meeting_id": "meeting-1",
                "call_id": "call-1",
                "created_at": "2026-04-03T12:00:00Z",
                "end_at": "2026-04-03T12:30:00Z",
                "content_correlation_id": "corr-1",
                "transcript_content_url": "https://graph.microsoft.com/v1.0/transcripts/1/content",
                "organizer_user_id": "user-1",
                "organizer_display_name": "Owner",
                "organizer_tenant_id": "tenant-1",
            }
        ]
    }
    assert calendar_client.list_meeting_transcripts_calls[-1]["top"] == 10


@pytest.mark.asyncio
async def test_read_meeting_transcript_returns_structured_content() -> None:
    calendar_client = _FakeCalendarClient()
    server = create_server(runtime=_FakeRuntime(calendar=calendar_client))

    result = await server.call_tool(
        "read_meeting_transcript",
        {"event_id": "event-1", "max_chars": 50000},
    )

    assert result.structured_content == {
        "transcript": {
            "id": "transcript-1",
            "meeting_id": "meeting-1",
            "call_id": "call-1",
            "created_at": "2026-04-03T12:00:00Z",
            "end_at": "2026-04-03T12:30:00Z",
            "content_correlation_id": "corr-1",
            "transcript_content_url": "https://graph.microsoft.com/v1.0/transcripts/1/content",
            "organizer_user_id": "user-1",
            "organizer_display_name": "Owner",
            "organizer_tenant_id": "tenant-1",
        },
        "format": "vtt",
        "text_content": "Speaker One: Hello team",
        "is_truncated": False,
        "warnings": [],
    }
    assert calendar_client.read_meeting_transcript_calls[-1]["max_chars"] == 50000


@pytest.mark.asyncio
async def test_read_meeting_notes_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("read_meeting_notes", {"event_id": "event-1"})

    assert result.structured_content == {
        "id": "insight-1",
        "call_id": "call-1",
        "content_correlation_id": "corr-1",
        "created_at": "2026-04-03T12:31:00Z",
        "end_at": "2026-04-03T12:30:00Z",
        "meeting_notes": [
            {
                "title": "Launch planning",
                "text": "Reviewed the launch checklist.",
                "subpoints": [
                    {
                        "title": "Dependencies",
                        "text": "Finalize legal review.",
                        "subpoints": [],
                    }
                ],
            }
        ],
        "action_items": [
            {
                "title": "Finalize timeline",
                "text": "Lock the ship date.",
                "owner_display_name": "Bella Smith",
            }
        ],
        "mention_events": [
            {
                "event_at": "2026-04-03T12:15:00Z",
                "speaker_name": "John Smith",
                "speaker_user_id": "user-2",
                "transcript_utterance": "John Smith owns the launch deck.",
            }
        ],
    }


@pytest.mark.asyncio
async def test_find_free_slots_returns_open_windows_after_ignores() -> None:
    runtime = _FakeRuntime(
        graph_response={
            "value": [
                {
                    "scheduleItems": [
                        {
                            "status": "busy",
                            "subject": "Lunch",
                            "start": {"dateTime": "2026-04-03T12:00:00Z"},
                            "end": {"dateTime": "2026-04-03T12:30:00Z"},
                        },
                        {
                            "status": "busy",
                            "subject": "Planning",
                            "start": {"dateTime": "2026-04-03T13:00:00Z"},
                            "end": {"dateTime": "2026-04-03T14:00:00Z"},
                        },
                    ]
                },
                {
                    "scheduleItems": [
                        {
                            "status": "tentative",
                            "subject": "Workout",
                            "start": {"dateTime": "2026-04-03T12:30:00Z"},
                            "end": {"dateTime": "2026-04-03T13:00:00Z"},
                        },
                        {
                            "status": "oof",
                            "subject": "OOO",
                            "start": {"dateTime": "2026-04-03T14:30:00Z"},
                            "end": {"dateTime": "2026-04-03T15:00:00Z"},
                        },
                    ]
                },
            ]
        }
    )
    server = create_server(runtime=runtime)

    result = await server.call_tool(
        "find_free_slots",
        {
            "attendees": ["a@example.com", "b@example.com"],
            "start": "2026-04-03T12:00:00Z",
            "end": "2026-04-03T16:00:00Z",
            "duration_minutes": 30,
            "ignore_subject_terms": ["lunch", "workout"],
        },
    )

    assert result.structured_content == {
        "windows": [
            {
                "start": "2026-04-03T12:00:00Z",
                "end": "2026-04-03T13:00:00Z",
                "duration_minutes": 60,
            },
            {
                "start": "2026-04-03T14:00:00Z",
                "end": "2026-04-03T14:30:00Z",
                "duration_minutes": 30,
            },
            {
                "start": "2026-04-03T15:00:00Z",
                "end": "2026-04-03T16:00:00Z",
                "duration_minutes": 60,
            },
        ]
    }
    assert runtime.graph_calls[0]["body"]["availabilityViewInterval"] == 30


@pytest.mark.asyncio
async def test_list_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_chats", {"top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "web_url": "",
                "is_hidden": False,
                "other_participant_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_chats_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("search_chats", {"query": "madeline", "top": 5})

    assert result.structured_content == {
        "chats": [
            {
                "id": "chat-1",
                "topic": "Madeline",
                "display_label": "Madeline",
                "chat_type": "oneOnOne",
                "created_at": "2026-04-03T12:00:00Z",
                "last_updated_at": "2026-04-03T12:05:00Z",
                "web_url": "",
                "is_hidden": False,
                "other_participant_count": 1,
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_chat_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool("list_chat_messages", {"chat_id": "chat-1", "top": 5})

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_chat_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_chat_messages",
        {"chat_id": "chat-1", "query": "reply", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_reply_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_messages_respects_max_chars_budget() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "top": 5, "max_chars": 80},
    )

    assert result.structured_content == {
        "messages": [],
        "truncated": True,
        "next_offset": None,
        "warnings": [_MAX_CHARS_TOO_SMALL_WARNING],
    }


@pytest.mark.asyncio
async def test_search_teams_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_teams_messages",
        {"query": "budget owner", "top": 5},
    )

    assert result.structured_content == {
        "messages": [
            {
                "id": "search-hit-1",
                "summary": "...budget owner...",
                "created_at": "2026-04-03T12:09:00Z",
                "subject": "",
                "importance": "normal",
                "web_url": "https://teams.microsoft.com/l/message/1",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender_name": "Rivera, Alex",
                "sender_email": "sara@example.com",
                "location_kind": "channel",
            }
        ],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_search_teams_messages_returns_and_uses_next_cursor() -> None:
    teams_client = _FakeTeamsClient(search_next_from=25)
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    first = await server.call_tool(
        "search_teams_messages",
        {"query": "budget owner", "top": 5},
    )

    await server.call_tool(
        "search_teams_messages",
        {"cursor": first.structured_content["next_cursor"], "top": 5},
    )

    assert teams_client.search_teams_messages_calls == [
        {"query": "budget owner", "top": 5, "from_index": 0},
        {"query": "budget owner", "top": 5, "from_index": 25},
    ]


@pytest.mark.asyncio
async def test_search_teams_messages_uses_graph_offset_without_overfetch() -> None:
    teams_client = _FakeTeamsClient()
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    result = await server.call_tool(
        "search_teams_messages",
        {"query": "budget owner", "top": 5, "offset": 20},
    )

    assert teams_client.search_teams_messages_calls == [
        {"query": "budget owner", "top": 5, "from_index": 20}
    ]
    assert result.structured_content["messages"][0]["id"] == "search-hit-1"


@pytest.mark.asyncio
async def test_search_teams_messages_allows_explicit_larger_top() -> None:
    teams_client = _FakeTeamsClient()
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    await server.call_tool(
        "search_teams_messages",
        {"query": "budget owner", "top": 25},
    )

    assert teams_client.search_teams_messages_calls == [
        {"query": "budget owner", "top": 25, "from_index": 0}
    ]


@pytest.mark.asyncio
async def test_search_teams_messages_suppresses_next_cursor_when_budget_truncates() -> None:
    teams_client = _FakeTeamsClient(search_next_from=25)
    server = create_server(runtime=_FakeRuntime(teams=teams_client))

    result = await server.call_tool(
        "search_teams_messages",
        {"query": "budget owner", "top": 5, "max_chars": 80},
    )

    assert result.structured_content["truncated"] is True
    assert "next_cursor" not in result.structured_content


@pytest.mark.asyncio
async def test_search_channel_messages_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "search_channel_messages",
        {"team_id": "team-1", "channel_id": "channel-1", "query": "hello", "top": 5},
    )

    assert result.structured_content == {
        "messages": [_teams_message_summary_payload()],
        "truncated": False,
    }


@pytest.mark.asyncio
async def test_list_channel_replies_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "list_channel_replies",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "replies": [_reply_summary_payload()],
        "truncated": False,
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_read_channel_thread_returns_structured_content() -> None:
    server = create_server(runtime=_FakeRuntime())

    result = await server.call_tool(
        "read_channel_thread",
        {"team_id": "team-1", "channel_id": "channel-1", "message_id": "root-1", "top": 5},
    )

    assert result.structured_content == {
        "root_message": {
            "id": "teams-msg-1",
            "body_content": "Hello from Teams",
            "content_type": "text",
            "created_at": "2026-04-03T12:07:00Z",
            "last_modified_at": "2026-04-03T12:07:00Z",
            "last_edited_at": "2026-04-03T12:08:00Z",
            "deleted_at": None,
            "subject": "",
            "summary": "Hello from Teams",
            "importance": "normal",
            "message_type": "message",
            "reply_to_id": "",
            "reply_count": 2,
            "web_url": "",
            "chat_id": "chat-1",
            "team_id": "team-1",
            "channel_id": "channel-1",
            "sender": {
                "display_name": "Sender",
                "email": "sender@example.com",
                "user_id": "user-1",
                "kind": "user",
            },
            "attachments": [
                {
                    "id": "teams-att-1",
                    "name": "brief.docx",
                    "content_type": "reference",
                    "content_url": "https://contoso.sharepoint.com/:w:/r/brief.docx",
                    "thumbnail_url": "",
                    "teams_app_id": "",
                }
            ],
        },
        "replies": [
            {
                "id": "reply-1",
                "body_content": "Reply body",
                "content_type": "text",
                "created_at": "2026-04-03T12:06:00Z",
                "last_modified_at": "2026-04-03T12:06:00Z",
                "last_edited_at": None,
                "deleted_at": None,
                "subject": "",
                "summary": "Reply body",
                "importance": "normal",
                "message_type": "message",
                "reply_to_id": "root-1",
                "reply_count": 0,
                "web_url": "",
                "chat_id": "",
                "team_id": "team-1",
                "channel_id": "channel-1",
                "sender": {
                    "display_name": "Responder",
                    "email": "responder@example.com",
                    "user_id": "user-2",
                    "kind": "user",
                },
                "attachments": [],
            }
        ],
        "has_more_replies": True,
    }


@pytest.mark.asyncio
async def test_tool_maps_authentication_failures_to_runtime_error() -> None:
    server = create_server(runtime=_FailingRuntime())

    with pytest.raises(ToolError, match="Authentication failed"):
        await server.call_tool("list_folders", {})


def test_mcp_main_supports_help() -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--help"])
    assert exc_info.value.code == 0


def test_mcp_server_can_warn_from_cached_stale_status(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("MS365_TOOLKIT_WARN_STALE", "1")
    calls: list[dict[str, object]] = []

    def fake_stale_warning(profile: str, *, timeout: float) -> str:
        calls.append({"profile": profile, "timeout": timeout})
        return f"stale warning for {profile}"

    monkeypatch.setattr(
        "ms365_toolkit.mcp.server.stale_warning_from_live",
        fake_stale_warning,
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    create_server(runtime=RuntimeWithProfile())

    assert "stale warning for default" in capsys.readouterr().err
    assert calls == [{"profile": "default", "timeout": 1.0}]


@pytest.mark.asyncio
async def test_tool_response_includes_cached_version_warning(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.mcp.tools.stale_warning_from_cache",
        lambda profile: f"stale warning for {profile}",
    )

    @dataclass
    class RuntimeWithProfile(_FakeRuntime):
        profile: str = "default"

    server = create_server(runtime=RuntimeWithProfile())

    result = await server.call_tool("list_inbox", {"mailbox_filter": "all", "top": 5})

    assert result.structured_content["version_warning"] == "stale warning for default"


@dataclass
class _FakeRuntime:
    graph_response: dict[str, Any] | None = None
    graph_calls: list[dict[str, Any]] = field(default_factory=list)
    sent_drafts: list[tuple[str, str]] = field(default_factory=list)
    email: _FakeEmailClient | None = None
    calendar: _FakeCalendarClient | None = None
    teams: _FakeTeamsClient | None = None

    def email_client(
        self,
        *,
        write: bool = False,
        include_share_links: bool = False,
    ) -> _FakeEmailClient:
        if self.email is None:
            self.email = _FakeEmailClient(self.sent_drafts)
        return self.email

    def calendar_client(
        self,
        *,
        include_meeting_transcripts: bool = False,
        include_meeting_notes: bool = False,
    ) -> _FakeCalendarClient:
        if self.calendar is None:
            self.calendar = _FakeCalendarClient()
        return self.calendar

    def teams_client(
        self,
        *,
        include_channel_messages: bool = False,
        include_files: bool = False,
    ) -> _FakeTeamsClient:
        if self.teams is None:
            self.teams = _FakeTeamsClient()
        return self.teams

    def graph_client(self) -> _FakeGraphClient:
        return _FakeGraphClient(self.graph_response or {"value": []}, self.graph_calls)


class _FailingRuntime(_FakeRuntime):
    def email_client(
        self,
        *,
        write: bool = False,
        include_share_links: bool = False,
    ) -> _FakeEmailClient:
        raise AuthenticationError("missing token")


class _FakeGraphClient:
    def __init__(self, response: dict[str, Any], calls: list[dict[str, Any]]) -> None:
        self._response = response
        self._calls = calls

    def post(self, path: str, *, body: dict[str, Any]) -> dict[str, Any]:
        self._calls.append({"path": path, "body": body})
        return self._response


class _FakeEmailClient:
    def __init__(
        self,
        sent_drafts: list[tuple[str, str]] | None = None,
        *,
        next_link: str | None = None,
    ) -> None:
        self._sent_drafts = sent_drafts if sent_drafts is not None else []
        self.next_link = next_link
        self.list_inbox_calls: list[dict[str, Any]] = []
        self.search_calls: list[dict[str, Any]] = []
        self.share_download_count = 0

    def list_inbox(
        self,
        *,
        mailbox_filter: str | None,
        top: int = 10,
        skip: int,
        summary_only: bool = False,
    ) -> list[EmailMessage]:
        return self.list_inbox_page(
            mailbox_filter=mailbox_filter,
            top=top,
            skip=skip,
            summary_only=summary_only,
        ).items

    def list_inbox_page(
        self,
        *,
        mailbox_filter: str | None = None,
        top: int,
        skip: int = 0,
        summary_only: bool = False,
        next_link: str | None = None,
    ) -> GraphPage[EmailMessage]:
        self.list_inbox_calls.append(
            {
                "mailbox_filter": mailbox_filter,
                "top": top,
                "skip": skip,
                "summary_only": summary_only,
                "next_link": next_link,
            }
        )
        return GraphPage([_message()], self.next_link)

    def search_emails(
        self,
        query: str,
        mailbox_filter: str | None = None,
        *,
        top: int = 25,
        summary_only: bool = False,
    ) -> list[EmailMessage]:
        return self.search_emails_page(
            query,
            mailbox_filter=mailbox_filter,
            top=top,
            summary_only=summary_only,
        ).items

    def search_emails_page(
        self,
        query: str,
        mailbox_filter: str | None = None,
        *,
        top: int = 25,
        summary_only: bool = False,
        next_link: str | None = None,
    ) -> GraphPage[EmailMessage]:
        self.search_calls.append(
            {
                "query": query,
                "mailbox_filter": mailbox_filter,
                "top": top,
                "summary_only": summary_only,
                "next_link": next_link,
            }
        )
        return GraphPage([_message()], self.next_link)

    def read_email(self, message_id: str) -> EmailMessage:
        return _message()

    def read_conversation_thread(
        self,
        conversation_id: str,
        *,
        top: int = 100,
    ) -> list[EmailMessage]:
        return [_message()]

    def list_attachments(
        self,
        message_id: str,
        *,
        include_inline: bool = False,
    ) -> list[EmailAttachment]:
        return [_attachment()]

    def read_attachment_text(
        self,
        message_id: str,
        attachment_id: str,
        *,
        max_chars: int = 50_000,
    ) -> ExtractedAttachment:
        return ExtractedAttachment(
            attachment=_attachment(),
            format="docx",
            text_content="Quarterly review",
            is_truncated=False,
            warnings=(),
        )

    def list_email_share_links(self, message_id: str) -> tuple[EmailShareLink, ...]:
        return (
            EmailShareLink(
                url="https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx",
                filename="Planning Brief.docx",
                host="contoso.sharepoint.com",
                source_text="Planning Brief.docx",
            ),
        )

    def resolve_share_link(self, url: str) -> ShareLinkDriveItem:
        return ShareLinkDriveItem(
            share_id="share-1",
            drive_id="drive-1",
            item_id="item-1",
            name="Planning Brief.docx",
            content_type=(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            size=9,
            web_url=url,
        )

    def download_share_link(self, url: str) -> DownloadedShareLink:
        return self.download_resolved_share_link(url, self.resolve_share_link(url))

    def download_resolved_share_link(
        self,
        url: str,
        drive_item: ShareLinkDriveItem,
    ) -> DownloadedShareLink:
        self.share_download_count += 1
        return DownloadedShareLink(
            url=url,
            drive_item=drive_item,
            content=b"docx-bytes",
        )

    def extract_downloaded_share_link_text(
        self,
        downloaded: DownloadedShareLink,
        *,
        max_chars: int = 50_000,
    ) -> ExtractedAttachment:
        return ExtractedAttachment(
            attachment=EmailAttachment(
                id=downloaded.drive_item.item_id,
                name=downloaded.drive_item.name,
                content_type=downloaded.drive_item.content_type,
                size=downloaded.drive_item.size,
                is_inline=False,
                is_reference=True,
                odata_type="#microsoft.graph.driveItem",
            ),
            format="docx",
            text_content="Quarterly review",
            is_truncated=False,
            warnings=(),
        )

    def list_folders(self) -> list[dict[str, str]]:
        return [{"id": "folder-1", "display_name": "Archive"}]

    def create_email_draft(
        self,
        *,
        to: tuple[str, ...],
        cc: tuple[str, ...] = (),
        bcc: tuple[str, ...] = (),
        subject: str,
        body: str,
        reply_to: tuple[str, ...] = (),
        importance: str = "normal",
    ) -> EmailDraft:
        return _draft(importance=importance)

    def create_reply_draft(
        self,
        message_id: str,
        *,
        body: str,
        importance: str | None = None,
    ) -> EmailDraft:
        return _draft(importance=importance or "high")

    def send_email_draft(self, draft_id: str, *, content_hash: str) -> None:
        self._sent_drafts.append((draft_id, content_hash))


class _FakeDuplicateShareLinkEmailClient(_FakeEmailClient):
    def list_email_share_links(self, message_id: str) -> tuple[EmailShareLink, ...]:
        return (
            *super().list_email_share_links(message_id),
            EmailShareLink(
                url="https://contoso.sharepoint.com/sites/Finance/Planning%20Brief.docx?web=1",
                filename="Planning Brief.docx",
                host="contoso.sharepoint.com",
                source_text="Planning Brief.docx",
            ),
        )


class _FakeCalendarClient:
    def __init__(self, *, next_link: str | None = None) -> None:
        self.next_link = next_link
        self.list_events_calls: list[dict[str, Any]] = []
        self.search_events_calls: list[dict[str, Any]] = []
        self.list_meeting_transcripts_calls: list[dict[str, Any]] = []
        self.read_meeting_transcript_calls: list[dict[str, Any]] = []

    def list_events(
        self,
        *,
        start: datetime,
        end: datetime,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> list[CalendarEvent]:
        return self.list_events_page(
            start=start,
            end=end,
            calendar_id=calendar_id,
            calendar_filter=calendar_filter,
        ).items

    def list_events_page(
        self,
        *,
        start: datetime | None = None,
        end: datetime | None = None,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
        next_link: str | None = None,
    ) -> GraphPage[CalendarEvent]:
        self.list_events_calls.append(
            {
                "start": start,
                "end": end,
                "calendar_id": calendar_id,
                "calendar_filter": calendar_filter,
                "next_link": next_link,
            }
        )
        return GraphPage([_event()], self.next_link)

    def get_event(self, event_id: str) -> CalendarEvent:
        return _event()

    def list_meeting_transcripts(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        top: int = 25,
    ) -> list[MeetingTranscript]:
        self.list_meeting_transcripts_calls.append(
            {
                "event_id": event_id,
                "join_web_url": join_web_url,
                "online_meeting_id": online_meeting_id,
                "top": top,
            }
        )
        return [_meeting_transcript()]

    def read_meeting_transcript(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        transcript_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedMeetingTranscript:
        self.read_meeting_transcript_calls.append(
            {
                "event_id": event_id,
                "join_web_url": join_web_url,
                "online_meeting_id": online_meeting_id,
                "transcript_id": transcript_id,
                "max_chars": max_chars,
            }
        )
        return ExtractedMeetingTranscript(
            transcript=_meeting_transcript(),
            format="vtt",
            text_content="Speaker One: Hello team",
            is_truncated=False,
            warnings=(),
        )

    def read_meeting_ai_insight(
        self,
        *,
        event_id: str | None = None,
        join_web_url: str | None = None,
        online_meeting_id: str | None = None,
        ai_insight_id: str | None = None,
    ) -> MeetingAiInsight:
        return _meeting_ai_insight()

    def search_events(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[CalendarEvent]:
        return self.search_events_page(query=query, start=start, end=end).items

    def search_events_page(
        self,
        *,
        query: str,
        start: datetime | None = None,
        end: datetime | None = None,
        next_link: str | None = None,
    ) -> GraphPage[CalendarEvent]:
        self.search_events_calls.append(
            {"query": query, "start": start, "end": end, "next_link": next_link}
        )
        return GraphPage([_event()], self.next_link)

    def list_calendars(self) -> list[dict[str, str]]:
        return self.list_calendars_page().items

    def list_calendars_page(
        self,
        *,
        next_link: str | None = None,
    ) -> GraphPage[dict[str, str]]:
        return GraphPage([{"id": "calendar-1", "name": "Primary"}], self.next_link)


class _FakeTeamsClient:
    def __init__(
        self,
        *,
        chats: list[TeamsChat] | None = None,
        messages: list[TeamsMessage] | None = None,
        chat_search_messages: list[TeamsMessage] | None = None,
        channel_messages: list[TeamsMessage] | None = None,
        channel_search_messages: list[TeamsMessage] | None = None,
        replies: tuple[TeamsMessage, ...] | None = None,
        search_hits: list[TeamsMessageSearchHit] | None = None,
        search_next_from: int | None = None,
        next_link: str | None = None,
    ) -> None:
        self.chats = chats if chats is not None else [_chat()]
        self.messages = messages if messages is not None else [_teams_message()]
        self.chat_search_messages = (
            chat_search_messages if chat_search_messages is not None else [_reply()]
        )
        self.channel_messages = (
            channel_messages if channel_messages is not None else [_teams_message()]
        )
        self.channel_search_messages = (
            channel_search_messages if channel_search_messages is not None else [_teams_message()]
        )
        self.replies = replies if replies is not None else (_reply(),)
        self.search_hits = search_hits if search_hits is not None else [_search_hit()]
        self.search_next_from = search_next_from
        self.next_link = next_link
        self.list_chat_messages_calls: list[dict[str, Any]] = []
        self.search_teams_messages_calls: list[dict[str, Any]] = []

    def list_chats(self, *, top: int = 25) -> list[TeamsChat]:
        return self.list_chats_page(top=top).items

    def list_chats_page(
        self,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsChat]:
        return GraphPage(self.chats, self.next_link)

    def search_chats(self, query: str, *, top: int = 10) -> list[TeamsChat]:
        return self.chats

    def list_chat_messages(self, chat_id: str, *, top: int = 25) -> list[TeamsMessage]:
        return self.list_chat_messages_page(chat_id, top=top).items

    def list_chat_messages_page(
        self,
        chat_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsMessage]:
        self.list_chat_messages_calls.append(
            {"chat_id": chat_id, "top": top, "next_link": next_link}
        )
        return GraphPage(self.messages, self.next_link)

    def search_chat_messages(
        self,
        chat_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return self.chat_search_messages

    def search_teams_messages(
        self,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessageSearchHit]:
        return self.search_teams_messages_page(query, top=top).items

    def search_teams_messages_page(
        self,
        query: str,
        *,
        top: int = 10,
        from_index: int = 0,
    ) -> TeamsMessageSearchPage:
        self.search_teams_messages_calls.append(
            {"query": query, "top": top, "from_index": from_index}
        )
        return TeamsMessageSearchPage(self.search_hits, self.search_next_from)

    def get_chat_message(self, chat_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def list_message_attachments(
        self,
        *,
        message_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
    ) -> list[TeamsMessageAttachment]:
        return [_teams_attachment()]

    def read_message_attachment_text(
        self,
        *,
        message_id: str,
        attachment_id: str,
        chat_id: str | None = None,
        team_id: str | None = None,
        channel_id: str | None = None,
        max_chars: int = 50_000,
    ) -> ExtractedTeamsFile:
        return ExtractedTeamsFile(
            attachment=_teams_attachment(),
            format="docx",
            text_content="Quarterly review",
            is_truncated=False,
            warnings=(),
        )

    def list_teams(self) -> list[TeamSummary]:
        return self.list_teams_page().items

    def list_teams_page(self, *, next_link: str | None = None) -> GraphPage[TeamSummary]:
        return GraphPage(
            [
                TeamSummary(
                    id="team-1",
                    display_name="Ops",
                    description="",
                    is_archived=False,
                    tenant_id="tenant-1",
                )
            ],
            self.next_link,
        )

    def list_channels(self, team_id: str) -> list[ChannelSummary]:
        return self.list_channels_page(team_id).items

    def list_channels_page(
        self,
        team_id: str,
        *,
        next_link: str | None = None,
    ) -> GraphPage[ChannelSummary]:
        return GraphPage(
            [
                ChannelSummary(
                    id="channel-1",
                    display_name="General",
                    description="",
                    membership_type="standard",
                    web_url="",
                )
            ],
            self.next_link,
        )

    def list_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
    ) -> list[TeamsMessage]:
        return self.list_channel_messages_page(team_id, channel_id, top=top).items

    def list_channel_messages_page(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> GraphPage[TeamsMessage]:
        return GraphPage(self.channel_messages, self.next_link)

    def search_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        query: str,
        *,
        top: int = 10,
    ) -> list[TeamsMessage]:
        return self.channel_search_messages

    def list_channel_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
    ) -> TeamsReplyPage:
        return self.list_channel_replies_page(team_id, channel_id, message_id, top=top)

    def list_channel_replies_page(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        top: int = 25,
        next_link: str | None = None,
    ) -> TeamsReplyPage:
        return TeamsReplyPage(
            replies=self.replies,
            has_more_replies=True,
            next_link=self.next_link,
        )

    def get_channel_message(self, team_id: str, channel_id: str, message_id: str) -> TeamsMessage:
        return _teams_message()

    def read_channel_thread(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        *,
        replies_top: int = 25,
    ) -> TeamsThread:
        return TeamsThread(
            root_message=_teams_message(),
            replies=(_reply(),),
            has_more_replies=True,
        )


def _message(
    *,
    message_id: str = "msg-1",
    subject: str = "Hello",
    body_preview: str = "Preview",
    body_content: str = "<untrusted-email-content>Hello</untrusted-email-content>",
) -> EmailMessage:
    return EmailMessage(
        id=message_id,
        subject=subject,
        sender="sender@example.com",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        body_preview=body_preview,
        body_content=body_content,
        received_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        is_read=False,
        is_flagged=True,
        importance="high",
        has_attachments=False,
        attachments=(),
        conversation_id="conversation-1",
        folder_id="folder-1",
    )


def _attachment() -> EmailAttachment:
    return EmailAttachment(
        id="att-1",
        name="brief.docx",
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        size=128,
        is_inline=False,
        is_reference=False,
        odata_type="#microsoft.graph.fileAttachment",
    )


def _draft(*, importance: str = "high") -> EmailDraft:
    return EmailDraft(
        draft_id="draft-1",
        content_hash="hash-1",
        to=("to@example.com",),
        cc=(),
        bcc=(),
        subject="Hello",
        body="<p>Hello</p>",
        attachments=(),
        reply_to=(),
        importance=importance,
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
    )


def _event() -> CalendarEvent:
    return CalendarEvent(
        id="event-1",
        subject="Planning",
        start=datetime(2026, 4, 3, 9, 0, tzinfo=UTC),
        end=datetime(2026, 4, 3, 9, 30, tzinfo=UTC),
        timezone="UTC",
        location="Room A",
        body_content="Agenda",
        attendees=(
            Attendee(
                email="person@example.com",
                name="Person",
                response="accepted",
                type="required",
            ),
        ),
        is_online_meeting=False,
        is_cancelled=False,
        importance="normal",
        categories=("Work",),
        recurrence=None,
        organizer="owner@example.com",
        response_status="accepted",
        calendar_id="calendar-1",
        join_url="https://teams.microsoft.com/l/meetup-join/meeting-1",
        ical_uid="ical-1",
    )


def _chat() -> TeamsChat:
    return TeamsChat(
        id="chat-1",
        topic="Madeline",
        display_label="Madeline",
        chat_type="oneOnOne",
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        last_updated_at=datetime(2026, 4, 3, 12, 5, tzinfo=UTC),
        last_message_read_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        web_url="",
        is_hidden=False,
        is_hidden_for_all_members=False,
        other_participants=(
            TeamsParticipant(
                display_name="Madeline",
                email="madeline@example.com",
                user_id="user-2",
            ),
        ),
    )


def _teams_message(
    *,
    message_id: str = "teams-msg-1",
    body_content: str = "Hello from Teams",
) -> TeamsMessage:
    return TeamsMessage(
        id=message_id,
        body_content=body_content,
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 7, tzinfo=UTC),
        last_edited_at=datetime(2026, 4, 3, 12, 8, tzinfo=UTC),
        deleted_at=None,
        subject="",
        summary=body_content,
        importance="normal",
        message_type="message",
        reply_to_id="",
        reply_count=2,
        web_url="",
        chat_id="chat-1",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Sender",
            email="sender@example.com",
            user_id="user-1",
            kind="user",
        ),
        attachments=(_teams_attachment(),),
    )


def _teams_message_summary_payload(
    *,
    message_id: str = "teams-msg-1",
    body_preview: str = "Hello from Teams",
    summary: str = "Hello from Teams",
) -> dict[str, Any]:
    return {
        "id": message_id,
        "body_preview": body_preview,
        "content_type": "text",
        "created_at": "2026-04-03T12:07:00Z",
        "subject": "",
        "summary": summary,
        "importance": "normal",
        "message_type": "message",
        "reply_to_id": "",
        "reply_count": 2,
        "web_url": "",
        "chat_id": "chat-1",
        "team_id": "team-1",
        "channel_id": "channel-1",
        "sender": {
            "display_name": "Sender",
            "email": "sender@example.com",
            "user_id": "user-1",
            "kind": "user",
        },
        "attachment_count": 1,
    }


def _reply() -> TeamsMessage:
    return TeamsMessage(
        id="reply-1",
        body_content="Reply body",
        content_type="text",
        created_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 6, tzinfo=UTC),
        last_edited_at=None,
        deleted_at=None,
        subject="",
        summary="Reply body",
        importance="normal",
        message_type="message",
        reply_to_id="root-1",
        reply_count=0,
        web_url="",
        chat_id="",
        team_id="team-1",
        channel_id="channel-1",
        sender=TeamsSender(
            display_name="Responder",
            email="responder@example.com",
            user_id="user-2",
            kind="user",
        ),
    )


def _search_hit() -> TeamsMessageSearchHit:
    return TeamsMessageSearchHit(
        id="search-hit-1",
        summary="...budget owner...",
        created_at=datetime(2026, 4, 3, 12, 9, tzinfo=UTC),
        last_modified_at=datetime(2026, 4, 3, 12, 10, tzinfo=UTC),
        subject="",
        importance="normal",
        web_url="https://teams.microsoft.com/l/message/1",
        chat_id="",
        team_id="team-1",
        channel_id="channel-1",
        sender_name="Rivera, Alex",
        sender_email="sara@example.com",
        location_kind="channel",
    )


def _reply_summary_payload() -> dict[str, Any]:
    return {
        "id": "reply-1",
        "body_preview": "Reply body",
        "content_type": "text",
        "created_at": "2026-04-03T12:06:00Z",
        "subject": "",
        "summary": "Reply body",
        "importance": "normal",
        "message_type": "message",
        "reply_to_id": "root-1",
        "reply_count": 0,
        "web_url": "",
        "chat_id": "",
        "team_id": "team-1",
        "channel_id": "channel-1",
        "sender": {
            "display_name": "Responder",
            "email": "responder@example.com",
            "user_id": "user-2",
            "kind": "user",
        },
        "attachment_count": 0,
    }


def _teams_attachment() -> TeamsMessageAttachment:
    return TeamsMessageAttachment(
        id="teams-att-1",
        name="brief.docx",
        content_type="reference",
        content_url="https://contoso.sharepoint.com/:w:/r/brief.docx",
        thumbnail_url="",
        teams_app_id="",
    )


def _meeting_transcript() -> MeetingTranscript:
    return MeetingTranscript(
        id="transcript-1",
        meeting_id="meeting-1",
        call_id="call-1",
        created_at=datetime(2026, 4, 3, 12, 0, tzinfo=UTC),
        end_at=datetime(2026, 4, 3, 12, 30, tzinfo=UTC),
        content_correlation_id="corr-1",
        transcript_content_url="https://graph.microsoft.com/v1.0/transcripts/1/content",
        organizer_user_id="user-1",
        organizer_display_name="Owner",
        organizer_tenant_id="tenant-1",
    )


def _meeting_ai_insight() -> MeetingAiInsight:
    return MeetingAiInsight(
        id="insight-1",
        call_id="call-1",
        content_correlation_id="corr-1",
        created_at=datetime(2026, 4, 3, 12, 31, tzinfo=UTC),
        end_at=datetime(2026, 4, 3, 12, 30, tzinfo=UTC),
        meeting_notes=(
            MeetingNotePoint(
                title="Launch planning",
                text="Reviewed the launch checklist.",
                subpoints=(MeetingNotePoint(title="Dependencies", text="Finalize legal review."),),
            ),
        ),
        action_items=(
            MeetingActionItem(
                title="Finalize timeline",
                text="Lock the ship date.",
                owner_display_name="Bella Smith",
            ),
        ),
        mention_events=(
            MeetingMentionEvent(
                event_at=datetime(2026, 4, 3, 12, 15, tzinfo=UTC),
                speaker_name="John Smith",
                speaker_user_id="user-2",
                transcript_utterance="John Smith owns the launch deck.",
            ),
        ),
    )
