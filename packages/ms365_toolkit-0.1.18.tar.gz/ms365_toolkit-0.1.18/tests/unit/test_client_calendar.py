from __future__ import annotations

import base64
import json
from dataclasses import replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import pytest

from ms365_toolkit.client.calendar import CalendarClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_list_events_uses_calendar_view_endpoint(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.list_events(
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
    )

    assert "/me/calendarView?" in captured["url"]
    assert "startDateTime=2026-03-12T09:00:00Z" in captured["url"]


def test_list_events_page_returns_next_link(tmp_path: Path) -> None:
    next_link = "https://graph.microsoft.com/v1.0/me/calendarView?$skiptoken=abc"

    client = CalendarClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {"@odata.nextLink": next_link, "value": [_event_item("event-1")]}
            ),
        )
    )

    page = client.list_events_page(
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
    )

    assert page.next_link == next_link
    assert page.items[0].id == "event-1"


def test_get_event_maps_graph_payload_to_calendar_event(tmp_path: Path) -> None:
    client = CalendarClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(_event_item("event-1")),
        )
    )

    event = client.get_event("event-1")

    assert event.id == "event-1"
    assert event.subject == "Planning"
    assert event.location == "Room A"
    assert event.body_content == "Agenda"
    assert event.attendees[0].email == "a@example.com"
    assert event.start == datetime(2026, 3, 12, 9, tzinfo=UTC)
    assert event.join_url == "https://teams.microsoft.com/l/meetup-join/meeting-1"
    assert event.ical_uid == "ical-1"


def test_find_free_slots_uses_get_schedule(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["body"] = req.data.decode("utf-8")
        return _response(
            {
                "value": [
                    {
                        "scheduleItems": [
                            {
                                "start": {"dateTime": "2026-03-12T09:00:00Z"},
                                "end": {"dateTime": "2026-03-12T09:30:00Z"},
                                "status": "busy",
                            }
                        ]
                    }
                ]
            }
        )

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    slots = client.find_free_slots(
        attendees=["a@example.com"],
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
        duration=30,
    )

    assert captured["url"].endswith("/me/calendar/getSchedule")
    assert '"availabilityViewInterval": 30' in captured["body"]
    assert slots[0].status == "busy"


def test_search_events_builds_filter(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.search_events(
        query="board",
        start=datetime(2026, 3, 12, 9, tzinfo=UTC),
        end=datetime(2026, 3, 12, 10, tzinfo=UTC),
    )

    assert "contains(subject,'board')" in captured["url"]
    assert "start%2FdateTime+ge+'2026-03-12T09:00:00Z'" in captured["url"]


def test_search_events_escapes_odata_quotes(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = CalendarClient(
        GraphClient(config=_config(tmp_path), token="token", transport=transport)
    )

    client.search_events(query="o'brien")

    assert "contains(subject,'o''brien')" in captured["url"]


def test_list_meeting_transcripts_resolves_online_meeting_from_event(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            _event_item("event-1"),
            {"value": [{"id": "meeting-1"}]},
            {"value": [_transcript_item("transcript-1")]},
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        return _response(next(responses))

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = CalendarClient(graph, online_meeting_graph=graph, transcript_graph=graph)

    transcripts = client.list_meeting_transcripts(event_id="event-1")

    assert transcripts[0].id == "transcript-1"
    assert transcripts[0].meeting_id == "meeting-1"
    assert "events/event-1" in calls[0]
    assert "JoinWebUrl+eq+" in calls[1]
    assert calls[2].endswith("/me/onlineMeetings/meeting-1/transcripts?$top=10")


def test_read_meeting_transcript_extracts_vtt_text(tmp_path: Path) -> None:
    responses = iter(
        [
            {"value": [_transcript_item("transcript-1")]},
            (
                b"WEBVTT\n\n"
                b"00:00:00.000 --> 00:00:02.000\n"
                b"<v Speaker One>Hello team\n\n"
                b"00:00:02.000 --> 00:00:04.000\n"
                b"<v Speaker Two>Reviewed the budget\n"
            ),
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = CalendarClient(graph, online_meeting_graph=graph, transcript_graph=graph)

    extracted = client.read_meeting_transcript(online_meeting_id="meeting-1")

    assert extracted.format == "vtt"
    assert "Speaker One: Hello team" in extracted.text_content
    assert "Speaker Two: Reviewed the budget" in extracted.text_content


def test_read_meeting_transcript_fetches_transcript_id_directly(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            _transcript_item("transcript-1"),
            b"WEBVTT\n\n00:00:00.000 --> 00:00:02.000\n<v Speaker One>Hello team\n",
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = CalendarClient(graph, online_meeting_graph=graph, transcript_graph=graph)

    extracted = client.read_meeting_transcript(
        online_meeting_id="meeting-1",
        transcript_id="transcript-1",
    )

    assert extracted.transcript.id == "transcript-1"
    assert calls == [
        "https://graph.microsoft.com/v1.0/me/onlineMeetings/meeting-1/transcripts/transcript-1",
        (
            "https://graph.microsoft.com/v1.0/me/onlineMeetings/meeting-1/transcripts/"
            "transcript-1/content"
        ),
    ]


def test_read_meeting_transcript_selects_matching_event_occurrence(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            _event_item("event-1"),
            {"value": [{"id": "meeting-1"}]},
            {
                "value": [
                    _transcript_item(
                        "transcript-old",
                        created_at="2026-03-05T09:30:00Z",
                        end_at="2026-03-05T10:00:00Z",
                    ),
                    _transcript_item("transcript-current"),
                ]
            },
            b"WEBVTT\n\n00:00:00.000 --> 00:00:02.000\n<v Speaker One>Hello team\n",
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    graph = GraphClient(config=_config(tmp_path), token="token", transport=transport)
    client = CalendarClient(graph, online_meeting_graph=graph, transcript_graph=graph)

    extracted = client.read_meeting_transcript(event_id="event-1")

    assert extracted.transcript.id == "transcript-current"
    assert calls[-1].endswith("/me/onlineMeetings/meeting-1/transcripts/transcript-current/content")


def test_read_meeting_ai_insight_returns_notes_and_actions(tmp_path: Path) -> None:
    responses = iter(
        [
            {"value": [_ai_insight_item("insight-1")]},
            _ai_insight_item("insight-1"),
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        return _response(next(responses))

    graph = GraphClient(
        config=_config(tmp_path),
        token=_jwt_token(user_id="user-1", upn="owner@example.com"),
        transport=transport,
    )
    client = CalendarClient(graph, online_meeting_graph=graph, ai_insights_graph=graph)

    insight = client.read_meeting_ai_insight(online_meeting_id="meeting-1")

    assert insight.id == "insight-1"
    assert insight.meeting_notes[0].title == "Launch planning"
    assert insight.action_items[0].owner_display_name == "Bella Smith"
    assert insight.mention_events[0].speaker_name == "John Smith"


def test_read_meeting_ai_insight_pages_until_matching_event_occurrence(tmp_path: Path) -> None:
    current_user_token = _jwt_token(user_id="user-1", upn="owner@example.com")
    event_url = (
        "https://graph.microsoft.com/v1.0/me/events/event-1"
        "?$select=id,start,end,isOnlineMeeting,onlineMeeting,onlineMeetingUrl"
    )
    meeting_lookup_url = (
        "https://graph.microsoft.com/v1.0/me/onlineMeetings"
        "?$filter=JoinWebUrl+eq+'https:%2F%2Fteams.microsoft.com%2Fl%2Fmeetup-join%2Fmeeting-1'"
    )
    insights_url = (
        "https://graph.microsoft.com/v1.0/copilot/users/user-1/"
        "onlineMeetings/meeting-1/aiInsights"
    )
    insight_detail_url = (
        "https://graph.microsoft.com/v1.0/copilot/users/user-1/"
        "onlineMeetings/meeting-1/aiInsights/insight-current"
    )
    next_link = (
        "https://graph.microsoft.com/v1.0/copilot/users/user-1/onlineMeetings/"
        "meeting-1/aiInsights?$skiptoken=page-2"
    )
    calls: list[str] = []
    responses: dict[str, Any] = {
        event_url: _event_item("event-1"),
        meeting_lookup_url: {"value": [{"id": "meeting-1"}]},
        insights_url: {
            "value": [
                _ai_insight_item(
                    "insight-old",
                    created_at="2026-03-05T10:05:00Z",
                    end_at="2026-03-05T10:00:00Z",
                )
            ],
            "@odata.nextLink": next_link,
        },
        next_link: {"value": [_ai_insight_item("insight-current")]},
        insight_detail_url: _ai_insight_item("insight-current"),
    }

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        return _response(responses[req.full_url])

    graph = GraphClient(config=_config(tmp_path), token=current_user_token, transport=transport)
    client = CalendarClient(graph, online_meeting_graph=graph, ai_insights_graph=graph)

    insight = client.read_meeting_ai_insight(event_id="event-1")

    assert insight.id == "insight-current"
    assert next_link in calls


def test_meeting_artifacts_require_me_endpoint(tmp_path: Path) -> None:
    config = _config(tmp_path)
    delegated_config = replace(
        config,
        user=replace(config.user, endpoint="users", user_principal_name="shared@example.com"),
    )
    graph = GraphClient(
        config=delegated_config,
        token="token",
        transport=lambda req, timeout: _response({}),
    )
    client = CalendarClient(graph, online_meeting_graph=graph, transcript_graph=graph)

    with pytest.raises(ValueError, match=r"user\.endpoint='me'"):
        client.list_meeting_transcripts(online_meeting_id="meeting-1")


class _FakeResponse:
    def __init__(self, payload: dict[str, Any]) -> None:
        import json

        self._payload = json.dumps(payload).encode("utf-8")

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _response(payload: dict[str, Any]) -> _FakeResponse:
    return _FakeResponse(payload)


class _FakeBytesResponse:
    def __init__(self, payload: bytes) -> None:
        self._payload = payload

    def __enter__(self) -> _FakeBytesResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _bytes_response(payload: bytes) -> _FakeBytesResponse:
    return _FakeBytesResponse(payload)


def _event_item(event_id: str) -> dict[str, Any]:
    return {
        "id": event_id,
        "subject": "Planning",
        "start": {"dateTime": "2026-03-12T09:00:00Z", "timeZone": "UTC"},
        "end": {"dateTime": "2026-03-12T10:00:00Z", "timeZone": "UTC"},
        "location": {"displayName": "Room A"},
        "body": {"content": "<p>Agenda</p>"},
        "attendees": [
            {
                "emailAddress": {"address": "a@example.com", "name": "A"},
                "status": {"response": "accepted"},
                "type": "required",
            }
        ],
        "isOnlineMeeting": True,
        "onlineMeeting": {"joinUrl": "https://teams.microsoft.com/l/meetup-join/meeting-1"},
        "onlineMeetingUrl": "https://teams.microsoft.com/l/meetup-join/meeting-1",
        "isCancelled": False,
        "importance": "high",
        "categories": ["Work"],
        "recurrence": None,
        "iCalUId": "ical-1",
        "organizer": {"emailAddress": {"address": "owner@example.com"}},
        "responseStatus": {"response": "accepted"},
        "calendar": {"id": "calendar-1"},
    }


def _transcript_item(
    transcript_id: str,
    *,
    created_at: str = "2026-03-12T09:30:00Z",
    end_at: str = "2026-03-12T10:00:00Z",
) -> dict[str, Any]:
    return {
        "id": transcript_id,
        "meetingId": "meeting-1",
        "callId": "call-1",
        "createdDateTime": created_at,
        "endDateTime": end_at,
        "contentCorrelationId": "corr-1",
        "transcriptContentUrl": "https://graph.microsoft.com/v1.0/transcripts/1/content",
        "meetingOrganizer": {
            "user": {
                "id": "user-1",
                "displayName": "Owner",
                "tenantId": "tenant-1",
            }
        },
    }


def _ai_insight_item(
    insight_id: str,
    *,
    created_at: str = "2026-03-12T10:05:00Z",
    end_at: str = "2026-03-12T10:00:00Z",
) -> dict[str, Any]:
    return {
        "id": insight_id,
        "callId": "call-1",
        "contentCorrelationId": "corr-1",
        "createdDateTime": created_at,
        "endDateTime": end_at,
        "meetingNotes": [
            {
                "title": "Launch planning",
                "text": "Reviewed the launch checklist.",
                "subpoints": [{"title": "Dependencies", "text": "Finalize legal review."}],
            }
        ],
        "actionItems": [
            {
                "title": "Finalize timeline",
                "text": "Lock the ship date.",
                "ownerDisplayName": "Bella Smith",
            }
        ],
        "viewpoint": {
            "mentionEvents": [
                {
                    "eventDateTime": "2026-03-12T09:45:00Z",
                    "transcriptUtterance": "John Smith owns the launch deck.",
                    "speaker": {"user": {"id": "user-2", "displayName": "John Smith"}},
                }
            ]
        },
    }


def _jwt_token(*, user_id: str, upn: str) -> str:
    header = base64.urlsafe_b64encode(
        json.dumps({"alg": "none", "typ": "JWT"}).encode("utf-8")
    ).rstrip(b"=")
    payload = base64.urlsafe_b64encode(
        json.dumps({"oid": user_id, "upn": upn, "exp": 9999999999}).encode("utf-8")
    ).rstrip(b"=")
    return f"{header.decode()}.{payload.decode()}."


def _config(tmp_path: Path) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
