from __future__ import annotations

import json
import stat
from datetime import UTC, datetime, timedelta

from ms365_toolkit.usage import (
    UsageEvent,
    UsageLogger,
    read_usage_events,
    record_graph_request,
    sanitize_graph_endpoint,
    start_usage_recording,
    stop_usage_recording,
    summarize_errors,
    summarize_health,
    summarize_slow,
    summarize_tools,
    summarize_usage,
)


def test_usage_logger_writes_jsonl_with_private_permissions(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.usage.get_profile_dir",
        lambda profile: tmp_path / profile,
    )
    logger = UsageLogger.for_profile("default")

    logger.log(
        UsageEvent(
            profile="default",
            surface="mcp",
            name="search_emails",
            version="0.1.10",
            duration_ms=12,
            success=True,
            timestamp=datetime(2026, 4, 18, tzinfo=UTC),
            result_size_chars=240,
            result_item_count=2,
            truncated=False,
        )
    )

    path = tmp_path / "default" / "usage" / "events.jsonl"
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["name"] == "search_emails"
    assert payload["result_item_count"] == 2
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    serialized = path.read_text(encoding="utf-8")
    assert "subject" not in serialized
    assert "recipient" not in serialized
    assert "message_id" not in serialized


def test_usage_logger_rotates(tmp_path) -> None:
    logger = UsageLogger(tmp_path / "events.jsonl", max_bytes=120, backup_count=2)

    for index in range(3):
        logger.log(
            UsageEvent(
                profile="default",
                surface="cli",
                name=f"command-{index}",
                version="0.1.10",
                duration_ms=1,
                success=True,
                timestamp=datetime(2026, 4, 18, tzinfo=UTC),
            )
        )

    assert (tmp_path / "events.jsonl").exists()
    assert (tmp_path / "events.jsonl.1").exists()


def test_usage_summaries_ignore_malformed_lines_and_filter_by_days(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.usage.get_profile_dir",
        lambda profile: tmp_path / profile,
    )
    path = tmp_path / "default" / "usage" / "events.jsonl"
    path.parent.mkdir(parents=True)
    now = datetime(2026, 4, 18, tzinfo=UTC)
    path.write_text(
        "\n".join(
            [
                "{bad json",
                json.dumps(
                    {
                        "timestamp": (now - timedelta(days=1)).isoformat(),
                        "profile": "default",
                        "surface": "mcp",
                        "name": "search_emails",
                        "version": "0.1.10",
                        "duration_ms": 10,
                        "success": True,
                        "result_size_chars": 100,
                        "result_item_count": 2,
                        "truncated": True,
                    }
                ),
                json.dumps(
                    {
                        "timestamp": (now - timedelta(days=2)).isoformat(),
                        "profile": "default",
                        "surface": "cli",
                        "name": "send-email-draft",
                        "version": "0.1.9",
                        "duration_ms": 30,
                        "success": False,
                        "result_size_chars": 20,
                        "result_item_count": 1,
                        "error_type": "SafetyDeniedError",
                        "error_code": "allowlist_denied",
                    }
                ),
                json.dumps(
                    {
                        "timestamp": (now - timedelta(days=20)).isoformat(),
                        "profile": "default",
                        "surface": "cli",
                        "name": "old",
                        "duration_ms": 999,
                        "success": True,
                    }
                ),
            ]
        ),
        encoding="utf-8",
    )

    events = read_usage_events("default", days=7, now=now)
    summary = summarize_usage(events)
    tools = summarize_tools(events)
    errors = summarize_errors(events)
    slow = summarize_slow(events, limit=1)

    assert len(events) == 2
    assert summary["failures"] == 1
    assert summary["truncated_count"] == 1
    assert summary["total_mcp_result_chars"] == 100
    assert summary["versions"] == {"0.1.10": 1, "0.1.9": 1}
    assert slow == [
        {
            "timestamp": (now - timedelta(days=2)).isoformat(),
            "name": "cli:send-email-draft",
            "duration_ms": 30,
            "result_size_chars": 20,
            "result_item_count": 1,
            "truncated": False,
            "success": False,
        }
    ]
    assert [item["name"] for item in tools] == ["cli:send-email-draft", "mcp:search_emails"]
    assert errors == [
        {
            "error_type": "SafetyDeniedError",
            "error_code": "allowlist_denied",
            "count": 1,
            "latest_timestamp": (now - timedelta(days=2)).isoformat(),
            "names": ["cli:send-email-draft"],
        }
    ]


def test_usage_recording_captures_sanitized_graph_metrics() -> None:
    token = start_usage_recording()

    record_graph_request(
        method="GET",
        url=(
            "https://graph.microsoft.com/v1.0/me/messages/"
            "AAMkAGNkZGIwOGUzLTRlNDctNGFlYi04MzYwLTg0ZjY4MTNmYmE4Nw=="
            "?$select=subject"
        ),
        status="2xx",
        duration_ms=42,
        retry_count=1,
    )

    metrics = stop_usage_recording(token)

    assert metrics["graph_request_count"] == 1
    assert metrics["graph_duration_ms"] == 42
    assert metrics["graph_retry_count"] == 1
    assert metrics["graph_status_counts"] == {"2xx": 1}
    assert metrics["graph_endpoint_counts"] == {"GET /me/messages/{id}": 1}
    assert metrics["graph_endpoint_duration_ms"] == {"GET /me/messages/{id}": 42}


def test_sanitize_graph_endpoint_removes_urls_queries_and_identifiers() -> None:
    endpoint = sanitize_graph_endpoint(
        "GET",
        "https://graph.microsoft.com/v1.0/users/leader%40example.com/messages/msg-123"
        "/attachments/att-456?$select=name",
    )

    assert endpoint == "GET /users/{id}/messages/{id}/attachments/{id}"
    assert "leader" not in endpoint
    assert "msg-123" not in endpoint
    assert "$select" not in endpoint


def test_summarize_health_reports_hotspots() -> None:
    events = [
        {
            "timestamp": "2026-04-18T00:00:00Z",
            "surface": "mcp",
            "name": "read_meeting_notes",
            "duration_ms": 500,
            "success": False,
            "error_type": "InsufficientScopesError",
            "error_code": "insufficient_scopes:OnlineMeetingAiInsight.Read.All",
            "result_size_chars": 0,
            "graph_endpoint_counts": {"GET /onlineMeetings": 1},
            "graph_endpoint_duration_ms": {"GET /onlineMeetings": 300},
        },
        {
            "timestamp": "2026-04-18T00:01:00Z",
            "surface": "mcp",
            "name": "search_emails",
            "duration_ms": 100,
            "success": True,
            "result_size_chars": 50_000,
            "result_item_count": 10,
            "truncated": True,
        },
    ]

    report = summarize_health(events, limit=1)

    assert report["summary"]["total_events"] == 2
    assert report["failure_hotspots"][0]["name"] == "mcp:read_meeting_notes"
    assert report["large_responses"][0]["name"] == "mcp:search_emails"
    assert report["graph_hotspots"][0]["endpoint"] == "GET /onlineMeetings"
