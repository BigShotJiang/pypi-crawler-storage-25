from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import pytest
from scripts import smoke_mcp as smoke

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class _FakeResult:
    structured_content: dict[str, Any]


class _FailingClient:
    async def list_tools(self) -> list[Any]:
        return []

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | int | None = None,
    ) -> Any:
        raise RuntimeError("private subject should not print")


class _RecordingClient:
    def __init__(self, payload: dict[str, Any]) -> None:
        self.payload = payload
        self.calls: list[tuple[str, dict[str, Any] | None]] = []

    async def list_tools(self) -> list[Any]:
        return []

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | int | None = None,
    ) -> Any:
        self.calls.append((name, arguments))
        return _FakeResult(self.payload)


def test_validate_collection_redacts_ids_and_private_fields_from_report() -> None:
    payload = {
        "messages": [
            {
                "id": "secret-message-id",
                "subject": "private subject",
                "sender": "private@example.com",
                "body_preview": "private preview",
            }
        ],
        "truncated": False,
    }

    details = smoke._validate_collection(
        payload,
        key="messages",
        forbidden=smoke.EMAIL_SUMMARY_FORBIDDEN,
    )
    line = smoke.format_result(smoke.CheckResult("list_inbox", "PASS", details))

    assert "secret-message-id" not in line
    assert "private subject" not in line
    assert "private@example.com" not in line
    assert "private preview" not in line
    assert smoke._hash_id("secret-message-id") in line


def test_validate_collection_rejects_forbidden_compact_fields() -> None:
    payload = {
        "messages": [
            {
                "id": "message-1",
                "body_content": "full body",
                "conversation_id": "conversation-1",
            }
        ]
    }

    with pytest.raises(smoke.SmokeAssertionError, match="body_content"):
        smoke._validate_collection(
            payload,
            key="messages",
            forbidden=smoke.EMAIL_SUMMARY_FORBIDDEN,
        )


@pytest.mark.asyncio
async def test_optional_tool_error_skips_without_private_error_text() -> None:
    results: list[smoke.CheckResult] = []

    await smoke._optional_tool(
        _FailingClient(),
        results,
        "list_chats",
        {},
        lambda payload: {},
        timeout=1,
    )

    assert results == [smoke.CheckResult("list_chats", "SKIP", {"error": "RuntimeError"})]
    assert "private subject" not in smoke.format_result(results[0])


@pytest.mark.asyncio
async def test_continue_if_present_uses_next_offset() -> None:
    client = _RecordingClient({"messages": [], "truncated": False})
    results: list[smoke.CheckResult] = []

    await smoke._continue_if_present(
        client,
        results,
        "list_inbox",
        {"messages": [], "truncated": True, "next_offset": 2},
        {"top": 5, "max_chars": 2_000},
        lambda payload: {"count": 0},
        timeout=1,
        required=True,
    )

    assert client.calls == [("list_inbox", {"top": 5, "max_chars": 2_000, "offset": 2})]
    assert results == [smoke.CheckResult("list_inbox:continue", "PASS", {"count": 0})]


@pytest.mark.asyncio
async def test_continue_if_present_uses_next_cursor() -> None:
    client = _RecordingClient({"messages": [], "truncated": False})
    results: list[smoke.CheckResult] = []

    await smoke._continue_if_present(
        client,
        results,
        "list_inbox",
        {"messages": [], "truncated": False, "next_cursor": "secret-cursor"},
        {"top": 5, "max_chars": 2_000},
        lambda payload: {"count": 0},
        timeout=1,
        required=True,
    )

    assert client.calls == [
        ("list_inbox", {"top": 5, "max_chars": 2_000, "cursor": "secret-cursor"})
    ]
    assert results == [smoke.CheckResult("list_inbox:continue", "PASS", {"count": 0})]


def test_exit_code_fails_only_when_failures_exist() -> None:
    assert smoke.exit_code([smoke.CheckResult("optional", "SKIP")]) == 0
    assert smoke.exit_code([smoke.CheckResult("required", "FAIL")]) == 1


def test_stdio_client_passes_safe_uv_environment(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("UV_CACHE_DIR", raising=False)
    monkeypatch.delenv("UV_TOOL_DIR", raising=False)

    client = smoke._stdio_client(profile="default", timeout=1, root=tmp_path)

    assert client.transport.env["UV_CACHE_DIR"] == "/tmp/ms365-toolkit-uv-cache"
    assert client.transport.env["UV_TOOL_DIR"] == "/tmp/ms365-toolkit-uv-tools"
