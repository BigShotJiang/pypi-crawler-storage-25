from __future__ import annotations

import subprocess

from ms365_toolkit.safety.dialog import OSASCRIPT_PATH, can_show_dialog, show_confirmation_dialog
from ms365_toolkit.safety.gate import DialogPreview, SafetyResult


def test_can_show_dialog_returns_false_outside_macos() -> None:
    assert can_show_dialog(platform="linux") is False


def test_show_confirmation_dialog_denies_when_preflight_fails() -> None:
    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="  hello \n world "),
        platform="linux",
    )

    assert result == SafetyResult(False, "dialog_preflight_failed")


def test_show_confirmation_dialog_allows_when_runner_succeeds() -> None:
    commands: list[list[str]] = []

    def runner(command: list[str]) -> int:
        commands.append(command)
        return 0

    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="  hello \n world "),
        platform="darwin",
        session_check=lambda: True,
        smoke_test=lambda: True,
        runner=runner,
    )

    assert result == SafetyResult(True, "dialog_approved")
    assert commands[0][0] == OSASCRIPT_PATH
    assert any("hello world" in part for part in commands[0])


def test_show_confirmation_dialog_denies_when_user_cancels() -> None:
    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="Body"),
        platform="darwin",
        session_check=lambda: True,
        smoke_test=lambda: True,
        runner=lambda command: 1,
    )

    assert result == SafetyResult(False, "dialog_cancelled")


def test_show_confirmation_dialog_denies_when_runner_raises_os_error() -> None:
    def runner(command: list[str]) -> int:
        raise OSError("osascript unavailable")

    result = show_confirmation_dialog(
        DialogPreview(title="Confirm", body="Body"),
        platform="darwin",
        session_check=lambda: True,
        smoke_test=lambda: True,
        runner=runner,
    )

    assert result == SafetyResult(False, "dialog_cancelled")


def test_run_dialog_command_handles_timeout(monkeypatch) -> None:
    from ms365_toolkit.safety import dialog

    def fake_run(*args, **kwargs):
        raise subprocess.TimeoutExpired(cmd=["/usr/bin/osascript"], timeout=1)

    monkeypatch.setattr(subprocess, "run", fake_run)

    assert dialog._run_dialog_command([OSASCRIPT_PATH, "-e", 'return "ok"']) == 1
