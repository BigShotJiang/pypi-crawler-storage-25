from __future__ import annotations

from types import SimpleNamespace
from typing import Any

from ms365_toolkit.cli import main


def test_cli_usage_summary_logs_usage_event(monkeypatch, capsys) -> None:
    events: list[Any] = []

    class FakeLogger:
        def log(self, event: Any) -> None:
            events.append(event)

    monkeypatch.setattr(
        "ms365_toolkit.cli.load_config",
        lambda profile: SimpleNamespace(profile=profile),
    )
    monkeypatch.setattr("ms365_toolkit.cli.usage.read_usage_events", lambda profile, days: [])
    monkeypatch.setattr(
        "ms365_toolkit.cli.UsageLogger.for_profile",
        lambda profile: FakeLogger(),
    )

    exit_code = main(["usage", "summary"])

    assert exit_code == 0
    assert "Events: 0" in capsys.readouterr().out
    assert len(events) == 1
    assert events[0].surface == "cli"
    assert events[0].name == "usage:summary"
    assert events[0].success is True


def test_cli_usage_slow_prints_slowest_events(monkeypatch, capsys) -> None:
    events: list[Any] = []

    class FakeLogger:
        def log(self, event: Any) -> None:
            events.append(event)

    monkeypatch.setattr(
        "ms365_toolkit.cli.load_config",
        lambda profile: SimpleNamespace(profile=profile),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.usage.read_usage_events",
        lambda profile, days: [
            {
                "timestamp": "2026-04-18T00:00:00Z",
                "surface": "mcp",
                "name": "list_events",
                "duration_ms": 42,
                "result_size_chars": 1200,
                "result_item_count": 3,
                "truncated": True,
                "success": True,
            }
        ],
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.UsageLogger.for_profile",
        lambda profile: FakeLogger(),
    )

    exit_code = main(["usage", "slow", "--top", "1"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "mcp:list_events duration=42ms chars=1200 items=3 truncated=True success=True" in output
    assert len(events) == 1
    assert events[0].name == "usage:slow"


def test_cli_usage_health_prints_actionable_report(monkeypatch, capsys) -> None:
    events: list[Any] = []

    class FakeLogger:
        def log(self, event: Any) -> None:
            events.append(event)

    monkeypatch.setattr(
        "ms365_toolkit.cli.load_config",
        lambda profile: SimpleNamespace(profile=profile),
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.usage.read_usage_events",
        lambda profile, days: [
            {
                "timestamp": "2026-04-18T00:00:00Z",
                "surface": "mcp",
                "name": "read_meeting_notes",
                "duration_ms": 500,
                "success": False,
                "error_type": "InsufficientScopesError",
                "error_code": "insufficient_scopes:OnlineMeetingAiInsight.Read.All",
                "result_size_chars": 0,
                "graph_endpoint_counts": {"GET /onlineMeetings": 1},
                "graph_endpoint_duration_ms": {"GET /onlineMeetings": 300},
            }
        ],
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.UsageLogger.for_profile",
        lambda profile: FakeLogger(),
    )

    exit_code = main(["usage", "health", "--top", "1"])

    output = capsys.readouterr().out
    assert exit_code == 0
    assert "Failure hotspots:" in output
    assert "mcp:read_meeting_notes InsufficientScopesError" in output
    assert "Graph hotspots:" in output
    assert "GET /onlineMeetings count=1 duration=300ms" in output
    assert len(events) == 1
    assert events[0].name == "usage:health"


def test_cli_usage_logging_failure_is_non_fatal(monkeypatch, capsys) -> None:
    class FailingLogger:
        def log(self, event: Any) -> None:
            raise PermissionError("readonly")

    monkeypatch.setattr(
        "ms365_toolkit.cli.load_config",
        lambda profile: SimpleNamespace(profile=profile),
    )
    monkeypatch.setattr("ms365_toolkit.cli.usage.read_usage_events", lambda profile, days: [])
    monkeypatch.setattr(
        "ms365_toolkit.cli.UsageLogger.for_profile",
        lambda profile: FailingLogger(),
    )

    exit_code = main(["usage", "summary"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "Events: 0" in captured.out
    assert "Warning: usage logging failed" in captured.err
