from __future__ import annotations

import io
import json
from typing import TYPE_CHECKING, Any
from urllib.error import HTTPError

import pytest

from ms365_toolkit.client.exceptions import AuthenticationError, GraphAPIError, RateLimitedError
from ms365_toolkit.client.graph import GraphClient, build_odata_query
from ms365_toolkit.config.loader import load_config, write_config_text
from ms365_toolkit.usage import start_usage_recording, stop_usage_recording

if TYPE_CHECKING:
    from pathlib import Path


def test_build_odata_query_skips_none_and_serializes_collections() -> None:
    query = build_odata_query({"$top": 10, "$select": ["id", "subject"], "$filter": None})

    assert "$top=10" in query
    assert "$select=id,subject" in query
    assert "$filter" not in query


def test_graph_client_builds_me_url_and_authorization_header(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["auth"] = req.headers["Authorization"]
        captured["timeout"] = timeout
        return _response({"value": []})

    client = GraphClient(config=_config(tmp_path), token="token-123", transport=transport)

    response = client.get("messages", query={"$top": 5})

    assert response == {"value": []}
    assert captured["url"] == "https://graph.microsoft.com/v1.0/me/messages?$top=5"
    assert captured["auth"] == "Bearer token-123"
    assert captured["timeout"] == 30.0


def test_graph_client_builds_users_endpoint_url(tmp_path: Path) -> None:
    config = _config(
        tmp_path,
        extra_replacements=(
            ('endpoint = "me"', 'endpoint = "users"'),
            ('user_principal_name = ""', 'user_principal_name = "leader@example.com"'),
        ),
    )
    client = GraphClient(config=config, token="token", transport=lambda req, timeout: _response({}))

    client.get("messages")

    assert client.build_url("messages") == (
        "https://graph.microsoft.com/v1.0/users/leader%40example.com/messages"
    )


def test_graph_client_quotes_users_endpoint_path_segment(tmp_path: Path) -> None:
    config = _config(
        tmp_path,
        extra_replacements=(
            ('endpoint = "me"', 'endpoint = "users"'),
            ('user_principal_name = ""', 'user_principal_name = "leader/team@example.com"'),
        ),
    )
    client = GraphClient(config=config, token="token", transport=lambda req, timeout: _response({}))

    assert client.build_url("messages") == (
        "https://graph.microsoft.com/v1.0/users/leader%2Fteam%40example.com/messages"
    )


def test_graph_client_allows_absolute_graph_url(tmp_path: Path) -> None:
    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=lambda req, timeout: _response({}),
    )

    assert client.build_url("https://graph.microsoft.com/v1.0/me/messages") == (
        "https://graph.microsoft.com/v1.0/me/messages"
    )


def test_graph_client_allows_team_paths_without_me_prefix(tmp_path: Path) -> None:
    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=lambda req, timeout: _response({}),
    )

    assert client.build_url("teams/team-1/channels") == (
        "https://graph.microsoft.com/v1.0/teams/team-1/channels"
    )


def test_graph_client_allows_share_and_drive_paths_without_me_prefix(tmp_path: Path) -> None:
    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=lambda req, timeout: _response({}),
    )

    assert client.build_url("shares/share-1/driveItem") == (
        "https://graph.microsoft.com/v1.0/shares/share-1/driveItem"
    )
    assert client.build_url("drives/drive-1/items/item-1/content") == (
        "https://graph.microsoft.com/v1.0/drives/drive-1/items/item-1/content"
    )


def test_graph_client_rejects_absolute_non_graph_url(tmp_path: Path) -> None:
    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=lambda req, timeout: _response({}),
    )

    with pytest.raises(ValueError, match="absolute Graph URL must use an allowed Graph host"):
        client.build_url("https://example.com/v1.0/me/messages")


def test_graph_client_retries_503_then_succeeds(tmp_path: Path) -> None:
    calls = {"count": 0}
    sleeps: list[float] = []

    def transport(req: Any, timeout: float) -> Any:
        calls["count"] += 1
        if calls["count"] == 1:
            raise HTTPError(
                req.full_url,
                503,
                "Service Unavailable",
                {"Retry-After": "2"},
                io.BytesIO(
                    json.dumps({"error": {"code": "Unavailable", "message": "Try later"}}).encode()
                ),
            )
        return _response({"ok": True})

    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=transport,
        sleeper=sleeps.append,
    )

    assert client.get("messages") == {"ok": True}
    assert calls["count"] == 2
    assert sleeps == [2]


def test_graph_client_records_sanitized_usage_metrics(tmp_path: Path) -> None:
    token = start_usage_recording()

    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=lambda req, timeout: _response({"value": []}),
    )

    client.get("messages/message-123/attachments", query={"$select": "name"})

    metrics = stop_usage_recording(token)

    assert metrics["graph_request_count"] == 1
    assert metrics["graph_status_counts"] == {"2xx": 1}
    assert metrics["graph_endpoint_counts"] == {
        "GET /me/messages/{id}/attachments": 1
    }


def test_graph_client_raises_authentication_error_on_401(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(req.full_url, 401, "Unauthorized", {}, io.BytesIO(b""))

    client = GraphClient(config=_config(tmp_path), token="token", transport=transport)

    with pytest.raises(AuthenticationError):
        client.get("messages")


def test_graph_client_raises_rate_limited_error_after_retries_exhausted(tmp_path: Path) -> None:
    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            429,
            "Too Many Requests",
            {"Retry-After": "7"},
            io.BytesIO(b""),
        )

    client = GraphClient(
        config=_config(tmp_path),
        token="token",
        transport=transport,
        sleeper=lambda seconds: None,
        max_retries=0,
    )

    with pytest.raises(RateLimitedError) as exc_info:
        client.get("messages")

    assert exc_info.value.retry_after == 7


def test_graph_client_raises_graph_api_error_with_json_message(tmp_path: Path) -> None:
    token = start_usage_recording()

    def transport(req: Any, timeout: float) -> Any:
        raise HTTPError(
            req.full_url,
            404,
            "Not Found",
            {},
            io.BytesIO(
                json.dumps({"error": {"code": "ErrorItemNotFound", "message": "Missing"}}).encode()
            ),
        )

    client = GraphClient(config=_config(tmp_path), token="token", transport=transport)

    with pytest.raises(GraphAPIError) as exc_info:
        client.get("messages")

    assert exc_info.value.status_code == 404
    assert exc_info.value.error_code == "ErrorItemNotFound"
    assert exc_info.value.message == "Missing"
    metrics = stop_usage_recording(token)
    assert metrics["graph_status_counts"] == {"404:ErrorItemNotFound": 1}
    assert metrics["graph_endpoint_counts"] == {"GET /me/messages": 1}


class _FakeResponse:
    def __init__(self, payload: dict[str, Any]) -> None:
        self._payload = json.dumps(payload).encode("utf-8")

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload


def _response(payload: dict[str, Any]) -> _FakeResponse:
    return _FakeResponse(payload)


def _config(tmp_path: Path, extra_replacements: tuple[tuple[str, str], ...] = ()) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    for old, new in extra_replacements:
        content = content.replace(old, new)
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
