from __future__ import annotations

import json
from argparse import Namespace
from http.server import ThreadingHTTPServer
from threading import Thread
from typing import TYPE_CHECKING
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from ms365_toolkit.cli.labeling_web import (
    _index_html,
    _is_loopback_host,
    _make_handler,
    _records_payload,
    launch_label_ui_command,
)
from ms365_toolkit.intelligence.labels import ThreadLabelRecord, ThreadLabels

if TYPE_CHECKING:
    import pytest


def test_records_payload_serializes_labels() -> None:
    payload = _records_payload([_record()])

    assert len(payload["records"]) == 1
    record = payload["records"][0]
    assert isinstance(record, dict)
    assert record["thread_id"] == "conv-1"
    assert isinstance(record["labels"], dict)
    assert record["labels"]["thread_class"] == "decision_request"


def test_index_html_contains_label_form() -> None:
    html = _index_html()

    assert "Thread Labels" in html
    assert "Save + Next" in html
    assert "approval_request" in html
    assert "strategic_update" in html
    assert 'meta name="csrf-token"' in html
    assert "X-CSRF-Token" in html


def test_is_loopback_host_accepts_local_only_hosts() -> None:
    assert _is_loopback_host("127.0.0.1") is True
    assert _is_loopback_host("localhost") is True
    assert _is_loopback_host("::1") is True


def test_launch_label_ui_command_rejects_non_loopback_host(
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = launch_label_ui_command(
        Namespace(profile="default", host="0.0.0.0", port=8765, no_open=True),
        _config(),
    )

    assert exit_code == 1
    assert "loopback hosts only" in capsys.readouterr().out


def test_records_endpoint_rejects_non_positive_top(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling_web._labels_path",
        lambda profile: tmp_path / "labels.jsonl",
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling_web.list_label_candidates",
        lambda labels_path, *, status, top: [],
    )

    with _TestServer("default") as base_url:
        try:
            urlopen(f"{base_url}/api/records?top=-1")
        except HTTPError as error:
            assert error.code == 400
            payload = json.loads(error.read().decode("utf-8"))
        else:
            raise AssertionError("Expected HTTP 400 for negative top")

    assert payload["error"] == "top must be between 1 and 500"


def test_records_endpoint_rejects_invalid_top(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling_web._labels_path",
        lambda profile: tmp_path / "labels.jsonl",
    )
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling_web.list_label_candidates",
        lambda labels_path, *, status, top: [],
    )

    with _TestServer("default") as base_url:
        try:
            urlopen(f"{base_url}/api/records?top=abc")
        except HTTPError as error:
            assert error.code == 400
            payload = json.loads(error.read().decode("utf-8"))
        else:
            raise AssertionError("Expected HTTP 400 for invalid top")

    assert payload["error"] == "top must be an integer between 1 and 500"


def test_label_endpoint_rejects_missing_csrf_token(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    monkeypatch.setattr(
        "ms365_toolkit.cli.labeling_web._labels_path",
        lambda profile: tmp_path / "labels.jsonl",
    )

    with _TestServer("default", csrf_token="known-token") as base_url:
        request = Request(
            f"{base_url}/api/records/conv-1/label",
            data=json.dumps(
                {
                    "thread_class": "decision_request",
                    "action_needed": "yes",
                    "urgency": "high",
                    "acted_by_you": "replied",
                    "confidence": 0.9,
                }
            ).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            urlopen(request)
        except HTTPError as error:
            assert error.code == 403
            payload = json.loads(error.read().decode("utf-8"))
        else:
            raise AssertionError("Expected HTTP 403 for missing CSRF token")

    assert payload["error"] == "Invalid CSRF token"


def _record() -> ThreadLabelRecord:
    return ThreadLabelRecord(
        thread_id="conv-1",
        message_id="msg-1",
        subject="Subject",
        sender="sender@example.com",
        sender_type="human_internal",
        received_at="2026-03-14T12:00:00+00:00",
        body_preview="Preview",
        body_content="Body",
        thread_size=1,
        cluster_size=1,
        labels=ThreadLabels(
            thread_class="decision_request",
            action_needed="yes",
            urgency="high",
            acted_by_you="replied",
            confidence=0.9,
        ),
        notes="note",
    )


def _config():
    class StubConfig:
        pass

    return StubConfig()


class _TestServer:
    def __init__(self, profile: str, *, csrf_token: str = "test-csrf") -> None:
        self._profile = profile
        self._csrf_token = csrf_token
        self._server: ThreadingHTTPServer | None = None
        self._thread: Thread | None = None

    def __enter__(self) -> str:
        self._server = ThreadingHTTPServer(
            ("127.0.0.1", 0),
            _make_handler(self._profile, csrf_token=self._csrf_token),
        )
        self._thread = Thread(target=self._server.handle_request)
        self._thread.start()
        return f"http://127.0.0.1:{self._server.server_port}"

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._thread is not None:
            self._thread.join(timeout=5)
        if self._server is not None:
            self._server.server_close()
