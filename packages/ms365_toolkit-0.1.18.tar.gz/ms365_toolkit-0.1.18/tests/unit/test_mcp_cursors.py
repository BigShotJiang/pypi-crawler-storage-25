from __future__ import annotations

import pytest

from ms365_toolkit.mcp.cursors import (
    decode_offset_cursor,
    decode_page_cursor,
    encode_offset_cursor,
    encode_page_cursor,
)


def test_page_cursor_round_trips_context() -> None:
    cursor = encode_page_cursor(
        "list_chat_messages",
        "https://graph.microsoft.com/v1.0/me/chats/chat-1/messages?$skiptoken=abc",
        context={"chat_id": "chat-1"},
    )

    decoded = decode_page_cursor("list_chat_messages", cursor or "")

    assert decoded.next_link.endswith("$skiptoken=abc")
    assert decoded.context == {"chat_id": "chat-1"}


def test_page_cursor_rejects_malformed_value() -> None:
    with pytest.raises(ValueError, match="cursor is invalid"):
        decode_page_cursor("list_inbox", "not a cursor")


def test_page_cursor_rejects_wrong_tool() -> None:
    cursor = encode_page_cursor("list_inbox", "https://graph.microsoft.com/v1.0/me/messages")

    with pytest.raises(ValueError, match="cursor does not match this tool"):
        decode_page_cursor("search_emails", cursor or "")


def test_offset_cursor_round_trips_context() -> None:
    cursor = encode_offset_cursor(
        "search_teams_messages",
        25,
        context={"query": "budget owner"},
    )

    decoded = decode_offset_cursor("search_teams_messages", cursor or "")

    assert decoded.offset == 25
    assert decoded.context == {"query": "budget owner"}


def test_offset_cursor_rejects_wrong_tool() -> None:
    cursor = encode_offset_cursor("search_teams_messages", 25)

    with pytest.raises(ValueError, match="cursor does not match this tool"):
        decode_offset_cursor("list_inbox", cursor or "")
