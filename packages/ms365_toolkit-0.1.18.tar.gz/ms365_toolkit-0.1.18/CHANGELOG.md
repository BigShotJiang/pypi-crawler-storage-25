# Changelog

## Unreleased

## 0.1.18 - 2026-04-25

- Added diagnostics-focused usage analytics with sanitized Graph endpoint metrics, safe error classification, fail-open logging, and `ms365-toolkit usage health`.
- Improved high-cost paths from usage telemetry: meeting transcript defaults now return smaller result sets, explicit transcript reads fetch by ID directly, MCP Teams search offsets use Microsoft Search pagination directly, and email SharePoint/OneDrive batch downloads dedupe resolved files before downloading.
- Added `download_email_share_links` for CLI and MCP to download all SharePoint/OneDrive files linked from an email body and write supported text extraction sidecars.

## 0.1.17 - 2026-04-23

- Fixed stale-version startup checks so an unwritable local status cache cannot prevent the MCP server from starting.

## 0.1.16 - 2026-04-23

- Added email-body SharePoint/OneDrive link discovery and download support, including `list_email_share_links`, `download_share_link`, `auth login --share-links`, and DOCX text extraction sidecars.
- Added opt-in live MCP stale-version checks at startup and cached `version_warning` fields in tool responses when a running MCP is stale.
- Hardened profile path validation, delegated-user Graph URL construction, guarded-write safety checks, local label UI CSRF protection, dialog invocation, and rate-limit SQL queries.
- Added strict mypy, Bandit, and dependency-audit cleanup for the current codebase.
- Updated dependency constraints to avoid vulnerable `requests` and `pygments` versions.

## 0.1.15 - 2026-04-21

- Added MCP cursor continuation for `search_teams_messages` using Microsoft Search `from` / `size` pagination while keeping local derived Teams searches bounded.
- Added an opt-in real-world MCP smoke script that launches the local stdio server, checks real read-only Graph tools, and prints redacted pass/fail/skip output.
- Added unit coverage for smoke redaction, compact-response validation, continuation calls, optional skips, and exit-code behavior.
- Added MIT licensing, security reporting guidance, contribution guidance, and public package metadata.
- Documented local-first security/privacy expectations and public beta setup guidance.

## 0.1.14 - 2026-04-19

- Added opaque MCP `cursor` / `next_cursor` continuation for Graph-backed email, calendar, Teams chat, Teams team/channel, and channel reply list/search tools.
- Added paged client methods that preserve existing CLI list-returning behavior while exposing Graph `@odata.nextLink` to the MCP layer.
- Kept local derived searches and Microsoft Search API pagination out of this release because they require different cursor semantics.

## 0.1.13 - 2026-04-18

- Added `offset` continuation support to compact MCP list/search tools so callers can page through results after `max_chars` truncation.
- Added `next_offset` and warnings to truncated compact MCP responses.
- Kept full read/detail tools unchanged.

## 0.1.12 - 2026-04-18

- Added compact MCP response budgets for Teams and calendar list/search tools to reduce token pressure.
- Added `ms365-toolkit usage slow` to identify slow tools and large MCP responses from local usage analytics.
- Kept full read/detail tools unchanged so agents can fetch complete records after summary discovery.

## 0.1.11 - 2026-04-18

- Added local-only usage analytics for CLI and MCP calls, including durations, success/failure counts, result-size metrics, truncation counts, and observed toolkit versions.
- Added `ms365-toolkit version`, `ms365-toolkit version --check`, and `ms365-toolkit doctor` for explicit stale-version detection and update guidance.
- Added MCP `get_toolkit_status` for Codex/Claude sessions to inspect installed and latest toolkit versions.
- Added opt-in cache-only MCP startup stale warnings via `MS365_TOOLKIT_WARN_STALE=1`.
- Documented `ms365-toolkit-mcp@latest` as the recommended MCP registration path and kept pinned registration as a reproducible fallback.
- Clarified that existing pinned Codex/Claude registrations should be rerun with `@latest` and active sessions restarted.
