# ms365-toolkit - Build Plan

This is the current working roadmap for `ms365-toolkit`. It reflects the shipped
state after the `0.1.15` public-readiness release and the follow-on hardening
pass, and replaces the older phase-by-phase implementation dump.

## Current Status

Shipped capabilities:

- Device-code auth with read, write, Teams channel-message, Teams file, meeting transcript, and meeting notes scopes.
- Core Graph clients for email, calendar, Teams chats, Teams channels, Teams files, meeting transcripts, and Copilot meeting notes.
- CLI tools for auth, email/calendar/Teams reads, attachment extraction/downloads, local mailbox indexing, triage, morning brief, labeling, guarded email draft/send, usage analytics, version checks, and doctor output.
- Local stdio MCP server with installable `ms365-toolkit-mcp` wrapper package.
- MCP tools for email, calendar, Teams chats/channels, Teams files, meeting transcripts, meeting notes, guarded email drafts/replies/sends, usage-safe compact summaries, `max_chars` budgets, `offset`/`next_offset` continuation, Graph-backed `cursor`/`next_cursor` continuation, and Microsoft Search `cursor` continuation for global Teams message search.
- Guarded email write flow for creating drafts, creating reply drafts, and sending drafts with hash verification.
- Safety primitives for domain allowlists, folder allowlists, rate limits, audit logging, canonical hashes, dialog checks, and SafetyGate orchestration.
- Local-only usage analytics for CLI and MCP calls, including duration, result size, truncation, error, and version metrics.
- Version-status checks and `@latest` MCP launcher guidance for stale-version detection.
- CI and trusted-publishing release workflows for root and MCP wrapper packages.
- Live read-only stdio MCP validation against real Microsoft Graph data for compact response continuation.
- Opt-in real-world MCP smoke script with redacted pass/fail/skip output for core and tiered optional Graph checks.
- Strict mypy, Bandit, unit-test, dependency-audit, and read-only MCP smoke baselines are clean.
- Profile path validation, delegated-user Graph URL quoting, local label UI CSRF protection, fixed rate-limit SQL, and hardened dialog invocation are in place.

Known limitations:

- Cursor support is intentionally limited to Graph-backed list/search tools that return `@odata.nextLink` plus Microsoft Search API `search_teams_messages`.
- Local derived searches remain bounded first-page convenience filters.
- MCP does not yet expose intelligence tools such as triage, morning brief, or day overview.
- Email write support is limited to draft, reply draft, and send draft.
- Calendar write support is not implemented.
- Config/profile CLI workflow is incomplete.
- The adapter package is present but does not yet provide usable downstream provider implementations.
- CI does not yet run strict mypy, Bandit, pip-audit, or the read-only MCP smoke script.

## Operating Principles

- Config loading must stay offline-safe: no Graph API calls during parse or validation.
- Never hardcode secrets, tokens, client secrets, or mailbox-derived private data.
- Read/list/search tools should return compact summaries first; full payload hydration belongs in read/get tools.
- Response-size controls must be explicit and agent-friendly: use `max_chars`, `truncated`, and continuation metadata instead of returning bulk JSON.
- Write operations must require a write token, a configured SafetyGate, allowlist checks, rate-limit checks, hash binding, and audit logging.
- Rate limits are charged once per externally invoked user-visible write action, not once per internal sub-step.
- Audit logs and usage analytics must avoid email bodies, transcript text, tokens, cleartext recipients, and other sensitive content.
- Release changes that affect MCP behavior must update `README.md`, `CHANGELOG.md`, package versions, and the MCP install/update guidance.
- Public-facing changes should keep `ruff`, strict mypy, Bandit, dependency audit, unit tests, and read-only MCP smoke validation green.

## Backlog

1. MCP intelligence tools

   Expose existing triage, morning brief, and day overview logic through MCP with compact outputs and safe full-read follow-up paths.

2. Additional guarded email actions

   Add forward, move, flag, and bulk move/flag operations with folder allowlist checks, bulk confirmation, rate limits, hash/audit coverage where applicable, and MCP/CLI surfaces.

3. Calendar write tools

   Add create event, update event, and respond to event with calendar-specific safety previews, invite guards, rate limits, and audit logging.

4. Config and profile CLI commands

   Add `config init`, `config validate`, `config show`, `profile list`, `profile switch`, and `serve` so setup and troubleshooting are self-service from the CLI.

5. Adapter integration

   Implement read-only email and calendar provider adapters under `src/ms365_toolkit/adapter/`, then validate them in the downstream integration repo.

6. Adversarial safety suite

   Add explicit prompt-injection and safety-bypass tests for malicious email/calendar content, domain spoofing, folder escape, hash mismatch, rate-limit concurrency, config TOCTOU, and platform/dialog bypass attempts.

7. CI security gates

   Add strict mypy, Bandit, and dependency audit to GitHub Actions once runtime is acceptable for public PRs.

8. CI maintenance

    Resolve GitHub Actions Node 20 deprecation warnings before GitHub-hosted runners force Node 24 defaults.

## Next Recommended Work

Next technical priority: MCP intelligence tools.

Why:

- Triage, morning brief, and day overview already exist in CLI/intelligence code but are not available to Codex/Claude through MCP.
- Agents can use compact discovery plus full read tools, so intelligence summaries are now safer to expose.
- It is the next highest user-facing productivity improvement after pagination and smoke validation.

Recommended shape:

- Add compact MCP tools for triage, morning brief, and day overview.
- Keep outputs summary-first and avoid exposing full email bodies or transcript text.
- Add unit tests for scoring/output shape and extend smoke validation only if safe redacted assertions are possible.

## Validation Checklist

Before committing implementation work:

- Run `git diff --check`.
- Run `uv run ruff check src tests scripts`.
- Run `uv run mypy src/ms365_toolkit/`.
- Run `uv run pytest -q tests/unit`.
- Run `uvx bandit -q -r src scripts`.
- Run `uv run --with pip-audit pip-audit --local`.
- Run `uv run python scripts/check_release_version.py` when package versions change.
- Build both wheels when package or MCP wrapper metadata changes:
  - `uv build --wheel`
  - `uv build --wheel --directory packages/ms365-toolkit-mcp`
- For MCP behavior changes, run `uv run --extra mcp python scripts/smoke_mcp.py --profile default`.
- Update `README.md`, `CHANGELOG.md`, and version pins for published user-facing changes.
