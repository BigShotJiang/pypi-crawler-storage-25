# Security Policy

## Reporting Vulnerabilities

Please report suspected vulnerabilities privately by opening a GitHub security advisory or by contacting the maintainer listed in `pyproject.toml`.

Do not include real access tokens, refresh tokens, mailbox data, transcript text, message IDs, or private tenant identifiers in public issues.

## Supported Versions

Security fixes are expected to target the latest published version. Users should keep MCP registrations on `ms365-toolkit-mcp@latest` or rerun the pinned install command after a release.

## Security Model

`ms365-toolkit` is local-first tooling for Microsoft 365 delegated access:

- Tokens and profile configuration are stored locally under the active user profile.
- Users configure their own Microsoft Entra public-client app registration.
- No client secret is required or supported for normal device-code auth.
- MCP and CLI tools use delegated Microsoft Graph permissions granted by the tenant.
- Guarded write actions require an explicit write token, configured safety gates, allowlist checks, rate limits, and audit logging.
- Profile names are treated as local path components and must be simple names, not paths.
- The local labeling UI binds to loopback hosts only and requires a per-server CSRF token for label updates.

## Data Handling

The toolkit should not log email bodies, transcript text, cleartext recipients, access tokens, refresh tokens, or full Graph IDs in usage analytics. Real-world smoke tests print only redacted pass/fail/skip metadata.

Local profile directories, token caches, mailbox indexes, downloaded files, and generated reports can contain sensitive data. Do not commit or share them.

Before public-facing changes, run the local security checks documented in `CONTRIBUTING.md`.
