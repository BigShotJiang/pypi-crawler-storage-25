"""BacktestReport — tick-level curves, scalar summaries, plots, and HTML export."""
from __future__ import annotations

import json
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING

import pandas as pd

from gnomepy.reporting.metrics import Curves, build_curves, compute_sharpe

if TYPE_CHECKING:
    import plotly.graph_objects as go
    from gnomepy.java.recorder import BacktestResults


def _with_mid_price(market_df: pd.DataFrame) -> pd.DataFrame:
    """Ensure market_df has a ``mid_price`` column."""
    if market_df is None or market_df.empty:
        return market_df
    if "mid_price" in market_df.columns:
        return market_df
    if "bid_price_0" in market_df.columns and "ask_price_0" in market_df.columns:
        df = market_df.copy()
        df["mid_price"] = (
            df["bid_price_0"].astype(float) + df["ask_price_0"].astype(float)
        ) / 2.0
        return df
    return market_df


def _config_from_metadata(metadata) -> dict:
    """Build a config dict from BacktestMetadata."""
    config: dict = {}
    if metadata.strategy is not None:
        if ":" in metadata.strategy:
            config["strategy"] = metadata.strategy
        else:
            config["java_strategy"] = metadata.strategy
    if metadata.start_date is not None:
        config["start_date"] = metadata.start_date
    if metadata.end_date is not None:
        config["end_date"] = metadata.end_date
    if metadata.config_path is not None:
        config["config_path"] = metadata.config_path
    if metadata.preset_name is not None:
        config["preset_name"] = metadata.preset_name
    if metadata.backtest_id is not None:
        config["backtest_id"] = metadata.backtest_id
    if metadata.config is not None:
        config.update(metadata.config)
    return config


def _extract_config(backtest) -> dict:
    """Build a config dict from a Backtest object's attributes."""
    config: dict = {}

    strategy = getattr(backtest, "_strategy", None)
    if strategy is not None:
        if isinstance(strategy, str):
            if ":" in strategy:
                config["strategy"] = strategy
            else:
                config["java_strategy"] = strategy
        else:
            cls = type(strategy)
            config["strategy"] = f"{cls.__module__}:{cls.__name__}"

    start = getattr(backtest, "_start_date", None)
    if start is not None:
        config["start_date"] = str(start)

    end = getattr(backtest, "_end_date", None)
    if end is not None:
        config["end_date"] = str(end)

    raw_config = getattr(backtest, "_config", None)
    if isinstance(raw_config, str):
        config["config_path"] = raw_config

    return config


class BacktestReport:
    """Wraps ``BacktestResults`` and exposes tick-level curves plus scalar summaries."""

    def __init__(
        self,
        results: "BacktestResults",
        start_date: pd.Timestamp | str | None = None,
        end_date: pd.Timestamp | str | None = None,
        config: dict | None = None,
        backtest: "Backtest | None" = None,
    ):
        self._results = results
        if config is not None:
            self._config = config
        elif backtest is not None and hasattr(backtest, "_preset_config"):
            self._config = backtest._preset_config
        elif backtest is not None:
            self._config = _extract_config(backtest)
        elif results.metadata is not None:
            self._config = _config_from_metadata(results.metadata)
        else:
            self._config = None
        self._market_df: pd.DataFrame = _with_mid_price(results.market_records_df())
        self._exec_df: pd.DataFrame = results.fills_df()
        self._intent_df: pd.DataFrame = results.intent_records_df()

        if start_date is not None or end_date is not None:
            start = pd.Timestamp(start_date) if start_date is not None else self._market_df.index.min()
            end = pd.Timestamp(end_date) if end_date is not None else self._market_df.index.max()
            self._market_df = self._market_df.loc[start:end]
            if not self._exec_df.empty:
                self._exec_df = self._exec_df.loc[start:end]
            if not self._intent_df.empty:
                self._intent_df = self._intent_df.loc[start:end]

    @classmethod
    def from_dataframes(
        cls,
        market_df: pd.DataFrame,
        exec_df: pd.DataFrame,
        intent_df: pd.DataFrame | None = None,
        config: dict | None = None,
    ) -> "BacktestReport":
        """Create a report from pre-loaded DataFrames (e.g. from parquet files)."""
        obj = object.__new__(cls)
        obj._results = None
        obj._config = config
        obj._market_df = _with_mid_price(market_df)
        obj._exec_df = exec_df
        obj._intent_df = intent_df if intent_df is not None else pd.DataFrame()
        return obj

    @cached_property
    def _curves(self) -> Curves:
        return build_curves(self._market_df, self._exec_df)

    # -- Total curves --------------------------------------------------------

    @property
    def pnl_curve(self) -> pd.Series:
        return self._curves.pnl

    @property
    def position_curve(self) -> pd.Series:
        return self._curves.position

    @property
    def fees_curve(self) -> pd.Series:
        return self._curves.fees

    @property
    def volume_curve(self) -> pd.Series:
        return self._curves.volume

    # -- Per-symbol breakdowns -----------------------------------------------

    @property
    def pnl_by_symbol(self) -> pd.DataFrame:
        return self._curves.pnl_by_symbol

    @property
    def position_by_symbol(self) -> pd.DataFrame:
        return self._curves.position_by_symbol

    @property
    def fees_by_symbol(self) -> pd.DataFrame:
        return self._curves.fees_by_symbol

    @property
    def volume_by_symbol(self) -> pd.DataFrame:
        return self._curves.volume_by_symbol

    @property
    def notional_curve(self) -> pd.Series:
        return self._curves.notional

    @property
    def notional_by_symbol(self) -> pd.DataFrame:
        return self._curves.notional_by_symbol

    # -- Metadata ------------------------------------------------------------

    @property
    def metadata(self):
        """BacktestMetadata from the results (None if not available)."""
        return self._results.metadata

    # -- Fills ---------------------------------------------------------------

    @property
    def fills(self) -> pd.DataFrame:
        return self._curves.fills

    # -- Sharpe --------------------------------------------------------------

    def sharpe_metrics(self, bar: str = "10s", n_buckets: int = 5) -> dict:
        """Compute Sharpe, Sortino, and per-bucket stability metrics."""
        return compute_sharpe(self.pnl_curve, bar=bar, n_buckets=n_buckets)

    # -- Scalars -------------------------------------------------------------

    def summary(self) -> dict:
        c = self._curves
        duration = 0.0
        if not self._market_df.empty:
            duration = float(
                (self._market_df.index.max() - self._market_df.index.min()).total_seconds()
            )

        final_pnl = float(c.pnl.iloc[-1]) if not c.pnl.empty else 0.0
        total_fees = float(c.fees.iloc[-1]) if not c.fees.empty else 0.0
        total_volume = float(c.volume.iloc[-1]) if not c.volume.empty else 0.0
        total_notional = float(c.notional.iloc[-1]) if not c.notional.empty else 0.0
        final_position = float(c.position.iloc[-1]) if not c.position.empty else 0.0

        if not c.pnl_by_symbol.empty:
            final_pnl_by_symbol = {str(col): float(c.pnl_by_symbol[col].iloc[-1]) for col in c.pnl_by_symbol.columns}
        else:
            final_pnl_by_symbol = {}

        if not c.position_by_symbol.empty:
            final_positions = {str(col): float(c.position_by_symbol[col].iloc[-1]) for col in c.position_by_symbol.columns}
        else:
            final_positions = {}

        sharpe = self.sharpe_metrics()

        return {
            "backtest_id": self._results.backtest_id if self._results else None,
            "duration_seconds": duration,
            "market_record_count": int(self._results.market_record_count) if self._results else len(self._market_df),
            "intent_record_count": int(self._results.intent_record_count) if self._results else len(self._intent_df),
            "fill_count": c.fill_count,
            "total_volume": total_volume,
            "total_notional": total_notional,
            "final_position": final_position,
            "final_positions": final_positions,
            "total_fees": total_fees,
            "final_pnl": final_pnl,
            "final_pnl_by_symbol": final_pnl_by_symbol,
            "sharpe": sharpe["sharpe"],
            "sortino": sharpe["sortino"],
            "sharpe_std": sharpe["sharpe_std"],
            "pct_positive_buckets": sharpe["pct_positive_buckets"],
            "warnings": self._results.metadata.warnings if self._results and self._results.metadata else [],
        }

    def summary_df(self) -> pd.Series:
        s = self.summary()
        flat = {k: v for k, v in s.items() if not isinstance(v, dict)}
        return pd.Series(flat, name="backtest_report")

    # -- Plots ---------------------------------------------------------------

    def plot_pnl(self, **kwargs) -> "go.Figure":
        """PnL + drawdown chart with mid overlay and fill markers."""
        from gnomepy.reporting.plots import plot_pnl
        return plot_pnl(self, **kwargs)

    def plot_position(self, **kwargs) -> "go.Figure":
        """Position, cumulative fees, and cumulative volume subplots."""
        from gnomepy.reporting.plots import plot_position
        return plot_position(self, **kwargs)

    def plot_cross_exchange_spread(self, **kwargs) -> "go.Figure":
        """Spread between two exchanges for the same security (bps)."""
        from gnomepy.reporting.plots import plot_cross_exchange_spread
        return plot_cross_exchange_spread(self, **kwargs)

    def plot_spread(self, **kwargs) -> "go.Figure":
        """Bid-ask spread over time."""
        from gnomepy.reporting.plots import plot_spread
        return plot_spread(self, **kwargs)

    def plot_pnl_by_symbol(self, **kwargs) -> "go.Figure":
        """Per-symbol PnL curves on a single chart."""
        from gnomepy.reporting.plots import plot_pnl_by_symbol
        return plot_pnl_by_symbol(self, **kwargs)

    # -- HTML export ---------------------------------------------------------

    def to_html(
        self,
        *,
        exclude: list[str] | None = None,
        extra_sections: list | None = None,
        extra_figs: list["go.Figure"] | None = None,
        max_points: int | None = None,
        plotly_cdn: bool | None = None,
    ) -> str:
        """Return the full HTML report as a string."""
        from gnomepy.reporting.plots import DEFAULT_MAX_POINTS, assemble_html, resolve_sections

        cfg_exclude, cfg_sections, cfg_max_points, cfg_plotly_cdn = resolve_sections(self._config or {})

        merged_exclude = list(exclude or []) + cfg_exclude
        merged_sections = list(extra_sections or []) + cfg_sections
        if max_points is None:
            max_points = cfg_max_points if cfg_max_points is not None else DEFAULT_MAX_POINTS
        if plotly_cdn is None:
            plotly_cdn = cfg_plotly_cdn

        return assemble_html(
            self, exclude=merged_exclude or None, extra_sections=merged_sections or None,
            extra_figs=extra_figs, max_points=max_points, plotly_cdn=plotly_cdn,
        )

    def save_html(
        self,
        path: str | Path,
        *,
        exclude: list[str] | None = None,
        extra_sections: list | None = None,
        extra_figs: list["go.Figure"] | None = None,
        max_points: int | None = None,
        plotly_cdn: bool | None = None,
    ) -> None:
        """Write a standalone HTML report to a local path or s3:// URI."""
        html = self.to_html(
            exclude=exclude, extra_sections=extra_sections,
            extra_figs=extra_figs, max_points=max_points, plotly_cdn=plotly_cdn,
        )
        path_str = str(path)
        if path_str.startswith("s3://"):
            from gnomepy._fs import resolve_fs
            fs, normalized = resolve_fs(path_str)
            content = html.encode("utf-8")
            with fs.open_output_stream(normalized) as f:
                f.write(content)
        else:
            Path(path_str).write_text(html)

    def save_summary(self, path: str | Path) -> None:
        """Write summary metrics as JSON to a local path or s3:// URI."""
        data = self.summary()
        path_str = str(path)
        if path_str.startswith("s3://"):
            from gnomepy._fs import resolve_fs
            fs, normalized = resolve_fs(path_str)
            content = (json.dumps(data, indent=2, default=str) + "\n").encode("utf-8")
            with fs.open_output_stream(normalized) as f:
                f.write(content)
        else:
            Path(path_str).write_text(json.dumps(data, indent=2, default=str) + "\n")

    def __repr__(self) -> str:
        s = self.summary()
        lines = [
            "BacktestReport",
            f"  duration:        {s['duration_seconds']:.2f} s",
            f"  market records:  {s['market_record_count']:,}",
            f"  intents:         {s['intent_record_count']:,}",
            f"  fills:           {s['fill_count']:,}",
            f"  total volume:    {s['total_volume']:.4f}",
            f"  final position:  {s['final_position']:.4f}",
            f"  total fees:      {s['total_fees']:.4f}",
            f"  final PnL:       {s['final_pnl']:.4f}",
        ]
        for sym, pnl in s.get("final_pnl_by_symbol", {}).items():
            lines.append(f"    {sym}: {pnl:.4f}")
        return "\n".join(lines)
