# coding=utf-8
# Copyright 2026 XRTM Team. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

r"""Causal graph intervention analysis.

Provides the ``InterventionEngine`` that applies do-calculus-style
interventions to a ``ForecastOutput`` by setting a node's probability to a
fixed value and propagating the change through the causal graph using
topological ordering.
"""

import logging

import networkx as nx
from xrtm.data.core.schemas.forecast import ForecastOutput

logger = logging.getLogger(__name__)


class InterventionEngine:
    @staticmethod
    def apply_intervention(output: ForecastOutput, node_id: str, new_probability: float) -> ForecastOutput:
        new_output = output.model_copy(deep=True)
        dg = new_output.to_networkx()
        if node_id not in dg:
            raise ValueError(f"Node ID '{node_id}' not found in the causal graph.")
        for node in new_output.logical_trace:
            if node.node_id == node_id:
                node.probability = new_probability
                break
        else:
            raise ValueError(f"Node ID '{node_id}' not found in logical_trace.")
        nodes_ordered = list(nx.topological_sort(dg))
        start_index = nodes_ordered.index(node_id)
        trace_map = {node.node_id: node for node in reversed(new_output.logical_trace)}
        for current_id in nodes_ordered[start_index:]:
            current_node = trace_map[current_id]
            for _, target_id, data in dg.out_edges(current_id, data=True):
                weight = data.get("weight", 1.0)
                target_node = trace_map[target_id]
                old_target_prob = target_node.probability or 0.5
                normalized_delta = (
                    current_node.probability - (dg.nodes[current_id].get("probability") or 0.5)
                ) * weight
                target_node.probability = max(0.0, min(1.0, old_target_prob + normalized_delta))
        leaf_nodes = [n for n in dg.nodes() if dg.out_degree(n) == 0]
        if leaf_nodes:
            leaf_probabilities = []
            for leaf_id in leaf_nodes:
                if leaf_id not in trace_map:
                    raise ValueError(f"Leaf node ID '{leaf_id}' not found in logical_trace.")
                leaf_probabilities.append(trace_map[leaf_id].probability or 0.0)
            avg_leaf_prob = sum(leaf_probabilities) / len(leaf_nodes)
            new_output.confidence = avg_leaf_prob
        return new_output


__all__ = ["InterventionEngine"]
