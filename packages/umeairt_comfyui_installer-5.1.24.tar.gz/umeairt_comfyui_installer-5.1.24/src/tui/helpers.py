"""Shared helpers for TUI screens.

Provides reusable utilities that multiple TUI screens depend on,
avoiding code duplication across screen modules.
"""

from __future__ import annotations

import contextlib
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path


def detect_vram() -> float | None:
    """Detect GPU VRAM in GiB.

    Returns:
        VRAM in GiB, or ``None`` if no GPU is detected.
    """
    try:
        from src.utils.gpu import get_gpu_vram_info
        gpu = get_gpu_vram_info()
        if gpu:
            return gpu.vram_gib
    except Exception:
        pass
    return None


def get_venv_python(install_path: Path) -> Path | None:
    """Find the ComfyUI environment Python executable.

    Checks the saved ``install_type`` marker to determine which
    environment to look for:

    - ``conda`` → ``install_path/scripts/conda_env/``
    - ``venv`` (default) → ``install_path/scripts/venv/``

    With platform-appropriate binary path (``Scripts/python.exe``
    on Windows, ``bin/python`` elsewhere).

    Args:
        install_path: Root installation directory.

    Returns:
        Path to the Python executable, or ``None`` if not found.
    """
    # Determine install type from saved marker
    install_type = "venv"
    marker = install_path / "scripts" / "install_type"
    if marker.exists():
        with contextlib.suppress(OSError):
            install_type = marker.read_text(encoding="utf-8").strip()

    if install_type == "conda":
        env_dir = install_path / "scripts" / "conda_env"
        if sys.platform == "win32":
            python_exe = env_dir / "python.exe"
        else:
            python_exe = env_dir / "bin" / "python"
    else:
        env_dir = install_path / "scripts" / "venv"
        if sys.platform == "win32":
            python_exe = env_dir / "Scripts" / "python.exe"
        else:
            python_exe = env_dir / "bin" / "python"

    return python_exe if python_exe.exists() else None
