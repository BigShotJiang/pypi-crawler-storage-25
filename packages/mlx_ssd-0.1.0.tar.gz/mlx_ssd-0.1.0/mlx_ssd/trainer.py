"""Stage 2: fine-tune with mlx-lm training entrypoint."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def train_model(
    model: str,
    data_dir: str,
    output_dir: str,
    iters: int,
    fine_tune_type: str = "full",
    batch_size: int | None = None,
) -> Path:
    data_path = Path(data_dir)
    train_file = data_path / "train.jsonl"
    valid_file = data_path / "valid.jsonl"
    if not train_file.exists() or not valid_file.exists():
        raise FileNotFoundError(
            f"Expected train.jsonl and valid.jsonl in '{data_path}'. Run sample stage first."
        )

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    train_examples = sum(1 for _ in train_file.open("r", encoding="utf-8"))
    valid_examples = sum(1 for _ in valid_file.open("r", encoding="utf-8"))
    if train_examples < 1 or valid_examples < 1:
        raise ValueError("Training requires at least one train and one valid example.")

    effective_batch_size = batch_size if batch_size is not None else min(4, train_examples, valid_examples)
    if effective_batch_size < 1:
        raise ValueError("Resolved training batch size is invalid.")

    cmd = [
        sys.executable,
        "-m",
        "mlx_lm",
        "lora",
        "--train",
        "--model",
        model,
        "--data",
        str(data_path),
        "--fine-tune-type",
        fine_tune_type,
        "--iters",
        str(iters),
        "--batch-size",
        str(effective_batch_size),
        "--adapter-path",
        str(output_path / "adapters"),
        "--save-every",
        "200",
    ]
    subprocess.run(cmd, check=True)

    fuse_cmd = [
        sys.executable,
        "-m",
        "mlx_lm",
        "fuse",
        "--model",
        model,
        "--adapter-path",
        str(output_path / "adapters"),
        "--save-path",
        str(output_path / "fused"),
    ]
    subprocess.run(fuse_cmd, check=True)
    return output_path / "fused"
