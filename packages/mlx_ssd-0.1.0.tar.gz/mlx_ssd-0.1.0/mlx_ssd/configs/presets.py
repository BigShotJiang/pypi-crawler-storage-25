"""Paper-aligned presets used across pipeline stages."""

from __future__ import annotations

from copy import deepcopy

PRESETS = {
    "qwen3-4b-instruct": {
        "train_temperature": 1.6,
        "train_top_k": 20,
        "train_top_p": 0.8,
        "eval_temperature": 1.1,
        "eval_top_k": 20,
        "eval_top_p": 0.8,
        "iters": 2500,
        "fine_tune_type": "full",
    },
    "qwen3-30b-instruct": {
        "train_temperature": 1.6,
        "train_top_k": 20,
        "train_top_p": 0.8,
        "eval_temperature": 0.9,
        "eval_top_k": 20,
        "eval_top_p": 0.8,
        "iters": 2500,
        "fine_tune_type": "full",
    },
    "llama-3.1-8b-instruct": {
        "train_temperature": 0.8,
        "train_top_k": 20,
        "train_top_p": 0.8,
        "eval_temperature": 0.7,
        "eval_top_k": 20,
        "eval_top_p": 0.8,
        "iters": 2500,
        "fine_tune_type": "full",
    },
}


def get_preset(name: str) -> dict:
    if name not in PRESETS:
        supported = ", ".join(sorted(PRESETS))
        raise ValueError(f"Unknown preset '{name}'. Available presets: {supported}")
    return deepcopy(PRESETS[name])
