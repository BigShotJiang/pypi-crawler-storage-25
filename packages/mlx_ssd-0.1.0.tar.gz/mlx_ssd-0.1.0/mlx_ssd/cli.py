"""Command-line interface for mlx-ssd."""

from __future__ import annotations

import argparse
from pathlib import Path

from mlx_lm import generate, load

from .configs.presets import PRESETS, get_preset
from .sampler import sample_dataset
from .trainer import train_model
from .utils.prompts import DEFAULT_CONFIG, DEFAULT_DATASET, DEFAULT_SPLIT


def _merge_sample_args(args: argparse.Namespace) -> tuple[float, int, float]:
    if args.preset:
        preset = get_preset(args.preset)
        temperature = args.temperature if args.temperature is not None else preset["train_temperature"]
        top_k = args.top_k if args.top_k is not None else preset["train_top_k"]
        top_p = args.top_p if args.top_p is not None else preset["train_top_p"]
        return temperature, top_k, top_p
    if args.temperature is None or args.top_k is None or args.top_p is None:
        raise ValueError("Provide --preset or all of --temperature/--top-k/--top-p.")
    return args.temperature, args.top_k, args.top_p


def _merge_eval_args(args: argparse.Namespace) -> tuple[float, int, float]:
    if args.preset:
        preset = get_preset(args.preset)
        temperature = args.temperature if args.temperature is not None else preset["eval_temperature"]
        top_k = args.top_k if args.top_k is not None else preset["eval_top_k"]
        top_p = args.top_p if args.top_p is not None else preset["eval_top_p"]
        return temperature, top_k, top_p
    if args.temperature is None or args.top_k is None or args.top_p is None:
        raise ValueError("Provide --preset or all of --temperature/--top-k/--top-p.")
    return args.temperature, args.top_k, args.top_p


def _resolve_iters(args: argparse.Namespace) -> tuple[int, str]:
    if args.preset:
        preset = get_preset(args.preset)
        iters = args.iters if args.iters is not None else preset["iters"]
        fine_tune_type = preset["fine_tune_type"]
        return iters, fine_tune_type
    if args.iters is None:
        raise ValueError("Provide --preset or --iters.")
    return args.iters, "full"


def cmd_sample(args: argparse.Namespace) -> int:
    temperature, top_k, top_p = _merge_sample_args(args)
    train_path, valid_path = sample_dataset(
        model=args.model,
        problems=args.problems,
        output_dir=args.output,
        temperature=temperature,
        top_k=top_k,
        top_p=top_p,
        max_tokens=args.max_tokens,
        batch_size=args.batch_size,
        dataset_config=args.dataset_config,
        dataset_split=args.dataset_split,
        limit=args.limit,
    )
    print(f"Wrote {train_path} and {valid_path}")
    return 0


def cmd_train(args: argparse.Namespace) -> int:
    iters, fine_tune_type = _resolve_iters(args)
    fused_path = train_model(
        model=args.model,
        data_dir=args.data,
        output_dir=args.output,
        iters=iters,
        fine_tune_type=fine_tune_type,
        batch_size=args.batch_size,
    )
    print(f"Wrote fused model to {fused_path}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    temperature, top_k, top_p = _merge_eval_args(args)
    mdl, tokenizer = load(args.model)
    text = generate(
        mdl,
        tokenizer,
        prompt=args.prompt,
        temp=temperature,
        top_k=top_k,
        top_p=top_p,
        max_tokens=args.max_tokens,
        verbose=False,
    )
    print(text)
    return 0


def cmd_distill(args: argparse.Namespace) -> int:
    sample_output = Path(args.output) / "ssd_data"
    model_output = Path(args.output) / "ssd_model"
    sample_ns = argparse.Namespace(
        model=args.model,
        problems=args.problems,
        dataset_config=args.dataset_config,
        dataset_split=args.dataset_split,
        output=str(sample_output),
        temperature=None,
        top_k=None,
        top_p=None,
        max_tokens=args.max_tokens,
        batch_size=args.batch_size,
        limit=args.limit,
        preset=args.preset,
    )
    train_ns = argparse.Namespace(
        model=args.model,
        data=str(sample_output),
        output=str(model_output),
        iters=None,
        batch_size=None,
        preset=args.preset,
    )
    cmd_sample(sample_ns)
    cmd_train(train_ns)
    print(f"Distillation complete. Model: {model_output / 'fused'}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mlx-ssd")
    sub = parser.add_subparsers(dest="command", required=True)
    presets_help = f"Preset name ({', '.join(sorted(PRESETS))})"

    p_sample = sub.add_parser("sample", help="Generate SFT data via temperature sampling.")
    p_sample.add_argument("--model", required=True)
    p_sample.add_argument("--problems", default=DEFAULT_DATASET)
    p_sample.add_argument("--dataset-config", default=DEFAULT_CONFIG)
    p_sample.add_argument("--dataset-split", default=DEFAULT_SPLIT)
    p_sample.add_argument("--output", required=True)
    p_sample.add_argument("--temperature", type=float)
    p_sample.add_argument("--top-k", type=int)
    p_sample.add_argument("--top-p", type=float)
    p_sample.add_argument("--max-tokens", type=int, default=1024)
    p_sample.add_argument("--batch-size", type=int, default=16)
    p_sample.add_argument("--limit", type=int)
    p_sample.add_argument("--preset", choices=sorted(PRESETS), help=presets_help)
    p_sample.set_defaults(func=cmd_sample)

    p_train = sub.add_parser("train", help="Fine-tune with mlx-lm and fuse adapters.")
    p_train.add_argument("--model", required=True)
    p_train.add_argument("--data", required=True)
    p_train.add_argument("--output", required=True)
    p_train.add_argument("--iters", type=int)
    p_train.add_argument("--batch-size", type=int)
    p_train.add_argument("--preset", choices=sorted(PRESETS), help=presets_help)
    p_train.set_defaults(func=cmd_train)

    p_run = sub.add_parser("run", help="Generate text using eval-time settings.")
    p_run.add_argument("--model", required=True)
    p_run.add_argument("--prompt", required=True)
    p_run.add_argument("--temperature", type=float)
    p_run.add_argument("--top-k", type=int)
    p_run.add_argument("--top-p", type=float)
    p_run.add_argument("--max-tokens", type=int, default=1024)
    p_run.add_argument("--preset", choices=sorted(PRESETS), help=presets_help)
    p_run.set_defaults(func=cmd_run)

    p_distill = sub.add_parser("distill", help="Run sample + train in one command.")
    p_distill.add_argument("--model", required=True)
    p_distill.add_argument("--output", required=True)
    p_distill.add_argument("--problems", default=DEFAULT_DATASET)
    p_distill.add_argument("--dataset-config", default=DEFAULT_CONFIG)
    p_distill.add_argument("--dataset-split", default=DEFAULT_SPLIT)
    p_distill.add_argument("--preset", choices=sorted(PRESETS), required=True, help=presets_help)
    p_distill.add_argument("--max-tokens", type=int, default=1024)
    p_distill.add_argument("--batch-size", type=int, default=16)
    p_distill.add_argument("--limit", type=int)
    p_distill.set_defaults(func=cmd_distill)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except Exception as exc:
        parser.exit(status=1, message=f"error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
