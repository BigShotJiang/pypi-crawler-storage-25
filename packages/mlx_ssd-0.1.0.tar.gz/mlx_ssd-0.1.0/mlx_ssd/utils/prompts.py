"""Prompt set loading for sampling."""

from __future__ import annotations

from typing import Iterable

from datasets import load_dataset

DEFAULT_DATASET = "microsoft/rStar-Coder"
DEFAULT_CONFIG = "seed_sft"
DEFAULT_SPLIT = "train"

DATASET_ALIASES = {
    "rstar-coder": DEFAULT_DATASET,
    "rstarcoder": DEFAULT_DATASET,
}


def _extract_question(record: dict, index: int) -> str:
    if "question" not in record:
        raise ValueError(f"Dataset record {index} is missing required 'question' field.")
    value = record["question"]
    if not isinstance(value, str):
        raise ValueError(f"Dataset record {index} has non-string 'question' field: {type(value).__name__}.")
    question = value.strip()
    if not question:
        raise ValueError(f"Dataset record {index} has empty 'question' field.")
    return question


def resolve_dataset_id(name: str) -> str:
    return DATASET_ALIASES.get(name, name)


def load_problem_prompts(
    name: str,
    split: str = DEFAULT_SPLIT,
    config: str | None = DEFAULT_CONFIG,
    limit: int | None = None,
) -> list[str]:
    dataset_id = resolve_dataset_id(name)
    dataset = load_dataset(dataset_id, config, split=split)
    prompts: list[str] = []
    for index, record in enumerate(dataset):
        prompts.append(_extract_question(record, index))
        if limit is not None and len(prompts) >= limit:
            break
    if not prompts:
        raise ValueError(f"No prompts found for problem set '{dataset_id}' (config={config}, split={split}).")
    return prompts


def iter_user_messages(prompts: Iterable[str]) -> list[dict]:
    return [{"role": "user", "content": prompt} for prompt in prompts]
