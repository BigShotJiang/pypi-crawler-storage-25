"""Data loading and JSONL formatting utilities."""

from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Iterable


def write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_jsonl(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def train_valid_split(rows: list[dict], valid_ratio: float = 0.05, seed: int = 42) -> tuple[list[dict], list[dict]]:
    if not rows:
        return [], []
    random.Random(seed).shuffle(rows)
    valid_size = max(1, int(len(rows) * valid_ratio))
    valid = rows[:valid_size]
    train = rows[valid_size:]
    if not train:
        train, valid = valid, train
    return train, valid
