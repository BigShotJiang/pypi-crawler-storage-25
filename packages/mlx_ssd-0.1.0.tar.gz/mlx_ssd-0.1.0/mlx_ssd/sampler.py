"""Stage 1: sample model outputs and build SFT datasets."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mlx_lm import load
from mlx_lm.generate import BatchGenerator
from mlx_lm.sample_utils import make_sampler

from .utils.data import train_valid_split, write_jsonl
from .utils.prompts import DEFAULT_CONFIG, DEFAULT_SPLIT, load_problem_prompts


def _is_degenerate(text: str) -> bool:
    clean = text.strip()
    if not clean:
        return True
    # Minimal heuristic: drop very short one-liners.
    if "\n" not in clean and len(clean.split()) < 8:
        return True
    return False


def _batch_generate_texts(
    model: Any,
    tokenizer: Any,
    prompts: list[list[int]],
    sampler: Any,
    max_tokens: int,
) -> list[str]:
    gen = BatchGenerator(
        model,
        stop_tokens=tokenizer.eos_token_ids,
        sampler=sampler,
    )
    try:
        uids = gen.insert(prompts, max_tokens)
        tokens_by_uid: dict[int, list[int]] = {uid: [] for uid in uids}
        while responses := gen.next():
            for response in responses:
                if response.finish_reason != "stop":
                    tokens_by_uid[response.uid].append(response.token)
        return [tokenizer.decode(tokens_by_uid[uid]) for uid in uids]
    finally:
        gen.close()


def sample_dataset(
    model: str,
    problems: str,
    output_dir: str,
    temperature: float,
    top_k: int,
    top_p: float,
    max_tokens: int = 1024,
    batch_size: int = 16,
    dataset_config: str | None = DEFAULT_CONFIG,
    dataset_split: str = DEFAULT_SPLIT,
    limit: int | None = None,
    seed: int = 42,
) -> tuple[Path, Path]:
    prompts = load_problem_prompts(
        problems,
        split=dataset_split,
        config=dataset_config,
        limit=limit,
    )
    mdl, tokenizer = load(model)
    sampler = make_sampler(temp=temperature, top_p=top_p, top_k=top_k)

    rows: list[dict] = []
    if batch_size <= 0:
        raise ValueError("--batch-size must be positive.")

    for i in range(0, len(prompts), batch_size):
        prompt_batch = prompts[i : i + batch_size]
        tokenized_batch = [tokenizer.encode(prompt) for prompt in prompt_batch]
        completions = _batch_generate_texts(
            model=mdl,
            tokenizer=tokenizer,
            prompts=tokenized_batch,
            sampler=sampler,
            max_tokens=max_tokens,
        )
        for prompt, completion in zip(prompt_batch, completions, strict=True):
            if _is_degenerate(completion):
                continue
            rows.append(
                {
                    "messages": [
                        {"role": "user", "content": prompt},
                        {"role": "assistant", "content": completion.strip()},
                    ]
                }
            )

    if not rows:
        raise ValueError("No valid samples generated; adjust sampling settings.")

    train_rows, valid_rows = train_valid_split(rows, valid_ratio=0.05, seed=seed)
    output_path = Path(output_dir)
    train_path = output_path / "train.jsonl"
    valid_path = output_path / "valid.jsonl"
    write_jsonl(train_path, train_rows)
    write_jsonl(valid_path, valid_rows)
    return train_path, valid_path
