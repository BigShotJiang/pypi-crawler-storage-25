"""Statistical comparison tools."""
