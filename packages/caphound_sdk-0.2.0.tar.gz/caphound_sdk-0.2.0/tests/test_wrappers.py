"""Tests for wrap_openai, wrap_anthropic, wrap_gemini."""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

import pytest

from caphound_sdk.wrap_anthropic import wrap_anthropic
from caphound_sdk.wrap_gemini import wrap_gemini

GATEWAY_RESPONSE = {
    "id": "chatcmpl-wrap-001",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o",
    "choices": [{"index": 0, "message": {"role": "assistant", "content": "Wrapped response!"}, "finish_reason": "stop"}],
    "usage": {"prompt_tokens": 12, "completion_tokens": 18, "total_tokens": 30},
}


class _Handler(BaseHTTPRequestHandler):
    requests: list[dict] = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode()
        _Handler.requests.append({
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        })
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(GATEWAY_RESPONSE).encode())

    def log_message(self, format, *args):
        pass


def _get_header(req: dict, name: str) -> str | None:
    for k, v in req["headers"].items():
        if k.lower() == name.lower():
            return v
    return None


@pytest.fixture()
def server():
    _Handler.requests = []
    srv = HTTPServer(("127.0.0.1", 0), _Handler)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield port
    srv.shutdown()


# ── wrap_anthropic tests ──────────────────────────────────────────────────────

class _FakeAnthropicMessages:
    def __init__(self):
        self.create_called = False

    def create(self, **kwargs):
        self.create_called = True
        return {"type": "message", "content": [{"text": "direct"}]}


class _FakeAnthropicClient:
    def __init__(self):
        self.messages = _FakeAnthropicMessages()


class TestWrapAnthropic:
    def test_routes_through_gateway(self, server):
        client = _FakeAnthropicClient()
        wrapped = wrap_anthropic(client, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        assert len(_Handler.requests) == 1
        assert _Handler.requests[0]["path"] == "/v1/chat/completions"
        assert result.content[0].text == "Wrapped response!"

    def test_sends_caphound_headers(self, server):
        client = _FakeAnthropicClient()
        wrapped = wrap_anthropic(client, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        wrapped.messages.create(model="claude-3-5-sonnet-20241022", max_tokens=1024, messages=[{"role": "user", "content": "Hi"}])

        assert _get_header(_Handler.requests[0], "X-CapHound-SDK-Version") == "0.2.0"
        assert _get_header(_Handler.requests[0], "Authorization") == "Bearer warden_test_key"

    def test_translates_system_message(self, server):
        client = _FakeAnthropicClient()
        wrapped = wrap_anthropic(client, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        wrapped.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            system="You are helpful.",
            messages=[{"role": "user", "content": "Hello"}],
        )

        body = json.loads(_Handler.requests[0]["body"])
        assert body["messages"][0] == {"role": "system", "content": "You are helpful."}
        assert body["messages"][1] == {"role": "user", "content": "Hello"}

    def test_maps_token_counts(self, server):
        client = _FakeAnthropicClient()
        wrapped = wrap_anthropic(client, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.messages.create(model="claude-3-5-sonnet-20241022", max_tokens=1024, messages=[{"role": "user", "content": "Hi"}])

        assert result.usage.input_tokens == 12
        assert result.usage.output_tokens == 18

    def test_response_shape(self, server):
        client = _FakeAnthropicClient()
        wrapped = wrap_anthropic(client, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.messages.create(model="claude-3-5-sonnet-20241022", max_tokens=1024, messages=[{"role": "user", "content": "Hi"}])

        assert result.type == "message"
        assert result.role == "assistant"
        assert result.stop_reason == "end_turn"


# ── wrap_gemini tests ─────────────────────────────────────────────────────────

class _FakeGeminiModel:
    def __init__(self):
        self.model_name = "gemini-1.5-pro"
        self.generate_called = False

    def generate_content(self, contents, **kwargs):
        self.generate_called = True
        return {"text": "direct"}


class TestWrapGemini:
    def test_routes_through_gateway(self, server):
        model = _FakeGeminiModel()
        wrapped = wrap_gemini(model, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.generate_content("Hello")

        assert len(_Handler.requests) == 1
        assert _Handler.requests[0]["path"] == "/v1/chat/completions"
        assert result.text == "Wrapped response!"

    def test_sends_caphound_headers(self, server):
        model = _FakeGeminiModel()
        wrapped = wrap_gemini(model, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        wrapped.generate_content("Hello")

        assert _get_header(_Handler.requests[0], "X-CapHound-SDK-Version") == "0.2.0"
        assert _get_header(_Handler.requests[0], "Authorization") == "Bearer warden_test_key"

    def test_translates_string_input(self, server):
        model = _FakeGeminiModel()
        wrapped = wrap_gemini(model, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        wrapped.generate_content("Hello world")

        body = json.loads(_Handler.requests[0]["body"])
        assert body["messages"] == [{"role": "user", "content": "Hello world"}]
        assert body["model"] == "gemini-1.5-pro"

    def test_maps_token_counts(self, server):
        model = _FakeGeminiModel()
        wrapped = wrap_gemini(model, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.generate_content("Hello")

        assert result.usage_metadata.prompt_token_count == 12
        assert result.usage_metadata.candidates_token_count == 18
        assert result.usage_metadata.total_token_count == 30

    def test_response_shape(self, server):
        model = _FakeGeminiModel()
        wrapped = wrap_gemini(model, gateway_url=f"http://127.0.0.1:{server}", api_key="warden_test_key")

        result = wrapped.generate_content("Hello")

        assert len(result.candidates) == 1
        assert result.candidates[0].content.role == "model"
        assert result.candidates[0].content.parts[0].text == "Wrapped response!"
