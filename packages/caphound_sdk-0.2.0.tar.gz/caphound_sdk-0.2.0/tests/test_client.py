"""Tests for the CapHoundClient — sync and async chat completions."""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

import pytest

from caphound_sdk.client import CapHoundClient, ChatCompletionOptions
from caphound_sdk.context import caphound_feature, caphound_customer_id

MOCK_RESPONSE = {
    "id": "chatcmpl-test-001",
    "object": "chat.completion",
    "created": 1700000000,
    "model": "gpt-4o",
    "choices": [{"index": 0, "message": {"role": "assistant", "content": "Hello!"}, "finish_reason": "stop"}],
    "usage": {"prompt_tokens": 10, "completion_tokens": 15, "total_tokens": 25},
}


def _get_header(req: dict, name: str) -> str | None:
    """Case-insensitive header lookup."""
    for k, v in req["headers"].items():
        if k.lower() == name.lower():
            return v
    return None


class _Handler(BaseHTTPRequestHandler):
    requests: list[dict] = []

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode()
        _Handler.requests.append({
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        })
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(MOCK_RESPONSE).encode())

    def log_message(self, format, *args):
        pass


@pytest.fixture()
def server():
    _Handler.requests = []
    srv = HTTPServer(("127.0.0.1", 0), _Handler)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield port
    srv.shutdown()


class TestCapHoundClientSync:
    def test_constructor_requires_api_key(self):
        with pytest.raises(ValueError, match="api_key"):
            CapHoundClient(api_key="", gateway_url="http://localhost")

    def test_constructor_requires_gateway_url(self):
        with pytest.raises(ValueError, match="gateway_url"):
            CapHoundClient(api_key="key", gateway_url="")

    def test_sends_to_gateway(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert resp["id"] == "chatcmpl-test-001"
        assert len(_Handler.requests) == 1
        assert _Handler.requests[0]["path"] == "/v1/chat/completions"
        client.close()

    def test_sends_sdk_version_header(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        client.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
        assert _get_header(_Handler.requests[0], "X-CapHound-SDK-Version") == "0.2.0"
        client.close()

    def test_sends_authorization_header(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        client.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
        assert _get_header(_Handler.requests[0], "Authorization") == "Bearer warden_test_key"
        client.close()

    def test_injects_caphound_metadata(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            options=ChatCompletionOptions(feature="checkout", customer_id="cust_001"),
        )
        body = json.loads(_Handler.requests[0]["body"])
        assert body["caphound"]["feature"] == "checkout"
        assert body["caphound"]["customer_id"] == "cust_001"
        client.close()

    def test_uses_contextvars_for_feature(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        token = caphound_feature.set("payments")
        try:
            client.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
            body = json.loads(_Handler.requests[0]["body"])
            assert body["caphound"]["feature"] == "payments"
        finally:
            caphound_feature.reset(token)
            client.close()

    def test_defaults_feature_to_untagged(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        client.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
        body = json.loads(_Handler.requests[0]["body"])
        assert body["caphound"]["feature"] == "untagged"
        client.close()


class TestCapHoundClientAsync:
    @pytest.mark.asyncio
    async def test_async_sends_to_gateway(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        resp = await client.chat.completions.acreate(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        assert resp["id"] == "chatcmpl-test-001"
        assert len(_Handler.requests) == 1
        await client.aclose()

    @pytest.mark.asyncio
    async def test_async_sends_sdk_version_header(self, server):
        client = CapHoundClient(api_key="warden_test_key", gateway_url=f"http://127.0.0.1:{server}")
        await client.chat.completions.acreate(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
        assert _get_header(_Handler.requests[0], "X-CapHound-SDK-Version") == "0.2.0"
        await client.aclose()
