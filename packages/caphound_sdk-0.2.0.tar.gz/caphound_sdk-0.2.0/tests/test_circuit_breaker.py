"""Tests for the Python circuit breaker — sync and async paths."""

import asyncio
import time

import pytest

from caphound_sdk.circuit_breaker import CircuitBreaker


# ── Sync tests ────────────────────────────────────────────────────────────────

class TestCircuitBreakerSync:
    def test_starts_closed(self):
        cb = CircuitBreaker()
        assert cb.state == "closed"

    def test_stays_closed_on_success(self):
        cb = CircuitBreaker()
        for _ in range(5):
            cb.execute(lambda: "ok", lambda: "fallback")
        assert cb.state == "closed"

    def test_opens_after_threshold(self):
        cb = CircuitBreaker(failure_threshold=3, window_s=10)

        def fail():
            raise Exception("fail")

        for _ in range(3):
            cb.execute(fail, lambda: "fallback")
        assert cb.state == "open"

    def test_fallback_used_when_open(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10)

        def fail():
            raise Exception("fail")

        cb.execute(fail, lambda: "fallback")
        assert cb.state == "open"

        result = cb.execute(lambda: "gateway", lambda: "fallback")
        assert result == "fallback"

    def test_never_surfaces_errors(self):
        cb = CircuitBreaker(failure_threshold=3, window_s=10)

        def fail():
            raise Exception("fail")

        for _ in range(5):
            result = cb.execute(fail, lambda: "ok")
            assert result == "ok"

    def test_queues_bypass_events(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10)

        def fail():
            raise Exception("fail")

        cb.execute(fail, lambda: "ok", bypass_event={"model": "gpt-4o"})
        assert cb.bypass_queue_size == 1

    def test_flush_returns_and_clears(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10)

        def fail():
            raise Exception("fail")

        cb.execute(fail, lambda: "ok", bypass_event={"a": 1})
        cb.execute(lambda: "ok", lambda: "ok", bypass_event={"b": 2})

        events = cb.flush_bypass_queue()
        assert len(events) == 2
        assert cb.bypass_queue_size == 0

    def test_recovery_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10, recovery_timeout_s=0.05)

        def fail():
            raise Exception("fail")

        cb.execute(fail, lambda: "fallback")
        assert cb.state == "open"

        time.sleep(0.06)
        result = cb.execute(lambda: "gateway", lambda: "fallback")
        assert result == "gateway"
        assert cb.state == "closed"


# ── Async tests ───────────────────────────────────────────────────────────────

class TestCircuitBreakerAsync:
    @pytest.mark.asyncio
    async def test_stays_closed_on_success(self):
        cb = CircuitBreaker()

        async def ok():
            return "ok"

        for _ in range(3):
            await cb.execute_async(ok, ok)
        assert cb.state == "closed"

    @pytest.mark.asyncio
    async def test_opens_after_threshold(self):
        cb = CircuitBreaker(failure_threshold=2, window_s=10)

        async def fail():
            raise Exception("fail")

        async def fallback():
            return "fallback"

        for _ in range(2):
            await cb.execute_async(fail, fallback)
        assert cb.state == "open"

    @pytest.mark.asyncio
    async def test_fallback_used_when_open(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10)

        async def fail():
            raise Exception("fail")

        async def fallback():
            return "fallback"

        await cb.execute_async(fail, fallback)
        assert cb.state == "open"

        async def gateway():
            return "gateway"

        result = await cb.execute_async(gateway, fallback)
        assert result == "fallback"

    @pytest.mark.asyncio
    async def test_recovery_closes_circuit(self):
        cb = CircuitBreaker(failure_threshold=1, window_s=10, recovery_timeout_s=0.05)

        async def fail():
            raise Exception("fail")

        async def fallback():
            return "fallback"

        await cb.execute_async(fail, fallback)
        assert cb.state == "open"

        await asyncio.sleep(0.06)

        async def gateway():
            return "gateway"

        result = await cb.execute_async(gateway, fallback)
        assert result == "gateway"
        assert cb.state == "closed"
