"""
Context variables for per-request cost attribution.

Usage:
    from caphound_sdk import caphound_feature, caphound_customer_id

    # Set for the current async task / thread:
    caphound_feature.set("checkout")
    caphound_customer_id.set("cust_001")

    # These are automatically picked up by the CapHoundClient and wrappers.
    result = await client.chat.completions.create(...)

    # Or use as context managers (resets on exit):
    token = caphound_feature.set("checkout")
    try:
        ...
    finally:
        caphound_feature.reset(token)
"""

from contextvars import ContextVar

caphound_feature: ContextVar[str] = ContextVar("caphound_feature", default="untagged")
caphound_customer_id: ContextVar[str | None] = ContextVar("caphound_customer_id", default=None)
