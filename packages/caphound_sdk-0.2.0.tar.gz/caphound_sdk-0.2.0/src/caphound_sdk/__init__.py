"""CapHound SDK — LLM cost visibility gateway client for Python."""

from .client import CapHoundClient
from .circuit_breaker import CircuitBreaker
from .context import caphound_feature, caphound_customer_id
from .wrap_openai import wrap_openai
from .wrap_anthropic import wrap_anthropic
from .wrap_gemini import wrap_gemini

__version__ = "0.1.3"

__all__ = [
    "CapHoundClient",
    "CircuitBreaker",
    "caphound_feature",
    "caphound_customer_id",
    "wrap_openai",
    "wrap_anthropic",
    "wrap_gemini",
]
