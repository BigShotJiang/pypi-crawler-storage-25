import shutil
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar

import click

from wst.ai import get_ai_backend
from wst.config import WstConfig
from wst.db import Database
from wst.document import extract_doc_info, is_supported
from wst.ingest import _find_documents, clean_inbox, ingest_files
from wst.models import DocType, LibraryEntry
from wst.storage import LocalStorage, build_dest_path

F = TypeVar("F", bound=Callable[..., Any])

FORMAT_CHOICE = click.Choice(["human", "md", "json", "yaml", "ndjson"], case_sensitive=False)


def _apply_command_format(ctx: click.Context, param: click.Parameter, value: str | None) -> None:
    """When a subcommand passes --format, override the group default in ctx.obj."""
    if value is not None:
        ctx.ensure_object(dict)
        ctx.obj["format"] = value.lower()


def command_format_option() -> Callable[[F], F]:
    """Add --format on subcommands (not only `wst --format … CMD`)."""

    def decorator(f: F) -> F:
        f = click.option(
            "--format",
            "_command_format",
            default=None,
            type=FORMAT_CHOICE,
            callback=_apply_command_format,
            expose_value=False,
            help=(
                "Output format for this command (overrides `wst --format`). "
                "Same as: wst --format yaml <command>"
            ),
        )(f)
        # Common typo (--formate); hidden so normal help stays clean.
        return click.option(
            "--formate",
            "_command_format_typo",
            default=None,
            type=FORMAT_CHOICE,
            callback=_apply_command_format,
            expose_value=False,
            hidden=True,
        )(f)

    return decorator


class WstCli(click.Group):
    def invoke(self, ctx: click.Context) -> object:  # type: ignore[override]
        try:
            return super().invoke(ctx)
        except Exception as e:
            fmt = None
            try:
                fmt = ctx.obj.get("format") if isinstance(ctx.obj, dict) else None
            except Exception:
                fmt = None

            if fmt in {"md", "json", "yaml", "ndjson"}:
                from wst.output import WstError, render_error

                if isinstance(e, WstError):
                    render_error(
                        code=e.code,
                        message=e.message,
                        details=e.details,
                        fmt=fmt,
                    )
                    raise SystemExit(e.exit_code)

                if isinstance(e, click.UsageError):
                    render_error(
                        code="usage_error",
                        message=e.format_message(),
                        details={"hint": "See `wst --help` for usage."},
                        fmt=fmt,
                    )
                    raise SystemExit(e.exit_code)

                if isinstance(e, click.ClickException):
                    render_error(
                        code="click_error",
                        message=e.format_message(),
                        details=None,
                        fmt=fmt,
                    )
                    raise SystemExit(e.exit_code)

                if isinstance(e, SystemExit):
                    render_error(
                        code="system_exit",
                        message="Command failed.",
                        details={"exit_code": e.code},
                        fmt=fmt,
                    )
                    raise

                render_error(
                    code="unexpected_error",
                    message=str(e) or e.__class__.__name__,
                    details=None,
                    fmt=fmt,
                )
                raise SystemExit(1)

            raise


@click.group(cls=WstCli)
@click.option(
    "--backend",
    "-b",
    default=None,
    type=click.Choice(["claude", "codex"], case_sensitive=False),
    help="AI backend to use (default: claude)",
)
@click.option(
    "--model", "-m", "ai_model", default=None, help="AI model to use (e.g. sonnet, opus, gpt-5.4)"
)
@click.option(
    "--format",
    "output_format",
    default="human",
    type=FORMAT_CHOICE,
    help="Output format: human (terminal), md, json, yaml (default: human)",
)
@click.pass_context
def cli(
    ctx: click.Context,
    backend: str | None,
    ai_model: str | None,
    output_format: str,
) -> None:
    """wst — organize your books and PDFs.

    \b
    Output formats:
      - --format human  : terminal-friendly output (default)
      - --format md     : markdown (machine-friendly, pasteable)
      - --format json   : structured output for scripts
      - --format yaml   : structured output for configs/pipelines

    \b
    Notes:
      - In machine formats (md/json/yaml), commands do not prompt for input.
        Use explicit flags (e.g. -y/--yes, --set key=value) or the command will fail.

    \b
    Examples:
      wst list
      wst --format json list
      wst list --format json
      wst show 3 --format yaml
      wst browse --id 3 --action view --format md

    \b
    Where --format goes:
      - After `wst`: `wst --format yaml search "foo"` (always works).
      - After the subcommand: `wst search "foo" --format yaml`
        (same; each command accepts --format).
    """
    ctx.ensure_object(dict)
    config = WstConfig()
    if backend:
        config.ai_backend = backend
    if ai_model:
        config.ai_model = ai_model
    ctx.obj["config"] = config
    ctx.obj["format"] = output_format.lower()


@cli.command()
@command_format_option()
@click.argument("path", type=click.Path(exists=True, path_type=Path), required=False, default=None)
@click.option("--confirm", "-c", is_flag=True, help="Manually confirm metadata for each file")
@click.option("--reprocess", "-r", is_flag=True, help="Re-ingest duplicates with fresh AI metadata")
@click.option("--keep-inbox", is_flag=True, help="Don't clean inbox after processing")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed per-file processing logs")
@click.option(
    "--ocr",
    is_flag=True,
    help="Force OCR on every PDF (default: auto-detect — OCR scanned PDFs only "
    "when ocrmypdf is installed; warn otherwise)",
)
@click.option(
    "--ocr-language",
    default="spa",
    help="OCR language code (default: spa)",
)
@click.pass_context
def ingest(
    ctx: click.Context,
    path: Path | None,
    confirm: bool,
    reprocess: bool,
    keep_inbox: bool,
    verbose: bool,
    ocr: bool,
    ocr_language: str,
) -> None:
    """Ingest PDFs into the library.

    \b
    Without arguments, processes all files in ~/wst/inbox/ and cleans it afterwards.
    With a PATH argument (file or directory), ingests only those files
    (copies them to inbox for processing, without touching other inbox files).

    \b
    Machine output:
      - Use --format json|yaml|md for structured output.
      - In machine formats, progress bars are disabled and output is emitted once at the end.

    \b
    Examples:
        wst ingest                        # process and clean inbox
        wst ingest ~/Downloads/book.pdf   # ingest a single file
        wst ingest ~/Documents/papers/    # ingest a whole folder
        wst ingest --keep-inbox           # process inbox without cleaning
        wst ingest -v                     # verbose per-file output
        wst ingest --ocr                  # OCR scanned PDFs before ingesting
        wst ingest --format json          # structured output
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    config.ensure_dirs()

    # NDJSON mode (RFC 0013): line-buffer stdout, auto-confirm, emit one JSON
    # event per file as it finishes, plus a final summary event.
    if fmt == "ndjson":
        import sys

        try:
            sys.stdout.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
        except (AttributeError, ValueError):
            pass
        # Suppress the interactive "Accept and ingest?" prompt; the consumer
        # of NDJSON has no terminal in which to answer it.
        confirm = False

    ai = get_ai_backend(config.ai_backend, config.ai_model)
    storage = LocalStorage(config.library_path)
    db = Database(config.db_path)

    try:
        import json as _json

        removed = 0
        if path is not None:
            copied_files = _copy_to_inbox(path, config.inbox_path)
            if not copied_files:
                if fmt == "human":
                    click.echo("No supported files found at the given path.")
                elif fmt == "ndjson":
                    click.echo(
                        _json.dumps(
                            {
                                "event": "summary",
                                "processed": 0,
                                "ingested": 0,
                                "skipped": 0,
                                "failed": 0,
                            }
                        ),
                        nl=True,
                    )
                return
            if fmt == "human":
                click.echo(f"Copied {len(copied_files)} file(s) to inbox.")
            files_to_process = copied_files
        else:
            if not config.inbox_path.exists() or not any(
                p for p in config.inbox_path.rglob("*") if is_supported(p)
            ):
                if fmt == "human":
                    click.echo(f"No supported files in inbox ({config.inbox_path}).")
                elif fmt == "ndjson":
                    click.echo(
                        _json.dumps(
                            {
                                "event": "summary",
                                "processed": 0,
                                "ingested": 0,
                                "skipped": 0,
                                "failed": 0,
                            }
                        ),
                        nl=True,
                    )
                return
            files_to_process = _find_documents(config.inbox_path)

        ocr_summary = None
        if ocr:
            from wst.ocr import ocr_files as run_ocr_batch
            from wst.ocr import require_ocr_dependencies

            if not require_ocr_dependencies():
                return
            pdfs = [f for f in files_to_process if f.suffix.lower() == ".pdf"]
            if pdfs:
                if fmt == "human":
                    click.echo("\n--- OCR pass ---")
                ocr_summary = run_ocr_batch(
                    pdfs,
                    language=ocr_language,
                    verbose=verbose,
                    emit=(fmt == "human"),
                    progress=(fmt == "human"),
                )
                if fmt == "human":
                    click.echo("")

        if fmt == "human":
            click.echo("--- Ingest pass ---")

        # NDJSON per-file callback: emit one event per IngestResult as it lands.
        per_file_callback = None
        if fmt == "ndjson":

            def per_file_callback(r):  # type: ignore[no-redef]
                payload = {
                    "event": "file",
                    "filename": r.filename,
                    "status": r.status,
                    "reason": r.reason,
                    "dest_path": r.dest_path,
                    "notes": list(r.notes),
                }
                click.echo(_json.dumps(payload), nl=True)

        ingest_summary = ingest_files(
            files_to_process,
            ai,
            storage,
            db,
            auto_confirm=not confirm,
            reprocess=reprocess,
            verbose=verbose,
            emit=(fmt == "human"),
            progress=(fmt == "human"),
            library_path=config.library_path,
            per_file_callback=per_file_callback,
        )

        if path is None and not keep_inbox:
            removed = clean_inbox(config.inbox_path)
            if fmt == "human" and removed > 0:
                click.echo(f"Cleaned inbox: removed {removed} remaining file(s).")

        if fmt == "ndjson":
            click.echo(
                _json.dumps(
                    {
                        "event": "summary",
                        "processed": ingest_summary["processed"],
                        "ingested": ingest_summary["ingested"],
                        "skipped": ingest_summary["skipped"],
                        "failed": ingest_summary["failed"],
                        "cleaned_inbox_removed": removed,
                    }
                ),
                nl=True,
            )
        elif fmt != "human":
            from wst.output import render_ok

            render_ok(
                {
                    "ocr": ocr_summary,
                    "ingest": ingest_summary,
                    "cleaned_inbox_removed": removed,
                },
                fmt=fmt,
            )
    finally:
        db.close()


@cli.group(invoke_without_command=True)
@command_format_option()
@click.pass_context
def backup(ctx: click.Context) -> None:
    """Backup library files to a cloud provider.

    \b
    This command is interactive by default.
    For non-interactive scripting, use subcommands:
      - wst backup icloud <ID|TITLE>
      - wst backup s3 <ID|TITLE>
    """
    from wst.backup import PROVIDERS, run_backup_interactive

    if ctx.invoked_subcommand is not None:
        return

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")

    if fmt != "human":
        from wst.output import WstError

        raise WstError(
            "usage_error",
            (
                "Interactive backup requires --format human. "
                "Use `wst backup icloud|s3` with an identifier, or add non-interactive flags."
            ),
            details={"hint": "Try: wst backup s3 3 --format json"},
            exit_code=2,
        )

    # Interactive provider selection
    from InquirerPy import inquirer

    provider_names = list(PROVIDERS.keys())
    choice = inquirer.select(
        message="Choose backup provider:",
        choices=provider_names,
    ).execute()

    provider = PROVIDERS[choice]()
    db = Database(config.db_path)
    try:
        run_backup_interactive(provider, db, config.library_path)
    finally:
        db.close()


@backup.command("icloud")
@command_format_option()
@click.argument("identifier", required=False, default=None)
@click.pass_context
def backup_icloud(ctx: click.Context, identifier: str | None) -> None:
    """Backup files to iCloud Drive."""
    from wst.backup import ICloudProvider, run_backup_file, run_backup_interactive

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    provider = ICloudProvider()
    db = Database(config.db_path)

    try:
        if fmt != "human" and not identifier:
            from wst.output import WstError

            raise WstError(
                "usage_error",
                "Non-interactive backup requires an IDENTIFIER (ID or exact title).",
                details={"hint": "Try: wst backup icloud 3 --format json"},
                exit_code=2,
            )

        if identifier:
            if fmt == "human":
                run_backup_file(provider, db, config.library_path, identifier, emit=True)
                return
            if not provider.is_configured():
                from wst.output import WstError

                raise WstError(
                    "requires_interactive",
                    "Backup provider is not configured. Run interactive configuration first.",
                    details={"hint": "Try: wst backup icloud --format human"},
                    exit_code=2,
                )
            # Avoid stdout contamination from backup module in machine formats
            run_backup_file(provider, db, config.library_path, identifier, emit=False)
            from wst.output import render_ok

            render_ok({"provider": "icloud", "identifier": identifier, "status": "ok"}, fmt=fmt)
        else:
            run_backup_interactive(provider, db, config.library_path)
    finally:
        db.close()


@backup.command("s3")
@command_format_option()
@click.argument("identifier", required=False, default=None)
@click.option("--configure", is_flag=True, help="Configure S3 credentials")
@click.pass_context
def backup_s3(
    ctx: click.Context,
    identifier: str | None,
    configure: bool,
) -> None:
    """Backup files to S3 (or S3-compatible storage).

    \b
    Works with AWS S3, Cloudflare R2, Backblaze B2, MinIO, etc.
    Credentials are stored in ~/wst/config.json.

    \b
    Examples:
        wst backup s3 --configure       # set up credentials
        wst backup s3                    # interactive backup
        wst backup s3 3                  # backup document by ID
        wst backup s3 "Cosmos"           # backup document by title
    """
    from wst.backup import S3Provider, run_backup_file, run_backup_interactive

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    provider = S3Provider()

    if configure:
        if fmt != "human":
            from wst.output import WstError

            raise WstError(
                "usage_error",
                "S3 configuration is interactive. Use --format human.",
                details={"hint": "Try: wst backup s3 --configure --format human"},
                exit_code=2,
            )
        provider.configure()
        return

    db = Database(config.db_path)
    try:
        if fmt != "human" and not identifier:
            from wst.output import WstError

            raise WstError(
                "usage_error",
                "Non-interactive backup requires an IDENTIFIER (ID or exact title).",
                details={"hint": "Try: wst backup s3 3 --format json"},
                exit_code=2,
            )

        if identifier:
            if fmt == "human":
                run_backup_file(provider, db, config.library_path, identifier, emit=True)
                return
            if not provider.is_configured():
                from wst.output import WstError

                raise WstError(
                    "requires_interactive",
                    "Backup provider is not configured. "
                    "Run `wst backup s3 --configure` in human mode first.",
                    details={"hint": "Try: wst backup s3 --configure --format human"},
                    exit_code=2,
                )
            run_backup_file(provider, db, config.library_path, identifier, emit=False)
            from wst.output import render_ok

            render_ok({"provider": "s3", "identifier": identifier, "status": "ok"}, fmt=fmt)
        else:
            run_backup_interactive(provider, db, config.library_path)
    finally:
        db.close()


@cli.command()
@command_format_option()
@click.option("--id", "doc_id", type=int, default=None, help="Select document by ID")
@click.option("--title", default=None, help="Select document by exact title")
@click.option(
    "--query",
    default=None,
    help="Search query to select a document (uses full-text search)",
)
@click.option(
    "--select",
    type=int,
    default=None,
    help="When --query returns multiple results, pick N (1-based)",
)
@click.option(
    "--first",
    is_flag=True,
    help="When --query returns multiple results, pick the first match",
)
@click.option(
    "--action",
    type=click.Choice(["view", "open", "find", "edit", "delete"], case_sensitive=False),
    default=None,
    help="Non-interactive action to run on the selected document",
)
@click.option("--set", "set_kv", multiple=True, help="For --action edit: key=value (repeatable)")
@click.option("--yes", "-y", is_flag=True, help="Auto-accept (delete/edit) without prompting")
@click.option("--dry-run", is_flag=True, help="Preview (delete/edit) without making changes")
@click.option(
    "--no-launch",
    is_flag=True,
    help="For open/find: don't launch apps; only output command/path",
)
@click.pass_context
def browse(
    ctx: click.Context,
    doc_id: int | None,
    title: str | None,
    query: str | None,
    select: int | None,
    first: bool,
    action: str | None,
    set_kv: tuple[str, ...],
    yes: bool,
    dry_run: bool,
    no_launch: bool,
) -> None:
    """Browse documents (interactive TUI or non-interactive actions).

    \b
    Interactive mode:
      wst browse

    \b
    Non-interactive mode (scriptable):
      wst browse --id 3 --action view --format json
      wst browse --query "Cosmos" --first --action open --no-launch --format yaml
      wst browse --id 3 --action delete --dry-run --format md
      wst browse --id 3 --action delete -y --format json
      wst browse --id 3 --action edit --set title="New" --dry-run --format json
      wst browse --id 3 --action edit --set title="New" -y --format json
    """
    from wst.browse import BrowseUsageError, browse_library, resolve_entry, run_action

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)
    storage = LocalStorage(config.library_path)

    try:
        if fmt == "human" and not any(
            [
                doc_id,
                title,
                query,
                action,
                set_kv,
                yes,
                dry_run,
                no_launch,
                select,
                first,
            ]
        ):
            browse_library(db, storage, config.library_path)
            return

        if action is None:
            # Non-interactive selection only is not useful; require an action.
            from wst.output import WstError

            raise WstError(
                "usage_error",
                "Non-interactive browse requires --action plus a selector (--id/--title/--query).",
                details={"hint": "Try: wst browse --id 3 --action view --format json"},
                exit_code=2,
            )

        try:
            entry = resolve_entry(
                db,
                doc_id=doc_id,
                title=title,
                query=query,
                select=select,
                first=first,
            )
        except BrowseUsageError as e:
            if fmt == "human":
                raise click.UsageError(str(e))
            from wst.output import WstError

            raise WstError("usage_error", str(e), exit_code=2)

        set_dict = _parse_set_kv(set_kv) if set_kv else None
        try:
            result = run_action(
                entry,
                action=action,
                db=db,
                storage=storage,
                library_path=config.library_path,
                yes=yes,
                dry_run=dry_run,
                no_launch=no_launch,
                set_kv=set_dict,
            )
        except BrowseUsageError as e:
            if fmt == "human":
                raise click.UsageError(str(e))
            from wst.output import WstError

            raise WstError("usage_error", str(e), exit_code=2)

        if fmt == "human":
            # Keep a minimal human output for non-interactive use
            click.echo(result.get("status") or "ok")
            return

        from wst.output import render_ok

        render_ok(result, fmt=fmt)
    finally:
        db.close()


@cli.command()
@command_format_option()
@click.argument(
    "path",
    type=click.Path(exists=True, path_type=Path),
)
@click.option(
    "--language",
    "-l",
    default="spa",
    help="OCR language code (default: spa). Use + for multiple: spa+eng",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Force OCR even if the PDF already has extractable text",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show detailed per-file processing logs",
)
@click.pass_context
def ocr(ctx: click.Context, path: Path, language: str, force: bool, verbose: bool) -> None:
    """Run OCR on scanned PDFs to make them searchable.

    \b
    Adds an invisible text layer to scanned PDFs using ocrmypdf.
    Skips PDFs that already have extractable text (use --force to override).
    Requires ocrmypdf: pipx install ocrmypdf

    \b
    Examples:
        wst ocr scan.pdf                # OCR a single file
        wst ocr ~/scans/                # OCR all PDFs in a folder
        wst ocr scan.pdf -l eng         # OCR in English
        wst ocr scan.pdf -l spa+eng     # OCR in Spanish and English
        wst ocr scan.pdf --force        # Force OCR even if text exists
        wst ocr scan.pdf --format json  # structured output
    """
    from wst.ocr import ocr_files as run_ocr_batch

    fmt: str = ctx.obj.get("format", "human")

    if path.is_file():
        if path.suffix.lower() != ".pdf":
            click.echo("Only PDF files can be OCR'd.")
            return
        files = [path]
    elif path.is_dir():
        files = sorted(p for p in path.rglob("*") if p.is_file() and p.suffix.lower() == ".pdf")
        if not files:
            click.echo("No PDF files found in the given directory.")
            return
    else:
        click.echo("Path must be a file or directory.")
        return

    summary = run_ocr_batch(
        files,
        language=language,
        force=force,
        verbose=verbose,
        emit=(fmt == "human"),
        progress=(fmt == "human"),
    )
    if fmt != "human":
        from wst.output import render_ok

        render_ok(summary, fmt=fmt)


def _copy_to_inbox(source: Path, inbox: Path) -> list[Path]:
    """Copy supported files from source to inbox. Returns list of copied file paths in inbox."""
    inbox.mkdir(parents=True, exist_ok=True)
    copied: list[Path] = []
    files = []
    if source.is_file():
        if is_supported(source):
            files = [source]
    elif source.is_dir():
        files = [p for p in source.rglob("*") if p.is_file() and is_supported(p)]

    for pdf in files:
        dest = inbox / pdf.name
        if dest.exists():
            stem, suffix = dest.stem, dest.suffix
            counter = 1
            while dest.exists():
                dest = inbox / f"{stem} ({counter}){suffix}"
                counter += 1
        shutil.copy2(str(pdf), str(dest))
        copied.append(dest)
    return copied


@cli.command()
@command_format_option()
@click.argument("query", default="")
@click.option("--author", "-a", default=None, help="Filter by author")
@click.option("--type", "-t", "doc_type", default=None, help="Filter by document type")
@click.option("--subject", "-s", default=None, help="Filter by subject/knowledge area")
@click.option("--topic", "-p", default=None, help="Filter by topic (partial, case-insensitive)")
@click.option(
    "--mode",
    type=click.Choice(["auto", "fts", "semantic"], case_sensitive=False),
    default="auto",
    help=(
        "Search mode: auto (semantic when index exists, else FTS), "
        "fts (keyword), semantic (embedding-based)"
    ),
)
@click.pass_context
def search(
    ctx: click.Context,
    query: str,
    author: str | None,
    doc_type: str | None,
    subject: str | None,
    topic: str | None,
    mode: str,
) -> None:
    """Search documents using structured query syntax or semantic search.

    \b
    Syntax:
      word                  full-text / semantic search
      "quoted phrase"       phrase search
      field:value           substring/exact match
      field:>value          range (year:>2000, year:<1990)
      field:~pattern        regex match (case-insensitive)
      AND / OR / NOT        boolean operators

    \b
    Fields: title, author, type, year, subject, topic, tag, language, isbn

    \b
    Examples:
      wst search 'author:Knuth type:book'
      wst search 'topic:cálculo year:>2010'
      wst search '"linear algebra" NOT author:Strang'
      wst search 'cálculo diferencial'       # semantic when index exists
      wst search 'cálculo' --mode fts        # force keyword search
    """
    from wst.query_parser import parse_query

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        if query and fmt == "human":
            pq = parse_query(query)
            for w in pq.warnings:
                click.echo(f"Warning: {w}", err=True)

        results = _run_search(
            db, query, mode=mode, doc_type=doc_type, author=author, subject=subject, topic=topic
        )
        if not results:
            if fmt == "human":
                click.echo("No results found.")
                return
            from wst.output import render_ok

            render_ok([], fmt=fmt)
            return
        if fmt == "human":
            _print_table(results)
            return
        from wst.output import render_ok

        render_ok(results, fmt=fmt)
    finally:
        db.close()


def _run_search(
    db: Database,
    query: str,
    *,
    mode: str = "auto",
    doc_type: str | None = None,
    author: str | None = None,
    subject: str | None = None,
    topic: str | None = None,
) -> list:
    """Route search through semantic or FTS depending on mode and index availability."""
    use_semantic = False
    if query and mode in ("auto", "semantic"):
        from wst.search import search as _semantic_search

        sem_results = _semantic_search(db, query, top_k=50)
        if sem_results is not None:
            use_semantic = True
            results = sem_results
            # Apply field filters in-memory (semantic bypasses SQL WHERE)
            if doc_type:
                results = [r for r in results if r.metadata.doc_type.value == doc_type.lower()]
            if author:
                results = [
                    r for r in results if author.lower() in (r.metadata.author or "").lower()
                ]
            if subject:
                results = [
                    r for r in results if subject.lower() in (r.metadata.subject or "").lower()
                ]
            if topic:
                results = [
                    r for r in results if any(topic.lower() in t.lower() for t in r.metadata.topics)
                ]
            return results

    if not use_semantic:
        return db.search(query, doc_type=doc_type, author=author, subject=subject, topic=topic)
    return []


@cli.command(name="list")
@command_format_option()
@click.option("--type", "-t", "doc_type", default=None, help="Filter by document type")
@click.option(
    "--sort",
    "-s",
    "sort_by",
    default="title",
    type=click.Choice(["title", "author", "year"]),
    help="Sort by field",
)
@click.pass_context
def list_cmd(ctx: click.Context, doc_type: str | None, sort_by: str) -> None:
    """List all documents in the library."""
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        entries = db.list_all(doc_type=doc_type, sort_by=sort_by)
        if not entries:
            if fmt == "human":
                click.echo("Library is empty.")
                return
            from wst.output import render_ok

            render_ok([], fmt=fmt)
            return
        if fmt == "human":
            _print_table(entries)
            return
        from wst.output import render_ok

        render_ok(entries, fmt=fmt)
    finally:
        db.close()


@cli.command()
@command_format_option()
@click.argument("identifier")
@click.pass_context
def show(ctx: click.Context, identifier: str) -> None:
    """Show full metadata for a document (by ID or title)."""
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        entry = _find_entry(db, identifier)
        if entry is None:
            if fmt == "human":
                click.echo(f"Document not found: {identifier}")
                raise SystemExit(1)
            from wst.output import WstError

            raise WstError("not_found", f"Document not found: {identifier}", exit_code=1)

        if fmt != "human":
            from wst.output import render_ok

            render_ok(entry, fmt=fmt)
            return

        m = entry.metadata
        click.echo(f"ID:            {entry.id}")
        click.echo(f"Title:         {m.title}")
        click.echo(f"Author:        {m.author}")
        click.echo(f"Type:          {m.doc_type.value}")
        click.echo(f"Year:          {m.year or 'N/A'}")
        click.echo(f"Publisher:     {m.publisher or 'N/A'}")
        click.echo(f"ISBN:          {m.isbn or 'N/A'}")
        click.echo(f"Language:      {m.language or 'N/A'}")
        click.echo(f"Pages:         {m.page_count or 'N/A'}")
        click.echo(f"Subject:       {m.subject or 'N/A'}")
        click.echo(f"Tags:          {', '.join(m.tags) if m.tags else 'N/A'}")
        click.echo(f"Topics:        {', '.join(m.topics) if m.topics else 'N/A'}")
        click.echo(f"Summary:       {m.summary or 'N/A'}")
        click.echo(f"TOC:           {m.table_of_contents or 'N/A'}")
        click.echo(f"File:          {entry.file_path}")
        click.echo(f"Original file: {entry.original_filename}")
        click.echo(f"Ingested at:   {entry.ingested_at}")
    finally:
        db.close()


@cli.command()
@command_format_option()
@click.option(
    "--type",
    "-t",
    "doc_type",
    default=None,
    type=click.Choice([dt.value for dt in DocType], case_sensitive=False),
    help="Filter by document type",
)
@click.pass_context
def stats(ctx: click.Context, doc_type: str | None) -> None:
    """Show metadata coverage statistics.

    \b
    Displays how complete the metadata is across all documents,
    broken down by document type and field.

    \b
    Examples:
        wst stats
        wst stats --type textbook
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        entries = db.list_all(doc_type=doc_type)
        if not entries:
            if fmt == "human":
                click.echo("Library is empty.")
                return
            from wst.output import render_ok

            render_ok(
                {"total": 0, "coverage_by_field": [], "breakdown_by_type": []},
                fmt=fmt,
            )
            return

        fields = [
            "title",
            "author",
            "year",
            "publisher",
            "isbn",
            "language",
            "subject",
            "summary",
            "table_of_contents",
            "page_count",
        ]

        # Group by doc_type
        by_type: dict[str, list[LibraryEntry]] = {}
        for e in entries:
            dt = e.metadata.doc_type.value
            by_type.setdefault(dt, []).append(e)

        if fmt != "human":
            coverage_by_field = []
            for field in fields:
                filled = sum(1 for e in entries if _field_filled(e, field))
                missing = len(entries) - filled
                pct = (filled / len(entries)) * 100
                coverage_by_field.append(
                    {"field": field, "filled": filled, "missing": missing, "coverage_pct": pct}
                )

            key_fields = ["isbn", "table_of_contents", "year", "publisher", "summary"]
            breakdown_by_type = []
            for dt in sorted(by_type):
                group = by_type[dt]
                total = len(group)
                per = {}
                for f in key_fields:
                    n = sum(1 for e in group if _field_filled(e, f))
                    per[f] = (n / total) * 100 if total else 0.0
                breakdown_by_type.append({"type": dt, "total": total, **per})

            from wst.output import render_ok

            render_ok(
                {
                    "total": len(entries),
                    "coverage_by_field": coverage_by_field,
                    "breakdown_by_type": breakdown_by_type,
                },
                fmt=fmt,
            )
            return

        # Overall coverage per field
        click.echo(f"\nTotal documents: {len(entries)}\n")
        click.echo(f"  {'Field':<22} {'Filled':>6} {'Missing':>7} {'Coverage':>9}")
        click.echo("  " + "-" * 48)
        for field in fields:
            filled = sum(1 for e in entries if _field_filled(e, field))
            missing = len(entries) - filled
            pct = (filled / len(entries)) * 100
            bar = _coverage_bar(pct)
            click.echo(f"  {field:<22} {filled:>6} {missing:>7} {pct:>6.1f}%  {bar}")

        # Per-type breakdown
        key_fields = ["isbn", "table_of_contents", "year", "publisher", "summary"]
        headers = ["ISBN", "TOC", "Year", "Publisher", "Summary"]
        click.echo(f"\n  {'Type':<16} {'Total':>5}  {'  '.join(f'{h:>9}' for h in headers)}")
        click.echo("  " + "-" * (24 + 11 * len(headers)))
        for dt in sorted(by_type):
            group = by_type[dt]
            total = len(group)
            pcts = []
            for f in key_fields:
                n = sum(1 for e in group if _field_filled(e, f))
                pcts.append(f"{(n / total) * 100:>6.0f}%")
            click.echo(f"  {dt:<16} {total:>5}  {'  '.join(f'{p:>9}' for p in pcts)}")
        click.echo()
    finally:
        db.close()


def _field_filled(entry: LibraryEntry, field: str) -> bool:
    val = getattr(entry.metadata, field, None)
    return val is not None and val != "" and val != []


def _pct_str(filled: int, total: int) -> str:
    pct = (filled / total) * 100 if total else 0
    return f"{filled}/{total} {pct:.0f}%"


def _coverage_bar(pct: float, width: int = 15) -> str:
    filled = int(pct / 100 * width)
    return "[" + "#" * filled + "." * (width - filled) + "]"


@cli.command()
@command_format_option()
@click.argument("identifier")
@click.option(
    "--enrich",
    is_flag=True,
    help="Use AI to fill missing fields (ISBN, publisher, etc.)",
)
@click.option(
    "--set",
    "set_kv",
    multiple=True,
    help=(
        "Non-interactive update in key=value form (repeatable). "
        'Example: --set title="New" --set year=2024'
    ),
)
@click.option("--yes", "-y", is_flag=True, help="Auto-accept changes without prompting")
@click.option(
    "--move/--no-move",
    default=True,
    help="When metadata changes the destination path, move the file (default: move)",
)
@click.pass_context
def edit(
    ctx: click.Context,
    identifier: str,
    enrich: bool,
    set_kv: tuple[str, ...],
    yes: bool,
    move: bool,
) -> None:
    """Edit metadata for a document (interactive or non-interactive).

    \b
    Shows current values and lets you change any field.
    Press Enter to keep the current value. If the document type
    changes, the file is moved to the correct folder.

    \b
    Use --enrich to automatically fill missing fields (ISBN,
    publisher, year) using AI and web search.

    \b
    Non-interactive mode:
      - Use --set key=value (repeatable) and -y to apply.
      - Without -y, the command performs a dry-run (no changes).

    \b
    Examples:
        wst edit 1
        wst edit "Player's Handbook"
        wst edit 42 --enrich
        wst edit 42 --enrich -y --format json
        wst edit 42 --set title="New title" --dry-run --format yaml
        wst edit 42 --set title="New title" -y --format json
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)
    storage = LocalStorage(config.library_path)

    try:
        entry = _find_entry(db, identifier)
        if entry is None:
            if fmt == "human":
                click.echo(f"Document not found: {identifier}")
                raise SystemExit(1)
            from wst.output import WstError

            raise WstError("not_found", f"Document not found: {identifier}", exit_code=1)

        m = entry.metadata

        if enrich:
            if fmt != "human" and not yes:
                from wst.output import WstError

                raise WstError(
                    "usage_error",
                    "Non-interactive enrich requires --yes (or use --format human).",
                    details={"hint": "Try: wst edit <id> --enrich -y --format json"},
                    exit_code=2,
                )
            _enrich_entry(entry, config, db, confirm=(fmt == "human" and not yes))
            if fmt != "human":
                from wst.output import render_ok

                render_ok(entry, fmt=fmt)
            return

        if set_kv:
            updates = _parse_set_kv(set_kv)
            updated_entry, changes = _apply_metadata_updates(
                entry,
                updates,
                config=config,
                db=db,
                storage=storage,
                move=move,
                dry_run=not yes,
                emit=(fmt == "human"),
            )
            if fmt == "human":
                if not yes:
                    click.echo("\nDry-run complete (use -y to apply).")
                return
            from wst.output import render_ok

            render_ok(
                {
                    "applied": bool(yes),
                    "changes": changes,
                    "entry": updated_entry,
                },
                fmt=fmt,
            )
            return

        if fmt != "human":
            from wst.output import WstError

            raise WstError(
                "usage_error",
                (
                    "This command is interactive by default. "
                    "Use --set key=value (and -y) for non-interactive mode."
                ),
                details={"hint": 'Try: wst edit 1 --set title="..." -y --format json'},
                exit_code=2,
            )

        click.echo(f"\nEditing: {m.title} (ID {entry.id})")
        click.echo("Press Enter to keep current value.\n")

        m.title = _prompt_field("Title", m.title)
        m.author = _prompt_field("Author", m.author)
        m.doc_type = _prompt_doc_type(m.doc_type)
        year_str = _prompt_field("Year", str(m.year) if m.year else "")
        m.year = int(year_str) if year_str else None
        m.publisher = _prompt_field("Publisher", m.publisher or "") or None
        m.isbn = _prompt_field("ISBN", m.isbn or "") or None
        m.language = _prompt_field("Language", m.language or "") or None
        m.subject = _prompt_field("Subject", m.subject or "") or None
        tags_str = _prompt_field("Tags (comma-separated)", ", ".join(m.tags))
        m.tags = [t.strip() for t in tags_str.split(",") if t.strip()] if tags_str else []
        m.summary = _prompt_field("Summary", m.summary or "") or None

        # Rebuild destination path and move if needed
        new_dest = build_dest_path(m)
        old_path = entry.file_path

        if new_dest != old_path:
            old_full = config.library_path / old_path
            if old_full.exists():
                final = storage.store(old_full, new_dest)
                old_full.unlink()
                entry.file_path = final
                entry.filename = Path(final).name
                click.echo(f"\nMoved: {old_path} -> {final}")
            else:
                entry.file_path = new_dest
                entry.filename = Path(new_dest).name
                click.echo(f"\nWarning: old file not found at {old_path}, updated path in DB only.")
        else:
            click.echo("")

        db.update(entry)
        click.echo("Updated successfully.")
    finally:
        db.close()


def _enrich_entry(
    entry: LibraryEntry,
    config: WstConfig,
    db: Database,
    *,
    confirm: bool = True,
) -> None:
    m = entry.metadata
    missing = _get_missing_fields(m)

    if not missing:
        click.echo(f"\n{m.title}: all fields already populated, nothing to enrich.")
        return

    click.echo(f"\nEnriching: {m.title} (ID {entry.id})")
    click.echo(f"Missing fields: {', '.join(missing)}")

    changes, enriched = _run_enrich(entry, config)

    if not changes:
        click.echo("  AI could not find any additional information.")
        return

    click.echo("\n  Found:")
    for field, value in changes:
        display = value if not isinstance(value, list) else ", ".join(value)
        click.echo(f"    {field}: {display}")

    if confirm:
        if not click.confirm("\n  Apply these changes?", default=True):
            click.echo("  Skipped.")
            return

    entry.metadata = enriched
    db.update(entry)
    click.echo("  Updated successfully.")


def _parse_set_kv(items: tuple[str, ...]) -> dict[str, str]:
    updates: dict[str, str] = {}
    for raw in items:
        if "=" not in raw:
            raise click.UsageError(f"Invalid --set value (expected key=value): {raw}")
        k, v = raw.split("=", 1)
        k = k.strip()
        v = v.strip()
        if not k:
            raise click.UsageError(f"Invalid --set key: {raw}")
        updates[k] = v
    return updates


def _apply_metadata_updates(
    entry: LibraryEntry,
    updates: dict[str, str],
    *,
    config: WstConfig,
    db: Database,
    storage: LocalStorage,
    move: bool,
    dry_run: bool,
    emit: bool,
) -> tuple[LibraryEntry, list[dict[str, object]]]:
    m = entry.metadata
    before = m.model_dump()

    for k, v in updates.items():
        match k:
            case "title":
                m.title = v
            case "author":
                m.author = v
            case "type" | "doc_type":
                m.doc_type = DocType(v)
            case "year":
                m.year = int(v) if v else None
            case "publisher":
                m.publisher = v or None
            case "isbn":
                m.isbn = v or None
            case "language":
                m.language = v or None
            case "subject":
                m.subject = v or None
            case "summary":
                m.summary = v or None
            case "tags":
                m.tags = [t.strip() for t in v.split(",") if t.strip()] if v else []
            case "topics":
                m.topics = [t.strip() for t in v.split(",") if t.strip()] if v else []
            case _:
                raise click.UsageError(f"Unknown metadata field for --set: {k}")

    changes: list[dict[str, object]] = []
    after = m.model_dump()
    for k in sorted(after.keys()):
        if after[k] != before.get(k):
            changes.append({"field": k, "before": before.get(k), "after": after[k]})

    new_dest = build_dest_path(m)
    old_path = entry.file_path

    if move and new_dest != old_path:
        old_full = config.library_path / old_path
        if old_full.exists():
            if not dry_run:
                final = storage.store(old_full, new_dest)
                old_full.unlink()
                entry.file_path = final
                entry.filename = Path(final).name
            if emit:
                click.echo(f"\nMoved: {old_path} -> {new_dest}")
        else:
            if not dry_run:
                entry.file_path = new_dest
                entry.filename = Path(new_dest).name
            if emit:
                click.echo(f"\nWarning: old file not found at {old_path}, updated path in DB only.")

    if not dry_run:
        db.update(entry)

    return entry, changes


def _get_missing_fields(m) -> list[str]:
    return [k for k, v in m.model_dump().items() if v is None]


def _run_enrich(entry: LibraryEntry, config: WstConfig) -> tuple[list[tuple[str, object]], object]:
    """Run AI enrichment. Returns (changes, enriched_metadata)."""
    m = entry.metadata
    missing = _get_missing_fields(m)

    file_path = config.library_path / entry.file_path
    text_sample = ""
    if file_path.exists():
        try:
            _, text_sample, _ = extract_doc_info(file_path)
        except Exception:
            click.echo("  Warning: could not read file for text context.")

    ai = get_ai_backend(config.ai_backend, config.ai_model)
    click.echo("  Searching with AI...")

    enriched = ai.enrich_metadata(m, text_sample)

    changes = []
    old_dump = m.model_dump()
    new_dump = enriched.model_dump()
    for field in missing:
        if new_dump[field] != old_dump[field]:
            changes.append((field, new_dump[field]))

    return changes, enriched


def _find_entry(db: Database, identifier: str) -> LibraryEntry | None:
    entry = None
    if identifier.isdigit():
        entry = db.get(int(identifier))
    if entry is None:
        entry = db.get_by_title(identifier)
    return entry


def _prompt_field(label: str, current: str) -> str:
    value = click.prompt(f"  {label}", default=current, show_default=True)
    return value.strip()


def _prompt_doc_type(current: DocType) -> DocType:
    types = list(DocType)
    click.echo(f"  Type [{current.value}]:")
    for i, dt in enumerate(types, 1):
        marker = " <-" if dt == current else ""
        click.echo(f"    {i}. {dt.value}{marker}")
    choice = click.prompt("  Choose number or Enter to keep", default="", show_default=False)
    if choice and choice.isdigit() and 1 <= int(choice) <= len(types):
        return types[int(choice) - 1]
    return current


@cli.command()
@command_format_option()
@click.option(
    "--type",
    "doc_type",
    type=click.Choice([dt.value for dt in DocType], case_sensitive=False),
    help="Only fix documents of this type",
)
@click.option(
    "--field",
    multiple=True,
    help="Only fix documents missing this field (e.g. --field isbn --field toc)",
)
@click.option(
    "--topics",
    "fix_topics",
    is_flag=True,
    help="Assign topics (from existing vocabulary) to documents that have none",
)
@click.option("--yes", "-y", is_flag=True, help="Auto-accept all changes without prompting")
@click.option("--dry-run", is_flag=True, help="Show what would be enriched without making changes")
@click.pass_context
def fix(
    ctx: click.Context,
    doc_type: str | None,
    field: tuple[str, ...],
    fix_topics: bool,
    yes: bool,
    dry_run: bool,
) -> None:
    """Enrich all documents that have missing metadata fields.

    \b
    Scans the library for documents with missing fields (ISBN, publisher,
    year, table_of_contents, etc.) and uses AI + web search to fill them.

    \b
    Examples:
        wst fix                         # fix all documents with missing fields
        wst fix --type book             # only books
        wst fix --field isbn            # only those missing ISBN
        wst fix --field isbn --field toc
        wst fix --topics                # assign topics to docs without topics
        wst fix --dry-run               # preview what needs fixing
        wst fix -y                      # fix all docs, auto-accept
        wst fix --dry-run --format json # preview as structured output
        wst fix -y --format yaml        # run non-interactively
    """
    field_map = {"toc": "table_of_contents"}
    target_fields = [field_map.get(f, f) for f in field] if field else None

    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        # --topics shortcut: assign topics to docs that have none
        if fix_topics:
            _fix_topics_cmd(db, config, fmt=fmt, yes=yes, dry_run=dry_run, doc_type=doc_type)
            return

        entries = db.list_all(doc_type=doc_type)

        # Filter to entries with missing fields
        to_fix = []
        for entry in entries:
            missing = _get_missing_fields(entry.metadata)
            if target_fields:
                missing = [f for f in missing if f in target_fields]
            if missing:
                to_fix.append((entry, missing))

        if not to_fix:
            if fmt == "human":
                click.echo("All documents are complete. Nothing to fix.")
                return
            from wst.output import render_ok

            render_ok(
                {
                    "scanned": len(entries),
                    "to_fix": 0,
                    "fixed": 0,
                    "skipped": 0,
                    "failed": 0,
                    "results": [],
                },
                fmt=fmt,
            )
            return

        if fmt != "human" and not dry_run and not yes:
            from wst.output import WstError

            raise WstError(
                "usage_error",
                "Non-interactive fix requires -y/--yes (or use --dry-run).",
                details={"hint": "Try: wst fix -y --format json"},
                exit_code=2,
            )

        if fmt == "human":
            click.echo(f"Found {len(to_fix)} document(s) with missing fields.\n")

        if dry_run:
            preview = []
            for entry, missing in to_fix:
                m = entry.metadata
                preview.append(
                    {
                        "id": entry.id,
                        "title": m.title,
                        "type": m.doc_type.value,
                        "missing_fields": missing,
                    }
                )
            if fmt == "human":
                click.echo(f"{'ID':>4}  {'Title':<40}  {'Type':<12}  Missing fields")
                click.echo("-" * 90)
                for entry, missing in to_fix:
                    m = entry.metadata
                    title = m.title[:38] + ".." if len(m.title) > 40 else m.title
                    click.echo(
                        f"{entry.id:>4}  {title:<40}  {m.doc_type.value:<12}  {', '.join(missing)}"
                    )
                return
            from wst.output import render_ok

            render_ok(
                {
                    "scanned": len(entries),
                    "to_fix": len(to_fix),
                    "preview": preview,
                },
                fmt=fmt,
            )
            return

        fixed = 0
        failed = 0
        skipped = 0
        start = time.monotonic()
        results = []

        for i, (entry, missing) in enumerate(to_fix, 1):
            m = entry.metadata
            if fmt == "human":
                click.echo(f"\n[{i}/{len(to_fix)}] {m.title} (ID {entry.id})")
                click.echo(f"  Missing: {', '.join(missing)}")

            try:
                changes, enriched = _run_enrich(entry, config)
            except Exception as e:
                if fmt == "human":
                    click.echo(f"  Error: {e}")
                failed += 1
                results.append(
                    {
                        "id": entry.id,
                        "status": "failed",
                        "error": str(e),
                    }
                )
                continue

            if not changes:
                if fmt == "human":
                    click.echo("  No new information found.")
                skipped += 1
                results.append({"id": entry.id, "status": "skipped", "changes": []})
                continue

            if fmt == "human":
                click.echo("  Found:")
                for f_name, value in changes:
                    display = value if not isinstance(value, list) else ", ".join(value)
                    # Truncate long values like TOC for display
                    if isinstance(display, str) and len(display) > 80:
                        display = display[:77] + "..."
                    click.echo(f"    {f_name}: {display}")

            if fmt == "human" and not yes:
                if not click.confirm("  Apply?", default=True):
                    skipped += 1
                    results.append({"id": entry.id, "status": "skipped", "changes": changes})
                    continue

            entry.metadata = enriched
            db.update(entry)
            fixed += 1
            results.append({"id": entry.id, "status": "fixed", "changes": changes})
            if fmt == "human":
                click.echo("  Updated.")

        elapsed = time.monotonic() - start
        if fmt == "human":
            click.echo(
                f"\nDone in {int(elapsed)}s: {fixed} fixed, {skipped} skipped, {failed} failed"
            )
            return

        from wst.output import render_ok

        render_ok(
            {
                "scanned": len(entries),
                "to_fix": len(to_fix),
                "fixed": fixed,
                "skipped": skipped,
                "failed": failed,
                "elapsed_seconds": elapsed,
                "results": results,
            },
            fmt=fmt,
        )
    finally:
        db.close()


@cli.command()
@click.option(
    "--type",
    "-t",
    "doc_type",
    default=None,
    type=click.Choice([dt.value for dt in DocType], case_sensitive=False),
    help="Only process documents of this type",
)
@click.option(
    "--missing",
    is_flag=True,
    default=False,
    help="List documents missing covers without generating them",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Regenerate all covers, even those already cached",
)
@click.pass_context
def covers(ctx: click.Context, doc_type: str | None, missing: bool, force: bool) -> None:
    """Download and cache cover images for all documents.

    \b
    For documents with ISBN: fetches from Open Library.
    For documents without ISBN (or no cover found): renders
    the first page of the PDF as a thumbnail.

    \b
    Covers are cached at ~/wst/library/.covers/ and used
    by the desktop app.

    \b
    Examples:
        wst covers                  # generate missing covers
        wst covers --force          # regenerate all covers
        wst covers --missing        # list docs without covers
        wst covers --type textbook  # only textbooks
    """
    from wst.covers import ensure_cover, get_cached_cover

    config: WstConfig = ctx.obj["config"]
    db = Database(config.db_path)

    try:
        entries = db.list_all(doc_type=doc_type)
        total = len(entries)

        if force:
            missing_entries = entries
        else:
            missing_entries = [
                e for e in entries if get_cached_cover(config.library_path, e.id) is None
            ]

        if missing:
            if not missing_entries:
                click.echo("All documents have covers.")
                return
            click.echo(f"{len(missing_entries)} document(s) missing covers:")
            for e in missing_entries:
                source = "PDF" if not e.metadata.isbn else "ISBN"
                click.echo(f"  [{e.id}] {e.metadata.title[:60]} ({source})")
            return

        already = total - len(missing_entries)
        click.echo(f"Total: {total}, cached: {already}, to fetch: {len(missing_entries)}")

        if not missing_entries:
            click.echo("All covers are cached.")
            return

        fetched = 0
        failed = 0
        start = time.monotonic()

        for i, entry in enumerate(missing_entries, 1):
            m = entry.metadata
            name = m.title[:40] + ".." if len(m.title) > 42 else m.title
            source = "ISBN" if m.isbn else "PDF"
            click.echo(f"  [{i}/{len(missing_entries)}] {name} ({source})...", nl=False)

            result = ensure_cover(config.library_path, entry.id, m.isbn, entry.file_path)

            if result:
                fetched += 1
                click.echo(" ok")
            else:
                failed += 1
                click.echo(" failed")

        elapsed = time.monotonic() - start
        click.echo(f"\nDone in {int(elapsed)}s: {fetched} fetched, {failed} failed")
    finally:
        db.close()


def _print_table(entries: list) -> None:
    """Print a simple table of entries."""
    click.echo(f"{'ID':>4}  {'Title':<40}  {'Author':<25}  {'Type':<12}  {'Year':>4}")
    click.echo("-" * 93)
    for e in entries:
        m = e.metadata
        title = m.title[:38] + ".." if len(m.title) > 40 else m.title
        author = m.author[:23] + ".." if len(m.author) > 25 else m.author
        year = str(m.year) if m.year else "N/A"
        click.echo(f"{e.id:>4}  {title:<40}  {author:<25}  {m.doc_type.value:<12}  {year:>4}")


# ---------------------------------------------------------------------------
# Topics group
# ---------------------------------------------------------------------------


@cli.group()
@command_format_option()
@click.pass_context
def topics(ctx: click.Context) -> None:
    """Manage high-level topic vocabulary and document assignments.

    \b
    Commands:
      build     Generate vocabulary from corpus and assign to all documents.
      list      Show the current topic vocabulary.
      assign    (Re)assign topics to one or all documents.
      subjects  Show the topic → subject mapping.
    """


@topics.command("build")
@command_format_option()
@click.option(
    "--n-topics",
    "n_topics",
    type=int,
    default=None,
    help="Number of topics to generate (default: auto-detect via silhouette score)",
)
@click.option("--yes", "-y", is_flag=True, help="Overwrite existing vocabulary without prompting")
@click.pass_context
def topics_build(ctx: click.Context, n_topics: int | None, yes: bool) -> None:
    """Generate topic vocabulary from the corpus and assign to all documents.

    \b
    Steps:
      1. Embed all documents with a multilingual sentence-transformer.
      2. Cluster with KMeans (auto-detect optimal k or use --n-topics).
      3. Name each cluster via AI.
      4. Assign 1-3 topics to every document.
      5. Save vocabulary to the database.

    \b
    Examples:
        wst topics build
        wst topics build --n-topics 12
        wst topics build -y --format json
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        from wst.topics import assign_topics, backfill_subjects, build_vocabulary, save_vocabulary

        # Check for existing vocabulary
        existing = db.load_topics_vocabulary()
        if existing and not yes:
            if fmt != "human":
                from wst.output import WstError

                raise WstError(
                    "usage_error",
                    "Vocabulary already exists. Use -y/--yes to overwrite.",
                    details={"hint": "Try: wst topics build -y --format json"},
                    exit_code=2,
                )
            if not click.confirm(
                f"Vocabulary already exists ({len(existing)} topics). Overwrite?", default=False
            ):
                click.echo("Aborted.")
                return

        ai = get_ai_backend(config.ai_backend, config.ai_model)

        if fmt == "human":
            click.echo("Step 1/4  Embedding documents and clustering...")
        # Pass existing vocab size as minimum so adding a few new documents
        # doesn't collapse the vocabulary to a smaller number of topics.
        min_topics = len(existing) if existing else None
        vocabulary, representative_docs, topic_to_subject = build_vocabulary(
            db, ai, n_topics=n_topics, min_topics=min_topics
        )

        if not vocabulary:
            if fmt == "human":
                click.echo("Library is empty — nothing to build.")
                return
            from wst.output import render_ok

            render_ok({"vocabulary": [], "assignments": {}}, fmt=fmt)
            return

        if fmt == "human":
            click.echo(f"          Generated {len(vocabulary)} topics: {', '.join(vocabulary)}")
            if existing:
                old_set = set(existing)
                new_set = set(vocabulary)
                added = sorted(new_set - old_set)
                removed = sorted(old_set - new_set)
                if added or removed:
                    click.echo("          Changes vs previous vocabulary:")
                    for t in added:
                        click.echo(f"            + {t}")
                    for t in removed:
                        click.echo(f"            - {t}")
                else:
                    click.echo("          (No changes vs previous vocabulary)")

        # --- Interactive review/edit (human mode without -y) ---
        if fmt == "human" and not yes:
            vocabulary = _review_vocabulary_interactive(vocabulary, representative_docs)
            if vocabulary is None:
                click.echo("Cancelado.")
                return

        if fmt == "human":
            click.echo("Step 2/4  Assigning topics to documents...")

        assignments = assign_topics(db, ai, vocabulary)

        if fmt == "human":
            click.echo("Step 3/4  Saving to database...")

        save_vocabulary(db, vocabulary, topic_to_subject)

        # Persist topic assignments
        entries = db.list_all()
        entry_map = {e.id: e for e in entries}
        for doc_id, assigned in assignments.items():
            entry = entry_map.get(doc_id)
            if entry is None:
                continue
            entry.metadata.topics = assigned
            db.update(entry)

        # Backfill subjects from topic→subject mapping
        if fmt == "human":
            click.echo("Step 4/4  Backfilling subjects from topic clusters...")
        subject_updated = backfill_subjects(db, topic_to_subject)

        if fmt == "human":
            click.echo(f"\nDone. {len(assignments)} document(s) assigned topics.")
            click.echo(f"      {subject_updated} document(s) had their subject updated.")
            click.echo(f"Vocabulary ({len(vocabulary)}): {', '.join(vocabulary)}")
            return

        from wst.output import render_ok

        render_ok(
            {
                "vocabulary": vocabulary,
                "subjects": topic_to_subject,
                "assigned_count": len(assignments),
                "subjects_updated": subject_updated,
                "assignments": {str(k): v for k, v in assignments.items()},
            },
            fmt=fmt,
        )
    finally:
        db.close()


@topics.command("list")
@command_format_option()
@click.pass_context
def topics_list(ctx: click.Context) -> None:
    """Show the current topic vocabulary.

    \b
    Examples:
        wst topics list
        wst topics list --format json
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        vocabulary = db.load_topics_vocabulary()
        if not vocabulary:
            if fmt == "human":
                click.echo("No topic vocabulary found. Run `wst topics build` first.")
                return
            from wst.output import render_ok

            render_ok({"vocabulary": []}, fmt=fmt)
            return

        if fmt == "human":
            click.echo(f"Topic vocabulary ({len(vocabulary)} topics):")
            for i, t in enumerate(vocabulary, 1):
                click.echo(f"  {i:>3}. {t}")
            return

        from wst.output import render_ok

        render_ok({"vocabulary": vocabulary}, fmt=fmt)
    finally:
        db.close()


@topics.command("assign")
@command_format_option()
@click.option("--id", "doc_id", type=int, default=None, help="Assign topics to a single document")
@click.option("--yes", "-y", is_flag=True, help="Apply without prompting")
@click.pass_context
def topics_assign(ctx: click.Context, doc_id: int | None, yes: bool) -> None:
    """(Re)assign topics to a specific document or all documents.

    \b
    Requires a vocabulary already built with `wst topics build`.

    \b
    Examples:
        wst topics assign --id 3
        wst topics assign           # reassign all documents
        wst topics assign -y --format json
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        from wst.topics import assign_topics, backfill_subjects

        vocabulary = db.load_topics_vocabulary()
        if not vocabulary:
            if fmt == "human":
                click.echo("No vocabulary found. Run `wst topics build` first.")
                raise SystemExit(1)
            from wst.output import WstError

            raise WstError(
                "not_found",
                "No topic vocabulary found. Run `wst topics build` first.",
                exit_code=1,
            )

        ai = get_ai_backend(config.ai_backend, config.ai_model)

        if doc_id is not None:
            entry = db.get(doc_id)
            if entry is None:
                if fmt == "human":
                    click.echo(f"Document {doc_id} not found.")
                    raise SystemExit(1)
                from wst.output import WstError

                raise WstError("not_found", f"Document {doc_id} not found.", exit_code=1)
            entries_to_assign = [entry]
        else:
            entries_to_assign = db.list_all()

        if fmt == "human" and not yes and not doc_id:
            if not click.confirm(
                f"Reassign topics for all {len(entries_to_assign)} document(s)?", default=True
            ):
                click.echo("Aborted.")
                return

        assignments = assign_topics(db, ai, vocabulary)

        entry_map = {e.id: e for e in entries_to_assign}
        updated = 0
        for eid, assigned_topics in assignments.items():
            entry = entry_map.get(eid)
            if entry is None:
                continue
            entry.metadata.topics = assigned_topics
            db.update(entry)
            updated += 1

        # Backfill subjects from stored topic→subject mapping
        topic_to_subject = db.load_topics_subjects()
        subject_updated = backfill_subjects(db, topic_to_subject) if topic_to_subject else 0

        if fmt == "human":
            click.echo(f"Assigned topics to {updated} document(s).")
            if subject_updated:
                click.echo(f"Updated subjects for {subject_updated} document(s).")
            return

        from wst.output import render_ok

        render_ok(
            {
                "updated": updated,
                "subjects_updated": subject_updated,
                "assignments": {str(k): v for k, v in assignments.items()},
            },
            fmt=fmt,
        )
    finally:
        db.close()


@topics.command("subjects")
@command_format_option()
@click.pass_context
def topics_subjects(ctx: click.Context) -> None:
    """Show the topic → subject mapping derived from clustering.

    \b
    Examples:
        wst topics subjects
        wst topics subjects --format json
    """
    config: WstConfig = ctx.obj["config"]
    fmt: str = ctx.obj.get("format", "human")
    db = Database(config.db_path)

    try:
        topic_to_subject = db.load_topics_subjects()
        if not topic_to_subject:
            if fmt == "human":
                click.echo("No subject mapping found. Run `wst topics build` first.")
                return
            from wst.output import render_ok

            render_ok({"subjects": {}}, fmt=fmt)
            return

        if fmt == "human":
            # Group by subject for readability
            from collections import defaultdict

            by_subject: dict[str, list[str]] = defaultdict(list)
            for topic, subject in topic_to_subject.items():
                by_subject[subject].append(topic)
            click.echo(f"Topic → Subject mapping ({len(topic_to_subject)} topics):")
            for subject in sorted(by_subject):
                topics_in = ", ".join(sorted(by_subject[subject]))
                click.echo(f"  {subject}: {topics_in}")
            return

        from wst.output import render_ok

        render_ok({"subjects": topic_to_subject}, fmt=fmt)
    finally:
        db.close()


def _review_vocabulary_interactive(
    vocabulary: list[str],
    representative_docs: dict[int, list[str]] | None = None,
) -> list[str] | None:
    """Show the generated vocabulary and let the user confirm, cancel, or edit topics.

    Args:
        vocabulary: The list of topic names to review.
        representative_docs: Optional mapping of cluster index (0-based) to a list of
            up to 3 representative document titles for that cluster.

    Returns the (possibly edited) vocabulary list, or None if the user cancelled.
    """
    rep_docs = representative_docs or {}

    while True:
        click.echo(f"\nTópicos generados ({len(vocabulary)}):\n")
        for i, topic in enumerate(vocabulary, 1):
            cluster_idx = i - 1
            docs = rep_docs.get(cluster_idx, [])
            click.echo(f"  {i}. {topic}")
            for doc_title in docs:
                click.echo(f"     • {doc_title}")
            if docs:
                click.echo("")

        raw = input("¿Aceptás estos tópicos? [S/n/editar número]: ").strip()

        if raw == "" or raw.lower() in ("s", "si", "sí", "y", "yes"):
            return vocabulary

        if raw.lower() in ("n", "no"):
            return None

        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(vocabulary):
                cluster_idx = idx - 1
                current = vocabulary[cluster_idx]
                docs = rep_docs.get(cluster_idx, [])
                click.echo(f'\nTópico {idx} actual: "{current}"')
                if docs:
                    click.echo("  Documentos representativos:")
                    for doc_title in docs:
                        click.echo(f"    • {doc_title}")
                new_name = input("Nuevo nombre (Enter para mantener): ").strip()
                if new_name:
                    vocabulary = list(vocabulary)
                    vocabulary[cluster_idx] = new_name
            else:
                click.echo(f"Número fuera de rango. Ingresá un número entre 1 y {len(vocabulary)}.")
        else:
            click.echo("Opción no válida. Usá S (confirmar), n (cancelar) o un número para editar.")


def _fix_topics_cmd(
    db: Database,
    config: WstConfig,
    *,
    fmt: str,
    yes: bool,
    dry_run: bool,
    doc_type: str | None,
) -> None:
    """Assign topics (from existing vocabulary) to documents that have none."""
    from wst.topics import assign_topics, backfill_subjects

    vocabulary = db.load_topics_vocabulary()
    if not vocabulary:
        if fmt == "human":
            click.echo("No vocabulary found. Run `wst topics build` first.")
            raise SystemExit(1)
        from wst.output import WstError

        raise WstError(
            "not_found",
            "No topic vocabulary found. Run `wst topics build` first.",
            exit_code=1,
        )

    entries = db.list_all(doc_type=doc_type)
    without_topics = [e for e in entries if not e.metadata.topics]

    if not without_topics:
        if fmt == "human":
            click.echo("All documents already have topics assigned.")
            return
        from wst.output import render_ok

        render_ok({"scanned": len(entries), "updated": 0}, fmt=fmt)
        return

    if fmt == "human":
        click.echo(f"Found {len(without_topics)} document(s) without topics.")

    if dry_run:
        preview = [{"id": e.id, "title": e.metadata.title} for e in without_topics]
        if fmt == "human":
            for item in preview:
                click.echo(f"  [{item['id']}] {item['title']}")
            return
        from wst.output import render_ok

        render_ok(
            {"scanned": len(entries), "to_assign": len(without_topics), "preview": preview}, fmt=fmt
        )
        return

    if fmt != "human" and not yes:
        from wst.output import WstError

        raise WstError(
            "usage_error",
            "Non-interactive --topics fix requires -y/--yes (or use --dry-run).",
            details={"hint": "Try: wst fix --topics -y --format json"},
            exit_code=2,
        )

    ai = get_ai_backend(config.ai_backend, config.ai_model)
    assignments = assign_topics(db, ai, vocabulary)

    entry_map = {e.id: e for e in without_topics}
    updated = 0
    for doc_id, assigned_topics in assignments.items():
        entry = entry_map.get(doc_id)
        if entry is None:
            continue
        entry.metadata.topics = assigned_topics
        db.update(entry)
        updated += 1

    topic_to_subject = db.load_topics_subjects()
    backfill_subjects(db, topic_to_subject)

    if fmt == "human":
        click.echo(f"Assigned topics to {updated} document(s).")
        return

    from wst.output import render_ok

    render_ok({"scanned": len(entries), "updated": updated}, fmt=fmt)


@cli.command("install")
@click.argument("extra", required=False)
@click.option("--list", "list_extras", is_flag=True, help="Show install status for all extras.")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output (with --list).")
@click.option("--upgrade", is_flag=True, help="Upgrade an already-installed extra.")
def install_cmd(extra: str | None, list_extras: bool, as_json: bool, upgrade: bool) -> None:
    """Install optional feature packages (ocr, topics).

    \b
    Examples:
      wst install ocr           # install OCR support + system deps
      wst install topics        # install topic modeling support
      wst install ocr --upgrade # upgrade OCR packages
      wst install --list        # show what's installed
    """
    from wst.install import install_extra
    from wst.install import list_extras as _list_extras

    if list_extras or (extra is None and not upgrade):
        _list_extras(as_json=as_json)
        return

    if extra is None:
        raise click.UsageError("Specify an extra to install, or use --list.")

    try:
        install_extra(extra, upgrade=upgrade)
    except ValueError as e:
        raise click.BadParameter(str(e), param_hint="extra") from e
    except Exception as e:
        raise click.ClickException(str(e)) from e
