---
description: Read trial artifacts and return result_summary.json
agent: build
---

Read the attached files for:

- `study_name`: `$1`
- `task`: `$2`
- `trial_id`: `$3`
- `primary_metric`: `$4`

Required attached files:

- `test.json`

Optional attached files:

- `evaluate.json`
- `best_trial.json`
- `recent result_summary.json`

Task:

1. Follow the inline guidance included below for result summarization. Do not call any skill tool.
2. Read the test and evaluation artifacts.
3. Produce the final contents of `result_summary.json`.
4. Keep the output concise, structured, and grounded in the attached files.
5. Do not ask for shell access or return prose outside the JSON object.

Return only one JSON object.
No markdown fences.
No prose before or after the JSON.
