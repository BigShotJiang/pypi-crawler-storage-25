import os
import warnings
import requests
import openai

# --- Warnings Suppression ---
warnings.filterwarnings("ignore")
os.environ["PYTHONWARNINGS"] = "ignore"

import google.generativeai as genai

# --- Configuration ---

# Gemini մոդելները (դասավորված ըստ առաջնահերթության)
GEMINI_MODELS = [
    "models/deep-research-max-preview-04-2026",
    "models/deep-research-pro-preview-12-2025",
    "models/deep-research-preview-04-2026",
    "models/gemini-3.1-pro-preview",
    "models/gemini-3.1-pro-preview-agent",
    "models/gemini-3-pro-preview",
    "models/gemini-2.5-pro",
    "models/gemini-pro-latest",
    "models/gemini-3.1-flash-lite",
    "models/gemini-3.1-flash-lite-preview",
    "models/gemini-3-flash-preview",
    "models/gemini-3-flash-preview-agent",
    "models/gemini-2.5-flash",
    "models/gemini-2.0-flash",
    "models/gemini-flash-latest",
    "models/gemini-flash-lite-latest",
    "models/gemini-2.5-flash-lite"
]

DEFAULT_GEMINI_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyBOHMazGo02uXHvjbklXWxVEvyN42BC_o0")
DEFAULT_MISTRAL_KEY = os.getenv("MISTRAL_API_KEY", "83m7bHL52JrfeG8mD910gy2PHxQ9wBRa")

def _get_api_key(provider="gemini", provided_key=None):
    if provided_key:
        return provided_key
    return DEFAULT_GEMINI_KEY if provider == "gemini" else DEFAULT_MISTRAL_KEY

def max(prompt, api_key=None):
    """
    OpenAI հարցում GPT-5.5 մոդելով (AIHubMix):
    """
    if not api_key:
        api_key = "sk-LZxka2a94epk4mpE56442fF209Db401f869fCf78CdFb3c97"
        
    client = openai.OpenAI(
        api_key=api_key,
        base_url="https://aihubmix.com/v1"
    )

    try:
        response = client.chat.completions.create(
            model="gpt-5.5-free",
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"OpenAI (GPT-5.5) Սխալ: {str(e)}"

def min(prompt, api_key=None):
    """
    Mistral AI հարցում:
    """
    url = "https://api.mistral.ai/v1/chat/completions"
    key = _get_api_key("mistral", api_key)
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}"
    }
    
    data = {
        "model": "mistral-large-latest",
        "messages": [{"role": "user", "content": prompt}]
    }
    
    try:
        response = requests.post(url, headers=headers, json=data, timeout=10)
        if response.status_code == 200:
            return response.json()["choices"][0]["message"]["content"]
        else:
            return f"Mistral Սխալ {response.status_code}: {response.text}"
    except Exception as e:
        return f"Mistral-ի հետ կապի սխալ (հնարավոր է DNS խնդիր): {str(e)}"

def hello():
    return "Ողջույն nampy-ից: Պատրաստ եմ աշխատել max (Gemini), min (Mistral) և help() ֆունկցիաներով:"

def help():
    text = """
import tensorflow as tf
import numpy as np
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Input, Flatten, Dropout, Conv2D, MaxPooling2D, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import regularizers

1. ՌԵԳՐԵՍԻԱ (Թվերի կանխատեսում. գին, տարիք, աշխատավարձ)
   - Վերջին շերտը՝ Dense(1) առանց activation-ի
   - Loss (Սխալի չափիչ)՝
       * Ստանդարտ. loss='mse' (զգայուն է շեղումների նկատմամբ)
       * Ավելի լավ. loss='mae' (ավելի կայուն է)
       * ԼԱՎԱԳՈՒՅՆ (ՊՐՈ). loss=tf.keras.losses.Huber() (խելացի հիբրիդ է)
   - Metrics (Գնահատական)՝
       * metrics=['mae', tf.keras.metrics.RootMeanSquaredError(name='rmse')]
       * Բիզնեսի համար խորհուրդ տրվող. metrics=['mape'] (%-ային սխալ)

---------------------------------------------------------------------

2. ԵՐԿՈՒԱԿԱՆ ԴԱՍԱԿԱՐԳՈՒՄ (Այո/Ոչ, Հիվանդ է / Առողջ է, Սպամ / Ոչ սպամ)
   - Վերջին շերտը՝ Dense(1, activation='sigmoid')
   - Loss (Սխալի չափիչ)՝
       * Ստանդարտ. loss='binary_crossentropy'
   - Metrics (Գնահատական)՝
       * Ստանդարտ. metrics=['accuracy'] (ՎԱՏ է դիսբալանսի դեպքում)
       * ԼԱՎԱԳՈՒՅՆ (ՊՐՈ).
         metrics=[
             'accuracy',
             tf.keras.metrics.Precision(name='precision'),
             tf.keras.metrics.Recall(name='recall'),
             tf.keras.metrics.AUC(name='auc_roc')
         ]

---------------------------------------------------------------------

3. ԲԱԶՄԱԴԱՍ ԴԱՍԱԿԱՐԳՈՒՄ (3 և ավելի դասեր. Շուն, Կատու, Մուկ)
   - Վերջին շերտը՝ Dense(դասերի_քանակ, activation='softmax')
   - Loss (Սխալի չափիչ)՝
       * Վատ (հիշողություն լցնող). loss='categorical_crossentropy' (պահանջում է One-Hot)
       * ԼԱՎԱԳՈՒՅՆ (ՊՐՈ). loss='sparse_categorical_crossentropy' (աշխատում է պարզ թվերով՝ 0, 1, 2)
   - Metrics (Գնահատական)՝
       * Ստանդարտ. metrics=['accuracy']
       * Շատ դասերի դեպքում (ՊՐՈ). metrics=['accuracy', tf.keras.metrics.SparseTopKCategoricalAccuracy(k=3)]
         (Համարվում է ճիշտ, եթե ճիշտ պատասխանը մոդելի առաջարկած լավագույն 3 տարբերակների մեջ է)

---------------------------------------------------------------------

4. ՕՊՏԻՄԻԶԱՏՈՐՆԵՐ (Optimizers - Ինչպե՞ս է մոդելը սովորում և ուղղում սխալները)

   * ՎԱՏ / ՀՆԱՑԱԾ (Բայց տեսության համար լավն է).
     optimizer='sgd' (կամ tf.keras.optimizers.SGD(learning_rate=0.01))
     - Դանդաղ է, հաճախ խրվում է «փոսերի» մեջ և չի գտնում լավագույն լուծումը:

   * ԼԱՎ / ՍՏԱՆԴԱՐՏ (Աշխատում է դեպքերի 90%-ում).
     optimizer=tf.keras.optimizers.Adam(learning_rate=0.001)
     - Ոսկե միջինն է։ Ինքն իրեն հասկանում է, թե որ կշիռը (weight) որքանով փոխի։
     - Նշում: learning_rate=0.01 դրվում է փոքր տվյալներով արագ սովորելու համար, բայց բարդ խնդիրներում 0.001-ը կամ 0.0001-ն ավելի ապահով են:

   * ՀԱՏՈՒԿ ԴԵՊՔԵՐԻ ՀԱՄԱՐ.
     optimizer=tf.keras.optimizers.RMSprop(learning_rate=0.001)
     - Լավագույնն է ժամանակագրական տվյալների կամ տեքստերի վերլուծության համար (RNN, LSTM մոդելներ):

   * ԼԱՎԱԳՈՒՅՆ / ՊՐՈՖԵՍԻՈՆԱԼ (Ժամանակակից ստանդարտ).
     optimizer=tf.keras.optimizers.AdamW(learning_rate=0.001, weight_decay=0.004)
     - Սա Adam-ի բարելավված տարբերակն է (Adam with Weight Decay)։
     - Թույլ չի տալիս, որ մոդելը անգիր անի տվյալները (Overfitting)։ Օգտագործվում է աշխարհի լավագույն մոդելներում (օրինակ՝ ChatGPT, Vision Transformers):

---------------------------------------------------------------------

# Օրինակ 1. Պարզ Ռեգրեսիա + Advanced Layers
X_reg = np.array([1.0, 2.0, 3.0, 4.0, 5.0], dtype=float)
y_reg = np.array([3.0, 6.0, 9.0, 12.0, 15.0], dtype=float)

model_reg = Sequential([
    Input(shape=(1,)),
    Dense(64, activation='relu', kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4)),
    BatchNormalization(),
    Dropout(0.3),
    Dense(32, activation='relu'),
    Dense(1)
])

model_reg.compile(optimizer=Adam(learning_rate=0.01), loss='mse', metrics=['mae'])
model_reg.fit(X_reg, y_reg, epochs=100, verbose=0)
print(f"Կանխատեսում 10-ի համար: {model_reg.predict(np.array([10.0]), verbose=0)}")

# Օրինակ 2. Բազմադաս Դասակարգում (CNN + MNIST)
from tensorflow.keras.datasets import mnist
(X_train, y_train), (X_test, y_test) = mnist.load_data()
X_train = X_train.reshape(-1, 28, 28, 1).astype('float32') / 255

model_cnn = Sequential([
    Input(shape=(28, 28, 1)),
    Conv2D(32, (3, 3), activation='relu'),
    BatchNormalization(),
    MaxPooling2D((2, 2)),
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(10, activation='softmax')
])

model_cnn.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
# model_cnn.fit(X_train, y_train, epochs=5, batch_size=32, validation_split=0.2) #validation_data=(X_val, y_val)
"""
    print(text)