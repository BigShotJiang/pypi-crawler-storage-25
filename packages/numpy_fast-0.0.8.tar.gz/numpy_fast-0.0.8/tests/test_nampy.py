import nampy_fast

print(nampy_fast.max("Բարև, դու ո՞ր մոդելն ես:"))

print(nampy_fast.min("Ողջույն Mistral!"))
