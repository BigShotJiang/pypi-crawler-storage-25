#
# Copyright 2026 Tabs Data Inc.
#

DEFAULT_TIME_ROLLOVER_SECS = 60

AWS_ACCESS_KEY_ID = "AWS_ACCESS_KEY_ID"
AWS_SECRET_ACCESS_KEY = "AWS_SECRET_ACCESS_KEY"
AWS_DEFAULT_REGION = "AWS_DEFAULT_REGION"


CONSUME_TIMEOUT_SECS = 2
CONNECTION_TIMEOUT_SECS = 16

BOOTSTRAP_SERVERS_KEY = "bootstrap.servers"
AUTO_OFFSET_RESET_KEY = "auto.offset.reset"
ENABLE_AUTO_COMMIT_KEY = "enable.auto.commit"
SECURITY_PROTOCOL_KEY = "security.protocol"
SASL_MECHANISM_KEY = "sasl.mechanism"
SASL_USERNAME_KEY = "sasl.username"
SASL_PASSWORD_KEY = "sasl.password"
GROUP_ID_KEY = "group.id"
URL_KEY = "url"
BASIC_AUTH_USER_INFO_KEY = "basic.auth.user.info"
REGION_NAME_KEY = "region_name"

_AVRO = "avro"
_JSON = "json"
_PROTOBUF = "protobuf"
