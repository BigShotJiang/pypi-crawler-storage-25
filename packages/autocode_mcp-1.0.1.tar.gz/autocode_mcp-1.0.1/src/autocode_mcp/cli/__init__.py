"""CLI helpers for AutoCode."""
