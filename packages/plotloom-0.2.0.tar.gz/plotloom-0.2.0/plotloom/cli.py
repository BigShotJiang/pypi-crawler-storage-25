from __future__ import annotations

import json
import re
import sys

import click

from plotloom import __version__
from plotloom.errors import PlotloomError


def _error_code(error: click.ClickException) -> str:
    name = error.__class__.__name__
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).upper()


def _wants_json(args: list[str]) -> bool:
    return "--json" in args


def _normalize_json_args(args: list[str]) -> list[str]:
    if "--json" not in args or "--help" in args or "-h" in args or "--version" in args:
        return args
    normalized = [arg for arg in args if arg != "--json"]
    return ["--json", *normalized]


def _attempted_command(args: list[str]) -> str:
    options_with_values = {
        "--adapter",
        "--audio",
        "--clip",
        "--clips",
        "--character",
        "--config",
        "--duration",
        "--duration-tolerance",
        "--episode",
        "--file",
        "--fps",
        "--include-candidates",
        "--kind",
        "--mode",
        "--output",
        "--path",
        "--prompt-file",
        "--ratio",
        "--repo",
        "--resolution",
        "--scene",
        "--status",
        "--task-id",
        "--timeout",
        "--title",
    }
    flag_options = {"--json", "--quiet", "--dry-run", "--candidate", "--include-candidates", "-h", "--help"}
    parts: list[str] = []
    skip_next = False
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in options_with_values:
            skip_next = True
            continue
        if arg in flag_options:
            continue
        if arg.startswith("-"):
            continue
        parts.append(arg)
        if len(parts) == 2:
            break
    if not parts:
        return "unknown"
    if parts[0] == "config":
        if len(parts) > 1 and parts[1] in {"doctor", "init", "path"}:
            return f"config.{parts[1]}"
        return "config"
    if parts[0] == "repos":
        if len(parts) > 1 and parts[1] in {"add", "list", "remove", "resolve", "set-status"}:
            return f"repos.{parts[1]}"
        return "repos"
    if parts[0] == "media":
        if len(parts) > 1 and parts[1] in {"check", "normalize", "probe"}:
            return f"media.{parts[1]}"
        return "media"
    if parts[0] == "prompt":
        if len(parts) > 1 and parts[1] in {"check", "compile", "extract", "list"}:
            return f"prompt.{parts[1]}"
        return "prompt"
    if parts[0] == "image":
        if len(parts) > 1 and parts[1] in {"generate"}:
            return f"image.{parts[1]}"
        return "image"
    if parts[0] == "asset":
        if len(parts) > 1 and parts[1] in {"import", "info", "list"}:
            return f"asset.{parts[1]}"
        return "asset"
    if parts[0] == "delivery":
        if len(parts) > 1 and parts[1] in {"files", "summary"}:
            return f"delivery.{parts[1]}"
        return "delivery"
    if parts[0] == "stitch":
        if len(parts) > 1 and parts[1] == "plan":
            return "stitch.plan"
        return "stitch"
    if parts[0] == "video":
        if len(parts) > 1 and parts[1] in {"compare", "poll", "submit"}:
            return f"video.{parts[1]}"
        return "video"
    if parts[0] == "youtube":
        if len(parts) > 1 and parts[1] in {"auth", "upload"}:
            return f"youtube.{parts[1]}"
        return "youtube"
    if parts[0] in {"init", "validate"}:
        return f"repo.{parts[0]}"
    return parts[0]


def _exit_code(error: click.ClickException) -> int:
    if isinstance(error, click.UsageError):
        return 1
    return error.exit_code


class PlotloomGroup(click.Group):
    def main(
        self,
        args: list[str] | tuple[str, ...] | None = None,
        prog_name: str | None = None,
        complete_var: str | None = None,
        standalone_mode: bool = True,
        windows_expand_args: bool = True,
        **extra: object,
    ) -> object:
        args_list = list(sys.argv[1:] if args is None else args)
        normalized_args = _normalize_json_args(args_list)
        try:
            result = super().main(
                args=normalized_args,
                prog_name=prog_name,
                complete_var=complete_var,
                standalone_mode=False,
                windows_expand_args=windows_expand_args,
                **extra,
            )
            if standalone_mode and isinstance(result, int):
                sys.exit(result)
            return result
        except PlotloomError as error:
            if _wants_json(args_list):
                payload = {
                    "ok": False,
                    "command": _attempted_command(normalized_args),
                    "error": {
                        "code": error.code,
                        "message": error.message,
                    },
                }
                if error.next_step:
                    payload["error"]["next_step"] = error.next_step
                click.echo(json.dumps(payload, ensure_ascii=False))
            else:
                click.echo(f"Error: {error.message}", err=True)
                if error.next_step:
                    click.echo(f"Next step: {error.next_step}", err=True)
            if standalone_mode:
                sys.exit(error.exit_code)
            raise
        except click.ClickException as error:
            if _wants_json(args_list):
                click.echo(
                    json.dumps(
                        {
                            "ok": False,
                            "command": _attempted_command(args_list),
                            "error": {
                                "code": _error_code(error),
                                "message": error.format_message(),
                            },
                        },
                        ensure_ascii=False,
                    )
                )
            else:
                error.show()
            if standalone_mode:
                sys.exit(_exit_code(error))
            raise
        except click.exceptions.Exit as error:
            if standalone_mode:
                sys.exit(error.exit_code)
            raise


@click.group(cls=PlotloomGroup, context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="plotloom")
@click.option("--repo", type=click.Path(path_type=str), help="Series repo path.")
@click.option("--config", "config_path", type=click.Path(path_type=str), help="Config file path.")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON to stdout.")
@click.option("--quiet", is_flag=True, help="Only print critical paths/status.")
@click.option("--dry-run", is_flag=True, help="Show planned actions without provider calls.")
@click.pass_context
def main(ctx: click.Context, repo: str | None, config_path: str | None, as_json: bool, quiet: bool, dry_run: bool) -> None:
    """Plotloom short-drama production CLI."""
    ctx.ensure_object(dict)
    ctx.obj.update({"repo": repo, "config_path": config_path, "as_json": as_json, "quiet": quiet, "dry_run": dry_run})


from plotloom.commands.config import config_group  # noqa: E402
from plotloom.commands.asset import asset_group  # noqa: E402
from plotloom.commands.delivery import delivery_group  # noqa: E402
from plotloom.commands.doctor import doctor_command  # noqa: E402
from plotloom.commands.image import image_group  # noqa: E402
from plotloom.commands.media import media_group  # noqa: E402
from plotloom.commands.prompt import prompt_group  # noqa: E402
from plotloom.commands.repo import init_command, validate_command  # noqa: E402
from plotloom.commands.repos import repos_group  # noqa: E402
from plotloom.commands.select import select_command  # noqa: E402
from plotloom.commands.stitch import stitch_group  # noqa: E402
from plotloom.commands.video import video_group  # noqa: E402
from plotloom.commands.youtube import youtube_group  # noqa: E402

main.add_command(asset_group)
main.add_command(config_group)
main.add_command(delivery_group)
main.add_command(doctor_command)
main.add_command(image_group)
main.add_command(init_command)
main.add_command(media_group)
main.add_command(prompt_group)
main.add_command(repos_group)
main.add_command(select_command)
main.add_command(stitch_group)
main.add_command(validate_command)
main.add_command(video_group)
main.add_command(youtube_group)


if __name__ == "__main__":
    main()
