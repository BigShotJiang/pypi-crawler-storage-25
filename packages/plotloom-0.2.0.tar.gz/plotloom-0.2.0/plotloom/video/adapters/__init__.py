"""Video adapter implementations."""
