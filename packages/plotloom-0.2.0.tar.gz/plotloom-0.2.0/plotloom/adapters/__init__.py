"""External adapter implementations."""
