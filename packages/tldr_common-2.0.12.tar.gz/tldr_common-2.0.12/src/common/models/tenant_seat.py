# common/models/tenant_seat.py
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class TenantSeat(BaseModel):
    id: int
    user_id: int
    email: str
    name: str
    created_at: datetime
    deleted_at: Optional[datetime] = None
