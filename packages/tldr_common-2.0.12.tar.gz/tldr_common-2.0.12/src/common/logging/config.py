from typing import Optional

from dotenv import find_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict


class LogFireSettings(BaseSettings):
    log_env: str = "development"
    logfire_write_token: Optional[str] = None

    model_config = SettingsConfigDict(
        env_file=find_dotenv(), env_file_encoding="utf-8", extra="ignore"
    )
