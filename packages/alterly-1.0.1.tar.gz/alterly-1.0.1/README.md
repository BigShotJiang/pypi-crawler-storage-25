# alterly

Alterly CLI — wrapper for the [mempalace](https://github.com/mempalace/mempalace) AI memory system.

Provides the `alter` command with Polish-friendly aliases and automatic palace path resolution.

## Install

```bash
pip install alterly
```

## Usage

```bash
alter wake-up               # Alter Wake up — load memory
alter koduj .               # encode current directory into Rdzeń
alter przywoła "STIR"       # search Rdzeń
alter status                # health check
alter --version
```

## Palace path

By default uses `.alterly/` in current directory. Set `ALTERLY_PALACE` to use a fixed path:

```bash
# Mac / Linux (~/.zshrc or ~/.bashrc)
export ALTERLY_PALACE="/Volumes/GoogleDrive/Dyski współdzielone/SOCAP WSPOLNY/CLAUDE SOCAP AI/01_PRACOWNICY/Rafal_Przybylski/.alterly"

# Windows (PowerShell profile)
$env:ALTERLY_PALACE = "G:\Dyski współdzielone\SOCAP WSPOLNY\CLAUDE SOCAP AI\01_PRACOWNICY\Rafal_Przybylski\.alterly"
```
