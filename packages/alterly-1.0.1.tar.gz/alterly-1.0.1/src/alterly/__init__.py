"""Alterly — AI memory system for SoCap. Forked from mempalace 3.3.4 (MIT)."""

import logging

from .version import __version__  # noqa: E402

logging.getLogger("chromadb.telemetry.product.posthog").setLevel(logging.CRITICAL)

__all__ = ["__version__"]
