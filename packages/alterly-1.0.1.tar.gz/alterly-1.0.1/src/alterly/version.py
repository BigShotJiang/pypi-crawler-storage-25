"""Alterly version — forked from mempalace 3.3.4."""

__version__ = "1.0.1"
