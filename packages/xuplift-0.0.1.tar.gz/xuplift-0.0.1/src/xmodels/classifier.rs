use std::sync::Arc;

use faer::prelude::Solve;
use faer::{Col, Mat};
use rayon::prelude::*;

use crate::feature_map::KernelFeatureMap;

/// A Binary Classifier using Nystrom features and Iteratively Reweighted Least Squares (IRLS).
pub struct Classifier {
    /// The kernel_feature_map responsible for kernel-based feature mapping.
    pub kernel_feature_map: Arc<KernelFeatureMap>,
    /// The Ridge regularization penalty factor.
    pub penalty: f32,
    /// The maximum number of iterations for the IRLS algorithm.
    pub max_iter: usize,
    /// The global mean of the target variable, used as an implicit bias (intercept).
    pub base_value: f32,
    /// Learned weight coefficients for each feature block.
    pub coefficients: Vec<Col<f32>>,
}

impl Classifier {
    /// Creates a new Classifier instance with a fitted KernelFeatureMap.
    pub fn new(kernel_feature_map: Arc<KernelFeatureMap>, penalty: f32, max_iter: usize) -> Self {
        Self {
            kernel_feature_map,
            penalty,
            max_iter,
            base_value: 0.0,
            coefficients: Vec::new(),
        }
    }

    /// Sigmoid function: sigma(x) = 1 / (1 + exp(-x))
    fn sigmoid(x: f32) -> f32 {
        1.0 / (1.0 + (-x).exp())
    }

    /// Fits the binary classifier using the IRLS algorithm.
    ///
    /// This implementation uses target centering (y - mean) to align with the Regressor's logic.
    /// The `base_value` serves as the learned intercept, eliminating the need for an explicit bias column.
    pub fn fit(&mut self, y: &Col<f32>) {
        let num_rows = self.kernel_feature_map.num_rows;
        let num_features = self.kernel_feature_map.num_features;
        let num_bases = self.kernel_feature_map.num_bases;

        // Validate that the number of rows in the feature map matches the number of target values
        if num_rows != y.nrows() {
            panic!(
                "Mismatched dimensions: The number of rows in the feature map ({}) must match the number of target values ({}).",
                num_rows,
                y.nrows()
            );
        }
        // Calculate the mean of target 'y' and initialize base_value in logit space
        let mean_y = y.iter().sum::<f32>() / num_rows as f32;
        let eps = 1e-6;
        let p_clamped = mean_y.clamp(eps, 1.0 - eps);
        self.base_value = (p_clamped / (1.0 - p_clamped)).ln();

        // Initial probabilities based on the global intercept
        let initial_prob = p_clamped;
        let y_centered = y - Col::<f32>::full(num_rows, initial_prob);

        // De-stacking is no longer needed during fit since we use block-based accumulation
        let total_dim = num_features * num_bases;

        // Initialize weights
        let mut w = Col::<f32>::zeros(total_dim);

        // IRLS Iteration
        for _ in 0..self.max_iter {
            // Current linear prediction: a = Z * w
            // Compute this block by block: a = Sum(Z_i * w_i)
            let mut curr_raw_pred = Col::<f32>::zeros(num_rows);
            for i in 0..num_features {
                let z_i = &self.kernel_feature_map.z_matrices[i];
                let w_i = w.as_ref().subrows(i * num_bases, num_bases);
                curr_raw_pred += z_i * w_i;
            }

            // Transform predictions to probabilities: mu = sigmoid(a)
            let curr_prob = curr_raw_pred.map(|&v| Self::sigmoid(v));

            // Compute the diagonal weight matrix R: r_ii = mu * (1 - mu).
            let r_diag = curr_prob.map(|m| (m * (1.0 - m)).max(1e-5));

            // Calculate the error (gradient component).
            let error = &y_centered - &curr_prob;

            // Construct the Hessian (H = Z^T * R * Z + lambda * I) and RHS (Z^T * error)
            let mut hessian = Mat::<f32>::zeros(total_dim, total_dim);
            let mut rhs = Col::<f32>::zeros(total_dim);

            for i in 0..num_features {
                let z_i = &self.kernel_feature_map.z_matrices[i];
                let offset_i = i * num_bases;

                // RHS contribution: Z_i^T * error
                for r in 0..num_rows {
                    let err = error[r];
                    for k in 0..num_bases {
                        rhs[offset_i + k] += z_i[(r, k)] * err;
                    }
                }

                for j in 0..num_features {
                    let z_j = &self.kernel_feature_map.z_matrices[j];
                    let offset_j = j * num_bases;

                    // Hessian contribution: Z_i^T * R * Z_j
                    for r in 0..num_rows {
                        let r_val = r_diag[r];
                        for k in 0..num_bases {
                            let val_i = z_i[(r, k)] * r_val;
                            for l in 0..num_bases {
                                hessian[(offset_i + k, offset_j + l)] += val_i * z_j[(r, l)];
                            }
                        }
                    }
                }
            }

            // Add L2 regularization (Ridge)
            for i in 0..total_dim {
                hessian[(i, i)] += self.penalty;
            }

            // Solve the normal equations (H * delta_w = gradient) using LDLT decomposition.
            let delta_w = hessian.ldlt(faer::Side::Lower).unwrap().solve(&rhs);

            // Convergence check based on the update magnitude.
            if delta_w.iter().map(|x| x.abs()).sum::<f32>() <= 1e-6 {
                break;
            }
            w += delta_w;
        }

        // De-stack the weight vector into per-feature coefficients.
        self.coefficients = (0..num_features)
            .into_par_iter()
            .map(|f_idx| {
                let start = f_idx * num_bases;
                w.as_ref().subrows(start, num_bases).to_owned()
            })
            .collect();
    }

    /// Predicts class probabilities for the given input matrix X.
    ///
    /// Returns a vector of probabilities for the positive class (1).
    pub fn predict(&self, x: &Mat<f32>) -> Col<f32> {
        // Validate that the number of columns in the input matches the number of features in the feature map
        let num_features = self.kernel_feature_map.num_features;
        let num_rows = x.nrows();
        if num_features != x.ncols() {
            panic!(
                "Mismatched dimensions: The number of columns in the feature map ({}) must match the number of input columns ({}).",
                num_features,
                x.ncols()
            );
        }
        // Map raw input to the feature space
        let z_matrices = self.kernel_feature_map.transform(x);

        // Parallel computation of y_pred = Sum(Z_i * coeff_i)
        let linear_pred = (0..num_features)
            .into_par_iter()
            .map(|f_idx| &z_matrices[f_idx] * &self.coefficients[f_idx])
            .reduce(
                || Col::<f32>::zeros(num_rows),
                |mut acc, res| {
                    acc += res;
                    acc
                },
            );
        // Apply sigmoid activation, incorporating the base_value as the global intercept.
        linear_pred.map(|v| Self::sigmoid(v + self.base_value))
    }

    /// Explains the model's prediction by decomposing it into individual feature contributions.
    ///
    /// For each feature $i$, it calculates the contribution $C_i = Z_i \cdot \alpha_i$,
    /// resulting in a matrix where each column represents the contribution of a specific feature.
    pub fn explain(&self, x: &Mat<f32>) -> Mat<f32> {
        // Validate that the number of columns in the input matches the number of features in the feature map
        let num_features = self.kernel_feature_map.num_features;
        if num_features != x.ncols() {
            panic!(
                "Mismatched dimensions: The number of columns in the feature map ({}) must match the number of input columns ({}).",
                num_features,
                x.ncols()
            );
        }

        // Map raw input to the feature space
        let z_matrices = self.kernel_feature_map.transform(x);

        // Parallel computation of comtribution vec
        let contributions_vec: Vec<Col<f32>> = (0..x.ncols())
            .into_par_iter()
            .map(|f_idx| &z_matrices[f_idx] * &self.coefficients[f_idx])
            .collect();
        Mat::from_fn(x.nrows(), x.ncols(), |i, j| contributions_vec[j][i])
    }
}
