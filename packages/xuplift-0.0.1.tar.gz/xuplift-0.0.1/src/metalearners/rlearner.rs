use std::sync::Arc;

use faer::{Col, Mat};

use crate::feature_map::KernelFeatureMap;
use crate::xmodels::classifier::Classifier;
use crate::xmodels::regressor::Regressor;

/// R-Learner for Uplift Modeling.
///
/// Based on Robinson's transformation, this learner focuses on the residual-on-residual
/// regression to directly estimate the Heterogeneous Treatment Effect (HTE).
pub struct RLearner {
    /// Treatment effect model
    pub tau: Regressor,
}

impl RLearner {
    /// Initializes and fits the RLearner using the provided data.
    ///
    /// # Arguments
    /// * `x` - The original feature matrix (n_samples x n_features).
    /// * `t` - The treatment assignment vector (n_samples, 0 or 1).
    /// * `y` - The observed outcome vector.
    /// * `mu_penalty` - The regularization penalty for the regressor.
    /// * `p_penalty` - The regularization penalty for the propensity model.
    /// * `p_max_iter` - The maximum number of iterations for the propensity model.
    /// * `tau_penalty` - The regularization penalty for the treatment effect model.
    pub fn new(
        x: &Mat<f32>,
        t: &Col<f32>,
        y: &Col<f32>,
        mu_penalty: f32,
        p_penalty: f32,
        p_max_iter: usize,
        tau_penalty: f32,
    ) -> Self {
        let num_rows = x.nrows();

        // Train mu(x): Outcome model (E[Y|X])
        let mut mu_map = KernelFeatureMap::new();
        mu_map.fit(x);
        let mu_map_arc = Arc::new(mu_map);
        let mut mu = Regressor::new(Arc::clone(&mu_map_arc), mu_penalty);
        mu.fit(y);

        // Train p(x): Propensity model (E[T|X])
        let mut p_map = KernelFeatureMap::new();
        p_map.fit(x);
        let p_map_arc = Arc::new(p_map);
        let mut p = Classifier::new(p_map_arc, p_penalty, p_max_iter);
        p.fit(t);

        // Compute Residuals
        let mu_pred = mu.predict(x);
        let p_pred = p.predict(x);

        let mut r_target = Col::<f32>::zeros(num_rows);
        let mut r_weights = Col::<f32>::zeros(num_rows);

        for i in 0..num_rows {
            let y_tilde = y[i] - mu_pred[i];
            let t_tilde = t[i] - p_pred[i].clamp(0.01, 0.99);

            // Objective: Minimize (y_tilde - t_tilde * tau)^2
            // Equivalent to Weighted Least Squares: Minimize sum( w_i * (target_i - tau)^2 )
            // where target_i = y_tilde / t_tilde and w_i = t_tilde^2
            r_weights[i] = t_tilde * t_tilde;
            r_target[i] = if t_tilde.abs() > 1e-6 {
                y_tilde / t_tilde
            } else {
                0.0
            };
        }

        // Train the final tau model on the R-objective target with weights
        let mut tau_map = KernelFeatureMap::new();
        tau_map.fit(x);
        let mut tau = Regressor::new(Arc::new(tau_map), tau_penalty);
        tau.fit_weighted(&r_target, &r_weights);

        Self { tau }
    }

    /// Estimates the uplift score: $\hat{\tau}(x) = \arg\min_{\tau} \sum [ (Y - m(x)) - (T - e(x)) \cdot \tau(x) ]^2$
    pub fn predict_uplift(&self, x: &Mat<f32>) -> Col<f32> {
        self.tau.predict(x)
    }

    /// Explains the uplift by decomposing the feature contributions of the tau model.
    ///
    /// This explanation reveals how each feature contributes to the *change* in outcome
    /// caused by the treatment, rather than the outcome itself.
    ///
    /// Because R-Learner isolates the treatment signal by subtracting baseline expectations ($m(x)$ and $e(x)$),
    /// the feature contributions here are uniquely focused on "Causal Interaction" rather than simple correlation.
    ///
    /// # Returns
    /// A matrix (n_samples x n_features) showing the attribution of each feature
    /// to the final estimated Treatment Effect.
    pub fn explain_uplift(&self, x: &Mat<f32>) -> Mat<f32> {
        self.tau.explain(x)
    }
}
