import numpy as np
from numpy.typing import NDArray

class Classifier:
    def __init__(
        self,
        x: NDArray[np.float32],
        penalty: float,
        max_iter: int,
    ) -> None: ...
    def fit(self, y: NDArray[np.float32]) -> None: ...
    def predict(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...

class Regressor:
    def __init__(
        self,
        x: NDArray[np.float32],
        penalty: float,
    ) -> None: ...
    def fit(self, y: NDArray[np.float32]) -> None: ...
    def predict(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...

class RLearner:
    def __init__(
        self,
        x: NDArray[np.float32],
        t: NDArray[np.float32],
        y: NDArray[np.float32],
        mu_penalty: float,
        p_penalty: float,
        p_max_iter: int,
        tau_penalty: float,
    ) -> None: ...
    def predict_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...

class SLearner:
    def __init__(
        self,
        x: NDArray[np.float32],
        t: NDArray[np.float32],
        y: NDArray[np.float32],
        mu_penalty: float,
    ) -> None: ...
    def predict_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...

class TLearner:
    def __init__(
        self,
        x: NDArray[np.float32],
        t: NDArray[np.float32],
        y: NDArray[np.float32],
        mu_penalty: float,
    ) -> None: ...
    def predict_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...

class XLearner:
    def __init__(
        self,
        x: NDArray[np.float32],
        t: NDArray[np.float32],
        y: NDArray[np.float32],
        mu_penalty: float,
        p_penalty: float,
        p_max_iter: int,
        tau_penalty: float,
    ) -> None: ...
    def predict_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
    def explain_uplift(self, x: NDArray[np.float32]) -> NDArray[np.float32]: ...
