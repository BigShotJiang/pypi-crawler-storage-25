"""CLI package for MCPGen."""

