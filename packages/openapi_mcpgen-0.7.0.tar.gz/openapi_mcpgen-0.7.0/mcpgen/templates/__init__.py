"""Generated server templates."""

