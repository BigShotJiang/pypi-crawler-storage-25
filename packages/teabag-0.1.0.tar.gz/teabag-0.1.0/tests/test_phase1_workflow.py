from __future__ import annotations

import json
from pathlib import Path

from teabag import cli
from teabag import config as config_mod


def run_cli(tmp_repo: Path, *args: str) -> int:
    return cli.main(["--repo-root", str(tmp_repo), *args])


def test_phase1_basic_workflow(tmp_path: Path, monkeypatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "requirements.txt").write_text("pytest\n", encoding="utf-8")

    # Simulate a git repo so diff computation path is exercised.
    (repo / ".git").mkdir()

    # Initialize teabag.
    assert run_cli(repo, "init") == 0

    cfg = config_mod.load_or_init(repo)
    assert cfg.workspaces_dir.exists()
    assert cfg.ai_history_dir.exists()
    assert cfg.env_store_dir.exists()

    # Spawn a workspace.
    assert run_cli(repo, "spawn", "agent_1") == 0
    ws = cfg.workspaces_dir / "agent_1"
    assert ws.exists()

    # Provide minimal intent and prompt in the workspace.
    intent = {
        "parent_experiment": "exp_001",
        "prompt": "dummy prompt",
        "intent": {
            "files_to_modify": ["example.py"],
            "goal": "test run logging",
        },
    }
    (ws / "intent.json").write_text(json.dumps(intent), encoding="utf-8")
    (ws / "prompt.md").write_text("# prompt", encoding="utf-8")

    # Create a dummy file to ensure diff path runs without error.
    (repo / "example.py").write_text("print('hello')\n", encoding="utf-8")

    # Record a run.
    assert run_cli(repo, "run", "agent_1") == 0

    # At least one run directory should exist with the expected files.
    runs = [p for p in cfg.ai_history_dir.iterdir() if p.is_dir() and p.name.startswith("run_")]
    assert runs, "Expected at least one run directory"
    run_dir = runs[0]
    assert (run_dir / "prompt.md").exists()
    assert (run_dir / "intent.json").exists()
    assert (run_dir / "diff.patch").exists()
    assert (run_dir / "metadata.json").exists()

