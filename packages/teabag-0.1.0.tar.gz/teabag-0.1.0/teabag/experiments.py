from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .config import RepoConfig


EXPERIMENTS_FILE_NAME = "experiments.json"

ExperimentStatus = Literal["pending", "accepted", "rejected"]


@dataclass
class Experiment:
    exp_id: str
    parent_exp_id: str | None
    run_ids: list[str]
    status: ExperimentStatus


def _experiments_file(cfg: RepoConfig) -> Path:
    return cfg.teabag_dir / EXPERIMENTS_FILE_NAME


def _load_raw(cfg: RepoConfig) -> dict:
    path = _experiments_file(cfg)
    if not path.exists():
        return {"experiments": [], "next_id": 1}
    return json.loads(path.read_text(encoding="utf-8"))


def _save_raw(cfg: RepoConfig, data: dict) -> None:
    path = _experiments_file(cfg)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def create_experiment_for_run(cfg: RepoConfig, run_id: str, parent_exp_id: str | None = None) -> Experiment:
    data = _load_raw(cfg)
    next_id = int(data.get("next_id", 1))
    exp_id = f"exp_{next_id:03d}"
    exp = {
        "exp_id": exp_id,
        "parent_exp_id": parent_exp_id,
        "run_ids": [run_id],
        "status": "pending",
    }
    data.setdefault("experiments", []).append(exp)
    data["next_id"] = next_id + 1
    _save_raw(cfg, data)
    return Experiment(exp_id=exp_id, parent_exp_id=parent_exp_id, run_ids=[run_id], status="pending")


def list_experiments(cfg: RepoConfig) -> list[Experiment]:
    data = _load_raw(cfg)
    exps: list[Experiment] = []
    for raw in data.get("experiments", []):
        exps.append(
            Experiment(
                exp_id=raw["exp_id"],
                parent_exp_id=raw.get("parent_exp_id"),
                run_ids=list(raw.get("run_ids", [])),
                status=raw.get("status", "pending"),  # type: ignore[arg-type]
            )
        )
    return exps


def update_experiment_status(cfg: RepoConfig, exp_id: str, status: ExperimentStatus) -> None:
    data = _load_raw(cfg)
    changed = False
    for raw in data.get("experiments", []):
        if raw.get("exp_id") == exp_id:
            raw["status"] = status
            changed = True
            break
    if changed:
        _save_raw(cfg, data)


def get_accepted_run_ids(cfg: RepoConfig) -> list[str]:
    """Return run_ids of all experiments with status 'accepted'."""
    run_ids: list[str] = []
    for exp in list_experiments(cfg):
        if exp.status == "accepted":
            run_ids.extend(exp.run_ids)
    return run_ids

