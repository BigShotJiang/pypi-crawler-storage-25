from __future__ import annotations

import json
import shutil
from pathlib import Path
from datetime import datetime, timezone

from .config import RepoConfig
from . import env as env_mod

PROMPT_JSON_NAME = "prompt.json"


def _default_prompt_json_path() -> Path:
    return Path(__file__).parent / "prompt_template.json"


def write_default_prompt_json(ws_path: Path) -> None:
    """Write default prompt.json (with _teabag section) into workspace if not present."""
    dest = ws_path / PROMPT_JSON_NAME
    if dest.exists():
        return
    template_path = _default_prompt_json_path()
    if template_path.exists():
        dest.write_text(template_path.read_text(encoding="utf-8"), encoding="utf-8")


def _workspace_path(cfg: RepoConfig, agent_name: str) -> Path:
    return cfg.workspaces_dir / agent_name


def spawn_workspace(cfg: RepoConfig, agent_name: str) -> Path:
    ws_path = _workspace_path(cfg, agent_name)
    ws_path.mkdir(parents=True, exist_ok=True)

    # Link or create shared environment.
    env_path = env_mod.ensure_env(cfg)
    venv_link = ws_path / "venv"
    if venv_link.exists() or venv_link.is_symlink():
        # Best-effort cleanup before recreating link/dir.
        if venv_link.is_symlink() or venv_link.is_file():
            venv_link.unlink()
        else:
            shutil.rmtree(venv_link)

    try:
        venv_link.symlink_to(env_path)
    except (OSError, NotImplementedError):
        # Fallback: document the env path in a text file if symlinks are not available.
        (ws_path / "ENV_PATH").write_text(str(env_path), encoding="utf-8")

    write_default_prompt_json(ws_path)
    return ws_path


def delete_workspace(cfg: RepoConfig, agent_name: str) -> None:
    ws_path = _workspace_path(cfg, agent_name)
    if ws_path.exists():
        shutil.rmtree(ws_path)


def snapshot_workspace(cfg: RepoConfig, agent_name: str) -> Path:
    """Copy workspace to .teabag/snapshots/<agent_name>_<iso_timestamp>. Excludes venv."""
    ws_path = _workspace_path(cfg, agent_name)
    if not ws_path.exists():
        raise SystemExit(f"Workspace for agent {agent_name!r} does not exist.")
    cfg.snapshots_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest = cfg.snapshots_dir / f"{agent_name}_{ts}"
    shutil.copytree(
        ws_path,
        dest,
        ignore=shutil.ignore_patterns("venv", "ENV_PATH", "__pycache__", "*.pyc", ".git"),
        dirs_exist_ok=False,
    )
    return dest


def spawn_workspace_from_template(cfg: RepoConfig, agent_name: str, template_dir: Path) -> Path:
    """Create a workspace by copying a snapshot/template directory, then link shared venv."""
    ws_path = _workspace_path(cfg, agent_name)
    if ws_path.exists():
        shutil.rmtree(ws_path)
    shutil.copytree(
        template_dir,
        ws_path,
        ignore=shutil.ignore_patterns("venv", "ENV_PATH", "__pycache__", "*.pyc", ".git"),
        dirs_exist_ok=False,
    )
    env_path = env_mod.ensure_env(cfg)
    venv_link = ws_path / "venv"
    try:
        venv_link.symlink_to(env_path)
    except (OSError, NotImplementedError):
        (ws_path / "ENV_PATH").write_text(str(env_path), encoding="utf-8")
    return ws_path


def agents_spawn(cfg: RepoConfig, n: int, template: str | None = None) -> list[str]:
    """Spawn n workspaces named agent_1 .. agent_n. If template is set, copy from that snapshot."""
    names = [f"agent_{i}" for i in range(1, n + 1)]
    template_path = None
    if template:
        template_path = cfg.snapshots_dir / template
        if not template_path.exists():
            raise SystemExit(f"Template snapshot {template!r} not found in {cfg.snapshots_dir}.")
    for name in names:
        if template_path is not None:
            spawn_workspace_from_template(cfg, name, template_path)
        else:
            spawn_workspace(cfg, name)
    return names

