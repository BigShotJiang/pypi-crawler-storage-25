from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from . import config as config_mod
from . import workspace as workspace_mod
from . import history as history_mod
from . import experiments as experiments_mod
from . import env as env_mod
from . import orchestrator as orchestrator_mod


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path.cwd(),
        help="Path to the repository root (defaults to current working directory).",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tb",
        description="AI-native version control CLI for safe AI-assisted development.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # teabag init
    init_p = subparsers.add_parser(
        "init",
        help="Initialize .teabag/ metadata for the current repository.",
    )
    _add_common_args(init_p)

    # teabag spawn <agent_name>
    spawn_p = subparsers.add_parser(
        "spawn",
        help="Create an isolated workspace for an agent.",
    )
    _add_common_args(spawn_p)
    spawn_p.add_argument("agent_name", help="Name of the agent/workspace.")

    # teabag agents spawn <n> [--template <name>]
    agents_p = subparsers.add_parser(
        "agents",
        help="Multi-agent workspace operations (Phase 3).",
    )
    _add_common_args(agents_p)
    agents_sub = agents_p.add_subparsers(dest="agents_command", required=True)
    agents_spawn = agents_sub.add_parser("spawn", help="Spawn N workspaces (agent_1 .. agent_N).")
    agents_spawn.add_argument("n", type=int, help="Number of workspaces to spawn.")
    agents_spawn.add_argument("--template", default=None, help="Snapshot name under .teabag/snapshots/ to copy from.")

    # teabag run <agent_name>
    run_p = subparsers.add_parser(
        "run",
        help="Record an AI run for a workspace (requires intent and prompt).",
    )
    _add_common_args(run_p)
    run_p.add_argument("agent_name", help="Name of the agent/workspace.")

    # teabag list-runs
    list_runs_p = subparsers.add_parser(
        "list-runs",
        help="List recorded AI runs.",
    )
    _add_common_args(list_runs_p)

    # teabag runs show/compare/accept
    runs_p = subparsers.add_parser(
        "runs",
        help="Inspect and compare AI runs and experiments.",
    )
    _add_common_args(runs_p)
    runs_sub = runs_p.add_subparsers(dest="runs_command", required=True)

    runs_show = runs_sub.add_parser("show", help="Show details for a run.")
    runs_show.add_argument("run_id")

    runs_compare = runs_sub.add_parser(
        "compare",
        help="Compare two runs at a high level.",
    )
    runs_compare.add_argument("run_a")
    runs_compare.add_argument("run_b")

    runs_accept = runs_sub.add_parser(
        "accept",
        help="Apply a run's diff.patch to the main repo and mark experiment accepted.",
    )
    runs_accept.add_argument("run_id", help="Run to apply (e.g. run_001).")
    runs_accept.add_argument(
        "--dry-run",
        action="store_true",
        help="Only check if the patch would apply; do not modify files.",
    )
    runs_rank = runs_sub.add_parser("rank", help="Rank runs by tests, time, or diff size.")
    runs_rank.add_argument("--by", default="tests", choices=["tests", "time", "diff"], help="Ranking criterion.")

    # teabag workspace snapshot <agent_name>
    ws_p = subparsers.add_parser(
        "workspace",
        help="Workspace operations (snapshot).",
    )
    _add_common_args(ws_p)
    ws_sub = ws_p.add_subparsers(dest="workspace_command", required=True)
    ws_snapshot = ws_sub.add_parser("snapshot", help="Create a named snapshot of a workspace.")
    ws_snapshot.add_argument("agent_name", help="Name of the agent/workspace.")

    # teabag delete-workspace <agent_name>
    delete_ws_p = subparsers.add_parser(
        "delete-workspace",
        help="Delete an isolated workspace directory.",
    )
    _add_common_args(delete_ws_p)
    delete_ws_p.add_argument("agent_name", help="Name of the agent/workspace to delete.")

    # teabag env list/prune
    env_p = subparsers.add_parser(
        "env",
        help="Inspect and maintain shared environments.",
    )
    _add_common_args(env_p)
    env_sub = env_p.add_subparsers(dest="env_command", required=True)
    env_list = env_sub.add_parser("list", help="List known environments.")
    env_prune = env_sub.add_parser("prune", help="Remove stale environments from registry.")

    # teabag task list / run
    task_p = subparsers.add_parser(
        "task",
        help="High-level AI tasks (Phase 3).",
    )
    _add_common_args(task_p)
    task_sub = task_p.add_subparsers(dest="task_command", required=True)
    task_sub.add_parser("list", help="List tasks recorded in the orchestrator.")
    task_run = task_sub.add_parser("run", help="Create a task and spawn N agent workspaces.")
    task_run.add_argument("description", help="Task description.")
    task_run.add_argument("--agents", type=int, default=1, metavar="N", help="Number of agent workspaces to spawn.")
    task_run.add_argument("--template", default=None, help="Snapshot name to use as template for each workspace.")

    # teabag merge best / plan
    merge_p = subparsers.add_parser(
        "merge",
        help="Merge best runs or show merge plan (Phase 3).",
    )
    _add_common_args(merge_p)
    merge_sub = merge_p.add_subparsers(dest="merge_command", required=True)
    merge_best_p = merge_sub.add_parser("best", help="Apply the best K non-conflicting runs (by test rank).")
    merge_best_p.add_argument("--limit", type=int, default=1, help="Max number of runs to apply.")
    merge_best_p.add_argument("--dry-run", action="store_true", help="Only print what would be applied.")
    merge_plan_p = merge_sub.add_parser("plan", help="Show a human-readable merge plan for a run.")
    merge_plan_p.add_argument("run_id", help="Run to plan (e.g. run_001).")

    return parser


def main(argv: list[str] | None = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = build_parser()
    args = parser.parse_args(argv)

    repo_root: Path = args.repo_root.resolve()

    if args.command == "init":
        config_mod.init_repo(repo_root)
        return 0

    # All other commands require initialized repo.
    cfg = config_mod.load_or_init(repo_root)

    if args.command == "spawn":
        workspace_mod.spawn_workspace(cfg, args.agent_name)
        return 0

    if args.command == "agents":
        if args.agents_command == "spawn":
            names = workspace_mod.agents_spawn(cfg, args.n, template=args.template)
            for name in names:
                print(name)
            return 0

    if args.command == "run":
        history_mod.record_run(cfg, args.agent_name)
        return 0

    if args.command == "list-runs":
        history_mod.list_runs(cfg)
        return 0

    if args.command == "runs":
        if args.runs_command == "show":
            history_mod.show_run(cfg, args.run_id)
            return 0
        if args.runs_command == "compare":
            history_mod.compare_runs(cfg, args.run_a, args.run_b)
            return 0
        if args.runs_command == "accept":
            history_mod.accept_run(cfg, args.run_id, dry_run=args.dry_run)
            return 0
        if args.runs_command == "rank":
            history_mod.rank_runs(cfg, by=args.by)
            return 0

    if args.command == "workspace":
        if args.workspace_command == "snapshot":
            path = workspace_mod.snapshot_workspace(cfg, args.agent_name)
            print(f"Snapshot: {path}")
            return 0

    if args.command == "delete-workspace":
        workspace_mod.delete_workspace(cfg, args.agent_name)
        return 0

    if args.command == "env":
        if args.env_command == "list":
            env_mod.list_envs(cfg)
            return 0
        if args.env_command == "prune":
            env_mod.prune_envs(cfg)
            return 0

    if args.command == "task":
        if args.task_command == "list":
            orchestrator_mod.list_tasks(cfg)
            return 0
        if args.task_command == "run":
            task = orchestrator_mod.task_run(
                cfg, args.description, args.agents, template=args.template
            )
            print(f"Created {task.task_id}: {task.description}")
            for name in task.agent_names:
                print(f"  {name}")
            return 0

    if args.command == "merge":
        if args.merge_command == "best":
            history_mod.merge_best(cfg, limit=args.limit, dry_run=args.dry_run)
            return 0
        if args.merge_command == "plan":
            history_mod.merge_plan(cfg, args.run_id)
            return 0

    parser.error(f"Unknown command {args.command!r}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

