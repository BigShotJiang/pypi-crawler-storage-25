from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

from .config import RepoConfig

ENV_REGISTRY_FILE_NAME = "environments.json"


def _python_version_fingerprint() -> str:
    return sys.version.split()[0]


def _requirements_fingerprint(repo_root: Path) -> str | None:
    req = repo_root / "requirements.txt"
    if not req.exists():
        return None
    content = req.read_text(encoding="utf-8")
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]


def compute_env_hash(cfg: RepoConfig) -> str:
    parts: dict[str, str | None] = {
        "python": _python_version_fingerprint(),
        "requirements": _requirements_fingerprint(cfg.repo_root),
    }
    raw = json.dumps(parts, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def ensure_env(cfg: RepoConfig) -> Path:
    """Ensure a shared virtualenv exists for this repo+requirements."""
    env_hash = compute_env_hash(cfg)
    target = cfg.env_store_dir / env_hash
    if (target / "bin" / "python").exists() or (target / "Scripts" / "python.exe").exists():
        return target

    target.mkdir(parents=True, exist_ok=True)
    # Create venv inside target directory.
    subprocess.check_call([sys.executable, "-m", "venv", str(target)])
    _register_env(cfg, target)
    return target


def _registry_path(cfg: RepoConfig) -> Path:
    return cfg.teabag_dir / ENV_REGISTRY_FILE_NAME


def _load_registry(cfg: RepoConfig) -> dict:
    path = _registry_path(cfg)
    if not path.exists():
        return {"environments": []}
    return json.loads(path.read_text(encoding="utf-8"))


def _save_registry(cfg: RepoConfig, data: dict) -> None:
    path = _registry_path(cfg)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def _register_env(cfg: RepoConfig, env_path: Path) -> None:
    env_hash = env_path.name
    data = _load_registry(cfg)
    envs = data.setdefault("environments", [])
    if not any(e.get("hash") == env_hash for e in envs):
        envs.append(
            {
                "hash": env_hash,
                "path": str(env_path),
            }
        )
        _save_registry(cfg, data)


def list_envs(cfg: RepoConfig) -> None:
    data = _load_registry(cfg)
    for env in data.get("environments", []):
        print(f"{env.get('hash')}\t{env.get('path')}")


def prune_envs(cfg: RepoConfig) -> None:
    data = _load_registry(cfg)
    envs = data.get("environments", [])
    kept = []
    for env in envs:
        path = Path(env.get("path", ""))
        if path.exists():
            kept.append(env)
        else:
            # silently drop missing env
            continue
    if len(kept) != len(envs):
        data["environments"] = kept
        _save_registry(cfg, data)


