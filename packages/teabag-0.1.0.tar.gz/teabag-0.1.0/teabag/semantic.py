from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable, Set


def parse_diff_touched_files(patch_text: str) -> Set[str]:
    """Extract set of file paths from a unified diff (--- a/path or +++ b/path)."""
    paths: Set[str] = set()
    for line in patch_text.splitlines():
        if line.startswith("--- ") or line.startswith("+++ "):
            # --- a/src/foo.py or +++ b/src/foo.py or --- /dev/null
            part = line[4:].strip()
            if part and part != "/dev/null":
                # Strip a/ or b/ prefix if present
                if re.match(r"^[ab]/", part):
                    part = part[2:]
                paths.add(part)
    return paths


def _python_imports(path: Path) -> Set[str]:
    """Very lightweight import scanner to approximate dependency surface."""
    imports: Set[str] = set()
    if not path.exists() or path.suffix != ".py":
        return imports
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("import "):
            parts = line.split()
            if len(parts) >= 2:
                imports.add(parts[1].split(".")[0])
        elif line.startswith("from "):
            parts = line.split()
            if len(parts) >= 2:
                imports.add(parts[1].split(".")[0])
    return imports


def summarize_dependency_scope(files: Iterable[Path]) -> Set[str]:
    scope: Set[str] = set()
    for f in files:
        scope.update(_python_imports(f))
    return scope

