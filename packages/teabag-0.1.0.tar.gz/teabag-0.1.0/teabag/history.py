from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path

from .config import RepoConfig, load_hooks_config
from . import env as env_mod
from . import experiments as experiments_mod
from . import semantic as semantic_mod
from .workspace import _workspace_path


# Flow: human writes prompt.json (with _teabag section) -> AI writes intent.json -> record_run copies both.
# intent.json is immutable after creation & filled by AI: run artifacts are made read-only.
INTENT_FILE_NAME = "intent.json"
PROMPT_JSON_NAME = "prompt.json"
PROMPT_FILE_NAME = "prompt.md"


def _make_immutable(path: Path) -> None:
    """Set file to read-only so the run record cannot be tampered with."""
    try:
        os.chmod(path, 0o444)
    except OSError:
        pass


@dataclass
class RunRecord:
    run_id: str
    path: Path
    workspace: str
    created_at: float


def _next_run_id(cfg: RepoConfig) -> str:
    existing = [p for p in cfg.ai_history_dir.iterdir() if p.is_dir() and p.name.startswith("run_")]
    max_num = 0
    for p in existing:
        try:
            num = int(p.name.split("_", 1)[1])
        except (IndexError, ValueError):
            continue
        if num > max_num:
            max_num = num
    return f"run_{max_num + 1:03d}"


def _validate_intent(intent_path: Path) -> dict:
    data = json.loads(intent_path.read_text(encoding="utf-8"))
    intent = data.get("intent", {})
    if "goal" not in intent or not isinstance(intent["goal"], str):
        raise ValueError("intent.json must contain intent.goal as a string")
    return data


def _compute_diff(repo_root: Path, workspace_path: Path) -> str:
    # Use git diff if repo is under git, otherwise a placeholder.
    git_dir = repo_root / ".git"
    if git_dir.exists():
        try:
            result = subprocess.run(
                ["git", "diff", "--no-color", "--", str(repo_root), str(workspace_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=False,
                cwd=repo_root,
            )
            return result.stdout
        except OSError:
            pass
    return "# Diff computation not implemented for non-git projects.\n"


def _touched_python_files(repo_root: Path, workspace_path: Path) -> list[Path]:
    # For now, just walk the workspace and return .py files.
    files: list[Path] = []
    for path in workspace_path.rglob("*.py"):
        files.append(path)
    return files


def _get_workspace_venv_path(ws_path: Path) -> Path | None:
    """Resolve the shared venv path for a workspace (symlink or ENV_PATH file)."""
    venv_link = ws_path / "venv"
    if venv_link.is_symlink():
        return venv_link.resolve()
    if venv_link.is_dir() and (venv_link / "bin" / "python").exists():
        return venv_link
    if venv_link.is_dir() and (venv_link / "Scripts" / "python.exe").exists():
        return venv_link
    env_path_file = ws_path / "ENV_PATH"
    if env_path_file.exists():
        return Path(env_path_file.read_text(encoding="utf-8").strip())
    return None


def _capture_environment_fingerprint(cfg: RepoConfig, env_path: Path | None) -> dict:
    """Build environment.json content: Python version, packages, env hash, OS."""
    fingerprint: dict = {
        "python_version": sys.version.split()[0],
        "platform": platform.system(),
        "env_hash": env_mod.compute_env_hash(cfg),
    }
    if env_path is not None:
        pip_exe = env_path / "bin" / "pip"
        if not pip_exe.exists():
            pip_exe = env_path / "Scripts" / "pip.exe"
        if pip_exe.exists():
            try:
                r = subprocess.run(
                    [str(pip_exe), "list", "--format=json"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    cwd=cfg.repo_root,
                )
                if r.returncode == 0 and r.stdout.strip():
                    fingerprint["installed_packages"] = json.loads(r.stdout)
                else:
                    fingerprint["installed_packages"] = "pip list failed or empty"
            except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError):
                fingerprint["installed_packages"] = "capture failed"
    return fingerprint


def _run_test_hook(cfg: RepoConfig, ws_path: Path, timeout_seconds: int) -> dict:
    """Run test_command from teabag.json in workspace; return tests.json payload."""
    hooks = load_hooks_config(cfg.repo_root)
    if not hooks or not hooks.test_command:
        return {}
    try:
        r = subprocess.run(
            hooks.test_command,
            shell=True,
            cwd=ws_path,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
        return {
            "exit_code": r.returncode,
            "stdout": r.stdout[:4096] if r.stdout else "",
            "stderr": r.stderr[:4096] if r.stderr else "",
            "timeout_seconds": timeout_seconds,
        }
    except subprocess.TimeoutExpired:
        return {"exit_code": -1, "error": "timeout", "timeout_seconds": timeout_seconds}
    except OSError as e:
        return {"exit_code": -1, "error": str(e)}


def _run_metrics_hook(cfg: RepoConfig, ws_path: Path) -> dict:
    """Run metrics_script from teabag.json; return metrics.json payload."""
    hooks = load_hooks_config(cfg.repo_root)
    if not hooks or not hooks.metrics_script:
        return {}
    script_path = cfg.repo_root / hooks.metrics_script
    if not script_path.exists():
        return {"error": f"script not found: {hooks.metrics_script}"}
    try:
        r = subprocess.run(
            [str(script_path)],
            cwd=ws_path,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return {
            "exit_code": r.returncode,
            "stdout": r.stdout[:8192] if r.stdout else "",
            "stderr": r.stderr[:1024] if r.stderr else "",
        }
    except subprocess.TimeoutExpired:
        return {"error": "timeout"}
    except OSError as e:
        return {"error": str(e)}


def _resolve_prompt_file(ws: Path) -> tuple[Path, str]:
    """Return (path to prompt file, filename to use in run dir). Prefer prompt.json over prompt.md."""
    json_path = ws / PROMPT_JSON_NAME
    md_path = ws / PROMPT_FILE_NAME
    if json_path.exists():
        return (json_path, PROMPT_JSON_NAME)
    if md_path.exists():
        return (md_path, PROMPT_FILE_NAME)
    raise SystemExit(
        f"Neither {PROMPT_JSON_NAME} nor {PROMPT_FILE_NAME} found in workspace {ws}. "
        f"Add prompt.json (with _teabag section) or prompt.md; then AI writes {INTENT_FILE_NAME}."
    )


def record_run(cfg: RepoConfig, agent_name: str) -> RunRecord:
    ws = _workspace_path(cfg, agent_name)
    if not ws.exists():
        raise SystemExit(f"Workspace for agent {agent_name!r} does not exist. Run 'tb spawn {agent_name}' first.")

    intent_path = ws / INTENT_FILE_NAME
    if not intent_path.exists():
        raise SystemExit(
            f"{INTENT_FILE_NAME} not found in workspace {ws}. "
            "AI should read prompt.json and write intent.json (with intent.goal) before running tb run."
        )

    prompt_path, prompt_filename = _resolve_prompt_file(ws)
    intent_data = _validate_intent(intent_path)

    run_id = _next_run_id(cfg)
    run_dir = cfg.ai_history_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    # Copy prompt and intent into history.
    (run_dir / prompt_filename).write_text(prompt_path.read_text(encoding="utf-8"), encoding="utf-8")
    (run_dir / INTENT_FILE_NAME).write_text(json.dumps(intent_data, indent=2), encoding="utf-8")

    diff_text = _compute_diff(cfg.repo_root, ws)
    (run_dir / "diff.patch").write_text(diff_text, encoding="utf-8")

    # Very lightweight semantic scope summary for Python files.
    py_files = _touched_python_files(cfg.repo_root, ws)
    scope = list(sorted(semantic_mod.summarize_dependency_scope(py_files)))

    metadata = {
        "workspace": agent_name,
        "workspace_path": str(ws),
        "repo_root": str(cfg.repo_root),
        "created_at": time.time(),
        "python_dependency_scope": scope,
    }
    # Create a simple experiment node for this run.
    exp = experiments_mod.create_experiment_for_run(cfg, run_id, intent_data.get("parent_experiment"))
    metadata["experiment_id"] = exp.exp_id
    (run_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    # Phase 2: environment fingerprint and optional test/metrics hooks.
    venv_path = _get_workspace_venv_path(ws)
    env_fingerprint = _capture_environment_fingerprint(cfg, venv_path)
    (run_dir / "environment.json").write_text(
        json.dumps(env_fingerprint, indent=2), encoding="utf-8"
    )

    hooks = load_hooks_config(cfg.repo_root)
    if hooks and hooks.test_command:
        tests_result = _run_test_hook(cfg, ws, hooks.test_timeout_seconds)
        if tests_result:
            (run_dir / "tests.json").write_text(
                json.dumps(tests_result, indent=2), encoding="utf-8"
            )
    if hooks and hooks.metrics_script:
        metrics_result = _run_metrics_hook(cfg, ws)
        if metrics_result:
            (run_dir / "metrics.json").write_text(
                json.dumps(metrics_result, indent=2), encoding="utf-8"
            )

    # Make run record immutable: intent.json and all artifacts are read-only after creation.
    for name in [prompt_filename, INTENT_FILE_NAME, "diff.patch", "metadata.json", "environment.json", "tests.json", "metrics.json"]:
        p = run_dir / name
        if p.exists():
            _make_immutable(p)

    return RunRecord(
        run_id=run_id,
        path=run_dir,
        workspace=agent_name,
        created_at=metadata["created_at"],
    )


def list_runs(cfg: RepoConfig) -> None:
    runs: list[RunRecord] = []
    for p in sorted(cfg.ai_history_dir.iterdir()):
        if not p.is_dir() or not p.name.startswith("run_"):
            continue
        meta_path = p / "metadata.json"
        workspace = "unknown"
        created_at = 0.0
        if meta_path.exists():
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
                workspace = data.get("workspace", workspace)
                created_at = float(data.get("created_at", 0.0))
            except Exception:
                pass
        runs.append(RunRecord(run_id=p.name, path=p, workspace=workspace, created_at=created_at))

    for r in sorted(runs, key=lambda r: r.created_at):
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(r.created_at)) if r.created_at else "unknown"
        print(f"{r.run_id}\t{ts}\tworkspace={r.workspace}")


def _run_dir(cfg: RepoConfig, run_id: str) -> Path:
    path = cfg.ai_history_dir / run_id
    if not path.exists():
        raise SystemExit(f"Unknown run_id {run_id!r}")
    return path


def show_run(cfg: RepoConfig, run_id: str) -> None:
    run_dir = _run_dir(cfg, run_id)
    meta_path = run_dir / "metadata.json"
    intent_path = run_dir / "intent.json"
    env_path = run_dir / "environment.json"
    tests_path = run_dir / "tests.json"
    metrics_path = run_dir / "metrics.json"

    print(f"Run: {run_id}")
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        print("Metadata:")
        print(json.dumps(meta, indent=2))
    if intent_path.exists():
        print("\nIntent:")
        print(intent_path.read_text(encoding="utf-8"))
    if env_path.exists():
        print("\nEnvironment fingerprint:")
        print(env_path.read_text(encoding="utf-8"))
    if tests_path.exists():
        tests = json.loads(tests_path.read_text(encoding="utf-8"))
        ec = tests.get("exit_code", "?")
        print(f"\nTests: exit_code={ec}")
        if tests.get("stdout"):
            print("  stdout (truncated):", tests["stdout"][:500])
    if metrics_path.exists():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        print("\nMetrics:", json.dumps(metrics, indent=2)[:500])


def compare_runs(cfg: RepoConfig, run_a: str, run_b: str) -> None:
    dir_a = _run_dir(cfg, run_a)
    dir_b = _run_dir(cfg, run_b)

    def _summary(run_dir: Path) -> dict:
        diff_path = run_dir / "diff.patch"
        meta_path = run_dir / "metadata.json"
        tests_path = run_dir / "tests.json"
        metrics_path = run_dir / "metrics.json"
        meta = {}
        if meta_path.exists():
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        diff_lines = 0
        if diff_path.exists():
            diff_lines = sum(1 for _ in diff_path.read_text(encoding="utf-8").splitlines())
        out = {
            "run_dir": str(run_dir),
            "workspace": meta.get("workspace", "unknown"),
            "created_at": meta.get("created_at"),
            "diff_lines": diff_lines,
            "experiment_id": meta.get("experiment_id"),
        }
        if tests_path.exists():
            try:
                t = json.loads(tests_path.read_text(encoding="utf-8"))
                out["tests_exit_code"] = t.get("exit_code")
            except Exception:
                pass
        if metrics_path.exists():
            try:
                m = json.loads(metrics_path.read_text(encoding="utf-8"))
                out["metrics"] = {k: v for k, v in m.items() if k not in ("stdout", "stderr")}
            except Exception:
                pass
        return out

    summary_a = _summary(dir_a)
    summary_b = _summary(dir_b)
    print("Run A:")
    print(json.dumps(summary_a, indent=2))
    print("\nRun B:")
    print(json.dumps(summary_b, indent=2))


def accept_run(cfg: RepoConfig, run_id: str, dry_run: bool = False) -> None:
    """Apply diff.patch from a run to the main repo. Optionally update experiment status."""
    run_dir = _run_dir(cfg, run_id)
    patch_path = run_dir / "diff.patch"
    if not patch_path.exists():
        raise SystemExit(f"No diff.patch in run {run_id}.")
    patch_content = patch_path.read_text(encoding="utf-8")
    if not patch_content.strip() or patch_content.strip().startswith("#"):
        raise SystemExit(f"Run {run_id} has no meaningful diff to apply.")

    if dry_run:
        # Run patch --dry-run to see if it would apply cleanly.
        try:
            r = subprocess.run(
                ["patch", "-p1", "--dry-run", "-d", str(cfg.repo_root)],
                input=patch_content,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if r.returncode != 0:
                print("Dry run failed. patch stderr:", r.stderr or r.stdout)
                raise SystemExit(1)
            print("Dry run succeeded. Patch would apply cleanly.")
        except FileNotFoundError:
            print("'patch' command not found. Install patch (e.g. brew install patch).")
            raise SystemExit(1)
        except subprocess.TimeoutExpired:
            raise SystemExit(1)
        return

    try:
        r = subprocess.run(
            ["patch", "-p1", "-d", str(cfg.repo_root)],
            input=patch_content,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if r.returncode != 0:
            print("patch failed:", r.stderr or r.stdout)
            raise SystemExit(1)
    except FileNotFoundError:
        print("'patch' command not found. Install patch (e.g. brew install patch).")
        raise SystemExit(1)
    except subprocess.TimeoutExpired:
        raise SystemExit(1)

    # Mark the run's experiment as accepted.
    meta_path = run_dir / "metadata.json"
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            exp_id = meta.get("experiment_id")
            if exp_id:
                experiments_mod.update_experiment_status(cfg, exp_id, "accepted")
        except Exception:
            pass
    print(f"Applied run {run_id} to repo.")


def _run_summary_for_ranking(cfg: RepoConfig, run_dir: Path) -> dict:
    """Load run dir into a dict with run_id, created_at, tests_exit_code, diff_lines, touched_files."""
    run_id = run_dir.name
    meta: dict = {}
    meta_path = run_dir / "metadata.json"
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    diff_path = run_dir / "diff.patch"
    diff_lines = 0
    touched_files: set = set()
    if diff_path.exists():
        content = diff_path.read_text(encoding="utf-8")
        diff_lines = sum(1 for _ in content.splitlines())
        touched_files = semantic_mod.parse_diff_touched_files(content)
    tests_exit_code = None
    tests_path = run_dir / "tests.json"
    if tests_path.exists():
        try:
            t = json.loads(tests_path.read_text(encoding="utf-8"))
            tests_exit_code = t.get("exit_code")
        except Exception:
            pass
    return {
        "run_id": run_id,
        "created_at": meta.get("created_at", 0.0),
        "tests_exit_code": tests_exit_code,
        "diff_lines": diff_lines,
        "touched_files": touched_files,
        "experiment_id": meta.get("experiment_id"),
    }


def get_all_run_summaries(cfg: RepoConfig) -> list[dict]:
    """Return a list of run summary dicts for all runs in .ai_history."""
    summaries = []
    for p in sorted(cfg.ai_history_dir.iterdir()):
        if not p.is_dir() or not p.name.startswith("run_"):
            continue
        summaries.append(_run_summary_for_ranking(cfg, p))
    return summaries


def get_touched_files_for_run(cfg: RepoConfig, run_id: str) -> set:
    """Return the set of file paths touched by this run's diff."""
    run_dir = _run_dir(cfg, run_id)
    diff_path = run_dir / "diff.patch"
    if not diff_path.exists():
        return set()
    return semantic_mod.parse_diff_touched_files(diff_path.read_text(encoding="utf-8"))


def rank_runs(cfg: RepoConfig, by: str = "tests") -> None:
    """Print runs ranked by the given criterion: tests (passing first), time (newest first), diff (smallest first)."""
    summaries = get_all_run_summaries(cfg)
    if by == "tests":
        # Prefer tests_exit_code 0, then by created_at descending
        def key(s: dict):
            ec = s.get("tests_exit_code")
            if ec is None:
                ec = 999
            return (ec, -float(s.get("created_at", 0)))
        summaries.sort(key=key)
    elif by == "time":
        summaries.sort(key=lambda s: -float(s.get("created_at", 0)))
    elif by == "diff":
        summaries.sort(key=lambda s: (s.get("diff_lines", 0), -float(s.get("created_at", 0))))
    else:
        raise SystemExit(f"Unknown rank criterion: {by!r}. Use tests, time, or diff.")
    for s in summaries:
        ec = s.get("tests_exit_code")
        ec_str = str(ec) if ec is not None else "n/a"
        print(f"{s['run_id']}\ttests={ec_str}\tdiff_lines={s.get('diff_lines', 0)}\t{s.get('experiment_id', '')}")


def _runs_with_overlapping_files(cfg: RepoConfig, run_id: str, other_run_ids: list[str]) -> list[str]:
    """Return other_run_ids that touch any file also touched by run_id."""
    touched = get_touched_files_for_run(cfg, run_id)
    if not touched:
        return []
    overlapping = []
    for oid in other_run_ids:
        if oid == run_id:
            continue
        ot = get_touched_files_for_run(cfg, oid)
        if touched & ot:
            overlapping.append(oid)
    return overlapping


def merge_plan(cfg: RepoConfig, run_id: str) -> None:
    """Print a human-readable merge plan for a run: intent, touched files, test result, and conflicts."""
    run_dir = _run_dir(cfg, run_id)
    touched = get_touched_files_for_run(cfg, run_id)
    meta_path = run_dir / "metadata.json"
    intent_path = run_dir / "intent.json"
    tests_path = run_dir / "tests.json"

    print(f"Merge plan for {run_id}")
    print("-" * 40)
    if meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        print(f"Workspace: {meta.get('workspace', '?')}")
        print(f"Experiment: {meta.get('experiment_id', '?')}")
    if intent_path.exists():
        data = json.loads(intent_path.read_text(encoding="utf-8"))
        goal = (data.get("intent") or {}).get("goal", "?")
        print(f"Goal: {goal}")
    print(f"Touched files ({len(touched)}): {sorted(touched)[:20]}{'...' if len(touched) > 20 else ''}")
    if tests_path.exists():
        t = json.loads(tests_path.read_text(encoding="utf-8"))
        print(f"Tests exit code: {t.get('exit_code', 'n/a')}")

    accepted = experiments_mod.get_accepted_run_ids(cfg)
    conflicts = _runs_with_overlapping_files(cfg, run_id, accepted)
    if conflicts:
        print(f"\nConflicts with accepted runs (overlapping files): {conflicts}")
        print("Resolve by accepting only one of these runs or merging manually.")
    else:
        print("\nNo conflicts with already-accepted runs.")


def merge_best(cfg: RepoConfig, limit: int = 1, dry_run: bool = False) -> None:
    """Rank runs by tests, then apply up to `limit` runs that do not conflict with already-accepted runs."""
    summaries = get_all_run_summaries(cfg)
    # Rank by tests (passing first)
    summaries.sort(key=lambda s: (s.get("tests_exit_code") if s.get("tests_exit_code") is not None else 999, -float(s.get("created_at", 0))))
    accepted_ids = set(experiments_mod.get_accepted_run_ids(cfg))
    applied = 0
    for s in summaries:
        if applied >= limit:
            break
        run_id = s["run_id"]
        if run_id in accepted_ids:
            continue
        touched = s.get("touched_files") or set()
        if not touched:
            # No meaningful diff; skip or still try to apply?
            continue
        # Check conflict with already accepted (from experiments) and with runs we've applied this round
        other_accepted = list(accepted_ids)
        conflicts = _runs_with_overlapping_files(cfg, run_id, other_accepted)
        if conflicts:
            print(f"Skipping {run_id}: conflicts with {conflicts}")
            continue
        if dry_run:
            print(f"Would apply {run_id}")
            accepted_ids.add(run_id)
            applied += 1
        else:
            try:
                accept_run(cfg, run_id, dry_run=False)
                accepted_ids.add(run_id)
                applied += 1
            except SystemExit:
                raise
            except Exception as e:
                print(f"Failed to apply {run_id}: {e}")


