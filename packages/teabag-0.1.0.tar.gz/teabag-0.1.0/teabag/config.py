from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json


CONFIG_DIR_NAME = ".teabag"
CONFIG_FILE_NAME = "config.json"
HOOKS_CONFIG_JSON = "teabag.json"
WORKSPACES_DIR_NAME = "workspaces"
AI_HISTORY_DIR_NAME = ".ai_history"
ENV_STORE_DIR_NAME = "env_store"
SNAPSHOTS_DIR_NAME = "snapshots"


@dataclass
class HooksConfig:
    """Optional test and metrics hooks for Phase 2 run recording."""
    test_command: str | None = None
    test_timeout_seconds: int = 300
    metrics_script: str | None = None


@dataclass
class RepoConfig:
    repo_root: Path
    teabag_dir: Path
    workspaces_dir: Path
    ai_history_dir: Path
    env_store_dir: Path
    snapshots_dir: Path


def _config_paths(repo_root: Path) -> RepoConfig:
    teabag_dir = repo_root / CONFIG_DIR_NAME
    return RepoConfig(
        repo_root=repo_root,
        teabag_dir=teabag_dir,
        workspaces_dir=repo_root / WORKSPACES_DIR_NAME,
        ai_history_dir=repo_root / AI_HISTORY_DIR_NAME,
        env_store_dir=repo_root / ENV_STORE_DIR_NAME,
        snapshots_dir=teabag_dir / SNAPSHOTS_DIR_NAME,
    )


def init_repo(repo_root: Path) -> RepoConfig:
    cfg = _config_paths(repo_root)
    cfg.teabag_dir.mkdir(exist_ok=True)
    cfg.workspaces_dir.mkdir(exist_ok=True)
    cfg.ai_history_dir.mkdir(exist_ok=True)
    cfg.env_store_dir.mkdir(exist_ok=True)

    cfg.snapshots_dir.mkdir(parents=True, exist_ok=True)
    config_file = cfg.teabag_dir / CONFIG_FILE_NAME
    if not config_file.exists():
        data = {
            "version": 1,
            "paths": {
                "workspaces": str(cfg.workspaces_dir.relative_to(repo_root)),
                "ai_history": str(cfg.ai_history_dir.relative_to(repo_root)),
                "env_store": str(cfg.env_store_dir.relative_to(repo_root)),
            },
        }
        config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

    return cfg


def load_or_init(repo_root: Path) -> RepoConfig:
    cfg = _config_paths(repo_root)
    teabag_dir = cfg.teabag_dir
    config_file = teabag_dir / CONFIG_FILE_NAME
    if not config_file.exists():
        return init_repo(repo_root)

    # For now, we trust the paths in the file but still derive absolute Paths.
    data = json.loads(config_file.read_text(encoding="utf-8"))
    paths = data.get("paths", {})
    workspaces_dir = repo_root / paths.get("workspaces", WORKSPACES_DIR_NAME)
    ai_history_dir = repo_root / paths.get("ai_history", AI_HISTORY_DIR_NAME)
    env_store_dir = repo_root / paths.get("env_store", ENV_STORE_DIR_NAME)
    snapshots_dir = teabag_dir / SNAPSHOTS_DIR_NAME

    workspaces_dir.mkdir(exist_ok=True)
    ai_history_dir.mkdir(exist_ok=True)
    env_store_dir.mkdir(exist_ok=True)
    snapshots_dir.mkdir(exist_ok=True)

    return RepoConfig(
        repo_root=repo_root,
        teabag_dir=teabag_dir,
        workspaces_dir=workspaces_dir,
        ai_history_dir=ai_history_dir,
        env_store_dir=env_store_dir,
        snapshots_dir=snapshots_dir,
    )


def load_hooks_config(repo_root: Path) -> HooksConfig | None:
    """Load teabag.json from repo root. Returns None if missing or invalid."""
    path = repo_root / HOOKS_CONFIG_JSON
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    test_cmd = data.get("test_command")
    if test_cmd is not None and not isinstance(test_cmd, str):
        test_cmd = None
    timeout = 300
    if "test_timeout" in data and isinstance(data["test_timeout"], (int, float)):
        timeout = int(data["test_timeout"])
    metrics = data.get("metrics_script")
    if metrics is not None and not isinstance(metrics, str):
        metrics = None
    return HooksConfig(
        test_command=test_cmd,
        test_timeout_seconds=timeout,
        metrics_script=metrics,
    )

