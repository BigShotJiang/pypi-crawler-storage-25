from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from .config import RepoConfig


TASKS_FILE_NAME = "tasks.json"

TaskStatus = Literal["pending", "running", "completed"]


@dataclass
class Task:
    task_id: str
    description: str
    status: TaskStatus
    agent_names: list[str]


def _tasks_file(cfg: RepoConfig) -> Path:
    return cfg.teabag_dir / TASKS_FILE_NAME


def _load_tasks(cfg: RepoConfig) -> dict:
    path = _tasks_file(cfg)
    if not path.exists():
        return {"tasks": [], "next_id": 1}
    return json.loads(path.read_text(encoding="utf-8"))


def _save_tasks(cfg: RepoConfig, data: dict) -> None:
    path = _tasks_file(cfg)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def create_task(cfg: RepoConfig, description: str, agents: list[str]) -> Task:
    data = _load_tasks(cfg)
    next_id = int(data.get("next_id", 1))
    task_id = f"task_{next_id:03d}"
    raw = {
        "task_id": task_id,
        "description": description,
        "status": "pending",
        "agents": agents,
    }
    data.setdefault("tasks", []).append(raw)
    data["next_id"] = next_id + 1
    _save_tasks(cfg, data)
    return Task(task_id=task_id, description=description, status="pending", agent_names=agents)


def list_tasks(cfg: RepoConfig) -> None:
    data = _load_tasks(cfg)
    for raw in data.get("tasks", []):
        print(f"{raw.get('task_id')}\t{raw.get('status')}\t{raw.get('description')}")


def task_run(cfg: RepoConfig, description: str, num_agents: int, template: str | None = None) -> Task:
    """Create a task, spawn num_agents workspaces (agent_1 .. agent_n), and associate them with the task."""
    from . import workspace as workspace_mod

    names = workspace_mod.agents_spawn(cfg, num_agents, template=template)
    return create_task(cfg, description, names)

