# env-guard-checker

Lightweight pre-flight checks for Python projects.

Validate environment variables, services, endpoints and files before running your application.

---

## Installation

```bash
pip install env-guard-checker
```

Requires Python 3.9+.

---

## Quick example

```bash
envguard init
envguard check
```

Example output:

```text
ENV VARS
✓ OPENAI_API_KEY present
✗ DATABASE_URL missing

TCP PORTS
✗ PostgreSQL connection refused
```

---

## Configuration

Create an `envguard.yaml` file:

```yaml
name: my-app

env_vars:
  - key: OPENAI_API_KEY
    required: true
    validate: starts_with:sk-

  - key: DATABASE_URL
    required: true
    validate: contains:postgresql

tcp_ports:
  - host: localhost
    port: 5432
    label: PostgreSQL

http_endpoints:
  - url: http://localhost:8000/health
    expect_status: 200

files:
  - path: .env
    type: file
```

---

## CLI

```bash
envguard check
envguard check --hints
envguard check -c custom.yaml
envguard init
```

Exit codes:
- 0 → success
- 1 → failed checks

---

## Use cases

- Local development sanity checks
- CI validation before deploy
- Preventing common misconfiguration issues

---

## Project

Source code:
https://github.com/IvanYanishevskyi/env-guard

---

## License

MIT
