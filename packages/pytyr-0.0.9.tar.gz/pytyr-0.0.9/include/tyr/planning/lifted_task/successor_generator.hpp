/*
 * Copyright (C) 2025-2026 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_PLANNING_LIFTED_TASK_SUCCESSOR_GENERATOR_HPP_
#define TYR_PLANNING_LIFTED_TASK_SUCCESSOR_GENERATOR_HPP_

#include "tyr/common/itertools.hpp"
#include "tyr/common/onetbb.hpp"
#include "tyr/datalog/policies/annotation.hpp"
#include "tyr/datalog/policies/termination.hpp"
#include "tyr/datalog/workspaces/program.hpp"
#include "tyr/formalism/planning/ground_action_view.hpp"
#include "tyr/planning/action_executor.hpp"
#include "tyr/planning/declarations.hpp"
#include "tyr/planning/ground_task/match_tree/declarations.hpp"
#include "tyr/planning/lifted_task.hpp"
#include "tyr/planning/lifted_task/axiom_evaluator.hpp"
#include "tyr/planning/lifted_task/node.hpp"
#include "tyr/planning/lifted_task/state_repository.hpp"
#include "tyr/planning/lifted_task/state_view.hpp"
#include "tyr/planning/successor_generator.hpp"

#include <type_traits>
#include <utility>

namespace tyr::planning
{

template<>
class SuccessorGenerator<LiftedTag>
{
public:
    explicit SuccessorGenerator(std::shared_ptr<Task<LiftedTag>> task, ExecutionContextPtr execution_context);

    static std::shared_ptr<SuccessorGenerator<LiftedTag>> create(std::shared_ptr<Task<LiftedTag>> task, ExecutionContextPtr execution_context);

    Node<LiftedTag> get_initial_node();

    // Ground action API (interning)
    std::vector<LabeledNode<LiftedTag>> get_labeled_successor_nodes(const Node<LiftedTag>& node);

    void get_labeled_successor_nodes(const Node<LiftedTag>& node, std::vector<LabeledNode<LiftedTag>>& out_nodes);

    Node<LiftedTag> get_successor_node(const Node<LiftedTag>& node, formalism::planning::GroundActionView action);

    // Action binding API (interning)
    Node<LiftedTag> get_successor_node(const Node<LiftedTag>& node, formalism::planning::ActionBindingView binding);

    std::vector<formalism::planning::ActionBindingView> get_applicable_action_bindings(const Node<LiftedTag>& node);

    void get_applicable_action_bindings(const Node<LiftedTag>& node, std::vector<formalism::planning::ActionBindingView>& out_bindings);

    // Action binding API (no interning)
    Node<LiftedTag> get_successor_node(const Node<LiftedTag>& node, const Data<formalism::RelationBinding<formalism::planning::Action>>& binding);

    template<typename Callback>
    void for_each_applicable_action_binding(const Node<LiftedTag>& node, Callback&& callback);

    template<typename Callback>
    void for_each_applicable_action_binding(const Node<LiftedTag>& node,
                                            Data<formalism::RelationBinding<formalism::planning::Action>>& scratch_binding,
                                            Callback&& callback);

    // Lookup
    Node<LiftedTag> get_node(Index<State<LiftedTag>> state_index);

    // Diagnostics
    void print_summary(size_t verbosity) const;

    const auto& get_state_repository() const noexcept { return m_state_repository; }
    const auto& get_workspace() const noexcept { return m_workspace; }

private:
    void compute_action_facts(const Node<LiftedTag>& node);

    using ActionBindingCallback = void (*)(const Data<formalism::RelationBinding<formalism::planning::Action>>&, void*);

    void for_each_applicable_action_binding_impl(const Node<LiftedTag>& node,
                                                 Data<formalism::RelationBinding<formalism::planning::Action>>& scratch_binding,
                                                 ActionBindingCallback callback,
                                                 void* callback_data);

private:
    std::shared_ptr<Task<LiftedTag>> m_task;
    ExecutionContextPtr m_execution_context;
    itertools::cartesian_set::Workspace<Index<formalism::Object>> m_cartesian_workspace;
    Data<formalism::RelationBinding<formalism::planning::Action>> m_scratch_action_binding;

    datalog::ProgramWorkspace<datalog::NoOrAnnotationPolicy, datalog::NoAndAnnotationPolicy, datalog::NoTerminationPolicy> m_workspace;

    std::shared_ptr<StateRepository<LiftedTag>> m_state_repository;

    ActionExecutor m_executor;
};

/**
 * Implementations
 */

// Action binding API (no interning)

template<typename Callback>
void SuccessorGenerator<LiftedTag>::for_each_applicable_action_binding(const Node<LiftedTag>& node, Callback&& callback)
{
    auto scratch_binding = Data<formalism::RelationBinding<formalism::planning::Action>>();
    for_each_applicable_action_binding(node, scratch_binding, std::forward<Callback>(callback));
}

template<typename Callback>
void SuccessorGenerator<LiftedTag>::for_each_applicable_action_binding(const Node<LiftedTag>& node,
                                                                       Data<formalism::RelationBinding<formalism::planning::Action>>& scratch_binding,
                                                                       Callback&& callback)
{
    using CallbackStorage = std::remove_reference_t<Callback>;
    auto callback_storage = &callback;
    for_each_applicable_action_binding_impl(
        node,
        scratch_binding,
        [](const Data<formalism::RelationBinding<formalism::planning::Action>>& binding, void* callback_data)
        { (*static_cast<CallbackStorage*>(callback_data))(binding); },
        callback_storage);
}
}

#endif
