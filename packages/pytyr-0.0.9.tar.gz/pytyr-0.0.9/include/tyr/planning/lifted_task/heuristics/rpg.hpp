/*
 * Copyright (C) 2025-2026 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_PLANNING_LIFTED_TASK_HEURISTICS_RPG_HPP_
#define TYR_PLANNING_LIFTED_TASK_HEURISTICS_RPG_HPP_

#include "tyr/common/onetbb.hpp"
#include "tyr/datalog/bottom_up.hpp"
#include "tyr/datalog/contexts/program.hpp"
#include "tyr/datalog/formatter.hpp"
#include "tyr/datalog/workspaces/program.hpp"
#include "tyr/planning/declarations.hpp"
#include "tyr/planning/heuristic.hpp"
#include "tyr/planning/lifted_task.hpp"
#include "tyr/planning/lifted_task/state_data.hpp"
#include "tyr/planning/lifted_task/state_view.hpp"
#include "tyr/planning/lifted_task/unpacked_state.hpp"
#include "tyr/planning/task_utils.hpp"

#include <fmt/ostream.h>

namespace tyr::planning
{

template<typename Derived, typename OrAP, typename AndAP, typename TP>
class RPGBase : public Heuristic<LiftedTag>
{
private:
    /// @brief Helper to cast to Derived.
    constexpr const auto& self() const { return static_cast<const Derived&>(*this); }
    constexpr auto& self() { return static_cast<Derived&>(*this); }

public:
    explicit RPGBase(std::shared_ptr<Task<LiftedTag>> task, ExecutionContextPtr execution_context, const OrAP& or_ap, const AndAP& and_ap, const TP& tp) :
        m_task(std::move(task)),
        m_execution_context(std::move(execution_context)),
        m_workspace(m_task->get_rpg_program().get_program_context(), m_task->get_rpg_program().get_const_program_workspace(), or_ap, and_ap, tp)
    {
        m_workspace.tp.set_goals(m_task->get_rpg_program().get_goal());
    }

    void set_goal(formalism::planning::GroundConjunctiveConditionView goal) override
    {
        auto merge_context = formalism::planning::MergeDatalogContext { m_workspace.datalog_builder, m_workspace.workspace_repository };
        const auto& p2d = m_task->get_rpg_program().get_translation_context().p2d;
        m_workspace.tp.set_goals(formalism::planning::merge_p2d(goal, p2d.fluent_to_fluent_predicate, p2d.derived_to_fluent_predicate, merge_context).first);
    }

    float_t evaluate(const StateView<LiftedTag>& state) override
    {
        m_workspace.facts.reset();

        auto merge_context = formalism::planning::MergeDatalogContext { m_workspace.datalog_builder, m_workspace.workspace_repository };

        insert_fluent_atoms_to_fact_set(state.get_unpacked_state(),
                                        *m_task->get_repository(),
                                        m_task->get_rpg_program().get_translation_context().p2d.fluent_to_fluent_predicate,
                                        merge_context,
                                        m_workspace.facts.fact_sets);
        insert_numeric_variables_to_fact_set(state.get_unpacked_state(), *m_task->get_repository(), merge_context, m_workspace.facts.fact_sets);

        auto ctx = datalog::ProgramExecutionContext(m_workspace, m_task->get_rpg_program().get_const_program_workspace());
        ctx.clear();

        m_execution_context->arena().execute([&] { datalog::solve_bottom_up(ctx); });

        return (m_workspace.tp.check(datalog::FactSets { m_task->get_rpg_program().get_const_program_workspace().facts.fact_sets, m_workspace.facts.fact_sets })) ?
                   self().extract_cost_and_set_preferred_actions_impl(state) :
                   std::numeric_limits<float_t>::infinity();
    }

    const auto& get_workspace() const noexcept { return m_workspace; }

    void print_summary(size_t verbosity) const override
    {
        if (verbosity < 1)
            return;

        std::cout << "[RPGHeuristic] Summary" << std::endl;
        fmt::print(std::cout, "{}\n", m_workspace.statistics);
        auto rule_statistics = std::vector<datalog::RuleStatistics> {};
        for (const auto& ws_rule : m_workspace.rules)
            rule_statistics.push_back(ws_rule->common.statistics);
        fmt::print(std::cout, "{}\n", datalog::compute_aggregated_rule_statistics(rule_statistics));
        auto rule_worker_statistics = std::vector<datalog::RuleWorkerStatistics> {};
        for (const auto& ws_rule : m_workspace.rules)
            for (const auto& worker : ws_rule->worker)
                rule_worker_statistics.push_back(worker.solve.statistics);
        fmt::print(std::cout, "{}\n", datalog::compute_aggregated_rule_worker_statistics(rule_worker_statistics));
    }

protected:
    std::shared_ptr<Task<LiftedTag>> m_task;
    ExecutionContextPtr m_execution_context;

    datalog::ProgramWorkspace<OrAP, AndAP, TP> m_workspace;
};

}

#endif
