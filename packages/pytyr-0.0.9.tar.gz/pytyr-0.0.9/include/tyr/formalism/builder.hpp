/*
 * Copyright (C) 2025-2026 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_FORMALISM_BUILDER_HPP_
#define TYR_FORMALISM_BUILDER_HPP_

#include "tyr/common/tuple.hpp"
#include "tyr/formalism/basic_builder.hpp"

#include <tuple>

namespace tyr::formalism
{

template<typename... Ts>
class Builder
{
private:
    using BuilderStorage = std::tuple<BasicBuilder<Ts>...>;

    BuilderStorage m_builder;

public:
    Builder() = default;

    template<typename T>
    [[nodiscard]] auto get_builder()
    {
        return std::get<BasicBuilder<T>>(m_builder).get_builder();
    }
};

}

#endif
