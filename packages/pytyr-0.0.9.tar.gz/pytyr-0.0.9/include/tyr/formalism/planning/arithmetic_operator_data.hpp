/*
 * Copyright (C) 2025-2026 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_FORMALISM_PLANNING_ARITHMETIC_OPERATOR_DATA_HPP_
#define TYR_FORMALISM_PLANNING_ARITHMETIC_OPERATOR_DATA_HPP_

#include "tyr/common/types.hpp"
#include "tyr/common/types_utils.hpp"
#include "tyr/formalism/planning/binary_operator_index.hpp"
#include "tyr/formalism/planning/declarations.hpp"
#include "tyr/formalism/planning/multi_operator_index.hpp"
#include "tyr/formalism/planning/unary_operator_index.hpp"

#include <variant>

namespace tyr
{
template<typename T>
struct Data<formalism::planning::ArithmeticOperator<T>>
{
    using Variant = ::cista::offset::variant<Index<formalism::planning::UnaryOperator<formalism::OpSub, T>>,
                                             Index<formalism::planning::BinaryOperator<formalism::OpAdd, T>>,
                                             Index<formalism::planning::BinaryOperator<formalism::OpSub, T>>,
                                             Index<formalism::planning::BinaryOperator<formalism::OpMul, T>>,
                                             Index<formalism::planning::BinaryOperator<formalism::OpDiv, T>>,
                                             Index<formalism::planning::MultiOperator<formalism::OpAdd, T>>,
                                             Index<formalism::planning::MultiOperator<formalism::OpMul, T>>>;

    Variant value;

    template<typename C>
    using ViewVariant = std::variant<View<Index<formalism::planning::UnaryOperator<formalism::OpSub, T>>, C>,
                                     View<Index<formalism::planning::BinaryOperator<formalism::OpAdd, T>>, C>,
                                     View<Index<formalism::planning::BinaryOperator<formalism::OpSub, T>>, C>,
                                     View<Index<formalism::planning::BinaryOperator<formalism::OpMul, T>>, C>,
                                     View<Index<formalism::planning::BinaryOperator<formalism::OpDiv, T>>, C>,
                                     View<Index<formalism::planning::MultiOperator<formalism::OpAdd, T>>, C>,
                                     View<Index<formalism::planning::MultiOperator<formalism::OpMul, T>>, C>>;

    Data() = default;
    Data(Variant value_) : value(value_) {}
    // Python constructor
    template<typename C>
    Data(ViewVariant<C> value_) : value(std::visit([](const auto& view) -> Variant { return Variant(view.get_index()); }, value_))
    {
    }

    void clear() noexcept { tyr::clear(value); }

    auto cista_members() const noexcept { return std::tie(value); }
    auto identifying_members() const noexcept { return std::tie(value); }
};

static_assert(!uses_trivial_storage_v<formalism::planning::ArithmeticOperator<Data<formalism::planning::FunctionExpression>>>);
}

#endif
