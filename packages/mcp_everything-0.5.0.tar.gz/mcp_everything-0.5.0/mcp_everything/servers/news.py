"""
News MCP server.
Uses NewsAPI.org — free tier: 100 requests/day.
Get your free key at: https://newsapi.org/register
Set NEWS_API_KEY in your environment or .env file.
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP
from mcp_everything.env_utils import load_mcp_env

load_mcp_env()

mcp = FastMCP("news")

NEWS_API = "https://newsapi.org/v2"


def _api_key() -> str:
    key = os.environ.get("NEWS_API_KEY", "")
    if not key:
        raise ValueError(
            "NEWS_API_KEY not set. Get a free key at https://newsapi.org/register "
            "then run: export NEWS_API_KEY=your_key_here"
        )
    return key


@mcp.tool()
async def news_headlines(country: str = "us", category: str = "", limit: int = 5) -> str:
    """Get today's top news headlines.

    Args:
        country: 2-letter country code (e.g. 'us', 'gb', 'au', 'ca', default 'us')
        category: News category — 'business', 'entertainment', 'health', 'science', 'sports', 'technology' (optional)
        limit: Number of articles (1-20, default 5)
    """
    limit = min(max(1, limit), 20)
    params: dict = {"country": country, "pageSize": limit, "apiKey": _api_key()}
    if category:
        params["category"] = category

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{NEWS_API}/top-headlines", params=params)
        r.raise_for_status()
        data = r.json()

    articles = data.get("articles", [])
    if not articles:
        return f"No headlines found for country '{country}'."

    cat_label = f" [{category}]" if category else ""
    results = [f"**Top Headlines ({country.upper()}){cat_label}**\n"]
    for a in articles:
        source = a.get("source", {}).get("name", "Unknown")
        title = a.get("title", "Untitled")
        desc = a.get("description") or ""
        url = a.get("url", "")
        published = a.get("publishedAt", "")[:10]
        results.append(
            f"**{title}**\n"
            f"{desc[:150]}{'...' if len(desc) > 150 else ''}\n"
            f"_{source}_ · {published} · {url}"
        )
    return "\n\n---\n\n".join(results)


@mcp.tool()
async def news_search(query: str, limit: int = 5, sort_by: str = "relevancy", language: str = "en") -> str:
    """Search news articles from the last month.

    Args:
        query: Search terms (e.g. 'artificial intelligence', 'climate change')
        limit: Number of articles (1-20, default 5)
        sort_by: 'relevancy', 'popularity', or 'publishedAt' (default 'relevancy')
        language: Language code (e.g. 'en', 'es', 'fr', 'de', default 'en')
    """
    limit = min(max(1, limit), 20)
    sort_by = sort_by if sort_by in ("relevancy", "popularity", "publishedAt") else "relevancy"

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(
            f"{NEWS_API}/everything",
            params={
                "q": query,
                "pageSize": limit,
                "sortBy": sort_by,
                "language": language,
                "apiKey": _api_key(),
            },
        )
        r.raise_for_status()
        data = r.json()

    articles = data.get("articles", [])
    if not articles:
        return f"No news found for '{query}'."

    total = data.get("totalResults", 0)
    results = [f"**News search: '{query}'** ({total:,} total results)\n"]
    for a in articles:
        source = a.get("source", {}).get("name", "Unknown")
        title = a.get("title", "Untitled")
        desc = a.get("description") or ""
        url = a.get("url", "")
        published = a.get("publishedAt", "")[:10]
        results.append(
            f"**{title}**\n"
            f"{desc[:150]}{'...' if len(desc) > 150 else ''}\n"
            f"_{source}_ · {published} · {url}"
        )
    return "\n\n---\n\n".join(results)


@mcp.tool()
async def news_sources(category: str = "", country: str = "", language: str = "en") -> str:
    """List available news sources you can follow.

    Args:
        category: Filter by category — 'business', 'entertainment', 'health', 'science', 'sports', 'technology'
        country: Filter by country code (e.g. 'us', 'gb')
        language: Filter by language code (e.g. 'en', 'es', default 'en')
    """
    params: dict = {"language": language, "apiKey": _api_key()}
    if category:
        params["category"] = category
    if country:
        params["country"] = country

    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{NEWS_API}/top-headlines/sources", params=params)
        r.raise_for_status()
        data = r.json()

    sources = data.get("sources", [])
    if not sources:
        return "No sources found with those filters."

    results = [f"**Available News Sources** ({len(sources)} found)\n"]
    for s in sources[:20]:
        results.append(
            f"• **{s.get('name')}** (`{s.get('id')}`)\n"
            f"  {s.get('description', '')[:100]}\n"
            f"  {s.get('url', '')}"
        )
    return "\n\n".join(results)


if __name__ == "__main__":
    mcp.run()
