"""
NASA MCP server.
Free API key at: https://api.nasa.gov (instant, no credit card)
Set NASA_API_KEY in your environment. Without a key, uses DEMO_KEY (30 req/hour).
"""

import os
import httpx
from mcp.server.fastmcp import FastMCP
from mcp_everything.env_utils import load_mcp_env

load_mcp_env()

mcp = FastMCP("nasa")

NASA_API = "https://api.nasa.gov"


def _key() -> str:
    return os.environ.get("NASA_API_KEY", "DEMO_KEY")


@mcp.tool()
async def nasa_apod(date: str = "") -> str:
    """Get NASA's Astronomy Picture of the Day (APOD).

    Args:
        date: Date in YYYY-MM-DD format (default: today). Can go back to 1995-06-16.
    """
    params: dict = {"api_key": _key()}
    if date:
        params["date"] = date

    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(f"{NASA_API}/planetary/apod", params=params)
        if r.status_code == 400:
            return f"Invalid date '{date}'. Use YYYY-MM-DD format, between 1995-06-16 and today."
        r.raise_for_status()
        data = r.json()

    media_type = data.get("media_type", "image")
    url = data.get("url", "")
    hdurl = data.get("hdurl", url)

    return (
        f"# {data.get('title', 'Astronomy Picture of the Day')}\n"
        f"**Date:** {data.get('date')}\n\n"
        f"{data.get('explanation', '')}\n\n"
        f"{'🖼️ Image' if media_type == 'image' else '🎥 Video'}: {hdurl or url}"
        + (f"\n_Copyright: {data['copyright']}_" if data.get("copyright") else "")
    )


@mcp.tool()
async def nasa_neo(start_date: str = "", end_date: str = "") -> str:
    """Get Near Earth Objects (asteroids) passing close to Earth.

    Args:
        start_date: Start date in YYYY-MM-DD format (default: today)
        end_date: End date in YYYY-MM-DD format (default: 7 days from start, max 7-day window)
    """
    from datetime import date, timedelta
    if not start_date:
        start_date = date.today().isoformat()
    if not end_date:
        start = date.fromisoformat(start_date)
        end_date = (start + timedelta(days=7)).isoformat()

    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(
            f"{NASA_API}/neo/rest/v1/feed",
            params={"start_date": start_date, "end_date": end_date, "api_key": _key()},
        )
        r.raise_for_status()
        data = r.json()

    total = data.get("element_count", 0)
    near_earth_objects = data.get("near_earth_objects", {})

    results = [f"**Near-Earth Objects: {start_date} to {end_date}**\n{total} total objects\n"]
    for date_str, objects in sorted(near_earth_objects.items())[:7]:
        results.append(f"**{date_str}** ({len(objects)} objects)")
        hazardous = [o for o in objects if o.get("is_potentially_hazardous_asteroid")]
        for obj in sorted(objects, key=lambda o: o.get("close_approach_data", [{}])[0].get("miss_distance", {}).get("kilometers", "999999999"))[:3]:
            name = obj.get("name", "Unknown")
            approach = obj.get("close_approach_data", [{}])[0]
            miss_km = float(approach.get("miss_distance", {}).get("kilometers", 0))
            velocity = float(approach.get("relative_velocity", {}).get("kilometers_per_hour", 0))
            diam_min = obj.get("estimated_diameter", {}).get("kilometers", {}).get("estimated_diameter_min", 0)
            diam_max = obj.get("estimated_diameter", {}).get("kilometers", {}).get("estimated_diameter_max", 0)
            hazard = " ⚠️ HAZARDOUS" if obj.get("is_potentially_hazardous_asteroid") else ""
            results.append(
                f"  • {name}{hazard}\n"
                f"    Distance: {miss_km:,.0f} km | Speed: {velocity:,.0f} km/h\n"
                f"    Diameter: {diam_min:.3f}–{diam_max:.3f} km"
            )

    return "\n\n".join(results)


@mcp.tool()
async def nasa_mars_photos(rover: str = "curiosity", sol: int = 1000, limit: int = 5) -> str:
    """Get photos taken by a NASA Mars rover.

    Args:
        rover: Rover name — 'curiosity', 'opportunity', 'spirit', or 'perseverance' (default 'curiosity')
        sol: Martian sol (day) number (default 1000)
        limit: Number of photos to return (1-20, default 5)
    """
    limit = min(max(1, limit), 20)
    rover = rover.lower()
    if rover not in ("curiosity", "opportunity", "spirit", "perseverance"):
        return "Invalid rover. Choose from: curiosity, opportunity, spirit, perseverance"

    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(
            f"{NASA_API}/mars-photos/api/v1/rovers/{rover}/photos",
            params={"sol": sol, "api_key": _key(), "per_page": limit},
        )
        r.raise_for_status()
        data = r.json()

    photos = data.get("photos", [])
    if not photos:
        return f"No photos from {rover.title()} on sol {sol}. Try a different sol number."

    results = [f"**{rover.title()} Mars Photos — Sol {sol}**\n"]
    for p in photos[:limit]:
        camera = p.get("camera", {}).get("full_name", "Unknown camera")
        earth_date = p.get("earth_date", "?")
        img_url = p.get("img_src", "")
        results.append(f"📷 {camera} ({earth_date})\n{img_url}")
    return "\n\n".join(results)


if __name__ == "__main__":
    mcp.run()
