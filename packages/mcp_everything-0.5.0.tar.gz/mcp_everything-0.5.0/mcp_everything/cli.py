"""
mcp-everything CLI — setup wizard and server management.

Usage:
    mcp-everything setup              # interactive setup wizard
    mcp-everything list               # show available servers
    mcp-everything add <server>       # add a single server
    mcp-everything remove <server>    # remove a single server
    mcp-everything status             # show currently configured servers
    mcp-everything create <name>      # scaffold a new custom server
    mcp-everything doctor             # diagnose your setup
    mcp-everything update             # check for a newer version
    mcp-everything test [server]      # live-test one or all servers
"""

import click
import json
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from mcp_everything import __version__
from mcp_everything.config import (
    SERVERS,
    build_server_entry,
    get_claude_config_path,
    load_config,
    save_config,
)

console = Console()

BANNER = r"""
  _ __ ___   ___ _ __       _____   _____ _ __ _   _| |_| |__ (_)_ __   __ _
 | '_ ` _ \ / __| '_ \ ____/ _ \ \ / / _ \ '__| | | | __| '_ \| | '_ \ / _` |
 | | | | | | (__| |_) |___/  __/\ V /  __/ |  | |_| | |_| | | | | | | | (_| |
 |_| |_| |_|\___| .__/     \___| \_/ \___|_|   \__, |\__|_| |_|_|_| |_|\__, |
                |_|                              |___/                   |___/
"""


def _print_banner():
    console.print(f"[bold cyan]{BANNER}[/bold cyan]")
    console.print(f"[dim]v{__version__} — plug-and-play MCP servers for Claude[/dim]\n")


def _get_server_by_key(key: str) -> dict | None:
    return next((s for s in SERVERS if s["key"] == key), None)


def _collect_env(server: dict) -> dict[str, str]:
    """Prompt for API keys and return as env dict."""
    env: dict[str, str] = {}
    for var in server.get("env_vars", []):
        required = var.get("required", True)
        label = "[bold yellow]required[/bold yellow]" if required else "[dim]optional — skip to use without[/dim]"
        console.print(f"\n  {var['prompt']} ({label})")
        console.print(f"  [dim]{var['hint']}[/dim]")
        value = click.prompt("  Enter key", default="", show_default=False).strip()
        if value:
            env[var["name"]] = value
        elif required:
            console.print(f"  [yellow]⚠  Skipping {server['label']} (no API key provided)[/yellow]")
            return {}
    return env


@click.group()
def main():
    """mcp-everything — plug-and-play MCP servers for Claude Desktop."""
    pass


@main.command()
def setup():
    """Interactive setup wizard — configure MCP servers for Claude Desktop."""
    _print_banner()

    config_path = get_claude_config_path()
    if config_path is None:
        console.print("[red]❌ Could not detect your OS. Please run on macOS, Windows, or Linux.[/red]")
        raise SystemExit(1)

    console.print(f"[green]✓[/green] Found Claude Desktop config at:\n  [bold]{config_path}[/bold]\n")

    # Show server table
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("Server", style="bold")
    table.add_column("What it does")
    table.add_column("API key?", justify="center")

    for i, s in enumerate(SERVERS, 1):
        key_badge = "[yellow]🔑 Yes[/yellow]" if s["needs_key"] else "[green]✅ No[/green]"
        table.add_row(str(i), s["label"], s["description"], key_badge)

    console.print(table)
    console.print()

    # Choose servers
    console.print("[bold]Which servers do you want to enable?[/bold]")
    console.print("Enter numbers separated by commas, or [bold]'all'[/bold] for all, [bold]'free'[/bold] for no-API-key servers only.")
    console.print(f"[dim](e.g. 1,2,3 or all or free)[/dim]\n")

    choice = click.prompt("Your choice", default="free").strip().lower()

    if choice == "all":
        selected_indices = list(range(len(SERVERS)))
    elif choice == "free":
        selected_indices = [i for i, s in enumerate(SERVERS) if not s["needs_key"]]
    else:
        selected_indices = []
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                if 0 <= idx < len(SERVERS):
                    selected_indices.append(idx)
        if not selected_indices:
            console.print("[red]No valid servers selected. Exiting.[/red]")
            raise SystemExit(1)

    selected = [SERVERS[i] for i in selected_indices]
    console.print(f"\n[green]Selected {len(selected)} server(s):[/green] {', '.join(s['label'] for s in selected)}\n")

    # Collect keys and build config entries
    config = load_config(config_path)
    mcp_servers = config.setdefault("mcpServers", {})

    added = []
    for server in selected:
        console.rule(f"[bold cyan]{server['label']}[/bold cyan]")
        if server["needs_key"]:
            env = _collect_env(server)
            if not env and any(v["required"] for v in server["env_vars"]):
                continue
        else:
            env = {}

        if server.get("server_type") == "url":
            mcp_servers[server["key"]] = build_server_entry(url=server["url"], env_vars=env or None)
        else:
            mcp_servers[server["key"]] = build_server_entry(server["module"], env or None)
        added.append(server["label"])

    if not added:
        console.print("\n[yellow]No servers were added.[/yellow]")
        raise SystemExit(0)

    save_config(config_path, config)

    console.print()
    console.print(
        Panel(
            f"[green bold]✅ Done![/green bold] Added [bold]{len(added)}[/bold] MCP server(s):\n"
            + "\n".join(f"  • {name}" for name in added)
            + f"\n\n[dim]Config saved to {config_path}[/dim]\n\n"
            + "[bold]Restart Claude Desktop[/bold] for the changes to take effect.",
            title="[bold green]mcp-everything setup complete[/bold green]",
            border_style="green",
        )
    )


@main.command()
def list():
    """List all available MCP servers."""
    _print_banner()
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Server", style="bold")
    table.add_column("Key")
    table.add_column("Description")
    table.add_column("API Key Required", justify="center")
    table.add_column("Tools")

    tool_counts = {
        "hackernews": 4,
        "wikipedia": 4,
        "arxiv": 3,
        "weather": 2,
        "pokedex": 3,
        "reddit": 4,
        "github": 5,
        "news": 3,
    }

    for s in SERVERS:
        key_badge = "🔑 Yes" if s["needs_key"] else "✅ No"
        table.add_row(
            s["label"],
            s["key"],
            s["description"],
            key_badge,
            str(tool_counts.get(s["key"], "?")),
        )

    console.print(table)
    console.print(
        f"\n[dim]Run [bold]mcp-everything setup[/bold] to configure these servers in Claude Desktop.[/dim]"
    )


@main.command()
@click.argument("server_key")
def add(server_key: str):
    """Add a single MCP server to Claude Desktop config.

    SERVER_KEY: Server identifier (e.g. hackernews, wikipedia, github)
    """
    server = _get_server_by_key(server_key)
    if not server:
        keys = [s["key"] for s in SERVERS]
        console.print(f"[red]Unknown server '{server_key}'.[/red] Available: {', '.join(keys)}")
        raise SystemExit(1)

    config_path = get_claude_config_path()
    if config_path is None:
        console.print("[red]Could not detect OS / Claude config path.[/red]")
        raise SystemExit(1)

    console.print(f"\n[bold]Adding {server['label']}...[/bold]")
    env: dict[str, str] = {}
    if server["needs_key"]:
        env = _collect_env(server)
        if not env and any(v["required"] for v in server["env_vars"]):
            console.print("[red]Required API key missing. Aborting.[/red]")
            raise SystemExit(1)

    config = load_config(config_path)
    if server.get("server_type") == "url":
        config.setdefault("mcpServers", {})[server["key"]] = build_server_entry(url=server["url"], env_vars=env or None)
    else:
        config.setdefault("mcpServers", {})[server["key"]] = build_server_entry(server["module"], env or None)
    save_config(config_path, config)
    console.print(f"[green]✅ {server['label']} added.[/green] Restart Claude Desktop to apply changes.")


@main.command()
@click.argument("server_key")
def remove(server_key: str):
    """Remove a single MCP server from Claude Desktop config.

    SERVER_KEY: Server identifier (e.g. hackernews, wikipedia)
    """
    config_path = get_claude_config_path()
    if config_path is None:
        console.print("[red]Could not detect OS / Claude config path.[/red]")
        raise SystemExit(1)

    config = load_config(config_path)
    mcp_servers = config.get("mcpServers", {})

    if server_key not in mcp_servers:
        console.print(f"[yellow]'{server_key}' is not in your Claude Desktop config.[/yellow]")
        raise SystemExit(0)

    del mcp_servers[server_key]
    save_config(config_path, config)
    console.print(f"[green]✅ '{server_key}' removed.[/green] Restart Claude Desktop to apply changes.")


@main.command()
def status():
    """Show which mcp-everything servers are currently configured in Claude Desktop."""
    config_path = get_claude_config_path()
    if config_path is None:
        console.print("[red]Could not detect OS / Claude config path.[/red]")
        raise SystemExit(1)

    config = load_config(config_path)
    mcp_servers = config.get("mcpServers", {})
    our_keys = {s["key"] for s in SERVERS}
    active = {k: v for k, v in mcp_servers.items() if k in our_keys}

    if not active:
        console.print("[yellow]No mcp-everything servers configured.[/yellow]")
        console.print("Run [bold]mcp-everything setup[/bold] to get started.")
        return

    table = Table(box=box.ROUNDED, header_style="bold cyan")
    table.add_column("Server", style="bold green")
    table.add_column("Status", justify="center")
    table.add_column("Has API key", justify="center")

    for key in active:
        server = _get_server_by_key(key)
        label = server["label"] if server else key
        has_env = bool(active[key].get("env"))
        table.add_row(label, "✅ Active", "Yes" if has_env else "No")

    console.print(table)
    console.print(f"\n[dim]Config: {config_path}[/dim]")


# ── create ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("name")
@click.option("--output-dir", default="", help="Directory to save the server file (default: ~/.mcp-everything/servers/)")
def create(name: str, output_dir: str):
    """Scaffold a new custom MCP server from a template.

    NAME: Identifier for your server (e.g. jira, slack-custom, my-api).
    Creates a ready-to-edit Python file and adds it to Claude Desktop config.
    """
    import re
    from pathlib import Path
    from mcp_everything.server_template import TEMPLATE

    # Sanitise name
    safe_name = re.sub(r"[^a-z0-9_]", "_", name.lower().strip())
    if not safe_name:
        console.print("[red]Invalid server name.[/red]")
        raise SystemExit(1)

    # Resolve output directory
    if output_dir:
        out_dir = Path(output_dir).expanduser().resolve()
    else:
        out_dir = Path.home() / ".mcp-everything" / "servers"
    out_dir.mkdir(parents=True, exist_ok=True)

    out_file = out_dir / f"{safe_name}.py"
    if out_file.exists():
        console.print(f"[yellow]⚠  {out_file} already exists.[/yellow]")
        if not click.confirm("Overwrite?", default=False):
            raise SystemExit(0)

    # Write template
    code = TEMPLATE.replace("SERVER_NAME", safe_name)
    out_file.write_text(code, encoding="utf-8")

    # Register in Claude Desktop config
    config_path = get_claude_config_path()
    if config_path:
        config = load_config(config_path)
        import sys
        config.setdefault("mcpServers", {})[safe_name] = {
            "command": sys.executable,
            "args": [str(out_file)],
        }
        save_config(config_path, config)
        config_msg = f"[green]✓[/green] Registered in Claude Desktop config"
    else:
        config_msg = "[yellow]⚠  Could not find Claude Desktop config — add it manually[/yellow]"

    console.print(
        Panel(
            f"[bold green]✅ Custom server created![/bold green]\n\n"
            f"[bold]File:[/bold] {out_file}\n"
            f"{config_msg}\n\n"
            f"[bold]Next steps:[/bold]\n"
            f"  1. Open the file and replace the TODO sections with your real API logic\n"
            f"  2. Restart Claude Desktop\n"
            f"  3. Ask Claude to use your new [bold cyan]{safe_name}[/bold cyan] server",
            title=f"[bold cyan]{safe_name}[/bold cyan] server scaffolded",
            border_style="cyan",
        )
    )


# ── doctor ────────────────────────────────────────────────────────────────────

@main.command()
def doctor():
    """Diagnose your mcp-everything setup — check config, keys, and imports."""
    import sys
    import importlib
    import os
    from pathlib import Path

    _print_banner()
    console.print("[bold]Running diagnostics...[/bold]\n")

    all_ok = True

    def ok(msg: str):
        console.print(f"[green]✅[/green] {msg}")

    def warn(msg: str):
        nonlocal all_ok
        all_ok = False
        console.print(f"[yellow]⚠ [/yellow] {msg}")

    def fail(msg: str):
        nonlocal all_ok
        all_ok = False
        console.print(f"[red]❌[/red] {msg}")

    # Python version
    major, minor = sys.version_info[:2]
    if (major, minor) >= (3, 10):
        ok(f"Python {major}.{minor} (3.10+ required)")
    else:
        fail(f"Python {major}.{minor} — mcp-everything requires Python 3.10+")

    # mcp package
    try:
        import mcp
        ok(f"mcp package installed ({getattr(mcp, '__version__', 'unknown version')})")
    except ImportError:
        fail("mcp package not found — run: pip install mcp")

    # httpx
    try:
        import httpx
        ok(f"httpx installed ({httpx.__version__})")
    except ImportError:
        fail("httpx not found — run: pip install httpx")

    # Claude Desktop config
    config_path = get_claude_config_path()
    if config_path is None:
        fail("Could not determine Claude Desktop config path (unsupported OS?)")
    elif not config_path.exists():
        warn(f"Claude Desktop config not found at {config_path}\n"
             "  → Is Claude Desktop installed? Run `mcp-everything setup` to create the config.")
    else:
        ok(f"Claude Desktop config found: {config_path}")

        # Valid JSON?
        try:
            config = load_config(config_path)
            ok("Config file is valid JSON")
        except Exception as e:
            fail(f"Config file has invalid JSON: {e}")
            config = {}

        # Which servers are active?
        active = config.get("mcpServers", {})
        our_keys = {s["key"] for s in SERVERS}
        active_ours = {k: v for k, v in active.items() if k in our_keys}
        custom = {k: v for k, v in active.items() if k not in our_keys}

        if not active_ours and not custom:
            warn("No MCP servers configured yet. Run `mcp-everything setup` to add some.")
        else:
            ok(f"{len(active_ours)} built-in + {len(custom)} custom server(s) configured")

        # Check API keys for active servers that need them
        console.print()
        console.print("[bold]API key checks for active servers:[/bold]")
        for server in SERVERS:
            if server["key"] not in active_ours:
                continue
            for var in server.get("env_vars", []):
                env_name = var["name"]
                val = (active_ours[server["key"]].get("env") or {}).get(env_name) or os.environ.get(env_name, "")
                if val:
                    ok(f"  {server['label']}: {env_name} is set")
                elif var.get("required"):
                    fail(f"  {server['label']}: {env_name} is MISSING — server will error on use")
                else:
                    warn(f"  {server['label']}: {env_name} not set (optional — limited functionality)")

    # Import check for all built-in servers
    console.print()
    console.print("[bold]Server import checks:[/bold]")
    for server in SERVERS:
        mod_name = f"mcp_everything.servers.{server['module']}"
        try:
            importlib.import_module(mod_name)
            ok(f"  {server['label']} importable")
        except Exception as e:
            fail(f"  {server['label']}: import failed — {e}")

    console.print()
    if all_ok:
        console.print(Panel("[bold green]All checks passed! ✨[/bold green]\nRestart Claude Desktop if you made any recent changes.", border_style="green"))
    else:
        console.print(Panel("[yellow]Some issues found above.[/yellow]\nFix them and re-run [bold]mcp-everything doctor[/bold].", border_style="yellow"))


# ── update ────────────────────────────────────────────────────────────────────

@main.command()
def update():
    """Check PyPI for a newer version of mcp-everything and show the upgrade command."""
    import urllib.request
    import json as _json

    from mcp_everything import __version__

    console.print(f"[dim]Current version: {__version__}[/dim]")
    console.print("Checking PyPI for updates...")

    try:
        with urllib.request.urlopen("https://pypi.org/pypi/mcp-everything/json", timeout=8) as resp:
            data = _json.loads(resp.read())
        latest = data["info"]["version"]
    except Exception as e:
        console.print(f"[red]Could not reach PyPI: {e}[/red]")
        raise SystemExit(1)

    from packaging.version import Version
    try:
        current_v = Version(__version__)
        latest_v = Version(latest)
    except Exception:
        current_v = latest_v = None

    if latest_v and latest_v > current_v:
        console.print(
            Panel(
                f"[bold yellow]Update available![/bold yellow]\n\n"
                f"  Current: [red]{__version__}[/red]\n"
                f"  Latest:  [green]{latest}[/green]\n\n"
                f"Run this to upgrade:\n"
                f"  [bold cyan]pip install --upgrade mcp-everything[/bold cyan]",
                border_style="yellow",
            )
        )
    else:
        console.print(
            Panel(
                f"[bold green]You're up to date![/bold green]\n"
                f"  Installed: [green]{__version__}[/green]  |  Latest: {latest}",
                border_style="green",
            )
        )


# ── test ──────────────────────────────────────────────────────────────────────

@main.command(name="test")
@click.argument("server_key", default="")
@click.option("--all", "run_all", is_flag=True, default=False, help="Test all known servers")
def test_cmd(server_key: str, run_all: bool):
    """Live-test MCP server API connectivity.

    SERVER_KEY: Server to test (e.g. hackernews, crypto). Omit to test all configured servers.
    """
    import asyncio
    from mcp_everything.server_tests import SERVER_TESTS, run_test

    config_path = get_claude_config_path()
    active_keys: list[str] = []

    if server_key:
        active_keys = [server_key]
    elif run_all:
        active_keys = list(SERVER_TESTS.keys())
    else:
        # Default: test all configured servers
        if config_path and config_path.exists():
            config = load_config(config_path)
            active_keys = [k for k in config.get("mcpServers", {}) if k in SERVER_TESTS]
        if not active_keys:
            console.print("[yellow]No configured servers found.[/yellow] Run [bold]mcp-everything setup[/bold] first, or use --all to test everything.")
            raise SystemExit(0)

    unknown = [k for k in active_keys if k not in SERVER_TESTS]
    if unknown:
        console.print(f"[yellow]No test defined for: {', '.join(unknown)}[/yellow]")
        active_keys = [k for k in active_keys if k in SERVER_TESTS]
    if not active_keys:
        raise SystemExit(1)

    console.print(f"\n[bold]Testing {len(active_keys)} server(s)...[/bold]\n")

    table = Table(box=box.ROUNDED, header_style="bold cyan", show_lines=True)
    table.add_column("Server", style="bold", min_width=16)
    table.add_column("Result", min_width=10)
    table.add_column("Details", min_width=40)
    table.add_column("Time", justify="right", min_width=6)

    async def run_all_tests():
        results = []
        for key in active_keys:
            passed, message, elapsed = await run_test(key)
            results.append((key, passed, message, elapsed))
        return results

    results = asyncio.run(run_all_tests())

    passed_count = 0
    for key, passed, message, elapsed in results:
        server = _get_server_by_key(key)
        label = server["label"] if server else key
        if passed:
            passed_count += 1
            status = "[green]✅ PASS[/green]"
            detail = f"[dim]{message[:70]}[/dim]"
        else:
            status = "[red]❌ FAIL[/red]"
            detail = f"[red]{message[:70]}[/red]"
        table.add_row(label, status, detail, f"{elapsed:.2f}s")

    console.print(table)
    console.print(
        f"\n[bold]{'[green]' if passed_count == len(results) else '[yellow]'}"
        f"{passed_count}/{len(results)} passed[/bold]"
        + ("[/green]" if passed_count == len(results) else "[/yellow]")
    )


# ── serve ─────────────────────────────────────────────────────────────────────

@main.command()
@click.option("--port", default=7337, help="Port to listen on (default: 7337)")
@click.option("--no-browser", is_flag=True, default=False, help="Don't open browser automatically")
def serve(port: int, no_browser: bool):
    """Open a web dashboard to manage servers, enter API keys, and run tests.

    Starts a local server at http://localhost:7337 and opens your browser.
    Much friendlier than the terminal wizard — great for non-developers.
    """
    from mcp_everything.serve import run_server
    run_server(port=port, open_browser=not no_browser)


# ── export ────────────────────────────────────────────────────────────────────

@main.command(name="export")
@click.option("--output", "-o", default="", help="File path to write to (default: stdout)")
def export_config(output: str):
    """Export your current mcp-everything server configuration as a shareable JSON file.

    The exported file lists which servers are enabled. API keys are NOT included.
    Share this file with your team or post it online — others can import it directly.
    """
    config_path = get_claude_config_path()
    if not config_path or not config_path.exists():
        console.print("[red]No Claude Desktop config found.[/red]")
        raise SystemExit(1)

    config = load_config(config_path)
    mcp_servers = config.get("mcpServers", {})
    our_keys = {s["key"] for s in SERVERS}

    export_data = {
        "mcp_everything_version": "0.4.0",
        "enabled_servers": [k for k in mcp_servers if k in our_keys],
        "custom_servers": {
            k: v for k, v in mcp_servers.items()
            if k not in our_keys
        },
    }

    output_str = json.dumps(export_data, indent=2)

    if output:
        from pathlib import Path
        Path(output).write_text(output_str, encoding="utf-8")
        console.print(f"[green]✅ Config exported to {output}[/green]")
    else:
        console.print(output_str)


# ── import ────────────────────────────────────────────────────────────────────

@main.command(name="import")
@click.argument("file_path")
@click.option("--merge", is_flag=True, default=True, help="Merge with existing servers (default: True)")
def import_config(file_path: str, merge: bool):
    """Import a shared mcp-everything configuration file.

    FILE_PATH: Path to a JSON file exported with `mcp-everything export`.
    Enables all the servers listed in the file, prompting for any missing API keys.
    """
    import json as _json
    from pathlib import Path

    src = Path(file_path).expanduser().resolve()
    if not src.exists():
        console.print(f"[red]File not found: {src}[/red]")
        raise SystemExit(1)

    try:
        data = _json.loads(src.read_text(encoding="utf-8"))
    except _json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON: {e}[/red]")
        raise SystemExit(1)

    enabled_keys = data.get("enabled_servers", [])
    custom = data.get("custom_servers", {})

    if not enabled_keys and not custom:
        console.print("[yellow]Nothing to import.[/yellow]")
        raise SystemExit(0)

    console.print(f"\n[bold]Importing:[/bold] {', '.join(enabled_keys) or 'none'}")
    if custom:
        console.print(f"[bold]Custom servers:[/bold] {', '.join(custom.keys())}")

    config_path = get_claude_config_path()
    if not config_path:
        console.print("[red]Claude Desktop config not found.[/red]")
        raise SystemExit(1)

    config = load_config(config_path)
    mcp_servers = config.setdefault("mcpServers", {})

    added = []
    for key in enabled_keys:
        server = _get_server_by_key(key)
        if not server:
            console.print(f"[yellow]Unknown server '{key}' — skipping[/yellow]")
            continue

        if server["needs_key"]:
            console.print(f"\n[bold cyan]{server['label']}[/bold cyan] requires an API key.")
            env = _collect_env(server)
            if not env and any(v["required"] for v in server["env_vars"]):
                console.print(f"[yellow]Skipping {server['label']} (no key provided)[/yellow]")
                continue
        else:
            env = {}

        if server.get("server_type") == "url":
            mcp_servers[key] = build_server_entry(url=server["url"], env_vars=env or None)
        else:
            mcp_servers[key] = build_server_entry(server["module"], env or None)
        added.append(key)

    # Import custom servers as-is
    for key, entry in custom.items():
        mcp_servers[key] = entry
        added.append(key)

    save_config(config_path, config)
    console.print(
        Panel(
            f"[green bold]✅ Imported {len(added)} server(s)[/green bold]\n"
            + "\n".join(f"  • {k}" for k in added)
            + "\n\n[bold]Restart Claude Desktop[/bold] to apply.",
            border_style="green",
        )
    )


if __name__ == "__main__":
    main()
