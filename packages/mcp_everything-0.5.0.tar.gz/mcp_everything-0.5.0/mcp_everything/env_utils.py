"""
Shared .env file support for mcp-everything servers.

All servers that need API keys call load_mcp_env() at startup.
Keys are read from ~/.mcp-everything/.env, falling back to environment variables.
This means users can store keys once, in one place, rather than in claude_desktop_config.json.
"""

import os
from pathlib import Path

MCP_DIR = Path.home() / ".mcp-everything"
MCP_ENV_FILE = MCP_DIR / ".env"


def load_mcp_env() -> None:
    """Load API keys from ~/.mcp-everything/.env into the environment.
    Safe to call multiple times — won't overwrite existing env vars.
    """
    if not MCP_ENV_FILE.exists():
        return
    try:
        from dotenv import load_dotenv
        load_dotenv(MCP_ENV_FILE, override=False)
    except ImportError:
        # Manual fallback if python-dotenv isn't available
        _parse_env_file(MCP_ENV_FILE)


def _parse_env_file(path: Path) -> None:
    """Minimal .env parser — handles KEY=value and KEY="value" lines."""
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def write_env_key(key: str, value: str) -> None:
    """Write or update a single key in ~/.mcp-everything/.env."""
    MCP_DIR.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    found = False

    if MCP_ENV_FILE.exists():
        for line in MCP_ENV_FILE.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith(f"{key}=") or stripped.startswith(f"{key} ="):
                lines.append(f'{key}="{value}"')
                found = True
            else:
                lines.append(line)

    if not found:
        lines.append(f'{key}="{value}"')

    MCP_ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_env_keys(keys: list[str]) -> dict[str, str]:
    """Read specific keys from ~/.mcp-everything/.env (without polluting os.environ)."""
    result: dict[str, str] = {}
    if not MCP_ENV_FILE.exists():
        return result
    for line in MCP_ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        if k in keys:
            result[k] = v.strip().strip('"').strip("'")
    return result


def get_env_file_path() -> Path:
    return MCP_ENV_FILE
