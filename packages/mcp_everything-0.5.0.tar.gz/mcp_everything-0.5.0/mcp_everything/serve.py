"""
mcp-everything serve — localhost web dashboard for managing MCP servers.
Opens a beautiful UI at http://localhost:7337 to toggle servers, enter API keys,
run live tests, and save your Claude Desktop config — no terminal needed.
"""

from __future__ import annotations
import asyncio
import json
import os
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from mcp_everything.config import (
    SERVERS, build_server_entry, get_claude_config_path,
    load_config, save_config,
)
from mcp_everything.env_utils import (
    MCP_ENV_FILE, get_env_file_path, read_env_keys, write_env_key,
)
from mcp_everything import __version__

PORT = 7337

# ── HTML dashboard ─────────────────────────────────────────────────────────────

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>mcp-everything</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
  body { background: #0f172a; color: #e2e8f0; font-family: 'Inter', system-ui, sans-serif; }
  .toggle-bg { transition: background 0.2s; }
  .toggle-dot { transition: transform 0.2s; }
  input[type=checkbox]:checked + .toggle-bg { background: #6366f1; }
  input[type=checkbox]:checked + .toggle-bg .toggle-dot { transform: translateX(1.25rem); }
  .key-input { background: #1e293b; border: 1px solid #334155; color: #e2e8f0; }
  .key-input:focus { outline: none; border-color: #6366f1; box-shadow: 0 0 0 2px rgba(99,102,241,0.2); }
  .card { background: #1e293b; border: 1px solid #334155; transition: border-color 0.15s; }
  .card:hover { border-color: #475569; }
  .card.active { border-color: #6366f1; }
  .badge-free { background: #064e3b; color: #6ee7b7; }
  .badge-key  { background: #312e81; color: #a5b4fc; }
  .status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
  .status-pass { background: #22c55e; }
  .status-fail { background: #ef4444; }
  .status-idle { background: #475569; }
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: #0f172a; }
  ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
  .fade-in { animation: fadeIn 0.3s ease; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }
</style>
</head>
<body class="min-h-screen p-6">

<div class="max-w-4xl mx-auto">

  <!-- Header -->
  <div class="flex items-center justify-between mb-8">
    <div>
      <h1 class="text-2xl font-bold text-white flex items-center gap-2">
        <span class="text-indigo-400">⚡</span> mcp-everything
        <span class="text-sm font-normal text-slate-500 ml-2">v__VERSION__</span>
      </h1>
      <p class="text-slate-400 text-sm mt-1">Toggle servers, enter API keys, save to Claude Desktop</p>
    </div>
    <div class="flex gap-3">
      <button onclick="runAllTests()" class="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-sm font-medium transition-colors">
        🧪 Test All
      </button>
      <button onclick="saveConfig()" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-semibold transition-colors">
        💾 Save & Restart
      </button>
    </div>
  </div>

  <!-- Keys file notice -->
  <div class="mb-6 px-4 py-3 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-400 flex items-center gap-2">
    <span>🔒</span>
    <span>API keys are saved to <code class="text-indigo-300">~/.mcp-everything/.env</code> — not inside your Claude config file.</span>
  </div>

  <!-- Save status toast -->
  <div id="toast" class="hidden fixed bottom-6 right-6 px-5 py-3 rounded-xl text-sm font-medium shadow-lg fade-in z-50"></div>

  <!-- Server cards -->
  <div id="server-list" class="space-y-3"></div>

  <p class="text-center text-slate-600 text-xs mt-8">
    Restart Claude Desktop after saving •
    <a href="https://github.com/Wellix260/mcp-everything" class="text-indigo-500 hover:text-indigo-400">GitHub</a>
  </p>
</div>

<script>
let state = { servers: {}, envKeys: {} };

async function loadState() {
  const r = await fetch('/api/state');
  state = await r.json();
  renderServers();
}

function renderServers() {
  const list = document.getElementById('server-list');
  list.innerHTML = '';

  const freeServers = state.servers.filter(s => !s.needs_key);
  const keyServers  = state.servers.filter(s => s.needs_key);

  if (freeServers.length) {
    list.appendChild(sectionHeader('✅ Free servers — no API key needed'));
    freeServers.forEach(s => list.appendChild(makeCard(s)));
  }
  if (keyServers.length) {
    list.appendChild(sectionHeader('🔑 API key servers — free keys available'));
    keyServers.forEach(s => list.appendChild(makeCard(s)));
  }
}

function sectionHeader(text) {
  const el = document.createElement('div');
  el.className = 'text-xs font-semibold text-slate-500 uppercase tracking-wider mt-6 mb-2 px-1';
  el.textContent = text;
  return el;
}

function makeCard(server) {
  const enabled = state.active[server.key] !== undefined;
  const card = document.createElement('div');
  card.className = `card rounded-xl p-4 ${enabled ? 'active' : ''}`;
  card.id = `card-${server.key}`;

  const badge = server.needs_key
    ? `<span class="badge-key text-xs px-2 py-0.5 rounded-full font-medium">🔑 API key</span>`
    : `<span class="badge-free text-xs px-2 py-0.5 rounded-full font-medium">✅ Free</span>`;

  const testBtn = `<button onclick="testServer('${server.key}')"
    class="test-btn-${server.key} text-xs px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 transition-colors ml-2">Test</button>`;

  const statusDot = `<span id="status-${server.key}" class="status-dot status-idle ml-2" title="Not tested"></span>`;

  let keyFields = '';
  if (server.needs_key && server.env_vars) {
    keyFields = server.env_vars.map(v => {
      const val = state.envKeys[v.name] || '';
      const req = v.required ? '<span class="text-red-400">*</span>' : '<span class="text-slate-500">(optional)</span>';
      return `
        <div class="mt-3">
          <label class="text-xs text-slate-400 block mb-1">${v.prompt} ${req}</label>
          <div class="flex gap-2">
            <input type="password" id="key-${v.name}" value="${val}"
              placeholder="${v.hint}"
              class="key-input flex-1 text-sm px-3 py-2 rounded-lg font-mono"
              oninput="markDirty()">
            <button onclick="toggleShow('${v.name}')"
              class="text-xs px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 transition-colors">Show</button>
            <a href="${getKeyUrl(v.name)}" target="_blank"
              class="text-xs px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 transition-colors no-underline text-slate-300">Get key ↗</a>
          </div>
          <p class="text-xs text-slate-600 mt-1">${v.hint}</p>
        </div>`;
    }).join('');
  }

  card.innerHTML = `
    <div class="flex items-start justify-between">
      <div class="flex items-center gap-3 flex-1">
        <label class="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" class="sr-only" id="toggle-${server.key}"
            ${enabled ? 'checked' : ''} onchange="toggleServer('${server.key}', this.checked)">
          <div class="toggle-bg w-10 h-6 rounded-full bg-slate-600 relative">
            <div class="toggle-dot absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow"></div>
          </div>
        </label>
        <div>
          <div class="flex items-center gap-2">
            <span class="font-semibold text-white text-sm">${server.label}</span>
            ${badge}
            ${statusDot}
          </div>
          <p class="text-xs text-slate-400 mt-0.5">${server.description}</p>
        </div>
      </div>
      <div class="flex items-center">
        ${testBtn}
      </div>
    </div>
    ${keyFields}`;

  return card;
}

function getKeyUrl(varName) {
  const urls = {
    GITHUB_TOKEN: 'https://github.com/settings/tokens',
    NEWS_API_KEY: 'https://newsapi.org/register',
    NASA_API_KEY: 'https://api.nasa.gov',
    TMDB_API_KEY: 'https://www.themoviedb.org/settings/api',
    YOUTUBE_API_KEY: 'https://console.cloud.google.com',
  };
  return urls[varName] || '#';
}

function toggleShow(varName) {
  const input = document.getElementById(`key-${varName}`);
  input.type = input.type === 'password' ? 'text' : 'password';
}

function toggleServer(key, enabled) {
  const card = document.getElementById(`card-${key}`);
  if (enabled) {
    state.active[key] = true;
    card.classList.add('active');
  } else {
    delete state.active[key];
    card.classList.remove('active');
  }
  markDirty();
}

let dirty = false;
function markDirty() { dirty = true; }

async function saveConfig() {
  // Collect current toggle state and key values
  const enabled = {};
  const keys = {};

  state.servers.forEach(server => {
    const toggle = document.getElementById(`toggle-${server.key}`);
    if (toggle && toggle.checked) {
      enabled[server.key] = true;
    }
    if (server.env_vars) {
      server.env_vars.forEach(v => {
        const input = document.getElementById(`key-${v.name}`);
        if (input && input.value.trim()) {
          keys[v.name] = input.value.trim();
        }
      });
    }
  });

  const r = await fetch('/api/save', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ enabled, keys }),
  });
  const result = await r.json();

  if (result.ok) {
    showToast('✅ Saved! Restart Claude Desktop to apply changes.', 'bg-green-700');
    dirty = false;
    await loadState();
  } else {
    showToast('❌ Save failed: ' + result.error, 'bg-red-700');
  }
}

async function testServer(key) {
  const dot = document.getElementById(`status-${key}`);
  dot.className = 'status-dot bg-yellow-400 ml-2';
  dot.title = 'Testing...';

  const r = await fetch(`/api/test/${key}`);
  const result = await r.json();

  if (result.passed) {
    dot.className = 'status-dot status-pass ml-2';
    dot.title = result.message;
    showToast(`✅ ${key}: ${result.message.slice(0, 60)}`, 'bg-green-700');
  } else {
    dot.className = 'status-dot status-fail ml-2';
    dot.title = result.message;
    showToast(`❌ ${key}: ${result.message.slice(0, 60)}`, 'bg-red-800');
  }
}

async function runAllTests() {
  for (const server of state.servers) {
    await testServer(server.key);
    await new Promise(r => setTimeout(r, 150));
  }
}

function showToast(msg, bgClass) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `fixed bottom-6 right-6 px-5 py-3 rounded-xl text-sm font-medium shadow-lg fade-in z-50 text-white ${bgClass}`;
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => { toast.className = 'hidden'; }, 4000);
}

window.addEventListener('beforeunload', e => {
  if (dirty) { e.preventDefault(); e.returnValue = ''; }
});

loadState();
</script>
</body>
</html>"""


# ── HTTP handler ───────────────────────────────────────────────────────────────

class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # suppress access logs

    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/":
            html = DASHBOARD_HTML.replace("__VERSION__", __version__)
            body = html.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        elif path == "/api/state":
            config_path = get_claude_config_path()
            config = load_config(config_path) if config_path and config_path.exists() else {}
            active = config.get("mcpServers", {})

            # Collect all env var names
            all_var_names = [v["name"] for s in SERVERS for v in s.get("env_vars", [])]
            env_keys = read_env_keys(all_var_names)

            self._send_json({
                "servers": SERVERS,
                "active": active,
                "envKeys": env_keys,
                "configPath": str(config_path) if config_path else None,
                "envFile": str(get_env_file_path()),
            })

        elif path.startswith("/api/test/"):
            key = path.split("/api/test/", 1)[-1]
            from mcp_everything.server_tests import SERVER_TESTS, run_test
            if key not in SERVER_TESTS:
                self._send_json({"passed": False, "message": f"No test for '{key}'"})
                return
            passed, message, elapsed = asyncio.run(run_test(key))
            self._send_json({"passed": passed, "message": message, "elapsed": round(elapsed, 2)})

        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/api/save":
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length))
            try:
                _save_config(body)
                self._send_json({"ok": True})
            except Exception as e:
                self._send_json({"ok": False, "error": str(e)}, 500)
        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


def _save_config(body: dict):
    """Apply enabled/disabled servers and write env keys to disk."""
    enabled: dict = body.get("enabled", {})
    keys: dict = body.get("keys", {})

    # Write API keys to ~/.mcp-everything/.env
    for var_name, value in keys.items():
        if value:
            write_env_key(var_name, value)

    # Update Claude Desktop config
    config_path = get_claude_config_path()
    if not config_path:
        raise RuntimeError("Claude Desktop config path not found")

    config = load_config(config_path)
    mcp_servers = config.setdefault("mcpServers", {})

    # Remove our servers that are now disabled
    our_keys = {s["key"] for s in SERVERS}
    for key in list(mcp_servers.keys()):
        if key in our_keys and key not in enabled:
            del mcp_servers[key]

    # Add/update enabled servers
    for server in SERVERS:
        if server["key"] not in enabled:
            continue
        # env vars are now in the .env file — don't store them in the config
        mcp_servers[server["key"]] = build_server_entry(server["module"])

    save_config(config_path, config)


# ── Entry point ────────────────────────────────────────────────────────────────

def run_server(port: int = PORT, open_browser: bool = True):
    server = HTTPServer(("127.0.0.1", port), DashboardHandler)
    url = f"http://localhost:{port}"

    if open_browser:
        threading.Timer(0.5, webbrowser.open, args=[url]).start()

    print(f"\n  ⚡ mcp-everything dashboard → {url}")
    print("  Press Ctrl+C to stop\n")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Dashboard stopped.")
        server.server_close()
