"""Guard the SessionStart hook against a silent rename break.

Background: the BeagleLathe plugin previously shipped a hook whose
`ToolSearch select:` query referenced `mcp__plugin_beagle_beaglelathe__*`
while the actual MCP server registered tools under
`mcp__plugin_lathe_lathe__*` (after the plugin/server were renamed).
The model's first ToolSearch call returned "No matching deferred tools
found", silently fell back to the built-in tools, and the savings meter
under-counted. The bug shipped because nothing wired the hook text to
the plugin manifest.

This test reads plugin.json, derives the prefix Claude Code will actually
register the MCP tools under, and asserts every mcp__plugin_*__* token in
scripts/session-start.sh uses that prefix. Any future rename that updates
plugin.json but forgets the hook fails CI before the wheel ships.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
PLUGIN_JSON = REPO_ROOT / ".claude-plugin" / "plugin.json"
HOOK_SCRIPT = REPO_ROOT / "scripts" / "session-start.sh"

CORE_TOOLS = ("search", "read", "edit", "sh")
PREFIX_TOKEN_RE = re.compile(
    r"mcp__plugin_([A-Za-z0-9]+)_([A-Za-z0-9]+)__([A-Za-z0-9_]+)"
)


def _expected_prefixes() -> list[str]:
    manifest = json.loads(PLUGIN_JSON.read_text())
    plugin_name = manifest["name"]
    server_names = list(manifest["mcpServers"].keys())
    assert server_names, "plugin.json declares no mcpServers"
    return [f"mcp__plugin_{plugin_name}_{server}__" for server in server_names]


def test_hook_prefixes_match_plugin_manifest():
    expected = _expected_prefixes()
    hook_text = HOOK_SCRIPT.read_text()
    found = PREFIX_TOKEN_RE.findall(hook_text)
    assert found, f"no mcp__plugin_*__* tokens found in {HOOK_SCRIPT}"

    bad: list[str] = []
    for plugin, server, tool in found:
        token = f"mcp__plugin_{plugin}_{server}__{tool}"
        prefix = f"mcp__plugin_{plugin}_{server}__"
        if prefix not in expected:
            bad.append(token)

    assert not bad, (
        f"{HOOK_SCRIPT.name} references tool prefixes not registered by the "
        f"MCP server. Expected one of {expected}; found stale tokens: "
        f"{sorted(set(bad))}. Update the hook to match plugin.json."
    )


@pytest.mark.parametrize("tool", CORE_TOOLS)
def test_hook_references_each_core_tool(tool: str):
    expected = _expected_prefixes()
    hook_text = HOOK_SCRIPT.read_text()
    candidates = [f"{prefix}{tool}" for prefix in expected]
    assert any(c in hook_text for c in candidates), (
        f"session-start.sh does not mention any of {candidates}; the model "
        f"won't be told to prefer the BeagleLathe {tool!r} tool over its "
        f"built-in counterpart."
    )


def test_toolsearch_preload_query_present():
    """The hook must include a `ToolSearch ... select:...` line that loads
    every core tool in one call. Without it the model has to guess the names."""
    hook_text = HOOK_SCRIPT.read_text()
    match = re.search(r"ToolSearch[^\n]*select:([^\"\n]+)", hook_text)
    assert match, "session-start.sh is missing the ToolSearch select: preload line"
    selected = match.group(1)
    expected = _expected_prefixes()
    for tool in CORE_TOOLS:
        candidates = [f"{prefix}{tool}" for prefix in expected]
        assert any(c in selected for c in candidates), (
            f"ToolSearch preload query is missing {tool!r}: {selected!r}"
        )
