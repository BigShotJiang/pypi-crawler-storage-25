"""Tests for the language registry — language_for_path() and LanguageConfig shape.

test_ast_engine.py covers the truncation behavior; this file pins the
extension-to-language mapping and the LanguageConfig dataclass contract so
'we forgot to register .pyx' or 'the .Tsx upcased extension stopped resolving'
regressions show up with a finger pointed at the right file.
"""

from __future__ import annotations

import pytest

from beaglelathe.ast import LANGUAGES, language_for_path
from beaglelathe.ast.handlers._base import LanguageHandler
from beaglelathe.ast.handlers.tsx import TSXHandler


# ── language_for_path() across every registered extension ────────────────────


@pytest.mark.parametrize(
    "path,expected",
    [
        ("foo.py", "python"),
        ("foo.ts", "typescript"),
        ("foo.tsx", "tsx"),
        ("a/b/c.py", "python"),
        ("src/utils/helpers.ts", "typescript"),
        ("components/Counter.tsx", "tsx"),
    ],
)
def test_language_for_path_known_extensions(path, expected):
    assert language_for_path(path) == expected


def test_every_registered_extension_resolves_back_to_its_language():
    """Round-trip: each extension declared in a LanguageConfig must resolve to
    the same language name. Prevents a registry edit from silently dropping
    extensions."""

    for name, config in LANGUAGES.items():
        for ext in config.extensions:
            sample = f"sample{ext}"
            assert language_for_path(sample) == name, (
                f"extension {ext!r} did not resolve back to {name!r}"
            )


@pytest.mark.parametrize(
    "path",
    [
        "foo.txt",
        "README",
        "Makefile",
        "foo.unknown",
        "foo.md",
        "foo.json",
        "foo",  # no extension at all
        "",     # empty path
    ],
)
def test_language_for_path_unknown_returns_none(path):
    assert language_for_path(path) is None


# ── Case sensitivity ─────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "path,expected",
    [
        ("foo.PY", "python"),
        ("foo.Py", "python"),
        ("Component.TSX", "tsx"),
        ("Component.Tsx", "tsx"),
        ("file.TS", "typescript"),
        ("file.Ts", "typescript"),
    ],
)
def test_language_for_path_extension_is_case_insensitive(path, expected):
    assert language_for_path(path) == expected


def test_language_for_path_directory_case_does_not_affect_match():
    """Whether the directory portion is upper- or lower-case must not matter —
    only the suffix counts."""

    assert language_for_path("/Some/PATH/Mixed/file.py") == "python"
    assert language_for_path("/some/PATH/Mixed/file.PY") == "python"


# ── Paths with dots in directory names ───────────────────────────────────────


@pytest.mark.parametrize(
    "path,expected",
    [
        ("my.config/foo.py", "python"),
        ("project.v2/src/foo.ts", "typescript"),
        ("a.b.c/d.tsx", "tsx"),
        ("dot.in.dir/another.dot/file.py", "python"),
        ("./relative.dir/foo.py", "python"),
        ("/abs/dotted.dir.name/foo.tsx", "tsx"),
        # Hidden files — `.foo.py` resolves via the .py suffix.
        (".hidden.py", "python"),
    ],
)
def test_language_for_path_handles_dots_in_directories(path, expected):
    assert language_for_path(path) == expected


def test_dotfile_with_no_suffix_returns_none():
    """`.foorc` has suffix `.foorc` which isn't registered. Pin the behavior."""

    assert language_for_path(".bashrc") is None
    assert language_for_path(".eslintrc") is None


def test_double_extension_uses_last_suffix():
    """`foo.test.ts` — `.ts` is the suffix that wins, not `.test`."""

    assert language_for_path("foo.test.ts") == "typescript"
    assert language_for_path("Component.test.tsx") == "tsx"
    assert language_for_path("module.spec.py") == "python"


def test_extension_without_dot_returns_none():
    """A trailing component without a dot is not an extension."""

    assert language_for_path("foo/py") is None  # `py` is a directory name


# ── LanguageConfig dataclass contract ────────────────────────────────────────


def test_language_config_is_frozen():
    """frozen=True so the registry can't be mutated by accident."""

    cfg = LANGUAGES["python"]
    with pytest.raises(Exception):
        cfg.name = "different"  # type: ignore[misc]


def test_every_language_has_required_fields():
    for name, cfg in LANGUAGES.items():
        assert cfg.name == name
        assert isinstance(cfg.extensions, tuple) and len(cfg.extensions) >= 1
        assert all(e.startswith(".") for e in cfg.extensions), (
            f"{name}: extensions must include the leading dot"
        )
        assert cfg.tags_query_path.endswith(".scm")
        assert isinstance(cfg.body_field_name, str)
        assert isinstance(cfg.function_capture_names, tuple)
        assert isinstance(cfg.class_capture_names, tuple)
        assert isinstance(cfg.import_capture_names, tuple)
        assert isinstance(cfg.constant_capture_names, tuple)


def test_language_config_handler_either_none_or_handler_subclass():
    for name, cfg in LANGUAGES.items():
        if cfg.handler is not None:
            assert issubclass(cfg.handler, LanguageHandler), (
                f"{name}: handler must subclass LanguageHandler"
            )


def test_tsx_has_a_dedicated_handler():
    """TSX needs the tsx grammar — the registry must wire TSXHandler in."""

    assert LANGUAGES["tsx"].handler is TSXHandler


def test_python_and_typescript_use_generic_engine_no_handler():
    """The generic engine in truncate.py handles these; pinning the absence
    of a handler keeps us from accidentally adding one for no reason."""

    assert LANGUAGES["python"].handler is None
    assert LANGUAGES["typescript"].handler is None


def test_tags_query_files_exist_on_disk():
    """A LanguageConfig pointing at a missing .scm file silently breaks the
    engine. Verify each query file resolves."""

    from pathlib import Path

    for name, cfg in LANGUAGES.items():
        assert Path(cfg.tags_query_path).is_file(), (
            f"{name}: missing query file {cfg.tags_query_path}"
        )


# ── Defensive checks against duplicates ──────────────────────────────────────


def test_no_extension_registered_to_two_languages():
    """One extension → one language. Catching duplicates here is much easier
    than debugging silently-wrong dispatch in production."""

    seen: dict[str, str] = {}
    for name, cfg in LANGUAGES.items():
        for ext in cfg.extensions:
            normalized = ext.lower()
            assert normalized not in seen, (
                f"extension {ext!r} registered to both "
                f"{seen[normalized]!r} and {name!r}"
            )
            seen[normalized] = name
