from pathlib import Path

from beaglelathe.tools.edit import apply_edits


def _write(tmp_path: Path, rel: str, content: str) -> Path:
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


def test_exact_match_single(tmp_path: Path):
    _write(tmp_path, "a.txt", "hello world\n")
    out = apply_edits([{"path": "a.txt", "old_string": "world", "new_string": "there"}], tmp_path)
    assert out["applied"] == 1 and out["failed"] == 0
    assert (tmp_path / "a.txt").read_text() == "hello there\n"
    assert out["results"][0]["match_type"] == "exact"


def test_not_unique_without_replace_all(tmp_path: Path):
    _write(tmp_path, "a.txt", "foo foo\n")
    out = apply_edits([{"path": "a.txt", "old_string": "foo", "new_string": "bar"}], tmp_path)
    assert out["applied"] == 0 and out["failed"] == 1
    assert out["results"][0]["reason"] == "old_string not unique"
    # File untouched.
    assert (tmp_path / "a.txt").read_text() == "foo foo\n"


def test_replace_all(tmp_path: Path):
    _write(tmp_path, "a.txt", "foo foo foo\n")
    out = apply_edits(
        [{"path": "a.txt", "old_string": "foo", "new_string": "bar", "replace_all": True}],
        tmp_path,
    )
    assert out["applied"] == 1
    assert (tmp_path / "a.txt").read_text() == "bar bar bar\n"


def test_atomic_batch_failure_writes_nothing(tmp_path: Path):
    _write(tmp_path, "a.txt", "hello\n")
    _write(tmp_path, "b.txt", "world\n")
    out = apply_edits(
        [
            {"path": "a.txt", "old_string": "hello", "new_string": "HI"},
            {"path": "b.txt", "old_string": "NONEXISTENT", "new_string": "X"},
        ],
        tmp_path,
    )
    assert out["applied"] == 0
    assert (tmp_path / "a.txt").read_text() == "hello\n"
    assert (tmp_path / "b.txt").read_text() == "world\n"


def test_path_outside_workspace(tmp_path: Path):
    out = apply_edits(
        [{"path": "../escape.txt", "old_string": "x", "new_string": "y"}], tmp_path
    )
    assert out["applied"] == 0
    assert any(r.get("reason") == "path outside workspace" for r in out["results"])


def test_normalized_match_smart_quotes(tmp_path: Path):
    _write(tmp_path, "a.txt", "const x = “hello”;\n")
    out = apply_edits(
        [
            {
                "path": "a.txt",
                "old_string": 'const x = "hello";',
                "new_string": 'const x = "world";',
            }
        ],
        tmp_path,
    )
    assert out["applied"] == 1
    assert out["results"][0]["match_type"] == "normalized"
    assert (tmp_path / "a.txt").read_text() == 'const x = "world";\n'


def test_two_edits_same_file_compose(tmp_path: Path):
    _write(tmp_path, "a.txt", "alpha bravo charlie\n")
    out = apply_edits(
        [
            {"path": "a.txt", "old_string": "alpha", "new_string": "AAA"},
            {"path": "a.txt", "old_string": "charlie", "new_string": "CCC"},
        ],
        tmp_path,
    )
    assert out["applied"] == 2
    assert (tmp_path / "a.txt").read_text() == "AAA bravo CCC\n"


def test_noop_edit_fails(tmp_path: Path):
    _write(tmp_path, "a.txt", "hello\n")
    out = apply_edits(
        [{"path": "a.txt", "old_string": "hello", "new_string": "hello"}], tmp_path
    )
    assert out["applied"] == 0
    assert out["results"][0]["reason"] == "no-op edit"


def test_file_not_found(tmp_path: Path):
    out = apply_edits(
        [{"path": "nope.txt", "old_string": "x", "new_string": "y"}], tmp_path
    )
    assert out["applied"] == 0
    assert out["results"][0]["reason"] == "file not found"


def test_validation_ok_python(tmp_path: Path):
    _write(tmp_path, "a.py", "def f():\n    return 1\n")
    out = apply_edits(
        [{"path": "a.py", "old_string": "return 1", "new_string": "return 2"}], tmp_path
    )
    assert out["applied"] == 1
    assert out["results"][0]["validation"] == "ok"


def test_validation_syntax_error_python_warn_only(tmp_path: Path):
    # Edit that breaks syntax. Write still happens; validation reports the error.
    _write(tmp_path, "a.py", "def f():\n    return 1\n")
    out = apply_edits(
        [{"path": "a.py", "old_string": "return 1", "new_string": "return (1"}], tmp_path
    )
    assert out["applied"] == 1
    assert out["results"][0]["validation"] == "syntax_error"
    assert "validation_detail" in out["results"][0]
    # File was still written (warn-only policy).
    assert "return (1" in (tmp_path / "a.py").read_text()


def test_validation_skipped_for_unknown_ext(tmp_path: Path):
    _write(tmp_path, "notes.txt", "hello\n")
    out = apply_edits(
        [{"path": "notes.txt", "old_string": "hello", "new_string": "world"}], tmp_path
    )
    assert out["results"][0]["validation"] == "skipped"


def test_validation_disabled(tmp_path: Path):
    _write(tmp_path, "a.py", "def f():\n    return 1\n")
    out = apply_edits(
        [{"path": "a.py", "old_string": "return 1", "new_string": "return 2"}],
        tmp_path,
        validate=False,
    )
    assert out["applied"] == 1
    assert "validation" not in out["results"][0]
