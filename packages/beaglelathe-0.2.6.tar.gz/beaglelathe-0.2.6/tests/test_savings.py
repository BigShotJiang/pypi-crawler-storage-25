"""Tests for savings.py — local SQLite savings tracker."""

from __future__ import annotations

from pathlib import Path


from beaglelathe.savings import (
    CALLS_SAVED_PER_USE,
    COST_PER_TOKEN_USD,
    TOKENS_PER_VANILLA_CALL,
    compute_savings,
    format_summary,
    record_call,
)


# ── empty state ───────────────────────────────────────────────────────────────

def test_empty_db_zero_summary(tmp_path):
    db = tmp_path / "state.db"
    s = compute_savings(db)
    assert s.total_calls == 0
    assert s.calls_saved == 0
    assert s.tokens_saved == 0
    assert s.cost_saved_usd == 0.0
    assert s.by_tool == {}


# ── record_call + compute_savings ────────────────────────────────────────────

def test_single_search_call(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)
    s = compute_savings(db)
    assert s.total_calls == 1
    assert s.by_tool == {"search": 1}
    assert s.calls_saved == round(CALLS_SAVED_PER_USE["search"])


def test_multiple_search_calls_accumulate(tmp_path):
    db = tmp_path / "state.db"
    for _ in range(5):
        record_call("search", db)
    s = compute_savings(db)
    assert s.total_calls == 5
    assert s.calls_saved == round(5 * CALLS_SAVED_PER_USE["search"])


def test_all_four_tools_recorded(tmp_path):
    db = tmp_path / "state.db"
    for tool in ("search", "edit", "read", "sh"):
        record_call(tool, db)
    s = compute_savings(db)
    assert s.total_calls == 4
    assert set(s.by_tool) == {"search", "edit", "read", "sh"}


def test_calls_saved_math(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)   # saves 2.0
    record_call("edit", db)     # saves 2.0
    record_call("read", db)     # saves 1.0
    record_call("sh", db)       # saves 0.5
    s = compute_savings(db)
    expected = round(2.0 + 2.0 + 1.0 + 0.5)  # 6 (rounds 5.5 → 6)
    assert s.calls_saved == expected


def test_tokens_saved_derived_from_calls_saved_float(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)   # 2.0 calls saved
    s = compute_savings(db)
    # tokens = round(calls_saved_float * TOKENS_PER_VANILLA_CALL)
    assert s.tokens_saved == round(CALLS_SAVED_PER_USE["search"] * TOKENS_PER_VANILLA_CALL)


def test_cost_saved_derived_from_tokens(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)
    s = compute_savings(db)
    expected_cost = round(s.tokens_saved * COST_PER_TOKEN_USD, 4)
    assert s.cost_saved_usd == expected_cost


def test_time_saved_positive(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)
    s = compute_savings(db)
    assert s.time_saved_seconds > 0


def test_unknown_tool_contributes_zero_savings(tmp_path):
    db = tmp_path / "state.db"
    record_call("run_tests", db)   # not in CALLS_SAVED_PER_USE
    s = compute_savings(db)
    assert s.total_calls == 1
    assert s.calls_saved == 0
    assert s.tokens_saved == 0


# ── record_call resilience ───────────────────────────────────────────────────

def test_record_call_swallows_bad_path():
    # Should not raise even for a path that cannot be created
    record_call("search", Path("/nonexistent/definitely/not/here/state.db"))


def test_record_call_creates_directory_on_demand(tmp_path):
    db = tmp_path / "deep" / "nested" / "state.db"
    record_call("edit", db)
    assert db.exists()


# ── format_summary ───────────────────────────────────────────────────────────

def test_format_summary_contains_all_sections(tmp_path):
    db = tmp_path / "state.db"
    record_call("search", db)
    s = compute_savings(db)
    text = format_summary(s)
    assert "total calls" in text
    assert "calls saved" in text
    assert "tokens saved" in text
    assert "cost saved" in text
    assert "time saved" in text
    assert "by tool" in text
    assert "search" in text


def test_format_summary_lists_tool_in_canonical_order(tmp_path):
    db = tmp_path / "state.db"
    for t in ("sh", "read", "edit", "search"):
        record_call(t, db)
    text = format_summary(compute_savings(db))
    # canonical order: search, edit, read, sh
    positions = [text.index(t) for t in ("search", "edit", "read", "sh")]
    assert positions == sorted(positions)


def test_format_summary_unknown_tool_appended(tmp_path):
    db = tmp_path / "state.db"
    record_call("run_tests", db)
    text = format_summary(compute_savings(db))
    assert "run_tests" in text
