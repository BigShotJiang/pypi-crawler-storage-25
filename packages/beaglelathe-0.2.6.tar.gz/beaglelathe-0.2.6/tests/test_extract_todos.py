import shutil
import subprocess
from pathlib import Path

import pytest

from beaglelathe.tools.extract_todos import run_extract_todos


@pytest.fixture
def small_project(tmp_path: Path) -> Path:
    (tmp_path / "a.py").write_text(
        "def f():\n"
        "    # TODO: handle the error case\n"
        "    return 1\n"
    )
    (tmp_path / "b.py").write_text(
        "# FIXME: this needs a real implementation\n"
        "def g():\n"
        "    pass\n"
        "\n"
        "# HACK(alice): temporary workaround\n"
        "def h():\n"
        "    pass\n"
    )
    (tmp_path / "c.txt").write_text("not code, but also contains TODO: ignore me maybe\n")
    return tmp_path


def test_finds_todo_and_fixme(small_project: Path):
    out = run_extract_todos({"include_blame": False}, small_project)
    markers = sorted(t["marker"] for t in out["todos"])
    assert "TODO" in markers
    assert "FIXME" in markers
    assert "HACK" in markers
    assert out["by_marker"]["TODO"] >= 1
    assert out["by_marker"]["FIXME"] == 1
    assert out["by_marker"]["HACK"] == 1


def test_marker_text_extracted(small_project: Path):
    out = run_extract_todos({"include_blame": False}, small_project)
    todo = next(t for t in out["todos"] if t["marker"] == "TODO" and t["file"].endswith("a.py"))
    assert "handle the error case" in todo["text"]
    assert todo["line"] == 2


def test_context_lines(small_project: Path):
    out = run_extract_todos(
        {"include_blame": False, "context_lines": 1}, small_project
    )
    todo = next(t for t in out["todos"] if t["file"].endswith("a.py"))
    assert todo["context"] is not None
    assert "TODO" in todo["context"]


def test_no_blame_when_not_in_git(small_project: Path):
    out = run_extract_todos({"include_blame": True}, small_project)
    # No git repo here, so blame can't run; entries should lack age_days.
    for todo in out["todos"]:
        assert "age_days" not in todo


def test_custom_markers_only(small_project: Path):
    out = run_extract_todos(
        {"include_blame": False, "markers": ["FIXME"]}, small_project
    )
    markers = {t["marker"] for t in out["todos"]}
    assert markers == {"FIXME"}


def test_max_results_truncates(tmp_path: Path):
    for i in range(10):
        (tmp_path / f"f{i}.py").write_text(f"# TODO: thing {i}\n")
    out = run_extract_todos(
        {"include_blame": False, "max_results": 3}, tmp_path
    )
    assert len(out["todos"]) == 3
    assert out["total"] == 10
    assert out["truncated"] is True


def test_sort_by_file(small_project: Path):
    out = run_extract_todos(
        {"include_blame": False, "sort_by": "file"}, small_project
    )
    files = [t["file"] for t in out["todos"]]
    assert files == sorted(files)


@pytest.mark.skipif(shutil.which("git") is None, reason="git not on PATH")
def test_blame_attaches_in_git_repo(tmp_path: Path):
    # Init a repo with a single file containing a TODO.
    def g(*args: str) -> None:
        subprocess.run(["git", *args], cwd=tmp_path, check=True, capture_output=True)

    g("init", "--initial-branch=main")
    g("config", "user.email", "ann@example.com")
    g("config", "user.name", "Ann")
    g("config", "commit.gpgsign", "false")
    (tmp_path / "src.py").write_text("# TODO: revisit\nx = 1\n")
    g("add", "src.py")
    g("commit", "-m", "initial")

    out = run_extract_todos({"include_blame": True}, tmp_path)
    todo = next(t for t in out["todos"] if t["file"].endswith("src.py"))
    assert todo.get("author") in ("ann@example.com", "Ann")
    assert todo.get("commit") is not None
    assert todo.get("age_days") is not None
    assert todo["age_days"] >= 0
