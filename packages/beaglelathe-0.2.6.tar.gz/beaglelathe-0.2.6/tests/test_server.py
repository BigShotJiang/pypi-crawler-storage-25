"""Tests for server.py — MCP dispatch, welcome/quota gating, and the bg sync hook."""

from __future__ import annotations

import asyncio
import threading

import pytest

from beaglelathe import server
from beaglelathe.auth.credentials import Credentials, CredentialsError
from mcp.types import TextContent

# Capture the real Thread class before any test patches it — the autouse fixture
# below swaps `threading.Thread` for a no-op, but the integration test at the
# bottom needs the real class to actually run a daemon thread.
_REAL_THREAD = threading.Thread


# ── Shared fixtures ──────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _isolate_server_state(monkeypatch, tmp_path):
    """Reset module-level flags and steer all side effects away from the user's home.

    - `_welcomed`, `_quota_exceeded`, `_upgrade_url` reset so each test starts cold.
    - `record_call` redirected to a tmp DB so we don't pollute ~/.beaglelathe/state.db.
    - `offline_too_long` neutered so the offline gate never fires in tests that
      don't explicitly exercise it.
    - Background thread spawn replaced with a synchronous no-op so the assertions
      stay deterministic.
    """
    monkeypatch.setattr(server, "_welcomed", False)
    monkeypatch.setattr(server, "_quota_exceeded", False)
    monkeypatch.setattr(server, "_upgrade_url", None)
    monkeypatch.setattr(server, "record_call", lambda *_a, **_kw: None)
    monkeypatch.setattr(server, "offline_too_long", lambda *_a, **_kw: False)
    monkeypatch.setattr(
        server,
        "load_credentials",
        lambda *_a, **_kw: Credentials(
            jwt="jwt",
            user_id="u",
            email="e@example.com",
            plan="free",
            budget_remaining=10,
            budget_resets_at="2099-01-01T00:00:00+00:00",
            base_url="http://localhost",
            issued_at="2099-01-01T00:00:00+00:00",
        ),
    )

    # Replace the background-thread spawn with a no-op so call_tool tests are
    # deterministic. Individual tests opt back in by re-patching threading.Thread.
    class _NoopThread:
        def __init__(self, *_a, **_kw):
            pass

        def start(self):
            pass

    monkeypatch.setattr(server.threading, "Thread", _NoopThread)
    yield


def _run(coro):
    return asyncio.run(coro)


# ── list_tools ───────────────────────────────────────────────────────────────


EXPECTED_TOOLS = {
    "search",
    "edit",
    "read",
    "sh",
    "run_tests",
    "git_status",
    "git_diff",
    "changed_files",
    "lint_and_typecheck",
    "extract_todos",
    "commit_message",
}


def test_list_tools_returns_all_registered_tools():
    tools = _run(server.list_tools())
    names = {t.name for t in tools}
    assert names == EXPECTED_TOOLS


def test_list_tools_every_tool_has_non_empty_schema():
    tools = _run(server.list_tools())
    for t in tools:
        assert t.description, f"{t.name} missing description"
        assert isinstance(t.inputSchema, dict)
        # Must declare a JSON-schema type or properties.
        assert t.inputSchema.get("type") or t.inputSchema.get("properties"), (
            f"{t.name} input schema is empty: {t.inputSchema!r}"
        )


# ── call_tool dispatch ───────────────────────────────────────────────────────


@pytest.fixture
def stub_all_tools(monkeypatch):
    """Replace every tool implementation with a sentinel-returning stub."""

    def _stub(args, *_a, **_kw):
        return {"ok": True, "args": dict(args)}

    monkeypatch.setattr(server, "run_search", _stub)
    monkeypatch.setattr(server, "apply_edits", lambda edits, _cwd, validate=True: {"ok": True})
    monkeypatch.setattr(server, "run_read", _stub)
    monkeypatch.setattr(server, "run_sh", _stub)
    monkeypatch.setattr(server, "run_tests", _stub)
    monkeypatch.setattr(server, "run_git_status", _stub)
    monkeypatch.setattr(server, "run_git_diff", _stub)
    monkeypatch.setattr(server, "run_changed_files", _stub)
    monkeypatch.setattr(server, "run_lint_and_typecheck", _stub)
    monkeypatch.setattr(server, "run_extract_todos", _stub)
    monkeypatch.setattr(server, "run_commit_message", _stub)


@pytest.mark.parametrize("tool", sorted(EXPECTED_TOOLS))
def test_call_tool_dispatches_each_known_tool(stub_all_tools, tool):
    content, result = _run(server.call_tool(tool, {}))
    assert isinstance(content, list)
    assert all(isinstance(c, TextContent) for c in content)
    assert content[0].type == "text"
    assert isinstance(content[0].text, str)
    # The dispatch happens — result is whatever the stub returned (plus possibly
    # _type/hint augmentations). It must at minimum be a dict.
    assert isinstance(result, dict)


def test_call_tool_unknown_tool_returns_error(stub_all_tools):
    content, result = _run(server.call_tool("does-not-exist", {}))
    assert isinstance(content[0], TextContent)
    assert "unknown tool" in result["error"]


def test_call_tool_text_content_reflects_format_result(stub_all_tools):
    content, _ = _run(server.call_tool("read", {"path": "x"}))
    # Whatever format_result produces, we just need a non-empty string.
    assert content[0].text


# ── Welcome-once gating ──────────────────────────────────────────────────────


def test_welcome_notice_shown_when_no_credentials(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "_welcomed", False)
    monkeypatch.setattr(server, "load_credentials", lambda *_a, **_kw: None)
    _, result = _run(server.call_tool("read", {"path": "x"}))
    assert "_notice" in result
    assert "BeagleLathe" in result["_notice"]
    assert "/lathe-login" in result["_notice"]


def test_welcome_notice_suppressed_when_credentials_present(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "_welcomed", False)
    # The autouse fixture already returns a Credentials object from load_credentials.
    _, result = _run(server.call_tool("read", {"path": "x"}))
    assert "_notice" not in result


def test_welcome_notice_only_appears_once(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "_welcomed", False)
    monkeypatch.setattr(server, "load_credentials", lambda *_a, **_kw: None)
    _, first = _run(server.call_tool("read", {"path": "x"}))
    _, second = _run(server.call_tool("read", {"path": "x"}))
    assert "_notice" in first
    assert "_notice" not in second


def test_welcome_notice_tolerates_credentials_error(stub_all_tools, monkeypatch):
    """CredentialsError must be treated as 'no creds' — show the welcome anyway."""

    monkeypatch.setattr(server, "_welcomed", False)

    def _raises(*_a, **_kw):
        raise CredentialsError("corrupt")

    monkeypatch.setattr(server, "load_credentials", _raises)
    _, result = _run(server.call_tool("read", {"path": "x"}))
    assert "_notice" in result


# ── Quota-exceeded gating ────────────────────────────────────────────────────


def test_quota_exceeded_short_circuits_dispatch(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "_quota_exceeded", True)
    monkeypatch.setattr(server, "_upgrade_url", "https://example.com/upgrade")
    # If the gate failed to fire, the read stub would set ok=True; assert we
    # don't see that — the quota payload replaces it entirely.
    content, result = _run(server.call_tool("read", {"path": "x"}))
    assert result["error"] == "quota_exceeded"
    assert result["upgrade_url"] == "https://example.com/upgrade"
    assert "Free-tier limit" in result["message"]
    assert "Free-tier limit" in content[0].text
    assert "https://example.com/upgrade" in content[0].text
    assert result.get("ok") is None  # the tool stub never ran


def test_quota_exceeded_without_upgrade_url_omits_field(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "_quota_exceeded", True)
    monkeypatch.setattr(server, "_upgrade_url", None)
    _, result = _run(server.call_tool("read", {"path": "x"}))
    assert result["error"] == "quota_exceeded"
    assert "upgrade_url" not in result


# ── Offline gating ───────────────────────────────────────────────────────────


def test_offline_too_long_short_circuits(stub_all_tools, monkeypatch):
    monkeypatch.setattr(server, "offline_too_long", lambda *_a, **_kw: True)
    monkeypatch.setattr(server, "offline_grace_hours", lambda *_a, **_kw: 24.0)
    content, result = _run(server.call_tool("read", {"path": "x"}))
    assert result["error"] == "offline_too_long"
    assert "24" in result["message"]
    assert "offline" in content[0].text.lower()


# ── _improve_search_errors ───────────────────────────────────────────────────


def test_improve_search_errors_upgrades_missing_ripgrep_message():
    out = server._improve_search_errors({"error": "ripgrep ('rg') not found. blah"})
    assert "system error" in out["error"]
    assert "brew install ripgrep" in out["error"]
    assert out["_type"] == "system_error"


def test_improve_search_errors_tags_unknown_error_as_user_error():
    out = server._improve_search_errors({"error": "bad regex"})
    assert out["_type"] == "user_error"


def test_improve_search_errors_passes_through_clean_result():
    out = server._improve_search_errors({"matches": [1, 2, 3]})
    assert out == {"matches": [1, 2, 3]}


def test_improve_search_errors_respects_existing_type():
    out = server._improve_search_errors({"error": "x", "_type": "system_error"})
    assert out["_type"] == "system_error"  # not overwritten to user_error


# ── _improve_read_errors ─────────────────────────────────────────────────────


def test_improve_read_errors_tags_missing_file_as_user_error_with_hint():
    out = server._improve_read_errors({"error": "file not found"})
    assert out["_type"] == "user_error"
    assert "hint" in out
    assert "ls" in out["hint"]


def test_improve_read_errors_tags_no_such_file_as_user_error():
    out = server._improve_read_errors({"error": "no such file or directory"})
    assert out["_type"] == "user_error"


def test_improve_read_errors_other_errors_tagged_system():
    out = server._improve_read_errors({"error": "decode failed"})
    assert out["_type"] == "system_error"


def test_improve_read_errors_passes_through_clean_result():
    out = server._improve_read_errors({"content": "ok"})
    assert out == {"content": "ok"}


# ── _improve_sh_errors ───────────────────────────────────────────────────────


def test_improve_sh_errors_tags_allowlist_violation_as_user_error():
    out = server._improve_sh_errors(
        {"error": "command `rm` not in read-only allowlist"}
    )
    assert out["_type"] == "user_error"
    assert "Bash" in out["hint"]


def test_improve_sh_errors_tags_metacharacters_as_user_error():
    out = server._improve_sh_errors({"error": "shell metacharacters rejected"})
    assert out["_type"] == "user_error"
    assert "pipes" in out["hint"]


def test_improve_sh_errors_tags_command_not_found_as_system_error():
    out = server._improve_sh_errors({"error": "rg: command not found"})
    assert out["_type"] == "system_error"
    assert "PATH" in out["hint"]


def test_improve_sh_errors_passes_through_clean_result():
    out = server._improve_sh_errors({"stdout": "ok"})
    assert out == {"stdout": "ok"}


# ── _sync_usage_bg ───────────────────────────────────────────────────────────


def test_sync_usage_bg_noops_when_no_credentials(monkeypatch):
    """No creds → no network call, no exception, no state change."""
    monkeypatch.setattr(server, "load_credentials", lambda *_a, **_kw: None)
    monkeypatch.setattr(server, "_quota_exceeded", False)
    # If post_sync were imported and called it would raise — prove we don't.
    import beaglelathe.usage_client as uc

    def _explode(*_a, **_kw):
        raise AssertionError("post_sync should not be called without credentials")

    monkeypatch.setattr(uc, "post_sync", _explode)
    server._sync_usage_bg()  # must not raise
    assert server._quota_exceeded is False


def test_sync_usage_bg_sets_quota_when_upgrade_url_returned(monkeypatch):
    import beaglelathe.usage_client as uc

    monkeypatch.setattr(
        uc,
        "post_sync",
        lambda creds, tool_calls: {"upgrade_url": "https://example.com/up"},
    )
    monkeypatch.setattr(server, "_quota_exceeded", False)
    monkeypatch.setattr(server, "_upgrade_url", None)
    server._sync_usage_bg()
    assert server._quota_exceeded is True
    assert server._upgrade_url == "https://example.com/up"


def test_sync_usage_bg_swallows_post_sync_exception(monkeypatch):
    import beaglelathe.usage_client as uc

    def _raise(*_a, **_kw):
        raise RuntimeError("network down")

    monkeypatch.setattr(uc, "post_sync", _raise)
    # Must not raise. Quota state must stay clean.
    server._sync_usage_bg()
    assert server._quota_exceeded is False


def test_sync_usage_bg_persists_refreshed_jwt(monkeypatch, tmp_path):
    import beaglelathe.usage_client as uc

    monkeypatch.setattr(
        uc,
        "post_sync",
        lambda creds, tool_calls: {"jwt": "new-jwt-value"},
    )
    saved: dict = {}

    def _fake_save(creds, *_a, **_kw):
        saved["creds"] = creds

    monkeypatch.setattr(server, "save_credentials", _fake_save)
    server._sync_usage_bg()
    assert saved["creds"].jwt == "new-jwt-value"


def test_sync_usage_bg_does_not_persist_when_jwt_unchanged(monkeypatch):
    import beaglelathe.usage_client as uc

    # Fixture's load_credentials returns Credentials(jwt='jwt').
    monkeypatch.setattr(uc, "post_sync", lambda creds, tool_calls: {"jwt": "jwt"})

    def _should_not_save(*_a, **_kw):
        raise AssertionError("save_credentials should not be called when JWT unchanged")

    monkeypatch.setattr(server, "save_credentials", _should_not_save)
    server._sync_usage_bg()  # must not raise


def test_sync_usage_bg_swallows_save_credentials_failure(monkeypatch):
    import beaglelathe.usage_client as uc

    monkeypatch.setattr(uc, "post_sync", lambda creds, tool_calls: {"jwt": "new"})

    def _bad_save(*_a, **_kw):
        raise OSError("disk full")

    monkeypatch.setattr(server, "save_credentials", _bad_save)
    # Must not raise even when save fails.
    server._sync_usage_bg()


# ── Background-thread spawn ──────────────────────────────────────────────────


def test_call_tool_spawns_daemon_thread_for_sync(monkeypatch, stub_all_tools):
    """call_tool must fire _sync_usage_bg on a daemon thread that never blocks."""

    captured: dict = {}

    real_thread = threading.Thread

    class _RecordingThread(real_thread):
        def __init__(self, *args, **kwargs):
            captured["target"] = kwargs.get("target")
            captured["daemon"] = kwargs.get("daemon")
            super().__init__(*args, **kwargs)

        def start(self):
            captured["started"] = True
            # Don't actually start — _sync_usage_bg is exercised in its own tests.

    monkeypatch.setattr(server.threading, "Thread", _RecordingThread)
    _run(server.call_tool("read", {"path": "x"}))

    assert captured.get("started") is True
    assert captured.get("daemon") is True
    assert captured.get("target") is server._sync_usage_bg


def test_real_sync_usage_bg_runs_on_daemon_without_propagating(monkeypatch):
    """Integration check: spawn a real thread; an internal failure must not bubble up."""

    import beaglelathe.usage_client as uc

    def _raise(*_a, **_kw):
        raise RuntimeError("kaboom")

    monkeypatch.setattr(uc, "post_sync", _raise)

    t = _REAL_THREAD(target=server._sync_usage_bg, daemon=True)
    t.start()
    t.join(timeout=2.0)
    assert not t.is_alive()
