"""Tests for the BeagleLathe credentials store."""

import json
import stat
from pathlib import Path

import pytest

from beaglelathe.auth.credentials import (
    Credentials,
    CredentialsError,
    clear_credentials,
    credentials_path,
    load_credentials,
    save_credentials,
)


@pytest.fixture
def home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("BEAGLELATHE_HOME", str(tmp_path))
    return tmp_path


def _sample(**overrides) -> Credentials:
    defaults = dict(
        jwt="header.payload.sig",
        user_id="00000000-0000-0000-0000-000000000001",
        email="user@example.com",
        plan="free",
        budget_remaining=200,
        budget_resets_at="2026-06-01T00:00:00Z",
        base_url="http://localhost:8000",
        issued_at="2026-05-09T00:00:00Z",
    )
    defaults.update(overrides)
    return Credentials(**defaults)


def test_credentials_path_uses_env(home: Path):
    assert credentials_path() == home / "credentials.json"


def test_load_returns_none_when_missing(home: Path):
    assert load_credentials() is None


def test_save_then_load_roundtrip(home: Path):
    c = _sample()
    path = save_credentials(c)
    assert path == home / "credentials.json"
    loaded = load_credentials()
    assert loaded == c


def test_save_creates_directory(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    deep = tmp_path / "deep" / "tree" / "home"
    monkeypatch.setenv("BEAGLELATHE_HOME", str(deep))
    save_credentials(_sample())
    assert (deep / "credentials.json").exists()


def test_save_writes_mode_0600(home: Path):
    save_credentials(_sample())
    p = credentials_path()
    mode = stat.S_IMODE(p.stat().st_mode)
    # rw owner only; group/other zeroed.
    assert mode & (stat.S_IRWXG | stat.S_IRWXO) == 0
    assert mode & stat.S_IRUSR
    assert mode & stat.S_IWUSR


def test_save_uses_atomic_replace(home: Path):
    """We write to .tmp then os.replace; final file is the only artifact."""
    save_credentials(_sample())
    files = sorted(p.name for p in home.iterdir())
    assert files == ["credentials.json"]


def test_clear_returns_false_when_absent(home: Path):
    assert clear_credentials() is False


def test_clear_removes_existing(home: Path):
    save_credentials(_sample())
    assert clear_credentials() is True
    assert not (home / "credentials.json").exists()


def test_load_raises_on_missing_field(home: Path):
    p = home / "credentials.json"
    p.write_text(json.dumps({"jwt": "abc"}))
    with pytest.raises(CredentialsError):
        load_credentials()


def test_load_raises_on_corrupt_json(home: Path):
    p = home / "credentials.json"
    p.write_text("not json {{{")
    with pytest.raises(CredentialsError):
        load_credentials()


def test_credentials_with_unlimited_budget(home: Path):
    c = _sample(plan="pro", budget_remaining=None)
    save_credentials(c)
    loaded = load_credentials()
    assert loaded is not None
    assert loaded.plan == "pro"
    assert loaded.budget_remaining is None
