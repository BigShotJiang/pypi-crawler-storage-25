"""Tests for AuthClient (mocked over httpx.MockTransport)."""


import httpx
import pytest

from beaglelathe.auth.client import (
    AuthClient,
    AuthError,
    credentials_from_poll_ok,
    default_base_url,
    device_fingerprint,
)


def test_default_base_url_falls_back_to_prod(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("BEAGLELATHE_API_URL", raising=False)
    assert default_base_url() == "https://beaglelathe-api.fly.dev"


def test_default_base_url_respects_env(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("BEAGLELATHE_API_URL", "https://api.example.com/")
    # Trailing slash stripped.
    assert default_base_url() == "https://api.example.com"


def test_device_fingerprint_is_stable():
    assert device_fingerprint() == device_fingerprint()
    fp = device_fingerprint()
    assert len(fp) == 32
    # Hex.
    int(fp, 16)


def _client_with(handler) -> AuthClient:
    transport = httpx.MockTransport(handler)
    c = AuthClient(base_url="http://test.local", poll_interval=0.0)
    c._client = httpx.Client(transport=transport, follow_redirects=False)
    return c


def test_start_posts_fingerprint():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["body"] = request.read()
        return httpx.Response(
            200,
            json={
                "login_session_id": "11111111-1111-1111-1111-111111111111",
                "login_url": "http://test.local/auth/login?session=11111111-1111-1111-1111-111111111111",
                "poll_url": "http://test.local/auth/poll?session=11111111-1111-1111-1111-111111111111",
                "poll_secret": "test-poll-secret",
                "expires_at": "2026-05-09T01:00:00+00:00",
            },
        )

    with _client_with(handler) as client:
        out = client.start(fingerprint="abc1234567")
    assert out["login_session_id"] == "11111111-1111-1111-1111-111111111111"
    assert seen["url"] == "http://test.local/auth/start"
    assert b'"device_fingerprint":"abc1234567"' in seen["body"]


def test_start_raises_on_http_error():
    def handler(request):
        return httpx.Response(500, text="boom")

    with _client_with(handler) as client:
        with pytest.raises(AuthError):
            client.start(fingerprint="x" * 12)


def test_poll_until_complete_returns_when_ok():
    calls = {"n": 0, "secrets": []}

    def handler(request):
        calls["n"] += 1
        calls["secrets"].append(request.url.params.get("secret"))
        if calls["n"] < 3:
            return httpx.Response(200, json={"status": "pending"})
        return httpx.Response(
            200,
            json={
                "status": "ok",
                "jwt": "eyJ.fake.jwt",
                "user": {"id": "22222222-2222-2222-2222-222222222222", "email": "u@example.com"},
                "plan": "free",
                "budget_remaining": 199,
                "budget_resets_at": "2026-06-01T00:00:00+00:00",
            },
        )

    with _client_with(handler) as client:
        result = client.poll_until_complete(
            "11111111-1111-1111-1111-111111111111",
            "test-poll-secret",
            deadline_seconds=5,
        )
    assert result["status"] == "ok"
    assert result["jwt"] == "eyJ.fake.jwt"
    assert calls["n"] == 3
    assert calls["secrets"] == ["test-poll-secret"] * 3


def test_poll_until_complete_times_out():
    def handler(request):
        return httpx.Response(200, json={"status": "pending"})

    with _client_with(handler) as client:
        with pytest.raises(AuthError, match="timed out"):
            client.poll_until_complete(
                "11111111-1111-1111-1111-111111111111",
                "test-poll-secret",
                deadline_seconds=0.1,
            )


def test_credentials_from_poll_ok_handles_unlimited():
    payload = {
        "status": "ok",
        "jwt": "tok",
        "user": {"id": "id-1", "email": "p@example.com"},
        "plan": "pro",
        "budget_remaining": None,
        "budget_resets_at": "2026-06-01T00:00:00+00:00",
    }
    creds = credentials_from_poll_ok(payload, base_url="http://test.local")
    assert creds.plan == "pro"
    assert creds.budget_remaining is None
    assert creds.email == "p@example.com"
    assert creds.base_url == "http://test.local"


def test_authclient_close_is_idempotent():
    c = AuthClient(base_url="http://test.local", poll_interval=0.0)
    c.close()
    # Calling again should be safe.
    c.close()
