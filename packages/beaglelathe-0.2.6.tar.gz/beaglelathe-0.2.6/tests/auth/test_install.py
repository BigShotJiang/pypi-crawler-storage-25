"""Tests for the plugin install routine and `beaglelathe install` CLI."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from beaglelathe.__main__ import main
from beaglelathe.auth import install as install_mod


@pytest.fixture
def fake_homes(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> dict:
    """Redirect ~/.beaglelathe and ~/.claude/plugins into tmp_path."""
    bl_home = tmp_path / "beaglelathe"
    claude_plugins = tmp_path / "claude-plugins"
    bl_home.mkdir()
    claude_plugins.mkdir()
    monkeypatch.setenv("BEAGLELATHE_HOME", str(bl_home))
    monkeypatch.delenv("BEAGLELATHE_API_URL", raising=False)
    monkeypatch.setattr(install_mod, "claude_plugins_dir", lambda: claude_plugins)
    return {"bl_home": bl_home, "claude_plugins": claude_plugins}


@pytest.fixture
def fake_plugin_src(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Build a minimal plugin source tree and point bundled_plugin_path at it."""
    src = tmp_path / "plugin-src"
    (src / ".claude-plugin").mkdir(parents=True)
    (src / ".claude-plugin" / "marketplace.json").write_text(
        json.dumps(
            {
                "name": "beaglelathe",
                "owner": {"name": "BeagleLathe"},
                "plugins": [{"name": "lathe", "source": "./", "version": "0.0.1"}],
            }
        )
    )
    (src / ".claude-plugin" / "plugin.json").write_text(
        json.dumps(
            {
                "name": "lathe",
                "version": "0.0.1",
                "mcpServers": {
                    "lathe": {"command": "beaglelathe", "args": ["serve"]}
                },
            }
        )
    )
    (src / "agents").mkdir()
    (src / "agents" / "x.md").write_text("agent")
    monkeypatch.setenv("BEAGLELATHE_PLUGIN_SRC", str(src))
    return src


@pytest.fixture
def fake_claude(monkeypatch: pytest.MonkeyPatch) -> list:
    """Pretend `claude` is on PATH and capture calls."""
    calls: list[list[str]] = []

    def fake_run(argv, **kwargs):
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(install_mod.shutil, "which", lambda name: f"/fake/{name}")
    monkeypatch.setattr(install_mod.subprocess, "run", fake_run)
    return calls


def _write_installed_state(claude_plugins: Path) -> None:
    """Write Claude's plugin/marketplace registries as if the install ran."""
    (claude_plugins / "known_marketplaces.json").write_text(
        json.dumps({"beaglelathe": {"installLocation": "/x"}})
    )
    (claude_plugins / "installed_plugins.json").write_text(
        json.dumps(
            {
                "version": 2,
                "plugins": {
                    "lathe@beaglelathe": [
                        {"scope": "user", "version": "0.0.1"}
                    ]
                },
            }
        )
    )


def _simulate_prior_install(fake_homes: dict) -> None:
    """Pre-populate everything `install_plugin` would set up on a real first run:
    sync the local plugin tree with a matching version stamp, plus Claude's
    registries. Used by tests that exercise the idempotent skip path.
    """
    install_mod.sync_plugin_tree(force=True)
    _write_installed_state(fake_homes["claude_plugins"])


def test_install_first_run_registers_marketplace_and_plugin(
    fake_homes, fake_plugin_src, fake_claude, capsys
):
    rc = main(["install"])
    assert rc == 0, capsys.readouterr().err

    # Plugin tree was synced into ~/.beaglelathe/plugin/
    bl_plugin = fake_homes["bl_home"] / "plugin"
    assert (bl_plugin / ".claude-plugin" / "marketplace.json").is_file()
    assert (bl_plugin / "agents" / "x.md").is_file()
    assert (bl_plugin / ".version").is_file()

    # claude was invoked twice with the right argv.
    assert len(fake_claude) == 2
    assert fake_claude[0] == [
        "/fake/claude",
        "plugin",
        "marketplace",
        "add",
        str(bl_plugin),
    ]
    assert fake_claude[1] == [
        "/fake/claude",
        "plugin",
        "install",
        "lathe@beaglelathe",
    ]


def test_install_idempotent_when_already_installed(
    fake_homes, fake_plugin_src, fake_claude, capsys
):
    _simulate_prior_install(fake_homes)

    rc = main(["install"])
    assert rc == 0
    assert fake_claude == []  # no shell-outs
    err = capsys.readouterr().err
    assert "already installed" in err


def test_install_force_reruns_shell_outs(
    fake_homes, fake_plugin_src, fake_claude, capsys
):
    _simulate_prior_install(fake_homes)

    rc = main(["install", "--force"])
    assert rc == 0
    assert len(fake_claude) == 2
    assert fake_claude[0][1:4] == ["plugin", "marketplace", "add"]
    assert fake_claude[1][1:] == ["plugin", "install", "lathe@beaglelathe"]


def test_install_refreshes_claude_cache_when_tree_changes(
    fake_homes, fake_plugin_src, fake_claude, capsys
):
    """After an upgrade, claude plugin install must re-run so Claude picks up
    the new bundled files even though `lathe@beaglelathe` is already registered.
    """
    # Pre-populate everything, then stamp an old version to simulate an upgrade.
    _simulate_prior_install(fake_homes)
    stamp = fake_homes["bl_home"] / "plugin" / ".version"
    stamp.write_text("0.0.0")  # older than the installed package version

    rc = main(["install"])
    assert rc == 0

    # Marketplace already registered, so skip the add. But the plugin install
    # must re-run to refresh ~/.claude/plugins/cache/.
    cmds = [c[1:] for c in fake_claude]
    assert ["plugin", "install", "lathe@beaglelathe"] in cmds
    assert all(c[:3] != ["plugin", "marketplace", "add"] for c in cmds)


def test_install_pins_plugin_json_to_sys_executable(
    fake_homes, fake_plugin_src, fake_claude
):
    """The local plugin.json must use sys.executable so the MCP server starts
    cleanly under pipx / uv tool install / unactivated venvs.
    """
    import sys

    rc = main(["install"])
    assert rc == 0

    local_plugin_json = fake_homes["bl_home"] / "plugin" / ".claude-plugin" / "plugin.json"
    data = json.loads(local_plugin_json.read_text())
    server = data["mcpServers"]["lathe"]
    assert server["command"] == sys.executable
    assert server["args"] == ["-m", "beaglelathe"]


def test_install_errors_when_claude_missing(
    fake_homes, fake_plugin_src, monkeypatch, capsys
):
    monkeypatch.setattr(install_mod.shutil, "which", lambda name: None)

    rc = main(["install"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "Claude Code CLI" in err
    assert "claude.com/code" in err


def test_install_propagates_claude_failure(
    fake_homes, fake_plugin_src, monkeypatch, capsys
):
    def failing_run(argv, **kwargs):
        raise subprocess.CalledProcessError(
            returncode=1, cmd=argv, output="", stderr="boom: marketplace exists"
        )

    monkeypatch.setattr(install_mod.shutil, "which", lambda name: f"/fake/{name}")
    monkeypatch.setattr(install_mod.subprocess, "run", failing_run)

    rc = main(["install"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "install failed" in err
    assert "boom: marketplace exists" in err


def test_install_mcp_json_writes_project_file(fake_homes, tmp_path, capsys):
    import sys

    project = tmp_path / "proj"
    project.mkdir()

    rc = main(["install", "--mcp-json", str(project)])
    assert rc == 0

    mcp_path = project / ".mcp.json"
    assert mcp_path.is_file()
    cfg = json.loads(mcp_path.read_text())
    # Per-project .mcp.json pins to sys.executable so it works inside whatever
    # venv created it — same robustness story as the plugin install.
    assert cfg["mcpServers"]["lathe"]["command"] == sys.executable
    assert cfg["mcpServers"]["lathe"]["args"] == ["-m", "beaglelathe"]


def test_login_runs_install_first_then_logs_in(
    fake_homes, fake_plugin_src, fake_claude, monkeypatch, capsys
):
    """`beaglelathe login` should perform install, then the magic-link flow."""
    import httpx

    from beaglelathe.auth import client as client_mod
    from beaglelathe.auth.credentials import load_credentials

    monkeypatch.setattr("beaglelathe.auth.cli.webbrowser.open", lambda *a, **k: True)

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/auth/start":
            return httpx.Response(
                200,
                json={
                    "login_session_id": "11111111-1111-1111-1111-111111111111",
                    "login_url": "http://test.local/auth/login?s=1",
                    "poll_url": "http://test.local/auth/poll?s=1",
                    "poll_secret": "sec",
                    "expires_at": "2026-05-09T01:00:00+00:00",
                },
            )
        if request.url.path == "/auth/poll":
            return httpx.Response(
                200,
                json={
                    "status": "ok",
                    "jwt": "eyJ.fake",
                    "user": {"id": "u1", "email": "a@example.com"},
                    "plan": "free",
                    "budget_remaining": 199,
                    "budget_resets_at": "2026-06-01T00:00:00+00:00",
                },
            )
        return httpx.Response(404)

    real_init = client_mod.AuthClient.__init__

    def fake_init(self, *args, **kwargs):
        real_init(self, *args, **kwargs)
        self._client.close()
        self._client = httpx.Client(transport=httpx.MockTransport(handler))

    monkeypatch.setattr(client_mod.AuthClient, "__init__", fake_init)

    rc = main(
        [
            "login",
            "--api-url",
            "http://test.local",
            "--no-browser",
            "--timeout",
            "5",
            "--poll-interval",
            "0",
        ]
    )
    assert rc == 0, capsys.readouterr().err
    assert load_credentials() is not None
    # Install ran (marketplace add + plugin install).
    assert len(fake_claude) == 2


def test_login_aborts_when_install_fails(
    fake_homes, fake_plugin_src, monkeypatch, capsys
):
    monkeypatch.setattr(install_mod.shutil, "which", lambda name: None)

    rc = main(["login", "--api-url", "http://test.local", "--no-browser", "--timeout", "1"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "plugin install failed" in err
    assert "Claude Code CLI" in err
