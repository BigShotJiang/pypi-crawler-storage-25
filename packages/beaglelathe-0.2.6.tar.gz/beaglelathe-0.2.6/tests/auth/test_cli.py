"""End-to-end-ish tests for the login/logout/whoami CLI subcommands."""

from pathlib import Path

import httpx
import pytest

from beaglelathe.__main__ import main
from beaglelathe.auth import client as client_mod
from beaglelathe.auth.credentials import credentials_path, load_credentials


@pytest.fixture
def home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("BEAGLELATHE_HOME", str(tmp_path))
    monkeypatch.delenv("BEAGLELATHE_API_URL", raising=False)
    return tmp_path


def test_logout_when_logged_out(home: Path, capsys: pytest.CaptureFixture):
    rc = main(["logout"])
    assert rc == 0
    err = capsys.readouterr().err
    assert "No credentials" in err


def test_whoami_when_logged_out(home: Path, capsys: pytest.CaptureFixture):
    rc = main(["whoami"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "not logged in" in err


def test_login_and_then_whoami_logout(home: Path, capsys: pytest.CaptureFixture, monkeypatch: pytest.MonkeyPatch):
    # Mock the auth backend and disable the real browser opener.
    monkeypatch.setattr("beaglelathe.auth.cli.webbrowser.open", lambda *a, **k: True)

    poll_calls = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/auth/start":
            return httpx.Response(
                200,
                json={
                    "login_session_id": "33333333-3333-3333-3333-333333333333",
                    "login_url": "http://test.local/auth/login?session=33333333-3333-3333-3333-333333333333",
                    "poll_url": "http://test.local/auth/poll?session=33333333-3333-3333-3333-333333333333",
                    "poll_secret": "test-poll-secret",
                    "expires_at": "2026-05-09T01:00:00+00:00",
                },
            )
        if request.url.path == "/auth/poll":
            assert request.url.params.get("secret") == "test-poll-secret"
            poll_calls["n"] += 1
            if poll_calls["n"] < 2:
                return httpx.Response(200, json={"status": "pending"})
            return httpx.Response(
                200,
                json={
                    "status": "ok",
                    "jwt": "eyJ.fake.jwt",
                    "user": {"id": "user-1", "email": "test@example.com"},
                    "plan": "free",
                    "budget_remaining": 199,
                    "budget_resets_at": "2026-06-01T00:00:00+00:00",
                },
            )
        return httpx.Response(404)

    real_client_init = client_mod.AuthClient.__init__

    def fake_init(self, *args, **kwargs):
        real_client_init(self, *args, **kwargs)
        self._client.close()
        self._client = httpx.Client(transport=httpx.MockTransport(handler))

    monkeypatch.setattr(client_mod.AuthClient, "__init__", fake_init)

    rc = main(
        [
            "login",
            "--api-url",
            "http://test.local",
            "--no-browser",
            "--skip-install",
            "--timeout",
            "5",
            "--poll-interval",
            "0",
        ]
    )
    assert rc == 0, capsys.readouterr().err
    err = capsys.readouterr().err
    assert "Signed in as test@example.com" in err

    # Credentials persisted.
    creds = load_credentials()
    assert creds is not None
    assert creds.jwt == "eyJ.fake.jwt"
    assert creds.email == "test@example.com"
    assert creds.plan == "free"

    # whoami sees them.
    rc = main(["whoami"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "test@example.com" in out
    assert "plan:             free" in out

    # logout clears them.
    rc = main(["logout"])
    assert rc == 0
    assert load_credentials() is None
    assert not credentials_path().exists()


def test_login_reports_backend_failure(home: Path, capsys: pytest.CaptureFixture, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("beaglelathe.auth.cli.webbrowser.open", lambda *a, **k: True)

    def handler(request):
        return httpx.Response(503, text="backend down")

    real_client_init = client_mod.AuthClient.__init__

    def fake_init(self, *args, **kwargs):
        real_client_init(self, *args, **kwargs)
        self._client.close()
        self._client = httpx.Client(transport=httpx.MockTransport(handler))

    monkeypatch.setattr(client_mod.AuthClient, "__init__", fake_init)

    rc = main(["login", "--api-url", "http://test.local", "--no-browser", "--skip-install", "--timeout", "1"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "login failed" in err
