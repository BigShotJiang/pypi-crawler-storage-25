"""Tests for ripgrep.py — vendored-binary discovery, PATH fallback, and run() wrapper."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from beaglelathe import ripgrep
from beaglelathe.ripgrep import (
    RipgrepError,
    RipgrepNotFound,
    _FALLBACK_RG_PATHS,
    _platform_key,
    _resolve_rg,
    _vendored_rg_paths,
    run,
)


# ── _platform_key ────────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "sys_platform,machine,expected",
    [
        ("darwin", "arm64", "darwin-arm64"),
        ("darwin", "aarch64", "darwin-arm64"),
        ("darwin", "x86_64", "darwin-x86_64"),
        ("darwin", "amd64", "darwin-x86_64"),
        ("linux", "x86_64", "linux-x86_64"),
        ("linux2", "amd64", "linux-x86_64"),
        ("linux", "aarch64", "linux-arm64"),
        ("linux", "arm64", "linux-arm64"),
        ("win32", "amd64", "windows-x86_64"),
        ("win32", "x86_64", "windows-x86_64"),
    ],
)
def test_platform_key_known_combinations(monkeypatch, sys_platform, machine, expected):
    monkeypatch.setattr(ripgrep.sys, "platform", sys_platform)
    monkeypatch.setattr(ripgrep.platform, "machine", lambda: machine)
    assert _platform_key() == expected


@pytest.mark.parametrize(
    "sys_platform,machine",
    [
        ("darwin", "i386"),         # 32-bit mac not vendored
        ("darwin", "armv7"),        # weird arm variant
        ("linux", "i386"),          # 32-bit linux not vendored
        ("linux", "armv7l"),        # 32-bit arm linux
        ("win32", "arm64"),         # arm windows not vendored
        ("win32", "i386"),          # 32-bit windows
        ("freebsd", "x86_64"),      # unsupported OS family
        ("sunos5", "x86_64"),
    ],
)
def test_platform_key_unknown_returns_none(monkeypatch, sys_platform, machine):
    monkeypatch.setattr(ripgrep.sys, "platform", sys_platform)
    monkeypatch.setattr(ripgrep.platform, "machine", lambda: machine)
    assert _platform_key() is None


def test_platform_key_lowercases_machine(monkeypatch):
    monkeypatch.setattr(ripgrep.sys, "platform", "darwin")
    monkeypatch.setattr(ripgrep.platform, "machine", lambda: "ARM64")
    assert _platform_key() == "darwin-arm64"


# ── _vendored_rg_paths ───────────────────────────────────────────────────────


def test_vendored_rg_paths_empty_when_platform_unknown(monkeypatch):
    monkeypatch.setattr(ripgrep, "_platform_key", lambda: None)
    assert _vendored_rg_paths() == []


def test_vendored_rg_paths_ordering_without_env(monkeypatch):
    monkeypatch.setattr(ripgrep, "_platform_key", lambda: "darwin-arm64")
    monkeypatch.delenv("CLAUDE_PLUGIN_ROOT", raising=False)
    paths = _vendored_rg_paths()
    # No CLAUDE_PLUGIN_ROOT → first candidate is the _bin sibling, second is the source-tree bin/.
    assert len(paths) == 2
    here = Path(ripgrep.__file__).resolve()
    assert paths[0] == here.parent / "_bin" / "darwin-arm64" / "rg"
    assert paths[1] == here.parents[2] / "bin" / "darwin-arm64" / "rg"


def test_vendored_rg_paths_prepends_plugin_root(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_platform_key", lambda: "linux-x86_64")
    monkeypatch.setenv("CLAUDE_PLUGIN_ROOT", str(tmp_path))
    paths = _vendored_rg_paths()
    assert len(paths) == 3
    assert paths[0] == tmp_path / "bin" / "linux-x86_64" / "rg"


def test_vendored_rg_paths_windows_uses_rg_exe(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_platform_key", lambda: "windows-x86_64")
    monkeypatch.setenv("CLAUDE_PLUGIN_ROOT", str(tmp_path))
    paths = _vendored_rg_paths()
    for p in paths:
        assert p.name == "rg.exe"


# ── _resolve_rg ──────────────────────────────────────────────────────────────


def _make_executable(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("#!/bin/sh\nexit 0\n")
    path.chmod(0o755)


def test_resolve_rg_prefers_vendored_over_path(monkeypatch, tmp_path):
    vendored = tmp_path / "vendored" / "rg"
    _make_executable(vendored)
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [vendored])
    # Make shutil.which also report a different rg; vendored must win.
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: "/path/from/which/rg")
    assert _resolve_rg() == str(vendored)


def test_resolve_rg_falls_through_missing_vendored(monkeypatch, tmp_path):
    missing = tmp_path / "missing" / "rg"
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [missing])
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: "/usr/bin/rg")
    assert _resolve_rg() == "/usr/bin/rg"


def test_resolve_rg_chmods_when_not_executable(monkeypatch, tmp_path):
    vendored = tmp_path / "vendored" / "rg"
    vendored.parent.mkdir(parents=True)
    vendored.write_text("payload")
    vendored.chmod(0o644)  # readable but not executable
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [vendored])
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: None)
    assert _resolve_rg() == str(vendored)
    # Re-stat to confirm we attempted to chmod it executable.
    mode = vendored.stat().st_mode & 0o777
    assert mode & 0o111  # at least one execute bit set


def test_resolve_rg_falls_back_to_path(monkeypatch):
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [])
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: "/usr/local/bin/rg")
    assert _resolve_rg() == "/usr/local/bin/rg"


def test_resolve_rg_falls_back_to_fallback_paths(monkeypatch, tmp_path):
    fake_rg = tmp_path / "rg"
    _make_executable(fake_rg)
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [])
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: None)
    monkeypatch.setattr(ripgrep, "_FALLBACK_RG_PATHS", (str(fake_rg),))
    assert _resolve_rg() == str(fake_rg)


def test_resolve_rg_raises_when_all_options_exhausted(monkeypatch):
    monkeypatch.setattr(ripgrep, "_vendored_rg_paths", lambda: [])
    monkeypatch.setattr(ripgrep.shutil, "which", lambda _: None)
    monkeypatch.setattr(ripgrep, "_FALLBACK_RG_PATHS", ("/nonexistent/rg",))
    with pytest.raises(RipgrepNotFound) as e:
        _resolve_rg()
    # The message should give an install hint, not just a bare exception.
    assert "ripgrep" in str(e.value).lower()
    assert "install" in str(e.value).lower()


def test_fallback_paths_constant_includes_common_unix_locations():
    # Pin the publicly-known fallback list so a refactor that drops one is loud.
    assert "/opt/homebrew/bin/rg" in _FALLBACK_RG_PATHS
    assert "/usr/local/bin/rg" in _FALLBACK_RG_PATHS
    assert "/usr/bin/rg" in _FALLBACK_RG_PATHS


# ── run() ────────────────────────────────────────────────────────────────────


class _FakeCompletedProcess:
    def __init__(self, *, stdout: str = "", stderr: str = "", returncode: int = 0):
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode


def test_run_success_yields_decoded_json_objects(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    payload = (
        json.dumps({"type": "begin", "data": {}}) + "\n"
        + json.dumps({"type": "match", "data": {"lines": {"text": "hi\n"}}}) + "\n"
        + json.dumps({"type": "end", "data": {}}) + "\n"
    )

    def fake_run(*_, **__):
        return _FakeCompletedProcess(stdout=payload, returncode=0)

    monkeypatch.setattr(ripgrep.subprocess, "run", fake_run)
    out = list(run("needle", tmp_path))
    assert [item["type"] for item in out] == ["begin", "match", "end"]


def test_run_no_matches_returncode_one_is_not_an_error(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    monkeypatch.setattr(
        ripgrep.subprocess,
        "run",
        lambda *_, **__: _FakeCompletedProcess(stdout="", returncode=1),
    )
    # Should produce zero events, no exception.
    assert list(run("nothing", tmp_path)) == []


def test_run_non_zero_exit_raises_ripgrep_error_with_stderr(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    monkeypatch.setattr(
        ripgrep.subprocess,
        "run",
        lambda *_, **__: _FakeCompletedProcess(
            stdout="", stderr="bad regex pattern", returncode=2
        ),
    )
    with pytest.raises(RipgrepError) as e:
        list(run("[bad", tmp_path))
    assert "bad regex pattern" in str(e.value)


def test_run_non_zero_exit_without_stderr_falls_back_to_exit_code(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    monkeypatch.setattr(
        ripgrep.subprocess,
        "run",
        lambda *_, **__: _FakeCompletedProcess(stdout="", stderr="", returncode=2),
    )
    with pytest.raises(RipgrepError) as e:
        list(run("x", tmp_path))
    assert "2" in str(e.value)


def test_run_timeout_raised_as_ripgrep_error(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")

    def fake_run(*_, **__):
        raise subprocess.TimeoutExpired(cmd=["rg"], timeout=0.001)

    monkeypatch.setattr(ripgrep.subprocess, "run", fake_run)
    with pytest.raises(RipgrepError) as e:
        list(run("x", tmp_path, timeout=0.001))
    assert "timed out" in str(e.value)


def test_run_skips_malformed_json_lines(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    payload = (
        json.dumps({"type": "begin"}) + "\n"
        + "this is not json\n"
        + "\n"  # blank line: also skipped
        + json.dumps({"type": "end"}) + "\n"
    )
    monkeypatch.setattr(
        ripgrep.subprocess,
        "run",
        lambda *_, **__: _FakeCompletedProcess(stdout=payload, returncode=0),
    )
    out = list(run("x", tmp_path))
    assert [item["type"] for item in out] == ["begin", "end"]


def test_run_passes_pattern_path_glob_and_case_flag(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    captured: dict = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = list(cmd)
        captured["cwd"] = kwargs.get("cwd")
        captured["timeout"] = kwargs.get("timeout")
        return _FakeCompletedProcess(stdout="", returncode=1)

    monkeypatch.setattr(ripgrep.subprocess, "run", fake_run)
    list(run("FOO", tmp_path, path_glob="**/*.py", case_sensitive=True, timeout=5))

    cmd = captured["cmd"]
    assert cmd[0] == "/fake/rg"
    assert "--json" in cmd
    # case_sensitive=True must NOT add -i
    assert "-i" not in cmd
    assert "-g" in cmd and "**/*.py" in cmd
    assert "FOO" in cmd
    assert cmd[-1] == "."
    assert captured["cwd"] == str(tmp_path)
    assert captured["timeout"] == 5


def test_run_default_case_insensitive_omits_glob_when_default(monkeypatch, tmp_path):
    monkeypatch.setattr(ripgrep, "_resolve_rg", lambda: "/fake/rg")
    captured: dict = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = list(cmd)
        return _FakeCompletedProcess(stdout="", returncode=1)

    monkeypatch.setattr(ripgrep.subprocess, "run", fake_run)
    list(run("x", tmp_path))
    cmd = captured["cmd"]
    assert "-i" in cmd
    # `**/*` is the no-op default and must be skipped to avoid an extra rg arg.
    assert "-g" not in cmd
