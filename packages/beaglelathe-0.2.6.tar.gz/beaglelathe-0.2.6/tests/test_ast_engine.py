"""Tests for the BeagleLathe AST subsystem.

Exercises parse, truncate, symbols, imports, language_for_path, the registry,
and the round-trip / idempotence properties from AST_SUBSYSTEM_PLAN.md §17-18.
"""

from pathlib import Path

import pytest

from beaglelathe.ast import (
    LANGUAGES,
    imports,
    language_for_path,
    parse,
    symbols,
    truncate,
)
from beaglelathe.ast.handlers.tsx import TSXHandler

FIXTURES = Path(__file__).parent / "fixtures" / "ast"


# ----- registry & language_for_path -----------------------------------------


def test_language_for_path_python():
    assert language_for_path("foo.py") == "python"
    assert language_for_path("a/b/c.py") == "python"


def test_language_for_path_typescript():
    assert language_for_path("foo.ts") == "typescript"
    assert language_for_path("foo.tsx") == "tsx"


def test_language_for_path_unknown_returns_none():
    assert language_for_path("foo.txt") is None
    assert language_for_path("readme") is None
    assert language_for_path("foo.unknown") is None


def test_registry_has_python_typescript_tsx():
    assert "python" in LANGUAGES
    assert "typescript" in LANGUAGES
    assert "tsx" in LANGUAGES


def test_tsx_handler_wired_into_registry():
    cfg = LANGUAGES["tsx"]
    assert cfg.handler is TSXHandler


# ----- parse -----------------------------------------------------------------


def test_parse_python_clean():
    src = b"def f():\n    return 1\n"
    tree = parse(src, "python")
    assert tree.root_node.has_error is False


def test_parse_python_syntax_error_flagged():
    src = b"def f(:\n    return\n"
    tree = parse(src, "python")
    assert tree.root_node.has_error is True


def test_parse_unsupported_language_raises():
    with pytest.raises(ValueError):
        parse(b"hello", "klingon")


def test_parse_rejects_str():
    with pytest.raises(TypeError):
        parse("def f(): pass", "python")  # type: ignore[arg-type]


# ----- truncate (Python) -----------------------------------------------------


def _read_fixture(language: str, name: str) -> bytes:
    folder = {"python": "python", "typescript": "typescript", "tsx": "tsx"}[language]
    return (FIXTURES / folder / name).read_bytes()


def test_python_truncate_strips_function_bodies():
    src = _read_fixture("python", "simple.py")
    out = truncate(src, "python")
    text = out.decode()
    assert "def alpha(x):" in text
    assert "def beta(self, y):" in text
    assert "a = x + 1" not in text
    assert "z = y + 1" not in text
    # constants / type hints / imports survive
    assert "MAX_RETRIES = 3" in text
    assert "from pathlib import Path" in text


def test_python_truncated_reparses_clean():
    src = _read_fixture("python", "simple.py")
    out = truncate(src, "python")
    assert parse(out, "python").root_node.has_error is False


def test_python_truncate_idempotent():
    src = _read_fixture("python", "simple.py")
    once = truncate(src, "python")
    twice = truncate(once, "python")
    assert once == twice


def test_python_keep_symbol_top_level():
    src = _read_fixture("python", "simple.py")
    out = truncate(src, "python", keep_symbol="alpha")
    text = out.decode()
    assert "a = x + 1" in text  # alpha kept
    assert "z = y + 1" not in text  # Bar.beta still stubbed


def test_python_keep_symbol_qualified_method():
    src = _read_fixture("python", "simple.py")
    out = truncate(src, "python", keep_symbol="Bar.beta")
    text = out.decode()
    assert "z = y + 1" in text  # Bar.beta kept
    assert "a = x + 1" not in text  # alpha stubbed


def test_python_truncate_nested_classes():
    src = _read_fixture("python", "nested.py")
    out = truncate(src, "python")
    assert parse(out, "python").root_node.has_error is False


def test_python_truncate_async_and_decorated():
    src = _read_fixture("python", "tricky.py")
    out = truncate(src, "python")
    text = out.decode()
    assert "async def async_fn" in text
    assert "@staticmethod" in text
    # Bodies stubbed.
    assert "await asyncio.sleep(0)" not in text
    assert parse(out, "python").root_node.has_error is False


def test_python_truncate_token_reduction():
    src = _read_fixture("python", "simple.py")
    out = truncate(src, "python")
    assert len(out) < len(src) * 0.85, (len(src), len(out))


# ----- truncate (TypeScript) -------------------------------------------------


def test_typescript_truncate_strips_bodies():
    src = _read_fixture("typescript", "simple.ts")
    out = truncate(src, "typescript")
    text = out.decode()
    assert "{ /* ... */ }" in text
    assert "const a = x + 1" not in text
    assert "let z = y + 1" not in text
    # Signatures and types preserved.
    assert "export function alpha(x: number): number" in text
    assert "export interface User {" in text
    assert "export type Id = number;" in text


def test_typescript_truncated_reparses():
    src = _read_fixture("typescript", "simple.ts")
    out = truncate(src, "typescript")
    assert parse(out, "typescript").root_node.has_error is False


def test_typescript_truncate_idempotent():
    src = _read_fixture("typescript", "simple.ts")
    once = truncate(src, "typescript")
    twice = truncate(once, "typescript")
    assert once == twice


def test_typescript_keep_symbol_method():
    src = _read_fixture("typescript", "simple.ts")
    out = truncate(src, "typescript", keep_symbol="Bar.beta")
    text = out.decode()
    assert "let z = y + 1" in text
    assert "const a = x + 1" not in text


def test_typescript_truncate_generics_and_async():
    src = _read_fixture("typescript", "tricky.ts")
    out = truncate(src, "typescript")
    text = out.decode()
    assert "export async function fetchAll<T>" in text
    assert "export interface Repo<T>" in text
    assert "export enum Status" in text
    assert "for (const id of ids)" not in text
    assert parse(out, "typescript").root_node.has_error is False


def test_typescript_truncate_nested_namespaces():
    src = _read_fixture("typescript", "nested.ts")
    out = truncate(src, "typescript")
    assert parse(out, "typescript").root_node.has_error is False


# ----- truncate (TSX dispatch) ----------------------------------------------


def test_tsx_truncate_uses_tsx_grammar():
    src = _read_fixture("tsx", "simple.tsx")
    # If we tried this with the typescript grammar, JSX would fail to parse.
    out = truncate(src, "tsx")
    text = out.decode()
    assert "{ /* ... */ }" in text
    # JSX is inside the bodies; gone after truncation.
    assert "<div className=" not in text
    # Interfaces and class shapes preserved.
    assert "export interface HelloProps" in text
    assert "export class Counter" in text
    assert parse(out, "tsx").root_node.has_error is False


def test_tsx_truncate_idempotent():
    src = _read_fixture("tsx", "simple.tsx")
    once = truncate(src, "tsx")
    twice = truncate(once, "tsx")
    assert once == twice


# ----- symbols ---------------------------------------------------------------


def test_python_symbols_simple():
    src = _read_fixture("python", "simple.py")
    syms = symbols(src, "python")
    by_name = {(s.kind, s.name, s.parent): s for s in syms}
    assert ("function", "alpha", None) in by_name
    assert ("class", "Bar", None) in by_name
    assert ("function", "beta", "Bar") in by_name
    assert ("function", "short", "Bar") in by_name
    assert ("constant", "MAX_RETRIES", None) in by_name
    # Line numbers are 1-indexed.
    alpha = by_name[("function", "alpha", None)]
    assert alpha.start_line >= 1
    assert alpha.end_line >= alpha.start_line


def test_python_symbols_byte_ranges_consistent_with_source():
    src = _read_fixture("python", "simple.py")
    syms = symbols(src, "python")
    for s in syms:
        chunk = src[s.start_byte:s.end_byte]
        assert s.name.encode() in chunk


def test_typescript_symbols_simple():
    src = _read_fixture("typescript", "simple.ts")
    syms = symbols(src, "typescript")
    kinds_names = {(s.kind, s.name) for s in syms}
    assert ("type", "Id") in kinds_names
    assert ("interface", "User") in kinds_names
    assert ("function", "alpha") in kinds_names
    assert ("class", "Bar") in kinds_names
    assert ("method", "beta") in kinds_names
    assert ("method", "short") in kinds_names


def test_unsupported_language_returns_empty_symbols():
    # language_for_path returns None; calling symbols with bogus name returns [].
    assert symbols(b"x = 1", "klingon") == []


# ----- imports ---------------------------------------------------------------


def test_python_imports_simple():
    src = _read_fixture("python", "simple.py")
    imps = imports(src, "python")
    by_module = {i.module: i for i in imps}
    assert "os" in by_module
    assert "pathlib" in by_module
    pathlib_import = by_module["pathlib"]
    assert "Path" in pathlib_import.names


def test_typescript_imports_simple():
    src = _read_fixture("typescript", "simple.ts")
    imps = imports(src, "typescript")
    modules = {i.module for i in imps}
    assert "./foo" in modules
    assert "bar" in modules
    foo = next(i for i in imps if i.module == "./foo")
    assert "foo" in foo.names


def test_typescript_namespace_import_extracts_alias():
    src = _read_fixture("typescript", "tricky.ts")
    imps = imports(src, "typescript")
    ns = next((i for i in imps if i.module == "ns"), None)
    assert ns is not None
    assert "ns" in ns.names


# ----- syntax error fallback ------------------------------------------------


def test_truncate_returns_unchanged_on_syntax_error():
    src = b"def f(:\n    return\n"
    out = truncate(src, "python")
    assert out == src
