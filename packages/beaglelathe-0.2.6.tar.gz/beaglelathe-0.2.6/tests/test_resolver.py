from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from beaglelathe import ripgrep as ripgrep_mod
from beaglelathe.ripgrep import (
    RipgrepNotFound,
    _platform_key,
    _resolve_rg,
)

_KNOWN_KEYS = {
    "darwin-arm64",
    "darwin-x86_64",
    "linux-arm64",
    "linux-x86_64",
    "windows-x86_64",
}


def test_current_platform_is_shipped():
    assert _platform_key() in _KNOWN_KEYS


def _neutralize_system_rg(monkeypatch):
    import shutil

    monkeypatch.setattr(shutil, "which", lambda _: None)
    monkeypatch.setattr(ripgrep_mod, "_FALLBACK_RG_PATHS", ())


def test_resolver_prefers_vendored(monkeypatch):
    _neutralize_system_rg(monkeypatch)
    key = _platform_key()
    path = _resolve_rg()
    assert f"bin/{key}/" in Path(path).as_posix()


def test_resolved_binary_executes(monkeypatch):
    _neutralize_system_rg(monkeypatch)
    path = _resolve_rg()
    subprocess.run([path, "--version"], check=True, capture_output=True)


def test_raises_when_nothing_found(monkeypatch):
    _neutralize_system_rg(monkeypatch)
    monkeypatch.setattr(ripgrep_mod, "_vendored_rg_paths", lambda: [])
    with pytest.raises(RipgrepNotFound):
        _resolve_rg()
