from pathlib import Path

from beaglelathe.ast import parse
from beaglelathe.tools.read import run_read

PY_SAMPLE = '''\
import os
from pathlib import Path

MAX_RETRIES = 3


def alpha(x):
    """docstring"""
    a = x + 1
    b = a * 2
    c = b - 3
    return c


class Bar:
    def beta(self, y):
        z = y + 1
        z = z + 2
        z = z + 3
        return z

    def short(self):
        return 1
'''

TS_SAMPLE = '''\
import { foo } from "./foo";
import bar from "bar";

export type Id = number;

export interface User {
  id: Id;
  name: string;
}

export function alpha(x: number): number {
  const a = x + 1;
  const b = a * 2;
  const c = b - 3;
  return c;
}

export class Bar {
  beta(y: number): number {
    let z = y + 1;
    z = z + 2;
    z = z + 3;
    return z;
  }

  short(): number { return 1; }
}
'''

TSX_SAMPLE = '''\
import React from "react";

export function Hello({ name }: { name: string }) {
  const greeting = "hi";
  const wrapped = greeting + " " + name;
  return <div className="g">{wrapped}</div>;
}
'''


# ----- Default mode (truncated) ---------------------------------------------


def test_python_default_mode_is_truncated(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py"}, tmp_path)
    assert "error" not in out, out
    assert out["language"] == "python"
    assert out["mode"] == "truncated"
    assert "def alpha(x):" in out["content"]
    assert "def beta(self, y):" in out["content"]
    assert "a = x + 1" not in out["content"]
    assert "..." in out["content"]
    assert out["truncated_to_lines"] < out["lines"]


def test_python_truncated_reparses_cleanly(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py"}, tmp_path)
    tree = parse(out["content"].encode("utf-8"), "python")
    assert tree.root_node.has_error is False


def test_python_truncated_is_idempotent(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    first = run_read({"path": "a.py"}, tmp_path)["content"]
    p.write_text(first)
    second = run_read({"path": "a.py"}, tmp_path)["content"]
    assert first == second


def test_python_keep_symbol_preserves_body(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py", "symbol": "Bar.beta"}, tmp_path)
    assert "z = y + 1" in out["content"]  # beta body kept
    assert "a = x + 1" not in out["content"]  # alpha body still stubbed


def test_python_symbols_list_populated(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py"}, tmp_path)
    kinds_names = {(s["kind"], s["name"]) for s in out["symbols"]}
    assert ("function", "alpha") in kinds_names
    assert ("class", "Bar") in kinds_names
    assert ("function", "beta") in kinds_names
    assert ("constant", "MAX_RETRIES") in kinds_names


def test_typescript_default_mode_truncates(tmp_path: Path):
    p = tmp_path / "a.ts"
    p.write_text(TS_SAMPLE)
    out = run_read({"path": "a.ts"}, tmp_path)
    assert out["language"] == "typescript"
    assert out["mode"] == "truncated"
    assert "export function alpha" in out["content"]
    assert "{ /* ... */ }" in out["content"]
    assert "const a = x + 1" not in out["content"]
    # signatures and type-level declarations preserved
    assert "export type Id = number;" in out["content"]
    assert "export interface User {" in out["content"]


def test_typescript_truncated_reparses(tmp_path: Path):
    p = tmp_path / "a.ts"
    p.write_text(TS_SAMPLE)
    out = run_read({"path": "a.ts"}, tmp_path)
    tree = parse(out["content"].encode("utf-8"), "typescript")
    assert tree.root_node.has_error is False


def test_tsx_routes_through_tsx_grammar(tmp_path: Path):
    p = tmp_path / "App.tsx"
    p.write_text(TSX_SAMPLE)
    out = run_read({"path": "App.tsx"}, tmp_path)
    assert out["language"] == "tsx"
    assert out["mode"] == "truncated"
    # JSX content is *inside* the body and gets stubbed.
    assert "<div" not in out["content"]
    assert "{ /* ... */ }" in out["content"]
    # Re-parses with the tsx grammar.
    tree = parse(out["content"].encode("utf-8"), "tsx")
    assert tree.root_node.has_error is False


# ----- mode=full -------------------------------------------------------------


def test_full_mode_returns_verbatim(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py", "mode": "full"}, tmp_path)
    assert out["mode"] == "full"
    assert "a = x + 1" in out["content"]
    assert out["truncated_to_lines"] == out["lines"]


# ----- mode=skeleton ---------------------------------------------------------


def test_skeleton_mode_python(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text(PY_SAMPLE)
    out = run_read({"path": "a.py", "mode": "skeleton"}, tmp_path)
    assert out["mode"] == "skeleton"
    content = out["content"]
    assert "def alpha" in content
    assert "class Bar:" in content
    assert "import os" in content
    # body lines are gone
    assert "a = x + 1" not in content
    assert "return c" not in content


def test_skeleton_mode_typescript(tmp_path: Path):
    p = tmp_path / "a.ts"
    p.write_text(TS_SAMPLE)
    out = run_read({"path": "a.ts", "mode": "skeleton"}, tmp_path)
    assert out["mode"] == "skeleton"
    content = out["content"]
    assert "export function alpha" in content
    assert "export interface User" in content
    assert "const a = x + 1" not in content


# ----- Unsupported language --------------------------------------------------


def test_plain_file_unsupported_returns_full(tmp_path: Path):
    p = tmp_path / "notes.txt"
    p.write_text("hello\nworld\n")
    out = run_read({"path": "notes.txt"}, tmp_path)
    assert out["language"] == "plain"
    assert out["mode"] == "full"
    assert out["content"] == "hello\nworld\n"
    assert "note" in out


# ----- Syntax error fallback -------------------------------------------------


def test_syntax_error_returns_full_with_note(tmp_path: Path):
    p = tmp_path / "broken.py"
    p.write_text("def foo(\n    return 1\n")
    out = run_read({"path": "broken.py"}, tmp_path)
    # truncate() bails on syntax errors and returns source unchanged; the read
    # tool detects this and surfaces mode=full plus a note.
    assert out["mode"] == "full"
    assert "note" in out
    assert "syntax error" in out["note"].lower()


# ----- Path safety -----------------------------------------------------------


def test_invalid_mode_rejected(tmp_path: Path):
    p = tmp_path / "a.py"
    p.write_text("def f(): pass\n")
    out = run_read({"path": "a.py", "mode": "weird"}, tmp_path)
    assert "error" in out
    assert "mode must be" in out["error"]


def test_path_outside_workspace(tmp_path: Path):
    out = run_read({"path": "../escape.py"}, tmp_path)
    assert out.get("error") == "path outside workspace"


def test_file_not_found(tmp_path: Path):
    out = run_read({"path": "nope.py"}, tmp_path)
    assert out.get("error") == "file not found"


def test_binary_file_rejected(tmp_path: Path):
    p = tmp_path / "bin.py"
    p.write_bytes(b"\x00\x01\x02hello\x00more")
    out = run_read({"path": "bin.py"}, tmp_path)
    assert out.get("error") == "binary file"

