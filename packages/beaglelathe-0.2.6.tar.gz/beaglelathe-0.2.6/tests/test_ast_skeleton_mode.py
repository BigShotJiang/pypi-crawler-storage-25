"""Tests for the `read` tool's mode=skeleton fallback path.

mode=skeleton is the cheapest read mode — regex-picked declaration lines only.
It exists as a fallback for files too large for the AST engine and for
unsupported languages. test_ast_engine.py covers the AST path; test_read.py
covers the dispatch wiring. This file isolates regressions in the skeleton
extractor itself: empty files, undeclared content, mixed encodings, the
unsupported-language pattern, and the very-large-file path.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from beaglelathe.tools.read import (
    MAX_OUTPUT_CHARS,
    _GENERIC_SKELETON_KEYWORDS,
    _SKELETON_PATTERNS,
    _skeleton,
    run_read,
)


# ── Internal _skeleton() — pattern matching ───────────────────────────────────


def test_skeleton_python_keeps_def_and_class_lines_only():
    src = (
        "import os\n"
        "from pathlib import Path\n"
        "\n"
        "X = 1\n"  # constants are NOT picked by python skeleton pattern
        "def alpha():\n"
        "    body = 1\n"
        "    return body\n"
        "class Bar:\n"
        "    def beta(self):\n"
        "        z = 1\n"
        "        return z\n"
    )
    out = _skeleton(src, "python")
    assert "import os" in out
    assert "from pathlib import Path" in out
    assert "def alpha():" in out
    assert "class Bar:" in out
    assert "def beta(self):" in out
    # Bodies stripped.
    assert "body = 1" not in out
    assert "return body" not in out
    assert "z = 1" not in out
    # The "X = 1" constant is not declared by `def|class|import|from|@`, so
    # the skeleton pattern omits it. Pin that.
    assert "X = 1" not in out


def test_skeleton_python_keeps_decorator_lines():
    src = "@staticmethod\ndef f():\n    return 1\n"
    out = _skeleton(src, "python")
    assert "@staticmethod" in out
    assert "def f():" in out
    assert "return 1" not in out


def test_skeleton_typescript_keeps_declarations():
    src = (
        'import { foo } from "./foo";\n'
        "export type Id = number;\n"
        "export interface User { id: Id; }\n"
        "export function alpha(x: number): number {\n"
        "  return x + 1;\n"
        "}\n"
        "class Bar {\n"
        "  beta() { return 1; }\n"
        "}\n"
    )
    out = _skeleton(src, "typescript")
    assert 'import { foo } from "./foo";' in out
    assert "export type Id = number;" in out
    assert "export interface User { id: Id; }" in out
    assert "export function alpha(x: number): number {" in out
    assert "class Bar {" in out
    assert "return x + 1;" not in out
    assert "beta() { return 1; }" not in out


def test_skeleton_tsx_pattern_aliases_typescript():
    """tsx files should match the same declaration keywords as ts."""
    assert _SKELETON_PATTERNS["tsx"] is not None
    src = 'import React from "react";\nexport function App() { return null; }\n'
    out = _skeleton(src, "tsx")
    assert 'import React from "react";' in out
    assert "export function App() { return null; }" in out


def test_skeleton_unsupported_language_uses_generic_keywords():
    """Unknown languages fall back to the generic keyword regex — must still
    pull out def/class/function/etc lines."""
    src = (
        "package foo\n"
        "import bar\n"
        "fn answer() -> i32 {\n"
        "    return 42;\n"
        "}\n"
        "struct Cat {}\n"
        "trait Animal {}\n"
    )
    out = _skeleton(src, "rust")  # rust is not in _SKELETON_PATTERNS
    assert "import bar" in out
    assert "fn answer() -> i32 {" in out
    assert "struct Cat {}" in out
    assert "trait Animal {}" in out
    assert "return 42;" not in out


def test_skeleton_unknown_language_string_uses_generic_pattern():
    """Passing None as language must also route through the generic pattern."""
    src = "def x(): return 1\nclass Y: pass\n"
    out = _skeleton(src, None)
    assert "def x(): return 1" in out
    assert "class Y: pass" in out


# ── Files with no parseable declarations ──────────────────────────────────────


def test_skeleton_empty_file_returns_empty_string():
    assert _skeleton("", "python") == ""
    assert _skeleton("", None) == ""


def test_skeleton_only_comments_returns_empty():
    src = "# top comment\n# another\n# all comments\n"
    out = _skeleton(src, "python")
    assert out == ""


def test_skeleton_only_data_returns_empty():
    src = "x = 1\ny = 2\nz = 3\n"
    out = _skeleton(src, "python")
    # None of those lines match the python skeleton pattern.
    assert out == ""


def test_skeleton_preserves_trailing_newline_when_lines_kept():
    out = _skeleton("def f(): pass\n", "python")
    assert out.endswith("\n")


def test_skeleton_no_trailing_newline_when_nothing_matched():
    out = _skeleton("not a declaration\n", "python")
    assert out == ""


# ── Generic pattern explicit checks ──────────────────────────────────────────


@pytest.mark.parametrize(
    "line",
    [
        "def x():",
        "class X:",
        "function x() {",
        "interface X {",
        "type X = number;",
        "enum X { A, B }",
        "import x from 'y';",
        "from y import x",
        "export const X = 1;",
        "fn x() {",
        "func x() {",
        "impl X for Y {",
        "trait X {",
        "struct X {}",
        "module X {",
        "namespace X {",
        "public class X",
        "private void X()",
        "protected int X",
        "@Component",
    ],
)
def test_generic_skeleton_pattern_matches_common_declarations(line):
    assert _GENERIC_SKELETON_KEYWORDS.match(line) is not None


@pytest.mark.parametrize(
    "line",
    [
        "x = 1",
        "    body",
        "return x",
        "// a comment",
        "  for (let i = 0; i < n; i++)",
    ],
)
def test_generic_skeleton_pattern_rejects_non_declarations(line):
    assert _GENERIC_SKELETON_KEYWORDS.match(line) is None


# ── Large-file fallback through run_read(mode='skeleton') ────────────────────


def test_run_read_skeleton_handles_very_large_file_via_hard_cap(tmp_path: Path):
    """A file whose skeleton output exceeds MAX_OUTPUT_CHARS must be capped."""

    # Build a file with so many declaration lines that the skeleton output
    # blows past the hard cap. Each line is "def fn_<n>(): pass with much padding".
    pad = "x" * 80  # ~ 100 bytes per line
    n_lines = (MAX_OUTPUT_CHARS // 60) + 500  # comfortably over the 200k cap
    src = "\n".join(f"def fn_{i}_{pad}():" for i in range(n_lines)) + "\n"
    target = tmp_path / "huge.py"
    target.write_text(src)
    result = run_read({"path": "huge.py", "mode": "skeleton"}, tmp_path)
    assert result["mode"] == "skeleton"
    assert result["size_capped"] is True
    # The elision marker from _hard_cap must show up in the output.
    assert "chars elided" in result["content"]


def test_run_read_skeleton_on_file_with_no_declarations(tmp_path: Path):
    target = tmp_path / "nothing.py"
    target.write_text("# just\n# comments\n# everywhere\nx = 1\n")
    result = run_read({"path": "nothing.py", "mode": "skeleton"}, tmp_path)
    assert result["mode"] == "skeleton"
    assert result["content"] == ""
    assert result["truncated_to_lines"] == 0
    # lines (total) reflects the real file, not the skeleton output.
    assert result["lines"] == 4


def test_run_read_skeleton_round_trip_basic(tmp_path: Path):
    target = tmp_path / "demo.py"
    target.write_text("import os\ndef foo():\n    return 1\n")
    result = run_read({"path": "demo.py", "mode": "skeleton"}, tmp_path)
    assert result["mode"] == "skeleton"
    assert "import os" in result["content"]
    assert "def foo():" in result["content"]
    assert "return 1" not in result["content"]


# ── Mixed encodings ──────────────────────────────────────────────────────────


def test_skeleton_handles_utf8_with_non_ascii_identifiers(tmp_path: Path):
    """Unicode identifiers must survive the regex match."""

    target = tmp_path / "uni.py"
    target.write_text("def café():\n    return 1\nclass Naïve: pass\n", encoding="utf-8")
    result = run_read({"path": "uni.py", "mode": "skeleton"}, tmp_path)
    assert "def café():" in result["content"]
    assert "class Naïve: pass" in result["content"]


def test_run_read_rejects_non_utf8_before_reaching_skeleton(tmp_path: Path):
    """Latin-1 bytes that aren't valid utf-8 must error out before skeleton runs."""

    target = tmp_path / "latin.py"
    target.write_bytes(b"def caf\xe9():\n    return 1\n")
    result = run_read({"path": "latin.py", "mode": "skeleton"}, tmp_path)
    assert "error" in result
    assert "utf-8" in result["error"]


def test_run_read_skeleton_rejects_binary_file(tmp_path: Path):
    """Files with embedded NULs are flagged as binary before any decode runs."""

    target = tmp_path / "blob.py"
    target.write_bytes(b"def f():\n\x00\nreturn 1\n")
    result = run_read({"path": "blob.py", "mode": "skeleton"}, tmp_path)
    assert result == {"error": "binary file"}


def test_skeleton_tolerates_crlf_line_endings():
    src = "def alpha():\r\n    return 1\r\ndef beta():\r\n    return 2\r\n"
    out = _skeleton(src, "python")
    # splitlines() handles \r\n, so both defs appear in the skeleton.
    assert "def alpha():" in out
    assert "def beta():" in out
    assert "return 1" not in out
