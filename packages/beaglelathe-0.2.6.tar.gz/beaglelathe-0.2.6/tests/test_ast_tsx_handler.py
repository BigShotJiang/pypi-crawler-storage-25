"""TSX-handler-specific regressions.

test_ast_engine.py already covers the happy path. This file pins behavior that's
specific to .tsx — JSX in bodies, default exports, type-only imports, generic
arrow functions, and graceful handling of malformed JSX — so a regression in
any of those shows up here pointing at the TSX handler instead of a generic
'something in the AST broke' failure elsewhere.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from beaglelathe.ast import LANGUAGES, language_for_path, parse, symbols, truncate
from beaglelathe.ast.handlers._base import LanguageHandler
from beaglelathe.ast.handlers.tsx import TSXHandler


def _trunc(src: str) -> str:
    return truncate(src.encode(), "tsx").decode()


# ── Handler wiring ────────────────────────────────────────────────────────────


def test_tsx_handler_subclasses_language_handler():
    """If the inheritance breaks, the generic engine won't find the class."""
    assert issubclass(TSXHandler, LanguageHandler)


def test_tsx_handler_returns_bytes():
    out = TSXHandler.truncate(b"const x: number = 1;\n", LANGUAGES["tsx"])
    assert isinstance(out, bytes)


def test_tsx_dispatch_matches_extension():
    assert language_for_path("Component.tsx") == "tsx"
    assert language_for_path("Component.Test.tsx") == "tsx"


# ── JSX in component bodies ──────────────────────────────────────────────────


def test_jsx_function_component_body_is_stubbed():
    src = """\
import React from "react";

export function Hello({ name }: { name: string }) {
  const greeting = "hi";
  const wrapped = greeting + " " + name;
  return <div className="g">{wrapped}</div>;
}
"""
    out = _trunc(src)
    # Signature kept.
    assert "export function Hello({ name }: { name: string })" in out
    # JSX from the body gone.
    assert "<div className=" not in out
    assert "{wrapped}" not in out
    # Reparses cleanly so consumers can build on the truncated form.
    assert parse(out.encode(), "tsx").root_node.has_error is False


def test_jsx_class_component_render_body_is_stubbed():
    src = """\
import React from "react";

export class Counter extends React.Component<{}, { n: number }> {
  state = { n: 0 };

  render() {
    return <button onClick={() => this.setState({ n: this.state.n + 1 })}>{this.state.n}</button>;
  }
}
"""
    out = _trunc(src)
    assert "export class Counter" in out
    assert "render()" in out
    # The arrow-callback'd JSX from inside render must be gone.
    assert "this.setState" not in out
    assert "<button" not in out


def test_jsx_fragments_in_body_are_stubbed():
    src = """\
export function List({ items }: { items: string[] }) {
  return <>{items.map(i => <span key={i}>{i}</span>)}</>;
}
"""
    out = _trunc(src)
    assert "export function List" in out
    assert "<span" not in out
    assert "<>" not in out


# ── Default exports ──────────────────────────────────────────────────────────


def test_default_exported_function_body_is_stubbed():
    src = """\
export default function App() {
  const x = 1;
  return <div>{x}</div>;
}
"""
    out = _trunc(src)
    assert "export default function App()" in out
    assert "<div>" not in out
    assert parse(out.encode(), "tsx").root_node.has_error is False


def test_default_exported_arrow_via_const_kept_intact():
    """Arrow expressions bound to a const aren't `function_declaration`s — bodies
    inside arrows aren't statement_block nodes, so the truncator leaves them
    alone. Pin that so a future change doesn't silently start stubbing them."""
    src = """\
const App = () => <div>x</div>;
export default App;
"""
    out = _trunc(src)
    assert "<div>x</div>" in out


# ── Type-only imports ────────────────────────────────────────────────────────


def test_type_only_import_survives_truncation():
    src = """\
import type { ReactNode } from "react";
import { useState } from "react";

export function Wrap({ children }: { children: ReactNode }) {
  const [n, setN] = useState(0);
  return <div onClick={() => setN(n + 1)}>{children}</div>;
}
"""
    out = _trunc(src)
    assert 'import type { ReactNode } from "react";' in out
    assert 'import { useState } from "react";' in out


def test_inline_type_only_import_specifier_survives():
    """`import { type Foo, bar }` — TS 4.5+ inline type-only modifier."""
    src = """\
import { type Props, useEffect } from "./lib";

export function X(p: Props) {
  const x = 1;
  return <div>{x}</div>;
}
"""
    out = _trunc(src)
    assert "import { type Props, useEffect } from" in out


# ── Generic arrow functions ──────────────────────────────────────────────────


def test_generic_arrow_function_signature_survives():
    """Generic arrow bodies are expressions (not block statements) so the
    truncator skips them. The whole declaration must remain verbatim."""
    src = """\
const identity = <T,>(x: T): T => x;
const pair = <A, B>(a: A, b: B): [A, B] => [a, b];
"""
    out = _trunc(src)
    assert "const identity = <T,>(x: T): T => x;" in out
    assert "const pair = <A, B>(a: A, b: B): [A, B] => [a, b];" in out


def test_generic_function_declaration_body_is_stubbed():
    src = """\
export function map<T, U>(xs: T[], f: (x: T) => U): U[] {
  const out: U[] = [];
  for (const x of xs) out.push(f(x));
  return out;
}
"""
    out = _trunc(src)
    assert "export function map<T, U>(xs: T[], f: (x: T) => U): U[]" in out
    assert "for (const x of xs)" not in out
    assert "out.push" not in out


# ── Malformed JSX ────────────────────────────────────────────────────────────


def test_malformed_jsx_falls_back_to_unchanged_source():
    """The generic truncator bails (returns source unchanged) when the tree has
    parse errors. The handler must not crash and must preserve the original."""
    bad = b"export function Bad() { return <div><span></div>; }\n"
    out = TSXHandler.truncate(bad, LANGUAGES["tsx"])
    assert out == bad


def test_unclosed_jsx_does_not_raise():
    bad = b"export function Bad() { return <div>; }\n"
    # Must not raise — the engine returns source unchanged on parse failure.
    assert TSXHandler.truncate(bad, LANGUAGES["tsx"]) == bad


# ── Symbols extracted from .tsx files ────────────────────────────────────────


def test_symbols_extracted_from_tsx_jsx_file():
    src = (
        Path(__file__).parent
        / "fixtures"
        / "ast"
        / "tsx"
        / "simple.tsx"
    ).read_bytes()
    syms = symbols(src, "tsx")
    by_kind_name = {(s.kind, s.name) for s in syms}
    assert ("interface", "HelloProps") in by_kind_name
    assert ("function", "Hello") in by_kind_name
    assert ("class", "Counter") in by_kind_name


@pytest.mark.parametrize(
    "fragment",
    [
        "export function A() { return <div/>; }\n",
        "export function B(): JSX.Element { return <span>x</span>; }\n",
        "export const C = () => <p>hi</p>;\n",
    ],
)
def test_idempotent_truncation_on_tsx_fragments(fragment):
    once = truncate(fragment.encode(), "tsx")
    twice = truncate(once, "tsx")
    assert once == twice
