import shutil
from pathlib import Path

import pytest

from beaglelathe.tools.run_tests import run_tests


def test_pytest_pass(tmp_path: Path):
    (tmp_path / "test_a.py").write_text("def test_ok():\n    assert 1 == 1\n")
    out = run_tests({}, tmp_path)
    assert out["framework"] == "pytest"
    assert out["summary"]["passed"] == 1
    assert out["summary"]["failed"] == 0
    assert out["failures"] == []
    assert out["truncated_failures"] is False


def test_pytest_fail(tmp_path: Path):
    (tmp_path / "test_a.py").write_text(
        "def test_bad():\n    x = 1\n    assert x == 2\n"
    )
    out = run_tests({}, tmp_path)
    assert out["summary"]["failed"] == 1
    assert out["summary"]["passed"] == 0
    assert len(out["failures"]) == 1
    f = out["failures"][0]
    assert f["name"].endswith("::test_bad")
    assert f["file"] == "test_a.py"
    assert f["line"] == 3
    assert f["message"] is not None
    assert "assert" in (f["traceback_tail"] or "").lower()
    assert f["source_excerpt"] is not None
    assert "assert x == 2" in f["source_excerpt"]


def test_pytest_skip(tmp_path: Path):
    (tmp_path / "test_a.py").write_text(
        "import pytest\n\ndef test_skipped():\n    pytest.skip('nope')\n"
    )
    out = run_tests({}, tmp_path)
    assert out["summary"]["skipped"] == 1
    assert out["summary"]["failed"] == 0
    assert out["failures"] == []


def test_no_framework_detected(tmp_path: Path):
    out = run_tests({}, tmp_path)
    assert "error" in out
    assert "detect" in out["error"]


def test_explicit_command(tmp_path: Path):
    out = run_tests({"command": "echo no tests"}, tmp_path)
    # echo output is unparseable as a test framework; we should still get a
    # structured response with exit_code and summary zeros.
    assert "error" not in out
    assert out["framework"] == "unknown"
    assert out["summary"]["total"] == 0
    assert out["exit_code"] == 0
    assert "no tests" in out["stdout"]


def test_max_failures(tmp_path: Path):
    body = "".join(
        f"def test_f{i}():\n    assert 0\n\n" for i in range(5)
    )
    (tmp_path / "test_a.py").write_text(body)
    out = run_tests({"max_failures": 2}, tmp_path)
    assert out["summary"]["failed"] == 5
    assert len(out["failures"]) == 2
    assert out["truncated_failures"] is True


def test_pytest_pattern_filter(tmp_path: Path):
    (tmp_path / "test_a.py").write_text(
        "def test_keep():\n    assert True\n\n"
        "def test_skip_me():\n    assert False\n"
    )
    out = run_tests({"pattern": "test_keep"}, tmp_path)
    # -k filter excludes test_skip_me from collection entirely.
    assert out["summary"]["passed"] == 1
    assert out["summary"]["failed"] == 0


def test_pytest_collection_error(tmp_path: Path):
    (tmp_path / "test_a.py").write_text("import nonexistent_module_xyz\n")
    out = run_tests({}, tmp_path)
    # Collection error: zero tests ran, pytest exits non-zero, error_output set.
    assert out["summary"]["total"] == 0
    assert "error_output" in out


def test_path_argument_restricts_tests(tmp_path: Path):
    (tmp_path / "test_a.py").write_text("def test_a():\n    assert True\n")
    (tmp_path / "test_b.py").write_text("def test_b():\n    assert False\n")
    out = run_tests({"path": "test_a.py"}, tmp_path)
    assert out["summary"]["passed"] == 1
    assert out["summary"]["failed"] == 0


def test_explicit_command_not_found(tmp_path: Path):
    out = run_tests({"command": "definitely-not-a-real-binary-xyz"}, tmp_path)
    assert "error" in out
    assert "not found" in out["error"]


def test_pytest_runs_when_bare_pytest_not_on_path(tmp_path: Path, monkeypatch):
    """Regression: pipx/uv installs have `pytest` importable but not on PATH.

    The runner must invoke pytest via `sys.executable -m pytest`, not the bare
    `pytest` binary, so it works in any env where the running Python can
    `import pytest`.
    """
    # Strip pytest off PATH; /usr/bin almost never has a `pytest` binary.
    monkeypatch.setenv("PATH", "/usr/bin")
    assert shutil.which("pytest") is None, (
        "test setup invalid: bare `pytest` still found on PATH=/usr/bin"
    )
    (tmp_path / "test_a.py").write_text("def test_ok():\n    assert 1 == 1\n")
    out = run_tests({}, tmp_path)
    assert "error" not in out, f"runner returned error: {out.get('error')!r}"
    assert out["framework"] == "pytest"
    assert out["summary"]["passed"] == 1
    assert out["summary"]["failed"] == 0


@pytest.mark.skipif(shutil.which("go") is None, reason="go toolchain not installed")
def test_go_framework_detected(tmp_path: Path):
    (tmp_path / "go.mod").write_text("module example.com/x\n\ngo 1.21\n")
    (tmp_path / "x_test.go").write_text(
        'package x\n\nimport "testing"\n\nfunc TestPass(t *testing.T) {}\n'
    )
    (tmp_path / "x.go").write_text("package x\n")
    out = run_tests({}, tmp_path)
    assert out["framework"] == "go test"
    assert out["summary"]["passed"] >= 1
