class Outer:
    class Inner:
        def method(self):
            return 1

    def outer_method(self):
        def closure():
            return 2
        return closure()
