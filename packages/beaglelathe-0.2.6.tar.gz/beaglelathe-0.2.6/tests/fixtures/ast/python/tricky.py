import asyncio
from typing import Optional


@staticmethod
def decorated(x: int) -> int:
    return x * 2


async def async_fn(coro: asyncio.Future) -> Optional[int]:
    await asyncio.sleep(0)
    return 42


class Generic:
    async def amethod(self, n: int) -> int:
        result = n
        for _ in range(n):
            result += 1
        return result
