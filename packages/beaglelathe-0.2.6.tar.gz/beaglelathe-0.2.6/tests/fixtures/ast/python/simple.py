"""A small Python file: imports, a constant, a function, a class with two methods."""

import os
from pathlib import Path

MAX_RETRIES = 3


def alpha(x):
    """Return x + 1."""
    a = x + 1
    b = a * 2
    return b


class Bar:
    def beta(self, y):
        z = y + 1
        z = z * 2
        return z

    def short(self):
        return 1
