import { foo } from "./foo";
import bar from "bar";

export type Id = number;

export interface User {
  id: Id;
  name: string;
}

export function alpha(x: number): number {
  const a = x + 1;
  const b = a * 2;
  return b;
}

export class Bar {
  beta(y: number): number {
    let z = y + 1;
    z = z * 2;
    return z;
  }

  short(): number { return 1; }
}
