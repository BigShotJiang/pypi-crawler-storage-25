import * as ns from "ns";

export type Pair<A, B> = { left: A; right: B };

export interface Repo<T> {
  find(id: string): Promise<T | null>;
}

export async function fetchAll<T>(repo: Repo<T>, ids: string[]): Promise<T[]> {
  const out: T[] = [];
  for (const id of ids) {
    const item = await repo.find(id);
    if (item !== null) out.push(item);
  }
  return out;
}

export enum Status {
  Pending,
  Done,
}
