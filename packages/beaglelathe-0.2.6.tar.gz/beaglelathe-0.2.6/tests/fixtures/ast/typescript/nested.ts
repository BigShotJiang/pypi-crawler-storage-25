export namespace Outer {
  export class Inner {
    method(): number {
      return 1;
    }
  }
}

export class Wrapper {
  outer(): number {
    function closure() {
      return 2;
    }
    return closure();
  }
}
