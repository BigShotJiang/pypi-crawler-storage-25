import React from "react";

export interface HelloProps {
  name: string;
}

export function Hello({ name }: HelloProps) {
  const greeting = "hi";
  return <div className="g">{greeting} {name}</div>;
}

export class Counter extends React.Component<{}, { n: number }> {
  state = { n: 0 };

  render() {
    return <button onClick={() => this.setState({ n: this.state.n + 1 })}>{this.state.n}</button>;
  }
}
