import shutil
import subprocess
from pathlib import Path

import pytest

from beaglelathe.tools.git_ops import (
    run_changed_files,
    run_git_diff,
    run_git_status,
)


pytestmark = pytest.mark.skipif(
    shutil.which("git") is None, reason="git binary not on PATH"
)


def _init_repo(tmp_path: Path) -> None:
    def g(*args: str) -> None:
        subprocess.run(["git", *args], cwd=tmp_path, check=True, capture_output=True)

    g("init", "--initial-branch=main")
    g("config", "user.email", "test@example.com")
    g("config", "user.name", "Test")
    g("config", "commit.gpgsign", "false")
    (tmp_path / "README.md").write_text("# initial\n")
    g("add", "README.md")
    g("commit", "-m", "initial")


# ---------------------------------------------------------------------------
# git_status
# ---------------------------------------------------------------------------


def test_git_status_clean(tmp_path: Path):
    _init_repo(tmp_path)
    out = run_git_status({}, tmp_path)
    assert "error" not in out
    assert out["branch"] == "main"
    assert out["staged"] == []
    assert out["unstaged"] == []
    assert out["untracked"] == []
    assert out["ahead"] == 0
    assert out["behind"] == 0


def test_git_status_with_changes(tmp_path: Path):
    _init_repo(tmp_path)
    (tmp_path / "README.md").write_text("# changed\n")
    (tmp_path / "new_staged.txt").write_text("staged\n")
    subprocess.run(["git", "add", "new_staged.txt"], cwd=tmp_path, check=True)
    (tmp_path / "scratch.txt").write_text("untracked\n")

    out = run_git_status({}, tmp_path)
    assert "README.md" in out["unstaged"]
    assert "new_staged.txt" in out["staged"]
    assert "scratch.txt" in out["untracked"]


def test_git_status_renamed(tmp_path: Path):
    _init_repo(tmp_path)
    subprocess.run(["git", "mv", "README.md", "RENAMED.md"], cwd=tmp_path, check=True)
    out = run_git_status({}, tmp_path)
    assert any(r["to"] == "RENAMED.md" for r in out["renamed"])


def test_git_status_detached_head(tmp_path: Path):
    _init_repo(tmp_path)
    sha = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=tmp_path, check=True, capture_output=True, text=True
    ).stdout.strip()
    subprocess.run(["git", "checkout", sha], cwd=tmp_path, check=True, capture_output=True)

    out = run_git_status({}, tmp_path)
    assert out.get("detached") is True
    assert out.get("head_sha", "").startswith(sha[:7])
    assert out["branch"] is None


def test_git_status_not_a_repo(tmp_path: Path):
    out = run_git_status({}, tmp_path)
    assert "error" in out
    assert "not a git repository" in out["error"]


def test_git_status_include_untracked_false(tmp_path: Path):
    _init_repo(tmp_path)
    (tmp_path / "scratch.txt").write_text("x\n")
    out = run_git_status({"include_untracked": False}, tmp_path)
    assert out["untracked"] == []


# ---------------------------------------------------------------------------
# git_diff
# ---------------------------------------------------------------------------


def test_git_diff_unstaged(tmp_path: Path):
    _init_repo(tmp_path)
    (tmp_path / "README.md").write_text("# initial\nline2\n")

    out = run_git_diff({}, tmp_path)
    assert "error" not in out
    assert len(out["files"]) == 1
    f = out["files"][0]
    assert f["path"] == "README.md"
    assert f["status"] == "modified"
    assert f["additions"] == 1
    assert f["deletions"] == 0
    assert len(f["hunks"]) == 1
    h = f["hunks"][0]
    assert h["new_lines"] >= 2
    assert "+line2" in h["content"]


def test_git_diff_staged(tmp_path: Path):
    _init_repo(tmp_path)
    (tmp_path / "new.txt").write_text("hello\n")
    subprocess.run(["git", "add", "new.txt"], cwd=tmp_path, check=True)

    out = run_git_diff({"staged": True}, tmp_path)
    assert len(out["files"]) == 1
    f = out["files"][0]
    assert f["path"] == "new.txt"
    assert f["status"] == "added"
    assert f["additions"] == 1


def test_git_diff_added_file(tmp_path: Path):
    _init_repo(tmp_path)
    (tmp_path / "new.txt").write_text("a\nb\nc\n")
    subprocess.run(["git", "add", "new.txt"], cwd=tmp_path, check=True)
    out = run_git_diff({"staged": True}, tmp_path)
    f = out["files"][0]
    assert f["status"] == "added"
    assert f["additions"] == 3


def test_git_diff_deleted_file(tmp_path: Path):
    _init_repo(tmp_path)
    subprocess.run(["git", "rm", "README.md"], cwd=tmp_path, check=True, capture_output=True)
    out = run_git_diff({"staged": True}, tmp_path)
    assert any(f["status"] == "deleted" for f in out["files"])


def test_git_diff_unknown_ref(tmp_path: Path):
    _init_repo(tmp_path)
    out = run_git_diff({"from_ref": "no-such-ref-xyz"}, tmp_path)
    assert "error" in out
    assert "unknown ref" in out["error"]


def test_git_diff_max_hunks_truncates(tmp_path: Path):
    _init_repo(tmp_path)
    # Create a file with many separated changes.
    body = "\n".join(f"line {i}" for i in range(60)) + "\n"
    (tmp_path / "big.txt").write_text(body)
    subprocess.run(["git", "add", "big.txt"], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "commit", "-m", "add big"], cwd=tmp_path, check=True, capture_output=True
    )
    # Edit every 10th line so we get multiple separate hunks (3-line context
    # means changes <7 lines apart merge into one hunk).
    new_body = "\n".join(
        (f"line {i}!" if i % 10 == 0 and i > 0 else f"line {i}") for i in range(60)
    ) + "\n"
    (tmp_path / "big.txt").write_text(new_body)

    out = run_git_diff({"max_hunks_per_file": 2}, tmp_path)
    f = out["files"][0]
    assert len(f["hunks"]) <= 2
    assert out["truncated_hunks"] is True


# ---------------------------------------------------------------------------
# changed_files
# ---------------------------------------------------------------------------


def test_changed_files_against_main(tmp_path: Path):
    _init_repo(tmp_path)
    subprocess.run(["git", "checkout", "-b", "feature"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "added.txt").write_text("hello\nworld\n")
    subprocess.run(["git", "add", "added.txt"], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "commit", "-m", "add file"], cwd=tmp_path, check=True, capture_output=True
    )

    out = run_changed_files({}, tmp_path)
    assert out["branch_compared"] == "main"
    paths = [f["path"] for f in out["files"]]
    assert "added.txt" in paths
    added = next(f for f in out["files"] if f["path"] == "added.txt")
    assert added["additions"] == 2
    assert added["status"] == "added"
    assert out["totals"]["files"] == 1


def test_changed_files_no_changes(tmp_path: Path):
    _init_repo(tmp_path)
    out = run_changed_files({"branch": "main"}, tmp_path)
    assert out["files"] == []
    assert out["totals"] == {"files": 0, "additions": 0, "deletions": 0}


def test_changed_files_unknown_branch(tmp_path: Path):
    _init_repo(tmp_path)
    out = run_changed_files({"branch": "no-such-branch"}, tmp_path)
    assert "error" in out
    assert "unknown ref" in out["error"]


def test_changed_files_includes_uncommitted(tmp_path: Path):
    _init_repo(tmp_path)
    subprocess.run(["git", "checkout", "-b", "feature"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "wip.txt").write_text("wip\n")  # untracked, uncommitted
    out = run_changed_files({"include_uncommitted": True}, tmp_path)
    paths = [f["path"] for f in out["files"]]
    assert "wip.txt" in paths


def test_changed_files_excludes_uncommitted(tmp_path: Path):
    _init_repo(tmp_path)
    subprocess.run(["git", "checkout", "-b", "feature"], cwd=tmp_path, check=True, capture_output=True)
    (tmp_path / "wip.txt").write_text("wip\n")
    out = run_changed_files({"include_uncommitted": False}, tmp_path)
    paths = [f["path"] for f in out["files"]]
    assert "wip.txt" not in paths


def test_changed_files_not_a_repo(tmp_path: Path):
    out = run_changed_files({}, tmp_path)
    assert "error" in out
    assert "not a git repository" in out["error"]
