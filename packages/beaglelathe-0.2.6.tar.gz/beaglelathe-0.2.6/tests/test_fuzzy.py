from beaglelathe.fuzzy import fuzzy_find, normalize


def test_normalize_line_endings():
    out, offsets = normalize("a\r\nb\rc\nd")
    assert out == "a\nb\nc\nd"
    assert len(offsets) == len(out)


def test_normalize_collapse_whitespace_within_line():
    out, _ = normalize("foo   \t  bar")
    assert out == "foo bar"


def test_normalize_strip_trailing_whitespace_per_line():
    out, _ = normalize("foo   \nbar")
    assert out == "foo\nbar"


def test_normalize_smart_quotes_and_dashes_and_ellipsis():
    out, _ = normalize("‘hi’ “yo” — – …")
    assert out == "'hi' \"yo\" - - ..."


def test_normalize_offset_map_round_trip():
    src = "foo  bar"
    out, offsets = normalize(src)
    assert out == "foo bar"
    # The 'b' in normalized output corresponds to 'b' in original at offset 5.
    bi = out.index("b")
    assert src[offsets[bi]] == "b"


def test_fuzzy_find_exact():
    h = "alpha bravo charlie delta"
    n = "bravo"
    res = fuzzy_find(h, n)
    assert res is not None and res != "ambiguous"
    s, e, score = res
    assert h[s:e] == "bravo"
    assert score == 100


def test_fuzzy_find_one_typo():
    h = "alpha brovo charlie delta"
    n = "bravo"
    res = fuzzy_find(h, n, min_score=80)
    assert res is not None and res != "ambiguous"
    s, e, score = res
    assert h[s:e] == "brovo"
    assert score >= 80


def test_fuzzy_find_no_match():
    assert fuzzy_find("completely unrelated text here", "xyzzy") is None


def test_fuzzy_find_ambiguous():
    # Two identical occurrences => non-overlapping near-best ties.
    h = "foo bravo bar bravo baz"
    res = fuzzy_find(h, "bravo")
    assert res == "ambiguous"
