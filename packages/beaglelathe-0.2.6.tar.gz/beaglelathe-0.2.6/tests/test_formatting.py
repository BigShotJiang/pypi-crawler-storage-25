"""Tests for the human-readable result formatter.

Each renderer should preserve every load-bearing field in the dict it
receives — paths, line numbers, stdout, diffs, summaries — because the text
is what the model and the UI see. These tests also guard the fallback path
(JSON) and the shared `_notice` / error handling.
"""

from __future__ import annotations

import json

from beaglelathe.formatting import format_result


# ---------------------------------------------------------------------------
# sh
# ---------------------------------------------------------------------------


def test_sh_renders_command_and_stdout():
    out = format_result(
        "sh",
        {"command": "ls scripts/"},
        {"exit_code": 0, "stdout": "smoke.py\nsmoke_all.py\n", "stderr": "", "truncated": False},
    )
    assert out.splitlines()[0] == "$ ls scripts/"
    assert "smoke.py" in out
    assert "smoke_all.py" in out
    assert out.rstrip().endswith("exit 0")
    # no JSON braces leak through
    assert "{" not in out and '"stdout"' not in out


def test_sh_renders_stderr_section_and_truncated():
    out = format_result(
        "sh",
        {"command": "tail huge.log"},
        {"exit_code": 1, "stdout": "line1\n", "stderr": "boom\n", "truncated": True},
    )
    assert "--- stderr ---" in out
    assert "boom" in out
    assert "exit 1 (output truncated)" in out


def test_sh_error_path_uses_user_error_label():
    out = format_result(
        "sh",
        {"command": "rm -rf /"},
        {"error": "command 'rm' not in read-only allowlist.", "_type": "user_error",
         "hint": "Use the built-in Bash tool for writes."},
    )
    assert out.splitlines()[0] == "$ rm -rf /"
    assert "error (user):" in out
    assert "hint: Use the built-in Bash tool" in out


# ---------------------------------------------------------------------------
# read
# ---------------------------------------------------------------------------


def test_read_renders_header_and_content():
    out = format_result(
        "read",
        {"path": "src/foo.py"},
        {
            "path": "src/foo.py",
            "language": "python",
            "mode": "truncated",
            "lines": 100,
            "truncated_to_lines": 40,
            "content": "def foo():\n    ...\n",
            "size_capped": False,
            "symbols": [],
        },
    )
    assert "read src/foo.py" in out
    assert "(python, mode=truncated)" in out
    assert "showing 40/100 lines" in out
    assert "def foo():" in out


def test_read_error():
    out = format_result(
        "read",
        {"path": "missing.py"},
        {"error": "file not found", "_type": "user_error", "hint": "Check the path"},
    )
    assert "read missing.py" in out
    assert "error (user): file not found" in out


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


def test_search_renders_matches():
    out = format_result(
        "search",
        {"pattern": "handleAuth", "path_glob": "src/**/*.ts"},
        {
            "files_searched": 5,
            "files_matched": 2,
            "total_matches": 3,
            "truncated": False,
            "results": [
                {
                    "path": "src/auth/login.ts",
                    "matches": [
                        {"line": 10, "text": "  return handleAuth()", "context_before": [], "context_after": [], "count": 1},
                    ],
                },
                {
                    "path": "src/auth/session.ts",
                    "matches": [
                        {"line": 2, "text": "// uses handleAuth", "context_before": [], "context_after": [], "count": 2},
                    ],
                },
            ],
        },
    )
    assert "search /handleAuth/ in src/**/*.ts" in out
    assert "3 match(es) in 2/5 file(s)" in out
    assert "src/auth/login.ts" in out
    assert "10: " in out and "handleAuth" in out
    assert "(x2)" in out  # repeated-line count


# ---------------------------------------------------------------------------
# edit
# ---------------------------------------------------------------------------


def test_edit_renders_applied_with_diff():
    out = format_result(
        "edit",
        {"edits": []},
        {
            "applied": 1,
            "failed": 0,
            "results": [
                {
                    "path": "src/x.py",
                    "status": "applied",
                    "match_type": "exact",
                    "diff": "- old\n+ new\n",
                    "validation": "ok",
                }
            ],
        },
    )
    assert "edit: 1 applied, 0 failed" in out
    assert "applied: src/x.py (exact)" in out
    assert "- old" in out and "+ new" in out


def test_edit_renders_failure_reason():
    out = format_result(
        "edit",
        {"edits": []},
        {
            "applied": 0,
            "failed": 1,
            "results": [
                {"path": "dup.py", "status": "failed", "reason": "old_string not unique"},
            ],
        },
    )
    assert "failed: dup.py" in out
    assert "reason: old_string not unique" in out


# ---------------------------------------------------------------------------
# run_tests
# ---------------------------------------------------------------------------


def test_run_tests_renders_summary_and_failure():
    out = format_result(
        "run_tests",
        {},
        {
            "framework": "pytest",
            "command": "pytest --tb=short -v",
            "duration_ms": 1234,
            "summary": {"total": 5, "passed": 4, "failed": 1, "skipped": 0, "errors": 0},
            "failures": [
                {
                    "name": "tests/test_x.py::test_a",
                    "file": "tests/test_x.py",
                    "line": 42,
                    "message": "AssertionError: nope",
                    "source_excerpt": "  41: pass\n  42: assert False\n",
                    "traceback_tail": "AssertionError",
                }
            ],
            "truncated_failures": False,
        },
    )
    assert "pytest: pytest --tb=short -v" in out
    assert "duration: 1234ms" in out
    assert "5 total" in out and "4 passed" in out and "1 failed" in out
    assert "FAIL tests/test_x.py::test_a  (tests/test_x.py:42)" in out
    assert "AssertionError: nope" in out
    assert "  42: assert False" in out


# ---------------------------------------------------------------------------
# git_status
# ---------------------------------------------------------------------------


def test_git_status_renders_branch_and_sections():
    out = format_result(
        "git_status",
        {},
        {
            "branch": "feat/foo",
            "upstream": "origin/feat/foo",
            "ahead": 2,
            "behind": 0,
            "staged": ["a.py"],
            "unstaged": ["b.py"],
            "untracked": [],
            "renamed": [],
            "conflicts": [],
        },
    )
    assert "branch: feat/foo -> origin/feat/foo (ahead 2)" in out
    assert "staged (1):" in out and "a.py" in out
    assert "unstaged (1):" in out and "b.py" in out


def test_git_status_clean_repo():
    out = format_result(
        "git_status",
        {},
        {
            "branch": "main", "upstream": None, "ahead": 0, "behind": 0,
            "staged": [], "unstaged": [], "untracked": [], "renamed": [], "conflicts": [],
        },
    )
    assert "branch: main" in out
    assert "clean" in out


# ---------------------------------------------------------------------------
# git_diff / changed_files / lint / extract_todos / commit_message
# ---------------------------------------------------------------------------


def test_git_diff_renders_hunks():
    out = format_result(
        "git_diff",
        {},
        {
            "files": [
                {
                    "path": "a.py", "status": "modified", "additions": 1, "deletions": 1,
                    "hunks": [
                        {
                            "old_start": 1, "old_lines": 2, "new_start": 1, "new_lines": 2,
                            "header": "@@ -1,2 +1,2 @@",
                            "content": "-x = 1\n+x = 2\n",
                        }
                    ],
                }
            ],
            "truncated_files": False, "truncated_hunks": False,
        },
    )
    assert "git_diff: 1 file(s)" in out
    assert "modified a.py  +1 -1" in out
    assert "@@ -1,2 +1,2 @@" in out
    assert "-x = 1" in out and "+x = 2" in out


def test_changed_files_renders_totals():
    out = format_result(
        "changed_files",
        {},
        {
            "branch_compared": "main",
            "files": [{"path": "a.py", "additions": 3, "deletions": 1, "status": "modified"}],
            "totals": {"files": 1, "additions": 3, "deletions": 1},
        },
    )
    assert "changed_files vs main: 1 files, +3 -1" in out
    assert "modified a.py  +3 -1" in out


def test_lint_renders_issues_and_skipped():
    out = format_result(
        "lint_and_typecheck",
        {},
        {
            "level": "full",
            "summary": {"errors": 1, "warnings": 0, "by_file": {}},
            "issues": [
                {"file": "a.py", "line": 3, "column": 5, "severity": "error",
                 "code": "E999", "source": "ruff", "message": "syntax"},
            ],
            "ran_runners": ["ruff"],
            "skipped_runners": ["mypy"],
            "truncated": False,
        },
    )
    assert "lint_and_typecheck (level=full): 1 errors, 0 warnings" in out
    assert "ran: ruff" in out
    assert "skipped: mypy" in out
    assert "a.py:3:5  error E999 [ruff]: syntax" in out


def test_extract_todos_renders_marker_and_age():
    out = format_result(
        "extract_todos",
        {},
        {
            "todos": [{
                "marker": "TODO", "file": "a.py", "line": 7,
                "text": "fix me later", "context": "  6: pass\n  7: # TODO fix me later\n",
                "author": "alice@example.com", "age_days": 42, "commit": "abc1234",
            }],
            "total": 1, "by_marker": {"TODO": 1}, "truncated": False,
        },
    )
    assert "extract_todos: 1 match(es)" in out
    assert "by marker: TODO=1" in out
    assert "TODO a.py:7  (alice@example.com, 42d old)" in out
    assert "fix me later" in out


def test_commit_message_renders_message_and_files():
    out = format_result(
        "commit_message",
        {},
        {
            "type": "feat", "scope": "auth", "subject": "add login flow",
            "message": "feat(auth): add login flow",
            "source": "staged",
            "files": [{"path": "src/auth/login.py", "status": "added"}],
        },
    )
    assert "type:    feat" in out
    assert "scope:   auth" in out
    assert "subject: add login flow" in out
    assert "feat(auth): add login flow" in out
    assert "added src/auth/login.py" in out


# ---------------------------------------------------------------------------
# Shared concerns
# ---------------------------------------------------------------------------


def test_notice_prefixes_output():
    out = format_result(
        "sh",
        {"command": "ls"},
        {"_notice": "Welcome to BeagleLathe!", "exit_code": 0, "stdout": "a\n", "stderr": "", "truncated": False},
    )
    assert out.startswith("Welcome to BeagleLathe!\n\n$ ls")


def test_unknown_tool_falls_back_to_json():
    out = format_result("does_not_exist", {}, {"k": 1})
    # Round-trips as JSON.
    assert json.loads(out) == {"k": 1}


def test_renderer_exception_falls_back_to_json():
    # `lines` is None on purpose; renderer accesses it but should not raise.
    # Use a payload that *would* break a naive renderer, then ensure fallback.
    out = format_result("read", {"path": "x"}, {"path": "x", "language": None,
                                                "mode": "full", "lines": None,
                                                "truncated_to_lines": None,
                                                "content": None})
    # Should not raise; either renders cleanly or falls back to JSON.
    assert "read x" in out or '"path"' in out
