import shutil
import subprocess
from pathlib import Path

import pytest

from beaglelathe.tools.commit_message import run_commit_message


pytestmark = pytest.mark.skipif(shutil.which("git") is None, reason="git not on PATH")


def _init_repo(tmp_path: Path) -> None:
    def g(*args: str) -> None:
        subprocess.run(["git", *args], cwd=tmp_path, check=True, capture_output=True)

    g("init", "--initial-branch=main")
    g("config", "user.email", "test@example.com")
    g("config", "user.name", "Test")
    g("config", "commit.gpgsign", "false")
    (tmp_path / "README.md").write_text("# x\n")
    g("add", "README.md")
    g("commit", "-m", "initial")


def _stage(tmp_path: Path, files: list[tuple[str, str]]) -> None:
    """Write files and stage them."""
    for rel, content in files:
        full = tmp_path / rel
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content)
        subprocess.run(["git", "add", rel], cwd=tmp_path, check=True)


def test_not_a_repo(tmp_path: Path):
    out = run_commit_message({}, tmp_path)
    assert "error" in out
    assert "not a git repository" in out["error"]


def test_no_changes(tmp_path: Path):
    _init_repo(tmp_path)
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert "error" in out
    assert "no changes" in out["error"]


def test_feat_for_new_source_file(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [("src/auth/login.py", "def login():\n    pass\n")])
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["type"] == "feat"
    assert out["scope"] == "auth"
    assert "add" in out["subject"]
    assert "login.py" in out["subject"]
    assert out["message"].startswith("feat(auth):")


def test_test_type_for_test_paths(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [
        ("tests/test_login.py", "def test_x():\n    assert True\n"),
        ("tests/test_logout.py", "def test_y():\n    assert True\n"),
    ])
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["type"] == "test"
    assert out["scope"] == "tests"
    assert "tests" in out["subject"]


def test_docs_type_for_markdown(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [("docs/usage.md", "# Usage\n")])
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["type"] == "docs"


def test_ci_type_for_github_workflows(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [(".github/workflows/test.yml", "name: test\n")])
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["type"] == "ci"


def test_build_type_for_pyproject(tmp_path: Path):
    _init_repo(tmp_path)
    # Modify the existing README so something else changes too -- no, test pyproject alone.
    # pyproject.toml fresh-add:
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
    subprocess.run(["git", "add", "pyproject.toml"], cwd=tmp_path, check=True)
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["type"] == "build"


def test_type_override(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [("src/x.py", "x = 1\n")])
    out = run_commit_message(
        {"source": "staged", "type_override": "perf"}, tmp_path
    )
    assert out["type"] == "perf"
    assert out["message"].startswith("perf")


def test_scope_override(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [("src/x.py", "x = 1\n")])
    out = run_commit_message(
        {"source": "staged", "scope_override": "core"}, tmp_path
    )
    assert out["scope"] == "core"
    assert "(core)" in out["message"]


def test_last_commit_source(tmp_path: Path):
    _init_repo(tmp_path)
    # The initial commit added README.md.
    out = run_commit_message({"source": "last_commit"}, tmp_path)
    assert "error" not in out
    assert any(f["path"] == "README.md" for f in out["files"])


def test_working_tree_includes_untracked_modifications(tmp_path: Path):
    _init_repo(tmp_path)
    # Modify README without staging.
    (tmp_path / "README.md").write_text("# x\nedited\n")
    out = run_commit_message({"source": "working_tree"}, tmp_path)
    assert any(f["path"] == "README.md" for f in out["files"])


def test_scope_strips_src_prefix(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [
        ("src/tools/run_tests.py", "x = 1\n"),
        ("src/tools/git_ops.py", "y = 1\n"),
    ])
    out = run_commit_message({"source": "staged"}, tmp_path)
    assert out["scope"] == "tools"


def test_subject_length_cap(tmp_path: Path):
    _init_repo(tmp_path)
    _stage(tmp_path, [(f"src/feature/file_{i}.py", "x = 1\n") for i in range(8)])
    out = run_commit_message(
        {"source": "staged", "max_subject_length": 40}, tmp_path
    )
    # Header should fit within max_subject_length (give a small slack for "..." or trim).
    assert len(out["message"]) <= 60
