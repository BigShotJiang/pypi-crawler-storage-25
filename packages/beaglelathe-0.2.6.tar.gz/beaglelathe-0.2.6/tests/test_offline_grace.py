"""Tests for the offline-grace timer in savings.py.

The timer blocks tool calls once we've gone over `offline_grace_hours()` with
no successful backend response. These tests cover the round-trip, the env
override, the first-install seed, and the cutoff calculation around the edge.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from beaglelathe.savings import (
    DEFAULT_OFFLINE_GRACE_HOURS,
    get_last_server_contact,
    offline_grace_hours,
    offline_too_long,
    set_last_server_contact,
)


# ── set / get round-trip ────────────────────────────────────────────────────

def test_first_open_seeds_contact_timestamp(tmp_path):
    db = tmp_path / "state.db"
    # Touching the DB at all should seed the meta row so a freshly installed
    # user gets a full grace window, not an immediate block.
    contact = get_last_server_contact(db)
    assert contact is not None
    # Within the last second of "now" (clock fudge tolerance).
    delta = datetime.now(timezone.utc) - contact
    assert delta < timedelta(seconds=5), f"seed too far in the past: {delta}"


def test_set_then_get_default_now(tmp_path):
    db = tmp_path / "state.db"
    set_last_server_contact(db_path=db)
    contact = get_last_server_contact(db)
    assert contact is not None
    delta = datetime.now(timezone.utc) - contact
    assert delta < timedelta(seconds=5)


def test_set_with_explicit_ts(tmp_path):
    db = tmp_path / "state.db"
    fixed = datetime(2026, 1, 2, 3, 4, 5, tzinfo=timezone.utc)
    set_last_server_contact(ts=fixed, db_path=db)
    assert get_last_server_contact(db) == fixed


def test_set_overwrites_previous_value(tmp_path):
    db = tmp_path / "state.db"
    old = datetime(2026, 1, 1, tzinfo=timezone.utc)
    new = datetime(2026, 5, 13, tzinfo=timezone.utc)
    set_last_server_contact(ts=old, db_path=db)
    set_last_server_contact(ts=new, db_path=db)
    assert get_last_server_contact(db) == new


# ── grace-window calculation ────────────────────────────────────────────────

def test_just_contacted_is_not_offline(tmp_path):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    set_last_server_contact(ts=now, db_path=db)
    assert offline_too_long(db_path=db, now=now) is False


def test_one_hour_old_is_not_offline(tmp_path):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    set_last_server_contact(ts=now - timedelta(hours=1), db_path=db)
    assert offline_too_long(db_path=db, now=now) is False


def test_just_under_grace_is_not_offline(tmp_path):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    almost = timedelta(hours=DEFAULT_OFFLINE_GRACE_HOURS) - timedelta(minutes=1)
    set_last_server_contact(ts=now - almost, db_path=db)
    assert offline_too_long(db_path=db, now=now) is False


def test_just_over_grace_is_offline(tmp_path):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    past = timedelta(hours=DEFAULT_OFFLINE_GRACE_HOURS) + timedelta(minutes=1)
    set_last_server_contact(ts=now - past, db_path=db)
    assert offline_too_long(db_path=db, now=now) is True


def test_week_old_is_offline(tmp_path):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    set_last_server_contact(ts=now - timedelta(days=7), db_path=db)
    assert offline_too_long(db_path=db, now=now) is True


# ── env override ────────────────────────────────────────────────────────────

def test_env_override_extends_grace(tmp_path, monkeypatch):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    # 25h old would normally be offline; bumping the grace to 48h saves it.
    set_last_server_contact(ts=now - timedelta(hours=25), db_path=db)
    monkeypatch.setenv("BEAGLELATHE_OFFLINE_GRACE_HOURS", "48")
    assert offline_grace_hours() == 48.0
    assert offline_too_long(db_path=db, now=now) is False


def test_env_override_shrinks_grace(tmp_path, monkeypatch):
    db = tmp_path / "state.db"
    now = datetime(2026, 5, 13, 12, 0, 0, tzinfo=timezone.utc)
    set_last_server_contact(ts=now - timedelta(hours=2), db_path=db)
    monkeypatch.setenv("BEAGLELATHE_OFFLINE_GRACE_HOURS", "1")
    assert offline_grace_hours() == 1.0
    assert offline_too_long(db_path=db, now=now) is True


@pytest.mark.parametrize("bad", ["", "not-a-number", "0", "-5"])
def test_env_invalid_or_nonpositive_falls_back(monkeypatch, bad):
    monkeypatch.setenv("BEAGLELATHE_OFFLINE_GRACE_HOURS", bad)
    assert offline_grace_hours() == DEFAULT_OFFLINE_GRACE_HOURS
