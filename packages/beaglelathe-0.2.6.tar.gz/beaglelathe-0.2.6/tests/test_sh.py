from pathlib import Path

from beaglelathe.tools.sh import run_sh


def test_ls(tmp_path: Path):
    (tmp_path / "a.txt").write_text("x")
    (tmp_path / "b.txt").write_text("y")
    out = run_sh({"command": "ls"}, tmp_path)
    assert out.get("exit_code") == 0
    assert "a.txt" in out["stdout"]
    assert "b.txt" in out["stdout"]


def test_cat(tmp_path: Path):
    (tmp_path / "a.txt").write_text("hello\n")
    out = run_sh({"command": "cat a.txt"}, tmp_path)
    assert out["stdout"] == "hello\n"
    assert out["exit_code"] == 0


def test_pipe_rejected(tmp_path: Path):
    out = run_sh({"command": "cat a.txt | head -1"}, tmp_path)
    assert "error" in out
    assert "metacharacters" in out["error"]


def test_redirect_rejected(tmp_path: Path):
    out = run_sh({"command": "cat a.txt > out.txt"}, tmp_path)
    assert "error" in out


def test_subshell_rejected(tmp_path: Path):
    out = run_sh({"command": "echo $(whoami)"}, tmp_path)
    assert "error" in out


def test_envvar_rejected(tmp_path: Path):
    out = run_sh({"command": "echo $HOME"}, tmp_path)
    assert "error" in out


def test_nonwhitelisted_first_token(tmp_path: Path):
    out = run_sh({"command": "rm -rf /"}, tmp_path)
    assert "error" in out
    assert "allowlist" in out["error"]


def test_git_status_allowed(tmp_path: Path):
    out = run_sh({"command": "git status"}, tmp_path)
    # exit_code may be non-zero (no repo here), but it must have run.
    assert "error" not in out or "exit_code" in out


def test_git_push_rejected(tmp_path: Path):
    out = run_sh({"command": "git push origin main"}, tmp_path)
    assert "error" in out
    assert "git subcommand" in out["error"]


def test_truncation(tmp_path: Path):
    big = tmp_path / "big.txt"
    big.write_text("\n".join(f"line {i}" for i in range(2000)) + "\n")
    out = run_sh({"command": "cat big.txt"}, tmp_path)
    assert out["truncated"] is True
    assert out["stdout"].count("\n") <= 600
