import shutil
from pathlib import Path

import pytest

from beaglelathe.tools import lint_and_typecheck
from beaglelathe.tools.lint_and_typecheck import run_lint_and_typecheck


# ---------------------------------------------------------------------------
# Always-available tests (use py_compile, monkeypatching, etc.)
# ---------------------------------------------------------------------------


def test_unknown_extension(tmp_path: Path):
    (tmp_path / "notes.txt").write_text("nothing to lint here\n")
    out = run_lint_and_typecheck({"paths": ["."]}, tmp_path)
    assert out["issues"] == []
    assert out["ran_runners"] == []
    assert out["skipped_runners"] == []
    assert out.get("note") == "no recognized source files in paths"
    assert out["summary"] == {"errors": 0, "warnings": 0, "by_file": {}}


def test_syntax_level_clean_python(tmp_path: Path):
    (tmp_path / "good.py").write_text("def f():\n    return 1\n")
    out = run_lint_and_typecheck({"paths": ["."], "level": "syntax"}, tmp_path)
    assert out["level"] == "syntax"
    assert out["summary"]["errors"] == 0
    assert "py_compile" in out["ran_runners"]
    assert out["issues"] == []


def test_syntax_level_catches_python_syntax_error(tmp_path: Path):
    (tmp_path / "bad.py").write_text("def f(:\n    pass\n")
    out = run_lint_and_typecheck({"paths": ["."], "level": "syntax"}, tmp_path)
    assert out["summary"]["errors"] >= 1
    assert any(i["source"] == "py_compile" and i["code"] == "SyntaxError" for i in out["issues"])
    bad = next(i for i in out["issues"] if i["file"].endswith("bad.py"))
    assert bad["line"] == 1
    assert bad["severity"] == "error"


def test_max_issues_truncates(tmp_path: Path):
    for i in range(5):
        (tmp_path / f"bad{i}.py").write_text("def f(:\n    pass\n")
    out = run_lint_and_typecheck(
        {"paths": ["."], "level": "syntax", "max_issues": 2}, tmp_path
    )
    assert len(out["issues"]) == 2
    assert out["truncated"] is True


def test_invalid_level_argument(tmp_path: Path):
    out = run_lint_and_typecheck({"level": "weird"}, tmp_path)
    assert "error" in out
    assert "level" in out["error"]


def test_runner_not_installed_listed_as_skipped(tmp_path: Path, monkeypatch):
    (tmp_path / "src.py").write_text("import os\n")

    # Pretend nothing is installed except py_compile (which doesn't go through
    # shutil.which; it uses sys.executable). With ruff and mypy missing, both
    # should land in skipped_runners and not in errored_runners.
    original_which = shutil.which

    def fake_which(name, *a, **kw):
        if name in ("ruff", "mypy"):
            return None
        return original_which(name, *a, **kw)

    monkeypatch.setattr(lint_and_typecheck.shutil, "which", fake_which)

    out = run_lint_and_typecheck({"paths": ["."], "level": "full"}, tmp_path)
    assert "ruff" in out["skipped_runners"]
    assert "mypy" in out["skipped_runners"]
    assert "ruff" not in out["ran_runners"]
    assert "errored_runners" not in out


def test_explicit_file_path(tmp_path: Path):
    (tmp_path / "good.py").write_text("x = 1\n")
    (tmp_path / "bad.py").write_text("def f(:\n    pass\n")
    out = run_lint_and_typecheck(
        {"paths": ["good.py"], "level": "syntax"}, tmp_path
    )
    assert out["summary"]["errors"] == 0
    assert out["issues"] == []


def test_skip_dirs_excluded(tmp_path: Path):
    (tmp_path / "src.py").write_text("x = 1\n")
    nested = tmp_path / "node_modules" / "pkg"
    nested.mkdir(parents=True)
    (nested / "lib.py").write_text("def f(:\n    pass\n")  # should be ignored

    out = run_lint_and_typecheck({"paths": ["."], "level": "syntax"}, tmp_path)
    assert out["summary"]["errors"] == 0


# ---------------------------------------------------------------------------
# Toolchain-gated tests
# ---------------------------------------------------------------------------


@pytest.mark.skipif(shutil.which("ruff") is None, reason="ruff not installed")
def test_python_full_clean_with_ruff(tmp_path: Path):
    (tmp_path / "clean.py").write_text("x = 1\n")
    out = run_lint_and_typecheck({"paths": ["clean.py"], "level": "full"}, tmp_path)
    assert out["summary"]["errors"] == 0
    assert "ruff" in out["ran_runners"]


@pytest.mark.skipif(shutil.which("ruff") is None, reason="ruff not installed")
def test_python_full_ruff_catches_undefined_name(tmp_path: Path):
    (tmp_path / "bad.py").write_text("def f():\n    return undefined_name\n")
    out = run_lint_and_typecheck({"paths": ["bad.py"], "level": "full"}, tmp_path)
    assert any(
        i["source"] == "ruff" and i["code"].startswith("F") for i in out["issues"]
    )


@pytest.mark.skipif(shutil.which("go") is None, reason="go toolchain not installed")
def test_go_path_runs_govet(tmp_path: Path):
    (tmp_path / "go.mod").write_text("module example.com/x\n\ngo 1.21\n")
    (tmp_path / "x.go").write_text("package x\n")
    out = run_lint_and_typecheck({"paths": ["."], "level": "syntax"}, tmp_path)
    assert "go vet" in out["ran_runners"]
