from pathlib import Path

from beaglelathe.validators import validate


def test_python_ok(tmp_path: Path):
    p = tmp_path / "a.py"
    status, detail = validate(p, "def f():\n    return 1\n")
    assert status == "ok"
    assert detail is None


def test_python_syntax_error(tmp_path: Path):
    p = tmp_path / "a.py"
    status, detail = validate(p, "def f(:\n    return\n")
    assert status == "syntax_error"
    assert detail is not None


def test_json_ok(tmp_path: Path):
    p = tmp_path / "a.json"
    status, _ = validate(p, '{"x": 1}')
    assert status == "ok"


def test_json_bad(tmp_path: Path):
    p = tmp_path / "a.json"
    status, detail = validate(p, '{"x": 1')
    assert status == "syntax_error"
    assert detail is not None


def test_typescript_ok(tmp_path: Path):
    p = tmp_path / "a.ts"
    status, _ = validate(p, "export const x: number = 1;\n")
    assert status == "ok"


def test_typescript_bad(tmp_path: Path):
    # Brace-balance check (no real parser): use an unmistakable structural error.
    p = tmp_path / "a.ts"
    status, detail = validate(p, "function foo() { return 1\n")
    assert status == "syntax_error"
    assert detail is not None


def test_unknown_extension_skipped(tmp_path: Path):
    p = tmp_path / "a.txt"
    status, _ = validate(p, "hello")
    assert status == "skipped"
