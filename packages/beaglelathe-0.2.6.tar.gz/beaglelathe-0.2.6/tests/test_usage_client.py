"""Tests for usage_client.py — mocks httpx at the module level."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from beaglelathe.auth.credentials import Credentials
from beaglelathe.usage_client import UsageClientError, get_status, post_checkout, post_sync


# ── helpers ───────────────────────────────────────────────────────────────────

def _creds(**overrides) -> Credentials:
    defaults = dict(
        jwt="test-jwt",
        user_id="uid-1",
        email="user@example.com",
        plan="free",
        budget_remaining=150,
        budget_resets_at="2026-06-01T00:00:00Z",
        base_url="http://localhost:8000",
        issued_at="2026-05-01T00:00:00Z",
    )
    return Credentials(**{**defaults, **overrides})


def _resp(status: int, body: dict) -> MagicMock:
    r = MagicMock()
    r.status_code = status
    r.json.return_value = body
    return r


# ── get_status ────────────────────────────────────────────────────────────────

class TestGetStatus:
    def test_success_returns_json(self):
        body = {"plan": "free", "tool_calls_this_month": 10, "budget_remaining": 190}
        with patch("httpx.get", return_value=_resp(200, body)):
            result = get_status(_creds())
        assert result["plan"] == "free"
        assert result["tool_calls_this_month"] == 10

    def test_sends_bearer_auth_header(self):
        with patch("httpx.get", return_value=_resp(200, {})) as mock_get:
            get_status(_creds(jwt="my-jwt"))
        _, kwargs = mock_get.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer my-jwt"

    def test_calls_correct_url(self):
        with patch("httpx.get", return_value=_resp(200, {})) as mock_get:
            get_status(_creds(base_url="http://api.example.com"))
        args, _ = mock_get.call_args
        assert args[0] == "http://api.example.com/usage/status"

    def test_trailing_slash_stripped_from_base_url(self):
        with patch("httpx.get", return_value=_resp(200, {})) as mock_get:
            get_status(_creds(base_url="http://api.example.com/"))
        args, _ = mock_get.call_args
        assert not args[0].endswith("//usage/status")

    def test_401_raises_auth_error(self):
        with patch("httpx.get", return_value=_resp(401, {})):
            with pytest.raises(UsageClientError, match="expired"):
                get_status(_creds())

    def test_500_raises_usage_client_error(self):
        with patch("httpx.get", return_value=_resp(500, {})):
            with pytest.raises(UsageClientError, match="500"):
                get_status(_creds())

    def test_network_error_raises_usage_client_error(self):
        import httpx as _httpx
        with patch("httpx.get", side_effect=_httpx.HTTPError("connection refused")):
            with pytest.raises(UsageClientError, match="network error"):
                get_status(_creds())


# ── post_sync ─────────────────────────────────────────────────────────────────

class TestPostSync:
    def test_success_returns_json(self):
        body = {"budget_remaining": 140, "new_jwt": "refreshed-token"}
        with patch("httpx.post", return_value=_resp(200, body)):
            result = post_sync(_creds(), tool_calls=10)
        assert result["budget_remaining"] == 140

    def test_sends_tool_calls_in_body(self):
        with patch("httpx.post", return_value=_resp(200, {})) as mock_post:
            post_sync(_creds(), tool_calls=7)
        _, kwargs = mock_post.call_args
        assert kwargs["json"]["tool_calls"] == 7

    def test_calls_sync_url(self):
        with patch("httpx.post", return_value=_resp(200, {})) as mock_post:
            post_sync(_creds(base_url="http://api.example.com"), tool_calls=1)
        args, _ = mock_post.call_args
        assert args[0].endswith("/usage/sync")

    def test_401_raises_auth_error(self):
        with patch("httpx.post", return_value=_resp(401, {})):
            with pytest.raises(UsageClientError, match="expired"):
                post_sync(_creds(), tool_calls=1)

    def test_network_error_raises_usage_client_error(self):
        import httpx as _httpx
        with patch("httpx.post", side_effect=_httpx.HTTPError("refused")):
            with pytest.raises(UsageClientError, match="network error"):
                post_sync(_creds(), tool_calls=1)


# ── post_checkout ─────────────────────────────────────────────────────────────

class TestPostCheckout:
    def test_success_returns_url(self):
        body = {"checkout_url": "https://checkout.stripe.com/pay/cs_test_abc123"}
        with patch("httpx.post", return_value=_resp(200, body)):
            url = post_checkout(_creds())
        assert url == "https://checkout.stripe.com/pay/cs_test_abc123"

    def test_calls_checkout_url(self):
        body = {"checkout_url": "https://stripe.com/x"}
        with patch("httpx.post", return_value=_resp(200, body)) as mock_post:
            post_checkout(_creds(base_url="http://api.example.com"))
        args, _ = mock_post.call_args
        assert args[0].endswith("/billing/checkout")

    def test_missing_checkout_url_raises(self):
        with patch("httpx.post", return_value=_resp(200, {})):
            with pytest.raises(UsageClientError, match="checkout_url"):
                post_checkout(_creds())

    def test_401_raises_auth_error(self):
        with patch("httpx.post", return_value=_resp(401, {})):
            with pytest.raises(UsageClientError, match="expired"):
                post_checkout(_creds())

    def test_network_error_raises_usage_client_error(self):
        import httpx as _httpx
        with patch("httpx.post", side_effect=_httpx.HTTPError("refused")):
            with pytest.raises(UsageClientError, match="network error"):
                post_checkout(_creds())
