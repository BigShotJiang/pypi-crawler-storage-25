"""Tests for tools/search.py — runs real ripgrep against tmp_path fixtures."""

from __future__ import annotations

from pathlib import Path


from beaglelathe.tools.search import run_search


def _write(tmp_path: Path, rel: str, content: str) -> Path:
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return p


# ── validation ────────────────────────────────────────────────────────────────

def test_missing_pattern_returns_error(tmp_path):
    result = run_search({}, tmp_path)
    assert "error" in result


# ── basic matching ─────────────────────────────────────────────────────────────

def test_single_file_single_match(tmp_path):
    _write(tmp_path, "foo.py", "def my_func():\n    pass\n")
    result = run_search({"pattern": "my_func"}, tmp_path)
    assert result["files_matched"] == 1
    assert result["total_matches"] >= 1
    assert result["results"][0]["path"] == "foo.py"


def test_multi_file_match(tmp_path):
    _write(tmp_path, "a.py", "TARGET = 1\n")
    _write(tmp_path, "b.py", "# nothing here\n")
    _write(tmp_path, "c.py", "print(TARGET)\n")
    result = run_search({"pattern": "TARGET"}, tmp_path)
    assert result["files_matched"] == 2
    paths = {r["path"] for r in result["results"]}
    assert "a.py" in paths and "c.py" in paths


def test_no_match_returns_empty(tmp_path):
    _write(tmp_path, "a.py", "hello world\n")
    result = run_search({"pattern": "ZZZNOMATCH_XYZ"}, tmp_path)
    assert result["files_matched"] == 0
    assert result["total_matches"] == 0
    assert result["results"] == []
    assert result["truncated"] is False


# ── path_glob scoping ─────────────────────────────────────────────────────────

def test_path_glob_limits_to_subtree(tmp_path):
    _write(tmp_path, "src/a.py", "NEEDLE = 1\n")
    _write(tmp_path, "tests/b.py", "NEEDLE = 2\n")
    result = run_search({"pattern": "NEEDLE", "path_glob": "src/**/*.py"}, tmp_path)
    assert result["files_matched"] == 1
    assert result["results"][0]["path"].startswith("src/")


def test_path_glob_extension_filter(tmp_path):
    _write(tmp_path, "a.py", "X = 1\n")
    _write(tmp_path, "b.ts", "const X = 1;\n")
    result = run_search({"pattern": "X", "path_glob": "**/*.ts"}, tmp_path)
    assert result["files_matched"] == 1
    assert result["results"][0]["path"].endswith(".ts")


# ── context lines ─────────────────────────────────────────────────────────────

def test_context_lines_before_and_after(tmp_path):
    _write(tmp_path, "x.py", "before\nTARGET\nafter\n")
    result = run_search({"pattern": "TARGET", "context_lines": 1}, tmp_path)
    m = result["results"][0]["matches"][0]
    assert m["context_before"] == ["before"]
    assert m["context_after"] == ["after"]


def test_context_lines_zero(tmp_path):
    _write(tmp_path, "x.py", "before\nTARGET\nafter\n")
    result = run_search({"pattern": "TARGET", "context_lines": 0}, tmp_path)
    m = result["results"][0]["matches"][0]
    assert m["context_before"] == []
    assert m["context_after"] == []


# ── case sensitivity ──────────────────────────────────────────────────────────

def test_case_insensitive_by_default(tmp_path):
    _write(tmp_path, "a.py", "Hello = 1\n")
    result = run_search({"pattern": "hello", "case_sensitive": False}, tmp_path)
    assert result["files_matched"] == 1


def test_case_sensitive_no_match(tmp_path):
    _write(tmp_path, "a.py", "Hello = 1\n")
    result = run_search({"pattern": "hello", "case_sensitive": True}, tmp_path)
    assert result["files_matched"] == 0


# ── max_results truncation ────────────────────────────────────────────────────

def test_max_results_truncates(tmp_path):
    lines = "\n".join(f"MATCH_{i} = {i}" for i in range(20))
    _write(tmp_path, "big.py", lines)
    result = run_search({"pattern": "MATCH_", "max_results": 5}, tmp_path)
    assert result["truncated"] is True
    # total_matches reflects when truncation was triggered; may be >= max_results
    assert result["total_matches"] >= 5


def test_max_results_not_truncated_when_under_limit(tmp_path):
    _write(tmp_path, "a.py", "X = 1\nX = 2\nX = 3\n")
    result = run_search({"pattern": "X", "max_results": 10}, tmp_path)
    assert result["truncated"] is False
    assert result["total_matches"] == 3


# ── deduplication ─────────────────────────────────────────────────────────────

def test_duplicate_lines_collapsed_with_count(tmp_path):
    _write(tmp_path, "dupe.py", "SAME = 1\nSAME = 1\nSAME = 1\n")
    result = run_search({"pattern": "SAME"}, tmp_path)
    matches = result["results"][0]["matches"]
    assert len(matches) == 1
    assert matches[0]["count"] == 3


def test_unique_lines_not_collapsed(tmp_path):
    _write(tmp_path, "a.py", "FOO = 1\nFOO = 2\n")
    result = run_search({"pattern": "FOO"}, tmp_path)
    matches = result["results"][0]["matches"]
    assert len(matches) == 2
    assert all(m["count"] == 1 for m in matches)


# ── result shape ──────────────────────────────────────────────────────────────

def test_result_has_expected_keys(tmp_path):
    _write(tmp_path, "a.py", "X = 1\n")
    result = run_search({"pattern": "X"}, tmp_path)
    assert {"files_searched", "files_matched", "total_matches", "truncated", "results"} == set(result.keys())


def test_match_entry_has_expected_keys(tmp_path):
    _write(tmp_path, "a.py", "X = 1\n")
    result = run_search({"pattern": "X"}, tmp_path)
    m = result["results"][0]["matches"][0]
    assert {"line", "text", "context_before", "context_after", "count"} == set(m.keys())


def test_match_line_number_correct(tmp_path):
    _write(tmp_path, "a.py", "skip\nskip\nTARGET\n")
    result = run_search({"pattern": "TARGET"}, tmp_path)
    m = result["results"][0]["matches"][0]
    assert m["line"] == 3
