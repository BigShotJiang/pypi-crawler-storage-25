from __future__ import annotations

import json
from typing import Any, Iterator, Optional

import httpx

from cube_sdk.exceptions import AuthenticationError, CubeAPIError, RateLimitError

DEFAULT_ENVIRONMENT = "cube_cloud"
VALID_ENVIRONMENTS = {"sandbox", "cube_cloud", "byok"}


class AgentsResource:
    """Wraps /gateway/v1/agents and /agents endpoints."""

    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def execute(
        self,
        agent_id: str,
        *,
        query: str,
        environment: str = DEFAULT_ENVIRONMENT,
        conversation_id: Optional[str] = None,
        inputs: Optional[dict[str, Any]] = None,
        llm_api_key: Optional[str] = None,
    ) -> dict[str, Any]:
        """Synchronous agent execution. Returns the full response dict."""
        body = self._build_body(
            query=query,
            environment=environment,
            conversation_id=conversation_id,
            inputs=inputs,
            llm_api_key=llm_api_key,
        )
        response = self._http.post(
            f"/gateway/v1/agents/{agent_id}/execute",
            json=body,
        )
        return self._handle_response(response)

    def stream(
        self,
        agent_id: str,
        *,
        query: str,
        environment: str = DEFAULT_ENVIRONMENT,
        conversation_id: Optional[str] = None,
        inputs: Optional[dict[str, Any]] = None,
        llm_api_key: Optional[str] = None,
    ) -> Iterator[dict[str, Any]]:
        """SSE streaming execution. Yields parsed JSON events."""
        body = self._build_body(
            query=query,
            environment=environment,
            conversation_id=conversation_id,
            inputs=inputs,
            llm_api_key=llm_api_key,
        )
        with self._http.stream(
            "POST",
            f"/gateway/v1/agents/{agent_id}/stream",
            json=body,
        ) as response:
            if response.status_code != 200:
                response.read()
                self._raise_for_status(response)

            yield from self._parse_sse(response)

    def specs(self, agent_id: str) -> dict[str, Any]:
        """Fetch agent integration specifications."""
        response = self._http.get(f"/gateway/v1/agents/{agent_id}/specs")
        return self._handle_response(response)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_body(
        *,
        query: str,
        environment: str,
        conversation_id: Optional[str],
        inputs: Optional[dict[str, Any]],
        llm_api_key: Optional[str],
    ) -> dict[str, Any]:
        if environment not in VALID_ENVIRONMENTS:
            raise ValueError(
                f"Invalid environment '{environment}'. Must be one of: {', '.join(sorted(VALID_ENVIRONMENTS))}"
            )
        body: dict[str, Any] = {
            "query": query,
            "environment": environment,
        }
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if inputs is not None:
            body["inputs"] = inputs
        if llm_api_key is not None:
            body["llm_api_key"] = llm_api_key
        return body

    @staticmethod
    def _parse_sse(response: httpx.Response) -> Iterator[dict[str, Any]]:
        for line in response.iter_lines():
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload == "[DONE]":
                return
            try:
                yield json.loads(payload)
            except json.JSONDecodeError:
                continue

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        if response.status_code >= 400:
            self._raise_for_status(response)
        return response.json()

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        detail: Any = ""
        try:
            body = response.json()
            detail = body.get("detail", body)
        except Exception:
            detail = response.text

        message = detail
        if isinstance(detail, dict):
            parts = [detail.get("message") or ""]
            topup_url = detail.get("topup_url")
            if topup_url:
                parts.append(f"Top up your balance: {topup_url}")
            message = " ".join(p for p in parts if p) or str(detail)

        if response.status_code == 401:
            raise AuthenticationError(detail=message)

        if response.status_code == 429:
            retry_after_raw = response.headers.get("retry-after")
            retry_after = float(retry_after_raw) if retry_after_raw else None
            raise RateLimitError(detail=message, retry_after=retry_after)

        raise CubeAPIError(
            message=message,
            status_code=response.status_code,
            detail=detail,
        )
