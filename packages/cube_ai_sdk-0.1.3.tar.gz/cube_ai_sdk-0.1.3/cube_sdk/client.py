from __future__ import annotations

from typing import Optional

import httpx

from cube_sdk.agents import AgentsResource

DEFAULT_BASE_URL = "https://cube-market.com"
DEFAULT_TIMEOUT = 60.0


class CubeClient:
    """Thin wrapper around the CUBE Gateway API.

    Usage::

        client = CubeClient(api_key="cube_...")
        result = client.agents.execute("agent-id", query="Hello!")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self._owns_client = http_client is None
        self._http = http_client or httpx.Client(
            base_url=base_url,
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )

        self.agents = AgentsResource(self._http)

    def close(self) -> None:
        if self._owns_client:
            self._http.close()

    def __enter__(self) -> CubeClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
