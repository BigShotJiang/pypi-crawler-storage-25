from __future__ import annotations

from typing import Optional


class CubeAPIError(Exception):
    """Base exception for all CUBE API errors."""

    def __init__(
        self,
        message: str,
        status_code: int,
        detail: Optional[str] = None,
    ) -> None:
        self.status_code = status_code
        self.detail = detail or message
        super().__init__(message)


class AuthenticationError(CubeAPIError):
    """Raised on 401 responses — invalid or missing API key."""

    def __init__(self, detail: str = "Authentication failed") -> None:
        super().__init__(
            message=detail,
            status_code=401,
            detail=detail,
        )


class RateLimitError(CubeAPIError):
    """Raised on 429 responses — request rate or quota exceeded."""

    def __init__(
        self,
        detail: str = "Rate limit exceeded",
        retry_after: Optional[float] = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(
            message=detail,
            status_code=429,
            detail=detail,
        )
