# Changelog

All notable changes to `cube-ai-sdk` (Python SDK) will be documented in this file.
Format: [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); SemVer.

## [0.1.3] - 2026-04-25

### Changed
- 402 Payment Required errors now surface a `topup_url` (the CUBE billing
  page) inside the error message, so users can act on the failure directly.

## [0.1.2] - 2026-04-25

### Changed
- PyPI package name renamed from `cube-sdk` to `cube-ai-sdk` (PyPI rejected
  `cube-sdk` as too similar to the existing `cubesdk` package). Import path
  is unchanged: `from cube_sdk import CubeClient`.

## [0.1.1] - 2026-04-25

### Changed
- Default `base_url` is now `https://cube-market.com` (was the placeholder
  `https://api.cube.bot`, which never had a working backend). Existing users
  who already pass `base_url` explicitly are unaffected.

## [0.1.0] - 2026-04-23

### Added
- Initial PyPI release.
- `CubeClient` with `agents.execute`, `agents.stream`, `agents.specs`.
- Error classes: `AuthenticationError`, `RateLimitError`, `CubeAPIError`.
- Three execution environments: `sandbox`, `cube_cloud`, `byok`.
- Context manager support (`with CubeClient(...) as client:`).
- Type hints throughout; `py.typed` marker included.
- Single runtime dependency: `httpx>=0.24`.
