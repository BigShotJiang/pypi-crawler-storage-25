"""Halton Meter — local LLM API proxy daemon."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("halton-meter")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
