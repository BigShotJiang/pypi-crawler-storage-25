"""
Project tagging for Halton Meter daemon.

Resolves a project name for a given mitmproxy flow using the following
precedence (first match wins):

  1. HALTON_PROJECT environment variable on the originating process
  2. .haltonrc file in the originating process's working directory or
     any parent directory (walk upward until filesystem root)
  3. Originating process's working directory basename
  4. Literal string "unattributed"

The originating process's working directory is obtained via psutil
(looking up the PID of the connecting process from the flow). If
psutil lookup fails (the common case for ``claude`` — a Mach-O binary
the connections walk does not always peer into), the resolver returns
``None`` and the caller short-circuits to ``"unattributed"`` rather
than borrowing ``os.getcwd()`` of the daemon process. The daemon's
own cwd under launchd is ``~/.halton-meter``, whose basename is
``.halton-meter`` — that is what produced the ``.halton-meter``
project name in v0.1.7 reports (Gap 6, v0.1.8).

Project names are post-processed to refuse a leading dot: a leading
dot is stripped; if the result is empty the name becomes
``"unattributed"``. This keeps system-directory basenames out of the
report column.

This function is intentionally synchronous — it runs in the mitmproxy
proxy hot path and must be fast. All I/O is filesystem-only (no network,
no DB writes).

Decision reference: memory/decisions.md 2026-04-28 — "Project tagging
precedence: env var over .haltonrc"
"""

from __future__ import annotations

import os
from pathlib import Path

import structlog

log = structlog.get_logger()

_RCFILE_NAME = ".haltonrc"
_ENV_VAR = "HALTON_PROJECT"
_UNATTRIBUTED = "unattributed"


def _get_process_cwd(flow: object) -> str | None:
    """
    Attempt to resolve the working directory of the process that opened
    the connection represented by the given flow.

    Uses psutil to look up the client PID from the flow's client connection.
    Returns ``None`` on any failure (no flow, non-HTTPFlow, no peername,
    PID not found, psutil unavailable, etc.). The caller is expected to
    fall back to ``"unattributed"`` rather than ``os.getcwd()``: the
    daemon's own cwd under launchd is ``~/.halton-meter`` and using
    that as a project name produces the ``.halton-meter`` mis-attribution
    fixed in v0.1.8 Gap 6.
    """
    try:
        import psutil  # type: ignore[import-untyped]
        from mitmproxy import http  # type: ignore[import-untyped]

        if not isinstance(flow, http.HTTPFlow):
            return None

        client_conn = flow.client_conn
        # client_conn.peername is (host, port) for the connecting client
        # For local processes this is the loopback address.
        # We look up by port to find the owning PID.
        client_port: int | None = None
        if client_conn.peername:
            client_port = client_conn.peername[1]

        if client_port is None:
            return None

        # Walk all connections to find the process owning this port.
        # psutil 6+ uses net_connections() as a method; older versions exposed
        # "connections" as a process_iter attr. Try both.
        for proc in psutil.process_iter(["pid"]):
            try:
                try:
                    conns = proc.net_connections()   # psutil >= 6.0
                except AttributeError:
                    conns = proc.connections()       # psutil < 6.0
                for conn in conns:
                    if hasattr(conn, "laddr") and conn.laddr and conn.laddr.port == client_port:
                        return proc.cwd()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

    except Exception as exc:
        log.debug("tagging.cwd_lookup_failed", error=str(exc))

    return None


def _sanitize_project_name(name: str) -> str:
    """Refuse leading-dot project names (v0.1.8 Gap 6).

    A leading dot is stripped (``.halton-meter`` → ``halton-meter``).
    If the result is empty, returns ``"unattributed"``. Whitespace-only
    inputs are also normalised to ``"unattributed"``.
    """
    stripped = name.strip()
    while stripped.startswith("."):
        stripped = stripped[1:]
    stripped = stripped.strip()
    if not stripped:
        return _UNATTRIBUTED
    return stripped


def _read_haltonrc(start_dir: str) -> str | None:
    """
    Walk from start_dir upward, looking for a .haltonrc file.

    File format (simple line scan — no YAML parser dependency):
        project: my-project-name

    Returns the project name if found and non-empty, or None.
    """
    current = Path(start_dir).resolve()
    while True:
        rc_file = current / _RCFILE_NAME
        if rc_file.is_file():
            try:
                content = rc_file.read_text(encoding="utf-8")
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("project:"):
                        value = stripped[len("project:"):].strip()
                        if value:
                            log.debug(
                                "tagging.rcfile_found",
                                path=str(rc_file),
                                project=value,
                            )
                            return value
            except OSError as exc:
                log.debug("tagging.rcfile_read_error", path=str(rc_file), error=str(exc))

        parent = current.parent
        if parent == current:
            # Reached filesystem root
            break
        current = parent

    return None


def resolve_project(flow: object) -> str:
    """
    Resolve the project name for a given mitmproxy HTTPFlow.

    Precedence:
      1. HALTON_PROJECT environment variable on the originating process
         (read from os.environ — the daemon process's environment reflects
         the system environment at startup; for true per-process env lookup
         we would need psutil, but env var is typically set at daemon level
         or exported before starting the proxy client process)
      2. .haltonrc file found by walking upward from the originating
         process's working directory
      3. Basename of the originating process's working directory
      4. "unknown"

    The attribution method is logged so debugging is possible.
    """
    # Step 1 — HALTON_PROJECT env var
    env_project = os.environ.get(_ENV_VAR, "").strip()
    if env_project:
        sanitized = _sanitize_project_name(env_project)
        log.debug("tagging.resolved", method="env", project=sanitized)
        return sanitized

    # Determine the originating process's working directory.
    #
    # If the lookup fails (psutil can't peer into the source process
    # — common for ``claude`` and other Mach-O binaries) we MUST NOT
    # fall back to ``os.getcwd()``. The daemon's own cwd under
    # launchd is ``~/.halton-meter``; using its basename produces
    # the bogus ``.halton-meter`` project name. Short-circuit to
    # ``unattributed`` instead. (v0.1.8 Gap 6.)
    try:
        cwd = _get_process_cwd(flow)
    except Exception as exc:
        log.debug("tagging.cwd_error", error=str(exc))
        cwd = None

    if cwd is None:
        log.debug("tagging.resolved", method="unattributed", reason="no_cwd")
        return _UNATTRIBUTED

    # Step 2 — .haltonrc walk
    rc_project = _read_haltonrc(cwd)
    if rc_project:
        sanitized = _sanitize_project_name(rc_project)
        log.debug("tagging.resolved", method="rcfile", project=sanitized, cwd=cwd)
        return sanitized

    # Step 3 — workdir basename
    basename = Path(cwd).name
    if basename:
        sanitized = _sanitize_project_name(basename)
        log.debug("tagging.resolved", method="workdir", project=sanitized, cwd=cwd)
        return sanitized

    # Step 4 — unattributed
    log.debug("tagging.resolved", method="unattributed", cwd=cwd)
    return _UNATTRIBUTED
