"""Lifecycle CLI orchestrator: ``halton-meter start | stop | status`` (Phase 2B.8).

Wraps ``launchctl load|unload|list`` (macOS) / ``systemctl --user`` (Linux)
into ergonomic commands that close the gaps left by ``install`` / ``uninstall``:

* ``start`` is "I want metering on without re-running the cert + proxy
  setup steps". Refuses up-front if the daemon's ports are held by an
  unrelated process; reuses ``init._detect_live_daemon`` for the
  already-loaded check; verifies ``/health`` comes up before claiming
  success.
* ``stop`` is "I want metering paused without losing my install state".
  Unloads both plists, then absorbs the manual
  ``lsof -ti :8765 | xargs kill -9`` recovery dance if any zombie still
  holds the ports. Does NOT touch the system proxy (that's
  ``uninstall``'s load-bearing recovery line).
* ``status`` is the single-pane "is metering working?" view. Reports
  daemon, watchdog, system proxy, sentinel, cert trust, and latest
  capture state in a Rich table or as JSON via ``--json``.

Pure orchestrator — no new functionality lives here that isn't a thin
wrapper over existing modules. Each public entry point returns a process
exit code. macOS is the priority path; Linux is best-effort via
systemctl --user; Windows prints "not yet supported".
"""

from __future__ import annotations

import json as _json
import os
import signal as _signal
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from halton_meter.config import load_config
from halton_meter.init import _detect_live_daemon
from halton_meter.install import (
    _EDGE_LABEL,
    _LABEL,
    _LINUX_UNIT_NAME,
    _LINUX_WATCHDOG_UNIT_NAME,
    _WATCHDOG_LABEL,
    _linux_unit_path,
    _linux_watchdog_unit_path,
    _macos_edge_plist_path,
    _macos_paths,
    _macos_watchdog_plist_path,
    _proxy_managed_sentinel_path,
)
from halton_meter.port_alloc import load_effective_config

# Exit codes
_EXIT_OK = 0
_EXIT_FAILED = 1


# --------------------------------------------------------------------------- #
# launchctl helpers                                                            #
# --------------------------------------------------------------------------- #


def _launchctl_label_pid(label: str) -> int | None:
    """Return the PID launchctl reports for ``label``, or None if unknown / not running.

    Modern macOS surfaces the PID via ``launchctl list <label>`` as a
    plist-like fragment containing ``"PID" = <int>;``. When the label
    is registered but not currently running launchctl prints ``"PID"
    = -;`` or omits the key entirely. When the label is unknown
    launchctl exits non-zero.
    """
    if sys.platform != "darwin":
        return None
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        # `"PID" = 81234;`  (running)   or  `"PID" = -;`  (not running)
        if line.startswith('"PID"'):
            _, _, rhs = line.partition("=")
            value = rhs.strip().rstrip(";").strip()
            if value == "-" or not value:
                return None
            try:
                return int(value)
            except ValueError:
                return None
    return None


def _launchctl_label_known(label: str) -> bool:
    """Return True iff ``launchctl list <label>`` exits 0 (label is registered)."""
    if sys.platform != "darwin":
        return False
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _detect_live_watchdog() -> bool:
    """Return True iff launchctl reports a live watchdog agent (mirror of
    :func:`init._detect_live_daemon`)."""
    if sys.platform != "darwin":
        return False
    try:
        uid = os.getuid()
    except AttributeError:
        return False
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{_WATCHDOG_LABEL}"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


# --------------------------------------------------------------------------- #
# Port + process helpers                                                       #
# --------------------------------------------------------------------------- #


def _lsof_pids_on_port(port: int) -> list[int]:
    """Return the list of PIDs holding ``port`` according to ``lsof -ti :<port>``.

    Empty list when nothing is bound (or lsof is unavailable). Caller is
    responsible for distinguishing "managed by us" vs "orphan".
    """
    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode not in (0, 1):
        # rc 1 from lsof can mean "nothing matched" — treat as empty.
        return []
    pids: list[int] = []
    for tok in result.stdout.split():
        try:
            pids.append(int(tok.strip()))
        except ValueError:
            continue
    return pids


def _process_name(pid: int) -> str:
    """Best-effort: return the process name for ``pid`` via ``ps``."""
    try:
        result = subprocess.run(
            ["ps", "-o", "comm=", "-p", str(pid)],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "unknown"
    name = (result.stdout or "").strip().splitlines()
    if not name:
        return "unknown"
    return name[0].strip() or "unknown"


def _our_managed_pids() -> set[int]:
    """Return the PIDs launchctl reports as belonging to our two labels."""
    pids: set[int] = set()
    for label in (_LABEL, _WATCHDOG_LABEL):
        pid = _launchctl_label_pid(label)
        if pid is not None:
            pids.add(pid)
    return pids


# --------------------------------------------------------------------------- #
# /health                                                                     #
# --------------------------------------------------------------------------- #


def _poll_health_with_latency(api_port: int, timeout: float = 1.0) -> tuple[bool, float | None]:
    """Single ``/health`` poll with millisecond latency. ``(healthy, ms)``."""
    import json as _j
    import urllib.error
    import urllib.request

    url = f"http://127.0.0.1:{api_port}/health"
    started = time.monotonic()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return (False, None)
            body = resp.read()
            try:
                payload = _j.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return (False, None)
            ms = (time.monotonic() - started) * 1000.0
            return (
                isinstance(payload, dict) and payload.get("status") == "ok",
                ms,
            )
    except (urllib.error.URLError, TimeoutError, OSError):
        return (False, None)
    except Exception:
        return (False, None)


def _wait_for_health(api_port: int, *, timeout_seconds: float = 15.0) -> tuple[bool, float | None]:
    """Poll /health until healthy or ``timeout_seconds`` elapse.

    Default is 15s (was 5s pre-2B.10.2): Python 3.14 cold-start through
    `halton-meter start`'s `launchctl load` path can take longer than 5s
    on a freshly-booted Mac before uvicorn binds. 15s ceiling matches the
    cadence in 2B.10.1's smoke scripts (which use 10x1s on top of a 1s
    settle). Cold-start is the only realistic regression here; on warm
    starts /health responds in <1s and the wait returns immediately.
    """
    deadline = time.monotonic() + timeout_seconds
    last_ms: float | None = None
    while time.monotonic() < deadline:
        ok, ms = _poll_health_with_latency(api_port, timeout=0.75)
        if ok:
            return (True, ms)
        last_ms = ms
        time.sleep(0.25)
    return (False, last_ms)


# --------------------------------------------------------------------------- #
# Cert trust check (delegates to setup module)                                 #
# --------------------------------------------------------------------------- #


def _is_cert_trusted() -> bool:
    """macOS-only cert-trust check; delegates to setup._is_cert_trusted_macos."""
    if sys.platform != "darwin":
        return False
    try:
        from halton_meter.setup import _is_cert_trusted_macos
        return _is_cert_trusted_macos()
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# System proxy state                                                           #
# --------------------------------------------------------------------------- #


def _system_proxy_state(host: str, port: int) -> tuple[str, str]:
    """Return ``(state, detail)`` for the system proxy row.

    States: ``enabled`` (points at us, on) / ``pointed elsewhere``
    (on but address differs) / ``disabled`` (off or absent).
    """
    if sys.platform != "darwin":
        return ("not applicable", "Linux: managed via HTTPS_PROXY env var")
    from halton_meter import system_proxy

    enabled_anywhere = False
    matching_iface: str | None = None
    other_target: str | None = None
    for iface in system_proxy._macos_interfaces():
        for secure in (True, False):
            enabled, current_host, current_port = system_proxy._read_macos_proxy(
                iface, secure=secure
            )
            if not enabled:
                continue
            enabled_anywhere = True
            if system_proxy._proxy_targets_us(current_host, current_port, host, port):
                matching_iface = iface
                break
            if other_target is None and current_host:
                other_target = f"{current_host}:{current_port or '?'}"
        if matching_iface is not None:
            break

    if matching_iface is not None:
        return ("enabled", f"{host}:{port} on {matching_iface}")
    if enabled_anywhere:
        return (
            "pointed elsewhere",
            f"system proxy on but address={other_target or 'unknown'}",
        )
    return ("disabled", "no interface routing through halton-meter")


# --------------------------------------------------------------------------- #
# Effective ports row with auto-fallback marker (v0.1.4 P0-5)                 #
# --------------------------------------------------------------------------- #


def _port_status_row(listen_port: int, api_port: int) -> _ComponentRow:
    """Build the "Effective ports" row, marking auto-fallback explicitly.

    When the proxy listener or HTTP API uses a non-default port (e.g.
    8081 instead of 8080), the detail string includes ``"(fallback
    from busy default 8080)"`` so the user knows their tool config
    must target the actual port, not the marketed default.

    State: ``default`` (both ports at default) / ``fallback`` (at
    least one differs). Both states are non-failing — the row is
    informational, not a health signal.
    """
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    parts: list[str] = []
    parts.append(f"proxy=:{listen_port}")
    parts.append(f"api=:{api_port}")
    fallback_notes: list[str] = []
    if listen_port != LISTEN_PORT_DEFAULT:
        fallback_notes.append(
            f"proxy fell back from busy default :{LISTEN_PORT_DEFAULT} to :{listen_port}"
        )
    if api_port != API_PORT_DEFAULT:
        fallback_notes.append(
            f"api fell back from busy default :{API_PORT_DEFAULT} to :{api_port}"
        )
    if fallback_notes:
        return _ComponentRow(
            "Effective ports", "fallback", "; ".join(fallback_notes)
        )
    return _ComponentRow(
        "Effective ports", "default", " ".join(parts)
    )


# --------------------------------------------------------------------------- #
# Latest capture (SQLite read)                                                 #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class _LatestCapture:
    found: bool
    db_missing: bool
    timestamp_iso: str | None = None
    seconds_ago: float | None = None
    model: str | None = None
    project: str | None = None
    cost_usd_minor_units: int | None = None
    captured_last_hour: int = 0
    captured_last_day: int = 0


def _latest_capture(db_path: str) -> _LatestCapture:
    """Read the latest capture row + window counts from SQLite. Defensive."""
    from datetime import UTC, datetime

    expanded = Path(db_path).expanduser()
    if not expanded.exists():
        return _LatestCapture(found=False, db_missing=True)

    try:
        conn = sqlite3.connect(f"file:{expanded}?mode=ro", uri=True, timeout=2.0)
    except sqlite3.Error:
        return _LatestCapture(found=False, db_missing=True)

    try:
        cur = conn.cursor()
        try:
            cur.execute(
                "SELECT requested_at, model, project_id, cost_usd_minor_units "
                "FROM requests ORDER BY requested_at DESC LIMIT 1"
            )
            row = cur.fetchone()
        except sqlite3.Error:
            return _LatestCapture(found=False, db_missing=False)

        if row is None:
            return _LatestCapture(found=False, db_missing=False)

        ts_str, model, project_id, cost = row

        seconds_ago: float | None = None
        try:
            ts = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=UTC)
            seconds_ago = (datetime.now(tz=UTC) - ts).total_seconds()
        except (ValueError, TypeError):
            pass

        # Window counts. Use SQLite datetime() arithmetic on the
        # ISO-8601 strings; if requested_at is malformed for some
        # rows the predicate just skips them.
        last_hour = 0
        last_day = 0
        try:
            cur.execute(
                "SELECT COUNT(*) FROM requests WHERE "
                "requested_at >= datetime('now', '-1 hour')"
            )
            last_hour = int(cur.fetchone()[0] or 0)
            cur.execute(
                "SELECT COUNT(*) FROM requests WHERE "
                "requested_at >= datetime('now', '-1 day')"
            )
            last_day = int(cur.fetchone()[0] or 0)
        except sqlite3.Error:
            pass

        # Resolve project slug from id (best-effort).
        project_slug: str | None = None
        try:
            cur.execute("SELECT slug FROM projects WHERE id = ?", (project_id,))
            slug_row = cur.fetchone()
            if slug_row:
                project_slug = str(slug_row[0])
        except sqlite3.Error:
            pass

        return _LatestCapture(
            found=True,
            db_missing=False,
            timestamp_iso=str(ts_str) if ts_str else None,
            seconds_ago=seconds_ago,
            model=str(model) if model else None,
            project=project_slug,
            cost_usd_minor_units=int(cost) if cost is not None else None,
            captured_last_hour=last_hour,
            captured_last_day=last_day,
        )
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


# --------------------------------------------------------------------------- #
# Status assembly                                                              #
# --------------------------------------------------------------------------- #


@dataclass
class _ComponentRow:
    name: str
    state: str
    detail: str


# v0.1.3 P0-8: mode-aware health summary at the top of `halton-meter status`.
@dataclass
class _HealthSummary:
    """Mode-aware verdict computed from component rows + install mode."""

    severity: str  # "HEALTHY" | "INCONSISTENT" | "BROKEN"
    message: str  # one-line user-facing summary


@dataclass
class _StatusReport:
    healthy: bool
    rows: list[_ComponentRow] = field(default_factory=list)
    last_hour: int = 0
    last_day: int = 0
    platform: str = ""
    health_summary: _HealthSummary | None = None

    def to_json_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "healthy": self.healthy,
            "platform": self.platform,
            "components": [
                {"name": r.name, "state": r.state, "detail": r.detail}
                for r in self.rows
            ],
            "captured_last_hour": self.last_hour,
            "captured_last_day": self.last_day,
        }
        if self.health_summary is not None:
            payload["health_summary"] = {
                "severity": self.health_summary.severity,
                "message": self.health_summary.message,
            }
        return payload


def _compute_health_summary_macos(
    rows: list[_ComponentRow], install_mode: str | None
) -> _HealthSummary:
    """Compute the mode-aware top-line verdict (v0.1.5 (2B.16) three modes).

    Decision matrix:

    * env-only: HEALTHY when daemon healthy + cert trusted. System proxy
      state is informational (we don't manage it in this mode).
    * apps: HEALTHY when daemon + cert trusted AND system proxy is
      DISABLED on our interfaces. System proxy enabled in apps mode is
      DRIFT (BROKEN) — apps mode promises not to manage system proxy.
    * full: HEALTHY when daemon + cert trusted AND system proxy is
      enabled at us. BROKEN if proxy enabled but cert not trusted
      (totaljobs.com cert↔proxy invariant). INCONSISTENT if proxy not
      enabled.
    * unknown mode (sentinel missing): INCONSISTENT to nudge re-init.

    Legacy ``gui`` sentinel value is read by ``init.read_install_mode``
    as the canonical ``full`` — this function only sees canonical
    names.
    """
    by_name = {r.name: r for r in rows}
    daemon = by_name.get("Daemon")
    proxy = by_name.get("System proxy")
    cert = by_name.get("Cert trust")

    daemon_ok = daemon is not None and daemon.state == "healthy"
    cert_trusted = cert is not None and cert.state == "trusted"
    proxy_enabled = proxy is not None and proxy.state == "enabled"

    if not daemon_ok:
        return _HealthSummary(
            "BROKEN",
            "daemon is not healthy — run `halton-meter start`",
        )

    if install_mode == "env-only":
        if cert_trusted:
            return _HealthSummary(
                "HEALTHY",
                "env-var-only mode: use `halton-meter run <command>` to meter "
                "Claude Code, SDK clients, etc. For terminal + Spotlight-app "
                "coverage, re-run `halton-meter init --apps`. For broadest "
                "coverage (browsers + GUI apps), re-run "
                "`halton-meter init --full`.",
            )
        return _HealthSummary(
            "BROKEN",
            "cert is not trusted — run `halton-meter setup --force`",
        )

    if install_mode == "apps":
        if not cert_trusted:
            return _HealthSummary(
                "BROKEN",
                "cert is not trusted — run `halton-meter setup --force`",
            )
        if proxy_enabled:
            # Drift: apps mode promises NOT to manage system proxy.
            return _HealthSummary(
                "BROKEN",
                "system proxy is enabled but install-mode is `apps` "
                "(stale full-mode state). Re-run "
                "`halton-meter init --apps` to reconcile.",
            )
        return _HealthSummary(
            "HEALTHY",
            "--apps mode is healthy. New shells + Spotlight-spawned apps are "
            "metered; system proxy is intentionally unmanaged.",
        )

    # Full or unknown mode follows the v0.1.2 invariant: proxy enabled
    # implies cert must be trusted.
    if proxy_enabled and not cert_trusted:
        return _HealthSummary(
            "BROKEN",
            "system proxy enabled but cert is not trusted "
            "(SecTrust will reject TLS) — run `halton-meter reset-proxy`",
        )

    if install_mode == "full":
        if not proxy_enabled:
            return _HealthSummary(
                "INCONSISTENT",
                "--full mode but system proxy not enabled — "
                "run `halton-meter start`",
            )
        if cert_trusted:
            return _HealthSummary("HEALTHY", "--full mode is healthy.")
        return _HealthSummary(
            "BROKEN",
            "--full mode requires cert to be trusted — "
            "run `halton-meter setup --force`",
        )

    # Unknown mode.
    if proxy_enabled and cert_trusted:
        return _HealthSummary(
            "INCONSISTENT",
            "install-mode sentinel missing (older install). "
            "Re-run `halton-meter init` to reconcile.",
        )
    return _HealthSummary(
        "INCONSISTENT",
        "install-mode sentinel missing — run `halton-meter init`.",
    )


def _detect_graceful_uninstall_macos(cfg: Any) -> _StatusReport | None:
    """Detect the post-`uninstall --graceful` state and render a one-row table.

    v0.1.10 Gap 16. After `halton-meter uninstall --graceful` the edge
    process is alive (in pure passthrough), but the daemon and watchdog
    plists are gone, the install-mode sentinel was removed, and the
    edge plist file itself was removed from `~/Library/LaunchAgents/`.
    The standard `_build_status_macos` would render this as a wall of
    "not installed" red and a BROKEN verdict — confusing the user out
    of an explicit, expected state.

    Detection requires ALL FOUR conditions:

    * Edge label has a live PID (via `_launchctl_label_pid`)
    * Daemon label is unknown to launchctl
    * Install-mode sentinel `~/.halton-meter/proxy-managed` is missing
    * Edge plist file is missing from `~/Library/LaunchAgents/`

    All four are necessary because partial states (e.g. only the
    sentinel was deleted) are NOT graceful-uninstall — they are drift
    that should keep going to the standard render so the user sees the
    inconsistency.

    Returns the special `_StatusReport` when matched, else ``None``.
    """
    edge_pid = _launchctl_label_pid(_EDGE_LABEL)
    if edge_pid is None:
        return None
    if _launchctl_label_known(_LABEL):
        return None
    if _proxy_managed_sentinel_path().exists():
        return None
    if _macos_edge_plist_path().exists():
        return None

    detail = (
        f"PID {edge_pid}, port=:{cfg.daemon.edge_port} "
        "(no metering — edge tunnels direct to upstream until next reboot)"
    )
    row = _ComponentRow("Graceful uninstall", "edge in passthrough", detail)
    summary = _HealthSummary(
        "HEALTHY",
        "graceful uninstall is in effect — edge proxy is still running in "
        "pure-passthrough so apps with HTTPS_PROXY baked in keep working. "
        "No metering until next reboot. Re-run `halton-meter init` to "
        "restore metering.",
    )
    return _StatusReport(
        healthy=True,
        rows=[row],
        last_hour=0,
        last_day=0,
        platform="darwin",
        health_summary=summary,
    )


def _build_status_macos(cfg: Any) -> _StatusReport:
    # v0.1.10 Gap 16: pre-empt the standard table when the post-graceful
    # signature is present (edge alive, daemon label unknown, sentinel
    # gone, edge plist gone). Pure rendering pre-emption — the standard
    # path below is unchanged.
    graceful = _detect_graceful_uninstall_macos(cfg)
    if graceful is not None:
        return graceful

    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()
    sentinel_path = _proxy_managed_sentinel_path()

    rows: list[_ComponentRow] = []
    healthy = True

    # Daemon row.
    if not plist_path.exists():
        rows.append(_ComponentRow("Daemon", "not installed", f"{plist_path} missing"))
        healthy = False
    else:
        daemon_pid = _launchctl_label_pid(_LABEL)
        if daemon_pid is None:
            registered = _launchctl_label_known(_LABEL)
            if not registered:
                rows.append(
                    _ComponentRow(
                        "Daemon", "not loaded",
                        f"label {_LABEL} unknown to launchctl",
                    )
                )
                healthy = False
            else:
                rows.append(
                    _ComponentRow("Daemon", "loaded", "label registered, no live PID")
                )
                healthy = False
        else:
            ok, ms = _poll_health_with_latency(cfg.daemon.api_port)
            if ok:
                latency_str = f"{ms:.0f}ms" if ms is not None else "—"
                rows.append(
                    _ComponentRow(
                        "Daemon",
                        "healthy",
                        # 2C.2 (v0.1.6): the daemon binds internal_port now
                        # — the edge owns the user-facing edge_port. Surface
                        # both in the detail string so operators can tell at
                        # a glance which process they're inspecting.
                        f"PID {daemon_pid}, internal=:{cfg.daemon.internal_port}, "
                        f"/health OK ({latency_str})",
                    )
                )
            else:
                rows.append(
                    _ComponentRow(
                        "Daemon",
                        "loaded",
                        f"PID {daemon_pid}, internal=:{cfg.daemon.internal_port}, "
                        f"/health failed on :{cfg.daemon.api_port}",
                    )
                )
                healthy = False

    # Watchdog row.
    if not watchdog_plist_path.exists():
        rows.append(_ComponentRow("Watchdog", "not installed", f"{watchdog_plist_path} missing"))
        healthy = False
    else:
        watchdog_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
        if watchdog_pid is None:
            if _launchctl_label_known(_WATCHDOG_LABEL):
                rows.append(_ComponentRow("Watchdog", "loaded", "label registered, no live PID"))
                healthy = False
            else:
                rows.append(
                    _ComponentRow(
                        "Watchdog", "not loaded",
                        f"label {_WATCHDOG_LABEL} unknown",
                    )
                )
                healthy = False
        else:
            rows.append(_ComponentRow("Watchdog", "healthy", f"PID {watchdog_pid}"))

    # 2C.2 (v0.1.6): Edge proxy row. The edge owns the user-facing
    # HTTPS_PROXY port — apps see it. It must stay running across every
    # daemon transition. Without this row a stopped/dead edge would be
    # invisible until apps started failing.
    edge_plist_path = _macos_edge_plist_path()
    if not edge_plist_path.exists():
        rows.append(
            _ComponentRow("Edge", "not installed", f"{edge_plist_path} missing")
        )
        healthy = False
    else:
        edge_pid = _launchctl_label_pid(_EDGE_LABEL)
        if edge_pid is None:
            if _launchctl_label_known(_EDGE_LABEL):
                rows.append(
                    _ComponentRow(
                        "Edge", "loaded", "label registered, no live PID"
                    )
                )
                healthy = False
            else:
                rows.append(
                    _ComponentRow(
                        "Edge", "not loaded",
                        f"label {_EDGE_LABEL} unknown",
                    )
                )
                healthy = False
        else:
            # v0.1.7 Gap 0: surface the edge's actual chain target.
            # When the edge bound to a stale internal_port (port-fallback
            # race) the row goes from "healthy" to "stale chain" so the
            # operator sees the silent metering loss in `status` itself,
            # not just in `doctor`.
            edge_detail = f"PID {edge_pid}, port=:{cfg.daemon.edge_port}"
            edge_state_status = "healthy"
            try:
                from halton_meter.port_alloc import read_edge_state_toml

                edge_state = read_edge_state_toml()
                edge_chain = edge_state.get("chain_port")
                edge_state_pid = edge_state.get("pid")
                runtime_internal = int(cfg.daemon.internal_port)
                if (
                    edge_chain is not None
                    and edge_state_pid == edge_pid
                ):
                    if edge_chain == runtime_internal:
                        edge_detail += f" -> chain :{edge_chain} ✓"
                    else:
                        edge_detail += (
                            f" -> chain :{edge_chain} ✗ "
                            f"(daemon on :{runtime_internal})"
                        )
                        edge_state_status = "stale chain"
                        healthy = False
            except Exception:
                pass
            rows.append(
                _ComponentRow(
                    "Edge",
                    edge_state_status,
                    edge_detail,
                )
            )

    # Effective ports row (v0.1.4 P0-5). When auto-port-fallback fired
    # (chosen port differs from default), make it explicit so the user
    # knows their tools must point at the actual port — not the
    # default. Witnessed: the daemon picked 8081 because 8080 was
    # busy; user wasn't sure which port to configure.
    rows.append(_port_status_row(cfg.daemon.edge_port, cfg.daemon.api_port))

    # System proxy row.
    proxy_state, proxy_detail = _system_proxy_state(
        cfg.daemon.listen_host, cfg.daemon.edge_port
    )
    rows.append(_ComponentRow("System proxy", proxy_state, proxy_detail))
    if proxy_state != "enabled":
        healthy = False

    # Sentinel row.
    if sentinel_path.exists():
        rows.append(_ComponentRow("Sentinel file", "present", str(sentinel_path)))
    else:
        rows.append(_ComponentRow("Sentinel file", "missing", str(sentinel_path)))
        # Sentinel missing is informative but doesn't itself fail status.

    # Cert trust row.
    if _is_cert_trusted():
        rows.append(_ComponentRow("Cert trust", "trusted", "/Library/Keychains/System.keychain"))
    else:
        rows.append(_ComponentRow("Cert trust", "not trusted", "run `halton-meter setup`"))

    # Latest capture row.
    capture = _latest_capture(cfg.storage.db_path)
    if capture.db_missing:
        rows.append(_ComponentRow("Latest capture", "database not found", cfg.storage.db_path))
    elif not capture.found:
        rows.append(_ComponentRow("Latest capture", "no captures yet", "database empty"))
    else:
        ago = "?"
        if capture.seconds_ago is not None:
            ago = _humanize_seconds(capture.seconds_ago)
        cost_str = ""
        if capture.cost_usd_minor_units is not None:
            cost_str = f" / ${capture.cost_usd_minor_units / 100_000:.4f}"
        detail = (
            f"{capture.model or '—'} / {capture.project or '—'}{cost_str}"
        )
        rows.append(_ComponentRow("Latest capture", f"{ago} ago", detail))

    # P0-8: mode-aware health summary.
    from halton_meter.init import read_install_mode

    install_mode = read_install_mode()
    health_summary = _compute_health_summary_macos(rows, install_mode)
    # v0.1.5 (2B.16): mode-aware Capture hint row.
    if install_mode == "env-only":
        rows.append(
            _ComponentRow(
                "Capture",
                "env-var-only",
                "use `halton-meter run <command>` to meter CLI / SDK clients. "
                "Re-run `halton-meter init --apps` for terminal + "
                "Spotlight-app coverage, or `init --full` for browsers too.",
            )
        )
    elif install_mode == "apps":
        rows.append(
            _ComponentRow(
                "Capture",
                "apps mode",
                "new shells + Spotlight-spawned apps inherit the proxy env "
                "vars; browsers flow direct. For browser coverage re-run "
                "`halton-meter init --full`.",
            )
        )

    return _StatusReport(
        healthy=healthy,
        rows=rows,
        last_hour=capture.captured_last_hour,
        last_day=capture.captured_last_day,
        platform="darwin",
        health_summary=health_summary,
    )


def _build_status_linux(cfg: Any) -> _StatusReport:
    rows: list[_ComponentRow] = []
    healthy = True

    daemon_unit_path = _linux_unit_path()
    watchdog_unit_path = _linux_watchdog_unit_path()

    daemon_active = (
        _systemctl_is_active(_LINUX_UNIT_NAME)
        if daemon_unit_path.exists()
        else "not installed"
    )
    watchdog_active = (
        _systemctl_is_active(_LINUX_WATCHDOG_UNIT_NAME)
        if watchdog_unit_path.exists()
        else "not installed"
    )
    if daemon_active == "active":
        rows.append(_ComponentRow("Daemon", "healthy", f"systemd unit {_LINUX_UNIT_NAME} active"))
    else:
        rows.append(_ComponentRow("Daemon", daemon_active, _LINUX_UNIT_NAME))
        healthy = False
    if watchdog_active == "active":
        rows.append(
            _ComponentRow(
                "Watchdog", "healthy",
                f"systemd unit {_LINUX_WATCHDOG_UNIT_NAME} active",
            )
        )
    else:
        rows.append(_ComponentRow("Watchdog", watchdog_active, _LINUX_WATCHDOG_UNIT_NAME))
        healthy = False

    # Linux: skip system-proxy row (not managed by this tool).

    # Latest capture row.
    capture = _latest_capture(cfg.storage.db_path)
    if capture.db_missing:
        rows.append(_ComponentRow("Latest capture", "database not found", cfg.storage.db_path))
    elif not capture.found:
        rows.append(_ComponentRow("Latest capture", "no captures yet", "database empty"))
    else:
        ago = "?"
        if capture.seconds_ago is not None:
            ago = _humanize_seconds(capture.seconds_ago)
        rows.append(
            _ComponentRow(
                "Latest capture",
                f"{ago} ago",
                f"{capture.model or '—'} / {capture.project or '—'}",
            )
        )

    return _StatusReport(
        healthy=healthy,
        rows=rows,
        last_hour=capture.captured_last_hour,
        last_day=capture.captured_last_day,
        platform="linux",
    )


def _systemctl_is_active(unit: str) -> str:
    try:
        result = subprocess.run(
            ["systemctl", "--user", "is-active", unit],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "unknown"
    state = (result.stdout or "").strip()
    return state or "unknown"


def _humanize_seconds(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s"
    if seconds < 3600:
        return f"{int(seconds / 60)}m"
    if seconds < 86400:
        return f"{int(seconds / 3600)}h"
    return f"{int(seconds / 86400)}d"


def _render_status(report: _StatusReport, console: Console) -> None:
    # P0-8: render the mode-aware health summary above the table.
    if report.health_summary is not None:
        color = {
            "HEALTHY": "green",
            "INCONSISTENT": "yellow",
            "BROKEN": "red",
        }.get(report.health_summary.severity, "white")
        console.print(
            f"[bold {color}]{report.health_summary.severity}[/bold {color}] "
            f"— {report.health_summary.message}"
        )

    table = Table(title="halton-meter status", show_lines=False, expand=False)
    table.add_column("Component", style="bold")
    table.add_column("State")
    table.add_column("Detail")
    state_styles = {
        "healthy": "green",
        "trusted": "green",
        "enabled": "green",
        "present": "green",
        "default": "green",  # P0-5: effective ports at the marketed default
        "loaded": "yellow",
        "pointed elsewhere": "yellow",
        "missing": "yellow",
        "no captures yet": "yellow",
        "fallback": "yellow",  # P0-5: auto-fallback fired (informative)
        "edge in passthrough": "yellow",  # v0.1.10 Gap 16: graceful-uninstall row
        "not loaded": "red",
        "not installed": "red",
        "not trusted": "red",
        "disabled": "red",
        "database not found": "red",
        "unknown": "red",
        "inactive": "red",
        "failed": "red",
    }
    for row in report.rows:
        style = state_styles.get(row.state, "")
        if not style and row.state.endswith(" ago"):
            style = "green"
        rendered_state = f"[{style}]{row.state}[/{style}]" if style else row.state
        table.add_row(row.name, rendered_state, row.detail)
    console.print(table)
    console.print(
        f"\nTests captured (last 1h):  [bold]{report.last_hour:,}[/bold]\n"
        f"Tests captured (last 24h): [bold]{report.last_day:,}[/bold]"
    )


# --------------------------------------------------------------------------- #
# Public entry points                                                          #
# --------------------------------------------------------------------------- #


def start(*, console: Console | None = None) -> int:
    """Load both launchd plists; refuse if ports are held by another process.

    Idempotent — ``start`` of an already-started service is a no-op
    success. macOS path is fully implemented; Linux delegates to
    ``systemctl --user start``; Windows prints "not yet supported".
    """
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter start is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK
    if platform == "darwin":
        return _start_macos(console)
    if platform.startswith("linux"):
        return _start_linux(console)
    console.print(f"[red]unsupported platform: {platform}[/red]")
    return _EXIT_FAILED


def stop(*, console: Console | None = None) -> int:
    """Unload both launchd plists, kill orphan port-holders, reset the system proxy.

    The sentinel file (``~/.halton-meter/proxy-managed``) is preserved so
    ``halton-meter start`` can resume cleanly via the daemon's Option-1
    startup re-enable. Use ``halton-meter uninstall`` for full removal
    (plists + sentinel + proxy reset).
    """
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter stop is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK
    if platform == "darwin":
        return _stop_macos(console)
    if platform.startswith("linux"):
        return _stop_linux(console)
    console.print(f"[red]unsupported platform: {platform}[/red]")
    return _EXIT_FAILED


def status(*, console: Console | None = None, json_output: bool = False) -> int:
    """Print a unified view of daemon + watchdog + proxy state."""
    if console is None:
        console = Console()

    platform = sys.platform
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter status is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK

    try:
        cfg = load_effective_config()
    except Exception as exc:
        console.print(f"[red]failed to load config: {exc}[/red]")
        return _EXIT_FAILED

    if platform == "darwin":
        report = _build_status_macos(cfg)
    elif platform.startswith("linux"):
        report = _build_status_linux(cfg)
    else:
        console.print(f"[red]unsupported platform: {platform}[/red]")
        return _EXIT_FAILED

    if json_output:
        # Bypass Rich (which wraps long lines / inserts control codes when
        # the terminal is narrow) — JSON output must be byte-clean for
        # downstream parsers.
        sys.stdout.write(_json.dumps(report.to_json_dict(), indent=2) + "\n")
        sys.stdout.flush()
    else:
        _render_status(report, console)

    return _EXIT_OK if report.healthy else _EXIT_FAILED


# --------------------------------------------------------------------------- #
# macOS implementations                                                        #
# --------------------------------------------------------------------------- #


def _start_macos(console: Console) -> int:
    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()

    # Step 1: detect plists installed.
    if not plist_path.exists() or not watchdog_plist_path.exists():
        console.print(
            "[red]halton-meter is not installed; run `halton-meter init` first.[/red]"
        )
        return _EXIT_FAILED

    try:
        cfg = load_effective_config()
    except Exception as exc:
        console.print(f"[red]failed to load config: {exc}[/red]")
        return _EXIT_FAILED

    # Step 2: detect already-loaded.
    daemon_running = _detect_live_daemon() and _launchctl_label_pid(_LABEL) is not None
    watchdog_running = (
        _detect_live_watchdog() and _launchctl_label_pid(_WATCHDOG_LABEL) is not None
    )
    if daemon_running and watchdog_running:
        d_pid = _launchctl_label_pid(_LABEL)
        w_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
        console.print(
            f"[green]halton-meter is already running[/green] "
            f"(daemon PID {d_pid}, watchdog PID {w_pid})"
        )
        return _EXIT_OK

    # Step 3: detect port conflicts (against unmanaged orphans).
    managed_pids = _our_managed_pids()
    for port in (cfg.daemon.api_port, cfg.daemon.edge_port):
        holders = _lsof_pids_on_port(port)
        orphans = [pid for pid in holders if pid not in managed_pids]
        if orphans:
            pid = orphans[0]
            console.print(
                f"[red]port {port} is held by PID {pid} ({_process_name(pid)}); "
                f"free it before starting halton-meter, or run "
                f"`halton-meter stop` to clear orphans first.[/red]"
            )
            return _EXIT_FAILED

    # Step 4: load both plists.
    for label, path in (
        (_LABEL, plist_path),
        (_WATCHDOG_LABEL, watchdog_plist_path),
    ):
        # Silent unload first so a partial state doesn't refuse load.
        try:
            subprocess.run(
                ["launchctl", "unload", str(path)],
                capture_output=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            pass
        try:
            result = subprocess.run(
                ["launchctl", "load", "-w", str(path)],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            console.print(f"[red]launchctl load failed for {label}: {exc}[/red]")
            return _EXIT_FAILED
        if result.returncode != 0:
            console.print(
                f"[red]launchctl load failed for {label} "
                f"(exit {result.returncode}): {(result.stderr or '').strip()}[/red]"
            )
            return _EXIT_FAILED

    # Step 5: wait + verify /health.
    # 2B.10.2: 15s ceiling (was 5s) — Python 3.14 cold-start can blow past
    # 5s on a freshly-booted Mac, leaving the daemon healthy but `start`
    # exiting non-zero. 15s matches the smoke-script cadence in 2B.10.1.
    healthy, ms = _wait_for_health(cfg.daemon.api_port, timeout_seconds=15.0)
    if not healthy:
        console.print(
            f"[red]daemon loaded but /health never came up on "
            f":{cfg.daemon.api_port} within 15s[/red]"
        )
        _print_err_log_tail(console)
        return _EXIT_FAILED

    # Step 6: success summary.
    daemon_pid = _launchctl_label_pid(_LABEL)
    watchdog_pid = _launchctl_label_pid(_WATCHDOG_LABEL)
    proxy_state, proxy_detail = _system_proxy_state(
        cfg.daemon.listen_host, cfg.daemon.edge_port
    )
    capture = _latest_capture(cfg.storage.db_path)
    last_capture = "no captures yet"
    if capture.db_missing:
        last_capture = "database not found"
    elif capture.found and capture.seconds_ago is not None:
        last_capture = f"{_humanize_seconds(capture.seconds_ago)} ago"

    body = (
        f"[green]✓[/green] Daemon PID [bold]{daemon_pid}[/bold]  "
        f"/health [bold]{ms:.0f}ms[/bold]\n"
        f"[green]✓[/green] Watchdog PID [bold]{watchdog_pid}[/bold]\n"
        f"System proxy: [bold]{proxy_state}[/bold] — {proxy_detail}\n"
        f"Latest capture: [bold]{last_capture}[/bold]"
    )
    console.print(
        Panel(body, title="halton-meter start", border_style="green", expand=False)
    )
    return _EXIT_OK


def _stop_macos(console: Console) -> int:
    plist_path, _, _ = _macos_paths()
    watchdog_plist_path = _macos_watchdog_plist_path()

    plists_present = plist_path.exists() or watchdog_plist_path.exists()

    cfg: Any | None = None
    try:
        cfg = load_config()
    except Exception as exc:
        # Without config we can't kill orphan port-holders, but we can
        # still reset the system proxy — that's the load-bearing step.
        console.print(f"[yellow]warning: failed to load config: {exc}[/yellow]")

    unloaded: list[str] = []
    unload_failed: list[str] = []
    for label, path in (
        (_WATCHDOG_LABEL, watchdog_plist_path),
        (_LABEL, plist_path),
    ):
        if not path.exists():
            continue
        try:
            result = subprocess.run(
                ["launchctl", "unload", str(path)],
                capture_output=True,
                timeout=5,
                check=False,
            )
            if result.returncode == 0:
                unloaded.append(label)
            else:
                unload_failed.append(label)
        except (OSError, subprocess.SubprocessError) as exc:
            console.print(f"[yellow]warning: launchctl unload {label} raised: {exc}[/yellow]")
            unload_failed.append(label)

    # Brief pause to give launchd a chance to actually terminate the process.
    if plists_present:
        time.sleep(0.5)

    # Kill orphan port-holders (best-effort; needs cfg).
    killed: list[tuple[int, str]] = []
    if cfg is not None:
        for port in (cfg.daemon.api_port, cfg.daemon.edge_port):
            for pid in _lsof_pids_on_port(port):
                sig_sent = _terminate_pid(pid)
                if sig_sent:
                    killed.append((pid, sig_sent))

    # Reset the system proxy. Symmetric with `uninstall`'s recovery line:
    # leaving the system proxy pointed at our (now-dead) listener breaks
    # every HTTPS-via-system-proxy client on the machine. The sentinel
    # file is intentionally preserved so `halton-meter start` can resume
    # via the daemon's Option-1 startup re-enable.
    proxy_reset_ifaces = _reset_macos_system_proxy(console)

    body_lines: list[str] = []
    if not plists_present:
        body_lines.append("[yellow]halton-meter is not installed; no plists to unload.[/yellow]")
    if unloaded:
        body_lines.append(f"Unloaded: [bold]{', '.join(unloaded)}[/bold]")
    if unload_failed:
        body_lines.append(
            f"[yellow]Unload returned non-zero: {', '.join(unload_failed)} "
            f"(continuing — system-proxy reset still ran)[/yellow]"
        )
    if killed:
        body_lines.append(
            "Killed orphans: "
            + ", ".join(f"PID {pid} ({sig})" for pid, sig in killed)
        )
    if proxy_reset_ifaces:
        body_lines.append(f"System proxy reset on: [bold]{', '.join(proxy_reset_ifaces)}[/bold]")
    # 2C.2 (v0.1.6): the edge proxy is INTENTIONALLY left running. It
    # owns the user-facing port (HTTPS_PROXY for any app) and tunnels
    # traffic directly to upstream (no metering) until the daemon is
    # restarted. Apps don't need to be restarted.
    edge_port: int | None = None
    if cfg is not None:
        try:
            edge_port = int(cfg.daemon.edge_port)
        except (AttributeError, TypeError, ValueError):
            edge_port = None
    if edge_port is not None:
        body_lines.append(
            f"[bold]Apps still work[/bold] — the edge proxy is still running on "
            f":{edge_port} and will tunnel traffic directly to upstream until "
            f"you run `halton-meter start`. No metering during this period."
        )
    body_lines.append(
        "[dim]Sentinel preserved — `halton-meter start` will re-enable the proxy. "
        "Use `halton-meter uninstall` for full removal.[/dim]"
    )
    console.print(
        Panel("\n".join(body_lines), title="halton-meter stop", border_style="yellow", expand=False)
    )
    return _EXIT_OK


def _reset_macos_system_proxy(console: Console) -> list[str]:
    """Disable the macOS system proxy on Wi-Fi + Ethernet, both secure and
    unsecure. Best-effort — non-zero exits per interface are swallowed
    (not every interface exists on every machine). Returns the list of
    interfaces a reset was attempted on (for the status line).

    Interfaces are enumerated dynamically via
    ``networksetup -listallnetworkservices`` (see ``decisions.md``
    2026-04-30 — "2B.7.2 enumerate macOS network services dynamically")
    so machines without ``Ethernet`` (or with ``Thunderbolt Bridge`` /
    ``iPhone USB`` instead) get their proxy reset on the interfaces that
    actually exist."""
    from halton_meter import system_proxy

    interfaces = system_proxy._macos_interfaces()
    succeeded: list[str] = []
    for iface in interfaces:
        any_ok = False
        for variant in ("-setsecurewebproxystate", "-setwebproxystate"):
            try:
                result = subprocess.run(
                    ["networksetup", variant, iface, "off"],
                    capture_output=True,
                    timeout=5,
                    check=False,
                )
                if result.returncode == 0:
                    any_ok = True
            except (OSError, subprocess.SubprocessError):
                pass
        if any_ok:
            succeeded.append(iface)
            console.print(f"[dim][halton-meter] system proxy reset on {iface}[/dim]")
    return succeeded


def _terminate_pid(pid: int) -> str | None:
    """Send SIGTERM, wait, then SIGKILL if still alive. Returns signal sent."""
    try:
        os.kill(pid, _signal.SIGTERM)
    except ProcessLookupError:
        return None
    except OSError:
        return None

    # Wait up to 2s for graceful exit.
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        try:
            os.kill(pid, 0)  # signal 0 = liveness probe
        except ProcessLookupError:
            return "SIGTERM"
        except OSError:
            return "SIGTERM"
        time.sleep(0.1)

    # Still alive — escalate.
    try:
        os.kill(pid, _signal.SIGKILL)
        return "SIGKILL"
    except (ProcessLookupError, OSError):
        return "SIGTERM"


def _print_err_log_tail(console: Console, *, lines: int = 20) -> None:
    err_log = Path.home() / ".halton-meter" / "daemon.err.log"
    if not err_log.exists():
        return
    try:
        text = err_log.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    tail = "\n".join(text.splitlines()[-lines:])
    if tail.strip():
        console.print(f"\n[dim]daemon.err.log tail:[/dim]\n[dim]{tail}[/dim]")


# --------------------------------------------------------------------------- #
# Linux implementations (best-effort minimal stub)                             #
# --------------------------------------------------------------------------- #


def _start_linux(console: Console) -> int:
    if not _linux_unit_path().exists():
        console.print(
            "[red]halton-meter is not installed; run `halton-meter init` first.[/red]"
        )
        return _EXIT_FAILED
    try:
        result = subprocess.run(
            [
                "systemctl",
                "--user",
                "start",
                _LINUX_UNIT_NAME,
                _LINUX_WATCHDOG_UNIT_NAME,
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        console.print(
            f"[yellow]systemctl --user start failed ({exc}); "
            f"manual: systemctl --user start {_LINUX_UNIT_NAME} "
            f"{_LINUX_WATCHDOG_UNIT_NAME}[/yellow]"
        )
        return _EXIT_OK
    if result.returncode != 0:
        console.print(
            f"[red]systemctl start failed: {(result.stderr or '').strip()}[/red]"
        )
        return _EXIT_FAILED
    console.print("[green]halton-meter started via systemd[/green]")
    return _EXIT_OK


def _stop_linux(console: Console) -> int:
    if not _linux_unit_path().exists():
        console.print("[yellow]halton-meter is not installed; nothing to stop.[/yellow]")
        return _EXIT_OK
    try:
        subprocess.run(
            [
                "systemctl",
                "--user",
                "stop",
                _LINUX_UNIT_NAME,
                _LINUX_WATCHDOG_UNIT_NAME,
            ],
            capture_output=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        console.print(f"[yellow]systemctl stop raised: {exc}[/yellow]")
    console.print("[green]halton-meter stopped via systemd[/green]")
    return _EXIT_OK
