"""
CA cert auto-setup logic for Halton Meter.

Automates the manual steps from daemon/SPIKE_SETUP.md:
  1. Generate mitmproxy CA cert (via mitmproxy's CertStore API).
  2. Trust in macOS system keychain via `security add-trusted-cert`.
  3. Patch the active Python's certifi bundle (append the CA cert).

The module exposes:
  - check_steps()  — returns StepStatus for each step without modifying anything
  - run_setup()    — executes each step in order, skipping completed ones
  - Each step can be forced via force=True

macOS only for this phase — Linux/Windows print "not yet supported".

Marker string used to detect whether the cert is already in the certifi bundle:
  # halton-meter mitmproxy CA cert appended by halton-meter setup
"""

from __future__ import annotations

import platform
import subprocess
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MITMPROXY_CERT_PATH = Path("~/.mitmproxy/mitmproxy-ca-cert.pem").expanduser()
# Marker line written/detected in the certifi bundle
CERTIFI_MARKER = "# halton-meter mitmproxy CA cert appended by halton-meter setup"

# Layer 2 sentinel: written when setup completes successfully so the
# daemon knows it may re-enable the macOS system proxy on startup. See
# decisions.md 2026-04-29 — "Layer 2 watchdog: Option-1 daemon-side
# proxy enable on startup".
PROXY_MANAGED_SENTINEL = Path("~/.halton-meter/proxy-managed").expanduser()


# ---------------------------------------------------------------------------
# Status model
# ---------------------------------------------------------------------------


@dataclass
class StepStatus:
    """Status of a single setup step."""

    name: str
    done: bool
    note: str  # brief human-readable status line


@dataclass
class SetupResult:
    """Result of running all setup steps."""

    cert_generated: StepStatus
    cert_trusted: StepStatus
    certifi_patched: StepStatus

    def all_done(self) -> bool:
        """True if every step is marked done."""
        return self.cert_generated.done and self.cert_trusted.done and self.certifi_patched.done


# ---------------------------------------------------------------------------
# Step 1 — Generate mitmproxy CA cert
# ---------------------------------------------------------------------------


def _cert_exists() -> bool:
    """Return True if the mitmproxy CA cert PEM file already exists."""
    return MITMPROXY_CERT_PATH.exists()


def generate_mitmproxy_cert(*, force: bool = False) -> StepStatus:
    """
    Generate the mitmproxy CA cert by running mitmdump briefly.

    Skips if the cert already exists and force=False.

    Args:
        force: Re-generate even if the cert already exists.

    Returns:
        StepStatus describing what happened.
    """
    if _cert_exists() and not force:
        return StepStatus(
            name="Generate mitmproxy CA cert",
            done=True,
            note=f"Already exists at {MITMPROXY_CERT_PATH}",
        )

    # Use mitmproxy's CertStore API directly — avoids spawning a subprocess
    # and is more reliable than running mitmdump.
    try:
        from mitmproxy.certs import CertStore  # type: ignore[import-untyped]

        ca_dir = MITMPROXY_CERT_PATH.parent
        ca_dir.mkdir(parents=True, exist_ok=True)

        # CertStore.create_store generates the CA files if they don't exist.
        CertStore.create_store(ca_dir, "mitmproxy", 2048)

        if _cert_exists():
            return StepStatus(
                name="Generate mitmproxy CA cert",
                done=True,
                note=f"Generated at {MITMPROXY_CERT_PATH}",
            )
        else:
            return StepStatus(
                name="Generate mitmproxy CA cert",
                done=False,
                note="CertStore ran but cert file not found — check ~/.mitmproxy/",
            )
    except Exception as exc:
        return StepStatus(
            name="Generate mitmproxy CA cert",
            done=False,
            note=f"Failed: {exc}",
        )


# ---------------------------------------------------------------------------
# Step 2 — Trust in macOS keychain
# ---------------------------------------------------------------------------


def _verify_cert_trust_macos_raw() -> tuple[int, str, str]:
    """
    Run `security verify-cert -c <pem> -p ssl` and return (rc, stdout, stderr).

    Diagnostic primitive used by both `_is_cert_trusted_macos()` and
    `halton-meter doctor` so that doctor can surface raw tool output to
    a support ticket. NEVER pass `-r <self>` here — see the docstring on
    `_is_cert_trusted_macos`.

    On FileNotFoundError / TimeoutExpired / SubprocessError, returns
    (-1, "", str(exc)) so callers can distinguish "tool unavailable" from
    "cert verification failed".
    """
    cmd = [
        "security",
        "verify-cert",
        "-c",
        str(MITMPROXY_CERT_PATH),
        "-p",
        "ssl",
    ]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode, result.stdout, result.stderr
    except FileNotFoundError as exc:
        return -1, "", str(exc)
    except subprocess.TimeoutExpired as exc:
        return -1, "", str(exc)
    except subprocess.SubprocessError as exc:
        return -1, "", str(exc)


def _is_cert_trusted_macos() -> bool:
    """
    Return True iff the mitmproxy CA cert is currently trusted by macOS
    SecTrust for SSL evaluation.

    Implementation: `security verify-cert -c <pem> -p ssl` (NO `-r` flag,
    NO find-certificate pre-filter). Per the v0.1.3 cert-trust spike
    (Phase 1, 2026-04-30, three-state evaluation on Vikrant's MacBook):

      * `verify-cert -c <pem> -p ssl -r <pem>` (the form v0.1.2 shipped)
        adds the cert as its own trust anchor for the verification, so
        rc=0 in ALL three test states (trusted, untrusted-in-keychain,
        not-in-keychain). Tautological for any self-signed CA — broken.
      * `verify-cert -c <pem> -p ssl` (no `-r`) consults the SecTrust
        resolver TLS clients use, so its verdict matches what
        Chrome/Safari/SecTrust will see for HTTPS connections.
      * `find-certificate` as a pre-filter has a real false-negative
        case: a cert can be admin-trusted (TLS works) yet absent from
        both the System and login keychains under that name. v0.1.2's
        find-certificate gate said "not trusted" in that drift mode.
        v0.1.3 drops the pre-filter entirely.

    Fail-closed: any subprocess error / unavailability returns False.
    The daemon would rather refuse to enable the proxy than enable one
    intercepting TLS the kernel rejects.
    """
    if not _cert_exists():
        return False
    rc, _stdout, _stderr = _verify_cert_trust_macos_raw()
    return rc == 0


def trust_cert_macos(*, force: bool = False, console: Console | None = None) -> StepStatus:
    """
    Add the mitmproxy CA cert to the macOS system keychain as trusted.

    Requires admin rights. v0.1.4 (2B.15 P0-2) prefers the standard macOS
    "halton-meter wants to make changes" GUI password dialog (via
    osascript) over a terminal sudo prompt. New users on a clean Mac
    don't necessarily know what ``sudo -v`` is — the GUI dialog is what
    Brew, the macOS installer, and every other macOS-native tool uses,
    so it's the path of least surprise.

    Order of precedence (whichever succeeds first wins):
      1. osascript-wrapped admin dialog via
         :func:`halton_meter.system_proxy.run_with_admin`. Pops a system
         "halton-meter wants to make changes" dialog; the user types
         their password into the macOS panel rather than the terminal.
         No pre-cached sudo required.
      2. Plain ``sudo security add-trusted-cert ...`` fallback. Used
         when osascript is unavailable (extremely rare on macOS) or
         when the GUI dialog itself fails for an unexpected reason.
         If the user has not pre-cached sudo, this path will deadlock
         on the password prompt — but step 1 should always succeed
         first on macOS.

    Args:
        force: Re-run even if the cert already appears to be trusted.
        console: Optional rich Console for printing status (used in check mode).

    Returns:
        StepStatus describing what happened.
    """
    if not _cert_exists():
        return StepStatus(
            name="Trust cert in macOS keychain",
            done=False,
            note="CA cert not found — run step 1 first",
        )

    if _is_cert_trusted_macos() and not force:
        return StepStatus(
            name="Trust cert in macOS keychain",
            done=True,
            note="Already trusted in /Library/Keychains/System.keychain",
        )

    # The actual command is the same for both paths. Stored here so we
    # can quote it back to the user verbatim if both elevation paths fail.
    inner_argv = [
        "security",
        "add-trusted-cert",
        "-d",
        "-r",
        "trustRoot",
        "-k",
        "/Library/Keychains/System.keychain",
        str(MITMPROXY_CERT_PATH),
    ]

    # Path 1: osascript-wrapped admin dialog (preferred).
    if _osascript_available():
        try:
            from halton_meter.system_proxy import (
                AdminCancelledError,
                AdminInfrastructureError,
                AdminInnerCommandError,
                run_with_admin,
            )

            run_with_admin(
                inner_argv,
                prompt_reason=(
                    "halton-meter wants to add its CA cert to the system "
                    "keychain so HTTPS traffic can be metered locally."
                ),
            )
            return StepStatus(
                name="Trust cert in macOS keychain",
                done=True,
                note="Added to /Library/Keychains/System.keychain (via admin dialog)",
            )
        except AdminCancelledError:
            # v0.1.5 (2B.16) P1-AUDIT-4: typed exception. No more
            # message-substring inspection.
            return StepStatus(
                name="Trust cert in macOS keychain",
                done=False,
                note=(
                    "Admin password dialog cancelled by user. "
                    "Re-run `halton-meter init` and authorise the dialog "
                    "to grant cert trust."
                ),
            )
        except (AdminInnerCommandError, AdminInfrastructureError) as exc:
            # Inner command failed under osascript, or osascript itself
            # is missing / unrunnable. Either way fall through to sudo
            # path, but surface the reason for transparency.
            if console is not None:
                console.print(
                    "[dim](osascript admin dialog failed; falling back to "
                    f"terminal sudo: {exc})[/dim]"
                )
        except Exception as exc:
            # Any other unexpected failure: same fallback strategy.
            if console is not None:
                console.print(
                    "[dim](osascript admin path raised unexpected "
                    f"{type(exc).__name__}: {exc}; trying terminal sudo)[/dim]"
                )

    # Path 2: plain sudo fallback. Used on the unusual path where
    # osascript is missing or the GUI dialog itself failed for a
    # non-cancel reason. Without a pre-cached sudo this will deadlock
    # on the password prompt; preserved for back-compat with the v0.1.3
    # contract (which the init preflight still depends on).
    cmd = ["sudo", *inner_argv]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return StepStatus(
                name="Trust cert in macOS keychain",
                done=True,
                note="Added to /Library/Keychains/System.keychain (via sudo)",
            )
        else:
            manual_cmd = " ".join(cmd)
            error_msg = result.stderr.strip() or result.stdout.strip() or "(no output)"
            return StepStatus(
                name="Trust cert in macOS keychain",
                done=False,
                note=(
                    f"Command failed (sudo may be required): {error_msg}\n"
                    f"  Run manually: {manual_cmd}"
                ),
            )
    except subprocess.TimeoutExpired:
        manual_cmd = " ".join(cmd)
        return StepStatus(
            name="Trust cert in macOS keychain",
            done=False,
            note=f"Timed out (sudo prompt unanswered?).\n  Run manually: {manual_cmd}",
        )
    except FileNotFoundError:
        return StepStatus(
            name="Trust cert in macOS keychain",
            done=False,
            note="'security' command not found — is this macOS?",
        )
    except subprocess.SubprocessError as exc:
        manual_cmd = " ".join(cmd)
        return StepStatus(
            name="Trust cert in macOS keychain",
            done=False,
            note=f"Subprocess error: {exc}\n  Run manually: {manual_cmd}",
        )


def _osascript_available() -> bool:
    """Return True iff ``osascript`` is on PATH. macOS-only.

    osascript ships with every macOS install at ``/usr/bin/osascript`` —
    a missing osascript would indicate a broken install or a non-macOS
    platform. Test seam so the GUI-dialog path can be disabled
    deterministically in setup tests.
    """
    import shutil

    return shutil.which("osascript") is not None


# ---------------------------------------------------------------------------
# Step 3 — Patch certifi bundle
# ---------------------------------------------------------------------------


def _certifi_bundle_path() -> Path:
    """Return the path to certifi's CA bundle in the running Python."""
    import certifi  # type: ignore[import-untyped]

    return Path(certifi.where())


def _is_certifi_patched() -> bool:
    """Return True if the mitmproxy cert marker AND current cert body are in
    the certifi bundle.

    Idempotency contract (v0.1.3, P0-2): the patch step is skipped only when
    BOTH the marker line is present AND the *current* mitmproxy CA cert body
    appears in the bundle. If the marker is present but the cert body has
    drifted (cert rotated; certifi reinstalled; manual edit), the patch step
    re-runs to re-append the current cert. This avoids the failure mode where
    a stale marker hides a missing-cert state from idempotent re-runs.
    """
    try:
        bundle = _certifi_bundle_path()
        if not bundle.exists():
            return False
        bundle_text = bundle.read_text(encoding="utf-8")
        if CERTIFI_MARKER not in bundle_text:
            return False
        if not _cert_exists():
            # Cannot prove the bundle has the current cert without it on disk.
            # Conservatively: marker present + cert file missing -> not patched
            # for the current cert body.
            return False
        cert_body = MITMPROXY_CERT_PATH.read_text(encoding="utf-8").strip()
        if not cert_body:
            return False
        return cert_body in bundle_text
    except Exception:
        return False


def patch_certifi(*, force: bool = False) -> StepStatus:
    """
    Append the mitmproxy CA cert to the certifi bundle in the running Python.

    This is necessary because the Anthropic Python SDK uses certifi for TLS
    verification and ignores the macOS system keychain.

    Skips if the marker string is already present and force=False.

    Args:
        force: Re-patch even if the cert is already present.

    Returns:
        StepStatus describing what happened.
    """
    if not _cert_exists():
        return StepStatus(
            name="Patch certifi bundle",
            done=False,
            note="CA cert not found — run step 1 first",
        )

    try:
        bundle_path = _certifi_bundle_path()
    except Exception as exc:
        return StepStatus(
            name="Patch certifi bundle",
            done=False,
            note=f"certifi not importable: {exc}",
        )

    if _is_certifi_patched() and not force:
        return StepStatus(
            name="Patch certifi bundle",
            done=True,
            note=f"Already patched: {bundle_path}",
        )

    try:
        cert_pem = MITMPROXY_CERT_PATH.read_text(encoding="utf-8")
        with bundle_path.open("a", encoding="utf-8") as fh:
            fh.write(f"\n{CERTIFI_MARKER}\n")
            fh.write(cert_pem)
            if not cert_pem.endswith("\n"):
                fh.write("\n")
        return StepStatus(
            name="Patch certifi bundle",
            done=True,
            note=f"Patched: {bundle_path}",
        )
    except PermissionError:
        manual = (
            f"sudo python -c "
            f"\"open('{bundle_path}','a').write(open('{MITMPROXY_CERT_PATH}').read())\""
        )
        return StepStatus(
            name="Patch certifi bundle",
            done=False,
            note=f"Permission denied writing to {bundle_path}. Try: {manual}",
        )
    except Exception as exc:
        return StepStatus(
            name="Patch certifi bundle",
            done=False,
            note=f"Failed: {exc}",
        )


# ---------------------------------------------------------------------------
# Platform guard helpers
# ---------------------------------------------------------------------------


def _is_macos() -> bool:
    return platform.system() == "Darwin"


def _not_supported_step(step_name: str) -> StepStatus:
    """Return a stub StepStatus for unsupported platforms."""
    return StepStatus(
        name=step_name,
        done=False,
        note=f"Not yet supported on {platform.system()} — macOS only for Phase 0",
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def check_steps() -> SetupResult:
    """
    Check the current state of each setup step without modifying anything.

    Returns:
        SetupResult with StepStatus for each step.
    """
    # Step 1: cert generation — check by file existence
    if _cert_exists():
        cert_gen = StepStatus(
            name="Generate mitmproxy CA cert",
            done=True,
            note=f"Found at {MITMPROXY_CERT_PATH}",
        )
    else:
        cert_gen = StepStatus(
            name="Generate mitmproxy CA cert",
            done=False,
            note=f"Not found at {MITMPROXY_CERT_PATH}",
        )

    # Step 2: keychain trust
    if not _is_macos():
        cert_trust = _not_supported_step("Trust cert in macOS keychain")
    elif _is_cert_trusted_macos():
        cert_trust = StepStatus(
            name="Trust cert in macOS keychain",
            done=True,
            note="Found in /Library/Keychains/System.keychain",
        )
    else:
        cert_trust = StepStatus(
            name="Trust cert in macOS keychain",
            done=False,
            note="Not found in /Library/Keychains/System.keychain",
        )

    # Step 3: certifi patch
    if _is_certifi_patched():
        certifi_patch = StepStatus(
            name="Patch certifi bundle",
            done=True,
            note=f"Marker found in {_certifi_bundle_path()}",
        )
    else:
        try:
            bundle = _certifi_bundle_path()
            certifi_patch = StepStatus(
                name="Patch certifi bundle",
                done=False,
                note=f"Marker not found in {bundle}",
            )
        except Exception as exc:
            certifi_patch = StepStatus(
                name="Patch certifi bundle",
                done=False,
                note=f"certifi not importable: {exc}",
            )

    return SetupResult(
        cert_generated=cert_gen,
        cert_trusted=cert_trust,
        certifi_patched=certifi_patch,
    )


def run_setup(
    *,
    force: bool = False,
    managed: bool = True,
    console: Console | None = None,
) -> SetupResult:
    """
    Execute all setup steps in order. Skip steps already done unless force=True.

    Platform guard: on non-macOS, the keychain step is skipped with a stub.

    Args:
        force: Re-run all steps even if already done.
        managed: When True (default), write the layer-2 ``proxy-managed``
            sentinel on the success path so the daemon knows it may
            re-enable the macOS system proxy on startup. When False
            (v0.1.3 env-var-only mode entry point), suppress that write —
            the user has not opted in to system-proxy management; only
            cert + certifi work happens. The legacy ``halton-meter setup``
            command keeps the default ``managed=True`` for backward
            compatibility.
        console: Optional rich Console for progress output.

    Returns:
        SetupResult with the final status of each step.
    """
    cert_gen = generate_mitmproxy_cert(force=force)

    if _is_macos():
        cert_trust = trust_cert_macos(force=force, console=console)
    else:
        cert_trust = _not_supported_step("Trust cert in macOS keychain")

    certifi_patch = patch_certifi(force=force)

    result = SetupResult(
        cert_generated=cert_gen,
        cert_trusted=cert_trust,
        certifi_patched=certifi_patch,
    )

    # Layer 2 sentinel: write only on the success path (all three steps
    # done on macOS) AND only when the caller asked for managed mode.
    # On other platforms the keychain step returns a stub and we don't
    # yet manage the system proxy, so the sentinel stays absent.
    # ``halton-meter uninstall`` removes it.
    if managed and _is_macos() and result.all_done():
        try:
            PROXY_MANAGED_SENTINEL.parent.mkdir(parents=True, exist_ok=True)
            PROXY_MANAGED_SENTINEL.touch(exist_ok=True)
        except OSError:
            # Non-fatal: setup itself succeeded; only the sentinel write
            # failed. The user can still re-run setup.
            pass

    return result


# ---------------------------------------------------------------------------
# Rich rendering helpers
# ---------------------------------------------------------------------------


def render_result(result: SetupResult, console: Console) -> None:
    """Print a checklist panel showing the status of each setup step."""
    steps = [
        result.cert_generated,
        result.cert_trusted,
        result.certifi_patched,
    ]

    lines = []
    for step in steps:
        icon = "[green]✓[/green]" if step.done else "[red]✗[/red]"
        lines.append(f"{icon}  [bold]{step.name}[/bold]")
        lines.append(f"   {step.note}")

    console.print("\n".join(lines))
