"""
Edge proxy (Phase 2C.2 / v0.1.6).

A tiny, stdlib-only asyncio TCP CONNECT proxy that owns the user-facing
proxy port (the one that lives in apps' ``HTTPS_PROXY`` env var). For
each incoming connection it decides — based on a cached daemon-health
signal — whether to chain the request through the metering daemon
(full TLS interception + cost attribution) or open a direct
passthrough tunnel to the upstream host (no decryption, no metering,
the user's request just works).

The point of this component is to decouple the apps' connectivity
contract from the metering daemon's lifecycle. Apps can stay running
across a daemon stop / crash / upgrade because the edge port stays
bound by this process the whole time.

See ``memory/plans/2026-04-30-edge-proxy-decoupling.md`` for the full
design. The cardinal rule (CLAUDE.md): observation must never break
the developer's workflow. This module is the architectural answer.

Stdlib only: ``asyncio`` + ``socket``. No mitmproxy, no httpx, no
Pydantic. The edge does not decrypt; it shuttles bytes.
"""

from __future__ import annotations

import asyncio
import os
import time
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)


# --------------------------------------------------------------------------- #
# Tunables                                                                    #
# --------------------------------------------------------------------------- #

# Health-cache TTLs. Asymmetric (see plan §4 / §12.3):
#   - Healthy state is the steady state. Re-probing every 500ms during
#     normal metering wastes CPU. 1000ms is short enough that a freshly
#     crashed daemon is detected quickly; long enough that sustained
#     traffic doesn't generate probe noise.
#   - Unhealthy state should converge fast on recovery. 200ms is
#     sub-perceptible (< two human reaction times).
#   - Chain-failure invalidation closes the stale-positive race: if the
#     cached "healthy" answer is stale because the daemon crashed
#     between probe and request, the chain TCP connect raises
#     ConnectionRefusedError; we invalidate and fall through to
#     passthrough on that very request — no TTL wait.
DEFAULT_HEALTHY_TTL_SECONDS = 1.0
DEFAULT_UNHEALTHY_TTL_SECONDS = 0.2
DEFAULT_PROBE_TIMEOUT_SECONDS = 0.1

# Per-request limits.
_MAX_REQUEST_LINE_BYTES = 8192  # 8 KiB
_MAX_HEADER_BYTES = 16 * 1024  # 16 KiB
_SHUTTLE_CHUNK_BYTES = 65536


# --------------------------------------------------------------------------- #
# Health cache                                                                #
# --------------------------------------------------------------------------- #


@dataclass
class DaemonHealthCache:
    """Asymmetric-TTL cache for the metering daemon's ``/health`` state.

    Probe a daemon's HTTP ``/health`` endpoint and cache the result.
    The cached value's freshness window depends on the value:

    * ``healthy_ttl_s`` — how long a True answer stays cached.
    * ``unhealthy_ttl_s`` — how long a False answer stays cached.
    * :meth:`invalidate` clears the cache immediately, used when a
      real chain attempt observes ``ConnectionRefusedError`` despite
      a cached "healthy" answer.

    The probe runs as an asyncio task; concurrent callers de-duplicate
    onto a single in-flight probe via ``_probe_lock``. Time is taken
    from a monotonic clock so wall-clock changes don't affect us.

    Port semantics (v0.1.7 Gap 5 — ship-blocker fix):

    * ``internal_port`` is the **chain target** — the mitmproxy CONNECT
      proxy port that ``EdgeProxy._try_chain`` opens TCP to for actual
      data flow. mitmproxy is a CONNECT proxy and does NOT serve
      ``/health``; probing it always returns nothing → cache stuck
      False → all CONNECTs fall through to passthrough → zero captures.
    * ``probe_port`` is the **HTTP API port** where FastAPI/uvicorn
      serves ``/health``. This is what the probe must hit. Defaults to
      8765 (matches ``DaemonConfig.api_port``).
    """

    internal_host: str = "127.0.0.1"
    internal_port: int = 8090
    probe_port: int = 8765
    healthy_ttl_s: float = DEFAULT_HEALTHY_TTL_SECONDS
    unhealthy_ttl_s: float = DEFAULT_UNHEALTHY_TTL_SECONDS
    probe_timeout_s: float = DEFAULT_PROBE_TIMEOUT_SECONDS
    # Test seam: pluggable monotonic clock.
    clock: callable = field(default=time.monotonic)
    _last_check_at: float = 0.0
    _last_result: bool = False
    _has_result: bool = False
    _probe_lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def is_healthy(self) -> bool:
        """Return cached or freshly-probed daemon health.

        On a hot cache (``now - last_check_at < ttl``) the cached value
        is returned without a network call. On a cold cache the probe
        runs under ``_probe_lock`` so concurrent callers share one
        in-flight probe.
        """
        now = self.clock()
        if self._has_result:
            ttl = self.healthy_ttl_s if self._last_result else self.unhealthy_ttl_s
            if (now - self._last_check_at) < ttl:
                return self._last_result

        async with self._probe_lock:
            # Re-check inside the lock — another caller may have just
            # populated the cache while we were waiting.
            now = self.clock()
            if self._has_result:
                ttl = (
                    self.healthy_ttl_s
                    if self._last_result
                    else self.unhealthy_ttl_s
                )
                if (now - self._last_check_at) < ttl:
                    return self._last_result
            result = await self._probe()
            self._last_result = result
            self._last_check_at = self.clock()
            self._has_result = True
            return result

    def invalidate(self) -> None:
        """Forget the cached answer. Next ``is_healthy()`` re-probes."""
        self._has_result = False
        self._last_result = False
        self._last_check_at = 0.0

    async def _probe(self) -> bool:
        """Issue ``GET /health`` to the metering daemon.

        Returns True iff the daemon answers with 200 OK within
        ``probe_timeout_s``. Any error (timeout, ConnectionRefused,
        non-200, malformed response) returns False — fail-closed.

        Stdlib raw HTTP/1.0 over a single TCP connection. We don't need
        keep-alive, redirects, TLS, or chunked transfer; the daemon's
        ``/health`` endpoint returns a small JSON dict.
        """
        try:
            return await asyncio.wait_for(
                self._probe_inner(), timeout=self.probe_timeout_s
            )
        except TimeoutError:
            return False
        except Exception:  # pragma: no cover - defensive
            return False

    async def _probe_inner(self) -> bool:
        try:
            reader, writer = await asyncio.open_connection(
                self.internal_host, self.probe_port
            )
        except (ConnectionRefusedError, OSError):
            return False
        try:
            request = (
                b"GET /health HTTP/1.0\r\n"
                b"Host: " + self.internal_host.encode("ascii") + b"\r\n"
                b"Connection: close\r\n"
                b"\r\n"
            )
            writer.write(request)
            await writer.drain()
            # Read just enough to parse the status line.
            status_line = await reader.readline()
            if not status_line:
                return False
            try:
                parts = status_line.decode("ascii", errors="replace").split()
            except Exception:
                return False
            return len(parts) >= 2 and parts[1] == "200"
        except (ConnectionResetError, BrokenPipeError, OSError):
            return False
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass


# --------------------------------------------------------------------------- #
# Request-line parsing                                                        #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class ParsedRequest:
    """Parsed HTTP-proxy request first line + raw header block.

    The raw header block (``raw_head``) is replayed verbatim when
    chaining or passthrough'ing — we never decode/re-encode the
    headers; that would be an unwarranted source of subtle bugs. Only
    the request-line method + target is parsed for routing.
    """

    method: str
    target: str  # e.g. "host:port" for CONNECT, "http://example.com/x" for HTTP
    version: str  # e.g. "HTTP/1.1"
    raw_head: bytes  # request line + headers + terminating CRLF CRLF


def parse_connect_target(target: str) -> tuple[str, int] | None:
    """Parse ``host:port`` from a CONNECT request target.

    Returns ``(host, port)`` or ``None`` if the target is malformed.
    Bracketed IPv6 literals are supported (``[::1]:443``).
    """
    target = target.strip()
    if not target:
        return None
    if target.startswith("["):
        end = target.find("]")
        if end == -1:
            return None
        host = target[1:end]
        rest = target[end + 1:]
        if not rest.startswith(":"):
            return None
        port_str = rest[1:]
    else:
        if ":" not in target:
            return None
        host, _, port_str = target.rpartition(":")
    if not host or not port_str:
        return None
    try:
        port = int(port_str)
    except ValueError:
        return None
    if not (0 < port < 65536):
        return None
    return host, port


async def read_request_head(reader: asyncio.StreamReader) -> ParsedRequest | None:
    """Read the request line + header block from ``reader``.

    Returns ``None`` if the request line is malformed, the head is
    larger than the limit, or the connection closes before the head
    completes. The raw bytes (request line + every header line +
    terminating CRLF CRLF) are returned in :attr:`ParsedRequest.raw_head`
    so the caller can replay them verbatim downstream.
    """
    try:
        request_line = await reader.readline()
    except (ConnectionResetError, BrokenPipeError, OSError):
        return None
    if not request_line or len(request_line) > _MAX_REQUEST_LINE_BYTES:
        return None
    try:
        decoded = request_line.decode("iso-8859-1").rstrip("\r\n")
    except Exception:
        return None
    parts = decoded.split(" ", 2)
    if len(parts) != 3:
        return None
    method, target, version = parts
    if not method or not target or not version.startswith("HTTP/"):
        return None

    # Read header block until blank line.
    head_bytes = bytearray(request_line)
    while True:
        if len(head_bytes) > _MAX_HEADER_BYTES:
            return None
        try:
            line = await reader.readline()
        except (ConnectionResetError, BrokenPipeError, OSError):
            return None
        if not line:
            # Connection closed before headers terminated.
            return None
        head_bytes.extend(line)
        if line in (b"\r\n", b"\n"):
            break
    return ParsedRequest(
        method=method,
        target=target,
        version=version,
        raw_head=bytes(head_bytes),
    )


# --------------------------------------------------------------------------- #
# Bidirectional byte shuttle                                                  #
# --------------------------------------------------------------------------- #


async def _shuttle_one_way(
    src: asyncio.StreamReader,
    dst: asyncio.StreamWriter,
) -> None:
    """Copy bytes from ``src`` to ``dst`` until EOF on ``src``.

    Closes the write side of ``dst`` on completion so the peer's
    counterpart shuttle observes EOF and unblocks. Errors are
    swallowed: this function exists inside a try/finally where the
    caller closes both streams unconditionally; logging an
    OSError per side per close is noise.
    """
    try:
        while True:
            chunk = await src.read(_SHUTTLE_CHUNK_BYTES)
            if not chunk:
                break
            dst.write(chunk)
            await dst.drain()
    except (ConnectionResetError, BrokenPipeError, OSError):
        return
    finally:
        try:
            if dst.can_write_eof():
                dst.write_eof()
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass


async def shuttle_bidirectional(
    a_reader: asyncio.StreamReader,
    a_writer: asyncio.StreamWriter,
    b_reader: asyncio.StreamReader,
    b_writer: asyncio.StreamWriter,
) -> None:
    """Bidirectionally pipe bytes between two stream pairs.

    Returns when either direction finishes. The caller is responsible
    for closing both writers in their finally block.
    """
    a_to_b = asyncio.create_task(_shuttle_one_way(a_reader, b_writer))
    b_to_a = asyncio.create_task(_shuttle_one_way(b_reader, a_writer))
    try:
        await asyncio.gather(a_to_b, b_to_a)
    except (ConnectionResetError, BrokenPipeError, OSError):
        return


# --------------------------------------------------------------------------- #
# The edge proxy itself                                                       #
# --------------------------------------------------------------------------- #


@dataclass
class EdgeConfig:
    """Runtime config for the edge proxy.

    Decoupled from :class:`halton_meter.config.HaltonConfig` on purpose
    — the edge has a stripped-down concern surface. The
    :meth:`from_halton_config` classmethod (added in W2) reads
    ``cfg.daemon.edge_port`` / ``internal_port`` / ``edge_health_ttl_ms``
    so the production entry point and tests share one wiring.
    """

    edge_host: str = "127.0.0.1"
    edge_port: int = 8081
    internal_host: str = "127.0.0.1"
    internal_port: int = 8090
    # v0.1.7 Gap 5: HTTP API port where the daemon serves ``/health``.
    # The probe MUST hit this, not ``internal_port`` (mitmproxy CONNECT,
    # speaks no HTTP). Default matches ``DaemonConfig.api_port``.
    probe_port: int = 8765
    healthy_ttl_s: float = DEFAULT_HEALTHY_TTL_SECONDS
    unhealthy_ttl_s: float = DEFAULT_UNHEALTHY_TTL_SECONDS
    probe_timeout_s: float = DEFAULT_PROBE_TIMEOUT_SECONDS
    # v0.1.7 Gap 0: paths for the runtime.toml re-resolve and the edge
    # sidecar. Both default to None so existing tests (which construct
    # EdgeConfig with literal ports) keep their previous behaviour —
    # re-resolution and sidecar writes are no-ops unless a path is set.
    # Production wiring via ``from_halton_config`` populates both with
    # the canonical paths from port_alloc.
    runtime_path: Path | None = None
    state_path: Path | None = None

    @classmethod
    def from_halton_config(cls, cfg: object) -> EdgeConfig:
        """Map a :class:`halton_meter.config.HaltonConfig` into an
        :class:`EdgeConfig`. Imports lazily so this module stays
        stdlib-only at import time (the rest of the file deliberately
        does not depend on Pydantic or the rest of the daemon).
        """
        # ``cfg`` is typed as ``object`` to avoid a hard import-time
        # dependency on halton_meter.config; we duck-type it here.
        daemon = cfg.daemon  # type: ignore[attr-defined]
        ttl_ms = int(getattr(daemon, "edge_health_ttl_ms", 1000))
        # Lazy import keeps edge.py importable without port_alloc when
        # callers construct EdgeConfig directly.
        from halton_meter.port_alloc import (
            EDGE_STATE_TOML_PATH,
            RUNTIME_TOML_PATH,
        )
        return cls(
            edge_host=str(daemon.listen_host),
            edge_port=int(daemon.edge_port),
            internal_host=str(daemon.listen_host),
            internal_port=int(daemon.internal_port),
            probe_port=int(getattr(daemon, "api_port", 8765)),
            healthy_ttl_s=max(ttl_ms, 0) / 1000.0,
            unhealthy_ttl_s=DEFAULT_UNHEALTHY_TTL_SECONDS,
            probe_timeout_s=DEFAULT_PROBE_TIMEOUT_SECONDS,
            runtime_path=RUNTIME_TOML_PATH,
            state_path=EDGE_STATE_TOML_PATH,
        )


class EdgeProxy:
    """Asyncio TCP CONNECT/HTTP-via-proxy server.

    Lifecycle:

    * :meth:`start` binds the listener and returns the bound port.
    * :meth:`serve_forever` runs the accept loop until cancelled.
    * :meth:`stop` cleanly drains and closes.

    Per-connection flow:

    1. Read the request head (request line + headers).
    2. If method == ``CONNECT``: parse host:port; decide chain vs
       passthrough; either connect to daemon and replay the head, or
       connect direct and answer ``200 Connection Established``;
       shuttle bytes both ways.
    3. Else (HTTP-via-proxy): open the same kind of upstream
       connection; replay the head verbatim; shuttle bytes both ways.
    4. On any error: log structured + close both sockets. Never raise
       out of the per-connection task.
    """

    def __init__(
        self,
        config: EdgeConfig,
        *,
        health_cache: DaemonHealthCache | None = None,
    ) -> None:
        self._config = config
        self._cache = health_cache or DaemonHealthCache(
            internal_host=config.internal_host,
            internal_port=config.internal_port,
            probe_port=config.probe_port,
            healthy_ttl_s=config.healthy_ttl_s,
            unhealthy_ttl_s=config.unhealthy_ttl_s,
            probe_timeout_s=config.probe_timeout_s,
        )
        self._server: asyncio.base_events.Server | None = None

    @property
    def health_cache(self) -> DaemonHealthCache:
        return self._cache

    def _read_runtime_internal_port(self) -> int | None:
        """Read ``daemon.internal_port`` out of ``runtime.toml``.

        Stdlib-only on purpose — the edge module deliberately doesn't
        import port_alloc to keep the hot path free of Pydantic /
        config-layer imports. Returns ``None`` if no runtime path is
        configured, the file is missing, or the value is malformed.
        """
        path = self._config.runtime_path
        if path is None:
            return None
        try:
            if not path.exists():
                return None
            with path.open("rb") as fh:
                raw = tomllib.load(fh)
        except (tomllib.TOMLDecodeError, OSError):
            return None
        daemon_tbl = raw.get("daemon", {}) or {}
        val = daemon_tbl.get("internal_port")
        if isinstance(val, int) and 0 < val < 65536:
            return val
        return None

    def _write_state_sidecar(self) -> None:
        """Persist the current chain target to the edge sidecar.

        Best-effort; sidecar write failures must never break the hot
        path. Skips when no state_path is configured (test mode).
        """
        path = self._config.state_path
        if path is None:
            return
        try:
            from halton_meter.port_alloc import write_edge_state_toml

            write_edge_state_toml(
                path,
                edge_port=int(self._config.edge_port),
                chain_port=int(self._config.internal_port),
                pid=os.getpid(),
            )
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.state_sidecar_write_failed", error=str(exc))

    def write_initial_state(self, *, bound_edge_port: int | None = None) -> None:
        """Public entry point for ``halton-meter edge`` to persist the
        initial sidecar after binding.

        ``bound_edge_port`` lets the caller pass the kernel-assigned
        port (when the config asked for ``edge_port=0``) so the sidecar
        carries the actually-bound value, not the placeholder zero.
        """
        if bound_edge_port is not None:
            self._config.edge_port = int(bound_edge_port)
        self._write_state_sidecar()

    def _maybe_reresolve_chain_target(self) -> bool:
        """Re-read ``runtime.toml`` and rebind the chain target if it changed.

        Returns True iff the chain target was changed. Called on
        ``ConnectionRefusedError`` from a chain attempt — the daemon
        may have fallen back to a different ``internal_port`` since
        this process started, in which case the cached target is stale
        and every subsequent chain would also fail. Re-resolution is
        what stops the edge from locking into passthrough forever
        (memory/plans/2026-05-01-edge-passthrough-lockin-bug.md).
        """
        new_port = self._read_runtime_internal_port()
        if new_port is None:
            return False
        old_port = self._config.internal_port
        if new_port == old_port:
            return False
        self._config.internal_port = new_port
        self._cache.internal_port = new_port
        # New target: cached health answer is meaningless — force a
        # re-probe on the next request.
        self._cache.invalidate()
        log.warning(
            "edge.chain_target_changed",
            old_port=old_port,
            new_port=new_port,
        )
        self._write_state_sidecar()
        return True

    async def start(self) -> int:
        """Bind the listener; return the bound port.

        ``edge_port == 0`` is honoured for tests (kernel-assigned port).
        """
        self._server = await asyncio.start_server(
            self._handle_connection,
            host=self._config.edge_host,
            port=self._config.edge_port,
        )
        # Capture the actual bound port (relevant when caller passed 0).
        sock = self._server.sockets[0] if self._server.sockets else None
        if sock is None:
            return self._config.edge_port
        return sock.getsockname()[1]

    async def watch_runtime_toml(self, *, poll_interval_s: float = 1.0) -> None:
        """Poll ``runtime.toml`` and re-resolve the chain target on change.

        v0.1.8 Gap 10. Pre-fix, the edge only re-resolved its
        ``internal_port`` AFTER a chain attempt observed
        ``ConnectionRefusedError`` (the v0.1.7 Gap 0 fallback). That
        works but means **one CONNECT must fail** before correction.
        With this watcher running, the moment the daemon writes a new
        ``runtime.toml`` the edge re-resolves — zero failed CONNECTs.

        Stdlib-only on purpose. Polling on file mtime + size is portable
        across macOS / Linux without pulling in ``watchdog`` (the
        plan's hard constraint: no new third-party deps).

        Fail-open: every iteration is wrapped. Any exception is logged
        and the loop continues; the watcher is observation
        infrastructure and must never break the edge serving loop.
        Cancellation propagates via :exc:`asyncio.CancelledError`.

        No-op when ``runtime_path`` is unset (test mode).
        """
        path = self._config.runtime_path
        if path is None:
            return

        # Signature includes mtime_ns + size + inode. Inode is the
        # decisive bit when the daemon rewrites runtime.toml via
        # os.replace within the same mtime tick: the destination inode
        # changes so we always notice. mtime_ns gives nanosecond
        # resolution (mtime alone has 1s granularity on some FS).
        def _sig() -> tuple[int, int, int] | None:
            try:
                st = path.stat()
            except (FileNotFoundError, OSError):
                return None
            return (st.st_mtime_ns, st.st_size, st.st_ino)

        # Initial reconciliation: the daemon may have rewritten
        # runtime.toml between EdgeConfig construction and now (e.g.
        # daemon restart racing edge startup). Re-resolve once on entry
        # so we don't wait for a file change that already happened.
        try:
            self._maybe_reresolve_chain_target()
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("edge.runtime_watch_initial_reresolve_failed", error=str(exc))

        last_signature = _sig()

        while True:
            try:
                await asyncio.sleep(poll_interval_s)
                signature = _sig()
                if signature is None:
                    last_signature = None
                    continue
                if signature == last_signature:
                    continue
                last_signature = signature
                try:
                    changed = self._maybe_reresolve_chain_target()
                except Exception as exc:  # pragma: no cover - defensive
                    log.warning("edge.runtime_watch_reresolve_failed", error=str(exc))
                    continue
                if changed:
                    log.info(
                        "edge.runtime_watch_reresolved",
                        path=str(path),
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("edge.runtime_watch_iteration_failed", error=str(exc))

    async def serve_forever(self) -> None:
        if self._server is None:
            raise RuntimeError("EdgeProxy.start() must be called before serve_forever()")
        async with self._server:
            await self._server.serve_forever()

    async def stop(self) -> None:
        if self._server is None:
            return
        self._server.close()
        try:
            await self._server.wait_closed()
        except Exception:  # pragma: no cover - defensive
            pass
        self._server = None

    async def _handle_connection(
        self,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        """Per-connection handler. Never raises."""
        peer = client_writer.get_extra_info("peername")
        try:
            parsed = await read_request_head(client_reader)
            if parsed is None:
                log.info("edge.bad_request", peer=str(peer))
                self._safe_write(
                    client_writer,
                    b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
                )
                return
            if parsed.method.upper() == "CONNECT":
                await self._handle_connect(parsed, client_reader, client_writer)
            else:
                await self._handle_http(parsed, client_reader, client_writer)
        except Exception as exc:
            # Cardinal rule: log and let the connection die. Never let
            # an edge-proxy bug bring the listener down.
            log.error(
                "edge.connection_failed",
                peer=str(peer),
                error=str(exc),
                exc_info=True,
            )
        finally:
            try:
                client_writer.close()
                await client_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass

    async def _handle_connect(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        host_port = parse_connect_target(parsed.target)
        if host_port is None:
            log.info("edge.connect.bad_target", target=parsed.target)
            self._safe_write(
                client_writer,
                b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
            )
            return

        # Decide chain vs passthrough.
        chained = await self._try_chain(parsed, client_reader, client_writer)
        if chained:
            return
        # Fall through to direct passthrough.
        await self._do_passthrough_connect(host_port, client_reader, client_writer)

    async def _try_chain(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> bool:
        """Attempt to chain the request through the metering daemon.

        Returns True if the chain was attempted (regardless of whether
        it succeeded internally — once we hand off to the daemon the
        edge is just shuttling bytes). Returns False if we never
        attempted the chain (cache says daemon down) OR if the TCP
        connect to the daemon raised ConnectionRefusedError, in which
        case the cache is invalidated and the caller can fall through
        to passthrough.
        """
        if not await self._cache.is_healthy():
            return False
        try:
            up_reader, up_writer = await asyncio.open_connection(
                self._config.internal_host, self._config.internal_port
            )
        except ConnectionRefusedError:
            # Stale-positive race: cache said healthy but daemon died
            # between probe and chain. Invalidate so next request re-
            # probes; fall through to passthrough on this one.
            self._cache.invalidate()
            log.info(
                "edge.chain.refused_invalidating",
                internal=f"{self._config.internal_host}:{self._config.internal_port}",
            )
            # v0.1.7 Gap 0: the daemon may have moved to a different
            # internal_port since this edge process started (port-fallback
            # race). Re-read runtime.toml so the next chain attempt uses
            # the new target instead of looping refused → passthrough.
            self._maybe_reresolve_chain_target()
            return False
        except OSError as exc:
            self._cache.invalidate()
            log.warning("edge.chain.connect_failed", error=str(exc))
            self._maybe_reresolve_chain_target()
            return False
        try:
            up_writer.write(parsed.raw_head)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
        return True

    async def _do_passthrough_connect(
        self,
        host_port: tuple[str, int],
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        host, port = host_port
        try:
            up_reader, up_writer = await asyncio.open_connection(host, port)
        except (TimeoutError, OSError) as exc:
            log.info(
                "edge.passthrough.connect_failed",
                host=host,
                port=port,
                error=str(exc),
            )
            self._safe_write(
                client_writer,
                b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n",
            )
            return
        try:
            self._safe_write(
                client_writer,
                b"HTTP/1.1 200 Connection Established\r\n\r\n",
            )
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass

    async def _handle_http(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        """Handle plain (non-CONNECT) HTTP-via-proxy requests.

        Two upstream choices, same as CONNECT:

        * **Chain.** Replay the head to the metering daemon's proxy
          listener verbatim — mitmproxy speaks the absolute-URL HTTP-
          proxy form so the request line passes through unchanged.
        * **Passthrough.** Parse host:port out of the absolute URL,
          rewrite the request line to its origin form, replay
          headers, shuttle bytes.

        Edge case: a plain HTTP request to a proxy with a non-absolute
        target (i.e. someone sent us a regular HTTP request as if we
        were the origin server). Rare in practice and outside our
        contract. Reply 400 and move on.
        """
        chained = await self._try_chain_http(parsed, client_reader, client_writer)
        if chained:
            return
        # Passthrough branch — parse upstream out of the absolute URL.
        upstream = _parse_http_absolute_url(parsed.target)
        if upstream is None:
            log.info("edge.http.bad_target", target=parsed.target)
            self._safe_write(
                client_writer,
                b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n",
            )
            return
        await self._do_passthrough_http(
            parsed, upstream, client_reader, client_writer
        )

    async def _try_chain_http(
        self,
        parsed: ParsedRequest,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> bool:
        if not await self._cache.is_healthy():
            return False
        try:
            up_reader, up_writer = await asyncio.open_connection(
                self._config.internal_host, self._config.internal_port
            )
        except ConnectionRefusedError:
            self._cache.invalidate()
            # v0.1.7 Gap 0: same re-resolve trigger as the CONNECT path —
            # see _try_chain for the full rationale.
            self._maybe_reresolve_chain_target()
            return False
        except OSError:
            self._cache.invalidate()
            self._maybe_reresolve_chain_target()
            return False
        try:
            up_writer.write(parsed.raw_head)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass
        return True

    async def _do_passthrough_http(
        self,
        parsed: ParsedRequest,
        upstream: tuple[str, int, str],
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
    ) -> None:
        host, port, origin_path = upstream
        try:
            up_reader, up_writer = await asyncio.open_connection(host, port)
        except (TimeoutError, OSError) as exc:
            log.info(
                "edge.passthrough.http.connect_failed",
                host=host,
                port=port,
                error=str(exc),
            )
            self._safe_write(
                client_writer,
                b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n",
            )
            return
        try:
            # Rewrite request line: absolute-URL → origin-form.
            new_request_line = (
                f"{parsed.method} {origin_path} {parsed.version}\r\n"
            ).encode("iso-8859-1")
            # Append the original header block (everything after the
            # first line of raw_head).
            _, _, header_tail = parsed.raw_head.partition(b"\r\n")
            up_writer.write(new_request_line + header_tail)
            await up_writer.drain()
            await shuttle_bidirectional(
                client_reader, client_writer, up_reader, up_writer
            )
        finally:
            try:
                up_writer.close()
                await up_writer.wait_closed()
            except (ConnectionResetError, BrokenPipeError, OSError):
                pass

    @staticmethod
    def _safe_write(writer: asyncio.StreamWriter, data: bytes) -> None:
        try:
            writer.write(data)
        except (ConnectionResetError, BrokenPipeError, OSError):
            return


def _parse_http_absolute_url(target: str) -> tuple[str, int, str] | None:
    """Parse ``http://host[:port]/path`` from an HTTP-proxy request line.

    Returns ``(host, port, origin_path)`` or ``None`` if the target is
    not in absolute-URL form. Default port is 80 for ``http://``,
    443 for ``https://`` (though https-via-proxy is normally CONNECT,
    not absolute-URL).
    """
    target = target.strip()
    for scheme, default_port in (("http://", 80), ("https://", 443)):
        if target.lower().startswith(scheme):
            rest = target[len(scheme):]
            slash = rest.find("/")
            if slash == -1:
                authority = rest
                origin_path = "/"
            else:
                authority = rest[:slash]
                origin_path = rest[slash:]
            if not authority:
                return None
            if ":" in authority:
                host, _, port_str = authority.rpartition(":")
                try:
                    port = int(port_str)
                except ValueError:
                    return None
            else:
                host = authority
                port = default_port
            if not host or not (0 < port < 65536):
                return None
            return host, port, origin_path
    return None
