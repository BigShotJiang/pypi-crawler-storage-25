"""
v0.1.9 Gap 12 — `halton-meter retag` one-shot CLI.

Rewrites historical ``requests`` rows from one project slug to another.
Predominantly for fixing the ``project='.halton-meter'`` rows captured
before the v0.1.8 Gap 6 workdir-tagger fix landed.

Direct ``sqlite3`` (stdlib) — no SQLAlchemy. The retag operation is a
one-shot CLI invocation; pulling the full async engine for a couple of
UPDATE statements is gratuitous. Plan filed at
``memory/plans/2026-05-01-v0.1.9-gap-12-retag.md``.

Schema invariants we rely on:

* ``projects(id PK, slug UNIQUE)``
* ``requests(project_id FK -> projects.id)``
* ``audit_events(project_id FK -> projects.id, action, metadata JSON, occurred_at)``

If a future migration changes the FK shape, this module must be revisited
— the queries hard-code ``WHERE project_id = ?`` against ``projects.slug``
lookups.
"""

from __future__ import annotations

import json
import sqlite3
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import structlog

log = structlog.get_logger()


DEFAULT_FROM_SLUG = ".halton-meter"
DEFAULT_TO_SLUG = "unattributed"
DEFAULT_DB_PATH = Path("~/.halton-meter/db.sqlite").expanduser()


# Allowed slug character class: lowercase letters, digits, dashes, dots,
# underscores. Everything else (whitespace, path separators, control chars)
# is rejected. Mirrors the conservative shape the workdir tagger emits.
# Empty string and pure-dot patterns are rejected explicitly below.
_FORBIDDEN_SLUG_FRAGMENTS = ("/", "\\", "\x00", "..", "\n", "\r", "\t")


class RetagError(RuntimeError):
    """Raised when retag refuses to proceed (validation, daemon-running)."""


@dataclass(frozen=True)
class RetagPlan:
    """Result of a dry-run / apply pass.

    ``rows_updated`` reflects the actual UPDATE rowcount for ``--apply``,
    or the projected count from ``SELECT count(*)`` for the dry-run.
    """

    from_slug: str
    to_slug: str
    rows_matched: int
    rows_updated: int  # equals rows_matched for --apply success; 0 for dry-run
    from_project_existed: bool
    to_project_created: bool
    from_project_deleted: bool
    applied: bool


def _validate_slug(slug: str, *, label: str) -> None:
    """Reject empty / path-traversal-ish slugs. Raises RetagError on bad input."""
    if not slug or not slug.strip():
        msg = f"{label} slug must not be empty"
        raise RetagError(msg)
    if slug != slug.strip():
        msg = f"{label} slug must not have leading/trailing whitespace"
        raise RetagError(msg)
    for frag in _FORBIDDEN_SLUG_FRAGMENTS:
        if frag in slug:
            msg = f"{label} slug contains forbidden fragment {frag!r}"
            raise RetagError(msg)
    # Pure dots are likely an attempt to traverse / reference cwd.
    if set(slug) <= {"."}:
        msg = f"{label} slug must not be all dots"
        raise RetagError(msg)


def daemon_health_ok(api_host: str, api_port: int, *, timeout: float = 0.5) -> bool:
    """Probe ``GET /health`` on the daemon. Returns True iff it answers 200."""
    url = f"http://{api_host}:{api_port}/health"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return getattr(resp, "status", None) == 200
    except (urllib.error.URLError, TimeoutError, OSError):
        return False
    except Exception:  # pragma: no cover — defensive
        return False


def retag_project(
    *,
    db_path: Path,
    from_slug: str,
    to_slug: str,
    apply: bool,
) -> RetagPlan:
    """Rewrite ``requests.project_id`` from ``from_slug`` to ``to_slug``.

    Dry-run path opens the DB read-only via ``mode=ro`` URI. The apply
    path opens read-write and runs UPDATE / INSERT / DELETE inside a
    single transaction; on any error the transaction is rolled back and
    a :class:`RetagError` is raised.

    Returns a :class:`RetagPlan` describing what happened.
    """
    _validate_slug(from_slug, label="--from")
    _validate_slug(to_slug, label="--to")
    if from_slug == to_slug:
        msg = "--from and --to slugs are identical; nothing to do"
        raise RetagError(msg)

    if not db_path.exists():
        msg = f"database not found: {db_path}"
        raise RetagError(msg)

    if apply:
        return _retag_apply(db_path, from_slug, to_slug)
    return _retag_dry_run(db_path, from_slug, to_slug)


def _retag_dry_run(db_path: Path, from_slug: str, to_slug: str) -> RetagPlan:
    uri = f"file:{db_path}?mode=ro"
    conn = sqlite3.connect(uri, uri=True, timeout=5.0)
    try:
        cur = conn.execute(
            "SELECT id FROM projects WHERE slug = ?", (from_slug,)
        )
        from_row = cur.fetchone()
        from_project_existed = from_row is not None
        rows_matched = 0
        if from_project_existed:
            cur = conn.execute(
                "SELECT count(*) FROM requests WHERE project_id = ?",
                (from_row[0],),
            )
            rows_matched = int(cur.fetchone()[0] or 0)
        cur = conn.execute(
            "SELECT 1 FROM projects WHERE slug = ?", (to_slug,)
        )
        to_exists = cur.fetchone() is not None
    finally:
        conn.close()

    return RetagPlan(
        from_slug=from_slug,
        to_slug=to_slug,
        rows_matched=rows_matched,
        rows_updated=0,
        from_project_existed=from_project_existed,
        to_project_created=not to_exists,
        from_project_deleted=False,
        applied=False,
    )


def _retag_apply(db_path: Path, from_slug: str, to_slug: str) -> RetagPlan:
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        # Match the daemon's pragmas so we play nicely with WAL.
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("BEGIN IMMEDIATE")
        try:
            cur = conn.execute(
                "SELECT id FROM projects WHERE slug = ?", (from_slug,)
            )
            from_row = cur.fetchone()
            if from_row is None:
                conn.execute("ROLLBACK")
                return RetagPlan(
                    from_slug=from_slug,
                    to_slug=to_slug,
                    rows_matched=0,
                    rows_updated=0,
                    from_project_existed=False,
                    to_project_created=False,
                    from_project_deleted=False,
                    applied=True,
                )
            from_id = from_row[0]

            cur = conn.execute(
                "SELECT id FROM projects WHERE slug = ?", (to_slug,)
            )
            to_row = cur.fetchone()
            to_project_created = False
            if to_row is None:
                to_id = str(uuid.uuid4())
                created_at = datetime.now(tz=UTC).isoformat().replace("+00:00", "Z")
                conn.execute(
                    "INSERT INTO projects (id, name, slug, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    (to_id, to_slug, to_slug, created_at),
                )
                to_project_created = True
            else:
                to_id = to_row[0]

            cur = conn.execute(
                "UPDATE requests SET project_id = ? WHERE project_id = ?",
                (to_id, from_id),
            )
            rows_updated = int(cur.rowcount or 0)

            # Audit trail (Gap 0 / Gap 3 ledger). Best-effort: if the
            # audit_events table is missing on a very old DB, log and
            # continue — the data rewrite is the load-bearing operation.
            try:
                conn.execute(
                    "INSERT INTO audit_events "
                    "(id, project_id, request_id, policy_id, action, "
                    " metadata, occurred_at) VALUES (?, ?, NULL, NULL, ?, ?, ?)",
                    (
                        str(uuid.uuid4()),
                        to_id,
                        "audit.retag_executed",
                        json.dumps(
                            {
                                "from": from_slug,
                                "to": to_slug,
                                "rows_updated": rows_updated,
                            }
                        ),
                        datetime.now(tz=UTC).isoformat().replace("+00:00", "Z"),
                    ),
                )
            except sqlite3.Error as exc:
                log.warning("retag.audit_skipped", error=str(exc))

            # Clean up the now-empty source project row. Skip if foreign
            # key references remain (e.g. lingering audit events).
            from_project_deleted = False
            cur = conn.execute(
                "SELECT count(*) FROM requests WHERE project_id = ?", (from_id,)
            )
            remaining = int(cur.fetchone()[0] or 0)
            if remaining == 0:
                try:
                    conn.execute(
                        "DELETE FROM projects WHERE id = ?", (from_id,)
                    )
                    from_project_deleted = True
                except sqlite3.IntegrityError:
                    # Other tables (policies, audit_events) reference
                    # this project. Leave the row in place.
                    from_project_deleted = False

            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    finally:
        conn.close()

    return RetagPlan(
        from_slug=from_slug,
        to_slug=to_slug,
        rows_matched=rows_updated,
        rows_updated=rows_updated,
        from_project_existed=True,
        to_project_created=to_project_created,
        from_project_deleted=from_project_deleted,
        applied=True,
    )
