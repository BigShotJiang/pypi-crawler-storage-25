"""
TEMP-PHASE-0: Hardcoded Anthropic pricing matrix for Phase 0 only.

This module will be removed when the backend takes over cost computation
in Phase 1. Tracked in memory/decisions.md 2026-04-28.

Rates are in millicents per million tokens (1 USD = 100_000 millicents,
so $3.00/MTok = 300_000 millicents/MTok).

Decision reference: memory/decisions.md 2026-04-28 — "Daemon Phase 0
computes cost locally"

Source: Anthropic published rates as of 2026-04-28.
  https://www.anthropic.com/api

Format per model entry:
  "model-id": ModelRates(
      input=<millicents per million input tokens>,
      output=<millicents per million output tokens>,
      thinking=<millicents per million thinking/reasoning tokens>,
      cache_read=<millicents per million cache-read tokens>,
      cache_write=<millicents per million cache-write tokens>,
  )

────────────────────────────────────────────────────────────────────────────
Cache-write TTL limitation (recorded 2026-04-30; decisions.md "Cache token
accounting: rename `cached_tokens`, single `cache_write` field, defer TTL
split"):

1. Anthropic's response usage object surfaces **one** cache-write field —
   ``usage.cache_creation_input_tokens``. There is no 5m/1h split in the
   response. TTL is set request-side via ``cache_control`` blocks in the
   messages array; it is not echoed in the response.

2. Chosen rate: ``cache_write = 1.25 x input``, the documented Anthropic
   5m-default ephemeral cache-write rate. Single field, single rate.

3. 1h-TTL undercount: requests using a 1h ephemeral cache TTL are billed
   by Anthropic at 2x input but logged here at 1.25x input — an accepted
   undercount until Anthropic exposes the TTL split in response usage.
   The undercount must be disclosed in user-facing reports once we have
   any 1h-TTL users (product-copy task, tracked separately).

4. Deferred extension point — when Anthropic exposes a structured split
   (e.g. ``usage.cache_creation = {"ephemeral_5m": …, "ephemeral_1h": …}``):
       (a) ``ResponseMetadata`` adds ``cache_write_5m_tokens`` and
           ``cache_write_1h_tokens`` (replacing the single
           ``cache_write_tokens`` field, or alongside it during a
           transition window).
       (b) ``ModelRates`` adds a ``cache_write_1h`` rate (the existing
           ``cache_write`` becomes the 5m rate).
       (c) One additive schema migration adds two columns to ``requests``
           and one column to ``pricing_rates`` (gated by
           ``PRAGMA user_version``).
       (d) The Anthropic adapter extracts the structured ``usage.cache_creation``
           dict instead of the single ``cache_creation_input_tokens`` field.
   This is contained in scope: one adapter change + one schema migration.
────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelRates:
    """Pricing rates for a single model, in millicents per million tokens."""

    input: int
    """Millicents per million input tokens (prompt + system + tools)."""

    output: int
    """Millicents per million output tokens (completion)."""

    thinking: int
    """Millicents per million thinking/reasoning tokens (same as output for Anthropic)."""

    cache_read: int
    """Millicents per million cache-read tokens."""

    cache_write: int
    """Millicents per million cache-write tokens.

    Initially seeded at 1.25x ``input`` (the Anthropic 5m-default ephemeral
    cache-write rate). See module-level TTL-limitation note above for the
    1h undercount rationale and the deferred extension point.
    """


# TEMP-PHASE-0: Anthropic rates as of 2026-04-28.
# $1 USD = 100_000 millicents.
# Rates in millicents per million tokens.
#
# Model                Input $/MTok  Output $/MTok  Thinking $/MTok  Cache read $/MTok
# claude-opus-4-7      $5.00         $25.00         $25.00           $0.50
# claude-opus-4-6      $5.00         $25.00         $25.00           $0.50
# claude-sonnet-4-6    $3.00         $15.00         $15.00           $0.30
# claude-haiku-4-5     $1.00         $5.00          $5.00            $0.10

_MILLICENTS_PER_DOLLAR = 100_000


def _usd(dollars_per_million: float) -> int:
    """Convert USD/MTok rate to millicents/MTok."""
    return round(dollars_per_million * _MILLICENTS_PER_DOLLAR)


ANTHROPIC_RATES: dict[str, ModelRates] = {
    # ----------------------------------------------------------------
    # Claude Opus 4.7 (latest Opus)
    # ----------------------------------------------------------------
    "claude-opus-4-7": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # Dated snapshot alias
    "claude-opus-4-7-20260101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Opus 4.6
    # ----------------------------------------------------------------
    "claude-opus-4-6": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-6-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Sonnet 4.6
    # ----------------------------------------------------------------
    "claude-sonnet-4-6": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-6-20251101": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Claude Haiku 4.5
    # ----------------------------------------------------------------
    "claude-haiku-4-5": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
        cache_write=_usd(1.00 * 1.25),
    ),
    "claude-haiku-4-5-20251001": ModelRates(
        input=_usd(1.00),
        output=_usd(5.00),
        thinking=_usd(5.00),
        cache_read=_usd(0.10),
        cache_write=_usd(1.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Legacy Opus 4.5 / 4.1 / 4.0 (still in use on some machines)
    # ----------------------------------------------------------------
    "claude-opus-4-5": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-5-20251101": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-1": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    "claude-opus-4-1-20250805": ModelRates(
        input=_usd(5.00),
        output=_usd(25.00),
        thinking=_usd(25.00),
        cache_read=_usd(0.50),
        cache_write=_usd(5.00 * 1.25),
    ),
    # ----------------------------------------------------------------
    # Legacy Sonnet 4.5 / 4.0
    # ----------------------------------------------------------------
    "claude-sonnet-4-5": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-5-20250929": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-0": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
    "claude-sonnet-4-20250514": ModelRates(
        input=_usd(3.00),
        output=_usd(15.00),
        thinking=_usd(15.00),
        cache_read=_usd(0.30),
        cache_write=_usd(3.00 * 1.25),
    ),
}
