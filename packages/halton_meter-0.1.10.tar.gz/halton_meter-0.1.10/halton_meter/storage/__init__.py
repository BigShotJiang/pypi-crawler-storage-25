"""
Halton Meter daemon storage layer (Phase 2B.2).

Single SQLite file at ~/.halton-meter/db.sqlite (renamed from logs.db).
SQLAlchemy 2.0 + aiosqlite. WAL mode. metadata.create_all on first start.

The legacy `halton_meter.storage` module re-exports `StorageManager` from
this package as a compatibility shim — proxy.py and tests can keep importing
`from halton_meter.storage import StorageManager` unchanged.
"""

from __future__ import annotations

from halton_meter.storage.engine import (
    DEFAULT_DB_PATH,
    LEGACY_DB_PATH,
    create_engine_for,
    dispose_engines,
    migrate_legacy_db_if_present,
)
from halton_meter.storage.models import (
    AuditEvent,
    Base,
    Policy,
    PricingRate,
    Project,
    ReconciliationRecord,
    Request,
)
from halton_meter.storage.repo import (
    StorageManager,
    backfill_legacy_requests,
    init_db,
    seed_pricing_rates,
)

__all__ = [
    "DEFAULT_DB_PATH",
    "LEGACY_DB_PATH",
    "AuditEvent",
    "Base",
    "Policy",
    "PricingRate",
    "Project",
    "ReconciliationRecord",
    "Request",
    "StorageManager",
    "backfill_legacy_requests",
    "create_engine_for",
    "dispose_engines",
    "init_db",
    "migrate_legacy_db_if_present",
    "seed_pricing_rates",
]
