"""ReconciliationRecord model."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import BigInteger, DateTime, Float, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class ReconciliationRecord(Base):
    __tablename__ = "reconciliation_records"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    provider: Mapped[str] = mapped_column(String(64), nullable=False)

    period_start: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    period_end: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    our_logged_total_minor_units: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    provider_billed_total_minor_units: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    # Cloud uses Numeric(8, 4); SQLite has no native NUMERIC, so we store as
    # Float. Display layer (the dashboard) rounds for presentation.
    variance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    reconciled_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    reconciled_by: Mapped[str | None] = mapped_column(
        String(32), nullable=True
    )  # "manual" | "scheduled" | "api"
