"""SQLAlchemy declarative base + reusable type aliases for the daemon's SQLite store."""

from __future__ import annotations

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Shared declarative base. All daemon models hang off this metadata."""
