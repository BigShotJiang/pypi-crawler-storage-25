"""PricingRate model — versioned per-provider/model/mode rates."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


def _uuid4_str() -> str:
    return str(uuid.uuid4())


class PricingRate(Base):
    __tablename__ = "pricing_rates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    model: Mapped[str] = mapped_column(String(255), nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="standard")

    effective_from: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    effective_to: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # All rates in millicents per million tokens (1 USD = 100_000 millicents)
    input_rate_per_million_minor_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    output_rate_per_million_minor_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    thinking_rate_per_million_minor_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    cache_read_rate_per_million_minor_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False
    )
    # Cache write rate. Single field — Anthropic's response usage exposes
    # only one cache_creation field with no 5m/1h split. See
    # pricing/matrix.py for the TTL-limitation note. Initially seeded at
    # 1.25x input (the documented 5m-default rate). Default 0 keeps
    # additive ALTER TABLE migrations safe on pre-existing rows.
    cache_write_rate_per_million_minor_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0, server_default="0"
    )

    # When the rate row was last manually verified against the provider's
    # public price page. Surfaced in the dashboard as a "last verified"
    # caveat next to the figures. NULL on seed rows; populated when an
    # operator clicks "verify" in the UI (Phase 2E).
    last_verified_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
