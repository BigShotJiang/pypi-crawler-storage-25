"""AuditEvent model — immutable log of every system event."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import JSON, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    project_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("projects.id", ondelete="SET NULL"),
        nullable=True,
    )
    # Soft reference only — requests.id is not an FK because requests may be purged.
    request_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    policy_id: Mapped[str | None] = mapped_column(
        String(36),
        ForeignKey("policies.id", ondelete="SET NULL"),
        nullable=True,
    )
    # Action enum values:
    # request.captured | request.cost_computed | policy.warned | policy.blocked
    # policy.evaluated | rate.updated | recon.completed | daemon.started | daemon.stopped
    action: Mapped[str] = mapped_column(Text, nullable=False)
    metadata_: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    project: Mapped[object] = relationship(
        "Project", back_populates="audit_events", lazy="select"
    )

    __table_args__ = (
        Index("idx_audit_project_occurred_at", "project_id", "occurred_at"),
        Index("idx_audit_action_occurred_at", "action", "occurred_at"),
    )
