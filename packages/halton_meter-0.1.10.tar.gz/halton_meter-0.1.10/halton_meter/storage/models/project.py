"""Project model — one row per attribution slug seen by the daemon."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    name: Mapped[str] = mapped_column(Text, nullable=False)
    slug: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )
    archived_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    requests: Mapped[list] = relationship(
        "Request", back_populates="project", lazy="select"
    )
    policies: Mapped[list] = relationship(
        "Policy", back_populates="project", lazy="select"
    )
    audit_events: Mapped[list] = relationship(
        "AuditEvent", back_populates="project", lazy="select"
    )
