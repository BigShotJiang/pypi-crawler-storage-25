"""
Health-check router.

Returns a small JSON document used by the dashboard's status indicator and
by smoke tests during install. Intentionally does not touch the database —
storage health is reported by a separate endpoint added in 2B.2/2B.3.
"""

from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel

from halton_meter import __version__

router = APIRouter()


class HealthResponse(BaseModel):
    status: str
    version: str


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Return basic liveness info for the daemon's HTTP API."""
    return HealthResponse(status="ok", version=__version__)
