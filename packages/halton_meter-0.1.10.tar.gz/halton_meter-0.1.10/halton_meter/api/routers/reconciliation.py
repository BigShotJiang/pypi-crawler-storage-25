"""Reconciliation endpoints.

GET routes are ported verbatim. POST /v1/reconciliation/run returns 501
in v1.0 — the Anthropic Admin API integration is deferred to Phase 3.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.storage.models import ReconciliationRecord

router = APIRouter(prefix="/v1/reconciliation", tags=["reconciliation"])


def _reconciliation_status(variance_pct: float | None) -> str:
    if variance_pct is None:
        return "unknown"
    abs_v = abs(variance_pct)
    if abs_v <= 1.0:
        return "matched"
    if abs_v <= 3.0:
        return "minor"
    return "investigate"


class ReconciliationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    provider: str
    period_start: datetime | None
    period_end: datetime | None
    our_logged_total_minor_units: int | None
    provider_billed_total_minor_units: int | None
    variance_pct: float | None
    reconciled_at: datetime
    notes: str | None = None
    reconciled_by: str | None = None
    status: str = Field(description="matched | minor | investigate | unknown")

    @classmethod
    def from_orm(cls, record: ReconciliationRecord) -> ReconciliationResponse:  # type: ignore[override]
        vp = float(record.variance_pct) if record.variance_pct is not None else None
        return cls(
            id=record.id,
            provider=record.provider,
            period_start=record.period_start,
            period_end=record.period_end,
            our_logged_total_minor_units=record.our_logged_total_minor_units,
            provider_billed_total_minor_units=record.provider_billed_total_minor_units,
            variance_pct=vp,
            reconciled_at=record.reconciled_at,
            notes=record.notes,
            reconciled_by=record.reconciled_by,
            status=_reconciliation_status(vp),
        )


class ReconciliationRunRequest(BaseModel):
    provider: str
    since: str = Field(description="Start date YYYY-MM-DD (inclusive)")
    until: str = Field(description="End date YYYY-MM-DD (inclusive)")


@router.get("", response_model=list[ReconciliationResponse])
async def list_reconciliation(
    session: AsyncSession = Depends(get_session),
) -> list[ReconciliationResponse]:
    result = await session.execute(
        select(ReconciliationRecord).order_by(
            ReconciliationRecord.reconciled_at.desc()
        )
    )
    records = result.scalars().all()
    return [ReconciliationResponse.from_orm(r) for r in records]


@router.get("/latest", response_model=list[ReconciliationResponse])
async def get_latest_reconciliation(
    session: AsyncSession = Depends(get_session),
) -> list[ReconciliationResponse]:
    from sqlalchemy import func

    subq = (
        select(
            ReconciliationRecord.provider,
            func.max(ReconciliationRecord.reconciled_at).label("max_reconciled_at"),
        )
        .group_by(ReconciliationRecord.provider)
        .subquery()
    )
    result = await session.execute(
        select(ReconciliationRecord).join(
            subq,
            (ReconciliationRecord.provider == subq.c.provider)
            & (ReconciliationRecord.reconciled_at == subq.c.max_reconciled_at),
        )
    )
    records = result.scalars().all()
    return [ReconciliationResponse.from_orm(r) for r in records]


@router.post("/run")
async def trigger_reconciliation(
    body: ReconciliationRunRequest,
    session: AsyncSession = Depends(get_session),
) -> JSONResponse:
    """Returns 501 in v1.0 — Anthropic Admin API integration is Phase 3.

    Body still validated so the dashboard's existing form keeps working
    once the route lands. The body is intentionally accepted so callers
    don't get a 422 before the 501; they get an explanatory message.
    """
    del body, session
    return JSONResponse(
        status_code=501,
        content={
            "detail": (
                "Manual reconciliation is deferred to Phase 3 — the Anthropic "
                "Admin API integration is not in v1.0. Reconciliation records "
                "from prior runs remain available via GET /v1/reconciliation."
            ),
            "phase": "3",
        },
    )
