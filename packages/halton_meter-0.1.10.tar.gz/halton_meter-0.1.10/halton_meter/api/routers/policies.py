"""Policies CRUD API.

Ported from halton-meter-cloud:backend/app/routers/policies.py.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.storage.models import Policy, Project

router = APIRouter(prefix="/v1/policies", tags=["policies"])


class PolicyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID | None
    project_slug: str | None
    type: str
    config: dict[str, Any]
    active: bool
    warn_only: bool
    created_at: datetime


class PolicyCreate(BaseModel):
    project_slug: str
    type: str = Field(
        description="budget_monthly | model_allow_list | requests_per_day"
    )
    config: dict[str, Any] = Field(default_factory=dict)
    warn_only: bool = Field(default=True)


class PolicyUpdate(BaseModel):
    config: dict[str, Any] | None = None
    active: bool | None = None
    warn_only: bool | None = None


class DaemonSyncPolicy(BaseModel):
    project_slug: str
    type: str
    config: dict[str, Any]
    warn_only: bool


async def _get_project_by_slug(session: AsyncSession, slug: str) -> Project | None:
    result = await session.execute(select(Project).where(Project.slug == slug))
    return result.scalar_one_or_none()


async def _build_response(session: AsyncSession, policy: Policy) -> PolicyResponse:
    project_slug: str | None = None
    if policy.project_id is not None:
        result = await session.execute(
            select(Project).where(Project.id == policy.project_id)
        )
        proj = result.scalar_one_or_none()
        if proj is not None:
            project_slug = proj.slug
    return PolicyResponse(
        id=policy.id,
        project_id=policy.project_id,
        project_slug=project_slug,
        type=policy.type,
        config=policy.config,
        active=policy.active,
        warn_only=policy.warn_only,
        created_at=policy.created_at,
    )


@router.get("/daemon-sync", response_model=list[DaemonSyncPolicy])
async def daemon_sync(
    session: AsyncSession = Depends(get_session),
) -> list[DaemonSyncPolicy]:
    """Compact list used by external daemons (Phase 3 hosted shape).

    The local v1.0 daemon does not call this — it reads policies directly
    from SQLite. Kept for API-shape stability.
    """
    result = await session.execute(
        select(Policy, Project.slug)
        .outerjoin(Project, Policy.project_id == Project.id)
        .where(Policy.active.is_(True))
    )
    rows = result.all()
    return [
        DaemonSyncPolicy(
            project_slug=slug or "",
            type=policy.type,
            config=policy.config,
            warn_only=policy.warn_only,
        )
        for policy, slug in rows
    ]


@router.get("", response_model=list[PolicyResponse])
async def list_policies(
    project_slug: str | None = None,
    session: AsyncSession = Depends(get_session),
) -> list[PolicyResponse]:
    query = select(Policy).where(Policy.active.is_(True))
    if project_slug is not None:
        proj = await _get_project_by_slug(session, project_slug)
        if proj is None:
            raise HTTPException(
                status_code=404, detail=f"Project '{project_slug}' not found"
            )
        query = query.where(Policy.project_id == proj.id)
    result = await session.execute(query.order_by(Policy.created_at.desc()))
    policies = result.scalars().all()
    return [await _build_response(session, p) for p in policies]


@router.get("/{policy_id}", response_model=PolicyResponse)
async def get_policy(
    policy_id: uuid.UUID,
    session: AsyncSession = Depends(get_session),
) -> PolicyResponse:
    result = await session.execute(select(Policy).where(Policy.id == str(policy_id)))
    policy = result.scalar_one_or_none()
    if policy is None:
        raise HTTPException(status_code=404, detail=f"Policy {policy_id} not found")
    return await _build_response(session, policy)


@router.post("", response_model=PolicyResponse, status_code=201)
async def create_policy(
    body: PolicyCreate,
    session: AsyncSession = Depends(get_session),
) -> PolicyResponse:
    proj = await _get_project_by_slug(session, body.project_slug)
    if proj is None:
        raise HTTPException(
            status_code=404, detail=f"Project '{body.project_slug}' not found"
        )

    now = datetime.now(tz=UTC)
    policy = Policy(
        id=str(uuid.uuid4()),
        project_id=proj.id,
        type=body.type,
        config=body.config,
        active=True,
        warn_only=body.warn_only,
        created_at=now,
        updated_at=now,
    )
    session.add(policy)
    await session.flush()
    return await _build_response(session, policy)


@router.put("/{policy_id}", response_model=PolicyResponse)
async def update_policy(
    policy_id: uuid.UUID,
    body: PolicyUpdate,
    session: AsyncSession = Depends(get_session),
) -> PolicyResponse:
    result = await session.execute(select(Policy).where(Policy.id == str(policy_id)))
    policy = result.scalar_one_or_none()
    if policy is None:
        raise HTTPException(status_code=404, detail=f"Policy {policy_id} not found")

    if body.config is not None:
        policy.config = body.config
    if body.active is not None:
        policy.active = body.active
    if body.warn_only is not None:
        policy.warn_only = body.warn_only
    policy.updated_at = datetime.now(tz=UTC)

    await session.flush()
    return await _build_response(session, policy)


@router.delete("/{policy_id}", status_code=204)
async def delete_policy(
    policy_id: uuid.UUID,
    session: AsyncSession = Depends(get_session),
) -> None:
    result = await session.execute(select(Policy).where(Policy.id == str(policy_id)))
    policy = result.scalar_one_or_none()
    if policy is None:
        raise HTTPException(status_code=404, detail=f"Policy {policy_id} not found")
    policy.active = False
    policy.updated_at = datetime.now(tz=UTC)
    await session.flush()
