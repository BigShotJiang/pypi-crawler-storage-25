"""Daemon status endpoint.

Ported from halton-meter-cloud:backend/app/routers/daemon.py.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.storage.models import Request

router = APIRouter(prefix="/v1/daemon", tags=["daemon"])


class DaemonStatus(BaseModel):
    last_seen_at: datetime | None = Field(default=None)
    request_count_last_hour: int = Field(default=0, ge=0)


@router.get("/status", response_model=DaemonStatus)
async def get_daemon_status(
    session: Annotated[AsyncSession, Depends(get_session)],
) -> DaemonStatus:
    last_seen = (
        await session.execute(select(func.max(Request.recorded_at)))
    ).scalar_one_or_none()

    one_hour_ago = datetime.now(tz=UTC) - timedelta(hours=1)
    request_count = (
        await session.execute(
            select(func.count(Request.id)).where(Request.recorded_at >= one_hour_ago)
        )
    ).scalar_one()

    if last_seen is not None and last_seen.tzinfo is None:
        last_seen = last_seen.replace(tzinfo=UTC)

    return DaemonStatus(
        last_seen_at=last_seen,
        request_count_last_hour=int(request_count or 0),
    )
