"""Projects, stats, and global stats endpoints.

Ported from halton-meter-cloud:backend/app/routers/projects.py.
"""

from __future__ import annotations

import csv
import io
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.api.schemas.projects import (
    GlobalStats,
    ProjectDetail,
    ProjectListItem,
    ProjectStats,
    RequestsPage,
)
from halton_meter.api.services.stats import (
    get_global_stats,
    get_project_by_slug,
    get_project_requests,
    get_project_stats,
    list_projects,
)

router = APIRouter(tags=["projects"])

_stats_router = APIRouter(prefix="/v1/stats")


@_stats_router.get("", response_model=GlobalStats)
async def get_global_stats_endpoint(
    since: Annotated[datetime | None, Query()] = None,
    until: Annotated[datetime | None, Query()] = None,
    provider: Annotated[str | None, Query()] = None,
    session: AsyncSession = Depends(get_session),
) -> GlobalStats:
    return await get_global_stats(
        session=session, since=since, until=until, provider=provider
    )


_projects_router = APIRouter(prefix="/v1/projects")


@_projects_router.get("", response_model=list[ProjectListItem])
async def list_projects_endpoint(
    session: AsyncSession = Depends(get_session),
) -> list[ProjectListItem]:
    return await list_projects(session)


@_projects_router.get("/{slug}", response_model=ProjectDetail)
async def get_project(
    slug: str,
    session: AsyncSession = Depends(get_session),
) -> ProjectDetail:
    project = await get_project_by_slug(session, slug)
    if project is None:
        raise HTTPException(status_code=404, detail=f"Project '{slug}' not found")
    return project


@_projects_router.get("/{slug}/stats", response_model=ProjectStats)
async def get_stats(
    slug: str,
    since: Annotated[datetime | None, Query()] = None,
    until: Annotated[datetime | None, Query()] = None,
    provider: Annotated[str | None, Query()] = None,
    cursor: Annotated[str | None, Query()] = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    session: AsyncSession = Depends(get_session),
) -> ProjectStats:
    stats = await get_project_stats(
        session=session,
        slug=slug,
        since=since,
        until=until,
        provider=provider,
        cursor=cursor,
        limit=limit,
    )
    if stats is None:
        raise HTTPException(status_code=404, detail=f"Project '{slug}' not found")
    return stats


@_projects_router.get("/{slug}/requests", response_model=RequestsPage)
async def get_requests(
    slug: str,
    since: Annotated[datetime | None, Query()] = None,
    until: Annotated[datetime | None, Query()] = None,
    provider: Annotated[str | None, Query()] = None,
    model: Annotated[str | None, Query()] = None,
    cursor: Annotated[str | None, Query()] = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    session: AsyncSession = Depends(get_session),
) -> RequestsPage:
    return await get_project_requests(
        session=session,
        slug=slug,
        since=since,
        until=until,
        provider=provider,
        cursor=cursor,
        limit=limit,
    )


@_projects_router.get("/{slug}/requests.csv")
async def export_requests_csv(
    slug: str,
    since: Annotated[datetime | None, Query()] = None,
    until: Annotated[datetime | None, Query()] = None,
    provider: Annotated[str | None, Query()] = None,
    session: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    page = await get_project_requests(
        session=session,
        slug=slug,
        since=since,
        until=until,
        provider=provider,
        cursor=None,
        limit=10_000,
    )

    if not page.items and page.total == 0:
        project = await get_project_by_slug(session, slug)
        if project is None:
            raise HTTPException(status_code=404, detail=f"Project '{slug}' not found")

    today = datetime.now().strftime("%Y-%m-%d")
    filename = f"halton-meter-{slug}-{today}.csv"

    def generate_csv() -> str:
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(
            [
                "timestamp",
                "provider",
                "model",
                "mode",
                "input_tokens",
                "output_tokens",
                "thinking_tokens",
                # Renamed from `cached_tokens` 2026-04-30 (decisions.md);
                # `cache_write_tokens` is new (Anthropic
                # `cache_creation_input_tokens`).
                "cache_read_tokens",
                "cache_write_tokens",
                "cost_usd",
                "latency_ms",
                "status",
            ]
        )
        for r in page.items:
            cost_usd = (
                (r.cost_usd_minor_units / 100_000)
                if r.cost_usd_minor_units is not None
                else ""
            )
            writer.writerow(
                [
                    r.requested_at.isoformat(),
                    r.provider,
                    r.model,
                    r.mode,
                    r.input_tokens,
                    r.output_tokens,
                    r.thinking_tokens,
                    r.cache_read_tokens,
                    r.cache_write_tokens,
                    f"{cost_usd:.6f}" if cost_usd != "" else "",
                    r.latency_ms if r.latency_ms is not None else "",
                    r.status,
                ]
            )
        return buf.getvalue()

    csv_content = generate_csv()

    return StreamingResponse(
        iter([csv_content]),
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Type": "text/csv; charset=utf-8",
        },
    )


router.include_router(_stats_router)
router.include_router(_projects_router)
