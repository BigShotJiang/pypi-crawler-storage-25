"""POST /v1/requests/batch — preserved for forward compatibility.

The local v1.0 daemon writes directly to SQLite via the proxy hot path;
nothing posts to this route. We keep it so a future Phase 3 hosted-ingest
path can reuse the same shape without API churn.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.api.schemas.ingest import BatchIngestRequest, BatchIngestResponse
from halton_meter.api.services.ingest import ingest_batch

router = APIRouter(prefix="/v1/requests", tags=["ingest"])


@router.post("/batch", response_model=BatchIngestResponse)
async def batch_ingest(
    body: BatchIngestRequest,
    session: AsyncSession = Depends(get_session),
) -> BatchIngestResponse:
    """Receive a batch of log records.

    Validates the body, runs the ingest service, returns the accepted /
    duplicate counts. Idempotent on ``batch_id``.
    """
    records = [r.model_dump() for r in body.records]
    accepted, duplicate = await ingest_batch(
        session=session,
        batch_id=body.batch_id,
        records=records,
    )
    return BatchIngestResponse(accepted=accepted, duplicate=duplicate)
