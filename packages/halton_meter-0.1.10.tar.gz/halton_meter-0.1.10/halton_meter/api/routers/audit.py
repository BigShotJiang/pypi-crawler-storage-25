"""Audit log API.

Ported from halton-meter-cloud:backend/app/routers/audit.py.
"""

from __future__ import annotations

import base64
import json
import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.api.deps import get_session
from halton_meter.storage.models import AuditEvent, Project

router = APIRouter(prefix="/v1/audit", tags=["audit"])


class AuditEventResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    project_id: uuid.UUID | None
    project_slug: str | None
    request_id: uuid.UUID | None
    policy_id: uuid.UUID | None
    action: str
    metadata: dict[str, Any]
    occurred_at: datetime


class AuditPage(BaseModel):
    items: list[AuditEventResponse]
    next_cursor: str | None = Field(None)
    total: int


def _encode_cursor(event_id: str, occurred_at: datetime) -> str:
    payload = {"id": str(event_id), "at": occurred_at.isoformat()}
    return base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()


def _decode_cursor(cursor: str) -> tuple[str, datetime]:
    try:
        payload = json.loads(base64.urlsafe_b64decode(cursor.encode()))
        event_id = str(uuid.UUID(payload["id"]))
        occurred_at = datetime.fromisoformat(payload["at"])
        return event_id, occurred_at
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid pagination cursor") from exc


class DaemonEventIn(BaseModel):
    """Body for POST /v1/audit/daemon-event.

    Local v1.0 proxy writes audit events directly through services.audit.log_event;
    this route stays for API-shape stability so a Phase 3 hosted backend can
    consume daemon events the same way.
    """

    action: str
    project: str | None = None
    policy_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


@router.post("/daemon-event", status_code=204)
async def record_daemon_event(
    body: DaemonEventIn,
    session: AsyncSession = Depends(get_session),
) -> None:
    from halton_meter.api.services.audit import log_event  # local import

    project_id: str | None = None
    if body.project:
        result = await session.execute(
            select(Project).where(Project.slug == body.project)
        )
        proj = result.scalar_one_or_none()
        if proj is not None:
            project_id = proj.id

    policy_id: str | None = None
    if body.policy_id:
        try:
            policy_id = str(uuid.UUID(body.policy_id))
        except ValueError:
            pass

    await log_event(
        session,
        action=body.action,
        project_id=project_id,
        policy_id=policy_id,
        metadata=body.metadata,
    )


@router.get("", response_model=AuditPage)
async def list_audit_events(
    project_slug: str | None = Query(None),
    action: str | None = Query(None),
    since: datetime | None = Query(None),
    until: datetime | None = Query(None),
    limit: int = Query(default=100, ge=1, le=500),
    cursor: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
) -> AuditPage:
    conditions: list = []

    if project_slug is not None:
        proj_result = await session.execute(
            select(Project).where(Project.slug == project_slug)
        )
        proj = proj_result.scalar_one_or_none()
        if proj is None:
            raise HTTPException(
                status_code=404, detail=f"Project '{project_slug}' not found"
            )
        conditions.append(AuditEvent.project_id == proj.id)

    if action is not None:
        conditions.append(AuditEvent.action == action)
    if since is not None:
        conditions.append(AuditEvent.occurred_at >= since)
    if until is not None:
        conditions.append(AuditEvent.occurred_at <= until)

    count_result = await session.execute(
        select(func.count()).select_from(AuditEvent).where(*conditions)
    )
    total = count_result.scalar_one()

    if cursor is not None:
        cursor_id, cursor_at = _decode_cursor(cursor)
        conditions.append(
            (AuditEvent.occurred_at < cursor_at)
            | (
                (AuditEvent.occurred_at == cursor_at)
                & (AuditEvent.id < cursor_id)
            )
        )

    rows_result = await session.execute(
        select(AuditEvent, Project.slug)
        .outerjoin(Project, AuditEvent.project_id == Project.id)
        .where(*conditions)
        .order_by(AuditEvent.occurred_at.desc(), AuditEvent.id.desc())
        .limit(limit + 1)
    )
    rows = rows_result.all()

    has_more = len(rows) > limit
    page_rows = rows[:limit]

    items = [
        AuditEventResponse(
            id=event.id,
            project_id=event.project_id,
            project_slug=slug,
            request_id=event.request_id,
            policy_id=event.policy_id,
            action=event.action,
            metadata=event.metadata_,
            occurred_at=event.occurred_at,
        )
        for event, slug in page_rows
    ]

    next_cursor: str | None = None
    if has_more and page_rows:
        last_event, _ = page_rows[-1]
        next_cursor = _encode_cursor(last_event.id, last_event.occurred_at)

    return AuditPage(items=items, next_cursor=next_cursor, total=total)
