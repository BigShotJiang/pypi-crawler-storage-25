"""FastAPI routers mounted by the daemon's API app."""
