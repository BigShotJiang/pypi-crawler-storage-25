"""
FastAPI app factory for the Halton Meter daemon.

The app is mounted by `halton-meter daemon` programmatically — it is not
launched standalone via `uvicorn app:main`. The factory takes a HaltonConfig
so CORS origins (and future settings) flow from the same config file the
rest of the daemon reads.

Phase 2B.1 ships a skeleton: only the /health router is wired in. Routers
ported from the legacy backend (projects, pricing_rates, reconciliation,
policies, audit, daemon) land in Phase 2B.3.
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from halton_meter import __version__
from halton_meter.api.deps import configure_session_factory
from halton_meter.api.routers import (
    audit,
    daemon,
    health,
    ingest,
    policies,
    pricing_rates,
    projects,
    reconciliation,
)
from halton_meter.config import HaltonConfig


def create_app(config: HaltonConfig | None = None) -> FastAPI:
    """
    Build a FastAPI app for the daemon.

    Args:
        config: HaltonConfig instance. If None, defaults are used — useful for
            tests and ad-hoc REPL exploration. Production callers (the CLI)
            always pass an explicit config.

    Returns:
        A configured FastAPI app. Not yet bound to a server — the caller
        wraps it in uvicorn.
    """
    cfg = config or HaltonConfig()
    configure_session_factory(cfg.storage.db_path)

    app = FastAPI(
        title="Halton Meter",
        description="Local LLM API cost-attribution daemon HTTP API.",
        version=__version__,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(cfg.cors.allow_origins),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router)
    app.include_router(projects.router)
    app.include_router(pricing_rates.router)
    app.include_router(reconciliation.router)
    app.include_router(policies.router)
    app.include_router(audit.router)
    app.include_router(daemon.router)
    app.include_router(ingest.router)

    return app
