"""
FastAPI dependencies — async SQLAlchemy session injection.

Sessions are resolved against the engine cache in
``halton_meter.storage.engine``. The daemon CLI initialises the engine
once at startup against ``cfg.storage.db_path``; every request handler
gets a session bound to that same engine.

For tests we let the test rig override ``get_session`` to point at an
in-memory engine; that way the test uses the very same SQLAlchemy models
without spinning up the daemon process.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from halton_meter.config import HaltonConfig, load_config
from halton_meter.storage.engine import create_engine_for

# Path used for new sessions. The CLI sets this before mounting the app;
# tests that bypass the CLI can override the dependency directly via
# ``app.dependency_overrides``.
_DB_PATH: str | Path | None = None


def configure_session_factory(db_path: str | Path | None) -> None:
    """Set the DB path used for new sessions in this process."""
    global _DB_PATH
    _DB_PATH = db_path


def _resolve_db_path() -> str | Path:
    """Determine the DB path for new sessions.

    Order of precedence:
      1. ``configure_session_factory`` was called explicitly.
      2. The default loaded from ``HaltonConfig`` (i.e. ``~/.halton-meter/db.sqlite``).
    """
    if _DB_PATH is not None:
        return _DB_PATH
    cfg: HaltonConfig = load_config()
    return cfg.storage.db_path


@asynccontextmanager
async def session_scope() -> AsyncGenerator[AsyncSession, None]:
    """Yield a session, committing on clean exit and rolling back on error."""
    _, sessionmaker = create_engine_for(_resolve_db_path())
    async with sessionmaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields an AsyncSession per request."""
    async with session_scope() as session:
        yield session
