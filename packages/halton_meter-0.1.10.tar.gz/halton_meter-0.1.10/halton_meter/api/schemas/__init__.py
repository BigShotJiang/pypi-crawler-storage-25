"""Pydantic request/response schemas for the daemon's HTTP API.

Ported verbatim from the cloud backend (`halton-meter-cloud:backend/app/schemas/`).
The dashboard treats these as the authoritative contract; we keep wire shapes
identical so the dashboard does not need updating.
"""
