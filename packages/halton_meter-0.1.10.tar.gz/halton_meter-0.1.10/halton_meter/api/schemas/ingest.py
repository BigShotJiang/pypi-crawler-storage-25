"""
Pydantic schemas for the POST /v1/requests/batch ingest endpoint.

Preserved as a forward-compatible no-op route for the future Phase 3
hosted-ingest path. The local daemon writes directly to SQLite via the
proxy hot path; nothing currently posts to /v1/requests/batch in v1.0.
"""

from __future__ import annotations

import uuid

from pydantic import BaseModel, ConfigDict, Field


class LogRecordIn(BaseModel):
    """Single captured LLM API call from a remote daemon."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="UUID v4 from the daemon")
    project: str = Field(description="Project slug resolved by daemon tagging")
    provider: str = Field(description="Provider name, e.g. 'anthropic'")
    model: str = Field(description="Model identifier as returned by provider")

    input_tokens: int = Field(default=0)
    output_tokens: int = Field(default=0)
    thinking_tokens: int = Field(default=0)
    # Renamed from `cached_tokens` 2026-04-30 (decisions.md): the ambiguous
    # name became a bug once `cache_write_tokens` was introduced alongside
    # it. Wire-format rename only; no schema migration in this file.
    cache_read_tokens: int = Field(default=0)
    cache_write_tokens: int = Field(default=0)

    cost_millicents: int | None = Field(default=None)

    tokens_complete: bool = Field(default=True)
    latency_ms: float = Field(default=0.0)

    requested_at: str = Field(description="ISO 8601 UTC timestamp")
    recorded_at: str = Field(description="ISO 8601 UTC timestamp")


class BatchIngestRequest(BaseModel):
    model_config = ConfigDict(frozen=True)

    batch_id: uuid.UUID
    records: list[LogRecordIn]


class BatchIngestResponse(BaseModel):
    accepted: int
    duplicate: int
