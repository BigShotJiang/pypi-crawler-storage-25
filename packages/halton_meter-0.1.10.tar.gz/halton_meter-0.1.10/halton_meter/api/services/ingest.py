"""
Ingest service — receives batched log records and stores them.

Ported from halton-meter-cloud:backend/app/services/ingest.py with PG → SQLite
adjustments:

  * ``sqlalchemy.dialects.postgresql.insert`` → ``sqlalchemy.dialects.sqlite.insert``
  * UUIDs are stored as String(36) — accept either uuid.UUID or string keys.

The cost-recomputation routine is the cornerstone: the proxy hot path
calls ``compute_cost_for_record`` directly so a request lands in SQLite
already costed against the live ``pricing_rates`` row.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import structlog
from sqlalchemy import select
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from halton_meter.api.services.audit import log_event
from halton_meter.pricing import apply_rates
from halton_meter.storage.models import PricingRate, Project, Request

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

log = structlog.get_logger()

_processed_batch_ids: set[uuid.UUID] = set()


async def _get_or_create_project(session: AsyncSession, slug: str) -> Project:
    """Return existing project by slug, or auto-create it."""
    result = await session.execute(select(Project).where(Project.slug == slug))
    project = result.scalar_one_or_none()
    if project is None:
        project = Project(id=str(uuid.uuid4()), name=slug, slug=slug)
        session.add(project)
        await session.flush()
        log.info("project.auto_created", slug=slug)
    return project


async def get_pricing_rate(
    session: AsyncSession,
    provider: str,
    model: str,
    mode: str,
    at: datetime,
) -> PricingRate | None:
    """Look up the active pricing rate for ``(provider, model, mode)`` at ``at``."""
    result = await session.execute(
        select(PricingRate)
        .where(
            PricingRate.provider == provider,
            PricingRate.model == model,
            PricingRate.mode == mode,
            PricingRate.effective_from <= at,
            (PricingRate.effective_to.is_(None)) | (PricingRate.effective_to > at),
        )
        .order_by(PricingRate.effective_from.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


def compute_cost_from_rate(
    rate: PricingRate,
    input_tokens: int,
    output_tokens: int,
    thinking_tokens: int,
    cache_read_tokens: int,
    cache_write_tokens: int = 0,
) -> int:
    """Compute cost in millicents using a ``PricingRate`` row.

    Routes through the shared :func:`halton_meter.pricing.apply_rates`
    helper so cost values are bit-identical to the proxy hot-path
    (bundled-matrix) calculation for the same token set + rate values.
    See memory/plans/2026-04-30-daemon-audit-remediation.md (P0-4).
    """
    return apply_rates(
        input_tokens=input_tokens,
        input_rate=rate.input_rate_per_million_minor_units,
        output_tokens=output_tokens,
        output_rate=rate.output_rate_per_million_minor_units,
        thinking_tokens=thinking_tokens,
        thinking_rate=rate.thinking_rate_per_million_minor_units,
        cache_read_tokens=cache_read_tokens,
        cache_read_rate=rate.cache_read_rate_per_million_minor_units,
        cache_write_tokens=cache_write_tokens,
        cache_write_rate=rate.cache_write_rate_per_million_minor_units,
    )


async def ingest_batch(
    session: AsyncSession,
    batch_id: uuid.UUID,
    records: list[dict],
) -> tuple[int, int]:
    """
    Insert records into the requests table.

    Returns ``(accepted, duplicate)`` counts. Idempotent by ``batch_id``: a
    re-post of the same batch returns ``(0, len(records))``.

    Cost is recomputed from the ``pricing_rates`` table using the rate
    effective at ``requested_at``. If no rate is found, falls back to the
    daemon-supplied ``cost_millicents``.
    """
    if batch_id in _processed_batch_ids:
        log.info("ingest.batch_duplicate", batch_id=str(batch_id), records=len(records))
        return 0, len(records)

    accepted = 0
    duplicate = 0

    slugs = {r["project"] for r in records}
    project_map: dict[str, str] = {}
    for slug in slugs:
        project = await _get_or_create_project(session, slug)
        project_map[slug] = project.id

    for rec in records:
        try:
            requested_at = datetime.fromisoformat(
                rec["requested_at"].replace("Z", "+00:00")
            )
        except (ValueError, KeyError, AttributeError):
            requested_at = datetime.now(tz=UTC)

        try:
            recorded_at = datetime.fromisoformat(
                rec["recorded_at"].replace("Z", "+00:00")
            )
        except (ValueError, KeyError, AttributeError):
            recorded_at = datetime.now(tz=UTC)

        try:
            record_id = str(uuid.UUID(rec["id"]))
        except (ValueError, KeyError, TypeError):
            record_id = str(uuid.uuid4())

        thinking_tokens = int(rec.get("thinking_tokens", 0) or 0)
        mode = "thinking" if thinking_tokens > 0 else "standard"

        input_tokens = int(rec.get("input_tokens", 0) or 0)
        output_tokens = int(rec.get("output_tokens", 0) or 0)
        # Wire-format dict keys renamed 2026-04-30 (decisions.md):
        # `cached_tokens` → `cache_read_tokens`; `cache_write_tokens` is new.
        cache_read_tokens = int(rec.get("cache_read_tokens", 0) or 0)
        cache_write_tokens = int(rec.get("cache_write_tokens", 0) or 0)
        provider = rec.get("provider", "unknown")
        model = rec.get("model", "unknown")

        computed_cost: int | None = None
        rate: PricingRate | None = None
        try:
            rate = await get_pricing_rate(session, provider, model, mode, requested_at)
            if rate is not None:
                computed_cost = compute_cost_from_rate(
                    rate,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    thinking_tokens=thinking_tokens,
                    cache_read_tokens=cache_read_tokens,
                    cache_write_tokens=cache_write_tokens,
                )
            else:
                daemon_cost = rec.get("cost_millicents")
                computed_cost = int(daemon_cost) if daemon_cost is not None else None
        except Exception as exc:  # pragma: no cover — defensive
            daemon_cost = rec.get("cost_millicents")
            computed_cost = int(daemon_cost) if daemon_cost is not None else None
            log.error("ingest.cost_error", model=model, error=str(exc), exc_info=True)

        stmt = (
            sqlite_insert(Request)
            .values(
                id=record_id,
                project_id=project_map[rec["project"]],
                provider=provider,
                model=model,
                mode=mode,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                thinking_tokens=thinking_tokens,
                cache_read_tokens=cache_read_tokens,
                cache_write_tokens=cache_write_tokens,
                cost_usd_minor_units=computed_cost,
                latency_ms=float(rec.get("latency_ms", 0.0)) or None,
                tokens_complete=bool(rec.get("tokens_complete", True)),
                requested_at=requested_at,
                recorded_at=recorded_at,
                status="success",
            )
            .on_conflict_do_nothing(index_elements=["id"])
        )
        result = await session.execute(stmt)
        if (result.rowcount or 0) == 1:
            accepted += 1
            await log_event(
                session,
                action="request.captured",
                project_id=project_map[rec["project"]],
                request_id=record_id,
                metadata={
                    "provider": provider,
                    "model": model,
                    "cost_usd_minor_units": computed_cost,
                },
            )
            if rate is not None and computed_cost is not None:
                await log_event(
                    session,
                    action="request.cost_computed",
                    project_id=project_map[rec["project"]],
                    request_id=record_id,
                    metadata={
                        "model": model,
                        "rate_id": str(rate.id),
                        "cost_usd_minor_units": computed_cost,
                    },
                )
        else:
            duplicate += 1

    _processed_batch_ids.add(batch_id)
    log.info(
        "ingest.batch_complete",
        batch_id=str(batch_id),
        accepted=accepted,
        duplicate=duplicate,
    )
    return accepted, duplicate


async def recompute_cost(
    session: AsyncSession,
    provider: str,
    model: str,
    mode: str,
    requested_at: datetime,
    input_tokens: int,
    output_tokens: int,
    thinking_tokens: int,
    cache_read_tokens: int,
    cache_write_tokens: int = 0,
    fallback: int | None = None,
) -> tuple[int | None, PricingRate | None]:
    """Look up the active rate and compute cost for a single request.

    Returns (cost_millicents_or_fallback, matched_rate_or_None). Used by
    the proxy hot path so the record landing in SQLite is already priced
    against the canonical pricing_rates row, not just the bundled matrix.

    Routes the cost computation through the shared
    :func:`halton_meter.pricing.apply_rates` helper (via
    :func:`compute_cost_from_rate`) so the rates-table path is
    bit-identical to the bundled-matrix path for the same token set +
    rate values. The ``cache_write_tokens`` parameter — and the
    ``cache_write`` rate term inside ``apply_rates`` — closes the
    cache-write undercount in the rates-table path that P0-3 closed in
    the bundled-matrix path. See
    memory/plans/2026-04-30-daemon-audit-remediation.md (P0-4).
    """
    try:
        rate = await get_pricing_rate(session, provider, model, mode, requested_at)
    except Exception as exc:
        log.error("ingest.recompute_lookup_failed", error=str(exc), exc_info=True)
        return fallback, None
    if rate is None:
        return fallback, None
    cost = compute_cost_from_rate(
        rate,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        thinking_tokens=thinking_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_write_tokens=cache_write_tokens,
    )
    return cost, rate
