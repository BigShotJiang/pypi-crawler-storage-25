"""
Audit service — fire-and-forget event logging.

Ported from halton-meter-cloud:backend/app/services/audit.py. Same semantics:
caller owns the commit, log_event flushes within the caller's transaction,
errors are caught and swallowed.

Action enum:
  request.captured | request.cost_computed | policy.warned | policy.blocked
  policy.evaluated | rate.updated           | recon.completed
  daemon.started   | daemon.stopped
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import structlog

from halton_meter.storage.models import AuditEvent

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

log = structlog.get_logger()


async def log_event(
    db: AsyncSession,
    action: str,
    project_id: str | None = None,
    request_id: str | None = None,
    policy_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Insert one ``audit_events`` row. Never raises."""
    try:
        event = AuditEvent(
            id=str(uuid.uuid4()),
            project_id=project_id,
            request_id=request_id,
            policy_id=policy_id,
            action=action,
            metadata_=metadata or {},
            occurred_at=datetime.now(tz=UTC),
        )
        db.add(event)
        await db.flush()
        log.debug(
            "audit.logged",
            action=action,
            project_id=project_id,
        )
    except Exception as exc:  # pragma: no cover — defensive
        log.error(
            "audit.log_failed",
            action=action,
            error=str(exc),
            exc_info=True,
        )
