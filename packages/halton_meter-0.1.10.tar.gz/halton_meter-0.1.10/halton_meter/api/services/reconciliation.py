"""
Reconciliation service — variance analysis between local logs and provider billing.

In v1.0 the daemon ports the cloud's READ-side reconciliation routines
(``list_reconciliation`` / ``get_latest_reconciliation`` are direct
SQLAlchemy queries handled in the router). The active ``run_reconciliation``
that hits Anthropic's Admin API is preserved here for Phase 3, but the
matching POST route returns 501 Not Implemented in v1.0 — the daemon
process should not be making outbound provider Admin-API calls when its
own proxy is sitting on HTTPS_PROXY.
"""

from __future__ import annotations

import uuid
from datetime import UTC, date, datetime, timedelta
from typing import TYPE_CHECKING, Any

import structlog
from sqlalchemy import func, select

from halton_meter.api.services.audit import log_event
from halton_meter.storage.models import PricingRate, ReconciliationRecord, Request

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

log = structlog.get_logger()


def _compute_variance_pct(our_total: int, provider_total: int) -> float:
    if provider_total == 0:
        return 0.0
    return (our_total - provider_total) / provider_total * 100


async def _fetch_anthropic_usage(
    admin_api_key: str,
    since: date,
    until: date,
) -> list[dict[str, Any]]:  # pragma: no cover — Phase 3 path
    """Fetch usage from Anthropic Admin API. Phase 3 only."""
    import httpx  # local import keeps the daemon hot path off httpx

    params = {
        "starting_at": f"{since.isoformat()}T00:00:00Z",
        "ending_at": f"{until.isoformat()}T23:59:59Z",
        "bucket_width": "1d",
    }
    headers = {
        "x-api-key": admin_api_key,
        "anthropic-version": "2023-06-01",
    }
    async with httpx.AsyncClient(timeout=30.0, trust_env=False) as client:
        resp = await client.get(
            "https://api.anthropic.com/v1/organizations/usage_report/messages",
            params=params,
            headers=headers,
        )
    resp.raise_for_status()
    payload = resp.json()
    return payload.get("data", [])


async def _get_current_rate(
    session: AsyncSession, provider: str, model: str
) -> PricingRate | None:
    result = await session.execute(
        select(PricingRate)
        .where(
            PricingRate.provider == provider,
            PricingRate.model == model,
            PricingRate.effective_to.is_(None),
        )
        .order_by(PricingRate.effective_from.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


def _compute_provider_cost(
    rate: PricingRate,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int,
) -> int:
    return (
        input_tokens * rate.input_rate_per_million_minor_units
        + output_tokens * rate.output_rate_per_million_minor_units
        + cache_read_tokens * rate.cache_read_rate_per_million_minor_units
    ) // 1_000_000


async def run_reconciliation(  # pragma: no cover — Phase 3 path
    db: AsyncSession,
    provider: str,
    since: date,
    until: date,
    admin_api_key: str,
) -> ReconciliationRecord:
    """Phase 3: full reconciliation against Anthropic Admin API."""
    period_start_dt = datetime(since.year, since.month, since.day, tzinfo=UTC)
    period_end_dt = datetime(until.year, until.month, until.day, tzinfo=UTC) + timedelta(days=1)

    our_result = await db.execute(
        select(
            func.coalesce(func.sum(Request.cost_usd_minor_units), 0).label("total")
        ).where(
            Request.provider == provider,
            Request.requested_at >= period_start_dt,
            Request.requested_at < period_end_dt,
        )
    )
    our_total = int(our_result.scalar_one())

    usage_rows = await _fetch_anthropic_usage(admin_api_key, since, until)

    provider_total = 0
    for bucket in usage_rows:
        for row in bucket.get("results", []):
            model = row.get("model", "")
            usage = row.get("usage", {})
            input_tokens = int(usage.get("input_tokens", 0))
            output_tokens = int(usage.get("output_tokens", 0))
            cache_read_tokens = int(usage.get("cache_read_input_tokens", 0))
            rate = await _get_current_rate(db, provider, model)
            if rate is None:
                continue
            provider_total += _compute_provider_cost(
                rate, input_tokens, output_tokens, cache_read_tokens
            )

    variance = _compute_variance_pct(our_total, provider_total)
    now = datetime.now(tz=UTC)

    existing_result = await db.execute(
        select(ReconciliationRecord).where(
            ReconciliationRecord.provider == provider,
            ReconciliationRecord.period_start == period_start_dt,
            ReconciliationRecord.period_end == period_end_dt,
        )
    )
    existing = existing_result.scalar_one_or_none()

    if existing is not None:
        existing.our_logged_total_minor_units = our_total
        existing.provider_billed_total_minor_units = provider_total
        existing.variance_pct = round(variance, 4)
        existing.reconciled_at = now
        existing.reconciled_by = "api"
        record = existing
    else:
        record = ReconciliationRecord(
            id=str(uuid.uuid4()),
            provider=provider,
            period_start=period_start_dt,
            period_end=period_end_dt,
            our_logged_total_minor_units=our_total,
            provider_billed_total_minor_units=provider_total,
            variance_pct=round(variance, 4),
            reconciled_at=now,
            reconciled_by="api",
        )
        db.add(record)

    await db.flush()

    await log_event(
        db,
        action="recon.completed",
        metadata={
            "provider": provider,
            "variance_pct": round(variance, 4),
            "our_total": our_total,
            "theirs_total": provider_total,
        },
    )
    return record
