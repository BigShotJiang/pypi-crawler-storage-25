"""Service-layer helpers ported from halton-meter-cloud:backend/app/services/.

These are the cost-recomputation, stats-aggregation, audit-logging and
reconciliation routines. They operate against the daemon's SQLite store
through the shared SQLAlchemy session — no HTTP, no separate process.
"""
