"""
FastAPI HTTP API mounted inside the Halton Meter daemon process.

This package is the home of the daemon's HTTP API surface. As of Phase 2B.1
it contains only a skeleton (the app factory and a /health router); the
routers, services and schemas ported from the legacy backend land in 2B.3.
"""

from halton_meter.api.main import create_app

__all__ = ["create_app"]
