"""
Policy evaluation engine for the Halton Meter daemon.

Evaluates active policies against the current request context (project, model,
running totals) and returns a PolicyDecision indicating whether to allow, warn,
or block the request.

All evaluation is synchronous and pure — no I/O. Call from the proxy hot path
after fetching policies and totals from StorageManager.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PolicyDecision:
    """Result of evaluating a set of policies against a request."""

    action: str  # 'allow' | 'warn' | 'block'
    reason: str | None = None
    policy_id: str | None = None
    metadata: dict = field(default_factory=dict)


def evaluate_policies(
    policies: list[dict],
    project: str,
    model: str,
    running_total_millicents: int,
    requests_today: int,
) -> PolicyDecision:
    """
    Evaluate all active policies for a project against the current request.

    Returns a PolicyDecision with action 'allow', 'warn', or 'block'.
    First blocking/warning policy wins — policies are evaluated in list order.

    Args:
        policies:                 List of policy dicts from StorageManager.get_policies().
        project:                  Project slug for this request.
        model:                    Model identifier from the request (e.g. 'claude-sonnet-4-6').
        running_total_millicents: Cumulative cost in millicents for this project this month.
        requests_today:           Number of requests this project has made today.

    Returns:
        PolicyDecision with action='allow' if all policies pass.
    """
    # Track the most severe warning/block encountered
    # 'block' > 'warn' > 'allow' in severity
    worst_decision: PolicyDecision | None = None

    for policy in policies:
        decision = _evaluate_one(policy, model, running_total_millicents, requests_today)
        if decision.action == "block":
            # Blocks short-circuit immediately — first block wins
            return decision
        if decision.action == "warn" and (
            worst_decision is None or worst_decision.action == "allow"
        ):
            worst_decision = decision

    if worst_decision is not None:
        return worst_decision

    return PolicyDecision(action="allow")


def _evaluate_one(
    policy: dict,
    model: str,
    running_total_millicents: int,
    requests_today: int,
) -> PolicyDecision:
    """Evaluate a single policy. Returns a PolicyDecision."""
    policy_type = policy.get("type", "")
    config = policy.get("config", {})
    warn_only = policy.get("warn_only", True)
    policy_id = policy.get("id")

    if policy_type == "budget_monthly":
        return _eval_budget_monthly(config, warn_only, policy_id, running_total_millicents)
    if policy_type == "model_allow_list":
        return _eval_model_allow_list(config, warn_only, policy_id, model)
    if policy_type == "requests_per_day":
        return _eval_requests_per_day(config, warn_only, policy_id, requests_today)

    # Unknown policy type — allow through
    return PolicyDecision(action="allow")


def _eval_budget_monthly(
    config: dict,
    warn_only: bool,
    policy_id: str | None,
    running_total_millicents: int,
) -> PolicyDecision:
    """
    Evaluate a budget_monthly policy.

    config: { limit_usd: float }
    Limit is stored as USD; we convert to millicents (1 USD = 100_000 millicents).

    - At 80%+ of limit: warn regardless of warn_only (early warning).
    - At 100%+ of limit + warn_only: warn.
    - At 100%+ of limit + not warn_only: block.
    """
    limit_usd = float(config.get("limit_usd", 0) or 0)
    if limit_usd <= 0:
        return PolicyDecision(action="allow")

    limit_mc = int(limit_usd * 100_000)
    used_usd = running_total_millicents / 100_000
    pct = (running_total_millicents / limit_mc) * 100 if limit_mc > 0 else 0

    if running_total_millicents >= limit_mc:
        reason = (
            f"Monthly budget ${limit_usd:.2f} USD reached "
            f"({used_usd:.2f} USD used, {pct:.0f}%)"
        )
        if warn_only:
            return PolicyDecision(
                action="warn",
                reason=reason,
                policy_id=policy_id,
                metadata={
                    "pct": round(pct, 1),
                    "limit_usd": limit_usd,
                    "used_usd": round(used_usd, 4),
                },
            )
        else:
            return PolicyDecision(
                action="block",
                reason=(
                    f"Monthly budget ${limit_usd:.2f} USD exceeded "
                    f"({used_usd:.2f} USD used)"
                ),
                policy_id=policy_id,
                metadata={
                    "pct": round(pct, 1),
                    "limit_usd": limit_usd,
                    "used_usd": round(used_usd, 4),
                },
            )

    if running_total_millicents >= limit_mc * 0.8:
        # 80% warning — always warn regardless of warn_only (it's informational)
        return PolicyDecision(
            action="warn",
            reason=(
                f"Monthly budget at {pct:.0f}% "
                f"(${used_usd:.2f} of ${limit_usd:.2f} used)"
            ),
            policy_id=policy_id,
            metadata={
                "pct": round(pct, 1),
                "limit_usd": limit_usd,
                "used_usd": round(used_usd, 4),
            },
        )

    return PolicyDecision(action="allow")


def _eval_model_allow_list(
    config: dict,
    warn_only: bool,
    policy_id: str | None,
    model: str,
) -> PolicyDecision:
    """
    Evaluate a model_allow_list policy.

    config: { allowed_models: list[str] }
    """
    allowed: list[str] = config.get("allowed_models", []) or []
    if not allowed or model in allowed:
        return PolicyDecision(action="allow")

    reason = f"Model '{model}' is not in the allow-list for this project"
    if warn_only:
        return PolicyDecision(
            action="warn",
            reason=reason,
            policy_id=policy_id,
            metadata={"model": model, "allowed_models": allowed},
        )
    return PolicyDecision(
        action="block",
        reason=reason,
        policy_id=policy_id,
        metadata={"model": model, "allowed_models": allowed},
    )


def _eval_requests_per_day(
    config: dict,
    warn_only: bool,
    policy_id: str | None,
    requests_today: int,
) -> PolicyDecision:
    """
    Evaluate a requests_per_day policy.

    config: { limit: int }
    """
    limit = int(config.get("limit", 0) or 0)
    if limit <= 0 or requests_today < limit:
        return PolicyDecision(action="allow")

    reason = f"Daily request limit of {limit} reached ({requests_today} requests today)"
    if warn_only:
        return PolicyDecision(
            action="warn",
            reason=reason,
            policy_id=policy_id,
            metadata={"limit": limit, "requests_today": requests_today},
        )
    return PolicyDecision(
        action="block",
        reason=reason,
        policy_id=policy_id,
        metadata={"limit": limit, "requests_today": requests_today},
    )
