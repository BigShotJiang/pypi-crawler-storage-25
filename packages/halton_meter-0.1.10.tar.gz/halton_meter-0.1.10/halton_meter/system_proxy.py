"""Best-effort system-proxy cleanup.

When the daemon's listener dies but the macOS / Linux / Windows system
proxy is still pointed at it, every outbound HTTPS call on the user's
machine fails with ``Connection refused`` until something resets the
proxy. That breaks Claude Code, the Anthropic SDK, browsers — anything.

This module:

  * Detects on startup whether the system proxy points at *our* port.
  * If it does, registers signal + atexit handlers that reset the
    proxy on shutdown — clean exit, Ctrl-C, SIGTERM, or a Python-level
    crash that still triggers atexit.

Hard crashes (segfault, kill -9) cannot be intercepted; ``halton-meter
uninstall`` (Phase 2B.5/2B.6) will reset unconditionally as the
ultimate recovery path.

This is a hot-fix layered on top of the daemon's existing lifecycle.
The proper supervisor work happens in Phase 2B.5/2B.6.
"""

from __future__ import annotations

import atexit
import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger("halton_meter.system_proxy")


# v0.1.5 (2B.16) P1-AUDIT-4: typed admin-elevation errors so callers can
# distinguish user-cancel from inner-command failure without parsing
# string substrings of a RuntimeError. RuntimeError remains the base so
# v0.1.4-era ``except RuntimeError`` blocks continue to catch both.
class AdminElevationError(RuntimeError):
    """Base class for ``run_with_admin`` failures."""


class AdminCancelledError(AdminElevationError):
    """User cancelled the macOS admin-password dialog."""


class AdminInnerCommandError(AdminElevationError):
    """The wrapped command exited non-zero under osascript."""

    def __init__(self, message: str, *, returncode: int, stderr: str) -> None:
        super().__init__(message)
        self.returncode = returncode
        self.stderr = stderr


class AdminInfrastructureError(AdminElevationError):
    """osascript itself was missing / unrunnable."""

# macOS network services — fallback only.
#
# Originally this was the canonical list, populated from common Mac
# hardware names. That assumption broke on machines whose primary
# Ethernet service isn't literally named "Ethernet" (modern MacBooks via
# Thunderbolt / USB-C dongles enumerate under different names; some
# Macs have no Ethernet service at all). 2B.7.1 widened the elevation
# heuristic but could not rescue a `networksetup` call against a
# non-existent service (rc=4 "parameters not valid"). 2B.7.2 enumerates
# services dynamically via `networksetup -listallnetworkservices`; this
# tuple is now used ONLY when the enumeration call itself fails (e.g.
# `networksetup` is missing or returns non-zero).
_MACOS_INTERFACE_FALLBACK = ("Wi-Fi", "Ethernet", "USB 10/100/1000 LAN", "Thunderbolt Bridge")

# v0.1.7 Gap 1: refresh the macOS interface enumeration every
# ``_MACOS_INTERFACES_TTL_SECONDS`` so a Thunderbolt dock plug-in or a
# Wi-Fi switch is observed within ~1 minute. Pre-v0.1.7 the cache was
# process-lifetime, which meant a long-running daemon never picked up
# new services — its ``enable_system_proxy_if_managed`` calls would
# silently skip the new interface.
_MACOS_INTERFACES_TTL_SECONDS = 60.0

# Cached result of :func:`_macos_interfaces`. Stores a
# ``(timestamp, services)`` pair where ``timestamp`` is from
# ``time.monotonic()``; ``None`` means "not yet computed".
#
# Test seam: callers that monkeypatch this variable directly to a raw
# ``tuple[str, ...]`` (legacy shape pre-Gap 1) are still honoured —
# the getter detects the legacy shape and treats it as fresh. Tests
# that want to exercise TTL behaviour use the new shape.
_MACOS_INTERFACES_CACHE: tuple[float, tuple[str, ...]] | tuple[str, ...] | None = None


def _macos_interfaces_uncached() -> tuple[str, ...]:
    """Probe ``networksetup`` and return the parsed service list.

    Same semantics as the cached :func:`_macos_interfaces`: returns
    :data:`_MACOS_INTERFACE_FALLBACK` on any failure, an empty tuple
    on non-macOS. Factored out so :func:`_macos_interfaces` is a
    pure cache-management wrapper and tests can monkeypatch the
    probe without monkeypatching the cache state.
    """
    if sys.platform != "darwin":
        return ()

    try:
        result = subprocess.run(
            ["networksetup", "-listallnetworkservices"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        log.warning(
            "system_proxy.interface_enumeration_failed",
            error=str(exc),
            fallback=list(_MACOS_INTERFACE_FALLBACK),
        )
        return _MACOS_INTERFACE_FALLBACK

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        log.warning(
            "system_proxy.interface_enumeration_failed",
            returncode=result.returncode,
            stderr=stderr,
            fallback=list(_MACOS_INTERFACE_FALLBACK),
        )
        return _MACOS_INTERFACE_FALLBACK

    services: list[str] = []
    for raw_line in result.stdout.splitlines():
        line = raw_line.rstrip()
        if not line:
            continue
        # Header: "An asterisk (*) denotes that a network service is
        # disabled." Sometimes wraps onto a second line; both start with
        # capital words, never with "*" or a service name.
        if line.startswith("An asterisk"):
            continue
        # Disabled services are prefixed with "*" — strip it; still a
        # real service that networksetup commands accept.
        if line.startswith("*"):
            line = line[1:].lstrip()
        if line:
            services.append(line)

    if not services:
        log.warning(
            "system_proxy.interface_enumeration_failed",
            returncode=0,
            stderr="no services parsed from networksetup output",
            fallback=list(_MACOS_INTERFACE_FALLBACK),
        )
        return _MACOS_INTERFACE_FALLBACK

    return tuple(services)


def _macos_interfaces() -> tuple[str, ...]:
    """Return macOS network services dynamically via ``networksetup``.

    v0.1.7 Gap 1: result cached with a 60-second TTL via
    :data:`_MACOS_INTERFACES_TTL_SECONDS`. A long-running daemon now
    picks up newly-attached interfaces (Thunderbolt dock plug-in, Wi-Fi
    switch, etc.) within 60 seconds without us having to subscribe to
    SCDynamicStore notifications (deferred to v0.1.8 with PyObjC).

    On any failure (binary missing, non-zero rc, subprocess error, non-
    macOS platform) returns :data:`_MACOS_INTERFACE_FALLBACK` and logs
    ``system_proxy.interface_enumeration_failed`` at warning level so
    the failure is observable in ``~/.halton-meter/daemon.err.log``.

    Linux / Windows return an empty tuple — ``networksetup`` does not
    exist outside macOS and the rest of this module is macOS-gated
    anyway.
    """
    global _MACOS_INTERFACES_CACHE
    cache = _MACOS_INTERFACES_CACHE
    if cache is not None:
        # Legacy/test seed: a raw tuple-of-strings is treated as fresh
        # forever. This preserves the pre-Gap-1 monkeypatch ergonomics
        # where dozens of tests do
        #   monkeypatch.setattr(system_proxy,
        #                       "_MACOS_INTERFACES_CACHE",
        #                       _MACOS_INTERFACE_FALLBACK)
        # and expect the value to come back unchanged. Tests that want
        # to exercise the TTL use the (timestamp, services) shape.
        if not cache or isinstance(cache[0], str):
            return cache  # type: ignore[return-value]
        timestamp, value = cache  # type: ignore[misc]
        if (time.monotonic() - timestamp) < _MACOS_INTERFACES_TTL_SECONDS:
            return value
        # else: stale, fall through to re-probe.

    services = _macos_interfaces_uncached()
    _MACOS_INTERFACES_CACHE = (time.monotonic(), services)
    return services

# Sentinel file written by ``halton-meter setup`` once the user has
# completed managed-mode setup (cert trust + certifi patch). Its presence
# is the daemon's signal that it may re-enable the macOS system proxy on
# startup so that traffic is metered again after a launchd-driven revive.
# Absence means the user has not opted in; the daemon must NOT touch the
# system proxy. See decisions.md 2026-04-29 — "Layer 2 watchdog: Option-1
# daemon-side proxy enable on startup".
_PROXY_MANAGED_SENTINEL = Path("~/.halton-meter/proxy-managed").expanduser()


def _read_macos_proxy(interface: str, secure: bool) -> tuple[bool, str | None, str | None]:
    """Returns (enabled, host, port). ``secure`` selects HTTPS vs HTTP proxy."""
    flag = "-getsecurewebproxy" if secure else "-getwebproxy"
    try:
        result = subprocess.run(
            ["networksetup", flag, interface],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return (False, None, None)
    if result.returncode != 0:
        return (False, None, None)
    enabled = False
    host: str | None = None
    port: str | None = None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if line.startswith("Enabled:"):
            enabled = "Yes" in line
        elif line.startswith("Server:"):
            host = line.split(":", 1)[1].strip() or None
        elif line.startswith("Port:"):
            port = line.split(":", 1)[1].strip() or None
    return (enabled, host, port)


def _disable_macos_proxy(interface: str) -> None:
    for flag in ("-setsecurewebproxystate", "-setwebproxystate"):
        try:
            subprocess.run(
                ["networksetup", flag, interface, "off"],
                capture_output=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            pass


# --------------------------------------------------------------------------- #
# Snapshot / restore (2B.11)                                                   #
# --------------------------------------------------------------------------- #
#
# Capture the user's pre-install macOS system-proxy state so ``halton-meter
# uninstall`` can restore it instead of leaving the proxy disabled. The
# canonical state file is ``~/.halton-meter/system_state.json``; written
# atomically (``O_CREAT|O_TRUNC|O_WRONLY``, mode 0600, fsync, ``os.replace``).
# A second snapshot is skipped if the file already exists — the first capture
# is the load-bearing one (the system proxy may already point at us by the
# time a second ``init`` runs). Linux/Windows: silent no-op; ``networksetup``
# does not exist there. Restore is self-guarded: if the captured ``host:port``
# matches our daemon's listener we DISABLE the service rather than restoring,
# so we never re-point the user at a dead proxy. After a successful restore
# the state file is deleted.

_SYSTEM_STATE_PATH = Path("~/.halton-meter/system_state.json").expanduser()


def system_state_path() -> Path:
    """Return the snapshot file path (test hook)."""
    return _SYSTEM_STATE_PATH


def _read_bypass_domains(interface: str) -> list[str]:
    """Return the list of bypass-domain strings for ``interface``.

    Parses ``networksetup -getproxybypassdomains <iface>`` output. The
    command emits one domain per line; the literal output ``"There aren't
    any bypass domains set on <iface>."`` (note the wording varies across
    macOS versions) is normalised to an empty list. Any subprocess failure
    returns an empty list — bypass domains are best-effort metadata, not
    a load-bearing field.
    """
    try:
        result = subprocess.run(
            ["networksetup", "-getproxybypassdomains", interface],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if result.returncode != 0:
        return []
    domains: list[str] = []
    for raw in result.stdout.splitlines():
        line = raw.strip()
        if not line:
            continue
        # macOS emits a sentence rather than nothing when no domains set.
        # Match defensively across phrasings ("aren't any", "no bypass").
        lowered = line.lower()
        if "aren't any" in lowered or "no bypass" in lowered:
            continue
        domains.append(line)
    return domains


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    """Atomically write ``payload`` as JSON to ``path``.

    Order: open with ``O_CREAT|O_TRUNC|O_WRONLY`` and mode 0600 to a
    sibling ``<path>.tmp`` file, write JSON bytes, ``fsync``, ``close``,
    then ``os.replace`` over ``path``. Crash-safe: a partial write never
    appears at the canonical path.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    data = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
    fd = os.open(str(tmp), os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(str(tmp), str(path))


def snapshot_system_proxy() -> None:
    """Capture per-service macOS system-proxy state to ``system_state.json``.

    Called from ``_enable_system_proxy_for_init`` BEFORE any
    ``-setsecurewebproxy`` / ``-setwebproxy`` mutation. Captures, per
    network service:

    * ``web_proxy_enabled`` — bool from ``-getwebproxy``
    * ``secure_web_proxy_enabled`` — bool from ``-getsecurewebproxy``
    * ``host``, ``port`` — strings from the secure variant (the HTTPS one
      is what we point at the daemon; this is what we need to restore)
    * ``bypass_domains`` — list[str] from ``-getproxybypassdomains``

    Skipped (silent) if the file already exists — the first capture wins.
    Skipped (silent) on non-macOS platforms. Failures during enumeration
    or per-service reads are logged at warning level but never raised:
    the snapshot is best-effort, and a missing snapshot at uninstall just
    means uninstall falls back to disable-only (no regression vs. pre-2B.11
    behaviour).
    """
    if sys.platform != "darwin":
        return
    if not shutil.which("networksetup"):
        return
    if _SYSTEM_STATE_PATH.exists():
        log.info(
            "system_proxy.snapshot_skipped_already_exists",
            path=str(_SYSTEM_STATE_PATH),
        )
        return

    services: dict[str, dict[str, Any]] = {}
    for iface in _macos_interfaces():
        try:
            web_enabled, _w_host, _w_port = _read_macos_proxy(iface, secure=False)
            sec_enabled, host, port = _read_macos_proxy(iface, secure=True)
            bypass = _read_bypass_domains(iface)
        except Exception as exc:
            log.warning(
                "system_proxy.snapshot_iface_failed",
                iface=iface,
                error=str(exc),
            )
            continue
        # 2B.11.1: discard host/port when the secure variant is disabled.
        # ``networksetup -setsecurewebproxystate <iface> off`` does NOT
        # clear the stored host/port — it only flips the enabled bit. So
        # ``_read_macos_proxy`` returns stale leftovers (often pointing at
        # our own daemon from a prior session) for services that are off.
        # Treat "disabled" as "no prior config" so a future restore doesn't
        # re-point the user at a stale target. Without this gate, a corp
        # user whose pre-existing proxy was already disabled would have us
        # overwriting their stored host:port with our daemon's address —
        # losing the original config on uninstall via the self-guard path.
        captured_host = host if sec_enabled else ""
        captured_port = port if sec_enabled else ""
        services[iface] = {
            "web_proxy_enabled": bool(web_enabled),
            "secure_web_proxy_enabled": bool(sec_enabled),
            "host": captured_host,
            "port": captured_port,
            "bypass_domains": bypass,
        }

    payload: dict[str, Any] = {
        "version": 1,
        "platform": "darwin",
        "services": services,
    }
    try:
        _atomic_write_json(_SYSTEM_STATE_PATH, payload)
    except OSError as exc:
        log.warning(
            "system_proxy.snapshot_write_failed",
            path=str(_SYSTEM_STATE_PATH),
            error=str(exc),
        )
        return
    log.info(
        "system_proxy.snapshot_written",
        path=str(_SYSTEM_STATE_PATH),
        services=list(services.keys()),
    )


def _set_bypass_domains(interface: str, domains: list[str]) -> None:
    """Set the bypass-domain list for ``interface`` via ``networksetup``.

    ``networksetup -setproxybypassdomains <iface> <d1> <d2> ...`` replaces
    the entire list. Passing the special token ``"Empty"`` clears it.
    Failures are swallowed — bypass is metadata, not load-bearing.
    """
    argv = ["networksetup", "-setproxybypassdomains", interface]
    argv.extend(domains if domains else ["Empty"])
    try:
        subprocess.run(argv, capture_output=True, timeout=5, check=False)
    except (OSError, subprocess.SubprocessError):
        pass


def _set_macos_proxy_address(
    interface: str, host: str, port: str, *, secure: bool
) -> None:
    flag = "-setsecurewebproxy" if secure else "-setwebproxy"
    try:
        subprocess.run(
            ["networksetup", flag, interface, host, port],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        pass


def _set_macos_proxy_state(interface: str, *, secure: bool, on: bool) -> None:
    flag = "-setsecurewebproxystate" if secure else "-setwebproxystate"
    try:
        subprocess.run(
            ["networksetup", flag, interface, "on" if on else "off"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        pass


def restore_system_proxy(our_host: str, our_port: int) -> bool:
    """Restore (or self-guard-disable) the macOS system proxy from snapshot.

    Returns ``True`` if a snapshot was loaded and processed (regardless of
    whether each service was restored or disabled), ``False`` if no
    snapshot existed. Non-macOS: silent no-op, returns ``False``.

    Self-guard: if the captured ``host:port`` for a service matches our
    daemon's listener (``our_host:our_port``), DISABLE that service
    instead of restoring. This prevents a stale snapshot from re-pointing
    the user at a dead proxy if uninstall ran while the daemon's listener
    was still recorded as the previous state.

    Deletes ``system_state.json`` after a successful pass.
    """
    if sys.platform != "darwin":
        return False
    if not _SYSTEM_STATE_PATH.exists():
        return False
    if not shutil.which("networksetup"):
        # No way to apply state. Leave the file in place so a future
        # uninstall on a system with networksetup can complete the restore.
        return False

    try:
        raw = _SYSTEM_STATE_PATH.read_text(encoding="utf-8")
        payload = json.loads(raw)
    except (OSError, ValueError) as exc:
        log.warning(
            "system_proxy.restore_read_failed",
            path=str(_SYSTEM_STATE_PATH),
            error=str(exc),
        )
        return False

    services = payload.get("services") or {}
    if not isinstance(services, dict):
        log.warning(
            "system_proxy.restore_payload_malformed",
            path=str(_SYSTEM_STATE_PATH),
        )
        return False

    for iface, captured in services.items():
        if not isinstance(captured, dict):
            log.warning(
                "system_proxy.restore_skipped_malformed_entry",
                iface=iface,
            )
            continue
        host = captured.get("host")
        port = captured.get("port")
        web_on = bool(captured.get("web_proxy_enabled"))
        sec_on = bool(captured.get("secure_web_proxy_enabled"))
        bypass = captured.get("bypass_domains") or []
        if not isinstance(bypass, list):
            bypass = []

        # Self-guard: captured host:port == our daemon listener?
        targets_us = _proxy_targets_us(
            host if isinstance(host, str) else None,
            str(port) if port is not None else None,
            our_host,
            our_port,
        )
        if targets_us:
            log.info(
                "system_proxy.restore_self_guard_disabled",
                iface=iface,
                captured_host=host,
                captured_port=port,
                reason="captured_target_matches_our_daemon",
            )
            _disable_macos_proxy(iface)
            continue

        # Apply the captured address (best-effort) before toggling state.
        if isinstance(host, str) and host and (port is not None):
            port_str = str(port)
            _set_macos_proxy_address(iface, host, port_str, secure=True)
            _set_macos_proxy_address(iface, host, port_str, secure=False)
        # Apply bypass domains.
        _set_bypass_domains(iface, [d for d in bypass if isinstance(d, str)])
        # Toggle state to match the snapshot.
        _set_macos_proxy_state(iface, secure=True, on=sec_on)
        _set_macos_proxy_state(iface, secure=False, on=web_on)
        log.info(
            "system_proxy.restore_applied",
            iface=iface,
            host=host,
            port=port,
            secure_on=sec_on,
            web_on=web_on,
            bypass_count=len(bypass),
        )

    # Delete the snapshot after the pass — restore is one-shot.
    try:
        _SYSTEM_STATE_PATH.unlink()
        log.info("system_proxy.restore_state_file_removed", path=str(_SYSTEM_STATE_PATH))
    except FileNotFoundError:
        pass
    except OSError as exc:
        log.warning(
            "system_proxy.restore_state_file_remove_failed",
            path=str(_SYSTEM_STATE_PATH),
            error=str(exc),
        )
    return True


def read_proxy_target(
    interface: str, *, secure: bool = True
) -> tuple[bool, str | None, int | None]:
    """Public wrapper around :func:`_read_macos_proxy` returning a typed port.

    The watchdog (and any future caller) needs to inspect which interface
    currently has the system proxy pointed at us. The leading-underscore
    helper has long been used here too — promoting a public alias keeps
    callers out of the private namespace. Returns ``(enabled, host,
    port_as_int_or_None)``; non-macOS callers always get a no-op tuple.
    """
    if sys.platform != "darwin":
        return (False, None, None)
    enabled, host, port_str = _read_macos_proxy(interface, secure)
    port: int | None
    try:
        port = int(port_str) if port_str else None
    except (TypeError, ValueError):
        port = None
    return (enabled, host, port)


def proxy_managed_sentinel_path() -> Path:
    """Return the path of the managed-proxy sentinel file (test hook)."""
    return _PROXY_MANAGED_SENTINEL


def enable_system_proxy_if_managed(
    host: str, port: int, *, eager: bool = False
) -> None:
    """Re-enable the macOS system proxy pointing at ``host:port``.

    Gated on the existence of ``~/.halton-meter/proxy-managed``. If the
    sentinel is absent the user has not opted in to managed proxying and
    we must not touch their system proxy. Idempotent: ``networksetup``
    is happy to be told the proxy is "on" when it already is.

    Silent no-op on non-macOS or when ``networksetup`` is unavailable.

    Modes
    -----
    Two operating modes:

    * ``eager=False`` (default — daemon-startup contract): swallow
      per-interface failures and emit structured warning logs. Returns
      ``None`` regardless. The daemon must never crash because the
      system proxy can't be reconfigured.
    * ``eager=True`` (``halton-meter init`` contract): on the FIRST
      address-set or state-toggle that returns a non-zero exit code (or
      raises), abort and raise :class:`RuntimeError` with the iface,
      failing argv, and stderr embedded. Subsequent interfaces are not
      attempted — the caller (``init``) renders the failure to the user
      and exits non-zero. When the address is already correct (skipping
      the admin-requiring address-set), only the state-toggle can fail,
      and that path doesn't require admin so it should not raise on a
      well-configured machine.

    Best-effort under launchd (``eager=False``)
    -------------------------------------------
    On macOS Sonoma+, ``networksetup -setsecurewebproxy <iface> <host>
    <port>`` (setting the address) requires admin rights. Toggling state
    via ``-setsecurewebproxystate <iface> on`` does NOT require admin if
    the address already matches. When the daemon runs under launchd
    (i.e. without sudo), the address-set call may fail silently. We
    therefore: (1) read the current address first; (2) skip the
    address-set call entirely when the address already matches us; (3)
    log structured warnings on any failure so the user can diagnose via
    ``~/.halton-meter/daemon.err.log``.
    """
    if sys.platform != "darwin":
        return
    if not shutil.which("networksetup"):
        return
    if not _PROXY_MANAGED_SENTINEL.exists():
        return

    port_str = str(port)
    for iface in _macos_interfaces():
        for _secure, set_target, set_state in (
            (True, "-setsecurewebproxy", "-setsecurewebproxystate"),
            (False, "-setwebproxy", "-setwebproxystate"),
        ):
            # Skip the address-set call when the proxy already points at us.
            # That is the no-admin path: state-toggle alone does not require
            # admin rights.
            _enabled, current_host, current_port = _read_macos_proxy(
                iface, secure=_secure
            )
            already_correct = _proxy_targets_us(current_host, current_port, host, port)

            if not already_correct:
                # Need to actually set the address. Try once; on failure
                # log and skip the state-toggle for this (iface, variant)
                # — no point toggling state on the wrong address.
                set_argv = ["networksetup", set_target, iface, host, port_str]
                try:
                    result = subprocess.run(
                        set_argv,
                        capture_output=True,
                        timeout=5,
                        check=False,
                    )
                except (OSError, subprocess.SubprocessError) as exc:
                    if eager:
                        raise RuntimeError(
                            f"system_proxy.set_address failed on iface={iface!r}: "
                            f"argv={set_argv!r}: {exc}"
                        ) from exc
                    log.warning(
                        "system_proxy.set_address_failed",
                        iface=iface,
                        variant=set_target,
                        error=str(exc),
                        hint="admin rights may be required; halton-meter init in 2B.7 handles this",
                    )
                    continue
                if result.returncode != 0:
                    stderr_text = (
                        result.stderr.decode("utf-8", errors="replace")
                        if isinstance(result.stderr, (bytes, bytearray))
                        else (result.stderr or "")
                    ).strip()
                    if eager:
                        raise RuntimeError(
                            f"system_proxy.set_address failed on iface={iface!r}: "
                            f"argv={set_argv!r} rc={result.returncode} stderr={stderr_text!r}"
                        )
                    log.warning(
                        "system_proxy.set_address_failed",
                        iface=iface,
                        variant=set_target,
                        returncode=result.returncode,
                        stderr=stderr_text,
                        hint="admin rights may be required; halton-meter init in 2B.7 handles this",
                    )
                    continue

            # Address either already matched or was set successfully.
            # Toggle state on. Capture failures the same way.
            state_argv = ["networksetup", set_state, iface, "on"]
            try:
                state_result = subprocess.run(
                    state_argv,
                    capture_output=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                if eager:
                    raise RuntimeError(
                        f"system_proxy.set_state failed on iface={iface!r}: "
                        f"argv={state_argv!r}: {exc}"
                    ) from exc
                log.warning(
                    "system_proxy.set_state_failed",
                    iface=iface,
                    variant=set_state,
                    error=str(exc),
                )
                continue
            if state_result.returncode != 0:
                state_stderr = (
                    state_result.stderr.decode("utf-8", errors="replace")
                    if isinstance(state_result.stderr, (bytes, bytearray))
                    else (state_result.stderr or "")
                ).strip()
                if eager:
                    raise RuntimeError(
                        f"system_proxy.set_state failed on iface={iface!r}: "
                        f"argv={state_argv!r} rc={state_result.returncode} stderr={state_stderr!r}"
                    )
                log.warning(
                    "system_proxy.set_state_failed",
                    iface=iface,
                    variant=set_state,
                    returncode=state_result.returncode,
                    stderr=state_stderr,
                )


def run_with_admin(
    argv: list[str], *, prompt_reason: str
) -> subprocess.CompletedProcess[str]:
    """Run ``argv`` with administrator privileges via osascript (macOS GUI).

    Pops the standard macOS "halton-meter wants to make changes" dialog;
    the user enters their password into the system dialog rather than
    the terminal. Works under any Click invocation (no terminal-sudo
    gymnastics required).

    Returns the :class:`subprocess.CompletedProcess` (text mode) so the
    caller can inspect ``returncode``, ``stdout``, ``stderr``.

    v0.1.5 (2B.16) P1-AUDIT-4: failure modes are now distinguished by
    exception type:

    * :class:`AdminCancelledError` — user cancelled the password
      dialog (osascript exits 1 with ``User canceled`` in stderr).
    * :class:`AdminInnerCommandError` — wrapped command exited
      non-zero; ``returncode`` and ``stderr`` attributes carry the
      inner failure detail.
    * :class:`AdminInfrastructureError` — osascript itself missing
      or unrunnable.

    All three subclass :class:`AdminElevationError` which subclasses
    :class:`RuntimeError`, so v0.1.4-era ``except RuntimeError``
    blocks continue to catch the union.

    Raises :class:`NotImplementedError` on non-macOS platforms.
    """
    if sys.platform != "darwin":
        raise NotImplementedError(
            "run_with_admin uses osascript and is macOS-only; "
            f"current platform is {sys.platform!r}"
        )

    inner_cmd = " ".join(shlex.quote(part) for part in argv)
    # AppleScript itself uses double-quoted strings; backslash-escape the
    # double quotes that are part of inner_cmd's shlex output. shlex on
    # POSIX prefers single-quoting so this is rarely hit, but stay safe.
    inner_cmd_for_applescript = inner_cmd.replace("\\", "\\\\").replace('"', '\\"')
    prompt_for_applescript = prompt_reason.replace("\\", "\\\\").replace('"', '\\"')
    script = (
        f'do shell script "{inner_cmd_for_applescript}" '
        f'with prompt "{prompt_for_applescript}" '
        f"with administrator privileges"
    )

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise AdminInfrastructureError(
            "osascript not found; macOS-only helper"
        ) from exc
    except (OSError, subprocess.SubprocessError) as exc:
        raise AdminInfrastructureError(
            f"osascript invocation failed: {exc}"
        ) from exc

    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        if "User canceled" in stderr or "User cancelled" in stderr:
            raise AdminCancelledError(
                "admin password dialog cancelled by user"
            )
        raise AdminInnerCommandError(
            f"osascript failed: {stderr or '(no stderr)'}",
            returncode=result.returncode,
            stderr=stderr,
        )

    return result


def _proxy_targets_us(host: str | None, port: str | None, our_host: str, our_port: int) -> bool:
    if not host or not port:
        return False
    # ``our_host`` may be 0.0.0.0 / 127.0.0.1 / localhost; the system proxy
    # field will be the literal string the user set, which is almost always
    # 127.0.0.1 or localhost. Match either.
    host_match = host in {our_host, "127.0.0.1", "localhost", "0.0.0.0"}
    try:
        port_match = int(port) == int(our_port)
    except (TypeError, ValueError):
        port_match = False
    return host_match and port_match


# --------------------------------------------------------------------------- #
# launchctl setenv / unsetenv (v0.1.3 P0-3)                                    #
# --------------------------------------------------------------------------- #

# Environment variable keys we manage in --gui mode. The values are computed
# by the caller (init.py) from the resolved daemon ports + certifi bundle
# path so the daemon's choice of port is honoured (P0-5 auto-fallback).
GUI_LAUNCHCTL_ENV_KEYS: tuple[str, ...] = (
    "HTTPS_PROXY",
    "HTTP_PROXY",
    "NO_PROXY",
    "NODE_EXTRA_CA_CERTS",
    "SSL_CERT_FILE",
    "REQUESTS_CA_BUNDLE",
    # v0.1.5.1: per-tool CA bundles for clients that don't read SSL_CERT_FILE.
    "GIT_SSL_CAINFO",
    "CURL_CA_BUNDLE",
    "AWS_CA_BUNDLE",
)


def setenv_user_domain(env_vars: dict[str, str]) -> dict[str, int]:
    """Write the given env vars into launchd's user domain via ``launchctl
    setenv``. Each var becomes visible to GUI apps spawned via Spotlight,
    Dock, Finder, etc.

    Idempotent at the launchctl level — `launchctl setenv KEY VALUE` is happy
    to overwrite. macOS-only; silent no-op on other platforms or when
    `launchctl` is missing. Returns a dict mapping each key to its rc (0
    on success). On non-macOS, returns an empty dict.
    """
    if sys.platform != "darwin":
        return {}
    if not shutil.which("launchctl"):
        log.warning("system_proxy.setenv.launchctl_missing")
        return {}
    rcs: dict[str, int] = {}
    for key, value in env_vars.items():
        try:
            result = subprocess.run(
                ["launchctl", "setenv", key, value],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            rcs[key] = result.returncode
            if result.returncode != 0:
                log.warning(
                    "system_proxy.setenv.failed",
                    key=key,
                    rc=result.returncode,
                    stderr=result.stderr.strip(),
                )
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("system_proxy.setenv.error", key=key, error=str(exc))
            rcs[key] = -1
    return rcs


def unsetenv_user_domain(keys: list[str] | tuple[str, ...]) -> dict[str, int]:
    """Remove the given env keys from launchd's user domain via ``launchctl
    unsetenv``. Idempotent — unsetting a key that isn't set is a no-op
    (rc=0). macOS-only.
    """
    if sys.platform != "darwin":
        return {}
    if not shutil.which("launchctl"):
        return {}
    rcs: dict[str, int] = {}
    for key in keys:
        try:
            result = subprocess.run(
                ["launchctl", "unsetenv", key],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            rcs[key] = result.returncode
        except (OSError, subprocess.SubprocessError) as exc:
            log.warning("system_proxy.unsetenv.error", key=key, error=str(exc))
            rcs[key] = -1
    return rcs


def getenv_user_domain(key: str) -> str | None:
    """Read a launchd user-domain env var via ``launchctl getenv KEY``.

    Returns the value (stripped) or ``None`` if unset / unavailable.
    Used by ``halton-meter doctor`` to verify --gui mode wiring.
    """
    if sys.platform != "darwin":
        return None
    if not shutil.which("launchctl"):
        return None
    try:
        result = subprocess.run(
            ["launchctl", "getenv", key],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    val = (result.stdout or "").strip()
    return val if val else None


def reset_proxy_minimal() -> int:
    """Sentinel-blind, config-independent best-effort system-proxy reset.

    Layer-4 (Q1) escape hatch invoked from the new ``halton-meter
    reset-proxy`` CLI command and from the launchd / systemd shutdown
    hooks (``ExitTimeOut`` grace period, ``ExecStop=`` line). Designed to
    succeed even when ``~/.halton-meter/config.toml`` is missing or
    corrupt: it does NOT call :func:`load_config`, does NOT touch the
    ``proxy-managed`` sentinel, and does NOT unload any plists / units.
    Its single job is to make sure the macOS system proxy is OFF on the
    common interfaces, both secure (HTTPS) and unsecure (HTTP).

    Idempotent: ``networksetup -setsecurewebproxystate <iface> off`` is
    happy to be told the proxy is off when it already is. Safe to run
    twice in a row, safe to run when no daemon was ever installed.

    Platforms:

    * macOS — runs the ``networksetup`` loop over
      services returned by :func:`_macos_interfaces` x ``(secure,
      unsecure)``. Per-interface
      failures are swallowed (not every machine has Ethernet etc.).
    * Linux — `HTTPS_PROXY` / `HTTP_PROXY` are shell-side env vars; the
      daemon cannot unset them in the user's shell. Prints the
      reminder one-liner and returns 0.
    * Windows — stub; prints "not yet supported" and returns 0.

    Returns the intended process exit code (always 0 — best-effort by
    design).
    """
    if sys.platform == "darwin":
        if not shutil.which("networksetup"):
            print(
                "[halton-meter] reset-proxy: networksetup not found; nothing to do.",
                file=sys.stderr,
                flush=True,
            )
            return 0
        ifaces = _macos_interfaces()
        for iface in ifaces:
            _disable_macos_proxy(iface)
        print(
            "[halton-meter] reset-proxy: system proxy disabled on "
            f"{', '.join(ifaces)} (secure + unsecure).",
            file=sys.stderr,
            flush=True,
        )
        return 0

    if sys.platform.startswith("linux"):
        print(
            "[halton-meter] reset-proxy: on Linux, HTTPS_PROXY / HTTP_PROXY are\n"
            "[halton-meter]   shell-side env vars. Run in your shell:\n"
            "[halton-meter]     unset HTTPS_PROXY HTTP_PROXY",
            file=sys.stderr,
            flush=True,
        )
        return 0

    print(
        f"[halton-meter] reset-proxy: not yet supported on {sys.platform!r}; no-op.",
        file=sys.stderr,
        flush=True,
    )
    return 0


def install_proxy_cleanup(our_host: str, our_port: int) -> Callable[[], None] | None:
    """Install signal + atexit handlers to reset the system proxy on shutdown.

    Only takes effect if, *at install time*, the system proxy points at
    ``our_host:our_port``. Returns the cleanup callable so callers can also
    invoke it explicitly (e.g. inside an asyncio shutdown finally block),
    or ``None`` if no cleanup was installed.
    """
    if sys.platform != "darwin":
        # Linux + Windows handlers live in 2B.5/2B.6. Skip silently.
        return None
    if not shutil.which("networksetup"):
        return None

    interfaces_to_reset: list[str] = []
    for iface in _macos_interfaces():
        for secure in (True, False):
            enabled, host, port = _read_macos_proxy(iface, secure)
            if enabled and _proxy_targets_us(host, port, our_host, our_port):
                if iface not in interfaces_to_reset:
                    interfaces_to_reset.append(iface)

    if not interfaces_to_reset:
        return None

    print(
        f"[halton-meter] System proxy detected on {', '.join(interfaces_to_reset)} → "
        f"will reset on shutdown so your traffic doesn't break.",
        file=sys.stderr,
        flush=True,
    )

    already_ran = False

    def _cleanup(*_args: object) -> None:
        nonlocal already_ran
        if already_ran:
            return
        already_ran = True
        for iface in interfaces_to_reset:
            _disable_macos_proxy(iface)
        print(
            "[halton-meter] System proxy reset on exit.",
            file=sys.stderr,
            flush=True,
        )

    atexit.register(_cleanup)

    # Chain into existing handlers (e.g. mitmproxy's) rather than replacing them.
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            # Note: we deliberately do NOT chain into the previous
            # handler (typically uvicorn's capture_signals re-raise).
            # See the comment inside ``_chained`` for the failure mode.
            signal.getsignal(sig)  # touched only to surface ValueError

            def _chained(signum: int, frame: object) -> None:
                # 2B.10.4: ALWAYS exit 0 after cleanup runs successfully.
                # The launchd plist uses ``KeepAlive={SuccessfulExit:
                # False}``, so a non-zero exit (e.g. the conventional
                # 128+SIGTERM=143) would trigger a respawn-loop where the
                # new daemon re-enables the system proxy that ``_cleanup``
                # just disabled. We deliberately do NOT chain into the
                # previous handler (typically uvicorn's capture_signals
                # re-raise): re-entering it produces the SystemExit:143
                # observed in daemon.err.log. ``_cleanup`` already did the
                # proxy reset; uvicorn's drain happens via the ``finally``
                # in ``_run_daemon`` regardless of how we leave here.
                del signum, frame
                _cleanup()
                sys.exit(0)

            signal.signal(sig, _chained)
        except (OSError, ValueError):
            # Some environments forbid signal installation (e.g. non-main
            # threads, certain CI runners). Atexit covers most cases.
            pass

    return _cleanup
