"""``halton-meter doctor`` — single-command install diagnostic (v0.1.3 P0-7).

Prints every signal that matters for "is metering working" with concrete
next-action guidance per row, plus a top-line BROKEN / INCONSISTENT /
HEALTHY verdict that's mode-aware (env-var-only vs --gui).

Designed to be copy-pasteable into a support ticket. The optional
``--curl`` probe targets ``https://example.com`` ONLY — never a provider
domain. Regression-tested.

``--json`` emits a structured report for scripted consumption.
"""

from __future__ import annotations

import json as _json
import os
import platform as _platform
import shutil
import subprocess
import sys as _sys
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import click
from rich.console import Console
from rich.table import Table

from halton_meter import __version__

# Verdict constants. Order matters for severity comparisons.
VERDICT_HEALTHY = "HEALTHY"
VERDICT_INCONSISTENT = "INCONSISTENT"
VERDICT_BROKEN = "BROKEN"

# --curl probe target. Must NEVER be a provider domain. Tested by
# ``test_doctor_curl_target_is_safe``.
_CURL_PROBE_URL = "https://example.com"
# Substrings that must NEVER appear in _CURL_PROBE_URL.
_FORBIDDEN_HOST_FRAGMENTS = (
    "anthropic",
    "openai",
    "googleapis",
    "gemini",
    "groq",
    "x.ai",
    "cohere",
    "mistral",
    "deepseek",
)


@dataclass
class DoctorRow:
    """One row in the doctor report."""

    name: str
    icon: str  # "ok" / "warn" / "fail" — UI translates to glyph + colour
    summary: str
    next_action: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass
class DoctorReport:
    verdict: str  # HEALTHY / INCONSISTENT / BROKEN
    summary_message: str
    rows: list[DoctorRow]
    mode: str | None  # env-only / apps / full / unknown (legacy "gui" reads as "full")
    platform: str
    version: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "summary_message": self.summary_message,
            "mode": self.mode,
            "platform": self.platform,
            "version": self.version,
            "rows": [
                {
                    "name": r.name,
                    "icon": r.icon,
                    "summary": r.summary,
                    "next_action": r.next_action,
                    "raw": r.raw,
                }
                for r in self.rows
            ],
        }


# --------------------------------------------------------------------------- #
# v0.1.7 Gap 3 helper: inside-metered-session detection                        #
# --------------------------------------------------------------------------- #
#
# ``halton-meter doctor --fix --apply`` may briefly interrupt the user's
# in-flight HTTPS_PROXY pointing at our edge — fine when run from a
# fresh terminal, but a footgun when run from inside Claude Code (which
# is itself proxied through us). Detect that situation up-front so we
# can warn before the disruption.
#
# Race note: while ``runtime.toml`` is being atomically rewritten the
# read may briefly return ``{}``. We err on "no warning" — false
# negatives are acceptable here; false positives would block legitimate
# repair.

def is_running_inside_metered_session(
    *,
    runtime_path: Path | None = None,
    env: Mapping[str, str] | None = None,
) -> bool:
    """True iff ``HTTPS_PROXY`` (or ``https_proxy``) points at our
    edge port per ``runtime.toml``.

    Numeric port comparison via :func:`urllib.parse.urlparse.port` —
    NEVER substring matching against a hardcoded port. The user may
    have pinned their edge to a non-default port; the only ground
    truth is ``runtime.toml.edge_port``.
    """
    from halton_meter.port_alloc import RUNTIME_TOML_PATH, _read_runtime_toml

    actual_env = env if env is not None else os.environ
    proxy = actual_env.get("HTTPS_PROXY") or actual_env.get("https_proxy")
    if not proxy:
        return False
    try:
        parsed_port = urlparse(proxy).port
    except ValueError:
        return False
    if parsed_port is None:
        return False
    ports = _read_runtime_toml(runtime_path or RUNTIME_TOML_PATH)
    edge = ports.get("edge_port")
    return edge is not None and parsed_port == edge


def _icon_glyph(icon: str) -> str:
    return {"ok": "[green]✓[/green]", "warn": "[yellow]⚠[/yellow]", "fail": "[red]✗[/red]"}.get(
        icon, "·"
    )


def _icon_plain(icon: str) -> str:
    return {"ok": "OK", "warn": "WARN", "fail": "FAIL"}.get(icon, "??")


def _read_install_mode() -> str | None:
    """Best-effort read of the install-mode sentinel."""
    from halton_meter import init as init_module

    return init_module.read_install_mode()


def _build_rows(*, run_curl: bool) -> tuple[list[DoctorRow], str | None, str]:
    """Build the diagnostic rows. Returns ``(rows, mode, platform)``."""
    rows: list[DoctorRow] = []
    plat = _sys.platform

    # --- Platform info -----------------------------------------------------
    rows.append(
        DoctorRow(
            "Platform",
            "ok",
            f"{_platform.system()} {_platform.machine()} python={_platform.python_version()}",
            raw={
                "system": _platform.system(),
                "machine": _platform.machine(),
                "python": _platform.python_version(),
            },
        )
    )

    # --- Mode --------------------------------------------------------------
    mode = _read_install_mode()
    rows.append(
        DoctorRow(
            "Install mode",
            "ok" if mode is not None else "warn",
            mode if mode is not None else "unknown (older install / sentinel missing)",
            next_action=(
                "run `halton-meter init` to (re)write the install-mode sentinel"
                if mode is None
                else None
            ),
            raw={"mode": mode},
        )
    )

    # --- Effective config (ports) ------------------------------------------
    try:
        from halton_meter.port_alloc import load_effective_config

        cfg = load_effective_config()
        listen_host = cfg.daemon.listen_host
        listen_port = cfg.daemon.edge_port
        api_host = cfg.daemon.api_host
        api_port = cfg.daemon.api_port
    except Exception as exc:
        rows.append(
            DoctorRow(
                "Effective config",
                "fail",
                f"could not load: {exc}",
                next_action="check ~/.halton-meter/config.toml syntax",
            )
        )
        return rows, mode, plat
    # v0.1.4 (2B.15) P0-5: surface auto-port-fallback explicitly. When
    # the chosen port differs from the marketed default, append a
    # human-readable note so the user knows the daemon picked a
    # non-default port (and therefore their tool config must target
    # the actual one, not the default). Icon stays "ok" — a fallback
    # is informative, not a failure mode; the doctor verdict must not
    # downgrade to INCONSISTENT just because 8080 was busy.
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    fallback_notes: list[str] = []
    if listen_port != LISTEN_PORT_DEFAULT:
        fallback_notes.append(
            f"proxy fell back from busy default :{LISTEN_PORT_DEFAULT} to :{listen_port}"
        )
    if api_port != API_PORT_DEFAULT:
        fallback_notes.append(
            f"api fell back from busy default :{API_PORT_DEFAULT} to :{api_port}"
        )
    if fallback_notes:
        ports_summary = (
            f"listen={listen_host}:{listen_port}  api={api_host}:{api_port}  "
            f"({'; '.join(fallback_notes)})"
        )
    else:
        ports_summary = (
            f"listen={listen_host}:{listen_port}  api={api_host}:{api_port}"
        )
    rows.append(
        DoctorRow(
            "Effective ports",
            "ok",
            ports_summary,
            raw={
                "listen_host": listen_host,
                "listen_port": listen_port,
                "api_host": api_host,
                "api_port": api_port,
                "listen_default": LISTEN_PORT_DEFAULT,
                "api_default": API_PORT_DEFAULT,
                "fallback": bool(fallback_notes),
            },
        )
    )

    # --- Daemon /health ----------------------------------------------------
    from halton_meter.health import (
        check_daemon_health,
        check_install_mode_sentinel,
        check_plists_loaded_macos,
        check_port_persisted,
        shell_env_present,
    )

    h = check_daemon_health(api_host, api_port, timeout=2.0)
    rows.append(
        DoctorRow(
            "Daemon /health",
            # 2C.2 (v0.1.6): a daemon-down state alone is no longer BROKEN
            # — the edge keeps apps working in passthrough. Surface as
            # warn (so the verdict is INCONSISTENT, not BROKEN) when the
            # edge is up; the edge-row check below escalates to fail
            # when the edge itself is down.
            "ok" if h.ok else "warn",
            h.message + (
                ""
                if h.ok
                else "  (edge proxy still tunnels apps in passthrough; "
                "metering is paused until the daemon is back)"
            ),
            next_action=None if h.ok else "run `halton-meter start`",
        )
    )

    # --- Edge proxy state (macOS) -----------------------------------------
    # 2C.2 (v0.1.6): the edge is the load-bearing port-keeper for apps.
    # Daemon down + edge up = INCONSISTENT (no metering, but apps work).
    # Edge down = BROKEN (apps cannot reach upstream).
    if plat == "darwin":
        from halton_meter.install import _EDGE_LABEL, _macos_edge_plist_path

        edge_plist_exists = _macos_edge_plist_path().exists()
        edge_label_known = False
        edge_pid: int | None = None
        if edge_plist_exists:
            try:
                from halton_meter.lifecycle import (
                    _launchctl_label_known,
                    _launchctl_label_pid,
                )

                edge_label_known = _launchctl_label_known(_EDGE_LABEL)
                edge_pid = _launchctl_label_pid(_EDGE_LABEL)
            except Exception:
                pass
        if not edge_plist_exists:
            rows.append(
                DoctorRow(
                    "Edge proxy",
                    "fail",
                    "edge plist not installed; apps will fail with "
                    "ConnectionRefused",
                    next_action="run `halton-meter init` to install the edge plist",
                )
            )
        elif edge_pid is None:
            rows.append(
                DoctorRow(
                    "Edge proxy",
                    "fail",
                    "edge plist installed but no live PID; "
                    f"label_known={edge_label_known}",
                    next_action=(
                        "run `launchctl load -w "
                        "~/Library/LaunchAgents/com.haltonlabs.meter.edge.plist`"
                    ),
                )
            )
        else:
            # v0.1.7 Gap 0: surface stale-chain INCONSISTENT.
            # When the daemon fell back to a different internal_port
            # after the edge had already cached the original, every
            # chain attempt fails and the edge silently locks into
            # passthrough — apps work, captures vanish.
            stale_chain_detail: str | None = None
            try:
                from halton_meter.port_alloc import (
                    RUNTIME_TOML_PATH,
                    _read_runtime_toml,
                    read_edge_state_toml,
                )

                runtime_internal = _read_runtime_toml(
                    RUNTIME_TOML_PATH
                ).get("internal_port")
                edge_state = read_edge_state_toml()
                edge_chain = edge_state.get("chain_port")
                edge_state_pid = edge_state.get("pid")
                if (
                    runtime_internal is not None
                    and edge_chain is not None
                    and edge_state_pid == edge_pid
                    and edge_chain != runtime_internal
                ):
                    stale_chain_detail = (
                        f"chain :{edge_chain} but daemon on "
                        f":{runtime_internal} (stale chain target)"
                    )
            except Exception:
                stale_chain_detail = None

            if stale_chain_detail is not None:
                rows.append(
                    DoctorRow(
                        "Edge proxy",
                        "warn",
                        f"PID {edge_pid}, port=:{listen_port}, "
                        f"{stale_chain_detail}",
                        next_action=(
                            "kick the edge: `launchctl kickstart -k "
                            "gui/$(id -u)/com.haltonlabs.meter.edge` "
                            "(or `halton-meter doctor --fix --apply` from "
                            "a fresh terminal)"
                        ),
                    )
                )
            else:
                rows.append(
                    DoctorRow(
                        "Edge proxy",
                        "ok",
                        f"PID {edge_pid}, port=:{listen_port}",
                    )
                )

    # --- mitmproxy CA cert on disk (cross-platform) ------------------------
    # v0.1.9 Gap 14: surface CA-on-disk drift explicitly so doctor --apply
    # has a concrete row to dispatch the regenerate fixer against.
    from halton_meter.setup import (
        MITMPROXY_CERT_PATH,
        _certifi_bundle_path,
        _is_certifi_patched,
    )

    ca_present = MITMPROXY_CERT_PATH.exists()
    rows.append(
        DoctorRow(
            "mitmproxy CA cert",
            "ok" if ca_present else "fail",
            (
                f"present at {MITMPROXY_CERT_PATH}"
                if ca_present
                else f"missing at {MITMPROXY_CERT_PATH}"
            ),
            next_action=(
                None if ca_present
                else "run `halton-meter setup` to regenerate the CA"
            ),
            raw={"path": str(MITMPROXY_CERT_PATH), "present": ca_present},
        )
    )

    # --- certifi bundle patched (cross-platform) ---------------------------
    try:
        bundle_path = _certifi_bundle_path()
        certifi_patched = _is_certifi_patched()
        rows.append(
            DoctorRow(
                "Certifi bundle patched",
                "ok" if certifi_patched else "warn",
                (
                    f"patched: {bundle_path}"
                    if certifi_patched
                    else f"unpatched: {bundle_path} "
                    "(Anthropic SDK / Python `requests` will reject our cert)"
                ),
                next_action=(
                    None if certifi_patched
                    else "run `halton-meter setup` to re-append the CA"
                ),
                raw={
                    "bundle_path": str(bundle_path),
                    "patched": certifi_patched,
                },
            )
        )
    except Exception as exc:  # pragma: no cover — certifi import failure
        rows.append(
            DoctorRow(
                "Certifi bundle patched",
                "warn",
                f"could not inspect certifi bundle: {exc}",
                next_action="reinstall certifi via `pipx reinstall halton-meter`",
            )
        )

    # --- Cert trust (macOS only) -------------------------------------------
    cert_trusted: bool | None = None
    if plat == "darwin":
        from halton_meter.setup import (
            _is_cert_trusted_macos,
            _verify_cert_trust_macos_raw,
        )

        rc, stdout, stderr = _verify_cert_trust_macos_raw()
        cert_trusted = _is_cert_trusted_macos()
        rows.append(
            DoctorRow(
                "Cert trust (security verify-cert -p ssl)",
                "ok" if cert_trusted else "fail",
                f"rc={rc} (trusted={cert_trusted})",
                next_action=(
                    None
                    if cert_trusted
                    else "run `halton-meter setup --force` to re-add the CA cert. "
                    "If MDM blocks the trust setting, contact your IT admin."
                ),
                raw={
                    "verify_cert_rc": rc,
                    "verify_cert_stdout": stdout,
                    "verify_cert_stderr": stderr,
                },
            )
        )

        # Phase 1 secondary diagnostic: parse trust-settings-export for
        # the mitmproxy CA's SHA-1. Surface in raw so support tickets can
        # distinguish drift modes.
        admin_trust = _admin_trust_contains_mitmproxy_sha1()
        if admin_trust is not None:
            rows.append(
                DoctorRow(
                    "Admin trust contains mitmproxy SHA-1",
                    "ok" if admin_trust["matched"] else "warn",
                    f"matched={admin_trust['matched']}  sha1={admin_trust['sha1']}",
                    next_action=None,
                    raw=admin_trust,
                )
            )

    # --- System proxy state per interface (macOS) --------------------------
    if plat == "darwin":
        from halton_meter import system_proxy

        ifaces = system_proxy._macos_interfaces()
        any_points_at_us = False
        per_iface: dict[str, dict[str, dict[str, Any]]] = {}
        for iface in ifaces:
            per_iface[iface] = {}
            for kind, secure in (("https", True), ("http", False)):
                enabled, host, port = system_proxy._read_macos_proxy(
                    iface, secure=secure
                )
                per_iface[iface][kind] = {
                    "enabled": enabled,
                    "host": host,
                    "port": port,
                }
                if enabled and system_proxy._proxy_targets_us(
                    host, port, listen_host, listen_port
                ):
                    any_points_at_us = True

        # v0.1.5 (2B.16) three-mode verdict:
        # * env-only: SHOULD NOT point at us. ok if not, ok if so (we
        #   tolerate user-managed proxies — only flag if they target
        #   our daemon).
        # * apps: SHOULD NOT point at us. If it does, treat as DRIFT
        #   (fail) — the apps mode promise is "system proxy is left
        #   alone"; pointing at us means a stale full-mode install
        #   wasn't cleaned up.
        # * full: MUST point at us; failure is fatal.
        # * unknown mode (sentinel missing): warn so the verdict is
        #   INCONSISTENT.
        if mode == "env-only":
            icon = "ok"  # env-only never asserts on system proxy state
        elif mode == "apps":
            # apps mode REQUIRES system proxy NOT to point at us. Drift =
            # fail.
            icon = "fail" if any_points_at_us else "ok"
        elif mode == "full":
            icon = "ok" if any_points_at_us else "fail"
        else:
            icon = "ok" if any_points_at_us else "warn"
        msg_kind = "points-at-us" if any_points_at_us else "not-pointing-at-us"
        if mode == "apps" and any_points_at_us:
            next_action = (
                "stale full-mode state — re-run `halton-meter init --apps` to "
                "reconcile (or `halton-meter uninstall` then re-init)"
            )
        elif mode == "full" and not any_points_at_us:
            next_action = "run `halton-meter init --full` to enable system proxy"
        else:
            next_action = None
        rows.append(
            DoctorRow(
                "System proxy",
                icon,
                f"{msg_kind} across {len(ifaces)} interfaces",
                next_action=next_action,
                raw={"interfaces": per_iface},
            )
        )

    # --- launchctl env vars (macOS) ----------------------------------------
    if plat == "darwin":
        from halton_meter.system_proxy import (
            GUI_LAUNCHCTL_ENV_KEYS,
            getenv_user_domain,
        )

        launchctl_env: dict[str, str | None] = {
            k: getenv_user_domain(k) for k in GUI_LAUNCHCTL_ENV_KEYS
        }
        any_set = any(v is not None for v in launchctl_env.values())
        # v0.1.5 (2B.16) three-mode verdict:
        # * env-only: SHOULD be unset (drift = stale apps/full state).
        # * apps + full: MUST be set (it's how those modes deliver
        #   their coverage).
        if mode == "env-only":
            icon = "ok" if not any_set else "warn"
            summary = (
                "all unset (expected for env-only mode)"
                if not any_set
                else "some env vars are set despite env-only mode "
                "(stale apps/full state?)"
            )
            next_action = (
                None if not any_set
                else "run `halton-meter init` to reconcile env-only mode"
            )
        elif mode in ("apps", "full"):
            icon = "ok" if any_set else "fail"
            summary = (
                f"{sum(1 for v in launchctl_env.values() if v is not None)}/"
                f"{len(launchctl_env)} keys set"
            )
            next_action = (
                None if any_set
                else f"run `halton-meter init --{mode}` to (re)write "
                "launchctl env"
            )
        else:
            # Unknown mode — informational.
            icon = "warn" if not any_set else "ok"
            n_set = sum(1 for v in launchctl_env.values() if v is not None)
            summary = f"{n_set}/{len(launchctl_env)} keys set"
            next_action = None
        rows.append(
            DoctorRow(
                "launchctl env (user domain)",
                icon,
                summary,
                next_action=next_action,
                raw={"env": launchctl_env},
            )
        )

    # --- Shell rc marker --------------------------------------------------
    if plat == "darwin":
        from halton_meter.init import (
            SHELL_RC_BLOCK_BEGIN,
            detect_shell_rc,
        )

        rc_path = detect_shell_rc()
        marker_present = False
        if rc_path is not None and rc_path.exists():
            try:
                marker_present = SHELL_RC_BLOCK_BEGIN in rc_path.read_text(
                    encoding="utf-8"
                )
            except OSError:
                pass
        if mode == "env-only":
            icon = "ok"  # shell-rc is apps/full-only; not having it is correct
            summary = (
                "(env-only mode does not append shell rc)"
                if not marker_present
                else "marker present despite env-only mode (stale)"
            )
            if marker_present:
                next_action = (
                    "run `halton-meter init` to reconcile env-only mode"
                )
            else:
                next_action = None
        elif mode in ("apps", "full"):
            icon = "ok" if marker_present else "warn"
            summary = (
                f"marker present in {rc_path}"
                if marker_present and rc_path
                else "marker not found (user may have declined the prompt)"
            )
            next_action = (
                None if marker_present
                else f"re-run `halton-meter init --{mode}` and accept "
                "the shell rc prompt"
            )
        else:
            icon = "warn"
            summary = (
                f"marker present in {rc_path}"
                if marker_present and rc_path
                else "marker not found"
            )
            next_action = None
        rows.append(
            DoctorRow(
                "Shell rc marker",
                icon,
                summary,
                next_action=next_action,
                raw={
                    "rc_path": str(rc_path) if rc_path else None,
                    "marker_present": marker_present,
                },
            )
        )

    # --- Per-tool env presence in current shell ---------------------------
    snap = shell_env_present()
    set_count = sum(1 for v in snap.values() if v)
    rows.append(
        DoctorRow(
            "Shell env (this process)",
            "ok" if set_count > 0 else "warn",
            f"{set_count}/{len(snap)} keys set",
            next_action=(
                None if set_count > 0
                else "in --gui mode after rc append, open a new shell. "
                "in env-only mode, use `halton-meter run <cmd>`."
            ),
            raw={"env": snap},
        )
    )

    # --- Plist (macOS) ----------------------------------------------------
    if plat == "darwin":
        plist_check = check_plists_loaded_macos()
        rows.append(
            DoctorRow(
                "Daemon plist registered",
                "ok" if plist_check.ok else "fail",
                plist_check.message,
                next_action=(
                    None if plist_check.ok else "run `halton-meter start`"
                ),
            )
        )

    # --- Sentinel file ----------------------------------------------------
    sentinel_check = check_install_mode_sentinel()
    rows.append(
        DoctorRow(
            sentinel_check.name,
            "ok" if sentinel_check.ok else "warn",
            sentinel_check.message,
            next_action=(
                None if sentinel_check.ok else "run `halton-meter init`"
            ),
        )
    )

    port_persist_check = check_port_persisted()
    rows.append(
        DoctorRow(
            port_persist_check.name,
            "ok",
            port_persist_check.message,
            next_action=None,
        )
    )

    # --- Optional curl probe ----------------------------------------------
    if run_curl:
        # Safety guard: assert nothing in the URL points at a provider.
        for forbidden in _FORBIDDEN_HOST_FRAGMENTS:
            assert forbidden not in _CURL_PROBE_URL, (
                f"FATAL: doctor --curl target {_CURL_PROBE_URL!r} contains "
                f"forbidden fragment {forbidden!r}; refusing to run probe"
            )
        rows.append(_run_curl_probe(api_host=api_host, listen_port=listen_port))

    return rows, mode, plat


def _run_curl_probe(*, api_host: str, listen_port: int) -> DoctorRow:
    """Probe ``https://example.com`` via the proxy. Returns a DoctorRow."""
    from halton_meter.setup import _certifi_bundle_path

    if not shutil.which("curl"):
        return DoctorRow(
            "Curl probe",
            "warn",
            "curl not found on PATH",
            next_action="install curl or run `halton-meter doctor` without --curl",
        )

    try:
        bundle = _certifi_bundle_path()
    except Exception as exc:
        return DoctorRow(
            "Curl probe",
            "fail",
            f"certifi bundle missing: {exc}",
            next_action="run `halton-meter setup` to re-create the patched bundle",
        )

    proxy_url = f"http://{api_host}:{listen_port}"
    cmd = [
        "curl",
        "-sS",
        "-o",
        "/dev/null",
        "-w",
        "%{http_code}",
        "--max-time",
        "10",
        "-x",
        proxy_url,
        "--cacert",
        str(bundle),
        _CURL_PROBE_URL,
    ]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return DoctorRow(
            "Curl probe",
            "fail",
            f"curl failed: {exc}",
            next_action=None,
            raw={"cmd": cmd, "error": str(exc)},
        )
    code = (result.stdout or "").strip()
    ok = code.startswith("2") or code.startswith("3")
    return DoctorRow(
        "Curl probe",
        "ok" if ok else "fail",
        f"GET {_CURL_PROBE_URL} via {proxy_url} -> HTTP {code or 'unknown'}",
        next_action=(
            None if ok
            else "if cert trust failed, the daemon refuses to enable the system proxy. "
            "doctor's cert-trust row above explains."
        ),
        raw={
            "url": _CURL_PROBE_URL,
            "proxy": proxy_url,
            "rc": result.returncode,
            "http_code": code,
            "stderr": (result.stderr or "")[-2000:],
        },
    )


def _admin_trust_contains_mitmproxy_sha1() -> dict[str, Any] | None:
    """Phase 1 secondary diagnostic (Approach B): parse
    ``security trust-settings-export -d <plist>`` and check whether the
    mitmproxy CA's SHA-1 appears as an admin-domain trust entry.

    Returns ``{"matched": bool, "sha1": str | None}`` or ``None`` if the
    probe could not run (non-macOS / missing tools / parsing failure).
    """
    if _sys.platform != "darwin":
        return None
    from halton_meter.setup import MITMPROXY_CERT_PATH

    if not MITMPROXY_CERT_PATH.exists():
        return None
    if not shutil.which("security") or not shutil.which("openssl"):
        return None
    # Compute mitmproxy CA SHA-1.
    try:
        sha_proc = subprocess.run(
            ["openssl", "x509", "-in", str(MITMPROXY_CERT_PATH), "-noout", "-fingerprint", "-sha1"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if sha_proc.returncode != 0:
        return None
    sha_line = (sha_proc.stdout or "").strip()
    # Format: "SHA1 Fingerprint=AB:CD:..."
    sha1 = sha_line.split("=", 1)[-1].strip().replace(":", "").upper() if "=" in sha_line else None
    if sha1 is None or len(sha1) != 40:
        return None

    # Export trust settings to a temp plist and grep for the SHA-1. We
    # don't parse the plist properly — just check substring presence,
    # which is robust against schema variation.
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".plist", delete=False) as tf:
        tmp_path = tf.name
    try:
        export_proc = subprocess.run(
            ["security", "trust-settings-export", "-d", tmp_path],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if export_proc.returncode != 0:
            return {"matched": False, "sha1": sha1}
        try:
            with open(tmp_path, "rb") as fh:
                content = fh.read()
        except OSError:
            return {"matched": False, "sha1": sha1}
        # SHA-1 may appear as either uppercase or with colons stripped.
        # The plist uses the cert's DER bytes for the trust-settings key,
        # not necessarily the SHA-1 directly. Do a best-effort grep on
        # the human-readable key form.
        matched = sha1.encode("ascii") in content.upper()
        return {"matched": matched, "sha1": sha1}
    finally:
        try:
            import os

            os.unlink(tmp_path)
        except OSError:
            pass


# --------------------------------------------------------------------------- #
# Verdict computation                                                         #
# --------------------------------------------------------------------------- #


def _compute_verdict(rows: list[DoctorRow], mode: str | None) -> tuple[str, str]:
    """Return ``(verdict, summary_message)``.

    Mode-aware decision matrix:

    * Any "fail" icon in fatal rows -> BROKEN.
    * Any "warn" icon -> INCONSISTENT (only when mode is known and
      something is mismatched).
    * Otherwise -> HEALTHY.

    The summary message names the leading symptom for the user.
    """
    fails = [r for r in rows if r.icon == "fail"]
    if fails:
        first = fails[0]
        return (
            VERDICT_BROKEN,
            f"{first.name}: {first.summary}"
            + (f"  ({first.next_action})" if first.next_action else ""),
        )
    warns = [r for r in rows if r.icon == "warn"]
    # 2C.2 (v0.1.6): when only the daemon /health row is warn (and the
    # edge proxy row is ok), surface the passthrough story as a
    # specific INCONSISTENT message: metering paused, apps still work.
    daemon_warn = next(
        (r for r in warns if r.name == "Daemon /health"), None
    )
    edge_ok = any(r.name == "Edge proxy" and r.icon == "ok" for r in rows)
    if daemon_warn is not None and edge_ok:
        return (
            VERDICT_INCONSISTENT,
            "metering paused; apps still work in passthrough  "
            "(run `halton-meter start` to resume metering)",
        )
    if warns:
        first = warns[0]
        return (
            VERDICT_INCONSISTENT,
            f"{first.name}: {first.summary}"
            + (f"  ({first.next_action})" if first.next_action else ""),
        )
    if mode == "env-only":
        return (
            VERDICT_HEALTHY,
            "env-var-only mode is healthy. "
            "Use `halton-meter run <cmd>` to meter Claude Code, SDK clients, etc.",
        )
    if mode == "apps":
        return (
            VERDICT_HEALTHY,
            "--apps mode is healthy. New shells + Spotlight-spawned apps are "
            "metered; system proxy is intentionally unmanaged.",
        )
    if mode == "full":
        return (VERDICT_HEALTHY, "--full mode is healthy.")
    return (VERDICT_HEALTHY, "Install is healthy.")


# --------------------------------------------------------------------------- #
# Public entry points                                                         #
# --------------------------------------------------------------------------- #


def run_doctor(
    *, run_curl: bool = False, console: Console | None = None
) -> DoctorReport:
    """Run the doctor probe set; return a DoctorReport (no rendering)."""
    rows, mode, plat = _build_rows(run_curl=run_curl)
    verdict, msg = _compute_verdict(rows, mode)
    return DoctorReport(
        verdict=verdict,
        summary_message=msg,
        rows=rows,
        mode=mode,
        platform=plat,
        version=__version__,
    )


def render_report(report: DoctorReport, console: Console) -> None:
    """Plain-text render: top-line verdict, table of rows, footer hint."""
    color = {
        VERDICT_HEALTHY: "green",
        VERDICT_INCONSISTENT: "yellow",
        VERDICT_BROKEN: "red",
    }.get(report.verdict, "white")
    console.print(f"[bold {color}]{report.verdict}[/bold {color}] — {report.summary_message}")
    console.print(
        f"[dim]platform={report.platform}  mode={report.mode or 'unknown'}  "
        f"version={report.version}[/dim]"
    )
    table = Table(title="halton-meter doctor", show_header=True, header_style="bold")
    table.add_column("Status", width=8)
    table.add_column("Check")
    table.add_column("Detail")
    table.add_column("Next action")
    for r in report.rows:
        table.add_row(
            _icon_glyph(r.icon),
            r.name,
            r.summary,
            r.next_action or "—",
        )
    console.print(table)
    console.print(
        "\n[dim]Paste this output into a support ticket if you need help.[/dim]"
    )


@click.command(name="doctor")
@click.option(
    "--curl",
    "run_curl",
    is_flag=True,
    default=False,
    help=(
        "Probe https://example.com via the proxy as an end-to-end TLS "
        "smoke test. The probe target is hard-coded to a non-provider "
        "domain."
    ),
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    default=False,
    help="Emit a structured JSON report on stdout instead of a Rich table.",
)
@click.option(
    "--fix",
    "fix_mode",
    is_flag=True,
    default=False,
    help=(
        "Show the repair plan that would bring the install back into "
        "agreement with the recorded mode. Plan-only by default — does "
        "NOT mutate state; pair with --apply to execute."
    ),
)
@click.option(
    "--apply",
    "apply_repair",
    is_flag=True,
    default=False,
    help=(
        "Execute the repair plan. Briefly interrupts any active "
        "proxied session — recommend running from a fresh terminal."
    ),
)
def doctor_cmd(
    run_curl: bool, as_json: bool, fix_mode: bool, apply_repair: bool
) -> None:
    """Diagnose the halton-meter install and surface concrete next-actions."""
    console = Console()

    # v0.1.7 Gap 3: --apply implies --fix. Allowing bare --apply also
    # works — it's the most common invocation.
    if apply_repair and not fix_mode:
        fix_mode = True

    report = run_doctor(run_curl=run_curl, console=console)
    if as_json:
        click.echo(_json.dumps(report.to_dict(), indent=2))
    else:
        render_report(report, console)

    if fix_mode:
        _run_fix(report, apply_repair=apply_repair, console=console)

    # Exit code: 0 if HEALTHY, 1 if INCONSISTENT, 2 if BROKEN.
    rc = {VERDICT_HEALTHY: 0, VERDICT_INCONSISTENT: 1, VERDICT_BROKEN: 2}.get(
        report.verdict, 1
    )
    _sys.exit(rc)


# --------------------------------------------------------------------------- #
# v0.1.7 Gap 3: --fix / --apply driver                                        #
# --------------------------------------------------------------------------- #


def _run_fix(report: DoctorReport, *, apply_repair: bool, console: Console) -> None:
    """Render the repair plan; if ``apply_repair`` is set and the user
    confirms (or skips the inside-session warning), reconcile the
    install to its recorded mode.

    Plan rendering is intentionally simple: the existing doctor rows
    already enumerate what's wrong with concrete next-actions; the
    "plan" is just those rows surfaced under a heading. Reconcile is
    delegated to :func:`init._reconcile_to_mode` — the canonical
    sweeper used by ``halton-meter init`` itself.
    """
    fixable = [r for r in report.rows if r.icon in ("warn", "fail")]

    console.print()
    if not fixable:
        console.print("[green]Repair plan: nothing to do — install is HEALTHY.[/green]")
        return

    console.print("[bold]Repair plan[/bold]")
    for row in fixable:
        bullet = (
            f"  • {row.name}: {row.summary}"
            + (f"\n    -> {row.next_action}" if row.next_action else "")
        )
        console.print(bullet)

    if not apply_repair:
        console.print()
        console.print(
            "Plan-only — pass [bold]--apply[/bold] to execute. "
            "Recommend running from a fresh terminal."
        )
        return

    # Inside-session warning. The reconcile step toggles launchctl env
    # and may bounce the system proxy; running from inside a metered
    # tool (Claude Code, Windsurf, etc.) will briefly interrupt the
    # current session.
    if is_running_inside_metered_session():
        console.print()
        console.print(
            "[yellow]Warning: you are running this from inside a proxied "
            "session (Claude Code, Windsurf, etc.). Applying will briefly "
            "interrupt the current session.[/yellow]"
        )
        console.print(
            "Recommended: run [bold]halton-meter doctor --fix --apply[/bold] "
            "from a fresh terminal."
        )
        if not click.confirm("Continue anyway?", default=False):
            console.print("Aborted; no state was changed.")
            return

    # Delegate to the canonical sweeper.
    from halton_meter.init import _reconcile_to_mode, read_install_mode

    target_mode = read_install_mode() or "env-only"
    console.print()
    console.print(f"[bold]Applying repair[/bold] (target mode: {target_mode})")
    _reconcile_to_mode(target_mode, console)

    # v0.1.7 Gap 3: ``_reconcile_to_mode`` rewrites plists / launchctl env
    # but does NOT bounce the live edge process — so a Gap 0 stale-chain
    # row stays stale across a reconcile (the edge has cached the wrong
    # internal_port at exec time). Kick the edge explicitly when the
    # report flagged it. Fail-open: kickstart errors are logged and
    # continue; the rest of the repair has already landed.
    _kick_edge_if_stale_chain(report, console)

    # v0.1.9 Gap 14: extend the apply pass to fix drift `_reconcile_to_mode`
    # never touches — certifi patch, cert trust, shell-rc block, mitmproxy
    # CA on disk. Each fixer is fail-open: a rotten row must not block the
    # rest. Dispatch is mechanical (row.name -> fixer) so adding new
    # categories later is a one-line registration.
    _apply_extra_fixers(report, target_mode=target_mode, console=console)

    console.print("[green]Repair applied.[/green] Run `halton-meter doctor` again to verify.")


# --------------------------------------------------------------------------- #
# v0.1.9 Gap 14 — per-row reconcile dispatch                                  #
# --------------------------------------------------------------------------- #


def _fix_mitmproxy_ca(console: Console, _row: DoctorRow, _target_mode: str) -> None:
    """Regenerate the mitmproxy CA on disk by invoking ``mitmdump
    --version`` once — that bootstraps ``~/.mitmproxy/`` lazily.

    We don't shell out to mitmdump's full proxy; ``--version`` is a no-op
    that exits immediately. After the cert exists, the user typically
    also needs cert trust — handled by the next fixer in the chain.
    """
    from halton_meter.setup import generate_mitmproxy_cert

    status = generate_mitmproxy_cert(force=False)
    console.print(f"  -> {status.note or status.name}")


def _fix_certifi_patched(
    console: Console, _row: DoctorRow, _target_mode: str
) -> None:
    """Re-append the mitmproxy CA to the certifi bundle."""
    from halton_meter.setup import patch_certifi

    status = patch_certifi(force=False)
    console.print(f"  -> {status.note or status.name}")


def _fix_cert_trust(
    console: Console, _row: DoctorRow, _target_mode: str
) -> None:
    """Re-trust the mitmproxy CA in the macOS keychain.

    Reuses the existing osascript-admin / sudo-fallback elevation flow
    in :func:`halton_meter.setup.trust_cert_macos` — do NOT reinvent it.
    macOS only; no-op elsewhere.
    """
    if _sys.platform != "darwin":
        console.print("  -> skipping cert trust (non-macOS platform)")
        return
    from halton_meter.setup import trust_cert_macos

    status = trust_cert_macos(force=False, console=console)
    console.print(f"  -> {status.note or status.name}")


def _fix_shell_rc(
    console: Console, _row: DoctorRow, target_mode: str
) -> None:
    """Re-append the managed env block to the user's shell rc.

    Only meaningful in ``apps`` / ``full`` modes — env-only mode never
    writes the rc block. Always prompts before touching ``.zshrc``;
    skipping a missing rc file is silent (we never create one).
    """
    from halton_meter.init import (
        MODE_APPS,
        MODE_FULL,
        append_coverage_block_to_rc,
        build_env_vars,
        detect_shell_rc,
    )
    from halton_meter.port_alloc import load_effective_config
    from halton_meter.setup import _certifi_bundle_path

    if target_mode not in (MODE_APPS, MODE_FULL):
        console.print(
            "  -> skipping shell rc (env-only mode does not append a block)"
        )
        return
    rc_path = detect_shell_rc()
    if rc_path is None:
        console.print("  -> skipping shell rc ($SHELL is not zsh / bash)")
        return
    if not rc_path.exists():
        console.print(f"  -> skipping shell rc ({rc_path} does not exist)")
        return
    if not click.confirm(
        f"  Append managed env block to {rc_path}?", default=False
    ):
        console.print("  -> declined; shell rc unchanged")
        return
    cfg = load_effective_config()
    env_vars = build_env_vars(
        cfg.daemon.listen_host, cfg.daemon.edge_port, _certifi_bundle_path()
    )
    status = append_coverage_block_to_rc(rc_path, env_vars)
    console.print(f"  -> shell rc {status} ({rc_path})")


# Doctor-row name -> fixer. Keyed on the *exact* string passed to
# DoctorRow(name=...) in :func:`_build_rows`. Adding a new fixable row
# is one line here + one row entry above.
_FIXER_BY_ROW: dict[str, Callable[[Console, DoctorRow, str], None]] = {
    "mitmproxy CA cert": _fix_mitmproxy_ca,
    "Certifi bundle patched": _fix_certifi_patched,
    "Cert trust (security verify-cert -p ssl)": _fix_cert_trust,
    "Shell rc marker": _fix_shell_rc,
}


def _apply_extra_fixers(
    report: DoctorReport, *, target_mode: str, console: Console
) -> None:
    """Walk fixable rows; dispatch each to its registered fixer.

    Fail-open per fixer: any exception is logged via the console and
    the loop continues. The `_reconcile_to_mode` sweeper has already
    run by this point, so we are working *on top of* a freshly-bounced
    install — every fixer can assume plists / launchctl env are sane.
    """
    for row in report.rows:
        if row.icon not in ("warn", "fail"):
            continue
        fixer = _FIXER_BY_ROW.get(row.name)
        if fixer is None:
            continue
        console.print(f"Fixing [bold]{row.name}[/bold]...")
        try:
            fixer(console, row, target_mode)
        except Exception as exc:  # pragma: no cover — defensive fail-open
            # One rotten row must not block the others. Surface the
            # failure but keep going.
            console.print(
                f"  [yellow]fixer for {row.name!r} raised "
                f"{type(exc).__name__}: {exc}[/yellow]  (continuing)"
            )


def _kick_edge_if_stale_chain(report: DoctorReport, console: Console) -> None:
    """If the doctor report contains an Edge-proxy row flagged as
    stale-chain (Gap 0), shell ``launchctl kickstart -k`` against the
    edge label so it re-execs and re-resolves ``internal_port`` from
    ``runtime.toml``.

    Detection key: a row named "Edge proxy" with ``icon == "warn"``
    whose ``summary`` contains the marker substring "stale chain
    target" — that's the exact phrasing Gap 0 emits at
    ``doctor.py`` ~line 306-309. Coupling on the marker string keeps
    this helper independent of Gap 0's plumbing internals (the test
    fixtures the row directly).
    """
    if _sys.platform != "darwin":
        return

    stale = next(
        (
            r
            for r in report.rows
            if r.name == "Edge proxy"
            and r.icon == "warn"
            and "stale chain target" in r.summary
        ),
        None,
    )
    if stale is None:
        return

    from halton_meter.install import _EDGE_LABEL

    target = f"gui/{os.getuid()}/{_EDGE_LABEL}"
    cmd = ["launchctl", "kickstart", "-k", target]
    console.print(f"Kicking edge proxy: [bold]{' '.join(cmd)}[/bold]")
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        # Fail-open: surface the failure but do NOT raise. The user can
        # bounce the edge manually; the rest of the repair has landed.
        console.print(
            f"[yellow]launchctl kickstart failed: {exc}[/yellow]  "
            "(repair otherwise applied; bounce the edge manually if needed)"
        )
        return
    if result.returncode != 0:
        console.print(
            f"[yellow]launchctl kickstart rc={result.returncode}: "
            f"{(result.stderr or '').strip()}[/yellow]"
        )
        return
    console.print("[green]Edge proxy kicked.[/green]")
