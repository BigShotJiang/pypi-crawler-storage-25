"""
mitmproxy addon and DumpMaster runner for Halton Meter.

HaltonAddon is the mitmproxy addon class. It:
  - Filters requests to inference endpoints only (paths starting with /v1/messages)
  - Looks up the appropriate provider adapter for the request host
  - Parses request metadata and stores it keyed by flow ID
  - On response, parses response metadata, resolves project, computes cost,
    writes a LogRecord to SQLite, and prints a capture line

The hot path (request / response hooks) never raises — all errors are caught,
logged, and the flow continues unaffected. This is the cardinal rule: observation
must never become a single point of failure for the developer's workflow.

Path filtering rationale:
  The adapter registry matches on host (e.g. api.anthropic.com), but Anthropic
  exposes many non-inference endpoints on that host:
    /v1/mcp_servers, /api/oauth/..., /api/claude_cli/..., /mcp-registry/...
  These are matched by the adapter's matches() but should not be processed.
  The path filter lives here in proxy.py (not in the adapter) so that adapters
  remain pure host-matching parsers and the filtering concern stays in one place.
"""

from __future__ import annotations

import asyncio
import sys
import time
import uuid
from collections import defaultdict, deque
from datetime import UTC, datetime

import structlog
from mitmproxy import http
from mitmproxy.options import Options
from mitmproxy.tools.dump import DumpMaster

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import ProviderAdapter, RequestMetadata
from halton_meter.config import HaltonConfig
from halton_meter.models import LogRecord
from halton_meter.policy_engine import PolicyDecision, evaluate_policies
from halton_meter.pricing import compute_cost_millicents
from halton_meter.storage import StorageManager
from halton_meter.tagging import resolve_project

log = structlog.get_logger()


# ---------------------------------------------------------------------------
# v0.1.7 Gap 4: per-host parse timeouts + circuit breaker
#
# The response hook used to call ``adapter.parse_response`` synchronously
# on the asyncio event loop. A pathological response body (e.g. a 50 MB
# accumulated SSE stream that triggers a slow regex) would stall the
# event loop, blocking every other in-flight flow until the parse
# returned. We now offload the parse to a worker thread under
# ``asyncio.wait_for`` with a per-host timeout; if a host racks up
# repeated timeouts the breaker trips and bypasses metering for that
# host until it cools off (60s -> 120s -> 240s, capped).
#
# Important invariants (do not redesign without re-reading these):
#  * Pure-buffer mode: mitmproxy is configured WITHOUT
#    ``stream_large_bodies`` / ``flow.response.stream``. ``parse_response``
#    is a pure function over the fully-accumulated body. If you ever
#    enable streaming mode, the asyncio.to_thread offload silently races
#    the stream — DO NOT enable streaming without revisiting the hook.
#  * ``_pending.pop`` happens BEFORE the circuit-open check so a
#    sustained outage cannot grow ``_pending`` unbounded.
#  * ONLY parse timeouts trip the breaker. Parse exceptions stay
#    fail-open without tripping — they don't stall the hot path, so
#    tripping on them would lose data unnecessarily.
# ---------------------------------------------------------------------------

PARSE_TIMEOUTS: dict[str, float] = {
    "api.anthropic.com": 5.0,
    "*": 3.0,
}

_CB_WINDOW_SEC = 60.0
_CB_FAILURE_THRESHOLD = 5
_CB_OPEN_DURATIONS = (60.0, 120.0, 240.0)  # 1st, 2nd, 3rd+ trip (capped)

# ---------------------------------------------------------------------------
# Adapter registry
#
# Maps host → adapter. To add a new provider: instantiate its adapter here.
# The registry is a list; first match wins.
# ---------------------------------------------------------------------------

ADAPTER_REGISTRY: list[ProviderAdapter] = [
    AnthropicAdapter(),
]


def find_adapter(host: str) -> ProviderAdapter | None:
    """Return the first adapter that matches the given host, or None."""
    for adapter in ADAPTER_REGISTRY:
        if adapter.matches(host):
            return adapter
    return None


# ---------------------------------------------------------------------------
# Path filter
#
# Only process requests to inference endpoints. All other paths on matched
# hosts are forwarded silently. This prevents logging noise from OAuth,
# MCP registry, bootstrap, event logging, and other Anthropic endpoints
# that are not inference calls and would produce model=unknown, tokens=0.
# ---------------------------------------------------------------------------

_INFERENCE_PATH_PREFIXES: tuple[str, ...] = (
    "/v1/messages",
    # Future providers will add their inference paths here:
    # "/v1/chat/completions",   # OpenAI
    # "/v1beta/models/",         # Gemini
    # "/openai/v1/chat/",        # Groq
)


def _is_inference_path(path: str) -> bool:
    """Return True if the request path is an LLM inference endpoint."""
    return any(path.startswith(prefix) for prefix in _INFERENCE_PATH_PREFIXES)


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def _format_cost(cost_millicents: int | None) -> str:
    """Format a cost value in millicents for display, e.g. '$0.0012'."""
    if cost_millicents is None:
        return "unknown"
    dollars = cost_millicents / 100_000
    return f"${dollars:.4f}"


def _now_iso() -> str:
    """Return the current UTC time as an ISO 8601 string."""
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Policy enforcement helpers (Phase 3)
# ---------------------------------------------------------------------------


async def _evaluate_project_policies(
    storage: StorageManager | None,
    project: str,
    model: str,
) -> PolicyDecision:
    """
    Fetch cached policies for the project and evaluate them against the request.

    Returns PolicyDecision(action='allow') if no storage or no policies.
    Never raises.
    """
    if storage is None:
        return PolicyDecision(action="allow")
    try:
        policies = await storage.get_policies(project)
        if not policies:
            return PolicyDecision(action="allow")
        running_total = await storage.get_running_monthly_total(project)
        requests_today = await storage.get_today_request_count(project)
        return evaluate_policies(
            policies=policies,
            project=project,
            model=model,
            running_total_millicents=running_total,
            requests_today=requests_today,
        )
    except Exception as exc:
        # Policy enforcement must never disrupt the proxy hot path
        log.error("policy.evaluation_error", project=project, error=str(exc), exc_info=True)
        return PolicyDecision(action="allow")


def _print_policy_decision(decision: PolicyDecision, project: str, model: str) -> None:
    """Print a policy warn/block line to stderr."""
    tag = "WARN" if decision.action == "warn" else "BLOCK"
    print(
        f"[halton-meter] policy.{decision.action.upper()} project={project} model={model}"
        f" reason={decision.reason}",
        file=sys.stderr,
        flush=True,
    )
    log.warning(
        f"policy.{tag.lower()}",
        project=project,
        model=model,
        reason=decision.reason,
        policy_id=decision.policy_id,
    )


async def _log_audit_event(
    storage: StorageManager | None,
    action: str,
    project: str,
    policy_id: str | None,
    metadata: dict,
) -> None:
    """
    Write a policy audit event to local SQLite.

    Replaces the Phase 1/3 ``_post_audit_event`` httpx POST to the backend
    — the daemon now writes audit events to the same SQLite file the
    FastAPI app reads from. Fire-and-forget; never raises.
    """
    if storage is None or storage._sessionmaker is None:
        return
    try:
        from halton_meter.api.services.audit import log_event
        from halton_meter.storage.models import Project

        async with storage._sessionmaker() as session, session.begin():
            project_id: str | None = None
            if project:
                from sqlalchemy import select  # local import to keep hot-path lean

                proj_result = await session.execute(
                    select(Project).where(Project.slug == project)
                )
                proj = proj_result.scalar_one_or_none()
                if proj is not None:
                    project_id = proj.id
            await log_event(
                session,
                action=action,
                project_id=project_id,
                policy_id=policy_id,
                metadata=metadata,
            )
    except Exception:  # pragma: no cover — observation-infrastructure rule
        pass


# ---------------------------------------------------------------------------
# mitmproxy addon
# ---------------------------------------------------------------------------


class HaltonAddon:
    """
    mitmproxy addon that intercepts LLM inference traffic and logs metadata.

    Lifecycle per request:
      request()  → path-filter → adapter lookup → parse_request → store in _pending
      response() → retrieve from _pending → parse_response → tag → cost → write DB → print
    """

    def __init__(
        self,
        storage: StorageManager | None = None,
    ) -> None:
        # flow.id → (RequestMetadata, requested_at ISO string).
        # Bounded in practice by in-flight request count.
        self._pending: dict[str, tuple[RequestMetadata, str]] = {}
        # StorageManager instance, provided by the runner at startup
        self._storage = storage
        # v0.1.7 Gap 4: per-host circuit-breaker state. Only parse-
        # timeouts trip the breaker (parse exceptions are fail-open
        # without tripping — see module docstring for why).
        self._cb_timeouts: dict[str, deque[float]] = defaultdict(deque)
        self._cb_open_until: dict[str, float] = {}
        self._cb_trip_count: dict[str, int] = defaultdict(int)

    # ----------------------------------------------------------------- #
    # Gap 4 helpers — parse timeout + circuit breaker                    #
    # ----------------------------------------------------------------- #

    def _get_parse_timeout(self, host: str) -> float:
        return PARSE_TIMEOUTS.get(host, PARSE_TIMEOUTS["*"])

    def _is_circuit_open(self, host: str) -> bool:
        return time.monotonic() < self._cb_open_until.get(host, 0.0)

    def _record_parse_timeout(self, host: str) -> None:
        """Record a parse-timeout against ``host``; trip the breaker if
        we've crossed the threshold inside the rolling window. Only
        timeouts call this — parse exceptions do not.
        """
        now = time.monotonic()
        dq = self._cb_timeouts[host]
        dq.append(now)
        while dq and now - dq[0] > _CB_WINDOW_SEC:
            dq.popleft()
        if len(dq) >= _CB_FAILURE_THRESHOLD:
            idx = min(self._cb_trip_count[host], len(_CB_OPEN_DURATIONS) - 1)
            open_for = _CB_OPEN_DURATIONS[idx]
            self._cb_open_until[host] = now + open_for
            self._cb_trip_count[host] += 1
            dq.clear()
            log.warning(
                "addon.circuit_opened",
                host=host,
                open_for_sec=open_for,
                trip_count=self._cb_trip_count[host],
            )

    async def request(self, flow: http.HTTPFlow) -> None:
        """
        Called when mitmproxy has the full outbound request.

        Policy enforcement runs here, before forwarding to the provider.
        If a policy blocks the request, we inject a synthetic 429 response
        and mark the flow as killed — the provider never sees the request.
        """
        host = flow.request.host
        path = flow.request.path

        # --- Path filter: only process inference endpoints ---
        if not _is_inference_path(path):
            return

        adapter = find_adapter(host)
        if adapter is None:
            return

        try:
            meta = adapter.parse_request(flow)
            requested_at = _now_iso()

            # --- Policy enforcement (Phase 3) ---
            project = resolve_project(flow)
            decision = await _evaluate_project_policies(
                storage=self._storage,
                project=project,
                model=meta.model,
            )

            if decision.action in ("warn", "block"):
                _print_policy_decision(decision, project=project, model=meta.model)
                # Write audit event to local SQLite fire-and-forget
                # (never blocks proxy; replaces the httpx POST that
                # previously called the cloud backend).
                asyncio.create_task(  # noqa: RUF006
                    _log_audit_event(
                        storage=self._storage,
                        action=(
                            "policy.warned"
                            if decision.action == "warn"
                            else "policy.blocked"
                        ),
                        project=project,
                        policy_id=decision.policy_id,
                        metadata={
                            "reason": decision.reason,
                            "model": meta.model,
                            **decision.metadata,
                        },
                    )
                )

            if decision.action == "block":
                # Inject synthetic 429 — the provider never sees this request.
                # We still write a LogRecord to SQLite with status='blocked_by_policy'.
                error_body = (
                    f'{{"type":"error","error":{{"type":"rate_limit_error",'
                    f'"message":"[Halton Meter] {decision.reason}"}}}}'
                )
                flow.response = http.Response.make(
                    429,
                    error_body,
                    {"content-type": "application/json"},
                )
                # Write a blocked LogRecord to SQLite (fire-and-forget)
                if self._storage is not None:
                    record = LogRecord(
                        id=str(uuid.uuid4()),
                        project=project,
                        provider=meta.provider,
                        model=meta.model,
                        input_tokens=0,
                        output_tokens=0,
                        thinking_tokens=0,
                        cache_read_tokens=0,
                        cache_write_tokens=0,
                        cost_millicents=None,
                        tokens_complete=False,
                        latency_ms=0.0,
                        requested_at=requested_at,
                        recorded_at=_now_iso(),
                        status="blocked_by_policy",
                    )
                    asyncio.create_task(self._storage.write_record(record))  # noqa: RUF006
                return  # Do not add to _pending — response hook will skip it

            self._pending[flow.id] = (meta, requested_at)
            log.info(
                "intercept.request",
                provider=adapter.name,
                model=meta.model,
                stream=meta.stream,
                host=host,
                path=path,
            )
        except Exception as exc:
            log.error(
                "addon.request.failed",
                host=host,
                path=path,
                error=str(exc),
                exc_info=True,
            )

    async def response(self, flow: http.HTTPFlow) -> None:
        """Async response hook with per-host parse timeout + circuit breaker.

        v0.1.7 Gap 4: the parse runs on a worker thread under
        ``asyncio.wait_for`` so a slow / stuck parser cannot stall the
        mitmproxy event loop; sustained per-host timeouts trip a
        circuit breaker that bypasses metering for that host until it
        cools off (see module docstring for the failure model).

        IMPORTANT — pure-buffer assumption:
          mitmproxy is configured WITHOUT ``stream_large_bodies`` /
          ``flow.response.stream``. That means ``flow.response.content``
          holds the fully-accumulated body (incl. SSE) by the time this
          hook fires, and ``adapter.parse_response`` is a pure function
          over that final body. If you ever enable streaming mode on
          mitmproxy, this ``asyncio.to_thread`` offload will silently
          start racing the stream — DO NOT enable streaming without
          revisiting this hook.
        """
        host = "<unknown>"
        try:
            host = flow.request.host

            pending = self._pending.pop(flow.id, None)
            if pending is None:
                return

            # Circuit open → bypass metering for this host. Pending
            # entry has already been popped so memory cannot grow
            # unbounded during a sustained outage.
            if self._is_circuit_open(host):
                log.info("addon.response.circuit_bypass", host=host, flow_id=flow.id)
                return

            request_meta, requested_at = pending
            adapter = find_adapter(host)
            if adapter is None:
                log.warning("addon.response.no_adapter", host=host, flow_id=flow.id)
                return

            # Offload parsing to a worker thread with a hard timeout so
            # a slow/stuck parser cannot stall the mitmproxy event loop.
            try:
                resp_meta = await asyncio.wait_for(
                    asyncio.to_thread(adapter.parse_response, flow, request_meta),
                    timeout=self._get_parse_timeout(host),
                )
            except TimeoutError:
                # asyncio.TimeoutError aliases TimeoutError on 3.11+.
                log.warning("addon.parse_response_timeout", host=host, flow_id=flow.id)
                self._record_parse_timeout(host)
                return  # fail-open — request already returned to client
            # Any other exception falls through to the outer except,
            # which logs and returns — does NOT trip the breaker.

            # Resolve project tag (sync, fast, never raises)
            project = resolve_project(flow)

            # Local fallback cost from the bundled matrix. The repo's
            # write_record path will look up the active pricing_rates row
            # asynchronously and override this when one is found, so the
            # bundled matrix is only used until rates are seeded or for
            # models the matrix knows but the rates table doesn't.
            cost = compute_cost_millicents(
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
            )

            recorded_at = _now_iso()
            record = LogRecord(
                id=str(uuid.uuid4()),
                project=project,
                provider=request_meta.provider,
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
                cost_millicents=cost,
                tokens_complete=resp_meta.tokens_complete,
                latency_ms=resp_meta.latency_ms,
                requested_at=requested_at,
                recorded_at=recorded_at,
            )

            # Write to SQLite asynchronously. We are inside an async
            # hook so plain ``asyncio.create_task`` works (no need to
            # fetch the running loop explicitly). write_record never
            # raises — errors are caught and logged internally.
            if self._storage is not None:
                asyncio.create_task(self._storage.write_record(record))  # noqa: RUF006

            log.info(
                "intercept.complete",
                provider=request_meta.provider,
                model=request_meta.model,
                project=project,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                thinking_tokens=resp_meta.thinking_tokens,
                cache_read_tokens=resp_meta.cache_read_tokens,
                cache_write_tokens=resp_meta.cache_write_tokens,
                tokens_complete=resp_meta.tokens_complete,
                cost_millicents=cost,
                latency_ms=round(resp_meta.latency_ms),
            )

            _print_capture(
                project=project,
                provider=request_meta.provider,
                model=request_meta.model,
                input_tokens=resp_meta.input_tokens,
                output_tokens=resp_meta.output_tokens,
                cost_millicents=cost,
                latency_ms=resp_meta.latency_ms,
            )

        except Exception as exc:
            # Fail-open. NOTE: parse exceptions land here. They do NOT
            # trip the breaker — only timeouts do (see
            # _record_parse_timeout).
            log.error(
                "addon.response.failed",
                host=host,
                error=str(exc),
                exc_info=True,
            )


def _print_capture(
    *,
    project: str,
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    cost_millicents: int | None,
    latency_ms: float,
) -> None:
    """Print a single-line capture summary to stderr."""
    cost_str = _format_cost(cost_millicents)
    print(
        f"[halton-meter] project={project} provider={provider} model={model}"
        f" input={input_tokens} output={output_tokens}"
        f" cost={cost_str} latency={round(latency_ms)}ms",
        file=sys.stderr,
        flush=True,
    )


# ---------------------------------------------------------------------------
# DumpMaster runner
# ---------------------------------------------------------------------------


async def run_proxy(config: HaltonConfig) -> None:
    """
    Start the mitmproxy DumpMaster with HaltonAddon.

    Initialises StorageManager, passes it to HaltonAddon, then blocks until
    Ctrl-C. Shuts down cleanly on interrupt.
    """
    storage = StorageManager(config.storage.db_path)
    await storage.initialise()

    # v0.1.6 (2C.2): the daemon's mitmproxy listener binds the
    # internal_port. The user-facing edge_port is owned by the edge
    # proxy process; apps see edge_port in HTTPS_PROXY and the edge
    # chains CONNECTs through to this internal_port for metering. The
    # internal_port is loopback-only and is never advertised in any
    # env var.
    options = Options(
        listen_host=config.daemon.listen_host,
        listen_port=config.daemon.internal_port,
    )
    master = DumpMaster(options, with_termlog=False, with_dumper=False)
    master.addons.add(HaltonAddon(storage=storage))

    print(
        f"[halton-meter] Daemon proxy (internal) listening on "
        f"http://{config.daemon.listen_host}:{config.daemon.internal_port}",
        file=sys.stderr,
        flush=True,
    )
    print(
        f"[halton-meter] Apps should set HTTPS_PROXY=http://"
        f"{config.daemon.listen_host}:{config.daemon.edge_port} "
        f"(edge proxy chains to this daemon).",
        file=sys.stderr,
        flush=True,
    )
    print("[halton-meter] Press Ctrl-C to stop.", file=sys.stderr, flush=True)

    try:
        await master.run()
    except KeyboardInterrupt:
        master.shutdown()
        print("\n[halton-meter] Stopped.", file=sys.stderr, flush=True)
    finally:
        await storage.close()
