"""``halton-meter run <cmd>`` exec wrapper (v0.1.3 P0-4).

Plug-and-play CLI / SDK metering: spawn an arbitrary command with the
proxy + cert env vars set, so any HTTP client that respects ``HTTPS_PROXY``
and the standard CA-bundle env keys is metered through our daemon. This
is the env-var-only mode's primary user-facing surface — no system proxy
mutation required.

Usage:

    halton-meter run claude                  # meter Claude Code
    halton-meter run -- python my_script.py  # arbitrary command + args
    halton-meter run --shell                 # interactive subshell

Implementation notes:

* The certifi-patched bundle (cert appended by ``setup.patch_certifi``)
  is used as ``NODE_EXTRA_CA_CERTS`` / ``SSL_CERT_FILE`` /
  ``REQUESTS_CA_BUNDLE``. NOT the raw mitmproxy cert: most clients
  expect a bundle that contains the system roots PLUS the mitmproxy CA;
  the patched bundle is exactly that. (Risk callout C in the v0.1.3
  brief.)
* ``NO_PROXY=localhost,127.0.0.1`` is critical — without it, our own
  /health probes would tarpit through the proxy at ourselves.
* Pre-flight: refuse to exec if the daemon's /health endpoint doesn't
  respond within ~3 seconds. Otherwise the user's command would hit the
  proxy address and get connection refused.
* ``os.execvpe`` replaces the Python process with the target so exit
  codes propagate cleanly. Signal handling is inherited (Ctrl-C kills
  the child).
"""

from __future__ import annotations

import os
import urllib.error
import urllib.request
from pathlib import Path

import click

_PREFLIGHT_TIMEOUT_SECONDS = 3.0


def _build_run_env(listen_host: str, listen_port: int, certifi_bundle: Path) -> dict[str, str]:
    """Construct the env-var dict ``halton-meter run`` injects before exec.

    Layered on top of the parent process's environment — caller is
    responsible for merging via ``{**os.environ, **build_run_env(...)}``
    (or via the kwargs accepted by ``os.execvpe``).
    """
    proxy_url = f"http://{listen_host}:{listen_port}"
    bundle = str(certifi_bundle)
    return {
        "HTTPS_PROXY": proxy_url,
        "HTTP_PROXY": proxy_url,
        "NO_PROXY": "localhost,127.0.0.1",
        "NODE_EXTRA_CA_CERTS": bundle,
        "SSL_CERT_FILE": bundle,
        "REQUESTS_CA_BUNDLE": bundle,
        # v0.1.5.1: per-tool CA bundles for clients that don't read
        # SSL_CERT_FILE. git/curl/AWS each have their own env var.
        "GIT_SSL_CAINFO": bundle,
        "CURL_CA_BUNDLE": bundle,
        "AWS_CA_BUNDLE": bundle,
    }


def _preflight_health(api_host: str, api_port: int, timeout: float) -> bool:
    """Return True iff the daemon's /health endpoint returns 200 within
    ``timeout`` seconds. Idempotent and side-effect-free."""
    url = f"http://{api_host}:{api_port}/health"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, ValueError):
        return False


def run_cmd(
    cmd: tuple[str, ...],
    *,
    use_shell: bool = False,
    preflight_timeout: float = _PREFLIGHT_TIMEOUT_SECONDS,
) -> int:
    """Execute ``cmd`` (or the user's $SHELL when ``use_shell=True``) with
    the metering env vars injected.

    Returns the exit code of a refusal path; on success this function
    does NOT return — ``os.execvpe`` replaces the current process.
    """
    from halton_meter.port_alloc import load_effective_config
    from halton_meter.setup import _certifi_bundle_path

    cfg = load_effective_config()
    listen_host = cfg.daemon.listen_host
    # v0.1.6: the run wrapper injects ``HTTPS_PROXY`` pointing at the
    # user-facing proxy port (now ``edge_port``). W4 keeps env-var
    # generation locked to ``edge_port`` — never ``internal_port``.
    listen_port = int(cfg.daemon.edge_port)
    api_host = cfg.daemon.api_host
    api_port = int(cfg.daemon.api_port)

    if not _preflight_health(api_host, api_port, preflight_timeout):
        # v0.1.5 (2B.16): mode-aware refusal hint. In apps/full mode
        # the user might not have realised the daemon needs to be
        # running for `run` to inject the env vars (the global env
        # block in their shell is independent of the daemon process).
        from halton_meter.init import (
            MODE_APPS,
            MODE_FULL,
            read_install_mode,
        )

        mode = read_install_mode()
        mode_hint = ""
        if mode in (MODE_APPS, MODE_FULL):
            mode_hint = (
                f"\n  (You're in --{mode} mode — your global env vars "
                "are still set in new shells, but `halton-meter run` "
                "needs the daemon up to inject env vars + verify a "
                "live cert bundle.)"
            )
        click.echo(
            "[halton-meter run] daemon not responding on "
            f"http://{api_host}:{api_port}/health within "
            f"{preflight_timeout:.0f}s.\n"
            "  Run [bold]halton-meter init[/bold] (first time) or "
            "[bold]halton-meter start[/bold] to (re)start the daemon, then\n"
            "  retry [bold]halton-meter run ...[/bold]." + mode_hint,
            err=True,
        )
        return 1

    # Build env BEFORE we decide what to exec, so the env build error path
    # produces a clean message rather than a half-execed child.
    try:
        bundle = _certifi_bundle_path()
    except Exception as exc:
        click.echo(
            f"[halton-meter run] could not locate certifi bundle: {exc}\n"
            "  Run [bold]halton-meter setup[/bold] to install / repair the "
            "patched bundle.",
            err=True,
        )
        return 2
    env_overrides = _build_run_env(listen_host, listen_port, bundle)
    merged_env = {**os.environ, **env_overrides}

    if use_shell:
        shell = os.environ.get("SHELL")
        if not shell:
            click.echo(
                "[halton-meter run --shell] $SHELL is not set; cannot "
                "spawn a subshell.",
                err=True,
            )
            return 3
        argv = [shell]
    else:
        if not cmd:
            click.echo(
                "[halton-meter run] missing command. "
                "Try [bold]halton-meter run claude[/bold] or "
                "[bold]halton-meter run --shell[/bold].",
                err=True,
            )
            return 4
        argv = list(cmd)

    # os.execvpe replaces this process with the child; exit codes
    # propagate through the OS. Per the brief, this is the clean exit-
    # code-propagation path.
    try:
        os.execvpe(argv[0], argv, merged_env)
    except FileNotFoundError:
        click.echo(
            f"[halton-meter run] command not found: {argv[0]}",
            err=True,
        )
        return 127
    except OSError as exc:
        click.echo(
            f"[halton-meter run] failed to exec {argv[0]}: {exc}",
            err=True,
        )
        return 126

    # Unreachable on a successful exec — but keep mypy happy.
    return 0  # pragma: no cover
