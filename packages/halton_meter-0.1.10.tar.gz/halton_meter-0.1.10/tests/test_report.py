"""
Tests for halton_meter.report — formatting and aggregation logic.

All tests use fixture LogRecords; no live DB required.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from rich.console import Console

from halton_meter.models import LogRecord
from halton_meter.report import (
    build_report_data,
    filter_records_by_days,
    format_usd,
    render_report,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_record(
    *,
    project: str = "test-project",
    model: str = "claude-haiku-4-5",
    input_tokens: int = 100,
    output_tokens: int = 50,
    cost_millicents: int | None = 10,
    tokens_complete: bool = True,
    latency_ms: float = 500.0,
    requested_at: str | None = None,
) -> LogRecord:
    """Construct a minimal LogRecord for testing."""
    if requested_at is None:
        # Use a recent timestamp so it passes any default since_days filter
        ts = datetime.now(UTC).isoformat().replace("+00:00", "Z")
        requested_at = ts
    return LogRecord(
        id="test-id",
        project=project,
        provider="anthropic",
        model=model,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        cost_millicents=cost_millicents,
        tokens_complete=tokens_complete,
        latency_ms=latency_ms,
        requested_at=requested_at,
        recorded_at=requested_at,
    )


# ---------------------------------------------------------------------------
# format_usd
# ---------------------------------------------------------------------------


class TestFormatUsd:
    def test_zero(self) -> None:
        assert format_usd(0) == "$0.000000"

    def test_sub_cent_4_millicents(self) -> None:
        # 4 millicents = 4/100_000 USD = $0.000040 — must NOT round to $0.0000
        assert format_usd(4) == "$0.000040"

    def test_sub_cent_5_millicents(self) -> None:
        # 5 millicents = 5/100_000 USD = $0.000050
        assert format_usd(5) == "$0.000050"

    def test_one_cent(self) -> None:
        # 1 cent = 1_000 millicents (since 1 USD = 100 cents = 100_000 millicents)
        assert format_usd(1_000) == "$0.010000"

    def test_one_dollar(self) -> None:
        # 1 USD = 100_000 millicents
        assert format_usd(100_000) == "$1.000000"

    def test_none_returns_na(self) -> None:
        assert format_usd(None) == "N/A"

    def test_large_amount(self) -> None:
        # $54.32 = 5_432_000 millicents
        result = format_usd(5_432_000)
        assert result == "$54.320000"


# ---------------------------------------------------------------------------
# build_report_data — empty
# ---------------------------------------------------------------------------


class TestBuildReportDataEmpty:
    def test_empty_records(self) -> None:
        data = build_report_data([])
        assert data.total_requests == 0
        assert data.total_input_tokens == 0
        assert data.total_output_tokens == 0
        assert data.total_cost_millicents == 0
        assert data.date_from is None
        assert data.date_to is None
        assert data.incomplete_count == 0
        assert data.project_stats == []
        assert data.model_stats == []


# ---------------------------------------------------------------------------
# build_report_data — single record
# ---------------------------------------------------------------------------


class TestBuildReportDataSingle:
    def test_totals(self) -> None:
        rec = _make_record(input_tokens=20, output_tokens=5, cost_millicents=4)
        data = build_report_data([rec])
        assert data.total_requests == 1
        assert data.total_input_tokens == 20
        assert data.total_output_tokens == 5
        assert data.total_cost_millicents == 4

    def test_project_stats(self) -> None:
        rec = _make_record(
            project="smoke-test", input_tokens=20, output_tokens=5, cost_millicents=4
        )
        data = build_report_data([rec])
        assert len(data.project_stats) == 1
        ps = data.project_stats[0]
        assert ps.project == "smoke-test"
        assert ps.requests == 1
        assert ps.input_tokens == 20
        assert ps.output_tokens == 5
        assert ps.cost_millicents == 4

    def test_model_stats(self) -> None:
        rec = _make_record(
            model="claude-haiku-4-5", input_tokens=20, output_tokens=5, cost_millicents=4
        )
        data = build_report_data([rec])
        assert len(data.model_stats) == 1
        ms = data.model_stats[0]
        assert ms.model == "claude-haiku-4-5"
        assert ms.requests == 1

    def test_tokens_complete_flag(self) -> None:
        rec = _make_record(tokens_complete=False)
        data = build_report_data([rec])
        assert data.incomplete_count == 1


# ---------------------------------------------------------------------------
# build_report_data — multiple records
# ---------------------------------------------------------------------------


class TestBuildReportDataMultiple:
    def test_two_records_same_project(self) -> None:
        """Smoke-test scenario: two records matching the live DB state."""
        r1 = _make_record(
            project="smoke-test",
            model="claude-haiku-4-5",
            input_tokens=20,
            output_tokens=5,
            cost_millicents=4,
        )
        r2 = _make_record(
            project="smoke-test",
            model="claude-haiku-4-5",
            input_tokens=15,
            output_tokens=8,
            cost_millicents=5,
        )
        data = build_report_data([r1, r2])

        assert data.total_requests == 2
        assert data.total_input_tokens == 35
        assert data.total_output_tokens == 13
        assert data.total_cost_millicents == 9

        # One project bucket
        assert len(data.project_stats) == 1
        ps = data.project_stats[0]
        assert ps.requests == 2
        assert ps.input_tokens == 35
        assert ps.cost_millicents == 9

        # One model bucket
        assert len(data.model_stats) == 1

    def test_two_projects(self) -> None:
        r1 = _make_record(project="alpha", cost_millicents=10)
        r2 = _make_record(project="beta", cost_millicents=20)
        data = build_report_data([r1, r2])

        assert data.total_requests == 2
        assert data.total_cost_millicents == 30
        projects = {ps.project for ps in data.project_stats}
        assert projects == {"alpha", "beta"}

    def test_two_models(self) -> None:
        r1 = _make_record(model="claude-haiku-4-5", cost_millicents=5)
        r2 = _make_record(model="claude-sonnet-4-6", cost_millicents=15)
        data = build_report_data([r1, r2])

        assert len(data.model_stats) == 2
        models = {ms.model for ms in data.model_stats}
        assert models == {"claude-haiku-4-5", "claude-sonnet-4-6"}

    def test_none_cost_propagates(self) -> None:
        r1 = _make_record(cost_millicents=10)
        r2 = _make_record(cost_millicents=None)  # unknown model
        data = build_report_data([r1, r2])
        assert data.total_cost_millicents is None

    def test_avg_latency(self) -> None:
        r1 = _make_record(latency_ms=100.0)
        r2 = _make_record(latency_ms=300.0)
        data = build_report_data([r1, r2])
        ps = data.project_stats[0]
        assert ps.avg_latency_ms == pytest.approx(200.0)

    def test_date_range(self) -> None:
        r1 = _make_record(requested_at="2026-04-27T10:00:00Z")
        r2 = _make_record(requested_at="2026-04-28T12:00:00Z")
        data = build_report_data([r1, r2])
        assert data.date_from == "2026-04-27T10:00:00Z"
        assert data.date_to == "2026-04-28T12:00:00Z"


# ---------------------------------------------------------------------------
# filter_records_by_days
# ---------------------------------------------------------------------------


class TestFilterRecordsByDays:
    def _recent_iso(self, hours_ago: float = 1.0) -> str:
        dt = datetime.now(UTC) - timedelta(hours=hours_ago)
        return dt.isoformat().replace("+00:00", "Z")

    def _old_iso(self, days_ago: float = 60.0) -> str:
        dt = datetime.now(UTC) - timedelta(days=days_ago)
        return dt.isoformat().replace("+00:00", "Z")

    def test_since_zero_returns_empty(self) -> None:
        rec = _make_record(requested_at=self._recent_iso())
        assert filter_records_by_days([rec], 0) == []

    def test_since_negative_returns_empty(self) -> None:
        rec = _make_record(requested_at=self._recent_iso())
        assert filter_records_by_days([rec], -5) == []

    def test_recent_record_included(self) -> None:
        rec = _make_record(requested_at=self._recent_iso(hours_ago=2))
        result = filter_records_by_days([rec], since_days=30)
        assert len(result) == 1

    def test_old_record_excluded(self) -> None:
        rec = _make_record(requested_at=self._old_iso(days_ago=60))
        result = filter_records_by_days([rec], since_days=30)
        assert len(result) == 0

    def test_since_1_includes_today(self) -> None:
        rec = _make_record(requested_at=self._recent_iso(hours_ago=0.5))
        result = filter_records_by_days([rec], since_days=1)
        assert len(result) == 1

    def test_mixed_records(self) -> None:
        recent = _make_record(requested_at=self._recent_iso())
        old = _make_record(requested_at=self._old_iso())
        result = filter_records_by_days([recent, old], since_days=30)
        assert len(result) == 1
        assert result[0].requested_at == recent.requested_at

    def test_empty_input(self) -> None:
        assert filter_records_by_days([], since_days=30) == []


# ---------------------------------------------------------------------------
# render_report — smoke tests (just check it doesn't crash)
# ---------------------------------------------------------------------------


class TestRenderReport:
    def _console(self) -> Console:
        """Return a Console that captures output instead of printing to stdout."""
        return Console(record=True, width=120)

    def test_renders_empty(self) -> None:
        c = self._console()
        data = build_report_data([])
        render_report(data, c)
        output = c.export_text()
        # Empty state still shows the brand header and a guidance line
        assert "halton-meter" in output
        assert "no records yet" in output
        # 2B.12.1: never recommend the dev-mode `halton-meter daemon`
        # command in user-facing CLI output. Default-empty hint must
        # point at `halton-meter start`.
        assert "halton-meter daemon" not in output
        assert "halton-meter start" in output

    def test_renders_empty_with_custom_hint(self) -> None:
        """Caller-supplied ``empty_hint`` overrides the default guidance line."""
        c = self._console()
        data = build_report_data([])
        render_report(data, c, empty_hint="custom guidance for empty state")
        output = c.export_text()
        assert "custom guidance for empty state" in output
        assert "no records yet" not in output

    def test_renders_two_smoke_records(self) -> None:
        """The two records in the live DB should render without error."""
        r1 = _make_record(
            project="smoke-test",
            model="claude-haiku-4-5",
            input_tokens=20,
            output_tokens=5,
            cost_millicents=4,
        )
        r2 = _make_record(
            project="smoke-test",
            model="claude-haiku-4-5",
            input_tokens=15,
            output_tokens=8,
            cost_millicents=5,
        )
        c = self._console()
        data = build_report_data([r1, r2])
        render_report(data, c)
        output = c.export_text()
        # Brand header + cost report label
        assert "halton-meter" in output
        assert "cost report" in output
        # Cost shows 6dp precision — not $0.0000
        # 4+5=9 millicents = 9/100_000 USD = $0.000090
        assert "$0.000090" in output
        # Project and model tables present
        assert "smoke-test" in output
        assert "claude-haiku-4-5" in output

    def test_cost_6dp_not_zero(self) -> None:
        """Key requirement: sub-cent costs must not display as $0.0000."""
        r1 = _make_record(cost_millicents=4)
        r2 = _make_record(cost_millicents=5)
        c = self._console()
        data = build_report_data([r1, r2])
        render_report(data, c)
        output = c.export_text()
        # Must not round to $0.0000 — 4+5=9 millicents = 9/100_000 USD = $0.000090
        assert "$0.000090" in output
        # Must contain a $ sign with non-zero value at 6dp
        assert "$0.000000" not in output

    def test_incomplete_records_flagged(self) -> None:
        rec = _make_record(tokens_complete=False, cost_millicents=10)
        c = self._console()
        data = build_report_data([rec])
        render_report(data, c)
        output = c.export_text()
        assert "incomplete" in output.lower()

    def test_unknown_model_cost_na(self) -> None:
        rec = _make_record(cost_millicents=None)
        c = self._console()
        data = build_report_data([rec])
        render_report(data, c)
        output = c.export_text()
        assert "N/A" in output
