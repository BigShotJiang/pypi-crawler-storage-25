"""Cost-path symmetry tests for ``halton_meter.api.services.ingest``.

P0-4 wires both cost paths through the shared
``halton_meter.pricing.apply_rates`` helper:

  * Bundled-matrix path: ``compute_cost_millicents`` (proxy hot path).
  * Rates-table path: ``compute_cost_from_rate`` + ``recompute_cost``
    (canonical price authority once a ``pricing_rates`` row matches).

These tests assert that:

1. The two paths produce **bit-identical** millicent values for the
   same token set and rate values — no per-line truncation drift, no
   missing cache-write term. This is the load-bearing acceptance test
   for the P0-4 refactor.
2. ``recompute_cost`` reproduces the P0-3 golden hand-computed cost
   when run against a seeded ``pricing_rates`` row, exercising the
   rates-table path end-to-end (rate lookup → ``apply_rates`` →
   millicents).

Tests are unit-level: they construct a ``PricingRate`` directly or seed
the bundled matrix into a per-test SQLite file. No HTTP client needed —
HTTP-level ingest behaviour is covered in ``tests/api/test_ingest.py``.

See memory/plans/2026-04-30-daemon-audit-remediation.md (P0-4) for
context.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest
import pytest_asyncio

from halton_meter.api.services.ingest import (
    compute_cost_from_rate,
    recompute_cost,
)
from halton_meter.pricing import compute_cost_millicents
from halton_meter.pricing.matrix import ANTHROPIC_RATES
from halton_meter.storage import init_db, seed_pricing_rates
from halton_meter.storage.engine import _ENGINES, create_engine_for, dispose_engines
from halton_meter.storage.models import PricingRate


@pytest.fixture(autouse=True)
def _reset_engine_cache():
    _ENGINES.clear()
    yield
    _ENGINES.clear()


@pytest_asyncio.fixture
async def seeded_db(tmp_path: Path):
    """Per-test SQLite file with schema + bundled pricing rates seeded."""
    p = tmp_path / "ingest-test.sqlite"
    engine, sessionmaker = create_engine_for(p)
    await init_db(engine)
    async with sessionmaker() as session:
        await seed_pricing_rates(session)
    yield sessionmaker
    await dispose_engines()


def _matrix_rate_to_pricing_rate(model: str, mode: str = "standard") -> PricingRate:
    """Construct an in-memory ``PricingRate`` whose values exactly mirror
    the bundled matrix entry for ``model``. Used to drive the bit-identical
    cost comparison without hitting the database.
    """
    rates = ANTHROPIC_RATES[model]
    output_rate = rates.thinking if mode == "thinking" else rates.output
    return PricingRate(
        id="test-rate",
        provider="anthropic",
        model=model,
        mode=mode,
        effective_from=datetime(1970, 1, 1, tzinfo=UTC),
        effective_to=None,
        input_rate_per_million_minor_units=rates.input,
        output_rate_per_million_minor_units=output_rate,
        thinking_rate_per_million_minor_units=rates.thinking,
        cache_read_rate_per_million_minor_units=rates.cache_read,
        cache_write_rate_per_million_minor_units=rates.cache_write,
        last_verified_at=None,
    )


# ---------------------------------------------------------------------------
# Bit-identical proxy-vs-ingest cost across paths
# ---------------------------------------------------------------------------


def test_proxy_and_ingest_paths_are_bit_identical_for_same_inputs() -> None:
    """The bundled-matrix path and the rates-table path must agree to the
    millicent for the same token set + rate values, since both now route
    through the shared ``apply_rates`` helper.

    A drift here would mean either (a) one path is still using a per-line
    ``// 1_000_000`` formula, (b) one path is missing a rate term (e.g.
    ``cache_write`` was the original P0-3/P0-4 bug), or (c) one path has
    an off-by-one in kwarg threading. Any of those is a cost-correctness
    regression and must fail this test loud.
    """
    model = "claude-sonnet-4-6"

    # Same token set used by the P0-3 golden test — exercises every line item.
    tokens = {
        "input_tokens": 12_345,
        "output_tokens": 6_789,
        "thinking_tokens": 2_500,
        "cache_read_tokens": 98_765,
        "cache_write_tokens": 4_321,
    }

    # Bundled-matrix path (proxy hot path)
    proxy_cost = compute_cost_millicents(model=model, **tokens)

    # Rates-table path (ingest / recompute_cost path) — driven by a
    # PricingRate whose values exactly mirror the matrix entry.
    rate = _matrix_rate_to_pricing_rate(model)
    ingest_cost = compute_cost_from_rate(rate, **tokens)

    # Sanity: P0-3 golden value is preserved on the matrix path.
    assert proxy_cost == 22_220
    # Load-bearing assertion for P0-4.
    assert proxy_cost == ingest_cost


def test_bit_identical_under_truncation_edge_case() -> None:
    """Truncation edge case (small per-line products) must also agree.

    Reuses the P0-3 sum-first-vs-per-line test vector on
    ``claude-haiku-4-5``: every per-line product is < 1_000_000, so a
    drifting per-line implementation in either path would return 0
    while the correct sum-first total is 3 millicents. Asserts both
    paths return the same 3.
    """
    model = "claude-haiku-4-5"
    tokens = {
        "input_tokens": 9,
        "output_tokens": 1,
        "thinking_tokens": 1,
        "cache_read_tokens": 99,
        "cache_write_tokens": 7,
    }

    proxy_cost = compute_cost_millicents(model=model, **tokens)
    rate = _matrix_rate_to_pricing_rate(model)
    ingest_cost = compute_cost_from_rate(rate, **tokens)

    assert proxy_cost == 3
    assert proxy_cost == ingest_cost


def test_bit_identical_with_default_cache_write() -> None:
    """The ``cache_write_tokens=0`` default must agree on both paths."""
    model = "claude-opus-4-7"
    common = {
        "input_tokens": 1_000,
        "output_tokens": 500,
        "thinking_tokens": 0,
        "cache_read_tokens": 250,
    }

    proxy_cost = compute_cost_millicents(model=model, **common)
    rate = _matrix_rate_to_pricing_rate(model)
    ingest_cost = compute_cost_from_rate(rate, **common)

    assert proxy_cost is not None
    assert proxy_cost == ingest_cost


# ---------------------------------------------------------------------------
# recompute_cost golden test (rates-table path end-to-end)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_recompute_cost_golden_matches_p03_hand_computed_value(
    seeded_db,
) -> None:
    """End-to-end ``recompute_cost`` golden test against the seeded rates.

    Mirrors the P0-3 ``compute_cost_millicents`` golden test (same token
    set, same model) but goes through the full rates-table path:
    ``recompute_cost`` looks up the active ``pricing_rates`` row in
    SQLite, then calls ``compute_cost_from_rate`` -> ``apply_rates``.
    The expected millicent value (22_220) is identical because the
    seed populates ``pricing_rates`` from the bundled matrix.

    A failure here means the rates-table cost path drifted from the
    bundled-matrix cost path — typically a missing kwarg, a schema
    column rename gone wrong, or a regression of P0-3's sum-first fix
    inside ``apply_rates``.
    """
    sessionmaker = seeded_db
    async with sessionmaker() as session:
        cost, rate = await recompute_cost(
            session=session,
            provider="anthropic",
            model="claude-sonnet-4-6",
            mode="standard",
            requested_at=datetime(2026, 4, 30, 12, 0, 0, tzinfo=UTC),
            input_tokens=12_345,
            output_tokens=6_789,
            thinking_tokens=2_500,
            cache_read_tokens=98_765,
            cache_write_tokens=4_321,
            fallback=None,
        )

    assert rate is not None, "seeded pricing_rates row should match"
    assert cost == 22_220


@pytest.mark.asyncio
async def test_recompute_cost_falls_back_when_rate_missing(seeded_db) -> None:
    """Unknown ``(provider, model)`` -> fallback returned, no rate matched.

    Guards against a regression where ``recompute_cost`` either raises
    or returns a wrong-but-non-None cost when the rates table has no
    matching row.
    """
    sessionmaker = seeded_db
    async with sessionmaker() as session:
        cost, rate = await recompute_cost(
            session=session,
            provider="anthropic",
            model="not-a-real-model",
            mode="standard",
            requested_at=datetime(2026, 4, 30, 12, 0, 0, tzinfo=UTC),
            input_tokens=1_000,
            output_tokens=1_000,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
            fallback=42_000,
        )

    assert rate is None
    assert cost == 42_000


@pytest.mark.asyncio
async def test_recompute_cost_applies_cache_write_rate(seeded_db) -> None:
    """The ``cache_write_tokens`` kwarg must be priced via the rates-table
    ``cache_write_rate_per_million_minor_units`` column.

    P0-1 added the column; P0-3 added the kwarg + rate term in the
    bundled-matrix path; P0-4 wires the same kwarg + rate term through
    the rates-table path. Without that wiring, this test would see
    ``with_writes == base`` — the kwarg silently dropped — and fail.
    """
    sessionmaker = seeded_db
    common: dict[str, object] = {
        "provider": "anthropic",
        "model": "claude-opus-4-7",
        "mode": "standard",
        "requested_at": datetime(2026, 4, 30, 12, 0, 0, tzinfo=UTC),
        "input_tokens": 1_000,
        "output_tokens": 500,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "fallback": None,
    }
    async with sessionmaker() as session:
        base, _ = await recompute_cost(session=session, cache_write_tokens=0, **common)
        with_writes, _ = await recompute_cost(
            session=session, cache_write_tokens=10_000, **common
        )

    assert base is not None and with_writes is not None
    rates = ANTHROPIC_RATES["claude-opus-4-7"]
    expected_delta = 10_000 * rates.cache_write // 1_000_000
    assert with_writes - base == expected_delta
