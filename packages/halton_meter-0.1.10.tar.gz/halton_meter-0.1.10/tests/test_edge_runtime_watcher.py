"""Gap 10 (v0.1.8) — edge polls ``runtime.toml`` and re-resolves the
chain target the instant it changes, with zero failed CONNECTs.

Pre-fix (v0.1.7 Gap 0): the edge only re-resolved its ``internal_port``
AFTER a chain attempt observed ``ConnectionRefusedError``. Correct, but
it cost one failed CONNECT per port change. Gap 10 closes that window.

Tests intentionally use a short ``poll_interval_s`` (50 ms) so the
suite stays fast.
"""

from __future__ import annotations

import asyncio
import contextlib
from pathlib import Path

from halton_meter.edge import EdgeConfig, EdgeProxy
from halton_meter.port_alloc import _write_runtime_toml
from tests.test_edge import FakeDaemon


async def _wait_until(predicate, timeout_s: float = 2.0, step_s: float = 0.02) -> bool:
    """Poll ``predicate`` until True or timeout. Returns the final value."""
    deadline = asyncio.get_event_loop().time() + timeout_s
    while asyncio.get_event_loop().time() < deadline:
        if predicate():
            return True
        await asyncio.sleep(step_s)
    return predicate()


async def test_runtime_watcher_reresolves_on_file_change(tmp_path: Path) -> None:
    """Watcher picks up a runtime.toml rewrite without any chain traffic.

    The plan-mandated integration shape: write runtime.toml with
    internal_port=A, start the edge + watcher, atomically rewrite to
    internal_port=B, assert the edge's chain target updates within ~2s
    with NO chain attempt happening in between.
    """
    daemon_a = FakeDaemon()
    daemon_b = FakeDaemon()
    port_a = await daemon_a.start()
    port_b = await daemon_b.start()
    runtime_path = tmp_path / "runtime.toml"
    _write_runtime_toml(
        runtime_path, edge_port=8081, internal_port=port_a, api_port=8765
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=port_a,
        runtime_path=runtime_path,
    )
    edge = EdgeProxy(config)
    await edge.start()
    watch_task = asyncio.create_task(edge.watch_runtime_toml(poll_interval_s=0.05))
    try:
        assert edge._config.internal_port == port_a

        # Atomic rewrite (mimics port_alloc's _write_runtime_toml — uses
        # os.replace under the hood).
        _write_runtime_toml(
            runtime_path, edge_port=8081, internal_port=port_b, api_port=8765
        )

        ok = await _wait_until(
            lambda: edge._config.internal_port == port_b, timeout_s=2.0
        )
        assert ok, (
            f"watcher did not re-resolve within 2s; "
            f"internal_port still {edge._config.internal_port}, expected {port_b}"
        )
        # The cache must also have been re-pointed and invalidated.
        assert edge.health_cache.internal_port == port_b
    finally:
        watch_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await watch_task
        await edge.stop()
        await daemon_a.stop()
        await daemon_b.stop()


async def test_runtime_watcher_no_op_when_path_unset(tmp_path: Path) -> None:
    """With ``runtime_path=None`` the watcher returns immediately."""
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=8090,
        runtime_path=None,
    )
    edge = EdgeProxy(config)
    # Returns straight away — no infinite loop, no exception.
    await asyncio.wait_for(edge.watch_runtime_toml(poll_interval_s=0.01), timeout=1.0)


async def test_runtime_watcher_survives_missing_then_recreated_file(
    tmp_path: Path,
) -> None:
    """Watcher tolerates a runtime.toml that doesn't exist yet, then appears.

    Daemon-restart racing edge-startup: edge wakes up, runtime.toml is
    momentarily absent, daemon writes it. Watcher must not crash and
    must pick up the new file on the next tick.
    """
    runtime_path = tmp_path / "runtime.toml"
    # File deliberately absent at start.
    daemon_a = FakeDaemon()
    port_a = await daemon_a.start()
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=9999,  # placeholder — runtime.toml will dictate
        runtime_path=runtime_path,
    )
    edge = EdgeProxy(config)
    watch_task = asyncio.create_task(edge.watch_runtime_toml(poll_interval_s=0.05))
    try:
        # Sleep past one poll iteration with the file missing — must not crash.
        await asyncio.sleep(0.2)
        assert not watch_task.done(), watch_task.exception() if watch_task.done() else None

        _write_runtime_toml(
            runtime_path, edge_port=8081, internal_port=port_a, api_port=8765
        )
        ok = await _wait_until(
            lambda: edge._config.internal_port == port_a, timeout_s=2.0
        )
        assert ok
    finally:
        watch_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await watch_task
        await daemon_a.stop()


async def test_runtime_watcher_idle_when_file_unchanged(tmp_path: Path) -> None:
    """No re-resolve fires when runtime.toml's mtime/size are stable."""
    daemon_a = FakeDaemon()
    port_a = await daemon_a.start()
    runtime_path = tmp_path / "runtime.toml"
    _write_runtime_toml(
        runtime_path, edge_port=8081, internal_port=port_a, api_port=8765
    )
    config = EdgeConfig(
        edge_host="127.0.0.1",
        edge_port=0,
        internal_host="127.0.0.1",
        internal_port=port_a,
        runtime_path=runtime_path,
    )
    edge = EdgeProxy(config)
    call_count = {"n": 0}
    real = edge._maybe_reresolve_chain_target

    def _spy() -> bool:
        call_count["n"] += 1
        return real()

    edge._maybe_reresolve_chain_target = _spy  # type: ignore[method-assign]

    watch_task = asyncio.create_task(edge.watch_runtime_toml(poll_interval_s=0.05))
    try:
        await asyncio.sleep(0.3)  # ~6 poll ticks
        # The watcher always does ONE initial reconcile on entry (in
        # case runtime.toml was rewritten between EdgeConfig construction
        # and watcher start). After that, with the file unchanged, no
        # further reconcile must fire.
        assert call_count["n"] == 1
    finally:
        watch_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await watch_task
        await daemon_a.stop()
