"""Fail-open contract test for ``HaltonAddon.response`` (PR 7 P2-1).

CLAUDE.md critical principle: errors on the proxy hot path must NEVER
escape — the developer's request must always fall through unaffected.
P2-1 widened the ``response()`` try-block boundary to include the two
lines that previously ran outside it (``flow.request.host`` access and
``self._pending.pop``). This test pins that contract: when the very
first formerly-uncovered line raises, the addon catches and logs, does
not re-raise, and leaves the flow's response untouched so mitmproxy
forwards it normally.
"""

from __future__ import annotations

import uuid
from unittest.mock import patch

import pytest
from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.proxy import HaltonAddon


class _RaisingRequestProxy:
    """Stand-in for ``flow.request`` whose ``.host`` access raises.

    Exercises the formerly-uncovered first line of ``response()``:
    ``host = flow.request.host``.
    """

    def __init__(self, real_request: http.Request) -> None:
        self._real = real_request

    @property
    def host(self) -> str:
        raise RuntimeError("synthetic host-access failure")

    def __getattr__(self, name: str) -> object:
        return getattr(self._real, name)


@pytest.mark.asyncio
async def test_response_hot_path_fails_open_when_pre_try_lines_raise() -> None:
    """The two lines that used to live outside the try block —
    ``flow.request.host`` and ``self._pending.pop`` — must now be
    covered. We exercise the first of them by making ``.host`` raise
    and assert: (a) the exception is caught (response() does not
    raise), (b) the request's response body is untouched so
    mitmproxy forwards it unchanged, (c) the failure is logged via
    ``addon.response.failed`` with the safe ``<unknown>`` host
    placeholder.
    """
    req = tutils.treq(host="api.anthropic.com", port=443, path="/v1/messages")
    flow = tflow.tflow(req=req)
    flow.id = str(uuid.uuid4())
    flow.response = http.Response.make(
        200,
        b'{"usage": {"input_tokens": 1, "output_tokens": 1}}',
        {"Content-Type": "application/json"},
    )
    original_body = flow.response.content

    addon = HaltonAddon(storage=None)
    flow.request = _RaisingRequestProxy(flow.request)  # type: ignore[assignment]

    with patch("halton_meter.proxy.log") as mock_log:
        # (a) Must not raise. This is the fail-open guarantee.
        await addon.response(flow)

    # (b) The response body the user receives is unchanged.
    assert flow.response.content == original_body

    # (c) The except-branch fired with the safe host placeholder. If
    # this line were still outside the try, the test would error out
    # at addon.response(flow) above.
    calls = [
        c
        for c in mock_log.error.call_args_list
        if c.args and c.args[0] == "addon.response.failed"
    ]
    assert calls, (
        f"expected addon.response.failed log; got {mock_log.error.call_args_list}"
    )
    assert calls[0].kwargs.get("host") == "<unknown>"
