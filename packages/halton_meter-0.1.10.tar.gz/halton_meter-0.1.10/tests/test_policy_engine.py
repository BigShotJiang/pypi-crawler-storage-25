"""Tests for the policy evaluation engine."""

from __future__ import annotations

from halton_meter.policy_engine import evaluate_policies


def _budget_policy(
    limit_usd: float = 100.0,
    warn_only: bool = True,
    policy_id: str = "p-budget",
) -> dict:
    return {
        "id": policy_id,
        "type": "budget_monthly",
        "config": {"limit_usd": limit_usd},
        "warn_only": warn_only,
    }


def _allow_list_policy(
    allowed_models: list[str] | None = None,
    warn_only: bool = True,
    policy_id: str = "p-allowlist",
) -> dict:
    return {
        "id": policy_id,
        "type": "model_allow_list",
        "config": {"allowed_models": allowed_models or ["claude-sonnet-4-6"]},
        "warn_only": warn_only,
    }


def _rate_policy(
    limit: int = 10,
    warn_only: bool = True,
    policy_id: str = "p-rate",
) -> dict:
    return {
        "id": policy_id,
        "type": "requests_per_day",
        "config": {"limit": limit},
        "warn_only": warn_only,
    }


# ── budget_monthly ────────────────────────────────────────────────────────────


def test_budget_policy_under_limit_allows():
    """Budget below threshold → allow."""
    policies = [_budget_policy(limit_usd=100.0)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="claude-sonnet-4-6",
        running_total_millicents=50_000,  # $0.50 — well under $100
        requests_today=1,
    )
    assert decision.action == "allow"


def test_budget_policy_at_80_pct_warns():
    """Budget at exactly 80% → warn regardless of warn_only."""
    # $100 limit; 80% = $80 = 8_000_000 millicents
    limit_usd = 100.0
    running = int(limit_usd * 100_000 * 0.8)

    for warn_only in (True, False):
        policies = [_budget_policy(limit_usd=limit_usd, warn_only=warn_only)]
        decision = evaluate_policies(
            policies=policies,
            project="proj",
            model="m",
            running_total_millicents=running,
            requests_today=0,
        )
        assert decision.action == "warn", f"Expected warn at 80%, warn_only={warn_only}"


def test_budget_policy_at_100_pct_warn_only_warns():
    """Budget at 100%, warn_only=True → warn (not block)."""
    limit_usd = 50.0
    running = int(limit_usd * 100_000)  # exactly at limit
    policies = [_budget_policy(limit_usd=limit_usd, warn_only=True)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=running,
        requests_today=0,
    )
    assert decision.action == "warn"


def test_budget_policy_at_100_pct_hard_block_blocks():
    """Budget at 100%, warn_only=False → block."""
    limit_usd = 50.0
    running = int(limit_usd * 100_000)
    policies = [_budget_policy(limit_usd=limit_usd, warn_only=False)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=running,
        requests_today=0,
    )
    assert decision.action == "block"
    assert decision.policy_id == "p-budget"


def test_budget_policy_over_limit_hard_block():
    """Budget exceeded (over 100%), warn_only=False → block."""
    limit_usd = 10.0
    running = int(limit_usd * 100_000) + 1  # one millicent over
    policies = [_budget_policy(limit_usd=limit_usd, warn_only=False)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=running,
        requests_today=0,
    )
    assert decision.action == "block"


# ── model_allow_list ──────────────────────────────────────────────────────────


def test_allow_list_allowed_model_passes():
    """Allowed model → allow."""
    policies = [_allow_list_policy(allowed_models=["claude-sonnet-4-6", "claude-haiku-4-5"])]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="claude-sonnet-4-6",
        running_total_millicents=0,
        requests_today=0,
    )
    assert decision.action == "allow"


def test_allow_list_blocked_model_warn_only():
    """Blocked model, warn_only=True → warn."""
    policies = [_allow_list_policy(allowed_models=["claude-haiku-4-5"], warn_only=True)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="claude-opus-4-7",
        running_total_millicents=0,
        requests_today=0,
    )
    assert decision.action == "warn"
    assert "claude-opus-4-7" in (decision.reason or "")


def test_allow_list_blocked_model_hard_block():
    """Blocked model, warn_only=False → block."""
    policies = [_allow_list_policy(allowed_models=["claude-haiku-4-5"], warn_only=False)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="claude-opus-4-7",
        running_total_millicents=0,
        requests_today=0,
    )
    assert decision.action == "block"


# ── requests_per_day ──────────────────────────────────────────────────────────


def test_rate_policy_under_limit_allows():
    """Requests under daily limit → allow."""
    policies = [_rate_policy(limit=100, warn_only=True)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=0,
        requests_today=50,
    )
    assert decision.action == "allow"


def test_rate_policy_at_limit_warn_only():
    """Requests at daily limit, warn_only=True → warn."""
    policies = [_rate_policy(limit=10, warn_only=True)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=0,
        requests_today=10,
    )
    assert decision.action == "warn"


def test_rate_policy_at_limit_hard_block():
    """Requests at daily limit, warn_only=False → block."""
    policies = [_rate_policy(limit=10, warn_only=False)]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=0,
        requests_today=10,
    )
    assert decision.action == "block"


# ── multi-policy ──────────────────────────────────────────────────────────────


def test_multiple_policies_first_block_wins():
    """First blocking policy short-circuits — remaining policies not evaluated."""
    # Budget at 100% with hard-block + allow-list (should never reach allow-list)
    limit_usd = 10.0
    running = int(limit_usd * 100_000)
    policies = [
        _budget_policy(limit_usd=limit_usd, warn_only=False, policy_id="budget-block"),
        _allow_list_policy(
            allowed_models=["claude-sonnet-4-6"], warn_only=False, policy_id="allowlist"
        ),
    ]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="claude-sonnet-4-6",
        running_total_millicents=running,
        requests_today=0,
    )
    assert decision.action == "block"
    assert decision.policy_id == "budget-block"


def test_no_policies_allows():
    """Empty policy list → allow."""
    decision = evaluate_policies(
        policies=[],
        project="proj",
        model="claude-sonnet-4-6",
        running_total_millicents=1_000_000,
        requests_today=100,
    )
    assert decision.action == "allow"


def test_unknown_policy_type_allows():
    """Unknown policy type is silently ignored → allow."""
    policies = [{"id": "x", "type": "unknown_policy", "config": {}, "warn_only": True}]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="m",
        running_total_millicents=0,
        requests_today=0,
    )
    assert decision.action == "allow"


def test_policy_decision_has_policy_id():
    """Triggered policies include the policy_id in the decision."""
    policies = [_allow_list_policy(allowed_models=["haiku"], warn_only=True, policy_id="my-policy")]
    decision = evaluate_policies(
        policies=policies,
        project="proj",
        model="sonnet",
        running_total_millicents=0,
        requests_today=0,
    )
    assert decision.action == "warn"
    assert decision.policy_id == "my-policy"
