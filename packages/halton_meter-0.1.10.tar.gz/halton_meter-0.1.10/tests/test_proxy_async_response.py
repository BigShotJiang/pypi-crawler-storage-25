"""
v0.1.7 Gap 4 regressions — async response hook + per-host parse timeout
+ per-host circuit breaker.

Each test would have caught a specific class of regression:

* timeout fail-open: a slow parser stalls the event loop instead of
  being cancelled.
* breaker trips: sustained timeouts allow stalled parses to keep
  arriving, eventually starving the worker pool.
* breaker resets: trip is permanent for the rest of the process.
* exponential backoff: subsequent trips don't escalate, so a flapping
  host keeps thrashing the metering pipeline.
* breaker on parse exception: parse exceptions trip the breaker even
  though they don't stall the loop, dropping otherwise-recoverable
  traffic.
* event-loop progress: a slow flow blocks fast flows (the bug this
  whole change exists to prevent).
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from pathlib import Path

import pytest
from mitmproxy import http
from mitmproxy.test import tflow, tutils

import halton_meter.proxy as proxy_module
from halton_meter.proxy import HaltonAddon
from halton_meter.storage import StorageManager


def _flow(host: str = "api.anthropic.com") -> http.HTTPFlow:
    req = tutils.treq(host=host, port=443, path="/v1/messages")
    req.content = json.dumps(
        {
            "model": "claude-haiku-4-5",
            "max_tokens": 16,
            "messages": [{"role": "user", "content": "hi"}],
        }
    ).encode()
    flow = tflow.tflow(req=req)
    flow.id = str(uuid.uuid4())
    flow.response = http.Response.make(
        200,
        json.dumps(
            {
                "id": "msg_test",
                "type": "message",
                "role": "assistant",
                "content": [{"type": "text", "text": "ok"}],
                "model": "claude-haiku-4-5",
                "stop_reason": "end_turn",
                "usage": {"input_tokens": 1, "output_tokens": 1},
            }
        ).encode(),
        {"Content-Type": "application/json"},
    )
    return flow


def _stage_pending(addon: HaltonAddon, flow: http.HTTPFlow) -> None:
    """Skip the request hook and stage a synthetic _pending entry so
    response() runs the timeout/breaker path."""
    from halton_meter.adapters.base import RequestMetadata

    meta = RequestMetadata(
        provider="anthropic",
        model="claude-haiku-4-5",
        stream=False,
        started_at=time.monotonic(),
    )
    addon._pending[flow.id] = (meta, "2026-05-01T00:00:00Z")


@pytest.mark.asyncio
async def test_parse_timeout_fails_open_and_does_not_record(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """A pathological parser that sleeps 10s under a 0.05s timeout
    must fail open within ~0.05s, log ``addon.parse_response_timeout``,
    and write no record. Pre-Gap-4 the parser would block the event
    loop until it returned."""

    def slow_parser(_flow: http.HTTPFlow, _meta: object) -> object:
        time.sleep(10)  # never returns within the test budget
        raise AssertionError("parser should have been cancelled")

    monkeypatch.setitem(proxy_module.PARSE_TIMEOUTS, "api.anthropic.com", 0.05)

    fake_adapter = type(
        "FakeAdapter",
        (),
        {
            "name": "anthropic",
            "matches": staticmethod(lambda h: h == "api.anthropic.com"),
            "parse_response": staticmethod(slow_parser),
        },
    )()
    monkeypatch.setattr(
        proxy_module, "ADAPTER_REGISTRY", [fake_adapter]
    )

    db_path = tmp_path / "timeout.sqlite"
    async with StorageManager(db_path) as storage:
        addon = HaltonAddon(storage=storage)
        flow = _flow()
        _stage_pending(addon, flow)

        started = time.monotonic()
        await addon.response(flow)
        elapsed = time.monotonic() - started

        assert elapsed < 0.5, (
            f"timeout must fail open quickly; took {elapsed:.2f}s"
        )

        for _ in range(20):
            await asyncio.sleep(0)
        records = await storage.read_records()
    assert records == []
    # Breaker has a single timeout recorded (threshold is 5 — not yet open).
    assert len(addon._cb_timeouts["api.anthropic.com"]) == 1
    assert not addon._is_circuit_open("api.anthropic.com")


@pytest.mark.asyncio
async def test_circuit_trips_after_threshold_and_bypasses_metering(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Five timeouts inside the rolling window must open the breaker;
    the next request bypasses metering even with a normally-fast
    adapter."""
    host = "api.anthropic.com"

    # Trip the breaker with five recorded timeouts.
    addon = HaltonAddon(storage=None)
    for _ in range(5):
        addon._record_parse_timeout(host)
    assert addon._is_circuit_open(host)
    assert addon._cb_trip_count[host] == 1

    # Even with a normally-fast adapter the next response must bypass
    # because the breaker is open.
    def fast_parser(*_a: object, **_kw: object) -> object:  # pragma: no cover
        raise AssertionError("breaker must short-circuit before parse")

    fake_adapter = type(
        "FakeAdapter",
        (),
        {
            "name": "anthropic",
            "matches": staticmethod(lambda h: h == host),
            "parse_response": staticmethod(fast_parser),
        },
    )()
    monkeypatch.setattr(proxy_module, "ADAPTER_REGISTRY", [fake_adapter])

    flow = _flow()
    _stage_pending(addon, flow)
    await addon.response(flow)
    # _pending was popped before the bypass — memory bound preserved.
    assert flow.id not in addon._pending


@pytest.mark.asyncio
async def test_circuit_recovers_after_open_window(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    """After the open-duration elapses the breaker is closed and the
    next response is processed normally."""
    host = "api.anthropic.com"
    addon = HaltonAddon(storage=None)

    # Pin a controllable clock.
    fake_now = {"t": 1000.0}
    monkeypatch.setattr(proxy_module.time, "monotonic", lambda: fake_now["t"])

    for _ in range(5):
        addon._record_parse_timeout(host)
    open_until = addon._cb_open_until[host]
    assert addon._is_circuit_open(host)

    # Jump past the open window.
    fake_now["t"] = open_until + 1.0
    assert not addon._is_circuit_open(host)


def test_circuit_backoff_progression(monkeypatch: pytest.MonkeyPatch) -> None:
    """Successive trips escalate 60 -> 120 -> 240 -> 240 (capped)."""
    host = "api.anthropic.com"
    addon = HaltonAddon(storage=None)

    fake_now = {"t": 1000.0}
    monkeypatch.setattr(proxy_module.time, "monotonic", lambda: fake_now["t"])

    durations: list[float] = []
    for _trip in range(4):
        before = fake_now["t"]
        for _ in range(5):
            addon._record_parse_timeout(host)
        opened_until = addon._cb_open_until[host]
        durations.append(opened_until - before)
        # Skip past the open window so the next trip's recordings land
        # in a fresh rolling window.
        fake_now["t"] = opened_until + 1.0

    assert durations == [60.0, 120.0, 240.0, 240.0]


@pytest.mark.asyncio
async def test_parse_exception_does_not_trip_breaker(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Parse exceptions land in the outer except — log + return — but
    must NOT add a sample to the breaker's window. Pre-Gap-4 a runaway
    of malformed responses on a noisy day would have flipped the
    breaker open, dropping otherwise-recoverable traffic."""

    def boom(*_a: object, **_kw: object) -> object:
        raise ValueError("malformed response body")

    fake_adapter = type(
        "FakeAdapter",
        (),
        {
            "name": "anthropic",
            "matches": staticmethod(lambda h: h == "api.anthropic.com"),
            "parse_response": staticmethod(boom),
        },
    )()
    monkeypatch.setattr(proxy_module, "ADAPTER_REGISTRY", [fake_adapter])

    addon = HaltonAddon(storage=None)
    for _ in range(10):
        flow = _flow()
        _stage_pending(addon, flow)
        await addon.response(flow)

    # Window must be empty — exceptions don't count.
    assert len(addon._cb_timeouts["api.anthropic.com"]) == 0
    assert not addon._is_circuit_open("api.anthropic.com")


@pytest.mark.asyncio
async def test_concurrent_slow_and_fast_flows_do_not_block_each_other(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    """A slow parser MUST NOT block fast flows. This is the bug the
    asyncio.to_thread offload exists to prevent."""
    host = "api.anthropic.com"

    def slow_then_fast(flow: http.HTTPFlow, _meta: object) -> object:
        delay = 0.4 if flow.request.path == "/v1/messages?slow=1" else 0.01
        time.sleep(delay)
        from halton_meter.adapters.base import ResponseMetadata

        return ResponseMetadata(
            input_tokens=1,
            output_tokens=1,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
            tokens_complete=True,
            latency_ms=1.0,
        )

    fake_adapter = type(
        "FakeAdapter",
        (),
        {
            "name": "anthropic",
            "matches": staticmethod(lambda h: h == host),
            "parse_response": staticmethod(slow_then_fast),
        },
    )()
    monkeypatch.setattr(proxy_module, "ADAPTER_REGISTRY", [fake_adapter])
    monkeypatch.setitem(proxy_module.PARSE_TIMEOUTS, host, 5.0)

    addon = HaltonAddon(storage=None)

    slow_flow = _flow()
    slow_flow.request.path = "/v1/messages?slow=1"
    _stage_pending(addon, slow_flow)

    fast_flow = _flow()
    _stage_pending(addon, fast_flow)

    started = time.monotonic()
    slow_task = asyncio.create_task(addon.response(slow_flow))
    fast_task = asyncio.create_task(addon.response(fast_flow))
    await fast_task
    fast_done_at = time.monotonic()
    await slow_task
    slow_done_at = time.monotonic()

    # Fast flow must complete well before the slow one — proves the
    # event loop kept making progress while the slow parser ran in a
    # worker thread.
    assert fast_done_at - started < 0.3
    assert slow_done_at - started > 0.3
