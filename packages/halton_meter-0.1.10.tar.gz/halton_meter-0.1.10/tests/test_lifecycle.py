"""Tests for ``halton_meter.lifecycle`` (Phase 2B.8).

All OS-level subprocess calls are mocked. No real ``launchctl``,
``lsof``, ``networksetup``, ``security``, ``systemctl``, ``ps``, or
``os.kill`` invocations against live processes.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import lifecycle, system_proxy
from halton_meter.cli import cli
from halton_meter.config import HaltonConfig

# --------------------------------------------------------------------------- #
# Helpers / fixtures                                                          #
# --------------------------------------------------------------------------- #


def _completed(rc: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(
        args=["mock"], returncode=rc, stdout=stdout, stderr=stderr
    )


def _make_cfg(tmp_path: Path) -> HaltonConfig:
    return HaltonConfig.model_validate(
        {
            "daemon": {
                "listen_host": "127.0.0.1",
                "listen_port": 9080,
                "api_host": "127.0.0.1",
                "api_port": 8765,
                "log_path": str(tmp_path / "daemon.log"),
            },
            "storage": {"db_path": str(tmp_path / "db.sqlite")},
        }
    )


@pytest.fixture(autouse=True)
def _reset_macos_interfaces_cache() -> Any:
    """Reset the per-process enumeration cache between tests so cache
    presets in one test do not leak into the next (2B.7.2 / 2B.7.3)."""
    system_proxy._MACOS_INTERFACES_CACHE = None
    yield
    system_proxy._MACOS_INTERFACES_CACHE = None


@pytest.fixture
def macos(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "darwin")
    # Preset the dynamic-enumeration cache (2B.7.2) so existing
    # stop/networksetup-call-count tests exercise the 4-interface
    # fallback deterministically without an extra
    # ``networksetup -listallnetworkservices`` call inflating counts.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )


@pytest.fixture
def installed_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> tuple[Path, Path]:
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "com.haltonlabs.meter.edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    edge_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    return daemon_plist, watchdog_plist


@pytest.fixture
def absent_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    daemon_plist = tmp_path / "missing.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)


@pytest.fixture
def cfg_loaded(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> HaltonConfig:
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle, "load_config", lambda: cfg)
    return cfg


# --------------------------------------------------------------------------- #
# start: macOS                                                                #
# --------------------------------------------------------------------------- #


def test_start_macos_not_installed_returns_error(
    macos: None, absent_plists: None, cfg_loaded: HaltonConfig
) -> None:
    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_port_held_by_orphan_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # No daemon running.
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    # Both labels are unknown to launchctl → no managed PIDs.
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    # Port 8765 held by an external PID 99999.
    monkeypatch.setattr(
        lifecycle,
        "_lsof_pids_on_port",
        lambda port: [99999] if port == 8765 else [],
    )
    monkeypatch.setattr(lifecycle, "_process_name", lambda pid: "ghost")

    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_already_running_is_idempotent(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: True)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: True)
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )

    rc = lifecycle.start()
    assert rc == 0


def test_start_macos_full_load_succeeds(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Initially nothing running, no port conflicts.
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])

    # After load, launchctl reports live PIDs.
    pid_state = {"daemon": 4242, "watchdog": 4243}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return pid_state["daemon"]
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", fake_pid)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())

    # Mock launchctl unload + load -w.
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    # /health comes up immediately.
    monkeypatch.setattr(
        lifecycle, "_wait_for_health",
        lambda port, timeout_seconds=15.0: (True, 3.2),
    )

    # System-proxy + capture.
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0
    # Should have called launchctl load for both labels (load -w * 2).
    load_calls = [argv for argv in run_calls if "load" in argv]
    assert len(load_calls) >= 2


def test_start_macos_health_never_comes_up_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_wait_for_health",
        lambda port, timeout_seconds=15.0: (False, None),
    )

    err_log_called: list[int] = []
    monkeypatch.setattr(
        lifecycle, "_print_err_log_tail", lambda console, lines=20: err_log_called.append(1)
    )

    rc = lifecycle.start()
    assert rc == 1
    assert err_log_called == [1]


# --------------------------------------------------------------------------- #
# stop: macOS                                                                 #
# --------------------------------------------------------------------------- #


def test_stop_macos_not_installed_is_idempotent(
    macos: None,
    absent_plists: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Even with no plists installed, `stop` resets the system proxy.

    A user who runs `stop` after a hard crash that left the proxy stuck
    wants the proxy off regardless of plist state — same recovery
    posture as `uninstall`.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x (secure, unsecure) variants → 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_unloads_both_plists(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    unload_argvs = [argv for argv in run_calls if "unload" in argv]
    # One unload per label.
    assert len(unload_argvs) == 2


def test_stop_macos_kills_orphan_port_holders(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    # Port 8765 held by 7777 even after unload.
    seen: dict[int, int] = {8765: 7777}
    monkeypatch.setattr(
        lifecycle, "_lsof_pids_on_port", lambda port: [seen[port]] if port in seen else []
    )

    kills: list[tuple[int, int]] = []

    def fake_kill(pid: int, sig: int) -> None:
        kills.append((pid, sig))
        # First SIGTERM: still alive; signal-0 probe also must succeed.
        # On SIGKILL or after timeout, simulate process gone.
        if sig == 0:
            # liveness probe: process still alive within the wait loop.
            return
        if sig == lifecycle._signal.SIGKILL:
            return

    monkeypatch.setattr(lifecycle.os, "kill", fake_kill)
    # Skip the wait loop.
    times = iter([0.0, 100.0])
    monkeypatch.setattr(lifecycle.time, "monotonic", lambda: next(times, 100.0))

    rc = lifecycle.stop()
    assert rc == 0
    # SIGTERM to 7777 then SIGKILL escalation.
    sent = {(pid, sig) for pid, sig in kills if sig != 0}
    assert (7777, lifecycle._signal.SIGTERM) in sent


def test_stop_macos_resets_system_proxy_after_unload(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`stop` must reset the system proxy, and only after unloading the plists.

    Inverted from the original 2B.8 contract — leaving the proxy
    pointed at a now-dead listener breaks every HTTPS-via-system-proxy
    client on the machine.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    # Networksetup must run for every fallback interface, both proxy variants, all `off`.
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8.
    assert len(networksetup_calls) == 8
    expected_pairs = {
        (iface, variant)
        for iface in system_proxy._MACOS_INTERFACE_FALLBACK
        for variant in ("-setsecurewebproxystate", "-setwebproxystate")
    }
    seen_pairs = {(argv[2], argv[1]) for argv in networksetup_calls}
    assert seen_pairs == expected_pairs
    for argv in networksetup_calls:
        assert argv[3] == "off"

    # Ordering: every networksetup call must come AFTER the last
    # launchctl unload, so the daemon is dead before the proxy goes off
    # (closes the brief window where new traffic would hit a dying listener).
    last_unload_idx = max(
        i
        for i, argv in enumerate(run_calls)
        if argv and argv[0] == "launchctl" and "unload" in argv
    )
    first_networksetup_idx = min(
        i for i, argv in enumerate(run_calls) if argv and argv[0] == "networksetup"
    )
    assert first_networksetup_idx > last_unload_idx


def test_stop_macos_preserves_sentinel_file(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """`stop` must NOT delete the proxy-managed sentinel — that's `uninstall`'s job.

    Preserving it means the daemon's Option-1 startup re-enable will
    fire on the next `halton-meter start`.
    """
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()

    real_unlink = Path.unlink
    unlinked: list[str] = []

    def tracking_unlink(self: Path, *args: Any, **kwargs: Any) -> None:
        unlinked.append(str(self))
        real_unlink(self, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", tracking_unlink)
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    assert sentinel.exists()
    assert str(sentinel) not in unlinked


def test_stop_macos_proxy_reset_runs_even_when_unload_fails(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If `launchctl unload` fails, system-proxy reset must still run.

    Same best-effort recovery posture as `uninstall` — the proxy reset
    is the load-bearing line, never gated on prior step success.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        if argv and argv[0] == "launchctl" and "unload" in argv:
            return _completed(1, stderr="launchctl: Could not unload service")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_resets_proxy_on_vikrants_mac_shape(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: `stop` on a Mac whose enumerated services
    are Wi-Fi / Thunderbolt Bridge / iPhone USB (Vikrant's MacBook) must
    reset the proxy on those three interfaces and MUST NOT call
    networksetup against a non-existent ``Ethernet`` service."""
    # Override the FALLBACK preset baked into the `macos` fixture.
    monkeypatch.setattr(
        system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi", "Thunderbolt Bridge", "iPhone USB"),
    )
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 3 interfaces x 2 variants = 6.
    assert len(networksetup_calls) == 6
    seen_ifaces = {argv[2] for argv in networksetup_calls}
    assert seen_ifaces == {"Wi-Fi", "Thunderbolt Bridge", "iPhone USB"}
    assert "Ethernet" not in seen_ifaces


def test_stop_macos_no_networksetup_calls_when_enum_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: when dynamic enumeration yields an empty
    tuple, `stop` must not shell out to networksetup at all — graceful
    degradation rather than a flurry of bad-argument failures."""
    monkeypatch.setattr(system_proxy, "_MACOS_INTERFACES_CACHE", ())
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    assert networksetup_calls == []


# --------------------------------------------------------------------------- #
# status: macOS                                                               #
# --------------------------------------------------------------------------- #


@pytest.fixture
def status_macos_healthy(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    # Sentinel present.
    sentinel = Path("/tmp/halton-meter-test-sentinel-status")
    sentinel.touch()
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(
            found=True, db_missing=False, timestamp_iso="2026-04-29T12:00:00Z",
            seconds_ago=25.0, model="claude-opus-4-7", project="halton-meter",
            cost_usd_minor_units=8790, captured_last_hour=12, captured_last_day=4208,
        ),
    )


def test_status_macos_healthy_returns_zero(status_macos_healthy: None) -> None:
    rc = lifecycle.status()
    assert rc == 0


def test_status_macos_edge_row_present_when_healthy(
    status_macos_healthy: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """2C.2 (v0.1.6): the status table includes an explicit Edge row
    showing the user-facing port. Without this row, a stopped/dead
    edge would be invisible until apps started failing."""
    lifecycle.status()
    out = capsys.readouterr().out
    assert "Edge" in out
    assert ":8081" in out  # default edge_port

    # The Daemon row also surfaces internal_port now (was only api_port).
    assert "internal=:8090" in out


def test_status_macos_edge_row_shows_chain_target_ok(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge sidecar's chain_port matches the
    cfg.daemon.internal_port, the row carries `chain :PORT ✓`."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8090, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "chain :8090" in out
    assert "✓" in out


def test_status_macos_edge_row_marks_stale_chain(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge's bound chain_port differs from the
    daemon's actual internal_port, the row says STALE and status returns
    non-zero. Pre-fix this state was completely invisible."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8091, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # stale chain forces non-healthy
    assert "chain :8091" in out
    assert "✗" in out
    assert "stale chain" in out


def test_status_macos_edge_not_installed_marks_unhealthy(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When the edge plist is missing the Edge row reports not-installed
    and status returns non-zero — apps would fail with ConnectionRefused."""
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_stop_macos_explains_apps_still_work_via_edge(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """2C.2 (v0.1.6): stop output makes the new behaviour explicit —
    apps continue working in passthrough via the still-running edge
    proxy. Stop never restarts apps; the edge is the reason it doesn't
    have to."""
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    out = capsys.readouterr().out
    assert "Apps still work" in out
    assert "edge proxy is still running" in out
    # Test cfg uses port 9080 — assert the resolved edge_port appears.
    assert f":{cfg_loaded.daemon.edge_port}" in out
    assert "halton-meter start" in out
    assert "No metering" in out


def test_status_macos_daemon_loaded_but_unhealthy_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_disabled_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_pointed_elsewhere_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("pointed elsewhere", "system proxy on but address=10.0.0.1:3128"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_database_missing(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "database not found" in result.output


def test_status_macos_database_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "no captures yet" in result.output


def test_status_json_output(status_macos_healthy: None) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    # Last JSON object on stdout — Rich console may have leading/trailing
    # whitespace but no other text in --json mode.
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert payload["platform"] == "darwin"
    assert "components" in payload
    assert any(c["name"] == "Daemon" for c in payload["components"])
    assert payload["captured_last_hour"] == 12
    assert payload["captured_last_day"] == 4208


# --------------------------------------------------------------------------- #
# v0.1.10 Gap 16 — graceful-uninstall status detection                        #
# --------------------------------------------------------------------------- #


@pytest.fixture
def graceful_uninstall_state(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Materialise the post-`uninstall --graceful` filesystem signature.

    Edge plist + sentinel + daemon plist all absent on disk; edge label
    has a live PID; daemon label is unknown to launchctl.
    """
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    sentinel = tmp_path / "missing-sentinel"
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    # daemon label unknown → returncode != 0 from `launchctl list`
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_known",
        lambda label: False,
    )
    monkeypatch.setattr(
        lifecycle,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )


def test_status_macos_graceful_uninstall_renders_single_row(
    graceful_uninstall_state: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """When all four detection conditions hold, `status` emits a single
    `Graceful uninstall` row instead of the standard 8-row table, and
    exits HEALTHY (0) — graceful is an explicit user-state, not drift."""
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "Graceful uninstall" in out
    assert "edge in passthrough" in out
    assert "PID 90210" in out
    # Standard rows must NOT appear.
    assert "Watchdog" not in out
    assert "System proxy" not in out
    assert "Cert trust" not in out
    # HEALTHY verdict, not BROKEN.
    assert "HEALTHY" in out
    assert "BROKEN" not in out


def test_status_macos_graceful_uninstall_json_payload(
    graceful_uninstall_state: None,
) -> None:
    """JSON output mirrors the rendered table — one component row,
    HEALTHY summary, healthy=True."""
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert len(payload["components"]) == 1
    assert payload["components"][0]["name"] == "Graceful uninstall"
    assert payload["components"][0]["state"] == "edge in passthrough"
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_macos_graceful_partial_falls_through_to_standard_table(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Partial graceful state (sentinel still present) is NOT graceful —
    it is drift. The standard render must fire so the user sees the
    inconsistency, not a misleading HEALTHY graceful row."""
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    # Sentinel is present — breaks the four-of-four detection.
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: False)
    monkeypatch.setattr(
        lifecycle, "_is_cert_trusted", lambda: True,
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # standard render reports the wall of "not installed"
    assert "Graceful uninstall" not in out
    # Standard table rows present.
    assert "Daemon" in out
    assert "Watchdog" in out


# --------------------------------------------------------------------------- #
# Linux                                                                       #
# --------------------------------------------------------------------------- #


def test_status_linux_skips_proxy_row(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "linux")
    monkeypatch.setattr(lifecycle.os, "name", "posix")
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle, "load_config", lambda: cfg)

    # Pretend systemd units exist + active.
    daemon_unit = tmp_path / "halton-meter.service"
    watchdog_unit = tmp_path / "halton-meter-watchdog.service"
    daemon_unit.write_text("")
    watchdog_unit.write_text("")
    monkeypatch.setattr(lifecycle, "_linux_unit_path", lambda: daemon_unit)
    monkeypatch.setattr(lifecycle, "_linux_watchdog_unit_path", lambda: watchdog_unit)
    monkeypatch.setattr(lifecycle, "_systemctl_is_active", lambda unit: "active")
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    payload = json.loads(result.output.strip())
    component_names = {c["name"] for c in payload["components"]}
    assert "System proxy" not in component_names
    assert "Daemon" in component_names
    assert "Watchdog" in component_names


# --------------------------------------------------------------------------- #
# Windows                                                                     #
# --------------------------------------------------------------------------- #


def test_start_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.start()
    assert rc == 0


def test_stop_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.stop()
    assert rc == 0


def test_status_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.status()
    assert rc == 0


# --------------------------------------------------------------------------- #
# v0.1.3 P0-8 — mode-aware health summary                                     #
# --------------------------------------------------------------------------- #


def _row(name: str, state: str) -> lifecycle._ComponentRow:
    return lifecycle._ComponentRow(name, state, "")


class TestComputeHealthSummaryMacos:
    def test_env_only_healthy_when_daemon_and_cert_ok(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
            _row("Sentinel file", "missing"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "HEALTHY"
        assert "halton-meter run" in summary.message

    def test_env_only_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "BROKEN"

    def test_full_broken_when_proxy_enabled_but_cert_untrusted(self) -> None:
        """Witnessed totaljobs.com regression: proxy enabled at us but
        cert is not trusted -> SecTrust rejects, browsing dies."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_full_inconsistent_when_proxy_not_enabled(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "INCONSISTENT"

    def test_full_healthy_when_all_signals_good(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "HEALTHY"

    def test_apps_healthy_when_proxy_disabled_and_cert_trusted(self) -> None:
        """v0.1.5 (2B.16): apps mode is HEALTHY when daemon + cert ok AND
        system proxy is DISABLED on our interfaces (apps mode promises
        to leave the system proxy alone)."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "HEALTHY"
        assert "apps" in summary.message.lower()

    def test_apps_broken_when_proxy_enabled_drift(self) -> None:
        """v0.1.5 (2B.16): apps mode + system proxy enabled = BROKEN
        drift. The user is running stale full-mode state."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "stale" in summary.message.lower() or "drift" in summary.message.lower()

    def test_apps_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_unknown_mode_returns_inconsistent(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, None)
        assert summary.severity == "INCONSISTENT"

    def test_daemon_unhealthy_dominates(self) -> None:
        rows = [
            _row("Daemon", "loaded"),  # not healthy
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "daemon" in summary.message.lower()


def test_status_report_to_json_dict_includes_health_summary() -> None:
    report = lifecycle._StatusReport(
        healthy=True,
        platform="darwin",
        health_summary=lifecycle._HealthSummary(
            "HEALTHY", "env-var-only mode is healthy."
        ),
    )
    payload = report.to_json_dict()
    assert "health_summary" in payload
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_report_to_json_dict_omits_health_summary_when_none() -> None:
    report = lifecycle._StatusReport(healthy=True, platform="darwin")
    payload = report.to_json_dict()
    assert "health_summary" not in payload


# --------------------------------------------------------------------------- #
# v0.1.4 (2B.15) P0-5 — auto-port-fallback in status                           #
# --------------------------------------------------------------------------- #


class TestPortStatusRow:
    """Effective ports row marks auto-fallback explicitly so the user
    knows their tools must target the actual port, not the marketed
    default."""

    def test_default_ports_show_default_state(self) -> None:
        # v0.1.6: user-facing proxy default is now 8081 (was 8080); the
        # daemon's mitmproxy listener still binds it at this stage of
        # the rollout (W4 flips it to internal_port 8090).
        row = lifecycle._port_status_row(8081, 8765)
        assert row.name == "Effective ports"
        assert row.state == "default"
        assert "8081" in row.detail
        assert "8765" in row.detail
        assert "fallback" not in row.detail.lower()

    def test_listen_port_fallback_marked(self) -> None:
        # 8082 is one above the v0.1.6 default 8081 -> fallback.
        row = lifecycle._port_status_row(8082, 8765)
        assert row.state == "fallback"
        assert "8082" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8081" in row.detail  # v0.1.6 default we fell back from

    def test_api_port_fallback_marked(self) -> None:
        row = lifecycle._port_status_row(8081, 8766)
        assert row.state == "fallback"
        assert "8766" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8765" in row.detail  # default we fell back from

    def test_both_ports_fallback_listed(self) -> None:
        row = lifecycle._port_status_row(8083, 8767)
        assert row.state == "fallback"
        # Both fallback notes present.
        assert "8083" in row.detail
        assert "8767" in row.detail
        assert "8081" in row.detail  # v0.1.6 default
        assert "8765" in row.detail
