"""
v0.1.9 Gap 12 — `halton-meter retag` regression coverage.

Tests use temporary SQLite DBs initialised against the daemon's real
schema (via SQLAlchemy's metadata.create_all) so the FK semantics the
retag code relies on are exercised end-to-end.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path

import pytest
from click.testing import CliRunner

from halton_meter.cli import cli
from halton_meter.retag import (
    RetagError,
    retag_project,
)
from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import Project, Request


def _make_db_with_rows(
    db_path: Path,
    *,
    from_slug: str,
    row_count: int,
    extra_projects: tuple[str, ...] = (),
) -> str:
    """Create a fresh DB with ``row_count`` requests under ``from_slug``.
    Returns the project_id of the source project."""

    async def _setup() -> str:
        engine, sm = create_engine_for(db_path)
        from halton_meter.storage.models.base import Base

        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        from_id = str(uuid.uuid4())
        async with sm() as session:
            session.add(
                Project(id=from_id, name=from_slug, slug=from_slug)
            )
            for slug in extra_projects:
                session.add(
                    Project(id=str(uuid.uuid4()), name=slug, slug=slug)
                )
            for _ in range(row_count):
                session.add(
                    Request(
                        id=str(uuid.uuid4()),
                        project_id=from_id,
                        provider="anthropic",
                        model="claude-sonnet-4-5",
                        mode="standard",
                        input_tokens=10,
                        output_tokens=20,
                        thinking_tokens=0,
                        cache_read_tokens=0,
                        cache_write_tokens=0,
                        cost_usd_minor_units=42,
                        latency_ms=100.0,
                        tokens_complete=True,
                        requested_at=datetime.now(tz=UTC),
                        recorded_at=datetime.now(tz=UTC),
                        status="success",
                    )
                )
            await session.commit()
        await engine.dispose()
        return from_id

    return asyncio.run(_setup())


def _row_count_for_slug(db_path: Path, slug: str) -> int:
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.execute(
            "SELECT count(*) FROM requests "
            "WHERE project_id = (SELECT id FROM projects WHERE slug = ?)",
            (slug,),
        )
        return int(cur.fetchone()[0] or 0)
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# retag_project() unit tests                                                  #
# --------------------------------------------------------------------------- #


def test_dry_run_reports_count_and_makes_no_changes(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=3)

    plan = retag_project(
        db_path=db, from_slug=".halton-meter", to_slug="unattributed", apply=False
    )

    assert plan.applied is False
    assert plan.from_project_existed is True
    assert plan.rows_matched == 3
    assert plan.rows_updated == 0
    assert plan.to_project_created is True
    # Source project should still own the rows.
    assert _row_count_for_slug(db, ".halton-meter") == 3
    assert _row_count_for_slug(db, "unattributed") == 0


def test_apply_updates_rows_and_emits_audit_event(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=5)

    plan = retag_project(
        db_path=db, from_slug=".halton-meter", to_slug="unattributed", apply=True
    )

    assert plan.applied is True
    assert plan.rows_updated == 5
    assert plan.to_project_created is True
    assert plan.from_project_deleted is True
    assert _row_count_for_slug(db, ".halton-meter") == 0
    assert _row_count_for_slug(db, "unattributed") == 5

    # Audit row exists with our action.
    conn = sqlite3.connect(str(db))
    try:
        cur = conn.execute(
            "SELECT action, metadata FROM audit_events "
            "WHERE action = 'audit.retag_executed'"
        )
        rows = cur.fetchall()
    finally:
        conn.close()
    assert len(rows) == 1, rows
    payload = json.loads(rows[0][1])
    assert payload == {
        "from": ".halton-meter",
        "to": "unattributed",
        "rows_updated": 5,
    }


def test_apply_no_op_when_from_slug_missing(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(
        db, from_slug="something-else", row_count=2, extra_projects=()
    )

    plan = retag_project(
        db_path=db, from_slug=".halton-meter", to_slug="unattributed", apply=True
    )

    assert plan.applied is True
    assert plan.from_project_existed is False
    assert plan.rows_matched == 0
    # The unrelated project's rows must not be touched.
    assert _row_count_for_slug(db, "something-else") == 2


def test_apply_preserves_existing_destination_project(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(
        db,
        from_slug=".halton-meter",
        row_count=2,
        extra_projects=("unattributed",),
    )

    plan = retag_project(
        db_path=db, from_slug=".halton-meter", to_slug="unattributed", apply=True
    )

    assert plan.to_project_created is False
    assert plan.rows_updated == 2
    assert _row_count_for_slug(db, "unattributed") == 2


def test_validation_rejects_empty_slug(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=1)
    with pytest.raises(RetagError, match="must not be empty"):
        retag_project(db_path=db, from_slug="", to_slug="x", apply=True)


def test_validation_rejects_path_traversal(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=1)
    with pytest.raises(RetagError, match="forbidden fragment"):
        retag_project(
            db_path=db, from_slug=".halton-meter", to_slug="../etc", apply=True
        )


def test_validation_rejects_identical_slugs(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=1)
    with pytest.raises(RetagError, match="identical"):
        retag_project(
            db_path=db, from_slug="x", to_slug="x", apply=False
        )


def test_validation_rejects_missing_db(tmp_path: Path) -> None:
    with pytest.raises(RetagError, match="database not found"):
        retag_project(
            db_path=tmp_path / "nope.sqlite",
            from_slug="a",
            to_slug="b",
            apply=False,
        )


# --------------------------------------------------------------------------- #
# CLI surface                                                                 #
# --------------------------------------------------------------------------- #


def test_cli_dry_run_prints_count(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=4)

    runner = CliRunner()
    result = runner.invoke(cli, ["retag", "--db", str(db)])
    assert result.exit_code == 0, result.output
    assert "Dry-run" in result.output
    assert "4" in result.output
    assert _row_count_for_slug(db, ".halton-meter") == 4


def test_cli_apply_executes(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=2)

    runner = CliRunner()
    result = runner.invoke(cli, ["retag", "--db", str(db), "--apply", "--force"])
    assert result.exit_code == 0, result.output
    assert "Retagged 2 rows" in result.output
    assert _row_count_for_slug(db, "unattributed") == 2


def test_cli_apply_refuses_when_daemon_running(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=1)

    monkeypatch.setattr(
        "halton_meter.retag.daemon_health_ok",
        lambda *_a, **_kw: True,
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["retag", "--db", str(db), "--apply"])
    assert result.exit_code == 2
    assert "daemon is running" in result.output
    # Force overrides.
    result = runner.invoke(cli, ["retag", "--db", str(db), "--apply", "--force"])
    assert result.exit_code == 0, result.output


def test_cli_no_match_exits_zero(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug="other", row_count=1)

    runner = CliRunner()
    result = runner.invoke(
        cli, ["retag", "--db", str(db), "--apply", "--force"]
    )
    assert result.exit_code == 0, result.output
    assert "nothing to retag" in result.output


def test_cli_rejects_bad_to_slug(tmp_path: Path) -> None:
    db = tmp_path / "db.sqlite"
    _make_db_with_rows(db, from_slug=".halton-meter", row_count=1)
    runner = CliRunner()
    result = runner.invoke(
        cli, ["retag", "--db", str(db), "--to", "../etc", "--apply", "--force"]
    )
    assert result.exit_code == 2
    assert "forbidden fragment" in result.output
