"""W4 (2C.2 v0.1.6): env-var generation locked to ``edge_port``.

Apps see the user-facing port via ``HTTPS_PROXY`` / ``HTTP_PROXY``.
That port is the EDGE port (always-on listener owned by the edge
process), not the daemon's mitmproxy ``internal_port``. This file
pins the contract so a future refactor cannot accidentally leak
``internal_port`` into env-var generation.
"""

from __future__ import annotations

from pathlib import Path

from halton_meter.config import DaemonConfig, HaltonConfig
from halton_meter.init import build_env_vars

# Distinct sentinel ports so a value mix-up is observable in assertions.
_EDGE_PORT = 18081
_INTERNAL_PORT = 28090


def _make_cfg() -> HaltonConfig:
    return HaltonConfig(
        daemon=DaemonConfig(
            edge_port=_EDGE_PORT,
            internal_port=_INTERNAL_PORT,
        ),
    )


def test_build_env_vars_emits_nine_keys_all_wired_to_listen_port_arg(
    tmp_path: Path,
) -> None:
    """``build_env_vars`` is the canonical generator. Every value in the
    resulting dict that contains a port number must carry the port
    passed in — i.e. the caller's chosen ``edge_port``. The proxy URLs
    are the only port-bearing values; the cert bundles do not embed a
    port. Assert all 9 expected keys are present and only the proxy
    URLs carry the port.
    """
    bundle = tmp_path / "cabundle.pem"
    env = build_env_vars("127.0.0.1", _EDGE_PORT, bundle)

    expected_keys = {
        "HTTPS_PROXY",
        "HTTP_PROXY",
        "NO_PROXY",
        "NODE_EXTRA_CA_CERTS",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
        "GIT_SSL_CAINFO",
        "CURL_CA_BUNDLE",
        "AWS_CA_BUNDLE",
    }
    assert set(env.keys()) == expected_keys
    assert env["HTTPS_PROXY"] == f"http://127.0.0.1:{_EDGE_PORT}"
    assert env["HTTP_PROXY"] == f"http://127.0.0.1:{_EDGE_PORT}"


def test_build_env_vars_called_with_edge_port_in_init_flow_path() -> None:
    """The ``init`` flow's call site (``init.init`` step 5) reads
    ``cfg.daemon.edge_port`` and passes it into ``build_env_vars``.
    This test asserts the field name on the config is what the call
    expects — a guard against a future rename of ``edge_port`` silently
    flipping the user-facing port to ``internal_port``.
    """
    cfg = _make_cfg()
    # The exact line in init.py reads cfg.daemon.edge_port.
    assert cfg.daemon.edge_port == _EDGE_PORT
    assert cfg.daemon.internal_port == _INTERNAL_PORT
    # And the two are distinct.
    assert cfg.daemon.edge_port != cfg.daemon.internal_port


def test_internal_port_value_never_appears_in_env_var_dict(tmp_path: Path) -> None:
    """Defence-in-depth: scan every value in the generated env dict and
    assert ``internal_port``'s string form never appears anywhere. If a
    future refactor mistakenly mixes the two ports, this catches it
    even when individual key assertions pass.
    """
    bundle = tmp_path / "cabundle.pem"
    env = build_env_vars("127.0.0.1", _EDGE_PORT, bundle)

    internal_str = str(_INTERNAL_PORT)
    for key, value in env.items():
        assert internal_str not in value, (
            f"env var {key}={value!r} unexpectedly contains internal_port "
            f"{_INTERNAL_PORT}; only edge_port {_EDGE_PORT} should appear "
            "in user-facing env vars"
        )


def test_run_wrapper_build_env_uses_edge_port_when_resolved_from_cfg() -> None:
    """The run wrapper's ``_build_run_env`` is fed ``cfg.daemon.edge_port``
    by ``run_cmd``. This asserts that the field selected from the config
    is ``edge_port``, not ``internal_port``, by reading both off a
    constructed config.
    """
    cfg = _make_cfg()
    # The exact call shape in run.py:100 is `int(cfg.daemon.edge_port)`.
    selected_port = int(cfg.daemon.edge_port)
    assert selected_port == _EDGE_PORT
    assert selected_port != int(cfg.daemon.internal_port)
