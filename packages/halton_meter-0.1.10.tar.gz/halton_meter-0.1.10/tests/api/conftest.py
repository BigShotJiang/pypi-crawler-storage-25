"""
Shared fixtures for the daemon's API-layer tests.

Each test gets its own SQLite database under ``tmp_path`` so test runs are
fully isolated. The FastAPI app is constructed with a config pointing at
that file; ``configure_session_factory`` is invoked per-test through
``create_app``. The cached engine is reset between tests via the
``reset_engine_cache`` fixture so we never reuse a stale handle.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from pathlib import Path

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from halton_meter.api import create_app
from halton_meter.api.deps import configure_session_factory
from halton_meter.config import HaltonConfig, StorageConfig
from halton_meter.storage import init_db
from halton_meter.storage.engine import _ENGINES, create_engine_for, dispose_engines


@pytest.fixture(autouse=True)
def reset_engine_cache():
    """Drop any cached engines before and after each test."""
    _ENGINES.clear()
    yield
    _ENGINES.clear()


@pytest_asyncio.fixture
async def db_path(tmp_path: Path) -> Path:
    """Per-test SQLite file with the schema created."""
    p = tmp_path / "api-test.sqlite"
    engine, _ = create_engine_for(p)
    await init_db(engine)
    return p


@pytest_asyncio.fixture
async def client(db_path: Path) -> AsyncGenerator[AsyncClient, None]:
    """ASGI client wired up to a fresh FastAPI app + per-test SQLite file."""
    cfg = HaltonConfig(storage=StorageConfig(db_path=str(db_path)))
    configure_session_factory(str(db_path))
    app = create_app(cfg)
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    await dispose_engines()
