"""Tests for /v1/projects and /v1/stats endpoints.

Exercises the SQLite stats-aggregation port (date_trunc → strftime).
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import Project, Request


@pytest.fixture
async def seed_one_project(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
        await session.flush()
        for i in range(3):
            session.add(
                Request(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    provider="anthropic",
                    model="claude-sonnet-4-6",
                    mode="standard",
                    input_tokens=100 * (i + 1),
                    output_tokens=50 * (i + 1),
                    thinking_tokens=0,
                    cache_read_tokens=10 * (i + 1),
                    cache_write_tokens=20 * (i + 1),
                    cost_usd_minor_units=1000 * (i + 1),
                    latency_ms=120.0,
                    tokens_complete=True,
                    requested_at=datetime(2026, 4, 28, 10, 0, 0, tzinfo=UTC),
                    recorded_at=datetime(2026, 4, 28, 10, 0, 1, tzinfo=UTC),
                    status="success",
                )
            )
    return proj


async def test_list_empty_projects(client):
    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_list_projects_returns_seeded(client, seed_one_project):
    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    p = data[0]
    assert p["slug"] == "alpha"
    assert p["stats"]["all_time_requests"] == 3
    assert p["stats"]["all_time_cost_usd_minor_units"] == 6000  # 1000+2000+3000


async def test_get_project_404(client):
    resp = await client.get("/v1/projects/nope")
    assert resp.status_code == 404


async def test_global_stats_with_data(client, seed_one_project):
    resp = await client.get("/v1/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["summary"]["total_requests"] == 3
    assert data["summary"]["active_projects"] == 1
    by_day = data["by_day"]
    assert len(by_day) == 1
    assert by_day[0]["date"] == "2026-04-28"
    assert by_day[0]["requests"] == 3


async def test_project_stats(client, seed_one_project):
    resp = await client.get("/v1/projects/alpha/stats")
    assert resp.status_code == 200
    data = resp.json()
    assert data["summary"]["total_requests"] == 3
    assert len(data["by_day"]) == 1
    assert data["by_day"][0]["date"] == "2026-04-28"


async def test_csv_export(client, seed_one_project):
    resp = await client.get("/v1/projects/alpha/requests.csv")
    assert resp.status_code == 200
    assert "text/csv" in resp.headers["content-type"]
    body = resp.text
    assert "timestamp" in body
    assert "claude-sonnet-4-6" in body


async def test_csv_export_header_has_renamed_cache_columns(client, seed_one_project):
    """CSV header carries `cache_read_tokens` + `cache_write_tokens`,
    not the legacy `cached_tokens` (decisions.md 2026-04-30)."""
    resp = await client.get("/v1/projects/alpha/requests.csv")
    assert resp.status_code == 200
    lines = resp.text.splitlines()
    header = lines[0].split(",")
    assert "cache_read_tokens" in header
    assert "cache_write_tokens" in header
    assert "cached_tokens" not in header


async def test_csv_export_data_rows_populate_cache_columns(client, seed_one_project):
    """Per-row cache_read/cache_write values from the seeded fixture must
    serialise into the CSV under the renamed + new columns."""
    resp = await client.get("/v1/projects/alpha/requests.csv")
    assert resp.status_code == 200
    lines = resp.text.splitlines()
    header = lines[0].split(",")
    read_idx = header.index("cache_read_tokens")
    write_idx = header.index("cache_write_tokens")
    # Three seeded rows (i=0,1,2): cache_read=10*(i+1), cache_write=20*(i+1).
    data_rows = [line.split(",") for line in lines[1:]]
    assert len(data_rows) == 3
    read_values = sorted(int(r[read_idx]) for r in data_rows)
    write_values = sorted(int(r[write_idx]) for r in data_rows)
    assert read_values == [10, 20, 30]
    assert write_values == [20, 40, 60]


async def test_stats_summary_renames_cached_to_cache_read_and_adds_write(
    client, seed_one_project
):
    """Wire-format check: `total_cached_tokens` is gone; replaced with
    `total_cache_read_tokens` + `total_cache_write_tokens`."""
    resp = await client.get("/v1/projects/alpha/stats")
    assert resp.status_code == 200
    summary = resp.json()["summary"]
    assert "total_cached_tokens" not in summary
    assert summary["total_cache_read_tokens"] == 60  # 10+20+30
    assert summary["total_cache_write_tokens"] == 120  # 20+40+60


async def test_request_record_renames_cached_and_adds_write(
    client, seed_one_project
):
    """Per-request wire-format: `cached_tokens` JSON key gone; replaced
    with `cache_read_tokens` + `cache_write_tokens`."""
    resp = await client.get("/v1/projects/alpha/stats")
    assert resp.status_code == 200
    items = resp.json()["requests"]["items"]
    assert items, "expected seeded requests"
    for item in items:
        assert "cached_tokens" not in item
        assert "cache_read_tokens" in item
        assert "cache_write_tokens" in item
    read_values = sorted(item["cache_read_tokens"] for item in items)
    write_values = sorted(item["cache_write_tokens"] for item in items)
    assert read_values == [10, 20, 30]
    assert write_values == [20, 40, 60]


async def test_global_stats_summary_uses_renamed_cache_fields(
    client, seed_one_project
):
    resp = await client.get("/v1/stats")
    assert resp.status_code == 200
    summary = resp.json()["summary"]
    assert "total_cached_tokens" not in summary
    assert summary["total_cache_read_tokens"] == 60
    assert summary["total_cache_write_tokens"] == 120


async def test_top_model_and_top_provider_present_for_seeded_project(
    client, seed_one_project
):
    """ProjectMonthStats exposes cost-ranked top_model + top_provider for
    every project. With one seeded model (claude-sonnet-4-6 / anthropic),
    those two fields collapse to that one model + provider."""
    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    items = resp.json()
    assert len(items) == 1
    stats = items[0]["stats"]
    assert stats["top_model"] == "claude-sonnet-4-6"
    assert stats["top_provider"] == "anthropic"


async def test_top_model_picks_highest_cost_model_with_dated_suffix(
    db_path, client
):
    """Real-world fixture: project has two Anthropic models, one dated
    (claude-opus-4-7-20260101 — high cost) and one undated (haiku — low
    cost). Server must rank by cost, returning the dated opus variant
    verbatim. This is the case the dashboard MODELS lookup couldn't handle."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="beta", slug="beta")
        session.add(proj)
        await session.flush()
        # Cheap haiku x 5 = 500 millicents total
        for _ in range(5):
            session.add(
                Request(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    provider="anthropic",
                    model="claude-haiku-4-5",
                    mode="standard",
                    input_tokens=100,
                    output_tokens=50,
                    thinking_tokens=0,
                    cache_read_tokens=0,
                    cache_write_tokens=0,
                    cost_usd_minor_units=100,
                    latency_ms=80.0,
                    tokens_complete=True,
                    requested_at=datetime(2026, 4, 28, 10, 0, 0, tzinfo=UTC),
                    recorded_at=datetime(2026, 4, 28, 10, 0, 1, tzinfo=UTC),
                    status="success",
                )
            )
        # Single expensive opus call with dated suffix = 50_000 millicents.
        session.add(
            Request(
                id=str(uuid.uuid4()),
                project_id=proj.id,
                provider="anthropic",
                model="claude-opus-4-7-20260101",
                mode="standard",
                input_tokens=1000,
                output_tokens=500,
                thinking_tokens=0,
                cache_read_tokens=0,
                cache_write_tokens=0,
                cost_usd_minor_units=50_000,
                latency_ms=2000.0,
                tokens_complete=True,
                requested_at=datetime(2026, 4, 28, 11, 0, 0, tzinfo=UTC),
                recorded_at=datetime(2026, 4, 28, 11, 0, 1, tzinfo=UTC),
                status="success",
            )
        )

    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    items = resp.json()
    beta = next(p for p in items if p["slug"] == "beta")
    assert beta["stats"]["top_model"] == "claude-opus-4-7-20260101"
    assert beta["stats"]["top_provider"] == "anthropic"


async def test_top_model_and_top_provider_null_on_empty_project(
    db_path, client
):
    """A project with no captured requests has no top_model or top_provider —
    server returns nulls, dashboard renders an em-dash."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(Project(id=str(uuid.uuid4()), name="gamma", slug="gamma"))

    resp = await client.get("/v1/projects")
    assert resp.status_code == 200
    items = resp.json()
    gamma = next(p for p in items if p["slug"] == "gamma")
    assert gamma["stats"]["top_model"] is None
    assert gamma["stats"]["top_provider"] is None


async def test_top_provider_chosen_independently_of_top_model(
    db_path, client
):
    """When provider B has the highest single-model cost but provider A's
    cost is split across two models (each individually smaller, jointly
    larger), top_provider must rank A and top_model must rank B's model.
    Confirms top_provider is computed from a separate aggregation."""
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="delta", slug="delta")
        session.add(proj)
        await session.flush()
        # Provider A: two models, 600 + 600 = 1200
        for model in ("a-model-1", "a-model-2"):
            session.add(
                Request(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    provider="provider-a",
                    model=model,
                    mode="standard",
                    input_tokens=100,
                    output_tokens=50,
                    thinking_tokens=0,
                    cache_read_tokens=0,
                    cache_write_tokens=0,
                    cost_usd_minor_units=600,
                    latency_ms=100.0,
                    tokens_complete=True,
                    requested_at=datetime(2026, 4, 28, 10, 0, 0, tzinfo=UTC),
                    recorded_at=datetime(2026, 4, 28, 10, 0, 1, tzinfo=UTC),
                    status="success",
                )
            )
        # Provider B: one model, 1000 (highest single model, but provider total < A)
        session.add(
            Request(
                id=str(uuid.uuid4()),
                project_id=proj.id,
                provider="provider-b",
                model="b-model-big",
                mode="standard",
                input_tokens=200,
                output_tokens=100,
                thinking_tokens=0,
                cache_read_tokens=0,
                cache_write_tokens=0,
                cost_usd_minor_units=1000,
                latency_ms=200.0,
                tokens_complete=True,
                requested_at=datetime(2026, 4, 28, 11, 0, 0, tzinfo=UTC),
                recorded_at=datetime(2026, 4, 28, 11, 0, 1, tzinfo=UTC),
                status="success",
            )
        )

    resp = await client.get("/v1/projects")
    items = resp.json()
    delta = next(p for p in items if p["slug"] == "delta")
    assert delta["stats"]["top_model"] == "b-model-big"
    assert delta["stats"]["top_provider"] == "provider-a"
