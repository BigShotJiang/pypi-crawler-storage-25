"""Tests for /v1/daemon/status."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import Project, Request


async def test_status_empty(client):
    resp = await client.get("/v1/daemon/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["last_seen_at"] is None
    assert data["request_count_last_hour"] == 0


@pytest.fixture
async def seed_recent_request(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
        await session.flush()
        now = datetime.now(tz=UTC)
        session.add(
            Request(
                id=str(uuid.uuid4()),
                project_id=proj.id,
                provider="anthropic",
                model="claude-sonnet-4-6",
                mode="standard",
                input_tokens=10,
                output_tokens=5,
                thinking_tokens=0,
                cache_read_tokens=0,
                cost_usd_minor_units=10,
                latency_ms=100.0,
                tokens_complete=True,
                requested_at=now - timedelta(minutes=5),
                recorded_at=now - timedelta(minutes=5),
                status="success",
            )
        )


async def test_status_with_recent_request(client, seed_recent_request):
    resp = await client.get("/v1/daemon/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["last_seen_at"] is not None
    assert data["request_count_last_hour"] == 1
