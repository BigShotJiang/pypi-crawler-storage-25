"""Tests for the audit log API."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import AuditEvent, Project


@pytest.fixture
async def seed_audit(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
        await session.flush()
        for action in ("request.captured", "policy.warned", "rate.updated"):
            session.add(
                AuditEvent(
                    id=str(uuid.uuid4()),
                    project_id=proj.id,
                    request_id=None,
                    policy_id=None,
                    action=action,
                    metadata_={"foo": "bar"},
                    occurred_at=datetime(2026, 4, 28, 10, 0, 0, tzinfo=UTC),
                )
            )


async def test_list_audit_events_empty(client):
    resp = await client.get("/v1/audit")
    assert resp.status_code == 200
    assert resp.json()["total"] == 0


async def test_list_audit_events_returns_seeded(client, seed_audit):
    resp = await client.get("/v1/audit")
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] == 3
    assert len(data["items"]) == 3


async def test_filter_by_action(client, seed_audit):
    resp = await client.get("/v1/audit", params={"action": "policy.warned"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] == 1
    assert data["items"][0]["action"] == "policy.warned"


async def test_post_daemon_event(client):
    body = {
        "action": "daemon.started",
        "project": None,
        "metadata": {"version": "0.0.1"},
    }
    resp = await client.post("/v1/audit/daemon-event", json=body)
    assert resp.status_code == 204

    resp = await client.get("/v1/audit")
    data = resp.json()
    assert data["total"] == 1
    assert data["items"][0]["action"] == "daemon.started"
