"""Tests for the reconciliation API.

POST /v1/reconciliation/run is intentionally 501 in v1.0 — the Anthropic
Admin API integration is deferred to Phase 3. GET routes work normally.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import ReconciliationRecord


@pytest.fixture
async def seed_record(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        session.add(
            ReconciliationRecord(
                id=str(uuid.uuid4()),
                provider="anthropic",
                period_start=datetime(2026, 4, 1, tzinfo=UTC),
                period_end=datetime(2026, 4, 30, tzinfo=UTC),
                our_logged_total_minor_units=12345,
                provider_billed_total_minor_units=12300,
                variance_pct=0.366,
                reconciled_at=datetime(2026, 4, 28, 12, 0, tzinfo=UTC),
                notes=None,
                reconciled_by="manual",
            )
        )


async def test_list_empty(client):
    resp = await client.get("/v1/reconciliation")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_list_with_seed(client, seed_record):
    resp = await client.get("/v1/reconciliation")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    rec = data[0]
    assert rec["provider"] == "anthropic"
    assert rec["status"] == "matched"  # variance < 1.0


async def test_latest_returns_one_per_provider(client, seed_record):
    resp = await client.get("/v1/reconciliation/latest")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    assert data[0]["provider"] == "anthropic"


async def test_run_returns_501(client):
    body = {"provider": "anthropic", "since": "2026-04-01", "until": "2026-04-28"}
    resp = await client.post("/v1/reconciliation/run", json=body)
    assert resp.status_code == 501
    payload = resp.json()
    assert "Phase 3" in payload["detail"]
