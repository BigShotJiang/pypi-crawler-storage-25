"""Tests for POST /v1/requests/batch (forward-compat ingest path)."""

from __future__ import annotations

import uuid

import pytest

from halton_meter.storage import seed_pricing_rates
from halton_meter.storage.engine import create_engine_for


@pytest.fixture(autouse=True)
async def _seed_rates(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session:
        await seed_pricing_rates(session)


def _record(model: str = "claude-sonnet-4-6") -> dict:
    return {
        "id": str(uuid.uuid4()),
        "project": "alpha",
        "provider": "anthropic",
        "model": model,
        "input_tokens": 1_000_000,
        "output_tokens": 100_000,
        "thinking_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "cost_millicents": None,
        "tokens_complete": True,
        "latency_ms": 100.0,
        "requested_at": "2026-04-28T10:00:00Z",
        "recorded_at": "2026-04-28T10:00:01Z",
    }


async def test_batch_inserts_records_and_recomputes_cost(client):
    body = {"batch_id": str(uuid.uuid4()), "records": [_record()]}
    resp = await client.post("/v1/requests/batch", json=body)
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data["accepted"] == 1
    assert data["duplicate"] == 0

    # Project was auto-created
    resp = await client.get("/v1/projects")
    projects = resp.json()
    assert len(projects) == 1
    assert projects[0]["slug"] == "alpha"

    # Cost was recomputed: 1M input @ $3 + 0.1M output @ $15 = $3 + $1.5 = $4.5
    # = 450_000 millicents
    resp = await client.get("/v1/projects/alpha/stats")
    stats = resp.json()
    assert stats["summary"]["total_cost_usd_minor_units"] == 450_000


async def test_batch_idempotent_on_batch_id(client):
    batch_id = str(uuid.uuid4())
    body = {"batch_id": batch_id, "records": [_record()]}
    r1 = await client.post("/v1/requests/batch", json=body)
    r2 = await client.post("/v1/requests/batch", json=body)
    assert r1.json()["accepted"] == 1
    assert r2.json()["accepted"] == 0
    assert r2.json()["duplicate"] == 1
