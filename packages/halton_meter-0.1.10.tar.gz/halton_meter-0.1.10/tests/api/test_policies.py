"""Tests for the policies CRUD API."""

from __future__ import annotations

import uuid

import pytest

from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.models import Project


@pytest.fixture
async def seed_project(db_path):
    _, sessionmaker = create_engine_for(db_path)
    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
    return "alpha"


async def test_list_empty(client, seed_project):
    resp = await client.get("/v1/policies")
    assert resp.status_code == 200
    assert resp.json() == []


async def test_create_and_list_policy(client, seed_project):
    body = {
        "project_slug": seed_project,
        "type": "budget_monthly",
        "config": {"limit_usd_minor_units": 5_000_000},
        "warn_only": True,
    }
    resp = await client.post("/v1/policies", json=body)
    assert resp.status_code == 201, resp.text
    created = resp.json()
    assert created["type"] == "budget_monthly"
    assert created["project_slug"] == seed_project

    resp = await client.get("/v1/policies")
    data = resp.json()
    assert len(data) == 1
    assert data[0]["id"] == created["id"]


async def test_create_policy_for_unknown_project_404(client):
    body = {
        "project_slug": "ghost",
        "type": "budget_monthly",
        "config": {},
    }
    resp = await client.post("/v1/policies", json=body)
    assert resp.status_code == 404


async def test_update_policy_partial(client, seed_project):
    body = {
        "project_slug": seed_project,
        "type": "budget_monthly",
        "config": {"limit_usd_minor_units": 5_000_000},
    }
    resp = await client.post("/v1/policies", json=body)
    pid = resp.json()["id"]

    resp = await client.put(
        f"/v1/policies/{pid}", json={"warn_only": False}
    )
    assert resp.status_code == 200
    assert resp.json()["warn_only"] is False


async def test_delete_soft_deletes(client, seed_project):
    body = {
        "project_slug": seed_project,
        "type": "budget_monthly",
        "config": {},
    }
    resp = await client.post("/v1/policies", json=body)
    pid = resp.json()["id"]

    resp = await client.delete(f"/v1/policies/{pid}")
    assert resp.status_code == 204

    resp = await client.get("/v1/policies")
    assert resp.json() == []
