"""
Tests for the FastAPI app factory and the /health router.

Phase 2B.1 ships a skeleton app — these tests verify the wiring
(app builds, /health returns expected shape, CORS middleware honours
the configured origins) without depending on the storage layer
that lands in 2B.2.
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from halton_meter import __version__
from halton_meter.api import create_app
from halton_meter.config import CorsConfig, HaltonConfig


def test_create_app_builds_a_fastapi_instance() -> None:
    app = create_app()
    assert isinstance(app, FastAPI)


def test_create_app_accepts_config_override() -> None:
    cfg = HaltonConfig(cors=CorsConfig(allow_origins=["http://example.test"]))
    app = create_app(cfg)
    assert isinstance(app, FastAPI)


def test_health_endpoint_returns_ok_with_version() -> None:
    app = create_app()
    client = TestClient(app)

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok", "version": __version__}


def test_health_response_content_type_is_json() -> None:
    app = create_app()
    client = TestClient(app)

    response = client.get("/health")

    assert response.headers["content-type"].startswith("application/json")


def test_cors_preflight_allows_configured_origin() -> None:
    """A cross-origin preflight from an allowed origin returns CORS headers."""
    cfg = HaltonConfig(cors=CorsConfig(allow_origins=["http://localhost:3000"]))
    app = create_app(cfg)
    client = TestClient(app)

    response = client.options(
        "/health",
        headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "content-type",
        },
    )

    assert response.status_code == 200
    assert (
        response.headers.get("access-control-allow-origin") == "http://localhost:3000"
    )
    allow_methods = response.headers.get("access-control-allow-methods", "")
    assert "GET" in allow_methods or "*" in allow_methods


def test_cors_preflight_rejects_unconfigured_origin() -> None:
    """Origins that are not in allow_origins do not get CORS headers echoed back."""
    cfg = HaltonConfig(cors=CorsConfig(allow_origins=["http://localhost:3000"]))
    app = create_app(cfg)
    client = TestClient(app)

    response = client.options(
        "/health",
        headers={
            "Origin": "http://evil.test",
            "Access-Control-Request-Method": "GET",
        },
    )

    # Starlette's CORSMiddleware returns 400 for disallowed preflight, and in
    # any case the allow-origin header is not echoed.
    assert response.headers.get("access-control-allow-origin") != "http://evil.test"


def test_health_endpoint_returns_simple_get() -> None:
    """Confirm the get from a non-CORS context still works."""
    app = create_app()
    client = TestClient(app)

    response = client.get("/health")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert isinstance(body["version"], str) and body["version"]
