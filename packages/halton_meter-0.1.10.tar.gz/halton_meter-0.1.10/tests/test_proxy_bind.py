"""Daemon mitmproxy listener binds ``internal_port`` (2C.2 W2, v0.1.6).

The v0.1.6 edge-proxy decoupling moves the user-facing ``HTTPS_PROXY``
port to a separate edge process. The metering daemon's mitmproxy
listener binds ``internal_port`` (loopback-only, never advertised in
any env var). This test pins that contract by inspecting the
``Options`` object the daemon would construct.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from halton_meter.config import DaemonConfig, HaltonConfig


@pytest.mark.asyncio
async def test_run_proxy_binds_internal_port_not_edge_port(tmp_path):
    """``run_proxy`` must construct ``Options(listen_port=internal_port)``.

    Asserts the daemon never binds the user-facing ``edge_port`` —
    that port belongs exclusively to the edge process.
    """
    cfg = HaltonConfig(
        daemon=DaemonConfig(edge_port=8081, internal_port=8090),
    )

    captured: dict[str, object] = {}

    class _FakeOptions:
        def __init__(self, **kwargs: object) -> None:
            captured.update(kwargs)

    class _FakeMaster:
        def __init__(self, *args: object, **kwargs: object) -> None:
            self.addons = type("A", (), {"add": lambda self, _x: None})()

        async def run(self) -> None:
            return

        def shutdown(self) -> None:
            return

    class _FakeStorage:
        def __init__(self, _path: str) -> None:
            pass

        async def initialise(self) -> None:
            return

        async def close(self) -> None:
            return

    with (
        patch("halton_meter.proxy.Options", _FakeOptions),
        patch("halton_meter.proxy.DumpMaster", _FakeMaster),
        patch("halton_meter.proxy.StorageManager", _FakeStorage),
    ):
        from halton_meter.proxy import run_proxy

        # Storage db_path won't be touched because we faked StorageManager.
        await run_proxy(cfg)

    assert captured["listen_port"] == 8090, (
        "daemon must bind internal_port=8090, not edge_port"
    )
    assert captured["listen_port"] != cfg.daemon.edge_port
    assert captured["listen_host"] == cfg.daemon.listen_host
