"""
v0.1.7 Gap 3 regressions — ``halton-meter doctor --fix [--apply]``
plan-only / apply UX guard + the ``is_running_inside_metered_session``
helper.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from halton_meter import doctor as doctor_module
from halton_meter.cli import cli
from halton_meter.doctor import (
    VERDICT_INCONSISTENT,
    DoctorReport,
    DoctorRow,
    is_running_inside_metered_session,
)
from halton_meter.port_alloc import _write_runtime_toml


def _fake_report_with_one_fail() -> DoctorReport:
    """Synthetic report carrying a single ``fail`` row so ``_run_fix``
    treats the install as fixable and reaches the reconcile branch.
    Required because on a clean test box the real ``run_doctor`` returns
    an all-green report → ``_run_fix`` early-returns at "nothing to do"
    (doctor.py:1024) and never invokes the patched reconcile sweeper.
    """
    row = DoctorRow(
        name="System proxy",
        icon="fail",
        summary="HTTPS proxy not pointed at edge",
        next_action="run halton-meter init",
    )
    return DoctorReport(
        verdict=VERDICT_INCONSISTENT,
        summary_message="install drifted from recorded mode",
        rows=[row],
        mode="env-only",
        platform="darwin",
        version="0.0.0-test",
    )

# --------------------------------------------------------------------------- #
# is_running_inside_metered_session                                           #
# --------------------------------------------------------------------------- #


def test_inside_metered_session_returns_true_when_https_proxy_matches_edge(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"HTTPS_PROXY": "http://127.0.0.1:8082"},
    ) is True


def test_inside_metered_session_returns_true_for_lowercase_var(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"https_proxy": "http://127.0.0.1:8082"},
    ) is True


def test_inside_metered_session_returns_false_when_port_differs(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    # Some unrelated proxy on a different port.
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"HTTPS_PROXY": "http://127.0.0.1:9999"},
    ) is False


def test_inside_metered_session_returns_false_with_no_env(tmp_path: Path) -> None:
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    assert is_running_inside_metered_session(runtime_path=runtime, env={}) is False


def test_inside_metered_session_returns_false_when_runtime_missing(
    tmp_path: Path,
) -> None:
    """Race-safe: while runtime.toml is being atomically rewritten the
    reader returns {}. We err on "no warning" to avoid blocking
    legitimate repair."""
    runtime = tmp_path / "missing.toml"
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"HTTPS_PROXY": "http://127.0.0.1:8082"},
    ) is False


def test_inside_metered_session_returns_false_for_malformed_url(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"HTTPS_PROXY": "::not a url::"},
    ) is False


def test_inside_metered_session_uses_numeric_port_not_substring(
    tmp_path: Path,
) -> None:
    """Substring matching against ":8082" would falsely fire on
    ``http://127.0.0.1:80820`` (a different port that happens to share
    the prefix). The helper compares numerically; verify."""
    runtime = tmp_path / "runtime.toml"
    _write_runtime_toml(runtime, edge_port=8082, internal_port=8090, api_port=8765)
    # The substring ":8082" appears in "8082" but not equal numerically.
    assert is_running_inside_metered_session(
        runtime_path=runtime,
        env={"HTTPS_PROXY": "http://127.0.0.1:80820"},
    ) is False


# --------------------------------------------------------------------------- #
# doctor --fix (plan-only) and --apply (mutating)                              #
# --------------------------------------------------------------------------- #


def test_doctor_fix_plan_only_does_not_call_reconcile(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``doctor --fix`` (no --apply) must NOT mutate state. Verified by
    asserting the canonical sweeper is never invoked."""
    called = {"n": 0}

    def fake_reconcile(_target_mode: str, _console: object) -> None:
        called["n"] += 1

    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", fake_reconcile
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--fix"])
    assert called["n"] == 0, "plan-only must not invoke reconcile"
    # Output should advertise the --apply step.
    assert "--apply" in result.output


def test_doctor_fix_apply_calls_reconcile_when_outside_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When --apply is set AND we're NOT inside a metered session, the
    reconcile fires without prompting."""
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor", lambda **_kw: _fake_report_with_one_fail()
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    seen: dict[str, object] = {}

    def fake_reconcile(target_mode: str, _console: object) -> None:
        seen["target_mode"] = target_mode

    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", fake_reconcile
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--fix", "--apply"])
    assert seen.get("target_mode") == "env-only"
    assert "Repair applied" in result.output


def test_doctor_apply_warns_inside_metered_session_and_aborts_on_no(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When invoked inside a session whose HTTPS_PROXY points at our
    edge, --apply must warn and prompt; declining the prompt aborts
    without calling reconcile."""
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: True
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor", lambda **_kw: _fake_report_with_one_fail()
    )

    fired = {"n": 0}

    def fake_reconcile(_target_mode: str, _console: object) -> None:
        fired["n"] += 1

    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", fake_reconcile
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )

    runner = CliRunner()
    # Decline the confirm prompt by feeding "n\n" on stdin.
    result = runner.invoke(cli, ["doctor", "--fix", "--apply"], input="n\n")
    assert fired["n"] == 0
    assert "Aborted" in result.output
    # The warning copy must appear so the user understands the risk.
    assert "proxied session" in result.output
    assert "fresh terminal" in result.output


def test_doctor_apply_inside_session_proceeds_when_user_confirms(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: True
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor", lambda **_kw: _fake_report_with_one_fail()
    )
    fired = {"n": 0}

    def fake_reconcile(_target_mode: str, _console: object) -> None:
        fired["n"] += 1

    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", fake_reconcile
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--fix", "--apply"], input="y\n")
    assert fired["n"] == 1
    assert "Repair applied" in result.output


def test_doctor_fix_covers_edge_chain_target(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Reconcile alone rewrites plists + launchctl env but does NOT
    bounce the live edge — a Gap 0 stale-chain row would survive an
    apply. Verify ``_run_fix`` shells ``launchctl kickstart -k
    gui/$UID/com.haltonlabs.meter.edge`` after reconcile when the
    Edge-proxy row is flagged stale-chain.
    """
    import os
    import subprocess
    import sys as _sys

    from rich.console import Console

    from halton_meter.doctor import (
        VERDICT_INCONSISTENT,
        DoctorReport,
        DoctorRow,
        _run_fix,
    )
    from halton_meter.install import _EDGE_LABEL

    if _sys.platform != "darwin":
        pytest.skip("kickstart path is macOS-only")

    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )

    captured: dict[str, object] = {}

    def fake_run(cmd, **kwargs):  # type: ignore[no-untyped-def]
        captured["cmd"] = list(cmd)
        captured["kwargs"] = kwargs
        return subprocess.CompletedProcess(args=cmd, returncode=0, stdout="", stderr="")

    monkeypatch.setattr(subprocess, "run", fake_run)
    # The doctor module imported subprocess at import-time, so patch
    # the binding it actually calls.
    monkeypatch.setattr(doctor_module.subprocess, "run", fake_run)

    stale_row = DoctorRow(
        name="Edge proxy",
        icon="warn",
        summary="PID 4321, port=:8080, chain :8090 but daemon on :8091 (stale chain target)",
        next_action="kick the edge",
    )
    report = DoctorReport(
        verdict=VERDICT_INCONSISTENT,
        summary_message="stale chain",
        rows=[stale_row],
        mode="env-only",
        platform="darwin",
        version="0.0.0-test",
    )

    _run_fix(report, apply_repair=True, console=Console(record=True))

    assert "cmd" in captured, "launchctl kickstart was not invoked"
    cmd = captured["cmd"]
    expected_target = f"gui/{os.getuid()}/{_EDGE_LABEL}"
    assert cmd == ["launchctl", "kickstart", "-k", expected_target], cmd


def test_doctor_apply_implies_fix(monkeypatch: pytest.MonkeyPatch) -> None:
    """``doctor --apply`` (no explicit --fix) must still execute the
    repair — bare ``--apply`` is the most common invocation."""
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor", lambda **_kw: _fake_report_with_one_fail()
    )
    fired = {"n": 0}

    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode",
        lambda *_a, **_kw: fired.__setitem__("n", fired["n"] + 1),
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )

    runner = CliRunner()
    runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 1


# --------------------------------------------------------------------------- #
# v0.1.9 Gap 14 — per-row reconcile dispatch                                  #
# --------------------------------------------------------------------------- #
#
# These exercise :func:`doctor._apply_extra_fixers`. Each test constructs
# a synthetic DoctorReport with the relevant row in warn/fail state,
# patches the fixer it should dispatch to, and asserts the fixer fires.


def _report_with_row(row_name: str, *, icon: str = "fail") -> DoctorReport:
    row = DoctorRow(
        name=row_name,
        icon=icon,
        summary="synthetic",
        next_action=None,
    )
    return DoctorReport(
        verdict=VERDICT_INCONSISTENT,
        summary_message="synthetic",
        rows=[row],
        mode="env-only",
        platform="darwin",
        version="0.0.0-test",
    )


def test_gap14_dispatch_mitmproxy_ca_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor",
        lambda **_kw: _report_with_row("mitmproxy CA cert"),
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    fired = {"n": 0}

    def fake_generate(*, force: bool = False) -> object:
        fired["n"] += 1
        from halton_meter.setup import StepStatus

        return StepStatus(name="x", done=True, note="generated")

    monkeypatch.setattr(
        "halton_meter.setup.generate_mitmproxy_cert", fake_generate
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 1, result.output
    assert "Fixing" in result.output


def test_gap14_dispatch_certifi_patched(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor",
        lambda **_kw: _report_with_row(
            "Certifi bundle patched", icon="warn"
        ),
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    fired = {"n": 0}

    def fake_patch(*, force: bool = False) -> object:
        fired["n"] += 1
        from halton_meter.setup import StepStatus

        return StepStatus(name="x", done=True, note="patched")

    monkeypatch.setattr("halton_meter.setup.patch_certifi", fake_patch)

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 1, result.output


def test_gap14_dispatch_cert_trust(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor",
        lambda **_kw: _report_with_row(
            "Cert trust (security verify-cert -p ssl)"
        ),
    )
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    fired = {"n": 0}

    def fake_trust(*, force: bool = False, console: object = None) -> object:
        fired["n"] += 1
        from halton_meter.setup import StepStatus

        return StepStatus(name="x", done=True, note="trusted")

    monkeypatch.setattr("halton_meter.setup.trust_cert_macos", fake_trust)

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 1, result.output


def test_gap14_dispatch_shell_rc_prompts_and_appends(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    monkeypatch.setattr(
        doctor_module, "run_doctor",
        lambda **_kw: _report_with_row("Shell rc marker", icon="warn"),
    )
    # Apps mode so the shell-rc fixer actually runs.
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "apps"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    rc_path = tmp_path / "fake-zshrc"
    rc_path.write_text("# pre-existing\n")

    monkeypatch.setattr(
        "halton_meter.init.detect_shell_rc", lambda: rc_path
    )

    fired = {"n": 0}

    def fake_append(rc: Path, env_vars: dict[str, str]) -> str:
        fired["n"] += 1
        return "appended"

    monkeypatch.setattr(
        "halton_meter.init.append_coverage_block_to_rc", fake_append
    )
    # build_env_vars + load_effective_config wired by default — skip the
    # dependency by stubbing both.
    from halton_meter import config as _config_module

    monkeypatch.setattr(
        "halton_meter.port_alloc.load_effective_config",
        lambda *a, **kw: _config_module.HaltonConfig(),
    )

    runner = CliRunner()
    # "y" confirms the apply prompt (no inside-session warning, since
    # is_running_inside_metered_session=False), then "y" again confirms
    # the per-row shell-rc append prompt.
    result = runner.invoke(cli, ["doctor", "--apply"], input="y\n")
    assert fired["n"] == 1, result.output


def test_gap14_fixer_failure_does_not_abort_other_rows(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """One rotten fixer must not block the rest of the apply pass.

    Construct a report with two fixable rows; make the first fixer
    raise; assert the second fixer still fires.
    """
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    rows = [
        DoctorRow(name="mitmproxy CA cert", icon="fail", summary="x"),
        DoctorRow(
            name="Certifi bundle patched", icon="warn", summary="x"
        ),
    ]
    report = DoctorReport(
        verdict=VERDICT_INCONSISTENT,
        summary_message="x",
        rows=rows,
        mode="env-only",
        platform="darwin",
        version="0.0.0-test",
    )
    monkeypatch.setattr(doctor_module, "run_doctor", lambda **_kw: report)
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    def boom(*_a, **_kw):  # type: ignore[no-untyped-def]
        msg = "synthetic boom"
        raise RuntimeError(msg)

    monkeypatch.setattr("halton_meter.setup.generate_mitmproxy_cert", boom)

    fired = {"n": 0}

    def fake_patch(*, force: bool = False) -> object:
        fired["n"] += 1
        from halton_meter.setup import StepStatus

        return StepStatus(name="x", done=True, note="patched")

    monkeypatch.setattr("halton_meter.setup.patch_certifi", fake_patch)

    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 1, result.output
    # The error from the first fixer should be surfaced (continuing).
    assert "synthetic boom" in result.output or "fixer for" in result.output


def test_gap14_ok_row_does_not_dispatch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An ok row must NOT dispatch its fixer even when a name match exists."""
    monkeypatch.setattr(
        doctor_module, "is_running_inside_metered_session", lambda **_kw: False
    )
    # Two rows: one fail (so apply reaches the dispatch loop), one ok
    # whose fixer must not fire.
    rows = [
        DoctorRow(name="System proxy", icon="fail", summary="x"),
        DoctorRow(name="mitmproxy CA cert", icon="ok", summary="present"),
    ]
    report = DoctorReport(
        verdict=VERDICT_INCONSISTENT,
        summary_message="x",
        rows=rows,
        mode="env-only",
        platform="darwin",
        version="0.0.0-test",
    )
    monkeypatch.setattr(doctor_module, "run_doctor", lambda **_kw: report)
    monkeypatch.setattr(
        "halton_meter.init.read_install_mode", lambda: "env-only"
    )
    monkeypatch.setattr(
        "halton_meter.init._reconcile_to_mode", lambda *_a, **_kw: None
    )

    fired = {"n": 0}

    def fake_generate(*, force: bool = False) -> object:
        fired["n"] += 1
        from halton_meter.setup import StepStatus

        return StepStatus(name="x", done=True, note="x")

    monkeypatch.setattr(
        "halton_meter.setup.generate_mitmproxy_cert", fake_generate
    )

    runner = CliRunner()
    runner.invoke(cli, ["doctor", "--apply"])
    assert fired["n"] == 0
