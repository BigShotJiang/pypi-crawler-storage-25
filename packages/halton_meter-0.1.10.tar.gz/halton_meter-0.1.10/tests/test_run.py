"""Tests for ``halton_meter.run`` (v0.1.3 P0-4 — exec wrapper).

The exec path is mocked end-to-end: we monkeypatch ``os.execvpe`` so the
test process is never actually replaced. Pre-flight is mocked via
``urllib.request.urlopen``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import run as run_module
from halton_meter.cli import cli


@pytest.fixture(autouse=True)
def _redirect_runtime_paths(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Make sure tests don't read or write the developer's real
    ``~/.halton-meter/runtime.toml`` or ``config.toml``."""
    from halton_meter import port_alloc

    monkeypatch.setattr(
        port_alloc, "RUNTIME_TOML_PATH", tmp_path / "missing-runtime.toml"
    )
    monkeypatch.setattr(
        port_alloc, "CONFIG_TOML_PATH", tmp_path / "missing-config.toml"
    )


# --------------------------------------------------------------------------- #
# _build_run_env                                                              #
# --------------------------------------------------------------------------- #


def test_build_run_env_contains_required_keys(tmp_path: Path) -> None:
    bundle = tmp_path / "cabundle.pem"
    env = run_module._build_run_env("127.0.0.1", 8080, bundle)
    assert env["HTTPS_PROXY"] == "http://127.0.0.1:8080"
    assert env["HTTP_PROXY"] == "http://127.0.0.1:8080"
    assert env["NO_PROXY"] == "localhost,127.0.0.1"
    assert env["NODE_EXTRA_CA_CERTS"] == str(bundle)
    assert env["SSL_CERT_FILE"] == str(bundle)
    assert env["REQUESTS_CA_BUNDLE"] == str(bundle)
    # v0.1.5.1: per-tool CA bundles for tools that don't read
    # SSL_CERT_FILE. Witnessed: ``git push`` failed because git uses
    # ``GIT_SSL_CAINFO``. Same shape applies to curl and AWS SDK.
    assert env["GIT_SSL_CAINFO"] == str(bundle)
    assert env["CURL_CA_BUNDLE"] == str(bundle)
    assert env["AWS_CA_BUNDLE"] == str(bundle)


def test_build_run_env_uses_resolved_port(tmp_path: Path) -> None:
    """When the daemon allocated 8081 instead of 8080 (P0-5), the run
    wrapper must use the resolved port — not the default."""
    bundle = tmp_path / "cabundle.pem"
    env = run_module._build_run_env("127.0.0.1", 8081, bundle)
    assert env["HTTPS_PROXY"] == "http://127.0.0.1:8081"


# --------------------------------------------------------------------------- #
# Pre-flight                                                                  #
# --------------------------------------------------------------------------- #


def test_preflight_returns_true_on_200(monkeypatch: pytest.MonkeyPatch) -> None:
    class _FakeResp:
        status = 200

        def __enter__(self) -> _FakeResp:
            return self

        def __exit__(self, *_args: Any) -> None:
            return None

    monkeypatch.setattr(
        run_module.urllib.request, "urlopen",
        lambda *_a, **_kw: _FakeResp(),
    )
    assert run_module._preflight_health("127.0.0.1", 8765, timeout=3.0) is True


def test_preflight_returns_false_on_url_error(monkeypatch: pytest.MonkeyPatch) -> None:
    import urllib.error

    monkeypatch.setattr(
        run_module.urllib.request, "urlopen",
        lambda *_a, **_kw: (_ for _ in ()).throw(urllib.error.URLError("nope")),
    )
    assert run_module._preflight_health("127.0.0.1", 8765, timeout=0.1) is False


def test_preflight_returns_false_on_socket_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        run_module.urllib.request, "urlopen",
        lambda *_a, **_kw: (_ for _ in ()).throw(OSError("connection refused")),
    )
    assert run_module._preflight_health("127.0.0.1", 8765, timeout=0.1) is False


# --------------------------------------------------------------------------- #
# run_cmd refusal paths                                                       #
# --------------------------------------------------------------------------- #


def test_run_cmd_refuses_when_daemon_not_responding(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: False)
    rc = run_module.run_cmd(("claude",))
    assert rc == 1


def test_run_cmd_refusal_includes_mode_hint_in_apps_mode(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.5 (2B.16): when the daemon is down and install-mode is
    apps/full, the refusal includes a hint that the daemon is still
    needed even though the user has the global env vars set."""
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: False)
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: "apps")
    rc = run_module.run_cmd(("claude",))
    assert rc == 1
    captured = capsys.readouterr()
    assert "--apps mode" in captured.err


def test_run_cmd_refusal_no_mode_hint_in_env_only_mode(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """env-only mode refusal does NOT include the mode hint (it would
    be redundant — env-only users already know `run` is the primary
    surface)."""
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: False)
    from halton_meter import init as init_module

    monkeypatch.setattr(init_module, "read_install_mode", lambda: "env-only")
    rc = run_module.run_cmd(("claude",))
    assert rc == 1
    captured = capsys.readouterr()
    assert "mode" not in captured.err.replace("daemon not responding", "")


def test_run_cmd_refuses_with_no_args_or_shell(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Empty cmd + use_shell=False -> refuse (4)."""
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(run_module, "_certifi_bundle_path", lambda: bundle, raising=False)
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )
    rc = run_module.run_cmd((), use_shell=False)
    assert rc == 4


def test_run_cmd_shell_refuses_when_shell_env_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )
    monkeypatch.delenv("SHELL", raising=False)
    rc = run_module.run_cmd((), use_shell=True)
    assert rc == 3


# --------------------------------------------------------------------------- #
# run_cmd happy path: assert env + argv passed to execvpe                     #
# --------------------------------------------------------------------------- #


def test_run_cmd_execvpe_receives_correct_argv_and_env(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )

    captured: dict[str, Any] = {}

    def fake_execvpe(file: str, argv: list[str], env: dict[str, str]) -> None:
        captured["file"] = file
        captured["argv"] = list(argv)
        captured["env"] = dict(env)

    monkeypatch.setattr(run_module.os, "execvpe", fake_execvpe)

    # On success, run_cmd never returns (execvpe replaces process). Our
    # fake returns None so the function falls through to its unreachable
    # ``return 0``.
    rc = run_module.run_cmd(("python", "my_script.py", "--flag"))
    # We don't actually care about the rc here — what matters is the
    # captured execvpe args.
    assert rc == 0
    assert captured["file"] == "python"
    assert captured["argv"] == ["python", "my_script.py", "--flag"]
    # Env is the merge: parent env + our overrides.
    env = captured["env"]
    assert env["HTTPS_PROXY"].startswith("http://127.0.0.1:")
    assert env["NO_PROXY"] == "localhost,127.0.0.1"
    assert env["NODE_EXTRA_CA_CERTS"] == str(bundle)


def test_run_cmd_shell_uses_user_shell_path(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )
    monkeypatch.setenv("SHELL", "/bin/zsh")

    captured: dict[str, Any] = {}

    def fake_execvpe(file: str, argv: list[str], env: dict[str, str]) -> None:
        captured["file"] = file
        captured["argv"] = list(argv)

    monkeypatch.setattr(run_module.os, "execvpe", fake_execvpe)

    run_module.run_cmd((), use_shell=True)
    assert captured["file"] == "/bin/zsh"
    assert captured["argv"] == ["/bin/zsh"]


def test_run_cmd_returns_127_on_command_not_found(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )

    def boom(*_a: Any, **_kw: Any) -> None:
        raise FileNotFoundError("no such bin")

    monkeypatch.setattr(run_module.os, "execvpe", boom)
    rc = run_module.run_cmd(("does-not-exist",))
    assert rc == 127


def test_run_cmd_returns_126_on_other_oserror(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )

    def boom(*_a: Any, **_kw: Any) -> None:
        raise OSError("permission denied")

    monkeypatch.setattr(run_module.os, "execvpe", boom)
    rc = run_module.run_cmd(("python",))
    assert rc == 126


# --------------------------------------------------------------------------- #
# CLI integration via Click                                                    #
# --------------------------------------------------------------------------- #


def test_cli_run_passes_args_through_unprocessed(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Click's ignore_unknown_options + UNPROCESSED type lets the user's
    flags like ``--flag`` reach the target command."""
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: True)
    bundle = tmp_path / "cabundle.pem"
    bundle.write_text("CERT", encoding="utf-8")
    monkeypatch.setattr(
        "halton_meter.setup._certifi_bundle_path", lambda: bundle
    )

    captured: dict[str, Any] = {}

    def fake_execvpe(file: str, argv: list[str], env: dict[str, str]) -> None:
        captured["argv"] = list(argv)

    monkeypatch.setattr(run_module.os, "execvpe", fake_execvpe)

    runner = CliRunner()
    result = runner.invoke(
        cli, ["run", "--", "python", "-c", "print('hi')"]
    )
    # SystemExit propagates as exit_code==0 because fake_execvpe returns
    # None and run_cmd falls through to ``return 0``.
    assert result.exit_code == 0
    assert captured["argv"] == ["python", "-c", "print('hi')"]


def test_cli_run_refusal_when_daemon_down_exits_nonzero(
    monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(run_module, "_preflight_health", lambda *_a, **_kw: False)
    runner = CliRunner()
    result = runner.invoke(cli, ["run", "echo", "hi"])
    assert result.exit_code == 1
    # Useful error message present.
    stderr_text = (result.stderr_bytes or b"").decode()
    assert ("halton-meter init" in result.output) or ("halton-meter init" in stderr_text)
