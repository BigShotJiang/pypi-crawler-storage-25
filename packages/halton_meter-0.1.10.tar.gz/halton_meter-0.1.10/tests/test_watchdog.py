"""Tests for ``halton_meter.watchdog`` (layer 2 of the connectivity-on-crash fix).

State machine tests are pure-logic with no I/O. Side-effect tests
mock ``subprocess.run`` and ``urllib.request.urlopen``. Real subprocess
only inside the optional ``requires_launchd`` integration, which is
hard-skipped in this commit (Vikrant's auto-memory is explicit that
touching his real system proxy in tests is off-limits).
"""

from __future__ import annotations

import io
import json
import shutil
import subprocess
import urllib.error
from typing import Any

import pytest

from halton_meter import watchdog

# --------------------------------------------------------------------------- #
# State machine                                                                #
# --------------------------------------------------------------------------- #


def test_state_machine_starts_healthy() -> None:
    sm = watchdog.WatchdogStateMachine()
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert sm.success_count == 0


def test_first_fail_moves_to_degrading() -> None:
    sm = watchdog.WatchdogStateMachine()
    t = sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.DEGRADING
    assert t.from_ is watchdog.WatchdogState.HEALTHY
    assert t.to is watchdog.WatchdogState.DEGRADING
    assert t.fail_count == 1
    assert t.should_disable_proxy_now is False


def test_success_during_degrading_returns_to_healthy_and_resets_fail_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    sm.record_health(success=False)
    sm.record_health(success=False)
    assert sm.fail_count == 2
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert t.from_ is watchdog.WatchdogState.DEGRADING
    assert t.to is watchdog.WatchdogState.HEALTHY


def test_five_consecutive_fails_transition_to_proxy_disabled_and_signal_disable() -> None:
    sm = watchdog.WatchdogStateMachine()
    transitions = [sm.record_health(success=False) for _ in range(5)]
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    # Disable signal fires exactly on the 5th fail (the
    # DEGRADING -> PROXY_DISABLED edge) and not before.
    assert [t.should_disable_proxy_now for t in transitions] == [
        False,
        False,
        False,
        False,
        True,
    ]


def test_disable_signal_emitted_only_once_per_transition() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    # Continued failures from PROXY_DISABLED must NOT re-emit disable.
    for _ in range(10):
        t = sm.record_health(success=False)
        assert t.should_disable_proxy_now is False


def test_first_success_in_proxy_disabled_moves_to_recovering() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.RECOVERING
    assert t.from_ is watchdog.WatchdogState.PROXY_DISABLED
    assert t.to is watchdog.WatchdogState.RECOVERING
    assert sm.success_count == 1


def test_fail_in_recovering_returns_to_proxy_disabled_and_resets_success_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    sm.record_health(success=True)
    sm.record_health(success=True)
    assert sm.success_count == 2
    t = sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    assert sm.success_count == 0
    assert t.should_disable_proxy_now is False


def test_three_consecutive_successes_in_recovering_return_to_healthy() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    sm.record_health(success=True)
    sm.record_health(success=True)
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert t.from_ is watchdog.WatchdogState.RECOVERING
    assert t.to is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert sm.success_count == 0


def test_flapping_in_degrading_never_reaches_proxy_disabled() -> None:
    sm = watchdog.WatchdogStateMachine()
    # Pattern: fail, succeed, fail, succeed, ... never accumulates 5 fails.
    for _ in range(20):
        sm.record_health(success=False)
        sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY


def test_flapping_in_recovering_resets_success_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    # Pattern: succeed, fail, succeed, fail — never gets 3 successes in a row.
    for _ in range(10):
        sm.record_health(success=True)
        sm.record_health(success=False)
    # Last call was fail -> back in PROXY_DISABLED.
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED


# --------------------------------------------------------------------------- #
# disable_system_proxy                                                         #
# --------------------------------------------------------------------------- #


def test_disable_system_proxy_calls_networksetup_per_combo(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(watchdog.subprocess, "run", fake_run)

    watchdog.disable_system_proxy(["Wi-Fi", "Ethernet"])

    expected = {
        ("networksetup", "-setsecurewebproxystate", "Wi-Fi", "off"),
        ("networksetup", "-setwebproxystate", "Wi-Fi", "off"),
        ("networksetup", "-setsecurewebproxystate", "Ethernet", "off"),
        ("networksetup", "-setwebproxystate", "Ethernet", "off"),
    }
    assert {tuple(c) for c in calls} == expected


def test_disable_system_proxy_attempts_all_even_when_one_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def flaky(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        if "Wi-Fi" in argv:
            raise OSError("simulated")
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(watchdog.subprocess, "run", flaky)

    watchdog.disable_system_proxy(["Wi-Fi", "Ethernet"])
    # All four combos still attempted.
    assert len(calls) == 4


# --------------------------------------------------------------------------- #
# poll_health                                                                  #
# --------------------------------------------------------------------------- #


class _FakeResp:
    def __init__(self, status: int, body: bytes) -> None:
        self.status = status
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> _FakeResp:
        return self

    def __exit__(self, *_a: Any) -> None:
        return None


def test_poll_health_returns_true_for_200_ok_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    body = json.dumps({"status": "ok", "version": "x"}).encode("utf-8")

    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, body)

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is True


def test_poll_health_returns_false_on_url_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_socket_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise TimeoutError("timed out")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_500(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(500, b"boom")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_malformed_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, b"<html>not json</html>")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_generic_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise RuntimeError("anything else")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    # Must not propagate.
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_wrong_status_field(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    body = json.dumps({"status": "degraded"}).encode("utf-8")

    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, body)

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


# --------------------------------------------------------------------------- #
# snapshot_interfaces                                                          #
# --------------------------------------------------------------------------- #


def test_snapshot_interfaces_non_macos_returns_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "linux")
    assert watchdog.snapshot_interfaces(8765) == []


def test_snapshot_interfaces_returns_matching_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")

    def fake_read(iface: str, *, secure: bool = True) -> tuple[bool, str | None, int | None]:
        if iface == "Wi-Fi":
            return (True, "127.0.0.1", 8080)
        if iface == "Ethernet":
            return (True, "10.0.0.5", 3128)  # someone else's proxy
        return (False, None, None)

    monkeypatch.setattr(watchdog.system_proxy, "read_proxy_target", fake_read)
    assert watchdog.snapshot_interfaces(8080) == ["Wi-Fi"]


def test_snapshot_interfaces_returns_empty_when_nothing_points_at_us(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")
    monkeypatch.setattr(
        watchdog.system_proxy,
        "read_proxy_target",
        lambda _iface, *, secure=True: (False, None, None),
    )
    assert watchdog.snapshot_interfaces(8080) == []


def test_snapshot_interfaces_matches_listen_port_not_api_port(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.5 regression. ``snapshot_interfaces`` must match against the
    proxy listener port (``daemon.listen_port``, default 8080), NOT the
    FastAPI ``/health`` port (``daemon.api_port``, default 8765). The
    OS stores the listener address on each network service; matching
    against ``api_port`` would always return empty on a real install
    where the two ports are distinct."""
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")

    def fake_read(iface: str, *, secure: bool = True) -> tuple[bool, str | None, int | None]:
        # Exactly the shape Vikrant's Mac sees post-install: each
        # interface points at the mitmproxy listener (8080), not the
        # API (8765).
        if iface == "Wi-Fi":
            return (True, "127.0.0.1", 8080)
        return (False, None, None)

    monkeypatch.setattr(watchdog.system_proxy, "read_proxy_target", fake_read)
    monkeypatch.setattr(
        watchdog.system_proxy,
        "_macos_interfaces",
        lambda: ("Wi-Fi", "Thunderbolt Bridge"),
    )

    # The new contract: pass listen_port → matches.
    assert watchdog.snapshot_interfaces(8080) == ["Wi-Fi"]

    # The bug: passing api_port → no match (was the silent failure
    # mode prior to 2B.10.5).
    assert watchdog.snapshot_interfaces(8765) == []


# --------------------------------------------------------------------------- #
# run_watchdog                                                                 #
# --------------------------------------------------------------------------- #


def test_run_watchdog_exits_zero_when_no_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: [])
    rc = watchdog.run_watchdog(8765)
    assert rc == 0


def test_run_watchdog_uses_listen_port_for_snapshot_and_api_port_for_health(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.5: ``run_watchdog`` must snapshot interfaces on
    ``listen_port`` (proxy listener) and poll ``/health`` on
    ``api_port`` (FastAPI). Two distinct ports, two distinct purposes."""
    snapshot_calls: list[int] = []
    health_calls: list[int] = []

    def fake_snapshot(port: int) -> list[str]:
        snapshot_calls.append(port)
        return ["Wi-Fi"]

    def fake_poll(port: int, timeout: float = 1.0) -> bool:
        health_calls.append(port)
        return True

    monkeypatch.setattr(watchdog, "snapshot_interfaces", fake_snapshot)
    monkeypatch.setattr(watchdog, "poll_health", fake_poll)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    rc = watchdog.run_watchdog(8765, listen_port=8080, max_polls=3)
    assert rc == 0
    assert snapshot_calls == [8080], (
        "snapshot_interfaces should be called with listen_port (8080)"
    )
    assert health_calls == [8765, 8765, 8765], (
        "poll_health should be called with api_port (8765)"
    )


def test_run_watchdog_disables_proxy_after_threshold(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # First poll succeeds to latch the 2B.10.8 cold-start gate open;
    # subsequent polls all fail to drive the DEGRADING ->
    # PROXY_DISABLED edge.
    poll_results = iter([True] + [False] * 20)
    monkeypatch.setattr(
        watchdog, "poll_health", lambda _port, timeout=1.0: next(poll_results)
    )
    # Don't actually sleep.
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []

    def fake_disable(interfaces: list[str]) -> None:
        disable_calls.append(list(interfaces))

    monkeypatch.setattr(watchdog, "disable_system_proxy", fake_disable)

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # Disabled exactly once across the 10 polls.
    assert disable_calls == [["Wi-Fi"]]


def test_run_watchdog_does_not_disable_during_cold_start_before_first_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.8: the watchdog must NOT call ``disable_system_proxy``
    when the state machine reaches PROXY_DISABLED before any
    successful ``/health`` response has been observed.

    Cold-start race: launchd ``RunAtLoad`` starts the watchdog
    concurrently with the daemon, and on Python 3.14 the daemon takes
    several seconds before ``/health`` answers 200. Without this gate,
    the watchdog's first 5 failed polls would tear down the user's
    system proxy moments after ``halton-meter start``."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # Always unhealthy; daemon never comes up during the test window.
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: False)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # State machine fired PROXY_DISABLED at fail #5 but the gate
    # suppressed the actual disable because no success was ever seen.
    assert disable_calls == [], (
        "watchdog must not disable proxy if it has never seen a healthy "
        "/health response — the daemon may simply still be starting"
    )


def test_run_watchdog_disables_after_first_success_then_failures(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.8: once the watchdog has observed at least one successful
    ``/health`` response, the cold-start gate latches open and the
    normal disable-on-threshold behaviour applies for the rest of the
    process lifetime."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # First poll succeeds (daemon is up); subsequent polls all fail
    # (daemon froze after coming up).
    poll_results = iter([True] + [False] * 20)

    def fake_poll(_port: int, timeout: float = 1.0) -> bool:
        return next(poll_results)

    monkeypatch.setattr(watchdog, "poll_health", fake_poll)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # 1 success (latches gate open) + 5 failures (DEGRADING ->
    # PROXY_DISABLED edge) = exactly one disable, then 4 more failures
    # in PROXY_DISABLED that don't re-disable.
    assert disable_calls == [["Wi-Fi"]], (
        "after first success, watchdog must disable proxy exactly once "
        "on the DEGRADING -> PROXY_DISABLED edge"
    )


def test_run_watchdog_never_disables_when_healthy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=20)
    assert rc == 0
    assert disable_calls == []


# --------------------------------------------------------------------------- #
# poll_once                                                                    #
# --------------------------------------------------------------------------- #


def test_poll_once_returns_zero_when_healthy(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: True)
    assert watchdog.poll_once(8765) == 0


def test_poll_once_returns_one_when_unhealthy(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: False)
    assert watchdog.poll_once(8765) == 1


# --------------------------------------------------------------------------- #
# Integration test (hard-skipped: do not touch user's real system proxy)       #
# --------------------------------------------------------------------------- #


@pytest.mark.skipif(
    shutil.which("launchctl") is None,
    reason="launchctl unavailable — integration test only meaningful on macOS",
)
def test_real_launchd_watchdog_smoke_disabled() -> None:
    """Placeholder.

    A real watchdog-vs-frozen-daemon smoke test would need a tmp-path
    plist and a fake ``networksetup`` binary on PATH to avoid touching
    the user's real system proxy. Vikrant's ``feedback_dont_kill_proxy.md``
    auto-memory is explicit that we do not run kill-based or SIGSTOP
    smoke tests against the live daemon from CI; the user-runnable
    ``daemon/scripts/smoke_layer_2.sh`` covers that path manually.
    """
    pytest.skip("integration disabled to honour 'don't kill proxy' auto-memory")


# Make BytesIO importable in this module so the fake response object's
# read() shape stays close to urllib.response.addinfourl's contract;
# unused otherwise.
_ = io
