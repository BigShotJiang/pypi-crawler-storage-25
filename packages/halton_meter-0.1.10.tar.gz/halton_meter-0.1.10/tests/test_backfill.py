"""
Tests for the legacy-requests backfill (Phase 2B.3 follow-up).

The daemon's `init_db()` renames the Phase-1 `requests` table to
`requests_legacy` whenever it detects the old schema, then `create_all()`
builds the v1.0 tables alongside it. `backfill_legacy_requests()` migrates
the rows over so the dashboard and CLI report don't appear to lose history.

These tests use a real SQLite file (no mocks) and seed the legacy table by
running the Phase-1 DDL directly.
"""

from __future__ import annotations

import sqlite3
import uuid
from pathlib import Path

import pytest

from halton_meter.storage import StorageManager
from halton_meter.storage.engine import create_engine_for
from halton_meter.storage.repo import backfill_legacy_requests, init_db

LEGACY_DDL = """
CREATE TABLE requests (
    id               TEXT    NOT NULL PRIMARY KEY,
    project          TEXT    NOT NULL,
    provider         TEXT    NOT NULL,
    model            TEXT    NOT NULL,
    input_tokens     INTEGER NOT NULL DEFAULT 0,
    output_tokens    INTEGER NOT NULL DEFAULT 0,
    thinking_tokens  INTEGER NOT NULL DEFAULT 0,
    cached_tokens    INTEGER NOT NULL DEFAULT 0,
    cost_millicents  INTEGER,
    tokens_complete  INTEGER NOT NULL DEFAULT 1,
    latency_ms       REAL    NOT NULL DEFAULT 0.0,
    requested_at     TEXT    NOT NULL,
    recorded_at      TEXT    NOT NULL,
    synced_at        TEXT,
    status           TEXT    NOT NULL DEFAULT 'success'
);
"""


def _seed_legacy_db(db: Path, rows: list[dict]) -> None:
    """Create a legacy-shaped DB with `requests` rows on disk."""
    conn = sqlite3.connect(db)
    try:
        conn.executescript(LEGACY_DDL)
        conn.executemany(
            "INSERT INTO requests (id, project, provider, model, "
            "input_tokens, output_tokens, thinking_tokens, cached_tokens, "
            "cost_millicents, tokens_complete, latency_ms, requested_at, "
            "recorded_at, status) VALUES "
            "(:id, :project, :provider, :model, :input_tokens, :output_tokens, "
            ":thinking_tokens, :cached_tokens, :cost_millicents, "
            ":tokens_complete, :latency_ms, :requested_at, :recorded_at, :status)",
            rows,
        )
        conn.commit()
    finally:
        conn.close()


def _legacy_row(
    *,
    id: str | None = None,
    project: str = "alpha",
    cost_millicents: int = 1000,
    thinking_tokens: int = 0,
) -> dict:
    return {
        "id": id or str(uuid.uuid4()),
        "project": project,
        "provider": "anthropic",
        "model": "claude-sonnet-4-6",
        "input_tokens": 100,
        "output_tokens": 50,
        "thinking_tokens": thinking_tokens,
        "cached_tokens": 0,
        "cost_millicents": cost_millicents,
        "tokens_complete": 1,
        "latency_ms": 123.4,
        "requested_at": "2026-04-28T10:00:00+00:00",
        "recorded_at": "2026-04-28T10:00:01+00:00",
        "status": "success",
    }


@pytest.mark.asyncio
async def test_backfill_greenfield_is_noop(tmp_path: Path) -> None:
    """No requests_legacy table → backfill returns 0 silently."""
    db = tmp_path / "fresh.db"
    async with StorageManager(db) as storage:
        # Initialising a brand new DB triggers the backfill internally.
        # A second explicit call must also be a no-op.
        assert storage._sessionmaker is not None
        count = await backfill_legacy_requests(storage._sessionmaker)
        assert count == 0


@pytest.mark.asyncio
async def test_backfill_migrates_legacy_rows(tmp_path: Path) -> None:
    """A legacy-shaped DB with rows is migrated into the new schema."""
    db = tmp_path / "legacy.db"
    rows = [
        _legacy_row(project="alpha", cost_millicents=500),
        _legacy_row(project="alpha", cost_millicents=750),
        _legacy_row(project="beta", cost_millicents=1200, thinking_tokens=20),
    ]
    _seed_legacy_db(db, rows)

    async with StorageManager(db) as storage:
        # initialise() runs init_db (which renames legacy → requests_legacy)
        # AND backfill_legacy_requests as part of its boot path.
        results = await storage.read_records(limit=100)

    assert len(results) == 3
    projects = {r.project for r in results}
    assert projects == {"alpha", "beta"}
    total_cost = sum(r.cost_millicents or 0 for r in results)
    assert total_cost == 500 + 750 + 1200

    # Thinking-mode row got mode=thinking; we can verify by reading the
    # underlying Request rows directly.
    from sqlalchemy import select

    from halton_meter.storage.models import Request

    _, sessionmaker = create_engine_for(db)
    async with sessionmaker() as session:
        result = await session.execute(
            select(Request.mode).where(Request.thinking_tokens > 0)
        )
        modes = [row[0] for row in result.all()]
    assert modes == ["thinking"]


@pytest.mark.asyncio
async def test_backfill_is_idempotent(tmp_path: Path) -> None:
    """Running backfill twice produces the same row count as once."""
    db = tmp_path / "legacy.db"
    rows = [_legacy_row(cost_millicents=1000) for _ in range(5)]
    _seed_legacy_db(db, rows)

    async with StorageManager(db) as storage:
        # First initialise() ran the backfill once. Run it explicitly a
        # second time — must be a no-op via the _migrations marker.
        assert storage._sessionmaker is not None
        second = await backfill_legacy_requests(storage._sessionmaker)
        assert second == 0
        records = await storage.read_records(limit=100)

    assert len(records) == 5


@pytest.mark.asyncio
async def test_backfill_no_audit_events_emitted(tmp_path: Path) -> None:
    """Backfilled rows must not generate request.captured audit events.

    The original capture predates the audit ledger; emitting events for
    historical rows would muddy the "this is what happened in real time"
    semantics of the audit log.
    """
    db = tmp_path / "legacy.db"
    _seed_legacy_db(db, [_legacy_row()])

    async with StorageManager(db):
        pass  # initialise() runs backfill

    from sqlalchemy import select

    from halton_meter.storage.models import AuditEvent

    _, sessionmaker = create_engine_for(db)
    async with sessionmaker() as session:
        result = await session.execute(select(AuditEvent))
        events = result.scalars().all()
    assert events == []


@pytest.mark.asyncio
async def test_backfill_skips_when_id_already_present(tmp_path: Path) -> None:
    """Pre-existing v1.0 rows with the same id are not overwritten."""
    db = tmp_path / "legacy.db"
    shared_id = str(uuid.uuid4())
    _seed_legacy_db(db, [_legacy_row(id=shared_id, cost_millicents=999)])

    # Pre-create the v1.0 schema and insert a row with the same id.
    engine, sessionmaker = create_engine_for(db)
    await init_db(engine)

    from halton_meter.storage.models import Project, Request

    async with sessionmaker() as session, session.begin():
        proj = Project(id=str(uuid.uuid4()), name="alpha", slug="alpha")
        session.add(proj)
        await session.flush()
        from datetime import UTC, datetime

        session.add(
            Request(
                id=shared_id,
                project_id=proj.id,
                provider="anthropic",
                model="claude-sonnet-4-6",
                mode="standard",
                input_tokens=1,
                output_tokens=1,
                cost_usd_minor_units=42,  # different from legacy 999
                requested_at=datetime.now(tz=UTC),
                recorded_at=datetime.now(tz=UTC),
            )
        )

    inserted = await backfill_legacy_requests(sessionmaker)
    assert inserted == 0  # pre-existing row blocked the only legacy row

    async with sessionmaker() as session:
        from sqlalchemy import select

        result = await session.execute(select(Request).where(Request.id == shared_id))
        row = result.scalar_one()
        assert row.cost_usd_minor_units == 42  # preserved, not overwritten
