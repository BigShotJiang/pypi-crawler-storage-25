"""
Tests for halton_meter.storage — StorageManager and LogRecord persistence.

Uses a real temporary SQLite file (no mocks), per memory/patterns.md.
"""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest

from halton_meter.models import LogRecord
from halton_meter.storage import StorageManager


def _make_record(
    *,
    project: str = "test-project",
    model: str = "claude-sonnet-4-6",
    cost_millicents: int | None = None,
    tokens_complete: bool = True,
    id: str | None = None,
) -> LogRecord:
    """Helper: build a LogRecord with sensible defaults."""
    return LogRecord(
        id=id or str(uuid.uuid4()),
        project=project,
        provider="anthropic",
        model=model,
        input_tokens=100,
        output_tokens=50,
        thinking_tokens=0,
        cache_read_tokens=0,
        cost_millicents=cost_millicents,
        tokens_complete=tokens_complete,
        latency_ms=123.4,
        requested_at="2026-04-28T10:00:00Z",
        recorded_at="2026-04-28T10:00:01Z",
    )


@pytest.mark.asyncio
async def test_write_and_read_round_trip(tmp_path: Path) -> None:
    """A written record must be retrievable with all fields intact."""
    db = tmp_path / "test.db"
    record = _make_record(project="invoice-app", cost_millicents=1500)

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        results = await storage.read_records()

    assert len(results) == 1
    r = results[0]
    assert r.id == record.id
    assert r.project == "invoice-app"
    assert r.provider == "anthropic"
    assert r.model == "claude-sonnet-4-6"
    assert r.input_tokens == 100
    assert r.output_tokens == 50
    assert r.thinking_tokens == 0
    assert r.cache_read_tokens == 0
    assert r.cache_write_tokens == 0
    # Cost is now authoritatively recomputed from pricing_rates by the
    # repo on write — the daemon-supplied 1500 is a fallback only used
    # when no rate matches. The seeded matrix knows claude-sonnet-4-6,
    # so we get a recomputed value here. We just verify it's non-null
    # and an integer; the exact value is exercised by api/test_ingest.
    assert isinstance(r.cost_millicents, int)
    assert r.cost_millicents >= 0
    assert r.tokens_complete is True
    assert abs(r.latency_ms - 123.4) < 0.01
    assert r.requested_at == "2026-04-28T10:00:00Z"
    assert r.recorded_at == "2026-04-28T10:00:01Z"


@pytest.mark.asyncio
async def test_project_filter(tmp_path: Path) -> None:
    """read_records(project=X) must return only records for that project."""
    db = tmp_path / "test.db"
    rec_a1 = _make_record(project="project-alpha")
    rec_a2 = _make_record(project="project-alpha")
    rec_b = _make_record(project="project-beta")

    async with StorageManager(db) as storage:
        await storage.write_record(rec_a1)
        await storage.write_record(rec_a2)
        await storage.write_record(rec_b)

        alpha_results = await storage.read_records(project="project-alpha")
        beta_results = await storage.read_records(project="project-beta")
        all_results = await storage.read_records()

    assert len(alpha_results) == 2
    assert all(r.project == "project-alpha" for r in alpha_results)

    assert len(beta_results) == 1
    assert beta_results[0].project == "project-beta"

    assert len(all_results) == 3


@pytest.mark.asyncio
async def test_empty_db_reads_return_empty_list(tmp_path: Path) -> None:
    """Reading from a freshly initialised DB must return an empty list."""
    db = tmp_path / "test.db"

    async with StorageManager(db) as storage:
        results = await storage.read_records()
        results_filtered = await storage.read_records(project="anything")

    assert results == []
    assert results_filtered == []


@pytest.mark.asyncio
async def test_duplicate_insert_is_ignored(tmp_path: Path) -> None:
    """Inserting the same UUID twice must not raise and must store only one row."""
    db = tmp_path / "test.db"
    record_id = str(uuid.uuid4())
    record = _make_record(id=record_id, project="alpha")

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        # Second insert with same id — must not raise
        await storage.write_record(record)
        results = await storage.read_records()

    assert len(results) == 1
    assert results[0].id == record_id


@pytest.mark.asyncio
async def test_nullable_cost_millicents_for_unknown_model(tmp_path: Path) -> None:
    """cost_millicents stays NULL when the model isn't in the rates table."""
    db = tmp_path / "test.db"
    # Use a model name absent from both the bundled matrix and the seed.
    record = _make_record(model="unknown-test-model", cost_millicents=None)

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        results = await storage.read_records()

    assert len(results) == 1
    assert results[0].cost_millicents is None


@pytest.mark.asyncio
async def test_tokens_incomplete_roundtrip(tmp_path: Path) -> None:
    """tokens_complete=False must survive the SQLite bool→int→bool round-trip."""
    db = tmp_path / "test.db"
    record = _make_record(tokens_complete=False)

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        results = await storage.read_records()

    assert len(results) == 1
    assert results[0].tokens_complete is False


@pytest.mark.asyncio
async def test_results_ordered_newest_first(tmp_path: Path) -> None:
    """read_records must return records ordered by requested_at DESC."""
    db = tmp_path / "test.db"

    old = LogRecord(
        id=str(uuid.uuid4()),
        project="p",
        provider="anthropic",
        model="claude-sonnet-4-6",
        input_tokens=10,
        output_tokens=5,
        thinking_tokens=0,
        cache_read_tokens=0,
        cost_millicents=None,
        tokens_complete=True,
        latency_ms=10.0,
        requested_at="2026-04-27T08:00:00Z",
        recorded_at="2026-04-27T08:00:01Z",
    )
    new = LogRecord(
        id=str(uuid.uuid4()),
        project="p",
        provider="anthropic",
        model="claude-sonnet-4-6",
        input_tokens=20,
        output_tokens=10,
        thinking_tokens=0,
        cache_read_tokens=0,
        cost_millicents=None,
        tokens_complete=True,
        latency_ms=20.0,
        requested_at="2026-04-28T10:00:00Z",
        recorded_at="2026-04-28T10:00:01Z",
    )

    async with StorageManager(db) as storage:
        await storage.write_record(old)
        await storage.write_record(new)
        results = await storage.read_records()

    # Newest first
    assert results[0].id == new.id
    assert results[1].id == old.id


@pytest.mark.asyncio
async def test_limit_is_respected(tmp_path: Path) -> None:
    """read_records(limit=N) must return at most N records."""
    db = tmp_path / "test.db"

    async with StorageManager(db) as storage:
        for _ in range(10):
            await storage.write_record(_make_record())

        results = await storage.read_records(limit=3)

    assert len(results) == 3


@pytest.mark.asyncio
async def test_db_file_and_parent_dirs_created(tmp_path: Path) -> None:
    """StorageManager must create the DB file and any missing parent directories."""
    db = tmp_path / "nested" / "dirs" / "test.db"

    async with StorageManager(db) as storage:
        await storage.write_record(_make_record())

    assert db.exists()


@pytest.mark.asyncio
async def test_reinitialise_is_idempotent(tmp_path: Path) -> None:
    """Calling initialise() on a DB that already has the schema must not fail."""
    db = tmp_path / "test.db"
    record = _make_record()

    # First session — writes a record
    async with StorageManager(db) as storage:
        await storage.write_record(record)

    # Second session — re-initialises (CREATE TABLE IF NOT EXISTS), reads record
    async with StorageManager(db) as storage:
        results = await storage.read_records()

    assert len(results) == 1
    assert results[0].id == record.id


@pytest.mark.asyncio
async def test_cache_read_and_write_tokens_round_trip(tmp_path: Path) -> None:
    """Both cache_read_tokens and cache_write_tokens must persist + read back.

    Regression test for the rename + add introduced 2026-04-30
    (decisions.md "Cache token accounting…"). The repo write path stores
    them on the renamed `cache_read_tokens` column and the new
    `cache_write_tokens` column; the read path round-trips them onto
    LogRecord.
    """
    db = tmp_path / "test.db"
    record = LogRecord(
        id=str(uuid.uuid4()),
        project="cache-roundtrip",
        provider="anthropic",
        model="claude-sonnet-4-6",
        input_tokens=100,
        output_tokens=50,
        thinking_tokens=0,
        cache_read_tokens=4_321,
        cache_write_tokens=1_234,
        cost_millicents=None,
        tokens_complete=True,
        latency_ms=10.0,
        requested_at="2026-04-28T10:00:00Z",
        recorded_at="2026-04-28T10:00:01Z",
    )

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        results = await storage.read_records()

    assert len(results) == 1
    r = results[0]
    assert r.cache_read_tokens == 4_321
    assert r.cache_write_tokens == 1_234


@pytest.mark.asyncio
async def test_cache_write_default_zero_when_unset(tmp_path: Path) -> None:
    """Records that omit cache_write_tokens must default to 0 on read.

    Confirms the new column's default propagates correctly through the
    write path even when the LogRecord uses the field's default value.
    """
    db = tmp_path / "test.db"
    record = _make_record()  # cache_read_tokens / cache_write_tokens both default 0

    async with StorageManager(db) as storage:
        await storage.write_record(record)
        results = await storage.read_records()

    assert results[0].cache_read_tokens == 0
    assert results[0].cache_write_tokens == 0


@pytest.mark.asyncio
async def test_in_place_migration_renames_cached_and_adds_cache_write(
    tmp_path: Path,
) -> None:
    """A pre-existing v0.1.5-style DB (cached_tokens column, no cache_write_tokens)
    must be migrated in place: column renamed, new column added, data preserved,
    and PRAGMA user_version stamped to 1.
    """
    import sqlite3

    db = tmp_path / "v0_1_5.db"
    # Recreate the v0.1.5 shape: project_id-FK schema (so it is NOT seen as
    # legacy by `_rename_if_legacy`) but with the old `cached_tokens` column.
    conn = sqlite3.connect(db)
    try:
        conn.executescript(
            """
            CREATE TABLE projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                slug TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL DEFAULT '2026-04-28T00:00:00Z',
                archived_at TEXT
            );
            CREATE TABLE requests (
                id TEXT PRIMARY KEY,
                project_id TEXT NOT NULL,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                mode TEXT NOT NULL DEFAULT 'standard',
                input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0,
                thinking_tokens INTEGER NOT NULL DEFAULT 0,
                cached_tokens INTEGER NOT NULL DEFAULT 0,
                cost_usd_minor_units BIGINT,
                latency_ms REAL,
                tokens_complete INTEGER NOT NULL DEFAULT 1,
                requested_at TEXT NOT NULL,
                recorded_at TEXT NOT NULL,
                source_machine TEXT,
                source_workdir TEXT,
                attribution_method TEXT,
                status TEXT NOT NULL DEFAULT 'success'
            );
            INSERT INTO projects (id, name, slug) VALUES ('p1', 'p1', 'preexisting');
            INSERT INTO requests (
                id, project_id, provider, model, mode, input_tokens,
                output_tokens, thinking_tokens, cached_tokens,
                cost_usd_minor_units, latency_ms, tokens_complete,
                requested_at, recorded_at, status
            ) VALUES (
                'r1', 'p1', 'anthropic', 'claude-sonnet-4-6', 'standard',
                10, 5, 0, 999, 42, 100.0, 1,
                '2026-04-28T10:00:00+00:00', '2026-04-28T10:00:01+00:00',
                'success'
            );
            PRAGMA user_version = 0;
            """
        )
        conn.commit()
    finally:
        conn.close()

    # Initialise via StorageManager — runs the migration block.
    async with StorageManager(db) as storage:
        results = await storage.read_records()

    # Pre-existing row preserved with cached_tokens value (999) on the
    # renamed column, and cache_write_tokens defaulted to 0.
    assert len(results) == 1
    assert results[0].cache_read_tokens == 999
    assert results[0].cache_write_tokens == 0

    # PRAGMA user_version was bumped.
    conn = sqlite3.connect(db)
    try:
        version = conn.execute("PRAGMA user_version").fetchone()[0]
    finally:
        conn.close()
    assert version == 1


@pytest.mark.asyncio
async def test_write_does_not_raise_when_no_connection() -> None:
    """write_record must not raise if StorageManager was never initialised."""
    storage = StorageManager("/tmp/nonexistent.db")
    # No await storage.initialise() — connection is None
    # Should log an error and return, not raise
    record = _make_record()
    await storage.write_record(record)  # must not raise
