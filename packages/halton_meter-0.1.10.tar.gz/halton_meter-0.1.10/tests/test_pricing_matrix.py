"""Tests for the bundled Anthropic pricing matrix in halton_meter.pricing.matrix.

Specifically asserts the seeded ``cache_write`` rate equals 1.25x the
``input`` rate (the documented Anthropic 5m-default ephemeral cache-write
rate) for representative models. See decisions.md 2026-04-30
("Cache token accounting…") for the rationale behind a single
``cache_write`` rate at 1.25x input.
"""

from __future__ import annotations

import pytest

from halton_meter.pricing.matrix import ANTHROPIC_RATES


@pytest.mark.parametrize(
    "model",
    [
        "claude-opus-4-7",
        "claude-sonnet-4-6",
        "claude-haiku-4-5",
        "claude-opus-4-5",
        "claude-sonnet-4-5",
    ],
)
def test_cache_write_rate_is_125_percent_of_input(model: str) -> None:
    """``cache_write`` must equal 1.25x ``input`` for every seeded model.

    Tolerates ±1 millicent rounding from the ``round(dollars * 100_000)``
    conversion in ``_usd``: e.g. input=$3.00 → 300_000; cache_write at
    1.25x = 375_000 (exact). For input=$1 → 100_000; 1.25x = 125_000.
    For input=$5 → 500_000; 1.25x = 625_000.
    """
    rates = ANTHROPIC_RATES[model]
    expected = round(rates.input * 1.25)
    assert rates.cache_write == expected, (
        f"{model}: cache_write={rates.cache_write} expected {expected} "
        f"(1.25x input={rates.input})"
    )


def test_cache_write_present_for_every_seeded_model() -> None:
    """Every seeded model must carry a non-zero cache_write rate.

    Guards against future entries forgetting to seed cache_write.
    """
    for model, rates in ANTHROPIC_RATES.items():
        assert rates.cache_write > 0, f"{model} has zero cache_write rate"


def test_cache_write_above_cache_read_for_every_model() -> None:
    """Cache writes are billed higher than cache reads — fail-loud invariant.

    Anthropic prices cache writes at 1.25x input (5m) vs cache reads at
    0.10x input. If a model entry inverts this, the matrix is wrong.
    """
    for model, rates in ANTHROPIC_RATES.items():
        assert rates.cache_write > rates.cache_read, (
            f"{model}: cache_write ({rates.cache_write}) "
            f"must exceed cache_read ({rates.cache_read})"
        )
