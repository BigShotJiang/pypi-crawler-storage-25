"""Regression for v0.1.7 Gap 5 — DaemonHealthCache must probe the API
port (where ``/health`` lives), not the mitmproxy CONNECT port.

Pre-fix bug: ``DaemonHealthCache._probe_inner`` opened a TCP connection
to ``internal_host:internal_port`` (the mitmproxy proxy port). mitmproxy
is a CONNECT proxy and does not serve ``GET /health`` — the request was
swallowed, the probe always returned False, the cache stayed unhealthy,
and every CONNECT through the edge fell through to passthrough. Net
effect on a fresh install: ZERO captures from real apps.

This test exercises a REAL probe against two real listeners. It
deliberately does NOT mock ``DaemonHealthCache`` — every other edge
test in the suite mocks the cache, which is exactly why the bug shipped.
"""

from __future__ import annotations

import asyncio
import socket
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from halton_meter.edge import DaemonHealthCache


class _HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        if self.path == "/health":
            body = b'{"status":"ok"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *_args: object) -> None:  # silence stderr noise
        return


def _start_health_server() -> tuple[HTTPServer, int, threading.Thread]:
    server = HTTPServer(("127.0.0.1", 0), _HealthHandler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, port, thread


def _start_silent_listener() -> tuple[socket.socket, int, threading.Event]:
    """Bind a TCP listener that accepts connections then immediately
    closes them — mimics mitmproxy's response to a raw ``GET /health``
    on its CONNECT port (no HTTP response on that wire).
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", 0))
    sock.listen(8)
    port = sock.getsockname()[1]
    stop = threading.Event()

    def _accept_loop() -> None:
        sock.settimeout(0.1)
        while not stop.is_set():
            try:
                conn, _ = sock.accept()
            except (TimeoutError, OSError):
                continue
            try:
                conn.close()
            except OSError:
                pass

    threading.Thread(target=_accept_loop, daemon=True).start()
    return sock, port, stop


@pytest.mark.asyncio
async def test_probe_returns_true_against_health_listener() -> None:
    """Cache wired with probe_port = the /health listener returns True.

    Also wires internal_port to a different port that accepts-and-closes
    (the chain target). Proves the probe targets ``probe_port``, not
    ``internal_port``.
    """
    server, health_port, _thread = _start_health_server()
    silent_sock, silent_port, stop = _start_silent_listener()
    try:
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=silent_port,
            probe_port=health_port,
            probe_timeout_s=1.0,
        )
        assert await cache.is_healthy() is True
    finally:
        server.shutdown()
        server.server_close()
        stop.set()
        silent_sock.close()


@pytest.mark.asyncio
async def test_probe_returns_false_against_silent_listener() -> None:
    """Pre-fix shape: probe_port pointed at the mitmproxy-style silent
    listener. is_healthy() must be False — this is the bug we are
    regressing against.
    """
    silent_sock, silent_port, stop = _start_silent_listener()
    try:
        cache = DaemonHealthCache(
            internal_host="127.0.0.1",
            internal_port=silent_port,
            probe_port=silent_port,
            probe_timeout_s=0.5,
        )
        assert await cache.is_healthy() is False
    finally:
        stop.set()
        silent_sock.close()
        # Give the accept loop a moment to wind down before pytest tears
        # down the event loop.
        await asyncio.sleep(0.05)
