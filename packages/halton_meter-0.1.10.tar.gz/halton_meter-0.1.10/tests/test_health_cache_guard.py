"""Gap 7 (v0.1.8) — structural guard against silent ``DaemonHealthCache``
regressions.

Background
----------
Gap 5 (v0.1.7 ship-blocker) was a one-line bug in
``DaemonHealthCache._probe_inner``: it opened a TCP connection to the
mitmproxy CONNECT port (``internal_port``) instead of the FastAPI
``/health`` port (``probe_port``). The bug shipped to PyPI in v0.1.6
because **every other edge test in the suite mocks ``DaemonHealthCache``**.
The probe code was never exercised against a real listener in CI.

This module installs two structural guards so a future Gap-5-class
regression cannot ship silently:

1. **Fingerprint test** — pin the class signature surface that the
   ``test_edge_real_probe.py`` regression depends on. If anyone renames
   ``probe_port``, drops ``_probe_inner``, or changes the constructor
   parameter set, the fingerprint test fails with a message pointing at
   the regression file. This forces the developer to update the real
   listener test in lock-step.

2. **Real-listener guard** — the ``test_edge_real_probe.py`` module
   MUST start a real ``http.server.HTTPServer`` (i.e. an unmocked
   listener) and MUST construct a ``DaemonHealthCache`` directly. If
   either fact stops being true the guard fails — preventing the
   regression file from being silently neutered.

Together these two checks make it impossible to ship a change that
alters the cache's probe behaviour without an accompanying update to a
test that runs against a real socket.
"""

from __future__ import annotations

import inspect
from pathlib import Path

from halton_meter.edge import DaemonHealthCache

_REAL_PROBE_TEST = Path(__file__).parent / "test_edge_real_probe.py"

_REGRESSION_HINT = (
    "If you are intentionally changing DaemonHealthCache's probe surface, "
    "update tests/test_edge_real_probe.py (the real-listener regression "
    "for v0.1.7 Gap 5) IN THE SAME COMMIT, then update the fingerprint "
    "in this file. Do NOT silently relax this guard — it exists because "
    "every other edge test mocks DaemonHealthCache and the Gap 5 bug "
    "shipped to PyPI undetected for that reason."
)


def test_daemon_health_cache_constructor_fingerprint() -> None:
    """Pin the public constructor parameter set.

    If a parameter is added, removed or renamed, this test fails — and
    the failure message tells the engineer to update the real-listener
    regression in test_edge_real_probe.py.
    """
    sig = inspect.signature(DaemonHealthCache)
    public_params = sorted(
        name for name in sig.parameters if not name.startswith("_")
    )
    expected = sorted(
        [
            "internal_host",
            "internal_port",
            "probe_port",
            "healthy_ttl_s",
            "unhealthy_ttl_s",
            "probe_timeout_s",
            "clock",
        ]
    )
    assert public_params == expected, (
        f"DaemonHealthCache constructor surface changed.\n"
        f"  expected: {expected}\n"
        f"  actual:   {public_params}\n\n"
        f"{_REGRESSION_HINT}"
    )


def test_daemon_health_cache_probe_inner_signature() -> None:
    """Pin ``_probe_inner`` as an async no-arg method returning bool.

    The Gap 5 bug lived inside ``_probe_inner``. If the method is
    renamed, made sync, or grows parameters, the regression test in
    test_edge_real_probe.py is no longer exercising the real probe path.
    """
    method = getattr(DaemonHealthCache, "_probe_inner", None)
    assert method is not None, (
        "DaemonHealthCache._probe_inner went missing.\n\n"
        + _REGRESSION_HINT
    )
    assert inspect.iscoroutinefunction(method), (
        "_probe_inner must remain a coroutine.\n\n" + _REGRESSION_HINT
    )
    sig = inspect.signature(method)
    # Only ``self`` — anything else and the regression test wouldn't be
    # exercising the same surface.
    params = [p for p in sig.parameters if p != "self"]
    assert params == [], (
        f"_probe_inner parameters changed: {params}.\n\n"
        + _REGRESSION_HINT
    )


def test_real_probe_test_file_exists_and_uses_real_listener() -> None:
    """The Gap 5 regression test file must exist and must NOT be a mock.

    A test file that imports ``DaemonHealthCache`` and exercises probe
    behaviour qualifies as "real" iff it stands up a real socket
    listener (``http.server.HTTPServer`` or equivalent). Without that,
    the regression vanishes the moment someone replaces it with a mock
    — exactly the failure mode that let Gap 5 ship.
    """
    assert _REAL_PROBE_TEST.exists(), (
        f"Missing regression file: {_REAL_PROBE_TEST.name}.\n\n"
        + _REGRESSION_HINT
    )
    src = _REAL_PROBE_TEST.read_text(encoding="utf-8")
    assert "DaemonHealthCache(" in src, (
        f"{_REAL_PROBE_TEST.name} no longer constructs DaemonHealthCache.\n\n"
        + _REGRESSION_HINT
    )
    assert "HTTPServer" in src, (
        f"{_REAL_PROBE_TEST.name} no longer stands up an HTTPServer; "
        f"the regression has been silently neutered.\n\n"
        + _REGRESSION_HINT
    )
    # Reject mock-based shortcuts in the regression file.
    forbidden = ("monkeypatch.setattr", "MagicMock", "AsyncMock", "mock.patch")
    offenders = [token for token in forbidden if token in src]
    assert not offenders, (
        f"{_REAL_PROBE_TEST.name} contains forbidden mocking tokens "
        f"{offenders!r}; the regression must exercise real network I/O.\n\n"
        + _REGRESSION_HINT
    )
