"""CLI package for RepoMind."""
