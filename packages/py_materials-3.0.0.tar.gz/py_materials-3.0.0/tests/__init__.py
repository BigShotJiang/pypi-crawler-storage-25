"""Tests for pymat package."""
