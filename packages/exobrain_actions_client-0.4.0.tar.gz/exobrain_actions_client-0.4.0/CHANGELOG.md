# Changelog

All notable changes to this project are documented here. Format inspired by Conventional Commits.

## [0.4.0] - 2026-05-5

### Features

- add score calculation retrieval via `get_score` method, with support for rule-based scoring (#6)


## [0.3.0] - 2026-04-16

### Features

- add AI-generated localized summary retrieval via `get_summary` method, with support for multiple languages and regions (#4)

## [0.2.1] - 2026-04-09

Wrap requests network errors into typed `HTTPClientError` subclasses (#3):

- wrap `requests` network exceptions in the Requests adapter so caller code can handle timeouts and connection failures
  through typed client exceptions
- add explicit timeout and connection exception types for the HTTP client abstraction to avoid leaking raw `requests`
  exceptions to consumers

---

## [0.2.0] - 2025-07-16

### Build

- bump package version to `0.2.0`
- update project metadata and release configuration
- update `exobrain-actions-schemas` dependency to `0.2.0`

### Docs

- add installation and usage guidance to `README.md`
