class HTTPClientError(Exception):
    """
    Base class for HTTP-related errors.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)


class HTTPTimeoutError(HTTPClientError):
    """
    Exception raised when an HTTP request times out.
    """


class HTTPConnectionError(HTTPClientError):
    """
    Exception raised when an HTTP connection fails.
    """
