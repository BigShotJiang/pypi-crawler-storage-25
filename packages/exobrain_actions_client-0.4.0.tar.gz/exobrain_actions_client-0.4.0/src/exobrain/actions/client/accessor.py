import typing as t
from uuid import UUID

from exobrain.actions.schemas.action_data import ActionData
from exobrain.actions.schemas.version_info import VersionStatus

from exobrain.actions.client.http_client.interfaces import HTTPClientFacade


class ActionsAccessor:
    """
    Base class for accessing resources in the Exobrain Actions API.
    """

    def __init__(self, client: HTTPClientFacade) -> None:
        """
        Initialize the BaseAccessor with a client instance.

        :param client: An instance of the Client class.
        """
        self.client = client

    def version_status(self) -> VersionStatus:
        """
        Retrieve the version status of the Exobrain Actions API.

        :return: An instance of VersionStatus containing version details.
        """
        response = self.client.get("/")
        response.raise_for_status()
        json_data = response.json()
        return VersionStatus.model_validate(json_data)

    def ping(self) -> None:
        """
        Ping the Exobrain Actions API to check if it is alive.

        :raises HTTPStatusError: If the ping fails.
        """
        response = self.client.get("/health/ping")
        response.raise_for_status()

    def get_action_data(self, service: str = "") -> ActionData:
        """
        Retrieve action data for a specific service or the currently running service.

        Args:
            service: The service name (e.g., "alternate-supplier").
            If not provided, defaults to the currently running service.

        Returns:
            An instance of ActionData containing the action data.
        """
        params = {"service": service} if service else {}
        response = self.client.get("/actions/data", params=params)
        response.raise_for_status()
        return ActionData.model_validate(response.json())

    def calculate(self, service: str, org_id: str | UUID, action_id: str | UUID) -> None:
        """
        Trigger the calculation for a specific action.

        Args:
            service: The service name (e.g., "alternate-supplier").
            org_id: The organization ID.
            action_id: The action ID.
        """
        url = f"/{service}/organizations/{org_id}/actions/{action_id}"
        response = self.client.get(url)
        response.raise_for_status()

    def update_actuals(
        self,
        service: str,
        org_id: str | UUID,
        action_id: str | UUID,
        kpis: t.Mapping[str, int | float],
    ) -> None:
        """
        Update the "ACTUAL" KPIs for a specific action.

        There are three types of KPIs: "ACTUAL", "RECOMMENDED", and "INITIAL".
        This method only updates the values of KPIs with the type "ACTUAL".

        Args:
            service: The service name (e.g., "alternate-supplier").
            org_id: The organization ID.
            action_id: The action ID.
            kpis: A dictionary containing the values to update for the "ACTUAL" KPIs.
        """
        url = f"/{service}/organizations/{org_id}/actions/{action_id}/actuals"
        response = self.client.post(url, json=kpis)
        response.raise_for_status()

    def get_summary(
        self,
        service: str,
        org_id: str | UUID,
        action_id: str | UUID,
        lang: str,
    ) -> dict[str, str]:
        """
        Request a localized AI-generated summary for a specific action.

        Calls ``GET /{service}/organizations/{org_id}/actions/{action_id}/summary``
        on the action service. The service builds a prompt from the action data,
        forwards it to the configured LLM provider, and returns the generated text.

        Args:
            service:   The service name (e.g., ``"alternate-supplier"``).
            org_id:    The organization UUID.
            action_id: The running action UUID.
            lang:      BCP-47 language tag (e.g. ``"fr"``, ``"en"``, ``"ar"``).

        Returns:
            A dict with two keys::

                {"summary": "<generated text>", "lang": "<lang>"}

        Raises:
            HTTPStatusError (400): Action not found in the service DB, or not feasible.
            HTTPStatusError (408): LLM provider timed out.
            HTTPStatusError (502): LLM provider unreachable or returned an unexpected error.
        """
        url = f"/{service}/organizations/{org_id}/actions/{action_id}/summary"
        response = self.client.get(url, params={"lang": lang})
        response.raise_for_status()
        return t.cast("dict[str, str]", response.json())

    def get_score(
        self,
        service: str,
        org_id: str | UUID,
        action_id: str | UUID,
        rule_set: str,
    ) -> dict[str, t.Any]:

        """
        Request the score details for a specific action and ruleset.

        Args:
            service: The name of the service for which the score is retrieved.
            org_id: The unique identifier of the organization.
            action_id: The unique identifier of the action.
            rule_set: The ruleset to be applied when fetching the score.

        Returns:
            A dictionary representation of the score details.

        Raises:
            HTTPError: If the response contains an HTTP error.
        """
        url = f"/{service}/organizations/{org_id}/actions/{action_id}/score"
        response = self.client.get(url, params={"rule_set": rule_set})
        response.raise_for_status()
        return t.cast("dict[str, t.Any]", response.json())
