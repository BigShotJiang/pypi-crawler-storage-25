# brunns-matchers

Various custom [PyHamcrest](https://pyhamcrest.readthedocs.io) matchers. See [the documentation](https://brunns-matchers.readthedocs.io/) for details.

[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)
[![Build Status](https://travis-ci.org/brunns/brunns-matchers.svg?branch=master&logo=travis)](https://travis-ci.org/brunns/brunns-matchers)
[![PyPi Version](https://img.shields.io/pypi/v/brunns-matchers.svg?logo=pypi)](https://pypi.org/project/brunns-matchers/#history)
[![Python Versions](https://img.shields.io/pypi/pyversions/brunns-matchers.svg?logo=python)](https://pypi.org/project/brunns-matchers/)
[![Licence](https://img.shields.io/github/license/brunns/brunns-matchers.svg)](https://github.com/brunns/brunns-matchers/blob/master/LICENSE)
[![GitHub all releases](https://img.shields.io/github/downloads/brunns/brunns-matchers/total.svg?logo=github)](https://github.com/brunns/brunns-matchers/releases/)
[![GitHub forks](https://img.shields.io/github/forks/brunns/brunns-matchers.svg?label=Fork&logo=github)](https://github.com/brunns/brunns-matchers/network/members)
[![GitHub stars](https://img.shields.io/github/stars/brunns/brunns-matchers.svg?label=Star&logo=github)](https://github.com/brunns/brunns-matchers/stargazers/)
[![GitHub watchers](https://img.shields.io/github/watchers/brunns/brunns-matchers.svg?label=Watch&logo=github)](https://github.com/brunns/brunns-matchers/watchers/)
[![GitHub contributors](https://img.shields.io/github/contributors/brunns/brunns-matchers.svg?logo=github)](https://github.com/brunns/brunns-matchers/graphs/contributors/)
[![GitHub issues](https://img.shields.io/github/issues/brunns/brunns-matchers.svg?logo=github)](https://github.com/brunns/brunns-matchers/issues/)
[![GitHub issues-closed](https://img.shields.io/github/issues-closed/brunns/brunns-matchers.svg?logo=github)](https://github.com/brunns/brunns-matchers/issues?q=is%3Aissue+is%3Aclosed)
[![GitHub pull-requests](https://img.shields.io/github/issues-pr/brunns/brunns-matchers.svg?logo=github)](https://github.com/brunns/brunns-matchers/pulls)
[![GitHub pull-requests closed](https://img.shields.io/github/issues-pr-closed/brunns/brunns-matchers.svg?logo=github)](https://github.com/brunns/brunns-matchers/pulls?utf8=%E2%9C%93&q=is%3Apr+is%3Aclosed)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/0b22e28c2ebe4722899a07c4cfa5bc69)](https://www.codacy.com/app/brunns/brunns-matchers)
[![Codacy Coverage](https://api.codacy.com/project/badge/coverage/0b22e28c2ebe4722899a07c4cfa5bc69)](https://www.codacy.com/app/brunns/brunns-matchers)
[![Lines of Code](https://tokei.rs/b1/github/brunns/brunns-matchers)](https://github.com/brunns/brunns-matchers)

## Setup

Install with pip:

    pip install brunns-matchers

(As usual, use of a [venv](https://docs.python.org/3/library/venv.html) or [virtualenv](https://virtualenv.pypa.io) is recommended.)

## Developing

Requires [uv](https://docs.astral.sh/uv/). Install with:

```shell
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Then install dependencies:

```shell
uv sync --all-extras
```

Run `make precommit` to check if you're OK to commit. For more options, run:

    make help

## Releasing

Releases are automated via GitHub Actions. To release version `n.n.n`:

1. Update version in `pyproject.toml` (using `uv version --bump major|minor|patch`) and `docs/conf.py`.
2. Run `make precommit` to ensure all checks pass
3. Commit and tag:
   ```sh
   version=`uv version --short`
   git commit -am "Release v$version"
   git tag "v$version"
   git push origin master --tags
   ```

The GitHub Actions workflow will automatically:
- Run tests and coverage checks
- Build distribution packages
- Publish to PyPI (using OIDC trusted publishing)
- Create a GitHub release with auto-generated notes

**Note**: Ensure PyPI trusted publishing is configured. See CLAUDE.md for setup instructions.
