"""RetrievalCore — mixin base class for retrieval pipeline methods.

Contains all retrieval orchestration methods extracted from RetrievalPipeline:
  - recall (primary multi-path entry point)
  - _system2_recall (goal-directed System-2 recall)
  - _spreading_recall (spreading activation graph walk)
  - recall_with_spreading (spreading-first retrieval)
  - dual_recall (dual-channel System-1 + System-2)
  - route_to_cortex (cortex routing)
  - sparse_recall (sparse-activation pipeline)
  - retrieve_with_descent (5-layer dimensional descent)
  - cascade_recall (causal chain recall)
  - graph_first_recall (topology-first retrieval)
  - topology_rank (graph topology ranking)
  - cross_modal_recall (cross-modal retrieval)
  - image_search (image-to-image search)
  - text_to_image (text-to-image search)

This is a bare mixin — it expects `self._rt` (a MemoryRuntime reference)
to be available, set by the inheriting class.
"""

from __future__ import annotations

import math
import time

from .scheduler import AgentContext, MemoryContext, MemoryItem, MemoryType
from .anchor import Anchor
from .router import RouteResult
from .dual_channel import DualChannelOutput
from .multimodal import CrossModalResult
from .math_utils import cosine_sim as _cosine_sim
from .topology import graph_first_recall, topology_rank


class RetrievalCore:
    """Mixin providing all retrieval orchestration methods.

    Expects self._rt to be a MemoryRuntime instance (set by the inheriting class).
    """

    # ── Primary recall entry point ────────────────────────────

    def recall(self, query: str = "",
               context: AgentContext | None = None,
               max_items: int = 10) -> MemoryContext:
        """Multi-path retrieval with tracing instrumentation and auto System-2 trigger.

        Path 0 (Exact Cache): Deterministic O(1) entity-pair lookup.
        Path A (L0 Raw Buffer): BM25 + vector search on uncompressed chunks.
        Path B (L1-L5 Graph): Dimensional descent through structured anchors.

        Auto-triggers System-2 (goal-directed traversal) when:
        - Query contains structural intent keywords (all/which/before/last/...)
        - System-1 confidence drops below 0.35
        """
        if context is None:
            context = AgentContext(task_type="conversation")

        # Detect if System-2 is warranted before running System-1
        query_lower = query.lower()
        s2_keyword = False
        for kw in self._SYSTEM2_KEYWORDS:
            if ' ' in kw:
                if kw in query_lower:
                    s2_keyword = True
                    break
            else:
                import re
                if re.search(r'\b' + re.escape(kw) + r'\b', query_lower):
                    s2_keyword = True
                    break

        if s2_keyword:
            return self._system2_recall(query, context, max_items,
                                        trigger_reason="structural_keyword")

        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None
        t_start = time.time()

        # Path 0: Exact cache lookup (deterministic O(1) bypass)
        t0 = time.time()
        exact_results: list[MemoryItem] = []
        if query:
            query_keys = self._rt.exact_cache.query_keys(query)
            for key in query_keys:
                entries = self._rt.exact_cache.get(key)
                for entry in entries:
                    anchor = self._rt.graph.anchors.get(entry.anchor_id)
                    if anchor and anchor.is_retrievable:
                        exact_results.append(MemoryItem(
                            anchor=anchor,
                            relevance_score=0.95 + entry.confidence * 0.05,
                            memory_type=MemoryType.SEMANTIC,
                            compression_level=0,
                            compressed_text=entry.text,
                        ))
            for key in query_keys:
                wm_entries = self._rt.working_memory.get_exact(key)
                for wme in wm_entries:
                    exact_results.append(MemoryItem(
                        anchor=None,
                        relevance_score=0.92,
                        memory_type=MemoryType.WORKING,
                        compression_level=0,
                        compressed_text=wme.text[:200],
                    ))
        exact_ms = (time.time() - t0) * 1000

        # Path 0.5: Cognitive cache lookup (query/session/topic/activation caches)
        t0 = time.time()
        cache_hit_anchors: list[tuple[Anchor, float, str]] = []
        if query:
            cache_result = self._rt.cognitive_cache.lookup(
                query=query,
                tags=list(context.task_tags) if context and getattr(context, 'task_tags', None) else None,
                seed_ids=[item.anchor.id for item in exact_results if item.anchor],
            )
            seen_ids: set[str] = set()
            for source, anchor_ids in cache_result.items():
                for aid in anchor_ids:
                    if aid in seen_ids:
                        continue
                    anchor = self._rt.graph.anchors.get(aid)
                    if anchor and anchor.is_retrievable:
                        seen_ids.add(aid)
                        score = 0.88 if source == "query_cache" else 0.82
                        cache_hit_anchors.append((anchor, score, source))
        cache_ms = (time.time() - t0) * 1000

        # Path A: Raw buffer search (L0 — highest priority after exact cache)
        t0 = time.time()
        raw_results = self._rt.raw_buffer.search(
            query=query, query_embedding=query_emb,
            top_k=max_items,
            session_id=context.session_id if context else "",
        )
        raw_ms = (time.time() - t0) * 1000

        # Path A2: BM25 anchor search — keyword-first, always reliable
        t0 = time.time()
        bm25_items = self._bm25_anchor_search(
            query=query, query_emb=query_emb,
            max_items=max_items, context=context)
        bm25_ms = (time.time() - t0) * 1000

        # Path B: Graph dimensional descent (L1-L5)
        t0 = time.time()
        graph_result = self.retrieve_with_descent(
            query=query, context=context, max_items=max_items)
        graph_ms = (time.time() - t0) * 1000

        # Path C: Spreading activation graph walk (#52)
        t0 = time.time()
        spreading_items = self._spreading_recall(
            query_emb=query_emb, query=query, max_items=max_items)
        spreading_ms = (time.time() - t0) * 1000

        # Merge: exact cache → BM25 anchor → cognitive cache → raw buffer → graph → spreading
        merged_items = list(exact_results)
        seen_texts = {self._rt._normalize_text(item.compressed_text) for item in merged_items
                      if hasattr(item, 'compressed_text') and item.compressed_text}
        seen_ids = {item.anchor.id for item in merged_items if item.anchor}

        # Track BM25-matched anchor IDs for priority sorting
        bm25_matched_ids: set[str] = {bm.anchor.id for bm in bm25_items if bm.anchor}

        # Insert BM25 anchor results (keyword-strong, anchored)
        for bm_item in bm25_items:
            if bm_item.anchor and bm_item.anchor.id in seen_ids:
                continue
            if bm_item.anchor:
                seen_ids.add(bm_item.anchor.id)
            norm_text = self._rt._normalize_text(bm_item.compressed_text or bm_item.anchor.text[:120])
            if norm_text and norm_text in seen_texts:
                continue
            seen_texts.add(norm_text)
            merged_items.append(bm_item)

        # Insert cognitive cache hits
        for anchor, score, source in cache_hit_anchors:
            if anchor.id in seen_ids:
                continue
            seen_ids.add(anchor.id)
            norm_text = self._rt._normalize_text(anchor.text[:120])
            seen_texts.add(norm_text)
            merged_items.append(MemoryItem(
                anchor=anchor,
                relevance_score=score,
                memory_type=MemoryType.SEMANTIC,
                compression_level=1,
                compressed_text=anchor.text[:200],
            ))

        for chunk, score in raw_results:
            norm_text = self._rt._normalize_text(chunk.text[:120])
            if norm_text and norm_text in seen_texts:
                continue
            seen_texts.add(norm_text)
            merged_items.append(MemoryItem(
                anchor=None,
                relevance_score=score,
                memory_type=MemoryType.WORKING,
                compression_level=0,
                compressed_text=chunk.text[:200],
            ))

        for item in graph_result.get("items", []):
            text = getattr(item, 'compressed_text', '') or ''
            norm_text = self._rt._normalize_text(text)
            if norm_text and norm_text in seen_texts:
                continue
            seen_texts.add(norm_text)
            merged_items.append(item)

        # Insert spreading activation results (#52)
        for item in spreading_items:
            text = getattr(item, 'compressed_text', '') or ''
            norm_text = self._rt._normalize_text(text)
            if norm_text and norm_text in seen_texts:
                # Boost existing item when spreading agrees with other paths
                for existing in merged_items:
                    existing_text = getattr(existing, 'compressed_text', '') or ''
                    if self._rt._normalize_text(existing_text) == norm_text:
                        existing.relevance_score = min(1.0, existing.relevance_score + 0.05)
                        break
                continue
            seen_texts.add(norm_text)
            merged_items.append(item)

        # ── Domain-based re-ranking (#48) ──
        dr_enabled = True
        dr_cfg = getattr(self._rt.cfg, 'domain_router', None)
        if dr_cfg:
            dr_enabled = getattr(dr_cfg, 'enabled', True)
        if dr_enabled and query:
            try:
                domain_ids, domain_path = self._rt.domain_router.get_candidate_scope(query)
                if domain_ids:
                    for item in merged_items:
                        if item.anchor and item.anchor.id in domain_ids:
                            item.relevance_score = min(1.0, item.relevance_score + 0.08)
            except Exception:
                pass

        # Sort: BM25-matched anchors first (keyword reliability), then
        # by relevance score. This prevents graph-descent items with
        # hardcoded 0.9 brain-hit scores from outranking keyword matches.
        merged_items.sort(key=lambda i: (
            not (i.anchor and i.anchor.id in bm25_matched_ids),
            -i.relevance_score,
        ))

        # Enforce retrieval budget — hard limits on node count + token budget (S-5)
        budget_state = self._rt.retrieval_budget.begin()
        merged_items = self._rt.retrieval_budget.enforce_nodes(merged_items, budget_state)
        merged_items = self._rt.retrieval_budget.enforce_tokens(merged_items, budget_state)
        merged_items = merged_items[:max_items]

        # Auto-trigger System-2 if System-1 confidence is low
        s1_confidence = graph_result.get("confidence", 1.0)
        if s1_confidence < 0.35 and len(merged_items) < max_items:
            return self._system2_recall(query, context, max_items,
                                        trigger_reason="low_confidence")

        # Record results in cognitive caches
        result_ids = [item.anchor.id for item in merged_items if item.anchor]
        result_scores = [item.relevance_score for item in merged_items]
        if query and result_ids:
            self._rt.cognitive_cache.record_query(query, result_ids, result_scores)
        for aid in result_ids:
            self._rt.cognitive_cache.record_access(aid)

        layers_visited = (["exact_cache"] if exact_results else [])
        if cache_hit_anchors:
            layers_visited.append("cognitive_cache")
        layers_visited.append("raw_buffer")
        layers_visited.extend(graph_result.get("layers_visited", []))
        total_ms = (time.time() - t_start) * 1000

        self._rt.tracer.record("recall", attributes={
            "query": query[:200],
            "max_items": max_items,
            "exact_hits": len(exact_results),
            "cache_hits": len(cache_hit_anchors),
            "raw_chunks": len(raw_results),
            "graph_items": len(graph_result.get("items", [])),
            "final_count": len(merged_items),
            "layers_visited": str(layers_visited)[:300],
            "channel": "system1",
            "exact_ms": round(exact_ms, 3),
            "cache_ms": round(cache_ms, 3),
            "raw_ms": round(raw_ms, 3),
            "graph_ms": round(graph_ms, 3),
            "spreading_ms": round(spreading_ms, 3),
            "budget_nodes": budget_state.nodes_activated,
            "budget_tokens": budget_state.tokens_used,
            "budget_truncated": budget_state.truncated,
            "total_ms": round(total_ms, 3),
        }, duration_ms=total_ms)

        return MemoryContext(
            items=merged_items,
            memory_summary=f"System-1 | Layer: {graph_result.get('layer_used', 'graph')}, visited: {layers_visited}",
            active_patterns=[],
            relevant_facts=[],
            reasoning_traces=[
                f"exact_hits={len(exact_results)}",
                f"cache_hits={len(cache_hit_anchors)}",
                f"raw_chunks={len(raw_results)}",
                f"graph_items={len(graph_result.get('items', []))}",
                f"merged={len(merged_items)}",
            ],
        )

    # ── BM25 anchor search ───────────────────────────────────

    def _bm25_anchor_search(self, query: str, query_emb: list[float] | None,
                             max_items: int, context: AgentContext | None) -> list[MemoryItem]:
        """BM25 keyword search over graph anchors with composite scoring.

        Uses the shared BM25Index on the runtime to find keyword-matching
        anchors, then computes a composite relevance score from:
          - BM25 term match (weight: 0.50)
          - Tag overlap with query terms (weight: 0.20)
          - Semantic cosine similarity (weight: 0.15)
          - Recency (weight: 0.10)
          - Importance (weight: 0.05)

        When the embedder uses hash fallback (no real semantic model),
        the semantic weight is redistributed to BM25.
        """
        if not query or not query.strip():
            return []

        bm25 = getattr(self._rt, 'bm25', None)
        if bm25 is None or bm25.size == 0:
            return []

        # Fetch 2x candidates for reranking headroom
        hits = bm25.search(query, top_k=max_items * 2)
        if not hits:
            return []

        # Detect hash-embedding fallback (no real semantic signal)
        embedder = self._rt._get_embedder()
        is_hash = getattr(embedder, '_backend', '') == 'hash'

        # Adjust weights: BM25 gets semantic weight when embeddings are degraded
        if is_hash:
            w_bm25, w_tag, w_sem, w_recency, w_importance = 0.80, 0.12, 0.00, 0.05, 0.03
        else:
            w_bm25, w_tag, w_sem, w_recency, w_importance = 0.55, 0.18, 0.15, 0.08, 0.04

        # Normalize BM25 scores to [0, 1] via exponential saturation
        max_bm25 = max(s for _, s in hits) if hits else 1.0

        # Tokenize query once for tag matching
        import re
        _tokenize = getattr(bm25, '_tokenize', None)
        if _tokenize is None:
            from .bm25 import _tokenize
        query_tokens = set(_tokenize(query))

        now = time.time()
        items: list[MemoryItem] = []
        for anchor_id, bm25_score in hits:
            anchor = self._rt.graph.anchors.get(anchor_id)
            if anchor is None or not anchor.is_retrievable:
                continue

            # 1. BM25 normalized score — calibrated so a good keyword
            #    match (BM25 ≥ 4) reaches ≥ 0.90, competing with the
            #    brain-hit baseline of 0.9 used by graph descent path.
            bm25_norm = 1.0 - math.exp(-bm25_score / 1.5)

            # 2. Tag overlap score
            tag_score = 0.0
            if anchor.tags and query_tokens:
                tag_tokens = set()
                for t in anchor.tags:
                    tag_tokens.update(_tokenize(t))
                overlap = query_tokens & tag_tokens
                if overlap:
                    tag_score = min(1.0, len(overlap) / max(len(query_tokens), 1))

            # 3. Semantic similarity
            sem_score = 0.0
            if not is_hash and query_emb and anchor.embedding:
                sem_score = max(0.0, _cosine_sim(query_emb, anchor.embedding))

            # 4. Recency (exponential decay, half-life ~7 days)
            age_seconds = now - getattr(anchor, 'created_at', now)
            half_life = 7 * 24 * 3600  # 7 days
            recency = math.exp(-math.log(2) * age_seconds / half_life) if age_seconds > 0 else 1.0

            # 5. Importance (from AnchorVector)
            importance = anchor.vector.importance if anchor.vector else 0.5

            # Composite score — scale to [0.82, 1.0] range so BM25
            # items outrank graph-descent brain hits (fixed 0.9).
            raw = (w_bm25 * bm25_norm +
                   w_tag * tag_score +
                   w_sem * sem_score +
                   w_recency * recency +
                   w_importance * importance)
            composite = raw  # raw is already calibrated to compete with graph descent

            items.append(MemoryItem(
                anchor=anchor,
                relevance_score=round(composite, 4),
                memory_type=MemoryType.SEMANTIC,
                compression_level=0,
                compressed_text=anchor.text[:200],
            ))

        items.sort(key=lambda i: -i.relevance_score)
        return items[:max_items]

    def _system2_recall(self, query: str, context: AgentContext,
                        max_items: int, trigger_reason: str) -> MemoryContext:
        """Run System-2 (goal-directed) recall via DualChannelRetriever."""
        t_start = time.time()
        dc_output = self._rt.dual_channel.retrieve(
            query=query, context=context,
            query_embedding=None, max_items=max_items,
        )
        total_ms = (time.time() - t_start) * 1000

        self._rt.tracer.record("recall", attributes={
            "query": query[:200],
            "max_items": max_items,
            "final_count": len(dc_output.items),
            "channel": dc_output.active_channel,
            "s2_triggered": dc_output.s2_triggered,
            "trigger_reason": trigger_reason,
            "s1_confidence": round(dc_output.s1_confidence, 3),
            "s2_confidence": round(dc_output.s2_confidence, 3),
            "total_ms": round(total_ms, 3),
        }, duration_ms=total_ms)

        channel_label = dc_output.active_channel
        if dc_output.s2_triggered:
            channel_label += f" (S2: {trigger_reason})"

        return MemoryContext(
            items=dc_output.items[:max_items],
            memory_summary=f"Dual-Channel [{channel_label}]",
            active_patterns=[],
            relevant_facts=[],
            reasoning_traces=[
                f"channel={dc_output.active_channel}",
                f"s2_triggered={dc_output.s2_triggered}",
                f"reason={trigger_reason}",
                f"s1_confidence={dc_output.s1_confidence:.3f}",
                f"s2_confidence={dc_output.s2_confidence:.3f}",
            ],
        )

    def _spreading_recall(self, query_emb: list[float] | None = None,
                          query: str = "", max_items: int = 10) -> list[MemoryItem]:
        """Path C: Spreading activation graph walk (#52).

        Finds seeds via ANN, then BFS-walks the graph with edge-type-weighted
        traversal. Returns MemoryItem list for merging into the main recall path.
        """
        if query_emb is None and query:
            embedder = self._rt._get_embedder()
            query_emb = embedder.encode(query)
        if query_emb is None:
            return []

        try:
            activated = self._rt.spreading.activate(
                query_embedding=query_emb, top_k=max_items)
        except Exception:
            return []

        items: list[MemoryItem] = []
        for node in activated:
            anchor = node.anchor
            if anchor is None or not anchor.is_retrievable:
                continue
            # Scale activation (0..~1.0 range) to relevance score (0..1.0)
            score = min(1.0, node.accumulated_activation)
            items.append(MemoryItem(
                anchor=anchor,
                relevance_score=score,
                memory_type=MemoryType.SEMANTIC,
                compression_level=node.activation_depth,
                compressed_text=anchor.text[:200],
            ))
        return items

    def recall_with_spreading(self, query: str = "",
                              context: AgentContext | None = None,
                              max_items: int = 10,
                              spreading_weight: float = 0.6) -> MemoryContext:
        """Spreading-first recall: graph walk as primary signal, embedding as refinement.

        Uses the SpreadingActivation BFS walk as the primary retrieval mechanism,
        with embedding similarity as a secondary re-ranking factor. This favours
        structurally-connected memories over pure semantic similarity.
        """
        if context is None:
            context = AgentContext(task_type="conversation")
        t_start = time.time()
        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None

        # Run spreading activation as primary path
        activated = self._rt.spreading.activate(
            query_embedding=query_emb, top_k=max_items * 2)

        # Convert to MemoryItem with combined topology+embedding score
        items: list[MemoryItem] = []
        for node in activated:
            anchor = node.anchor
            if anchor is None or not anchor.is_retrievable:
                continue
            topo_score = min(1.0, node.accumulated_activation)
            emb_score = 0.0
            if query_emb and anchor.embedding:
                emb_score = _cosine_sim(query_emb, anchor.embedding)
            combined = spreading_weight * topo_score + (1 - spreading_weight) * emb_score
            items.append(MemoryItem(
                anchor=anchor,
                relevance_score=combined,
                memory_type=MemoryType.SEMANTIC,
                compression_level=node.activation_depth,
                compressed_text=anchor.text[:200],
            ))

        items.sort(key=lambda i: -i.relevance_score)
        items = items[:max_items]

        total_ms = (time.time() - t_start) * 1000
        self._rt.tracer.record("recall", attributes={
            "query": query[:200],
            "max_items": max_items,
            "final_count": len(items),
            "channel": "spreading_first",
            "total_ms": round(total_ms, 3),
        }, duration_ms=total_ms)

        return MemoryContext(
            items=items,
            memory_summary=f"Spreading-First | activated {len(activated)} nodes, top {len(items)}",
            active_patterns=[],
            relevant_facts=[],
            reasoning_traces=[
                f"spreading_first",
                f"weight={spreading_weight}",
                f"activated={len(activated)}",
                f"returned={len(items)}",
            ],
        )

    def dual_recall(self, query: str = "",
                    context: AgentContext | None = None,
                    max_items: int = 10) -> DualChannelOutput:
        """Dual-channel recall: System-1 (fast association) + System-2 (goal-directed).

        System-2 auto-triggers when:
        - Query contains structural intent words (all, which, before, list, ...)
        - System-1 confidence drops below threshold (< 0.35)
        """
        if context is None:
            context = AgentContext(task_type="conversation")
        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None

        return self._rt.dual_channel.retrieve(
            query=query, context=context,
            query_embedding=query_emb, max_items=max_items,
        )

    # ── Sparse recall ─────────────────────────────────────────

    def route_to_cortex(self, query: str = "",
                        query_embedding: list[float] | None = None
                        ) -> list[RouteResult]:
        """Route a query to the most relevant cortices (1-3)."""
        return self._rt.router.route(query, query_embedding=query_embedding)

    def sparse_recall(self, query: str = "",
                      context: AgentContext | None = None,
                      max_items: int = 20) -> dict:
        """Full sparse-activation recall pipeline.

        1. Cortex routing — activate only 1-3 cortices
        2. Local recall within each activated cortex
        3. Memory gating — winner-take-all selection
        """
        if context is None:
            context = AgentContext(task_type="conversation")

        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None

        # Phase 1: Cortex routing
        routes = self._rt.router.route(query, query_embedding=query_emb)
        active_cortices = [r.cortex for r in routes]

        # Phase 2: Local recall from activated cortices only
        all_items: list = []
        for cortex in active_cortices:
            ctx = cortex.recall(query=query, context=context, max_items=max_items)
            all_items.extend(ctx.items)

        # Phase 3: Memory gating
        gated = self._rt.gate.gate(all_items, context, query_emb, query)

        return {
            "items": gated,
            "active_cortices": [c.config.name for c in active_cortices],
            "route_scores": {r.cortex.config.name: r.score for r in routes},
            "total_candidates": len(all_items),
            "gated_count": len(gated),
        }

    # ── 5-Layer dimensional descent ───────────────────────────

    def retrieve_with_descent(self, query: str = "",
                               context: AgentContext | None = None,
                               max_items: int = 15) -> dict:
        """5-layer dimensional descent retrieval pipeline.

        Layer 0: BrainSphere cache (fast path — common nodes)
            ↓ miss or insufficient results
        Layer 1: CortexSphere 3D search (semantic + gating within target cortex)
            ↓ need cross-domain or insufficient
        Layer 2: HubSphere traversal (cross-cortex hub navigation, max 2 hops)
            ↓ still insufficient
        Layer 3: 2D planar (time x importance projection, all cortices)
            ↓ still insufficient
        Layer 4: Pseudo-2D timeline scan (TimeSpine, guaranteed results)
        """
        if context is None:
            context = AgentContext(task_type="conversation")
        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None

        result = {
            "items": [],
            "layer_used": "",
            "layers_visited": [],
            "brain_hit": False,
            "total_candidates": 0,
            "active_cortices": [],
        }

        # ── Layer 0: BrainSphere (fast cache) ────────────
        result["layers_visited"].append("brain")
        brain_hits = self._rt.brain.query_common_nodes(query_emb, query, top_k=5)
        if brain_hits:
            result["brain_hit"] = True
            items = []
            for anchor in brain_hits:
                items.append(MemoryItem(
                    anchor=anchor,
                    relevance_score=0.9,
                    memory_type=MemoryType.WORKING,
                    compression_level=0,
                    compressed_text=anchor.text,
                ))
            if len(items) >= max_items:
                result["items"] = items[:max_items]
                result["layer_used"] = "brain"
                return result
            result["items"].extend(items)

        # ── Layer 1: CortexSphere 3D search ──────────────
        result["layers_visited"].append("cortex")
        routes = self._rt.router.route(query, query_embedding=query_emb)
        active_cortices = [r.cortex for r in routes if r.score > 0.1]
        result["active_cortices"] = [c.config.name for c in active_cortices]

        all_candidates: list = list(result["items"])
        for cortex in active_cortices[:3]:
            ctx = cortex.recall(query=query, context=context, max_items=max_items)
            all_candidates.extend(ctx.items)

        result["total_candidates"] = len(all_candidates)

        if all_candidates:
            gated = self._rt.gate.gate(all_candidates, context, query_emb, query)
            if len(gated) >= max_items:
                result["items"] = gated[:max_items]
                result["layer_used"] = "cortex"
                return result
            all_candidates = gated

        # ── Layer 1.5: Community-aware retrieval ──────────
        if self._rt._community_detection and self._rt._community_detection.communities:
            result["layers_visited"].append("community")
            best_community = None
            best_csim = -1.0
            route_weight = getattr(
                getattr(self._rt.cfg, 'community', None),
                'route_centroid_weight', 0.7)
            for c in self._rt._community_detection.communities:
                if c.centroid_embedding and query_emb:
                    sim = _cosine_sim(query_emb, c.centroid_embedding)
                    if sim * route_weight > best_csim:
                        best_csim = sim * route_weight
                        best_community = c.id

            if best_community and best_csim > 0.2:
                community_filter = {best_community}
                comm_items = self._rt.scheduler._community_aware_retrieve(
                    context, query, query_emb,
                    self._rt.scheduler._select_memory_types(context),
                    max_items,
                    community_filter=community_filter,
                    community_detection=self._rt._community_detection,
                )
                existing_ids = {item.anchor.id for item in all_candidates}
                for item in comm_items:
                    if item.anchor.id not in existing_ids:
                        all_candidates.append(item)
                        existing_ids.add(item.anchor.id)

                if len(all_candidates) >= max_items:
                    gated = self._rt.gate.gate(all_candidates, context, query_emb, query)
                    result["items"] = gated[:max_items]
                    result["layer_used"] = "community"
                    return result

        # ── Layer 2: HubSphere traversal ─────────────────
        result["layers_visited"].append("hub")
        existing_ids = {item.anchor.id for item in all_candidates}
        for cortex in active_cortices[:2]:
            seg = cortex.get_segment_for_hub("compressed")
            if seg and seg.hub_links:
                for hub_id in seg.hub_links[:2]:
                    related_hubs = self._rt.hublayer.traverse_hubs(hub_id, max_hops=2, max_results=3)
                    for hub in related_hubs:
                        if hub.id not in existing_ids:
                            hub_anchor = Anchor.create(
                                text=hub.text,
                                embedding=hub.embedding,
                                importance=hub.importance,
                            )
                            all_candidates.append(MemoryItem(
                                anchor=hub_anchor,
                                relevance_score=0.6,
                                memory_type=MemoryType.SEMANTIC,
                                compression_level=1,
                                compressed_text=hub.text[:120],
                            ))
                            existing_ids.add(hub.id)

        if len(all_candidates) >= max_items:
            gated = self._rt.gate.gate(all_candidates, context, query_emb, query)
            result["items"] = gated[:max_items]
            result["layer_used"] = "hub"
            return result

        # ── Layer 3: 2D planar (time x importance) ───────
        # Use TimeSpine-indexed scan for O(days*buckets) instead of O(all_anchors).
        # Falls back to time-limited cortex scan when TimeSpine is sparse/empty.
        result["layers_visited"].append("2d_plane")
        plane_items = []
        now = time.time()

        max_days = self._rt.cfg.get_path('timespine.max_days_scan', 30) if hasattr(self._rt.cfg, 'get_path') else 30
        spine_clusters = self._rt.scan_timeline(max_days=max_days, max_clusters=max_items * 2)
        spine_ids: set[str] = set()
        if spine_clusters:
            for sc in spine_clusters:
                for aid in sc.get("anchor_ids", []):
                    spine_ids.add(aid)

        candidates_from_spine = 0
        if spine_ids:
            # Look up spine-indexed anchors from global graph + all cortices
            for aid in spine_ids:
                if aid in existing_ids:
                    continue
                anchor = self._rt.graph.anchors.get(aid)
                if anchor is None:
                    for cortex in self._rt.router.cortices:
                        anchor = cortex.graph.anchors.get(aid)
                        if anchor:
                            break
                if anchor and anchor.is_retrievable:
                    hours = (now - anchor.last_activated_at) / 3600
                    recency = math.exp(-hours / 168)
                    score = 0.6 * recency + 0.4 * anchor.retention_score
                    plane_items.append((anchor, score))
                    candidates_from_spine += 1

        # Fallback: if TimeSpine is sparse, scan active cortices limited to recent window
        if candidates_from_spine < max_items:
            cutoff = now - max_days * 86400
            for cortex in active_cortices:
                for anchor in cortex.graph.anchors.values():
                    if not anchor.is_retrievable or anchor.id in existing_ids:
                        continue
                    if anchor.id in spine_ids:
                        continue  # already scored above
                    if anchor.last_activated_at < cutoff:
                        continue  # outside time window
                    hours = (now - anchor.last_activated_at) / 3600
                    recency = math.exp(-hours / 168)
                    score = 0.6 * recency + 0.4 * anchor.retention_score
                    plane_items.append((anchor, score))

        plane_items.sort(key=lambda x: -x[1])
        for anchor, score in plane_items[:max_items]:
            if anchor.id not in existing_ids:
                all_candidates.append(MemoryItem(
                    anchor=anchor, relevance_score=score,
                    memory_type=MemoryType.EPISODIC, compression_level=2,
                    compressed_text=anchor.text[:80],
                ))
                existing_ids.add(anchor.id)

        if len(all_candidates) >= max_items:
            result["items"] = [item for item in all_candidates if item.anchor is not None][:max_items]
            result["layer_used"] = "2d_plane"
            return result

        # ── Layer 4: Timeline scan (guaranteed results) ───
        result["layers_visited"].append("timeline")
        timeline_results = self._rt.scan_timeline(max_days=90, max_clusters=max_items)
        for tc in timeline_results:
            for anchor_id in tc.get("anchor_ids", []):
                if anchor_id in existing_ids:
                    continue
                anchor = self._rt.graph.anchors.get(anchor_id)
                if anchor is None:
                    for cortex in active_cortices:
                        anchor = cortex.graph.anchors.get(anchor_id)
                        if anchor:
                            break
                if anchor and anchor.is_retrievable:
                    all_candidates.append(MemoryItem(
                        anchor=anchor,
                        relevance_score=0.3 + 0.2 * tc.get("importance", 0.5),
                        memory_type=MemoryType.EPISODIC,
                        compression_level=3,
                        compressed_text=anchor.text[:60],
                    ))
                    existing_ids.add(anchor_id)

        if all_candidates:
            result["items"] = [item for item in all_candidates[:max_items] if item.anchor is not None]
        result["layer_used"] = "timeline"
        return result

    # ── Cascade recall ────────────────────────────────────────

    def cascade_recall(self, query: str = "",
                       max_chains: int = 5,
                       max_depth: int = 5) -> list:
        """Causal chain recall — trace event chains from query-relevant seeds."""
        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query)

        seeds = self._rt.scheduler._discover_seeds(
            AgentContext(task_type="reflection"), query, query_emb,
            self._rt.scheduler._select_memory_types(AgentContext()))

        seed_ids = [a.id for a in seeds[:3]]
        chains = self._rt.cascade.cascade_from_seeds(seed_ids, max_depth, max_chains)
        return [
            {"narrative": c.narrative, "confidence": c.total_confidence,
             "depth": c.depth, "type": c.chain_type}
            for c in chains if c.is_valid
        ]

    # ── Graph-first retrieval ──────────────────────────────────

    def graph_first_recall(self, query: str = "",
                           max_items: int = 10,
                           max_depth: int = 2) -> MemoryContext:
        """Graph-first retrieval: seed by embedding, then walk the graph.

        Unlike the standard recall() which ranks primarily by embedding similarity,
        this path uses graph topology as the primary signal:
        1. Find seed nodes via cheap ANN embedding search
        2. BFS walk from seeds following typed edges (causal > preference > topical)
        3. Rank all visited nodes by combined topology + embedding score

        The graph_first_weight / embedding_weight balance is configurable.
        """
        t_start = time.time()
        embedder = self._rt._get_embedder()
        query_emb = embedder.encode(query) if query else None

        if query_emb is None:
            return MemoryContext(
                items=[],
                memory_summary="Graph-First | No embedding available",
            )

        # Get graph-first weight config
        gf_cfg = getattr(self._rt.cfg, 'graph_first', None)
        graph_weight = getattr(gf_cfg, 'graph_weight', 0.6) if gf_cfg else 0.6
        embedding_weight = getattr(gf_cfg, 'embedding_weight', 0.4) if gf_cfg else 0.4
        max_depth_cfg = getattr(gf_cfg, 'max_depth', 2) if gf_cfg else max_depth

        # Run graph-first recall
        results = graph_first_recall(
            self._rt.graph,
            query_embedding=query_emb,
            top_k=max_items * 2,  # oversample for gate
            max_depth=max_depth_cfg,
            graph_weight=graph_weight,
            embedding_weight=embedding_weight,
        )

        if not results:
            return MemoryContext(
                items=[],
                memory_summary="Graph-First | No results",
            )

        # Build MemoryItems from results
        items = []
        for aid, score, depth in results:
            anchor = self._rt.graph.anchors.get(aid)
            if anchor is None or not anchor.is_retrievable:
                continue
            items.append(MemoryItem(
                anchor=anchor,
                relevance_score=score,
                memory_type=MemoryType.SEMANTIC,
                compression_level=depth,
                compressed_text=anchor.text[:200],
            ))

        # Gate the results
        if len(items) > max_items:
            items = self._rt.gate.gate(
                items,
                AgentContext(task_type="conversation"),
                query_emb,
                query,
            )[:max_items]

        total_ms = (time.time() - t_start) * 1000

        self._rt.tracer.record("graph_first_recall", attributes={
            "query": query[:200],
            "max_items": max_items,
            "max_depth": max_depth_cfg,
            "graph_weight": graph_weight,
            "embedding_weight": embedding_weight,
            "final_count": len(items),
            "total_ms": round(total_ms, 3),
        }, duration_ms=total_ms)

        return MemoryContext(
            items=items,
            memory_summary=f"Graph-First | {len(items)} items, depth<={max_depth_cfg}, "
                          f"g={graph_weight:.1f}/e={embedding_weight:.1f}",
            active_patterns=[],
            relevant_facts=[],
            reasoning_traces=[
                f"graph_first=True",
                f"depth={max_depth_cfg}",
                f"graph_weight={graph_weight}",
                f"results={len(results)}->gated->{len(items)}",
            ],
        )

    def topology_rank(self, candidate_ids: list[str] | None = None,
                      top_k: int = 20,
                      graph_weight: float = 0.6) -> list[tuple[str, float]]:
        """Rank anchors by graph topology score (centrality + edge type richness).

        Returns list of (anchor_id, topology_score) sorted descending.
        """
        return topology_rank(
            self._rt.graph,
            candidate_ids=candidate_ids,
            top_k=top_k,
            graph_weight=graph_weight,
        )

    # ── Cross-modal retrieval ─────────────────────────────────

    def cross_modal_recall(self, query: str = "",
                          query_image_path: str = "",
                          max_items: int = 10,
                          text_weight: float = 0.6,
                          image_weight: float = 0.4) -> list[CrossModalResult]:
        """Retrieve memories across text and image modalities."""
        all_anchors = dict(self._rt.graph.anchors)
        for cortex in self._rt.router.cortices:
            all_anchors.update(cortex.graph.anchors)

        return self._rt.cross_modal_retriever.retrieve(
            anchors=all_anchors,
            query_text=query,
            query_image_path=query_image_path,
            top_k=max_items,
            text_weight=text_weight,
            image_weight=image_weight,
        )

    def image_search(self, image_path: str,
                    max_items: int = 10) -> list[CrossModalResult]:
        """Find images visually similar to a query image."""
        all_anchors = dict(self._rt.graph.anchors)
        for cortex in self._rt.router.cortices:
            all_anchors.update(cortex.graph.anchors)
        return self._rt.cross_modal_retriever.image_search(
            anchors=all_anchors,
            query_image_path=image_path,
            top_k=max_items,
        )

    def text_to_image(self, query: str,
                     max_items: int = 10) -> list[CrossModalResult]:
        """Find images matching a text description (CLIP required for best results)."""
        all_anchors = dict(self._rt.graph.anchors)
        for cortex in self._rt.router.cortices:
            all_anchors.update(cortex.graph.anchors)
        return self._rt.cross_modal_retriever.text_to_image(
            anchors=all_anchors,
            query_text=query,
            top_k=max_items,
        )
