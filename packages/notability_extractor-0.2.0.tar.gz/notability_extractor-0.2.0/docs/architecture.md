# Architecture

A quick map of how the pieces fit. The tool runs in two distinct phases that
can happen on different machines.

---

## High-level flow

```
[ macOS only ]                         [ any OS ]
  extract phase                          archive layer
  -----------                            -------------
  .nbn bundles         -->               cards.jsonl
  HTTP cache (Cache.db)                  (source of truth)
                                               |
                                         build phase
                                         -----------
                                         .apkg (Anki)
                                         .json
                                         .md
```

---

## Extract phase (macOS only)

Notability stores content in two places:

**`.nbn` bundles** - one per note, under iCloud Drive. Each bundle contains:
- `HandwritingIndex/index.plist` - OCR'd handwriting and document structure
- `NBPDFIndex/PDFIndex.zip` - text layer from PDF attachments

**HTTP cache** - at `~/Library/Caches/com.notability.notability/`. Notability
Learn sends quiz and summary requests to server-side AI (Claude Haiku for quizzes,
Gemini 2.5 Flash for summaries) and caches the responses in a standard iOS/macOS
HTTP cache format:
- `Cache.db` - a SQLite database used as an HTTP response cache. It's not
  Notability's own schema; it's the system HTTP cache layer. The extractor
  treats it as an index to find which response blobs are relevant
- `fsCachedData/` - the actual response bodies, referenced by UUID from Cache.db

The extract phase walks all of this, normalizes it, and writes a flat directory
at `~/notability_export/` (or wherever `--out-dir` points when using
`--extract-only`).

A note on what "Notability's database" means: Notability doesn't have a
SQLite schema that the tool reads. `Cache.db` is SQLite but it's Apple's URL
cache layer, not a Notability-designed schema. All structured note data comes
from the `.nbn` plist/zip bundles directly.

---

## Archive layer (any OS)

`~/.notability_extractor/cards.jsonl` is the source of truth for flashcards.

Key properties:
- **JSONL format** - one JSON object per line, easy to inspect and diff
- **Atomic writes** - all writes go through a tmpfile + `os.replace()` pattern
  so the file is never partially written
- **File locking** - CRUD operations use `fcntl` on POSIX and `msvcrt` on Windows
  to prevent concurrent writes from multiple CLI or GUI processes
- **Hash-deduped snapshots** - backups check the archive hash against the most
  recent snapshot before copying; identical saves don't create redundant files
- **Retention** - configurable snapshot count; prune runs after each save

Notes and summaries are NOT archived. They're read fresh from `--input-dir` on
each build. Only flashcards persist because they can be edited, tagged, and
enriched over time.

---

## Build phase (any OS)

Takes the archive + the input directory and emits output files:

- **`.apkg`** - Anki deck package, built with `genanki`. Contains all cards from
  the archive. One deck, configurable name.
- **`.json`** - full structured dump of cards (or notes/summaries). Useful for
  scripting or loading into other tools.
- **`.md`** - human-readable formatted output. Cards are rendered as Q&A blocks;
  notes and summaries render as sections.

The build always reads from the archive, not from the raw input directory, so
any edits and tags you've added via CLI or GUI are included in every rebuild.

---

## GUI (PySide6)

A desktop companion for browsing and editing the archive without touching the CLI.

Structure:
- `main_window.py` - top-level window, sidebar, page switching
- `pages/library.py` - card editor with tag filter and color picker
- `pages/notes.py`, `pages/summaries.py` - read-only browsers
- `pages/export.py` - build runner
- `pages/settings.py` - config editor, snapshot list, scheduler install

The GUI never auto-extracts. Pull is explicit (a button in Settings). This is
intentional - auto-extraction on macOS requires access to iCloud paths that
might not exist on all setups, and the GUI should be usable on any OS.

All reads and writes go through the same archive layer the CLI uses. The GUI
doesn't have its own data format.

---

## Module layout

```
src/notability_extractor/
  cli.py                  - argparse entry point, flag dispatch
  model.py                - Card dataclass and related types
  utils.py                - logging setup, helpers
  anki.py                 - genanki wrapper for .apkg output
  archive/
    store.py              - JSONL CRUD with file locking
    backup.py             - snapshot, restore, export, import, prune
    config.py             - config.json read/write with defaults
    scheduler.py          - timer-based in-app cadence scheduler
    scheduler_install.py  - cron/launchd installer/uninstaller
    filter.py             - tag filter helpers
    exporter.py           - build-phase output writers (.json, .md)
  extract/
    nbn.py                - .nbn bundle parser (plist + PDF zip)
    http_cache.py         - Cache.db + fsCachedData/ reader
    platform_check.py     - macOS detection guard
  build/                  - high-level build orchestration
  gui/
    app.py                - QApplication entry point
    main_window.py        - window + sidebar
    theme.py              - palette setup for light/dark/auto
    pages/                - one file per sidebar page
    widgets/              - shared widget helpers
```
