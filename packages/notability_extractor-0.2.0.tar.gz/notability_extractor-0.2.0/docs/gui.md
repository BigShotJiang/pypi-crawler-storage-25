# GUI reference

Launch with `notability-extractor-gui` or `notability-extractor --gui`.

The window has a sidebar on the left. Five pages, in order from top to bottom.

---

## Library

The main flashcard editor. This is where you browse, edit, add, and delete cards.

**Left panel** - a table with three columns: ID, Tags, and Question. Clicking a
row loads that card in the editor on the right.

**Search box** - filters the table as you type. Matches against the question text
and tags.

**Tag filter** - a dropdown button labeled "Tags". Clicking it opens a popup with
a search box at the top and a scrollable, checkable tag list below. Check any
tags to narrow the table to cards that have all selected tags.

**+ Add** - creates an unsaved draft row and puts the editor in create mode.
Fill in the fields and hit Save to commit.

**Save** - writes the current card (new or edited) to the archive and takes a
backup snapshot.

**Delete** - removes the selected card from the archive after a confirmation
prompt.

**Navigating away** - selecting a different card (or closing the draft) discards
unsaved edits. There's no auto-save.

**Card editor (right panel)**:

- Question field - free text
- Four option fields (A, B, C, D) - each with a radio button on the left. The
  selected radio is the correct answer
- Tag chips below the options - each chip has a small color swatch you can click
  to open a color picker. The color is saved globally per tag name (so all cards
  sharing that tag get the same chip color). Add tags by typing in the tag input
  field and pressing Enter; remove by clicking the X on a chip
- Metadata row at the bottom: short card ID, source file, created timestamp,
  last-updated timestamp

---

## Notes

Read-only browser for note transcripts. These come from the `.nbn` bundles in
the input directory and aren't stored in the archive.

**Search box** - filters by note name and body text simultaneously.

**Splitter** - drag the divider between the note list and the text viewer to
resize. The viewer is plain text; it doesn't try to render any formatting.

---

## Summaries

Same layout as Notes, but for AI-generated summaries (from Gemini 2.5 Flash via
Notability Learn). The viewer renders markdown so headers, lists, and bold text
show up formatted.

---

## Export

Build output files from the current archive state.

**Output directory** - pick where files land. The selection is persisted to
`config.json` so you don't have to re-pick it every time.

**Format checkboxes** - choose which output formats to write per category:

- Flashcards: Anki `.apkg`, `.json`, `.md`
- Notes: `.json`, `.md`
- Summaries: `.json`, `.md`

**Export** button - runs the build. Progress/errors show in the status bar at
the bottom of the window.

The Export page doesn't re-run extraction. It builds from whatever is currently
in the archive plus whatever notes/summaries are in the configured `input_dir`.

---

## Settings

Everything that isn't a card edit.

**Extraction location** (`input_dir`) - the pre-extracted Notability directory.
Set this before clicking Pull on the Library page.

**Output directory** (`output_dir`) - default output location for builds.

**Export directory** (`export_dir`) - where manual backups from `--export` land.

**Theme** - Light, Dark, or Auto. Auto reads the OS preference. Changes apply
immediately without a restart.

**Font size** - 8 to 24pt. Applied to the whole app. Takes effect immediately.

**Log level** - Info (default) or Debug. Debug adds file-level detail to the
log. See [audit-logs.md](audit-logs.md).

**Deck name** - the Anki deck name written into `.apkg` files. Doesn't affect
filenames.

**Backup retention** - how many snapshot files to keep (1-100). Pruning runs
after each save.

**Schedule** - Off, Hourly, Daily, or Weekly. This controls the in-app timer
that fires `--backup` while the GUI is open. Separate from the system-level
scheduler (cron/LaunchAgent). See [scheduled-backups.md](scheduled-backups.md).

**Install schedule / Remove schedule** - writes or removes the platform system
scheduler entry (cron on Linux, LaunchAgent on macOS) for the selected cadence.
The cadence must not be Off to install. See [scheduled-backups.md](scheduled-backups.md).

**Pull** - re-reads the `input_dir`, merges any new flashcards into the archive,
and refreshes the Library. This is the button you click after copying a fresh
export from your Mac.

**Snapshot list** - shows existing backups with timestamps. Click a row and hit
Restore to roll the archive back to that snapshot. The current archive is
snapshotted before the restore so you can undo it.
