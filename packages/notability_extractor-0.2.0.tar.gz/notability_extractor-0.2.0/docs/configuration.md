# Configuration

Settings live at `~/.notability_extractor/config.json`. The file is created on
first run with defaults. It's a flat JSON object - you can edit it directly in
any text editor or manage it through the Settings page in the GUI.

---

## Keys

| Key | Type | Default | Description |
|---|---|---|---|
| `theme` | `"light"` \| `"dark"` \| `"auto"` | `"auto"` | Color scheme. `auto` reads the OS setting |
| `font_size` | int (8-24) | `13` | Base point size for the GUI |
| `log_level` | `"info"` \| `"debug"` | `"info"` | Detail level for audit logs |
| `deck_name` | string | `"Notability Flashcards"` | Anki deck name written into `.apkg` |
| `input_dir` | path | `""` (unset) | Pre-extracted Notability directory |
| `output_dir` | path | `"."` | Default output dir for build outputs |
| `export_dir` | path | `~/Documents/notability-backups` | Where `--export` and manual backups land |
| `schedule` | `"off"` \| `"hourly"` \| `"daily"` \| `"weekly"` | `"off"` | In-app backup timer cadence |
| `retention` | int (1-100) | `10` | How many snapshot files to keep |
| `tag_colors` | `{ "tag": "#rrggbb" }` | `{}` | Per-tag chip color, applied globally |

---

## Example

```json
{
  "theme": "dark",
  "font_size": 14,
  "log_level": "info",
  "deck_name": "My Study Cards",
  "input_dir": "/Users/mike/notability_export",
  "output_dir": "/Users/mike/anki-decks",
  "export_dir": "/Users/mike/Documents/notability-backups",
  "schedule": "daily",
  "retention": 20,
  "tag_colors": {
    "biology": "#2d7d4a",
    "chemistry": "#7b4fa0"
  }
}
```

---

## Notes on specific keys

**`theme`** - `auto` is the default and works well on both macOS and most Linux
desktops. Theme changes apply immediately in the GUI (no restart needed), though
a restart gives the palette a cleaner repaint on some systems.

**`font_size`** - affects the whole application. If things look cramped on a
high-DPI display, bump this up to 15-16.

**`input_dir`** - leave empty if you're on macOS and want auto-detection. Set it
on Linux/Windows or any time you want to point at a specific extracted directory.

**`output_dir`** - the dot default means "wherever you launched the CLI from."
In the GUI, it's set to the directory the GUI process started in. Set an
absolute path here if you want a stable location.

**`retention`** - prune runs after every save. If you set this to 5, you'll
always have the 5 most recent snapshots.

**`tag_colors`** - colors are stored as hex strings (`"#rrggbb"`). The GUI color
picker writes them here. You can set them manually if you want to pre-seed a
color scheme before running the GUI. Any tag without an entry gets the default
chip color from the current theme.

**`schedule`** - this controls the timer that fires while the GUI is open, not
the system scheduler. To install a cron/LaunchAgent job that runs even when the
GUI is closed, use the "Install schedule" button in Settings or see
[scheduled-backups.md](scheduled-backups.md).

---

## Direct editing

Changes made directly to `config.json` are picked up by the CLI immediately on
the next invocation. The GUI reloads config on each page switch, so most edits
are visible without a restart. The exception is `theme` - if you change it
outside the GUI while the GUI is running, a restart gives the palette a clean
repaint.
