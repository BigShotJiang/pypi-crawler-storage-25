# notability-extractor docs

User manual for [notability-extractor](https://github.com/mdeguzis/notability-extractor).

Install, configure, and run the tool from these focused guides:

| File | What it covers |
|---|---|
| [getting-started.md](getting-started.md) | Install, first run on each platform, where data lives |
| [cli.md](cli.md) | Every flag with examples and env overrides |
| [gui.md](gui.md) | GUI page-by-page reference (Library, Notes, Summaries, Export, Settings) |
| [configuration.md](configuration.md) | `config.json` keys, types, and defaults |
| [backups.md](backups.md) | How snapshots work, retention, restore, and manual export/import |
| [scheduled-backups.md](scheduled-backups.md) | Cron (Linux) and LaunchAgent (macOS) scheduler setup |
| [audit-logs.md](audit-logs.md) | Log location, rotation, levels, and how to grep the audit trail |
| [architecture.md](architecture.md) | How extract, archive, build, and GUI fit together |
| [development.md](development.md) | Dev environment setup, make targets, linters, test setup |
| [releasing.md](releasing.md) | How to cut a new release to PyPI |
