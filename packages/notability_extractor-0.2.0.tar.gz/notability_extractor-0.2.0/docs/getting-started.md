# Getting started

## Install

From PyPI (recommended):

```bash
pip install notability-extractor
# or with uv:
uv tool install notability-extractor
```

From source (for development):

```bash
git clone https://github.com/mdeguzis/notability-extractor.git
cd notability-extractor
make install
```

`make install` creates a `.venv/` and puts the `notability-extractor` console
script at `~/.local/bin/` so it's on your PATH.

Two binaries ship with the package:

- `notability-extractor` - the CLI, handles everything from extraction to deck building
- `notability-extractor-gui` - the PySide6 GUI companion

---

## First run on macOS

Just run it. The tool finds Notability's iCloud Drive bundles and HTTP cache
automatically, extracts quiz/summary/note content, and writes outputs to your
current directory:

```bash
notability-extractor
```

Output files land in `.`:

```
notability_flashcards.apkg
notability_flashcards.json
notability_flashcards.md
notability_notes.json
notability_notes.md
notability_summaries.json
notability_summaries.md
```

If the auto-detection fails (custom iCloud path, unusual user layout), pass
the Notability data path explicitly:

```bash
notability-extractor --input-dir ~/Library/Mobile\ Documents/iCloud~com~notability~notability/Documents
```

---

## First run on Linux or Windows

The extract phase only runs on macOS because that's where Notability and its
cache live. On Linux or Windows you need to point the tool at a directory that
was produced by running extraction on a Mac and then copying it over.

**Step 1** - on the Mac, run extraction and copy the output:

```bash
# on Mac
notability-extractor --extract-only
# ~/notability_export/ is now populated

# then copy it to the Linux/Windows machine however you like (scp, shared drive, etc.)
scp -r ~/notability_export user@linux-box:~/notability_export
```

**Step 2** - on the Linux/Windows machine, point at that dir:

```bash
notability-extractor --input-dir ~/notability_export
```

That produces the same `.apkg`, `.json`, and `.md` output files in the current
directory.

---

## First run with the GUI

```bash
notability-extractor-gui
# or:
notability-extractor --gui
```

On first launch the Library page will be empty. Go to **Settings** and set the
"Extraction location" field (the `input_dir`) to your pre-extracted directory,
then click **Pull** to import content into the archive.

On Wayland sessions without `DISPLAY` set, the GUI auto-applies
`QT_QPA_PLATFORM=wayland` so you don't need a manual export.

---

## Where data lives

All persistent state goes under `~/.notability_extractor/`:

| Path | What it is |
|---|---|
| `~/.notability_extractor/cards.jsonl` | Flashcard archive - the source of truth |
| `~/.notability_extractor/backups/` | Timestamped snapshots (`cards-YYYYMMDD-HHMMSS.jsonl`) |
| `~/.notability_extractor/config.json` | User preferences (theme, paths, schedule, etc.) |
| `~/.notability_extractor/logs/notability.log` | Rotating audit log |

Notes and summaries aren't archived - they're read fresh from `--input-dir` on
each run. Only flashcards persist in the archive so edits and tags survive
across rebuilds.
