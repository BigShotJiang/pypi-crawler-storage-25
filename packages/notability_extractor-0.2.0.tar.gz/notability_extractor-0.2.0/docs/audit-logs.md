# Audit logs

## Location

```
~/.notability_extractor/logs/notability.log
```

Both the CLI and GUI write to this file. Stderr also gets log output (at the
same level).

---

## Rotation

Logs rotate at midnight. Up to 20 dated files are kept:

```
~/.notability_extractor/logs/notability.log          # current
~/.notability_extractor/logs/notability.log.2026-05-15
~/.notability_extractor/logs/notability.log.2026-05-14
...
```

Rotated files get the date as a suffix in `YYYY-MM-DD` format. That makes them
easy to find and sort. After 20 rotations, the oldest is deleted.

---

## Log levels

**Info** (default) - covers all user-visible operations:
- Archive mutations: add, edit, delete, merge
- Pull (extract into archive)
- Build (output file generation)
- Backup: snapshot, restore, prune
- Export / import
- Schedule install / remove
- Settings changes: theme, font size, log level

**Debug** - adds:
- File-level details (which paths are being read/written)
- Subprocess calls for cron/launchd install
- Low-level cache parsing steps during extract

Switch levels in Settings or by setting `"log_level": "debug"` in `config.json`.
The CLI `--verbose` / `-v` flag also activates debug for that invocation.

---

## Log format

Each line in the file:

```
2026-05-15 09:00:00 INFO  notability_extractor.archive.store: added card a1b2c3d4
2026-05-15 09:00:00 INFO  notability_extractor.archive.backup: snapshot written to cards-20260515-090000.jsonl
```

Fields: timestamp, level, logger name (matches the module path), message.

Stderr uses a shorter format (level + message only) for readability in terminal
output.

---

## Using the audit trail

**When was a card added?**

```bash
grep "a1b2c3d4" ~/.notability_extractor/logs/notability.log
```

Replace `a1b2c3d4` with the short card ID shown in the Library editor.

**What happened on a specific day?**

```bash
cat ~/.notability_extractor/logs/notability.log.2026-05-14
```

**Find all backup events:**

```bash
grep "snapshot" ~/.notability_extractor/logs/notability.log
```

**Find all card deletions:**

```bash
grep "deleted card" ~/.notability_extractor/logs/notability.log*
```

The glob `notability.log*` covers the current file and all rotated files.

---

## Disabling file logging

File logging can only be turned off by patching `configure_logging(to_file=False)` in
`utils.py` - there's no config key for it. If the log directory isn't writable (read-only
filesystem, permission error), the tool falls back to stderr-only silently.
