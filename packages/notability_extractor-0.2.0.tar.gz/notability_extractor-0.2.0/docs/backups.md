# Backups

## How it works

`~/.notability_extractor/cards.jsonl` is the source of truth for all flashcards.
Every time any operation writes to it (CLI edit, GUI edit, Pull, import), a
snapshot is rolled to:

```
~/.notability_extractor/backups/cards-YYYYMMDD-HHMMSS.jsonl
```

The timestamp uses UTC so the filenames sort correctly regardless of timezone.

**Hash deduplication** - before writing a snapshot, the backup code checksums the
current archive and compares it against the most recent snapshot. If they match,
no copy is made. This means repeated no-op saves don't pile up identical files.

**Retention** - after each snapshot write, older snapshots are pruned so only
the `retention` newest remain. Default is 10. Configure it in Settings or
directly in `config.json`. See [configuration.md](configuration.md).

---

## Restoring a snapshot

**From the GUI**: Settings page -> scroll to the snapshot list -> select a row
-> click Restore. Before restoring, the current archive is snapshotted first, so
you can undo the restore by restoring that pre-restore snapshot.

**From the CLI**: use `--import` with `--mode replace`:

```bash
notability-extractor --import ~/.notability_extractor/backups/cards-20260515-090000.jsonl --mode replace
```

`replace` mode snapshots the current archive before wiping it, so you always
have a rollback point.

---

## Manual backup

One-shot snapshot of the current archive:

```bash
notability-extractor --backup
```

Export to a stable path in a specific format:

```bash
# byte-copy of the raw JSONL (default)
notability-extractor --export ~/cards-backup.jsonl

# pretty-printed JSON - useful for inspection or loading into other tools
notability-extractor --export ~/cards-backup.json --export-format json
```

---

## Import / merge

Bring cards in from an exported file. Two modes:

**merge** (default) - keeps existing cards, adds new ones, updates any that
share an ID with the incoming file:

```bash
notability-extractor --import ~/cards-backup.jsonl --mode merge
```

**replace** - snapshots the current archive, then replaces all cards with the
imported content:

```bash
notability-extractor --import ~/cards-backup.jsonl --mode replace
```

The import accepts both `.jsonl` (raw archive format, one JSON object per line)
and `.json` (pretty `{"cards": [...]}` object produced by `--export-format json`).

---

## Backup directory location

Default: `~/.notability_extractor/backups/`

Override with the `NOTABILITY_BACKUPS` env var (useful for testing or custom
layouts):

```bash
NOTABILITY_BACKUPS=/mnt/nas/notability-backups notability-extractor --backup
```
