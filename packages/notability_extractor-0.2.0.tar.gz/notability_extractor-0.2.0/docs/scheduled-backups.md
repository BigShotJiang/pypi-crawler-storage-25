# Scheduled backups

The tool can install a system-level periodic job that runs `notability-extractor --backup`
on a schedule, even when the GUI is closed. Platform support:

- **Linux**: crontab entry
- **macOS**: LaunchAgent plist
- **Windows**: not supported via this mechanism; use Task Scheduler manually

---

## Install from the GUI

1. Open Settings
2. Set **Schedule** to Hourly, Daily, or Weekly (not Off)
3. Click **Install schedule**

That's it. The job is installed and will start firing on the next trigger time.

To uninstall: click **Remove schedule**. The GUI also shows whether a job is
currently installed.

---

## Install from the CLI

There's no dedicated `--install-schedule` flag on the CLI. The installer is
only wired through the GUI Settings page. If you need headless setup, use one
of the manual methods below.

---

## Linux (crontab)

The installer appends a guarded block to your crontab. The block looks like:

```
# notability-extractor-backup (managed)
0 9 * * * /home/mike/.local/bin/notability-extractor --backup
```

The `# notability-extractor-backup (managed)` marker lets the tool find and
remove its own line without touching anything else in your crontab.

**Cron lines by cadence:**

| Cadence | Cron schedule |
|---|---|
| hourly | `0 * * * *` |
| daily | `0 9 * * *` (9 AM) |
| weekly | `0 9 * * 0` (9 AM Sunday) |

**Manual setup** - if you want to wire it yourself, grab the exact line from
Settings (it's displayed in the "headless cron" section) and add it to your
crontab:

```bash
crontab -e
# add:
# 0 9 * * * /path/to/notability-extractor --backup
```

**Remove manually** - if you installed via GUI and want to clean up by hand:

```bash
crontab -l | grep -v "notability-extractor" | crontab -
```

---

## macOS (LaunchAgent)

The installer writes a plist to:

```
~/Library/LaunchAgents/com.local.notability-extractor-backup.plist
```

Then runs `launchctl load` on it. The agent is registered with launchd so it
survives reboots. No Full Disk Access permission is needed.

**Calendar intervals by cadence:**

| Cadence | Fires at |
|---|---|
| hourly | every hour at :00 |
| daily | 9:00 AM |
| weekly | Sunday at 9:00 AM |

**Check if it's loaded:**

```bash
launchctl list | grep notability
```

**Remove manually:**

```bash
launchctl unload ~/Library/LaunchAgents/com.local.notability-extractor-backup.plist
rm ~/Library/LaunchAgents/com.local.notability-extractor-backup.plist
```

---

## How it interacts with the in-app scheduler

The **Schedule** setting in Settings controls two things:

1. The in-app timer (fires `--backup` while the GUI is open)
2. The cadence used when you click Install schedule

These are independent. You can have the in-app timer on `hourly` but no system
job installed, or a daily LaunchAgent with the in-app timer set to `off`. The
system job runs `notability-extractor --backup` as a subprocess - it doesn't
need the GUI to be open.
