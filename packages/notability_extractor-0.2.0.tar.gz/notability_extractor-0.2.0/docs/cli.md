# CLI reference

Full help: `notability-extractor --help`

---

## Extraction and build flags

### `--input-dir DIR`

Path to a pre-extracted Notability export directory. Required on Linux and
Windows. On macOS, omitting this triggers auto-detection.

```bash
notability-extractor --input-dir ~/notability_export
```

### `--out-dir DIR`

Directory to write output files (`.apkg`, `.json`, `.md`). Defaults to the
current working directory.

```bash
notability-extractor --input-dir ~/notability_export --out-dir ~/decks
```

### `--extract-only`

macOS only. Run phase 1 (extract to `~/notability_export/`) without building
any output files. Useful when you want to extract on a Mac and then process
on another machine.

```bash
notability-extractor --extract-only
```

### `--deck-name NAME`

Sets the Anki deck name that shows up inside Anki after import. Doesn't affect
filenames. Default is `Notability Flashcards`.

```bash
notability-extractor --deck-name "Bio 340 Midterm"
```

---

## Archive management

### `--edit-flashcards`

Opens a prompt-driven editor loop over the flashcard archive. Lets you edit
question, options, correct answer, and tags for any card interactively.

```bash
notability-extractor --edit-flashcards
```

### `--add-card`

Interactively add a single card to the archive. Prompts for question, options,
correct answer, and tags.

```bash
notability-extractor --add-card
```

### `--list-cards`

Print all cards in the archive to stdout, one per block.

```bash
notability-extractor --list-cards
```

### `--tag TAG`

Filter `--list-cards` output to cards that have this tag.

```bash
notability-extractor --list-cards --tag biology
```

---

## Backup and restore

### `--backup`

Take a one-shot snapshot of the archive to
`~/.notability_extractor/backups/cards-YYYYMMDD-HHMMSS.jsonl`.
Hash-deduped so identical archives don't make redundant copies.

```bash
notability-extractor --backup
```

### `--export PATH`

Dump the archive to a file at PATH. Useful for moving the archive to another
machine or keeping a stable backup in a known location.

```bash
notability-extractor --export ~/cards-2026-05.jsonl
```

### `--export-format {jsonl,json}`

Controls the format written by `--export`. `jsonl` (default) is a byte-copy
of the raw archive. `json` is a pretty-printed `{"cards": [...]}` object.

```bash
notability-extractor --export ~/cards.json --export-format json
```

### `--import PATH`

Load cards from PATH into the archive. Accepts both `.jsonl` and `.json`
formats. See `--mode` for merge behavior.

```bash
notability-extractor --import ~/cards-2026-05.jsonl
```

### `--mode {merge,replace}`

Controls what happens to existing cards when importing. `merge` (default)
keeps existing cards and adds/updates from the import file. `replace` snapshots
the current archive first, then replaces all cards with the import contents.

```bash
# merge: add new cards, update existing ones
notability-extractor --import ~/cards.jsonl --mode merge

# replace: wipe and reload (current archive is snapshotted first)
notability-extractor --import ~/cards.jsonl --mode replace
```

---

## GUI and display

### `--gui`

Launch the PySide6 GUI. Same as running `notability-extractor-gui` directly.

```bash
notability-extractor --gui
```

### `--verbose` / `-v`

Enable DEBUG-level logging. Logs go to both stderr and
`~/.notability_extractor/logs/notability.log`.

```bash
notability-extractor --verbose --list-cards
```

### `--version`

Print the installed version and exit.

```bash
notability-extractor --version
```

---

## Environment overrides

These env vars let you redirect the archive and backups to non-default paths.
Mainly used in tests, but handy for power users who want a custom layout.

| Variable | Default | What it controls |
|---|---|---|
| `NOTABILITY_ARCHIVE` | `~/.notability_extractor/cards.jsonl` | Path to the JSONL archive |
| `NOTABILITY_BACKUPS` | `~/.notability_extractor/backups/` | Directory for snapshots |

Example - use a scratch archive for a test run without touching your real data:

```bash
NOTABILITY_ARCHIVE=/tmp/test-cards.jsonl notability-extractor --list-cards
```
