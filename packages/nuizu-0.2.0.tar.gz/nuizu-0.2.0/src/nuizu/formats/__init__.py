"""Embroidery file format writers."""
