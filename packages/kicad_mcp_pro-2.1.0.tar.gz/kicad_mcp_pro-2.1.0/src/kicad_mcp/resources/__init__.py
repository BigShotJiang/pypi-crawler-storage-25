"""Resource registrations."""
