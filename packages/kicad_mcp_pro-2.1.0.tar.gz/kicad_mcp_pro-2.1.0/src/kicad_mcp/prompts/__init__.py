"""Prompt registrations."""
