"""Bundled manufacturer DFM profiles."""

