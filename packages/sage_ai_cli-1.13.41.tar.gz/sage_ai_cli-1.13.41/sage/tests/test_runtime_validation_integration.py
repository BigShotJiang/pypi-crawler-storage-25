"""TDD tests for runtime validation integration.

This test file verifies that validation functions are wired into the main
execution loop and actually BLOCK bad responses instead of just warning.

CRITICAL: These tests verify enforcement, not just detection.

Run with: pytest sage/tests/test_runtime_validation_integration.py -v
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch, call
from typing import Any

import pytest


# =============================================================================
# Runtime Integration: Analysis Request Validation
# =============================================================================

class TestAnalysisRequestEnforcement:
    """Tests that analysis requests are validated and rejected at runtime."""

    def test_analysis_response_rejected_without_file_reads(self):
        """Analysis responses must read files or be rejected with retry."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the codebase and list 100 items that should be improved"

        # Mock LLM that returns bad response (no file reads, just generic items)
        bad_response = """
Here are 100 improvements for the codebase:

1. Implement basic logging for debugging information
2. Implement basic logging for informational messages
3. Implement basic logging for tracing requests
... (97 more similar items)
"""

        # Mock the LLM call
        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = bad_response

            # Mock file system to show no files were read
            with patch('sage.main._track_files_read') as mock_tracker:
                mock_tracker.return_value = []  # No files read

                # Should reject and retry with feedback, then raise exception after max retries
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(user_request)

                # Verify it raised max retries exception
                assert "max retries exceeded" in str(exc_info.value).lower()

                # Verify retry was attempted with specific feedback
                assert mock_llm.call_count >= 2  # Initial + at least one retry

                # Check that retry included validation feedback
                retry_call = mock_llm.call_args_list[1]
                retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')

                assert "validation" in retry_prompt.lower() or "rejected" in retry_prompt.lower()
                assert "files" in retry_prompt.lower() or "analysis" in retry_prompt.lower()

    def test_analysis_response_accepted_with_sufficient_reads(self):
        """Analysis responses with sufficient file reads should be accepted."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the codebase and list 10 items that should be improved"

        # Good response with file references
        good_response = """
Based on analyzing the codebase (5 files read), here are improvements:

1. In backend/app.py: Add rate limiting to API endpoints
2. In sage/main.py: Refactor tool execution loop for clarity
3. In backend/auth.py: Fix authentication bypass vulnerability
... (7 more specific items with file references)
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = good_response

            # Mock file system to show files were read
            with patch('sage.main._track_files_read') as mock_tracker:
                mock_tracker.return_value = [
                    "backend/app.py",
                    "sage/main.py",
                    "backend/auth.py",
                    "sage/core/shell.py",
                    "backend/config.py"
                ]

                result = _execute_request_with_validation(user_request)

                # Should not retry, accept on first attempt
                assert mock_llm.call_count == 1

    def test_descriptive_tool_mentions_trigger_rejection(self):
        """Responses that describe tools instead of executing should be rejected."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the authentication system"

        # Bad response: describes what it WILL do
        bad_response = """
I will investigate this by reading the following files:

READ: backend/auth.py
READ: backend/app.py
READ: backend/config.py

Then I will analyze the architecture.
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = bad_response

            # Should reject and retry, then raise exception
            with pytest.raises(Exception) as exc_info:
                _execute_request_with_validation(user_request)

            # Verify it raised max retries exception
            assert "max retries exceeded" in str(exc_info.value).lower()

            # Should reject and retry
            assert mock_llm.call_count >= 2

            # Retry should mention tool execution issue
            retry_call = mock_llm.call_args_list[1]
            retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')
            assert "execute" in retry_prompt.lower() or "tool" in retry_prompt.lower()

    def test_repetitive_filler_triggers_rejection(self):
        """Responses with high repetition score should be rejected."""
        from sage.main import _execute_request_with_validation

        user_request = "List 20 security improvements"

        # Bad response: repetitive template
        filler_response = """
1. Implement input validation for endpoint A
2. Implement input validation for endpoint B
3. Implement input validation for endpoint C
4. Implement input validation for endpoint D
... (16 more identical items)
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = filler_response

            # Should reject and retry, then raise exception
            with pytest.raises(Exception) as exc_info:
                _execute_request_with_validation(user_request)

            # Verify it raised max retries exception
            assert "max retries exceeded" in str(exc_info.value).lower()

            # Should reject and retry
            assert mock_llm.call_count >= 2

            # Retry should mention repetition/filler issue
            retry_call = mock_llm.call_args_list[1]
            retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')
            assert "repetitive" in retry_prompt.lower() or "filler" in retry_prompt.lower() or "varied" in retry_prompt.lower()


# =============================================================================
# Runtime Integration: Implementation Request Validation
# =============================================================================

class TestImplementationRequestEnforcement:
    """Tests that implementation requests are validated and rejected at runtime."""

    def test_phantom_implementation_rejected(self):
        """Implementation claims without FILE: blocks should be rejected."""
        from sage.main import _execute_request_with_validation

        user_request = "Implement a ProxyCore class with routing logic"

        # Bad response: claims implementation but no FILE: blocks
        phantom_response = """
I've implemented the proxy core functionality:

```python
# proxy_core.py
class ProxyCore:
    def __init__(self):
        self.config = {}

    def route_request(self, request):
        return self.proxy.forward(request)
```

Implementation complete!
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = phantom_response

            # Mock to show no files were actually written
            with patch('sage.main._track_files_written') as mock_writer:
                mock_writer.return_value = []

                # Should reject and retry, then raise exception
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(
                        user_request,
                        is_implementation_request=True
                    )

                # Verify it raised max retries exception
                assert "max retries exceeded" in str(exc_info.value).lower()

                # Should reject and retry
                assert mock_llm.call_count >= 2

                # Retry should mention FILE: blocks requirement
                retry_call = mock_llm.call_args_list[1]
                retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')
                assert "FILE:" in retry_prompt or "file" in retry_prompt.lower()

    def test_valid_implementation_with_file_blocks_accepted(self):
        """Implementation with FILE: blocks and actual writes should be accepted."""
        from sage.main import _execute_request_with_validation

        user_request = "Implement a ProxyCore class"

        # Good response with FILE: blocks
        valid_response = """
FILE: proxy_core.py
class ProxyCore:
    def __init__(self):
        self.config = {}

FILE: test_proxy_core.py
def test_proxy_core():
    proxy = ProxyCore()
    assert proxy is not None
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = valid_response

            # Mock to show files were written
            with patch('sage.main._track_files_written') as mock_writer:
                mock_writer.return_value = ["proxy_core.py", "test_proxy_core.py"]

                result = _execute_request_with_validation(
                    user_request,
                    is_implementation_request=True
                )

                # Should accept on first attempt
                assert mock_llm.call_count == 1

    def test_tdd_compliance_enforced(self):
        """TDD implementation must have both tests and implementation files."""
        from sage.main import _execute_request_with_validation

        user_request = "Implement feature X using TDD"

        # Bad response: only implementation, no tests
        no_tests_response = """
FILE: feature_x.py
class FeatureX:
    def do_something(self):
        return 42

Implementation complete!
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = no_tests_response

            with patch('sage.main._track_files_written') as mock_writer:
                mock_writer.return_value = ["feature_x.py"]  # No test file

                # Should reject and retry, then raise exception
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(
                        user_request,
                        is_implementation_request=True,
                        requires_tdd=True
                    )

                # Verify it raised max retries exception
                assert "max retries exceeded" in str(exc_info.value).lower()

                # Should reject and retry
                assert mock_llm.call_count >= 2

                # Retry should mention TDD/tests requirement
                retry_call = mock_llm.call_args_list[1]
                retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')
                assert "test" in retry_prompt.lower() or "tdd" in retry_prompt.lower()


# =============================================================================
# Runtime Integration: Post-Action Verification
# =============================================================================

class TestPostActionVerification:
    """Tests that filesystem and command execution are verified."""

    def test_file_write_verification_before_claiming_success(self):
        """SAGE must verify files exist before claiming write success."""
        from sage.main import _execute_file_write_and_verify

        file_path = "test_file.py"
        content = "print('hello')"

        # Mock file write that claims success but doesn't actually write
        with patch('sage.main._write_file') as mock_write:
            mock_write.return_value = True  # Claims success

            # Mock file check that shows file doesn't exist
            with patch('sage.main._file_exists') as mock_exists:
                mock_exists.return_value = False  # File doesn't exist

                # Should detect mismatch and raise error
                with pytest.raises(Exception) as exc_info:
                    _execute_file_write_and_verify(file_path, content)

                assert "verification failed" in str(exc_info.value).lower()
                assert "file does not exist" in str(exc_info.value).lower()

    def test_command_execution_verification_before_showing_output(self):
        """SAGE must verify commands actually ran before showing output."""
        from sage.main import _execute_command_and_verify

        command = "pytest tests/test_feature.py -v"

        # Mock command that claims success with fake output
        with patch('sage.main._run_command') as mock_run:
            # Claims pytest passed but file doesn't exist
            mock_run.return_value = ("✅ All tests passed", 0)

            # Mock file check showing test file doesn't exist
            with patch('sage.main._file_exists') as mock_exists:
                mock_exists.return_value = False

                # Should detect impossible output and reject
                with pytest.raises(Exception) as exc_info:
                    _execute_command_and_verify(command)

                assert "verification failed" in str(exc_info.value).lower()
                assert "test file" in str(exc_info.value).lower() or "does not exist" in str(exc_info.value).lower()

    def test_post_write_content_verification(self):
        """Verify written file content matches what was requested."""
        from sage.main import _execute_file_write_and_verify

        file_path = "test_output.py"
        expected_content = "def foo():\n    return 42"

        with patch('sage.main._write_file') as mock_write:
            mock_write.return_value = True

            # File exists but content is wrong
            with patch('sage.main._file_exists') as mock_exists:
                mock_exists.return_value = True

                with patch('sage.main._read_file') as mock_read:
                    mock_read.return_value = "def bar():\n    return 24"  # Wrong content

                    # Should detect content mismatch
                    with pytest.raises(Exception) as exc_info:
                        _execute_file_write_and_verify(
                            file_path,
                            expected_content,
                            verify_content=True
                        )

                    assert "content mismatch" in str(exc_info.value).lower()


# =============================================================================
# Runtime Integration: Retry Loop with Feedback
# =============================================================================

class TestValidationRetryLoop:
    """Tests that validation failures trigger retries with specific feedback."""

    def test_retry_loop_includes_validation_violations(self):
        """Retry prompts must include specific validation violations."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the codebase"

        # Bad response that violates multiple rules
        bad_response = """
I will read these files:
READ: file1.py
READ: file2.py

1. Implement logging for A
2. Implement logging for B
3. Implement logging for C
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = bad_response

            with patch('sage.main._track_files_read') as mock_tracker:
                mock_tracker.return_value = []

                # Should reject and retry, then raise exception
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(user_request)

                # Verify it raised max retries exception
                assert "max retries exceeded" in str(exc_info.value).lower()

                # Should retry with violations listed
                assert mock_llm.call_count >= 2

                retry_call = mock_llm.call_args_list[1]
                retry_prompt = retry_call[0][0] if retry_call[0] else retry_call[1].get('prompt', '')

                # Should mention multiple violations
                assert "validation" in retry_prompt.lower()
                assert "tool" in retry_prompt.lower() or "execute" in retry_prompt.lower() or "files" in retry_prompt.lower()

    def test_retry_loop_has_max_attempts(self):
        """Retry loop should have maximum attempts to prevent infinite loops."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the codebase"

        # Always return bad response
        bad_response = "Generic response without any file reads"

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = bad_response

            with patch('sage.main._track_files_read') as mock_tracker:
                mock_tracker.return_value = []

                # Should eventually give up
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(user_request, max_retries=2)

                # Should have tried max_retries + 1 times (initial + retries)
                assert mock_llm.call_count == 3  # 1 initial + 2 retries
                assert "max retries exceeded" in str(exc_info.value).lower()

    def test_successful_retry_stops_loop(self):
        """Retry loop should stop when validation passes."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze the code"

        bad_response = "Generic response"
        good_response = "After reading file1.py, file2.py: Here is the analysis..."

        with patch('sage.main._call_llm') as mock_llm:
            # First call bad, second call good
            mock_llm.side_effect = [bad_response, good_response]

            with patch('sage.main._track_files_read') as mock_tracker:
                # First call no files, second call has files
                mock_tracker.side_effect = [[], ["file1.py", "file2.py"]]

                result = _execute_request_with_validation(user_request)

                # Should stop after successful second attempt
                assert mock_llm.call_count == 2
                assert result == good_response


# =============================================================================
# Runtime Integration: Fail-Closed Behavior
# =============================================================================

class TestFailClosedBehavior:
    """Tests that SAGE fails closed when critical operations fail."""

    def test_missing_read_command_results_fails_closed(self):
        """If READ: command fails, response must acknowledge failure."""
        from sage.main import _execute_request_with_validation

        user_request = "Analyze backend/nonexistent.py"

        # Response that assumes file was read successfully
        assumes_success_response = """
Based on analyzing backend/nonexistent.py:

1. The authentication logic needs refactoring
2. Add rate limiting
3. Improve error handling
"""

        with patch('sage.main._call_llm') as mock_llm:
            mock_llm.return_value = assumes_success_response

            # Mock to show no files were read (simulating failed read)
            with patch('sage.main._track_files_read') as mock_tracker:
                mock_tracker.return_value = []  # No files read (read failed)

                # Should fail closed and reject the response
                with pytest.raises(Exception) as exc_info:
                    _execute_request_with_validation(user_request)

                # Verify it raised max retries exception
                assert "max retries exceeded" in str(exc_info.value).lower()

                # Should have retried because analysis referenced failed read
                assert mock_llm.call_count >= 2

    def test_admin_auth_fails_closed_on_empty_token(self):
        """Admin endpoints must reject when admin_token is empty."""
        from backend.app import _require_admin_token_strict

        mock_request = MagicMock()
        mock_config = MagicMock()
        mock_config.admin_token = ""  # Empty token

        # Should fail closed (reject) not fail open (allow)
        with pytest.raises(Exception) as exc_info:
            _require_admin_token_strict(mock_request, mock_config)

        assert "not configured" in str(exc_info.value).lower() or "invalid" in str(exc_info.value).lower()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
