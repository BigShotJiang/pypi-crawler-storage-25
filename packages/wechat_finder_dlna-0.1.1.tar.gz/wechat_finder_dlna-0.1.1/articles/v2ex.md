最近想把视频号的一些直播存下来，搜了一圈发现这事居然这么麻烦 —— 要么挂代理抓包装证书，要么上逆向 Hook 微信进程，总之没一个省心的。

后来突然想到一个事：微信投屏到电视不是用的 DLNA 吗？那电视能拿到直播流地址，我电脑装个假电视不就行了？

试了一下，还真可以。SSDP 组播宣告自己是 MediaRenderer，微信就会在投屏列表里显示出来。选中之后微信会通过 SOAP 把 m3u8 地址 POST 过来，直接截获就完事了。

整个过程不需要动微信客户端，不需要证书，不需要代理，因为这就是标准的 DLNA 协议流程 —— 微信没法区分真电视和假电视。

用纯 Python 标准库写的，零依赖，500 来行代码：

```bash
pip install wechat-finder-dlna
wechat-finder-dlna
# 手机投屏过来就能拿到直播流地址
```

拿到地址之后 ffmpeg 录制、VLC 播放都行。也支持 `--record` 直接录。

B 站、爱奇艺那些支持 DLNA 投屏的 App 也都能用，不只是微信。

项目在这：https://github.com/gtoxlili/wechat-finder-dlna

有想法欢迎提 issue 交流。
