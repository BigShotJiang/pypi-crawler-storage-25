# Typerform

A Type-Safe UI/CLI Generator powered by Pydantic and Prompt-Toolkit.

[![PyPI version](https://img.shields.io/pypi/v/pytypeform.svg)](https://pypi.org/project/pytypeform/)
[![Python](https://img.shields.io/pypi/pyversions/pytypeform.svg)](https://pypi.org/project/pytypeform/)
[![CI](https://github.com/STHITAPRAJNAS/typeform/actions/workflows/ci.yml/badge.svg)](https://github.com/STHITAPRAJNAS/typeform/actions/workflows/ci.yml)
[![License](https://img.shields.io/badge/license-Apache%202.0-green)](LICENSE)
[![Typed](https://img.shields.io/badge/typing-py.typed-informational)](src/typeform/py.typed)

Typerform transforms your Pydantic models into professional, interactive CLI wizards. Stop writing boilerplate input loops and manual validation—let your schemas drive the user experience.

## Features

| Feature | Description |
|---------|-------------|
| **Zero Boilerplate** | Just one line of code to generate an entire multi-step wizard. |
| **Type-Safe** | Inherits all constraints (min_length, ge, EmailStr) from Pydantic. |
| **Backtracking** | Full backtracking support—type :b or :back to edit previous fields. |
| **Conditional Logic** | Dynamically skip fields based on previous answers using 'when' metadata. |
| **Secure by Default** | Automatic masking for SecretStr fields (API keys, passwords). |
| **Enterprise Ready** | Pluggable prompt engines for 100% automated testing in CI/CD. |
| **Smart Autocomplete**| Fuzzy search and real-time suggestions for Enums and Literals. |
| **Hydration** | Pre-fill forms from Environment variables or configuration files. |

## Installation

```bash
pip install pytypeform
```

## Quick Start

```python
from typing import Literal
from pydantic import BaseModel, Field
from typeform import form

class SetupConfig(BaseModel):
    project_name: str = Field(description="Project Name", min_length=3)
    environment: Literal["dev", "staging", "prod"] = Field(default="dev")
    enable_telemetry: bool = Field(default=True, description="Enable Telemetry")

# Generate the wizard!
config = form(SetupConfig, title="Project Setup")

print(config.model_dump())
```

## Advanced Usage

### Backtracking and Navigation
Typerform maintains a navigation stack. At any prompt, you can use special commands:
*   `:back` or `:b` - Move to the previous field.
*   `:?` - Show extended help text (if provided in `json_schema_extra`).

### Conditional Logic
Hide or show fields dynamically based on the current state of the form:

```python
class CloudConfig(BaseModel):
    provider: Literal["aws", "gcp"]
    # Only asked if provider is 'aws'
    aws_region: str = Field(
        "us-east-1", 
        json_schema_extra={"when": "provider == 'aws'"}
    )
```

### Collection Wizard (Lists)
Typerform handles `List[T]` by entering a collection loop:

```python
class Team(BaseModel):
    members: list[str] = Field(description="Team Members")

# User will be prompted to add multiple items sequentially.
```

### Hydration (Auto-filling)
Speed up workflows by pre-filling fields from the environment:

```python
import os
config = form(MyModel, hydrate_from=[os.environ])
```

## Contributing

Contributions are welcome! Whether it's bug reports, feature requests, or new prompt engines.

```bash
git clone https://github.com/STHITAPRAJNAS/typeform.git
cd typeform
pip install -e ".[dev]"
pytest                        # run test suite
ruff check src/typeform      # lint
mypy src/typeform            # type-check
```

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

Copyright (c) 2026 Sthitaprajna Sahoo and contributors.
