import pytest
from typing import Literal, Optional, Any, Dict
from enum import Enum
from pydantic import BaseModel, Field, SecretStr
from typeform import form
from typeform.core import PromptEngine, set_engine, config
import io
from rich.console import Console

# Setup global test config
config.verbose = True 
config.console = Console(file=io.StringIO(), force_terminal=False, width=80)

class MockEngine(PromptEngine):
    def __init__(self, responses: list):
        self.responses = responses
        self.index = 0
        self.last_calls = []

    def _get_next(self):
        if self.index >= len(self.responses):
            raise RuntimeError(f"MockEngine out of responses at index {self.index}")
        res = self.responses[self.index]
        self.index += 1
        return res

    def ask_text(self, message: str, default: str = "", password: bool = False) -> str:
        self.last_calls.append(("text", message))
        return self._get_next()

    def ask_confirm(self, message: str, default: bool = False) -> bool:
        self.last_calls.append(("confirm", message))
        return self._get_next()

    def ask_choice(self, message: str, choices: list[str], default: str = "") -> str:
        self.last_calls.append(("choice", message, choices))
        return self._get_next()

def test_backtracking():
    # Sequence: 
    # 1. name -> "johndoe"
    # 2. age -> ":b" (go back)
    # 3. name -> "realname"
    # 4. age -> "30"
    mock = MockEngine(responses=["johndoe", ":b", "realname", "30"])
    set_engine(mock)
    
    class User(BaseModel):
        name: str
        age: int

    result = form(User)
    assert result.name == "realname"
    assert result.age == 30

def test_conditional_logic():
    class ConditionalModel(BaseModel):
        use_db: bool
        db_type: Optional[str] = Field(None, json_schema_extra={"when": "use_db == True"})
        other: str

    # Case 1: use_db is False -> db_type should be skipped
    mock = MockEngine(responses=[False, "something"])
    set_engine(mock)
    res = form(ConditionalModel)
    assert res.use_db is False
    assert res.db_type is None
    assert res.other == "something"

    # Case 2: use_db is True -> db_type should be asked
    mock = MockEngine(responses=[True, "postgres", "something_else"])
    set_engine(mock)
    res = form(ConditionalModel)
    assert res.use_db is True
    assert res.db_type == "postgres"
    assert res.other == "something_else"

def test_hydration():
    class HydratedModel(BaseModel):
        api_key: str
        app_name: str

    mock = MockEngine(responses=["manual-name"])
    set_engine(mock)
    
    # Hydrate api_key from dict, leave app_name for prompt
    sources = [{"API_KEY": "secret-123"}]
    res = form(HydratedModel, hydrate_from=sources)
    
    assert res.api_key == "secret-123"
    assert res.app_name == "manual-name"
