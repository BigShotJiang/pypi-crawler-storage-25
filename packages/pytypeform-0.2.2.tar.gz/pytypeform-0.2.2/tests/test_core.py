import pytest
from typing import Literal, Optional, Any
from enum import Enum
from unittest.mock import MagicMock

from pydantic import BaseModel, Field, SecretStr
from typeform import form
from typeform.core import PromptEngine, set_engine, config
import io
from rich.console import Console

# Setup global test config
config.verbose = True 
config.console = Console(file=io.StringIO(), force_terminal=False, width=80)

class MockEngine(PromptEngine):
    def __init__(self, responses: list):
        self.responses = responses
        self.index = 0
        self.last_calls = []

    def _get_next(self):
        if self.index >= len(self.responses):
            raise RuntimeError(f"MockEngine out of responses at index {self.index}. Responses provided: {self.responses}")
        res = self.responses[self.index]
        self.index += 1
        return res

    def ask_text(self, message: str, default: str = "", password: bool = False) -> str:
        self.last_calls.append(("text", message, password))
        return self._get_next()

    def ask_confirm(self, message: str, default: bool = False) -> bool:
        self.last_calls.append(("confirm", message))
        return self._get_next()

    def ask_choice(self, message: str, choices: list[str], default: str = "") -> str:
        self.last_calls.append(("choice", message, choices))
        return self._get_next()

class Environment(Enum):
    DEV = "dev"
    PROD = "prod"

class DatabaseConfig(BaseModel):
    host: str = Field(description="DB Host")
    port: int = Field(description="DB Port", default=5432)

class ServerConfig(BaseModel):
    name: str = Field(min_length=3)
    env: Environment
    db: DatabaseConfig
    is_active: bool = True
    optional_tag: Optional[str] = None

def test_form_nested_and_enum():
    mock = MockEngine(responses=[
        "myserver",  # name
        "prod",      # env
        "localhost", # db.host
        "5433",      # db.port
        False,       # is_active
        ""           # optional_tag
    ])
    set_engine(mock)
    
    result = form(ServerConfig, title="Test Server Config")
    
    assert result.name == "myserver"
    assert result.env == Environment.PROD
    assert result.is_active is False
    assert result.db.port == 5433
    assert result.optional_tag is None

def test_secret_str_masking():
    mock = MockEngine(responses=["top-secret-key"])
    set_engine(mock)
    
    class Credentials(BaseModel):
        api_key: SecretStr

    result = form(Credentials)
    
    assert result.api_key.get_secret_value() == "top-secret-key"
    assert mock.last_calls[0][2] is True # password=True

def test_field_exclusion():
    mock = MockEngine(responses=["johndoe"])
    set_engine(mock)
    
    class User(BaseModel):
        username: str
        internal_id: str = "HIDDEN"

    result = form(User, exclude={"internal_id"})
    
    assert result.username == "johndoe"
    assert result.internal_id == "HIDDEN"
    assert mock.index == 1

def test_form_validation_retry():
    mock = MockEngine(responses=["abc", "validname"])
    set_engine(mock)
    
    class SimpleConfig(BaseModel):
        username: str = Field(min_length=5)

    result = form(SimpleConfig)
    
    assert result.username == "validname"
    assert mock.index == 2
