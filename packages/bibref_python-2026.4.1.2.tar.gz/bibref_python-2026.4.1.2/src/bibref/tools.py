import sys, pexpect, os, re, shutil

bibref_default_timeout = 5
bibref_default_timeout_max = 180
bibref_fullpath = ""

bibref = None

def set_bibref_path(fullpath = ""):
    global bibref_fullpath
    bibref_fullpath = fullpath

def spawn_bibref():
    global bibref
    if bibref is not None:
        return
    sys.stderr.write("Waiting for bibref's full startup...\n")

    if bibref_fullpath != "":
        bibref = pexpect.spawn(bibref_fullpath + " -a")
        bibref.expect("Done loading books of SBLGNT.")
        bibref.timeout = bibref_default_timeout
        return

    bibref_fullpath_auto = shutil.which("bibref")

    if bibref_fullpath_auto is None:
        raise RuntimeError(
            "No 'bibref' binary can be found in PATH. "
            "Install it first by using `snap install bibref`, for example. "
            "Alternatively, use 'set_bibref_path(...)' to set the correct full path."
        )

    sys.stderr.write(f"Spawning {bibref_fullpath_auto}...\n")
    bibref = pexpect.spawn(bibref_fullpath_auto + " -a")
    bibref.expect("Done loading books of SBLGNT.")
    bibref.timeout = bibref_default_timeout

def getrefs_maxlength(getrefs_input):
    """
    Returns the length of the longest match.
    :param getrefs_input: All parameters of getrefs as string
    :return: The length of the longest match
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout_max
    command = "getrefs " + getrefs_input
    bibref.sendline(command)
    bibref.expect("Finished")
    lines = bibref.before.decode('utf-8').splitlines()
    no_lines = len(lines)
    length_regex = re.compile(r'length=([0-9]+),')
    found = length_regex.search(lines[no_lines - 1])
    maxlength0 = found.group()
    maxlength1 = maxlength0.split("=")
    maxlength2 = maxlength1[1]
    maxlength3 = maxlength2.split(",")
    maxlength = maxlength3[0]
    bibref.timeout = bibref_default_timeout
    return maxlength

def text_n(c, greektext):
    """
    Stores the Greek input in the selected clipboard.
    :param c: Clipboard number (1 or 2)
    :param greektext: Greek input as string
    :return: the input converted to Latin notation
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "text" + str(c) + " " + greektext
    bibref.sendline(command)
    bibref.expect("Stored internally as (\\w+).")
    form = bibref.match.groups()
    return form[0].decode('utf-8')

def latintext_n(c, latintext):
    """
    Stores the Latin input in the selected clipboard.
    :param c: Clipboard number (1 or 2)
    :param greektext: Latin input as string
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "latintext" + str(c) + " " + latintext
    bibref.sendline(command)
    bibref.expect("Stored.")

def lookup_n(c, passage):
    """
    Looks up the passage and stores it in the selected clipboard.
    :param c: Clipboard number (1 or 2)
    :param passage: The passage to look up
    :return: the passage converted to Latin notation
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "lookup" + str(c) + " " + passage
    bibref.sendline(command)
    bibref.expect("Stored internally as (\\w+).")
    form = bibref.match.groups()
    return form[0].decode('utf-8')

def raw_n(c, bible, book, start, length):
    """
    Puts a passage in the given book in the given bible, beginning with the start position
    on length characters, into clipboard c. The whole book can be retrieved with start=1 and length=-1.
    :param c: Clipboard number (1 or 2)
    :param bible: the Bible edition
    :param book: the selected book
    :param start: the first position
    :param length: the length of the selected passage
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "raw" + str(c) + " " + bible + " " + book + " " + str(start) + " " + str(length)
    bibref.sendline(command)
    bibref.expect("Stored.")
    form = bibref.match.groups()

def find_n(c, bible):
    """
    Finds the clipboard text in a Bible edition.
    :param c: Clipboard number (1 or 2)
    :param bible: Bible edition
    :return: list of strings that explain the matches (in bibref format: passage, raw_start, raw_end)
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "find" + str(c) + " " + bible
    bibref.sendline(command)
    ret = []
    finished = False
    # Found in Acts 13:33+88 13:33 (book position 43840-43871)
    # Found in Hebrews 1:5+26 1:5-53 (book position 420-451)
    # Found in Hebrews 5:5+70 5:5 (book position 6271-6302)
    # 3 occurrences.
    while not finished:
        index = bibref.expect([r'Found in (.*?) \(book position ([0-9]+)\-([0-9]+)\)',r'([0-9]+) occurrences.'])
        if index == 0:
            passage, raw1, raw2 = bibref.match.groups()
            ret.append([passage.decode('utf-8'), int(raw1), int(raw2)])
        if index == 1:
            finished = True
    return ret

def jaccard12():
    """
    Computes the Jaccard distance between the two clipboard texts.
    :return: the Jaccard distance as a number between 0 and 1
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "jaccard12"
    bibref.sendline(command)
    bibref.expect("Jaccard distance is ([0-9]+\\.[0-9]+).")
    jaccard12 = bibref.match.groups()
    jaccard = float(jaccard12[0]) * 100
    return jaccard

def jaccard(t1, t2):
    """
    Puts the Greek inputs in the clipboards and compute their Jaccard distance.
    :param t1: the first Greek text
    :param t2: the second Greek text
    :return: the Jaccard distance as a number between 0 and 1
    """
    text_n(1, t1)
    text_n(2, t2)
    return jaccard12()

def latin_to_greek(latin):
    """
    Converts the Latin input into Greek text.
    :param latin: the input as Latin text
    :return: the text in Greek letters
    """
    greek = latin
    greek = greek.replace("a", "α") # Note that the implementation is not very elegant.
    greek = greek.replace("b", "β")
    greek = greek.replace("c", "ψ")
    greek = greek.replace("d", "δ")
    greek = greek.replace("e", "ε")
    greek = greek.replace("f", "φ")
    greek = greek.replace("g", "γ")
    greek = greek.replace("h", "η")
    greek = greek.replace("i", "ι")
    greek = greek.replace("j", "ξ")
    greek = greek.replace("k", "κ")
    greek = greek.replace("l", "λ")
    greek = greek.replace("m", "μ")
    greek = greek.replace("n", "ν")
    greek = greek.replace("o", "ο")
    greek = greek.replace("p", "π")
    greek = greek.replace("q", "ζ")
    greek = greek.replace("r", "ρ")
    greek = greek.replace("s", "σ")
    greek = greek.replace("t", "τ")
    greek = greek.replace("u", "θ")
    greek = greek.replace("v", "ω")
    greek = greek.replace("w", "ς") # unused
    greek = greek.replace("x", "χ")
    greek = greek.replace("y", "υ")
    greek = greek.replace("z", "ζ") # maybe unused
    return greek

def nearest12():
    """
    Computes the nearest substring of clipboard 1 and the text in clipboard2.
    :return: a 2-element list of the minimal Jaccard distance as a number between 0 and 1 and the nearest substring
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout_max
    command = "nearest12"
    bibref.sendline(command)
    bibref.expect("Nearest Jaccard distance is ([0-9]+\\.[0-9]+) with substring (\\w+).")
    nearest12 = bibref.match.groups()
    nearest = float(nearest12[0]) * 100
    nearest_substring = nearest12[1].decode('utf-8')
    return nearest, nearest_substring

def maxresults(m):
    """
    Sets the maximal amount of matches to be found, for the find command.
    :return: the value being actually set
    """
    global bibref
    spawn_bibref()
    bibref.timeout = bibref_default_timeout
    command = "maxresults " + str(m)
    bibref.sendline(command)
    bibref.expect("Set to ([0-9]+).")
    maxresults = bibref.match.groups()
    return int(maxresults[0])

def text1(greektext):
    return text_n(1,greektext)

def text2(greektext):
    return text_n(2,greektext)

def latintext1(latintext):
    return latintext_n(1,latintext)

def latintext2(latintext):
    return latintext_n(2,latintext)

def lookup1(passage):
    return lookup_n(1,passage)

def lookup2(passage):
    return lookup_n(2,passage)

def find1(bible):
    return find_n(1,bible)

def find2(bible):
    return find_n(2,bible)

def raw1(bible,book,start,length):
    return raw_n(1,bible,book,start,length)

def raw2(bible,book,start,length):
    return raw_n(2,bible,book,start,length)
