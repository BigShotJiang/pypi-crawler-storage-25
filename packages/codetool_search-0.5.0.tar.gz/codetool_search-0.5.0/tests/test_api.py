from __future__ import annotations

import json

import pytest

from codetool_search import (
    SearchArgumentError,
    SearchPatternError,
    SearchRootError,
    api,
)
from codetool_search.python_backend import search_python
from codetool_search.roots import normalize_search_roots


def write(path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_default_result_is_compressed_and_smaller_than_full(tmp_path):
    write(tmp_path / "a.py", "needle needle\n")
    write(tmp_path / "b.py", "needle\n")

    compressed = api.search("needle", root=str(tmp_path), backend="python")
    full = api.search(
        "needle", root=str(tmp_path), backend="python", result_format="full"
    )

    assert compressed["format"] == "compressed"
    assert compressed["mode"] == "files"
    assert compressed["backend"] == {"selected": "python"}
    assert compressed["totals"] == {"files": 2, "matches": 2, "count": 3}
    assert compressed["matches"][0].keys() == {"p"}
    assert compressed["matches"][0]["p"] == full["matches"][0]["path"]
    compact_json = json.dumps(compressed, sort_keys=True, separators=(",", ":"))
    full_json = json.dumps(full, sort_keys=True, separators=(",", ":"))
    assert len(compact_json.encode()) < len(full_json.encode())


def test_full_result_format_matches_pre_existing_python_shape(tmp_path):
    write(tmp_path / "a.py", "needle\n")

    result = api.search(
        "needle", root=str(tmp_path), backend="python", result_format="full"
    )

    assert result == search_python("needle", root=str(tmp_path), regex=True)


def test_public_api_treats_patterns_as_regex_by_default(tmp_path):
    write(tmp_path / "a.py", "UserService\nUserRepository\n")

    result = api.search(
        r"User(Service|Repository)", root=str(tmp_path), backend="python"
    )
    literal = api.search(
        r"User(Service|Repository)",
        root=str(tmp_path),
        backend="python",
        regex=False,
    )

    assert result["totals"] == {"files": 1, "matches": 1, "count": 2}
    assert literal["totals"] == {"files": 0, "matches": 0, "count": 0}


def test_public_api_accepts_file_root(tmp_path):
    target = tmp_path / "docs" / "tools.md"
    write(target, "## `search`\n")
    write(tmp_path / "docs" / "other.md", "search\n")

    result = api.search("## `search`", root=str(target), backend="python")

    assert result["totals"] == {"files": 1, "matches": 1, "count": 1}
    assert result["matches"] == [{"p": "tools.md"}]


def test_public_api_accepts_root_list_with_common_relative_paths(tmp_path):
    write(tmp_path / "src" / "agent.py", "search_workspace()\n")
    write(tmp_path / "webapp" / "app.js", "search_workspace();\n")
    write(tmp_path / "tests" / "test_agent.py", "search_workspace()\n")
    write(
        tmp_path / "src" / "pbi_agent" / "web" / "static" / "app" / "bundle.js",
        "search_workspace();\n",
    )

    result = api.search(
        "search_workspace",
        root=[str(tmp_path / "src"), str(tmp_path / "webapp"), str(tmp_path / "tests")],
        regex=False,
        exclude=["src/pbi_agent/web/static/app/**", "node_modules/**"],
        limit=200,
        backend="python",
        result_format="full",
    )

    assert result["root"] == [
        str(tmp_path / "src"),
        str(tmp_path / "webapp"),
        str(tmp_path / "tests"),
    ]
    assert {match["path"] for match in result["matches"]} == {
        "src/agent.py",
        "webapp/app.js",
        "tests/test_agent.py",
    }
    assert result["count"] == 3


def test_public_api_accepts_space_separated_root_string_for_files_and_dirs(
    monkeypatch, tmp_path
):
    write(tmp_path / "docs" / "guide.md", "needle in docs\n")
    write(tmp_path / "README.md", "needle in readme\n")
    write(tmp_path / "src" / "ignored.py", "needle outside requested roots\n")
    monkeypatch.chdir(tmp_path)

    result = api.search(
        "needle",
        root="docs README.md",
        regex=False,
        backend="python",
        result_format="full",
    )

    assert result["root"] == ["docs", "README.md"]
    assert {match["path"] for match in result["matches"]} == {
        "docs/guide.md",
        "README.md",
    }
    assert result["count"] == 2


def test_space_separated_root_string_preserves_existing_path_with_spaces(
    monkeypatch, tmp_path
):
    write(tmp_path / "my docs" / "a.md", "needle in spaced path\n")
    write(tmp_path / "my" / "ignored.md", "needle in split-looking path\n")
    write(tmp_path / "docs" / "ignored.md", "needle in split-looking path\n")
    monkeypatch.chdir(tmp_path)

    result = api.search(
        "needle",
        root="my docs",
        regex=False,
        backend="python",
        result_format="full",
    )

    assert result["root"] == "my docs"
    assert result["matches"] == [
        {"path": "a.md", "count": 1, "first_line": 1}
    ]


def test_search_target_path_matches_file_names_without_reading_contents(tmp_path):
    write(tmp_path / "src" / "auth_service.py", "no content hit\n")
    write(tmp_path / "src" / "users.py", "auth_service appears in content only\n")

    result = api.search(
        "auth",
        root=str(tmp_path),
        target="path",
        regex=False,
        backend="python",
        result_format="full",
    )

    assert result["target"] == "path"
    assert result["path_scope"] == "path"
    assert result["scanned_files"] == 2
    assert result["scanned_bytes"] == 0
    assert result["path_matches"] == 1
    assert result["count"] == 1
    assert result["matches"] == [
        {"path": "src/auth_service.py", "kind": "file", "match_kind": "path"}
    ]


def test_search_target_both_merges_path_and_content_matches(tmp_path):
    write(tmp_path / "src" / "auth.py", "no content hit\n")
    write(tmp_path / "src" / "users.py", "auth appears in content\n")
    write(tmp_path / "src" / "auth_model.py", "auth appears in content too\n")

    result = api.search(
        "auth",
        root=str(tmp_path),
        target="both",
        regex=False,
        backend="python",
        result_format="full",
    )

    by_path = {match["path"]: match for match in result["matches"]}
    assert by_path["src/auth.py"]["match_kind"] == "path"
    assert by_path["src/users.py"]["match_kind"] == "content"
    assert by_path["src/auth_model.py"]["match_kind"] == "both"
    assert result["path_matches"] == 2
    assert result["content_files"] == 2
    assert result["content_count"] == 2
    assert result["count"] == 3


def test_search_target_both_supports_snippets_with_path_only_rows(tmp_path):
    write(tmp_path / "src" / "auth.py", "no content hit\n")
    write(tmp_path / "src" / "users.py", "auth appears in content\n")

    result = api.search(
        "auth",
        root=str(tmp_path),
        target="both",
        regex=False,
        backend="python",
        mode="snippets",
    )

    by_path = {match["p"]: match for match in result["matches"]}
    assert result["mode"] == "snippets"
    assert result["target"] == "both"
    assert by_path["src/auth.py"] == {"p": "src/auth.py", "m": "path"}
    assert by_path["src/users.py"]["s"] == "auth appears in content"
    assert by_path["src/users.py"]["m"] == "content"
    assert result["totals"]["path"] == 1
    assert result["totals"]["content_files"] == 1
    assert result["totals"]["content_count"] == 1


def test_search_path_target_is_the_file_finder_surface(tmp_path):
    write(tmp_path / "src" / "auth_service.py", "")
    write(tmp_path / "tests" / "test_auth.py", "")
    write(tmp_path / "src" / "users.py", "")

    result = api.search(
        "auth",
        root=str(tmp_path),
        target="path",
        regex=False,
        backend="python",
    )

    assert result["target"] == "path"
    assert result["totals"]["path"] == 2
    assert [match["p"] for match in result["matches"]] == [
        "src/auth_service.py",
        "tests/test_auth.py",
    ]


def test_compressed_snippets_preserve_line_snippet_context_and_page(tmp_path):
    write(tmp_path / "a.py", "before\nneedle one\nneedle two\n")

    result = api.search(
        "needle",
        root=str(tmp_path),
        backend="python",
        mode="snippets",
        context_lines=1,
        limit=1,
    )

    assert result["totals"]["count"] == 2
    assert result["totals"]["matches"] == 2
    assert result["matches"] == [
        {
            "p": "a.py",
            "l": 2,
            "s": "needle one",
            "ctx": [
                {"line": 1, "text": "before"},
                {"line": 2, "text": "needle one"},
                {"line": 3, "text": "needle two"},
            ],
        }
    ]
    assert result["page"]["truncated"] is True
    assert result["page"]["next_cursor"] == "1"
    assert result["page"]["next_request"]["cursor"] == "1"


def test_compressed_count_mode_preserves_per_file_and_total_counts(tmp_path):
    write(tmp_path / "a.py", "needle needle\n")

    result = api.search(
        "needle", root=str(tmp_path), backend="python", mode="count"
    )

    assert result["mode"] == "count"
    assert result["totals"]["count"] == 2
    assert result["matches"] == [{"p": "a.py", "l": 1, "c": 2}]


def test_text_result_format_groups_common_path_and_paginates(tmp_path):
    write(tmp_path / "src" / "common" / "deep" / "a.py", "needle needle\n")
    write(tmp_path / "src" / "common" / "deep" / "b.py", "needle\n")

    result = api.search(
        "needle",
        root=str(tmp_path),
        regex=False,
        backend="python",
        result_format="text",
        limit=1,
    )

    assert isinstance(result, str)
    assert result.startswith("-- more: cursor=1\n")
    assert "src/" in result
    assert "common/" in result
    assert "deep/" in result
    assert ".py" in result
    assert ":1" not in result
    assert "next_cursor" not in result


def test_text_result_format_no_match_is_warning(tmp_path):
    write(tmp_path / "a.py", "needle\n")

    result = api.search(
        "missing",
        root=str(tmp_path),
        regex=False,
        backend="python",
        result_format="raw",
    )

    assert result == "No Match"


def test_text_result_format_count_mode_preserves_counts(tmp_path):
    write(tmp_path / "pkg" / "a.py", "needle needle\n")
    write(tmp_path / "pkg" / "b.py", "needle\n")

    result = api.search(
        "needle",
        root=str(tmp_path),
        regex=False,
        backend="python",
        mode="count",
        result_format="text",
        limit=10,
    )

    assert isinstance(result, str)
    assert "pkg/" in result
    assert "a.py x2" in result
    assert "b.py x1" in result


def test_text_result_format_snippets_merges_context_by_file(tmp_path):
    write(tmp_path / "src" / "a.py", "before\nneedle one\nneedle two\nafter\n")

    result = api.search(
        "needle",
        root=str(tmp_path),
        regex=False,
        backend="python",
        mode="snippets",
        context_lines=1,
        limit=10,
        result_format="text",
    )

    assert result == "\n".join(
        [
            "src/",
            " a.py",
            "  before",
            "  2:needle one",
            "  3:needle two",
            "  after",
        ]
    )


def test_text_result_format_both_snippets_renders_path_only_rows(tmp_path):
    write(tmp_path / "src" / "auth.py", "no content hit\n")

    result = api.search(
        "auth",
        root=str(tmp_path),
        target="both",
        regex=False,
        backend="python",
        mode="snippets",
        result_format="text",
    )

    assert result == "src/auth.py"
    assert ":0:" not in result


def test_text_result_format_regex_crop_keeps_actual_match_visible(tmp_path):
    write(tmp_path / "a.py", f"{'x' * 100} UserService trailing\n")

    result = api.search(
        r"User(Service|Repository)",
        root=str(tmp_path),
        backend="python",
        mode="snippets",
        result_format="text",
    )

    assert isinstance(result, str)
    assert "UserService" in result
    assert "User(Service|Repository)" not in result


def test_auto_falls_back_to_python_when_rust_missing(monkeypatch, tmp_path):
    (tmp_path / "a.py").write_text("needle\n", encoding="utf-8")
    monkeypatch.setattr(api, "find_rust_binary", lambda: None)

    result = api.search("needle", root=str(tmp_path), backend="auto")

    assert result["backend"]["selected"] == "python"
    assert result["backend"]["requested"] == "auto"
    assert "Rust backend unavailable" in result["backend"]["fallback"]


def test_auto_uses_rust_for_default_regex_when_available(monkeypatch, tmp_path):
    monkeypatch.setattr(api, "find_rust_binary", lambda: "/fake/rust")

    def fake_rust(pattern, **kwargs):
        assert pattern == r"User(Service)?"
        assert kwargs["regex"] is True
        assert kwargs["binary"] == "/fake/rust"
        return {
            "pattern": pattern,
            "backend": "rust",
            "root": kwargs["root"],
            "regex": True,
            "mode": kwargs["mode"],
            "matches": [{"path": "a.py", "count": 1, "first_line": 1}],
            "returned": 1,
            "total_files": 1,
            "total_matches": 1,
            "count": 1,
            "truncated": False,
            "next_cursor": None,
            "offset": 0,
            "limit": kwargs["limit"],
        }

    monkeypatch.setattr(api, "search_rust", fake_rust)

    result = api.search(r"User(Service)?", root=str(tmp_path))

    assert result["backend"] == {"selected": "rust", "requested": "auto"}
    assert result["matches"][0]["p"] == "a.py"


def test_auto_regex_empty_match_uses_python_for_counts(monkeypatch, tmp_path):
    write(tmp_path / "a.py", "abc\n")
    monkeypatch.setattr(api, "find_rust_binary", lambda: "/fake/rust")

    def fail_rust(*args, **kwargs):
        pytest.fail("empty-match regex should skip Rust in auto mode")

    monkeypatch.setattr(api, "search_rust", fail_rust)

    result = api.search(
        "a*",
        root=str(tmp_path),
        regex=True,
        mode="count",
        result_format="full",
    )

    assert result["backend"] == "python"
    assert result["backend_requested"] == "auto"
    assert "empty spans" in result["backend_fallback"]
    assert result["count"] == 4
    assert result["matches"] == [{"path": "a.py", "count": 4, "first_line": 1}]


def test_auto_regex_falls_back_to_python_when_rust_rejects_syntax(
    monkeypatch, tmp_path
):
    (tmp_path / "a.py").write_text("UserService\n", encoding="utf-8")
    monkeypatch.setattr(api, "find_rust_binary", lambda: "/fake/rust")
    monkeypatch.setattr(
        api,
        "search_rust",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            RuntimeError("invalid regex: look-around is not supported")
        ),
    )

    result = api.search(r"(?<=User)Service", root=str(tmp_path), regex=True)

    assert result["backend"]["selected"] == "python"
    assert result["backend"]["requested"] == "auto"
    assert "look-around" in result["backend"]["fallback"]
    assert result["matches"] == [{"p": "a.py"}]


def test_auto_fallback_reuses_one_shot_root_iterable(monkeypatch, tmp_path):
    (tmp_path / "a.py").write_text("UserService\n", encoding="utf-8")
    monkeypatch.setattr(api, "find_rust_binary", lambda: "/fake/rust")

    def rejecting_rust(*args, **kwargs):
        normalize_search_roots(kwargs["root"])
        raise RuntimeError("invalid regex: look-around is not supported")

    monkeypatch.setattr(api, "search_rust", rejecting_rust)
    roots = (root for root in [str(tmp_path)])

    result = api.search(
        r"(?<=User)Service",
        root=roots,
        regex=True,
        backend="auto",
        result_format="full",
    )

    assert result["backend"] == "python"
    assert result["backend_requested"] == "auto"
    assert result["matches"] == [{"path": "a.py", "count": 1, "first_line": 1}]


def test_explicit_rust_dispatches_to_wrapper(monkeypatch, tmp_path):
    def fake_rust(pattern, **kwargs):
        return {
            "pattern": pattern,
            "backend": "rust",
            "root": kwargs["root"],
            "mode": kwargs["mode"],
            "matches": [],
        }

    monkeypatch.setattr(api, "search_rust", fake_rust)

    result = api.search("needle", root=str(tmp_path), mode="count", backend="rust")

    assert result == {
        "mode": "count",
        "format": "compressed",
        "backend": {"selected": "rust"},
        "totals": {"files": 0, "matches": 0, "count": 0},
        "page": {
            "returned": 0,
            "limit": None,
            "offset": None,
            "truncated": False,
            "next_cursor": None,
        },
        "matches": [],
    }


def test_explicit_rust_full_format_returns_wrapper_shape(monkeypatch, tmp_path):
    old_shape = {
        "pattern": "needle",
        "backend": "rust",
        "root": str(tmp_path),
        "mode": "count",
        "matches": [],
    }

    monkeypatch.setattr(api, "search_rust", lambda *args, **kwargs: old_shape)

    result = api.search(
        "needle",
        root=str(tmp_path),
        mode="count",
        backend="rust",
        result_format="full",
    )

    assert result is old_shape


def test_auto_rust_path_is_compressed_with_requested_backend(monkeypatch, tmp_path):
    monkeypatch.setattr(api, "find_rust_binary", lambda: "/fake/rust")

    def fake_rust(pattern, **kwargs):
        assert kwargs["binary"] == "/fake/rust"
        return {
            "pattern": pattern,
            "backend": "rust",
            "root": kwargs["root"],
            "mode": kwargs["mode"],
            "matches": [{"path": "a.py", "count": 1, "first_line": 1}],
            "returned": 1,
            "total_files": 1,
            "total_matches": 1,
            "count": 1,
            "truncated": False,
            "next_cursor": None,
            "offset": 0,
            "limit": kwargs["limit"],
        }

    monkeypatch.setattr(api, "search_rust", fake_rust)

    result = api.search("needle", root=str(tmp_path), backend="auto")

    assert result["backend"] == {"selected": "rust", "requested": "auto"}
    assert result["matches"] == [{"p": "a.py"}]


def test_invalid_backend_is_rejected():
    with pytest.raises(SearchArgumentError, match="backend"):
        api.search("needle", backend="unknown")


def test_invalid_result_format_is_rejected(tmp_path):
    write(tmp_path / "a.py", "needle\n")

    with pytest.raises(SearchArgumentError, match="result_format"):
        api.search("needle", root=str(tmp_path), result_format="verbose")


def test_invalid_regex_raises_pattern_error(tmp_path):
    write(tmp_path / "a.py", "needle\n")

    with pytest.raises(SearchPatternError, match="invalid regex"):
        api.search("[", root=str(tmp_path), backend="python")


def test_missing_root_raises_root_error(tmp_path):
    with pytest.raises(SearchRootError, match="root does not exist"):
        api.search("needle", root=str(tmp_path / "missing"), backend="python")
