from __future__ import annotations

from codetool_search.ranking import (
    definition_bonus,
    file_sort_key,
    is_generated_path,
    is_source_path,
    is_test_path,
    path_relevance,
    query_mentions_tests,
    snippet_sort_key,
)


def test_path_classification_helpers():
    assert is_source_path("src/app.py")
    assert is_generated_path("src/generated/client.py")
    assert is_generated_path("web/app.min.js")
    assert is_test_path("tests/test_app.py")
    assert not is_test_path("src/app.py")


def test_path_relevance_prioritises_basename_and_directory_matches():
    assert path_relevance("src/auth.py", "auth") < path_relevance(
        "src/other.py", "auth"
    )
    assert path_relevance("src/auth/service.py", "auth") < path_relevance(
        "docs/readme.md", "auth"
    )


def test_path_relevance_matches_identifier_variants_and_regex_terms():
    assert path_relevance("src/user_service.py", "UserService") == 0
    assert path_relevance("src/search-text.ts", "searchText") == 0
    assert path_relevance("src/user_service.py", "User(Service|Repo)") < 50
    assert path_relevance("src/user_service.py", r"\bUserService\b") < path_relevance(
        "src/other.py", r"\bUserService\b"
    )
    assert path_relevance("src/user_service.py", "User(Service|Repo)") < path_relevance(
        "src/other.py", "User(Service|Repo)"
    )


def test_query_mentions_tests_uses_intent_tokens_not_substrings():
    assert query_mentions_tests("test login")
    assert query_mentions_tests("pytest fixture")
    assert query_mentions_tests("UserSpec")
    assert query_mentions_tests(r"\btest\b")
    assert not query_mentions_tests("special")
    assert not query_mentions_tests("contest")
    assert not query_mentions_tests("latest")
    assert not query_mentions_tests("specification")
    assert not query_mentions_tests(r"\bspecial\b")


def test_file_sort_key_prefers_source_before_tests_and_generated_paths():
    rows = [
        {"path": "tests/test_service.py", "count": 1, "first_line": 1},
        {"path": "src/generated/service.py", "count": 1, "first_line": 1},
        {"path": "src/service.py", "count": 1, "first_line": 1},
    ]

    rows.sort(key=lambda row: file_sort_key(row, "service"))

    assert [row["path"] for row in rows] == [
        "src/service.py",
        "tests/test_service.py",
        "src/generated/service.py",
    ]


def test_file_sort_key_does_not_treat_special_as_test_intent():
    rows = [
        {"path": "tests/test_special.py", "count": 1, "first_line": 1},
        {"path": "src/special.py", "count": 1, "first_line": 1},
    ]

    rows.sort(key=lambda row: file_sort_key(row, "special"))

    assert [row["path"] for row in rows] == [
        "src/special.py",
        "tests/test_special.py",
    ]


def test_snippet_sort_key_prefers_definition_like_lines():
    rows = [
        {"path": "src/service.py", "line": 20, "snippet": "value = UserService()"},
        {"path": "src/service.py", "line": 5, "snippet": "class UserService:"},
    ]

    rows.sort(key=lambda row: snippet_sort_key(row, "UserService"))

    assert rows[0]["snippet"] == "class UserService:"
    assert definition_bonus("def UserService():") < 0


def test_definition_bonus_covers_common_declaration_forms():
    assert definition_bonus("pub struct Config {") < 0
    assert definition_bonus("pub async fn run() {") < 0
    assert definition_bonus("export class UserService {") < 0
    assert definition_bonus("export const handler = () => {}") < 0


def test_snippet_sort_key_prefers_rust_definition_over_usage():
    rows = [
        {
            "path": "src/config.rs",
            "line": 5,
            "snippet": "Config::default();",
        },
        {"path": "src/config.rs", "line": 20, "snippet": "pub struct Config {"},
    ]

    assert definition_bonus("Config::default();") == 0
    rows.sort(key=lambda row: snippet_sort_key(row, "Config"))

    assert rows[0]["snippet"] == "pub struct Config {"
