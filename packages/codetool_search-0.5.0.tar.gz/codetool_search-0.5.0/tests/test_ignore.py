from __future__ import annotations

from codetool_search.ignore import (
    is_common_ignored_dir,
    load_ignore_patterns,
    matches_glob,
    normalize_patterns,
    normalize_relpath,
    path_matches_pattern,
    should_ignore_path,
)


def test_normalize_relpath_and_patterns():
    assert normalize_relpath("./src\\pkg/file.py") == "src/pkg/file.py"
    assert normalize_patterns("*.py") == ("*.py",)
    assert normalize_patterns(["*.py", "", None, " src/** "]) == ("*.py", "src/**")


def test_common_ignores_and_exclude_patterns():
    assert is_common_ignored_dir("node_modules")
    assert should_ignore_path("node_modules/pkg/index.js", is_dir=True)
    assert should_ignore_path(
        "src/generated.py", is_dir=False, exclude_patterns=("generated.py",)
    )
    assert not should_ignore_path("src/app.py", is_dir=False)


def test_glob_and_path_patterns_match_basename_segments_and_prefixes():
    assert matches_glob("src/app/service.py", ("*.py",))
    assert matches_glob("src/app/service.py", ("src/**",))
    assert path_matches_pattern("src/vendor/file.py", "vendor")
    assert path_matches_pattern("src/generated/file.py", "src/generated/**")
    assert not matches_glob("src/app/service.py", ("*.rs",))


def test_load_ignore_patterns_supports_root_ignore_files(tmp_path):
    (tmp_path / ".gitignore").write_text(
        "# comment\nignored_dir/\n*.tmp\n!keep.tmp\n", encoding="utf-8"
    )

    patterns = load_ignore_patterns(str(tmp_path))

    assert "ignored_dir" in patterns
    assert "ignored_dir/**" in patterns
    assert "*.tmp" in patterns
    assert "!keep.tmp" not in patterns
