from __future__ import annotations

import json

from codetool_search import cli


def write(path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_cli_raw_text_no_match_prints_warning(tmp_path, capsys):
    write(tmp_path / "a.py", "needle\n")

    code = cli.main(
        [
            "missing",
            str(tmp_path),
            "--literal",
            "--backend",
            "python",
            "--format",
            "text",
        ]
    )

    assert code == 0
    assert capsys.readouterr().out == "No Match\n"


def test_cli_raw_text_snippets_mode(tmp_path, capsys):
    write(tmp_path / "src" / "a.py", "before\nneedle\n")

    code = cli.main(
        [
            "needle",
            str(tmp_path),
            "--literal",
            "--backend",
            "python",
            "--mode",
            "snippets",
            "--raw",
        ]
    )

    assert code == 0
    assert capsys.readouterr().out == "src/a.py:2:needle\n"


def test_cli_raw_text_count_mode(tmp_path, capsys):
    write(tmp_path / "src" / "a.py", "needle needle\n")

    code = cli.main(
        [
            "--pattern",
            "needle",
            "--root",
            str(tmp_path),
            "--literal",
            "--backend",
            "python",
            "--mode",
            "count",
            "--format",
            "raw",
        ]
    )

    assert code == 0
    assert capsys.readouterr().out == "src/a.py x2\n"


def test_cli_pattern_flag_treats_single_positional_as_root(tmp_path, capsys):
    root = tmp_path / "root"
    write(root / "src" / "a.py", "needle\n")

    code = cli.main(
        [
            "--pattern",
            "needle",
            str(root),
            "--literal",
            "--backend",
            "python",
            "--raw",
        ]
    )

    assert code == 0
    assert capsys.readouterr().out == "src/a.py\n"


def test_cli_repeated_root_searches_multiple_roots(tmp_path, capsys):
    write(tmp_path / "src" / "a.py", "needle\n")
    write(tmp_path / "tests" / "test_a.py", "needle\n")
    write(tmp_path / "docs" / "a.md", "needle\n")

    code = cli.main(
        [
            "needle",
            "--root",
            str(tmp_path / "src"),
            "--root",
            str(tmp_path / "tests"),
            "--literal",
            "--backend",
            "python",
        ]
    )

    assert code == 0
    result = json.loads(capsys.readouterr().out)
    assert {match["p"] for match in result["matches"]} == {
        "src/a.py",
        "tests/test_a.py",
    }


def test_cli_single_root_flag_preserves_scalar_root_metadata(tmp_path, capsys):
    write(tmp_path / "a.py", "needle\n")
    write(tmp_path / "b.py", "needle\n")

    code = cli.main(
        [
            "needle",
            "--root",
            str(tmp_path),
            "--literal",
            "--backend",
            "python",
            "--format",
            "full",
        ]
    )

    assert code == 0
    full_result = json.loads(capsys.readouterr().out)
    assert full_result["root"] == str(tmp_path)

    code = cli.main(
        [
            "needle",
            "--root",
            str(tmp_path),
            "--literal",
            "--backend",
            "python",
            "--limit",
            "1",
        ]
    )

    assert code == 0
    compressed_result = json.loads(capsys.readouterr().out)
    assert compressed_result["page"]["next_request"]["root"] == str(tmp_path)


def test_cli_default_prints_compact_json(tmp_path, capsys):
    write(tmp_path / "a.py", "needle\n")

    code = cli.main(["needle", str(tmp_path), "--literal", "--backend", "python"])

    assert code == 0
    result = json.loads(capsys.readouterr().out)
    assert result["format"] == "compressed"
    assert result["matches"] == [{"p": "a.py"}]


def test_cli_can_search_paths(tmp_path, capsys):
    write(tmp_path / "src" / "auth.py", "")
    write(tmp_path / "src" / "users.py", "auth\n")

    code = cli.main(
        [
            "auth",
            str(tmp_path),
            "--target",
            "path",
            "--literal",
            "--backend",
            "python",
        ]
    )

    assert code == 0
    result = json.loads(capsys.readouterr().out)
    assert result["target"] == "path"
    assert result["matches"] == [{"p": "src/auth.py", "m": "path"}]


def test_cli_search_errors_are_clean(tmp_path, capsys):
    write(tmp_path / "a.py", "needle\n")

    code = cli.main(["[", str(tmp_path), "--backend", "python"])

    captured = capsys.readouterr()
    assert code == 2
    assert captured.out == ""
    assert captured.err.startswith("codetool-search: invalid regex:")