from __future__ import annotations

import os
import zipfile

from codetool_search import rust_backend


def test_packaged_binary_names_prefer_stable_runtime_key(monkeypatch):
    monkeypatch.setenv("CODETOOL_SEARCH_TARGET_RUNTIME", "linux-x86_64")
    names = rust_backend.packaged_binary_names()

    assert names[0] == "codetool-search-rust-linux-x86_64"
    assert "codetool-search-rust" in names


def test_runtime_key_normalizes_backward_compatible_aliases():
    assert rust_backend.normalize_runtime_key("linux-arm64") == "linux-aarch64"
    assert rust_backend.normalize_runtime_key("darwin-aarch64") == "macos-arm64"
    assert rust_backend.normalize_runtime_key("win-amd64") == "windows-x86_64"


def test_target_runtime_env_specific_overrides_generic(monkeypatch):
    monkeypatch.setenv("CODETOOL_TARGET_RUNTIME", "linux-aarch64")
    monkeypatch.setenv("CODETOOL_SEARCH_TARGET_RUNTIME", "macos-arm64")

    assert rust_backend._platform_tag() == "macos-arm64"
    assert (
        rust_backend.packaged_binary_names()[0]
        == "codetool-search-rust-macos-arm64"
    )


def test_target_runtime_env_generic_is_supported(monkeypatch):
    monkeypatch.delenv("CODETOOL_SEARCH_TARGET_RUNTIME", raising=False)
    monkeypatch.setenv("CODETOOL_TARGET_RUNTIME", "windows-arm64")

    assert rust_backend._platform_tag() == "windows-arm64"
    assert (
        "codetool-search-rust-windows-arm64"
        in rust_backend.packaged_binary_names()
    )
    assert (
        "codetool-search-rust-windows-aarch64"
        in rust_backend.packaged_binary_names()
    )


def test_find_rust_binary_discovers_packaged_platform_binary(monkeypatch, tmp_path):
    package_dir = tmp_path / "codetool_search"
    bin_dir = package_dir / "_bin"
    bin_dir.mkdir(parents=True)
    monkeypatch.setenv("CODETOOL_SEARCH_TARGET_RUNTIME", "linux-x86_64")
    binary_name = rust_backend.packaged_binary_names()[0]
    binary = bin_dir / binary_name
    binary.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
    binary.chmod(0o755)

    monkeypatch.delenv(rust_backend.ENV_BINARY, raising=False)
    monkeypatch.setattr(rust_backend, "__file__", str(package_dir / "rust_backend.py"))
    monkeypatch.setattr(
        rust_backend, "_is_executable_file", lambda path: path.is_file()
    )
    monkeypatch.setattr(rust_backend.shutil, "which", lambda name: None)

    assert rust_backend.find_rust_binary() == os.fspath(binary)


def test_find_rust_binary_discovers_windows_target_exe_on_non_windows(
    monkeypatch, tmp_path
):
    package_dir = tmp_path / "codetool_search"
    bin_dir = package_dir / "_bin"
    bin_dir.mkdir(parents=True)
    monkeypatch.setenv("CODETOOL_SEARCH_TARGET_RUNTIME", "windows-arm64")
    binary = bin_dir / "codetool-search-rust-windows-arm64.exe"
    binary.write_text("MZ", encoding="utf-8")
    binary.chmod(0o755)

    monkeypatch.delenv(rust_backend.ENV_BINARY, raising=False)
    monkeypatch.setattr(rust_backend, "__file__", str(package_dir / "rust_backend.py"))
    monkeypatch.setattr(
        rust_backend, "_is_executable_file", lambda path: path.is_file()
    )
    monkeypatch.setattr(rust_backend.shutil, "which", lambda name: None)

    assert rust_backend.find_rust_binary() == os.fspath(binary)


def test_built_wheel_contains_only_target_packaged_binary_when_staged():
    dist = os.path.join(os.getcwd(), "dist")
    if not os.path.isdir(dist):
        return

    wheels = [
        os.path.join(dist, name) for name in os.listdir(dist) if name.endswith(".whl")
    ]
    if not wheels:
        return

    with zipfile.ZipFile(sorted(wheels)[-1]) as wheel:
        names = wheel.namelist()

    if not any(name.startswith("codetool_search/") for name in names):
        return

    binaries = [
        name
        for name in names
        if name.startswith("codetool_search/_bin/codetool-search-rust-")
    ]
    assert len(binaries) == 1
