from __future__ import annotations

import pytest

from codetool_search.cursor import (
    decode_cursor,
    encode_cursor,
    normalize_limit,
    page_items,
)


def test_normalize_limit_defaults_caps_and_rejects_invalid_values():
    assert normalize_limit(None) == 50
    assert normalize_limit(2) == 2
    assert normalize_limit(10_000) == 1_000
    with pytest.raises(ValueError):
        normalize_limit(0)
    with pytest.raises(ValueError):
        normalize_limit("not-an-int")


def test_cursor_roundtrip_and_invalid_cursor_resets_to_zero():
    assert encode_cursor(12) == "12"
    assert decode_cursor("12") == 12
    assert decode_cursor("-5") == 0
    assert decode_cursor("bad") == 0
    assert decode_cursor(None) == 0


def test_page_items_returns_page_truncation_and_next_cursor():
    page, truncated, next_cursor, offset = page_items(["a", "b", "c"], limit=2)
    assert page == ["a", "b"]
    assert truncated is True
    assert next_cursor == "2"
    assert offset == 0

    page, truncated, next_cursor, offset = page_items(
        ["a", "b", "c"], limit=2, cursor=next_cursor
    )
    assert page == ["c"]
    assert truncated is False
    assert next_cursor is None
    assert offset == 2
