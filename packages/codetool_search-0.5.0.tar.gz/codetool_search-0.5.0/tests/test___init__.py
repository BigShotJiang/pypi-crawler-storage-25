from __future__ import annotations


def test_public_import_exports_search(tmp_path):
    from codetool_search import SearchError, __all__, search

    (tmp_path / "example.py").write_text("needle\n", encoding="utf-8")

    assert __all__ == [
        "search",
        "SearchArgumentError",
        "SearchBackendError",
        "SearchError",
        "SearchPatternError",
        "SearchRootError",
    ]
    assert issubclass(SearchError, Exception)
    result = search("needle", root=str(tmp_path), backend="python")
    assert result["backend"] == {"selected": "python"}
    assert result["matches"][0]["p"] == "example.py"
    assert search("example", root=str(tmp_path), target="path", backend="python")[
        "matches"
    ][0]["p"] == "example.py"
