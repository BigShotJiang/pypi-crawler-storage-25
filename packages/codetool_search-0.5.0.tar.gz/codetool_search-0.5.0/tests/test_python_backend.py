from __future__ import annotations

import os

from codetool_search import python_backend
from codetool_search.python_backend import iter_candidate_files, search_python


def write(path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_literal_files_mode_uses_relative_paths_common_ignores_and_counts(tmp_path):
    write(
        tmp_path / "src" / "service.py",
        "class UserService:\n    pass\ndef build():\n    return UserService()\n",
    )
    write(
        tmp_path / "tests" / "test_service.py", "from src.service import UserService\n"
    )
    write(tmp_path / "node_modules" / "pkg" / "ignored.py", "UserService\n")

    result = search_python("UserService", root=str(tmp_path), mode="files")

    assert result["backend"] == "python"
    assert result["count"] == 3
    assert result["total_files"] == 2
    assert [match["path"] for match in result["matches"]] == [
        "src/service.py",
        "tests/test_service.py",
    ]
    assert result["matches"][0]["count"] == 2
    assert all(not os.path.isabs(match["path"]) for match in result["matches"])


def test_smart_case_lowercase_pattern_is_case_insensitive(tmp_path):
    write(tmp_path / "src" / "service.py", "class UserService:\n    pass\n")

    result = search_python("userservice", root=str(tmp_path), case="smart")

    assert result["effective_case"] == "insensitive"
    assert result["matches"][0]["path"] == "src/service.py"


def test_smart_case_uppercase_pattern_is_case_sensitive(tmp_path):
    write(tmp_path / "src" / "service.py", "userservice\nUserService\n")

    result = search_python("UserService", root=str(tmp_path), case="smart")

    assert result["effective_case"] == "sensitive"
    assert result["matches"][0]["count"] == 1


def test_regex_mode_only_when_requested(tmp_path):
    write(tmp_path / "src" / "service.py", "UserService\nUserRepository\n")

    literal = search_python(
        r"User(Service|Repository)", root=str(tmp_path), regex=False
    )
    regex = search_python(
        r"User(Service|Repository)", root=str(tmp_path), regex=True
    )

    assert literal["matches"] == []
    assert regex["matches"][0]["count"] == 2


def test_snippets_mode_includes_context_and_limits_per_file(tmp_path):
    write(
        tmp_path / "src" / "service.py",
        "before\n"
        "UserService one\n"
        "middle\n"
        "UserService two\n"
        "UserService three\n"
        "UserService four\n",
    )

    result = search_python(
        "UserService",
        root=str(tmp_path),
        mode="snippets",
        context_lines=1,
        limit=10,
    )

    assert result["count"] == 4
    assert result["total_matches"] == 3
    assert len(result["matches"]) == 3
    assert result["matches"][0]["line"] == 2
    assert result["matches"][0]["context"][0] == {"line": 1, "text": "before"}


def test_glob_and_exclude_filter_candidates(tmp_path):
    write(tmp_path / "src" / "service.py", "Needle\n")
    write(tmp_path / "src" / "service.txt", "Needle\n")
    write(tmp_path / "tests" / "test_service.py", "Needle\n")

    result = search_python(
        "Needle",
        root=str(tmp_path),
        glob="*.py",
        exclude="tests/**",
    )

    assert [match["path"] for match in result["matches"]] == ["src/service.py"]
    assert result["glob"] == ["*.py"]
    assert result["exclude"] == ["tests/**"]


def test_binary_and_huge_files_are_skipped(monkeypatch, tmp_path):
    monkeypatch.setattr(python_backend, "MAX_FILE_BYTES", 16)
    (tmp_path / "binary.bin").write_bytes(b"abc\x00Needle")
    (tmp_path / "huge.txt").write_text("Needle " * 20, encoding="utf-8")
    write(tmp_path / "small.txt", "Needle\n")

    result = search_python("Needle", root=str(tmp_path))

    assert [match["path"] for match in result["matches"]] == ["small.txt"]
    assert result["skipped"]["binary"] == 1
    assert result["skipped"]["huge"] == 1


def test_cursor_paginates_ranked_results(tmp_path):
    for index in range(3):
        write(tmp_path / "src" / f"service_{index}.py", "Needle\n")

    first = search_python("Needle", root=str(tmp_path), limit=1)
    second = search_python(
        "Needle", root=str(tmp_path), limit=1, cursor=first["next_cursor"]
    )

    assert first["truncated"] is True
    assert first["next_cursor"] == "1"
    assert first["matches"][0]["path"] != second["matches"][0]["path"]
    assert second["offset"] == 1


def test_count_mode_returns_per_file_rows_and_total_count(tmp_path):
    write(tmp_path / "a.py", "Needle Needle\n")
    write(tmp_path / "b.py", "Needle\n")

    result = search_python("Needle", root=str(tmp_path), mode="count")

    assert result["count"] == 3
    assert {match["path"]: match["count"] for match in result["matches"]} == {
        "a.py": 2,
        "b.py": 1,
    }


def test_file_root_searches_only_that_file_relative_to_parent(tmp_path):
    target = tmp_path / "docs" / "tools.md"
    write(target, "## `search`\nsearch again\n")
    write(tmp_path / "docs" / "other.md", "search should not be scanned\n")

    result = search_python("search", root=str(target), mode="files")

    assert result["root"] == str(target)
    assert result["scanned_files"] == 1
    assert result["count"] == 2
    assert result["matches"] == [
        {"path": "tools.md", "count": 2, "first_line": 1}
    ]


def test_root_list_preserves_sibling_prefixes_and_global_pagination(tmp_path):
    write(tmp_path / "src" / "a.py", "Needle\n")
    write(tmp_path / "tests" / "test_a.py", "Needle\n")

    first = search_python(
        "Needle",
        root=[str(tmp_path / "src"), str(tmp_path / "tests")],
        limit=1,
    )
    second = search_python(
        "Needle",
        root=[str(tmp_path / "src"), str(tmp_path / "tests")],
        limit=1,
        cursor=first["next_cursor"],
    )

    assert first["root"] == [str(tmp_path / "src"), str(tmp_path / "tests")]
    assert first["total_files"] == 2
    assert first["matches"][0]["path"] != second["matches"][0]["path"]
    assert {first["matches"][0]["path"], second["matches"][0]["path"]} == {
        "src/a.py",
        "tests/test_a.py",
    }


def test_root_list_searches_explicit_root_named_like_common_ignore(tmp_path):
    write(tmp_path / ".gitignore", "build/\n")
    write(tmp_path / "src" / "a.py", "Needle\n")
    write(tmp_path / "build" / "sub" / "generated.py", "Needle\n")
    write(tmp_path / "build" / "node_modules" / "pkg.py", "Needle\n")

    result = search_python(
        "Needle",
        root=[str(tmp_path / "src"), str(tmp_path / "build")],
        mode="files",
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/a.py",
        "build/sub/generated.py",
    }
    assert result["total_files"] == 2


def test_root_list_preserves_root_local_bare_ignore_patterns(tmp_path):
    write(tmp_path / "src" / ".gitignore", "generated.py\n")
    write(tmp_path / "src" / "keep.py", "Needle\n")
    write(tmp_path / "src" / "sub" / "generated.py", "Needle\n")
    write(tmp_path / "tests" / "test_keep.py", "Needle\n")

    result = search_python(
        "Needle",
        root=[str(tmp_path / "src"), str(tmp_path / "tests")],
        mode="files",
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/keep.py",
        "tests/test_keep.py",
    }
    assert result["total_files"] == 2


def test_root_list_preserves_explicit_root_ignored_by_wildcard_child_pattern(
    tmp_path,
):
    write(tmp_path / ".gitignore", "build/*\n")
    write(tmp_path / "src" / "a.py", "Needle\n")
    write(tmp_path / "build" / "sub" / "generated.py", "Needle\n")

    result = search_python(
        "Needle",
        root=[str(tmp_path / "src"), str(tmp_path / "build")],
        mode="files",
    )

    assert {match["path"] for match in result["matches"]} == {
        "src/a.py",
        "build/sub/generated.py",
    }
    assert result["total_files"] == 2


def test_file_root_supports_regex_snippets_context_and_filters(tmp_path):
    target = tmp_path / "docs" / "tools.md"
    write(target, "before\n## `search`\nafter\n")

    result = search_python(
        r"## `search`",
        root=str(target),
        regex=True,
        mode="snippets",
        context_lines=1,
        glob="*.md",
    )

    assert result["matches"] == [
        {
            "path": "tools.md",
            "line": 2,
            "snippet": "## `search`",
            "context": [
                {"line": 1, "text": "before"},
                {"line": 2, "text": "## `search`"},
                {"line": 3, "text": "after"},
            ],
        }
    ]

    excluded = search_python("search", root=str(target), exclude="tools.md")

    assert excluded["scanned_files"] == 0
    assert excluded["matches"] == []


def test_iter_candidate_files_uses_scandir_and_skips_symlinked_dirs(tmp_path):
    write(tmp_path / "src" / "app.py", "Needle\n")
    write(tmp_path / "build" / "generated.py", "Needle\n")

    candidates = list(iter_candidate_files(str(tmp_path), glob_patterns=("*.py",)))

    assert [candidate.rel_path for candidate in candidates] == ["src/app.py"]


def test_search_python_path_target_supports_basename_scope_and_empty_pattern(tmp_path):
    write(tmp_path / "src" / "auth.py", "")
    write(tmp_path / "docs" / "auth.md", "")
    write(tmp_path / "docs" / "readme.md", "")

    basename = search_python(
        "auth",
        root=str(tmp_path),
        target="path",
        path_scope="basename",
        regex=False,
    )
    all_files = search_python("", root=str(tmp_path), target="path")

    assert [match["path"] for match in basename["matches"]] == [
        "src/auth.py",
        "docs/auth.md",
    ]
    assert all_files["total_files"] == 3
    assert all_files["scanned_bytes"] == 0


def test_search_python_rejects_snippets_for_path_target(tmp_path):
    write(tmp_path / "src" / "auth.py", "")

    try:
        search_python("auth", root=str(tmp_path), target="path", mode="snippets")
    except ValueError as exc:
        assert "snippets" in str(exc)
    else:
        raise AssertionError("expected ValueError")


def test_search_python_both_target_snippets_include_path_only_rows(tmp_path):
    write(tmp_path / "src" / "auth.py", "no content hit\n")
    write(tmp_path / "src" / "users.py", "auth appears in content\n")
    write(tmp_path / "src" / "auth_model.py", "auth appears in content too\n")

    result = search_python(
        "auth",
        root=str(tmp_path),
        target="both",
        regex=False,
        mode="snippets",
        limit=10,
    )

    by_path = {match["path"]: match for match in result["matches"]}
    assert by_path["src/auth.py"] == {
        "path": "src/auth.py",
        "kind": "file",
        "match_kind": "path",
    }
    assert by_path["src/users.py"]["line"] == 1
    assert by_path["src/users.py"]["match_kind"] == "content"
    assert by_path["src/auth_model.py"]["line"] == 1
    assert by_path["src/auth_model.py"]["match_kind"] == "both"
    assert result["total_files"] == 3
    assert result["total_matches"] == 3
    assert result["path_matches"] == 2
    assert result["content_files"] == 2
    assert result["content_count"] == 2
    assert result["count"] == 3
