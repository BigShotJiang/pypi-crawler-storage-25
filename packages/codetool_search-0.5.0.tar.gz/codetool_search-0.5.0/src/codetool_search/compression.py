"""Compact result shaping for public search output.

The search backends return the full, compatibility-preserving result shape.
This module owns the API output compression layer that runs after any backend
finishes, keeping location/count/pagination data while abbreviating low-value
metadata for coding-agent token efficiency.
"""

from __future__ import annotations


def _next_request(result: dict[str, object]) -> dict[str, object] | None:
    next_cursor = result.get("next_cursor")
    if next_cursor is None:
        return None
    request: dict[str, object] = {
        "pattern": result.get("pattern"),
        "root": result.get("root"),
        "cursor": next_cursor,
        "limit": result.get("limit"),
        "backend": result.get("backend_requested", result.get("backend")),
    }
    for key in ("target", "path_scope", "mode", "case", "regex", "glob", "exclude"):
        if key in result:
            request[key] = result[key]
    return request


def compress_result(result: dict[str, object]) -> dict[str, object]:
    """Return the default compact structured search result shape."""

    mode = str(result.get("mode", "files"))
    compact_matches: list[dict[str, object]] = []
    for match in result.get("matches", []):
        if not isinstance(match, dict):
            continue
        compact: dict[str, object] = {}
        if "path" in match:
            compact["p"] = match["path"]
        if mode != "files":
            if "line" in match:
                compact["l"] = match["line"]
            elif "first_line" in match:
                compact["l"] = match["first_line"]
            if "count" in match:
                compact["c"] = match["count"]
        if "snippet" in match:
            compact["s"] = match["snippet"]
        if "context" in match:
            compact["ctx"] = match["context"]
        if "match_kind" in match:
            compact["m"] = match["match_kind"]
        if "kind" in match and match.get("kind") != "file":
            compact["k"] = match["kind"]
        compact_matches.append(compact)

    backend: dict[str, object] = {"selected": result.get("backend")}
    if "backend_requested" in result:
        backend["requested"] = result["backend_requested"]
    if "backend_fallback" in result:
        backend["fallback"] = result["backend_fallback"]

    page: dict[str, object] = {
        "returned": result.get("returned", len(compact_matches)),
        "limit": result.get("limit"),
        "offset": result.get("offset"),
        "truncated": result.get("truncated", False),
        "next_cursor": result.get("next_cursor"),
    }
    next_request = _next_request(result)
    if next_request is not None:
        page["next_request"] = next_request

    totals: dict[str, object] = {
        "files": result.get("total_files", 0),
        "matches": result.get("total_matches", 0),
        "count": result.get("count", 0),
    }
    target = result.get("target", "content")
    if target != "content":
        totals["path"] = result.get("path_matches", 0)
        totals["content_files"] = result.get("content_files", 0)
        totals["content_count"] = result.get("content_count", 0)

    output: dict[str, object] = {
        "format": "compressed",
        "mode": mode,
        "backend": backend,
        "totals": totals,
        "page": page,
        "matches": compact_matches,
    }
    if target != "content" and "target" in result:
        output["target"] = result["target"]
    return output
