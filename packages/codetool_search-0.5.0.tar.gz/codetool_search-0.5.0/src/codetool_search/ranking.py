"""Ranking helpers for search results.

The ranking favours source files, path relevance, definitions, and concise
matches. It is intentionally deterministic so pagination remains stable.
"""

from __future__ import annotations

import os
import re
from collections.abc import Mapping

SOURCE_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".py",
        ".pyi",
        ".rs",
        ".go",
        ".js",
        ".jsx",
        ".ts",
        ".tsx",
        ".java",
        ".kt",
        ".c",
        ".h",
        ".cc",
        ".cpp",
        ".hpp",
        ".cs",
        ".rb",
        ".php",
        ".swift",
        ".scala",
        ".sh",
        ".bash",
        ".zsh",
        ".fish",
        ".toml",
        ".yaml",
        ".yml",
        ".json",
        ".md",
        ".rst",
    }
)

GENERATED_SEGMENTS: frozenset[str] = frozenset(
    {
        "generated",
        "vendor",
        "vendors",
        "third_party",
        "third-party",
        "coverage",
        "htmlcov",
        "site-packages",
        "dist-packages",
    }
)

TEST_SEGMENTS: frozenset[str] = frozenset(
    {"test", "tests", "spec", "specs", "__tests__"}
)

DEFINITION_PREFIXES: tuple[str, ...] = (
    "def ",
    "async def ",
    "class ",
    "fn ",
    "pub fn ",
    "pub(crate) fn ",
    "pub(super) fn ",
    "async fn ",
    "pub async fn ",
    "pub(crate) async fn ",
    "pub(super) async fn ",
    "unsafe fn ",
    "pub unsafe fn ",
    "pub(crate) unsafe fn ",
    "function ",
    "export function ",
    "export async function ",
    "export default function ",
    "export default async function ",
    "export class ",
    "export default class ",
    "const ",
    "pub const ",
    "pub(crate) const ",
    "pub(super) const ",
    "static ",
    "pub static ",
    "pub(crate) static ",
    "pub(super) static ",
    "let ",
    "export const ",
    "export let ",
    "export var ",
    "var ",
    "type ",
    "pub type ",
    "pub(crate) type ",
    "pub(super) type ",
    "export type ",
    "interface ",
    "export interface ",
    "struct ",
    "pub struct ",
    "pub(crate) struct ",
    "pub(super) struct ",
    "enum ",
    "pub enum ",
    "pub(crate) enum ",
    "pub(super) enum ",
    "trait ",
    "pub trait ",
    "pub(crate) trait ",
    "pub(super) trait ",
    "export enum ",
    "impl ",
)

TEST_INTENT_TERMS: frozenset[str] = frozenset(
    {
        "test",
        "tests",
        "testing",
        "spec",
        "specs",
        "fixture",
        "fixtures",
        "mock",
        "mocks",
        "assert",
        "pytest",
        "unittest",
    }
)


def _segments(path: str) -> tuple[str, ...]:
    return tuple(
        segment.lower()
        for segment in path.replace(os.sep, "/").replace("\\", "/").split("/")
        if segment
    )


def _basename(path: str) -> str:
    return path.replace(os.sep, "/").replace("\\", "/").rsplit("/", 1)[-1]


def is_generated_path(path: str) -> bool:
    """Return true for generated/vendor/minified-looking paths."""

    basename = _basename(path).lower()
    return (
        basename.endswith(".min.js")
        or basename.endswith(".map")
        or any(segment in GENERATED_SEGMENTS for segment in _segments(path))
    )


def is_test_path(path: str) -> bool:
    """Return true for common test/spec file paths."""

    basename = _basename(path).lower()
    stem = basename.rsplit(".", 1)[0]
    return (
        any(segment in TEST_SEGMENTS for segment in _segments(path))
        or stem.startswith("test_")
        or stem.endswith("_test")
        or stem.endswith(".test")
        or stem.endswith(".spec")
    )


def is_source_path(path: str) -> bool:
    """Return true for common source/documentation file extensions."""

    _, extension = os.path.splitext(_basename(path).lower())
    return extension in SOURCE_EXTENSIONS


def query_mentions_tests(query: str) -> bool:
    """Return true if the query itself appears test/spec oriented."""

    return any(term in TEST_INTENT_TERMS for term in _query_terms(query))


def path_relevance(path: str, query: str) -> int:
    """Lower score is better for how well ``path`` matches ``query``."""

    if not query:
        return 50

    query_lower = query.lower()
    normalised = path.replace(os.sep, "/").replace("\\", "/").lower()
    basename = _basename(normalised)
    stem = basename.rsplit(".", 1)[0]
    segments = _segments(normalised)

    if stem == query_lower or basename == query_lower:
        return 0
    if stem.startswith(query_lower) or basename.startswith(query_lower):
        return 5
    if query_lower in stem or query_lower in basename:
        return 10
    if any(
        query_lower == segment or segment.startswith(query_lower)
        for segment in segments[:-1]
    ):
        return 15
    if any(query_lower in segment for segment in segments[:-1]):
        return 20
    if query_lower in normalised:
        return 30

    query_compact = _compact_alnum(query) if _query_allows_compact_variant(query) else ""
    basename_compact = _compact_alnum(basename)
    stem_compact = _compact_alnum(stem)
    if len(query_compact) >= 2 and query_compact in {stem_compact, basename_compact}:
        return 0
    if len(query_compact) >= 2 and (
        stem_compact.startswith(query_compact)
        or basename_compact.startswith(query_compact)
    ):
        return 5
    if len(query_compact) >= 2 and (
        query_compact in stem_compact or query_compact in basename_compact
    ):
        return 10

    return _term_path_relevance(normalised, stem, segments, query)


def _term_path_relevance(
    normalised: str, stem: str, segments: tuple[str, ...], query: str
) -> int:
    terms = _query_terms(query)
    if not terms:
        return 50

    stem_compact = _compact_alnum(stem)
    path_compact = _compact_alnum(normalised)
    directory_text = "/".join(segments[:-1])
    directory_compact = _compact_alnum(directory_text)

    stem_hits = sum(_text_matches_term(stem, stem_compact, term) for term in terms)
    directory_hits = sum(
        _text_matches_term(directory_text, directory_compact, term) for term in terms
    )
    path_hits = sum(_text_matches_term(normalised, path_compact, term) for term in terms)

    if stem_hits == len(terms):
        return 8
    if stem_hits >= 2:
        return 12
    if directory_hits == len(terms):
        return 15
    if path_hits == len(terms):
        return 18
    if stem_hits == 1:
        return 22
    if directory_hits >= 1:
        return 26
    if path_hits >= 1:
        return 35
    return 50


def _text_matches_term(text: str, compact: str, term: str) -> bool:
    return term in text or term in compact


def _query_terms(query: str) -> tuple[str, ...]:
    terms = list(_split_identifier_terms(query))
    if _query_allows_compact_variant(query):
        _append_unique(terms, _compact_alnum(query))
    return tuple(terms)


def _split_identifier_terms(text: str) -> tuple[str, ...]:
    text = _regex_escapes_as_separators(text)
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", text)
    spaced = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", spaced)
    terms: list[str] = []
    for term in re.split(r"[^0-9A-Za-z]+", spaced):
        _append_unique(terms, term.lower())
    return tuple(terms)


def _regex_escapes_as_separators(text: str) -> str:
    chars: list[str] = []
    index = 0
    while index < len(text):
        character = text[index]
        if character == "\\":
            chars.append(" ")
            index += 1
            if index < len(text):
                if (
                    text[index] in {"p", "P"}
                    and index + 1 < len(text)
                    and text[index + 1] == "{"
                ):
                    index += 2
                    while index < len(text) and text[index] != "}":
                        index += 1
                    if index < len(text):
                        index += 1
                else:
                    index += 1
            continue

        chars.append(character)
        index += 1
    return "".join(chars)


def _query_allows_compact_variant(query: str) -> bool:
    return all(
        (character.isascii() and character.isalnum()) or character in "_-."
        for character in query
    )


def _compact_alnum(text: str) -> str:
    return "".join(
        character.lower()
        for character in text
        if character.isascii() and character.isalnum()
    )


def _append_unique(terms: list[str], term: str) -> None:
    if len(term) >= 2 and term not in terms:
        terms.append(term)


def definition_bonus(snippet: str) -> int:
    """Return a negative score for definition-like snippets."""

    stripped = snippet.strip().lower()
    return -10 if stripped.startswith(DEFINITION_PREFIXES) else 0


def file_sort_key(match: Mapping[str, object], query: str) -> tuple[object, ...]:
    """Sort key for file/count mode result rows."""

    path = str(match.get("path", ""))
    count = int(match.get("count", 0) or 0)
    first_line = int(match.get("first_line", 0) or 0)
    mentions_tests = query_mentions_tests(query)
    return (
        10 if is_generated_path(path) else 0,
        0 if is_source_path(path) else 5,
        5 if is_test_path(path) and not mentions_tests else 0,
        path_relevance(path, query),
        min(count, 20),  # fewer matches are often more precise
        first_line,
        len(path),
        path,
    )


def snippet_sort_key(match: Mapping[str, object], query: str) -> tuple[object, ...]:
    """Sort key for snippet mode result rows."""

    path = str(match.get("path", ""))
    snippet = str(match.get("snippet", ""))
    line = int(match.get("line", 0) or 0)
    mentions_tests = query_mentions_tests(query)
    return (
        10 if is_generated_path(path) else 0,
        0 if is_source_path(path) else 5,
        5 if is_test_path(path) and not mentions_tests else 0,
        path_relevance(path, query),
        definition_bonus(snippet),
        line,
        len(path),
        path,
    )
