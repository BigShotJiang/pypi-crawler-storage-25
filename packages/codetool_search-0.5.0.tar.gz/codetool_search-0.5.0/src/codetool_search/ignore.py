"""Ignore, glob, and path-normalisation helpers.

The implementation deliberately avoids external dependencies. It is not a full
Git wildmatch clone; it provides fast common ignores plus simple shell-style
patterns that are good enough for coding-agent search.
"""

from __future__ import annotations

import fnmatch
import os
from collections.abc import Iterable

COMMON_IGNORED_DIRS: frozenset[str] = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        ".tox",
        ".nox",
        ".venv",
        "venv",
        "env",
        "__pycache__",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".cache",
        "node_modules",
        "bower_components",
        "dist",
        "build",
        "target",
        ".next",
        ".nuxt",
        ".idea",
        ".vscode",
    }
)

COMMON_IGNORED_FILES: frozenset[str] = frozenset(
    {
        ".DS_Store",
        "Thumbs.db",
    }
)

IGNORE_FILES: tuple[str, ...] = (".pbiignore", ".gitignore")


def normalize_relpath(path: str) -> str:
    """Return a compact relative path using forward slashes."""

    rel = os.fspath(path).replace("\\", "/").replace(os.sep, "/")
    if os.altsep:
        rel = rel.replace(os.altsep, "/")
    while rel.startswith("./"):
        rel = rel[2:]
    return "" if rel == "." else rel


def relative_path(path: str, root: str) -> str:
    """Return ``path`` relative to ``root`` with stable slash separators."""

    try:
        return normalize_relpath(os.path.relpath(path, root))
    except ValueError:
        # Different drives on Windows; fall back to a normalised absolute path.
        return normalize_relpath(os.path.abspath(path))


def normalize_patterns(patterns: str | Iterable[str] | None) -> tuple[str, ...]:
    """Normalise a public glob/exclude value into a tuple of patterns."""

    if patterns is None:
        return ()
    if isinstance(patterns, str):
        raw_patterns = (patterns,)
    else:
        raw_patterns = tuple(patterns)
    normalised: list[str] = []
    for pattern in raw_patterns:
        if pattern is None:
            continue
        text = normalize_relpath(str(pattern).strip())
        if not text:
            continue
        normalised.append(text)
    return tuple(normalised)


def load_ignore_patterns(root: str) -> tuple[str, ...]:
    """Load simple root-level patterns from ``.pbiignore`` and ``.gitignore``.

    Supported syntax is intentionally small: comments and blank lines are
    ignored, leading ``!`` negation is ignored, and trailing slash means the
    directory and everything under it.
    """

    patterns: list[str] = []
    for filename in IGNORE_FILES:
        path = os.path.join(root, filename)
        try:
            with open(path, encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
        except OSError:
            continue
        for line in lines:
            text = line.strip()
            if not text or text.startswith("#") or text.startswith("!"):
                continue
            text = normalize_relpath(text)
            if text.endswith("/"):
                text = text.rstrip("/")
                patterns.extend((text, f"{text}/**"))
            else:
                patterns.append(text)
    return tuple(patterns)


def _path_segments(rel_path: str) -> tuple[str, ...]:
    return tuple(
        segment for segment in normalize_relpath(rel_path).split("/") if segment
    )


def is_common_ignored_dir(name: str) -> bool:
    """Return true when ``name`` is a directory we should hard-prune."""

    return name in COMMON_IGNORED_DIRS


def is_common_ignored_file(name: str) -> bool:
    """Return true when ``name`` is a common unhelpful file."""

    return name in COMMON_IGNORED_FILES


def path_matches_pattern(rel_path: str, pattern: str) -> bool:
    """Match a normalised relative path against a simple shell-style pattern."""

    rel_path = normalize_relpath(rel_path)
    pattern = normalize_relpath(pattern)
    if not pattern:
        return False

    basename = rel_path.rsplit("/", 1)[-1]

    if fnmatch.fnmatchcase(rel_path, pattern) or fnmatch.fnmatchcase(basename, pattern):
        return True

    # Treat bare directory names as "any segment named X".
    if "/" not in pattern and pattern in _path_segments(rel_path):
        return True

    # Treat "dir" and "dir/**" as directory-prefix patterns.
    prefix = pattern[:-3] if pattern.endswith("/**") else pattern
    if prefix and (rel_path == prefix or rel_path.startswith(prefix.rstrip("/") + "/")):
        return True

    return False


def path_matches_any(rel_path: str, patterns: Iterable[str]) -> bool:
    """Return true if ``rel_path`` matches any pattern."""

    return any(path_matches_pattern(rel_path, pattern) for pattern in patterns)


def pattern_targets_path_or_descendant(path: str, pattern: str) -> bool:
    """Return true when a pattern is anchored at ``path`` or its descendants."""

    path = normalize_relpath(path).strip("/")
    pattern = normalize_relpath(pattern).strip("/")
    if not path or not pattern:
        return False
    return path_matches_pattern(path, pattern) or pattern.startswith(f"{path}/")


def matches_glob(rel_path: str, glob_patterns: Iterable[str]) -> bool:
    """Return true if the path is accepted by the optional glob filters."""

    patterns = tuple(glob_patterns)
    if not patterns:
        return True
    return path_matches_any(rel_path, patterns)


def should_ignore_path(
    rel_path: str,
    *,
    is_dir: bool,
    exclude_patterns: Iterable[str] = (),
    ignore_patterns: Iterable[str] = (),
    root_ignore_patterns: Iterable[str] = (),
    common_rel_path: str | None = None,
) -> bool:
    """Return true when a file/directory should be skipped."""

    rel_path = normalize_relpath(rel_path)
    common_path = normalize_relpath(
        common_rel_path if common_rel_path is not None else rel_path
    )
    common_name = common_path.rsplit("/", 1)[-1]
    common_segments = _path_segments(common_path)

    if is_dir:
        if common_name in COMMON_IGNORED_DIRS or any(
            segment in COMMON_IGNORED_DIRS for segment in common_segments
        ):
            return True
    elif common_name in COMMON_IGNORED_FILES:
        return True

    all_patterns = tuple(exclude_patterns) + tuple(ignore_patterns)
    if all_patterns and path_matches_any(rel_path, all_patterns):
        return True

    if root_ignore_patterns and path_matches_any(common_path, root_ignore_patterns):
        return True

    return False
