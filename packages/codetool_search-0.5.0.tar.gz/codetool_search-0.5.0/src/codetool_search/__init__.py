"""Fast workspace search for coding-agent tools.

The main public API is intentionally a single function:

```
from codetool_search import search
```

`search()` can target file contents, file paths, or both. Patterns are regexes
by default. ``backend="auto"`` dispatches to a bundled/development Rust CLI
accelerator when available, with the pure-Python stdlib backend as fallback.
Use ``result_format="text"`` for maximally compact raw text output. Controlled
failures raise ``SearchError`` subclasses.
"""

from __future__ import annotations

from .api import search
from .errors import (
    SearchArgumentError,
    SearchBackendError,
    SearchError,
    SearchPatternError,
    SearchRootError,
)

__all__ = [
    "search",
    "SearchArgumentError",
    "SearchBackendError",
    "SearchError",
    "SearchPatternError",
    "SearchRootError",
]
