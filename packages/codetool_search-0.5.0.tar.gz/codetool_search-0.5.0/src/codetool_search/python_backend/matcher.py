"""Content and path matcher construction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TypeAlias

from .literal import LiteralMatcher
from .regex_search import RegexLineMatcher

SearchMatcher: TypeAlias = LiteralMatcher | RegexLineMatcher


def build_content_matcher(
    pattern: str,
    *,
    regex: bool,
    case_sensitive: bool,
) -> SearchMatcher:
    """Build the matcher used for content search."""

    if regex:
        flags = 0 if case_sensitive else re.IGNORECASE
        return RegexLineMatcher(re.compile(pattern, flags))
    needle = pattern.encode("utf-8", errors="surrogatepass")
    return LiteralMatcher(needle=needle, case_sensitive=case_sensitive)


@dataclass(frozen=True)
class PathMatcher:
    """Prepared path matcher state."""

    pattern: str
    regex: bool
    case_sensitive: bool
    compiled: re.Pattern[str] | None = None

    @classmethod
    def build(
        cls,
        pattern: str,
        *,
        regex: bool,
        case_sensitive: bool,
    ) -> "PathMatcher":
        """Build a path matcher, compiling regexes when requested."""

        compiled = None
        if regex:
            flags = 0 if case_sensitive else re.IGNORECASE
            compiled = re.compile(pattern, flags)
        return cls(
            pattern=pattern,
            regex=regex,
            case_sensitive=case_sensitive,
            compiled=compiled,
        )

    def is_match(self, rel_path: str, path_scope: str) -> bool:
        """Return whether ``rel_path`` matches this matcher."""

        text = path_match_subject(rel_path, path_scope)
        if self.regex:
            assert self.compiled is not None
            return self.compiled.search(text) is not None
        if not self.pattern:
            return True
        if self.case_sensitive:
            return self.pattern in text
        return self.pattern.casefold() in text.casefold()


def path_match_subject(rel_path: str, path_scope: str) -> str:
    """Return the relative path component selected by ``path_scope``."""

    if path_scope == "basename":
        return rel_path.rsplit("/", 1)[-1]
    return rel_path