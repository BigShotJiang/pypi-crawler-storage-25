"""Text decoding, cropping, and snippet context helpers."""

from __future__ import annotations

from .constants import MAX_SNIPPET_CHARS


def decode_line(line: bytes) -> str:
    """Decode one raw line for display."""

    return line.decode("utf-8", errors="replace").rstrip("\r")


def crop(text: str, *, max_chars: int = MAX_SNIPPET_CHARS) -> str:
    """Compact and crop snippet text."""

    text = text.replace("\t", " ").strip()
    if len(text) <= max_chars:
        return text
    if max_chars <= 1:
        return text[:max_chars]
    return text[: max_chars - 1].rstrip() + "…"


def context_for_lines(
    lines: list[bytes],
    line_index: int,
    context_lines: int,
) -> list[dict[str, object]]:
    """Return cropped context rows around ``line_index``."""

    if context_lines <= 0:
        return []
    start = max(0, line_index - context_lines)
    end = min(len(lines), line_index + context_lines + 1)
    return [
        {"line": index + 1, "text": crop(decode_line(lines[index]))}
        for index in range(start, end)
    ]