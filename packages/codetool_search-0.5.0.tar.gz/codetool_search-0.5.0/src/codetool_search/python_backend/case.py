"""Case-sensitivity handling for the Python backend."""

from __future__ import annotations

from ..errors import SearchArgumentError


def resolve_case(case: str, pattern: str) -> tuple[str, bool]:
    """Return ``(effective_case, case_sensitive)`` for a search pattern."""

    normalised = str(case or "smart").lower()
    if normalised == "smart":
        case_sensitive = any(char.isupper() for char in pattern)
        return "sensitive" if case_sensitive else "insensitive", case_sensitive
    if normalised in {"sensitive", "case-sensitive", "exact"}:
        return "sensitive", True
    if normalised in {"insensitive", "ignore", "ignorecase", "case-insensitive", "i"}:
        return "insensitive", False
    raise SearchArgumentError("case must be one of: smart, sensitive, insensitive")