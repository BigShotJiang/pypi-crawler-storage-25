"""Data models shared by the Python backend modules."""

from __future__ import annotations

from dataclasses import dataclass


class BinaryFileError(ValueError):
    """Raised internally when a candidate file looks binary."""


@dataclass(frozen=True)
class CandidateFile:
    """A candidate file found by the scanner."""

    path: str
    rel_path: str
    size: int


@dataclass(frozen=True)
class IgnorePatterns:
    """Ignore patterns split by the path they should match against."""

    common: tuple[str, ...] = ()
    root: tuple[str, ...] = ()


@dataclass
class SearchCounters:
    """Mutable counters collected while searching candidates."""

    scanned_files: int = 0
    scanned_bytes: int = 0
    path_match_count: int = 0
    content_match_count: int = 0
    skipped_binary: int = 0
    skipped_huge: int = 0
    skipped_errors: int = 0

    @property
    def skipped(self) -> dict[str, int]:
        """Return skipped counters in the public result shape."""

        return {
            "binary": self.skipped_binary,
            "huge": self.skipped_huge,
            "errors": self.skipped_errors,
        }