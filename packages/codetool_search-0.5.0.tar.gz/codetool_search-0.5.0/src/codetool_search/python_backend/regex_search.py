"""Regex content matching for the Python backend."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .constants import MAX_SNIPPETS_PER_FILE
from .models import CandidateFile
from .text import context_for_lines, crop, decode_line


@dataclass(frozen=True)
class RegexLineMatcher:
    """Prepared regex line matcher."""

    compiled: re.Pattern[str]


def search_regex_file(
    candidate: CandidateFile,
    data: bytes,
    matcher: RegexLineMatcher,
    *,
    context_lines: int,
    collect_snippets: bool,
) -> tuple[dict[str, object] | None, list[dict[str, object]]]:
    """Search one file's decoded lines with a compiled regex."""

    lines = data.splitlines()

    count = 0
    first_line: int | None = None
    snippets: list[dict[str, object]] = []

    for index, raw_line in enumerate(lines):
        line = decode_line(raw_line)
        matches = list(matcher.compiled.finditer(line))
        if not matches:
            continue
        count += len(matches)
        line_number = index + 1
        if first_line is None:
            first_line = line_number
        if collect_snippets and len(snippets) < MAX_SNIPPETS_PER_FILE:
            snippet: dict[str, object] = {
                "path": candidate.rel_path,
                "line": line_number,
                "snippet": crop(line),
            }
            context = context_for_lines(lines, index, context_lines)
            if context:
                snippet["context"] = context
            snippets.append(snippet)

    if count == 0 or first_line is None:
        return None, []

    return {
        "path": candidate.rel_path,
        "count": count,
        "first_line": first_line,
    }, snippets