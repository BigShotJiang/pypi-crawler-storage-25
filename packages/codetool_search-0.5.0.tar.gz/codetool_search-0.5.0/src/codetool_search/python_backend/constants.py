"""Constants used by the Python backend."""

from __future__ import annotations

import sys
from typing import Any

DEFAULT_MAX_FILE_BYTES = 5 * 1024 * 1024
DEFAULT_BINARY_CHECK_BYTES = 8 * 1024

MAX_FILE_BYTES = DEFAULT_MAX_FILE_BYTES
BINARY_CHECK_BYTES = DEFAULT_BINARY_CHECK_BYTES
MAX_SNIPPETS_PER_FILE = 3
MAX_SNIPPET_CHARS = 180
VALID_MODES = frozenset({"files", "snippets", "count"})
VALID_TARGETS = frozenset({"content", "path", "both"})
VALID_PATH_SCOPES = frozenset({"path", "basename"})


def _runtime_constant(name: str, default: int) -> int:
    """Read a tunable constant, preserving package-level monkeypatch support."""

    package = sys.modules.get("codetool_search.python_backend")
    package_value: Any = getattr(package, name, default) if package else default
    module_value: Any = globals().get(name, default)
    value = package_value if package_value != default else module_value
    return int(value)


def max_file_bytes() -> int:
    """Return the active maximum content file size."""

    return _runtime_constant("MAX_FILE_BYTES", DEFAULT_MAX_FILE_BYTES)


def binary_check_bytes() -> int:
    """Return the active binary-probe byte count."""

    return _runtime_constant("BINARY_CHECK_BYTES", DEFAULT_BINARY_CHECK_BYTES)