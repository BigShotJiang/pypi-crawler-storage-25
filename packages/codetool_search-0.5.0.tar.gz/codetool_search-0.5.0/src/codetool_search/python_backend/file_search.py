"""Read text candidates and dispatch content searchers."""

from __future__ import annotations

from .constants import binary_check_bytes, max_file_bytes
from .literal import LiteralMatcher, search_literal_file
from .matcher import SearchMatcher
from .models import BinaryFileError, CandidateFile
from .regex_search import RegexLineMatcher, search_regex_file


def read_text_candidate(candidate: CandidateFile) -> bytes:
    """Read a candidate file after applying huge-file and binary guards."""

    if candidate.size > max_file_bytes():
        raise OverflowError("huge file")
    with open(candidate.path, "rb") as handle:
        first = handle.read(binary_check_bytes())
        if b"\x00" in first:
            raise BinaryFileError("binary file")
        rest = handle.read()
    return first + rest


def search_file(
    candidate: CandidateFile,
    matcher: SearchMatcher,
    *,
    context_lines: int,
    collect_snippets: bool,
) -> tuple[dict[str, object] | None, list[dict[str, object]]]:
    """Search one already-filtered candidate file."""

    data = read_text_candidate(candidate)
    if isinstance(matcher, LiteralMatcher):
        return search_literal_file(
            candidate,
            data,
            matcher,
            context_lines=context_lines,
            collect_snippets=collect_snippets,
        )
    if isinstance(matcher, RegexLineMatcher):
        return search_regex_file(
            candidate,
            data,
            matcher,
            context_lines=context_lines,
            collect_snippets=collect_snippets,
        )
    raise TypeError(f"unsupported matcher: {type(matcher).__name__}")