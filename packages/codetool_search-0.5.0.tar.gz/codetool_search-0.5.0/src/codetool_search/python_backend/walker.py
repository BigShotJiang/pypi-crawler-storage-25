"""Candidate-file walking for the Python backend."""

from __future__ import annotations

import os
from collections.abc import Iterable, Iterator

from ..ignore import matches_glob, relative_path, should_ignore_path
from .ignore_rules import ignore_patterns_for_root
from .models import CandidateFile


def iter_candidate_files(
    root: str,
    *,
    rel_base: str | None = None,
    glob_patterns: Iterable[str] = (),
    exclude_patterns: Iterable[str] = (),
) -> Iterator[CandidateFile]:
    """Yield candidate files for a directory or single-file ``root``."""

    root_abs = os.path.abspath(os.fspath(root))
    rel_base_abs = os.path.abspath(os.fspath(rel_base)) if rel_base else None
    if os.path.isfile(root_abs):
        yield from _iter_single_file_root(
            root_abs,
            rel_base_abs=rel_base_abs,
            glob_patterns=glob_patterns,
            exclude_patterns=exclude_patterns,
        )
        return

    base_root = rel_base_abs or root_abs
    ignore_patterns = ignore_patterns_for_root(
        root_abs,
        rel_base_abs=rel_base_abs,
        is_file=False,
    )
    stack = [root_abs]

    while stack:
        current = stack.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        rel_path = relative_path(entry.path, base_root)
                        common_rel_path = (
                            relative_path(entry.path, root_abs)
                            if rel_base_abs is not None
                            else rel_path
                        )
                        if entry.is_dir(follow_symlinks=False):
                            if should_ignore_path(
                                rel_path,
                                is_dir=True,
                                exclude_patterns=exclude_patterns,
                                ignore_patterns=ignore_patterns.common,
                                root_ignore_patterns=ignore_patterns.root,
                                common_rel_path=common_rel_path,
                            ):
                                continue
                            stack.append(entry.path)
                        elif entry.is_file(follow_symlinks=False):
                            if should_ignore_path(
                                rel_path,
                                is_dir=False,
                                exclude_patterns=exclude_patterns,
                                ignore_patterns=ignore_patterns.common,
                                root_ignore_patterns=ignore_patterns.root,
                                common_rel_path=common_rel_path,
                            ):
                                continue
                            if not matches_glob(rel_path, glob_patterns):
                                continue
                            try:
                                stat_result = entry.stat(follow_symlinks=False)
                            except OSError:
                                continue
                            yield CandidateFile(
                                entry.path,
                                rel_path,
                                stat_result.st_size,
                            )
                    except OSError:
                        continue
        except OSError:
            continue


def _iter_single_file_root(
    root_abs: str,
    *,
    rel_base_abs: str | None,
    glob_patterns: Iterable[str],
    exclude_patterns: Iterable[str],
) -> Iterator[CandidateFile]:
    filter_root = os.path.dirname(root_abs) or os.curdir
    base_root = rel_base_abs or filter_root
    rel_path = relative_path(root_abs, base_root)
    ignore_patterns = ignore_patterns_for_root(
        root_abs,
        rel_base_abs=rel_base_abs,
        is_file=True,
    )
    if should_ignore_path(
        rel_path,
        is_dir=False,
        exclude_patterns=exclude_patterns,
        ignore_patterns=ignore_patterns.common,
        root_ignore_patterns=ignore_patterns.root,
        common_rel_path=relative_path(root_abs, filter_root),
    ) or not matches_glob(rel_path, glob_patterns):
        return
    try:
        stat_result = os.stat(root_abs)
    except OSError:
        return
    yield CandidateFile(root_abs, rel_path, stat_result.st_size)