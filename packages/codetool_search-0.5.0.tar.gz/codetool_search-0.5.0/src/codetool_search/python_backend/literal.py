"""Literal content matching for the Python backend."""

from __future__ import annotations

from dataclasses import dataclass

from .constants import MAX_SNIPPETS_PER_FILE
from .models import CandidateFile
from .text import context_for_lines, crop, decode_line


@dataclass(frozen=True)
class LiteralMatcher:
    """Prepared literal matcher state."""

    needle: bytes
    case_sensitive: bool


def count_non_overlapping(haystack: bytes, needle: bytes) -> int:
    """Count non-overlapping byte literal matches."""

    count = 0
    start = 0
    step = max(1, len(needle))
    while True:
        index = haystack.find(needle, start)
        if index < 0:
            return count
        count += 1
        start = index + step


def search_literal_file(
    candidate: CandidateFile,
    data: bytes,
    matcher: LiteralMatcher,
    *,
    context_lines: int,
    collect_snippets: bool,
) -> tuple[dict[str, object] | None, list[dict[str, object]]]:
    """Search one file's bytes for a literal needle."""

    compare_needle = matcher.needle if matcher.case_sensitive else matcher.needle.lower()
    lines = data.splitlines()

    count = 0
    first_line: int | None = None
    snippets: list[dict[str, object]] = []

    for index, line in enumerate(lines):
        compare_line = line if matcher.case_sensitive else line.lower()
        line_count = count_non_overlapping(compare_line, compare_needle)
        if line_count == 0:
            continue
        count += line_count
        line_number = index + 1
        if first_line is None:
            first_line = line_number
        if collect_snippets and len(snippets) < MAX_SNIPPETS_PER_FILE:
            snippet: dict[str, object] = {
                "path": candidate.rel_path,
                "line": line_number,
                "snippet": crop(decode_line(line)),
            }
            context = context_for_lines(lines, index, context_lines)
            if context:
                snippet["context"] = context
            snippets.append(snippet)

    if count == 0 or first_line is None:
        return None, []

    file_match: dict[str, object] = {
        "path": candidate.rel_path,
        "count": count,
        "first_line": first_line,
    }
    return file_match, snippets