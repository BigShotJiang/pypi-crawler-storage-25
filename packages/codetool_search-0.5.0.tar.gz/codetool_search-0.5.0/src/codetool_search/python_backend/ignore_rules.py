"""Ignore-pattern loading for Python backend candidate walking."""

from __future__ import annotations

import os

from ..ignore import (
    load_ignore_patterns,
    pattern_targets_path_or_descendant,
    relative_path,
)
from .models import IgnorePatterns


def ignore_patterns_for_root(
    root_abs: str,
    *,
    rel_base_abs: str | None,
    is_file: bool,
) -> IgnorePatterns:
    """Return common-base and root-local ignore patterns for a search root."""

    filter_root = os.path.dirname(root_abs) if is_file else root_abs
    if rel_base_abs is None:
        return IgnorePatterns(root=load_ignore_patterns(filter_root))

    root_prefix = relative_path(filter_root, rel_base_abs)
    patterns: list[str] = []
    if os.path.isdir(rel_base_abs):
        patterns.extend(
            pattern
            for pattern in load_ignore_patterns(rel_base_abs)
            if not pattern_targets_path_or_descendant(root_prefix, pattern)
        )

    root_patterns = load_ignore_patterns(filter_root)
    return IgnorePatterns(
        common=tuple(dict.fromkeys(patterns)),
        root=tuple(dict.fromkeys(root_patterns)),
    )