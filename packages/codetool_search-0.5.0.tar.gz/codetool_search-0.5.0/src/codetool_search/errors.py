"""Public exception taxonomy for codetool-search."""

from __future__ import annotations


class SearchError(Exception):
    """Base class for controlled codetool-search failures."""


class SearchArgumentError(SearchError, ValueError):
    """Raised for invalid public search arguments."""


class SearchPatternError(SearchArgumentError):
    """Raised for invalid or unsupported search patterns."""


class SearchRootError(SearchError, OSError):
    """Raised when the requested search root cannot be searched."""


class SearchBackendError(SearchError, RuntimeError):
    """Raised when a selected search backend fails at runtime."""
