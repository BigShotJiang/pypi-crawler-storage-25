"""Rust CLI backend discovery and subprocess wrapper."""

from __future__ import annotations

import json
import os
import platform
import shutil
import subprocess
import sys
from collections.abc import Iterable, Iterator
from pathlib import Path

from .cursor import normalize_limit
from .errors import (
    SearchArgumentError,
    SearchBackendError,
    SearchPatternError,
)
from .ignore import normalize_patterns
from .python_backend import normalize_mode, normalize_path_scope, normalize_target, resolve_case
from .roots import RootInput, normalize_search_roots

ENV_BINARY = "CODETOOL_SEARCH_RUST_BINARY"
TARGET_RUNTIME_ENVS = (
    "CODETOOL_SEARCH_TARGET_RUNTIME",
    "CODETOOL_TARGET_RUNTIME",
)
SUPPORTED_RUNTIME_KEYS = (
    "linux-x86_64",
    "linux-aarch64",
    "macos-x86_64",
    "macos-arm64",
    "windows-x86_64",
    "windows-arm64",
)
RUNTIME_ALIASES = {
    "linux-amd64": "linux-x86_64",
    "linux-x64": "linux-x86_64",
    "linux-arm64": "linux-aarch64",
    "darwin-x86_64": "macos-x86_64",
    "darwin-amd64": "macos-x86_64",
    "darwin-arm64": "macos-arm64",
    "darwin-aarch64": "macos-arm64",
    "macos-aarch64": "macos-arm64",
    "macosx-x86_64": "macos-x86_64",
    "macosx-arm64": "macos-arm64",
    "windows-amd64": "windows-x86_64",
    "windows-x64": "windows-x86_64",
    "windows-aarch64": "windows-arm64",
    "win-x86_64": "windows-x86_64",
    "win-amd64": "windows-x86_64",
    "win-arm64": "windows-arm64",
}
BINARY_NAMES: tuple[str, ...] = (
    "codetool-search-rust",
    "codetool_search_rust",
)
BASE_BINARY = "codetool-search-rust"


class RustBackendUnavailable(SearchBackendError):
    """Raised when an explicit Rust backend request cannot be satisfied."""


def _normalize_machine(machine: str | None = None) -> str:
    raw = (machine or platform.machine() or "unknown").lower().replace("-", "_")
    aliases = {
        "amd64": "x86_64",
        "x64": "x86_64",
        "i386": "x86",
        "i686": "x86",
        "arm64": "arm64",
        "aarch64": "aarch64",
    }
    return aliases.get(raw, raw)


def normalize_runtime_key(value: str) -> str:
    """Normalize user/platform spelling to a stable packaged-binary runtime key."""

    key = value.strip().lower().replace("_", "-")
    key = key.replace("linux-x86-64", "linux-x86_64")
    key = key.replace("macos-x86-64", "macos-x86_64")
    key = key.replace("windows-x86-64", "windows-x86_64")
    key = key.replace("darwin-x86-64", "darwin-x86_64")
    key = RUNTIME_ALIASES.get(key, key)
    if key not in SUPPORTED_RUNTIME_KEYS:
        supported = ", ".join(SUPPORTED_RUNTIME_KEYS)
        raise SearchArgumentError(
            f"unsupported target runtime {value!r}; expected one of: {supported}"
        )
    return key


def _host_runtime_key() -> str:
    if os.name == "nt":
        os_tag = "windows"
    elif sys.platform == "darwin":
        os_tag = "macos"
    elif sys.platform.startswith("linux"):
        os_tag = "linux"
    else:
        os_tag = sys.platform.replace("-", "_")

    arch = _normalize_machine()
    if os_tag == "linux" and arch == "arm64":
        arch = "aarch64"
    elif os_tag in {"macos", "windows"} and arch == "aarch64":
        arch = "arm64"
    return normalize_runtime_key(f"{os_tag}-{arch}")


def _target_runtime_key() -> str:
    for env_name in TARGET_RUNTIME_ENVS:
        if value := os.environ.get(env_name):
            return normalize_runtime_key(value)
    return _host_runtime_key()


def _platform_tag() -> str:
    """Return the stable runtime key used for packaged Rust helper binaries."""

    return _target_runtime_key()


def packaged_binary_names(runtime_key: str | None = None) -> tuple[str, ...]:
    """Return target-specific packaged binary names and generic binary names."""

    tag = normalize_runtime_key(runtime_key) if runtime_key else _platform_tag()
    names = [f"{BASE_BINARY}-{tag}"]
    if tag == "linux-x86_64":
        names.append(f"{BASE_BINARY}-linux-x86_64")
    if tag.endswith("arm64"):
        names.append(f"{BASE_BINARY}-{tag.replace('arm64', 'aarch64')}")
    names.extend(BINARY_NAMES)
    return tuple(dict.fromkeys(names))


def _with_platform_suffix(name: str) -> tuple[str, ...]:
    if os.name == "nt" and not name.endswith(".exe"):
        return (name + ".exe", name)
    return (name,)


def _candidate_names() -> Iterator[str]:
    for name in BINARY_NAMES:
        yield from _with_platform_suffix(name)


def _packaged_candidate_names() -> Iterator[str]:
    for name in packaged_binary_names():
        yield name
        if "windows-" in name and not name.endswith(".exe"):
            yield name + ".exe"
        elif os.name == "nt" and not name.endswith(".exe"):
            yield name + ".exe"


def _is_executable_file(path: Path) -> bool:
    return path.is_file() and os.access(path, os.X_OK)


def candidate_binary_paths() -> Iterator[Path]:
    """Yield environment, packaged, and development Rust binary candidates."""

    env_value = os.environ.get(ENV_BINARY)
    if env_value:
        yield Path(env_value).expanduser()

    package_dir = Path(__file__).resolve().parent
    for name in _packaged_candidate_names():
        yield package_dir / "_bin" / name

    # Development checkout: src/codetool_search/rust_backend.py -> repo root
    repo_root = package_dir.parents[1]
    for profile in ("release", "debug"):
        for name in _candidate_names():
            yield repo_root / "rust" / "target" / profile / name


def find_rust_binary() -> str | None:
    """Find the optional Rust CLI binary, if available."""

    for path in candidate_binary_paths():
        if _is_executable_file(path):
            return str(path)

    for name in _candidate_names():
        found = shutil.which(name)
        if found:
            return found

    return None


def _append_patterns(args: list[str], flag: str, patterns: Iterable[str]) -> None:
    for pattern in patterns:
        args.extend((flag, pattern))


def search_rust(
    pattern: str,
    root: RootInput = ".",
    *,
    regex: bool = False,
    target: str = "content",
    path_scope: str = "path",
    glob: str | Iterable[str] | None = None,
    exclude: str | Iterable[str] | None = None,
    case: str = "smart",
    mode: str = "files",
    context_lines: int = 0,
    limit: int = 50,
    cursor: str | int | None = None,
    binary: str | None = None,
) -> dict[str, object]:
    """Search workspace content, paths, or both by invoking the Rust CLI."""

    if not isinstance(pattern, str):
        raise SearchArgumentError("pattern must be a string")
    normalised_target = normalize_target(target)
    if pattern == "" and normalised_target in {"content", "both"}:
        raise SearchPatternError("pattern must not be empty")
    root_set = normalize_search_roots(root)

    normalised_mode = normalize_mode(mode)
    if normalised_mode == "snippets" and normalised_target == "path":
        raise SearchArgumentError(
            "mode='snippets' is not supported for target='path'; "
            "use target='content' or target='both'"
        )
    normalised_path_scope = normalize_path_scope(path_scope)
    resolve_case(str(case or "smart").lower(), pattern)
    safe_limit = normalize_limit(limit)
    try:
        safe_context_lines = max(0, int(context_lines or 0))
    except (TypeError, ValueError) as exc:
        raise SearchArgumentError(
            "context_lines must be a non-negative integer"
        ) from exc
    glob_patterns = normalize_patterns(glob)
    exclude_patterns = normalize_patterns(exclude)

    executable = binary or find_rust_binary()
    if not executable:
        raise RustBackendUnavailable(
            f"Rust backend unavailable; set {ENV_BINARY} or build rust/ with cargo"
        )

    args = [
        executable,
        "--pattern",
        pattern,
        "--mode",
        normalised_mode,
        "--target",
        normalised_target,
        "--path-scope",
        normalised_path_scope,
        "--case",
        str(case or "smart"),
        "--limit",
        str(safe_limit),
        "--context-lines",
        str(safe_context_lines),
    ]
    for search_root in root_set.roots:
        args.extend(("--root", search_root.raw))
    if regex:
        args.append("--regex")
    if cursor not in (None, ""):
        args.extend(("--cursor", str(cursor)))
    _append_patterns(args, "--glob", glob_patterns)
    _append_patterns(args, "--exclude", exclude_patterns)

    try:
        completed = subprocess.run(
            args,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=60,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SearchBackendError(f"Rust backend failed: {exc}") from exc
    if completed.returncode != 0:
        message = (
            completed.stderr.strip()
            or completed.stdout.strip()
            or "Rust backend failed"
        )
        if "invalid regex" in message or "empty spans" in message:
            raise SearchPatternError(message)
        raise SearchBackendError(message)

    try:
        result = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise SearchBackendError("Rust backend returned invalid JSON") from exc

    if not isinstance(result, dict):
        raise SearchBackendError("Rust backend returned a non-object JSON response")

    result["backend"] = "rust"
    result["root"] = root_set.display
    return result
