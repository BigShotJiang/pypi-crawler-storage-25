"""Measure RTK grep output length against codetool-search API output.

This benchmark focuses on the RTK corpus and compares payloads for the same
search scenarios:

* ``rtk grep`` compact textual stdout;
* ``rg`` stdout;
* GNU ``grep`` stdout;
* ``codetool_search.search(..., result_format='text')`` raw text;
* ``codetool_search.search(..., result_format='full')`` JSON; and
* default ``codetool_search.search(...)`` compressed JSON.

The outputs are intentionally not semantically identical. The comparison is
useful because coding agents ultimately pay for output length in either
representation. Token counts use tiktoken when available.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = REPO_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from codetool_search import search  # noqa: E402

try:  # benchmark/reporting only; not a package runtime dependency
    import tiktoken  # type: ignore[import-not-found]  # noqa: E402
except Exception:  # pragma: no cover - depends on local benchmark env
    tiktoken = None  # type: ignore[assignment]

CORPUS = REPO_ROOT / "benchmarks" / "corpus" / "cython"

DEFAULT_EXCLUDES = (
    ".git/**",
    ".hg/**",
    ".svn/**",
    "node_modules/**",
    "target/**",
    "dist/**",
    "build/**",
    ".venv/**",
    "venv/**",
    "__pycache__/**",
    ".pytest_cache/**",
    ".mypy_cache/**",
    ".ruff_cache/**",
    ".cache/**",
    ".next/**",
    ".nuxt/**",
    ".vscode/**",
)

SCENARIOS: tuple[dict[str, Any], ...] = (
    {"name": "literal_files_error", "pattern": "error", "case": "smart", "mode": "files", "limit": 200},
    {"name": "insensitive_config_snippets", "pattern": "CONFIG", "case": "insensitive", "mode": "snippets", "context_lines": 1, "limit": 200},
    {"name": "rust_impl_files", "pattern": "impl", "case": "smart", "mode": "files", "glob": "*.rs", "limit": 200},
    {"name": "python_def_files", "pattern": "def ", "case": "smart", "mode": "files", "glob": "*.py", "limit": 200},
    {"name": "agent_docs_snippets", "pattern": "agent", "case": "insensitive", "mode": "snippets", "context_lines": 2, "limit": 200},
    {"name": "count_todo", "pattern": "TODO", "case": "insensitive", "mode": "count", "limit": 200},
    {"name": "no_match_probe", "pattern": "__codetool_search_no_match_probe__", "case": "sensitive", "mode": "snippets", "limit": 200},
)

_TOKENIZER = None


def tokenizer():
    global _TOKENIZER
    if tiktoken is None:
        return None
    if _TOKENIZER is None:
        _TOKENIZER = tiktoken.get_encoding("o200k_base")
    return _TOKENIZER


def byte_len(text: str) -> int:
    return len(text.encode("utf-8"))


def line_count(text: str) -> int:
    return 0 if text == "" else text.count("\n") + (0 if text.endswith("\n") else 1)


def token_len(text: str) -> int:
    enc = tokenizer()
    if enc is None:
        return max(1, round(len(text) / 4)) if text else 0
    return len(enc.encode(text))


def output_stats(text: str) -> dict[str, object]:
    return {
        "bytes": byte_len(text),
        "chars": len(text),
        "lines": line_count(text),
        "tokens": token_len(text),
        "approx_tokens_4chars": max(1, round(len(text) / 4)) if text else 0,
        "tokenizer": "tiktoken:o200k_base" if tokenizer() is not None else "approx_4chars",
    }


def apply_case(args: list[str], case: str) -> None:
    if case == "smart":
        args.append("--smart-case")
    elif case == "insensitive":
        args.append("--ignore-case")
    elif case == "sensitive":
        args.append("--case-sensitive")


def apply_grep_case(args: list[str], case: str, pattern: str) -> None:
    if case == "insensitive" or (
        case == "smart" and not any(ch.isupper() for ch in pattern)
    ):
        args.append("--ignore-case")


def append_globs(args: list[str], scenario: dict[str, Any]) -> None:
    for pattern in DEFAULT_EXCLUDES:
        args.extend(("--glob", f"!{pattern}"))
    if glob := scenario.get("glob"):
        args.extend(("--glob", str(glob)))
    exclude = scenario.get("exclude")
    if exclude:
        excludes = (exclude,) if isinstance(exclude, str) else tuple(exclude)
        for pattern in excludes:
            args.extend(("--glob", f"!{pattern}"))


def append_grep_exclude(args: list[str], pattern: str) -> None:
    if pattern.endswith("/**"):
        directory = pattern[:-3].rstrip("/")
        name = directory.rsplit("/", 1)[-1]
        if name:
            args.append(f"--exclude-dir={name}")
            return
    args.append(f"--exclude={pattern.rsplit('/', 1)[-1]}")


def append_grep_globs(args: list[str], scenario: dict[str, Any]) -> None:
    for pattern in DEFAULT_EXCLUDES:
        append_grep_exclude(args, pattern)
    if glob := scenario.get("glob"):
        args.append(f"--include={glob}")
    exclude = scenario.get("exclude")
    if exclude:
        excludes = (exclude,) if isinstance(exclude, str) else tuple(exclude)
        for pattern in excludes:
            append_grep_exclude(args, str(pattern))


def build_rg_command(root: Path, scenario: dict[str, Any]) -> list[str]:
    mode = str(scenario.get("mode", "files"))
    args = [
        "rg",
        "--fixed-strings",
        "--hidden",
        "--no-messages",
        "--color",
        "never",
    ]
    apply_case(args, str(scenario.get("case", "smart")))
    append_globs(args, scenario)
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        args.append("--count-matches")
    else:
        args.append("--line-number")
        if context := int(scenario.get("context_lines") or 0):
            args.extend(("--context", str(context)))
    args.extend((str(scenario["pattern"]), str(root)))
    return args


def build_grep_command(root: Path, scenario: dict[str, Any]) -> list[str]:
    mode = str(scenario.get("mode", "files"))
    pattern = str(scenario["pattern"])
    args = [
        "grep",
        "--recursive",
        "--fixed-strings",
        "--binary-files=without-match",
        "--with-filename",
    ]
    apply_grep_case(args, str(scenario.get("case", "smart")), pattern)
    append_grep_globs(args, scenario)
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        args.append("--only-matching")
    else:
        args.append("--line-number")
        if context := int(scenario.get("context_lines") or 0):
            args.extend(("--context", str(context)))
    args.extend((pattern, str(root)))
    return args


def build_rtk_command(root: Path, scenario: dict[str, Any]) -> list[str]:
    args = [
        "rtk",
        "grep",
        str(scenario["pattern"]),
        str(root),
        "--fixed-strings",
        "--hidden",
        "--no-messages",
        "--color",
        "never",
    ]
    apply_case(args, str(scenario.get("case", "smart")))
    append_globs(args, scenario)
    mode = str(scenario.get("mode", "files"))
    if mode == "files":
        args.append("--files-with-matches")
    elif mode == "count":
        args.append("--count-matches")
    else:
        args.append("--line-number")
        if context := int(scenario.get("context_lines") or 0):
            args.extend(("--context", str(context)))
    return args


def run_command_output(command: list[str], timeout: float) -> dict[str, Any]:
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": output_stats(completed.stdout),
        "stderr": output_stats(completed.stderr),
        "preview": completed.stdout[:500],
    }


def run_rg(root: Path, scenario: dict[str, Any], timeout: float) -> dict[str, Any]:
    return run_command_output(build_rg_command(root, scenario), timeout)


def run_grep(root: Path, scenario: dict[str, Any], timeout: float) -> dict[str, Any]:
    return run_command_output(build_grep_command(root, scenario), timeout)


def run_rtk(root: Path, scenario: dict[str, Any], timeout: float) -> dict[str, Any]:
    return run_command_output(build_rtk_command(root, scenario), timeout)


def common_kwargs(root: Path, scenario: dict[str, Any]) -> dict[str, Any]:
    kwargs: dict[str, Any] = {
        "root": str(root),
        "backend": "auto",
        "regex": bool(scenario.get("regex", False)),
        "case": str(scenario.get("case", "smart")),
        "mode": str(scenario.get("mode", "files")),
        "context_lines": int(scenario.get("context_lines") or 0),
        "limit": int(scenario.get("limit") or 200),
    }
    if glob := scenario.get("glob"):
        kwargs["glob"] = glob
    if exclude := scenario.get("exclude"):
        kwargs["exclude"] = exclude
    return kwargs


def run_codetool(root: Path, scenario: dict[str, Any]) -> dict[str, Any]:
    pattern = str(scenario["pattern"])
    kwargs = common_kwargs(root, scenario)
    compressed = search(pattern, **kwargs)
    full = search(pattern, **kwargs, result_format="full")
    raw_text = search(pattern, **kwargs, result_format="text")
    assert isinstance(raw_text, str)
    compressed_json = json.dumps(compressed, sort_keys=True, separators=(",", ":"))
    full_json = json.dumps(full, sort_keys=True, separators=(",", ":"))
    return {
        "raw_text": output_stats(raw_text),
        "default_compressed_json": output_stats(compressed_json),
        "full_json": output_stats(full_json),
        "no_match_output": raw_text if raw_text == "No Match" else None,
        "compressed_result": {
            "backend": compressed.get("backend"),
            "totals": compressed.get("totals"),
            "page": compressed.get("page"),
        },
        "full_result_summary": {
            "backend": full.get("backend"),
            "backend_requested": full.get("backend_requested"),
            "total_files": full.get("total_files"),
            "total_matches": full.get("total_matches"),
            "count": full.get("count"),
            "returned": full.get("returned"),
            "truncated": full.get("truncated"),
            "next_cursor": full.get("next_cursor"),
        },
    }


def pct_smaller(smaller: int, larger: int) -> float | None:
    if larger <= 0:
        return None
    return round(((larger - smaller) / larger) * 100, 2)


def ratio(numerator: int, denominator: int) -> float | None:
    if denominator <= 0:
        return None
    return round(numerator / denominator, 3)


def average(values: list[float | None]) -> float | None:
    numbers = [float(value) for value in values if isinstance(value, int | float)]
    if not numbers:
        return None
    return round(sum(numbers) / len(numbers), 3)


def discover_codetool_binary() -> str | None:
    env = os.environ.get("CODETOOL_SEARCH_RUST_BINARY")
    candidates = [
        Path(env).expanduser() if env else None,
        REPO_ROOT / "rust" / "target" / "release" / "codetool-search-rust",
        REPO_ROOT / "rust" / "target" / "debug" / "codetool-search-rust",
        Path(path) if (path := shutil.which("codetool-search-rust")) else None,
    ]
    for candidate in candidates:
        if candidate and candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=CORPUS)
    parser.add_argument("--output", type=Path, default=REPO_ROOT / "reports" / "rtk_vs_codetool_output_lengths.json")
    parser.add_argument("--timeout", type=float, default=120)
    parser.add_argument(
        "--update-readme",
        action="store_true",
        help="refresh README benchmark tables after writing --output",
    )
    args = parser.parse_args()

    if not args.root.is_dir():
        raise SystemExit(f"corpus not found: {args.root}")
    if not shutil.which("rg"):
        raise SystemExit("rg not found on PATH")
    if not shutil.which("grep"):
        raise SystemExit("grep not found on PATH")
    if not shutil.which("rtk"):
        raise SystemExit("rtk not found on PATH")
    codetool_binary = discover_codetool_binary()
    if codetool_binary:
        os.environ["CODETOOL_SEARCH_RUST_BINARY"] = codetool_binary

    rows: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        rg = run_rg(args.root, scenario, args.timeout)
        if rg["returncode"] not in {0, 1}:
            raise SystemExit(f"rg failed for {scenario['name']} with {rg['returncode']}")
        grep = run_grep(args.root, scenario, args.timeout)
        if grep["returncode"] not in {0, 1}:
            raise SystemExit(
                f"grep failed for {scenario['name']} with {grep['returncode']}"
            )
        rtk = run_rtk(args.root, scenario, args.timeout)
        if rtk["returncode"] not in {0, 1}:
            raise SystemExit(f"rtk failed for {scenario['name']} with {rtk['returncode']}")
        codetool = run_codetool(args.root, scenario)
        rg_bytes = int(rg["stdout"]["bytes"])
        grep_bytes = int(grep["stdout"]["bytes"])
        rtk_bytes = int(rtk["stdout"]["bytes"])
        raw_bytes = int(codetool["raw_text"]["bytes"])
        compressed_bytes = int(codetool["default_compressed_json"]["bytes"])
        full_bytes = int(codetool["full_json"]["bytes"])
        rg_tokens = int(rg["stdout"]["tokens"])
        grep_tokens = int(grep["stdout"]["tokens"])
        rtk_tokens = int(rtk["stdout"]["tokens"])
        raw_tokens = int(codetool["raw_text"]["tokens"])
        compressed_tokens = int(codetool["default_compressed_json"]["tokens"])
        full_tokens = int(codetool["full_json"]["tokens"])
        rows.append(
            {
                "scenario": scenario,
                "rg": rg,
                "grep": grep,
                "rtk_grep": rtk,
                "codetool_search": codetool,
                "comparison": {
                    "codetool_compressed_vs_full_percent_smaller": pct_smaller(compressed_bytes, full_bytes),
                    "codetool_raw_vs_full_tokens_percent_smaller": pct_smaller(raw_tokens, full_tokens),
                    "codetool_raw_vs_compressed_tokens_percent_smaller": pct_smaller(raw_tokens, compressed_tokens),
                    "codetool_raw_over_rtk_tokens_ratio": ratio(raw_tokens, rtk_tokens),
                    "codetool_raw_over_rg_tokens_ratio": ratio(raw_tokens, rg_tokens),
                    "codetool_raw_over_grep_tokens_ratio": ratio(raw_tokens, grep_tokens),
                    "codetool_raw_extra_tokens_over_rtk": raw_tokens - rtk_tokens if rtk_tokens else None,
                    "codetool_raw_extra_tokens_over_rg": raw_tokens - rg_tokens if rg_tokens else None,
                    "codetool_raw_extra_tokens_over_grep": raw_tokens - grep_tokens if grep_tokens else None,
                    "codetool_raw_extra_bytes_over_rtk": raw_bytes - rtk_bytes if rtk_bytes else None,
                    "codetool_raw_extra_bytes_over_rg": raw_bytes - rg_bytes if rg_bytes else None,
                    "codetool_raw_extra_bytes_over_grep": raw_bytes - grep_bytes if grep_bytes else None,
                    "rtk_vs_codetool_full_percent_smaller": pct_smaller(rtk_bytes, full_bytes),
                    "rtk_vs_codetool_compressed_percent_smaller": pct_smaller(rtk_bytes, compressed_bytes),
                    "codetool_compressed_over_rtk_ratio": ratio(compressed_bytes, rtk_bytes),
                    "codetool_full_over_rtk_ratio": ratio(full_bytes, rtk_bytes),
                    "compressed_extra_bytes_over_rtk": compressed_bytes - rtk_bytes,
                    "full_extra_bytes_over_rtk": full_bytes - rtk_bytes,
                },
            }
        )

    compressed_savings = [r["comparison"]["codetool_compressed_vs_full_percent_smaller"] for r in rows]
    rtk_vs_compressed = [r["comparison"]["rtk_vs_codetool_compressed_percent_smaller"] for r in rows]
    ratios = [r["comparison"]["codetool_compressed_over_rtk_ratio"] for r in rows]
    raw_ratios = [r["comparison"]["codetool_raw_over_rtk_tokens_ratio"] for r in rows]
    summary = {
        "root": str(args.root),
        "scenarios": len(rows),
        "codetool_binary": codetool_binary,
        "tokenizer": rows[0]["codetool_search"]["raw_text"]["tokenizer"] if rows else None,
        "rtk_note": "RTK grep emits compact text; codetool-search raw text omits structured metadata and prints No Match when empty.",
        "average_codetool_compressed_vs_full_percent_smaller": average(compressed_savings),
        "average_rtk_vs_codetool_compressed_percent_smaller": average(rtk_vs_compressed),
        "average_codetool_compressed_over_rtk_ratio": average(ratios),
        "average_codetool_raw_over_rtk_tokens_ratio": average(raw_ratios),
        "total_bytes": {
            "rg_stdout": sum(int(r["rg"]["stdout"]["bytes"]) for r in rows),
            "grep_stdout": sum(int(r["grep"]["stdout"]["bytes"]) for r in rows),
            "rtk_grep_stdout": sum(int(r["rtk_grep"]["stdout"]["bytes"]) for r in rows),
            "codetool_raw_text": sum(int(r["codetool_search"]["raw_text"]["bytes"]) for r in rows),
            "codetool_compressed_json": sum(int(r["codetool_search"]["default_compressed_json"]["bytes"]) for r in rows),
            "codetool_full_json": sum(int(r["codetool_search"]["full_json"]["bytes"]) for r in rows),
        },
        "total_tokens": {
            "rg_stdout": sum(int(r["rg"]["stdout"]["tokens"]) for r in rows),
            "grep_stdout": sum(int(r["grep"]["stdout"]["tokens"]) for r in rows),
            "rtk_grep_stdout": sum(int(r["rtk_grep"]["stdout"]["tokens"]) for r in rows),
            "codetool_raw_text": sum(int(r["codetool_search"]["raw_text"]["tokens"]) for r in rows),
            "codetool_compressed_json": sum(int(r["codetool_search"]["default_compressed_json"]["tokens"]) for r in rows),
            "codetool_full_json": sum(int(r["codetool_search"]["full_json"]["tokens"]) for r in rows),
        },
    }
    total = summary["total_bytes"]
    total_tokens = summary["total_tokens"]
    summary["total_comparison"] = {
        "codetool_compressed_vs_full_percent_smaller": pct_smaller(total["codetool_compressed_json"], total["codetool_full_json"]),
        "rtk_vs_codetool_compressed_percent_smaller": pct_smaller(total["rtk_grep_stdout"], total["codetool_compressed_json"]),
        "codetool_compressed_over_rtk_ratio": ratio(total["codetool_compressed_json"], total["rtk_grep_stdout"]),
        "codetool_full_over_rtk_ratio": ratio(total["codetool_full_json"], total["rtk_grep_stdout"]),
        "codetool_raw_vs_full_tokens_percent_smaller": pct_smaller(total_tokens["codetool_raw_text"], total_tokens["codetool_full_json"]),
        "codetool_raw_vs_compressed_tokens_percent_smaller": pct_smaller(total_tokens["codetool_raw_text"], total_tokens["codetool_compressed_json"]),
        "codetool_raw_over_rtk_tokens_ratio": ratio(total_tokens["codetool_raw_text"], total_tokens["rtk_grep_stdout"]),
        "codetool_raw_over_rg_tokens_ratio": ratio(total_tokens["codetool_raw_text"], total_tokens["rg_stdout"]),
        "codetool_raw_over_grep_tokens_ratio": ratio(total_tokens["codetool_raw_text"], total_tokens["grep_stdout"]),
    }
    result = {"summary": summary, "rows": rows}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.update_readme:
        updater = REPO_ROOT / "scripts" / "update_readme_benchmarks.py"
        subprocess.run(
            [
                sys.executable,
                str(updater),
                "--tokens",
                str(args.output),
            ],
            check=True,
        )
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
