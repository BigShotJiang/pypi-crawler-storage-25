use std::path::PathBuf;

#[derive(Debug, Clone)]
pub(crate) struct CandidateFile {
    pub(crate) path: PathBuf,
    pub(crate) rel_path: String,
    pub(crate) size: u64,
}

#[derive(Debug, Clone)]
pub(crate) struct FileMatch {
    pub(crate) path: String,
    pub(crate) count: usize,
    pub(crate) first_line: usize,
    pub(crate) kind: Option<&'static str>,
    pub(crate) match_kind: Option<&'static str>,
}

#[derive(Debug, Clone)]
pub(crate) struct ContextLine {
    pub(crate) line: usize,
    pub(crate) text: String,
}

#[derive(Debug, Clone)]
pub(crate) struct SnippetMatch {
    pub(crate) path: String,
    pub(crate) line: usize,
    pub(crate) snippet: String,
    pub(crate) context: Vec<ContextLine>,
    pub(crate) kind: Option<&'static str>,
    pub(crate) match_kind: Option<&'static str>,
}

#[derive(Debug, Default)]
pub(crate) struct Skipped {
    pub(crate) binary: usize,
    pub(crate) huge: usize,
    pub(crate) errors: usize,
}

#[derive(Debug)]
pub(crate) struct SearchResult {
    pub(crate) file_matches: Vec<FileMatch>,
    pub(crate) snippet_matches: Vec<SnippetMatch>,
    pub(crate) scanned_files: usize,
    pub(crate) scanned_bytes: u64,
    pub(crate) skipped: Skipped,
    pub(crate) effective_case: String,
}
