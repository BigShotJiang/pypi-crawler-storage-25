use std::env;
use std::ffi::{OsStr, OsString};
use std::path::{Component, Path, PathBuf};

use caseless::default_case_fold_str;

pub(crate) fn relative_path(path: &Path, root: &Path) -> String {
    let rel =
        strip_prefix_for_platform(path, root, cfg!(windows)).unwrap_or_else(|| path.to_path_buf());
    normalize_relpath(&rel.to_string_lossy())
}

fn strip_prefix_for_platform(path: &Path, root: &Path, windows: bool) -> Option<PathBuf> {
    if !windows {
        return path.strip_prefix(root).ok().map(Path::to_path_buf);
    }

    let path_parts = path
        .components()
        .map(|component| component.as_os_str().to_os_string())
        .collect::<Vec<OsString>>();
    let root_parts = root
        .components()
        .map(|component| component.as_os_str().to_os_string())
        .collect::<Vec<OsString>>();

    if root_parts.len() > path_parts.len() {
        return None;
    }
    if !root_parts
        .iter()
        .zip(path_parts.iter())
        .all(|(left, right)| {
            default_case_fold_str(left.to_string_lossy().as_ref())
                == default_case_fold_str(right.to_string_lossy().as_ref())
        })
    {
        return None;
    }

    let mut out = PathBuf::new();
    for component in path_parts.into_iter().skip(root_parts.len()) {
        out.push(component);
    }
    Some(out)
}

pub(crate) fn normalize_relpath(path: &str) -> String {
    let mut out = path.replace('\\', "/");
    while out.starts_with("./") {
        out = out[2..].to_string();
    }
    if out == "." {
        String::new()
    } else {
        out
    }
}

pub(crate) fn absolute_path(path: &Path) -> PathBuf {
    let joined = if path.is_absolute() {
        path.to_path_buf()
    } else {
        env::current_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .join(path)
    };
    normalize_path(&joined)
}

fn normalize_path(path: &Path) -> PathBuf {
    let mut out = PathBuf::new();
    for component in path.components() {
        match component {
            Component::CurDir => {}
            Component::ParentDir => {
                out.pop();
            }
            Component::Prefix(_) | Component::RootDir | Component::Normal(_) => {
                out.push(component.as_os_str());
            }
        }
    }
    if out.as_os_str().is_empty() {
        PathBuf::from(".")
    } else {
        out
    }
}

pub(crate) fn basename(path: &str) -> &str {
    path.rsplit('/').next().unwrap_or(path)
}

pub(crate) fn extension(path: &str) -> &str {
    Path::new(basename(path))
        .extension()
        .and_then(OsStr::to_str)
        .unwrap_or("")
}

#[cfg(test)]
mod tests {
    use super::strip_prefix_for_platform;
    use std::path::Path;

    #[test]
    fn windows_strip_prefix_is_case_insensitive() {
        let stripped =
            strip_prefix_for_platform(Path::new("/Repo/src/file.txt"), Path::new("/repo"), true)
                .expect("prefix should match case-insensitively");

        assert_eq!(stripped, Path::new("src/file.txt"));
    }

    #[test]
    fn non_windows_strip_prefix_is_case_sensitive() {
        assert!(strip_prefix_for_platform(
            Path::new("/Repo/src/file.txt"),
            Path::new("/repo"),
            false,
        )
        .is_none());
    }
}
