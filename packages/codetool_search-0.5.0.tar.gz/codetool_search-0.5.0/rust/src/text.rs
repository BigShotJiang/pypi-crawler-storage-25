use std::cmp::min;

use memchr::{memchr, memchr_iter, memrchr};

use crate::constants::MAX_SNIPPET_CHARS;
use crate::models::ContextLine;

pub(crate) struct LineTracker<'a> {
    data: &'a [u8],
    line_number: usize,
    line_start: usize,
    next_newline: Option<usize>,
}

impl<'a> LineTracker<'a> {
    pub(crate) fn new(data: &'a [u8]) -> LineTracker<'a> {
        LineTracker {
            data,
            line_number: 1,
            line_start: 0,
            next_newline: memchr(b'\n', data),
        }
    }

    pub(crate) fn advance_to(&mut self, offset: usize) {
        while let Some(newline) = self.next_newline {
            if newline >= offset {
                break;
            }
            self.line_number += 1;
            self.line_start = newline + 1;
            self.next_newline =
                memchr(b'\n', &self.data[self.line_start..]).map(|index| self.line_start + index);
        }
    }

    pub(crate) fn line_number(&self) -> usize {
        self.line_number
    }

    pub(crate) fn line_start(&self) -> usize {
        self.line_start
    }

    pub(crate) fn line_end(&self) -> usize {
        self.next_newline.unwrap_or(self.data.len())
    }
}

pub(crate) fn line_number_for_offset(data: &[u8], offset: usize) -> usize {
    memchr_iter(b'\n', &data[..min(offset, data.len())]).count() + 1
}

pub(crate) fn context_for_offsets(
    data: &[u8],
    line_start: usize,
    line_number: usize,
    context_lines: usize,
) -> Vec<ContextLine> {
    if context_lines == 0 {
        return Vec::new();
    }

    let mut starts: Vec<(usize, usize)> = Vec::with_capacity(context_lines * 2 + 1);
    let mut previous_start = line_start;
    let mut previous_number = line_number;
    for _ in 0..context_lines {
        if previous_start == 0 {
            break;
        }
        let search_end = previous_start.saturating_sub(1);
        let start = memrchr(b'\n', &data[..search_end]).map_or(0, |index| index + 1);
        previous_number = previous_number.saturating_sub(1);
        previous_start = start;
        starts.push((previous_number, previous_start));
    }
    starts.reverse();
    starts.push((line_number, line_start));

    let mut next_start = line_end_from_start(data, line_start);
    if next_start < data.len() {
        next_start += 1;
    }
    let mut next_number = line_number + 1;
    for _ in 0..context_lines {
        if next_start >= data.len() {
            break;
        }
        starts.push((next_number, next_start));
        next_start = line_end_from_start(data, next_start);
        if next_start < data.len() {
            next_start += 1;
        }
        next_number += 1;
    }

    starts
        .into_iter()
        .map(|(line, start)| {
            let end = line_end_from_start(data, start);
            ContextLine {
                line,
                text: crop(&decode_line(&data[start..end])),
            }
        })
        .collect()
}

pub(crate) fn context_for_text_lines(
    lines: &[&str],
    line_index: usize,
    context_lines: usize,
) -> Vec<ContextLine> {
    if context_lines == 0 {
        return Vec::new();
    }
    let start = line_index.saturating_sub(context_lines);
    let end = min(lines.len(), line_index + context_lines + 1);
    (start..end)
        .map(|index| ContextLine {
            line: index + 1,
            text: crop(lines[index]),
        })
        .collect()
}

fn line_end_from_start(data: &[u8], start: usize) -> usize {
    memchr(b'\n', &data[start..]).map_or(data.len(), |index| start + index)
}

pub(crate) fn bytes_eq_ascii_insensitive(haystack: &[u8], lower_needle: &[u8]) -> bool {
    haystack
        .iter()
        .zip(lower_needle.iter())
        .all(|(candidate, needle)| ascii_lower(*candidate) == *needle)
}

pub(crate) fn ascii_lower(byte: u8) -> u8 {
    if byte.is_ascii_uppercase() {
        byte + 32
    } else {
        byte
    }
}

pub(crate) fn decode_line(line: &[u8]) -> String {
    let without_cr = if line.ends_with(b"\r") {
        &line[..line.len().saturating_sub(1)]
    } else {
        line
    };
    String::from_utf8_lossy(without_cr).to_string()
}

pub(crate) fn crop(text: &str) -> String {
    let compact = text.replace('\t', " ").trim().to_string();
    if compact.chars().count() <= MAX_SNIPPET_CHARS {
        return compact;
    }
    let mut out: String = compact.chars().take(MAX_SNIPPET_CHARS - 1).collect();
    out = out.trim_end().to_string();
    out.push('…');
    out
}
