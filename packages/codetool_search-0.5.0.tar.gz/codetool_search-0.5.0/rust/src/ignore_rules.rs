use std::fs;
use std::path::Path;

use crate::constants::{COMMON_IGNORED_DIRS, COMMON_IGNORED_FILES};
use crate::path_utils::{basename, normalize_relpath};

#[derive(Clone, Debug, Default)]
pub(crate) struct IgnorePatterns {
    pub(crate) common: Vec<String>,
    pub(crate) root: Vec<String>,
}

pub(crate) fn load_ignore_patterns(root: &Path) -> Vec<String> {
    let mut patterns = Vec::new();
    for filename in [".pbiignore", ".gitignore"] {
        let path = root.join(filename);
        let Ok(content) = fs::read_to_string(path) else {
            continue;
        };
        for line in content.lines() {
            let text = line.trim();
            if text.is_empty() || text.starts_with('#') || text.starts_with('!') {
                continue;
            }
            let mut normalised = normalize_relpath(text);
            if normalised.ends_with('/') {
                normalised = normalised.trim_end_matches('/').to_string();
                patterns.push(normalised.clone());
                patterns.push(format!("{normalised}/**"));
            } else {
                patterns.push(normalised);
            }
        }
    }
    patterns
}

pub(crate) fn should_ignore_path_with_common_rel(
    rel_path: &str,
    common_rel_path: &str,
    is_dir: bool,
    excludes: &[String],
    ignores: &[String],
    root_ignores: &[String],
) -> bool {
    let name = basename(common_rel_path);
    if is_dir {
        if is_common_ignored_dir(name)
            || common_rel_path
                .split('/')
                .filter(|segment| !segment.is_empty())
                .any(is_common_ignored_dir)
        {
            return true;
        }
    } else if is_common_ignored_file(name) {
        return true;
    }

    if excludes
        .iter()
        .chain(ignores.iter())
        .any(|pattern| path_matches_pattern(rel_path, pattern))
    {
        return true;
    }

    root_ignores
        .iter()
        .any(|pattern| path_matches_pattern(common_rel_path, pattern))
}

pub(crate) fn is_common_ignored_dir(name: &str) -> bool {
    COMMON_IGNORED_DIRS.contains(&name)
}

fn is_common_ignored_file(name: &str) -> bool {
    COMMON_IGNORED_FILES.contains(&name)
}

pub(crate) fn matches_glob(rel_path: &str, globs: &[String]) -> bool {
    if globs.is_empty() {
        return true;
    }
    let base = basename(rel_path);
    globs.iter().any(|pattern| {
        if let Some(suffix) = simple_basename_suffix_glob(pattern) {
            base.ends_with(suffix)
        } else {
            path_matches_pattern(rel_path, pattern)
        }
    })
}

fn simple_basename_suffix_glob(pattern: &str) -> Option<&str> {
    let suffix = pattern.strip_prefix('*')?;
    if suffix.is_empty()
        || suffix.contains('/')
        || suffix.contains('*')
        || suffix.contains('?')
        || suffix.contains('[')
        || suffix.contains(']')
    {
        return None;
    }
    Some(suffix)
}

pub(crate) fn path_matches_pattern(rel_path: &str, pattern: &str) -> bool {
    if pattern.is_empty() {
        return false;
    }
    let base = basename(rel_path);

    if wildcard_match(pattern, rel_path) || wildcard_match(pattern, base) {
        return true;
    }

    if !pattern.contains('/') && rel_path.split('/').any(|segment| segment == pattern) {
        return true;
    }

    let prefix = pattern.strip_suffix("/**").unwrap_or(pattern);
    let prefix = prefix.trim_end_matches('/');
    !prefix.is_empty()
        && (rel_path == prefix
            || (rel_path.starts_with(prefix)
                && rel_path.as_bytes().get(prefix.len()) == Some(&b'/')))
}

pub(crate) fn pattern_targets_path_or_descendant(path: &str, pattern: &str) -> bool {
    let path = normalize_relpath(path).trim_matches('/').to_string();
    let pattern = normalize_relpath(pattern).trim_matches('/').to_string();
    if path.is_empty() || pattern.is_empty() {
        return false;
    }
    path_matches_pattern(&path, &pattern) || pattern.starts_with(&format!("{path}/"))
}

fn wildcard_match(pattern: &str, text: &str) -> bool {
    let pattern = pattern.as_bytes();
    let text = text.as_bytes();
    let (mut p, mut t) = (0usize, 0usize);
    let mut star: Option<usize> = None;
    let mut match_index = 0usize;

    while t < text.len() {
        if p < pattern.len() && (pattern[p] == b'?' || pattern[p] == text[t]) {
            p += 1;
            t += 1;
        } else if p < pattern.len() && pattern[p] == b'*' {
            star = Some(p);
            match_index = t;
            p += 1;
        } else if let Some(star_index) = star {
            p = star_index + 1;
            match_index += 1;
            t = match_index;
        } else {
            return false;
        }
    }

    while p < pattern.len() && pattern[p] == b'*' {
        p += 1;
    }
    p == pattern.len()
}
