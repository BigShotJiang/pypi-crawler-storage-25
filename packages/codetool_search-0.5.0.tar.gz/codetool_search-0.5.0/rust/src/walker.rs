use std::collections::HashSet;
use std::env;
use std::fs;
use std::path::Path;
use std::sync::atomic::Ordering;
use std::sync::{Arc, Mutex};

use ignore::overrides::OverrideBuilder;
use ignore::{DirEntry, ParallelVisitor, ParallelVisitorBuilder, WalkBuilder, WalkState};

use crate::config::Config;
use crate::constants::{COMMON_IGNORED_DIRS, COMMON_IGNORED_FILES, MAX_FILE_BYTES};
use crate::file_search::{search_file_with_buffer, SearchFileError};
use crate::ignore_rules::{
    is_common_ignored_dir, load_ignore_patterns, matches_glob, pattern_targets_path_or_descendant,
    should_ignore_path_with_common_rel, IgnorePatterns,
};
use crate::matcher::{PathMatcher, SearchMatcher};
use crate::models::{CandidateFile, FileMatch, SnippetMatch};
use crate::path_utils::relative_path;
use crate::search::{lock_collections, SearchCollections, SearchCounters};

type SeenPaths = Option<Arc<Mutex<HashSet<String>>>>;
const SMALL_TREE_FILE_THRESHOLD: usize = 128;

pub(crate) fn walk_and_search_parallel(
    config: &Config,
    content_matcher: Option<&SearchMatcher>,
    path_matcher: Option<&PathMatcher>,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
) {
    let seen_paths = if config.roots.len() > 1 {
        Some(Arc::new(Mutex::new(HashSet::new())))
    } else {
        None
    };
    for root in &config.roots {
        walk_and_search_root(
            config,
            root,
            content_matcher,
            path_matcher,
            collect_snippets,
            Arc::clone(&counters),
            Arc::clone(&collections),
            seen_paths.clone(),
        );
    }
}

fn walk_and_search_root(
    config: &Config,
    root: &Path,
    content_matcher: Option<&SearchMatcher>,
    path_matcher: Option<&PathMatcher>,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
    seen_paths: SeenPaths,
) {
    if root.is_file() {
        search_single_root_file(
            config,
            root,
            content_matcher,
            path_matcher,
            collect_snippets,
            counters,
            collections,
            seen_paths,
        );
        return;
    }

    if is_small_tree(root, SMALL_TREE_FILE_THRESHOLD) {
        walk_and_search_sequential(
            config,
            root,
            content_matcher,
            path_matcher,
            collect_snippets,
            counters,
            collections,
            seen_paths,
        );
        return;
    }

    let rel_base = rel_base_for_root(config, root);
    let ignore_patterns = ignore_patterns_for_root(config, root);

    let mut builder = WalkBuilder::new(root);
    builder
        .standard_filters(false)
        .follow_links(false)
        .threads(worker_threads());
    let overrides = if config.rel_base.is_none() {
        build_walk_overrides(root, &config.globs, &config.excludes, &ignore_patterns.root)
    } else {
        None
    };
    if let Some(overrides) = overrides {
        builder.overrides(overrides);
    } else {
        let rel_base_for_filter = Arc::new(rel_base.to_path_buf());
        let globs_for_filter = Arc::new(config.globs.clone());
        let excludes_for_filter = Arc::new(config.excludes.clone());
        let common_ignores_for_filter = Arc::new(ignore_patterns.common);
        let root_ignores_for_filter = Arc::new(ignore_patterns.root);
        let root_for_filter = Arc::new(root.to_path_buf());
        builder.filter_entry(move |entry| {
            keep_walk_entry(
                entry,
                &rel_base_for_filter,
                &globs_for_filter,
                &excludes_for_filter,
                &common_ignores_for_filter,
                &root_ignores_for_filter,
                root_for_filter.as_path(),
            )
        });
    }

    let mut visitor_builder = SearchVisitorBuilder {
        rel_base,
        content_matcher,
        path_matcher,
        path_scope: &config.path_scope,
        mode: &config.mode,
        target: &config.target,
        context_lines: config.context_lines,
        collect_snippets,
        counters,
        collections,
        seen_paths,
    };
    builder.build_parallel().visit(&mut visitor_builder);
}

fn walk_and_search_sequential(
    config: &Config,
    root: &Path,
    content_matcher: Option<&SearchMatcher>,
    path_matcher: Option<&PathMatcher>,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
    seen_paths: SeenPaths,
) {
    let rel_base = rel_base_for_root(config, root);
    let ignore_patterns = ignore_patterns_for_root(config, root);
    // Tiny repositories are dominated by thread-pool and cross-thread handoff
    // overhead. A simple depth-first scan keeps startup latency competitive
    // while the parallel path carries large repositories.
    let mut stack = vec![root.to_path_buf()];
    let mut local = SearchCollections::default();
    let mut buffer = Vec::new();

    while let Some(current) = stack.pop() {
        let Ok(entries) = fs::read_dir(&current) else {
            continue;
        };
        for entry in entries.flatten() {
            let Ok(file_type) = entry.file_type() else {
                continue;
            };
            let path = entry.path();
            let rel_path = relative_path(&path, rel_base);
            let common_rel_path = if config.rel_base.is_some() {
                relative_path(&path, root)
            } else {
                rel_path.clone()
            };
            if file_type.is_dir() {
                if should_ignore_path_with_common_rel(
                    &rel_path,
                    &common_rel_path,
                    true,
                    &config.excludes,
                    &ignore_patterns.common,
                    &ignore_patterns.root,
                ) {
                    continue;
                }
                stack.push(path);
                continue;
            }
            if !file_type.is_file()
                || should_ignore_path_with_common_rel(
                    &rel_path,
                    &common_rel_path,
                    false,
                    &config.excludes,
                    &ignore_patterns.common,
                    &ignore_patterns.root,
                )
                || !matches_glob(&rel_path, &config.globs)
            {
                continue;
            }
            if !claim_candidate_path(&path, &seen_paths) {
                continue;
            }

            let Ok(metadata) = entry.metadata() else {
                continue;
            };
            let size = metadata.len();
            let path_matches =
                path_matcher.is_some_and(|matcher| matcher.is_match(&rel_path, &config.path_scope));
            let content_enabled = content_matcher.is_some();

            if !content_enabled {
                counters.scanned_files.fetch_add(1, Ordering::Relaxed);
                if path_matches {
                    push_path_only_match(
                        &mut local.file_matches,
                        &mut local.snippet_matches,
                        rel_path,
                        &config.mode,
                        false,
                    );
                }
                continue;
            }

            if size > MAX_FILE_BYTES {
                if config.target == "both" && path_matches {
                    push_path_only_match(
                        &mut local.file_matches,
                        &mut local.snippet_matches,
                        rel_path,
                        &config.mode,
                        collect_snippets,
                    );
                }
                counters.skipped_huge.fetch_add(1, Ordering::Relaxed);
                continue;
            }

            counters.scanned_files.fetch_add(1, Ordering::Relaxed);
            counters.scanned_bytes.fetch_add(size, Ordering::Relaxed);
            let candidate = CandidateFile {
                path,
                rel_path,
                size,
            };
            let matcher = content_matcher.expect("content matcher exists");
            match search_file_with_buffer(
                &candidate,
                matcher,
                config.context_lines,
                collect_snippets,
                &mut buffer,
            ) {
                Ok(Some((mut file_match, mut snippets))) => {
                    mark_content_match(&mut file_match, config.target.as_str(), path_matches);
                    mark_snippet_matches(&mut snippets, config.target.as_str(), path_matches);
                    local.file_matches.push(file_match);
                    local.snippet_matches.extend(snippets);
                }
                Ok(None) => {
                    if config.target == "both" && path_matches {
                        push_path_only_match(
                            &mut local.file_matches,
                            &mut local.snippet_matches,
                            candidate.rel_path,
                            &config.mode,
                            collect_snippets,
                        );
                    }
                }
                Err(SearchFileError::Binary) => {
                    if config.target == "both" && path_matches {
                        push_path_only_match(
                            &mut local.file_matches,
                            &mut local.snippet_matches,
                            candidate.rel_path,
                            &config.mode,
                            collect_snippets,
                        );
                    }
                    counters.skipped_binary.fetch_add(1, Ordering::Relaxed);
                }
                Err(SearchFileError::Io) => {
                    if config.target == "both" && path_matches {
                        push_path_only_match(
                            &mut local.file_matches,
                            &mut local.snippet_matches,
                            candidate.rel_path,
                            &config.mode,
                            collect_snippets,
                        );
                    }
                    counters.skipped_errors.fetch_add(1, Ordering::Relaxed);
                }
            }
        }
    }

    let mut output = lock_collections(&collections);
    output.file_matches.append(&mut local.file_matches);
    output.snippet_matches.append(&mut local.snippet_matches);
}

fn rel_base_for_root<'a>(config: &'a Config, root: &'a Path) -> &'a Path {
    config.rel_base.as_deref().unwrap_or(root)
}

fn ignore_patterns_for_root(config: &Config, root: &Path) -> IgnorePatterns {
    ignore_patterns_for_filter_root(config, root)
}

fn ignore_patterns_for_filter_root(config: &Config, filter_root: &Path) -> IgnorePatterns {
    let Some(rel_base) = config.rel_base.as_deref() else {
        return IgnorePatterns {
            common: Vec::new(),
            root: load_ignore_patterns(filter_root),
        };
    };

    let root_prefix = relative_path(filter_root, rel_base);
    let mut patterns = if rel_base.is_dir() {
        load_ignore_patterns(rel_base)
            .into_iter()
            .filter(|pattern| !pattern_targets_path_or_descendant(&root_prefix, pattern))
            .collect()
    } else {
        Vec::new()
    };
    patterns.sort();
    patterns.dedup();
    let mut root_patterns = load_ignore_patterns(filter_root);
    root_patterns.sort();
    root_patterns.dedup();
    IgnorePatterns {
        common: patterns,
        root: root_patterns,
    }
}

fn claim_candidate_path(path: &Path, seen_paths: &SeenPaths) -> bool {
    let Some(seen_paths) = seen_paths else {
        return true;
    };
    let mut seen = seen_paths
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    seen.insert(dedup_key(path))
}

fn dedup_key(path: &Path) -> String {
    #[cfg(windows)]
    {
        path.to_string_lossy().replace('\\', "/").to_lowercase()
    }
    #[cfg(not(windows))]
    {
        path.to_string_lossy().to_string()
    }
}

fn search_single_root_file(
    config: &Config,
    root: &Path,
    content_matcher: Option<&SearchMatcher>,
    path_matcher: Option<&PathMatcher>,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
    seen_paths: SeenPaths,
) {
    let filter_root = root
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let rel_base = config.rel_base.as_deref().unwrap_or(filter_root);
    let rel_path = relative_path(root, rel_base);
    let common_rel_path = relative_path(root, filter_root);
    let ignore_patterns = ignore_patterns_for_filter_root(config, filter_root);
    if should_ignore_path_with_common_rel(
        &rel_path,
        &common_rel_path,
        false,
        &config.excludes,
        &ignore_patterns.common,
        &ignore_patterns.root,
    ) || !matches_glob(&rel_path, &config.globs)
    {
        return;
    }
    if !claim_candidate_path(root, &seen_paths) {
        return;
    }

    let path_matches =
        path_matcher.is_some_and(|matcher| matcher.is_match(&rel_path, &config.path_scope));
    if content_matcher.is_none() {
        counters.scanned_files.fetch_add(1, Ordering::Relaxed);
        if path_matches {
            let mut output = lock_collections(&collections);
            let output = &mut *output;
            push_path_only_match(
                &mut output.file_matches,
                &mut output.snippet_matches,
                rel_path,
                &config.mode,
                false,
            );
        }
        return;
    }

    let Ok(metadata) = fs::metadata(root) else {
        counters.skipped_errors.fetch_add(1, Ordering::Relaxed);
        return;
    };
    let size = metadata.len();
    if size > MAX_FILE_BYTES {
        if config.target == "both" && path_matches {
            let mut output = lock_collections(&collections);
            let output = &mut *output;
            push_path_only_match(
                &mut output.file_matches,
                &mut output.snippet_matches,
                rel_path,
                &config.mode,
                collect_snippets,
            );
        }
        counters.skipped_huge.fetch_add(1, Ordering::Relaxed);
        return;
    }

    counters.scanned_files.fetch_add(1, Ordering::Relaxed);
    counters.scanned_bytes.fetch_add(size, Ordering::Relaxed);
    let candidate = CandidateFile {
        path: root.to_path_buf(),
        rel_path,
        size,
    };
    let mut buffer = Vec::new();
    let matcher = content_matcher.expect("content matcher exists");
    match search_file_with_buffer(
        &candidate,
        matcher,
        config.context_lines,
        collect_snippets,
        &mut buffer,
    ) {
        Ok(Some((mut file_match, mut snippets))) => {
            let mut output = lock_collections(&collections);
            mark_content_match(&mut file_match, config.target.as_str(), path_matches);
            mark_snippet_matches(&mut snippets, config.target.as_str(), path_matches);
            output.file_matches.push(file_match);
            output.snippet_matches.extend(snippets);
        }
        Ok(None) => {
            if config.target == "both" && path_matches {
                let mut output = lock_collections(&collections);
                let output = &mut *output;
                push_path_only_match(
                    &mut output.file_matches,
                    &mut output.snippet_matches,
                    candidate.rel_path,
                    &config.mode,
                    collect_snippets,
                );
            }
        }
        Err(SearchFileError::Binary) => {
            if config.target == "both" && path_matches {
                let mut output = lock_collections(&collections);
                let output = &mut *output;
                push_path_only_match(
                    &mut output.file_matches,
                    &mut output.snippet_matches,
                    candidate.rel_path,
                    &config.mode,
                    collect_snippets,
                );
            }
            counters.skipped_binary.fetch_add(1, Ordering::Relaxed);
        }
        Err(SearchFileError::Io) => {
            if config.target == "both" && path_matches {
                let mut output = lock_collections(&collections);
                let output = &mut *output;
                push_path_only_match(
                    &mut output.file_matches,
                    &mut output.snippet_matches,
                    candidate.rel_path,
                    &config.mode,
                    collect_snippets,
                );
            }
            counters.skipped_errors.fetch_add(1, Ordering::Relaxed);
        }
    }
}

fn path_file_match(rel_path: String, _mode: &str) -> FileMatch {
    FileMatch {
        path: rel_path,
        count: 1,
        first_line: 0,
        kind: Some("file"),
        match_kind: Some("path"),
    }
}

fn path_snippet_match(rel_path: String) -> SnippetMatch {
    SnippetMatch {
        path: rel_path,
        line: 0,
        snippet: String::new(),
        context: Vec::new(),
        kind: Some("file"),
        match_kind: Some("path"),
    }
}

fn push_path_only_match(
    file_matches: &mut Vec<FileMatch>,
    snippet_matches: &mut Vec<SnippetMatch>,
    rel_path: String,
    mode: &str,
    include_snippet: bool,
) {
    file_matches.push(path_file_match(rel_path.clone(), mode));
    if include_snippet {
        snippet_matches.push(path_snippet_match(rel_path));
    }
}

fn mark_content_match(file_match: &mut FileMatch, target: &str, path_matches: bool) {
    if target != "both" {
        return;
    }
    file_match.kind = Some("file");
    file_match.match_kind = Some(if path_matches { "both" } else { "content" });
}

fn mark_snippet_matches(snippets: &mut [SnippetMatch], target: &str, path_matches: bool) {
    if target != "both" {
        return;
    }
    let match_kind = if path_matches { "both" } else { "content" };
    for snippet in snippets {
        snippet.kind = Some("file");
        snippet.match_kind = Some(match_kind);
    }
}

fn worker_threads() -> usize {
    if let Ok(value) = env::var("CODETOOL_SEARCH_THREADS") {
        if let Ok(parsed) = value.parse::<usize>() {
            if parsed > 0 {
                return parsed;
            }
        }
    }
    std::thread::available_parallelism().map_or(1, |count| count.get().min(8))
}

/// Cheap preflight used only to pick the traversal strategy.
fn is_small_tree(root: &Path, file_threshold: usize) -> bool {
    let mut files = 0usize;
    let mut stack = vec![root.to_path_buf()];
    while let Some(current) = stack.pop() {
        let Ok(entries) = fs::read_dir(&current) else {
            continue;
        };
        for entry in entries.flatten() {
            let Ok(file_type) = entry.file_type() else {
                continue;
            };
            if file_type.is_dir() {
                if is_common_ignored_dir(&entry.file_name().to_string_lossy()) {
                    continue;
                }
                stack.push(entry.path());
            } else if file_type.is_file() {
                files += 1;
                if files > file_threshold {
                    return false;
                }
            }
        }
    }
    true
}

fn build_walk_overrides(
    root: &Path,
    globs: &[String],
    excludes: &[String],
    ignores: &[String],
) -> Option<ignore::overrides::Override> {
    let mut builder = OverrideBuilder::new(root);
    builder.allow_unclosed_class(true);

    for pattern in globs {
        builder.add(pattern).ok()?;
    }
    for pattern in excludes {
        builder.add(&format!("!{pattern}")).ok()?;
    }
    for pattern in ignores {
        builder.add(&format!("!{pattern}")).ok()?;
    }
    for dir in COMMON_IGNORED_DIRS {
        builder.add(&format!("!{dir}")).ok()?;
        builder.add(&format!("!{dir}/**")).ok()?;
        builder.add(&format!("!**/{dir}")).ok()?;
        builder.add(&format!("!**/{dir}/**")).ok()?;
    }
    for file in COMMON_IGNORED_FILES {
        builder.add(&format!("!{file}")).ok()?;
        builder.add(&format!("!**/{file}")).ok()?;
    }

    builder.build().ok()
}

fn keep_walk_entry(
    entry: &DirEntry,
    rel_base: &Path,
    globs: &[String],
    excludes: &[String],
    ignores: &[String],
    root_ignores: &[String],
    root: &Path,
) -> bool {
    let Some(file_type) = entry.file_type() else {
        return false;
    };
    let rel_path = relative_path(entry.path(), rel_base);
    let common_rel_path = relative_path(entry.path(), root);
    if file_type.is_dir() {
        !should_ignore_path_with_common_rel(
            &rel_path,
            &common_rel_path,
            true,
            excludes,
            ignores,
            root_ignores,
        )
    } else if file_type.is_file() {
        !should_ignore_path_with_common_rel(
            &rel_path,
            &common_rel_path,
            false,
            excludes,
            ignores,
            root_ignores,
        ) && matches_glob(&rel_path, globs)
    } else {
        false
    }
}

struct SearchVisitorBuilder<'a> {
    rel_base: &'a Path,
    content_matcher: Option<&'a SearchMatcher>,
    path_matcher: Option<&'a PathMatcher>,
    path_scope: &'a str,
    mode: &'a str,
    target: &'a str,
    context_lines: usize,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
    seen_paths: SeenPaths,
}

impl<'a> ParallelVisitorBuilder<'a> for SearchVisitorBuilder<'a> {
    fn build(&mut self) -> Box<dyn ParallelVisitor + 'a> {
        Box::new(SearchVisitor {
            rel_base: self.rel_base,
            content_matcher: self.content_matcher,
            path_matcher: self.path_matcher,
            path_scope: self.path_scope,
            mode: self.mode,
            target: self.target,
            context_lines: self.context_lines,
            collect_snippets: self.collect_snippets,
            counters: Arc::clone(&self.counters),
            collections: Arc::clone(&self.collections),
            seen_paths: self.seen_paths.clone(),
            file_matches: Vec::new(),
            snippet_matches: Vec::new(),
            buffer: Vec::new(),
        })
    }
}

struct SearchVisitor<'a> {
    rel_base: &'a Path,
    content_matcher: Option<&'a SearchMatcher>,
    path_matcher: Option<&'a PathMatcher>,
    path_scope: &'a str,
    mode: &'a str,
    target: &'a str,
    context_lines: usize,
    collect_snippets: bool,
    counters: Arc<SearchCounters>,
    collections: Arc<Mutex<SearchCollections>>,
    seen_paths: SeenPaths,
    file_matches: Vec<FileMatch>,
    snippet_matches: Vec<SnippetMatch>,
    buffer: Vec<u8>,
}

impl ParallelVisitor for SearchVisitor<'_> {
    fn visit(&mut self, entry: Result<DirEntry, ignore::Error>) -> WalkState {
        let Ok(entry) = entry else {
            return WalkState::Continue;
        };
        let Some(file_type) = entry.file_type() else {
            return WalkState::Continue;
        };
        if !file_type.is_file() {
            return WalkState::Continue;
        }

        let rel_path = relative_path(entry.path(), self.rel_base);
        let path_matches = self
            .path_matcher
            .is_some_and(|matcher| matcher.is_match(&rel_path, self.path_scope));
        if !claim_candidate_path(entry.path(), &self.seen_paths) {
            return WalkState::Continue;
        }

        if self.content_matcher.is_none() {
            self.counters.scanned_files.fetch_add(1, Ordering::Relaxed);
            if path_matches {
                push_path_only_match(
                    &mut self.file_matches,
                    &mut self.snippet_matches,
                    rel_path,
                    self.mode,
                    false,
                );
            }
            return WalkState::Continue;
        }

        let Ok(metadata) = entry.metadata() else {
            return WalkState::Continue;
        };
        let size = metadata.len();
        let candidate = CandidateFile {
            path: entry.path().to_path_buf(),
            rel_path,
            size,
        };

        if size > MAX_FILE_BYTES {
            if self.target == "both" && path_matches {
                push_path_only_match(
                    &mut self.file_matches,
                    &mut self.snippet_matches,
                    candidate.rel_path,
                    self.mode,
                    self.collect_snippets,
                );
            }
            self.counters.skipped_huge.fetch_add(1, Ordering::Relaxed);
            return WalkState::Continue;
        }

        self.counters.scanned_files.fetch_add(1, Ordering::Relaxed);
        self.counters
            .scanned_bytes
            .fetch_add(size, Ordering::Relaxed);

        let matcher = self.content_matcher.expect("content matcher exists");
        match search_file_with_buffer(
            &candidate,
            matcher,
            self.context_lines,
            self.collect_snippets,
            &mut self.buffer,
        ) {
            Ok(Some((mut file_match, mut snippets))) => {
                mark_content_match(&mut file_match, self.target, path_matches);
                mark_snippet_matches(&mut snippets, self.target, path_matches);
                self.file_matches.push(file_match);
                self.snippet_matches.extend(snippets);
            }
            Ok(None) => {
                if self.target == "both" && path_matches {
                    push_path_only_match(
                        &mut self.file_matches,
                        &mut self.snippet_matches,
                        candidate.rel_path,
                        self.mode,
                        self.collect_snippets,
                    );
                }
            }
            Err(SearchFileError::Binary) => {
                if self.target == "both" && path_matches {
                    push_path_only_match(
                        &mut self.file_matches,
                        &mut self.snippet_matches,
                        candidate.rel_path,
                        self.mode,
                        self.collect_snippets,
                    );
                }
                self.counters.skipped_binary.fetch_add(1, Ordering::Relaxed);
            }
            Err(SearchFileError::Io) => {
                if self.target == "both" && path_matches {
                    push_path_only_match(
                        &mut self.file_matches,
                        &mut self.snippet_matches,
                        candidate.rel_path,
                        self.mode,
                        self.collect_snippets,
                    );
                }
                self.counters.skipped_errors.fetch_add(1, Ordering::Relaxed);
            }
        }

        WalkState::Continue
    }
}

impl Drop for SearchVisitor<'_> {
    fn drop(&mut self) {
        if self.file_matches.is_empty() && self.snippet_matches.is_empty() {
            return;
        }
        let mut collections = lock_collections(&self.collections);
        collections.file_matches.append(&mut self.file_matches);
        collections
            .snippet_matches
            .append(&mut self.snippet_matches);
    }
}

#[cfg(test)]
mod tests {
    #[cfg(windows)]
    use super::dedup_key;
    #[cfg(windows)]
    use std::path::Path;

    #[cfg(windows)]
    #[test]
    fn dedup_key_is_case_insensitive_on_windows() {
        assert_eq!(
            dedup_key(Path::new(r"C:\Repo\src\a.py")),
            dedup_key(Path::new(r"c:\repo\src\a.py"))
        );
    }
}
