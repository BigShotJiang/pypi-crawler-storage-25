use crate::literal::LiteralMatcher;
use crate::path_utils::basename;
use crate::regex_search::RegexLineMatcher;
use caseless::default_case_fold_str;

#[derive(Debug)]
pub(crate) enum SearchMatcher {
    Literal(LiteralMatcher),
    Regex(RegexLineMatcher),
}

#[derive(Debug)]
pub(crate) enum PathMatcher {
    Literal {
        needle: String,
        case_sensitive: bool,
    },
    Regex(regex::Regex),
}

impl PathMatcher {
    pub(crate) fn new(
        pattern: &str,
        regex: bool,
        case_sensitive: bool,
    ) -> Result<PathMatcher, String> {
        if regex {
            let compiled = regex::RegexBuilder::new(pattern)
                .case_insensitive(!case_sensitive)
                .unicode(true)
                .build()
                .map_err(|err| format!("invalid regex: {err}"))?;
            Ok(PathMatcher::Regex(compiled))
        } else {
            let needle = if case_sensitive {
                pattern.to_string()
            } else {
                default_case_fold_str(pattern)
            };
            Ok(PathMatcher::Literal {
                needle,
                case_sensitive,
            })
        }
    }

    pub(crate) fn is_match(&self, rel_path: &str, path_scope: &str) -> bool {
        let text = if path_scope == "basename" {
            basename(rel_path)
        } else {
            rel_path
        };
        match self {
            PathMatcher::Literal {
                needle,
                case_sensitive,
            } => {
                if needle.is_empty() {
                    return true;
                }
                if *case_sensitive {
                    text.contains(needle)
                } else {
                    default_case_fold_str(text).contains(needle)
                }
            }
            PathMatcher::Regex(regex) => regex.is_match(text),
        }
    }
}
