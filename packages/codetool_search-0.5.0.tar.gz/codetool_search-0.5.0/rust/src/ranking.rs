use std::cmp::min;

use crate::models::{FileMatch, SnippetMatch};
use crate::path_utils::{basename, extension};

pub(crate) struct RankingContext {
    query_lower: String,
    query_terms: Vec<String>,
    query_compact: String,
    mentions_tests: bool,
}

impl RankingContext {
    pub(crate) fn new(query: &str) -> RankingContext {
        let query_terms = query_terms(query);
        let mentions_tests = terms_mention_tests(&query_terms);
        let query_compact = if query_allows_compact_variant(query) {
            compact_alnum(query)
        } else {
            String::new()
        };
        RankingContext {
            query_lower: query.to_ascii_lowercase(),
            query_terms,
            query_compact,
            mentions_tests,
        }
    }

    pub(crate) fn file_sort_key(
        &self,
        item: &FileMatch,
    ) -> (i32, i32, i32, i32, usize, usize, usize, String) {
        (
            if is_generated_path(&item.path) { 10 } else { 0 },
            if is_source_path(&item.path) { 0 } else { 5 },
            if is_test_path(&item.path) && !self.mentions_tests {
                5
            } else {
                0
            },
            path_relevance_with_context(&item.path, self),
            min(item.count, 20),
            item.first_line,
            item.path.len(),
            item.path.clone(),
        )
    }

    pub(crate) fn snippet_sort_key(
        &self,
        item: &SnippetMatch,
    ) -> (i32, i32, i32, i32, i32, usize, usize, String) {
        (
            if is_generated_path(&item.path) { 10 } else { 0 },
            if is_source_path(&item.path) { 0 } else { 5 },
            if is_test_path(&item.path) && !self.mentions_tests {
                5
            } else {
                0
            },
            path_relevance_with_context(&item.path, self),
            definition_bonus(&item.snippet),
            item.line,
            item.path.len(),
            item.path.clone(),
        )
    }
}

fn is_generated_path(path: &str) -> bool {
    let base = basename(path).to_ascii_lowercase();
    base.ends_with(".min.js")
        || base.ends_with(".map")
        || path.to_ascii_lowercase().split('/').any(|segment| {
            matches!(
                segment,
                "generated"
                    | "vendor"
                    | "vendors"
                    | "third_party"
                    | "third-party"
                    | "coverage"
                    | "htmlcov"
                    | "site-packages"
                    | "dist-packages"
            )
        })
}

fn is_source_path(path: &str) -> bool {
    matches!(
        extension(path).to_ascii_lowercase().as_str(),
        "py" | "pyi"
            | "rs"
            | "go"
            | "js"
            | "jsx"
            | "ts"
            | "tsx"
            | "java"
            | "kt"
            | "c"
            | "h"
            | "cc"
            | "cpp"
            | "hpp"
            | "cs"
            | "rb"
            | "php"
            | "swift"
            | "scala"
            | "sh"
            | "bash"
            | "zsh"
            | "fish"
            | "toml"
            | "yaml"
            | "yml"
            | "json"
            | "md"
            | "rst"
    )
}

fn is_test_path(path: &str) -> bool {
    let lower = path.to_ascii_lowercase();
    let base = basename(&lower);
    let stem = base.rsplit_once('.').map(|(stem, _)| stem).unwrap_or(base);
    lower
        .split('/')
        .any(|segment| matches!(segment, "test" | "tests" | "spec" | "specs" | "__tests__"))
        || stem.starts_with("test_")
        || stem.ends_with("_test")
        || stem.ends_with(".test")
        || stem.ends_with(".spec")
}

#[cfg(test)]
fn query_mentions_tests(query: &str) -> bool {
    terms_mention_tests(&query_terms(query))
}

fn terms_mention_tests(terms: &[String]) -> bool {
    terms.iter().any(|term| {
        matches!(
            term.as_str(),
            "test"
                | "tests"
                | "testing"
                | "spec"
                | "specs"
                | "fixture"
                | "fixtures"
                | "mock"
                | "mocks"
                | "assert"
                | "pytest"
                | "unittest"
        )
    })
}

#[cfg(test)]
fn path_relevance(path: &str, query: &str) -> i32 {
    let context = RankingContext::new(query);
    path_relevance_with_context(path, &context)
}

fn path_relevance_with_context(path: &str, context: &RankingContext) -> i32 {
    if context.query_lower.is_empty() {
        return 50;
    }
    let normalised_original = path.replace('\\', "/");
    let normalised = normalised_original.to_ascii_lowercase();
    let base = basename(&normalised);
    let stem = base.rsplit_once('.').map(|(stem, _)| stem).unwrap_or(base);
    let segments: Vec<&str> = normalised
        .split('/')
        .filter(|segment| !segment.is_empty())
        .collect();

    if stem == context.query_lower || base == context.query_lower {
        0
    } else if stem.starts_with(&context.query_lower) || base.starts_with(&context.query_lower) {
        5
    } else if stem.contains(&context.query_lower) || base.contains(&context.query_lower) {
        10
    } else if segments
        .iter()
        .take(segments.len().saturating_sub(1))
        .any(|segment| *segment == context.query_lower || segment.starts_with(&context.query_lower))
    {
        15
    } else if segments
        .iter()
        .take(segments.len().saturating_sub(1))
        .any(|segment| segment.contains(&context.query_lower))
    {
        20
    } else if normalised.contains(&context.query_lower) {
        30
    } else {
        let base_compact = compact_alnum(base);
        let stem_compact = compact_alnum(stem);
        if context.query_compact.len() >= 2
            && (stem_compact == context.query_compact || base_compact == context.query_compact)
        {
            return 0;
        }
        if context.query_compact.len() >= 2
            && (stem_compact.starts_with(&context.query_compact)
                || base_compact.starts_with(&context.query_compact))
        {
            return 5;
        }
        if context.query_compact.len() >= 2
            && (stem_compact.contains(&context.query_compact)
                || base_compact.contains(&context.query_compact))
        {
            return 10;
        }

        term_path_relevance(&normalised, stem, &segments, &context.query_terms)
    }
}

fn term_path_relevance(normalised: &str, stem: &str, segments: &[&str], terms: &[String]) -> i32 {
    if terms.is_empty() {
        return 50;
    }

    let stem_compact = compact_alnum(stem);
    let path_compact = compact_alnum(normalised);
    let directory_segments = &segments[..segments.len().saturating_sub(1)];
    let directory_text = directory_segments.join("/");
    let directory_compact = compact_alnum(&directory_text);

    let stem_hits = terms
        .iter()
        .filter(|term| text_matches_term(stem, &stem_compact, term))
        .count();
    let directory_hits = terms
        .iter()
        .filter(|term| text_matches_term(&directory_text, &directory_compact, term))
        .count();
    let path_hits = terms
        .iter()
        .filter(|term| text_matches_term(normalised, &path_compact, term))
        .count();

    if stem_hits == terms.len() {
        return 8;
    }
    if stem_hits >= 2 {
        return 12;
    }
    if directory_hits == terms.len() {
        return 15;
    }
    if path_hits == terms.len() {
        return 18;
    }
    if stem_hits == 1 {
        return 22;
    }
    if directory_hits >= 1 {
        return 26;
    }
    if path_hits >= 1 {
        return 35;
    }

    50
}

fn text_matches_term(text: &str, compact: &str, term: &str) -> bool {
    text.contains(term) || compact.contains(term)
}

fn query_terms(query: &str) -> Vec<String> {
    let mut terms = split_identifier_terms(query);
    if query_allows_compact_variant(query) {
        push_unique(&mut terms, compact_alnum(query));
    }
    terms
}

fn split_identifier_terms(text: &str) -> Vec<String> {
    let chars: Vec<char> = text.chars().collect();
    let mut terms = Vec::new();
    let mut current = String::new();
    let mut index = 0;

    while index < chars.len() {
        let ch = chars[index];
        if ch == '\\' {
            push_unique(&mut terms, std::mem::take(&mut current));
            index += 1;
            if index < chars.len() {
                if matches!(chars[index], 'p' | 'P') && chars.get(index + 1) == Some(&'{') {
                    index += 2;
                    while index < chars.len() && chars[index] != '}' {
                        index += 1;
                    }
                    if index < chars.len() {
                        index += 1;
                    }
                } else {
                    index += 1;
                }
            }
            continue;
        }

        if ch.is_ascii_alphanumeric() {
            let previous = index
                .checked_sub(1)
                .and_then(|previous_index| chars.get(previous_index));
            let next = chars.get(index + 1);
            let split_before = !current.is_empty()
                && ch.is_ascii_uppercase()
                && (previous.is_some_and(|previous| {
                    previous.is_ascii_lowercase() || previous.is_ascii_digit()
                }) || (previous.is_some_and(|previous| previous.is_ascii_uppercase())
                    && next.is_some_and(|next| next.is_ascii_lowercase())));
            if split_before {
                push_unique(&mut terms, std::mem::take(&mut current));
            }
            current.push(ch.to_ascii_lowercase());
        } else {
            push_unique(&mut terms, std::mem::take(&mut current));
        }
        index += 1;
    }

    push_unique(&mut terms, current);
    terms
}

fn query_allows_compact_variant(query: &str) -> bool {
    query
        .chars()
        .all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '_' | '-' | '.'))
}

fn compact_alnum(text: &str) -> String {
    text.chars()
        .filter(|ch| ch.is_ascii_alphanumeric())
        .map(|ch| ch.to_ascii_lowercase())
        .collect()
}

fn push_unique(terms: &mut Vec<String>, term: String) {
    if term.len() >= 2 && !terms.iter().any(|existing| existing == &term) {
        terms.push(term);
    }
}

fn definition_bonus(snippet: &str) -> i32 {
    let stripped = snippet.trim_start().to_ascii_lowercase();
    let prefixes = [
        "def ",
        "async def ",
        "class ",
        "fn ",
        "pub fn ",
        "pub(crate) fn ",
        "pub(super) fn ",
        "async fn ",
        "pub async fn ",
        "pub(crate) async fn ",
        "pub(super) async fn ",
        "unsafe fn ",
        "pub unsafe fn ",
        "pub(crate) unsafe fn ",
        "function ",
        "export function ",
        "export async function ",
        "export default function ",
        "export default async function ",
        "export class ",
        "export default class ",
        "const ",
        "pub const ",
        "pub(crate) const ",
        "pub(super) const ",
        "static ",
        "pub static ",
        "pub(crate) static ",
        "pub(super) static ",
        "let ",
        "export const ",
        "export let ",
        "export var ",
        "var ",
        "type ",
        "pub type ",
        "pub(crate) type ",
        "pub(super) type ",
        "export type ",
        "interface ",
        "export interface ",
        "struct ",
        "pub struct ",
        "pub(crate) struct ",
        "pub(super) struct ",
        "enum ",
        "pub enum ",
        "pub(crate) enum ",
        "pub(super) enum ",
        "trait ",
        "pub trait ",
        "pub(crate) trait ",
        "pub(super) trait ",
        "export enum ",
        "impl ",
    ];
    if prefixes.iter().any(|prefix| stripped.starts_with(prefix)) {
        -10
    } else {
        0
    }
}

#[cfg(test)]
pub(crate) fn file_sort_key(
    item: &FileMatch,
    query: &str,
) -> (i32, i32, i32, i32, usize, usize, usize, String) {
    RankingContext::new(query).file_sort_key(item)
}

#[cfg(test)]
pub(crate) fn snippet_sort_key(
    item: &SnippetMatch,
    query: &str,
) -> (i32, i32, i32, i32, i32, usize, usize, String) {
    RankingContext::new(query).snippet_sort_key(item)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::{FileMatch, SnippetMatch};

    #[test]
    fn test_query_mentions_tests_uses_intent_tokens() {
        assert!(query_mentions_tests("test login"));
        assert!(query_mentions_tests("pytest fixture"));
        assert!(query_mentions_tests("UserSpec"));
        assert!(query_mentions_tests(r"\btest\b"));
        assert!(!query_mentions_tests("special"));
        assert!(!query_mentions_tests("contest"));
        assert!(!query_mentions_tests("latest"));
        assert!(!query_mentions_tests("specification"));
        assert!(!query_mentions_tests(r"\bspecial\b"));
    }

    #[test]
    fn test_path_relevance_matches_identifier_variants() {
        assert_eq!(path_relevance("src/user_service.py", "UserService"), 0);
        assert_eq!(path_relevance("src/search-text.ts", "searchText"), 0);
        assert!(path_relevance("src/user_service.py", "User(Service|Repo)") < 50);
        assert!(
            path_relevance("src/user_service.py", r"\bUserService\b")
                < path_relevance("src/other.py", r"\bUserService\b")
        );
        assert!(
            path_relevance("src/user_service.py", "User(Service|Repo)")
                < path_relevance("src/other.py", "User(Service|Repo)")
        );
    }

    #[test]
    fn test_file_sort_key_keeps_special_source_before_tests() {
        let mut rows = [
            FileMatch {
                path: "tests/test_special.py".to_string(),
                count: 1,
                first_line: 1,
                kind: None,
                match_kind: None,
            },
            FileMatch {
                path: "src/special.py".to_string(),
                count: 1,
                first_line: 1,
                kind: None,
                match_kind: None,
            },
        ];

        rows.sort_by_cached_key(|row| file_sort_key(row, "special"));

        assert_eq!(rows[0].path, "src/special.py");
    }

    #[test]
    fn test_definition_bonus_covers_common_declarations() {
        assert!(definition_bonus("pub struct Config {") < 0);
        assert!(definition_bonus("pub async fn run() {") < 0);
        assert!(definition_bonus("export class UserService {") < 0);
        assert!(definition_bonus("export const handler = () => {}") < 0);
    }

    #[test]
    fn test_snippet_sort_key_prefers_rust_definition_over_usage() {
        let mut rows = [
            SnippetMatch {
                path: "src/config.rs".to_string(),
                line: 5,
                snippet: "Config::default();".to_string(),
                context: Vec::new(),
                kind: None,
                match_kind: None,
            },
            SnippetMatch {
                path: "src/config.rs".to_string(),
                line: 20,
                snippet: "pub struct Config {".to_string(),
                context: Vec::new(),
                kind: None,
                match_kind: None,
            },
        ];

        assert_eq!(definition_bonus("Config::default();"), 0);
        rows.sort_by_cached_key(|row| snippet_sort_key(row, "Config"));

        assert_eq!(rows[0].snippet, "pub struct Config {");
    }
}
