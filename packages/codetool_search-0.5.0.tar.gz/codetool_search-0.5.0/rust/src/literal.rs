use memchr::{memchr, memchr2};

use crate::constants::MAX_SNIPPETS_PER_FILE;
use crate::models::{CandidateFile, FileMatch, SnippetMatch};
use crate::text::{
    ascii_lower, bytes_eq_ascii_insensitive, context_for_offsets, crop, decode_line,
    line_number_for_offset, LineTracker,
};

#[derive(Debug)]
pub(crate) struct LiteralMatcher {
    needle: Vec<u8>,
    case_sensitive: bool,
    rare_index: usize,
}

impl LiteralMatcher {
    pub(crate) fn new(needle: Vec<u8>, case_sensitive: bool) -> LiteralMatcher {
        let rare_index = choose_rare_byte(&needle);
        LiteralMatcher {
            needle,
            case_sensitive,
            rare_index,
        }
    }

    fn needle_len(&self) -> usize {
        self.needle.len()
    }

    fn count_and_first(&self, haystack: &[u8]) -> (usize, Option<usize>) {
        let mut count = 0usize;
        let mut first = None;
        let mut start = 0usize;
        while let Some(offset) = self.find(haystack, start) {
            if first.is_none() {
                first = Some(offset);
            }
            count += 1;
            start = offset + self.needle_len();
        }
        (count, first)
    }

    fn find(&self, haystack: &[u8], start: usize) -> Option<usize> {
        let needle_len = self.needle.len();
        if needle_len == 0 || start > haystack.len() || haystack.len() - start < needle_len {
            return None;
        }

        if needle_len == 1 {
            return self.find_rare_byte(haystack, start).filter(|offset| {
                if self.case_sensitive {
                    haystack[*offset] == self.needle[0]
                } else {
                    ascii_lower(haystack[*offset]) == self.needle[0]
                }
            });
        }

        let rare_index = self.rare_index;
        let mut scan = start + rare_index;
        let last_rare = haystack.len() - (needle_len - rare_index);
        while scan <= last_rare {
            let rare_offset = self.find_rare_byte(haystack, scan)?;
            if rare_offset > last_rare {
                return None;
            }
            let candidate = rare_offset - rare_index;
            if self.matches_at(haystack, candidate) {
                return Some(candidate);
            }
            scan = rare_offset + 1;
        }
        None
    }

    fn find_rare_byte(&self, haystack: &[u8], start: usize) -> Option<usize> {
        let byte = self.needle[self.rare_index];
        if !self.case_sensitive && byte.is_ascii_alphabetic() {
            let upper = byte.to_ascii_uppercase();
            return memchr2(byte, upper, &haystack[start..]).map(|offset| start + offset);
        }
        memchr(byte, &haystack[start..]).map(|offset| start + offset)
    }

    fn matches_at(&self, haystack: &[u8], start: usize) -> bool {
        let end = start + self.needle.len();
        if end > haystack.len() {
            return false;
        }
        let candidate = &haystack[start..end];
        if self.case_sensitive {
            candidate == self.needle.as_slice()
        } else {
            bytes_eq_ascii_insensitive(candidate, &self.needle)
        }
    }
}

fn choose_rare_byte(needle: &[u8]) -> usize {
    let mut best_index = 0usize;
    let mut best_rank = u16::MAX;
    for (index, byte) in needle.iter().enumerate() {
        let rank = byte_frequency_rank(*byte);
        if rank < best_rank {
            best_rank = rank;
            best_index = index;
        }
    }
    best_index
}

fn byte_frequency_rank(byte: u8) -> u16 {
    match ascii_lower(byte) {
        b'z' => 1,
        b'q' => 2,
        b'x' => 3,
        b'j' => 4,
        b'k' => 5,
        b'v' => 8,
        b'b' => 10,
        b'p' => 12,
        b'y' => 14,
        b'g' => 16,
        b'f' => 18,
        b'w' => 20,
        b'm' => 24,
        b'u' => 28,
        b'c' => 32,
        b'd' => 36,
        b'l' => 40,
        b'r' => 44,
        b'h' => 48,
        b's' => 52,
        b'n' => 56,
        b'i' => 60,
        b'o' => 64,
        b'a' => 68,
        b't' => 72,
        b'e' => 76,
        b'0'..=b'9' => 30,
        b'_' | b'-' => 34,
        b'/' | b'\\' | b'.' => 58,
        b' ' | b'\t' | b'\r' | b'\n' => 90,
        _ => 22,
    }
}

pub(crate) fn search_file_count_only(
    candidate: &CandidateFile,
    data: &[u8],
    matcher: &LiteralMatcher,
) -> Option<(FileMatch, Vec<SnippetMatch>)> {
    let (count, first_offset) = matcher.count_and_first(data);
    let first_offset = first_offset?;
    Some((
        FileMatch {
            path: candidate.rel_path.clone(),
            count,
            first_line: line_number_for_offset(data, first_offset),
            kind: None,
            match_kind: None,
        },
        Vec::new(),
    ))
}

pub(crate) fn search_file_snippets(
    candidate: &CandidateFile,
    data: &[u8],
    matcher: &LiteralMatcher,
    context_lines: usize,
) -> Option<(FileMatch, Vec<SnippetMatch>)> {
    let mut count = 0usize;
    let mut first_line: Option<usize> = None;
    let mut snippets: Vec<SnippetMatch> = Vec::with_capacity(MAX_SNIPPETS_PER_FILE);
    let mut tracker = LineTracker::new(data);
    let mut last_snippet_line = 0usize;
    let mut start = 0usize;

    while let Some(offset) = matcher.find(data, start) {
        count += 1;
        tracker.advance_to(offset);
        let line_number = tracker.line_number();
        if first_line.is_none() {
            first_line = Some(line_number);
        }

        if snippets.len() < MAX_SNIPPETS_PER_FILE && line_number != last_snippet_line {
            let line_start = tracker.line_start();
            let line_end = tracker.line_end();
            snippets.push(SnippetMatch {
                path: candidate.rel_path.clone(),
                line: line_number,
                snippet: crop(&decode_line(&data[line_start..line_end])),
                context: context_for_offsets(data, line_start, line_number, context_lines),
                kind: None,
                match_kind: None,
            });
            last_snippet_line = line_number;
        }

        start = offset + matcher.needle_len();
    }

    let Some(first_line) = first_line else {
        return None;
    };
    Some((
        FileMatch {
            path: candidate.rel_path.clone(),
            count,
            first_line,
            kind: None,
            match_kind: None,
        },
        snippets,
    ))
}
