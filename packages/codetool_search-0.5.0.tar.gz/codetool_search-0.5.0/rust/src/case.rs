pub(crate) fn resolve_case(case: &str, pattern: &str) -> (String, bool) {
    match case {
        "smart" => {
            let sensitive = pattern.chars().any(|ch| ch.is_uppercase());
            (
                if sensitive {
                    "sensitive".to_string()
                } else {
                    "insensitive".to_string()
                },
                sensitive,
            )
        }
        "sensitive" | "case-sensitive" | "exact" => ("sensitive".to_string(), true),
        "insensitive" | "ignore" | "ignorecase" | "case-insensitive" | "i" => {
            ("insensitive".to_string(), false)
        }
        _ => ("insensitive".to_string(), false),
    }
}
