use regex::RegexBuilder;

use crate::constants::MAX_SNIPPETS_PER_FILE;
use crate::models::{CandidateFile, FileMatch, SnippetMatch};
use crate::text::{context_for_text_lines, crop};

#[derive(Debug)]
pub(crate) struct RegexLineMatcher {
    regex: regex::Regex,
}

impl RegexLineMatcher {
    pub(crate) fn new(pattern: &str, case_sensitive: bool) -> Result<RegexLineMatcher, String> {
        let mut builder = RegexBuilder::new(pattern);
        builder
            .case_insensitive(!case_sensitive)
            .multi_line(false)
            .dot_matches_new_line(false)
            .unicode(true);
        let regex = builder
            .build()
            .map_err(|err| format!("invalid regex: {err}"))?;
        // Rust's regex iterator intentionally advances past some empty spans
        // that Python's re.finditer reports. Reject those patterns so the
        // Python wrapper's auto mode can preserve public count semantics.
        if regex_can_produce_empty_match(&regex) {
            return Err(
                "regex patterns that can match empty spans require Python-compatible counting"
                    .to_string(),
            );
        }
        Ok(RegexLineMatcher { regex })
    }

    fn count_line(&self, line: &str) -> usize {
        self.regex.find_iter(line).count()
    }
}

fn regex_can_produce_empty_match(regex: &regex::Regex) -> bool {
    [
        "",
        "a",
        "abc",
        " a ",
        "_",
        "0",
        "é",
        "foo",
        "fn main",
        "struct Foo",
    ]
    .iter()
    .any(|sample| {
        sample
            .char_indices()
            .map(|(index, _)| index)
            .chain(std::iter::once(sample.len()))
            .any(|start| {
                regex
                    .find_at(sample, start)
                    .is_some_and(|mat| mat.start() == mat.end())
            })
    })
}

pub(crate) fn search_regex_file_count_only(
    candidate: &CandidateFile,
    data: &[u8],
    matcher: &RegexLineMatcher,
) -> Option<(FileMatch, Vec<SnippetMatch>)> {
    let text = String::from_utf8_lossy(data);
    let mut count = 0usize;
    let mut first_line: Option<usize> = None;

    for (index, raw_line) in text.lines().enumerate() {
        let line = strip_trailing_cr(raw_line);
        let line_count = matcher.count_line(line);
        if line_count == 0 {
            continue;
        }
        count += line_count;
        if first_line.is_none() {
            first_line = Some(index + 1);
        }
    }

    let first_line = first_line?;
    Some((
        FileMatch {
            path: candidate.rel_path.clone(),
            count,
            first_line,
            kind: None,
            match_kind: None,
        },
        Vec::new(),
    ))
}

pub(crate) fn search_regex_file_snippets(
    candidate: &CandidateFile,
    data: &[u8],
    matcher: &RegexLineMatcher,
    context_lines: usize,
) -> Option<(FileMatch, Vec<SnippetMatch>)> {
    let text = String::from_utf8_lossy(data);
    let lines: Vec<&str> = text.lines().map(strip_trailing_cr).collect();
    let mut count = 0usize;
    let mut first_line: Option<usize> = None;
    let mut snippets: Vec<SnippetMatch> = Vec::with_capacity(MAX_SNIPPETS_PER_FILE);

    for (index, line) in lines.iter().enumerate() {
        let line_count = matcher.count_line(line);
        if line_count == 0 {
            continue;
        }
        count += line_count;
        let line_number = index + 1;
        if first_line.is_none() {
            first_line = Some(line_number);
        }
        if snippets.len() < MAX_SNIPPETS_PER_FILE {
            snippets.push(SnippetMatch {
                path: candidate.rel_path.clone(),
                line: line_number,
                snippet: crop(line),
                context: context_for_text_lines(&lines, index, context_lines),
                kind: None,
                match_kind: None,
            });
        }
    }

    let first_line = first_line?;
    Some((
        FileMatch {
            path: candidate.rel_path.clone(),
            count,
            first_line,
            kind: None,
            match_kind: None,
        },
        snippets,
    ))
}

fn strip_trailing_cr(line: &str) -> &str {
    line.strip_suffix('\r').unwrap_or(line)
}
