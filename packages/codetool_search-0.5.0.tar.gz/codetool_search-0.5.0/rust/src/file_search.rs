use std::fs;
use std::io::Read;

use memchr::memchr;

use crate::constants::BINARY_CHECK_BYTES;
use crate::literal::{search_file_count_only, search_file_snippets};
use crate::matcher::SearchMatcher;
use crate::models::{CandidateFile, FileMatch, SnippetMatch};
use crate::regex_search::{search_regex_file_count_only, search_regex_file_snippets};

#[derive(Debug)]
pub(crate) enum SearchFileError {
    Binary,
    Io,
}

pub(crate) fn search_file_with_buffer(
    candidate: &CandidateFile,
    matcher: &SearchMatcher,
    context_lines: usize,
    collect_snippets: bool,
    buffer: &mut Vec<u8>,
) -> Result<Option<(FileMatch, Vec<SnippetMatch>)>, SearchFileError> {
    read_text_candidate(candidate, buffer)?;

    match matcher {
        SearchMatcher::Literal(literal) => {
            if collect_snippets {
                Ok(search_file_snippets(
                    candidate,
                    buffer,
                    literal,
                    context_lines,
                ))
            } else {
                Ok(search_file_count_only(candidate, buffer, literal))
            }
        }
        SearchMatcher::Regex(regex) => {
            if collect_snippets {
                Ok(search_regex_file_snippets(
                    candidate,
                    buffer,
                    regex,
                    context_lines,
                ))
            } else {
                Ok(search_regex_file_count_only(candidate, buffer, regex))
            }
        }
    }
}

fn read_text_candidate(
    candidate: &CandidateFile,
    buffer: &mut Vec<u8>,
) -> Result<(), SearchFileError> {
    buffer.clear();
    if buffer.capacity() < candidate.size as usize {
        buffer.reserve(candidate.size as usize - buffer.capacity());
    }
    let mut file = fs::File::open(&candidate.path).map_err(|_| SearchFileError::Io)?;
    file.read_to_end(buffer).map_err(|_| SearchFileError::Io)?;
    let check_len = buffer.len().min(BINARY_CHECK_BYTES);
    if memchr(b'\0', &buffer[..check_len]).is_some() {
        return Err(SearchFileError::Binary);
    }
    Ok(())
}
