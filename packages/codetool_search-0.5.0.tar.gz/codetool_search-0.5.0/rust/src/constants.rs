pub(crate) const MAX_FILE_BYTES: u64 = 5 * 1024 * 1024;
pub(crate) const BINARY_CHECK_BYTES: usize = 8 * 1024;
pub(crate) const MAX_SNIPPETS_PER_FILE: usize = 3;
pub(crate) const MAX_SNIPPET_CHARS: usize = 180;
pub(crate) const MAX_LIMIT: usize = 1_000;
pub(crate) const COMMON_IGNORED_DIRS: &[&str] = &[
    ".git",
    ".hg",
    ".svn",
    ".tox",
    ".nox",
    ".venv",
    "venv",
    "env",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".cache",
    "node_modules",
    "bower_components",
    "dist",
    "build",
    "target",
    ".next",
    ".nuxt",
    ".idea",
    ".vscode",
];
pub(crate) const COMMON_IGNORED_FILES: &[&str] = &[".DS_Store", "Thumbs.db"];
