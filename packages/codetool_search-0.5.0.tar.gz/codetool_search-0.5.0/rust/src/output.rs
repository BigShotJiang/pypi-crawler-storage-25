use std::cmp::min;

use crate::config::Config;
use crate::models::{FileMatch, SearchResult, SnippetMatch};

pub(crate) fn render_json(config: &Config, result: &SearchResult) -> String {
    let total_files = result.file_matches.len();
    let total_occurrences: usize = result.file_matches.iter().map(|item| item.count).sum();
    let total_rows = if config.mode == "snippets" {
        result.snippet_matches.len()
    } else {
        result.file_matches.len()
    };
    let offset = min(config.offset, total_rows);
    let end = min(offset + config.limit, total_rows);
    let truncated = end < total_rows;
    let next_cursor = if truncated {
        Some(end.to_string())
    } else {
        None
    };

    let mut out = String::new();
    out.push('{');
    push_json_pair_string(&mut out, "pattern", &config.pattern, false);
    if config.root_display.len() == 1 {
        push_json_pair_string(&mut out, "root", &config.root_display[0], true);
    } else {
        out.push_str(",\"root\":");
        render_string_array(&mut out, &config.root_display);
    }
    push_json_pair_bool(&mut out, "regex", config.regex, true);
    push_json_pair_string(&mut out, "target", &config.target, true);
    if config.target != "content" {
        push_json_pair_string(&mut out, "path_scope", &config.path_scope, true);
    }
    push_json_pair_string(&mut out, "mode", &config.mode, true);
    push_json_pair_string(&mut out, "case", &config.case, true);
    push_json_pair_string(&mut out, "effective_case", &result.effective_case, true);
    push_json_pair_usize(&mut out, "limit", config.limit, true);
    push_json_pair_optional_string(&mut out, "cursor", config.cursor.as_deref(), true);
    push_json_pair_string(&mut out, "backend", "rust", true);
    out.push_str(",\"matches\":");
    if config.mode == "snippets" {
        render_snippet_matches(&mut out, &result.snippet_matches[offset..end]);
    } else {
        render_file_matches(&mut out, &result.file_matches[offset..end], &config.mode);
    }
    push_json_pair_usize(&mut out, "returned", end - offset, true);
    push_json_pair_usize(&mut out, "total_files", total_files, true);
    let total_matches = if config.mode == "snippets" {
        result.snippet_matches.len()
    } else {
        total_files
    };
    push_json_pair_usize(&mut out, "total_matches", total_matches, true);
    push_json_pair_usize(&mut out, "count", total_occurrences, true);
    push_json_pair_usize(&mut out, "content_count", content_count(result), true);
    push_json_pair_usize(&mut out, "content_files", content_files(result), true);
    push_json_pair_usize(&mut out, "path_matches", path_matches(result), true);
    push_json_pair_bool(&mut out, "truncated", truncated, true);
    push_json_pair_optional_string(&mut out, "next_cursor", next_cursor.as_deref(), true);
    push_json_pair_usize(&mut out, "offset", offset, true);
    push_json_pair_usize(&mut out, "scanned_files", result.scanned_files, true);
    push_json_pair_u64(&mut out, "scanned_bytes", result.scanned_bytes, true);
    out.push_str(",\"skipped\":{");
    push_json_pair_usize(&mut out, "binary", result.skipped.binary, false);
    push_json_pair_usize(&mut out, "huge", result.skipped.huge, true);
    push_json_pair_usize(&mut out, "errors", result.skipped.errors, true);
    out.push('}');
    if !config.globs.is_empty() {
        out.push_str(",\"glob\":");
        render_string_array(&mut out, &config.globs);
    }
    if !config.excludes.is_empty() {
        out.push_str(",\"exclude\":");
        render_string_array(&mut out, &config.excludes);
    }
    out.push('}');
    out
}

fn render_file_matches(out: &mut String, matches: &[FileMatch], mode: &str) {
    out.push('[');
    for (index, item) in matches.iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push('{');
        push_json_pair_string(out, "path", &item.path, false);
        let mut comma = true;
        if item.match_kind != Some("path") || mode == "count" {
            push_json_pair_usize(out, "count", item.count, comma);
            comma = true;
        }
        if item.first_line > 0 {
            push_json_pair_usize(out, "first_line", item.first_line, comma);
            comma = true;
        }
        if let Some(kind) = item.kind {
            push_json_pair_string(out, "kind", kind, comma);
            comma = true;
        }
        if let Some(match_kind) = item.match_kind {
            push_json_pair_string(out, "match_kind", match_kind, comma);
        }
        out.push('}');
    }
    out.push(']');
}

fn content_count(result: &SearchResult) -> usize {
    result
        .file_matches
        .iter()
        .filter(|item| item.match_kind != Some("path"))
        .map(|item| item.count)
        .sum()
}

fn content_files(result: &SearchResult) -> usize {
    result
        .file_matches
        .iter()
        .filter(|item| item.match_kind != Some("path"))
        .count()
}

fn path_matches(result: &SearchResult) -> usize {
    result
        .file_matches
        .iter()
        .filter(|item| matches!(item.match_kind, Some("path") | Some("both")))
        .count()
}

fn render_snippet_matches(out: &mut String, matches: &[SnippetMatch]) {
    out.push('[');
    for (index, item) in matches.iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push('{');
        push_json_pair_string(out, "path", &item.path, false);
        let mut comma = true;
        if item.line > 0 {
            push_json_pair_usize(out, "line", item.line, comma);
            push_json_pair_string(out, "snippet", &item.snippet, true);
            comma = true;
        }
        if !item.context.is_empty() {
            if comma {
                out.push(',');
            }
            out.push_str("\"context\":[");
            for (ctx_index, ctx) in item.context.iter().enumerate() {
                if ctx_index > 0 {
                    out.push(',');
                }
                out.push('{');
                push_json_pair_usize(out, "line", ctx.line, false);
                push_json_pair_string(out, "text", &ctx.text, true);
                out.push('}');
            }
            out.push(']');
            comma = true;
        }
        if let Some(kind) = item.kind {
            push_json_pair_string(out, "kind", kind, comma);
            comma = true;
        }
        if let Some(match_kind) = item.match_kind {
            push_json_pair_string(out, "match_kind", match_kind, comma);
        }
        out.push('}');
    }
    out.push(']');
}

fn render_string_array(out: &mut String, values: &[String]) {
    out.push('[');
    for (index, value) in values.iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push('"');
        out.push_str(&json_escape(value));
        out.push('"');
    }
    out.push(']');
}

fn push_json_pair_string(out: &mut String, key: &str, value: &str, comma: bool) {
    if comma {
        out.push(',');
    }
    out.push('"');
    out.push_str(key);
    out.push_str("\":\"");
    out.push_str(&json_escape(value));
    out.push('"');
}

fn push_json_pair_optional_string(out: &mut String, key: &str, value: Option<&str>, comma: bool) {
    if comma {
        out.push(',');
    }
    out.push('"');
    out.push_str(key);
    out.push_str("\":");
    if let Some(value) = value {
        out.push('"');
        out.push_str(&json_escape(value));
        out.push('"');
    } else {
        out.push_str("null");
    }
}

fn push_json_pair_bool(out: &mut String, key: &str, value: bool, comma: bool) {
    if comma {
        out.push(',');
    }
    out.push('"');
    out.push_str(key);
    out.push_str("\":");
    out.push_str(if value { "true" } else { "false" });
}

fn push_json_pair_usize(out: &mut String, key: &str, value: usize, comma: bool) {
    if comma {
        out.push(',');
    }
    out.push('"');
    out.push_str(key);
    out.push_str("\":");
    out.push_str(&value.to_string());
}

fn push_json_pair_u64(out: &mut String, key: &str, value: u64, comma: bool) {
    if comma {
        out.push(',');
    }
    out.push('"');
    out.push_str(key);
    out.push_str("\":");
    out.push_str(&value.to_string());
}

fn json_escape(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            '\u{08}' => out.push_str("\\b"),
            '\u{0c}' => out.push_str("\\f"),
            ch if ch <= '\u{1f}' => {
                out.push_str(&format!("\\u{:04x}", ch as u32));
            }
            ch => out.push(ch),
        }
    }
    out
}
