use std::io::{self, Write};

mod app;
mod case;
mod config;
mod constants;
mod file_search;
mod ignore_rules;
mod literal;
mod matcher;
mod models;
mod output;
mod path_utils;
mod ranking;
mod regex_search;
mod search;
mod text;
mod walker;

fn main() {
    match config::parse_args().and_then(app::run) {
        Ok(json) => {
            println!("{json}");
        }
        Err(message) => {
            let _ = writeln!(io::stderr(), "{message}");
            std::process::exit(2);
        }
    }
}
