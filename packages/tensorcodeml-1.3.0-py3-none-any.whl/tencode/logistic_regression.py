"""tencode: logistic_regression (with libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import StandardScaler

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "StudyHours":      [1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15],
    "Attendance":      [45, 50, 52, 55, 60, 63, 68, 72, 75, 80, 85, 88, 90, 93, 95],
    "AssignmentScore": [40, 42, 45, 50, 55, 58, 62, 68, 72, 75, 80, 84, 87, 90, 94],
    "Pass":            [0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Labels ─────────────────────────────────────────────────────────
X = df[["StudyHours", "Attendance"]].values
y = df["Pass"].values

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

# ── Model ─────────────────────────────────────────────────────────────────────
model = LogisticRegression()
model.fit(X_train, y_train)
print("\\nTraining Completed!")

# ── Evaluation ────────────────────────────────────────────────────────────────
predictions = model.predict(X_test)

print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y_test)
print("\\nAccuracy :", accuracy_score(y_test, predictions))
print("\\nWeights:\\n",  model.coef_)
print("\\nBias:\\n",     model.intercept_)

cm = confusion_matrix(y_test, predictions)
print("\\nConfusion Matrix:\\n", cm)

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample             = scaler.transform(np.array([[8, 76]]))
sample_prediction  = model.predict(sample)
sample_probability = model.predict_proba(sample)

print("\\nSample Prediction Probability:\\n", sample_probability)
print("Student Will Pass" if sample_prediction[0] == 1 else "Student Will Fail")

# ── Plot 1 : Decision Boundary ────────────────────────────────────────────────
plt.figure(figsize=(8, 6))

for i in range(len(X_train)):
    if y_train[i] == 1:
        plt.scatter(X_train[i][0], X_train[i][1], color='green', s=120,
                    marker='o', label='Pass' if i == 0 else "")
    else:
        plt.scatter(X_train[i][0], X_train[i][1], color='red', s=120,
                    marker='x', label='Fail' if i == 1 else "")

x1 = np.linspace(min(X_train[:, 0]) - 1, max(X_train[:, 0]) + 1, 100)
x2 = -(model.coef_[0][0] * x1 + model.intercept_[0]) / model.coef_[0][1]

plt.plot(x1, x2, color='blue', linewidth=2, label='Decision Boundary')
plt.xlabel("Study Hours (scaled)")
plt.ylabel("Attendance (scaled)")
plt.title("Logistic Regression — Decision Boundary")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ── Plot 2 : Confusion Matrix ─────────────────────────────────────────────────
plt.figure(figsize=(6, 5))
plt.imshow(cm, cmap='Blues')
plt.title("Confusion Matrix")
plt.colorbar()
plt.xticks([0, 1], ["Fail", "Pass"])
plt.yticks([0, 1], ["Fail", "Pass"])

for i in range(2):
    for j in range(2):
        plt.text(j, i, cm[i, j], ha='center', va='center', color='black',
                 fontsize=14, fontweight='bold')

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
