"""tencode: svm_lineardata_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Experience":     [1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12],
    "InterviewScore": [35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90],
    "Communication":  [30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85],
    "Selected":       [-1, -1, -1, -1, -1, 1,  1,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Labels ─────────────────────────────────────────────────────────
X = df[["Experience", "InterviewScore"]].values
y = df["Selected"].values

# ── Normalisation ─────────────────────────────────────────────────────────────
X_mean = X.mean(axis=0)
X_std  = X.std(axis=0)
X      = (X - X_mean) / X_std

# ── Hyperparameters ───────────────────────────────────────────────────────────
weights      = np.zeros(X.shape[1])
bias         = 0
learning_rate = 0.001
epochs        = 1000
lambda_param  = 0.01

# ── Training Loop (Hinge Loss + SGD) ─────────────────────────────────────────
for epoch in range(epochs):
    for i, x_i in enumerate(X):
        if y[i] * (np.dot(x_i, weights) + bias) >= 1:
            dw = 2 * lambda_param * weights
            db = 0
        else:
            dw = 2 * lambda_param * weights - np.dot(x_i, y[i])
            db = -y[i]
        weights -= learning_rate * dw
        bias    -= learning_rate * db

print("\\nTraining Completed!")

# ── Predictions ───────────────────────────────────────────────────────────────
predictions = [np.sign(np.dot(x_i, weights) + bias) for x_i in X]
print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y)

accuracy = np.sum(predictions == y) / len(y)
print("\\nAccuracy :", accuracy)
print("\\nWeights:\\n", weights)
print("\\nBias:", bias)

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample      = (np.array([[7, 72]]) - X_mean) / X_std
sample_pred = np.sign(np.dot(sample, weights) + bias)
print("\\nSample Prediction:")
print("Candidate Selected" if sample_pred[0] == 1 else "Candidate Rejected")

# ── Plot : Hyperplane & Margins ───────────────────────────────────────────────
plt.figure(figsize=(8, 6))
for i in range(len(X)):
    if y[i] == 1:
        plt.scatter(X[i][0], X[i][1], color='green', s=100, marker='o',
                    label='Selected' if i == 5 else "")
    else:
        plt.scatter(X[i][0], X[i][1], color='red', s=100, marker='x',
                    label='Rejected' if i == 0 else "")

x1          = np.linspace(min(X[:, 0]) - 1, max(X[:, 0]) + 1, 100)
x2          = -(weights[0] * x1 + bias) / weights[1]
margin_up   = -(weights[0] * x1 + bias - 1) / weights[1]
margin_down = -(weights[0] * x1 + bias + 1) / weights[1]

plt.plot(x1, x2,          color='blue',  linewidth=2, label='Hyperplane')
plt.plot(x1, margin_up,   color='black', linewidth=1, linestyle='--')
plt.plot(x1, margin_down, color='black', linewidth=1, linestyle='--')
plt.xlabel("Experience (normalised)")
plt.ylabel("Interview Score (normalised)")
plt.title("SVM (Linear) — Candidate Selection")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
