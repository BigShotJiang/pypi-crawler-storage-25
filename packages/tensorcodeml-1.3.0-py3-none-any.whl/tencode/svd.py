"""tencode: svd (with libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import TruncatedSVD
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Maths":      [85, 78, 90, 65, 70, 88, 92, 60, 75, 80],
    "Science":    [80, 74, 95, 60, 68, 90, 96, 58, 72, 85],
    "English":    [78, 70, 88, 62, 66, 84, 91, 55, 73, 79],
    "Computer":   [92, 85, 97, 70, 72, 95, 99, 65, 80, 88],
    "Attendance": [90, 85, 95, 75, 78, 92, 97, 70, 82, 88],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler      = StandardScaler()
scaled_data = scaler.fit_transform(df)
print("\\nScaled Data:\\n")
print(scaled_data)

# ── SVD ───────────────────────────────────────────────────────────────────────
svd            = TruncatedSVD(n_components=2)
svd_components = svd.fit_transform(scaled_data)

svd_df = pd.DataFrame(
    data=svd_components,
    columns=["SVD_Component_1", "SVD_Component_2"]
)
print("\\nSVD Reduced Data:\\n")
print(svd_df)

print("\\nExplained Variance Ratio:", svd.explained_variance_ratio_)
print("Total Variance Explained : {:.2f}%".format(sum(svd.explained_variance_ratio_) * 100))
print("\\nSingular Values:", svd.singular_values_)
print("\\nSVD Components:\\n", svd.components_)

# ── Plot : SVD Scatter ────────────────────────────────────────────────────────
plt.figure(figsize=(7, 5))
sns.scatterplot(x=svd_df["SVD_Component_1"],
                y=svd_df["SVD_Component_2"], s=100)
plt.xlabel("SVD Component 1")
plt.ylabel("SVD Component 2")
plt.title("SVD — Dimensionality Reduction")
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
