"""tencode: svd_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset (User-Movie Ratings) ─────────────────────────────────────────────
data = {
    "Action":  [5, 4, 5, 1, 2, 1, 5, 4],
    "Comedy":  [1, 2, 1, 5, 4, 5, 2, 1],
    "Drama":   [4, 5, 4, 2, 3, 2, 5, 4],
    "SciFi":   [5, 4, 5, 1, 1, 2, 5, 4],
    "Romance": [1, 2, 1, 5, 5, 4, 2, 1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X = df.values.astype(float)

# ── Full SVD ──────────────────────────────────────────────────────────────────
U, S, VT = np.linalg.svd(X)

print("\\nU Matrix:\\n",         U)
print("\\nSingular Values:\\n",  S)
print("\\nVT Matrix:\\n",        VT)

# ── Truncated Reconstruction (top k=2) ───────────────────────────────────────
k          = 2
S_reduced  = np.zeros((k, k))
for i in range(k):
    S_reduced[i][i] = S[i]

X_reduced = np.dot(np.dot(U[:, :k], S_reduced), VT[:k, :])
print("\\nReduced Matrix (Top 2 Singular Values):\\n", X_reduced)

# ── Plot 1 : Original vs Reduced Matrix ──────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
user_labels  = [f"User {i+1}" for i in range(len(df))]
genre_labels = list(df.columns)

for ax, matrix, title in [(axes[0], X, "Original Rating Matrix"),
                           (axes[1], X_reduced, "Reduced Matrix after SVD")]:
    im = ax.imshow(matrix, cmap='viridis', aspect='auto')
    plt.colorbar(im, ax=ax)
    ax.set_xticks(range(len(genre_labels)))
    ax.set_xticklabels(genre_labels)
    ax.set_yticks(range(len(user_labels)))
    ax.set_yticklabels(user_labels)
    ax.set_title(title)

plt.tight_layout()
plt.show()

# ── Plot 2 : Singular Values ──────────────────────────────────────────────────
plt.figure(figsize=(7, 5))
plt.plot(range(1, len(S) + 1), S, marker='o', linewidth=2)
plt.xlabel("Singular Value Number")
plt.ylabel("Magnitude")
plt.title("SVD — Singular Values")
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
