"""tencode: decision_tree (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Attendance":          ["High","Medium","Low","High","Medium","Low","High","Medium","Low","High"],
    "StudyHours":          ["High","Medium","Low","High","Medium","Low","Medium","High","Low","Medium"],
    "InternalMarks":       ["Good","Average","Poor","Good","Average","Poor","Good","Average","Poor","Good"],
    "AssignmentCompletion":["Yes","Yes","No","Yes","No","No","Yes","Yes","No","Yes"],
    "Result":              ["Pass","Pass","Fail","Pass","Fail","Fail","Pass","Pass","Fail","Pass"],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Encoding ──────────────────────────────────────────────────────────────────
encoding = {
    "High": 2, "Medium": 1, "Low": 0,
    "Good": 2, "Average": 1, "Poor": 0,
    "Yes": 1, "No": 0,
    "Pass": 1, "Fail": 0,
}
df = df.replace(encoding)
print("\\nEncoded Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Result", axis=1)
y = df["Result"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Model ─────────────────────────────────────────────────────────────────────
model = DecisionTreeClassifier(criterion="entropy", max_depth=3, random_state=42)
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
accuracy = accuracy_score(y_test, y_pred)
cm       = confusion_matrix(y_test, y_pred)
report   = classification_report(y_test, y_pred)

print("\\nAccuracy :", accuracy)
print("\\nConfusion Matrix:\\n", cm)
print("\\nClassification Report:\\n", report)

# ── Plot : Decision Tree ──────────────────────────────────────────────────────
plt.figure(figsize=(10, 6))
plot_tree(model, feature_names=X.columns, class_names=["Fail", "Pass"], filled=True)
plt.title("Decision Tree")
plt.tight_layout()
plt.show()

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample     = [[2, 2, 2, 1]]
prediction = model.predict(sample)
print("\\nSample Prediction:")
print("Student will Pass" if prediction[0] == 1 else "Student will Fail")
"""

def main():
    print(_CODE)
