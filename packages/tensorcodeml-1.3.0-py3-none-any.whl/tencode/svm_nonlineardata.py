"""tencode: svm_nonlineardata (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "TransactionAmount": [100, 150, 200, 250, 300, 350, 400, 450, 500, 550],
    "TransactionTime":   [1,   2,   3,   4,   5,   18,  19,  20,  21,  22],
    "LocationDistance":  [2,   3,   2,   4,   3,   20,  25,  30,  35,  40],
    "DeviceRiskScore":   [0.1, 0.2, 0.1, 0.3, 0.2, 0.8, 0.9, 0.85,0.95,0.99],
    "FraudStatus":       [0,   0,   0,   0,   0,   1,   1,   1,   1,   1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("FraudStatus", axis=1)
y = df["FraudStatus"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

# ── Model ─────────────────────────────────────────────────────────────────────
model = SVC(kernel="rbf", C=1, gamma="scale")
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
accuracy = accuracy_score(y_test, y_pred)
cm       = confusion_matrix(y_test, y_pred)
report   = classification_report(y_test, y_pred)

print("\\nAccuracy :", accuracy)
print("\\nConfusion Matrix:\\n", cm)
print("\\nClassification Report:\\n", report)

# ── Plot : Confusion Matrix ───────────────────────────────────────────────────
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix — SVM (RBF Kernel)")
plt.tight_layout()
plt.show()

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample     = scaler.transform([[420, 20, 28, 0.9]])
prediction = model.predict(sample)
print("\\nSample Prediction:")
print("Fraud Transaction" if prediction[0] == 1 else "Not Fraud")
"""

def main():
    print(_CODE)
