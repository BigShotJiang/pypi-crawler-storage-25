"""tencode: k_means_clustering_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "AnnualIncome":  [15,18,20,22,25,28,30,32,35,38,40,42,45,48,50,52,55,58,60,62],
    "SpendingScore": [75,78,72,68,70,65,60,62,58,55,40,42,38,35,50,48,30,28,45,43],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X = df.values
k = 3

# ── Initialise Centroids ──────────────────────────────────────────────────────
np.random.seed(42)
centroids = X[np.random.choice(len(X), k, replace=False)]
print("\\nInitial Centroids:\\n", centroids)

# ── K-Means Loop ──────────────────────────────────────────────────────────────
for iteration in range(100):
    # Assign clusters
    distances = np.array([[np.sqrt(np.sum((point - c) ** 2)) for c in centroids]
                           for point in X])
    clusters = np.argmin(distances, axis=1)

    # Update centroids
    new_centroids = np.array([X[clusters == i].mean(axis=0) for i in range(k)])

    if np.allclose(centroids, new_centroids):
        print(f"Converged after {iteration + 1} iterations.")
        break
    centroids = new_centroids

print("\\nFinal Centroids:\\n", centroids)
print("\\nCluster Labels:\\n",  clusters)

# ── Plot : Clusters ───────────────────────────────────────────────────────────
colors = ['blue', 'green', 'orange']
plt.figure(figsize=(8, 6))
for i in range(k):
    pts = X[clusters == i]
    plt.scatter(pts[:, 0], pts[:, 1], color=colors[i], s=120, label=f'Cluster {i+1}')
plt.scatter(centroids[:, 0], centroids[:, 1],
            color='red', s=300, marker='X', label='Centroids')
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("K-Means — Customer Segmentation")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
