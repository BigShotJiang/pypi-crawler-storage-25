"""tencode: pca (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Maths":      [85, 78, 90, 65, 70, 88, 92, 60, 75, 80],
    "Science":    [80, 74, 95, 60, 68, 90, 96, 58, 72, 85],
    "English":    [78, 70, 88, 62, 66, 84, 91, 55, 73, 79],
    "Computer":   [92, 85, 97, 70, 72, 95, 99, 65, 80, 88],
    "Attendance": [90, 85, 95, 75, 78, 92, 97, 70, 82, 88],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler      = StandardScaler()
scaled_data = scaler.fit_transform(df)
print("\\nScaled Data:\\n")
print(scaled_data)

# ── PCA ───────────────────────────────────────────────────────────────────────
pca                  = PCA(n_components=2)
principal_components = pca.fit_transform(scaled_data)

pca_df = pd.DataFrame(
    data=principal_components,
    columns=["Principal_Component_1", "Principal_Component_2"]
)
print("\\nPCA Transformed Data:\\n")
print(pca_df)

print("\\nExplained Variance Ratio:", pca.explained_variance_ratio_)
print("Total Variance Explained : {:.2f}%".format(sum(pca.explained_variance_ratio_) * 100))
print("\\nPCA Components:\\n", pca.components_)

# ── Plot : PCA Scatter ────────────────────────────────────────────────────────
plt.figure(figsize=(7, 5))
sns.scatterplot(x=pca_df["Principal_Component_1"],
                y=pca_df["Principal_Component_2"], s=100)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("PCA — Dimensionality Reduction")
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
