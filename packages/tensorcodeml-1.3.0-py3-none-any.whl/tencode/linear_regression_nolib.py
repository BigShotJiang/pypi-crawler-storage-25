"""tencode: linear_regression_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Area_sqft":      [1000,1200,1400,1600,1800,2000,2200,2400,2600,2800,3000,3200,3400,3600,3800,4000,4200,4400,4600,4800],
    "Bedrooms":       [2,2,2,3,3,3,4,4,4,4,5,5,5,6,6,6,6,7,7,7],
    "Bathrooms":      [1,1,2,2,2,3,3,3,3,4,4,4,5,5,5,6,6,6,6,7],
    "Age_of_House":   [15,14,13,12,11,10,9,8,7,6,5,4,3,3,2,2,1,1,1,1],
    "Parking_Spaces": [1,1,1,2,2,2,3,3,3,3,4,4,4,5,5,5,6,6,6,7],
    "Price_Lakhs":    [40,45,50,60,68,75,85,95,105,115,125,135,150,165,175,190,205,220,235,250],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Price_Lakhs", axis=1).values
y = df["Price_Lakhs"].values

# ── Normalisation ─────────────────────────────────────────────────────────────
X_mean = X.mean(axis=0)
X_std  = X.std(axis=0)
X      = (X - X_mean) / X_std

# ── Train / Test Split (manual) ───────────────────────────────────────────────
np.random.seed(42)
indices      = np.random.permutation(len(X))
split        = int(0.8 * len(X))
X_train, X_test = X[indices[:split]], X[indices[split:]]
y_train, y_test = y[indices[:split]], y[indices[split:]]

# ── Hyperparameters ───────────────────────────────────────────────────────────
weights       = np.zeros(X_train.shape[1])
bias          = 0
learning_rate = 0.01
epochs        = 5000

# ── Training Loop ─────────────────────────────────────────────────────────────
for _ in range(epochs):
    y_predicted = np.dot(X_train, weights) + bias
    error       = y_predicted - y_train
    dw          = (1 / len(X_train)) * np.dot(X_train.T, error)
    db          = (1 / len(X_train)) * np.sum(error)
    weights    -= learning_rate * dw
    bias       -= learning_rate * db

print("\\nTraining Completed!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = np.dot(X_test, weights) + bias
print("\\nPredicted Values:\\n", y_pred)
print("\\nActual Values:\\n",    y_test)

# ── Evaluation ────────────────────────────────────────────────────────────────
mse         = np.mean((y_test - y_pred) ** 2)
rmse        = np.sqrt(mse)
mae         = np.mean(np.abs(y_test - y_pred))
ss_total    = np.sum((y_test - np.mean(y_test)) ** 2)
ss_residual = np.sum((y_test - y_pred) ** 2)
r2          = 1 - (ss_residual / ss_total)

print("\\nMean Squared Error      :", mse)
print("Root Mean Squared Error :", rmse)
print("Mean Absolute Error     :", mae)
print("R2 Score                :", r2)
print("\\nWeights:\\n", weights)
print("\\nBias:", bias)

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample          = (np.array([[2500, 4, 3, 5, 3]]) - X_mean) / X_std
predicted_price = np.dot(sample, weights) + bias
print("\\nPredicted House Price:", predicted_price[0], "Lakhs")

# ── Plot : Actual vs Predicted ────────────────────────────────────────────────
plt.figure(figsize=(6, 4))
plt.plot(y_test, marker='o', label="Actual")
plt.plot(y_pred, marker='x', label="Predicted")
plt.xlabel("Test Samples")
plt.ylabel("House Price (Lakhs)")
plt.title("Linear Regression — Actual vs Predicted")
plt.legend()
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
