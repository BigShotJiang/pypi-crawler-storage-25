"""tencode: boosting_adaboost_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "StudyHours":      [1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12],
    "Attendance":      [40, 45, 52, 58, 60, 63, 68, 72, 78, 82, 88, 91],
    "AssignmentScore": [35, 38, 48, 52, 50, 62, 60, 75, 73, 85, 82, 92],
    "Pass":            [0,  0,  0,  1,  0,  1,  1,  0,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X = df[["StudyHours", "Attendance", "AssignmentScore"]].values
y = np.where(df["Pass"].values == 0, -1, 1)   # Convert to {-1, +1}

# ── Decision Stump ────────────────────────────────────────────────────────────
class DecisionStump:
    def fit(self, X, y, weights):
        n_samples, n_features = X.shape
        self.feature_index    = None
        self.threshold        = None
        self.polarity         = 1
        min_error             = float('inf')

        for feature in range(n_features):
            for threshold in np.unique(X[:, feature]):
                predictions = np.ones(n_samples)
                predictions[X[:, feature] < threshold] = -1
                polarity = 1
                error    = np.sum(weights[y != predictions])
                if error > 0.5:
                    error    = 1 - error
                    polarity = -1
                if error < min_error:
                    min_error          = error
                    self.feature_index = feature
                    self.threshold     = threshold
                    self.polarity      = polarity
        return min_error

    def predict(self, X):
        predictions = np.ones(X.shape[0])
        if self.polarity == 1:
            predictions[X[:, self.feature_index] < self.threshold] = -1
        else:
            predictions[X[:, self.feature_index] >= self.threshold] = -1
        return predictions

# ── AdaBoost ──────────────────────────────────────────────────────────────────
class AdaBoost:
    def __init__(self, n_estimators=5):
        self.n_estimators          = n_estimators
        self.models                = []
        self.model_weights         = []
        self.sample_weights_history = []

    def fit(self, X, y):
        weights = np.full(X.shape[0], 1 / X.shape[0])
        for _ in range(self.n_estimators):
            stump        = DecisionStump()
            error        = stump.fit(X, y, weights)
            predictions  = stump.predict(X)
            stump_weight = 0.5 * np.log((1 - error) / (error + 1e-10))
            weights     *= np.exp(-stump_weight * y * predictions)
            weights     /= np.sum(weights)
            self.models.append(stump)
            self.model_weights.append(stump_weight)
            self.sample_weights_history.append(weights.copy())

    def predict(self, X):
        stump_preds = [w * s.predict(X) for s, w in zip(self.models, self.model_weights)]
        return np.sign(np.sum(stump_preds, axis=0))

# ── Train ─────────────────────────────────────────────────────────────────────
model = AdaBoost(n_estimators=5)
model.fit(X, y)
print("\\nTraining Completed!")

predictions = model.predict(X)
print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y)
print("\\nAccuracy :", np.sum(predictions == y) / len(y))

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample_pred = model.predict(np.array([[8, 78, 75]]))
print("\\nSample Prediction:")
print("Student Will Pass" if sample_pred[0] == 1 else "Student Will Fail")

# ── Plot 1 : Data Points ──────────────────────────────────────────────────────
plt.figure(figsize=(8, 6))
for i in range(len(X)):
    if y[i] == 1:
        plt.scatter(X[i][0], X[i][2], color='green', s=120, marker='o',
                    label='Pass' if i == 5 else "")
    else:
        plt.scatter(X[i][0], X[i][2], color='red', s=120, marker='x',
                    label='Fail' if i == 0 else "")
plt.xlabel("Study Hours")
plt.ylabel("Assignment Score")
plt.title("AdaBoost — Student Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ── Plot 2 : Sample Weight Changes ───────────────────────────────────────────
plt.figure(figsize=(8, 6))
for i, weights in enumerate(model.sample_weights_history):
    plt.plot(range(1, len(weights) + 1), weights, marker='o', label=f'Iteration {i+1}')
plt.xlabel("Samples")
plt.ylabel("Sample Weights")
plt.title("AdaBoost — Sample Weight Changes")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

print("\\nWeak Learner Details:")
for i, stump in enumerate(model.models):
    print(f"  Model {i+1} | Feature: {stump.feature_index} | Threshold: {stump.threshold} | Weight: {model.model_weights[i]:.4f}")
"""

def main():
    print(_CODE)
