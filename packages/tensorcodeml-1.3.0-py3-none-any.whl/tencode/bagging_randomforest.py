"""tencode: bagging_randomforest (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "URL_Length":       [45,  50,  60,  70,  80,  90,  100, 110, 120, 130],
    "Num_Dots":         [1,   1,   2,   2,   3,   3,   4,   4,   5,   5],
    "Num_Hyphens":      [0,   1,   1,   2,   2,   3,   3,   4,   4,   5],
    "Has_HTTPS":        [1,   1,   1,   1,   0,   0,   0,   0,   0,   0],
    "Domain_Age_Days":  [500, 450, 400, 350, 300, 200, 150, 100, 80,  50],
    "Target_Phishing":  [0,   0,   0,   0,   0,   1,   1,   1,   1,   1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Target_Phishing", axis=1)
y = df["Target_Phishing"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Model ─────────────────────────────────────────────────────────────────────
model = RandomForestClassifier(n_estimators=100, criterion="gini", random_state=42)
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
accuracy = accuracy_score(y_test, y_pred)
cm       = confusion_matrix(y_test, y_pred)
report   = classification_report(y_test, y_pred)

print("\\nAccuracy :", accuracy)
print("\\nConfusion Matrix:\\n", cm)
print("\\nClassification Report:\\n", report)

# ── Plot 1 : Confusion Matrix ─────────────────────────────────────────────────
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix — Random Forest")
plt.tight_layout()
plt.show()

# ── Feature Importance ────────────────────────────────────────────────────────
importance_df = pd.DataFrame({
    "Feature":    X.columns,
    "Importance": model.feature_importances_,
}).sort_values("Importance", ascending=False)

print("\\nFeature Importance:\\n")
print(importance_df)

# ── Plot 2 : Feature Importance ───────────────────────────────────────────────
plt.figure(figsize=(7, 5))
sns.barplot(x="Importance", y="Feature", data=importance_df)
plt.title("Feature Importance — Random Forest")
plt.tight_layout()
plt.show()

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample     = [[115, 5, 4, 0, 70]]
prediction = model.predict(sample)
print("\\nSample Prediction:")
print("Phishing URL" if prediction[0] == 1 else "Legitimate URL")
"""

def main():
    print(_CODE)
