"""tencode: bagging_randomforest_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
from collections import Counter
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Age":         [22, 25, 28, 30, 32, 35, 38, 40, 42, 45, 48, 50, 52, 55, 58],
    "Income":      [20, 25, 28, 32, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85],
    "CreditScore": [450,480,500,520,550,580,600,630,650,680,700,720,750,780,800],
    "LoanApproved":[0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X = df[["Age", "Income", "CreditScore"]].values
y = df["LoanApproved"].values

# ── Bootstrap Sampling ────────────────────────────────────────────────────────
def bootstrap_sample(X, y):
    indices = np.random.choice(len(X), len(X), replace=True)
    return X[indices], y[indices]

# ── Decision Stump ────────────────────────────────────────────────────────────
class DecisionStump:
    def fit(self, X, y):
        self.feature_index = 0
        self.threshold     = 0
        self.polarity      = 1
        min_error          = float('inf')

        for feature in range(X.shape[1]):
            for threshold in np.unique(X[:, feature]):
                predictions = np.ones(len(y))
                predictions[X[:, feature] < threshold] = 0
                error   = np.sum(predictions != y)
                polarity = 1
                if error > len(y) / 2:
                    error    = len(y) - error
                    polarity = -1
                if error < min_error:
                    min_error          = error
                    self.threshold     = threshold
                    self.feature_index = feature
                    self.polarity      = polarity

    def predict(self, X):
        predictions = np.ones(len(X))
        if self.polarity == 1:
            predictions[X[:, self.feature_index] < self.threshold] = 0
        else:
            predictions[X[:, self.feature_index] >= self.threshold] = 0
        return predictions

# ── Random Forest ─────────────────────────────────────────────────────────────
class RandomForest:
    def __init__(self, n_trees=5):
        self.n_trees = n_trees
        self.trees   = []

    def fit(self, X, y):
        for _ in range(self.n_trees):
            stump             = DecisionStump()
            X_sample, y_sample = bootstrap_sample(X, y)
            stump.fit(X_sample, y_sample)
            self.trees.append(stump)

    def predict(self, X):
        tree_preds = np.array([tree.predict(X) for tree in self.trees])
        return np.array([Counter(tree_preds[:, i]).most_common(1)[0][0]
                         for i in range(len(X))])

# ── Train ─────────────────────────────────────────────────────────────────────
model = RandomForest(n_trees=5)
model.fit(X, y)
print("\\nTraining Completed!")

predictions = model.predict(X)
print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y)
print("\\nAccuracy :", np.sum(predictions == y) / len(y))

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample_pred = model.predict(np.array([[40, 55, 690]]))
print("\\nSample Prediction:")
print("Loan Approved" if sample_pred[0] == 1 else "Loan Rejected")

# ── Plot 1 : Data Points ──────────────────────────────────────────────────────
plt.figure(figsize=(8, 6))
for i in range(len(X)):
    if y[i] == 1:
        plt.scatter(X[i][1], X[i][2], color='green', s=120, marker='o',
                    label='Approved' if i == 5 else "")
    else:
        plt.scatter(X[i][1], X[i][2], color='red', s=120, marker='x',
                    label='Rejected' if i == 0 else "")
plt.xlabel("Income")
plt.ylabel("Credit Score")
plt.title("Random Forest — Loan Approval")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ── Plot 2 : Tree Thresholds ──────────────────────────────────────────────────
thresholds = [tree.threshold for tree in model.trees]
plt.figure(figsize=(7, 5))
plt.bar(range(1, len(thresholds) + 1), thresholds)
plt.xlabel("Tree Number")
plt.ylabel("Threshold")
plt.title("Random Forest — Tree Thresholds")
plt.grid(True)
plt.tight_layout()
plt.show()

print("\\nRandom Forest Tree Details:")
for i, tree in enumerate(model.trees):
    print(f"  Tree {i+1} | Feature Index: {tree.feature_index} | Threshold: {tree.threshold}")
"""

def main():
    print(_CODE)
