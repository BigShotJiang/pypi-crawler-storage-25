"""tencode: boosting_adaboost (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "StudyHours":          [1,  2,  3,  4,  5,  6,  7,  8,  9,  10],
    "Attendance":          [50, 55, 60, 65, 70, 75, 80, 85, 90, 95],
    "InternalMarks":       [30, 35, 40, 45, 50, 55, 60, 65, 70, 75],
    "AssignmentsCompleted":[0,  0,  1,  1,  1,  1,  1,  1,  1,  1],
    "Result":              [0,  0,  0,  0,  0,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Result", axis=1)
y = df["Result"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Model ─────────────────────────────────────────────────────────────────────
model = AdaBoostClassifier(n_estimators=50, learning_rate=1, random_state=42)
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
accuracy = accuracy_score(y_test, y_pred)
cm       = confusion_matrix(y_test, y_pred)
report   = classification_report(y_test, y_pred)

print("\\nAccuracy :", accuracy)
print("\\nConfusion Matrix:\\n", cm)
print("\\nClassification Report:\\n", report)

# ── Plot : Confusion Matrix ───────────────────────────────────────────────────
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix — AdaBoost")
plt.tight_layout()
plt.show()

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample     = [[7, 82, 62, 1]]
prediction = model.predict(sample)
print("\\nSample Prediction:")
print("Student will Pass" if prediction[0] == 1 else "Student will Fail")
"""

def main():
    print(_CODE)
