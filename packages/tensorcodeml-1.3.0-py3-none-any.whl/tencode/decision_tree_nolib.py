"""tencode: decision_tree_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import math
from collections import Counter
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Attendance":          ["High","High","Medium","Low","Medium","High","Low","Medium","High","Low","Medium","High","Low","Medium","High","Low","Medium","High","Medium","Low"],
    "StudyHours":          ["High","Medium","Medium","Low","High","High","Low","Medium","High","Low","Medium","High","Low","Medium","High","Low","High","High","Medium","Low"],
    "InternalMarks":       ["Good","Good","Average","Poor","Average","Good","Poor","Average","Good","Poor","Average","Good","Poor","Average","Good","Poor","Average","Good","Average","Poor"],
    "AssignmentCompletion":["Yes","Yes","Yes","No","Yes","Yes","No","Yes","Yes","No","Yes","Yes","No","Yes","Yes","No","Yes","Yes","Yes","No"],
    "Result":              ["Pass","Pass","Pass","Fail","Pass","Pass","Fail","Pass","Pass","Fail","Pass","Pass","Fail","Pass","Pass","Fail","Pass","Pass","Pass","Fail"],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

dataset  = df.values.tolist()
features = df.columns[:-1].tolist()

# ── Helper Functions ──────────────────────────────────────────────────────────
def entropy(data):
    labels      = [row[-1] for row in data]
    total       = len(labels)
    label_count = Counter(labels)
    return -sum((c / total) * math.log2(c / total) for c in label_count.values())

def split_data(data, column):
    splits = {}
    for row in data:
        splits.setdefault(row[column], []).append(row)
    return splits

def information_gain(data, column):
    total            = len(data)
    splits           = split_data(data, column)
    weighted_entropy = sum((len(s) / total) * entropy(s) for s in splits.values())
    return entropy(data) - weighted_entropy

def best_feature(data):
    gains = [information_gain(data, i) for i in range(len(features))]
    return gains.index(max(gains))

# ── Find Best Root Feature ────────────────────────────────────────────────────
best_index = best_feature(dataset)
print("\\nBest Feature for Root Node:", features[best_index])

print("\\nInformation Gain Values:")
for i in range(len(features)):
    print(f"  {features[i]}: {information_gain(dataset, i):.4f}")

# ── Tree Structure ────────────────────────────────────────────────────────────
tree_structure = split_data(dataset, best_index)
print("\\nDecision Tree Structure:")
for key, value in tree_structure.items():
    print(f"\\n  {features[best_index]} = {key}")
    for row in value:
        print("   ", row)

# ── Plot 1 : Class Distribution ───────────────────────────────────────────────
results = df["Result"].value_counts()
plt.figure(figsize=(5, 4))
plt.bar(results.index, results.values, color=["green", "red"])
plt.xlabel("Result")
plt.ylabel("Count")
plt.title("Pass vs Fail Distribution")
plt.tight_layout()
plt.show()

# ── Sample Prediction (rule-based) ────────────────────────────────────────────
sample = ["High", "High", "Good", "Yes"]
print("\\nSample Prediction:")
print("Student will Pass" if sample[0] == "High" and sample[1] == "High" and sample[2] == "Good"
      else "Student may Fail")

# ── Plot 2 : Decision Tree Diagram ───────────────────────────────────────────
plt.figure(figsize=(12, 7))
plt.text(0.5, 0.95, "Attendance?", fontsize=14, ha='center', bbox=dict(facecolor='lightblue'))
plt.plot([0.5, 0.2], [0.92, 0.75])
plt.plot([0.5, 0.5], [0.92, 0.75])
plt.plot([0.5, 0.8], [0.92, 0.75])
plt.text(0.2, 0.72, "High",   fontsize=12, ha='center')
plt.text(0.5, 0.72, "Medium", fontsize=12, ha='center')
plt.text(0.8, 0.72, "Low",    fontsize=12, ha='center')
plt.text(0.2, 0.58, "StudyHours?",  fontsize=12, ha='center', bbox=dict(facecolor='lightyellow'))
plt.text(0.5, 0.58, "Assignments?", fontsize=12, ha='center', bbox=dict(facecolor='lightyellow'))
plt.text(0.8, 0.58, "Fail",         fontsize=12, ha='center', bbox=dict(facecolor='salmon'))
plt.plot([0.2, 0.1], [0.55, 0.38])
plt.plot([0.2, 0.3], [0.55, 0.38])
plt.plot([0.5, 0.4], [0.55, 0.38])
plt.plot([0.5, 0.6], [0.55, 0.38])
for x, label, color in [(0.1, "Pass", "lightgreen"), (0.3, "Pass", "lightgreen"),
                         (0.4, "Pass", "lightgreen"), (0.6, "Fail", "salmon")]:
    plt.text(x, 0.32, label, fontsize=11, ha='center', bbox=dict(facecolor=color))
for x, label in [(0.1, "High"), (0.3, "Medium"), (0.4, "Yes"), (0.6, "No")]:
    plt.text(x, 0.42, label, fontsize=10)
plt.axis('off')
plt.title("Multi-Level Decision Tree")
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
