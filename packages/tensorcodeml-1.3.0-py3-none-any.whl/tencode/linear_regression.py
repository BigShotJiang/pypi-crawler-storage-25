"""tencode: linear_regression (with libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Area_sqft":      [1000, 1200, 1500, 1800, 2000, 2200, 2500, 2700, 3000, 3200],
    "Bedrooms":       [2,    2,    3,    3,    4,    4,    4,    5,    5,    5],
    "Bathrooms":      [1,    2,    2,    2,    3,    3,    3,    4,    4,    4],
    "Age_of_House":   [15,   12,   10,   8,    7,    5,    4,    3,    2,    1],
    "Parking_Spaces": [1,    1,    2,    2,    2,    3,    3,    3,    4,    4],
    "Price_Lakhs":    [45,   50,   60,   72,   80,   90,   105,  115,  130,  140],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df[["Area_sqft", "Bedrooms", "Bathrooms", "Age_of_House", "Parking_Spaces"]]
y = df["Price_Lakhs"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Model ─────────────────────────────────────────────────────────────────────
model = LinearRegression()
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
mae  = mean_absolute_error(y_test, y_pred)
mse  = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2   = r2_score(y_test, y_pred)

print("\\nModel Evaluation")
print("Mean Absolute Error     :", mae)
print("Mean Squared Error      :", mse)
print("Root Mean Squared Error :", rmse)
print("R2 Score                :", r2)

# ── Coefficients ──────────────────────────────────────────────────────────────
print("\\nModel Parameters")
for feature, coef in zip(X.columns, model.coef_):
    print(f"  {feature}: {coef}")
print("Intercept:", model.intercept_)

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample          = [[2400, 4, 3, 4, 3]]
predicted_price = model.predict(sample)
print("\\nPredicted Price for Sample House:", predicted_price[0], "Lakhs")
"""

def main():
    print(_CODE)
