"""tencode: svm_nonlineardata_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Salary":        [25, 28, 30, 35, 38, 40, 42, 45, 48, 50, 52, 55, 58, 60, 62, 65],
    "SpendingScore": [90, 85, 80, 78, 75, 72, 70, 68, 30, 28, 25, 22, 20, 18, 15, 12],
    "Purchased":     [-1, -1, -1, -1, -1, -1, -1, -1, 1,  1,  1,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Labels ─────────────────────────────────────────────────────────
X = df[["Salary", "SpendingScore"]].values
y = df["Purchased"].values

X_mean = X.mean(axis=0)
X_std  = X.std(axis=0)
X      = (X - X_mean) / X_std

# ── RBF Kernel ────────────────────────────────────────────────────────────────
def rbf_kernel(x1, x2, gamma=1):
    return np.exp(-gamma * np.linalg.norm(x1 - x2) ** 2)

# ── Kernel Matrix ─────────────────────────────────────────────────────────────
n_samples     = len(X)
kernel_matrix = np.array([[rbf_kernel(X[i], X[j]) for j in range(n_samples)]
                           for i in range(n_samples)])

# ── Training (Dual Perceptron) ────────────────────────────────────────────────
alpha         = np.zeros(n_samples)
learning_rate = 0.01
epochs        = 1000

for _ in range(epochs):
    for i in range(n_samples):
        prediction = sum(alpha[j] * y[j] * kernel_matrix[j][i] for j in range(n_samples))
        if y[i] * prediction < 1:
            alpha[i] += learning_rate

# ── Predict Function ──────────────────────────────────────────────────────────
def predict(x_new):
    x_new = (x_new - X_mean) / X_std
    result = sum(alpha[i] * y[i] * rbf_kernel(X[i], x_new) for i in range(n_samples))
    return np.sign(result)

# ── Evaluate on Training Data ─────────────────────────────────────────────────
predictions = [np.sign(sum(alpha[j] * y[j] * kernel_matrix[j][i]
                           for j in range(n_samples))) for i in range(n_samples)]
print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y)
print("\\nAccuracy :", np.sum(predictions == y) / len(y))

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample_pred = predict(np.array([47, 35]))
print("\\nSample Prediction:")
print("Customer Purchased Product" if sample_pred == 1 else "Customer Did Not Purchase Product")

# ── Plot : Decision Boundary ──────────────────────────────────────────────────
plt.figure(figsize=(8, 6))
for i in range(len(X)):
    if y[i] == 1:
        plt.scatter(X[i][0], X[i][1], color='blue', s=100, marker='o',
                    label='Purchased' if i == 8 else "")
    else:
        plt.scatter(X[i][0], X[i][1], color='orange', s=100, marker='x',
                    label='Not Purchased' if i == 0 else "")

x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                     np.linspace(y_min, y_max, 200))
Z = np.array([[sum(alpha[k] * y[k] * rbf_kernel(X[k], np.array([xx[i, j], yy[i, j]]))
               for k in range(n_samples)) for j in range(xx.shape[1])]
              for i in range(xx.shape[0])])

plt.contourf(xx, yy, Z, levels=50, alpha=0.3, cmap='coolwarm')
plt.contour(xx,  yy, Z, levels=[0], colors='black', linewidths=2)
plt.xlabel("Salary (normalised)")
plt.ylabel("Spending Score (normalised)")
plt.title("SVM (RBF Kernel) — Purchase Prediction")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
