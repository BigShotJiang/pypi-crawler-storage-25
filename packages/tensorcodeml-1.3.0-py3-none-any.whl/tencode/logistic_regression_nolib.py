"""tencode: logistic_regression_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "StudyHours":      [1,  2,  3,  4,  5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15],
    "Attendance":      [45, 50, 52, 55, 60, 63, 68, 72, 75, 80, 85, 88, 90, 93, 95],
    "AssignmentScore": [40, 42, 45, 50, 55, 58, 62, 68, 72, 75, 80, 84, 87, 90, 94],
    "Pass":            [0,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Labels ─────────────────────────────────────────────────────────
X = df[["StudyHours", "Attendance"]].values
y = df["Pass"].values

# ── Normalisation (Z-score) ───────────────────────────────────────────────────
X_mean = X.mean(axis=0)
X_std  = X.std(axis=0)
X      = (X - X_mean) / X_std

# ── Hyperparameters ───────────────────────────────────────────────────────────
weights       = np.zeros(X.shape[1])
bias          = 0
learning_rate = 0.01
epochs        = 5000

# ── Sigmoid Function ──────────────────────────────────────────────────────────
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# ── Training Loop ─────────────────────────────────────────────────────────────
loss_history = []

for epoch in range(epochs):
    # Forward pass
    y_predicted = sigmoid(np.dot(X, weights) + bias)

    # Binary cross-entropy loss
    loss = -(1 / len(y)) * np.sum(
        y * np.log(y_predicted + 1e-10) +
        (1 - y) * np.log(1 - y_predicted + 1e-10)
    )
    loss_history.append(loss)

    # Gradients
    dw = (1 / len(X)) * np.dot(X.T, (y_predicted - y))
    db = (1 / len(X)) * np.sum(y_predicted - y)

    # Update parameters
    weights -= learning_rate * dw
    bias    -= learning_rate * db

print("\\nTraining Completed!")

# ── Predictions ───────────────────────────────────────────────────────────────
predicted_probabilities = sigmoid(np.dot(X, weights) + bias)
predictions = np.where(predicted_probabilities >= 0.5, 1, 0)

print("\\nPredicted Values:\\n", predictions)
print("\\nActual Values:\\n",    y)

accuracy = np.sum(predictions == y) / len(y)
print("\\nAccuracy :", accuracy)
print("\\nWeights:\\n", weights)
print("\\nBias:\\n",    bias)

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample             = np.array([[8, 76]])
sample             = (sample - X_mean) / X_std
sample_probability = sigmoid(np.dot(sample, weights) + bias)

print("\\nProbability of Passing :", sample_probability[0])
print("Student Will Pass" if sample_probability[0] >= 0.5 else "Student Will Fail")

# ── Plot 1 : Decision Boundary ────────────────────────────────────────────────
plt.figure(figsize=(8, 6))

for i in range(len(X)):
    if y[i] == 1:
        plt.scatter(X[i][0], X[i][1], color='green', s=120, marker='o',
                    label='Pass' if i == 6 else "")
    else:
        plt.scatter(X[i][0], X[i][1], color='red', s=120, marker='x',
                    label='Fail' if i == 0 else "")

x1 = np.linspace(min(X[:, 0]) - 1, max(X[:, 0]) + 1, 100)
x2 = -(weights[0] * x1 + bias) / weights[1]

plt.plot(x1, x2, color='blue', linewidth=2, label='Decision Boundary')
plt.xlabel("Study Hours (normalised)")
plt.ylabel("Attendance (normalised)")
plt.title("Logistic Regression — Decision Boundary")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ── Plot 2 : Loss Curve ───────────────────────────────────────────────────────
plt.figure(figsize=(7, 5))
plt.plot(range(epochs), loss_history, color='purple')
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Logistic Regression — Loss Reduction")
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
