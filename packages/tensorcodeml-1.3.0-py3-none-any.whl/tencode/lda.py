"""tencode: lda (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Maths":      [85, 78, 90, 65, 70, 88, 92, 60, 75, 80],
    "Science":    [80, 74, 95, 60, 68, 90, 96, 58, 72, 85],
    "English":    [78, 70, 88, 62, 66, 84, 91, 55, 73, 79],
    "Computer":   [92, 85, 97, 70, 72, 95, 99, 65, 80, 88],
    "Attendance": [90, 85, 95, 75, 78, 92, 97, 70, 82, 88],
    "Result":     [1,  1,  1,  0,  0,  1,  1,  0,  0,  1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Result", axis=1)
y = df["Result"]

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X)
print("\\nScaled Data:\\n")
print(X_scaled)

# ── LDA ───────────────────────────────────────────────────────────────────────
lda            = LinearDiscriminantAnalysis(n_components=1)
lda_components = lda.fit_transform(X_scaled, y)

lda_df = pd.DataFrame(data=lda_components, columns=["LDA_Component"])
lda_df["Result"] = y.values
print("\\nLDA Reduced Data:\\n")
print(lda_df)

print("\\nLDA Coefficients:\\n",        lda.coef_)
print("\\nExplained Variance Ratio:\\n", lda.explained_variance_ratio_)

# ── Plot : LDA Scatter ────────────────────────────────────────────────────────
plt.figure(figsize=(7, 5))
sns.scatterplot(x=lda_df.index, y=lda_df["LDA_Component"],
                hue=lda_df["Result"], palette="viridis", s=100)
plt.xlabel("Data Points")
plt.ylabel("LDA Component")
plt.title("LDA — Dimensionality Reduction")
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
