"""tencode: lda_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Maths":      [85,78,90,65,70,88,92,60,75,80,72,95,67,83,91],
    "Science":    [80,74,95,60,68,90,96,58,72,85,70,98,64,82,94],
    "English":    [78,70,88,62,66,84,91,55,73,79,68,94,61,80,90],
    "Computer":   [92,85,97,70,72,95,99,65,80,88,74,100,68,86,98],
    "Attendance": [90,85,95,75,78,92,97,70,82,88,76,99,72,87,96],
    "Result":     [1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X            = df.drop("Result", axis=1).values.astype(float)
y            = df["Result"].values
class_labels = np.unique(y)
n_features   = X.shape[1]

# ── Class Mean Vectors ────────────────────────────────────────────────────────
mean_vectors  = [X[y == label].mean(axis=0) for label in class_labels]
overall_mean  = X.mean(axis=0)

# ── Within-Class Scatter Matrix (SW) ─────────────────────────────────────────
SW = np.zeros((n_features, n_features))
for label, mv in zip(class_labels, mean_vectors):
    for row in X[y == label]:
        diff  = (row - mv).reshape(n_features, 1)
        SW   += diff.dot(diff.T)

# ── Between-Class Scatter Matrix (SB) ────────────────────────────────────────
SB = np.zeros((n_features, n_features))
for i, mean_vec in enumerate(mean_vectors):
    n    = len(X[y == i])
    diff = (mean_vec - overall_mean).reshape(n_features, 1)
    SB  += n * diff.dot(diff.T)

# ── Eigen Decomposition of SW^-1 * SB ────────────────────────────────────────
A                       = np.linalg.inv(SW).dot(SB)
eigen_values, eigen_vecs = np.linalg.eig(A)

sorted_idx  = np.argsort(np.abs(eigen_values))[::-1]
eigen_values = eigen_values[sorted_idx]
eigen_vecs   = eigen_vecs[:, sorted_idx]

W     = eigen_vecs[:, :2]
X_lda = X.dot(W)

print("\\nEigenvalues:\\n",    eigen_values)
print("\\nReduced Dataset:\\n", X_lda)

# ── Plot 1 : Before vs After LDA ─────────────────────────────────────────────
fig = plt.figure(figsize=(14, 6))

ax1 = fig.add_subplot(1, 2, 1, projection='3d')
for label, color, marker in zip(class_labels, ['blue', 'red'], ['o', '^']):
    ax1.scatter(X[y == label, 0], X[y == label, 1], X[y == label, 2],
                c=color, marker=marker, s=100, label=f'Class {label}')
ax1.set_xlabel("Maths")
ax1.set_ylabel("Science")
ax1.set_zlabel("English")
ax1.set_title("Before LDA (3D)")
ax1.legend()

ax2 = fig.add_subplot(1, 2, 2)
for label, color, marker in zip(class_labels, ['green', 'orange'], ['o', 's']):
    ax2.scatter(X_lda[y == label, 0], X_lda[y == label, 1],
                c=color, marker=marker, s=140, label=f'Class {label}')
for i in range(len(X_lda)):
    ax2.text(X_lda[i, 0], X_lda[i, 1], str(i + 1), fontsize=9)
ax2.set_xlabel("Linear Discriminant 1")
ax2.set_ylabel("Linear Discriminant 2")
ax2.set_title("After LDA (Class Separation)")
ax2.legend()
ax2.grid(True)

plt.tight_layout()
plt.show()

# ── Plot 2 : Discriminant Power ───────────────────────────────────────────────
explained = np.abs(eigen_values[:2])
plt.figure(figsize=(7, 5))
plt.bar(["LD1", "LD2"], explained, color=['purple', 'cyan'])
for i, v in enumerate(explained):
    plt.text(i, v + 0.2, round(float(v), 2), ha='center')
plt.ylabel("Discriminant Power")
plt.title("LDA — Component Importance")
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
