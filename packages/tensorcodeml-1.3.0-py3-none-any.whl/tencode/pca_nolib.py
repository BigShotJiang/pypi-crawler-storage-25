"""tencode: pca_nolib (without libraries)"""

_CODE = """\
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Maths":      [85,78,90,65,70,88,92,60,75,80,72,95],
    "Science":    [80,74,95,60,68,90,96,58,72,85,70,98],
    "English":    [78,70,88,62,66,84,91,55,73,79,68,94],
    "Computer":   [92,85,97,70,72,95,99,65,80,88,74,100],
    "Attendance": [90,85,95,75,78,92,97,70,82,88,76,99],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

X = df.values

# ── Standardise ───────────────────────────────────────────────────────────────
X = (X - X.mean(axis=0)) / X.std(axis=0)

# ── Covariance Matrix & Eigen Decomposition ───────────────────────────────────
cov_matrix              = np.cov(X, rowvar=False)
eigen_values, eigen_vecs = np.linalg.eig(cov_matrix)

# Sort by descending eigenvalue
sorted_idx      = np.argsort(eigen_values)[::-1]
eigen_values    = eigen_values[sorted_idx]
eigen_vecs      = eigen_vecs[:, sorted_idx]

# ── Project to 2 Components ───────────────────────────────────────────────────
principal_components = eigen_vecs[:, :2]
X_pca                = np.dot(X, principal_components)

explained_variance = (eigen_values / np.sum(eigen_values)) * 100
print("\\nEigenvalues:\\n",         eigen_values)
print("\\nExplained Variance (%):", explained_variance)
print("\\nReduced Dataset:\\n",     X_pca)

# ── Plot 1 : Before vs After PCA ──────────────────────────────────────────────
fig = plt.figure(figsize=(14, 6))

ax1 = fig.add_subplot(1, 2, 1, projection='3d')
ax1.scatter(X[:, 0], X[:, 1], X[:, 2], c='blue', s=100)
ax1.set_xlabel("Maths")
ax1.set_ylabel("Science")
ax1.set_zlabel("English")
ax1.set_title("Before PCA (3D)")

ax2 = fig.add_subplot(1, 2, 2)
scatter = ax2.scatter(X_pca[:, 0], X_pca[:, 1],
                      c=range(len(X_pca)), cmap='viridis', s=120)
for i in range(len(X_pca)):
    ax2.text(X_pca[i, 0], X_pca[i, 1], str(i + 1))
ax2.set_xlabel("Principal Component 1")
ax2.set_ylabel("Principal Component 2")
ax2.set_title("After PCA (2D)")
ax2.grid(True)
plt.colorbar(scatter, ax=ax2, label="Student Index")
plt.tight_layout()
plt.show()

# ── Plot 2 : Explained Variance Bar ──────────────────────────────────────────
plt.figure(figsize=(7, 5))
plt.bar(["PC1", "PC2", "PC3", "PC4", "PC5"], explained_variance)
plt.ylabel("Explained Variance (%)")
plt.title("PCA — Explained Variance per Component")
plt.grid(True)
plt.tight_layout()
plt.show()
"""

def main():
    print(_CODE)
