"""tencode: k_means_clustering (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Annual_Income":    [15, 18, 20, 22, 25, 60, 62, 65, 68, 70],
    "Spending_Score":   [20, 25, 30, 28, 35, 70, 75, 80, 78, 85],
    "Age":              [18, 20, 22, 24, 26, 40, 42, 44, 46, 48],
    "Online_Purchases": [2,  3,  4,  3,  5,  12, 13, 15, 14, 16],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Scaling ───────────────────────────────────────────────────────────────────
scaler      = StandardScaler()
scaled_data = scaler.fit_transform(df)

# ── Elbow Method ──────────────────────────────────────────────────────────────
wcss = []
for i in range(1, 11):
    km = KMeans(n_clusters=i, random_state=42, n_init=10)
    km.fit(scaled_data)
    wcss.append(km.inertia_)

plt.figure(figsize=(6, 4))
plt.plot(range(1, 11), wcss, marker="o")
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")
plt.title("Elbow Method")
plt.tight_layout()
plt.show()

# ── Model ─────────────────────────────────────────────────────────────────────
kmeans   = KMeans(n_clusters=2, random_state=42, n_init=10)
clusters = kmeans.fit_predict(scaled_data)

df["Cluster"] = clusters
print("\\nDataset with Cluster Labels:\\n")
print(df)

# ── Silhouette Score ──────────────────────────────────────────────────────────
score = silhouette_score(scaled_data, clusters)
print("\\nSilhouette Score:", score)

# ── Plot : Clusters ───────────────────────────────────────────────────────────
centroids = scaler.inverse_transform(kmeans.cluster_centers_)

plt.figure(figsize=(7, 5))
sns.scatterplot(x=df["Annual_Income"], y=df["Spending_Score"],
                hue=df["Cluster"], palette="viridis", s=100)
plt.scatter(centroids[:, 0], centroids[:, 1],
            color="red", marker="X", s=200, label="Centroids")
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("K-Means Clustering")
plt.legend()
plt.tight_layout()
plt.show()

print("\\nCluster Centers:\\n")
print(centroids)
"""

def main():
    print(_CODE)
