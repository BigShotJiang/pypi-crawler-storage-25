"""tencode index"""

WITH_LIBRARIES = [
    "bagging_randomforest",
    "boosting_adaboost",
    "boosting_xgboost",
    "decision_tree",
    "k_means_clustering",
    "lda",
    "linear_regression",
    "logistic_regression",
    "pca",
    "svd",
    "svm_lineardata",
    "svm_nonlineardata",
]

WITHOUT_LIBRARIES = [
    "bagging_randomforest_nolib",
    "boosting_adaboost_nolib",
    "boosting_xgboost_nolib",
    "decision_tree_nolib",
    "k_means_clustering_nolib",
    "lda_nolib",
    "linear_regression_nolib",
    "logistic_regression_nolib",
    "pca_nolib",
    "svd_nolib",
    "svm_lineardata_nolib",
    "svm_nonlineardata_nolib",
]

def main():
    print("=" * 54)
    print("  tencode — ML Code Reference Library")
    print("=" * 54)
    print()
    print("with libraries:")
    for name in WITH_LIBRARIES:
        print(f"    {name}")
    print()
    print("without libraries:")
    for name in WITHOUT_LIBRARIES:
        print(f"    {name}")
    print()
    print("Usage:")
    print("    from tencode import <module_name>")
    print("    <module_name>.main()")
    print("=" * 54)
