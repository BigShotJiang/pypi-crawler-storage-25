"""tencode: boosting_xgboost (with libraries)"""

_CODE = """\
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# ── Dataset ──────────────────────────────────────────────────────────────────
data = {
    "Age":                [22,    25,    28,    30,    35,    40,    45,    50,    55,    60],
    "Salary":             [25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000],
    "Experience_Years":   [1,     2,     3,     4,     5,     6,     7,     8,     9,     10],
    "Education_Level":    [1,     2,     2,     3,     3,     3,     4,     4,     4,     4],
    "Projects_Completed": [1,     2,     3,     4,     5,     6,     7,     8,     9,     10],
    "Target":             [0,     0,     0,     0,     1,     1,     1,     1,     1,     1],
}

df = pd.DataFrame(data)
print("Dataset:\\n")
print(df)

# ── Features & Target ─────────────────────────────────────────────────────────
X = df.drop("Target", axis=1)
y = df["Target"]

# ── Train / Test Split ────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("\\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape :", X_test.shape)

# ── Model ─────────────────────────────────────────────────────────────────────
# Note: use_label_encoder was removed in XGBoost >= 1.6, so it is not used here
model = XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=3,
    random_state=42,
    eval_metric="logloss",
)
model.fit(X_train, y_train)
print("\\nModel trained successfully!")

# ── Predictions ───────────────────────────────────────────────────────────────
y_pred = model.predict(X_test)
print("\\nPredicted Values:", y_pred)
print("Actual Values   :", y_test.values)

# ── Evaluation ────────────────────────────────────────────────────────────────
accuracy = accuracy_score(y_test, y_pred)
cm       = confusion_matrix(y_test, y_pred)
report   = classification_report(y_test, y_pred)

print("\\nAccuracy :", accuracy)
print("\\nConfusion Matrix:\\n", cm)
print("\\nClassification Report:\\n", report)

# ── Plot 1 : Confusion Matrix ─────────────────────────────────────────────────
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix — XGBoost")
plt.tight_layout()
plt.show()

# ── Feature Importance ────────────────────────────────────────────────────────
importance_df = pd.DataFrame({
    "Feature":    X.columns,
    "Importance": model.feature_importances_,
}).sort_values("Importance", ascending=False)

print("\\nFeature Importance:\\n")
print(importance_df)

# ── Plot 2 : Feature Importance ───────────────────────────────────────────────
plt.figure(figsize=(7, 5))
sns.barplot(x="Importance", y="Feature", data=importance_df)
plt.title("Feature Importance — XGBoost")
plt.tight_layout()
plt.show()

# ── Sample Prediction ─────────────────────────────────────────────────────────
sample     = [[42, 52000, 6, 3, 7]]
prediction = model.predict(sample)
print("\\nSample Prediction:")
print("High Performance Employee" if prediction[0] == 1 else "Low Performance Employee")
"""

def main():
    print(_CODE)
