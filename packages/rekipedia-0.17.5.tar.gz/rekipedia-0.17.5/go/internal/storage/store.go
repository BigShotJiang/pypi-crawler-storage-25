// Package storage provides SQLite-backed persistence for rekipedia.
package storage

import (
	"database/sql"
	"fmt"
	"path/filepath"
	"sort"
	"strings"
	"time"

	_ "modernc.org/sqlite"

	"github.com/unrealandychan/rekipedia/internal/models"
)

const schemaVersion = 1

// Store wraps a SQLite database with high-level operations.
type Store struct {
	db   *sql.DB
	path string
}

// Open opens (or creates) a Store at dbPath.
func Open(dbPath string) (*Store, error) {
	db, err := sql.Open("sqlite", dbPath+"?_journal_mode=WAL&_foreign_keys=on")
	if err != nil {
		return nil, fmt.Errorf("open sqlite: %w", err)
	}
	s := &Store{db: db, path: dbPath}
	if err := s.migrate(); err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("migrate: %w", err)
	}
	return s, nil
}

// DefaultPath returns the standard store path inside a repo's .rekipedia dir.
func DefaultPath(repoRoot string) string {
	return filepath.Join(repoRoot, ".rekipedia", "store.db")
}

// Close closes the underlying database connection.
func (s *Store) Close() error {
	return s.db.Close()
}

// migrate creates tables if they don't exist.
func (s *Store) migrate() error {
	ddl := []string{
		`CREATE TABLE IF NOT EXISTS runs (
			run_id      TEXT PRIMARY KEY,
			repo_path   TEXT NOT NULL,
			started_at  TEXT NOT NULL,
			finished_at TEXT,
			status      TEXT NOT NULL DEFAULT 'running',
			model       TEXT,
			page_count  INTEGER DEFAULT 0
		)`,
		`CREATE TABLE IF NOT EXISTS symbols (
			id         INTEGER PRIMARY KEY AUTOINCREMENT,
			run_id     TEXT NOT NULL,
			name       TEXT NOT NULL,
			kind       TEXT NOT NULL,
			file       TEXT NOT NULL,
			line_start INTEGER,
			line_end   INTEGER,
			signature  TEXT,
			docstring  TEXT
		)`,
		`CREATE TABLE IF NOT EXISTS relationships (
			id       INTEGER PRIMARY KEY AUTOINCREMENT,
			run_id   TEXT NOT NULL,
			from_sym TEXT NOT NULL,
			to_sym   TEXT NOT NULL,
			kind     TEXT NOT NULL,
			file     TEXT
		)`,
		`CREATE TABLE IF NOT EXISTS wiki_pages (
			id           INTEGER PRIMARY KEY AUTOINCREMENT,
			run_id       TEXT NOT NULL,
			slug         TEXT NOT NULL,
			title        TEXT NOT NULL,
			section      TEXT,
			content      TEXT,
			priority     INTEGER DEFAULT 50,
			importance   INTEGER DEFAULT 50,
			generated_at TEXT
		)`,
		`CREATE UNIQUE INDEX IF NOT EXISTS uq_wiki_slug ON wiki_pages(run_id, slug)`,
		`CREATE TABLE IF NOT EXISTS qa_history (
			id        INTEGER PRIMARY KEY AUTOINCREMENT,
			run_id    TEXT,
			question  TEXT NOT NULL,
			answer    TEXT,
			asked_at  TEXT NOT NULL
		)`,
		`CREATE TABLE IF NOT EXISTS file_manifest (
			path       TEXT PRIMARY KEY,
			sha256     TEXT NOT NULL,
			size_bytes INTEGER,
			language   TEXT,
			last_seen  TEXT NOT NULL
		)`,
		`CREATE TABLE IF NOT EXISTS tech_lead_notes (
			id         TEXT PRIMARY KEY,
			content    TEXT NOT NULL,
			tags       TEXT NOT NULL DEFAULT '',
			source     TEXT NOT NULL DEFAULT 'manual',
			created_at TEXT NOT NULL,
			updated_at TEXT NOT NULL
		)`,
		`CREATE TABLE IF NOT EXISTS codebase_tree (
			id        INTEGER PRIMARY KEY AUTOINCREMENT,
			run_id    TEXT    NOT NULL,
			path      TEXT    NOT NULL,
			name      TEXT    NOT NULL,
			kind      TEXT    NOT NULL CHECK(kind IN ('file','dir')),
			language  TEXT,
			parent_id INTEGER REFERENCES codebase_tree(id),
			depth     INTEGER NOT NULL DEFAULT 0,
			UNIQUE(run_id, path)
		)`,
	}
	for _, stmt := range ddl {
		if _, err := s.db.Exec(stmt); err != nil {
			return fmt.Errorf("ddl %q: %w", stmt[:40], err)
		}
	}
	return nil
}

// --- Runs ---

// CreateRun inserts a new scan run record.
func (s *Store) CreateRun(runID, repoPath, model string) error {
	_, err := s.db.Exec(
		`INSERT INTO runs (run_id, repo_path, started_at, status, model) VALUES (?, ?, ?, 'running', ?)`,
		runID, repoPath, time.Now().UTC().Format(time.RFC3339), model,
	)
	return err
}

// FinishRun marks a run as complete with page count.
func (s *Store) FinishRun(runID string, pageCount int) error {
	_, err := s.db.Exec(
		`UPDATE runs SET status='done', finished_at=?, page_count=? WHERE run_id=?`,
		time.Now().UTC().Format(time.RFC3339), pageCount, runID,
	)
	return err
}

// LatestRunID returns the most recent run_id for the given repo.
func (s *Store) LatestRunID(repoPath string) (string, error) {
	var id string
	err := s.db.QueryRow(
		`SELECT run_id FROM runs WHERE repo_path=? ORDER BY started_at DESC LIMIT 1`,
		repoPath,
	).Scan(&id)
	if err == sql.ErrNoRows {
		return "", nil
	}
	return id, err
}

// --- Symbols ---

// SaveSymbols bulk-inserts symbols for a run.
func (s *Store) SaveSymbols(runID string, syms []models.Symbol) error {
	tx, err := s.db.Begin()
	if err != nil {
		return err
	}
	stmt, err := tx.Prepare(
		`INSERT INTO symbols (run_id,name,kind,file,line_start,line_end,signature,docstring)
		 VALUES (?,?,?,?,?,?,?,?)`,
	)
	if err != nil {
		_ = tx.Rollback()
		return err
	}
	defer stmt.Close()
	for _, sym := range syms {
		if _, err := stmt.Exec(runID, sym.Name, string(sym.Kind), sym.File,
			sym.LineStart, sym.LineEnd, sym.Signature, sym.Docstring); err != nil {
			_ = tx.Rollback()
			return err
		}
	}
	return tx.Commit()
}

// ListSymbols returns all symbols for a run.
func (s *Store) ListSymbols(runID string) ([]models.Symbol, error) {
	rows, err := s.db.Query(
		`SELECT name,kind,file,line_start,line_end,signature,docstring FROM symbols WHERE run_id=?`,
		runID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var syms []models.Symbol
	for rows.Next() {
		var sym models.Symbol
		var kind string
		if err := rows.Scan(&sym.Name, &kind, &sym.File,
			&sym.LineStart, &sym.LineEnd, &sym.Signature, &sym.Docstring); err != nil {
			return nil, err
		}
		sym.Kind = models.SymbolKind(kind)
		syms = append(syms, sym)
	}
	return syms, rows.Err()
}

// --- Relationships ---

// SaveRelationships bulk-inserts relationships.
func (s *Store) SaveRelationships(runID string, rels []models.Relationship) error {
	tx, err := s.db.Begin()
	if err != nil {
		return err
	}
	stmt, err := tx.Prepare(
		`INSERT INTO relationships (run_id,from_sym,to_sym,kind,file) VALUES (?,?,?,?,?)`,
	)
	if err != nil {
		_ = tx.Rollback()
		return err
	}
	defer stmt.Close()
	for _, r := range rels {
		if _, err := stmt.Exec(runID, r.From, r.To, string(r.Kind), r.File); err != nil {
			_ = tx.Rollback()
			return err
		}
	}
	return tx.Commit()
}

// ListRelationships returns all relationships for a run.
func (s *Store) ListRelationships(runID string) ([]models.Relationship, error) {
	rows, err := s.db.Query(
		`SELECT from_sym, to_sym, kind, file FROM relationships WHERE run_id = ?`, runID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var rels []models.Relationship
	for rows.Next() {
		var r models.Relationship
		var kind string
		if err := rows.Scan(&r.From, &r.To, &kind, &r.File); err != nil {
			return nil, err
		}
		r.Kind = models.RelKind(kind)
		rels = append(rels, r)
	}
	return rels, rows.Err()
}

// --- Wiki Pages ---

// UpsertWikiPage inserts or replaces a wiki page.
func (s *Store) UpsertWikiPage(runID, slug, title, section, content string, priority, importance int) error {
	_, err := s.db.Exec(
		`INSERT INTO wiki_pages (run_id,slug,title,section,content,priority,importance,generated_at)
		 VALUES (?,?,?,?,?,?,?,?)
		 ON CONFLICT(run_id,slug) DO UPDATE SET
		   title=excluded.title, section=excluded.section, content=excluded.content,
		   priority=excluded.priority, importance=excluded.importance, generated_at=excluded.generated_at`,
		runID, slug, title, section, content, priority, importance,
		time.Now().UTC().Format(time.RFC3339),
	)
	return err
}

// GetWikiPage retrieves a single page by slug.
func (s *Store) GetWikiPage(runID, slug string) (title, section, content string, err error) {
	err = s.db.QueryRow(
		`SELECT title, section, content FROM wiki_pages WHERE run_id=? AND slug=?`,
		runID, slug,
	).Scan(&title, &section, &content)
	return
}

// ListWikiPages returns all pages for a run, ordered by importance desc.
func (s *Store) ListWikiPages(runID string) ([]WikiPageRow, error) {
	rows, err := s.db.Query(
		`SELECT slug, title, section, importance, priority FROM wiki_pages
		 WHERE run_id=? ORDER BY importance DESC, priority DESC`,
		runID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var pages []WikiPageRow
	for rows.Next() {
		var p WikiPageRow
		if err := rows.Scan(&p.Slug, &p.Title, &p.Section, &p.Importance, &p.Priority); err != nil {
			return nil, err
		}
		pages = append(pages, p)
	}
	return pages, rows.Err()
}

// WikiPageRow is a lightweight summary of a wiki page (no content).
type WikiPageRow struct {
	Slug       string
	Title      string
	Section    string
	Importance int
	Priority   int
}

// --- Q&A History ---

// SaveQA records a question/answer pair.
func (s *Store) SaveQA(runID, question, answer string) error {
	_, err := s.db.Exec(
		`INSERT INTO qa_history (run_id,question,answer,asked_at) VALUES (?,?,?,?)`,
		runID, question, answer, time.Now().UTC().Format(time.RFC3339),
	)
	return err
}

// --- File Manifest ---

// UpsertManifest inserts or updates a file's manifest record.
func (s *Store) UpsertManifest(path, sha256, language string, sizeBytes int64) error {
	_, err := s.db.Exec(
		`INSERT INTO file_manifest (path,sha256,size_bytes,language,last_seen)
		 VALUES (?,?,?,?,?)
		 ON CONFLICT(path) DO UPDATE SET
		   sha256=excluded.sha256, size_bytes=excluded.size_bytes,
		   language=excluded.language, last_seen=excluded.last_seen`,
		path, sha256, sizeBytes, language, time.Now().UTC().Format(time.RFC3339),
	)
	return err
}

// GetManifest returns the stored manifest for a path, or ("","",0) if not found.
func (s *Store) GetManifest(path string) (sha256, language string, sizeBytes int64, err error) {
	err = s.db.QueryRow(
		`SELECT sha256, language, size_bytes FROM file_manifest WHERE path=?`, path,
	).Scan(&sha256, &language, &sizeBytes)
	if err == sql.ErrNoRows {
		return "", "", 0, nil
	}
	return
}

// --- Tech Lead Notes ---

// NoteRow represents a tech lead note.
type NoteRow struct {
	ID        string
	Content   string
	Tags      string
	Source    string
	CreatedAt string
	UpdatedAt string
}

// UpsertNote inserts or updates a tech lead note. Returns the note ID.
func (s *Store) UpsertNote(content, tags, source string, id ...string) (string, error) {
	var noteID string
	if len(id) > 0 && id[0] != "" {
		noteID = id[0]
	} else {
		noteID = fmt.Sprintf("%x", time.Now().UnixNano())
	}
	now := time.Now().UTC().Format(time.RFC3339)
	_, err := s.db.Exec(
		`INSERT INTO tech_lead_notes (id,content,tags,source,created_at,updated_at)
		 VALUES (?,?,?,?,?,?)
		 ON CONFLICT(id) DO UPDATE SET
		   content=excluded.content, tags=excluded.tags, source=excluded.source, updated_at=excluded.updated_at`,
		noteID, content, tags, source, now, now,
	)
	return noteID, err
}

// ListNotes returns all notes, optionally filtered by tag.
func (s *Store) ListNotes(filterTag string) ([]NoteRow, error) {
	rows, err := s.db.Query(
		`SELECT id,content,tags,source,created_at,updated_at FROM tech_lead_notes ORDER BY created_at DESC`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var notes []NoteRow
	for rows.Next() {
		var n NoteRow
		if err := rows.Scan(&n.ID, &n.Content, &n.Tags, &n.Source, &n.CreatedAt, &n.UpdatedAt); err != nil {
			return nil, err
		}
		if filterTag != "" {
			matched := false
			for _, t := range splitTags(n.Tags) {
				if t == filterTag {
					matched = true
					break
				}
			}
			if !matched {
				continue
			}
		}
		notes = append(notes, n)
	}
	return notes, rows.Err()
}

// DeleteNote deletes a note by ID. Returns true if deleted.
func (s *Store) DeleteNote(id string) (bool, error) {
	res, err := s.db.Exec(`DELETE FROM tech_lead_notes WHERE id=?`, id)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n > 0, nil
}

// UpsertTree builds and persists the codebase tree from file manifests.
func (s *Store) UpsertTree(runID string, files []models.FileManifest) error {
	type node struct {
		path     string
		name     string
		kind     string
		language string
		depth    int
	}

	dirSet := map[string]bool{}
	var nodes []node

	for _, f := range files {
		depth := strings.Count(f.Path, "/")
		nodes = append(nodes, node{
			path:     f.Path,
			name:     filepath.Base(f.Path),
			kind:     "file",
			language: f.Language,
			depth:    depth,
		})
		dir := filepath.Dir(f.Path)
		for dir != "." && dir != "" {
			if dirSet[dir] {
				break
			}
			dirSet[dir] = true
			dir = filepath.Dir(dir)
		}
	}

	for dir := range dirSet {
		nodes = append(nodes, node{
			path:  dir,
			name:  filepath.Base(dir),
			kind:  "dir",
			depth: strings.Count(dir, "/"),
		})
	}

	sort.Slice(nodes, func(i, j int) bool {
		if nodes[i].kind != nodes[j].kind {
			return nodes[i].kind == "dir"
		}
		if nodes[i].depth != nodes[j].depth {
			return nodes[i].depth < nodes[j].depth
		}
		return nodes[i].path < nodes[j].path
	})

	tx, err := s.db.Begin()
	if err != nil {
		return err
	}

	pathToID := map[string]int64{}
	for _, n := range nodes {
		parentDir := filepath.Dir(n.path)
		var parentID *int64
		if parentDir != "." && parentDir != "" {
			if pid, ok := pathToID[parentDir]; ok {
				parentID = &pid
			}
		}
		res, err := tx.Exec(
			`INSERT OR IGNORE INTO codebase_tree (run_id,path,name,kind,language,parent_id,depth)
			 VALUES (?,?,?,?,?,?,?)`,
			runID, n.path, n.name, n.kind, n.language, parentID, n.depth,
		)
		if err != nil {
			_ = tx.Rollback()
			return err
		}
		id, _ := res.LastInsertId()
		if id != 0 {
			pathToID[n.path] = id
		} else {
			var existID int64
			if err2 := tx.QueryRow(`SELECT id FROM codebase_tree WHERE run_id=? AND path=?`, runID, n.path).Scan(&existID); err2 == nil {
				pathToID[n.path] = existID
			}
		}
	}

	return tx.Commit()
}

// GetTree returns all tree nodes for a run, ordered by path.
func (s *Store) GetTree(runID string) ([]models.TreeNode, error) {
	rows, err := s.db.Query(
		`SELECT id,run_id,path,name,kind,COALESCE(language,''),parent_id,depth FROM codebase_tree WHERE run_id=? ORDER BY path`,
		runID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var nodes []models.TreeNode
	for rows.Next() {
		var n models.TreeNode
		if err := rows.Scan(&n.ID, &n.RunID, &n.Path, &n.Name, &n.Kind, &n.Language, &n.ParentID, &n.Depth); err != nil {
			return nil, err
		}
		nodes = append(nodes, n)
	}
	return nodes, rows.Err()
}

func splitTags(tags string) []string {
	if tags == "" {
		return nil
	}
	var result []string
	for _, t := range splitByComma(tags) {
		t = trimSpace(t)
		if t != "" {
			result = append(result, t)
		}
	}
	return result
}

func splitByComma(s string) []string {
	var parts []string
	start := 0
	for i, c := range s {
		if c == ',' {
			parts = append(parts, s[start:i])
			start = i + 1
		}
	}
	parts = append(parts, s[start:])
	return parts
}

func trimSpace(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t') {
		s = s[1:]
	}
	for len(s) > 0 && (s[len(s)-1] == ' ' || s[len(s)-1] == '\t') {
		s = s[:len(s)-1]
	}
	return s
}
