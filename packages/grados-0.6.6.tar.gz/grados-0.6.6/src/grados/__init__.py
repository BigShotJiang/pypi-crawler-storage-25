"""GRaDOS — Academic research MCP server."""

__version__ = "0.6.6"

__all__ = ["__version__"]
