from __future__ import annotations

import re
import logging
from typing import Callable

from sfs_toolkit.models import Claim, ExtractionPattern, DomainConfig

logger = logging.getLogger(__name__)


 
 
 

BUILTIN_PATTERNS: list[ExtractionPattern] = [
     
    ExtractionPattern(
        claim_type="currency",
        pattern=r'\$\s*([\d,]+(?:\.\d+)?)',
        unit="USD",
        min_value=1.0,
    ),
     
    ExtractionPattern(
        claim_type="percentage",
        pattern=r'([\d.]+)\s*%',
        unit="%",
        min_value=0.01,
        max_value=200.0,
    ),
     
    ExtractionPattern(
        claim_type="distance",
        pattern=r'([\d.]+)\s*km',
        unit="km",
        min_value=0.01,
        max_value=1000.0,
    ),
     
    ExtractionPattern(
        claim_type="distance",
        pattern=r'([\d.]+)\s*(?:miles?|mi)',
        unit="miles",
        min_value=0.01,
        max_value=1000.0,
    ),
     
    ExtractionPattern(
        claim_type="duration",
        pattern=r'([\d.]+)\s*(?:hours?|hrs?)',
        unit="hours",
        min_value=0.01,
    ),
     
    ExtractionPattern(
        claim_type="duration",
        pattern=r'([\d.]+)\s*(?:minutes?|mins?)',
        unit="minutes",
        min_value=0.1,
    ),
     
    ExtractionPattern(
        claim_type="count",
        pattern=r'(\d+)\s+(?:patients?|records?|documents?|items?|entries?|results?|samples?|cases?|instances?|examples?|observations?)',
        unit="count",
        min_value=1.0,
    ),
     
    ExtractionPattern(
        claim_type="ratio",
        pattern=r'(?:ratio\s+(?:of\s+)?|factor\s+(?:of\s+)?)([\d.]+)',
        unit="ratio",
        min_value=0.01,
    ),
]


def extract_claims(
    text: str,
    config: DomainConfig | None = None,
    llm_extractor: Callable[[str], list[Claim]] | None = None,
) -> list[Claim]:
   
    patterns = (
        config.extraction_patterns if config and config.extraction_patterns
        else BUILTIN_PATTERNS
    )

    claims: list[Claim] = []
    seen: set[tuple[float, str]] = set()

    for ep in patterns:
        _extract_with_pattern(text, ep, claims, seen)

     
    if llm_extractor is not None:
        try:
            llm_claims = llm_extractor(text)
            for lc in llm_claims:
                key = (lc.extracted_value, lc.unit) if lc.extracted_value else (None, "")
                if key not in seen:
                    claims.append(lc)
                    if lc.extracted_value is not None:
                        seen.add(key)
        except Exception as e:
            logger.warning("LLM claim extraction failed: %s", e)

    logger.info("Extracted %d claims from text (%d chars)", len(claims), len(text))
    return claims


def _extract_with_pattern(
    text: str,
    ep: ExtractionPattern,
    claims: list[Claim],
    seen: set[tuple[float, str]],
) -> None:
     
    for match in re.finditer(ep.pattern, text, re.IGNORECASE):
        raw = match.group(ep.value_group).replace(",", "")
        try:
            value = float(raw)
        except ValueError:
            continue

         
        if ep.min_value is not None and value < ep.min_value:
            continue
        if ep.max_value is not None and value > ep.max_value:
            continue

         
        key = (value, ep.unit)
        if key in seen:
            continue

         
        if ep.context_keywords:
            ctx_start = max(0, match.start() - 80)
            ctx = text[ctx_start:match.end() + 20].lower()
            if not any(kw.lower() in ctx for kw in ep.context_keywords):
                continue

        seen.add(key)
        sentence = _extract_sentence(text, match.start())
        claims.append(Claim(
            claim_text=sentence,
            claim_type=ep.claim_type,
            extracted_value=value,
            unit=ep.unit,
            source_span=(match.start(), match.end()),
        ))


def _extract_sentence(text: str, pos: int) -> str:
     
     
    start = 0
    for i in range(pos - 1, -1, -1):
        if text[i] == "." and (i + 1 >= len(text) or not text[i + 1].isdigit()):
            start = i + 1
            break
        if text[i] == "\n" and i < pos - 1:
            start = i + 1
            break

     
    end = len(text)
    i = pos
    while i < len(text):
        if text[i] == "." and (i + 1 >= len(text) or not text[i + 1].isdigit()):
            end = i + 1
            break
        if text[i] == "\n":
            end = i
            break
        i += 1

    result = text[start:end].strip()
    return result if result else text[max(0, pos - 75):min(len(text), pos + 75)].strip()
