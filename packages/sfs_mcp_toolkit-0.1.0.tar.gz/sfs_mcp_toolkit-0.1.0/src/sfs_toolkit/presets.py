

from __future__ import annotations

from sfs_toolkit.models import DomainConfig, ExtractionPattern


def property_valuation() -> DomainConfig:
    
    return DomainConfig(
        name="Property Valuation",
        description=(
            "Spatial property valuation domain (GeoScribe). Extracts price, "
            "gradient, proximity, and count claims from LLM reasoning about "
            "residential property values."
        ),
        tolerance=0.15,
        type_tolerances={},
        percentage_absolute_threshold=15.0,
        extraction_patterns=[
             
            ExtractionPattern(
                claim_type="currency",
                pattern=r'(?:median|mean|average|price|cost|value|estimate|prediction)[^.]*?\$\s*([\d,]+(?:\.\d+)?)',
                unit="AUD",
                min_value=10_000,
                context_keywords=[],
            ),
             
            ExtractionPattern(
                claim_type="currency",
                pattern=r'\$\s*([\d,]+(?:\.\d+)?)',
                unit="AUD",
                min_value=10_000,
            ),
             
            ExtractionPattern(
                claim_type="percentage",
                pattern=r'([\d.]+)\s*%',
                unit="%",
                min_value=0.01,
                max_value=200.0,
                context_keywords=["gradient", "per km", "direction", "north", "south", "east", "west"],
            ),
             
            ExtractionPattern(
                claim_type="percentage",
                pattern=r'([\d.]+)\s*%',
                unit="%",
                min_value=0.01,
                max_value=200.0,
            ),
             
            ExtractionPattern(
                claim_type="distance",
                pattern=r'([\d.]+)\s*km',
                unit="km",
                min_value=0.01,
                max_value=100.0,
            ),
             
            ExtractionPattern(
                claim_type="count",
                pattern=r'(\d+)\s*(?:properties|comparables|homes|houses|sales)',
                unit="count",
                min_value=1.0,
            ),
        ],
    )


def medical_rag() -> DomainConfig:
    
    return DomainConfig(
        name="Medical RAG",
        description=(
            "Clinical / medical RAG domain. Extracts dosages, lab values, "
            "statistical percentages, and patient counts from LLM reasoning."
        ),
        tolerance=0.10,
        type_tolerances={
            "dosage": 0.05,   
        },
        percentage_absolute_threshold=10.0,
        extraction_patterns=[
             
            ExtractionPattern(
                claim_type="dosage",
                pattern=r'([\d.]+)\s*(?:mg|ml|mL|mcg|g|IU|units?)',
                unit="dosage",
                min_value=0.001,
            ),
             
            ExtractionPattern(
                claim_type="lab_value",
                pattern=r'(?:level|value|result|concentration|reading)\s+(?:of\s+)?([\d.]+)',
                unit="lab",
                min_value=0.001,
            ),
             
            ExtractionPattern(
                claim_type="percentage",
                pattern=r'([\d.]+)\s*%',
                unit="%",
                min_value=0.01,
                max_value=100.0,
            ),
             
            ExtractionPattern(
                claim_type="count",
                pattern=r'(\d+)\s*(?:patients?|subjects?|participants?|cases?)',
                unit="count",
                min_value=1.0,
            ),
             
            ExtractionPattern(
                claim_type="duration",
                pattern=r'([\d.]+)\s*(?:days?|weeks?|months?|years?)',
                unit="duration",
                min_value=0.1,
            ),
        ],
    )


def legal_rag() -> DomainConfig:
    
    return DomainConfig(
        name="Legal RAG",
        description=(
            "Legal domain RAG. Extracts monetary amounts, statutory references, "
            "durations, and percentage claims from legal reasoning."
        ),
        tolerance=0.10,
        type_tolerances={
            "currency": 0.05,   
        },
        percentage_absolute_threshold=5.0,
        extraction_patterns=[
            ExtractionPattern(
                claim_type="currency",
                pattern=r'\$\s*([\d,]+(?:\.\d+)?)',
                unit="USD",
                min_value=1.0,
            ),
            ExtractionPattern(
                claim_type="percentage",
                pattern=r'([\d.]+)\s*(?:%|percent)',
                unit="%",
                min_value=0.01,
                max_value=100.0,
            ),
            ExtractionPattern(
                claim_type="duration",
                pattern=r'([\d.]+)\s*(?:days?|months?|years?)',
                unit="duration",
                min_value=0.1,
            ),
            ExtractionPattern(
                claim_type="count",
                pattern=r'(\d+)\s*(?:counts?|charges?|violations?|claims?|parties)',
                unit="count",
                min_value=1.0,
            ),
        ],
    )


def financial_rag() -> DomainConfig:
    
    return DomainConfig(
        name="Financial RAG",
        description=(
            "Financial analysis domain. Extracts prices, returns, ratios, "
            "and statistical claims from financial reasoning."
        ),
        tolerance=0.10,
        type_tolerances={
            "ratio": 0.05,
        },
        percentage_absolute_threshold=10.0,
        extraction_patterns=[
            ExtractionPattern(
                claim_type="currency",
                pattern=r'\$\s*([\d,]+(?:\.\d+)?)',
                unit="USD",
                min_value=0.01,
            ),
            ExtractionPattern(
                claim_type="percentage",
                pattern=r'([\d.]+)\s*%',
                unit="%",
                min_value=0.001,
                max_value=1000.0,
            ),
            ExtractionPattern(
                claim_type="ratio",
                pattern=r'(?:P/?E|ratio|multiple|beta|alpha|sharpe)\s+(?:of\s+)?([\d.]+)',
                unit="ratio",
                min_value=0.001,
            ),
            ExtractionPattern(
                claim_type="currency",
                pattern=r'([\d,]+(?:\.\d+)?)\s*(?:billion|million|thousand)',
                unit="USD",
                min_value=1.0,
            ),
        ],
    )


 
PRESETS: dict[str, callable] = {
    "property_valuation": property_valuation,
    "medical": medical_rag,
    "legal": legal_rag,
    "financial": financial_rag,
}


def get_preset(name: str) -> DomainConfig:
     
    factory = PRESETS.get(name)
    if factory is None:
        available = ", ".join(sorted(PRESETS.keys()))
        raise KeyError(f"Unknown preset '{name}'. Available: {available}")
    return factory()


def list_presets() -> list[dict[str, str]]:
     
    result = []
    for name, factory in PRESETS.items():
        cfg = factory()
        result.append({
            "name": name,
            "display_name": cfg.name,
            "description": cfg.description,
            "tolerance": str(cfg.tolerance),
        })
    return result
