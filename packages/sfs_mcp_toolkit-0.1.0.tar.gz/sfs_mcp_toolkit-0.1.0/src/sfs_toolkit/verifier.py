

from __future__ import annotations

import logging

from sfs_toolkit.models import (
    Claim,
    ClaimVerification,
    DomainConfig,
    EvidenceItem,
    EvidencePool,
    SFSReport,
)

logger = logging.getLogger(__name__)


def compute_sfs(
    claims: list[Claim],
    evidence: EvidencePool,
    config: DomainConfig | None = None,
) -> SFSReport:
    
    tolerance = config.tolerance if config else 0.15
    type_tolerances = config.type_tolerances if config else {}
    pct_abs_threshold = config.percentage_absolute_threshold if config else 15.0

    if not claims:
        return SFSReport(
            sfs_score=1.0,
            total_claims=0,
            verified_claims=0,
            failed_claims=0,
            claim_verifications=[],
            type_breakdown={},
        )

    verifications: list[ClaimVerification] = []
    type_stats: dict[str, dict[str, int]] = {}

    for claim in claims:
        ct = claim.claim_type
        if ct not in type_stats:
            type_stats[ct] = {"total": 0, "verified": 0, "failed": 0}
        type_stats[ct]["total"] += 1

        t = type_tolerances.get(ct, tolerance)
        cv = _verify_single_claim(claim, evidence, t, pct_abs_threshold)
        verifications.append(cv)

        if cv.verified:
            type_stats[ct]["verified"] += 1
        else:
            type_stats[ct]["failed"] += 1

    verified_count = sum(1 for v in verifications if v.verified)
    total = len(claims)
    sfs = verified_count / total

    report = SFSReport(
        sfs_score=round(sfs, 4),
        total_claims=total,
        verified_claims=verified_count,
        failed_claims=total - verified_count,
        claim_verifications=verifications,
        type_breakdown=type_stats,
    )
    logger.info("SFS: %.2f%% (%d/%d claims verified)", sfs * 100, verified_count, total)
    return report


def verify_claim(
    claim: Claim,
    evidence: EvidencePool,
    config: DomainConfig | None = None,
) -> ClaimVerification:
    """Verify a single claim (convenience wrapper)."""
    tolerance = config.tolerance if config else 0.15
    if config and claim.claim_type in config.type_tolerances:
        tolerance = config.type_tolerances[claim.claim_type]
    pct_abs = config.percentage_absolute_threshold if config else 15.0
    return _verify_single_claim(claim, evidence, tolerance, pct_abs)


def _verify_single_claim(
    claim: Claim,
    evidence: EvidencePool,
    tolerance: float,
    pct_abs_threshold: float,
) -> ClaimVerification:
    """Core verification logic for one claim against the evidence pool."""
    if claim.extracted_value is None:
        return ClaimVerification(
            claim=claim,
            verified=False,
            reason="No numerical value could be extracted from the claim.",
        )

    claimed = claim.extracted_value
    is_percentage = claim.unit == "%"

     
     
    candidates = evidence.values_for_unit(claim.unit)
    if not candidates:
        candidates = evidence.all_values()

    if not candidates:
        return ClaimVerification(
            claim=claim,
            verified=False,
            reason="No evidence values available for comparison.",
        )

    best_error = float("inf")
    best_item: EvidenceItem | None = None

    for item in evidence.items:
        actual = item.value
        if actual == 0:
            continue

         
        if candidates and item.value not in candidates:
            continue

        error = abs(claimed - actual) / abs(actual)

        if error < best_error:
            best_error = error
            best_item = item

        if error <= tolerance:
            return ClaimVerification(
                claim=claim,
                verified=True,
                matched_evidence=item,
                error=round(error, 4),
                reason=f"Matched {item.key}: claimed={claimed}, actual={actual}, error={error:.2%}",
            )

         
        if is_percentage:
            abs_diff = abs(claimed - actual)
            if abs_diff <= pct_abs_threshold:
                return ClaimVerification(
                    claim=claim,
                    verified=True,
                    matched_evidence=item,
                    error=round(error, 4),
                    reason=(
                        f"Matched {item.key} via absolute threshold: "
                        f"claimed={claimed}%, actual={actual}%, diff={abs_diff:.1f}pp"
                    ),
                )

         
        if is_percentage and actual < 5 and abs(claimed) < 5:
            return ClaimVerification(
                claim=claim,
                verified=True,
                matched_evidence=item,
                error=round(error, 4),
                reason=f"Both near zero: claimed={claimed}%, actual={actual}%",
            )

    return ClaimVerification(
        claim=claim,
        verified=False,
        matched_evidence=best_item,
        error=round(best_error, 4) if best_error < float("inf") else None,
        reason=(
            f"No evidence matched within tolerance ({tolerance:.0%}). "
            f"Closest: {best_item.key}={best_item.value} (error={best_error:.2%})"
            if best_item else "No comparable evidence found."
        ),
    )
