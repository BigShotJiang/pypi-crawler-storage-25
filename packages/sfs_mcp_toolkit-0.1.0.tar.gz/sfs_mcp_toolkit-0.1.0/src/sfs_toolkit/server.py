

from __future__ import annotations

import json
import logging

from mcp.server.fastmcp import FastMCP

from sfs_toolkit.models import (
    Claim,
    DomainConfig,
    EvidenceItem,
    EvidencePool,
)
from sfs_toolkit.extractor import extract_claims
from sfs_toolkit.verifier import compute_sfs, verify_claim
from sfs_toolkit.presets import get_preset, list_presets

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

mcp = FastMCP(
    "SFS Toolkit",
     
     
     
     
     
)


 
 
 

@mcp.tool()
def sfs_extract_claims(
    text: str,
    preset: str = "",
    custom_config_json: str = "",
) -> str:
    
    config = _resolve_config(preset, custom_config_json)
    claims = extract_claims(text, config=config)
    return json.dumps([c.model_dump() for c in claims], indent=2)


 
 
 

@mcp.tool()
def sfs_verify_claims(
    claims_json: str,
    evidence_json: str,
    preset: str = "",
    custom_config_json: str = "",
) -> str:
    
    config = _resolve_config(preset, custom_config_json)
    claims = [Claim(**c) for c in json.loads(claims_json)]
    evidence = EvidencePool(items=[EvidenceItem(**e) for e in json.loads(evidence_json)])
    report = compute_sfs(claims, evidence, config=config)
    return json.dumps(report.model_dump(), indent=2, default=str)


 
 
 

@mcp.tool()
def sfs_compute(
    text: str,
    evidence_json: str,
    preset: str = "",
    custom_config_json: str = "",
) -> str:
    
    config = _resolve_config(preset, custom_config_json)
    claims = extract_claims(text, config=config)
    evidence = EvidencePool(items=[EvidenceItem(**e) for e in json.loads(evidence_json)])
    report = compute_sfs(claims, evidence, config=config)
    return json.dumps(report.model_dump(), indent=2, default=str)


 
 
 

@mcp.tool()
def sfs_verify_single(
    claim_text: str,
    claim_type: str,
    extracted_value: float,
    unit: str,
    evidence_json: str,
    preset: str = "",
    custom_config_json: str = "",
) -> str:
    
    config = _resolve_config(preset, custom_config_json)
    claim = Claim(
        claim_text=claim_text,
        claim_type=claim_type,
        extracted_value=extracted_value,
        unit=unit,
    )
    evidence = EvidencePool(items=[EvidenceItem(**e) for e in json.loads(evidence_json)])
    result = verify_claim(claim, evidence, config=config)
    return json.dumps(result.model_dump(), indent=2, default=str)


 
 
 

@mcp.tool()
def sfs_list_presets() -> str:
    
    return json.dumps(list_presets(), indent=2)


 
 
 

@mcp.tool()
def sfs_get_preset(preset_name: str) -> str:
    
    config = get_preset(preset_name)
    return json.dumps(config.model_dump(), indent=2)


 
 
 

def _resolve_config(
    preset: str,
    custom_config_json: str,
) -> DomainConfig | None:
     
    if custom_config_json:
        return DomainConfig(**json.loads(custom_config_json))
    if preset:
        return get_preset(preset)
    return None


 
 
 

def _load_key_map() -> dict[str, str]:
    """Parse SFS_API_KEYS env var into {key: username} dict.

    Format: "key1:alice,key2:bob,key3:charlie"
    Falls back to SFS_API_KEY (single key, user = "default") for backwards compat.
    """
    import os
    raw = os.environ.get("SFS_API_KEYS", "")
    if raw:
        key_map = {}
        for entry in raw.split(","):
            entry = entry.strip()
            if ":" in entry:
                k, user = entry.split(":", 1)
                key_map[k.strip()] = user.strip()
        return key_map

    # backwards compat: single key
    single = os.environ.get("SFS_API_KEY", "")
    if single:
        return {single: "default"}
    return {}


def _build_sse_app():
    """Wrap the SSE ASGI app with per-user API key authentication and usage logging."""
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import JSONResponse
    import time

    key_map = _load_key_map()
    auth_enabled = bool(key_map)

    class APIKeyMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request, call_next):
            if request.url.path == "/health":
                return await call_next(request)

            if auth_enabled:
                auth_header = request.headers.get("Authorization", "")
                token = auth_header.removeprefix("Bearer ").strip()
                user = key_map.get(token)
                if not user:
                    logger.warning("sfs_auth_failed path=%s", request.url.path)
                    return JSONResponse({"error": "Unauthorized"}, status_code=401)
            else:
                user = "anonymous"

            t0 = time.monotonic()
            response = await call_next(request)
            elapsed_ms = round((time.monotonic() - t0) * 1000)

            logger.info(
                "sfs_request user=%s method=%s path=%s status=%s duration_ms=%d",
                user,
                request.method,
                request.url.path,
                response.status_code,
                elapsed_ms,
            )
            return response

    app = mcp.sse_app()
    app.add_middleware(APIKeyMiddleware)
    return app


def main():
    import os
    transport = os.environ.get("MCP_TRANSPORT", "stdio")

    if transport == "sse":
        import uvicorn
        host = os.environ.get("HOST", "0.0.0.0")
        port = int(os.environ.get("PORT", "8080"))
        uvicorn.run(_build_sse_app(), host=host, port=port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
