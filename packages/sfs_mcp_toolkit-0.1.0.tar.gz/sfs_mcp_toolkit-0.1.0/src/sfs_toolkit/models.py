

from __future__ import annotations

from pydantic import BaseModel, Field


 
 
 

class Claim(BaseModel):
     

    claim_text: str = Field(
        description="The sentence or fragment containing the claim.",
    )
    claim_type: str = Field(
        description=(
            "Semantic category of the claim. Built-in types: 'currency', "
            "'percentage', 'distance', 'count', 'duration', 'ratio'. "
            "Custom types are supported via DomainConfig."
        ),
    )
    extracted_value: float | None = Field(
        default=None,
        description="The numerical value parsed from the claim text.",
    )
    unit: str = Field(
        default="",
        description="Unit of measurement (e.g. 'USD', '%', 'km', 'count').",
    )
    source_span: tuple[int, int] | None = Field(
        default=None,
        description="Character offsets (start, end) in the original text.",
    )


 
 
 

class EvidenceItem(BaseModel):
     

    key: str = Field(
        description="Identifier for this evidence datum (e.g. 'median_price', 'cbd_distance').",
    )
    value: float = Field(
        description="The numerical ground-truth value.",
    )
    unit: str = Field(
        default="",
        description="Unit of measurement, matching the claim's unit system.",
    )
    source: str = Field(
        default="",
        description="Provenance label (e.g. 'retrieved_doc_3', 'database', 'api').",
    )


class EvidencePool(BaseModel):
     

    items: list[EvidenceItem] = Field(default_factory=list)

    def values_for_unit(self, unit: str) -> list[float]:
         
        return [
            item.value
            for item in self.items
            if item.unit.lower() == unit.lower() and item.value != 0
        ]

    def all_values(self) -> list[float]:
         
        return [item.value for item in self.items if item.value != 0]


 
 
 

class ClaimVerification(BaseModel):
     

    claim: Claim
    verified: bool
    matched_evidence: EvidenceItem | None = None
    error: float | None = Field(
        default=None,
        description="Relative error |claimed - actual| / actual if a match was attempted.",
    )
    reason: str = Field(
        default="",
        description="Human-readable explanation of the verification outcome.",
    )


 
 
 

class SFSReport(BaseModel):
     

    sfs_score: float = Field(
        description="Ratio of verified claims to total claims (0.0 – 1.0).",
    )
    total_claims: int
    verified_claims: int
    failed_claims: int
    claim_verifications: list[ClaimVerification] = Field(default_factory=list)
    type_breakdown: dict[str, dict[str, int]] = Field(
        default_factory=dict,
        description="Per-type stats: {type: {total, verified, failed}}.",
    )


 
 
 

class ExtractionPattern(BaseModel):
     

    claim_type: str = Field(
        description="The claim type this pattern detects.",
    )
    pattern: str = Field(
        description="Python regex with at least one capture group for the numerical value.",
    )
    unit: str = Field(
        default="",
        description="Unit to assign to extracted claims.",
    )
    value_group: int = Field(
        default=1,
        description="Which regex capture group contains the numerical value.",
    )
    context_keywords: list[str] = Field(
        default_factory=list,
        description=(
            "If non-empty, the pattern only fires when one of these keywords "
            "appears within 80 chars before the match."
        ),
    )
    min_value: float | None = Field(
        default=None,
        description="Ignore extracted values below this threshold.",
    )
    max_value: float | None = Field(
        default=None,
        description="Ignore extracted values above this threshold.",
    )


 
 
 

class DomainConfig(BaseModel):
    

    name: str = Field(
        description="Human-readable domain name (e.g. 'Property Valuation').",
    )
    description: str = Field(
        default="",
        description="What this domain configuration covers.",
    )
    tolerance: float = Field(
        default=0.15,
        description=(
            "Default relative-error tolerance for verification. "
            "A claim is verified if |claimed - actual| / actual <= tolerance."
        ),
    )
    type_tolerances: dict[str, float] = Field(
        default_factory=dict,
        description=(
            "Per-type tolerance overrides. If a claim_type is listed here, "
            "its tolerance takes precedence over the default."
        ),
    )
    extraction_patterns: list[ExtractionPattern] = Field(
        default_factory=list,
        description="Ordered list of regex extraction rules.",
    )
    percentage_absolute_threshold: float = Field(
        default=15.0,
        description=(
            "For percentage claims: additionally pass if the absolute "
            "difference in percentage points is within this threshold."
        ),
    )
