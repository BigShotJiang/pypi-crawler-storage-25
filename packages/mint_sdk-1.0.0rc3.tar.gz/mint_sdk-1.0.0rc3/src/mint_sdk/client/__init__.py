"""MINT platform API client.

Usage:
    from mint_sdk.client import MINTClient

    client = MINTClient("http://localhost:8001")
    client.login("admin", "password")
    experiments = client.experiments.list()
"""

from __future__ import annotations

from importlib import import_module

_LAZY_EXPORTS = {
    "MINTClient": ("mint_sdk.client.client", "MINTClient"),
    "MINTAPIError": ("mint_sdk.client._exceptions", "MINTAPIError"),
    "AuthenticationError": ("mint_sdk.client._exceptions", "AuthenticationError"),
    "MINTPermissionError": ("mint_sdk.client._exceptions", "MINTPermissionError"),
    "NotFoundError": ("mint_sdk.client._exceptions", "NotFoundError"),
    "ConflictError": ("mint_sdk.client._exceptions", "ConflictError"),
    "MINTValidationError": ("mint_sdk.client._exceptions", "MINTValidationError"),
    "RateLimitError": ("mint_sdk.client._exceptions", "RateLimitError"),
    "ServerError": ("mint_sdk.client._exceptions", "ServerError"),
    "MINTConnectionError": ("mint_sdk.client._exceptions", "MINTConnectionError"),
}

__all__ = [
    "MINTClient",
    "MINTAPIError",
    "AuthenticationError",
    "MINTPermissionError",
    "NotFoundError",
    "ConflictError",
    "MINTValidationError",
    "RateLimitError",
    "ServerError",
    "MINTConnectionError",
]


def __getattr__(name: str):
    try:
        module_name, attr_name = _LAZY_EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}") from exc

    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
