"""Plugin discovery from pyproject.toml without importing the plugin.

Parses entry points, module paths, and routes prefix by inspecting files
statically — no plugin code is executed.
"""

from __future__ import annotations

import ast
import re
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]


@dataclass(slots=True)
class DiscoveredPlugin:
    """Statically discovered plugin metadata."""

    entry_point_name: str  # "drp-analysis"
    module_path: str  # "mint_plugin_drp.plugin"
    class_name: str  # "DRPAnalysisPlugin"
    factory_target: str  # "mint_plugin_drp.plugin:create_standalone_app"
    routes_prefix: str  # "/drp" (from source) or "/drp-analysis" (fallback)
    project_name: str  # "mint-plugin-drp"
    project_version: str | None  # "0.2.0" or None if dynamic
    project_description: str  # from [project].description
    has_frontend: bool  # frontend/package.json exists
    metadata_name: str = ""  # PluginMetadata.name, if statically readable
    metadata_version: str = ""  # PluginMetadata.version, if statically readable
    metadata_description: str = ""  # PluginMetadata.description, if statically readable
    metadata_analysis_type: str = ""  # PluginMetadata.analysis_type
    metadata_plugin_type: str = ""  # PluginMetadata.plugin_type
    metadata_author: str = ""  # PluginMetadata.author
    metadata_homepage: str = ""  # PluginMetadata.homepage
    metadata_license: str = ""  # PluginMetadata.license
    metadata_icon: str = ""  # PluginMetadata.icon
    metadata_color: str = ""  # PluginMetadata.color
    metadata_nav_items: list[dict[str, Any]] | None = None


def _read_full_pyproject(project_dir: Path) -> dict:
    """Read and return the full pyproject.toml as a dict."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        print(f"Error: {path} not found.", file=sys.stderr)
        sys.exit(1)
    with open(path, "rb") as f:
        return tomllib.load(f)


def _parse_entry_point(data: dict) -> tuple[str, str, str] | None:
    """Extract (name, module_path, class_name) from [project.entry-points."mint.plugins"].

    Returns None if no mint.plugins entry point is found.
    """
    entry_points = (
        data.get("project", {}).get("entry-points", {}).get("mint.plugins", {})
    )
    if not entry_points:
        return None

    # Take the first entry point
    name, value = next(iter(entry_points.items()))
    # value is "mint_plugin_drp.plugin:DRPAnalysisPlugin"
    if ":" not in value:
        return None
    module_path, class_name = value.rsplit(":", 1)
    return name, module_path, class_name


def _module_source_candidates(module_path: str, project_dir: Path) -> list[Path]:
    """Return possible source file paths for a plugin module path."""
    parts = module_path.split(".")
    return [
        project_dir / "src" / Path(*parts).with_suffix(".py"),
        project_dir / Path(*parts).with_suffix(".py"),
    ]


def _read_module_source(module_path: str, project_dir: Path) -> str | None:
    """Read a plugin module source file without importing it."""
    for source_path in _module_source_candidates(module_path, project_dir):
        if not source_path.exists():
            continue
        try:
            return source_path.read_text()
        except OSError:
            continue
    return None


def _parse_routes_prefix_from_source(module_path: str, project_dir: Path) -> str | None:
    """Parse PLUGIN_ROUTES_PREFIX from the plugin source file without importing it.

    Looks for patterns like:
        PLUGIN_ROUTES_PREFIX = "/drp"
        PLUGIN_ROUTES_PREFIX = '/drp'
    """
    content = _read_module_source(module_path, project_dir)
    if content:
        match = re.search(
            r'PLUGIN_ROUTES_PREFIX\s*=\s*["\'](/[^"\']+)["\']', content
        )
        if match:
            return match.group(1)

    return None


def _is_call_named(node: ast.Call, name: str) -> bool:
    func = node.func
    if isinstance(func, ast.Name):
        return func.id == name
    return isinstance(func, ast.Attribute) and func.attr == name


def _literal_value(node: ast.AST, constants: Mapping[str, Any] | None = None) -> Any:
    try:
        return ast.literal_eval(node)
    except (ValueError, SyntaxError):
        if isinstance(node, ast.Attribute):
            return node.attr.lower()
        if isinstance(node, ast.Name) and constants and node.id in constants:
            return constants[node.id]
        return None


def _keyword_literal(
    node: ast.Call,
    name: str,
    constants: Mapping[str, Any] | None = None,
) -> Any:
    for keyword in node.keywords:
        if keyword.arg != name:
            continue
        return _literal_value(keyword.value, constants)
    return None


def _metadata_string(
    node: ast.Call,
    name: str,
    constants: Mapping[str, Any],
) -> str:
    value = _keyword_literal(node, name, constants)
    return value if isinstance(value, str) else ""


def _parse_nav_items(node: ast.Call, constants: Mapping[str, Any]) -> list[dict[str, Any]]:
    nav_items: list[dict[str, Any]] = []
    for keyword in node.keywords:
        if keyword.arg != "nav_items":
            continue
        if not isinstance(keyword.value, (ast.List, ast.Tuple)):
            return nav_items
        for item in keyword.value.elts:
            if not isinstance(item, ast.Call) or not _is_call_named(item, "PluginNavItem"):
                continue
            nav_item: dict[str, Any] = {}
            for key in (
                "path",
                "label",
                "id",
                "icon",
                "description",
                "requires_auth",
                "requires_admin",
                "requires_feature",
            ):
                value = _keyword_literal(item, key, constants)
                if value not in (None, "", False):
                    nav_item[key] = value
            if nav_item.get("path") and nav_item.get("label"):
                nav_items.append(nav_item)
    return nav_items


def _module_constants(tree: ast.Module) -> dict[str, Any]:
    constants: dict[str, Any] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            value = _literal_value(node.value, constants)
            if value in (None, "", False):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    constants[target.id] = value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            value = _literal_value(node.value, constants) if node.value is not None else None
            if value not in (None, "", False):
                constants[node.target.id] = value
    return constants


def _parse_metadata_from_source(module_path: str, project_dir: Path) -> dict[str, Any]:
    """Parse simple PluginMetadata literal fields without importing the plugin."""
    content = _read_module_source(module_path, project_dir)
    if not content:
        return {}
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return {}
    constants = _module_constants(tree)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not _is_call_named(node, "PluginMetadata"):
            continue
        metadata: dict[str, Any] = {}
        for key in (
            "name",
            "version",
            "description",
            "analysis_type",
            "author",
            "homepage",
            "license",
            "icon",
            "color",
        ):
            if value := _metadata_string(node, key, constants):
                metadata[key] = value
        if plugin_type := _metadata_string(node, "plugin_type", constants):
            metadata["plugin_type"] = plugin_type
        if nav_items := _parse_nav_items(node, constants):
            metadata["nav_items"] = nav_items
        return metadata

    return {}


def discover_plugin(project_dir: Path) -> DiscoveredPlugin:
    """Discover plugin metadata from pyproject.toml and source files.

    Raises SystemExit if the project directory lacks required configuration.
    """
    data = _read_full_pyproject(project_dir)

    project = data.get("project")
    if not project:
        print("Error: pyproject.toml has no [project] table.", file=sys.stderr)
        sys.exit(1)

    entry_point = _parse_entry_point(data)
    if not entry_point:
        print(
            "Error: No [project.entry-points.\"mint.plugins\"] found in pyproject.toml.",
            file=sys.stderr,
        )
        sys.exit(1)

    ep_name, module_path, class_name = entry_point

    # Routes prefix: parse from source, fallback to /{entry_point_name}
    routes_prefix = _parse_routes_prefix_from_source(module_path, project_dir)
    if routes_prefix is None:
        routes_prefix = f"/{ep_name}"

    # Factory target for uvicorn --factory
    factory_target = f"{module_path}:create_standalone_app"

    # Version: static or None if dynamic
    version = project.get("version")

    has_frontend = (project_dir / "frontend" / "package.json").exists()
    metadata = _parse_metadata_from_source(module_path, project_dir)

    return DiscoveredPlugin(
        entry_point_name=ep_name,
        module_path=module_path,
        class_name=class_name,
        factory_target=factory_target,
        routes_prefix=routes_prefix,
        project_name=project["name"],
        project_version=version,
        project_description=project.get("description", ""),
        has_frontend=has_frontend,
        metadata_name=metadata.get("name", ""),
        metadata_version=metadata.get("version", ""),
        metadata_description=metadata.get("description", ""),
        metadata_analysis_type=metadata.get("analysis_type", ""),
        metadata_plugin_type=metadata.get("plugin_type", ""),
        metadata_author=metadata.get("author", ""),
        metadata_homepage=metadata.get("homepage", ""),
        metadata_license=metadata.get("license", ""),
        metadata_icon=metadata.get("icon", ""),
        metadata_color=metadata.get("color", ""),
        metadata_nav_items=metadata.get("nav_items"),
    )


def get_sdk_dependency_spec(project_dir: Path) -> str | None:
    """Extract the mint-sdk version specifier from pyproject.toml dependencies.

    Returns e.g. ">=0.9.4" or None if mint-sdk is not in dependencies.
    """
    data = _read_full_pyproject(project_dir)
    deps = data.get("project", {}).get("dependencies", [])
    for dep in deps:
        # Match "mint-sdk>=0.9.4", "mint-sdk>=0.9.4,<1.0", "mint-sdk"
        match = re.match(r"mint[-_]sdk\s*(.*)", dep, re.IGNORECASE)
        if match:
            spec = match.group(1).strip()
            return spec if spec else "*"
    return None
