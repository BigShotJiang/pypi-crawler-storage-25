"""Central catalog for abandoned and deprecated SDK API migrations."""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class DeprecatedApiReplacement:
    """Human-readable migration entry for deprecated API docs."""

    old: str
    new: str
    scope: str
    example: str


@dataclass(frozen=True, slots=True)
class DeprecatedFrontendComponent:
    """Deprecated Vue component export with its preferred replacement."""

    name: str
    replacement: str
    kebab_name: str


@dataclass(frozen=True, slots=True)
class DeprecatedFrontendComposable:
    """Deprecated frontend composable export with its preferred replacement."""

    name: str
    replacement: str


@dataclass(frozen=True, slots=True)
class DeprecatedFrontendType:
    """Deprecated frontend type export with its preferred replacement."""

    name: str
    replacement: str


_STATIC_API_REPLACEMENTS: tuple[DeprecatedApiReplacement, ...] = (
    DeprecatedApiReplacement(
        old="mld_sdk",
        new="mint_sdk",
        scope="Python imports",
        example="from mint_sdk import AnalysisPlugin, PluginMetadata",
    ),
    DeprecatedApiReplacement(
        old="mld-sdk",
        new="mint-sdk",
        scope="Python dependencies",
        example='"mint-sdk>=1.0.0a8"',
    ),
    DeprecatedApiReplacement(
        old="@morscherlab/mld-sdk",
        new="@morscherlab/mint-sdk",
        scope="Frontend dependencies/imports",
        example='import { AppLayout } from "@morscherlab/mint-sdk"',
    ),
    DeprecatedApiReplacement(
        old="mld <command>",
        new="mint <command>",
        scope="CLI commands in docs and agent instructions",
        example="mint add endpoint run --method post",
    ),
    DeprecatedApiReplacement(
        old='get_frontend_config()["navItems"]',
        new="PluginMetadata.nav_items",
        scope="Python plugin metadata",
        example=(
            'PluginMetadata(..., nav_items=[PluginNavItem(path="/", '
            'label="Dashboard", id="dashboard", icon="M3 13h8", '
            'description="Plugin overview")])'
        ),
    ),
    DeprecatedApiReplacement(
        old="PluginMetadata.nav_items dict entries",
        new="PluginNavItem(...)",
        scope="Python plugin metadata",
        example=(
            'PluginMetadata(..., nav_items=[PluginNavItem(path="/", '
            'label="Dashboard", id="dashboard", icon="M3 13h8")])'
        ),
    ),
    DeprecatedApiReplacement(
        old="PluginExperimentData",
        new="DesignData",
        scope="Python SDK data models",
        example="from mint_sdk import DesignData",
    ),
    DeprecatedApiReplacement(
        old="AnalysisPlugin.local_db",
        new="AnalysisPlugin.standalone_db",
        scope="Python standalone database access",
        example="db = self.standalone_db",
    ),
    DeprecatedApiReplacement(
        old="AnalysisPlugin.get_local_models()",
        new="AnalysisPlugin.get_shared_models()",
        scope="Python standalone database models",
        example="def get_shared_models(self) -> list[type]: return [MyModel]",
    ),
    DeprecatedApiReplacement(
        old="AnalysisPlugin._setup_local_database() / _teardown_local_database()",
        new="AnalysisPlugin._setup_standalone_db() / _teardown_standalone_db()",
        scope="Python standalone database lifecycle",
        example="self._setup_standalone_db(storage_dir)",
    ),
    DeprecatedApiReplacement(
        old='BaseTabs variant="bordered"',
        new='BaseTabs variant="underline"',
        scope="Frontend component props",
        example='<BaseTabs v-model="tab" :tabs="tabs" variant="underline" />',
    ),
    DeprecatedApiReplacement(
        old="AppSidebar items / active-id",
        new="AppSidebar panels / active-view",
        scope="Frontend component props",
        example='<AppSidebar variant="analysis" :panels="panels" active-view="overview" />',
    ),
    DeprecatedApiReplacement(
        old="AppTopBar floating / sticky",
        new="AppTopBar variant",
        scope="Frontend component props",
        example='<AppTopBar title="Plugin" variant="solid" />',
    ),
    DeprecatedApiReplacement(
        old="AppTopBar pluginName",
        new="AppTopBar title/subtitle or pageSelector",
        scope="Frontend component props",
        example='<AppTopBar title="Plugin" :page-selector="pages" />',
    ),
    DeprecatedApiReplacement(
        old="AppTopBar pages / current-page-id / tabs / current-tab-id",
        new="AppTopBar pageSelector / current-page-selector-id / pillNav / current-pill-id",
        scope="Frontend component props",
        example=(
            '<AppTopBar :page-selector="pages" current-page-selector-id="dashboard" '
            ':pill-nav="modes" current-pill-id="summary" />'
        ),
    ),
    DeprecatedApiReplacement(
        old="PluginWorkspaceView pages / current-page-id / tabs / current-tab-id",
        new=(
            "PluginWorkspaceView pageSelector / current-page-selector-id / "
            "pillNav / current-pill-id, or model-derived navigation"
        ),
        scope="Frontend component props",
        example=(
            '<PluginWorkspaceView :pill-nav="modes" current-pill-id="summary" '
            ':model="workspaceModel" />'
        ),
    ),
    DeprecatedApiReplacement(
        old="ControlWorkspaceView navigation prop",
        new="ControlWorkspaceView default pill navigation",
        scope="Frontend component props",
        example='<ControlWorkspaceView v-model="values" :model="workspaceModel" />',
    ),
    DeprecatedApiReplacement(
        old="DoseDesignWorkspaceView navigation prop",
        new="DoseDesignWorkspaceView default pill navigation",
        scope="Frontend component props",
        example='<DoseDesignWorkspaceView v-model="values" title="Dose Design" />',
    ),
    DeprecatedApiReplacement(
        old="BioTemplatePresetWorkspaceView preset-id / presetId",
        new="BioTemplatePresetWorkspaceView preset",
        scope="Frontend component props",
        example='<BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen" />',
    ),
    DeprecatedApiReplacement(
        old="controlsToTopBarTabs() / topBarTabs",
        new="controlsToViewItems() / topBar",
        scope="Frontend control workspace helpers",
        example='const topBar = workspace.topBar.value  // <AppTopBar v-bind="topBar" />',
    ),
    DeprecatedApiReplacement(
        old='ControlWorkspaceView v-bind="workspaceModel"',
        new='ControlWorkspaceView :model="workspaceModel"',
        scope="Frontend component props",
        example='<ControlWorkspaceView v-model="values" :model="workspaceModel" />',
    ),
)

_STATIC_DEPRECATED_FRONTEND_COMPONENTS: tuple[DeprecatedFrontendComponent, ...] = (
    DeprecatedFrontendComponent(
        name="AppPageSelector",
        replacement="AppTopBar",
        kebab_name="app-page-selector",
    ),
    DeprecatedFrontendComponent(
        name="AppPillNav",
        replacement="AppTopBar",
        kebab_name="app-pill-nav",
    ),
    DeprecatedFrontendComponent(
        name="FormFieldRenderer",
        replacement="FormBuilder",
        kebab_name="form-field-renderer",
    ),
    DeprecatedFrontendComponent(
        name="FormSection",
        replacement="FormBuilder",
        kebab_name="form-section",
    ),
    DeprecatedFrontendComponent(
        name="GroupingModal",
        replacement="AutoGroupModal",
        kebab_name="grouping-modal",
    ),
    DeprecatedFrontendComponent(
        name="SettingsButton",
        replacement="AppTopBar",
        kebab_name="settings-button",
    ),
    DeprecatedFrontendComponent(
        name="ToastNotification",
        replacement="AppToastContainer",
        kebab_name="toast-notification",
    ),
)

_STATIC_DEPRECATED_FRONTEND_COMPOSABLES: tuple[DeprecatedFrontendComposable, ...] = (
    DeprecatedFrontendComposable(
        name="usePluginApi",
        replacement="useGeneratedPluginClient",
    ),
    DeprecatedFrontendComposable(
        name="controlsToTopBarTabs",
        replacement="controlsToViewItems",
    ),
)

_STATIC_DEPRECATED_FRONTEND_TYPES: tuple[DeprecatedFrontendType, ...] = (
    DeprecatedFrontendType(
        name="UsePluginApiOptions",
        replacement="CreatePluginClientOptions / generated client types",
    ),
    DeprecatedFrontendType(
        name="TopBarPage",
        replacement="PageSelectorItem",
    ),
    DeprecatedFrontendType(
        name="TopBarPageInput",
        replacement="PageSelectorItemInput",
    ),
    DeprecatedFrontendType(
        name="TopBarTab",
        replacement="PillNavItem",
    ),
    DeprecatedFrontendType(
        name="TopBarTabInput",
        replacement="PillNavItemInput",
    ),
    DeprecatedFrontendType(
        name="TopBarTabOption",
        replacement="PillNavOption",
    ),
    DeprecatedFrontendType(
        name="TopBarTabOptionInput",
        replacement="PillNavOptionInput",
    ),
)


def _load_bundled_deprecated_frontend_components() -> tuple[DeprecatedFrontendComponent, ...]:
    """Load deprecated component migrations from the bundled frontend docs manifest."""
    manifest_path = Path(__file__).parent / "docs" / "bundled" / "frontend.json"
    try:
        data = json.loads(manifest_path.read_text())
    except Exception:
        return ()

    components = data.get("categories", {}).get("components", [])
    if not isinstance(components, list):
        return ()

    deprecated_components: list[DeprecatedFrontendComponent] = []
    for item in components:
        if not isinstance(item, dict) or item.get("deprecated") is not True:
            continue
        name = item.get("name")
        replacement = item.get("replacement")
        if not isinstance(name, str) or not isinstance(replacement, str):
            continue
        deprecated_components.append(
            DeprecatedFrontendComponent(
                name=name,
                replacement=replacement,
                kebab_name=_kebab_case_component(name),
            )
        )
    return tuple(deprecated_components)


def _load_bundled_deprecated_frontend_composables() -> tuple[DeprecatedFrontendComposable, ...]:
    """Load deprecated composable migrations from the bundled frontend docs manifest."""
    manifest_path = Path(__file__).parent / "docs" / "bundled" / "frontend.json"
    try:
        data = json.loads(manifest_path.read_text())
    except Exception:
        return ()

    composables = data.get("categories", {}).get("composables", [])
    if not isinstance(composables, list):
        return ()

    deprecated_composables: list[DeprecatedFrontendComposable] = []
    for item in composables:
        if not isinstance(item, dict) or item.get("deprecated") is not True:
            continue
        name = item.get("name")
        replacement = item.get("replacement")
        if not isinstance(name, str) or not isinstance(replacement, str):
            continue
        deprecated_composables.append(
            DeprecatedFrontendComposable(
                name=name,
                replacement=replacement,
            )
        )
    return tuple(deprecated_composables)


def _kebab_case_component(name: str) -> str:
    return re.sub(r"(?<!^)(?=[A-Z])", "-", name).lower()


DEPRECATED_FRONTEND_COMPONENTS: tuple[DeprecatedFrontendComponent, ...] = (
    _load_bundled_deprecated_frontend_components() or _STATIC_DEPRECATED_FRONTEND_COMPONENTS
)

DEPRECATED_FRONTEND_COMPOSABLES: tuple[DeprecatedFrontendComposable, ...] = (
    _load_bundled_deprecated_frontend_composables() or _STATIC_DEPRECATED_FRONTEND_COMPOSABLES
)

DEPRECATED_FRONTEND_TYPES: tuple[DeprecatedFrontendType, ...] = _STATIC_DEPRECATED_FRONTEND_TYPES


def _frontend_component_replacements() -> tuple[DeprecatedApiReplacement, ...]:
    return tuple(
        DeprecatedApiReplacement(
            old=component.name,
            new=component.replacement,
            scope="Frontend components",
            example=f"<{component.replacement} />",
        )
        for component in DEPRECATED_FRONTEND_COMPONENTS
    )


def _frontend_composable_replacements() -> tuple[DeprecatedApiReplacement, ...]:
    return tuple(
        DeprecatedApiReplacement(
            old=f"{composable.name}()",
            new=f"{composable.replacement}()",
            scope="Frontend composables",
            example=f"const client = {composable.replacement}()",
        )
        for composable in DEPRECATED_FRONTEND_COMPOSABLES
    )


def _frontend_type_replacements() -> tuple[DeprecatedApiReplacement, ...]:
    return tuple(
        DeprecatedApiReplacement(
            old=frontend_type.name,
            new=frontend_type.replacement,
            scope="Frontend types",
            example="import { createPluginClient, type CreatePluginClientOptions } from '@morscherlab/mint-sdk'",
        )
        for frontend_type in DEPRECATED_FRONTEND_TYPES
    )


DEPRECATED_API_REPLACEMENTS: tuple[DeprecatedApiReplacement, ...] = (
    *_STATIC_API_REPLACEMENTS[:3],
    _STATIC_API_REPLACEMENTS[3],
    *_frontend_component_replacements(),
    *_frontend_composable_replacements(),
    *_frontend_type_replacements(),
    *_STATIC_API_REPLACEMENTS[4:],
)

DEPRECATED_API_DOC: dict[str, Any] = {
    "name": "deprecated-apis",
    "purpose": (
        "Migrate plugin code away from abandoned package names, legacy frontend "
        "API helpers, and deprecated component APIs flagged by mint doctor."
    ),
    "diagnostics": [
        "mint doctor --explain",
        "mint doctor --json",
    ],
    "coverage": [
        "legacy package/dependency names in Python, frontend, docs, and agent instructions",
        "legacy get_frontend_config navItems page metadata",
        "legacy dict-shaped PluginMetadata.nav_items entries",
        (
            "Python compatibility aliases and local database hooks such as "
            "PluginExperimentData, local_db, get_local_models(), and "
            "_setup_local_database()"
        ),
        "legacy frontend API helpers such as usePluginApi()",
        "retired frontend type exports such as UsePluginApiOptions",
        (
            "deprecated frontend component/composable imports, re-exports, direct tags, namespace "
            "access, namespace destructuring, dynamic SDK import destructuring, "
            "direct dynamic SDK import member access, dynamic SDK namespace "
            "access, dynamic SDK promise callback access, dynamic SDK subpaths, "
            "and dynamic component references, including type-only imports/re-exports"
        ),
        (
            "plugin docs and agent instructions that recommend deprecated frontend APIs, "
            "private frontend subpath imports, or hand-written frontend API prefixes"
        ),
        (
            "deprecated frontend component props and prop values that have current "
            "replacements, including shorthand and long-form Vue bindings, "
            "inline v-bind objects, and named v-bind object props"
        ),
    ],
    "replacements": [asdict(replacement) for replacement in DEPRECATED_API_REPLACEMENTS],
    "follow_ups": [
        "mint docs frontend AutoGroupModal",
        "mint docs frontend AppSidebar",
        "mint docs frontend AppTopBar",
        "mint docs frontend-api",
    ],
}

DEPRECATED_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "mld_sdk Python package",
        re.compile(r"\bmld_sdk\b"),
        "mint_sdk",
    ),
    (
        "@morscherlab/mld-sdk frontend package",
        re.compile(r"@morscherlab/mld-sdk"),
        "@morscherlab/mint-sdk",
    ),
    (
        "mld-sdk Python dependency",
        re.compile(r"\bmld-sdk\b"),
        "mint-sdk",
    ),
    (
        "mld CLI command",
        re.compile(
            r"\bmld\s+(?:init|add|docs|doctor|dev|build|link|unlink|sdk|auth|deps|update|info)\b"
        ),
        "mint",
    ),
)

_COMPONENT_FRONTEND_IMPORT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    pattern
    for component in DEPRECATED_FRONTEND_COMPONENTS
    for pattern in (
        (
            f"{component.name} component",
            re.compile(
                rf"import\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(component.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/components)?['\"]",
                flags=re.MULTILINE,
            ),
            component.replacement,
        ),
        (
            f"{component.name} component import",
            re.compile(
                r"import\s+(?:type\s+)?[A-Za-z_$][\w$]*\s+from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/components|/src/components)?/"
                rf"{re.escape(component.name)}(?:\.vue)?['\"]",
                flags=re.MULTILINE,
            ),
            component.replacement,
        ),
        (
            f"{component.name} dynamic import",
            re.compile(
                r"\bimport\(\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/components|/src/components)?/"
                rf"{re.escape(component.name)}(?:\.vue)?['\"]"
                r"\s*\)",
                flags=re.MULTILINE,
            ),
            component.replacement,
        ),
        (
            f"{component.name} component re-export",
            re.compile(
                rf"export\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(component.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/components)?['\"]"
                r"|export\s*\{[\s\S]*?\bdefault\b[\s\S]*?\}\s*from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/components|/src/components)?/"
                rf"{re.escape(component.name)}(?:\.vue)?['\"]"
                r"|export\s+(?:type\s+)?\*\s+from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/components|/src/components)?/"
                rf"{re.escape(component.name)}(?:\.vue)?['\"]",
                flags=re.MULTILINE,
            ),
            component.replacement,
        ),
    )
)

_COMPOSABLE_FRONTEND_IMPORT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    pattern
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
    for pattern in (
        (
            f"{composable.name} composable",
            re.compile(
                rf"import\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(composable.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/composables)?['\"]",
                flags=re.MULTILINE,
            ),
            composable.replacement,
        ),
        (
            f"{composable.name} composable import",
            re.compile(
                r"import\s+(?:type\s+)?[A-Za-z_$][\w$]*\s+from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/composables|/src/composables)?/"
                rf"{re.escape(composable.name)}(?:\.(?:ts|js|mjs))?['\"]",
                flags=re.MULTILINE,
            ),
            composable.replacement,
        ),
        (
            f"{composable.name} dynamic import",
            re.compile(
                r"\bimport\(\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/composables|/src/composables)?/"
                rf"{re.escape(composable.name)}(?:\.(?:ts|js|mjs))?['\"]"
                r"\s*\)",
                flags=re.MULTILINE,
            ),
            composable.replacement,
        ),
        (
            f"{composable.name} composable re-export",
            re.compile(
                rf"export\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(composable.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/composables)?['\"]"
                r"|export\s*\{[\s\S]*?\bdefault\b[\s\S]*?\}\s*from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/composables|/src/composables)?/"
                rf"{re.escape(composable.name)}(?:\.(?:ts|js|mjs))?['\"]"
                r"|export\s+(?:type\s+)?\*\s+from\s*"
                rf"['\"]@morscherlab/mint-sdk(?:/composables|/src/composables)?/"
                rf"{re.escape(composable.name)}(?:\.(?:ts|js|mjs))?['\"]",
                flags=re.MULTILINE,
            ),
            composable.replacement,
        ),
    )
)

_TYPE_FRONTEND_IMPORT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    pattern
    for frontend_type in DEPRECATED_FRONTEND_TYPES
    for pattern in (
        (
            f"{frontend_type.name} frontend type",
            re.compile(
                rf"import\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(frontend_type.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/(?:types|composables))?['\"]",
                flags=re.MULTILINE,
            ),
            frontend_type.replacement,
        ),
        (
            f"{frontend_type.name} frontend type import",
            re.compile(
                rf"import\s+type\s*\{{[\s\S]*?\b{re.escape(frontend_type.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:(?:/src)?/types(?:/[^'\"]+)?|(?:/src)?/composables/usePluginApi(?:\.(?:ts|js|mjs))?)['\"]",
                flags=re.MULTILINE,
            ),
            frontend_type.replacement,
        ),
        (
            f"{frontend_type.name} frontend type re-export",
            re.compile(
                rf"export\s*(?:type\s*)?\{{[\s\S]*?\b{re.escape(frontend_type.name)}\b[\s\S]*?\}}\s*from\s*"
                r"['\"]@morscherlab/mint-sdk(?:/(?:types|composables))?['\"]"
                r"|export\s+(?:type\s+)?\*\s+from\s*"
                r"['\"]@morscherlab/mint-sdk(?:(?:/src)?/types(?:/[^'\"]+)?|(?:/src)?/composables/usePluginApi(?:\.(?:ts|js|mjs))?)['\"]",
                flags=re.MULTILINE,
            ),
            frontend_type.replacement,
        ),
    )
)

DEPRECATED_FRONTEND_IMPORT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    *_COMPONENT_FRONTEND_IMPORT_PATTERNS,
    *_COMPOSABLE_FRONTEND_IMPORT_PATTERNS,
    *_TYPE_FRONTEND_IMPORT_PATTERNS,
)

_COMPONENT_FRONTEND_EXPRESSION_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} namespace access",
        re.compile(rf"\b[A-Za-z_$][\w$]*\.{re.escape(component.name)}\b"),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPONENT_FRONTEND_DYNAMIC_MEMBER_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} dynamic import member",
        re.compile(
            r"(?:\(\s*(?:await\s*)?import\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/components)?['\"]"
            r"\s*\)\s*\)|\bimport\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/components)?['\"]"
            r"\s*\))\s*\.\s*"
            rf"{re.escape(component.name)}\b",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPONENT_FRONTEND_DYNAMIC_THEN_MEMBER_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} dynamic import then member",
        re.compile(
            r"\bimport\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/components)?['\"]"
            r"\s*\)\s*\.then\(\s*(?:async\s*)?(?P<alias>[A-Za-z_$][\w$]*)\s*=>"
            rf"[\s\S]{{0,500}}?\b(?P=alias)\s*\.\s*{re.escape(component.name)}\b",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPOSABLE_FRONTEND_EXPRESSION_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} namespace access",
        re.compile(rf"\b[A-Za-z_$][\w$]*\.{re.escape(composable.name)}\b"),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_COMPOSABLE_FRONTEND_DYNAMIC_MEMBER_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} dynamic import member",
        re.compile(
            r"(?:\(\s*(?:await\s*)?import\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/composables)?['\"]"
            r"\s*\)\s*\)|\bimport\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/composables)?['\"]"
            r"\s*\))\s*\.\s*"
            rf"{re.escape(composable.name)}\b",
            flags=re.MULTILINE,
        ),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_COMPOSABLE_FRONTEND_DYNAMIC_THEN_MEMBER_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} dynamic import then member",
        re.compile(
            r"\bimport\(\s*"
            rf"['\"]@morscherlab/mint-sdk(?:/composables)?['\"]"
            r"\s*\)\s*\.then\(\s*(?:async\s*)?(?P<alias>[A-Za-z_$][\w$]*)\s*=>"
            rf"[\s\S]{{0,500}}?\b(?P=alias)\s*\.\s*{re.escape(composable.name)}\b",
            flags=re.MULTILINE,
        ),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_CONTROL_WORKSPACE_FRONTEND_EXPRESSION_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "ControlWorkspace topBarTabs binding",
        re.compile(r"\btopBarTabs\b"),
        "ControlWorkspace topBar binding",
    ),
    (
        "ControlWorkspace topBar tab state",
        re.compile(r"\btopBar\s*\.\s*(?:tabs|currentTabId|onTabSelect)\b"),
        "ControlWorkspace topBar.value pill navigation",
    ),
)

_TYPE_FRONTEND_EXPRESSION_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{frontend_type.name} namespace access",
        re.compile(rf"\b[A-Za-z_$][\w$]*\.{re.escape(frontend_type.name)}\b"),
        frontend_type.replacement,
    )
    for frontend_type in DEPRECATED_FRONTEND_TYPES
)

DEPRECATED_FRONTEND_EXPRESSION_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    *_COMPONENT_FRONTEND_EXPRESSION_PATTERNS,
    *_COMPONENT_FRONTEND_DYNAMIC_MEMBER_PATTERNS,
    *_COMPONENT_FRONTEND_DYNAMIC_THEN_MEMBER_PATTERNS,
    *_COMPOSABLE_FRONTEND_EXPRESSION_PATTERNS,
    *_COMPOSABLE_FRONTEND_DYNAMIC_MEMBER_PATTERNS,
    *_COMPOSABLE_FRONTEND_DYNAMIC_THEN_MEMBER_PATTERNS,
    *_CONTROL_WORKSPACE_FRONTEND_EXPRESSION_PATTERNS,
    *_TYPE_FRONTEND_EXPRESSION_PATTERNS,
)

_COMPONENT_FRONTEND_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} namespace destructure",
        re.compile(
            rf"\b(?:const|let|var)\s*\{{[^}}]*\b{re.escape(component.name)}\b"
            r"(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}]*\}\s*=\s*[A-Za-z_$][\w$]*\b",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPONENT_FRONTEND_DYNAMIC_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} dynamic import destructure",
        re.compile(
            rf"\b(?:const|let|var)\s*\{{[^}}]*\b{re.escape(component.name)}\b"
            r"(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}]*\}\s*=\s*(?:await\s*)?"
            r"import\(\s*['\"]@morscherlab/mint-sdk(?:/components)?['\"]\s*\)",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPONENT_FRONTEND_DYNAMIC_THEN_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} dynamic import then destructure",
        re.compile(
            r"\bimport\(\s*['\"]@morscherlab/mint-sdk(?:/components)?['\"]\s*\)"
            r"\s*\.then\(\s*(?:async\s*)?\(\s*\{[^}]*"
            rf"\b{re.escape(component.name)}\b(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}}]*"
            r"\}\s*\)\s*=>",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPOSABLE_FRONTEND_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} namespace destructure",
        re.compile(
            rf"\b(?:const|let|var)\s*\{{[^}}]*\b{re.escape(composable.name)}\b"
            r"(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}]*\}\s*=\s*[A-Za-z_$][\w$]*\b",
            flags=re.MULTILINE,
        ),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_COMPOSABLE_FRONTEND_DYNAMIC_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} dynamic import destructure",
        re.compile(
            rf"\b(?:const|let|var)\s*\{{[^}}]*\b{re.escape(composable.name)}\b"
            r"(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}]*\}\s*=\s*(?:await\s*)?"
            r"import\(\s*['\"]@morscherlab/mint-sdk(?:/composables)?['\"]\s*\)",
            flags=re.MULTILINE,
        ),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_COMPOSABLE_FRONTEND_DYNAMIC_THEN_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} dynamic import then destructure",
        re.compile(
            r"\bimport\(\s*['\"]@morscherlab/mint-sdk(?:/composables)?['\"]\s*\)"
            r"\s*\.then\(\s*(?:async\s*)?\(\s*\{[^}]*"
            rf"\b{re.escape(composable.name)}\b(?:\s*:\s*[A-Za-z_$][\w$]*)?[^}}]*"
            r"\}\s*\)\s*=>",
            flags=re.MULTILINE,
        ),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    *_COMPONENT_FRONTEND_DESTRUCTURE_PATTERNS,
    *_COMPONENT_FRONTEND_DYNAMIC_DESTRUCTURE_PATTERNS,
    *_COMPONENT_FRONTEND_DYNAMIC_THEN_DESTRUCTURE_PATTERNS,
    *_COMPOSABLE_FRONTEND_DESTRUCTURE_PATTERNS,
    *_COMPOSABLE_FRONTEND_DYNAMIC_DESTRUCTURE_PATTERNS,
    *_COMPOSABLE_FRONTEND_DYNAMIC_THEN_DESTRUCTURE_PATTERNS,
)


_COMPONENT_FRONTEND_DOC_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} component docs",
        re.compile(
            rf"(?<![\w-])(?:{re.escape(component.name)}|{re.escape(component.kebab_name)})(?![\w-])"
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_COMPOSABLE_FRONTEND_DOC_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{composable.name} composable docs",
        re.compile(rf"(?<![\w-]){re.escape(composable.name)}(?![\w-])"),
        composable.replacement,
    )
    for composable in DEPRECATED_FRONTEND_COMPOSABLES
)

_TYPE_FRONTEND_DOC_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{frontend_type.name} frontend type docs",
        re.compile(rf"(?<![\w-]){re.escape(frontend_type.name)}(?![\w-])"),
        frontend_type.replacement,
    )
    for frontend_type in DEPRECATED_FRONTEND_TYPES
)

_FRONTEND_DOC_API_WIRING_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    (
        "component subpath import docs",
        re.compile(r"\bfrom\s+[`'\"]@morscherlab/mint-sdk/(?:src/)?components(?:/[^`'\"]+)?[`'\"]"),
        "root @morscherlab/mint-sdk import",
    ),
    (
        "composable subpath import docs",
        re.compile(r"\bfrom\s+[`'\"]@morscherlab/mint-sdk/(?:src/)?composables(?:/[^`'\"]+)?[`'\"]"),
        "root @morscherlab/mint-sdk import",
    ),
    (
        "VITE_API_PREFIX docs",
        re.compile(r"\bVITE_API_PREFIX\b"),
        "useGeneratedPluginClient",
    ),
    (
        "useApi({ baseUrl }) docs",
        re.compile(r"\buseApi\s*\(\s*\{[^\n}]*\bbaseUrl\b"),
        "useGeneratedPluginClient",
    ),
    (
        "raw /api frontend docs",
        re.compile(
            r"\b(?:fetch|axios(?:\.\w+)?|[A-Za-z_$][\w$]*\s*\.\s*"
            r"(?:get|post|put|patch|delete))\s*\(\s*[`'\"]\/api(?:\/|\b)"
        ),
        "useGeneratedPluginClient",
    ),
)

DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    *_COMPONENT_FRONTEND_DOC_TEXT_PATTERNS,
    *_COMPOSABLE_FRONTEND_DOC_TEXT_PATTERNS,
    *_TYPE_FRONTEND_DOC_TEXT_PATTERNS,
    *_FRONTEND_DOC_API_WIRING_PATTERNS,
)

DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = tuple(
    (
        f"{component.name} dynamic component",
        re.compile(
            rf"(?:\bresolveComponent\s*\(\s*['\"](?:{re.escape(component.name)}|{re.escape(component.kebab_name)})['\"]\s*\)"
            rf"|<component\b[\s\S]*?\b(?:is|:is)\s*=\s*['\"](?:['\"])?(?:{re.escape(component.name)}|{re.escape(component.kebab_name)})(?:['\"])?['\"]"
            rf"|\bcomponent\s*:\s*['\"](?:{re.escape(component.name)}|{re.escape(component.kebab_name)})['\"])",
            flags=re.MULTILINE,
        ),
        component.replacement,
    )
    for component in DEPRECATED_FRONTEND_COMPONENTS
)

_REMOVED_WORKSPACE_NAVIGATION_PROP_RE = re.compile(
    r"(?<![\w-])(?:v-bind:|:)?navigation(?:\s*=|\s|>|$)"
    r"|\bnavigation\s*:"
)

DEPRECATED_FRONTEND_TAG_RULES: tuple[tuple[tuple[str, ...], tuple[tuple[str, re.Pattern[str], str], ...]], ...] = (
    *(
        (
            (component.name, component.kebab_name),
            (
                (
                    f"{component.name} component",
                    re.compile(rf"<(?:{re.escape(component.name)}|{re.escape(component.kebab_name)})\b"),
                    component.replacement,
                ),
            ),
        )
        for component in DEPRECATED_FRONTEND_COMPONENTS
    ),
    (
        ("BaseTabs", "base-tabs"),
        (
            (
                'BaseTabs variant="bordered"',
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?variant\s*=\s*['\"](?:['\"`])?bordered(?:['\"`])?['\"]"
                    r"|\bvariant\s*:\s*['\"]bordered['\"]"
                ),
                'BaseTabs variant="underline"',
            ),
        ),
    ),
    (
        ("AppSidebar", "app-sidebar"),
        (
            (
                "AppSidebar items prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?items\s*=|\bitems\s*:"),
                "AppSidebar panels prop",
            ),
            (
                "AppSidebar active-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:active-id|activeId)\s*="
                    r"|(?:\bactiveId|['\"]active-id['\"])\s*:"
                ),
                "AppSidebar active-view prop",
            ),
        ),
    ),
    (
        ("AppTopBar", "app-top-bar"),
        (
            (
                "AppTopBar floating prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?floating(?:\s*=|\s|>)|\bfloating\s*:"),
                "AppTopBar variant prop",
            ),
            (
                "AppTopBar sticky prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?sticky(?:\s*=|\s|>)|\bsticky\s*:"),
                "AppTopBar variant prop",
            ),
            (
                "AppTopBar pluginName prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:plugin-name|pluginName)\s*="
                    r"|\bv-bind\s*=\s*['\"][\s\S]*(?:\bpluginName|['\"]plugin-name['\"])\s*:"
                ),
                "AppTopBar title/subtitle or pageSelector prop",
            ),
            (
                "AppTopBar pages prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?pages\s*=|\bv-bind\s*=\s*['\"][\s\S]*\bpages\s*:"),
                "AppTopBar pageSelector prop",
            ),
            (
                "AppTopBar current-page-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:current-page-id|currentPageId)\s*="
                    r"|\bv-bind\s*=\s*['\"][\s\S]*(?:\bcurrentPageId|['\"]current-page-id['\"])\s*:"
                ),
                "AppTopBar current-page-selector-id prop",
            ),
            (
                "AppTopBar tabs prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?tabs\s*=|\bv-bind\s*=\s*['\"][\s\S]*\btabs\s*:"),
                "AppTopBar pillNav prop",
            ),
            (
                "AppTopBar current-tab-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:current-tab-id|currentTabId)\s*="
                    r"|\bv-bind\s*=\s*['\"][\s\S]*(?:\bcurrentTabId|['\"]current-tab-id['\"])\s*:"
                ),
                "AppTopBar current-pill-id prop",
            ),
        ),
    ),
    (
        ("PluginWorkspaceView", "plugin-workspace-view"),
        (
            (
                "PluginWorkspaceView pages prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?pages\s*=|\bv-bind\s*=\s*['\"][\s\S]*\bpages\s*:"),
                "PluginWorkspaceView pageSelector prop",
            ),
            (
                "PluginWorkspaceView current-page-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:current-page-id|currentPageId)\s*="
                    r"|\bv-bind\s*=\s*['\"][\s\S]*(?:\bcurrentPageId|['\"]current-page-id['\"])\s*:"
                ),
                "PluginWorkspaceView current-page-selector-id prop",
            ),
            (
                "PluginWorkspaceView tabs prop",
                re.compile(r"(?<![\w-])(?:v-bind:|:)?tabs\s*=|\bv-bind\s*=\s*['\"][\s\S]*\btabs\s*:"),
                "PluginWorkspaceView pillNav prop or model-derived navigation",
            ),
            (
                "PluginWorkspaceView current-tab-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:current-tab-id|currentTabId)\s*="
                    r"|\bv-bind\s*=\s*['\"][\s\S]*(?:\bcurrentTabId|['\"]current-tab-id['\"])\s*:"
                ),
                "PluginWorkspaceView current-pill-id prop",
            ),
        ),
    ),
    (
        ("ControlWorkspaceView", "control-workspace-view"),
        (
            (
                "ControlWorkspaceView navigation prop",
                _REMOVED_WORKSPACE_NAVIGATION_PROP_RE,
                "ControlWorkspaceView default pill navigation",
            ),
            (
                'ControlWorkspaceView v-bind="workspaceModel"',
                re.compile(r"\bv-bind\s*=\s*['\"]workspaceModel['\"]"),
                'ControlWorkspaceView :model="workspaceModel"',
            ),
        ),
    ),
    (
        ("DoseDesignWorkspaceView", "dose-design-workspace-view"),
        (
            (
                "DoseDesignWorkspaceView navigation prop",
                _REMOVED_WORKSPACE_NAVIGATION_PROP_RE,
                "DoseDesignWorkspaceView default pill navigation",
            ),
        ),
    ),
    (
        ("BioTemplatePresetWorkspaceView", "bio-template-preset-workspace-view"),
        (
            (
                "BioTemplatePresetWorkspaceView preset-id prop",
                re.compile(
                    r"(?<![\w-])(?:v-bind:|:)?(?:preset-id|presetId)\s*="
                    r"|(?:\bpresetId|['\"]preset-id['\"])\s*:"
                ),
                "BioTemplatePresetWorkspaceView preset prop",
            ),
        ),
    ),
)
