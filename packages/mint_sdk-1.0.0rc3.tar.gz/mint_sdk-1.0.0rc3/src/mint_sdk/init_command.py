"""Core logic for the ``mint init`` scaffolding command."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from importlib import metadata as importlib_metadata
from pathlib import Path

from mint_sdk import init_templates as T

# ---------------------------------------------------------------------------
# AI assistant configurations
# ---------------------------------------------------------------------------

AI_ASSISTANTS: dict[str, dict[str, str]] = {
    "claude": {
        "filename": "CLAUDE.md",
        "tool_name": "Claude Code",
        "label": "Claude Code",
        "extra": "\n**Skill:** `mint-sdk-plugin` - Build full-stack analysis plugins for MINT platform.\n",
    },
    "codex": {
        "filename": "AGENTS.md",
        "tool_name": "Codex",
        "label": "Codex (OpenAI)",
        "extra": "",
    },
    "cursor": {
        "filename": ".cursorrules",
        "tool_name": "Cursor",
        "label": "Cursor",
        "extra": "",
    },
    "windsurf": {
        "filename": ".windsurfrules",
        "tool_name": "Windsurf",
        "label": "Windsurf",
        "extra": "",
    },
}

# Derived from AI_ASSISTANTS — single source of truth
AI_KEYS = list(AI_ASSISTANTS)
AI_LABELS = [cfg["label"] for cfg in AI_ASSISTANTS.values()]


@dataclass(slots=True)
class PluginNames:
    """All derived name forms for a plugin."""

    human: str  # "Drug Response Analyzer"
    slug: str  # "drug-response-analyzer"
    package_name: str  # "mint-plugin-drug-response-analyzer"
    module_name: str  # "mint_plugin_drug_response_analyzer"
    class_name: str  # "DrugResponseAnalyzerPlugin"
    routes_prefix: str  # "/drug-response-analyzer"


def derive_names(human_name: str) -> PluginNames:
    """Derive all name forms from a human-readable plugin name."""
    # Normalize: strip leading/trailing whitespace
    name = human_name.strip()

    # Strip any existing "mint-plugin-" or "mint_plugin_" prefix to avoid doubling
    name = re.sub(r"^mint[-_]plugin[-_]", "", name, flags=re.IGNORECASE)

    if not name:
        raise ValueError("Plugin name cannot be empty.")

    # Build slug: lowercase, replace non-alnum with hyphens, collapse multiples
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    if not slug:
        raise ValueError("Plugin name must contain at least one alphanumeric character.")
    if slug[0].isdigit():
        raise ValueError("Plugin name must start with a letter.")
    if not re.search(r"[a-z]", slug):
        raise ValueError("Plugin name must contain at least one letter.")

    package_name = f"mint-plugin-{slug}"
    module_name = package_name.replace("-", "_")

    # Build class name from slug segments for deterministic Python identifier output.
    class_name = "".join(part.capitalize() for part in slug.split("-")) + "Plugin"

    routes_prefix = f"/{slug}"

    return PluginNames(
        human=human_name.strip(),
        slug=slug,
        package_name=package_name,
        module_name=module_name,
        class_name=class_name,
        routes_prefix=routes_prefix,
    )


def _get_git_config(key: str) -> str:
    """Read a git config value, returning empty string on failure."""
    try:
        result = subprocess.run(
            ["git", "config", "--get", key],
            capture_output=True,
            text=True,
        )
        return result.stdout.strip() if result.returncode == 0 else ""
    except FileNotFoundError:
        return ""


_SDK_VERSION_FALLBACK = "1.0.0a8"


def _parse_semver_triplet(version: str) -> tuple[int, int, int] | None:
    """Return the leading major/minor/patch tuple from a version string."""
    match = re.match(r"(\d+)\.(\d+)\.(\d+)", version)
    if not match:
        return None
    return tuple(int(part) for part in match.groups())


def _normalize_dependency_version(version: str) -> str | None:
    """Return a PEP 440 dependency-safe version without local metadata."""
    match = re.match(
        r"(\d+\.\d+\.\d+(?:(?:a|b|rc)\d+)?(?:\.dev\d+)?)",
        version,
    )
    return match.group(1) if match else None


def _get_sdk_version() -> str:
    """Get the current SDK version for dependency pinning.

    Prefer installed distribution metadata because hatch-vcs can know the real
    package version even when ``mint_sdk.__version__`` is a stale generated file.
    Preserve prerelease suffixes during internal alpha iteration, but avoid
    writing local ``.dev`` versions that fresh plugin projects cannot resolve
    from an index.
    """
    candidates: list[str] = []

    try:
        candidates.append(importlib_metadata.version("mint-sdk"))
    except importlib_metadata.PackageNotFoundError:
        pass

    try:
        from mint_sdk import __version__

        if __version__:
            candidates.append(__version__)
    except Exception:
        pass

    fallback = _parse_semver_triplet(_SDK_VERSION_FALLBACK)
    for candidate in candidates:
        if not candidate or candidate == "0.0.0":
            continue
        version = _normalize_dependency_version(candidate)
        if not version:
            continue
        if ".dev" in version:
            continue
        parsed = _parse_semver_triplet(version)
        if parsed is not None and fallback is not None and parsed < fallback:
            continue
        return version

    return _SDK_VERSION_FALLBACK


def _get_frontend_sdk_version() -> str:
    """Get the local frontend SDK version when running from the monorepo."""
    package_json = Path(__file__).resolve().parents[3] / "sdk-frontend" / "package.json"
    try:
        if package_json.exists():
            version = json.loads(package_json.read_text()).get("version", "")
            if version:
                return version
    except Exception:
        pass
    return _get_sdk_version()


_PLUGIN_TYPES = ["analysis", "experiment-design"]
_PLUGIN_TYPE_LABELS = ["Analysis", "Experiment Design"]

PLUGIN_TEMPLATES: dict[str, dict[str, str]] = {
    "analysis-basic": {
        "label": "Analysis Basic",
        "description": "A minimal analysis plugin with one health route and one analysis route.",
        "next_step": "Replace AnalysisService.analyze() with your calculation.",
        "frontend_hint": "Add your analysis forms, data inputs, and result displays here.",
    },
    "file-upload-analysis": {
        "label": "File Upload Analysis",
        "description": "Start from a file-upload workflow for CSV, mzML, images, or instrument exports.",
        "next_step": "Run `mint add artifact` and wire FileUploader output into your analysis service.",
        "frontend_hint": "Use FileUploader for input files, then save generated outputs as artifacts.",
    },
    "plate-map-designer": {
        "label": "Plate Map Designer",
        "description": "Start from plate-aware experiment design patterns.",
        "next_step": "Run `mint add data-template plate-map --page`, then use `PluginType.EXPERIMENT_DESIGN` if this plugin owns designs.",
        "frontend_hint": "Use PlateMapTemplate, WellPlate, PlateMapEditor, and SampleLegend instead of raw plate JSON.",
    },
    "curve-fit": {
        "label": "Curve Fit",
        "description": "Start from a dose-response or calibration curve analysis workflow.",
        "next_step": (
            "Run `mint add data-template calibration-curve --page`, then add a typed "
            "settings_model for fit thresholds."
        ),
        "frontend_hint": (
            "Use CalibrationCurveTemplate, DoseResponseTemplate, FitPanel, and DoseCalculator "
            "for curve workflows."
        ),
    },
    "cell-culture-screen": {
        "label": "Cell Culture Screen",
        "description": "Start from sample metadata, sample prep, plate layout, reagents, protocol, and dose-response templates.",
        "next_step": "Edit template defaults, then use starter pages to save design data.",
        "frontend_hint": "Use SampleSheetTemplate, PlateMapTemplate, ReagentListTemplate, ProtocolStepsTemplate, and DoseResponseTemplate together.",
    },
    "omics-assay": {
        "label": "Omics Assay",
        "description": (
            "Start from sample metadata, sample prep, reagents, protocol, instrument run queue, "
            "calibration curve, and sample-by-feature assay matrix templates."
        ),
        "next_step": (
            "Replace the generated instrument-run, calibration-curve, and assay-matrix "
            "defaults with your imported instrument or omics features."
        ),
        "frontend_hint": (
            "Use SampleSheetTemplate, SamplePrepTemplate, ReagentListTemplate, ProtocolStepsTemplate, "
            "InstrumentRunTemplate, CalibrationCurveTemplate, AssayMatrixTemplate, and DataFrame."
        ),
    },
    "longitudinal-study": {
        "label": "Longitudinal Study",
        "description": "Start from sample metadata, time-course schedule, protocol, and measurement matrix templates.",
        "next_step": "Adjust time points and conditions, then save the generated template pages to experiment design_data.",
        "frontend_hint": "Use TimeCourseTemplate, ProtocolStepsTemplate, ExperimentTimeline, ScheduleCalendar, and DataFrame.",
    },
    "molecular-assay": {
        "label": "Molecular Assay",
        "description": (
            "Start from sample metadata, sample prep, reagents, protocol, instrument run queue, "
            "calibration curve, and qPCR/ddPCR plate templates."
        ),
        "next_step": (
            "Adjust run order, calibration standards, qPCR targets, controls, and replicate "
            "defaults before saving experiment design data."
        ),
        "frontend_hint": (
            "Use SamplePrepTemplate, InstrumentRunTemplate, CalibrationCurveTemplate, QpcrPlateTemplate, DataFrame, "
            "WellPlate, SampleSelector, and ReagentList together."
        ),
    },
    "wellplate-screen": {
        "label": "Well-Plate Screen",
        "description": (
            "Start from a ready-to-save plate map, sample sheet, and "
            "dose-response preset workspace."
        ),
        "next_step": (
            "Adjust the generated preset controls, then save the collection "
            "to experiment design_data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "WellPlate, PlateMapEditor, and DoseCalculator."
        ),
    },
    "qpcr-expression": {
        "label": "qPCR Expression",
        "description": (
            "Start from a ready-to-save sample metadata and qPCR/ddPCR plate "
            "preset workspace."
        ),
        "next_step": (
            "Adjust sample names, targets, chemistry, and replicates before "
            "saving experiment design data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "WellPlate, DataFrame, and SampleSelector."
        ),
    },
    "lcms-batch": {
        "label": "LC-MS Batch",
        "description": (
            "Start from a ready-to-save sample sheet, instrument queue, and "
            "assay matrix preset workspace."
        ),
        "next_step": (
            "Adjust samples, features, instrument, method, and QC defaults "
            "before saving experiment design data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "DataFrame, ExperimentTimeline, ScheduleCalendar, and SampleSelector."
        ),
    },
    "elisa-assay": {
        "label": "ELISA Assay",
        "description": (
            "Start from a ready-to-save ELISA plate, sample metadata, "
            "standard curve, and readout matrix workspace."
        ),
        "next_step": (
            "Adjust samples, analyte, standards, response unit, and plate "
            "format before saving experiment design data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "WellPlate, DataFrame, FitPanel, and ChartContainer."
        ),
    },
    "flow-cytometry-assay": {
        "label": "Flow Cytometry Assay",
        "description": (
            "Start from ready-to-save sample metadata, antibody marker panel, "
            "compensation controls, and readout matrix templates."
        ),
        "next_step": (
            "Adjust samples, markers, instrument, and readout defaults before "
            "saving experiment design data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "DataFrame, SampleSelector, and ChartContainer."
        ),
    },
    "western-blot-assay": {
        "label": "Western Blot Assay",
        "description": (
            "Start from ready-to-save sample metadata, reagent list, protocol "
            "steps, and normalized protein readout matrix templates."
        ),
        "next_step": (
            "Adjust samples, protein targets, and loading control before saving "
            "experiment design data."
        ),
        "frontend_hint": (
            "Use useBioTemplatePresetWorkspace, BioTemplatePresetWorkspaceView, "
            "DataFrame, ReagentList, ExperimentTimeline, and SampleSelector."
        ),
    },
    "report-generator": {
        "label": "Report Generator",
        "description": "Start from an analysis plugin that produces downloadable summaries and figures.",
        "next_step": "Run `mint add artifact` for report files and override export_summary/export_csv if needed.",
        "frontend_hint": "Use DataFrame, ChartContainer, ScientificNumber, and artifact downloads for reports.",
    },
    "instrument-importer": {
        "label": "Instrument Importer",
        "description": "Start from a workflow that imports instrument output into experiments.",
        "next_step": "Run `mint add schema ImportRequest --field file_id:str` and `mint add endpoint import-run --method post --request-model ImportRequest`.",
        "frontend_hint": "Use FileUploader, BatchProgressList, and AuditTrail for import sessions.",
    },
    "r-analysis": {
        "label": "R Analysis",
        "description": "Start from an R-backed analysis endpoint with Python/Pydantic contracts.",
        "next_step": "Edit the R script, then run `mint doctor --r --explain`.",
        "frontend_hint": "Use the generated R composable/page; the UI does not need to know the backend route runs R.",
    },
}
_PLUGIN_TEMPLATE_KEYS = list(PLUGIN_TEMPLATES)
_DATA_TEMPLATE_PRESET_TEMPLATES = {
    "wellplate-screen",
    "qpcr-expression",
    "lcms-batch",
    "elisa-assay",
    "flow-cytometry-assay",
    "western-blot-assay",
}
_PLUGIN_TEMPLATE_LABELS = [
    f"{data['label']} - {data['description']}" for data in PLUGIN_TEMPLATES.values()
]


def _data_template_pack_template_names() -> set[str]:
    from mint_sdk.templates import list_template_packs

    return {entry.name for entry in list_template_packs()}


def prompt_config(
    *,
    directory: str = ".",
    name: str | None = None,
    description: str | None = None,
    plugin_type: str | None = None,
    template: str | None = None,
    no_frontend: bool = False,
    ai_assistant: str | None = None,
    yes: bool = False,
) -> dict[str, str]:
    """Gather configuration from explicit values and interactive prompts.

    When ``yes`` is True, every otherwise-interactive prompt is short-circuited
    to its default. This makes the flow safe to run in CI / scripts without
    relying on the implicit non-TTY fallback.
    """
    from mint_sdk._prompt import prompt_confirm, prompt_multiselect, prompt_select, prompt_text

    config: dict[str, str] = {}

    # Directory
    config["directory"] = directory or "."

    # Plugin name
    if name:
        config["name"] = name
    else:
        default_name = directory.replace("-", " ").replace("_", " ").title() if directory != "." else "My Plugin"
        config["name"] = default_name if yes else prompt_text("Plugin name", default_name)

    # Description
    if description:
        config["description"] = description
    else:
        default_desc = "A MINT analysis plugin"
        config["description"] = default_desc if yes else prompt_text("Description", default_desc)

    # Plugin type
    if plugin_type:
        if plugin_type not in _PLUGIN_TYPES:
            valid = ", ".join(_PLUGIN_TYPES)
            raise ValueError(f"Invalid plugin type '{plugin_type}'. Valid types: {valid}.")
        config["type"] = plugin_type
    else:
        idx = 0 if yes else prompt_select("Plugin type", _PLUGIN_TYPE_LABELS, default=0)
        config["type"] = _PLUGIN_TYPES[idx]

    # Plugin template
    if template:
        if template not in PLUGIN_TEMPLATES:
            valid = ", ".join(_PLUGIN_TEMPLATE_KEYS)
            raise ValueError(f"Invalid template '{template}'. Valid templates: {valid}.")
        config["template"] = template
    else:
        idx = 0 if yes else prompt_select("Plugin template", _PLUGIN_TEMPLATE_LABELS, default=0)
        config["template"] = _PLUGIN_TEMPLATE_KEYS[idx]

    # Frontend
    if not no_frontend:
        if yes:
            config["include_frontend"] = "true"
        else:
            config["include_frontend"] = "true" if prompt_confirm("Include frontend?") else "false"
    else:
        config["include_frontend"] = "false"

    # AI assistants (multi-select)
    if ai_assistant:
        # CLI flag: comma-separated list like "claude,cursor"
        config["ai_assistants"] = ai_assistant
    elif yes:
        config["ai_assistants"] = AI_KEYS[0]  # default to first (claude)
    else:
        indices = prompt_multiselect("AI coding assistants", AI_LABELS, defaults=[0])
        selected = [AI_KEYS[i] for i in indices]
        config["ai_assistants"] = ",".join(selected) if selected else ""

    return config


def _build_template_context(
    names: PluginNames,
    config: dict[str, str],
    *,
    author: str | None = None,
    email: str | None = None,
) -> dict[str, str]:
    """Build the placeholder -> value mapping for template rendering.

    Author/email resolve in this order: explicit override → git config →
    placeholder. The override path lets non-interactive scaffolding produce
    correct metadata even on machines without a configured git identity.
    """
    plugin_type = config.get("type", "analysis")
    plugin_type_enum = "EXPERIMENT_DESIGN" if plugin_type == "experiment-design" else "ANALYSIS"

    # Resolve AI assistants — pick the primary by priority order
    ai_keys = _parse_ai_assistants(config.get("ai_assistants", "claude"))
    primary_key = _pick_primary(ai_keys)
    ai_cfg = AI_ASSISTANTS.get(primary_key) if primary_key else None
    include_frontend = config.get("include_frontend", "true") == "true"
    template_key = config.get("template", "analysis-basic")
    template = PLUGIN_TEMPLATES.get(template_key, PLUGIN_TEMPLATES["analysis-basic"])

    description = config.get("description", "A MINT analysis plugin")

    context = {
        "PLUGIN_NAME": names.human,
        "SLUG": names.slug,
        "PACKAGE_NAME": names.package_name,
        "MODULE_NAME": names.module_name,
        "CLASS_NAME": names.class_name,
        "ROUTES_PREFIX": names.routes_prefix,
        "DESCRIPTION": description,
        "DESCRIPTION_JSON": json.dumps(description),
        "PLUGIN_TYPE": config.get("type", "analysis"),
        "PLUGIN_TYPE_ENUM": plugin_type_enum,
        "PLUGIN_TEMPLATE": template_key,
        "PLUGIN_TEMPLATE_LABEL": template["label"],
        "PLUGIN_TEMPLATE_DESCRIPTION": template["description"],
        "PLUGIN_TEMPLATE_NEXT_STEP": template["next_step"],
        "PLUGIN_TEMPLATE_FRONTEND_HINT": template["frontend_hint"],
        "AUTHOR": author or _get_git_config("user.name") or "Your Name",
        "EMAIL": email or _get_git_config("user.email") or "you@example.com",
        "SDK_VERSION": _get_sdk_version(),
        "FRONTEND_SDK_VERSION": _get_frontend_sdk_version(),
        "AI_FILENAME": ai_cfg["filename"] if ai_cfg else "",
        "AI_TOOL_NAME": ai_cfg["tool_name"] if ai_cfg else "",
        "AI_EXTRA": ai_cfg.get("extra", "") if ai_cfg else "",
    }
    context.update(_frontend_template_context(names.module_name, include_frontend))
    return context


def _frontend_template_context(module_name: str, include_frontend: bool) -> dict[str, str]:
    """Return template values whose output depends on the frontend scaffold flag."""
    if not include_frontend:
        return {
            "FRONTEND_FORCE_INCLUDE": "",
            "FRONTEND_README_SECTION": "",
        }

    return {
        "FRONTEND_FORCE_INCLUDE": (
            "[tool.hatch.build.targets.wheel.force-include]\n"
            f'"frontend/dist" = "{module_name}/frontend"\n'
        ),
        "FRONTEND_README_SECTION": (
            "### Frontend\n\n"
            "```bash\n"
            "cd frontend\n"
            "bun install\n"
            "bun run dev\n"
            "```\n"
        ),
    }


def _parse_ai_assistants(raw: str) -> list[str]:
    """Parse comma-separated AI assistant keys, warning about invalid ones."""
    if not raw or raw.strip() == "none":
        return []
    valid: list[str] = []
    for token in raw.split(","):
        key = token.strip()
        if not key:
            continue
        if key == "none":
            continue
        if key in AI_ASSISTANTS:
            valid.append(key)
        else:
            print(
                f"  Warning: unknown AI assistant '{key}' (valid: {', '.join(sorted(AI_ASSISTANTS))})",
                file=sys.stderr,
            )
    return valid


def _pick_primary(keys: list[str]) -> str | None:
    """Pick the primary AI file by priority (Claude first — it has the Skill line)."""
    if not keys:
        return None
    for candidate in AI_KEYS:
        if candidate in keys:
            return candidate
    return keys[0]


def render(template: str, context: dict[str, str]) -> str:
    """Replace ``__KEY__`` placeholders in a template string."""
    result = template
    for key, value in context.items():
        result = result.replace(f"__{key.upper()}__", str(value))
    return result


# File tree: (relative_path, template_constant)
# None template means empty file.
BACKEND_FILES: list[tuple[str, str | None]] = [
    ("pyproject.toml", "PYPROJECT_TOML"),
    ("README.md", "README_MD"),
    ("CHANGELOG.md", "CHANGELOG_MD"),
    (".gitignore", "GITIGNORE"),
    ("src/__MODULE_NAME__/__init__.py", "INIT_PY"),
    ("src/__MODULE_NAME__/plugin.py", "PLUGIN_PY"),
    ("src/__MODULE_NAME__/routers/__init__.py", "ROUTERS_INIT_PY"),
    ("src/__MODULE_NAME__/routers/analysis.py", "ROUTERS_ANALYSIS_PY"),
    ("src/__MODULE_NAME__/schemas/__init__.py", "SCHEMAS_INIT_PY"),
    ("src/__MODULE_NAME__/schemas/requests.py", "SCHEMAS_REQUESTS_PY"),
    ("src/__MODULE_NAME__/schemas/responses.py", "SCHEMAS_RESPONSES_PY"),
    ("src/__MODULE_NAME__/services/__init__.py", "SERVICES_INIT_PY"),
    ("src/__MODULE_NAME__/services/analysis_service.py", "SERVICES_ANALYSIS_PY"),
    ("tests/__init__.py", None),
    ("tests/test_plugin.py", "TEST_PLUGIN_PY"),
    ("scripts/dev.sh", "SCRIPT_DEV_SH"),
    ("scripts/build.sh", "SCRIPT_BUILD_SH"),
    ("scripts/release.sh", "SCRIPT_RELEASE_SH"),
    (".github/workflows/ci.yml", "CI_YML"),
    (".github/workflows/release.yml", "RELEASE_YML"),
]

FRONTEND_FILES: list[tuple[str, str | None]] = [
    ("frontend/package.json", "FRONTEND_PACKAGE_JSON"),
    ("frontend/vite.config.ts", "FRONTEND_VITE_CONFIG_TS"),
    ("frontend/vitest.config.ts", "FRONTEND_VITEST_CONFIG_TS"),
    ("frontend/tsconfig.json", "FRONTEND_TSCONFIG_JSON"),
    ("frontend/tsconfig.node.json", "FRONTEND_TSCONFIG_NODE_JSON"),
    ("frontend/postcss.config.js", "FRONTEND_POSTCSS_CONFIG_JS"),
    ("frontend/index.html", "FRONTEND_INDEX_HTML"),
    ("frontend/src/main.ts", "FRONTEND_MAIN_TS"),
    ("frontend/src/style.css", "FRONTEND_STYLE_CSS"),
    ("frontend/src/env.d.ts", "FRONTEND_ENV_D_TS"),
    ("frontend/src/App.vue", "FRONTEND_APP_VUE"),
    ("frontend/src/views/DashboardView.vue", "FRONTEND_DASHBOARD_VIEW_VUE"),
    ("frontend/src/views/AnalysisView.vue", "FRONTEND_ANALYSIS_VIEW_VUE"),
    # Architecture-hinting placeholders — every mature plugin grows these dirs
    # within the first hour. Pre-creating them means agents drop new stores /
    # composables / types into the canonical location without thinking.
    ("frontend/src/stores/.gitkeep", None),
    ("frontend/src/composables/.gitkeep", None),
    ("frontend/src/types/.gitkeep", None),
]


def write_files(
    target_dir: Path,
    context: dict[str, str],
    include_frontend: bool,
    ai_keys: list[str] | None = None,
) -> list[str]:
    """Write all scaffolded files. Returns list of relative paths created."""
    context = {
        **context,
        **_frontend_template_context(context["MODULE_NAME"], include_frontend),
    }
    files = list(BACKEND_FILES)
    if include_frontend:
        files.extend(FRONTEND_FILES)

    # Also copy the sdk-auto-update workflow if the template exists
    sdk_auto_update = _find_sdk_auto_update_template()
    created: list[str] = []

    for rel_path, template_name in files:
        # Replace __MODULE_NAME__ in path
        rel_path = rel_path.replace("__MODULE_NAME__", context["MODULE_NAME"])
        abs_path = target_dir / rel_path

        abs_path.parent.mkdir(parents=True, exist_ok=True)

        if template_name is None:
            abs_path.write_text("")
        else:
            template = getattr(T, template_name)
            abs_path.write_text(render(template, context))

        created.append(rel_path)

    # Copy sdk-auto-update template if available
    if sdk_auto_update:
        dest = target_dir / ".github" / "workflows" / "sdk-auto-update.yml"
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(sdk_auto_update, dest)
        created.append(".github/workflows/sdk-auto-update.yml")

    # Write AI instructions: primary file + symlinks for others
    if ai_keys is None:
        ai_keys = []
    primary_key = _pick_primary(ai_keys)
    if primary_key:
        ai_template = Path(__file__).parent / "ai_instructions.md.template"
        if ai_template.exists():
            primary_filename = AI_ASSISTANTS[primary_key]["filename"]
            content = render(ai_template.read_text(), context)
            content = re.sub(r"\n{3,}", "\n\n", content)
            primary_dest = target_dir / primary_filename
            primary_dest.parent.mkdir(parents=True, exist_ok=True)
            primary_dest.write_text(content)
            created.append(primary_filename)

            # Symlink other selected AI files → primary
            for key in ai_keys:
                if key == primary_key:
                    continue
                link_filename = AI_ASSISTANTS[key]["filename"]
                link_path = target_dir / link_filename
                link_path.parent.mkdir(parents=True, exist_ok=True)
                if link_path.exists() or link_path.is_symlink():
                    link_path.unlink()
                os.symlink(primary_filename, link_path)
                created.append(f"{link_filename} -> {primary_filename}")

    return created


def _find_sdk_auto_update_template() -> Path | None:
    """Locate the sdk-auto-update workflow template in the SDK package."""
    # Check relative to this file (monorepo layout)
    candidate = (
        Path(__file__).resolve().parent.parent.parent.parent.parent
        / ".github"
        / "workflows"
        / "sdk-auto-update.template.yml"
    )
    if candidate.exists():
        return candidate
    return None


def post_scaffold(
    target_dir: Path,
    *,
    no_install: bool,
    no_git: bool,
    has_frontend: bool,
) -> None:
    """Run post-scaffolding steps: git init, install deps, chmod scripts."""
    # chmod scripts
    scripts_dir = target_dir / "scripts"
    if scripts_dir.exists():
        for script in scripts_dir.glob("*.sh"):
            script.chmod(script.stat().st_mode | 0o755)

    # git init
    if not no_git:
        if not (target_dir / ".git").exists():
            result = subprocess.run(
                ["git", "init"],
                cwd=target_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                print("  Initialized git repository")
            else:
                print(f"  Warning: git init failed: {result.stderr}", file=sys.stderr)

    # Create frontend/dist placeholder so hatch force-include doesn't fail
    if has_frontend:
        (target_dir / "frontend" / "dist").mkdir(parents=True, exist_ok=True)

    # uv sync
    if not no_install:
        if shutil.which("uv"):
            print("  Running uv sync...")
            # Stream stdout/stderr live so the user sees progress and full
            # error output if something fails. Swallowing stderr historically
            # masked broken networks, missing build tools, and resolver errors.
            result = subprocess.run(
                ["uv", "sync"],
                cwd=target_dir,
                text=True,
            )
            if result.returncode != 0:
                print(
                    "  uv sync failed (see output above).\n"
                    f"  Retry manually:  cd {target_dir} && uv sync",
                    file=sys.stderr,
                )
        else:
            print("  Warning: uv not found, skipping dependency install")

        # bun install
        if has_frontend:
            frontend_dir = target_dir / "frontend"
            if shutil.which("bun"):
                print("  Running bun install...")
                result = subprocess.run(
                    ["bun", "install"],
                    cwd=frontend_dir,
                    text=True,
                )
                if result.returncode != 0:
                    print(
                        "  bun install failed (see output above).\n"
                        f"  Retry manually:  cd {frontend_dir} && bun install",
                        file=sys.stderr,
                    )
            else:
                print("  Warning: bun not found, skipping frontend install")


def cmd_init(
    *,
    directory: str = ".",
    name: str | None = None,
    description: str | None = None,
    plugin_type: str | None = None,
    template: str | None = None,
    no_frontend: bool = False,
    no_install: bool = False,
    no_git: bool = False,
    force: bool = False,
    ai_assistant: str | None = None,
    yes: bool = False,
    author: str | None = None,
    email: str | None = None,
) -> None:
    """Execute the ``mint init`` command."""
    try:
        config = prompt_config(
            directory=directory,
            name=name,
            description=description,
            plugin_type=plugin_type,
            template=template,
            no_frontend=no_frontend,
            ai_assistant=ai_assistant,
            yes=yes,
        )
        names = derive_names(config["name"])
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    include_frontend = config.get("include_frontend", "true") == "true"

    # Resolve target directory
    resolved_directory = config["directory"]
    if resolved_directory == ".":
        target_dir = Path.cwd()
    else:
        target_dir = Path(resolved_directory).resolve()

    # Safety check: non-empty directory
    if target_dir.exists() and any(target_dir.iterdir()) and not force:
        print(
            f"Error: {target_dir} is not empty. Use --force to scaffold anyway.",
            file=sys.stderr,
        )
        sys.exit(1)

    target_dir.mkdir(parents=True, exist_ok=True)

    ai_keys = _parse_ai_assistants(config.get("ai_assistants", "claude"))
    context = _build_template_context(names, config, author=author, email=email)
    print(f"\nCreating {names.package_name}/ ...")

    created = write_files(target_dir, context, include_frontend, ai_keys=ai_keys)

    for f in created:
        print(f"  {f}")

    if config.get("template") == "r-analysis":
        from mint_sdk.add_command import cmd_add_r_analysis

        cmd_add_r_analysis(
            path=str(target_dir),
            name="analysis",
            page=include_frontend,
            emit_guidance=False,
        )

    if config.get("template") in _data_template_pack_template_names():
        from mint_sdk.add_command import DataTemplatePackKind, cmd_add_data_template_pack

        cmd_add_data_template_pack(
            path=str(target_dir),
            pack=DataTemplatePackKind(config["template"]),
            page=include_frontend,
            _refresh_contract=False,
        )

    if config.get("template") in _DATA_TEMPLATE_PRESET_TEMPLATES:
        from mint_sdk.add_command import DataTemplatePresetKind, cmd_add_data_template_preset

        cmd_add_data_template_preset(
            path=str(target_dir),
            preset=DataTemplatePresetKind(config["template"]),
            page=include_frontend,
        )

    if include_frontend:
        try:
            from mint_sdk.contract import generate_contract_files

            result = generate_contract_files(target_dir)
            print(f"  {result.detail}")
        except Exception as exc:
            print(
                "  Warning: could not generate frontend contract automatically.\n"
                f"  Retry manually:  cd {target_dir} && mint sdk generate\n"
                f"  Reason: {exc}",
                file=sys.stderr,
            )

    print()
    post_scaffold(
        target_dir,
        no_install=no_install,
        no_git=no_git,
        has_frontend=include_frontend,
    )

    _print_next_steps(
        resolved_directory=resolved_directory,
        include_frontend=include_frontend,
        ai_keys=ai_keys,
        template_key=config.get("template", "analysis-basic"),
    )


def _print_next_steps(
    *,
    resolved_directory: str,
    include_frontend: bool,
    ai_keys: list[str],
    template_key: str,
) -> None:
    """Print the post-init banner — ports, agent file pointer, and SDK discovery hints."""
    primary_key = _pick_primary(ai_keys)
    ai_filename = AI_ASSISTANTS[primary_key]["filename"] if primary_key else None

    lines = [
        "",
        "Done! Next steps:",
        f"  cd {resolved_directory}",
        "  mint doctor                       # validate plugin structure",
    ]
    if include_frontend:
        lines.insert(3, "  mint sdk generate                 # refresh typed frontend client")
    if template_key != "analysis-basic":
        lines.append(f"  # template: {template_key}")
    if include_frontend:
        lines.append("  mint dev                          # backend on :8003, frontend on :5175")
    else:
        lines.append("  mint dev                          # backend on :8003")

    if ai_filename:
        lines += [
            "",
            f"Agent instructions written to: {ai_filename}",
            "  → Tells your agent to run `mint docs` and discuss SDK component picks",
            "    BEFORE writing any custom Vue. Read it before your first prompt.",
        ]

    if include_frontend:
        lines += [
            "",
            "Discover SDK before building UI:",
            "  mint docs frontend choose         # canonical component paths by task",
            '  mint docs frontend components     # all 80+ components, grouped',
            '  mint docs search "<concept>"      # cross-SDK keyword search',
            "  mint docs contract .              # backend routes + generated client wiring",
            "  mint add data-template --list     # built-in biology data templates",
            "  mint add data-template-pack --list  # curated template sets",
            "  mint add data-template-preset --list # ready-to-save presets",
            "  mint docs r-bridge                # R bridge contracts/helpers",
            "  mint docs template-preset wellplate-screen",
            "  mint docs template plate-map      # template imports/adapters/components",
            "  mint docs frontend BioTemplatePresetWorkspaceView # one preset with controls + save/load",
            "  mint docs frontend BioTemplatePackWorkspaceView # curated template pack with save/load",
            "  mint docs frontend useTemplateCollection # low-level custom template persistence",
            "  mint docs frontend <Name>         # props/emits/slots for one component",
        ]

    print("\n".join(lines) + "\n")
