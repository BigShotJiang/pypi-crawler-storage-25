"""R analysis bridge for MINT plugins.

The bridge keeps Python/FastAPI as the plugin contract owner while allowing
analysis code to live in R. R scripts receive input/output paths as positional
arguments and via environment variables:

    Rscript analysis.R <input.json> <output.json>

Scripts must write JSON that validates against the declared output schema.
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field

from mint_sdk.exceptions import PluginException

InputFormat = Literal["json", "parquet"]
OutputFormat = Literal["json", "parquet"]
TOutput = TypeVar("TOutput", bound=BaseModel)


class RBridgeError(PluginException):
    """Raised when an R-backed analysis fails."""

    def __init__(self, message: str, details: dict[str, Any] | None = None):
        super().__init__(message, code="R_BRIDGE_ERROR", details=details)


class RScriptSpec(BaseModel):
    """Configuration for an R analysis script."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    script: str
    input_schema: type[BaseModel]
    output_schema: type[TOutput]
    working_dir: str | None = None
    timeout_seconds: int = 600
    input_format: InputFormat = "json"
    output_format: OutputFormat = "json"
    executable: str | None = None
    extra_args: list[str] = Field(default_factory=list)
    artifact_dir: str | None = None


@dataclass(slots=True)
class RRunProvenance:
    """Reproducibility details from the last R bridge execution."""

    executable: str
    script: str
    input_path: str
    output_path: str
    working_dir: str
    exit_code: int
    elapsed_seconds: float
    stdout_tail: str = ""
    stderr_tail: str = ""
    experiment_id: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)


class RAnalysisBridge:
    """Run an R script with validated Pydantic input and output models."""

    def __init__(self, spec: RScriptSpec):
        if spec.input_format != "json" or spec.output_format != "json":
            raise RBridgeError(
                "Only JSON input/output is supported in this SDK version.",
                details={"input_format": spec.input_format, "output_format": spec.output_format},
            )
        self.spec = spec
        self.last_run: RRunProvenance | None = None

    async def run(
        self,
        *,
        payload: BaseModel | dict[str, Any],
        experiment_id: int | None = None,
        extra_env: dict[str, str] | None = None,
    ) -> TOutput:
        """Run the R analysis and return a validated output model."""
        input_payload = self._validate_input(payload)
        executable = self._resolve_executable()
        working_dir = self._working_dir()
        script_path = self._script_path(working_dir)

        with tempfile.TemporaryDirectory(prefix="mint-r-") as temp_dir:
            temp_path = Path(temp_dir)
            input_path = temp_path / "input.json"
            output_path = temp_path / "output.json"
            input_path.write_text(input_payload.model_dump_json())
            artifact_dir = self._artifact_dir()

            env = {
                **os.environ,
                "MINT_R_INPUT": str(input_path),
                "MINT_R_OUTPUT": str(output_path),
            }
            provenance_extra: dict[str, Any] = {}
            if artifact_dir is not None:
                artifact_dir.mkdir(parents=True, exist_ok=True)
                env["MINT_R_ARTIFACT_DIR"] = str(artifact_dir)
                provenance_extra["artifact_dir"] = str(artifact_dir)
            if experiment_id is not None:
                env["MINT_EXPERIMENT_ID"] = str(experiment_id)
            if extra_env:
                env.update(extra_env)

            started = time.perf_counter()
            process = await asyncio.create_subprocess_exec(
                executable,
                str(script_path),
                str(input_path),
                str(output_path),
                *self.spec.extra_args,
                cwd=str(working_dir),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=self.spec.timeout_seconds,
                )
            except TimeoutError as exc:
                process.kill()
                await process.wait()
                raise RBridgeError(
                    "R analysis timed out.",
                    details={
                        "script": str(script_path),
                        "timeout_seconds": self.spec.timeout_seconds,
                    },
                ) from exc

            elapsed = time.perf_counter() - started
            stdout_text = _tail(stdout.decode(errors="replace"))
            stderr_text = _tail(stderr.decode(errors="replace"))
            self.last_run = RRunProvenance(
                executable=executable,
                script=str(script_path),
                input_path=str(input_path),
                output_path=str(output_path),
                working_dir=str(working_dir),
                exit_code=process.returncode or 0,
                elapsed_seconds=elapsed,
                stdout_tail=stdout_text,
                stderr_tail=stderr_text,
                experiment_id=experiment_id,
                extra=provenance_extra,
            )

            if process.returncode != 0:
                raise RBridgeError(
                    "R analysis failed.",
                    details={
                        "script": str(script_path),
                        "exit_code": process.returncode,
                        "stdout": stdout_text,
                        "stderr": stderr_text,
                    },
                )
            if not output_path.exists():
                raise RBridgeError(
                    "R analysis did not write an output file.",
                    details={"script": str(script_path), "output_path": str(output_path)},
                )
            try:
                return self.spec.output_schema.model_validate_json(output_path.read_text())
            except Exception as exc:
                raise RBridgeError(
                    "R analysis output failed schema validation.",
                    details={"script": str(script_path), "output_path": str(output_path), "error": str(exc)},
                ) from exc

    def _validate_input(self, payload: BaseModel | dict[str, Any]) -> BaseModel:
        try:
            if isinstance(payload, self.spec.input_schema):
                return payload
            return self.spec.input_schema.model_validate(payload)
        except Exception as exc:
            raise RBridgeError("R analysis input failed schema validation.", details={"error": str(exc)}) from exc

    def _resolve_executable(self) -> str:
        executable = self.spec.executable or os.environ.get("MINT_RSCRIPT") or shutil.which("Rscript")
        if not executable:
            raise RBridgeError(
                "Rscript executable not found.",
                details={"fix": "Install R or set MINT_RSCRIPT to the Rscript executable path."},
            )
        return executable

    def _working_dir(self) -> Path:
        return Path(self.spec.working_dir or ".").resolve()

    def _script_path(self, working_dir: Path) -> Path:
        script = Path(self.spec.script)
        path = script if script.is_absolute() else working_dir / script
        if not path.exists():
            raise RBridgeError("R script not found.", details={"script": str(path)})
        return path

    def _artifact_dir(self) -> Path | None:
        if self.spec.artifact_dir is None:
            return None
        path = Path(self.spec.artifact_dir)
        return path if path.is_absolute() else self._working_dir() / path


def check_r_environment(*, executable: str | None = None, project_dir: Path | None = None) -> list[dict[str, Any]]:
    """Return diagnostic checks for the local R bridge environment."""
    checks: list[dict[str, Any]] = []
    resolved = executable or os.environ.get("MINT_RSCRIPT") or shutil.which("Rscript")
    checks.append(
        {
            "ok": bool(resolved),
            "label": "Rscript",
            "detail": resolved or "not found",
            "fix": "Install R or set MINT_RSCRIPT." if not resolved else "",
        }
    )
    if project_dir is not None:
        renv = project_dir / "renv.lock"
        r_requirements = project_dir / "r-requirements.txt"
        r_scripts = _find_r_scripts(project_dir)
        bridge_helpers = _find_r_bridge_helpers(project_dir)
        jsonlite_declared = _declares_jsonlite_dependency(renv=renv, r_requirements=r_requirements)
        checks.append(
            {
                "ok": renv.exists() or r_requirements.exists(),
                "label": "R dependencies",
                "detail": (
                    "renv.lock found"
                    if renv.exists()
                    else "r-requirements.txt found"
                    if r_requirements.exists()
                    else "not declared"
                ),
                "fix": "Add renv.lock or r-requirements.txt for reproducible R packages."
                if not (renv.exists() or r_requirements.exists())
                else "",
            }
        )
        checks.append(
            {
                "ok": not r_scripts or jsonlite_declared,
                "label": "R jsonlite package",
                "detail": (
                    "no R scripts found"
                    if not r_scripts
                    else "jsonlite declared"
                    if jsonlite_declared
                    else "jsonlite not declared"
                ),
                "fix": "Add jsonlite to renv.lock or r-requirements.txt; mint_bridge.R requires it."
                if r_scripts and not jsonlite_declared
                else "",
            }
        )
        checks.append(
            {
                "ok": not r_scripts or bool(bridge_helpers),
                "label": "R bridge helper",
                "detail": (
                    f"{bridge_helpers[0].relative_to(project_dir).as_posix()} found"
                    if bridge_helpers
                    else "no R scripts found"
                    if not r_scripts
                    else f"{len(r_scripts)} R script(s), mint_bridge.R missing"
                ),
                "fix": (
                    "Run `mint add r-analysis <name>` or add r_scripts/mint_bridge.R next to your "
                    "R analysis scripts."
                )
                if r_scripts and not bridge_helpers
                else "",
            }
        )
    return checks


def _tail(value: str, limit: int = 4000) -> str:
    return value[-limit:] if len(value) > limit else value


_R_PROJECT_EXCLUDED_DIRS = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
}


def _find_r_scripts(project_dir: Path) -> list[Path]:
    scripts: list[Path] = []
    for path in project_dir.rglob("*.R"):
        if not path.is_file() or path.name == "mint_bridge.R":
            continue
        if _has_excluded_part(path.relative_to(project_dir)):
            continue
        scripts.append(path)
    return scripts


def _find_r_bridge_helpers(project_dir: Path) -> list[Path]:
    helpers: list[Path] = []
    for path in project_dir.rglob("mint_bridge.R"):
        if not path.is_file():
            continue
        if _has_excluded_part(path.relative_to(project_dir)):
            continue
        helpers.append(path)
    return helpers


def _has_excluded_part(path: Path) -> bool:
    return any(part in _R_PROJECT_EXCLUDED_DIRS for part in path.parts[:-1])


def _declares_jsonlite_dependency(*, renv: Path, r_requirements: Path) -> bool:
    return _requirements_include_jsonlite(r_requirements) or _renv_lock_includes_jsonlite(renv)


def _requirements_include_jsonlite(path: Path) -> bool:
    if not path.exists():
        return False

    for line in path.read_text(errors="ignore").splitlines():
        package = line.split("#", 1)[0].strip().lower()
        if not package:
            continue
        if package == "jsonlite" or package.startswith(
            ("jsonlite=", "jsonlite ", "jsonlite>", "jsonlite<", "jsonlite!", "jsonlite~")
        ):
            return True
    return False


def _renv_lock_includes_jsonlite(path: Path) -> bool:
    if not path.exists():
        return False

    try:
        payload = json.loads(path.read_text(errors="ignore"))
    except json.JSONDecodeError:
        return False

    packages = payload.get("Packages")
    if isinstance(packages, dict):
        if any(str(name).lower() == "jsonlite" for name in packages):
            return True
        return any(
            isinstance(meta, dict) and str(meta.get("Package", "")).lower() == "jsonlite"
            for meta in packages.values()
        )
    return False
