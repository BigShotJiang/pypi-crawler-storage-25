"""Template strings for the ``mint init`` scaffolding command.

All templates use ``__PLACEHOLDER__`` delimiters so they don't conflict
with curly braces in Python, TypeScript, JSON, or CSS.
"""

# ---------------------------------------------------------------------------
# Backend templates
# ---------------------------------------------------------------------------

PYPROJECT_TOML = """\
[project]
name = "__PACKAGE_NAME__"
dynamic = ["version"]
description = "__DESCRIPTION__"
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }
authors = [{ name = "__AUTHOR__", email = "__EMAIL__" }]
keywords = ["mint", "plugin", "__PLUGIN_TYPE__"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Framework :: FastAPI",
    "Intended Audience :: Science/Research",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.12",
]

dependencies = [
    "mint-sdk>=__SDK_VERSION__",
    "fastapi>=0.109.0",
    "pydantic>=2.0.0",
    "uvicorn>=0.27.0",
]

[dependency-groups]
dev = [
    "ruff>=0.4.0",
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "httpx>=0.27.0",
]

[project.entry-points."mint.plugins"]
__SLUG__ = "__MODULE_NAME__.plugin:__CLASS_NAME__"

[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"

[tool.hatch.version.raw-options]
fallback_version = "0.1.0"

[tool.hatch.build.hooks.vcs]
version-file = "src/__MODULE_NAME__/_version.py"

[tool.hatch.build.targets.wheel]
packages = ["src/__MODULE_NAME__"]

__FRONTEND_FORCE_INCLUDE__

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]

[tool.ruff]
target-version = "py312"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "UP"]
"""

INIT_PY = """\
try:
    from __MODULE_NAME__._version import __version__
except ImportError:
    __version__ = "0.0.0"
"""

PLUGIN_PY = """\
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import APIRouter
from mint_sdk import (
    AnalysisPlugin,
    HealthStatus,
    PlatformContext,
    PluginCapabilities,
    PluginHealth,
    PluginMetadata,
    PluginNavItem,
    PluginType,
)

from __MODULE_NAME__ import __version__
from __MODULE_NAME__.routers import analysis

PLUGIN_NAME = "__SLUG__"
PLUGIN_VERSION = __version__
PLUGIN_DESCRIPTION = "__DESCRIPTION__"
PLUGIN_ROUTES_PREFIX = "__ROUTES_PREFIX__"
PLUGIN_FRONTEND_ROUTE = "__ROUTES_PREFIX__"
PLUGIN_ANALYSIS_TYPE = "custom"
PLUGIN_TYPE = PluginType.__PLUGIN_TYPE_ENUM__
PLUGIN_TEMPLATE = "__PLUGIN_TEMPLATE__"


class __CLASS_NAME__(AnalysisPlugin):

    _instance: "__CLASS_NAME__ | None" = None

    def __new__(cls) -> "__CLASS_NAME__":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if hasattr(self, "_initialized"):
            return
        self._initialized = True

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=PLUGIN_NAME,
            version=PLUGIN_VERSION,
            description=PLUGIN_DESCRIPTION,
            analysis_type=PLUGIN_ANALYSIS_TYPE,
            routes_prefix=PLUGIN_ROUTES_PREFIX,
            plugin_type=PLUGIN_TYPE,
            capabilities=PluginCapabilities(
                requires_auth=False,
                requires_database=False,
                requires_experiments=False,
            ),
            author="__AUTHOR__",
            license="MIT",
            icon=(
                "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 "
                "2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 "
                "002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 "
                "2 0 01-2 2h-2a2 2 0 01-2-2z"
            ),
            # Optional brand color, e.g. "#0EA5E9".
            color="",
            nav_items=[
                PluginNavItem(
                    path="/",
                    label="Dashboard",
                    id="dashboard",
                    icon="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z",
                    description=PLUGIN_DESCRIPTION,
                ),
                PluginNavItem(
                    path="/analysis",
                    label="Analysis",
                    id="analysis",
                    icon="M4 19h16M7 16V8m5 8V4m5 12v-6",
                    description="Run analysis on your data",
                ),
            ],
        )

    async def initialize(self, context: PlatformContext | None = None) -> None:
        self._context = context
        mode = "integrated" if context else "standalone"
        print(f"[{PLUGIN_NAME}] Initialized in {mode} mode")

    async def shutdown(self) -> None:
        print(f"[{PLUGIN_NAME}] Shutting down...")

    def get_routers(self) -> list[tuple[APIRouter, str]]:
        return [
            (analysis.router, ""),
        ]

    def get_frontend_dir(self) -> str | None:
        frontend_dist = Path(__file__).parent / "frontend"
        if frontend_dist.exists():
            return str(frontend_dist)
        frontend_dist = Path(__file__).parent.parent.parent / "frontend" / "dist"
        if frontend_dist.exists():
            return str(frontend_dist)
        return None

    def get_frontend_config(self) -> dict[str, Any]:
        config = super().get_frontend_config()
        config["plugin_name"] = PLUGIN_NAME
        return config

    async def check_health(self) -> PluginHealth:
        return PluginHealth(
            status=HealthStatus.HEALTHY,
            message="Plugin is running normally",
            details={
                "mode": "standalone" if self.is_standalone else "integrated",
                "version": PLUGIN_VERSION,
                "template": PLUGIN_TEMPLATE,
            },
        )


def create_standalone_app():
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.staticfiles import StaticFiles

    plugin = __CLASS_NAME__()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Auto-detect subprocess isolation mode (MINT_PLATFORM_URL env var)
        from mint_sdk.remote_context import create_context_for_environment
        context = create_context_for_environment()
        await plugin.initialize(context=context)
        yield
        await plugin.shutdown()

    app = FastAPI(
        title=f"{PLUGIN_NAME} (Standalone)",
        version=PLUGIN_VERSION,
        description=PLUGIN_DESCRIPTION,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    for router, prefix in plugin.get_routers():
        app.include_router(router, prefix=f"/api{PLUGIN_ROUTES_PREFIX}{prefix}")

    frontend_dir = plugin.get_frontend_dir()
    if frontend_dir:

        class SPAStaticFiles(StaticFiles):
            async def get_response(self, path: str, scope):
                try:
                    return await super().get_response(path, scope)
                except Exception:
                    return await super().get_response("index.html", scope)

        app.mount(
            PLUGIN_FRONTEND_ROUTE,
            SPAStaticFiles(directory=frontend_dir, html=True),
            name="frontend",
        )

    return app


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "__MODULE_NAME__.plugin:create_standalone_app",
        factory=True,
        host="0.0.0.0",
        port=8003,
        reload=True,
    )
"""

ROUTERS_INIT_PY = """\
"""

ROUTERS_ANALYSIS_PY = """\
from fastapi import APIRouter

from __MODULE_NAME__.schemas.requests import AnalyzeRequest
from __MODULE_NAME__.schemas.responses import AnalyzeResponse
from __MODULE_NAME__.services import analysis_service

router = APIRouter(tags=["analysis"])


@router.get("/health")
async def health():
    return {"status": "healthy", "plugin": "__SLUG__"}


@router.post("/analyze/{experiment_id}", response_model=AnalyzeResponse)
async def analyze(experiment_id: int, request: AnalyzeRequest) -> AnalyzeResponse:
    service = analysis_service.get_analysis_service()
    return await service.analyze(experiment_id, request)
"""

SCHEMAS_INIT_PY = """\
"""

SCHEMAS_REQUESTS_PY = """\
from pydantic import BaseModel, Field


class AnalyzeRequest(BaseModel):
    parameters: dict[str, str] = Field(default_factory=dict)
"""

SCHEMAS_RESPONSES_PY = """\
from pydantic import BaseModel


class AnalyzeResponse(BaseModel):
    experiment_id: int
    status: str
    template: str
    hint: str
"""

SERVICES_INIT_PY = """\
"""

SERVICES_ANALYSIS_PY = """\
from __MODULE_NAME__.schemas.requests import AnalyzeRequest
from __MODULE_NAME__.schemas.responses import AnalyzeResponse

_instance: "AnalysisService | None" = None


class AnalysisService:

    async def analyze(self, experiment_id: int, request: AnalyzeRequest) -> AnalyzeResponse:
        # TODO: implement your analysis logic here
        return AnalyzeResponse(
            experiment_id=experiment_id,
            status="not_implemented",
            template="__PLUGIN_TEMPLATE__",
            hint="__PLUGIN_TEMPLATE_NEXT_STEP__",
        )


def get_analysis_service() -> AnalysisService:
    global _instance
    if _instance is None:
        _instance = AnalysisService()
    return _instance
"""

TEST_PLUGIN_PY = """\
from fastapi import FastAPI
from fastapi.testclient import TestClient

from __MODULE_NAME__.plugin import __CLASS_NAME__, create_standalone_app


def _create_test_client() -> TestClient:
    __CLASS_NAME__._instance = None
    return TestClient(create_standalone_app())


class TestPluginMetadata:

    def test_metadata_name(self):
        __CLASS_NAME__._instance = None
        plugin = __CLASS_NAME__()
        assert plugin.metadata.name == "__SLUG__"

    def test_metadata_routes_prefix(self):
        __CLASS_NAME__._instance = None
        plugin = __CLASS_NAME__()
        assert plugin.metadata.routes_prefix == "__ROUTES_PREFIX__"


class TestStandaloneApp:

    def test_create_standalone_app_returns_fastapi(self):
        __CLASS_NAME__._instance = None
        app = create_standalone_app()
        assert isinstance(app, FastAPI)


class TestRoutes:

    def test_health_route(self):
        with _create_test_client() as client:
            response = client.get("/api__ROUTES_PREFIX__/health")

        assert response.status_code == 200
        assert response.json() == {"status": "healthy", "plugin": "__SLUG__"}

    def test_analyze_route(self):
        payload = {"parameters": {"threshold": "0.5"}}

        with _create_test_client() as client:
            response = client.post("/api__ROUTES_PREFIX__/analyze/42", json=payload)

        assert response.status_code == 200
        body = response.json()
        assert body["experiment_id"] == 42
        assert body["status"] == "not_implemented"
        assert body["template"] == "__PLUGIN_TEMPLATE__"

    def test_analyze_route_rejects_invalid_payload(self):
        payload = {"parameters": {"threshold": 0.5}}

        with _create_test_client() as client:
            response = client.post("/api__ROUTES_PREFIX__/analyze/42", json=payload)

        assert response.status_code == 422
"""

# ---------------------------------------------------------------------------
# Config / meta files
# ---------------------------------------------------------------------------

README_MD = """\
# __PLUGIN_NAME__

__DESCRIPTION__

Template: **__PLUGIN_TEMPLATE_LABEL__** - __PLUGIN_TEMPLATE_DESCRIPTION__

Next step: __PLUGIN_TEMPLATE_NEXT_STEP__

## Development

```bash
# Install dependencies
uv sync

# Run backend dev server
uv run uvicorn __MODULE_NAME__.plugin:create_standalone_app --factory --reload --port 8003

# Run tests
uv run pytest -v
```

__FRONTEND_README_SECTION__

### Build

```bash
# Run tests, then build .mint bundle for distribution
mint build .

# Or use the build script
bash scripts/build.sh
```
"""

CHANGELOG_MD = """\
# Changelog

## 0.1.0

- Initial release
"""

GITIGNORE = """\
__pycache__/
*.py[cod]
*$py.class
*.egg-info/
dist/
build/
.eggs/
*.egg
.venv/
venv/
*.mint
uv.lock

# Frontend
frontend/node_modules/
frontend/dist/
frontend/bun.lock
frontend/bun.lockb

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
"""

# ---------------------------------------------------------------------------
# Scripts
# ---------------------------------------------------------------------------

SCRIPT_DEV_SH = """\
#!/usr/bin/env bash
set -e

# Start backend and frontend dev servers concurrently
echo "Starting __PLUGIN_NAME__ development servers..."

# Backend
uv run uvicorn __MODULE_NAME__.plugin:create_standalone_app \\
    --factory --reload --port 8003 &
BACKEND_PID=$!

# Frontend
if [ -d "frontend" ]; then
    cd frontend
    bun run dev &
    FRONTEND_PID=$!
    cd ..
fi

cleanup() {
    kill $BACKEND_PID 2>/dev/null || true
    [ -n "$FRONTEND_PID" ] && kill $FRONTEND_PID 2>/dev/null || true
}
trap cleanup EXIT

wait
"""

SCRIPT_BUILD_SH = """\
#!/usr/bin/env bash
set -e
echo "Building __PACKAGE_NAME__..."
mint build .
echo "Done! Check dist/ for the .mint bundle."
"""

SCRIPT_RELEASE_SH = """\
#!/usr/bin/env bash
set -e

# Version is derived from git tags via hatch-vcs.
# This script creates a new tag and pushes it.
# The release workflow triggers on v* tags.

BUMP_TYPE="${1:-patch}"
CURRENT=$(git describe --tags --match 'v*' --abbrev=0 2>/dev/null | sed 's/^v//')

if [[ -z "$CURRENT" ]]; then
    CURRENT="0.0.0"
    echo "No existing tags found, starting from $CURRENT"
fi

MAJOR=$(echo "$CURRENT" | cut -d. -f1)
MINOR=$(echo "$CURRENT" | cut -d. -f2)
PATCH=$(echo "$CURRENT" | cut -d. -f3 | cut -d- -f1)

case "$BUMP_TYPE" in
    major) NEW_VERSION="$((MAJOR + 1)).0.0" ;;
    minor) NEW_VERSION="$MAJOR.$((MINOR + 1)).0" ;;
    patch) NEW_VERSION="$MAJOR.$MINOR.$((PATCH + 1))" ;;
    *) echo "Usage: $0 [patch|minor|major]"; exit 1 ;;
esac

echo "Releasing: $CURRENT -> $NEW_VERSION"

git tag "v$NEW_VERSION"
git push origin HEAD --tags

echo "Tagged v$NEW_VERSION — release workflow will build and publish."
"""

# ---------------------------------------------------------------------------
# CI workflows
# ---------------------------------------------------------------------------

CI_YML = """\
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install uv
        uses: astral-sh/setup-uv@v5

      - name: Set up Python
        run: uv python install 3.12

      - name: Install dependencies
        run: uv sync

      - name: Lint
        run: uv run ruff check .

      - name: Test
        run: uv run pytest -v

      - name: Check for frontend
        id: frontend
        run: |
          if [[ -f frontend/package.json ]]; then
            echo "HAS_FRONTEND=true" >> $GITHUB_OUTPUT
          else
            echo "HAS_FRONTEND=false" >> $GITHUB_OUTPUT
          fi

      - name: Verify generated frontend contract
        if: steps.frontend.outputs.HAS_FRONTEND == 'true'
        run: uv run mint sdk generate --check

      - name: Setup Bun
        if: steps.frontend.outputs.HAS_FRONTEND == 'true'
        uses: oven-sh/setup-bun@v2

      - name: Frontend install and typecheck
        if: steps.frontend.outputs.HAS_FRONTEND == 'true'
        run: |
          cd frontend
          bun install
          bun run type-check
"""

RELEASE_YML = """\
name: Release

on:
  push:
    tags: ['v*']

permissions:
  contents: write

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install uv
        uses: astral-sh/setup-uv@v5

      - name: Set up Python
        run: uv python install 3.12

      - name: Install dependencies
        run: uv sync

      - name: Lint
        run: uv run ruff check .

      - name: Test
        run: uv run pytest -v

  build:
    runs-on: ubuntu-latest
    needs: [test]
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Install uv
        uses: astral-sh/setup-uv@v5

      - name: Set up Python
        run: uv python install 3.12

      - name: Install dependencies
        run: uv sync

      - name: Check for frontend
        id: frontend
        run: |
          if [[ -f frontend/package.json ]]; then
            echo "HAS_FRONTEND=true" >> $GITHUB_OUTPUT
          else
            echo "HAS_FRONTEND=false" >> $GITHUB_OUTPUT
          fi

      - name: Setup Bun
        if: steps.frontend.outputs.HAS_FRONTEND == 'true'
        uses: oven-sh/setup-bun@v2

      - name: Build .mint bundle
        run: uv run mint build . --output-dir dist/

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          files: dist/*.mint
          generate_release_notes: true
"""

# ---------------------------------------------------------------------------
# Frontend templates
# ---------------------------------------------------------------------------

FRONTEND_PACKAGE_JSON = """\
{
  "name": "__PACKAGE_NAME__-frontend",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vue-tsc -b && vite build",
    "preview": "vite preview",
    "type-check": "vue-tsc --noEmit",
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "dependencies": {
    "@morscherlab/mint-sdk": "^__FRONTEND_SDK_VERSION__",
    "pinia": "^2.1.7",
    "vue": "^3.4.0",
    "vue-router": "^4.2.0"
  },
  "devDependencies": {
    "@tailwindcss/postcss": "^4.1.0",
    "@types/node": "^25.1.0",
    "@vitejs/plugin-vue": "^6.0.0",
    "@vue/test-utils": "^2.4.6",
    "jsdom": "^28.1.0",
    "postcss": "^8.4.32",
    "tailwindcss": "^4.1.0",
    "typescript": "^5.3.0",
    "vite": "^8.0.0",
    "vitest": "^4.0.18",
    "vue-tsc": "^2.0.0"
  }
}
"""

FRONTEND_VITE_CONFIG_TS = """\
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
      // CRITICAL: Dedupe Vue/Pinia to avoid multiple instances when SDK is bundled
      'vue': resolve(__dirname, 'node_modules/vue'),
      'pinia': resolve(__dirname, 'node_modules/pinia'),
    },
    dedupe: ['vue', 'pinia', 'vue-router'],
  },
  optimizeDeps: {
    include: ['vue', 'vue-router', 'pinia'],
  },
  server: {
    port: 5175,
    proxy: {
      '/api': {
        target: 'http://localhost:8003',
        changeOrigin: true,
      },
    },
  },
  base: '__ROUTES_PREFIX__/',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
})
"""

FRONTEND_TSCONFIG_JSON = """\
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "module": "ESNext",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "preserve",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src/**/*.ts", "src/**/*.tsx", "src/**/*.vue"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
"""

FRONTEND_TSCONFIG_NODE_JSON = """\
{
  "compilerOptions": {
    "composite": true,
    "tsBuildInfoFile": "./tsconfig.node.tsbuildinfo",
    "target": "ES2022",
    "lib": ["ES2023"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true,
    "strict": true
  },
  "include": ["vite.config.ts"]
}
"""

FRONTEND_INDEX_HTML = """\
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>__PLUGIN_NAME__</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
"""

FRONTEND_POSTCSS_CONFIG_JS = """\
export default {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
"""

FRONTEND_MAIN_TS = """\
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { createRouter, createWebHistory } from 'vue-router'
import { MINTSdk } from '@morscherlab/mint-sdk'

import './style.css'

import App from './App.vue'

const routes = [
  {
    path: '/',
    name: 'dashboard',
    component: () => import('./views/DashboardView.vue'),
  },
  {
    path: '/analysis',
    name: 'analysis',
    component: () => import('./views/AnalysisView.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

const app = createApp(App)
const pinia = createPinia()

// MINTSdk must be installed before pinia/router so toast, theme, and platform
// context composables can register their stores.
app.use(MINTSdk)
app.use(pinia)
app.use(router)

app.mount('#app')
"""

FRONTEND_STYLE_CSS = """\
@import "tailwindcss";
@import "@morscherlab/mint-sdk/styles" layer(mint-sdk);
"""

FRONTEND_VITEST_CONFIG_TS = """\
import { defineConfig } from 'vitest/config'
import vue from '@vitejs/plugin-vue'
import { resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [vue()],
  test: {
    environment: 'jsdom',
    globals: true,
  },
  resolve: {
    alias: { '@': resolve(__dirname, 'src') },
  },
})
"""

FRONTEND_ENV_D_TS = """\
/// <reference types="vite/client" />

declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<{}, {}, any>
  export default component
}
"""

FRONTEND_APP_VUE = """\
<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import {
  AppContainer,
  PluginWorkspaceView,
} from '@morscherlab/mint-sdk'
import { pluginPageSelectorItems } from './generated/mint-plugin'

const route = useRoute()

function normalizeNavPath(path: string): string {
  const raw = path.trim() || '/'
  const prefixed = raw.startsWith('/') ? raw : `/${raw}`
  return prefixed.replace(/\\/+$/, '') || '/'
}

function pageId(path: string): string {
  const normalized = normalizeNavPath(path)
  return normalized === '/' ? 'dashboard' : normalized.replace(/^\\/+/, '').replace(/\\/+/g, '-') || 'dashboard'
}

const pageSelector = pluginPageSelectorItems

const currentPageSelectorId = computed(() => {
  const path = normalizeNavPath(route.path)
  return pageSelector.find(p => p.to === path)?.id ?? pageSelector[0]?.id ?? pageId(path)
})

const currentPageTitle = computed(() => {
  return pageSelector.find(p => p.id === currentPageSelectorId.value)?.label ?? 'Dashboard'
})
</script>

<template>
  <PluginWorkspaceView
    title="__PLUGIN_NAME__"
    :subtitle="currentPageTitle"
    :page-selector="pageSelector"
    :current-page-selector-id="currentPageSelectorId"
    show-theme-toggle
    show-settings
    :show-sidebar="false"
  >
    <AppContainer scrollable>
      <router-view />
    </AppContainer>
  </PluginWorkspaceView>
</template>
"""

FRONTEND_DASHBOARD_VIEW_VUE = """\
<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { AlertBox, Skeleton, useRequestSyncState } from '@morscherlab/mint-sdk'
import {
  useGeneratedPluginContract,
  useGeneratedPluginClient,
} from '../generated/mint-plugin'

const pluginClient = useGeneratedPluginClient()
const pluginContract = useGeneratedPluginContract()
const request = useRequestSyncState('Failed to fetch health status')

const healthStatus = ref<{ status: string; plugin: string } | null>(null)
const loading = computed(() => request.loading.value)
const error = computed(() => request.error.value)
const contractHashShort = computed(() => pluginContract.contractHash.slice(0, 19))
const healthEndpoint = pluginContract.endpointDefinitions.health

onMounted(async () => {
  await request.run(async () => {
    const response = await pluginClient.health()
    healthStatus.value = response as { status: string; plugin: string }
    return response
  }).catch(() => undefined)
})
</script>

<template>
  <div class="flex flex-col gap-3">
    <p class="m-0 text-sm text-[var(--text-muted)]">
      Your plugin dashboard. Start building here.
    </p>

    <div v-if="loading">
      <Skeleton variant="rounded" height="48px" />
    </div>
    <AlertBox v-else-if="error" type="error">
      {{ error }}
    </AlertBox>
    <AlertBox
      v-else
      :type="healthStatus?.status === 'healthy' ? 'success' : 'error'"
    >
      {{ healthStatus?.status === 'healthy' ? 'All systems operational' : 'Health check failed' }}
    </AlertBox>

    <p class="m-0 font-mono text-xs text-[var(--text-muted)]">
      contract {{ contractHashShort }} · {{ healthEndpoint.method.toUpperCase() }}
      {{ healthEndpoint.path }} · endpoints {{ pluginContract.endpoints.length }}
    </p>
  </div>
</template>
"""

FRONTEND_ANALYSIS_VIEW_VUE = """\
<script setup lang="ts">
import { EmptyState } from '@morscherlab/mint-sdk'
</script>

<template>
  <div class="flex flex-col gap-3">
    <p class="m-0 text-sm text-[var(--text-muted)]">
      __PLUGIN_TEMPLATE_FRONTEND_HINT__
    </p>

    <EmptyState
      title="No Analysis Configured"
      description="Replace this placeholder with your analysis UI."
      icon-path="M4 19h16M7 16V8m5 8V4m5 12v-6"
      size="sm"
    />
  </div>
</template>
"""
