"""Shared LCMS sequence models and Xcalibur CSV helpers."""

from __future__ import annotations

import csv
import io
import re
from enum import StrEnum
from pathlib import PurePosixPath, PureWindowsPath
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class LcmsPolarity(StrEnum):
    POS = "POS"
    NEG = "NEG"
    BOTH = "BOTH"


class LcmsContainerType(StrEnum):
    VIAL = "VIAL"
    PLATE = "PLATE"


class LcmsPlateType(StrEnum):
    WELL_96 = "96well"
    VIAL_54 = "54vial"


class LcmsPlateCell(BaseModel):
    """Single LCMS plate/vial cell used for sequence generation."""

    model_config = ConfigDict(extra="forbid")

    row: str
    column: int
    sample_name: str
    sample_type: str | None = None
    injection_volume: float | None = None
    injection_count: int | None = None
    custom_method: str | None = None
    slot: str | None = None


class LcmsSequenceItem(BaseModel):
    """Single Xcalibur-compatible sequence row."""

    model_config = ConfigDict(extra="forbid")

    sample_type: str
    file_name: str
    sample_id: str
    path: str = ""
    instrument_method: str
    position: str
    injection_volume: float


class LcmsSequenceParams(BaseModel):
    """Common LCMS sequence generation parameters."""

    model_config = ConfigDict(extra="forbid")

    prefix: str
    polarity: LcmsPolarity = LcmsPolarity.NEG
    plate_slot: str = "R"
    container_type: LcmsContainerType = LcmsContainerType.VIAL
    injection_volume: float = Field(default=5.0, ge=0.01, le=100.0)
    blank_position: str = "R:F9"
    blank_interval: int = Field(default=8, ge=1, le=50)
    blank_in_vial: bool = True
    external_qc_position: str = "R:F8"
    internal_qc_position: str | None = None
    internal_qc_interval: int = Field(default=50, ge=1, le=100)
    method_id: int | None = None
    custom_pos_method: str | None = None
    custom_neg_method: str | None = None
    save_path: str = r"D:\01_MS_data\MorscherLab"
    randomize: bool = False
    eqc_enabled: bool = True
    show_injection_number: bool = True


class LcmsMethodPathEntry(BaseModel):
    """A method path entry optionally tagged by polarity and container."""

    model_config = ConfigDict(extra="forbid")

    path: str = Field(..., min_length=1)
    polarity_tag: Literal["POS", "NEG"] | None = None
    container_tag: Literal["VIAL", "PLATE"] | None = None

    @model_validator(mode="after")
    def validate_placeholders(self) -> LcmsMethodPathEntry:
        has_polarity = "$POLARITY" in self.path
        has_container = "$CONTAINER" in self.path

        if self.polarity_tag and has_polarity:
            raise ValueError("Path must not contain $POLARITY when a polarity tag is set")
        if not self.polarity_tag and not has_polarity:
            raise ValueError("Path must contain $POLARITY when no polarity tag is set")
        if self.container_tag and has_container:
            raise ValueError("Path must not contain $CONTAINER when a container tag is set")
        if not self.container_tag and not has_container:
            raise ValueError("Path must contain $CONTAINER when no container tag is set")
        return self


def resolve_lcms_method_path(
    paths: list[dict] | list[LcmsMethodPathEntry],
    polarity: str,
    container: str,
    *,
    base_path: str | None = None,
) -> str:
    """Resolve the best method path for a polarity/container pair.

    Match priority is exact > polarity-only > container-only > untagged.
    Relative paths are joined to ``base_path`` when provided.
    """

    exact = polarity_only = container_only = untagged = None
    normalized = [
        entry if isinstance(entry, LcmsMethodPathEntry) else LcmsMethodPathEntry.model_validate(entry)
        for entry in paths
    ]

    for entry in normalized:
        if entry.polarity_tag == polarity and entry.container_tag == container:
            exact = entry
        elif entry.polarity_tag == polarity and entry.container_tag is None:
            polarity_only = entry
        elif entry.polarity_tag is None and entry.container_tag == container:
            container_only = entry
        elif entry.polarity_tag is None and entry.container_tag is None:
            untagged = entry

    if exact:
        resolved = exact.path
    elif polarity_only:
        resolved = polarity_only.path.replace("$CONTAINER", container)
    elif container_only:
        resolved = container_only.path.replace("$POLARITY", polarity)
    elif untagged:
        resolved = untagged.path.replace("$POLARITY", polarity).replace("$CONTAINER", container)
    else:
        raise ValueError(f"No path entry matches polarity={polarity}, container={container}")

    if "$POLARITY" in resolved or "$CONTAINER" in resolved:
        raise ValueError(f"Resolved path still contains unresolved placeholders: {resolved}")

    if base_path and not _is_absolute_path(resolved):
        return str(PureWindowsPath(base_path) / resolved)
    return resolved


def lcms_well_id_from_position(position: str) -> str:
    """Return the well id from a position such as ``R:A1``."""

    return position.rsplit(":", 1)[-1]


def infer_lcms_plate_type_from_positions(positions: list[str]) -> LcmsPlateType | None:
    """Infer 54-vial vs 96-well geometry from well positions."""

    max_col = 0
    max_row = 0
    for position in positions:
        well = lcms_well_id_from_position(position)
        match = re.match(r"^([A-Z])(\d+)$", well, re.IGNORECASE)
        if not match:
            continue
        max_row = max(max_row, ord(match.group(1).upper()) - ord("A") + 1)
        max_col = max(max_col, int(match.group(2)))

    if max_col == 0 and max_row == 0:
        return None
    return LcmsPlateType.VIAL_54 if max_col <= 9 and max_row <= 6 else LcmsPlateType.WELL_96


def extract_lcms_common_prefix(file_names: list[str]) -> str:
    """Extract the common sequence prefix from Xcalibur file names."""

    if not file_names:
        return ""

    prefixes: list[str] = []
    for file_name in file_names:
        cleaned = re.sub(r"_\d{3}$", "", file_name)
        match = re.match(r"^(.+?)_(POS|NEG)_.*$", cleaned, re.IGNORECASE)
        if match:
            prefixes.append(match.group(1))
        else:
            parts = cleaned.rsplit("_", 1)
            prefixes.append(parts[0] if len(parts) > 1 else cleaned)

    common = prefixes[0] if prefixes else ""
    for prefix in prefixes[1:]:
        while common and not prefix.startswith(common):
            index = common.rfind("_")
            common = common[:index] if index > 0 else common[:-1]
    return common


def extract_lcms_sample_name(file_name: str, prefix: str = "") -> str:
    """Extract a human-readable sample name from an Xcalibur file name."""

    name = re.sub(r"_\d{3}$", "", file_name)
    if prefix and name.startswith(prefix):
        name = name[len(prefix) :].lstrip("_")
    name = re.sub(r"^(POS|NEG)_", "", name, flags=re.IGNORECASE)
    return name or file_name


def plate_cells_to_lcms_sequence_items(
    cells: list[LcmsPlateCell],
    *,
    method_path: str,
    prefix: str,
    polarity: str,
    plate_slot: str,
    injection_volume: float,
    show_injection_number: bool = True,
) -> list[LcmsSequenceItem]:
    """Convert plate cells to sample sequence items, excluding control cells."""

    items: list[LcmsSequenceItem] = []
    for cell in cells:
        if cell.sample_type in {"blank", "qc", "iqc"}:
            continue

        slot = cell.slot or plate_slot
        position = f"{slot}:{cell.row}{cell.column}"
        cell_volume = cell.injection_volume or injection_volume
        cell_method = cell.custom_method or method_path
        injection_count = cell.injection_count or 1

        for injection_index in range(injection_count):
            suffix = (
                f"_inj{injection_index + 1}"
                if injection_count > 1 and show_injection_number
                else ""
            )
            items.append(
                LcmsSequenceItem(
                    sample_type="Unknown",
                    file_name=f"{prefix}_{polarity}_{cell.sample_name}{suffix}",
                    sample_id=position,
                    instrument_method=cell_method,
                    position=position,
                    injection_volume=cell_volume,
                )
            )
    return items


def insert_lcms_item_at_intervals(
    items: list[LcmsSequenceItem],
    insert_item: LcmsSequenceItem,
    interval: int,
) -> list[LcmsSequenceItem]:
    """Insert a copy of ``insert_item`` before each chunk after the first."""

    result: list[LcmsSequenceItem] = []
    for index in range(0, len(items), interval):
        if index > 0:
            result.append(insert_item.model_copy())
        result.extend(items[index : index + interval])
    return result


def number_lcms_sequence_items(
    items: list[LcmsSequenceItem],
    *,
    save_path: str,
    prefix: str,
) -> list[LcmsSequenceItem]:
    """Set output path and trailing 3-digit sequence numbers."""

    safe_save_path = save_path.replace("/", "\\")
    safe_prefix = "".join(char for char in prefix if char.isalnum() or char in " _-.()")
    output_path = f"{safe_save_path}\\{safe_prefix}"
    numbered: list[LcmsSequenceItem] = []
    for index, item in enumerate(items, start=1):
        base_name = re.sub(r"_\d{3}$", "", item.file_name)
        numbered.append(item.model_copy(update={"path": output_path, "file_name": f"{base_name}_{index:03d}"}))
    return numbered


def lcms_sequence_items_to_csv(items: list[LcmsSequenceItem]) -> str:
    """Serialize sequence items to Xcalibur CSV content."""

    output = io.StringIO()
    output.write("Bracket Type=4\n")
    writer = csv.DictWriter(
        output,
        fieldnames=[
            "Sample Type",
            "File Name",
            "Sample ID",
            "Path",
            "Instrument Method",
            "Position",
            "Inj Vol",
        ],
    )
    writer.writeheader()
    for item in items:
        writer.writerow(
            {
                "Sample Type": item.sample_type,
                "File Name": item.file_name,
                "Sample ID": item.sample_id,
                "Path": item.path,
                "Instrument Method": item.instrument_method,
                "Position": item.position,
                "Inj Vol": item.injection_volume,
            }
        )
    return output.getvalue()


def parse_lcms_sequence_csv(csv_content: str) -> list[LcmsSequenceItem]:
    """Parse Xcalibur CSV content into sequence items."""

    lines = csv_content.strip().splitlines()
    if lines and lines[0].startswith("Bracket Type"):
        csv_content = "\n".join(lines[1:])

    reader = csv.DictReader(io.StringIO(csv_content))
    items: list[LcmsSequenceItem] = []
    for row in reader:
        raw_volume = (row.get("Inj Vol") or "").strip()
        items.append(
            LcmsSequenceItem(
                sample_type=row.get("Sample Type", ""),
                file_name=row.get("File Name", ""),
                sample_id=row.get("Sample ID", ""),
                path=row.get("Path", ""),
                instrument_method=row.get("Instrument Method", ""),
                position=row.get("Position", ""),
                injection_volume=float(raw_volume) if raw_volume else 0.0,
            )
        )
    return items


def combine_lcms_sequence_csvs(csv_contents: list[str]) -> tuple[list[LcmsSequenceItem], str]:
    """Combine multiple Xcalibur CSV files and renumber rows."""

    items: list[LcmsSequenceItem] = []
    for content in csv_contents:
        items.extend(parse_lcms_sequence_csv(content))
    reordered = reorder_lcms_sequence_numbers(items)
    return reordered, lcms_sequence_items_to_csv(reordered)


def reorder_lcms_sequence_numbers(items: list[LcmsSequenceItem]) -> list[LcmsSequenceItem]:
    """Renumber trailing Xcalibur row suffixes from 001..N."""

    reordered: list[LcmsSequenceItem] = []
    for index, item in enumerate(items, start=1):
        base_name = re.sub(r"_\d{3}$", "", item.file_name)
        reordered.append(item.model_copy(update={"file_name": f"{base_name}_{index:03d}"}))
    return reordered


def reconstruct_lcms_plate_cells_from_sequence_items(
    items: list[LcmsSequenceItem],
) -> tuple[list[LcmsPlateCell], LcmsPlateType] | None:
    """Rebuild plate cells from Unknown sequence rows."""

    unknown_items = [item for item in items if item.sample_type == "Unknown"]
    if not unknown_items:
        return None

    prefix = extract_lcms_common_prefix([item.file_name for item in unknown_items])
    seen: set[str] = set()
    cells: list[LcmsPlateCell] = []

    for item in unknown_items:
        well_id = lcms_well_id_from_position(item.position)
        if well_id in seen:
            continue
        seen.add(well_id)
        match = re.match(r"^([A-Z])(\d+)$", well_id, re.IGNORECASE)
        if not match:
            continue
        cells.append(
            LcmsPlateCell(
                row=match.group(1).upper(),
                column=int(match.group(2)),
                sample_name=extract_lcms_sample_name(item.file_name, prefix),
            )
        )

    if not cells:
        return None

    plate_type = infer_lcms_plate_type_from_positions([f"{cell.row}{cell.column}" for cell in cells])
    if plate_type is None:
        return None
    return cells, plate_type


def _is_absolute_path(value: str) -> bool:
    return bool(re.match(r"^[A-Za-z]:\\", value)) or PurePosixPath(value).is_absolute()
