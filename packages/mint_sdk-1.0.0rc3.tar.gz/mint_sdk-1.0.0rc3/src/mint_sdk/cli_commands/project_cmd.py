"""CLI commands for MINT project management.

Provides: mint project list, get, create, update, delete, experiments, members
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Optional

import typer

from mint_sdk.cli_commands._utils import get_client, print_json
from mint_sdk.info_command import _supports_color


class ProjectStatus(StrEnum):
    active = "active"
    archived = "archived"
    completed = "completed"


project_app = typer.Typer(help="Manage projects", no_args_is_help=True)

_PROJECT_STATUS_COLORS = {"active": "32", "archived": "2", "completed": "34"}  # green, dim, blue


def _project_status_str(status: str, color: bool) -> str:
    code = _PROJECT_STATUS_COLORS.get(status, "0")
    return f"\033[{code}m{status}\033[0m" if color else status


@project_app.command(name="list")
def list_projects(
    search: Annotated[Optional[str], typer.Option("--search", help="Search by name")] = None,
    status: Annotated[Optional[ProjectStatus], typer.Option("--status", help="Filter by status")] = None,
    mine: Annotated[bool, typer.Option("--mine", help="Show only my projects")] = False,
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 100,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List projects."""
    client = get_client()
    projects = client.projects.list(
        search=search,
        status=status,
        my_projects=mine,
        limit=limit,
    )
    if json_output:
        print_json(projects)
    else:
        if not projects:
            print("No projects found.")
        else:
            c = _supports_color()
            bold = "\033[1m" if c else ""
            dim = "\033[2m" if c else ""
            r = "\033[0m" if c else ""

            print(f"{bold}{'ID':<6} {'Name':<30} {'Status':<12} {'Experiments':<12}{r}")
            print(f"{dim}{'-' * 62}{r}")
            for p in projects:
                st = _project_status_str(str(p.get("status", "")), c)
                print(
                    f"{p.get('id', ''):<6} "
                    f"{str(p.get('name', ''))[:28]:<30} "
                    f"{st:<{12 if not c else 21}} "
                    f"{dim}{p.get('experiment_count', 0)}{r}"
                )
            print(f"\n{dim}{len(projects)} project(s){r}")
    client.close()


@project_app.command()
def create(
    name: Annotated[str, typer.Argument(help="Project name")],
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="Project description")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Create a new project."""
    client = get_client()
    proj = client.projects.create(name=name, description=description)
    if json_output:
        print_json(proj)
    else:
        print(f"Created project #{proj.get('id')}: {proj.get('name')}")
    client.close()


@project_app.command()
def update(
    id: Annotated[int, typer.Argument(help="Project ID")],
    name: Annotated[Optional[str], typer.Option("--name", help="New project name")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="New description")] = None,
    status: Annotated[Optional[ProjectStatus], typer.Option("--status", help="New status")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Update project metadata."""
    fields = {
        key: value
        for key, value in {
            "name": name,
            "description": description,
            "status": status,
        }.items()
        if value is not None
    }
    if not fields:
        typer.echo("Error: provide at least one field to update.", err=True)
        raise typer.Exit(1)

    client = get_client()
    proj = client.projects.update(id, **fields)
    if json_output:
        print_json(proj)
    else:
        print(f"Updated project #{proj.get('id', id)}")
    client.close()


@project_app.command()
def delete(
    id: Annotated[int, typer.Argument(help="Project ID")],
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete a project."""
    if not yes:
        typer.confirm(f"Delete project #{id}?", abort=True)

    client = get_client()
    client.projects.delete(id)
    print(f"Deleted project #{id}")
    client.close()


@project_app.command()
def experiments(
    id: Annotated[int, typer.Argument(help="Project ID")],
    limit: Annotated[int, typer.Option("--limit", help="Max results")] = 100,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List experiments in a project."""
    client = get_client()
    experiments = client.projects.experiments(id, limit=limit)
    if json_output:
        print_json(experiments)
    elif not experiments:
        print("No experiments found.")
    else:
        c = _supports_color()
        bold = "\033[1m" if c else ""
        dim = "\033[2m" if c else ""
        r = "\033[0m" if c else ""
        print(f"{bold}{'ID':<6} {'Name':<30} {'Type':<15} {'Status':<12}{r}")
        print(f"{dim}{'-' * 66}{r}")
        for exp in experiments:
            st = _project_status_str(str(exp.get("status", "")), c)
            print(
                f"{exp.get('id', ''):<6} "
                f"{str(exp.get('name', ''))[:28]:<30} "
                f"{dim}{str(exp.get('experiment_type', ''))[:13]:<15}{r} "
                f"{st:<{12 if not c else 21}}"
            )
        print(f"\n{dim}{len(experiments)} experiment(s){r}")
    client.close()


@project_app.command()
def members(
    id: Annotated[int, typer.Argument(help="Project ID")],
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List project members."""
    client = get_client()
    members = client.projects.members(id)
    if json_output:
        print_json(members)
    elif not members:
        print("No members found.")
    else:
        c = _supports_color()
        bold = "\033[1m" if c else ""
        dim = "\033[2m" if c else ""
        r = "\033[0m" if c else ""
        print(f"{bold}{'User':<30} {'Role':<16} {'Status'}{r}")
        print(f"{dim}{'-' * 62}{r}")
        for member in members:
            user = member.get("user", member)
            username = user.get("username", user.get("email", member.get("username", "")))
            role = member.get("role", "")
            status = member.get("status", "")
            print(f"{str(username)[:28]:<30} {str(role)[:14]:<16} {dim}{status}{r}")
    client.close()


@project_app.command()
def get(
    id: Annotated[int, typer.Argument(help="Project ID")],
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Get project details."""
    client = get_client()
    proj = client.projects.get(id)
    if json_output:
        print_json(proj)
    else:
        c = _supports_color()
        bold = "\033[1m" if c else ""
        dim = "\033[2m" if c else ""
        r = "\033[0m" if c else ""

        st = _project_status_str(str(proj.get("status", "")), c)
        print(f"{bold}Project #{proj.get('id')}{r}")
        print(f"  {dim}Name:{r}        {proj.get('name')}")
        print(f"  {dim}Status:{r}      {st}")
        if proj.get("description"):
            print(f"  {dim}Desc:{r}        {proj.get('description')}")
        print(f"  {dim}Members:{r}     {proj.get('member_count', 0)}")
        print(f"  {dim}Experiments:{r} {proj.get('experiment_count', 0)}")
        print(f"  {dim}Created:{r}     {proj.get('created_at')}")
    client.close()
