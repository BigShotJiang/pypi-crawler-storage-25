"""Cross-SDK search with weighted scoring."""

from __future__ import annotations

from typing import Any


def search(
    query: str,
    python_data: dict[str, Any] | None,
    frontend_data: dict[str, Any] | None,
    *,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Search across both SDK manifests with weighted scoring.

    Scoring:
        - Name match: weight 3
        - Description match: weight 2
        - Prop/field/method name match: weight 1
    """
    q = query.lower()
    results: list[dict[str, Any]] = []

    for sdk_name, data in [("python", python_data), ("frontend", frontend_data)]:
        if data is None:
            continue
        for cat_name, cat_data in data.get("categories", {}).items():
            if not isinstance(cat_data, list):
                # CSS data is a dict of groups — search variable names
                if isinstance(cat_data, dict):
                    results.extend(_search_css(q, sdk_name, cat_name, cat_data))
                continue
            for item in cat_data:
                score, context = _score_item(q, item)
                if score > 0:
                    # Include description + source so an agent consuming
                    # `--json` can rank/triage results without N follow-up
                    # calls to `mint docs frontend <name>` per hit.
                    results.append({
                        "sdk": sdk_name,
                        "category": cat_name,
                        "group": item.get("group", ""),
                        "name": item.get("name", ""),
                        "kind": item.get("kind", ""),
                        "description": item.get("description", ""),
                        "source": item.get("source", ""),
                        "match_context": context,
                        "score": score,
                    })

    results.sort(key=lambda r: (-r["score"], r["name"]))
    return results[:limit]


def _score_item(query: str, item: dict[str, Any]) -> tuple[int, str]:
    """Score a single item against the query. Returns (score, match_context)."""
    score = 0
    context = ""

    name = item.get("name", "").lower()
    desc = item.get("description", "").lower()

    # Name match (weight 3)
    if _matches_query(query, name):
        score += 3
        context = item.get("name", "")

    # Description match (weight 2)
    if _matches_query(query, desc):
        score += 2
        if not context:
            context = item.get("description", "")[:60]

    # Prop/field/method/param name match (weight 1)
    for nested_key in ("props", "fields", "params", "abstract_methods", "concrete_methods", "methods", "members"):
        nested = item.get(nested_key, [])
        if isinstance(nested, list):
            for sub in nested:
                sub_name = sub.get("name", "").lower()
                if _matches_query(query, sub_name):
                    score += 1
                    if not context:
                        context = f"{nested_key}: {sub.get('name', '')}"
                    break  # Only count once per nested key

    # String-list metadata used by template catalogs.
    for list_key in ("aliases", "frontend_adapters", "components", "templates"):
        values = item.get(list_key, [])
        list_text = " ".join(str(value).lower() for value in values) if isinstance(values, list) else ""
        if list_text and _matches_query(query, list_text):
            score += 1
            if not context:
                context = f"{list_key}: {', '.join(str(value) for value in values[:3])}"

    # String metadata used by template catalogs.
    for string_key in ("template_id", "frontend_import", "add_command"):
        value = item.get(string_key)
        if isinstance(value, str) and _matches_query(query, value.lower()):
            score += 1
            if not context:
                context = f"{string_key}: {value[:60]}"

    # Emit name match (weight 1)
    for emit in item.get("emits", []):
        if _matches_query(query, emit.get("name", "").lower()):
            score += 1
            if not context:
                context = f"emit: {emit.get('name', '')}"
            break

    # Multi-token queries often span fields, for example a component name plus
    # a related SDK component mentioned in its description. Keep this as a
    # low-weight fallback so precise single-field matches still rank first.
    if score == 0 and _matches_query(query, _combined_item_text(item)):
        score += 1
        context = _combined_item_match_context(query, item)

    return score, context


def _matches_query(query: str, text: str) -> bool:
    """Return true for exact-substring matches or token-AND matches."""
    if query in text:
        return True
    tokens = [token for token in query.split() if token]
    return bool(tokens) and all(token in text for token in tokens)


def _combined_item_text(item: dict[str, Any]) -> str:
    """Build a broad searchable string for low-weight multi-field matches."""
    parts: list[str] = []
    for key in ("name", "kind", "group", "description", "source"):
        value = item.get(key)
        if isinstance(value, str):
            parts.append(value)

    for nested_key in ("props", "fields", "params", "abstract_methods", "concrete_methods", "methods", "members"):
        nested = item.get(nested_key, [])
        if isinstance(nested, list):
            for sub in nested:
                if isinstance(sub, dict):
                    for key in ("name", "type", "description"):
                        value = sub.get(key)
                        if isinstance(value, str):
                            parts.append(value)

    for list_key in ("aliases", "frontend_adapters", "components", "templates"):
        values = item.get(list_key, [])
        if isinstance(values, list):
            parts.extend(str(value) for value in values)

    for string_key in ("template_id", "frontend_import", "add_command"):
        value = item.get(string_key)
        if isinstance(value, str):
            parts.append(value)

    for emit in item.get("emits", []):
        if isinstance(emit, dict):
            value = emit.get("name")
            if isinstance(value, str):
                parts.append(value)

    return " ".join(part.lower() for part in parts)


def _combined_item_match_context(query: str, item: dict[str, Any]) -> str:
    """Return the most specific field that helped a broad multi-field match."""
    base_text = " ".join(
        str(item.get(key, "")).lower()
        for key in ("name", "kind", "group", "description", "source")
    )
    query_tokens = [token for token in query.split() if token]

    for nested_key in ("props", "fields", "params", "abstract_methods", "concrete_methods", "methods", "members"):
        nested = item.get(nested_key, [])
        if not isinstance(nested, list):
            continue
        for sub in nested:
            if not isinstance(sub, dict):
                continue
            sub_text = " ".join(
                str(sub.get(key, "")).lower()
                for key in ("name", "type", "description")
            )
            if not sub_text:
                continue
            if all(token in base_text or token in sub_text for token in query_tokens):
                name = sub.get("name", "")
                description = sub.get("description", "")
                return f"{nested_key}: {name} - {description}"[:180]

    return item.get("name", "") or item.get("description", "")[:60]


def _search_css(
    query: str,
    sdk_name: str,
    cat_name: str,
    css_data: dict[str, Any],
) -> list[dict[str, Any]]:
    """Search within CSS data (nested dict of groups)."""
    results: list[dict[str, Any]] = []
    for section_name, section_data in css_data.items():
        if isinstance(section_data, dict):
            # Grouped variables
            for group_name, variables in section_data.items():
                if isinstance(variables, list):
                    for var in variables:
                        var_name = var.get("name", "").lower()
                        if query in var_name:
                            results.append({
                                "sdk": sdk_name,
                                "category": f"css/{section_name}",
                                "group": group_name,
                                "name": var.get("name", ""),
                                "kind": "css-variable",
                                "match_context": var.get("value", ""),
                                "score": 3,
                            })
        elif isinstance(section_data, list):
            for item in section_data:
                if isinstance(item, dict):
                    item_name = item.get("name", "").lower()
                    if query in item_name:
                        results.append({
                            "sdk": sdk_name,
                            "category": f"css/{section_name}",
                            "group": "",
                            "name": item.get("name", ""),
                            "kind": "css-class",
                            "match_context": item.get("description", ""),
                            "score": 3,
                        })
    return results
