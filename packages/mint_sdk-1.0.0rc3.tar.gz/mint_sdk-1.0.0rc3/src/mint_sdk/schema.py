"""Schema conversion helpers shared by plugin settings and frontend forms."""

from __future__ import annotations

from enum import Enum
from types import UnionType
from typing import Any, Literal, Union, get_args, get_origin


def settings_model_to_form_fields(model: type) -> list[dict[str, Any]]:
    """Convert a Pydantic settings model into SDK FormBuilder field schemas.

    The returned shape matches the JSON-serializable subset of the frontend
    SDK's ``FormFieldSchema`` type. It is intentionally conservative: authors
    can still override labels, layout, or component-specific props in their
    plugin if needed, but common scalar settings render without hand-written
    frontend schema.
    """
    fields: list[dict[str, Any]] = []
    for name, field_info in model.model_fields.items():
        annotation = _unwrap_optional(field_info.annotation)
        field: dict[str, Any] = {
            "name": name,
            "label": field_info.title or name.replace("_", " ").title(),
            "type": _field_type(annotation),
        }

        if field_info.description:
            field["hint"] = field_info.description

        default = _field_default(field_info)
        if default is not _NoDefault:
            field["defaultValue"] = default

        validation = _validation(field_info)
        if validation:
            field["validation"] = validation

        options = _options(annotation)
        if options:
            field.setdefault("props", {})["options"] = options

        access = _access_metadata(field_info)
        field.update(access)

        fields.append(field)
    return fields


def settings_model_to_settings_schema(
    model: type,
    *,
    group_id: str = "settings",
    group_label: str = "Settings",
    description: str | None = None,
    columns: int = 1,
    access: dict[str, Any] | None = None,
    visible_for: str | list[str] | None = None,
    requires_admin: bool | None = None,
    permissions: list[str] | None = None,
    any_permissions: list[str] | None = None,
) -> dict[str, Any]:
    """Convert a Pydantic settings model into frontend ``SettingsModalSchema``."""
    group: dict[str, Any] = {
        "id": group_id,
        "label": group_label,
        "fields": settings_model_to_form_fields(model),
    }
    if description:
        group["description"] = description
    if columns in (1, 2, 3):
        group["columns"] = columns
    if access is not None:
        group["access"] = access
    if visible_for is not None:
        group["visibleFor"] = visible_for
    if requires_admin is not None:
        group["requiresAdmin"] = requires_admin
    if permissions is not None:
        group["permissions"] = permissions
    if any_permissions is not None:
        group["anyPermissions"] = any_permissions
    return {"groups": [group]}


class _NoDefaultType:
    pass


_NoDefault = _NoDefaultType()


def _unwrap_optional(annotation: Any) -> Any:
    origin = get_origin(annotation)
    if origin in (Union, UnionType):
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1:
            return args[0]
    return annotation


def _field_type(annotation: Any) -> str:
    origin = get_origin(annotation)
    if annotation is bool:
        return "toggle"
    if annotation in (int, float):
        return "number"
    if origin is Literal or _is_enum(annotation):
        return "select"
    if origin is list and get_args(annotation)[:1] == (str,):
        return "tags"
    return "text"


def _is_enum(annotation: Any) -> bool:
    return isinstance(annotation, type) and issubclass(annotation, Enum)


def _options(annotation: Any) -> list[dict[str, Any]]:
    origin = get_origin(annotation)
    if origin is Literal:
        return [{"label": str(value), "value": value} for value in get_args(annotation)]
    if _is_enum(annotation):
        return [{"label": str(member.value), "value": member.value} for member in annotation]
    return []


def _field_default(field_info: Any) -> Any:
    if field_info.is_required():
        return _NoDefault
    default = field_info.default
    if default is None:
        return None
    return default


def _validation(field_info: Any) -> dict[str, Any]:
    validation: dict[str, Any] = {}
    if field_info.is_required():
        validation["required"] = True

    for meta in field_info.metadata:
        if hasattr(meta, "ge") and meta.ge is not None:
            validation["min"] = meta.ge
        if hasattr(meta, "gt") and meta.gt is not None:
            validation["min"] = meta.gt
        if hasattr(meta, "le") and meta.le is not None:
            validation["max"] = meta.le
        if hasattr(meta, "lt") and meta.lt is not None:
            validation["max"] = meta.lt
        if hasattr(meta, "min_length") and meta.min_length is not None:
            validation["minLength"] = meta.min_length
        if hasattr(meta, "max_length") and meta.max_length is not None:
            validation["maxLength"] = meta.max_length
        if hasattr(meta, "pattern") and meta.pattern is not None:
            validation["pattern"] = meta.pattern

    return validation


def _access_metadata(field_info: Any) -> dict[str, Any]:
    extra = field_info.json_schema_extra or {}
    access: dict[str, Any] = {}
    for source_key, target_key in (
        ("access", "access"),
        ("visibleFor", "visibleFor"),
        ("visible_for", "visibleFor"),
        ("requiresAdmin", "requiresAdmin"),
        ("requires_admin", "requiresAdmin"),
        ("permissions", "permissions"),
        ("anyPermissions", "anyPermissions"),
        ("any_permissions", "anyPermissions"),
    ):
        if source_key in extra:
            access[target_key] = extra[source_key]
    return access
