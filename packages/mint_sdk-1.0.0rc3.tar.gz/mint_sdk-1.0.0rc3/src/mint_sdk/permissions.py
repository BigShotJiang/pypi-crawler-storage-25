"""Shared permission helpers for plugin backends.

The platform backend remains the source of truth for concrete permission
definitions. These helpers mirror the SDK frontend semantics so plugin authors
can evaluate role/permission-gated settings and routes consistently.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, Literal, TypedDict

ADMIN_ROLE = "admin"

ADMIN_PANEL_PERMISSIONS = (
    "users.view",
    "users.invite",
    "users.manage",
    "platform.configure",
    "platform.view_logs",
    "plugins.configure",
    "plugins.install",
)

AccessAudience = Literal["all", "admin", "user"]
AccessAudienceInput = AccessAudience | Iterable[AccessAudience]


class AccessPolicy(TypedDict, total=False):
    audience: AccessAudienceInput
    visibleFor: AccessAudienceInput
    requiresAuth: bool
    requiresAdmin: bool
    permissions: Iterable[str]
    anyPermissions: Iterable[str]
    plugin: str


def is_admin_role(role: str | None) -> bool:
    """Return whether a role slug represents the platform admin role."""

    return role == ADMIN_ROLE


def is_admin_user(user: Mapping[str, Any] | object | None) -> bool:
    """Return whether a user mapping/object represents a platform admin."""

    return is_admin_role(_value(user, "role")) or is_admin_role(_role_value(user, "slug"))


def get_user_permissions(user: Mapping[str, Any] | object | None) -> list[str]:
    """Return permissions from a user/role payload."""

    role_permissions = _role_value(user, "permissions")
    if isinstance(role_permissions, Iterable) and not isinstance(role_permissions, (str, bytes, dict)):
        return [str(permission) for permission in role_permissions]

    permissions = _value(user, "permissions")
    if isinstance(permissions, Iterable) and not isinstance(permissions, (str, bytes, dict)):
        return [str(permission) for permission in permissions]

    return []


def has_all_permissions(user: Mapping[str, Any] | object | None, permissions: Iterable[str] = ()) -> bool:
    """Return whether the user has every requested permission."""

    requested = tuple(permissions)
    if not requested:
        return True
    if is_admin_user(user):
        return True
    granted = set(get_user_permissions(user))
    return all(permission in granted for permission in requested)


def has_any_permission(user: Mapping[str, Any] | object | None, permissions: Iterable[str] = ()) -> bool:
    """Return whether the user has at least one requested permission."""

    requested = tuple(permissions)
    if not requested:
        return True
    if is_admin_user(user):
        return True
    granted = set(get_user_permissions(user))
    return any(permission in granted for permission in requested)


def can_access_admin(user: Mapping[str, Any] | object | None) -> bool:
    """Return whether the user can see platform admin surfaces."""

    return is_admin_user(user) or has_any_permission(user, ADMIN_PANEL_PERMISSIONS)


def can_access_plugin(user: Mapping[str, Any] | object | None, plugin_name: str | None) -> bool:
    """Return whether role plugin_access allows a plugin."""

    if not plugin_name:
        return True
    access = _role_value(user, "plugin_access")
    if access in (None, "all"):
        return True
    if isinstance(access, Iterable) and not isinstance(access, (str, bytes, dict)):
        return plugin_name in access
    return True


def get_access_audience(user: Mapping[str, Any] | object | None) -> Literal["admin", "user"]:
    """Return the SDK frontend audience bucket for the user."""

    return "admin" if is_admin_user(user) else "user"


def can_access_policy(
    user: Mapping[str, Any] | object | None,
    policy: AccessPolicy | Mapping[str, Any] | None,
    *,
    is_authenticated: bool | None = None,
) -> bool:
    """Evaluate a JSON-serializable access policy against a user payload."""

    if not policy:
        return True
    authenticated = user is not None if is_authenticated is None else is_authenticated
    if policy.get("requiresAuth") and not authenticated:
        return False
    if policy.get("requiresAdmin") and not is_admin_user(user):
        return False
    if not _audience_allows(policy.get("visibleFor", policy.get("audience")), user):
        return False
    if not has_all_permissions(user, policy.get("permissions", ())):
        return False
    if not has_any_permission(user, policy.get("anyPermissions", ())):
        return False
    return can_access_plugin(user, policy.get("plugin"))


def _audience_allows(audience: Any, user: Mapping[str, Any] | object | None) -> bool:
    if audience is None:
        return True
    allowed = (audience,) if isinstance(audience, str) else tuple(audience)
    if "all" in allowed:
        return True
    return get_access_audience(user) in allowed


def _role(user: Mapping[str, Any] | object | None) -> Any:
    return _value(user, "role_obj") or _value(user, "roleObj")


def _role_value(user: Mapping[str, Any] | object | None, key: str) -> Any:
    return _value(_role(user), key)


def _value(source: Mapping[str, Any] | object | None, key: str) -> Any:
    if source is None:
        return None
    if isinstance(source, Mapping):
        return source.get(key)
    return getattr(source, key, None)
