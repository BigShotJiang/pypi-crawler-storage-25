"""MigrationRunner — discovers, orders, validates, and executes plugin migrations."""

from __future__ import annotations

import hashlib
import importlib
import inspect
import logging
import pkgutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from mint_sdk.migrations.base import PluginMigration
from mint_sdk.migrations.errors import (
    MigrationChecksumError,
    MigrationError,
    SchemaVersionAheadError,
)
from mint_sdk.migrations.locking import advisory_lock
from mint_sdk.migrations.ops import MigrationOps

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncEngine

logger = logging.getLogger(__name__)

TRACKING_TABLE = "_plugin_migrations"

TRACKING_DDL_SQLITE = f"""
CREATE TABLE IF NOT EXISTS "{TRACKING_TABLE}" (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    plugin_name   TEXT NOT NULL,
    version       INTEGER NOT NULL,
    name          TEXT NOT NULL,
    applied_at    TEXT NOT NULL,
    checksum      TEXT,
    success       INTEGER NOT NULL DEFAULT 1,
    error_message TEXT,
    UNIQUE(plugin_name, version)
)
"""

TRACKING_DDL_POSTGRESQL = """
CREATE TABLE IF NOT EXISTS plugin_schema_migrations (
    id            SERIAL PRIMARY KEY,
    plugin_name   VARCHAR(255) NOT NULL,
    version       INTEGER NOT NULL,
    name          VARCHAR(255) NOT NULL,
    applied_at    TIMESTAMP NOT NULL,
    checksum      VARCHAR(64),
    success       BOOLEAN NOT NULL DEFAULT TRUE,
    error_message TEXT,
    UNIQUE(plugin_name, version)
)
"""


@dataclass
class MigrationResult:
    """Result of a migration run."""

    current_version: int = 0
    applied: list[int] = field(default_factory=list)
    stamped: list[int] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


class MigrationRunner:
    """Discovers, validates, and executes plugin migrations.

    Works with both PostgreSQL (platform integrated) and SQLite (standalone).
    """

    def __init__(
        self,
        engine: AsyncEngine,
        plugin_name: str,
        dialect: str,
    ) -> None:
        self._engine = engine
        self._plugin_name = plugin_name
        self._dialect = dialect
        self._tracking_table = (
            "plugin_schema_migrations" if dialect == "postgresql" else TRACKING_TABLE
        )

    # ── Public API ──────────────────────────────────────────────────

    async def run(
        self,
        migrations: list[PluginMigration],
        *,
        tables_already_exist: bool = False,
    ) -> MigrationResult:
        """Run all pending migrations for this plugin.

        Args:
            migrations: All migration instances for this plugin.
            tables_already_exist: If True and no history exists, stamp all as
                applied (fresh-install-stamp for existing tables from create_all).

        Returns:
            MigrationResult with applied/stamped versions.
        """
        async with advisory_lock(
            self._engine, self._plugin_name, dialect=self._dialect
        ) as conn:
            await self._ensure_tracking_table(conn)

            ordered = self._sort_migrations(migrations)
            if not ordered:
                return MigrationResult()

            applied_map = await self._get_applied(conn)
            plugin_max = max(m.version for m in ordered)
            db_version = max(applied_map.keys()) if applied_map else 0

            # Version guard
            if db_version > plugin_max:
                raise SchemaVersionAheadError(
                    self._plugin_name,
                    db_version=db_version,
                    plugin_max_version=plugin_max,
                )

            # Checksum validation for already-applied migrations
            for m in ordered:
                if m.version in applied_map:
                    record = applied_map[m.version]
                    if not record["success"]:
                        continue  # will retry
                    stored_checksum = record.get("checksum")
                    if stored_checksum:
                        actual = self._compute_checksum(type(m))
                        if actual != stored_checksum:
                            raise MigrationChecksumError(
                                self._plugin_name,
                                m.version,
                                stored_checksum,
                                actual,
                            )

            result = MigrationResult()

            # Fresh-install stamp
            if tables_already_exist and not applied_map:
                for m in ordered:
                    await self._stamp(conn, m)
                    result.stamped.append(m.version)
                result.current_version = plugin_max
                return result

            # Run pending migrations
            for m in ordered:
                if m.version in applied_map and applied_map[m.version]["success"]:
                    continue  # already applied successfully

                try:
                    ops = MigrationOps(
                        conn,
                        dialect=self._dialect,
                        destructive_allowed=m.destructive,
                    )
                    await m.upgrade(ops)
                    await self._record_success(conn, m)
                    result.applied.append(m.version)
                    logger.info(
                        "Applied migration v%03d_%s for plugin '%s'",
                        m.version,
                        m.name,
                        self._plugin_name,
                    )
                except Exception as exc:
                    error_msg = str(exc)
                    result.errors.append(f"v{m.version:03d}_{m.name}: {error_msg}")
                    logger.error(
                        "Migration v%03d_%s failed for plugin '%s': %s",
                        m.version,
                        m.name,
                        self._plugin_name,
                        error_msg,
                    )
                    raise MigrationError(
                        f"Migration v{m.version:03d}_{m.name} failed: {error_msg}"
                    ) from exc

            result.current_version = max(
                result.applied[-1] if result.applied else 0,
                db_version,
            )
            return result

    @staticmethod
    def discover(package_path: str) -> list[PluginMigration]:
        """Import a migrations package and return all PluginMigration instances."""
        package = importlib.import_module(package_path)
        migrations: list[PluginMigration] = []

        for _importer, modname, _ispkg in pkgutil.iter_modules(
            package.__path__, prefix=package.__name__ + "."
        ):
            module = importlib.import_module(modname)
            for _name, obj in inspect.getmembers(module, inspect.isclass):
                if (
                    issubclass(obj, PluginMigration)
                    and obj is not PluginMigration
                    and hasattr(obj, "version")
                    and isinstance(obj.version, int)
                ):
                    migrations.append(obj())

        return migrations

    # ── Internals ───────────────────────────────────────────────────

    def _sort_migrations(
        self, migrations: list[PluginMigration]
    ) -> list[PluginMigration]:
        return sorted(migrations, key=lambda m: m.version)

    @staticmethod
    def _compute_checksum(migration_cls: type) -> str:
        """SHA-256 of the migration class's source code."""
        try:
            source = inspect.getsource(migration_cls)
            return hashlib.sha256(source.encode()).hexdigest()
        except (TypeError, OSError):
            return hashlib.sha256(str(migration_cls).encode()).hexdigest()

    async def _ensure_tracking_table(self, conn: Any) -> None:
        from sqlalchemy import text

        ddl = (
            TRACKING_DDL_SQLITE
            if self._dialect == "sqlite"
            else TRACKING_DDL_POSTGRESQL
        )
        await conn.execute(text(ddl))

    async def _get_applied(self, conn: Any) -> dict[int, dict[str, Any]]:
        """Return {version: {success, checksum, ...}} for this plugin."""
        from sqlalchemy import text

        result = await conn.execute(
            text(
                f"SELECT version, name, checksum, success, error_message "
                f'FROM "{self._tracking_table}" '
                f"WHERE plugin_name = :pn ORDER BY version"
            ),
            {"pn": self._plugin_name},
        )
        return {
            row[0]: {
                "name": row[1],
                "checksum": row[2],
                "success": bool(row[3]),
                "error_message": row[4],
            }
            for row in result.fetchall()
        }

    async def _stamp(self, conn: Any, migration: PluginMigration) -> None:
        """Mark a migration as applied without executing it."""
        from sqlalchemy import text

        checksum = self._compute_checksum(type(migration))
        now = datetime.now(timezone.utc).isoformat()
        await conn.execute(
            text(
                f'INSERT INTO "{self._tracking_table}" '
                f"(plugin_name, version, name, applied_at, checksum, success, error_message) "
                f"VALUES (:pn, :v, :n, :at, :cs, 1, 'stamped_on_fresh_install')"
            ),
            {
                "pn": self._plugin_name,
                "v": migration.version,
                "n": migration.name,
                "at": now,
                "cs": checksum,
            },
        )

    async def _record_success(self, conn: Any, migration: PluginMigration) -> None:
        from sqlalchemy import text

        checksum = self._compute_checksum(type(migration))
        now = datetime.now(timezone.utc).isoformat()
        # Upsert: replace failed record on retry
        if self._dialect == "sqlite":
            await conn.execute(
                text(
                    f'INSERT OR REPLACE INTO "{self._tracking_table}" '
                    f"(plugin_name, version, name, applied_at, checksum, success, error_message) "
                    f"VALUES (:pn, :v, :n, :at, :cs, 1, NULL)"
                ),
                {
                    "pn": self._plugin_name,
                    "v": migration.version,
                    "n": migration.name,
                    "at": now,
                    "cs": checksum,
                },
            )
        else:
            await conn.execute(
                text(
                    f'INSERT INTO "{self._tracking_table}" '
                    f"(plugin_name, version, name, applied_at, checksum, success, error_message) "
                    f"VALUES (:pn, :v, :n, :at, :cs, TRUE, NULL) "
                    f"ON CONFLICT (plugin_name, version) DO UPDATE SET "
                    f"applied_at = :at, checksum = :cs, success = TRUE, error_message = NULL"
                ),
                {
                    "pn": self._plugin_name,
                    "v": migration.version,
                    "n": migration.name,
                    "at": now,
                    "cs": checksum,
                },
            )
