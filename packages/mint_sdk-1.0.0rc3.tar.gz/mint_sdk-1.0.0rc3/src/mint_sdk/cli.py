"""CLI entry point for the MINT SDK.

Provides commands for plugin development: build, init, dev, info, link, unlink.
"""

from __future__ import annotations

import difflib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Optional

import typer

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]

from mint_sdk.cli_commands.auth_cmd import auth_app
from mint_sdk.cli_commands.experiment_cmd import experiment_app
from mint_sdk.cli_commands.project_cmd import project_app

# ---------------------------------------------------------------------------
# App and sub-apps
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="mint",
    help="MINT plugin development CLI",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

dev_app = typer.Typer(
    name="dev",
    help="Run plugin in development mode with hot reload",
)

sdk_app = typer.Typer(
    name="sdk",
    help="Manage mint-sdk dependencies and linking",
)

add_app = typer.Typer(
    name="add",
    help="Add common plugin pieces to an existing project",
)

# ---------------------------------------------------------------------------
# Register sub-apps — Platform first, then Develop
# ---------------------------------------------------------------------------

# Platform
app.add_typer(auth_app, name="auth", rich_help_panel="Platform")
app.add_typer(experiment_app, name="experiment", rich_help_panel="Platform")
app.add_typer(project_app, name="project", rich_help_panel="Platform")

# Develop
app.add_typer(dev_app, name="dev", rich_help_panel="Develop")
app.add_typer(sdk_app, name="sdk", rich_help_panel="Develop")
app.add_typer(add_app, name="add", rich_help_panel="Develop")


# ---------------------------------------------------------------------------
# Version callback
# ---------------------------------------------------------------------------


def _version_callback(value: bool) -> None:
    if value:
        try:
            from mint_sdk._version import __version__
        except ImportError:
            __version__ = "dev"
        print(f"mint {__version__}")
        raise typer.Exit()


@app.callback()
def _app_callback(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """MINT plugin development CLI."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _read_pyproject(project_dir: Path) -> dict:
    """Read and return the [project] table from pyproject.toml."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        print(f"Error: {path} not found.", file=sys.stderr)
        sys.exit(1)
    with open(path, "rb") as f:
        data = tomllib.load(f)
    if "project" not in data:
        print("Error: pyproject.toml has no [project] table.", file=sys.stderr)
        sys.exit(1)
    return data["project"]


def _detect_package_manager(frontend_dir: Path) -> tuple[str, str]:
    """Detect the JavaScript package manager for a frontend directory.

    Returns a (name, command) tuple, e.g. ("bun", "bun") or ("npm", "npm").
    Exits if the required tool is not on PATH.
    """
    has_bun_lockfile = any((frontend_dir / f).exists() for f in ("bun.lockb", "bun.lock"))
    if has_bun_lockfile:
        if not shutil.which("bun"):
            print("Error: bun lockfile found but 'bun' is not on PATH.", file=sys.stderr)
            sys.exit(1)
        return ("bun", "bun")

    if (frontend_dir / "package-lock.json").exists():
        if not shutil.which("npm"):
            print(
                "Error: package-lock.json found but 'npm' is not on PATH.",
                file=sys.stderr,
            )
            sys.exit(1)
        return ("npm", "npm")

    # No lockfile — prefer bun, fallback to npm
    if shutil.which("bun"):
        return ("bun", "bun")
    if shutil.which("npm"):
        return ("npm", "npm")

    print(
        "Error: No JavaScript package manager found. Install bun or npm.",
        file=sys.stderr,
    )
    sys.exit(1)


def _build_frontend(project_dir: Path) -> bool:
    """Build the plugin frontend if present. Returns True if a frontend was built."""
    frontend_dir = project_dir / "frontend"
    if not (frontend_dir / "package.json").exists():
        return False

    pm_name, pm_cmd = _detect_package_manager(frontend_dir)
    print(f"Building frontend with {pm_name}...")

    for step, cmd in [("install", [pm_cmd, "install"]), ("run build", [pm_cmd, "run", "build"])]:
        result = subprocess.run(cmd, cwd=frontend_dir, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error: {pm_name} {step} failed:\n{result.stderr}", file=sys.stderr)
            sys.exit(1)

    # Verify dist exists and is non-empty
    dist_dir = frontend_dir / "dist"
    if not dist_dir.exists() or not any(dist_dir.iterdir()):
        print(
            "Error: frontend build produced no output in frontend/dist/.",
            file=sys.stderr,
        )
        sys.exit(1)

    print("Frontend build complete.")
    return True


def _check_force_include(project_dir: Path) -> None:
    """Warn if pyproject.toml lacks a force-include entry for frontend/dist."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        return
    with open(path, "rb") as f:
        data = tomllib.load(f)
    wheel_config = data.get("tool", {}).get("hatch", {}).get("build", {}).get("targets", {}).get("wheel", {})
    force_include = wheel_config.get("force-include", {})
    has_frontend_entry = any("frontend/dist" in k for k in force_include)
    if not has_frontend_entry:
        print(
            "Warning: pyproject.toml has no [tool.hatch.build.targets.wheel.force-include] "
            "entry for frontend/dist. The frontend build output may not be included in the wheel.",
            file=sys.stderr,
        )


def _run_tests(project_dir: Path) -> None:
    """Run the plugin test suite before packaging."""
    print("Running tests...")
    result = subprocess.run(
        ["uv", "run", "pytest"],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        output = "\n".join(part for part in [result.stdout, result.stderr] if part)
        print(f"Error: tests failed:\n{output}", file=sys.stderr)
        sys.exit(1)
    print("Tests passed.")


def _build_wheel(project_dir: Path, output_dir: Path) -> Path:
    """Build a wheel using ``uv build`` and return its path.

    If a wheel already exists in the output directory, it is reused.
    """
    result = subprocess.run(
        ["uv", "build", "--wheel", "--out-dir", str(output_dir)],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Error: uv build failed:\n{result.stderr}", file=sys.stderr)
        sys.exit(1)

    whls = list(output_dir.glob("*.whl"))
    if not whls:
        print("Error: uv build produced no .whl file.", file=sys.stderr)
        sys.exit(1)
    return whls[0]


def _download_deps(project_dir: Path, dest: Path) -> list[Path]:
    """Download binary dependency wheels into *dest*."""
    # Export requirements from pyproject.toml, then download wheels
    req_file = dest / "_requirements.txt"
    export_result = subprocess.run(
        ["uv", "export", "--no-dev", "--no-hashes", "-o", str(req_file)],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if export_result.returncode != 0:
        print(
            f"Warning: requirements export failed (non-fatal):\n{export_result.stderr}",
            file=sys.stderr,
        )
        return []

    result = subprocess.run(
        [
            "uv",
            "pip",
            "download",
            "--only-binary",
            ":all:",
            "--dest",
            str(dest),
            "--requirement",
            str(req_file),
        ],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    req_file.unlink(missing_ok=True)
    if result.returncode != 0:
        print(
            f"Warning: dependency download failed (non-fatal):\n{result.stderr}",
            file=sys.stderr,
        )
        return []
    return list(dest.glob("*.whl"))


def _build_manifest(
    project: dict,
    main_whl_name: str,
    dep_whl_names: list[str],
    *,
    has_frontend: bool = False,
) -> dict:
    """Build the manifest.json content."""
    return {
        "format_version": 1,
        "plugin": {
            "name": project["name"],
            "version": project["version"],
            "description": project.get("description", ""),
            "requires_mint": project.get("requires_mint", ">=1.0.0"),
            "has_frontend": has_frontend,
        },
        "wheels": {
            "main": main_whl_name,
            "dependencies": dep_whl_names,
        },
    }


def _version_from_wheel(whl_path: Path, name: str) -> str:
    """Extract version from a wheel filename (name-version-...)."""
    # Wheel filenames use underscores: my_pkg-1.2.3-py3-none-any.whl
    normalized = name.replace("-", "_").lower()
    stem = whl_path.stem  # strip .whl
    prefix = f"{normalized}-"
    if stem.startswith(prefix):
        # Everything between name- and the next - after version
        rest = stem[len(prefix) :]
        # Version ends at the first segment that looks like a tag (py3, cp312, etc.)
        parts = rest.split("-")
        return parts[0]
    # Fallback: split on second hyphen
    parts = stem.split("-")
    return parts[1] if len(parts) >= 2 else "0.0.0"


# ---------------------------------------------------------------------------
# Top-level commands — Platform panel
# ---------------------------------------------------------------------------


@app.command(rich_help_panel="Platform")
def status() -> None:
    """Show platform health and connection info."""
    from mint_sdk.cli_commands.status_cmd import cmd_status

    cmd_status()


# ---------------------------------------------------------------------------
# Top-level commands — Develop panel
# ---------------------------------------------------------------------------


@app.command(rich_help_panel="Develop")
def init(
    directory: Annotated[str, typer.Argument(help="Target directory")] = ".",
    name: Annotated[Optional[str], typer.Option("--name", "-n", help="Plugin name (human-readable)")] = None,
    description: Annotated[Optional[str], typer.Option("--description", "-d", help="One-line description")] = None,
    plugin_type: Annotated[
        Optional[str], typer.Option("--type", "-t", help="Plugin type (analysis or experiment-design)")
    ] = None,
    template: Annotated[
        Optional[str],
        typer.Option(
            "--template",
            help="Plugin starter template. Run `mint init --list-templates` to browse.",
        ),
    ] = None,
    list_templates: Annotated[
        bool,
        typer.Option("--list-templates", help="List plugin starter templates and exit"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output plugin starter templates as JSON"),
    ] = False,
    no_frontend: Annotated[bool, typer.Option("--no-frontend", help="Skip frontend scaffolding")] = False,
    no_install: Annotated[bool, typer.Option("--no-install", help="Skip uv sync and bun install")] = False,
    no_git: Annotated[bool, typer.Option("--no-git", help="Skip git init")] = False,
    force: Annotated[bool, typer.Option("--force", help="Allow non-empty directory")] = False,
    ai_assistant: Annotated[
        Optional[str],
        typer.Option("--ai-assistant", help="AI assistants, comma-separated (claude,codex,cursor,windsurf,none)"),
    ] = None,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Non-interactive: accept all defaults (safe for CI/scripts)")
    ] = False,
    author: Annotated[
        Optional[str], typer.Option("--author", help="Author name (overrides git config user.name)")
    ] = None,
    email: Annotated[
        Optional[str], typer.Option("--email", help="Author email (overrides git config user.email)")
    ] = None,
) -> None:
    """Scaffold a new plugin project."""
    from mint_sdk.init_command import cmd_init

    if list_templates or json_output:
        _print_init_template_catalog(json_output=json_output)
        return

    cmd_init(
        directory=directory,
        name=name,
        description=description,
        plugin_type=plugin_type,
        template=template,
        no_frontend=no_frontend,
        no_install=no_install,
        no_git=no_git,
        force=force,
        ai_assistant=ai_assistant,
        yes=yes,
        author=author,
        email=email,
    )


def _print_init_template_catalog(*, json_output: bool = False) -> None:
    from mint_sdk.init_command import PLUGIN_TEMPLATES

    templates = [
        {
            "name": name,
            "label": data["label"],
            "description": data["description"],
            "next_step": data["next_step"],
            "frontend_hint": data["frontend_hint"],
            "init_command": f"mint init --template {name}",
        }
        for name, data in PLUGIN_TEMPLATES.items()
    ]
    if json_output:
        typer.echo(json.dumps({"templates": templates}, indent=2))
        return

    lines = [
        "Available plugin starter templates:",
        "",
        *[
            f"  - {template['name']}: {template['description']}"
            for template in templates
        ],
        "",
        "Usage:",
        "  mint init --template analysis-basic",
        "  mint init --template cell-culture-screen",
        "  mint init --template elisa-assay",
        "  mint init --template flow-cytometry-assay",
        "  mint init --template western-blot-assay",
        "  mint init --list-templates --json",
    ]
    typer.echo("\n".join(lines))


@app.command(rich_help_panel="Develop")
def build(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    vendor_deps: Annotated[
        bool, typer.Option("--vendor-deps", help="Include dependency wheels in the .mint bundle")
    ] = False,
    no_frontend: Annotated[
        bool, typer.Option("--no-frontend", help="Skip frontend build even if frontend/package.json exists")
    ] = False,
    output_dir: Annotated[str, typer.Option("--output-dir", help="Output directory")] = "dist",
) -> None:
    """Package a plugin into a .mint bundle."""
    project_dir = Path(path).resolve()
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    project = _read_pyproject(project_dir)
    name = project["name"]

    _run_tests(project_dir)

    # Build frontend (before wheel so Hatch force-include picks up dist/)
    has_frontend = not no_frontend and _build_frontend(project_dir)
    if has_frontend:
        _check_force_include(project_dir)

    # Build the wheel
    with tempfile.TemporaryDirectory() as build_tmp:
        build_path = Path(build_tmp)
        main_whl = _build_wheel(project_dir, build_path)

        # Resolve version: static from pyproject.toml or dynamic from wheel
        version = project.get("version") or _version_from_wheel(main_whl, name)
        project["version"] = version

        # Optionally vendor dependencies
        dep_whls: list[Path] = []
        if vendor_deps:
            dep_dir = build_path / "deps"
            dep_dir.mkdir()
            dep_whls = _download_deps(project_dir, dep_dir)
            # Exclude the main wheel if it ended up in deps
            dep_whls = [w for w in dep_whls if w.name != main_whl.name]

        # Build manifest
        manifest = _build_manifest(
            project,
            main_whl.name,
            [w.name for w in dep_whls],
            has_frontend=has_frontend,
        )

        # Create .mint archive
        mint_filename = f"{name}-{version}.mint"
        mint_path = out_dir / mint_filename

        with zipfile.ZipFile(mint_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.write(main_whl, main_whl.name)
            for dep in dep_whls:
                zf.write(dep, dep.name)

    print(f"Built {mint_path}")


@app.command(rich_help_panel="Develop")
def doctor(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    deps: Annotated[bool, typer.Option("--deps", help="Check platform core dependency alignment")] = False,
    r: Annotated[bool, typer.Option("--r", help="Check R bridge environment")] = False,
    fix: Annotated[bool, typer.Option("--fix", help="Apply safe automatic fixes")] = False,
    explain: Annotated[bool, typer.Option("--explain", help="Show why each failed check matters")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Validate plugin project structure and configuration."""
    if r:
        from mint_sdk.r import check_r_environment

        checks = check_r_environment(project_dir=Path(path).resolve())
        failed = 0
        for check in checks:
            if not check["ok"]:
                failed += 1
        if json_output:
            print(
                json.dumps(
                    {
                        "ok": failed == 0,
                        "failed": failed,
                        "total": len(checks),
                        "checks": checks,
                    },
                    indent=2,
                )
            )
            if failed:
                raise typer.Exit(1)
            return

        print("\nChecking R bridge environment...\n")
        for check in checks:
            icon = "ok" if check["ok"] else "!!"
            detail = f"  {check['detail']}" if check.get("detail") else ""
            print(f"  [{icon}]  {check['label']}{detail}")
            if not check["ok"]:
                if explain and check.get("fix"):
                    print(f"        fix: {check['fix']}")
        print()
        if failed:
            raise typer.Exit(1)
        return

    if deps:
        from mint_sdk.deps_command import cmd_doctor_deps

        cmd_doctor_deps(path=path, fix=fix)
        return

    from mint_sdk.doctor_command import cmd_doctor

    cmd_doctor(path=path, explain=explain, fix=fix, json_output=json_output)


@app.command(rich_help_panel="Develop")
def info(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Show plugin metadata."""
    from mint_sdk.info_command import cmd_info

    cmd_info(path=path, json_output=json_output)


@app.command(rich_help_panel="Develop")
def docs(
    path_args: Annotated[
        Optional[list[str]],
        typer.Argument(help="Path to browse: [python|frontend|contract|template] [category|path] [item]"),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    no_cache: Annotated[bool, typer.Option("--no-cache", help="Force fresh extraction (ignore cache)")] = False,
    clear_cache: Annotated[bool, typer.Option("--clear-cache", help="Remove cached documentation and exit")] = False,
) -> None:
    """Browse SDK reference documentation."""
    from mint_sdk.docs_command import cmd_docs

    cmd_docs(
        path_args=path_args or [],
        json_output=json_output,
        no_cache=no_cache,
        clear_cache=clear_cache,
    )


# ---------------------------------------------------------------------------
# dev sub-app
# ---------------------------------------------------------------------------


@dev_app.callback(invoke_without_command=True)
def dev_callback(
    ctx: typer.Context,
    port: Annotated[int, typer.Option("--port", "-p", help="Backend server port")] = 8003,
    host: Annotated[str, typer.Option("--host", help="Backend host")] = "127.0.0.1",
    no_frontend: Annotated[bool, typer.Option("--no-frontend", help="Skip frontend dev server")] = False,
    platform: Annotated[
        bool, typer.Option("--platform", help="Also start the platform and configure dev proxy")
    ] = False,
    platform_dir: Annotated[
        Optional[str], typer.Option("--platform-dir", help="Path to platform directory")
    ] = None,
    prefix: Annotated[Optional[str], typer.Option("--prefix", help="Override routes prefix for dev proxy")] = None,
) -> None:
    """Run plugin in development mode with hot reload."""
    if ctx.invoked_subcommand is not None:
        return
    from mint_sdk.dev_command import cmd_dev

    cmd_dev(
        port=port,
        host=host,
        no_frontend=no_frontend,
        platform=platform,
        platform_dir=platform_dir,
        prefix=prefix,
    )


@dev_app.command()
def logs(
    process: Annotated[
        Optional[str], typer.Argument(help="Filter by process name (e.g., 'backend', 'frontend', 'platform')")
    ] = None,
    follow: Annotated[bool, typer.Option("--follow", "-f", help="Follow logs in real time")] = False,
    lines: Annotated[int, typer.Option("--lines", "-n", help="Number of recent lines to show")] = 50,
    list_logs: Annotated[bool, typer.Option("--list", help="List available log files")] = False,
    clear: Annotated[bool, typer.Option("--clear", help="Remove old log files")] = False,
) -> None:
    """View dev server logs."""
    from mint_sdk.logs_command import cmd_logs

    cmd_logs(
        process=process,
        follow=follow,
        lines=lines,
        list_logs=list_logs,
        clear=clear,
    )


# ---------------------------------------------------------------------------
# sdk sub-app
# ---------------------------------------------------------------------------


@sdk_app.command()
def link(
    sdk_path: Annotated[Optional[str], typer.Option("--sdk-path", help="Override path to SDK packages")] = None,
) -> None:
    """Link local SDK to sibling plugin repos."""
    from mint_sdk.link_command import cmd_link

    cmd_link(sdk_path=sdk_path)


@sdk_app.command()
def unlink() -> None:
    """Restore plugins to published SDK versions."""
    from mint_sdk.link_command import cmd_unlink

    cmd_unlink()


class UpdateScope(StrEnum):
    patch = "patch"
    minor = "minor"
    major = "major"


@sdk_app.command()
def update(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    scope: Annotated[UpdateScope, typer.Option("--scope", help="Update scope")] = UpdateScope.patch,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would be updated without modifying files")
    ] = False,
    no_sync: Annotated[bool, typer.Option("--no-sync", help="Skip running uv sync / bun install after update")] = False,
) -> None:
    """Update mint-sdk to the latest version."""
    from mint_sdk.update_command import cmd_update

    cmd_update(
        path=path,
        scope=scope,
        dry_run=dry_run,
        no_sync=no_sync,
    )


@sdk_app.command("generate")
def sdk_generate(
    path: Annotated[str, typer.Argument(help="Plugin project directory")] = ".",
    check: Annotated[bool, typer.Option("--check", help="Check generated contract files without writing")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    output: Annotated[
        Optional[str],
        typer.Option("--output", help="Output directory relative to project root"),
    ] = None,
) -> None:
    """Generate the frontend plugin contract and typed client."""
    from mint_sdk.contract import ContractGenerationError, generate_contract_files

    try:
        result = generate_contract_files(
            Path(path).resolve(),
            output_dir=Path(output) if output else None,
            check=check,
        )
    except ContractGenerationError as exc:
        if json_output:
            print(
                json.dumps(
                    {
                        "ok": False,
                        "detail": str(exc),
                        "check": check,
                        "output": output,
                        "error": str(exc),
                    },
                    indent=2,
                )
            )
            raise typer.Exit(1) from exc
        print(f"Error: {exc}", file=sys.stderr)
        raise typer.Exit(1) from exc

    if json_output:
        print(
            json.dumps(
                {
                    "ok": result.ok,
                    "detail": result.detail,
                    "check": check,
                    "output": output,
                    "explanation": result.explanation,
                    "fix_hint": result.fix_hint,
                },
                indent=2,
            )
        )
    else:
        print(f"Plugin contract: {result.detail}")
    if not result.ok:
        if not json_output:
            if result.explanation:
                print(f"why: {result.explanation}", file=sys.stderr)
            if result.fix_hint:
                print(f"fix: {result.fix_hint}", file=sys.stderr)
        raise typer.Exit(1)
    if not json_output and not check and "nothing generated" not in result.detail:
        print("Next: mint dev")
        print("Next: mint doctor --explain")


# ---------------------------------------------------------------------------
# add sub-app
# ---------------------------------------------------------------------------


@add_app.command()
def setting(
    name: Annotated[str, typer.Argument(help="Setting field name, e.g. threshold")],
    field_type: Annotated[
        str,
        typer.Option("--type", "-t", help="Field type: string, number, integer, boolean"),
    ] = "string",
    default: Annotated[Optional[str], typer.Option("--default", help="Default value as text")] = None,
    description: Annotated[str, typer.Option("--description", "-d", help="Field hint text")] = "",
    required: Annotated[bool, typer.Option("--required", help="Require a value")] = False,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding the setting")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a typed plugin setting and wire settings_model."""
    from mint_sdk.add_command import SettingType, cmd_add_setting

    cmd_add_setting(
        path=path,
        name=name,
        field_type=SettingType(field_type),
        default=default,
        description=description,
        required=required,
        generate=generate,
    )


@add_app.command()
def endpoint(
    name: Annotated[str, typer.Argument(help="Endpoint function name")],
    route_path: Annotated[Optional[str], typer.Option("--route", help="URL path, defaults to /<name>")] = None,
    method: Annotated[str, typer.Option("--method", "-m", help="HTTP method")] = "get",
    router: Annotated[str, typer.Option("--router", help="Router module name")] = "analysis",
    create_router: Annotated[bool, typer.Option("--create-router", help="Create and register the router if missing")] = False,
    request_model: Annotated[Optional[str], typer.Option("--request-model", help="Import request model from schemas.requests")] = None,
    response_model: Annotated[
        Optional[str], typer.Option("--response-model", help="Import response model from schemas.responses")
    ] = None,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding the endpoint")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Append a simple FastAPI endpoint to a router."""
    from mint_sdk.add_command import HttpMethod, cmd_add_endpoint

    cmd_add_endpoint(
        path=path,
        name=name,
        route_path=route_path,
        method=HttpMethod(method),
        router=router,
        create_router=create_router,
        request_model=request_model,
        response_model=response_model,
        generate=generate,
    )


@add_app.command()
def router(
    name: Annotated[str, typer.Argument(help="Router module name")],
    prefix: Annotated[Optional[str], typer.Option("--prefix", help="Sub-prefix mounted under the plugin routes prefix")] = None,
    tag: Annotated[Optional[str], typer.Option("--tag", help="OpenAPI tag")] = None,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Create and register a FastAPI router."""
    from mint_sdk.add_command import cmd_add_router

    cmd_add_router(path=path, name=name, prefix=prefix, tag=tag)


@add_app.command()
def migration(
    name: Annotated[str, typer.Argument(help="Migration description/name")],
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a plugin schema migration file."""
    from mint_sdk.add_command import cmd_add_migration

    cmd_add_migration(path=path, name=name)


@add_app.command()
def schema(
    name: Annotated[str, typer.Argument(help="Pydantic schema class name")],
    file: Annotated[str, typer.Option("--file", help="schemas/<file>.py target")] = "requests",
    fields: Annotated[
        list[str] | None,
        typer.Option(
            "--field",
            help="Repeatable field spec: name:type or name:type=default. Types: str, float, int, bool, dict, list",
        ),
    ] = None,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding the schema")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a Pydantic schema class."""
    from mint_sdk.add_command import cmd_add_schema

    cmd_add_schema(path=path, name=name, file=file, fields=fields, generate=generate)


@add_app.command()
def service(
    name: Annotated[str, typer.Argument(help="Service name")],
    method: Annotated[str, typer.Option("--method", help="Initial async method name")] = "run",
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a singleton service module."""
    from mint_sdk.add_command import cmd_add_service

    cmd_add_service(path=path, name=name, method=method)


@add_app.command()
def job(
    name: Annotated[str, typer.Argument(help="Job name")] = "analysis",
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a simple job service and /jobs router."""
    from mint_sdk.add_command import cmd_add_job

    cmd_add_job(path=path, name=name)


@add_app.command()
def artifact(
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a local artifact helper and /artifacts router."""
    from mint_sdk.add_command import cmd_add_artifact

    cmd_add_artifact(path=path)


@add_app.command()
def hook(
    kind: Annotated[str, typer.Argument(help="Hook kind: before-save, after-save, status-change")],
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a plugin lifecycle hook."""
    from mint_sdk.add_command import HookKind, cmd_add_hook

    cmd_add_hook(path=path, hook=HookKind(kind))


@add_app.command("frontend-page")
def frontend_page(
    name: Annotated[str, typer.Argument(help="Page name")],
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a Vue view and register it in the scaffolded router."""
    from mint_sdk.add_command import cmd_add_frontend_page

    cmd_add_frontend_page(path=path, name=name)


@add_app.command("frontend-composable")
def frontend_composable(
    name: Annotated[str, typer.Argument(help="Composable name without the use prefix")],
    endpoint: Annotated[Optional[str], typer.Option("--endpoint", help="API endpoint path used by the generated helpers")] = None,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a Vue composable wired to the plugin API."""
    from mint_sdk.add_command import cmd_add_frontend_composable

    cmd_add_frontend_composable(path=path, name=name, endpoint=endpoint)


@add_app.command("r-analysis")
def r_analysis(
    name: Annotated[str, typer.Argument(help="R analysis name")],
    script: Annotated[Optional[str], typer.Option("--script", help="R script path")] = None,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding the R endpoint")
    ] = False,
    page: Annotated[
        bool, typer.Option("--page", help="Create and register a starter Vue page for this R analysis")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add an R-backed analysis endpoint scaffold."""
    from mint_sdk.add_command import cmd_add_r_analysis

    cmd_add_r_analysis(path=path, name=name, script=script, generate=generate, page=page)


@add_app.command("data-template")
def data_template(
    template: Annotated[
        Optional[str],
        typer.Argument(
            help=(
                "Template: plate-map, sample-sheet, sample-prep, dose-response, calibration-curve, "
                "time-course, protocol-steps, assay-matrix, reagent-list, "
                "flow-cytometry-panel, instrument-run, or qpcr-plate"
            )
        ),
    ] = None,
    list_templates: Annotated[
        bool,
        typer.Option("--list", "--list-templates", help="List built-in biology data templates and exit"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output the built-in template catalog as JSON"),
    ] = False,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding template helpers")
    ] = False,
    page: Annotated[
        bool, typer.Option("--page", help="Create and register a starter Vue page for this template")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add importable biology data template helpers."""
    from mint_sdk.add_command import DataTemplateKind, cmd_add_data_template

    if list_templates or (json_output and template is None):
        _print_data_template_catalog(json_output=json_output)
        return

    if template is None:
        typer.echo("Error: choose a data template, or run `mint add data-template --list`.", err=True)
        raise typer.Exit(2)

    template_kind = _resolve_data_template_kind(template, DataTemplateKind)
    cmd_add_data_template(path=path, template=template_kind, generate=generate, page=page)


@add_app.command("data-template-pack")
def data_template_pack(
    pack: Annotated[
        Optional[str],
        typer.Argument(
            help="Pack: cell-culture-screen, omics-assay, longitudinal-study, or molecular-assay"
        ),
    ] = None,
    list_packs: Annotated[
        bool,
        typer.Option("--list", "--list-packs", help="List built-in biology data-template packs and exit"),
    ] = False,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output the built-in template-pack catalog as JSON"),
    ] = False,
    generate: Annotated[
        bool, typer.Option("--generate", help="Regenerate frontend contract/client after adding template pack")
    ] = False,
    page: Annotated[
        bool, typer.Option("--page", help="Create and register starter Vue pages for all templates in the pack")
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a curated biology data-template pack."""
    from mint_sdk.add_command import DataTemplatePackKind, cmd_add_data_template_pack

    if list_packs or (json_output and pack is None):
        _print_data_template_pack_catalog(json_output=json_output)
        return

    if pack is None:
        typer.echo("Error: choose a data-template pack, or run `mint add data-template-pack --list`.", err=True)
        raise typer.Exit(2)

    pack_kind = _resolve_data_template_pack_kind(pack, DataTemplatePackKind)
    cmd_add_data_template_pack(path=path, pack=pack_kind, generate=generate, page=page)


@add_app.command("data-template-preset")
def data_template_preset(
    preset: Annotated[
        Optional[str],
        typer.Argument(
            help=(
                "Preset: wellplate-screen, qpcr-expression, lcms-batch, "
                "elisa-assay, flow-cytometry-assay, or western-blot-assay"
            )
        ),
    ] = None,
    list_presets: Annotated[
        bool,
        typer.Option("--list", "--list-presets", help="List ready-to-save biology template presets and exit"),
    ] = False,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output the built-in template-preset catalog as JSON"),
    ] = False,
    page: Annotated[
        bool, typer.Option("--page", help="Create and register a starter Vue page for this preset"),
    ] = False,
    path: Annotated[str, typer.Option("--path", help="Plugin project directory")] = ".",
) -> None:
    """Add a ready-to-save biology data-template preset."""
    from mint_sdk.add_command import DataTemplatePresetKind, cmd_add_data_template_preset

    if list_presets or (json_output and preset is None):
        _print_data_template_preset_catalog(json_output=json_output)
        return

    if preset is None:
        typer.echo("Error: choose a data-template preset, or run `mint add data-template-preset --list`.", err=True)
        raise typer.Exit(2)

    preset_kind = _resolve_data_template_preset_kind(preset, DataTemplatePresetKind)
    cmd_add_data_template_preset(path=path, preset=preset_kind, page=page)


def _print_data_template_catalog(*, json_output: bool = False) -> None:
    from mint_sdk.templates import list_template_catalog, list_template_presets

    catalog = list_template_catalog()
    presets = list_template_presets()
    if json_output:
        typer.echo(
            json.dumps(
                {
                    "templates": [entry.model_dump(mode="json") for entry in catalog],
                    "presets": [entry.model_dump(mode="json") for entry in presets],
                },
                indent=2,
            )
        )
        return

    lines = [
        "Available data templates:",
        "",
        *[
            f"  - {entry.name}: {entry.purpose}"
            for entry in catalog
        ],
        "",
        "Ready-to-save template presets:",
        "",
        *[
            f"  - {entry.name}: {entry.purpose}"
            for entry in presets
        ],
        "",
        "Usage:",
        "  mint add data-template plate-map --page",
        "  mint add data-template-preset wellplate-screen --page",
        "  mint add data-template-preset elisa-assay --page",
        "  mint add data-template-preset flow-cytometry-assay --page",
        "  mint add data-template-preset western-blot-assay --page",
        "  mint docs template <name>",
        "  mint docs template-preset <name>",
    ]
    typer.echo("\n".join(lines))


def _print_data_template_preset_catalog(*, json_output: bool = False) -> None:
    from mint_sdk.add_command import list_data_template_presets

    presets = list_data_template_presets()
    if json_output:
        typer.echo(json.dumps({"presets": presets}, indent=2))
        return

    lines = [
        "Available data-template presets:",
        "",
        *[
            line
            for preset in presets
            for line in _format_data_template_preset_list_item(preset)
        ],
        "",
        "Usage:",
        "  mint add data-template-preset wellplate-screen --page",
        "  mint add data-template-preset elisa-assay --page",
        "  mint add data-template-preset flow-cytometry-assay --page",
        "  mint add data-template-preset western-blot-assay --page",
        "  mint docs template-preset wellplate-screen",
    ]
    typer.echo("\n".join(lines))


def _format_data_template_preset_list_item(preset: dict[str, object]) -> list[str]:
    aliases = _string_list(preset.get("aliases"))
    components = _string_list(preset.get("components"))
    lines = [
        f"  - {preset['name']}: {preset['purpose']}",
    ]
    if aliases:
        lines.append(f"    aliases: {', '.join(aliases)}")
    if components:
        lines.append(f"    components: {', '.join(components)}")
    if add_command := preset.get("add_command"):
        lines.append(f"    add: {add_command}")
    return lines


def _string_list(value: object) -> list[str]:
    if not isinstance(value, (list, tuple)):
        return []
    return [str(item) for item in value]


def _print_data_template_pack_catalog(*, json_output: bool = False) -> None:
    from mint_sdk.templates import list_template_packs

    packs = tuple(entry.model_dump(mode="json") for entry in list_template_packs())
    if json_output:
        typer.echo(json.dumps({"packs": packs}, indent=2))
        return

    lines = [
        "Available data-template packs:",
        "",
        *[
            f"  - {pack['name']}: {pack['purpose']}"
            for pack in packs
        ],
        "",
        "Usage:",
        "  mint add data-template-pack cell-culture-screen --page",
        "  mint add data-template-pack --list --json",
    ]
    typer.echo("\n".join(lines))


def _resolve_data_template_kind(template: str, data_template_kind: type[StrEnum]):
    from mint_sdk.templates import get_template_info, list_template_catalog

    info = get_template_info(template)
    if info is not None:
        return data_template_kind(info.name)

    choices = [entry.name for entry in list_template_catalog()]
    suggestion = difflib.get_close_matches(template, choices, n=1)
    lines = [f"Unknown data template: {template}"]
    if suggestion:
        lines.append(f"Did you mean: {suggestion[0]}?")
    lines.append("Run `mint add data-template --list` to see built-in templates.")
    typer.echo("\n".join(lines), err=True)
    raise typer.Exit(1)


def _resolve_data_template_pack_kind(pack: str, data_template_pack_kind: type[StrEnum]):
    from mint_sdk.templates import get_template_pack_info, list_template_packs

    info = get_template_pack_info(pack)
    if info is not None:
        return data_template_pack_kind(info.name)

    choices = [entry.name for entry in list_template_packs()]
    suggestion = difflib.get_close_matches(pack, choices, n=1)
    lines = [f"Unknown data-template pack: {pack}"]
    if suggestion:
        lines.append(f"Did you mean: {suggestion[0]}?")
    lines.append("Run `mint add data-template-pack --list` to see built-in packs.")
    typer.echo("\n".join(lines), err=True)
    raise typer.Exit(1)


def _resolve_data_template_preset_kind(preset: str, data_template_preset_kind: type[StrEnum]):
    from mint_sdk.add_command import get_data_template_preset_info, list_data_template_presets

    info = get_data_template_preset_info(preset)
    if info is not None:
        return data_template_preset_kind(str(info["name"]))

    choices = [str(entry["name"]) for entry in list_data_template_presets()]
    suggestion = difflib.get_close_matches(preset, choices, n=1)
    lines = [f"Unknown data-template preset: {preset}"]
    if suggestion:
        lines.append(f"Did you mean: {suggestion[0]}?")
    lines.append("Run `mint add data-template-preset --list` to see built-in presets.")
    typer.echo("\n".join(lines), err=True)
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Main CLI entry point."""
    app()


if __name__ == "__main__":
    main()
