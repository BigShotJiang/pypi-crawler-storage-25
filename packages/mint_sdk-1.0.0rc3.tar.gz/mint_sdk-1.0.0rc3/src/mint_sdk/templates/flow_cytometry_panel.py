"""Flow-cytometry panel biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

FlowMarkerPurpose = Literal["phenotype", "viability", "activation", "sorting", "control", "other"]
FlowControlKind = Literal["unstained", "single-stain", "fmo", "isotype", "viability", "beads", "other"]


class FlowPanelMarker(BioTemplate):
    """Single marker/fluorophore assignment for a flow-cytometry panel."""

    template_id = "flow-panel-marker"

    id: str
    marker: str
    fluorophore: str = "unassigned"
    detector: str | None = None
    clone: str | None = None
    reagent_id: str | None = Field(default=None, alias="reagentId")
    purpose: FlowMarkerPurpose = "phenotype"
    compensation_required: bool = Field(default=True, alias="compensationRequired")
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_marker(self) -> FlowPanelMarker:
        if not self.id:
            raise ValueError("Flow panel marker id is required.")
        if not self.marker:
            raise ValueError("Flow panel marker name is required.")
        return self


class FlowPanelControl(BioTemplate):
    """Control row for compensation, FMO, isotype, or viability setup."""

    template_id = "flow-panel-control"

    id: str
    name: str
    kind: FlowControlKind
    marker_id: str | None = Field(default=None, alias="markerId")
    required: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_control(self) -> FlowPanelControl:
        if not self.id:
            raise ValueError("Flow panel control id is required.")
        if not self.name:
            raise ValueError("Flow panel control name is required.")
        return self


class FlowCytometryPanelTemplate(BioTemplate):
    """Versioned template for flow-cytometry marker panels and controls."""

    template_id = "flow-cytometry-panel"

    markers: list[FlowPanelMarker]
    controls: list[FlowPanelControl] = Field(default_factory=list)
    instrument: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        markers: Sequence[str | Mapping[str, Any] | FlowPanelMarker],
        *,
        instrument: str | None = None,
        controls: Sequence[str | Mapping[str, Any] | FlowPanelControl] | None = None,
        include_default_controls: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> FlowCytometryPanelTemplate:
        """Build a flow panel from marker names, marker dictionaries, and optional controls."""
        marker_records: list[FlowPanelMarker] = []
        for index, marker in enumerate(markers):
            if isinstance(marker, FlowPanelMarker):
                marker_records.append(marker)
            elif isinstance(marker, str):
                marker_records.append(
                    FlowPanelMarker(
                        id=_id_from_name(marker, f"marker-{index + 1}"),
                        marker=marker,
                    )
                )
            else:
                marker_records.append(FlowPanelMarker.model_validate(dict(marker)))

        control_records = _coerce_controls(controls)
        if include_default_controls and controls is None:
            control_records = _default_controls(marker_records)

        return cls(
            markers=marker_records,
            controls=control_records,
            instrument=instrument,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> FlowCytometryPanelTemplate:
        if not self.markers:
            raise ValueError("FlowCytometryPanelTemplate requires at least one marker.")
        marker_ids = [marker.id for marker in self.markers]
        if len(marker_ids) != len(set(marker_ids)):
            raise ValueError("Flow panel marker ids must be unique.")

        control_ids = [control.id for control in self.controls]
        if len(control_ids) != len(set(control_ids)):
            raise ValueError("Flow panel control ids must be unique.")
        unknown_controls = [
            control.marker_id
            for control in self.controls
            if control.marker_id is not None and control.marker_id not in marker_ids
        ]
        if unknown_controls:
            raise ValueError(f"Flow panel controls reference unknown markers: {', '.join(unknown_controls)}.")
        return self


def _coerce_controls(
    controls: Sequence[str | Mapping[str, Any] | FlowPanelControl] | None,
) -> list[FlowPanelControl]:
    if controls is None:
        return []
    records: list[FlowPanelControl] = []
    for index, control in enumerate(controls):
        if isinstance(control, FlowPanelControl):
            records.append(control)
        elif isinstance(control, str):
            records.append(
                FlowPanelControl(
                    id=_id_from_name(control, f"control-{index + 1}"),
                    name=control,
                    kind="other",
                )
            )
        else:
            records.append(FlowPanelControl.model_validate(dict(control)))
    return records


def _default_controls(markers: Sequence[FlowPanelMarker]) -> list[FlowPanelControl]:
    controls = [
        FlowPanelControl(
            id="unstained",
            name="Unstained",
            kind="unstained",
        )
    ]
    controls.extend(
        FlowPanelControl(
            id=f"{marker.id}-single-stain",
            name=f"{marker.marker} single stain",
            kind="single-stain",
            markerId=marker.id,
        )
        for marker in markers
        if marker.compensation_required
    )
    return controls


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
