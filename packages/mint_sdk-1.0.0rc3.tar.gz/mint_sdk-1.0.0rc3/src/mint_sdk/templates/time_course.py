"""Time-course biology template models."""

from __future__ import annotations

import re
from collections.abc import Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

TimeUnit = Literal["second", "minute", "hour", "day", "week"]

DEFAULT_CONDITION_COLORS = [
    "#3B82F6",
    "#10B981",
    "#EF4444",
    "#F59E0B",
    "#8B5CF6",
    "#F97316",
    "#06B6D4",
    "#14B8A6",
    "#6B7280",
]


def _slug(value: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or fallback


def _timepoint_id(value: float, unit: TimeUnit, index: int) -> str:
    token = f"{value:g}".replace(".", "p")
    return f"t{token}-{unit}" if token else f"timepoint-{index + 1}"


class TimePoint(BioTemplate):
    """Single time point in a longitudinal experiment."""

    template_id = "time-point"

    id: str
    label: str
    value: float
    unit: TimeUnit
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_timepoint(self) -> "TimePoint":
        if self.value < 0:
            raise ValueError("Time point value cannot be negative.")
        return self


class TimeCourseCondition(BioTemplate):
    """Condition or treatment followed across time."""

    template_id = "time-course-condition"

    id: str
    name: str
    color: str | None = None
    description: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TimeCourseSample(BioTemplate):
    """Sample scheduled for one condition/timepoint/replicate."""

    template_id = "time-course-sample"

    sample_id: str = Field(alias="sampleId")
    condition_id: str = Field(alias="conditionId")
    timepoint_id: str = Field(alias="timepointId")
    replicate: int = 1
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_sample(self) -> "TimeCourseSample":
        if not self.sample_id:
            raise ValueError("Sample id is required.")
        if self.replicate < 1:
            raise ValueError("Replicate count must be at least 1.")
        return self


class TimeCourseTemplate(BioTemplate):
    """Versioned template for longitudinal biological designs."""

    template_id = "time-course"

    timepoints: list[TimePoint]
    conditions: list[TimeCourseCondition]
    samples: list[TimeCourseSample] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        timepoints: Sequence[float | TimePoint | dict[str, Any]],
        *,
        unit: TimeUnit,
        conditions: Sequence[str | TimeCourseCondition | dict[str, Any]],
        replicates: int = 1,
        metadata: dict[str, Any] | None = None,
    ) -> "TimeCourseTemplate":
        """Build a time-course template and generate scheduled samples."""
        timepoint_models: list[TimePoint] = []
        for index, timepoint in enumerate(timepoints):
            if isinstance(timepoint, TimePoint):
                timepoint_models.append(timepoint)
            elif isinstance(timepoint, dict):
                timepoint_models.append(TimePoint.model_validate(timepoint))
            else:
                timepoint_models.append(
                    TimePoint(
                        id=_timepoint_id(timepoint, unit, index),
                        label=f"{timepoint:g} {unit}",
                        value=float(timepoint),
                        unit=unit,
                    )
                )
        timepoint_models = sorted(timepoint_models, key=lambda timepoint: timepoint.value)

        condition_models: list[TimeCourseCondition] = []
        for index, condition in enumerate(conditions):
            if isinstance(condition, TimeCourseCondition):
                condition_models.append(condition)
            elif isinstance(condition, dict):
                condition_models.append(TimeCourseCondition.model_validate(condition))
            else:
                condition_models.append(
                    TimeCourseCondition(
                        id=_slug(condition, f"condition-{index + 1}"),
                        name=condition,
                        color=DEFAULT_CONDITION_COLORS[index % len(DEFAULT_CONDITION_COLORS)],
                    )
                )

        samples: list[TimeCourseSample] = []
        for condition in condition_models:
            for timepoint in timepoint_models:
                for replicate in range(1, replicates + 1):
                    samples.append(
                        TimeCourseSample(
                            sampleId=f"{condition.id}-{timepoint.id}-r{replicate}",
                            conditionId=condition.id,
                            timepointId=timepoint.id,
                            replicate=replicate,
                        )
                    )

        return cls(
            timepoints=timepoint_models,
            conditions=condition_models,
            samples=samples,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> "TimeCourseTemplate":
        if not self.timepoints:
            raise ValueError("TimeCourseTemplate requires at least one time point.")
        if not self.conditions:
            raise ValueError("TimeCourseTemplate requires at least one condition.")

        timepoint_ids = [timepoint.id for timepoint in self.timepoints]
        if len(timepoint_ids) != len(set(timepoint_ids)):
            raise ValueError("Time point ids must be unique.")
        timepoint_id_set = set(timepoint_ids)

        condition_ids = [condition.id for condition in self.conditions]
        if len(condition_ids) != len(set(condition_ids)):
            raise ValueError("Condition ids must be unique.")
        condition_id_set = set(condition_ids)

        sample_ids = [sample.sample_id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("Time-course sample ids must be unique.")

        for sample in self.samples:
            if sample.timepoint_id not in timepoint_id_set:
                raise ValueError(f"Sample '{sample.sample_id}' references unknown time point.")
            if sample.condition_id not in condition_id_set:
                raise ValueError(f"Sample '{sample.sample_id}' references unknown condition.")

        self.timepoints = sorted(self.timepoints, key=lambda timepoint: timepoint.value)
        return self
