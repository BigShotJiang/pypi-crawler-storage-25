"""Sample-sheet biology template models."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate
from .plate_map import well_position

SampleColumnType = Literal["string", "number", "integer", "boolean", "date", "category", "unknown"]

_SAMPLE_FIELD_ALIASES = {
    "sample_id": "sample_id",
    "sampleId": "sample_id",
    "name": "name",
    "group": "group",
    "batch": "batch",
    "replicate": "replicate",
    "plate_id": "plate_id",
    "plateId": "plate_id",
    "well_id": "well_id",
    "wellId": "well_id",
}


class SampleColumn(BioTemplate):
    """Column metadata for tabular sample sheets."""

    template_id = "sample-column"

    id: str
    label: str
    type: SampleColumnType = "string"
    required: bool = False
    groupable: bool = False


class SampleRecord(BioTemplate):
    """Single sample row with common fields and freeform metadata."""

    template_id = "sample-record"

    sample_id: str = Field(alias="sampleId")
    name: str | None = None
    group: str | None = None
    batch: str | None = None
    replicate: int | str | None = None
    plate_id: str | None = Field(default=None, alias="plateId")
    well_id: str | None = Field(default=None, alias="wellId")
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_sample(self) -> "SampleRecord":
        if not self.sample_id:
            raise ValueError("Sample id is required.")
        if self.well_id is not None:
            well_position(self.well_id)
            self.well_id = self.well_id.upper()
        return self


class SampleGroupDefinition(BioTemplate):
    """Named sample group compatible with grouping UI components."""

    template_id = "sample-group"

    name: str
    color: str = "#3B82F6"
    samples: list[str] = Field(default_factory=list)


class SampleSheetTemplate(BioTemplate):
    """Versioned template for tabular sample metadata."""

    template_id = "sample-sheet"

    samples: list[SampleRecord]
    columns: list[SampleColumn] = Field(default_factory=list)
    groups: list[SampleGroupDefinition] = Field(default_factory=list)

    @classmethod
    def from_rows(
        cls,
        rows: Sequence[Mapping[str, Any]],
        *,
        sample_id_key: str = "sample_id",
    ) -> "SampleSheetTemplate":
        """Build a sample sheet from CSV-like dictionaries."""
        records: list[SampleRecord] = []
        observed_columns: dict[str, SampleColumn] = {}

        for row in rows:
            normalized: dict[str, Any] = {}
            metadata: dict[str, Any] = {}

            for key, value in row.items():
                target = _SAMPLE_FIELD_ALIASES.get(key)
                if key == sample_id_key:
                    target = "sample_id"
                if target is None:
                    metadata[key] = value
                    observed_columns.setdefault(
                        key,
                        SampleColumn(
                            id=key,
                            label=key.replace("_", " ").replace("-", " ").title(),
                            type=_infer_column_type(value),
                            groupable=True,
                        ),
                    )
                else:
                    normalized[target] = value

            normalized.setdefault("metadata", metadata)
            records.append(SampleRecord.model_validate(normalized))

        columns = [
            SampleColumn(id="sampleId", label="Sample ID", required=True, groupable=False),
            SampleColumn(id="name", label="Name", required=False, groupable=False),
            *observed_columns.values(),
        ]
        return cls(samples=records, columns=columns)

    @model_validator(mode="after")
    def _validate_template(self) -> "SampleSheetTemplate":
        if not self.samples:
            raise ValueError("SampleSheetTemplate requires at least one sample.")

        sample_ids = [sample.sample_id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("Sample ids must be unique.")
        sample_id_set = set(sample_ids)

        column_ids = [column.id for column in self.columns]
        if len(column_ids) != len(set(column_ids)):
            raise ValueError("Sample sheet column ids must be unique.")

        for group in self.groups:
            for sample_id in group.samples:
                if sample_id not in sample_id_set:
                    raise ValueError(f"Group '{group.name}' references unknown sample '{sample_id}'.")

        return self


def _infer_column_type(value: Any) -> SampleColumnType:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, float):
        return "number"
    if value is None:
        return "unknown"
    return "string"
