"""Shared envelope and helpers for versioned biology data templates."""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from typing import Any, ClassVar, Optional, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field

from mint_sdk.exceptions import ValidationException

TEMPLATE_COLLECTION_KEY = "templates"


def normalize_template_lookup_key(value: str) -> str:
    """Normalize template lookup terms across spaces, hyphens, and underscores."""
    return re.sub(r"[\s_-]+", "-", value.strip().lower())


class TemplateValidationError(ValidationException):
    """Raised when a template envelope cannot be loaded safely."""

    def __init__(
        self,
        message: str,
        *,
        field: Optional[str] = None,
        value: Any = None,
        details: Optional[dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, field=field, value=value, details=details)
        self.code = "TEMPLATE_VALIDATION_ERROR"


class BioTemplateEnvelope(BaseModel):
    """Storage envelope for biology template payloads."""

    model_config = ConfigDict(extra="forbid")

    template_id: str
    template_version: str = "1.0"
    kind: str = "experiment-design"
    data: dict[str, Any]
    metadata: dict[str, Any] = Field(default_factory=dict)


class BioTemplate(BaseModel):
    """Base class for template payload models."""

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    template_id: ClassVar[str]
    template_version: ClassVar[str] = "1.0"
    template_kind: ClassVar[str] = "experiment-design"

    def to_envelope(self, metadata: dict[str, Any] | None = None) -> BioTemplateEnvelope:
        """Serialize this template payload into the shared storage envelope."""
        return BioTemplateEnvelope(
            template_id=self.template_id,
            template_version=self.template_version,
            kind=self.template_kind,
            data=self.model_dump(mode="json", by_alias=True, exclude_none=True),
            metadata=metadata or {},
        )

    def to_design_data(self, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
        """Return a JSON-compatible dict suitable for plugin ``design_data``."""
        return self.to_envelope(metadata=metadata).model_dump(mode="json")

    @classmethod
    def from_design_data(cls, payload: Mapping[str, Any]) -> Self:
        """Load a typed template from an envelope dict stored in ``design_data``."""
        if not isinstance(payload, Mapping):
            raise TemplateValidationError(
                "Template design data must be a mapping.",
                field="payload",
                value=type(payload).__name__,
            )

        envelope = BioTemplateEnvelope.model_validate(dict(payload))
        if envelope.template_id != cls.template_id:
            raise TemplateValidationError(
                f"Expected template_id '{cls.template_id}', got '{envelope.template_id}'.",
                field="template_id",
                value=envelope.template_id,
                details={"expected": cls.template_id},
            )
        return cls.model_validate(envelope.data)


class _TemplatePlugin(Protocol):
    async def save_design(
        self,
        experiment_id: int,
        data: dict[str, Any],
        *,
        schema_version: str | None = None,
    ) -> Any: ...

    async def load_design(self, experiment_id: int) -> Any: ...


async def save_template(
    plugin: _TemplatePlugin,
    experiment_id: int,
    template: BioTemplate,
    *,
    metadata: dict[str, Any] | None = None,
    schema_version: str | None = None,
    merge: bool = False,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> Any:
    """Save a template through a plugin's existing design-data method."""
    if merge:
        design_data = await _load_design_data(plugin, experiment_id)
        payload = _merge_template_into_design_data(
            design_data,
            template.to_design_data(metadata=metadata),
            collection_key=collection_key,
        )
        return await plugin.save_design(
            experiment_id,
            payload,
            schema_version=schema_version,
        )

    return await plugin.save_design(
        experiment_id,
        template.to_design_data(metadata=metadata),
        schema_version=schema_version,
    )


async def load_template[TemplateT: BioTemplate](
    plugin: _TemplatePlugin,
    experiment_id: int,
    template_cls: type[TemplateT],
    *,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> TemplateT | None:
    """Load and validate a template through a plugin's design-data method."""
    data = await _load_design_data(plugin, experiment_id)
    if data is None:
        return None

    payload = _extract_template_payload(data, template_cls.template_id, collection_key=collection_key)
    if payload is None:
        return None
    return template_cls.from_design_data(payload)


def create_template_collection(
    templates: Iterable[BioTemplate | BioTemplateEnvelope | Mapping[str, Any]],
    *,
    metadata: dict[str, Any] | None = None,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> dict[str, Any]:
    """Create a design-data payload containing multiple template envelopes."""
    collection: dict[str, dict[str, Any]] = {}
    for template in templates:
        envelope = _coerce_template_envelope(template)
        if envelope.template_id in collection:
            raise TemplateValidationError(
                f"Duplicate template_id '{envelope.template_id}' in template collection.",
                field=f"{collection_key}.{envelope.template_id}",
                value=envelope.template_id,
            )
        collection[envelope.template_id] = envelope.model_dump(mode="json")

    payload: dict[str, Any] = {collection_key: collection}
    if metadata is not None:
        payload["metadata"] = metadata
    return payload


def extract_template_collection(
    payload: Mapping[str, Any],
    *,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> dict[str, BioTemplateEnvelope]:
    """Extract validated template envelopes from collection or legacy single-template data."""
    if not isinstance(payload, Mapping):
        raise TemplateValidationError(
            "Template collection payload must be a mapping.",
            field="payload",
            value=type(payload).__name__,
        )

    if isinstance(payload.get("template_id"), str):
        envelope = _coerce_template_envelope(payload)
        return {envelope.template_id: envelope}

    collection = payload.get(collection_key)
    if collection is None:
        return {}
    if not isinstance(collection, Mapping):
        raise TemplateValidationError(
            "Template collection must be a mapping.",
            field=collection_key,
            value=type(collection).__name__,
        )

    envelopes: dict[str, BioTemplateEnvelope] = {}
    for template_id, value in collection.items():
        if not isinstance(template_id, str):
            raise TemplateValidationError(
                "Template collection keys must be strings.",
                field=collection_key,
                value=type(template_id).__name__,
            )
        if not isinstance(value, Mapping):
            raise TemplateValidationError(
                "Stored template collection entry must be a mapping.",
                field=f"{collection_key}.{template_id}",
                value=type(value).__name__,
            )
        envelope = _coerce_template_envelope(value)
        if envelope.template_id != template_id:
            raise TemplateValidationError(
                f"Template collection key '{template_id}' does not match envelope template_id "
                f"'{envelope.template_id}'.",
                field=f"{collection_key}.{template_id}.template_id",
                value=envelope.template_id,
                details={"expected": template_id},
            )
        envelopes[template_id] = envelope
    return envelopes


async def save_template_collection(
    plugin: _TemplatePlugin,
    experiment_id: int,
    templates: Iterable[BioTemplate | BioTemplateEnvelope | Mapping[str, Any]],
    *,
    metadata: dict[str, Any] | None = None,
    schema_version: str | None = None,
    merge: bool = True,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> Any:
    """Save multiple templates through a plugin's existing design-data method."""
    payload = create_template_collection(templates, metadata=metadata, collection_key=collection_key)
    if not merge:
        return await plugin.save_design(experiment_id, payload, schema_version=schema_version)

    design_data = await _load_design_data(plugin, experiment_id)
    merged: dict[str, Any] = dict(design_data) if design_data is not None else {}
    for envelope in extract_template_collection(payload, collection_key=collection_key).values():
        merged = _merge_template_into_design_data(
            merged,
            envelope.model_dump(mode="json"),
            collection_key=collection_key,
        )

    if metadata is not None:
        root_metadata = merged.get("metadata")
        merged["metadata"] = {
            **(dict(root_metadata) if isinstance(root_metadata, Mapping) else {}),
            **metadata,
        }

    return await plugin.save_design(experiment_id, merged, schema_version=schema_version)


async def load_template_collection(
    plugin: _TemplatePlugin,
    experiment_id: int,
    *,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
) -> dict[str, BioTemplateEnvelope]:
    """Load all template envelopes from a plugin design-data record."""
    data = await _load_design_data(plugin, experiment_id)
    if data is None:
        return {}
    return extract_template_collection(data, collection_key=collection_key)


async def _load_design_data(plugin: _TemplatePlugin, experiment_id: int) -> Mapping[str, Any] | None:
    record = await plugin.load_design(experiment_id)
    if record is None:
        return None

    data = getattr(record, "data", None)
    if data is None and isinstance(record, Mapping):
        data = record.get("data")
    if not isinstance(data, Mapping):
        raise TemplateValidationError(
            "Loaded design data record does not contain a template mapping.",
            field="data",
            value=type(data).__name__,
        )
    return data


def _coerce_template_envelope(
    template: BioTemplate | BioTemplateEnvelope | Mapping[str, Any],
) -> BioTemplateEnvelope:
    if isinstance(template, BioTemplateEnvelope):
        return template
    if isinstance(template, BioTemplate):
        return template.to_envelope()
    if isinstance(template, Mapping):
        return BioTemplateEnvelope.model_validate(dict(template))
    raise TemplateValidationError(
        "Template collection entries must be templates or envelope mappings.",
        field="template",
        value=type(template).__name__,
    )


def _extract_template_payload(
    data: Mapping[str, Any],
    template_id: str,
    *,
    collection_key: str,
) -> Mapping[str, Any] | None:
    if data.get("template_id") == template_id:
        return data

    collection = data.get(collection_key)
    if isinstance(collection, Mapping):
        payload = collection.get(template_id)
        if payload is None:
            return None
        if not isinstance(payload, Mapping):
            raise TemplateValidationError(
                "Stored template collection entry must be a mapping.",
                field=f"{collection_key}.{template_id}",
                value=type(payload).__name__,
            )
        return payload
    return None


def _merge_template_into_design_data(
    existing: Mapping[str, Any] | None,
    envelope: dict[str, Any],
    *,
    collection_key: str,
) -> dict[str, Any]:
    template_id = envelope["template_id"]
    if existing is None:
        return {collection_key: {template_id: envelope}}

    collection: dict[str, Any] = {}
    existing_collection = existing.get(collection_key)
    if isinstance(existing_collection, Mapping):
        root = dict(existing)
        collection = dict(existing_collection)
    elif isinstance(existing.get("template_id"), str):
        root = {}
        collection[str(existing["template_id"])] = dict(existing)
    else:
        root = dict(existing)

    collection[template_id] = envelope
    root[collection_key] = collection
    return root
