"""qPCR plate biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate
from .plate_map import PLATE_DIMENSIONS, WellPlateFormat, assert_well_in_format

QpcrChemistry = Literal["sybr", "taqman", "probe", "evagreen", "other"]
QpcrControlKind = Literal["sample", "no-template", "no-rt", "positive", "standard", "calibrator"]


class QpcrSample(BioTemplate):
    """Sample definition for a qPCR plate."""

    template_id = "qpcr-sample"

    sample_id: str = Field(alias="sampleId")
    name: str | None = None
    group: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_sample(self) -> QpcrSample:
        if not self.sample_id:
            raise ValueError("qPCR sample id is required.")
        return self


class QpcrTarget(BioTemplate):
    """qPCR target, primer/probe assay, or gene marker."""

    template_id = "qpcr-target"

    id: str
    name: str
    assay_id: str | None = Field(default=None, alias="assayId")
    reporter: str | None = None
    quencher: str | None = None
    amplicon_bp: int | None = Field(default=None, alias="ampliconBp")
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_target(self) -> QpcrTarget:
        if not self.id:
            raise ValueError("qPCR target id is required.")
        if not self.name:
            raise ValueError("qPCR target name is required.")
        if self.amplicon_bp is not None and self.amplicon_bp <= 0:
            raise ValueError("qPCR target amplicon size must be positive.")
        return self


class QpcrReaction(BioTemplate):
    """Single qPCR well reaction assignment and optional result fields."""

    template_id = "qpcr-reaction"

    id: str
    well_id: str = Field(alias="wellId")
    sample_id: str | None = Field(default=None, alias="sampleId")
    target_id: str = Field(alias="targetId")
    replicate: int = 1
    control_kind: QpcrControlKind = Field(default="sample", alias="controlKind")
    cq: float | None = None
    quantity: float | None = None
    flags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_reaction(self) -> QpcrReaction:
        if not self.id:
            raise ValueError("qPCR reaction id is required.")
        if not self.well_id:
            raise ValueError("qPCR reaction well id is required.")
        if not self.target_id:
            raise ValueError("qPCR reaction target id is required.")
        if self.replicate < 1:
            raise ValueError("qPCR reaction replicate must be at least 1.")
        if self.cq is not None and self.cq < 0:
            raise ValueError("qPCR reaction Cq cannot be negative.")
        if self.quantity is not None and self.quantity < 0:
            raise ValueError("qPCR reaction quantity cannot be negative.")
        if self.control_kind == "sample" and not self.sample_id:
            raise ValueError("qPCR sample reactions require sampleId.")
        return self


class QpcrPlateTemplate(BioTemplate):
    """Versioned template for qPCR/ddPCR plate layouts, targets, and reactions."""

    template_id = "qpcr-plate"

    plate_id: str = Field(default="qpcr-plate-1", alias="plateId")
    format: WellPlateFormat = 96
    samples: list[QpcrSample]
    targets: list[QpcrTarget]
    reactions: list[QpcrReaction]
    instrument: str | None = None
    chemistry: QpcrChemistry = "sybr"
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        *,
        samples: Sequence[str | Mapping[str, Any] | QpcrSample],
        targets: Sequence[str | Mapping[str, Any] | QpcrTarget],
        format: WellPlateFormat = 96,
        replicates: int = 3,
        include_no_template_controls: bool = True,
        instrument: str | None = None,
        chemistry: QpcrChemistry = "sybr",
        metadata: dict[str, Any] | None = None,
    ) -> QpcrPlateTemplate:
        """Build a qPCR plate from sample names, target names, and replicate count."""
        if replicates < 1:
            raise ValueError("qPCR replicates must be at least 1.")

        sample_records = _coerce_samples(samples)
        target_records = _coerce_targets(targets)
        wells = _well_ids(format)
        reactions: list[QpcrReaction] = []
        well_index = 0

        for sample in sample_records:
            for target in target_records:
                for replicate in range(1, replicates + 1):
                    if well_index >= len(wells):
                        raise ValueError(f"qPCR plate format {format} does not have enough wells.")
                    well = wells[well_index]
                    reactions.append(
                        QpcrReaction(
                            id=f"{sample.sample_id}-{target.id}-r{replicate}",
                            wellId=well,
                            sampleId=sample.sample_id,
                            targetId=target.id,
                            replicate=replicate,
                        )
                    )
                    well_index += 1

        if include_no_template_controls:
            for target in target_records:
                if well_index >= len(wells):
                    raise ValueError(f"qPCR plate format {format} does not have enough wells.")
                well = wells[well_index]
                reactions.append(
                    QpcrReaction(
                        id=f"ntc-{target.id}",
                        wellId=well,
                        targetId=target.id,
                        replicate=1,
                        controlKind="no-template",
                    )
                )
                well_index += 1

        return cls(
            format=format,
            samples=sample_records,
            targets=target_records,
            reactions=reactions,
            instrument=instrument,
            chemistry=chemistry,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> QpcrPlateTemplate:
        if not self.samples:
            raise ValueError("QpcrPlateTemplate requires at least one sample.")
        if not self.targets:
            raise ValueError("QpcrPlateTemplate requires at least one target.")
        if not self.reactions:
            raise ValueError("QpcrPlateTemplate requires at least one reaction.")

        sample_ids = [sample.sample_id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("qPCR sample ids must be unique.")
        sample_id_set = set(sample_ids)

        target_ids = [target.id for target in self.targets]
        if len(target_ids) != len(set(target_ids)):
            raise ValueError("qPCR target ids must be unique.")
        target_id_set = set(target_ids)

        reaction_ids = [reaction.id for reaction in self.reactions]
        if len(reaction_ids) != len(set(reaction_ids)):
            raise ValueError("qPCR reaction ids must be unique.")

        well_ids = [reaction.well_id for reaction in self.reactions]
        if len(well_ids) != len(set(well_ids)):
            raise ValueError("qPCR reaction wells must be unique.")

        for reaction in self.reactions:
            assert_well_in_format(reaction.well_id, self.format)
            if reaction.sample_id is not None and reaction.sample_id not in sample_id_set:
                raise ValueError(f"qPCR reaction references unknown sample '{reaction.sample_id}'.")
            if reaction.target_id not in target_id_set:
                raise ValueError(f"qPCR reaction references unknown target '{reaction.target_id}'.")
        return self


def _coerce_samples(samples: Sequence[str | Mapping[str, Any] | QpcrSample]) -> list[QpcrSample]:
    records: list[QpcrSample] = []
    for index, sample in enumerate(samples):
        if isinstance(sample, QpcrSample):
            records.append(sample)
        elif isinstance(sample, str):
            records.append(QpcrSample(sampleId=_id_from_name(sample, f"sample-{index + 1}"), name=sample))
        else:
            records.append(QpcrSample.model_validate(dict(sample)))
    return records


def _coerce_targets(targets: Sequence[str | Mapping[str, Any] | QpcrTarget]) -> list[QpcrTarget]:
    records: list[QpcrTarget] = []
    for index, target in enumerate(targets):
        if isinstance(target, QpcrTarget):
            records.append(target)
        elif isinstance(target, str):
            records.append(QpcrTarget(id=_id_from_name(target, f"target-{index + 1}"), name=target))
        else:
            records.append(QpcrTarget.model_validate(dict(target)))
    return records


def _well_ids(format: int) -> list[str]:
    try:
        rows, cols = PLATE_DIMENSIONS[format]
    except KeyError as exc:
        raise ValueError(f"Unsupported plate format '{format}'.") from exc
    return [f"{_row_label(row)}{col}" for row in range(rows) for col in range(1, cols + 1)]


def _row_label(index: int) -> str:
    label = ""
    current = index
    while True:
        label = chr(ord("A") + (current % 26)) + label
        current = current // 26 - 1
        if current < 0:
            return label


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
