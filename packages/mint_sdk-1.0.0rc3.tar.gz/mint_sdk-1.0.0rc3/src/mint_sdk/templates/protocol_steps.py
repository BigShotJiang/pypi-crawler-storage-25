"""Protocol-steps biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

ProtocolStepType = Literal[
    "incubation",
    "wash",
    "addition",
    "measurement",
    "transfer",
    "centrifuge",
    "mix",
    "custom",
]
ProtocolStepStatus = Literal["pending", "in_progress", "completed", "failed", "skipped"]


class ProtocolStepRecord(BioTemplate):
    """Single protocol step compatible with the frontend ``ExperimentTimeline``."""

    template_id = "protocol-step"

    id: str
    type: ProtocolStepType = "custom"
    name: str
    description: str | None = None
    duration: float | None = None
    status: ProtocolStepStatus = "pending"
    parameters: dict[str, Any] = Field(default_factory=dict)
    order: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_step(self) -> "ProtocolStepRecord":
        if not self.id:
            raise ValueError("Protocol step id is required.")
        if not self.name:
            raise ValueError("Protocol step name is required.")
        if self.duration is not None and self.duration < 0:
            raise ValueError("Protocol step duration cannot be negative.")
        if self.order < 0:
            raise ValueError("Protocol step order cannot be negative.")
        return self


class ProtocolStepsTemplate(BioTemplate):
    """Versioned template for experiment protocols and run sheets."""

    template_id = "protocol-steps"

    steps: list[ProtocolStepRecord]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        steps: Sequence[str | Mapping[str, Any] | ProtocolStepRecord],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> "ProtocolStepsTemplate":
        """Build protocol steps from names or step dictionaries."""
        records: list[ProtocolStepRecord] = []
        for index, step in enumerate(steps):
            if isinstance(step, ProtocolStepRecord):
                records.append(step)
            elif isinstance(step, str):
                records.append(
                    ProtocolStepRecord(
                        id=_id_from_name(step, f"step-{index + 1}"),
                        name=step,
                        order=index,
                    )
                )
            else:
                payload = dict(step)
                name = str(payload.get("name") or f"Step {index + 1}")
                payload.setdefault("id", _id_from_name(name, f"step-{index + 1}"))
                payload.setdefault("order", index)
                records.append(ProtocolStepRecord.model_validate(payload))
        return cls(steps=records, metadata=metadata or {})

    @model_validator(mode="after")
    def _validate_template(self) -> "ProtocolStepsTemplate":
        if not self.steps:
            raise ValueError("ProtocolStepsTemplate requires at least one step.")

        step_ids = [step.id for step in self.steps]
        if len(step_ids) != len(set(step_ids)):
            raise ValueError("Protocol step ids must be unique.")
        orders = [step.order for step in self.steps]
        if len(orders) != len(set(orders)):
            raise ValueError("Protocol step orders must be unique.")
        self.steps = sorted(self.steps, key=lambda step: step.order)
        return self


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
