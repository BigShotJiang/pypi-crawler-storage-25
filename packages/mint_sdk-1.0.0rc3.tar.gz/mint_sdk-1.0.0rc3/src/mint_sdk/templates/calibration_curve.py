"""Calibration-curve biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

CalibrationModel = Literal[
    "linear",
    "linear-weighted-1-x",
    "linear-weighted-1-x2",
    "quadratic",
    "four-parameter-logistic",
]
CalibrationPointRole = Literal["blank", "standard", "qc", "unknown"]
CalibrationPointStatus = Literal["planned", "accepted", "rejected", "warning"]


class CalibrationAcceptance(BioTemplate):
    """Acceptance thresholds for calibration and QC review."""

    template_id = "calibration-acceptance"

    min_r_squared: float = Field(default=0.99, alias="minRSquared")
    standard_tolerance_percent: float = Field(default=15.0, alias="standardTolerancePercent")
    qc_tolerance_percent: float = Field(default=20.0, alias="qcTolerancePercent")
    require_blank: bool = Field(default=True, alias="requireBlank")
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_acceptance(self) -> CalibrationAcceptance:
        if not 0 <= self.min_r_squared <= 1:
            raise ValueError("Calibration minRSquared must be between 0 and 1.")
        if self.standard_tolerance_percent < 0:
            raise ValueError("Calibration standard tolerance cannot be negative.")
        if self.qc_tolerance_percent < 0:
            raise ValueError("Calibration QC tolerance cannot be negative.")
        return self


class CalibrationPoint(BioTemplate):
    """One blank, standard, QC, or unknown point in a calibration curve."""

    template_id = "calibration-point"

    id: str
    order: int
    role: CalibrationPointRole = "standard"
    level: str
    concentration: float
    unit: str
    expected_response: float | None = Field(default=None, alias="expectedResponse")
    response: float | None = None
    replicate: int = 1
    include: bool = True
    status: CalibrationPointStatus = "planned"
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_point(self) -> CalibrationPoint:
        if not self.id:
            raise ValueError("Calibration point id is required.")
        if self.order < 0:
            raise ValueError("Calibration point order cannot be negative.")
        if not self.level:
            raise ValueError("Calibration point level is required.")
        if not self.unit:
            raise ValueError("Calibration point unit is required.")
        if self.concentration < 0:
            raise ValueError("Calibration point concentration cannot be negative.")
        if self.role in {"standard", "qc"} and self.concentration <= 0:
            raise ValueError("Calibration standards and QCs require positive concentration.")
        if self.replicate < 1:
            raise ValueError("Calibration point replicate must be at least 1.")
        return self


class CalibrationCurveTemplate(BioTemplate):
    """Versioned template for standard curves, QC acceptance, and quantitative calibration."""

    template_id = "calibration-curve"

    analyte: str
    model: CalibrationModel = "linear"
    x_unit: str = Field(alias="xUnit")
    response_unit: str = Field(default="response", alias="responseUnit")
    points: list[CalibrationPoint]
    acceptance: CalibrationAcceptance = Field(default_factory=CalibrationAcceptance)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        concentrations: Sequence[float | Mapping[str, Any] | CalibrationPoint],
        *,
        analyte: str = "Analyte",
        unit: str = "uM",
        response_unit: str = "response",
        model: CalibrationModel = "linear",
        include_blank: bool = True,
        include_qc: bool = True,
        acceptance: Mapping[str, Any] | CalibrationAcceptance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CalibrationCurveTemplate:
        """Build a calibration curve from standard concentrations and optional QC rows."""
        points: list[CalibrationPoint] = []
        order = 1

        if include_blank:
            points.append(
                CalibrationPoint(
                    id="blank",
                    order=order,
                    role="blank",
                    level="Blank",
                    concentration=0,
                    unit=unit,
                )
            )
            order += 1

        standard_values: list[float] = []
        for index, concentration in enumerate(concentrations):
            if isinstance(concentration, CalibrationPoint):
                points.append(concentration)
                if concentration.role == "standard":
                    standard_values.append(concentration.concentration)
                order = max(order, concentration.order + 1)
                continue
            if isinstance(concentration, Mapping):
                point = _coerce_point(concentration, order=order, unit=unit, index=index)
                points.append(point)
                if point.role == "standard":
                    standard_values.append(point.concentration)
                order = max(order, point.order + 1)
                continue

            value = float(concentration)
            standard_values.append(value)
            points.append(
                CalibrationPoint(
                    id=f"std-{index + 1}",
                    order=order,
                    role="standard",
                    level=f"Standard {index + 1}",
                    concentration=value,
                    unit=unit,
                )
            )
            order += 1

        if include_qc and standard_values:
            positive_values = sorted(value for value in standard_values if value > 0)
            if positive_values:
                qc_values = [positive_values[0]]
                if positive_values[-1] != positive_values[0]:
                    qc_values.append(positive_values[-1])
                for qc_index, qc_value in enumerate(qc_values):
                    level = "QC low" if qc_index == 0 else "QC high"
                    points.append(
                        CalibrationPoint(
                            id=_slug(level, f"qc-{qc_index + 1}"),
                            order=order,
                            role="qc",
                            level=level,
                            concentration=qc_value,
                            unit=unit,
                        )
                    )
                    order += 1

        acceptance_model = (
            acceptance
            if isinstance(acceptance, CalibrationAcceptance)
            else CalibrationAcceptance.model_validate(
                {"requireBlank": include_blank} if acceptance is None else acceptance
            )
        )

        return cls(
            analyte=analyte,
            model=model,
            xUnit=unit,
            responseUnit=response_unit,
            points=points,
            acceptance=acceptance_model,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> CalibrationCurveTemplate:
        if not self.analyte:
            raise ValueError("CalibrationCurveTemplate analyte is required.")
        if not self.x_unit:
            raise ValueError("CalibrationCurveTemplate xUnit is required.")
        if not self.response_unit:
            raise ValueError("CalibrationCurveTemplate responseUnit is required.")
        if not self.points:
            raise ValueError("CalibrationCurveTemplate requires at least one point.")

        point_ids = [point.id for point in self.points]
        if len(point_ids) != len(set(point_ids)):
            raise ValueError("Calibration point ids must be unique.")

        orders = [point.order for point in self.points]
        if len(orders) != len(set(orders)):
            raise ValueError("Calibration point orders must be unique.")

        standard_count = sum(1 for point in self.points if point.role == "standard" and point.include)
        if standard_count < 2:
            raise ValueError("CalibrationCurveTemplate requires at least two included standards.")

        if self.acceptance.require_blank and not any(point.role == "blank" for point in self.points):
            raise ValueError("CalibrationCurveTemplate requires a blank point when requireBlank is true.")

        return self


def _coerce_point(
    point: Mapping[str, Any],
    *,
    order: int,
    unit: str,
    index: int,
) -> CalibrationPoint:
    payload = dict(point)
    role = str(payload.get("role") or "standard")
    if not payload.get("unit"):
        payload["unit"] = unit
    if payload.get("order") is None:
        payload["order"] = order
    if not payload.get("level"):
        payload["level"] = f"{role.title()} {index + 1}"
    if not payload.get("id"):
        payload["id"] = _slug(str(payload["level"]), f"{role}-{index + 1}")
    if "concentration" not in payload:
        raise ValueError("Calibration point concentration is required.")
    return CalibrationPoint.model_validate(payload)


def _slug(value: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or fallback
