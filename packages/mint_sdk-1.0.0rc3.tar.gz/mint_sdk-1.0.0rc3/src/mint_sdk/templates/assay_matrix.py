"""Assay-matrix biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

AssayFeatureType = Literal["metabolite", "protein", "gene", "cell", "compound", "readout", "other"]


def _slug(value: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or fallback


class AssaySample(BioTemplate):
    """Sample row in an assay matrix."""

    template_id = "assay-sample"

    sample_id: str = Field(alias="sampleId")
    name: str | None = None
    group: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_sample(self) -> "AssaySample":
        if not self.sample_id:
            raise ValueError("Sample id is required.")
        return self


class AssayFeature(BioTemplate):
    """Measured feature, analyte, marker, or readout."""

    template_id = "assay-feature"

    id: str
    name: str
    type: AssayFeatureType = "readout"
    unit: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AssayMeasurement(BioTemplate):
    """One sample-feature measurement in a sparse matrix."""

    template_id = "assay-measurement"

    sample_id: str = Field(alias="sampleId")
    feature_id: str = Field(alias="featureId")
    value: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AssayMatrixTemplate(BioTemplate):
    """Versioned sample-by-feature assay matrix template."""

    template_id = "assay-matrix"

    samples: list[AssaySample]
    features: list[AssayFeature]
    measurements: list[AssayMeasurement] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        *,
        samples: Sequence[str | AssaySample | dict[str, Any]],
        features: Sequence[str | AssayFeature | dict[str, Any]],
        values: Mapping[str, Mapping[str, float | None]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "AssayMatrixTemplate":
        """Build an assay matrix from sample and feature definitions."""
        sample_models: list[AssaySample] = []
        for index, sample in enumerate(samples):
            if isinstance(sample, AssaySample):
                sample_models.append(sample)
            elif isinstance(sample, dict):
                sample_models.append(AssaySample.model_validate(sample))
            else:
                sample_models.append(
                    AssaySample(
                        sampleId=_slug(sample, f"sample-{index + 1}"),
                        name=sample,
                    )
                )

        feature_models: list[AssayFeature] = []
        for index, feature in enumerate(features):
            if isinstance(feature, AssayFeature):
                feature_models.append(feature)
            elif isinstance(feature, dict):
                feature_models.append(AssayFeature.model_validate(feature))
            else:
                feature_models.append(
                    AssayFeature(
                        id=_slug(feature, f"feature-{index + 1}"),
                        name=feature,
                    )
                )

        sample_lookup = _sample_lookup(sample_models)
        feature_lookup = _feature_lookup(feature_models)
        measurements = [
            AssayMeasurement(
                sampleId=sample_lookup.get(sample_id, sample_id),
                featureId=feature_lookup.get(feature_id, feature_id),
                value=value,
            )
            for sample_id, feature_values in (values or {}).items()
            for feature_id, value in feature_values.items()
        ]

        return cls(
            samples=sample_models,
            features=feature_models,
            measurements=measurements,
            metadata=metadata or {},
        )

    @classmethod
    def from_rows(
        cls,
        rows: Sequence[Mapping[str, Any]],
        *,
        sample_id_key: str = "sample_id",
        feature_id_key: str = "feature_id",
        value_key: str = "value",
        feature_type: AssayFeatureType = "readout",
    ) -> "AssayMatrixTemplate":
        """Build a sparse assay matrix from long-form measurement rows."""
        samples: dict[str, AssaySample] = {}
        features: dict[str, AssayFeature] = {}
        measurements: list[AssayMeasurement] = []

        for row in rows:
            sample_id = str(row[sample_id_key])
            feature_id = str(row[feature_id_key])
            value = row.get(value_key)
            samples.setdefault(sample_id, AssaySample(sampleId=sample_id))
            features.setdefault(feature_id, AssayFeature(id=feature_id, name=feature_id, type=feature_type))
            measurements.append(
                AssayMeasurement(
                    sampleId=sample_id,
                    featureId=feature_id,
                    value=float(value) if value is not None else None,
                    metadata={
                        key: item
                        for key, item in row.items()
                        if key not in {sample_id_key, feature_id_key, value_key}
                    },
                )
            )

        return cls(samples=list(samples.values()), features=list(features.values()), measurements=measurements)

    @model_validator(mode="after")
    def _validate_template(self) -> "AssayMatrixTemplate":
        if not self.samples:
            raise ValueError("AssayMatrixTemplate requires at least one sample.")
        if not self.features:
            raise ValueError("AssayMatrixTemplate requires at least one feature.")

        sample_ids = [sample.sample_id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("Assay matrix sample ids must be unique.")
        sample_id_set = set(sample_ids)

        feature_ids = [feature.id for feature in self.features]
        if len(feature_ids) != len(set(feature_ids)):
            raise ValueError("Assay matrix feature ids must be unique.")
        feature_id_set = set(feature_ids)

        seen_measurements: set[tuple[str, str]] = set()
        for measurement in self.measurements:
            key = (measurement.sample_id, measurement.feature_id)
            if key in seen_measurements:
                raise ValueError(
                    f"Duplicate assay measurement for sample '{measurement.sample_id}' "
                    f"and feature '{measurement.feature_id}'."
                )
            seen_measurements.add(key)
            if measurement.sample_id not in sample_id_set:
                raise ValueError(f"Measurement references unknown sample '{measurement.sample_id}'.")
            if measurement.feature_id not in feature_id_set:
                raise ValueError(f"Measurement references unknown feature '{measurement.feature_id}'.")

        return self


def _sample_lookup(samples: Sequence[AssaySample]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for sample in samples:
        lookup.setdefault(sample.sample_id, sample.sample_id)
        if sample.name:
            lookup.setdefault(sample.name, sample.sample_id)
            lookup.setdefault(_slug(sample.name, sample.sample_id), sample.sample_id)
    return lookup


def _feature_lookup(features: Sequence[AssayFeature]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for feature in features:
        lookup.setdefault(feature.id, feature.id)
        lookup.setdefault(feature.name, feature.id)
        lookup.setdefault(_slug(feature.name, feature.id), feature.id)
    return lookup
