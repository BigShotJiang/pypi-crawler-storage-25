"""Plate-map biology template models."""

from __future__ import annotations

import re
from collections.abc import Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

WellPlateFormat = Literal[6, 12, 24, 48, 54, 96, 384]
WellState = Literal["empty", "filled", "selected", "disabled"]

PLATE_DIMENSIONS: dict[int, tuple[int, int]] = {
    6: (2, 3),
    12: (3, 4),
    24: (4, 6),
    48: (6, 8),
    54: (6, 9),
    96: (8, 12),
    384: (16, 24),
}

WELL_ID_RE = re.compile(r"^([A-Z]+)([1-9][0-9]*)$")
DEFAULT_SAMPLE_COLORS = [
    "#3B82F6",
    "#10B981",
    "#EF4444",
    "#F59E0B",
    "#8B5CF6",
    "#F97316",
    "#06B6D4",
    "#14B8A6",
    "#6B7280",
]


def well_position(well_id: str) -> tuple[int, int]:
    """Return zero-based row and column indexes for a standard well id."""
    match = WELL_ID_RE.match(well_id.upper())
    if match is None:
        raise ValueError(f"Invalid well id '{well_id}'. Use row-letter notation such as A1.")

    row_label, col_label = match.groups()
    row = 0
    for char in row_label:
        row = row * 26 + (ord(char) - ord("A") + 1)
    return row - 1, int(col_label) - 1


def assert_well_in_format(well_id: str, plate_format: int) -> tuple[int, int]:
    """Validate a well id for a plate format and return its indexes."""
    row, col = well_position(well_id)
    try:
        rows, cols = PLATE_DIMENSIONS[plate_format]
    except KeyError as exc:
        raise ValueError(f"Unsupported plate format '{plate_format}'.") from exc
    if row < 0 or col < 0 or row >= rows or col >= cols:
        raise ValueError(f"Well '{well_id}' is outside a {plate_format}-well plate.")
    return row, col


def _sample_id_from_name(name: str, index: int) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or f"sample-{index + 1}"


class Well(BioTemplate):
    """Component-compatible well payload."""

    template_id = "well"

    id: str
    row: int | None = None
    col: int | None = None
    state: WellState = "empty"
    sample_type: str | None = Field(default=None, alias="sampleType")
    value: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_well(self) -> "Well":
        row, col = well_position(self.id)
        if self.row is None:
            self.row = row
        if self.col is None:
            self.col = col
        if self.row < 0 or self.col < 0:
            raise ValueError("Well row and column indexes must be non-negative.")
        return self


class SampleDefinition(BioTemplate):
    """Sample definition compatible with the frontend SampleType shape."""

    template_id = "sample-definition"

    id: str
    name: str
    color: str | None = None
    count: int | None = None
    description: str | None = None


class PlateMap(BioTemplate):
    """Single plate layout with component-compatible well data."""

    template_id = "plate"

    id: str
    name: str
    format: WellPlateFormat
    wells: dict[str, Well] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_plate(self) -> "PlateMap":
        for key, well in self.wells.items():
            if key != well.id:
                raise ValueError(f"Well key '{key}' does not match well id '{well.id}'.")
            row, col = assert_well_in_format(well.id, self.format)
            if well.row != row or well.col != col:
                raise ValueError(f"Well '{well.id}' row/col does not match its id.")
        return self


class PlateMapTemplate(BioTemplate):
    """Versioned template for one or more plate maps."""

    template_id = "plate-map"

    plates: list[PlateMap]
    samples: list[SampleDefinition] = Field(default_factory=list)
    active_plate_id: str | None = Field(default=None, alias="activePlateId")
    selected_wells: list[str] = Field(default_factory=list, alias="selectedWells")
    active_sample_id: str | None = Field(default=None, alias="activeSampleId")

    @classmethod
    def create(
        cls,
        *,
        name: str = "Plate 1",
        format: WellPlateFormat = 96,
        id: str = "plate-1",
        samples: Sequence[str | SampleDefinition | dict[str, Any]] | None = None,
    ) -> "PlateMapTemplate":
        """Create an empty plate-map template with optional sample definitions."""
        sample_definitions: list[SampleDefinition] = []
        for index, sample in enumerate(samples or []):
            if isinstance(sample, SampleDefinition):
                sample_definitions.append(sample)
            elif isinstance(sample, str):
                sample_definitions.append(
                    SampleDefinition(
                        id=_sample_id_from_name(sample, index),
                        name=sample,
                        color=DEFAULT_SAMPLE_COLORS[index % len(DEFAULT_SAMPLE_COLORS)],
                    )
                )
            else:
                sample_definitions.append(SampleDefinition.model_validate(sample))

        return cls(
            plates=[PlateMap(id=id, name=name, format=format, wells={})],
            samples=sample_definitions,
            activePlateId=id,
            selectedWells=[],
        )

    @classmethod
    def create_96_well(
        cls,
        *,
        name: str = "Plate 1",
        id: str = "plate-1",
        samples: Sequence[str | SampleDefinition | dict[str, Any]] | None = None,
    ) -> "PlateMapTemplate":
        """Create an empty 96-well plate-map template."""
        return cls.create(name=name, format=96, id=id, samples=samples)

    @model_validator(mode="after")
    def _validate_template(self) -> "PlateMapTemplate":
        if not self.plates:
            raise ValueError("PlateMapTemplate requires at least one plate.")

        plate_ids = [plate.id for plate in self.plates]
        if len(plate_ids) != len(set(plate_ids)):
            raise ValueError("Plate ids must be unique.")

        sample_ids = [sample.id for sample in self.samples]
        if len(sample_ids) != len(set(sample_ids)):
            raise ValueError("Sample ids must be unique.")
        sample_id_set = set(sample_ids)

        if self.active_plate_id is None:
            self.active_plate_id = self.plates[0].id
        elif self.active_plate_id not in plate_ids:
            raise ValueError(f"Unknown active plate id '{self.active_plate_id}'.")

        if self.active_sample_id is not None and self.active_sample_id not in sample_id_set:
            raise ValueError(f"Unknown active sample id '{self.active_sample_id}'.")

        for selected in self.selected_wells:
            well_position(selected)

        for plate in self.plates:
            for well in plate.wells.values():
                if well.sample_type is not None and well.sample_type not in sample_id_set:
                    raise ValueError(f"Well '{well.id}' references unknown sample '{well.sample_type}'.")

        return self
