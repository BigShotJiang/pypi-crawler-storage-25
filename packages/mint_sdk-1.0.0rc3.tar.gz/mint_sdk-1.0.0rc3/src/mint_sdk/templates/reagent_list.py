"""Reagent-list biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

ReagentKind = Literal[
    "compound",
    "antibody",
    "primer",
    "enzyme",
    "buffer",
    "media",
    "kit",
    "reagent",
    "other",
]
StorageCondition = Literal["RT", "4C", "-20C", "-80C"]


class ReagentRecord(BioTemplate):
    """Single reagent row compatible with the frontend ``ReagentList`` component."""

    template_id = "reagent-record"

    id: str
    name: str
    kind: ReagentKind = "reagent"
    catalog_number: str | None = Field(default=None, alias="catalogNumber")
    lot_number: str | None = Field(default=None, alias="lotNumber")
    expiry_date: str | None = Field(default=None, alias="expiryDate")
    storage_condition: StorageCondition | None = Field(default=None, alias="storageCondition")
    location: str | None = None
    stock_level: float | None = Field(default=None, alias="stockLevel")
    stock_unit: str | None = Field(default=None, alias="stockUnit")
    supplier: str | None = None
    url: str | None = None
    concentration: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_reagent(self) -> "ReagentRecord":
        if not self.id:
            raise ValueError("Reagent id is required.")
        if not self.name:
            raise ValueError("Reagent name is required.")
        if self.stock_level is not None and self.stock_level < 0:
            raise ValueError("Reagent stock level cannot be negative.")
        return self


class ReagentListTemplate(BioTemplate):
    """Versioned template for experiment reagents, lots, locations, and stocks."""

    template_id = "reagent-list"

    reagents: list[ReagentRecord]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        reagents: Sequence[str | Mapping[str, Any] | ReagentRecord],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> "ReagentListTemplate":
        """Build a reagent list from names or reagent dictionaries."""
        records: list[ReagentRecord] = []
        for index, reagent in enumerate(reagents):
            if isinstance(reagent, ReagentRecord):
                records.append(reagent)
            elif isinstance(reagent, str):
                records.append(
                    ReagentRecord(
                        id=_id_from_name(reagent, f"reagent-{index + 1}"),
                        name=reagent,
                    )
                )
            else:
                records.append(ReagentRecord.model_validate(dict(reagent)))
        return cls(reagents=records, metadata=metadata or {})

    @model_validator(mode="after")
    def _validate_template(self) -> "ReagentListTemplate":
        if not self.reagents:
            raise ValueError("ReagentListTemplate requires at least one reagent.")
        reagent_ids = [reagent.id for reagent in self.reagents]
        if len(reagent_ids) != len(set(reagent_ids)):
            raise ValueError("Reagent ids must be unique.")
        return self


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
