"""Sample-preparation biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

SamplePrepStepType = Literal[
    "extraction",
    "dilution",
    "normalization",
    "transfer",
    "incubation",
    "centrifugation",
    "cleanup",
    "digestion",
    "labeling",
    "other",
]
SamplePrepStatus = Literal["planned", "in-progress", "completed", "failed", "skipped"]


class SamplePrepStep(BioTemplate):
    """One ordered sample-preparation action."""

    template_id = "sample-prep-step"

    id: str
    order: int
    type: SamplePrepStepType = "extraction"
    name: str
    source_sample_id: str | None = Field(default=None, alias="sourceSampleId")
    source_plate_id: str | None = Field(default=None, alias="sourcePlateId")
    source_well_id: str | None = Field(default=None, alias="sourceWellId")
    destination_sample_id: str | None = Field(default=None, alias="destinationSampleId")
    destination_plate_id: str | None = Field(default=None, alias="destinationPlateId")
    destination_well_id: str | None = Field(default=None, alias="destinationWellId")
    reagent_id: str | None = Field(default=None, alias="reagentId")
    input_volume: float | None = Field(default=None, alias="inputVolume")
    output_volume: float | None = Field(default=None, alias="outputVolume")
    volume_unit: str = Field(default="uL", alias="volumeUnit")
    duration_min: float | None = Field(default=None, alias="durationMin")
    status: SamplePrepStatus = "planned"
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_step(self) -> SamplePrepStep:
        if not self.id:
            raise ValueError("Sample-prep step id is required.")
        if self.order < 0:
            raise ValueError("Sample-prep step order cannot be negative.")
        if not self.name:
            raise ValueError("Sample-prep step name is required.")
        if not self.volume_unit:
            raise ValueError("Sample-prep step volumeUnit is required.")
        if self.input_volume is not None and self.input_volume < 0:
            raise ValueError("Sample-prep input volume cannot be negative.")
        if self.output_volume is not None and self.output_volume < 0:
            raise ValueError("Sample-prep output volume cannot be negative.")
        if self.duration_min is not None and self.duration_min < 0:
            raise ValueError("Sample-prep duration cannot be negative.")
        if not any([self.source_sample_id, self.destination_sample_id, self.reagent_id]):
            raise ValueError("Sample-prep step requires a source sample, destination sample, or reagent.")
        return self


class SamplePrepTemplate(BioTemplate):
    """Versioned template for extraction, dilution, normalization, and transfer steps."""

    template_id = "sample-prep"

    protocol_name: str = Field(default="Sample preparation", alias="protocolName")
    steps: list[SamplePrepStep]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        samples: Sequence[str | Mapping[str, Any] | SamplePrepStep],
        *,
        prep_type: SamplePrepStepType = "extraction",
        protocol_name: str = "Sample preparation",
        volume_unit: str = "uL",
        input_volume: float | None = None,
        output_volume: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SamplePrepTemplate:
        """Build sample-preparation steps from sample names or partial step records."""
        steps: list[SamplePrepStep] = []
        order = 1

        for index, sample in enumerate(samples):
            if isinstance(sample, SamplePrepStep):
                steps.append(sample)
                order = max(order, sample.order + 1)
                continue
            if isinstance(sample, Mapping):
                step = _coerce_step(
                    sample,
                    order=order,
                    prep_type=prep_type,
                    volume_unit=volume_unit,
                    index=index,
                )
                steps.append(step)
                order = max(order, step.order + 1)
                continue

            source_sample_id = _slug(sample, f"sample-{index + 1}")
            steps.append(
                SamplePrepStep(
                    id=f"{source_sample_id}-prep",
                    order=order,
                    type=prep_type,
                    name=f"Prepare {sample}",
                    sourceSampleId=source_sample_id,
                    destinationSampleId=f"{source_sample_id}-prepared",
                    inputVolume=input_volume,
                    outputVolume=output_volume,
                    volumeUnit=volume_unit,
                )
            )
            order += 1

        return cls(
            protocolName=protocol_name,
            steps=steps,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> SamplePrepTemplate:
        if not self.protocol_name:
            raise ValueError("SamplePrepTemplate protocolName is required.")
        if not self.steps:
            raise ValueError("SamplePrepTemplate requires at least one step.")

        step_ids = [step.id for step in self.steps]
        if len(step_ids) != len(set(step_ids)):
            raise ValueError("Sample-prep step ids must be unique.")

        orders = [step.order for step in self.steps]
        if len(orders) != len(set(orders)):
            raise ValueError("Sample-prep step orders must be unique.")

        return self


def _coerce_step(
    step: Mapping[str, Any],
    *,
    order: int,
    prep_type: SamplePrepStepType,
    volume_unit: str,
    index: int,
) -> SamplePrepStep:
    payload = dict(step)
    step_type = str(payload.get("type") or prep_type)
    if not payload.get("type"):
        payload["type"] = step_type
    if payload.get("order") is None:
        payload["order"] = order
    sample_id = payload.get("sourceSampleId") or payload.get("source_sample_id")
    if not payload.get("name"):
        payload["name"] = f"Prepare {sample_id or index + 1}"
    if not payload.get("id"):
        payload["id"] = _slug(str(payload["name"]), f"{step_type}-{index + 1}")
    if not payload.get("volumeUnit"):
        payload["volumeUnit"] = payload.get("volume_unit") or volume_unit
    return SamplePrepStep.model_validate(payload)


def _slug(value: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or fallback
