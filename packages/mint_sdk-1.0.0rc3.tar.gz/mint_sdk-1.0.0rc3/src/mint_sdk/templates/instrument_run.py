"""Instrument-run queue biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate

InstrumentRunItemKind = Literal["sample", "blank", "qc", "standard", "calibration", "wash", "other"]
InstrumentRunStatus = Literal["planned", "queued", "running", "completed", "failed", "skipped"]


class InstrumentMethod(BioTemplate):
    """Instrument acquisition method used by one or more run-queue items."""

    template_id = "instrument-method"

    id: str
    name: str
    instrument: str | None = None
    acquisition_mode: str | None = Field(default=None, alias="acquisitionMode")
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_method(self) -> InstrumentMethod:
        if not self.id:
            raise ValueError("Instrument method id is required.")
        if not self.name:
            raise ValueError("Instrument method name is required.")
        return self


class InstrumentRunItem(BioTemplate):
    """One ordered sample, QC, blank, standard, or wash item in an instrument run."""

    template_id = "instrument-run-item"

    id: str
    order: int
    kind: InstrumentRunItemKind = "sample"
    sample_id: str | None = Field(default=None, alias="sampleId")
    name: str | None = None
    method_id: str = Field(alias="methodId")
    vial: str | None = None
    plate_id: str | None = Field(default=None, alias="plateId")
    well_id: str | None = Field(default=None, alias="wellId")
    injection_volume: float | None = Field(default=None, alias="injectionVolume")
    expected_duration_min: float | None = Field(default=None, alias="expectedDurationMin")
    status: InstrumentRunStatus = "planned"
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_item(self) -> InstrumentRunItem:
        if not self.id:
            raise ValueError("Instrument run item id is required.")
        if self.order < 0:
            raise ValueError("Instrument run item order cannot be negative.")
        if not self.method_id:
            raise ValueError("Instrument run item method id is required.")
        if self.kind == "sample" and not self.sample_id:
            raise ValueError("Sample run items require sampleId.")
        if self.injection_volume is not None and self.injection_volume < 0:
            raise ValueError("Instrument run injection volume cannot be negative.")
        if self.expected_duration_min is not None and self.expected_duration_min < 0:
            raise ValueError("Instrument run expected duration cannot be negative.")
        return self


class InstrumentRunTemplate(BioTemplate):
    """Versioned template for instrument sequence tables and acquisition queues."""

    template_id = "instrument-run"

    run_id: str = Field(default="run-1", alias="runId")
    instrument: str | None = None
    methods: list[InstrumentMethod]
    items: list[InstrumentRunItem]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        items: Sequence[str | Mapping[str, Any] | InstrumentRunItem],
        *,
        method: str | Mapping[str, Any] | InstrumentMethod = "Default method",
        instrument: str | None = None,
        include_blanks: bool = True,
        include_qc: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> InstrumentRunTemplate:
        """Build an instrument run queue from sample names and optional QC/blank rows."""
        method_model = _coerce_method(method, instrument=instrument)
        run_items: list[InstrumentRunItem] = []
        order = 1

        if include_blanks:
            run_items.append(
                InstrumentRunItem(
                    id="blank-start",
                    order=order,
                    kind="blank",
                    name="Blank start",
                    methodId=method_model.id,
                )
            )
            order += 1

        if include_qc:
            run_items.append(
                InstrumentRunItem(
                    id="qc-start",
                    order=order,
                    kind="qc",
                    name="QC start",
                    methodId=method_model.id,
                )
            )
            order += 1

        for index, item in enumerate(items):
            if isinstance(item, InstrumentRunItem):
                run_items.append(item)
                order = max(order, item.order + 1)
            elif isinstance(item, str):
                sample_id = _id_from_name(item, f"sample-{index + 1}")
                run_items.append(
                    InstrumentRunItem(
                        id=f"{sample_id}-run",
                        order=order,
                        kind="sample",
                        sampleId=sample_id,
                        name=item,
                        methodId=method_model.id,
                    )
                )
                order += 1
            else:
                run_items.append(
                    _coerce_run_item(
                        item,
                        method_id=method_model.id,
                        order=order,
                        index=index,
                    )
                )
                order = max(order, run_items[-1].order + 1)

        if include_qc:
            run_items.append(
                InstrumentRunItem(
                    id="qc-end",
                    order=order,
                    kind="qc",
                    name="QC end",
                    methodId=method_model.id,
                )
            )

        return cls(
            instrument=instrument,
            methods=[method_model],
            items=run_items,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> InstrumentRunTemplate:
        if not self.methods:
            raise ValueError("InstrumentRunTemplate requires at least one method.")
        if not self.items:
            raise ValueError("InstrumentRunTemplate requires at least one run item.")

        method_ids = [method.id for method in self.methods]
        if len(method_ids) != len(set(method_ids)):
            raise ValueError("Instrument method ids must be unique.")
        method_id_set = set(method_ids)

        item_ids = [item.id for item in self.items]
        if len(item_ids) != len(set(item_ids)):
            raise ValueError("Instrument run item ids must be unique.")

        orders = [item.order for item in self.items]
        if len(orders) != len(set(orders)):
            raise ValueError("Instrument run item orders must be unique.")

        for item in self.items:
            if item.method_id not in method_id_set:
                raise ValueError(f"Instrument run item references unknown method '{item.method_id}'.")
        return self


def _coerce_method(
    method: str | Mapping[str, Any] | InstrumentMethod,
    *,
    instrument: str | None,
) -> InstrumentMethod:
    if isinstance(method, InstrumentMethod):
        if method.instrument is None and instrument is not None:
            return method.model_copy(update={"instrument": instrument})
        return method
    if isinstance(method, str):
        return InstrumentMethod(
            id=_id_from_name(method, "method-1"),
            name=method,
            instrument=instrument,
        )
    payload = dict(method)
    name = str(payload.get("name") or payload.get("id") or "Default method")
    if not payload.get("id"):
        payload["id"] = _id_from_name(name, "method-1")
    if not payload.get("name"):
        payload["name"] = name
    if instrument is not None and not payload.get("instrument"):
        payload["instrument"] = instrument
    return InstrumentMethod.model_validate(payload)


def _coerce_run_item(
    item: Mapping[str, Any],
    *,
    method_id: str,
    order: int,
    index: int,
) -> InstrumentRunItem:
    payload = dict(item)
    kind = str(payload.get("kind") or "sample")
    if not payload.get("kind"):
        payload["kind"] = kind
    if payload.get("order") is None:
        payload["order"] = order
    if not (payload.get("methodId") or payload.get("method_id")):
        payload["methodId"] = method_id
    sample_id = payload.get("sampleId") or payload.get("sample_id")
    if kind == "sample" and not sample_id:
        sample_id = _id_from_name(
            str(payload.get("name") or f"Sample {index + 1}"),
            f"sample-{index + 1}",
        )
        payload["sampleId"] = sample_id
    label = payload.get("name") or sample_id or kind
    if not payload.get("id"):
        payload["id"] = _id_from_name(str(label), f"{kind}-{index + 1}")
    return InstrumentRunItem.model_validate(payload)


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
