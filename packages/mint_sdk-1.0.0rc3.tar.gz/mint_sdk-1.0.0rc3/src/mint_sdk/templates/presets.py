"""Ready-to-save biology template collections for common experiment designs."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from .assay_matrix import AssayMatrixTemplate
from .base import (
    TEMPLATE_COLLECTION_KEY,
    create_template_collection,
    extract_template_collection,
    normalize_template_lookup_key,
    save_template_collection,
)
from .calibration_curve import CalibrationCurveTemplate
from .dose_response import CompoundDoseSeries, DoseResponseTemplate
from .flow_cytometry_panel import FlowCytometryPanelTemplate
from .instrument_run import InstrumentMethod, InstrumentRunTemplate
from .plate_map import PlateMapTemplate, SampleDefinition, WellPlateFormat
from .protocol_steps import ProtocolStepsTemplate
from .qpcr_plate import QpcrPlateTemplate, QpcrSample, QpcrTarget
from .reagent_list import ReagentListTemplate
from .sample_prep import SamplePrepStepType, SamplePrepTemplate
from .sample_sheet import SampleRecord, SampleSheetTemplate


class BioTemplatePresetEntry(BaseModel):
    """Public metadata for one built-in biology template collection preset."""

    model_config = ConfigDict(frozen=True)

    name: str
    label: str
    category: str = "bio-template-preset"
    purpose: str
    templates: tuple[str, ...]
    aliases: tuple[str, ...] = Field(default_factory=tuple)
    python_import: str
    python_example: str
    frontend_import: str
    frontend_adapters: tuple[str, ...]
    components: tuple[str, ...]


_TEMPLATE_PRESETS: tuple[BioTemplatePresetEntry, ...] = (
    BioTemplatePresetEntry(
        name="wellplate-screen",
        label="Well-plate screen",
        purpose="Plate map, sample sheet, and dose-response payloads for plate-based screening assays.",
        templates=("plate-map", "sample-sheet", "dose-response"),
        aliases=(
            "wellplate",
            "well-plate screen",
            "drug screen",
            "plate screen",
            "dose response plate",
            "dose design",
            "dose planner",
        ),
        python_import="from mint_sdk.templates import create_wellplate_screen_collection, save_template_collection",
        python_example=(
            'create_wellplate_screen_collection(samples=["Control", "Treatment"], '
            'compounds={"Drug A": [10, 1, 0.1]}, unit="uM")'
        ),
        frontend_import=(
            "import { createWellPlateScreenCollection, toPlateMapEditorState, "
            "toTemplateDataFrame } from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toPlateMapEditorState", "toTemplateDataFrame", "toDoseConditions"),
        components=("PlateMapEditor", "WellPlate", "DataFrame", "DoseCalculator"),
    ),
    BioTemplatePresetEntry(
        name="qpcr-expression",
        label="qPCR expression",
        purpose="Sample metadata and qPCR/ddPCR plate layout for target-expression assays.",
        templates=("sample-sheet", "qpcr-plate"),
        aliases=("qpcr", "qPCR", "rt-qpcr", "ddpcr", "gene expression", "primer plate"),
        python_import="from mint_sdk.templates import create_qpcr_expression_collection, save_template_collection",
        python_example=(
            'create_qpcr_expression_collection(samples=["Control", "Treatment"], '
            'targets=["ACTB", "GAPDH"], replicates=3)'
        ),
        frontend_import=(
            "import { createQpcrExpressionCollection, toQpcrWellPlateWells, "
            "toTemplateDataFrame } from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toTemplateDataFrame", "toQpcrDataFrame", "toQpcrWellPlateWells"),
        components=("DataFrame", "WellPlate", "SampleSelector"),
    ),
    BioTemplatePresetEntry(
        name="lcms-batch",
        label="LC-MS batch",
        purpose="Sample metadata, instrument queue, and assay matrix payloads for omics acquisition batches.",
        templates=("sample-sheet", "instrument-run", "assay-matrix"),
        aliases=(
            "lcms",
            "lc-ms",
            "mass spec batch",
            "omics batch",
            "metabolomics",
            "metabolism",
            "metabolite profiling",
            "run queue",
            "sequence table",
        ),
        python_import="from mint_sdk.templates import create_lcms_batch_collection, save_template_collection",
        python_example=(
            'create_lcms_batch_collection(samples=["S001", "S002"], '
            'features=["Glucose", "Lactate"], instrument="LC-MS")'
        ),
        frontend_import=(
            "import { createLcmsBatchCollection, toAssayMatrixSampleOptions, "
            "toInstrumentRunDataFrame, toInstrumentRunScheduleEvents, "
            "toInstrumentRunSteps, toTemplateDataFrame } from "
            "'@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toInstrumentRunDataFrame",
            "toInstrumentRunSteps",
            "toInstrumentRunScheduleEvents",
            "toAssayMatrixDataFrame",
            "toAssayMatrixSampleOptions",
        ),
        components=("DataFrame", "ExperimentTimeline", "ScheduleCalendar", "ChartContainer", "SampleSelector"),
    ),
    BioTemplatePresetEntry(
        name="targeted-metabolomics",
        label="Targeted metabolomics",
        purpose=(
            "Sample metadata, extraction prep, internal standards, LC/GC-MS sequence, "
            "calibration curve, and metabolite readout matrix for quantitative metabolomics."
        ),
        templates=(
            "sample-sheet",
            "sample-prep",
            "reagent-list",
            "instrument-run",
            "calibration-curve",
            "assay-matrix",
        ),
        aliases=(
            "targeted metabolomics",
            "quantitative metabolomics",
            "lc-ms metabolomics",
            "gc-ms metabolomics",
            "targeted lcms",
            "metabolite quantitation",
            "mass spec quantitation",
            "internal standards",
            "peak area ratio",
        ),
        python_import=(
            "from mint_sdk.templates import create_targeted_metabolomics_collection, save_template_collection"
        ),
        python_example=(
            'create_targeted_metabolomics_collection(samples=["S001", "S002"], '
            'metabolites=["Glucose", "Lactate"], internal_standards=["13C Glucose"], '
            'instrument="LC-MS")'
        ),
        frontend_import=(
            "import { createTargetedMetabolomicsCollection, toInstrumentRunDataFrame, "
            "toCalibrationCurveDataFrame, toAssayMatrixDataFrame, toTemplateDataFrame } "
            "from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=(
            "toTemplateDataFrame",
            "toSamplePrepDataFrame",
            "toReagentDataFrame",
            "toInstrumentRunDataFrame",
            "toInstrumentRunSteps",
            "toInstrumentRunScheduleEvents",
            "toCalibrationCurveDataFrame",
            "toAssayMatrixDataFrame",
            "toAssayMatrixSampleOptions",
        ),
        components=(
            "DataFrame",
            "ReagentList",
            "ExperimentTimeline",
            "ScheduleCalendar",
            "FitPanel",
            "ChartContainer",
            "SampleSelector",
        ),
    ),
    BioTemplatePresetEntry(
        name="elisa-assay",
        label="ELISA assay",
        purpose="Plate layout, sample metadata, standard curve, and readout matrix for ELISA and plate-reader assays.",
        templates=("plate-map", "sample-sheet", "calibration-curve", "assay-matrix"),
        aliases=("elisa", "plate reader assay", "standard curve plate", "absorbance assay", "immunoassay"),
        python_import="from mint_sdk.templates import create_elisa_assay_collection, save_template_collection",
        python_example=(
            'create_elisa_assay_collection(samples=["Control", "Treatment"], '
            'analyte="IL-6", standard_concentrations=[1000, 100, 10, 1], unit="pg/mL")'
        ),
        frontend_import=(
            "import { createElisaAssayCollection, toPlateMapEditorState, "
            "toTemplateDataFrame } from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toPlateMapEditorState", "toTemplateDataFrame", "toCalibrationCurveDataFrame"),
        components=("PlateMapEditor", "WellPlate", "DataFrame", "FitPanel", "ChartContainer"),
    ),
    BioTemplatePresetEntry(
        name="flow-cytometry-assay",
        label="Flow cytometry assay",
        purpose=(
            "Sample metadata, antibody marker panel, compensation controls, and readout matrix "
            "for flow-cytometry assays."
        ),
        templates=("sample-sheet", "flow-cytometry-panel", "assay-matrix"),
        aliases=(
            "flow cytometry",
            "facs",
            "facs panel",
            "flow panel",
            "immune phenotyping",
            "immunophenotyping",
        ),
        python_import=(
            "from mint_sdk.templates import create_flow_cytometry_assay_collection, save_template_collection"
        ),
        python_example=(
            'create_flow_cytometry_assay_collection(samples=["Control", "Treatment"], '
            'markers=["CD3", "CD4", "CD8"], instrument="BD LSRFortessa")'
        ),
        frontend_import=(
            "import { createFlowCytometryAssayCollection, toFlowPanelDataFrame, "
            "toTemplateDataFrame } from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toTemplateDataFrame", "toFlowPanelDataFrame", "toAssayMatrixDataFrame"),
        components=("DataFrame", "SampleSelector", "ChartContainer"),
    ),
    BioTemplatePresetEntry(
        name="western-blot-assay",
        label="Western blot assay",
        purpose=(
            "Sample metadata, antibody/reagent list, protocol steps, and normalized protein "
            "readout matrix for Western blot assays."
        ),
        templates=("sample-sheet", "reagent-list", "protocol-steps", "assay-matrix"),
        aliases=("western blot", "western-blot", "immunoblot", "protein blot", "protein expression"),
        python_import="from mint_sdk.templates import create_western_blot_assay_collection, save_template_collection",
        python_example=(
            'create_western_blot_assay_collection(samples=["Control", "Treatment"], '
            'targets=["pERK", "ERK"], loading_control="ACTB")'
        ),
        frontend_import=(
            "import { createWesternBlotAssayCollection, toReagentDataFrame, "
            "toProtocolDataFrame, toTemplateDataFrame } from '@morscherlab/mint-sdk/templates'"
        ),
        frontend_adapters=("toTemplateDataFrame", "toReagentDataFrame", "toProtocolDataFrame"),
        components=("DataFrame", "ReagentList", "ExperimentTimeline", "SampleSelector"),
    ),
)


def list_template_presets() -> tuple[BioTemplatePresetEntry, ...]:
    """Return metadata for built-in multi-template collection presets."""
    return _TEMPLATE_PRESETS


def get_template_preset_info(name: str) -> BioTemplatePresetEntry | None:
    """Find a built-in template collection preset by id, label, or alias."""
    query = normalize_template_lookup_key(name)
    for entry in _TEMPLATE_PRESETS:
        identifiers = {
            normalize_template_lookup_key(entry.name),
            normalize_template_lookup_key(entry.label),
            *(normalize_template_lookup_key(alias) for alias in entry.aliases),
        }
        if query in identifiers:
            return entry
    return None


def require_template_preset_info(name: str) -> BioTemplatePresetEntry:
    """Return preset metadata or raise ``KeyError`` for an unknown preset."""
    entry = get_template_preset_info(name)
    if entry is None:
        raise KeyError(name)
    return entry


def create_template_preset_collection(name: str, **kwargs: Any) -> dict[str, Any]:
    """Create a ready-to-save template collection preset by id, label, or alias."""
    entry = require_template_preset_info(name)
    if entry.name == "wellplate-screen":
        return create_wellplate_screen_collection(**kwargs)
    if entry.name == "qpcr-expression":
        return create_qpcr_expression_collection(**kwargs)
    if entry.name == "lcms-batch":
        return create_lcms_batch_collection(**kwargs)
    if entry.name == "targeted-metabolomics":
        return create_targeted_metabolomics_collection(**kwargs)
    if entry.name == "elisa-assay":
        return create_elisa_assay_collection(**kwargs)
    if entry.name == "flow-cytometry-assay":
        return create_flow_cytometry_assay_collection(**kwargs)
    if entry.name == "western-blot-assay":
        return create_western_blot_assay_collection(**kwargs)
    raise KeyError(name)


async def save_template_preset_collection(
    plugin: Any,
    experiment_id: int,
    name: str,
    *,
    schema_version: str | None = None,
    merge: bool = True,
    collection_key: str = TEMPLATE_COLLECTION_KEY,
    **kwargs: Any,
) -> Any:
    """Create and save a built-in template collection preset in one call."""
    collection = create_template_preset_collection(name, **kwargs)
    metadata = collection.get("metadata") if isinstance(collection.get("metadata"), dict) else None
    return await save_template_collection(
        plugin,
        experiment_id,
        extract_template_collection(collection).values(),
        metadata=metadata,
        schema_version=schema_version,
        merge=merge,
        collection_key=collection_key,
    )


def create_wellplate_screen_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    compounds: Mapping[str, Sequence[float]] | Sequence[CompoundDoseSeries | Mapping[str, Any]] | None = None,
    unit: str = "uM",
    replicates: int = 3,
    plate_name: str = "Screen plate",
    plate_format: WellPlateFormat = 96,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save plate-map/sample-sheet/dose-response collection."""
    sample_records = _sample_records(samples or ("Control", "Treatment"))
    plate = PlateMapTemplate.create(
        name=plate_name,
        format=plate_format,
        samples=_plate_samples(sample_records),
    )
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    dose_response = DoseResponseTemplate.create(
        compounds or {"Compound A": [10, 1, 0.1]},
        unit=unit,
        replicates=replicates,
        layout=plate,
    )
    return create_template_collection(
        [plate, sample_sheet, dose_response],
        metadata={"preset": "wellplate-screen", **(metadata or {})},
    )


def create_qpcr_expression_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    targets: Sequence[str | QpcrTarget | Mapping[str, Any]] | None = None,
    replicates: int = 3,
    instrument: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save sample-sheet/qPCR-plate collection."""
    sample_records = _sample_records(samples or ("Control", "Treatment"))
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    qpcr = QpcrPlateTemplate.create(
        samples=_qpcr_samples(sample_records),
        targets=targets or ("ACTB", "GAPDH"),
        replicates=replicates,
        instrument=instrument,
    )
    return create_template_collection(
        [sample_sheet, qpcr],
        metadata={"preset": "qpcr-expression", **(metadata or {})},
    )


def create_lcms_batch_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    features: Sequence[str | Mapping[str, Any]] | None = None,
    instrument: str = "LC-MS",
    method: str | InstrumentMethod | Mapping[str, Any] = "Default method",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save sample-sheet/instrument-run/assay-matrix collection."""
    sample_records = _sample_records(samples or ("S001", "S002"))
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    instrument_run = InstrumentRunTemplate.create(
        [
            {"sampleId": sample.sample_id, "name": sample.name or sample.sample_id}
            for sample in sample_records
        ],
        method=method,
        instrument=instrument,
    )
    assay_matrix = AssayMatrixTemplate.create(
        samples=[
            {"sampleId": sample.sample_id, "name": sample.name, "metadata": sample.metadata}
            for sample in sample_records
        ],
        features=features or ("Glucose", "Lactate"),
    )
    return create_template_collection(
        [sample_sheet, instrument_run, assay_matrix],
        metadata={"preset": "lcms-batch", **(metadata or {})},
    )


def create_targeted_metabolomics_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    metabolites: Sequence[str | Mapping[str, Any]] | None = None,
    internal_standards: Sequence[str | Mapping[str, Any]] | None = None,
    standard_concentrations: Sequence[float] | None = None,
    concentration_unit: str = "uM",
    response_unit: str = "peak area ratio",
    calibration_analyte: str | None = None,
    instrument: str = "LC-MS",
    method: str | InstrumentMethod | Mapping[str, Any] = "Targeted metabolomics",
    prep_type: SamplePrepStepType = "extraction",
    output_volume: float | None = 50,
    include_qc: bool = True,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save targeted metabolomics LC/GC-MS collection."""
    sample_records = _sample_records(samples or ("S001", "S002"))
    metabolite_features = _metabolite_features(
        metabolites or ("Glucose", "Lactate", "Pyruvate"),
        response_unit=response_unit,
    )
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    sample_prep = SamplePrepTemplate.create(
        [sample.sample_id for sample in sample_records],
        prep_type=prep_type,
        protocol_name="Metabolomics sample preparation",
        output_volume=output_volume,
        metadata={"assay": "targeted-metabolomics"},
    )
    reagents = ReagentListTemplate.create(
        _internal_standard_reagents(
            internal_standards or ("Stable isotope internal standard mix",)
        ),
        metadata={"assay": "targeted-metabolomics"},
    )
    calibration_curve = CalibrationCurveTemplate.create(
        standard_concentrations or (0.1, 1, 10, 100),
        analyte=calibration_analyte or _first_feature_name(metabolite_features, "Metabolite panel"),
        unit=concentration_unit,
        response_unit=response_unit,
        model="linear-weighted-1-x",
        include_qc=include_qc,
        metadata={"assay": "targeted-metabolomics"},
    )
    instrument_run = InstrumentRunTemplate.create(
        _targeted_metabolomics_run_items(sample_records, calibration_curve, include_qc=include_qc),
        method=method,
        instrument=instrument,
        include_blanks=False,
        include_qc=False,
        metadata={"assay": "targeted-metabolomics"},
    )
    assay_matrix = AssayMatrixTemplate.create(
        samples=[
            {"sampleId": sample.sample_id, "name": sample.name, "group": sample.group, "metadata": sample.metadata}
            for sample in sample_records
        ],
        features=metabolite_features,
        metadata={"assay": "targeted-metabolomics", "responseUnit": response_unit},
    )
    return create_template_collection(
        [sample_sheet, sample_prep, reagents, instrument_run, calibration_curve, assay_matrix],
        metadata={"preset": "targeted-metabolomics", **(metadata or {})},
    )


def create_elisa_assay_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    analyte: str = "Analyte",
    standard_concentrations: Sequence[float] | None = None,
    unit: str = "pg/mL",
    response_unit: str = "OD450",
    plate_name: str = "ELISA plate",
    plate_format: WellPlateFormat = 96,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save plate/sample/calibration/readout collection for ELISA assays."""
    sample_records = _sample_records(samples or ("Control", "Treatment"))
    plate = PlateMapTemplate.create(
        name=plate_name,
        format=plate_format,
        samples=[
            SampleDefinition(id="blank", name="Blank"),
            SampleDefinition(id="standard", name="Standards"),
            SampleDefinition(id="qc", name="QC"),
            *_plate_samples(sample_records),
        ],
    )
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    calibration_curve = CalibrationCurveTemplate.create(
        standard_concentrations or (1000, 100, 10, 1),
        analyte=analyte,
        unit=unit,
        response_unit=response_unit,
        model="four-parameter-logistic",
    )
    assay_matrix = AssayMatrixTemplate.create(
        samples=[
            {"sampleId": sample.sample_id, "name": sample.name, "group": sample.group, "metadata": sample.metadata}
            for sample in sample_records
        ],
        features=[{"id": _id_from_name(analyte, "analyte"), "name": analyte, "type": "protein", "unit": response_unit}],
        metadata={"analyte": analyte, "responseUnit": response_unit},
    )
    return create_template_collection(
        [plate, sample_sheet, calibration_curve, assay_matrix],
        metadata={"preset": "elisa-assay", **(metadata or {})},
    )


def create_flow_cytometry_assay_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    markers: Sequence[str | Mapping[str, Any]] | None = None,
    features: Sequence[str | Mapping[str, Any]] | None = None,
    instrument: str = "Flow cytometer",
    include_default_controls: bool = True,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save sample/panel/readout collection for flow-cytometry assays."""
    sample_records = _sample_records(samples or ("Control", "Treatment"))
    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    flow_panel = FlowCytometryPanelTemplate.create(
        markers or ("CD3", "CD4", "CD8"),
        instrument=instrument,
        include_default_controls=include_default_controls,
    )
    assay_matrix = AssayMatrixTemplate.create(
        samples=[
            {"sampleId": sample.sample_id, "name": sample.name, "group": sample.group, "metadata": sample.metadata}
            for sample in sample_records
        ],
        features=features
        or [
            {
                "id": marker.id,
                "name": f"{marker.marker}+ cells",
                "type": "cell",
                "unit": "%",
                "metadata": {"marker": marker.marker, "fluorophore": marker.fluorophore},
            }
            for marker in flow_panel.markers
        ],
    )
    return create_template_collection(
        [sample_sheet, flow_panel, assay_matrix],
        metadata={"preset": "flow-cytometry-assay", **(metadata or {})},
    )


def create_western_blot_assay_collection(
    *,
    samples: Sequence[str | SampleRecord | Mapping[str, Any]] | None = None,
    targets: Sequence[str | Mapping[str, Any]] | None = None,
    loading_control: str = "ACTB",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create a ready-to-save sample/reagent/protocol/readout collection for Western blots."""
    sample_records = _sample_records(samples or ("Control", "Treatment"))
    target_names = [
        str(target.get("name", target.get("id", "Target protein")))
        if isinstance(target, Mapping)
        else str(target)
        for target in (targets or ("Target protein",))
    ]
    feature_names = [*target_names]
    if loading_control and loading_control not in feature_names:
        feature_names.append(loading_control)

    sample_sheet = SampleSheetTemplate.from_rows(_sample_rows(sample_records))
    reagents = ReagentListTemplate.create(
        [
            {
                "id": "primary-antibody",
                "name": "Primary antibody",
                "kind": "antibody",
                "storageCondition": "4C",
            },
            {
                "id": "secondary-antibody",
                "name": "Secondary antibody",
                "kind": "antibody",
                "storageCondition": "4C",
            },
            {"id": "lysis-buffer", "name": "Lysis buffer", "kind": "buffer", "storageCondition": "4C"},
            {"id": "blocking-buffer", "name": "Blocking buffer", "kind": "buffer", "storageCondition": "4C"},
            {"id": "wash-buffer", "name": "TBST wash buffer", "kind": "buffer", "storageCondition": "RT"},
            {"id": "substrate", "name": "Detection substrate", "kind": "reagent", "storageCondition": "4C"},
        ],
        metadata={"assay": "western-blot"},
    )
    protocol = ProtocolStepsTemplate.create(
        [
            {"id": "lyse-samples", "type": "addition", "name": "Lyse samples", "duration": 30},
            {"id": "run-gel", "type": "custom", "name": "Run SDS-PAGE", "duration": 90},
            {"id": "transfer", "type": "transfer", "name": "Transfer to membrane", "duration": 60},
            {"id": "block", "type": "incubation", "name": "Block membrane", "duration": 60},
            {
                "id": "primary-antibody",
                "type": "incubation",
                "name": "Primary antibody incubation",
                "duration": 960,
            },
            {
                "id": "secondary-antibody",
                "type": "incubation",
                "name": "Secondary antibody incubation",
                "duration": 60,
            },
            {"id": "detect", "type": "measurement", "name": "Detect and quantify bands", "duration": 30},
        ],
        metadata={"assay": "western-blot"},
    )
    assay_matrix = AssayMatrixTemplate.create(
        samples=[
            {"sampleId": sample.sample_id, "name": sample.name, "group": sample.group, "metadata": sample.metadata}
            for sample in sample_records
        ],
        features=[
            {
                "id": _id_from_name(feature, f"feature-{index + 1}"),
                "name": feature,
                "type": "protein",
                "unit": "relative intensity",
                "metadata": {"loadingControl": feature == loading_control},
            }
            for index, feature in enumerate(feature_names)
        ],
        metadata={"assay": "western-blot", "loadingControl": loading_control},
    )
    return create_template_collection(
        [sample_sheet, reagents, protocol, assay_matrix],
        metadata={"preset": "western-blot-assay", **(metadata or {})},
    )


def _sample_records(samples: Sequence[str | SampleRecord | Mapping[str, Any]]) -> list[SampleRecord]:
    records: list[SampleRecord] = []
    for index, sample in enumerate(samples):
        if isinstance(sample, SampleRecord):
            records.append(sample)
        elif isinstance(sample, str):
            records.append(
                SampleRecord(
                    sampleId=_id_from_name(sample, f"sample-{index + 1}"),
                    name=sample,
                    metadata={},
                )
            )
        else:
            records.append(SampleRecord.model_validate(dict(sample)))
    return records


def _sample_rows(samples: Sequence[SampleRecord]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for sample in samples:
        row = sample.model_dump(mode="json", by_alias=True, exclude_none=True)
        row.update(sample.metadata)
        rows.append(row)
    return rows


def _plate_samples(samples: Sequence[SampleRecord]) -> list[SampleDefinition]:
    return [
        SampleDefinition(id=sample.sample_id, name=sample.name or sample.sample_id)
        for sample in samples
    ]


def _qpcr_samples(samples: Sequence[SampleRecord]) -> list[QpcrSample]:
    return [
        QpcrSample(
            sampleId=sample.sample_id,
            name=sample.name,
            group=sample.group,
            metadata=sample.metadata,
        )
        for sample in samples
    ]


def _metabolite_features(
    metabolites: Sequence[str | Mapping[str, Any]],
    *,
    response_unit: str,
) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    for index, metabolite in enumerate(metabolites):
        if isinstance(metabolite, str):
            features.append(
                {
                    "id": _id_from_name(metabolite, f"metabolite-{index + 1}"),
                    "name": metabolite,
                    "type": "metabolite",
                    "unit": response_unit,
                    "metadata": {"quantitation": "targeted"},
                }
            )
            continue

        payload = dict(metabolite)
        name = str(payload.get("name") or payload.get("id") or f"Metabolite {index + 1}")
        payload.setdefault("id", _id_from_name(name, f"metabolite-{index + 1}"))
        payload.setdefault("name", name)
        payload.setdefault("type", "metabolite")
        payload.setdefault("unit", response_unit)
        metadata = dict(payload.get("metadata") or {})
        metadata.setdefault("quantitation", "targeted")
        payload["metadata"] = metadata
        features.append(payload)
    return features


def _internal_standard_reagents(
    internal_standards: Sequence[str | Mapping[str, Any]],
) -> list[dict[str, Any]]:
    reagents: list[dict[str, Any]] = []
    for index, standard in enumerate(internal_standards):
        if isinstance(standard, str):
            reagents.append(
                {
                    "id": _id_from_name(standard, f"internal-standard-{index + 1}"),
                    "name": standard,
                    "kind": "compound",
                    "metadata": {"role": "internal-standard"},
                }
            )
            continue

        payload = dict(standard)
        name = str(payload.get("name") or payload.get("id") or f"Internal standard {index + 1}")
        payload.setdefault("id", _id_from_name(name, f"internal-standard-{index + 1}"))
        payload.setdefault("name", name)
        payload.setdefault("kind", "compound")
        metadata = dict(payload.get("metadata") or {})
        metadata.setdefault("role", "internal-standard")
        payload["metadata"] = metadata
        reagents.append(payload)
    return reagents


def _targeted_metabolomics_run_items(
    samples: Sequence[SampleRecord],
    calibration_curve: CalibrationCurveTemplate,
    *,
    include_qc: bool,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for point in calibration_curve.points:
        if point.role == "qc" and not include_qc:
            continue
        if point.role not in {"blank", "standard", "qc"}:
            continue
        items.append(
            {
                "id": f"{point.id}-run",
                "kind": point.role,
                "name": point.level,
                "metadata": {
                    "concentration": point.concentration,
                    "unit": point.unit,
                    "role": point.role,
                },
            }
        )

    items.extend(
        {
            "sampleId": sample.sample_id,
            "name": sample.name or sample.sample_id,
            "kind": "sample",
        }
        for sample in samples
    )
    return items


def _first_feature_name(features: Sequence[Mapping[str, Any]], fallback: str) -> str:
    for feature in features:
        name = feature.get("name")
        if name:
            return str(name)
    return fallback


def _id_from_name(name: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or fallback
