"""Dose-response biology template models."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import Field, model_validator

from .base import BioTemplate
from .plate_map import PlateMapTemplate

ControlRole = Literal["vehicle", "positive", "negative", "blank", "baseline", "other"]


def _compound_id_from_name(name: str, index: int) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or f"compound-{index + 1}"


class CompoundDoseSeries(BioTemplate):
    """Concentration series for a compound."""

    template_id = "compound-dose-series"

    id: str
    name: str
    concentrations: list[float]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_series(self) -> "CompoundDoseSeries":
        if not self.concentrations:
            raise ValueError("Dose series requires at least one concentration.")
        if any(value < 0 for value in self.concentrations):
            raise ValueError("Dose concentrations cannot be negative.")
        self.concentrations = sorted(self.concentrations, reverse=True)
        return self


class ControlDefinition(BioTemplate):
    """First-class control or vehicle condition."""

    template_id = "control-definition"

    id: str
    name: str
    role: ControlRole = "other"
    vehicle: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class DoseResponseTemplate(BioTemplate):
    """Versioned template for dose-response experimental designs."""

    template_id = "dose-response"

    compounds: list[CompoundDoseSeries]
    unit: str
    replicates: int = 1
    controls: list[ControlDefinition] = Field(default_factory=list)
    layout: PlateMapTemplate | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def create(
        cls,
        compounds: Mapping[str, Sequence[float]] | Sequence[CompoundDoseSeries | dict[str, Any]],
        *,
        unit: str,
        replicates: int = 1,
        controls: Sequence[ControlDefinition | dict[str, Any]] | None = None,
        layout: PlateMapTemplate | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "DoseResponseTemplate":
        """Build a dose-response template from compound names and concentrations."""
        compound_models: list[CompoundDoseSeries] = []
        if isinstance(compounds, Mapping):
            for index, (name, concentrations) in enumerate(compounds.items()):
                compound_models.append(
                    CompoundDoseSeries(
                        id=_compound_id_from_name(name, index),
                        name=name,
                        concentrations=list(concentrations),
                    )
                )
        else:
            for compound in compounds:
                if isinstance(compound, CompoundDoseSeries):
                    compound_models.append(compound)
                else:
                    compound_models.append(CompoundDoseSeries.model_validate(compound))

        control_models = [
            control if isinstance(control, ControlDefinition) else ControlDefinition.model_validate(control)
            for control in controls or []
        ]
        return cls(
            compounds=compound_models,
            unit=unit,
            replicates=replicates,
            controls=control_models,
            layout=layout,
            metadata=metadata or {},
        )

    @model_validator(mode="after")
    def _validate_template(self) -> "DoseResponseTemplate":
        if not self.compounds:
            raise ValueError("DoseResponseTemplate requires at least one compound.")
        if not self.unit:
            raise ValueError("Dose unit is required.")
        if self.replicates < 1:
            raise ValueError("Replicate count must be at least 1.")

        compound_ids = [compound.id for compound in self.compounds]
        if len(compound_ids) != len(set(compound_ids)):
            raise ValueError("Compound ids must be unique.")

        control_ids = [control.id for control in self.controls]
        if len(control_ids) != len(set(control_ids)):
            raise ValueError("Control ids must be unique.")

        return self
