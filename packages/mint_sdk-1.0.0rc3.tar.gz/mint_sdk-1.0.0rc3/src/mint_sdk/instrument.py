"""Shared instrument status models for mass spectrometry plugins."""

from __future__ import annotations

from collections.abc import Iterable
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field


class InstrumentState(StrEnum):
    """Common instrument lifecycle states used by monitor plugins."""

    IDLE = "idle"
    RUNNING = "running"
    STANDBY = "standby"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    ERROR = "error"


class AlertLevel(StrEnum):
    """Common alert severity levels for instrument monitors."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class SampleInfo(BaseModel):
    """Minimal sample identity reported by an instrument monitor."""

    model_config = ConfigDict(extra="forbid")

    file_name: str
    sample_id: str | None = None
    sample_name: str | None = None
    vial_position: str | None = None
    injection_volume: float | None = None


class SequenceProgress(BaseModel):
    """Progress payload for an LC/MS or GC/MS acquisition sequence."""

    model_config = ConfigDict(extra="forbid")

    sequence_name: str | None = None
    current_sample: int
    total_samples: int
    elapsed_seconds: float = 0.0
    estimated_remaining_seconds: float | None = None
    avg_sample_seconds: float | None = None
    current_sample_name: str | None = None
    current_method: str | None = None
    estimated_finish_time: datetime | None = None
    sample_durations: list[float] = Field(default_factory=list)

    @property
    def percent_complete(self) -> float:
        """Return completion percentage clamped to the display-safe range."""

        if self.total_samples <= 0:
            return 0.0
        percent = (self.current_sample / self.total_samples) * 100.0
        return min(100.0, max(0.0, percent))

    @property
    def samples_remaining(self) -> int:
        """Return the number of samples still expected in the sequence."""

        return max(0, self.total_samples - self.current_sample)

    def estimate_remaining_seconds(self) -> float | None:
        """Return remaining seconds using explicit, average, or elapsed timing."""

        samples_left = self.samples_remaining
        if samples_left <= 0:
            return 0.0

        if self.estimated_remaining_seconds is not None and self.estimated_remaining_seconds > 0:
            return self.estimated_remaining_seconds

        avg = self.avg_sample_seconds
        if avg is None and self.sample_durations:
            avg = sum(self.sample_durations) / len(self.sample_durations)
        if avg is not None and avg > 0:
            return samples_left * avg

        if self.elapsed_seconds > 0 and self.current_sample > 0:
            return (self.elapsed_seconds / self.current_sample) * samples_left

        return None

    def estimate_finish_time(self, *, now: datetime | None = None) -> datetime | None:
        """Return ETA from explicit finish time or estimated remaining seconds."""

        if self.estimated_finish_time is not None:
            return self.estimated_finish_time

        remaining = self.estimate_remaining_seconds()
        if remaining is None or remaining <= 0:
            return None

        base = now or datetime.now(UTC)
        return base + timedelta(seconds=remaining)

    def with_estimates(self, *, now: datetime | None = None) -> Self:
        """Return a copy with missing average, remaining, and ETA fields filled."""

        avg = self.avg_sample_seconds
        if avg is None and self.sample_durations:
            avg = sum(self.sample_durations) / len(self.sample_durations)

        remaining = self.estimated_remaining_seconds
        if remaining is None:
            remaining = self.model_copy(update={"avg_sample_seconds": avg}).estimate_remaining_seconds()

        finish = self.estimated_finish_time
        if finish is None and remaining is not None and remaining > 0:
            finish = (now or datetime.now(UTC)) + timedelta(seconds=remaining)

        return self.model_copy(
            update={
                "avg_sample_seconds": _round_or_none(avg),
                "estimated_remaining_seconds": _round_or_none(remaining),
                "estimated_finish_time": finish,
            }
        )


class InstrumentStatus(BaseModel):
    """Common live status payload for an instrument monitor."""

    model_config = ConfigDict(extra="forbid")

    instrument_id: str
    state: InstrumentState
    active_method: str | None = None
    current_sample: SampleInfo | None = None
    sequence_progress: SequenceProgress | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    sequence_file: str | None = None
    sequence_row_index: int | None = None
    current_raw_file: str | None = None
    method_elapsed_pct: float | None = None

    @property
    def connected(self) -> bool:
        """Return whether the instrument is considered connected."""

        return self.state != InstrumentState.DISCONNECTED


class InstrumentAlertBody(BaseModel):
    """Structured instrument alert message for frontend rendering."""

    model_config = ConfigDict(extra="forbid")

    source: str | None = None
    event: str | None = None
    detail: str
    code: int | None = None
    raw_file: str | None = None


class InstrumentAlert(BaseModel):
    """Common alert payload emitted by an instrument monitor."""

    model_config = ConfigDict(extra="forbid")

    instrument_id: str
    level: AlertLevel
    rule: str
    body: InstrumentAlertBody
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    acknowledged: bool = False


def build_sequence_progress(
    *,
    current_sample: int,
    total_samples: int,
    sequence_name: str | None = None,
    started_at: datetime | None = None,
    elapsed_seconds: float | None = None,
    sample_durations: Iterable[float] | None = None,
    current_sample_name: str | None = None,
    current_method: str | None = None,
    now: datetime | None = None,
) -> SequenceProgress:
    """Create a ``SequenceProgress`` payload with average, remaining, and ETA."""

    base = now or datetime.now(UTC)
    durations = [value for duration in (sample_durations or ()) if (value := float(duration)) >= 0]
    elapsed = elapsed_seconds
    if elapsed is None:
        elapsed = _elapsed_since(started_at, base) if started_at is not None else 0.0
    elapsed = max(0.0, float(elapsed))

    avg: float | None = None
    if durations:
        avg = sum(durations) / len(durations)
    elif elapsed > 0 and current_sample > 0:
        avg = elapsed / current_sample

    samples_left = max(0, total_samples - current_sample)
    remaining = samples_left * avg if avg is not None and avg > 0 else None
    finish = base + timedelta(seconds=remaining) if remaining is not None and remaining > 0 else None

    return SequenceProgress(
        sequence_name=sequence_name,
        current_sample=current_sample,
        total_samples=total_samples,
        elapsed_seconds=round(elapsed, 1),
        estimated_remaining_seconds=_round_or_none(remaining),
        avg_sample_seconds=_round_or_none(avg),
        current_sample_name=current_sample_name,
        current_method=current_method,
        estimated_finish_time=finish,
        sample_durations=durations,
    )


def _round_or_none(value: float | None) -> float | None:
    return round(value, 1) if value is not None else None


def _elapsed_since(started_at: datetime, now: datetime) -> float:
    if started_at.tzinfo is None and now.tzinfo is not None:
        now = now.replace(tzinfo=None)
    elif started_at.tzinfo is not None and now.tzinfo is None:
        now = now.replace(tzinfo=started_at.tzinfo)
    return (now - started_at).total_seconds()
