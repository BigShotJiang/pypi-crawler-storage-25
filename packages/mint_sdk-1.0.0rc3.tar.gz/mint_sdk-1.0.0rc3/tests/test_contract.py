"""Tests for contract-first frontend client generation."""

from __future__ import annotations

import json
from pathlib import Path

from mint_sdk.add_command import HttpMethod, SettingType, cmd_add_endpoint, cmd_add_r_analysis, cmd_add_setting
from mint_sdk.contract import check_contract_files, generate_contract_files
from mint_sdk.init_command import _build_template_context, derive_names, write_files


def _make_scaffold(tmp_path: Path, *, frontend: bool = True) -> Path:
    context = _build_template_context(
        derive_names("My Analyzer"),
        {
            "description": "Desc",
            "type": "analysis",
            "include_frontend": "true" if frontend else "false",
        },
    )
    write_files(tmp_path, context, include_frontend=frontend)
    return tmp_path


def test_generate_contract_writes_json_and_typed_client(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    result = generate_contract_files(project)

    assert result.ok
    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    assert contract_path.exists()
    assert client_path.exists()

    contract = json.loads(contract_path.read_text())
    assert contract["plugin"]["name"] == "my-analyzer"
    assert contract["plugin"]["packageName"] == "mint-plugin-my-analyzer"
    assert contract["plugin"]["description"] == "Desc"
    assert contract["plugin"]["routesPrefix"] == "/my-analyzer"
    assert contract["plugin"]["apiPrefix"] == "/api/my-analyzer"
    assert contract["plugin"]["icon"]
    assert contract["plugin"]["color"] == ""
    assert contract["plugin"]["navItems"] == [
        {
            "path": "/",
            "label": "Dashboard",
            "id": "dashboard",
            "icon": "M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z",
            "description": "Desc",
        },
        {
            "path": "/analysis",
            "label": "Analysis",
            "id": "analysis",
            "icon": "M4 19h16M7 16V8m5 8V4m5 12v-6",
            "description": "Run analysis on your data",
        },
    ]
    assert contract["hash"].startswith("sha256:")
    assert [endpoint["name"] for endpoint in contract["endpoints"]] == ["health", "analyze"]

    analyze = contract["endpoints"][1]
    assert analyze["path"] == "/analyze/{experiment_id}"
    assert analyze["pathParams"] == [
        {"name": "experiment_id", "fieldName": "experimentId", "type": "number"}
    ]
    assert analyze["requestType"] == "AnalyzeRequest"
    assert analyze["responseType"] == "AnalyzeResponse"

    client = client_path.read_text()
    assert "buildPluginEndpointUrl" in client
    assert "getPluginPageSelectorItems" in client
    assert "usePluginSettings" in client
    assert "type PluginContract" in client
    assert "type PluginEndpointDefinition" in client
    assert "type PluginHttpMethod" in client
    assert "export const pluginContract = contractJson as PluginContract" in client
    assert "export const pluginContractHash = pluginContract.hash" in client
    assert "export const pluginApiPrefix = pluginContract.plugin.apiPrefix" in client
    assert "export const pluginRoutesPrefix = pluginContract.plugin.routesPrefix" in client
    assert "export const pluginNavItems = pluginContract.plugin.navItems ?? []" in client
    assert "export const pluginIcon = pluginContract.plugin.icon ?? ''" in client
    assert "export const pluginColor = pluginContract.plugin.color ?? ''" in client
    assert "export const pluginPageSelectorItems = getPluginPageSelectorItems(pluginContract)" in client
    assert (
        'export const generatedPluginEndpoints = ["health", "analyze"] '
        "as const satisfies readonly (keyof GeneratedPluginClient)[]"
    ) in client
    assert (
        "export type GeneratedPluginEndpointName = "
        "(typeof generatedPluginEndpoints)[number]"
    ) in client
    assert "export type GeneratedPluginEndpointPayload<N extends GeneratedPluginEndpointName> =" in client
    assert "export type GeneratedPluginEndpointDefinition = PluginEndpointDefinition & {" in client
    assert "export const generatedPluginEndpointDefinitions = {" in client
    assert "health: {" in client
    assert "analyze: {" in client
    assert "requestType: \"AnalyzeRequest\"" in client
    assert "responseType: \"AnalyzeResponse\"" in client
    assert "} satisfies Record<GeneratedPluginEndpointName, GeneratedPluginEndpointDefinition>" in client
    assert "export function getGeneratedPluginEndpoint<N extends GeneratedPluginEndpointName>(" in client
    assert "return generatedPluginEndpointDefinitions[name]" in client
    assert "export function hasGeneratedPluginEndpoint(" in client
    assert "name is GeneratedPluginEndpointName" in client
    assert "export function buildGeneratedPluginEndpointUrl<N extends GeneratedPluginEndpointName>(" in client
    assert "return buildPluginEndpointUrl(" in client
    assert "export function useGeneratedPluginContract()" in client
    assert "contractHash: pluginContractHash" in client
    assert "navItems: pluginNavItems" in client
    assert "pageSelectorItems: pluginPageSelectorItems" in client
    assert "icon: pluginIcon" in client
    assert "color: pluginColor" in client
    assert "endpointDefinitions: generatedPluginEndpointDefinitions" in client
    assert "getEndpoint: getGeneratedPluginEndpoint" in client
    assert "hasEndpoint: hasGeneratedPluginEndpoint" in client
    assert "buildEndpointUrl: buildGeneratedPluginEndpointUrl" in client
    assert "export interface AnalyzeRequest" in client
    assert "export interface AnalyzeResponse" in client
    assert "export type GeneratedPluginSettings = Record<string, unknown>" in client
    assert "export function useGeneratedPluginSettings()" in client
    assert "parameters?: Record<string, string>" in client
    assert "analyze: (params: { experimentId?: number; body: AnalyzeRequest }) => Promise<AnalyzeResponse>" in client
    assert "path: '/analyze/{experimentId}'" in client


def test_generate_contract_preserves_nav_item_ids(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    plugin_path = project / "src" / "mint_plugin_my_analyzer" / "plugin.py"
    plugin_path.write_text(
        plugin_path.read_text().replace(
            'id="dashboard",',
            'id="overview",',
            1,
        )
    )

    result = generate_contract_files(project)

    assert result.ok
    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert contract["plugin"]["navItems"][0]["id"] == "overview"


def test_generate_contract_types_plugin_settings(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_setting(
        path=str(project),
        name="threshold",
        field_type=SettingType.number,
        default="0.05",
        description="Significance threshold",
    )

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    client = client_path.read_text()

    assert contract["settings"]["modelName"] == "MyAnalyzerSettings"
    assert "export interface MyAnalyzerSettings" in client
    assert "threshold?: number" in client
    assert "export type GeneratedPluginSettings = MyAnalyzerSettings" in client
    assert "return usePluginSettings<GeneratedPluginSettings>()" in client


def test_generate_contract_emits_nested_settings_interfaces(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_setting(
        path=str(project),
        name="threshold",
        field_type=SettingType.number,
        default="0.05",
    )
    plugin_path = project / "src" / "mint_plugin_my_analyzer" / "plugin.py"
    content = plugin_path.read_text()
    content = content.replace(
        "\n\nclass MyAnalyzerSettings(BaseModel):",
        """

class AdvancedSettings(BaseModel):
    method: str = "bh"
    min_count: int = 3


class MyAnalyzerSettings(BaseModel):""",
    )
    content = content.replace(
        "class MyAnalyzerSettings(BaseModel):\n",
        (
            "class MyAnalyzerSettings(BaseModel):\n"
            "    advanced: AdvancedSettings = Field(default_factory=AdvancedSettings)\n"
        ),
    )
    plugin_path.write_text(content)

    generate_contract_files(project)

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client = client_path.read_text()
    assert "export interface AdvancedSettings" in client
    assert "method?: string" in client
    assert "min_count?: number" in client
    assert "advanced?: AdvancedSettings" in client
    assert "export type GeneratedPluginSettings = MyAnalyzerSettings" in client


def test_generate_contract_emits_nested_schema_interfaces(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    responses_path = project / "src" / "mint_plugin_my_analyzer" / "schemas" / "responses.py"
    responses_path.write_text(
        responses_path.read_text()
        + """


class AnalysisFeature(BaseModel):
    name: str
    score: float


class NestedAnalyzeResponse(BaseModel):
    features: list[AnalysisFeature]
    primary: AnalysisFeature | None = None
"""
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    router_content = router_path.read_text()
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse",
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse, NestedAnalyzeResponse",
    )
    router_content = router_content.rstrip() + """


@router.get("/nested", response_model=NestedAnalyzeResponse)
async def nested() -> NestedAnalyzeResponse:
    return NestedAnalyzeResponse(
        features=[AnalysisFeature(name="CD3", score=0.98)],
        primary=AnalysisFeature(name="CD3", score=0.98),
    )
"""
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse, NestedAnalyzeResponse",
        (
            "from mint_plugin_my_analyzer.schemas.responses import "
            "AnalysisFeature, AnalyzeResponse, NestedAnalyzeResponse"
        ),
    )
    router_path.write_text(router_content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    client = client_path.read_text()

    assert "AnalysisFeature" in contract["schemas"]
    assert "NestedAnalyzeResponse" in contract["schemas"]
    assert "export interface AnalysisFeature" in client
    assert "name: string" in client
    assert "score: number" in client
    assert "features: AnalysisFeature[]" in client
    assert "primary?: AnalysisFeature | null" in client
    assert "nested: () => Promise<NestedAnalyzeResponse>" in client


def test_generate_contract_supports_model_collection_request_and_response(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    responses_path = project / "src" / "mint_plugin_my_analyzer" / "schemas" / "responses.py"
    responses_path.write_text(
        responses_path.read_text()
        + """


class AnalysisFeature(BaseModel):
    name: str
    score: float
"""
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    router_content = router_path.read_text()
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse",
        "from mint_plugin_my_analyzer.schemas.responses import AnalysisFeature, AnalyzeResponse",
    )
    router_content = router_content.rstrip() + """


@router.post("/bulk-analyze", response_model=list[AnalysisFeature])
async def bulk_analyze(requests: list[AnalyzeRequest]) -> list[AnalysisFeature]:
    return [AnalysisFeature(name="CD3", score=0.98) for _ in requests]
"""
    router_path.write_text(router_content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    bulk = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "bulkAnalyze"][0]
    client = client_path.read_text()

    assert bulk["requestType"] == "AnalyzeRequest[]"
    assert bulk["responseType"] == "AnalysisFeature[]"
    assert "AnalysisFeature" in contract["schemas"]
    assert "bulkAnalyze: (body: AnalyzeRequest[]) => Promise<AnalysisFeature[]>" in client


def test_generate_contract_preserves_required_nullable_types(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    responses_path = project / "src" / "mint_plugin_my_analyzer" / "schemas" / "responses.py"
    responses_path.write_text(
        responses_path.read_text()
        + """


class NullableAnalyzeResponse(BaseModel):
    label: str | None
    score: float | None = None
"""
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    router_content = router_path.read_text()
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse",
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse, NullableAnalyzeResponse",
    )
    router_content = router_content.rstrip() + """


@router.get("/nullable", response_model=NullableAnalyzeResponse)
async def nullable() -> NullableAnalyzeResponse:
    return NullableAnalyzeResponse(label=None)
"""
    router_path.write_text(router_content)

    generate_contract_files(project)

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client = client_path.read_text()

    assert "label: string | null" in client
    assert "score?: number | null" in client
    assert "nullable: () => Promise<NullableAnalyzeResponse>" in client


def test_generate_contract_parenthesizes_array_union_items(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    responses_path = project / "src" / "mint_plugin_my_analyzer" / "schemas" / "responses.py"
    responses_path.write_text(
        "from typing import Literal\n\n"
        + responses_path.read_text()
        + """


class ArrayUnionAnalyzeResponse(BaseModel):
    values: list[str | int]
    labels: list[Literal["control", "treated"]]
"""
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    router_content = router_path.read_text()
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse",
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse, ArrayUnionAnalyzeResponse",
    )
    router_content = router_content.rstrip() + """


@router.get("/array-unions", response_model=ArrayUnionAnalyzeResponse)
async def array_unions() -> ArrayUnionAnalyzeResponse:
    return ArrayUnionAnalyzeResponse(values=["1", 2], labels=["control"])
"""
    router_path.write_text(router_content)

    generate_contract_files(project)

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client = client_path.read_text()

    assert "values: (string | number)[]" in client
    assert 'labels: ("control" | "treated")[]' in client


def test_generate_contract_quotes_non_identifier_schema_properties(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    responses_path = project / "src" / "mint_plugin_my_analyzer" / "schemas" / "responses.py"
    responses_path.write_text(
        responses_path.read_text().replace(
            "from pydantic import BaseModel",
            "from pydantic import BaseModel, Field",
        )
        + """


class AliasedAnalyzeResponse(BaseModel):
    sample_id: str = Field(alias="sample-id")
    run_metadata: dict[str, str] = Field(default_factory=dict, alias="run metadata")
"""
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    router_content = router_path.read_text()
    router_content = router_content.replace(
        "from mint_plugin_my_analyzer.schemas.responses import AnalyzeResponse",
        "from mint_plugin_my_analyzer.schemas.responses import AliasedAnalyzeResponse, AnalyzeResponse",
    )
    router_content = router_content.rstrip() + """


@router.get("/aliased", response_model=AliasedAnalyzeResponse)
async def aliased() -> dict[str, object]:
    return {"sample-id": "S1", "run metadata": {"batch": "B1"}}
"""
    router_path.write_text(router_content)

    generate_contract_files(project)

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client = client_path.read_text()

    assert '"sample-id": string' in client
    assert '"run metadata"?: Record<string, string>' in client
    assert "aliased: () => Promise<AliasedAnalyzeResponse>" in client


def test_generate_contract_makes_inferred_path_only_params_optional(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = content.rstrip() + """


@router.post("/prepare/{experiment_id}")
async def prepare_experiment(experiment_id: int):
    return {"experiment_id": experiment_id}
"""
    router_path.write_text(content)

    generate_contract_files(project)

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client = client_path.read_text()
    assert (
        "prepareExperiment: (params?: { experimentId?: number }) => Promise<unknown>"
        in client
    )


def test_contract_check_detects_current_and_stale_files(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    generate_contract_files(project)

    current = check_contract_files(project)
    assert current.ok

    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    client_path.write_text(client_path.read_text() + "\n// stale\n")

    stale = check_contract_files(project)
    assert not stale.ok
    assert "stale" in stale.detail


def test_generate_contract_supports_custom_output_dir(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=False)

    result = generate_contract_files(project, output_dir=Path("generated"))

    assert result.ok
    assert (project / "generated" / "mint-plugin.contract.json").exists()
    assert (project / "generated" / "mint-plugin.ts").exists()


def test_generate_contract_noops_for_backend_only_project_without_output(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=False)

    result = generate_contract_files(project)

    assert result.ok
    assert result.detail == "no frontend (nothing generated)"
    assert not (project / "frontend").exists()


def test_generate_contract_includes_r_analysis_endpoint(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_r_analysis(path=str(project), name="drp fit")

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    names = [endpoint["name"] for endpoint in contract["endpoints"]]
    assert "runDrpFit" in names
    assert "DrpFitRRequest" in contract["schemas"]
    assert "DrpFitRResponse" in contract["schemas"]
    assert (
        "runDrpFit: (params: { experimentId?: number; body: DrpFitRRequest }) => Promise<DrpFitRResponse>"
        in client_path.read_text()
    )


def test_generate_contract_includes_typed_query_params(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_endpoint(
        path=str(project),
        name="search",
        route_path="/search",
        method=HttpMethod.get,
        router="analysis",
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = content.replace(
        "async def search():\n    return {\"status\": \"ok\", \"endpoint\": \"search\"}",
        "async def search(q: str | None = None, limit: int = 100, include_archived: bool = False):\n"
        "    return {\"q\": q, \"limit\": limit, \"include_archived\": include_archived}",
    )
    router_path.write_text(content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    search = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "search"][0]
    assert search["queryParams"] == [
        {"name": "q", "fieldName": "q", "type": "string", "required": False},
        {"name": "limit", "fieldName": "limit", "type": "number", "required": False},
        {"name": "include_archived", "fieldName": "includeArchived", "type": "boolean", "required": False},
    ]

    client = client_path.read_text()
    assert "search: (params?: { q?: string; limit?: number; includeArchived?: boolean }) => Promise<unknown>" in client
    assert 'queryParams: [{ name: "q", fieldName: "q", type: "string", required: false }' in client
    assert '{ name: "include_archived", fieldName: "includeArchived", type: "boolean", required: false }]' in client


def test_generate_contract_marks_required_query_params(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_endpoint(
        path=str(project),
        name="search",
        route_path="/search",
        method=HttpMethod.get,
        router="analysis",
    )
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = content.replace(
        "async def search():\n    return {\"status\": \"ok\", \"endpoint\": \"search\"}",
        "async def search(q: str, limit: int = 100):\n"
        "    return {\"q\": q, \"limit\": limit}",
    )
    router_path.write_text(content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    search = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "search"][0]
    client = client_path.read_text()

    assert search["queryParams"] == [
        {"name": "q", "fieldName": "q", "type": "string", "required": True},
        {"name": "limit", "fieldName": "limit", "type": "number", "required": False},
    ]
    assert "search: (params: { q: string; limit?: number }) => Promise<unknown>" in client
    assert 'queryParams: [{ name: "q", fieldName: "q", type: "string", required: true }' in client


def test_generate_contract_types_literal_and_enum_query_params(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = "from enum import Enum\nfrom typing import Literal\n\n" + content
    content = content.replace(
        "\nrouter = APIRouter(tags=[\"analysis\"])",
        """

class Normalization(str, Enum):
    raw = "raw"
    zscore = "zscore"


router = APIRouter(tags=["analysis"])""",
    )
    content = content.rstrip() + """


@router.get("/choices")
async def choices(
    mode: Literal["fast", "accurate"],
    normalization: Normalization = Normalization.raw,
    replicate: Literal[1, 2] = 1,
):
    return {"mode": mode, "normalization": normalization, "replicate": replicate}
"""
    router_path.write_text(content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    choices = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "choices"][0]
    client = client_path.read_text()

    assert choices["queryParams"] == [
        {"name": "mode", "fieldName": "mode", "type": '"fast" | "accurate"', "required": True},
        {
            "name": "normalization",
            "fieldName": "normalization",
            "type": '"raw" | "zscore"',
            "required": False,
        },
        {"name": "replicate", "fieldName": "replicate", "type": "1 | 2", "required": False},
    ]
    assert (
        'choices: (params: { mode: "fast" | "accurate"; '
        'normalization?: "raw" | "zscore"; replicate?: 1 | 2 }) => Promise<unknown>'
    ) in client


def test_generate_contract_includes_post_body_and_query_params(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = content.replace(
        "async def analyze(experiment_id: int, request: AnalyzeRequest) -> AnalyzeResponse:",
        "async def analyze(\n"
        "    experiment_id: int,\n"
        "    request: AnalyzeRequest,\n"
        "    dry_run: bool = False,\n"
        ") -> AnalyzeResponse:",
    )
    router_path.write_text(content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    analyze = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "analyze"][0]
    client = client_path.read_text()

    assert analyze["queryParams"] == [
        {"name": "dry_run", "fieldName": "dryRun", "type": "boolean", "required": False}
    ]
    assert (
        "analyze: (params: { experimentId?: number; dryRun?: boolean; body: AnalyzeRequest }) "
        "=> Promise<AnalyzeResponse>"
    ) in client
    assert 'queryParams: [{ name: "dry_run", fieldName: "dryRun", type: "boolean", required: false }]' in client


def test_generate_contract_types_uuid_path_param_with_request_body(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    router_path = project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py"
    content = router_path.read_text()
    content = "from uuid import UUID\n\n" + content
    content = content.rstrip() + """


@router.patch("/instruments/{instrument_id}", response_model=AnalyzeResponse)
async def update_instrument(instrument_id: UUID, request: AnalyzeRequest) -> AnalyzeResponse:
    return AnalyzeResponse(status="ok", result={"instrument_id": str(instrument_id)})
"""
    router_path.write_text(content)

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    update_instrument = [
        endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "updateInstrument"
    ][0]
    client = client_path.read_text()

    assert update_instrument["pathParams"] == [
        {"name": "instrument_id", "fieldName": "instrumentId", "type": "string"}
    ]
    assert update_instrument["requestType"] == "AnalyzeRequest"
    assert (
        "updateInstrument: (params: { instrumentId: string; body: AnalyzeRequest }) "
        "=> Promise<AnalyzeResponse>"
    ) in client


def test_generate_contract_includes_delete_request_body(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_endpoint(
        path=str(project),
        name="purge",
        route_path="/purge",
        method=HttpMethod.delete,
        router="analysis",
        request_model="AnalyzeRequest",
    )

    generate_contract_files(project)

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    client_path = project / "frontend" / "src" / "generated" / "mint-plugin.ts"
    contract = json.loads(contract_path.read_text())
    purge = [endpoint for endpoint in contract["endpoints"] if endpoint["name"] == "purge"][0]
    client = client_path.read_text()

    assert purge["method"] == "delete"
    assert purge["requestType"] == "AnalyzeRequest"
    assert "purge: (body: AnalyzeRequest) => Promise<unknown>" in client
    assert "method: 'delete'" in client
    assert "hasBody: true" in client
