"""Tests for shared SDK permission helpers."""

from mint_sdk.permissions import (
    can_access_admin,
    can_access_plugin,
    can_access_policy,
    get_access_audience,
    has_all_permissions,
    has_any_permission,
    is_admin_user,
)


def test_admin_role_has_full_access() -> None:
    user = {"role": "admin"}

    assert is_admin_user(user)
    assert get_access_audience(user) == "admin"
    assert has_all_permissions(user, ["platform.configure"])
    assert can_access_admin(user)


def test_member_permissions_and_plugin_access() -> None:
    user = {
        "role": "member",
        "role_obj": {
            "slug": "member",
            "permissions": ["experiments.view", "plugins.configure"],
            "plugin_access": ["dose"],
        },
    }

    assert not is_admin_user(user)
    assert get_access_audience(user) == "user"
    assert has_all_permissions(user, ["experiments.view"])
    assert not has_all_permissions(user, ["platform.configure"])
    assert has_any_permission(user, ["platform.configure", "plugins.configure"])
    assert can_access_admin(user)
    assert can_access_plugin(user, "dose")
    assert not can_access_plugin(user, "reports")


def test_access_policy_evaluation() -> None:
    user = {
        "role": "member",
        "role_obj": {
            "slug": "member",
            "permissions": ["experiments.view"],
            "plugin_access": "all",
        },
    }

    assert can_access_policy(user, {"visibleFor": "user"})
    assert not can_access_policy(user, {"visibleFor": "admin"})
    assert can_access_policy(user, {"permissions": ["experiments.view"]})
    assert can_access_policy(user, {"anyPermissions": ["platform.configure", "experiments.view"]})
    assert not can_access_policy(user, {"requiresAdmin": True})
