"""Tests for platform-facing mint CLI commands."""

from __future__ import annotations

from unittest.mock import patch

from mint_sdk.cli import app
from typer.testing import CliRunner

runner = CliRunner()


class DummyExperiments:
    def __init__(self) -> None:
        self.updated: tuple[int, dict] | None = None
        self.created: dict | None = None
        self.data_calls: list[tuple[str, int]] = []

    def create(self, **fields):
        self.created = fields
        return {"id": 7, **fields}

    def update(self, experiment_id: int, **fields):
        self.updated = (experiment_id, fields)
        return {"id": experiment_id, **fields}

    def get_data_tree(self, experiment_id: int):
        self.data_calls.append(("tree", experiment_id))
        return {"tree": {"id": experiment_id}}

    def get_data_summary(self, experiment_id: int):
        self.data_calls.append(("summary", experiment_id))
        return {"summary": {"id": experiment_id}}

    def list_types(self):
        return [{"key": "drp", "label": "Dose Response", "description": "DRP"}]

    def next_seq(self, experiment_type: str):
        return {"experiment_type": experiment_type, "next_seq": 12, "code": "DRP-012"}


class DummyProjects:
    def __init__(self) -> None:
        self.list_kwargs: dict | None = None
        self.created: dict | None = None
        self.updated: tuple[int, dict] | None = None
        self.deleted: int | None = None

    def list(self, **kwargs):
        self.list_kwargs = kwargs
        return []

    def create(self, **fields):
        self.created = fields
        return {"id": 3, **fields}

    def update(self, project_id: int, **fields):
        self.updated = (project_id, fields)
        return {"id": project_id, **fields}

    def delete(self, project_id: int):
        self.deleted = project_id

    def experiments(self, project_id: int, **kwargs):
        return [{"id": 11, "name": "Exp", "experiment_type": "drp", "status": "planned"}]

    def members(self, project_id: int):
        return [{"user": {"username": "alice"}, "role": "owner", "status": "active"}]


class DummyClient:
    def __init__(self) -> None:
        self.experiments = DummyExperiments()
        self.projects = DummyProjects()
        self.closed = False

    def close(self) -> None:
        self.closed = True


def test_experiment_create_can_output_json() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.experiment_cmd.get_client", return_value=client):
        result = runner.invoke(app, ["experiment", "create", "Assay", "--type", "drp", "--json"])

    assert result.exit_code == 0, result.output
    assert client.experiments.created == {
        "name": "Assay",
        "experiment_type": "drp",
        "project_id": None,
        "notes": None,
    }
    assert '"name": "Assay"' in result.output
    assert client.closed


def test_experiment_update_passes_only_provided_fields() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.experiment_cmd.get_client", return_value=client):
        result = runner.invoke(app, ["experiment", "update", "7", "--status", "completed", "--notes", "done"])

    assert result.exit_code == 0, result.output
    assert client.experiments.updated == (7, {"status": "completed", "notes": "done"})
    assert "Updated experiment #7" in result.output


def test_experiment_update_rejects_empty_update() -> None:
    result = runner.invoke(app, ["experiment", "update", "7"])

    assert result.exit_code == 1
    assert "provide at least one field" in result.output


def test_experiment_data_supports_tree_view() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.experiment_cmd.get_client", return_value=client):
        result = runner.invoke(app, ["experiment", "data", "7", "--view", "tree"])

    assert result.exit_code == 0, result.output
    assert client.experiments.data_calls == [("tree", 7)]
    assert '"tree"' in result.output


def test_experiment_data_rejects_csv_tree_combination() -> None:
    result = runner.invoke(app, ["experiment", "data", "7", "--format", "csv", "--view", "tree"])

    assert result.exit_code == 1
    assert "csv can only be used" in result.output


def test_experiment_types_and_next_seq() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.experiment_cmd.get_client", return_value=client):
        types_result = runner.invoke(app, ["experiment", "types"])
        seq_result = runner.invoke(app, ["experiment", "next-seq", "drp"])

    assert types_result.exit_code == 0, types_result.output
    assert "Dose Response" in types_result.output
    assert seq_result.exit_code == 0, seq_result.output
    assert "DRP-012" in seq_result.output


def test_project_list_passes_mine_and_limit() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.project_cmd.get_client", return_value=client):
        result = runner.invoke(app, ["project", "list", "--mine", "--limit", "25"])

    assert result.exit_code == 0, result.output
    assert client.projects.list_kwargs == {
        "search": None,
        "status": None,
        "my_projects": True,
        "limit": 25,
    }


def test_project_create_update_delete() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.project_cmd.get_client", return_value=client):
        create_result = runner.invoke(app, ["project", "create", "Metabolomics", "--description", "Batch"])
        update_result = runner.invoke(app, ["project", "update", "3", "--status", "archived"])
        delete_result = runner.invoke(app, ["project", "delete", "3", "--yes"])

    assert create_result.exit_code == 0, create_result.output
    assert client.projects.created == {"name": "Metabolomics", "description": "Batch"}
    assert update_result.exit_code == 0, update_result.output
    assert client.projects.updated == (3, {"status": "archived"})
    assert delete_result.exit_code == 0, delete_result.output
    assert client.projects.deleted == 3


def test_project_update_rejects_empty_update() -> None:
    result = runner.invoke(app, ["project", "update", "3"])

    assert result.exit_code == 1
    assert "provide at least one field" in result.output


def test_project_experiments_and_members() -> None:
    client = DummyClient()
    with patch("mint_sdk.cli_commands.project_cmd.get_client", return_value=client):
        experiments_result = runner.invoke(app, ["project", "experiments", "3"])
        members_result = runner.invoke(app, ["project", "members", "3"])

    assert experiments_result.exit_code == 0, experiments_result.output
    assert "Exp" in experiments_result.output
    assert members_result.exit_code == 0, members_result.output
    assert "alice" in members_result.output
