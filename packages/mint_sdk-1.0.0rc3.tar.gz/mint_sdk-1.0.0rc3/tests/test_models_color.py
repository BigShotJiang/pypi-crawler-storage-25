"""Tests for the optional `color` field on PluginMetadata."""
from mint_sdk.models import PluginMetadata


def test_plugin_metadata_color_defaults_to_empty_string():
    meta = PluginMetadata(
        name="test",
        version="1.0.0",
        description="t",
        analysis_type="metabolomics",
        routes_prefix="/test",
    )
    assert meta.color == ""


def test_plugin_metadata_color_accepts_hex_string():
    meta = PluginMetadata(
        name="test",
        version="1.0.0",
        description="t",
        analysis_type="metabolomics",
        routes_prefix="/test",
        color="#0EA5E9",
    )
    assert meta.color == "#0EA5E9"
