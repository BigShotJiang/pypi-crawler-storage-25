"""Tests for biology data templates."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from mint_sdk import BioTemplatePackEntry as RootBioTemplatePackEntry
from mint_sdk import BioTemplatePresetEntry as RootBioTemplatePresetEntry
from mint_sdk import CalibrationCurveTemplate as RootCalibrationCurveTemplate
from mint_sdk import FlowCytometryPanelTemplate as RootFlowCytometryPanelTemplate
from mint_sdk import InstrumentRunTemplate as RootInstrumentRunTemplate
from mint_sdk import PlateMapTemplate as RootPlateMapTemplate
from mint_sdk import ProtocolStepsTemplate as RootProtocolStepsTemplate
from mint_sdk import QpcrPlateTemplate as RootQpcrPlateTemplate
from mint_sdk import ReagentListTemplate as RootReagentListTemplate
from mint_sdk import SamplePrepTemplate as RootSamplePrepTemplate
from mint_sdk import TimeCourseTemplate as RootTimeCourseTemplate
from mint_sdk import create_elisa_assay_collection as root_create_elisa_assay_collection
from mint_sdk import create_flow_cytometry_assay_collection as root_create_flow_cytometry_assay_collection
from mint_sdk import create_targeted_metabolomics_collection as root_create_targeted_metabolomics_collection
from mint_sdk import create_western_blot_assay_collection as root_create_western_blot_assay_collection
from mint_sdk import list_template_packs as root_list_template_packs
from mint_sdk import save_template_preset_collection as root_save_template_preset_collection
from mint_sdk.models import PluginMetadata
from mint_sdk.plugin import AnalysisPlugin
from mint_sdk.templates import (
    AssayMatrixTemplate,
    BioTemplatePackEntry,
    BioTemplatePresetEntry,
    CalibrationCurveTemplate,
    CalibrationPoint,
    ControlDefinition,
    DoseResponseTemplate,
    FlowCytometryPanelTemplate,
    InstrumentRunItem,
    InstrumentRunTemplate,
    PlateMap,
    PlateMapTemplate,
    ProtocolStepsTemplate,
    QpcrPlateTemplate,
    QpcrReaction,
    ReagentListTemplate,
    SampleDefinition,
    SamplePrepStep,
    SamplePrepTemplate,
    SampleSheetTemplate,
    TemplateValidationError,
    TimeCourseSample,
    TimeCourseTemplate,
    Well,
    create_elisa_assay_collection,
    create_flow_cytometry_assay_collection,
    create_lcms_batch_collection,
    create_qpcr_expression_collection,
    create_targeted_metabolomics_collection,
    create_template_collection,
    create_template_preset_collection,
    create_wellplate_screen_collection,
    create_western_blot_assay_collection,
    extract_template_collection,
    get_template_info,
    get_template_pack_info,
    get_template_preset_info,
    list_template_catalog,
    list_template_packs,
    list_template_presets,
    load_template,
    load_template_collection,
    require_template_info,
    require_template_pack_info,
    require_template_preset_info,
    save_template,
    save_template_collection,
    save_template_preset_collection,
)
from mint_sdk.testing import RecordingContext
from pydantic import ValidationError

FIXTURE_DIR = Path(__file__).parents[2] / "sdk-frontend" / "src" / "__tests__" / "fixtures" / "templates"
CATALOG_CONTRACT_PATH = Path(__file__).parents[2] / "bio-template-catalog.contract.json"
PACK_CONTRACT_PATH = Path(__file__).parents[2] / "bio-template-packs.contract.json"
PRESET_CONTRACT_PATH = Path(__file__).parents[2] / "bio-template-presets.contract.json"


class TemplatePlugin(AnalysisPlugin):
    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="template-plugin",
            version="1.0.0",
            description="Template plugin",
            analysis_type="template",
            routes_prefix="/template",
        )

    def get_routers(self):
        return []

    async def initialize(self, context=None):
        self._context = context

    async def shutdown(self):
        pass


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURE_DIR / name).read_text())


def load_catalog_contract() -> list[dict]:
    return json.loads(CATALOG_CONTRACT_PATH.read_text())


def load_pack_contract() -> list[dict]:
    return json.loads(PACK_CONTRACT_PATH.read_text())


def load_preset_contract() -> list[dict]:
    return json.loads(PRESET_CONTRACT_PATH.read_text())


def test_root_export_loads_template_class():
    assert RootBioTemplatePackEntry is BioTemplatePackEntry
    assert RootBioTemplatePresetEntry is BioTemplatePresetEntry
    assert RootCalibrationCurveTemplate is CalibrationCurveTemplate
    assert RootFlowCytometryPanelTemplate is FlowCytometryPanelTemplate
    assert RootInstrumentRunTemplate is InstrumentRunTemplate
    assert RootPlateMapTemplate is PlateMapTemplate
    assert RootProtocolStepsTemplate is ProtocolStepsTemplate
    assert RootQpcrPlateTemplate is QpcrPlateTemplate
    assert RootReagentListTemplate is ReagentListTemplate
    assert RootSamplePrepTemplate is SamplePrepTemplate
    assert root_create_elisa_assay_collection is create_elisa_assay_collection
    assert root_create_flow_cytometry_assay_collection is create_flow_cytometry_assay_collection
    assert root_create_targeted_metabolomics_collection is create_targeted_metabolomics_collection
    assert root_create_western_blot_assay_collection is create_western_blot_assay_collection
    assert root_list_template_packs is list_template_packs
    assert root_save_template_preset_collection is save_template_preset_collection
    assert RootTimeCourseTemplate is TimeCourseTemplate


def test_template_catalog_lists_built_ins_and_aliases():
    catalog = list_template_catalog()
    names = [entry.name for entry in catalog]

    assert names == [
        "plate-map",
        "sample-sheet",
        "sample-prep",
        "dose-response",
        "calibration-curve",
        "time-course",
        "protocol-steps",
        "assay-matrix",
        "reagent-list",
        "flow-cytometry-panel",
        "instrument-run",
        "qpcr-plate",
    ]
    assert get_template_info("wellplate") is not None
    assert require_template_info("wellplate").template_id == "plate-map"
    assert require_template_info("sample preparation").template_id == "sample-prep"
    assert require_template_info("dose-response").components == ("DoseCalculator", "ReagentEditor", "WellPlate")
    assert require_template_info("dose design").template_id == "dose-response"
    assert require_template_info("dose-design").template_id == "dose-response"
    assert require_template_info("dose calculator").template_id == "dose-response"
    assert require_template_info("dose_calculator").template_id == "dose-response"
    assert require_template_info("standard curve").template_id == "calibration-curve"
    assert require_template_info("protocol").template_id == "protocol-steps"
    assert require_template_info("omics matrix").template_id == "assay-matrix"
    assert require_template_info("antibodies").template_id == "reagent-list"
    assert require_template_info("facs panel").template_id == "flow-cytometry-panel"
    assert require_template_info("run queue").template_id == "instrument-run"
    assert "ExperimentTimeline" in require_template_info("run queue").components
    assert require_template_info("gene expression").template_id == "qpcr-plate"


def test_template_catalog_matches_shared_contract():
    assert [entry.model_dump(mode="json") for entry in list_template_catalog()] == load_catalog_contract()


def test_template_pack_catalog_lists_curated_collections():
    packs = list_template_packs()

    assert [entry.name for entry in packs] == [
        "cell-culture-screen",
        "omics-assay",
        "longitudinal-study",
        "molecular-assay",
    ]
    assert require_template_pack_info("cell culture").templates == (
        "sample-sheet",
        "sample-prep",
        "plate-map",
        "reagent-list",
        "protocol-steps",
        "dose-response",
        "flow-cytometry-panel",
    )
    assert require_template_pack_info("metabolomics").templates == (
        "sample-sheet",
        "sample-prep",
        "reagent-list",
        "protocol-steps",
        "instrument-run",
        "calibration-curve",
        "assay-matrix",
    )
    assert require_template_pack_info("metabolism").name == "omics-assay"
    assert require_template_pack_info("metabolite profiling").name == "omics-assay"
    assert "DataFrame" in require_template_pack_info("molecular").components
    assert require_template_pack_info("gene-expression").templates[-1] == "qpcr-plate"
    assert require_template_pack_info("longitudinal").init_command == "mint init --template longitudinal-study"
    assert get_template_pack_info("missing") is None


def test_template_pack_catalog_matches_shared_contract():
    assert [entry.model_dump(mode="json") for entry in list_template_packs()] == load_pack_contract()


def test_template_preset_catalog_lists_common_collections():
    presets = list_template_presets()

    assert [entry.name for entry in presets] == [
        "wellplate-screen",
        "qpcr-expression",
        "lcms-batch",
        "targeted-metabolomics",
        "elisa-assay",
        "flow-cytometry-assay",
        "western-blot-assay",
    ]
    assert require_template_preset_info("wellplate").name == "wellplate-screen"
    assert require_template_preset_info("dose planner").name == "wellplate-screen"
    assert require_template_preset_info("dose-planner").name == "wellplate-screen"
    assert require_template_preset_info("gene expression").templates == ("sample-sheet", "qpcr-plate")
    assert require_template_preset_info("mass spec batch").templates == (
        "sample-sheet",
        "instrument-run",
        "assay-matrix",
    )
    assert require_template_preset_info("metabolomics").name == "lcms-batch"
    assert require_template_preset_info("metabolism").name == "lcms-batch"
    assert require_template_preset_info("metabolite profiling").name == "lcms-batch"
    assert require_template_preset_info("targeted metabolomics").name == "targeted-metabolomics"
    assert require_template_preset_info("internal standards").name == "targeted-metabolomics"
    assert require_template_preset_info("immunoassay").templates == (
        "plate-map",
        "sample-sheet",
        "calibration-curve",
        "assay-matrix",
    )
    assert require_template_preset_info("facs").templates == (
        "sample-sheet",
        "flow-cytometry-panel",
        "assay-matrix",
    )
    assert require_template_preset_info("immunoblot").templates == (
        "sample-sheet",
        "reagent-list",
        "protocol-steps",
        "assay-matrix",
    )
    assert get_template_preset_info("missing") is None


def test_template_preset_catalog_matches_shared_contract():
    assert [entry.model_dump(mode="json") for entry in list_template_presets()] == load_preset_contract()


def test_dataframe_template_catalog_entries_prefer_generic_adapter():
    dataframe_templates = [
        entry for entry in list_template_catalog()
        if "DataFrame" in entry.components
    ]

    assert {entry.name for entry in dataframe_templates} == {
        "sample-sheet",
        "sample-prep",
        "calibration-curve",
        "time-course",
        "protocol-steps",
        "assay-matrix",
        "reagent-list",
        "flow-cytometry-panel",
        "instrument-run",
        "qpcr-plate",
    }
    for entry in dataframe_templates:
        assert entry.frontend_adapters[0] == "toTemplateDataFrame"
        assert "toTemplateDataFrame" in entry.frontend_import


def test_plate_map_round_trips_to_design_data():
    template = PlateMapTemplate.create_96_well(
        name="Drug screen plate",
        samples=["DMSO", "Drug A"],
    )

    payload = template.to_design_data(metadata={"source": "test"})
    loaded = PlateMapTemplate.from_design_data(payload)

    assert payload["template_id"] == "plate-map"
    assert payload["data"]["activePlateId"] == "plate-1"
    assert payload["metadata"]["source"] == "test"
    assert loaded.plates[0].format == 96
    assert loaded.samples[1].id == "drug-a"


def test_plate_map_fixture_loads():
    loaded = PlateMapTemplate.from_design_data(load_fixture("plate-map.json"))

    assert loaded.plates[0].wells["A2"].sample_type == "drug-a"
    assert loaded.plates[0].wells["A2"].row == 0
    assert loaded.plates[0].wells["A2"].col == 1


def test_wrong_template_id_is_rejected():
    payload = PlateMapTemplate.create_96_well().to_design_data()
    payload["template_id"] = "sample-sheet"

    with pytest.raises(TemplateValidationError, match="Expected template_id"):
        PlateMapTemplate.from_design_data(payload)


def test_invalid_plate_format_and_well_id_fail():
    with pytest.raises(ValidationError):
        PlateMapTemplate.create(format=1536)  # type: ignore[arg-type]

    with pytest.raises(ValidationError, match="outside a 96-well plate"):
        PlateMapTemplate(
            plates=[
                PlateMap(
                    id="plate-1",
                    name="Plate 1",
                    format=96,
                    wells={"Z99": Well(id="Z99")},
                )
            ],
            samples=[],
        )


def test_duplicate_and_missing_plate_samples_fail():
    with pytest.raises(ValidationError, match="Sample ids must be unique"):
        PlateMapTemplate(
            plates=[PlateMap(id="plate-1", name="Plate 1", format=96)],
            samples=[
                SampleDefinition(id="sample-1", name="A"),
                SampleDefinition(id="sample-1", name="B"),
            ],
        )

    with pytest.raises(ValidationError, match="unknown sample"):
        PlateMapTemplate(
            plates=[
                PlateMap(
                    id="plate-1",
                    name="Plate 1",
                    format=96,
                    wells={"A1": Well(id="A1", sampleType="missing")},
                )
            ],
            samples=[SampleDefinition(id="sample-1", name="A")],
        )


def test_sample_sheet_from_rows_maps_metadata_and_groups():
    template = SampleSheetTemplate.from_rows(
        [
            {"sample_id": "S001", "name": "Control", "group": "Control", "cell_line": "HCT116"},
            {"sample_id": "S002", "name": "Drug A", "group": "Drug A", "cell_line": "HCT116"},
        ]
    )

    payload = template.to_design_data()
    loaded = SampleSheetTemplate.from_design_data(payload)

    assert loaded.samples[0].sample_id == "S001"
    assert loaded.samples[0].metadata["cell_line"] == "HCT116"
    assert loaded.columns[0].id == "sampleId"
    assert any(column.id == "cell_line" for column in loaded.columns)


def test_sample_sheet_fixture_loads():
    loaded = SampleSheetTemplate.from_design_data(load_fixture("sample-sheet.json"))

    assert loaded.samples[0].well_id == "A1"
    assert loaded.groups[1].samples == ["S002"]


def test_sample_sheet_rejects_duplicate_samples_and_unknown_group_members():
    with pytest.raises(ValidationError, match="Sample ids must be unique"):
        SampleSheetTemplate.from_rows(
            [
                {"sample_id": "S001", "name": "A"},
                {"sample_id": "S001", "name": "B"},
            ]
        )

    payload = load_fixture("sample-sheet.json")
    payload["data"]["groups"][0]["samples"] = ["missing"]
    with pytest.raises(ValidationError, match="unknown sample"):
        SampleSheetTemplate.from_design_data(payload)


def test_sample_prep_creates_steps_and_round_trips():
    template = SamplePrepTemplate.create(
        ["S001", {"name": "Dilute S002", "sourceSampleId": "S002", "type": "dilution"}],
        prep_type="extraction",
        output_volume=50,
    )

    payload = template.to_design_data()
    loaded = SamplePrepTemplate.from_design_data(payload)

    assert payload["template_id"] == "sample-prep"
    assert loaded.protocol_name == "Sample preparation"
    assert loaded.steps[0].source_sample_id == "s001"
    assert loaded.steps[0].destination_sample_id == "s001-prepared"
    assert loaded.steps[0].output_volume == 50
    assert loaded.steps[1].id == "dilute-s002"
    assert loaded.steps[1].type == "dilution"
    assert loaded.steps[1].metadata == {}


def test_sample_prep_rejects_invalid_steps():
    with pytest.raises(ValidationError, match="requires at least one step"):
        SamplePrepTemplate(steps=[])

    with pytest.raises(ValidationError, match="orders must be unique"):
        SamplePrepTemplate(
            steps=[
                SamplePrepStep(id="prep-1", order=1, name="Prep 1", sourceSampleId="S001"),
                SamplePrepStep(id="prep-2", order=1, name="Prep 2", sourceSampleId="S002"),
            ]
        )

    with pytest.raises(ValidationError, match="requires a source sample"):
        SamplePrepTemplate(
            steps=[
                SamplePrepStep(id="prep-1", order=1, name="Prep 1"),
            ]
        )


def test_dose_response_sorts_concentrations_and_keeps_controls():
    template = DoseResponseTemplate.create(
        {"Drug A": [0.1, 10, 1]},
        unit="uM",
        replicates=2,
        controls=[ControlDefinition(id="dmso", name="DMSO", role="vehicle", vehicle="DMSO")],
    )

    payload = template.to_design_data()
    loaded = DoseResponseTemplate.from_design_data(payload)

    assert loaded.compounds[0].concentrations == [10, 1, 0.1]
    assert loaded.controls[0].role == "vehicle"
    assert loaded.replicates == 2


def test_dose_response_fixture_loads_with_layout():
    loaded = DoseResponseTemplate.from_design_data(load_fixture("dose-response.json"))

    assert loaded.unit == "uM"
    assert loaded.layout is not None
    assert loaded.layout.plates[0].wells["A2"].value == 10


def test_dose_response_rejects_empty_and_negative_series():
    with pytest.raises(ValidationError, match="at least one concentration"):
        DoseResponseTemplate.create({"Drug A": []}, unit="uM")

    with pytest.raises(ValidationError, match="cannot be negative"):
        DoseResponseTemplate.create({"Drug A": [10, -1]}, unit="uM")


def test_calibration_curve_creates_acceptance_points_and_round_trips():
    template = CalibrationCurveTemplate.create(
        [0.1, {"level": "Standard 2", "concentration": 1}, 10],
        analyte="Glucose",
        unit="uM",
    )

    payload = template.to_design_data()
    loaded = CalibrationCurveTemplate.from_design_data(payload)

    assert payload["template_id"] == "calibration-curve"
    assert loaded.analyte == "Glucose"
    assert loaded.x_unit == "uM"
    assert loaded.acceptance.min_r_squared == 0.99
    assert [point.role for point in loaded.points] == ["blank", "standard", "standard", "standard", "qc", "qc"]
    assert loaded.points[2].id == "standard-2"
    assert loaded.points[2].metadata == {}


def test_calibration_curve_rejects_invalid_points_and_acceptance():
    with pytest.raises(ValidationError, match="at least two included standards"):
        CalibrationCurveTemplate.create([1], unit="uM")

    with pytest.raises(ValidationError, match="positive concentration"):
        CalibrationCurveTemplate.create([0, 1], unit="uM", include_blank=False)

    with pytest.raises(ValidationError, match="orders must be unique"):
        CalibrationCurveTemplate(
            analyte="Glucose",
            xUnit="uM",
            points=[
                CalibrationPoint(id="std-1", order=1, level="Std 1", concentration=1, unit="uM"),
                CalibrationPoint(id="std-2", order=1, level="Std 2", concentration=2, unit="uM"),
            ],
        )

    with pytest.raises(ValidationError, match="between 0 and 1"):
        CalibrationCurveTemplate.create(
            [1, 2],
            unit="uM",
            acceptance={"minRSquared": 2},
        )


def test_time_course_creates_scheduled_samples_and_round_trips():
    template = TimeCourseTemplate.create(
        [24, 0, 6],
        unit="hour",
        conditions=["Control", "Treatment"],
        replicates=2,
    )

    payload = template.to_design_data()
    loaded = TimeCourseTemplate.from_design_data(payload)

    assert payload["template_id"] == "time-course"
    assert [timepoint.id for timepoint in loaded.timepoints] == ["t0-hour", "t6-hour", "t24-hour"]
    assert len(loaded.samples) == 12
    assert loaded.samples[0].sample_id == "control-t0-hour-r1"
    assert loaded.samples[2].sample_id == "control-t6-hour-r1"


def test_time_course_rejects_unknown_references():
    with pytest.raises(ValidationError, match="unknown time point"):
        TimeCourseTemplate(
            timepoints=[{"id": "t0", "label": "0 h", "value": 0, "unit": "hour"}],
            conditions=[{"id": "control", "name": "Control"}],
            samples=[
                TimeCourseSample(
                    sampleId="S001",
                    conditionId="control",
                    timepointId="missing",
                )
            ],
        )


def test_protocol_steps_create_run_sheet_and_round_trip():
    template = ProtocolStepsTemplate.create(
        [
            {
                "name": "Measure readout",
                "type": "measurement",
                "duration": 45,
                "order": 2,
            },
            "Seed cells",
        ]
    )

    payload = template.to_design_data()
    loaded = ProtocolStepsTemplate.from_design_data(payload)

    assert payload["template_id"] == "protocol-steps"
    assert [step.order for step in loaded.steps] == [1, 2]
    assert loaded.steps[0].id == "seed-cells"
    assert loaded.steps[1].type == "measurement"


def test_protocol_steps_reject_duplicate_orders_and_negative_duration():
    with pytest.raises(ValidationError, match="orders must be unique"):
        ProtocolStepsTemplate.create(
            [
                {"name": "A", "order": 0},
                {"name": "B", "order": 0},
            ]
        )

    with pytest.raises(ValidationError, match="duration cannot be negative"):
        ProtocolStepsTemplate.create(
            [
                {"name": "A", "duration": -1},
            ]
        )


def test_assay_matrix_creates_sparse_matrix_and_round_trips():
    template = AssayMatrixTemplate.create(
        samples=["S001", "S002"],
        features=["Lactate", "Glucose"],
        values={
            "s001": {"lactate": 1.2, "glucose": 5.4},
            "s002": {"lactate": 2.1, "glucose": 4.8},
        },
    )

    payload = template.to_design_data()
    loaded = AssayMatrixTemplate.from_design_data(payload)

    assert payload["template_id"] == "assay-matrix"
    assert loaded.samples[0].sample_id == "s001"
    assert loaded.features[1].id == "glucose"
    assert loaded.measurements[0].value == 1.2


def test_assay_matrix_create_accepts_display_names_for_values():
    template = AssayMatrixTemplate.create(
        samples=["S001"],
        features=["Lactate"],
        values={"S001": {"Lactate": 1.2}},
    )

    assert template.measurements[0].sample_id == "s001"
    assert template.measurements[0].feature_id == "lactate"


def test_assay_matrix_from_rows_and_validation():
    template = AssayMatrixTemplate.from_rows(
        [
            {"sample_id": "S001", "feature_id": "Lactate", "value": "1.2", "batch": "A"},
            {"sample_id": "S002", "feature_id": "Lactate", "value": "2.1", "batch": "A"},
        ],
    )

    assert template.measurements[0].metadata["batch"] == "A"
    with pytest.raises(ValidationError, match="unknown feature"):
        AssayMatrixTemplate.create(
            samples=["S001"],
            features=["Lactate"],
            values={"s001": {"missing": 1.0}},
        )


def test_reagent_list_creates_inventory_rows_and_round_trips():
    template = ReagentListTemplate.create(
        [
            {
                "id": "dmso",
                "name": "DMSO",
                "kind": "compound",
                "storageCondition": "RT",
                "stockLevel": 80,
                "stockUnit": "%",
            },
            "Anti-HA antibody",
        ]
    )

    payload = template.to_design_data()
    loaded = ReagentListTemplate.from_design_data(payload)

    assert payload["template_id"] == "reagent-list"
    assert loaded.reagents[0].storage_condition == "RT"
    assert loaded.reagents[0].stock_level == 80
    assert loaded.reagents[1].id == "anti-ha-antibody"


def test_flow_cytometry_panel_creates_controls_and_round_trips():
    template = FlowCytometryPanelTemplate.create(
        [
            {"id": "cd3", "marker": "CD3", "fluorophore": "FITC", "detector": "B530/30"},
            {"id": "cd4", "marker": "CD4", "fluorophore": "PE", "detector": "B585/42"},
        ],
        instrument="BD LSRFortessa",
    )

    payload = template.to_design_data()
    loaded = FlowCytometryPanelTemplate.from_design_data(payload)

    assert payload["template_id"] == "flow-cytometry-panel"
    assert loaded.markers[0].marker == "CD3"
    assert loaded.markers[0].fluorophore == "FITC"
    assert loaded.instrument == "BD LSRFortessa"
    assert [control.kind for control in loaded.controls] == [
        "unstained",
        "single-stain",
        "single-stain",
    ]


def test_instrument_run_creates_queue_and_round_trips():
    template = InstrumentRunTemplate.create(
        ["S001", {"name": "S002", "vial": "A2"}],
        instrument="LC-MS",
        method="Default method",
    )

    payload = template.to_design_data()
    loaded = InstrumentRunTemplate.from_design_data(payload)

    assert payload["template_id"] == "instrument-run"
    assert loaded.methods[0].id == "default-method"
    assert [item.kind for item in loaded.items] == ["blank", "qc", "sample", "sample", "qc"]
    assert loaded.items[2].sample_id == "s001"
    assert loaded.items[2].method_id == "default-method"
    assert loaded.items[3].sample_id == "s002"
    assert loaded.items[3].vial == "A2"


def test_instrument_run_rejects_unknown_method_and_duplicate_orders():
    with pytest.raises(ValidationError, match="unknown method"):
        InstrumentRunTemplate(
            methods=[{"id": "m1", "name": "Method 1"}],
            items=[InstrumentRunItem(id="S001", order=1, sampleId="S001", methodId="missing")],
        )

    with pytest.raises(ValidationError, match="orders must be unique"):
        InstrumentRunTemplate(
            methods=[{"id": "m1", "name": "Method 1"}],
            items=[
                InstrumentRunItem(id="S001", order=1, sampleId="S001", methodId="m1"),
                InstrumentRunItem(id="S002", order=1, sampleId="S002", methodId="m1"),
            ],
        )


def test_qpcr_plate_creates_reactions_and_round_trips():
    template = QpcrPlateTemplate.create(
        samples=["Control", "Treatment"],
        targets=["ACTB", "GAPDH"],
        replicates=2,
        instrument="QuantStudio",
    )

    payload = template.to_design_data()
    loaded = QpcrPlateTemplate.from_design_data(payload)

    assert payload["template_id"] == "qpcr-plate"
    assert loaded.samples[0].sample_id == "control"
    assert loaded.targets[0].id == "actb"
    assert loaded.reactions[0].well_id == "A1"
    assert loaded.reactions[0].sample_id == "control"
    assert loaded.reactions[0].target_id == "actb"
    assert loaded.reactions[-1].control_kind == "no-template"
    assert loaded.instrument == "QuantStudio"


def test_qpcr_plate_fixture_loads():
    loaded = QpcrPlateTemplate.from_design_data(load_fixture("qpcr-plate.json"))

    assert loaded.chemistry == "taqman"
    assert loaded.samples[1].metadata["condition"] == "treated"
    assert loaded.targets[0].assay_id == "Hs01060665_g1"
    assert loaded.reactions[0].well_id == "A1"
    assert loaded.reactions[2].flags == ["review"]
    assert loaded.reactions[3].control_kind == "no-template"


def test_qpcr_plate_rejects_unknown_references_and_duplicate_wells():
    with pytest.raises(ValidationError, match="unknown target"):
        QpcrPlateTemplate(
            samples=[{"sampleId": "S001"}],
            targets=[{"id": "ACTB", "name": "ACTB"}],
            reactions=[
                QpcrReaction(
                    id="r1",
                    wellId="A1",
                    sampleId="S001",
                    targetId="missing",
                )
            ],
        )

    with pytest.raises(ValidationError, match="wells must be unique"):
        QpcrPlateTemplate(
            samples=[{"sampleId": "S001"}],
            targets=[{"id": "ACTB", "name": "ACTB"}],
            reactions=[
                QpcrReaction(id="r1", wellId="A1", sampleId="S001", targetId="ACTB"),
                QpcrReaction(id="r2", wellId="A1", sampleId="S001", targetId="ACTB"),
            ],
        )


def test_reagent_list_rejects_duplicate_ids_and_negative_stock():
    with pytest.raises(ValidationError, match="Reagent ids must be unique"):
        ReagentListTemplate.create(
            [
                {"id": "dmso", "name": "DMSO"},
                {"id": "dmso", "name": "DMSO duplicate"},
            ]
        )

    with pytest.raises(ValidationError, match="stock level cannot be negative"):
        ReagentListTemplate.create(
            [
                {"id": "dmso", "name": "DMSO", "stockLevel": -1},
            ]
        )


def test_template_collection_helpers_build_and_extract_payload():
    plate = PlateMapTemplate.create_96_well(name="Plate 1")
    sample_sheet = SampleSheetTemplate.from_rows(
        [{"sample_id": "S001", "name": "Control 1", "group": "Control"}]
    )

    payload = create_template_collection([plate, sample_sheet], metadata={"source": "template-pack"})
    envelopes = extract_template_collection(payload)
    legacy_envelopes = extract_template_collection(plate.to_design_data())

    assert set(payload["templates"]) == {"plate-map", "sample-sheet"}
    assert payload["metadata"] == {"source": "template-pack"}
    assert set(envelopes) == {"plate-map", "sample-sheet"}
    assert envelopes["plate-map"].data["plates"][0]["name"] == "Plate 1"
    assert legacy_envelopes["plate-map"].template_id == "plate-map"
    with pytest.raises(TemplateValidationError, match="Duplicate template_id"):
        create_template_collection([plate, plate])


def test_template_collection_rejects_mismatched_keys():
    plate = PlateMapTemplate.create_96_well(name="Plate 1")

    with pytest.raises(TemplateValidationError, match="does not match envelope template_id"):
        extract_template_collection({"templates": {"sample-sheet": plate.to_design_data()}})


def test_template_presets_create_ready_to_save_collections():
    wellplate = create_wellplate_screen_collection(
        samples=["Control", "Treatment"],
        compounds={"Drug A": [10, 1, 0.1]},
        unit="uM",
    )
    qpcr = create_qpcr_expression_collection(
        samples=[{"sampleId": "S001", "name": "Control", "group": "Control"}],
        targets=["ACTB"],
    )
    lcms = create_lcms_batch_collection(
        samples=["S001", "S002"],
        features=["Glucose"],
        instrument="LC-MS",
    )
    targeted = create_targeted_metabolomics_collection(
        samples=["S001", "S002"],
        metabolites=["Glucose", "Lactate"],
        internal_standards=["13C Glucose"],
        standard_concentrations=[0.1, 1, 10],
        instrument="Orbitrap",
    )
    elisa = create_elisa_assay_collection(
        samples=["Control", "Treatment"],
        analyte="IL-6",
        standard_concentrations=[1000, 100, 10, 1],
        unit="pg/mL",
    )
    flow = create_flow_cytometry_assay_collection(
        samples=["Control", "Treatment"],
        markers=["CD3", "CD4"],
        instrument="BD LSRFortessa",
    )
    western = create_western_blot_assay_collection(
        samples=["Control", "Treatment"],
        targets=["pERK", "ERK"],
        loading_control="ACTB",
    )

    wellplate_templates = extract_template_collection(wellplate)
    qpcr_templates = extract_template_collection(qpcr)
    lcms_templates = extract_template_collection(lcms)
    targeted_templates = extract_template_collection(targeted)
    elisa_templates = extract_template_collection(elisa)
    flow_templates = extract_template_collection(flow)
    western_templates = extract_template_collection(western)

    assert set(wellplate_templates) == {"plate-map", "sample-sheet", "dose-response"}
    assert wellplate["metadata"]["preset"] == "wellplate-screen"
    assert wellplate_templates["plate-map"].data["samples"][1]["id"] == "treatment"
    assert wellplate_templates["dose-response"].data["layout"]["samples"][1]["id"] == "treatment"
    assert set(qpcr_templates) == {"sample-sheet", "qpcr-plate"}
    assert qpcr_templates["qpcr-plate"].data["reactions"][0]["sampleId"] == "S001"
    assert set(lcms_templates) == {"sample-sheet", "instrument-run", "assay-matrix"}
    assert lcms_templates["instrument-run"].data["instrument"] == "LC-MS"
    assert lcms_templates["instrument-run"].data["items"][2]["sampleId"] == "s001"
    assert lcms_templates["assay-matrix"].data["features"][0]["name"] == "Glucose"
    assert set(targeted_templates) == {
        "sample-sheet",
        "sample-prep",
        "reagent-list",
        "instrument-run",
        "calibration-curve",
        "assay-matrix",
    }
    assert targeted["metadata"]["preset"] == "targeted-metabolomics"
    assert targeted_templates["reagent-list"].data["reagents"][0]["kind"] == "compound"
    assert targeted_templates["reagent-list"].data["reagents"][0]["metadata"]["role"] == "internal-standard"
    assert targeted_templates["calibration-curve"].data["model"] == "linear-weighted-1-x"
    assert targeted_templates["calibration-curve"].data["responseUnit"] == "peak area ratio"
    assert [item["kind"] for item in targeted_templates["instrument-run"].data["items"]] == [
        "blank",
        "standard",
        "standard",
        "standard",
        "qc",
        "qc",
        "sample",
        "sample",
    ]
    assert targeted_templates["assay-matrix"].data["features"][1]["type"] == "metabolite"
    assert targeted_templates["assay-matrix"].data["features"][1]["unit"] == "peak area ratio"
    assert set(elisa_templates) == {"plate-map", "sample-sheet", "calibration-curve", "assay-matrix"}
    assert elisa["metadata"]["preset"] == "elisa-assay"
    assert elisa_templates["calibration-curve"].data["analyte"] == "IL-6"
    assert elisa_templates["calibration-curve"].data["model"] == "four-parameter-logistic"
    assert elisa_templates["assay-matrix"].data["features"][0]["name"] == "IL-6"
    assert set(flow_templates) == {"sample-sheet", "flow-cytometry-panel", "assay-matrix"}
    assert flow["metadata"]["preset"] == "flow-cytometry-assay"
    assert flow_templates["flow-cytometry-panel"].data["instrument"] == "BD LSRFortessa"
    assert [marker["marker"] for marker in flow_templates["flow-cytometry-panel"].data["markers"]] == ["CD3", "CD4"]
    assert flow_templates["assay-matrix"].data["features"][1]["name"] == "CD4+ cells"
    assert set(western_templates) == {"sample-sheet", "reagent-list", "protocol-steps", "assay-matrix"}
    assert western["metadata"]["preset"] == "western-blot-assay"
    assert western_templates["reagent-list"].data["reagents"][0]["kind"] == "antibody"
    assert western_templates["protocol-steps"].data["steps"][2]["name"] == "Transfer to membrane"
    assert [feature["name"] for feature in western_templates["assay-matrix"].data["features"]] == [
        "pERK",
        "ERK",
        "ACTB",
    ]
    assert western_templates["assay-matrix"].data["features"][2]["metadata"]["loadingControl"] is True

    alias_collection = create_template_preset_collection(
        "wellplate",
        samples=["Control", "Treatment"],
        compounds={"Drug A": [10, 1]},
    )
    assert alias_collection["metadata"]["preset"] == "wellplate-screen"
    assert set(extract_template_collection(alias_collection)) == {"plate-map", "sample-sheet", "dose-response"}

    elisa_alias_collection = create_template_preset_collection("elisa", samples=["Control"])
    assert elisa_alias_collection["metadata"]["preset"] == "elisa-assay"

    flow_alias_collection = create_template_preset_collection("facs", samples=["Control"])
    assert flow_alias_collection["metadata"]["preset"] == "flow-cytometry-assay"

    western_alias_collection = create_template_preset_collection("immunoblot", samples=["Control"])
    assert western_alias_collection["metadata"]["preset"] == "western-blot-assay"

    targeted_alias_collection = create_template_preset_collection("targeted metabolomics", samples=["Control"])
    assert targeted_alias_collection["metadata"]["preset"] == "targeted-metabolomics"

    with pytest.raises(KeyError):
        create_template_preset_collection("unknown-preset")


@pytest.mark.asyncio
async def test_save_and_load_template_wrappers_use_plugin_design_data():
    plugin = TemplatePlugin()
    await plugin.initialize(RecordingContext())
    template = PlateMapTemplate.create_96_well(name="Plate 1")

    saved = await save_template(plugin, 42, template, metadata={"source": "unit-test"})
    loaded = await load_template(plugin, 42, PlateMapTemplate)

    assert saved is not None
    assert loaded is not None
    assert loaded.plates[0].name == "Plate 1"


@pytest.mark.asyncio
async def test_save_template_merge_preserves_multiple_templates():
    plugin = TemplatePlugin()
    await plugin.initialize(RecordingContext())
    plate = PlateMapTemplate.create_96_well(name="Plate 1")
    sample_sheet = SampleSheetTemplate.from_rows(
        [{"sample_id": "S001", "name": "Control 1", "group": "Control"}]
    )

    await save_template(plugin, 42, plate, merge=True)
    saved = await save_template(plugin, 42, sample_sheet, merge=True)
    loaded_plate = await load_template(plugin, 42, PlateMapTemplate)
    loaded_sample_sheet = await load_template(plugin, 42, SampleSheetTemplate)

    assert saved is not None
    assert set(saved.data["templates"]) == {"plate-map", "sample-sheet"}
    assert loaded_plate is not None
    assert loaded_sample_sheet is not None
    assert loaded_plate.plates[0].name == "Plate 1"
    assert loaded_sample_sheet.samples[0].sample_id == "S001"


@pytest.mark.asyncio
async def test_save_template_merge_preserves_legacy_single_template():
    plugin = TemplatePlugin()
    await plugin.initialize(RecordingContext())
    plate = PlateMapTemplate.create_96_well(name="Plate 1")
    assay = AssayMatrixTemplate.create(samples=["S001"], features=["Lactate"])

    await save_template(plugin, 42, plate)
    saved = await save_template(plugin, 42, assay, merge=True)

    assert saved is not None
    assert set(saved.data["templates"]) == {"plate-map", "assay-matrix"}
    assert await load_template(plugin, 42, PlateMapTemplate) is not None
    assert await load_template(plugin, 42, AssayMatrixTemplate) is not None


@pytest.mark.asyncio
async def test_save_and_load_template_collection_merges_design_data():
    plugin = TemplatePlugin()
    await plugin.initialize(RecordingContext())
    plate = PlateMapTemplate.create_96_well(name="Plate 1")
    sample_sheet = SampleSheetTemplate.from_rows(
        [{"sample_id": "S001", "name": "Control 1", "group": "Control"}]
    )
    sample_prep = SamplePrepTemplate.create(["S001"], protocol_name="Extraction")

    await save_template(plugin, 42, plate)
    saved = await save_template_collection(
        plugin,
        42,
        [sample_sheet, sample_prep],
        metadata={"pack": "demo"},
    )
    envelopes = await load_template_collection(plugin, 42)
    loaded_prep = await load_template(plugin, 42, SamplePrepTemplate)

    assert saved is not None
    assert saved.data["metadata"] == {"pack": "demo"}
    assert set(envelopes) == {"plate-map", "sample-sheet", "sample-prep"}
    assert envelopes["sample-sheet"].data["samples"][0]["sampleId"] == "S001"
    assert loaded_prep is not None
    assert loaded_prep.protocol_name == "Extraction"


@pytest.mark.asyncio
async def test_save_template_preset_collection_creates_and_merges_design_data():
    plugin = TemplatePlugin()
    await plugin.initialize(RecordingContext())
    plate = PlateMapTemplate.create_96_well(name="Existing plate")

    await save_template(plugin, 42, plate)
    saved = await save_template_preset_collection(
        plugin,
        42,
        "wellplate",
        samples=["Control", "Treatment"],
        compounds={"Drug A": [10, 1]},
    )
    envelopes = await load_template_collection(plugin, 42)

    assert saved is not None
    assert saved.data["metadata"]["preset"] == "wellplate-screen"
    assert set(envelopes) == {"plate-map", "sample-sheet", "dose-response"}
    assert envelopes["plate-map"].data["samples"][1]["id"] == "treatment"

    custom_saved = await save_template_preset_collection(
        plugin,
        43,
        "qpcr",
        collection_key="preset_templates",
        samples=["Control"],
        targets=["ACTB"],
    )
    assert custom_saved is not None
    assert set(custom_saved.data["preset_templates"]) == {"sample-sheet", "qpcr-plate"}
