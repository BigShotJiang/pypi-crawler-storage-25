"""Tests for shared LCMS sequence helpers."""

from __future__ import annotations

import pytest
from mint_sdk.lcms import (
    LcmsMethodPathEntry,
    LcmsPlateCell,
    LcmsPlateType,
    LcmsSequenceItem,
    extract_lcms_common_prefix,
    extract_lcms_sample_name,
    lcms_sequence_items_to_csv,
    number_lcms_sequence_items,
    parse_lcms_sequence_csv,
    plate_cells_to_lcms_sequence_items,
    reconstruct_lcms_plate_cells_from_sequence_items,
    resolve_lcms_method_path,
)
from pydantic import ValidationError


def _sequence_item(**overrides: object) -> LcmsSequenceItem:
    data = {
        "sample_type": "Unknown",
        "file_name": "Batch_NEG_S1_001",
        "sample_id": "R:A1",
        "path": r"D:\data\Batch",
        "instrument_method": r"C:\Methods\neg.meth",
        "position": "R:A1",
        "injection_volume": 5.0,
    }
    data.update(overrides)
    return LcmsSequenceItem.model_validate(data)


def test_resolve_lcms_method_path_prefers_most_specific_entry() -> None:
    paths = [
        {"path": r"global_$POLARITY_$CONTAINER.meth", "polarity_tag": None, "container_tag": None},
        {"path": r"neg_$CONTAINER.meth", "polarity_tag": "NEG", "container_tag": None},
        {"path": r"plate_$POLARITY.meth", "polarity_tag": None, "container_tag": "PLATE"},
        {"path": r"neg_plate.meth", "polarity_tag": "NEG", "container_tag": "PLATE"},
    ]

    assert resolve_lcms_method_path(paths, "NEG", "PLATE") == r"neg_plate.meth"
    assert resolve_lcms_method_path(paths, "NEG", "VIAL") == r"neg_VIAL.meth"
    assert resolve_lcms_method_path(paths, "POS", "PLATE") == r"plate_POS.meth"
    assert (
        resolve_lcms_method_path(paths, "POS", "VIAL", base_path=r"C:\Methods")
        == r"C:\Methods\global_POS_VIAL.meth"
    )


def test_method_path_entry_validates_placeholder_contract() -> None:
    with pytest.raises(ValidationError):
        LcmsMethodPathEntry(path="neg_$POLARITY.meth", polarity_tag="NEG")

    with pytest.raises(ValidationError):
        LcmsMethodPathEntry(path="untagged.meth")


def test_file_name_prefix_and_sample_name_helpers() -> None:
    file_names = ["Batch_01_NEG_S1_001", "Batch_01_NEG_S2_002", "Batch_01_NEG_QC_003"]

    prefix = extract_lcms_common_prefix(file_names)

    assert prefix == "Batch_01"
    assert extract_lcms_sample_name("Batch_01_NEG_S1_001", prefix) == "S1"


def test_plate_cells_convert_to_sequence_items_with_repeat_injections() -> None:
    cells = [
        LcmsPlateCell(row="A", column=1, sample_name="S1", injection_count=2, slot="R"),
        LcmsPlateCell(row="A", column=2, sample_name="Blank", sample_type="blank", slot="R"),
    ]

    items = plate_cells_to_lcms_sequence_items(
        cells,
        method_path=r"C:\Methods\neg.meth",
        prefix="Batch",
        polarity="NEG",
        plate_slot="G",
        injection_volume=5.0,
    )

    assert [item.file_name for item in items] == ["Batch_NEG_S1_inj1", "Batch_NEG_S1_inj2"]
    assert [item.position for item in items] == ["R:A1", "R:A1"]
    assert all(item.instrument_method == r"C:\Methods\neg.meth" for item in items)


def test_sequence_csv_round_trip_and_numbering() -> None:
    numbered = number_lcms_sequence_items(
        [_sequence_item(file_name="Batch_NEG_S1"), _sequence_item(file_name="Batch_NEG_S2")],
        save_path=r"D:\data",
        prefix="Batch",
    )

    csv_content = lcms_sequence_items_to_csv(numbered)
    parsed = parse_lcms_sequence_csv(csv_content)

    assert [item.file_name for item in parsed] == ["Batch_NEG_S1_001", "Batch_NEG_S2_002"]
    assert [item.path for item in parsed] == [r"D:\data\Batch", r"D:\data\Batch"]
    assert parsed[0].injection_volume == 5.0


def test_reconstruct_plate_cells_from_sequence_items() -> None:
    result = reconstruct_lcms_plate_cells_from_sequence_items(
        [
            _sequence_item(file_name="Batch_NEG_S1_001", position="R:A1"),
            _sequence_item(file_name="Batch_NEG_S1_repeat_002", position="R:A1"),
            _sequence_item(file_name="Batch_NEG_S2_003", position="R:H12"),
            _sequence_item(sample_type="Blank", file_name="Batch_NEG_Blank_004", position="R:F9"),
        ]
    )

    assert result is not None
    cells, plate_type = result
    assert plate_type is LcmsPlateType.WELL_96
    assert [cell.model_dump() for cell in cells] == [
        {
            "row": "A",
            "column": 1,
            "sample_name": "S1",
            "sample_type": None,
            "injection_volume": None,
            "injection_count": None,
            "custom_method": None,
            "slot": None,
        },
        {
            "row": "H",
            "column": 12,
            "sample_name": "S2",
            "sample_type": None,
            "injection_volume": None,
            "injection_count": None,
            "custom_method": None,
            "slot": None,
        },
    ]
