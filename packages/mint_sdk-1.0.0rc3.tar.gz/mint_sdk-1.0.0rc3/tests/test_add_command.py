"""Tests for ``mint add`` code generation commands."""

from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

from fastapi.testclient import TestClient
from mint_sdk.add_command import (
    ANALYSIS_PAGE_ICON_PATH,
    DEFAULT_PAGE_ICON_PATH,
    PRESET_PAGE_ICON_PATH,
    TEMPLATE_PAGE_ICON_PATH,
    DataTemplateKind,
    DataTemplatePackKind,
    DataTemplatePresetKind,
    HookKind,
    HttpMethod,
    SettingType,
    cmd_add_data_template,
    cmd_add_data_template_pack,
    cmd_add_data_template_preset,
    cmd_add_endpoint,
    cmd_add_frontend_composable,
    cmd_add_frontend_page,
    cmd_add_hook,
    cmd_add_job,
    cmd_add_migration,
    cmd_add_r_analysis,
    cmd_add_router,
    cmd_add_schema,
    cmd_add_service,
    cmd_add_setting,
)
from mint_sdk.doctor_command import run_checks
from mint_sdk.init_command import _build_template_context, derive_names, write_files


def _make_scaffold(tmp_path: Path, *, frontend: bool = False) -> Path:
    context = _build_template_context(
        derive_names("My Analyzer"),
        {
            "description": "Desc",
            "type": "analysis",
            "include_frontend": "true" if frontend else "false",
        },
    )
    write_files(tmp_path, context, include_frontend=frontend)
    return tmp_path


def _clear_generated_plugin_modules() -> None:
    for name in list(sys.modules):
        if name == "mint_plugin_my_analyzer" or name.startswith("mint_plugin_my_analyzer."):
            del sys.modules[name]


def _assert_doctor_accepts_generated_frontend(project: Path) -> None:
    results = run_checks(project)
    details = {result.label: result for result in results}
    assert details["Frontend API wiring"].ok
    assert details["Frontend API wiring"].detail == "contract-first patterns"
    assert details["Frontend SDK API catalog"].ok
    assert details["Frontend SDK API catalog"].detail == "imports/re-exports match catalog"
    assert details["Frontend component guidance"].ok
    assert details["Frontend component guidance"].detail == "canonical component entrypoints"
    assert details["Deprecated SDK APIs"].ok
    assert details["Deprecated SDK APIs"].detail == "none found"


def test_add_setting_wires_settings_model(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_setting(
        path=str(project),
        name="threshold",
        field_type=SettingType.number,
        default="2.5",
        description="Score cutoff",
        required=False,
    )

    plugin_py = project / "src" / "mint_plugin_my_analyzer" / "plugin.py"
    content = plugin_py.read_text()
    assert "from pydantic import BaseModel, Field" in content
    assert "class MyAnalyzerSettings(BaseModel):" in content
    assert 'threshold: float = Field(default=2.5, description=\'Score cutoff\')' in content
    assert "settings_model = MyAnalyzerSettings" in content


def test_add_endpoint_appends_route(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_endpoint(
        path=str(project),
        name="summary",
        route_path="/summary",
        method=HttpMethod.get,
        router="analysis",
    )

    content = (project / "src" / "mint_plugin_my_analyzer" / "routers" / "analysis.py").read_text()
    assert '@router.get("/summary")' in content
    assert "async def summary()" in content


def test_add_endpoint_prints_generate_guidance_for_frontend(
    tmp_path: Path,
    capsys,
) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_endpoint(
        path=str(project),
        name="summary",
        route_path="/summary",
        method=HttpMethod.get,
        router="analysis",
    )

    output = capsys.readouterr().out
    assert "Next: mint sdk generate" in output


def test_add_frontend_page_registers_plugin_nav_item_and_refreshes_contract(
    tmp_path: Path,
    capsys,
) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_frontend_page(path=str(project), name="quality-control")

    view = project / "frontend" / "src" / "views" / "QualityControlView.vue"
    assert view.exists()
    plugin_py = project / "src" / "mint_plugin_my_analyzer" / "plugin.py"
    plugin_content = plugin_py.read_text()
    assert "PluginNavItem(" in plugin_content
    assert "path='/quality-control'" in plugin_content
    assert "label='Quality Control'" in plugin_content
    assert "id='quality-control'" in plugin_content
    assert f"icon='{DEFAULT_PAGE_ICON_PATH}'" in plugin_content
    assert "description='Build this page with SDK components.'" in plugin_content

    app_vue = (project / "frontend" / "src" / "App.vue").read_text()
    assert "pluginPageSelectorItems" in app_vue
    assert "label: 'Quality Control'" not in app_vue

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    nav_items = contract["plugin"]["navItems"]
    assert {
        "path": "/quality-control",
        "label": "Quality Control",
        "id": "quality-control",
        "icon": DEFAULT_PAGE_ICON_PATH,
        "description": "Build this page with SDK components.",
    } in nav_items

    output = capsys.readouterr().out
    assert "Generated frontend plugin contract:" in output
    assert "Added frontend page frontend/src/views/QualityControlView.vue" in output


def test_add_frontend_page_updates_older_inline_page_selector(
    tmp_path: Path,
) -> None:
    project = _make_scaffold(tmp_path, frontend=True)
    app_vue = project / "frontend" / "src" / "App.vue"
    app_vue.write_text("""\
<script setup lang="ts">
const pageSelector = [
  { id: 'dashboard', label: 'Dashboard', to: '/', icon: 'DASHBOARD_ICON' },
]

const currentPageSelectorId = 'dashboard'
</script>

<template>
  <router-view />
</template>
""")

    cmd_add_frontend_page(path=str(project), name="quality-control")

    content = app_vue.read_text()
    assert "id: 'quality-control'" in content
    assert "id: 'quality_control'" not in content
    assert "label: 'Quality Control'" in content
    assert "to: '/quality-control'" in content
    assert f"icon: '{DEFAULT_PAGE_ICON_PATH}'" in content
    assert "hint: 'Build this page with SDK components.'" in content
    assert "description: 'Build this page with SDK components.'" not in content
    assert content.index("id: 'quality-control'") < content.index("const currentPageSelectorId")


def test_add_frontend_page_creates_plugin_nav_items_for_legacy_metadata(
    tmp_path: Path,
) -> None:
    project = _make_scaffold(tmp_path, frontend=True)
    plugin_py = project / "src" / "mint_plugin_my_analyzer" / "plugin.py"
    content = plugin_py.read_text()
    nav_start = content.index("            nav_items=[")
    nav_end = content.index("            ],", nav_start) + len("            ],\n")
    content = content[:nav_start] + content[nav_end:]
    content = content.replace("    PluginNavItem,\n", "")
    plugin_py.write_text(content)

    cmd_add_frontend_page(path=str(project), name="quality-control")

    plugin_content = plugin_py.read_text()
    assert "PluginNavItem," in plugin_content
    assert "nav_items=[" in plugin_content
    assert "path='/quality-control'" in plugin_content
    assert "label='Quality Control'" in plugin_content
    assert "id='quality-control'" in plugin_content
    assert f"icon='{DEFAULT_PAGE_ICON_PATH}'" in plugin_content
    assert "description='Build this page with SDK components.'" in plugin_content

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert {
        "path": "/quality-control",
        "label": "Quality Control",
        "id": "quality-control",
        "icon": DEFAULT_PAGE_ICON_PATH,
        "description": "Build this page with SDK components.",
    } in contract["plugin"]["navItems"]


def test_add_endpoint_generate_refreshes_frontend_contract(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_endpoint(
        path=str(project),
        name="summary",
        route_path="/summary",
        method=HttpMethod.get,
        router="analysis",
        generate=True,
    )

    output = capsys.readouterr().out
    assert "Generated frontend plugin contract:" in output
    assert "Next: mint sdk generate" not in output
    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert "summary" in [endpoint["name"] for endpoint in contract["endpoints"]]


def test_add_setting_generate_refreshes_frontend_contract(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_setting(
        path=str(project),
        name="threshold",
        field_type=SettingType.number,
        default="2.5",
        description="Score cutoff",
        generate=True,
    )

    output = capsys.readouterr().out
    assert "Generated frontend plugin contract:" in output
    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert contract["settings"]["modelName"] == "MyAnalyzerSettings"


def test_add_router_creates_and_registers_router(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_router(path=str(project), name="imports", prefix="/imports", tag="imports")

    router = project / "src" / "mint_plugin_my_analyzer" / "routers" / "imports.py"
    assert router.exists()
    assert 'router = APIRouter(tags=["imports"])' in router.read_text()

    plugin_content = (project / "src" / "mint_plugin_my_analyzer" / "plugin.py").read_text()
    assert "from mint_plugin_my_analyzer.routers import (\n    analysis,\n    imports,\n)" in plugin_content
    assert '(imports.router, "/imports"),' in plugin_content


def test_add_endpoint_can_create_router_and_import_models(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_schema(path=str(project), name="RunRequest", fields=["threshold:float=0.5"])
    cmd_add_schema(path=str(project), name="RunResponse", file="responses", fields=["status:str=ok"])

    cmd_add_endpoint(
        path=str(project),
        name="run import",
        route_path="/run",
        method=HttpMethod.post,
        router="imports",
        create_router=True,
        request_model="RunRequest",
        response_model="RunResponse",
    )

    router_content = (project / "src" / "mint_plugin_my_analyzer" / "routers" / "imports.py").read_text()
    assert (
        "from fastapi import APIRouter\n\n"
        "from mint_plugin_my_analyzer.schemas.requests import RunRequest"
    ) in router_content
    assert "from mint_plugin_my_analyzer.schemas.requests import RunRequest" in router_content
    assert "from mint_plugin_my_analyzer.schemas.responses import RunResponse" in router_content
    assert '@router.post("/run", response_model=RunResponse)' in router_content
    assert "async def run_import(request: RunRequest)" in router_content


def test_add_migration_creates_package_and_registers_it(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_migration(path=str(project), name="add scores table")

    migration = project / "src" / "mint_plugin_my_analyzer" / "migrations" / "v001_add_scores_table.py"
    assert migration.exists()
    plugin_content = (project / "src" / "mint_plugin_my_analyzer" / "plugin.py").read_text()
    assert "def get_migrations_package(self) -> str:" in plugin_content
    assert 'return "mint_plugin_my_analyzer.migrations"' in plugin_content


def test_add_schema_appends_pydantic_model(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_schema(
        path=str(project),
        name="ImportRequest",
        fields=["threshold:float=0.25", "enabled:bool=true", "labels:list=a|b"],
    )

    content = (project / "src" / "mint_plugin_my_analyzer" / "schemas" / "requests.py").read_text()
    assert "class ImportRequest(BaseModel):" in content
    assert "threshold: float = Field(default=0.25)" in content
    assert "enabled: bool = Field(default=True)" in content
    assert "labels: list[str] = Field(default=['a', 'b'])" in content


def test_add_service_creates_singleton_service(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_service(path=str(project), name="import", method="parse")

    content = (
        project / "src" / "mint_plugin_my_analyzer" / "services" / "import_service.py"
    ).read_text()
    assert "class ImportService:" in content
    assert "async def parse(self, payload: dict | None = None) -> dict:" in content
    assert "def get_import_service() -> ImportService:" in content


def test_add_job_registers_jobs_router(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_job(path=str(project), name="fit")

    assert (project / "src" / "mint_plugin_my_analyzer" / "services" / "jobs.py").exists()
    assert (project / "src" / "mint_plugin_my_analyzer" / "routers" / "jobs.py").exists()
    plugin_content = (project / "src" / "mint_plugin_my_analyzer" / "plugin.py").read_text()
    assert "from mint_plugin_my_analyzer.routers import (\n    analysis,\n    jobs,\n)" in plugin_content
    assert '(jobs.router, "/jobs"),' in plugin_content


def test_add_hook_inserts_lifecycle_hook(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_hook(path=str(project), hook=HookKind.before_save)

    plugin_content = (project / "src" / "mint_plugin_my_analyzer" / "plugin.py").read_text()
    assert "LifecycleHookResult" in plugin_content
    assert "async def on_before_experiment_save(" in plugin_content
    assert "return LifecycleHookResult(success=True)" in plugin_content


def test_add_frontend_composable_uses_generated_client(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_frontend_composable(path=str(project), name="imports", endpoint="/imports")

    content = (project / "frontend" / "src" / "composables" / "useImports.ts").read_text()
    assert "import { useGeneratedPluginClient } from '../generated/mint-plugin'" in content
    assert "const endpointName = 'imports' satisfies keyof PluginClient" in content
    assert "const endpointPath = '/imports'" in content
    assert "Parameters<PluginClient[typeof endpointName]>" in content
    assert "return pluginClient[endpointName](...args)" in content
    assert "VITE_API_PREFIX || '/api" not in content

    output = capsys.readouterr().out
    assert "Next: mint sdk generate" in output
    assert "Added frontend composable frontend/src/composables/useImports.ts" in output


def test_add_data_template_creates_backend_helper(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.plate_map)

    module_root = project / "src" / "mint_plugin_my_analyzer"
    helper = project / "src" / "mint_plugin_my_analyzer" / "templates" / "plate_map.py"
    assert helper.exists()
    content = helper.read_text()
    assert "from mint_sdk.templates import PlateMapTemplate" in content
    assert "def create_default_plate_map() -> PlateMapTemplate:" in content
    assert "PlateMapTemplate.create_96_well(" in content

    service = (module_root / "services" / "plate_map_template.py").read_text()
    assert "def set_plate_map_template_plugin(plugin: AnalysisPlugin) -> None:" in service
    assert "def get_plate_map_template_plugin() -> AnalysisPlugin:" in service

    router = (module_root / "routers" / "plate_map_template.py").read_text()
    assert '@router.get("/{experiment_id}", response_model=PlateMapTemplateResponse)' in router
    assert '@router.post("/{experiment_id}", response_model=PlateMapTemplateResponse)' in router
    assert "await load_template(plugin, experiment_id, PlateMapTemplate)" in router
    assert "await save_template(" in router
    assert "merge=True" in router

    plugin_content = (module_root / "plugin.py").read_text()
    assert "from mint_plugin_my_analyzer.routers import (\n    analysis,\n    plate_map_template,\n)" in plugin_content
    assert (
        "from mint_plugin_my_analyzer.services import (\n"
        "    plate_map_template as plate_map_template_service,\n"
        ")"
        in plugin_content
    )
    assert "plate_map_template_service.set_plate_map_template_plugin(self)" in plugin_content
    assert '(plate_map_template.router, "/templates/plate-map"),' in plugin_content


def test_add_data_template_creates_expanded_template_helper(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.time_course)

    module_root = project / "src" / "mint_plugin_my_analyzer"
    helper = module_root / "templates" / "time_course.py"
    content = helper.read_text()
    assert "from mint_sdk.templates import TimeCourseTemplate" in content
    assert "def create_default_time_course() -> TimeCourseTemplate:" in content

    router = (module_root / "routers" / "time_course_template.py").read_text()
    assert "TimeCourseTemplateSchemaResponse" in router
    assert "class TimeCourseTemplateEnvelope(BaseModel):" in router
    assert 'template_id: Literal["time-course"]' in router
    assert "data: TimeCourseTemplate" in router
    assert "template: TimeCourseTemplateEnvelope" in router
    assert "default_template: TimeCourseTemplateEnvelope" in router
    assert "require_template_info(\"time-course\")" in router
    assert "TimeCourseTemplate.model_json_schema()" in router


def test_add_data_template_creates_frontend_composable(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.sample_sheet)

    content = (project / "frontend" / "src" / "composables" / "useSampleSheetTemplate.ts").read_text()
    assert "useGeneratedPluginClient" in content
    assert "useCurrentExperiment" in content
    assert "currentExperimentId" in content
    assert "hasExperiment" in content
    assert "requireExperimentId" in content
    assert "createSampleSheetTemplate" in content
    assert "ensureTemplateEnvelope" in content
    assert "toTemplateDataFrame" in content
    assert "const dataFrame = computed(() => toTemplateDataFrame(template.value))" in content
    assert "toSampleOptions" in content
    assert "metadata: {}" not in content
    assert "as SampleSheetTemplate" not in content
    assert "useRequestSyncState" in content
    assert "const request = useRequestSyncState('Template request failed.')" in content
    assert "const loading = computed(() => request.loading.value)" in content
    assert "const error = computed(() => request.error.value)" in content
    assert "const lastLoadedAt = computed(() => request.lastLoadedAt.value)" in content
    assert "const lastSavedAt = computed(() => request.lastSavedAt.value)" in content
    assert "function readErrorMessage(" not in content
    assert "return request.run(async () => {" in content
    assert "error," in content
    assert "getSampleSheetTemplateSchema" in content
    assert "getSampleSheetTemplate" in content
    assert "saveSampleSheetTemplate" in content
    assert "async function loadSchema()" in content
    assert "async function resetToDefaultTemplate()" in content
    assert "async function load(experimentId?: number)" in content
    assert "async function loadCurrent()" in content
    assert "const response = await load(requireExperimentId())" in content
    assert "async function save(experimentId?: number)" in content
    assert "async function saveCurrent()" in content
    assert "const response = await save(requireExperimentId())" in content
    load_section = content.split("async function load(experimentId?: number)", 1)[1].split(
        "async function loadCurrent()",
        1,
    )[0]
    load_current_section = content.split("async function loadCurrent()", 1)[1].split(
        "async function save(experimentId?: number)",
        1,
    )[0]
    save_section = content.split("async function save(experimentId?: number)", 1)[1].split(
        "async function saveCurrent()",
        1,
    )[0]
    save_current_section = content.split("async function saveCurrent()", 1)[1].split(
        "return {",
        1,
    )[0]
    assert "request.markLoaded()" in load_section
    assert "request.markLoaded()" not in load_current_section
    assert "request.markSaved()" in save_section
    assert "request.markSaved()" not in save_current_section

    output = capsys.readouterr().out
    assert "Added data template helper" in output
    assert "Added data template API" in output
    assert "Added frontend template composable" in output
    assert "Next: mint sdk generate" in output


def test_add_data_template_creates_expanded_frontend_composable(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.assay_matrix)

    content = (project / "frontend" / "src" / "composables" / "useAssayMatrixTemplate.ts").read_text()
    assert "createAssayMatrixTemplate" in content
    assert "ensureTemplateEnvelope" in content
    assert "toTemplateDataFrame" in content
    assert "const dataFrame = computed(() => toTemplateDataFrame(template.value))" in content
    assert "getAssayMatrixTemplateSchema" in content
    assert "resetToDefaultTemplate" in content


def test_add_data_template_creates_reagent_list_page(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.reagent_list, page=True)

    helper = project / "src" / "mint_plugin_my_analyzer" / "templates" / "reagent_list.py"
    composable = project / "frontend" / "src" / "composables" / "useReagentListTemplate.ts"
    view = project / "frontend" / "src" / "views" / "ReagentListTemplateView.vue"

    assert "ReagentListTemplate.create(" in helper.read_text()
    composable_content = composable.read_text()
    assert "createReagentListTemplate" in composable_content
    assert "ensureTemplateEnvelope" in composable_content
    assert "toReagentListItems" in composable_content
    assert "toTemplateDataFrame" in composable_content

    view_content = view.read_text()
    assert "ReagentList" in view_content
    assert "BioTemplateExperimentWorkspaceView" in view_content
    assert ':target="template"' in view_content
    assert "DataFrame" not in view_content
    assert ":status=" in view_content


def test_add_data_template_creates_protocol_steps_page(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.protocol_steps, page=True)

    helper = project / "src" / "mint_plugin_my_analyzer" / "templates" / "protocol_steps.py"
    composable = project / "frontend" / "src" / "composables" / "useProtocolStepsTemplate.ts"
    view = project / "frontend" / "src" / "views" / "ProtocolStepsTemplateView.vue"

    assert "ProtocolStepsTemplate.create(" in helper.read_text()
    composable_content = composable.read_text()
    assert "createProtocolStepsTemplate" in composable_content
    assert "toProtocolSteps" in composable_content
    assert "toTemplateDataFrame" in composable_content

    view_content = view.read_text()
    assert "BioTemplateExperimentWorkspaceView" in view_content
    assert ':target="template"' in view_content
    assert "ExperimentTimeline" not in view_content
    assert "DataFrame" not in view_content
    assert ":status=" in view_content


def test_add_data_template_pack_creates_curated_templates_once(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template_pack(
        path=str(project),
        pack=DataTemplatePackKind.cell_culture_screen,
        page=True,
    )

    module_root = project / "src" / "mint_plugin_my_analyzer"
    frontend_src = project / "frontend" / "src"

    for template in (
        "sample_sheet",
        "sample_prep",
        "plate_map",
        "reagent_list",
        "protocol_steps",
        "dose_response",
        "flow_cytometry_panel",
    ):
        assert (module_root / "templates" / f"{template}.py").exists()
        assert (module_root / "routers" / f"{template}_template.py").exists()

    pack_helper = module_root / "templates" / "cell_culture_screen_pack.py"
    pack_router = module_root / "routers" / "cell_culture_screen_template_pack.py"
    pack_composable = frontend_src / "composables" / "useCellCultureScreenTemplatePack.ts"
    pack_view = frontend_src / "views" / "CellCultureScreenTemplatePackView.vue"
    assert "create_template_collection" in pack_helper.read_text()
    assert "save_template_collection" in pack_router.read_text()
    assert "load_template_collection" in pack_router.read_text()
    pack_composable_content = pack_composable.read_text()
    assert "useBioTemplatePackWorkspace" in pack_composable_content
    assert "const workspace = useBioTemplatePackWorkspace(packId)" in pack_composable_content
    assert "const packId = 'cell-culture-screen' satisfies TemplatePackId" in pack_composable_content
    assert "useTemplateCollection" not in pack_composable_content
    assert "createTemplateCollection" not in pack_composable_content
    assert "currentExperimentId" in pack_composable_content
    assert "hasExperiment" in pack_composable_content
    assert "ensureTemplateFromCollection" in pack_composable_content
    assert "function loadCurrent(" in pack_composable_content
    assert "return load(workspace.requireCurrentExperimentId())" in pack_composable_content
    assert "function saveCurrent(" in pack_composable_content
    assert "return save(workspace.requireCurrentExperimentId())" in pack_composable_content
    assert "type SaveTemplateMap = NonNullable<" in pack_composable_content
    assert "function createSaveRequest(" in pack_composable_content
    assert "body: createSaveRequest()" in pack_composable_content
    assert "useRequestSyncState" in pack_composable_content
    assert "const request = useRequestSyncState('Template pack request failed.')" in pack_composable_content
    assert "const loading = computed(() => request.loading.value)" in pack_composable_content
    assert "const error = computed(() => request.error.value)" in pack_composable_content
    assert "const lastLoadedAt = computed(() => request.lastLoadedAt.value)" in pack_composable_content
    assert "const lastSavedAt = computed(() => request.lastSavedAt.value)" in pack_composable_content
    assert "Template pack request failed." in pack_composable_content
    assert "function readErrorMessage(" not in pack_composable_content
    assert "return request.run(async () => {" in pack_composable_content
    assert "}, { success: 'load' })" in pack_composable_content
    assert "}, { success: 'save' })" in pack_composable_content
    assert "error," in pack_composable_content
    assert "workspace," in pack_composable_content
    assert "function applyTemplateCollection(" in pack_composable_content
    assert "return workspace.applyCollection(value, metadata)" in pack_composable_content
    assert "extractTemplateCollection" not in pack_composable_content
    assert "readCollectionMetadata" not in pack_composable_content
    assert "return applyTemplateCollection(" in pack_composable_content
    assert "response.default_collection" in pack_composable_content
    long_lines = [
        (line_number, len(line))
        for line_number, line in enumerate(pack_composable_content.splitlines(), start=1)
        if len(line) > 120
    ]
    assert long_lines == []

    assert (frontend_src / "views" / "SampleSheetTemplateView.vue").exists()
    assert (frontend_src / "views" / "SamplePrepTemplateView.vue").exists()
    assert (frontend_src / "views" / "ProtocolStepsTemplateView.vue").exists()
    assert (frontend_src / "views" / "ReagentListTemplateView.vue").exists()
    assert pack_view.exists()
    pack_view_content = pack_view.read_text()
    assert "useCellCultureScreenTemplatePack" in pack_view_content
    assert "import { watch } from 'vue'" in pack_view_content
    assert "BioTemplatePackWorkspaceView" in pack_view_content
    assert "BioTemplateExperimentWorkspaceView" not in pack_view_content
    assert "RouterLink" not in pack_view_content
    assert "BioTemplateRenderer" not in pack_view_content
    assert "templateSummaries" not in pack_view_content
    assert "workspace," in pack_view_content
    assert "currentExperimentId," in pack_view_content
    assert "loadCurrent," in pack_view_content
    assert "saveCurrent," in pack_view_content
    assert "error," in pack_view_content
    assert "lastLoadedAt," in pack_view_content
    assert "lastSavedAt," in pack_view_content
    assert "watch(" in pack_view_content
    assert "void loadCurrent().catch(() => undefined)" in pack_view_content
    assert ':workspace="workspace"' in pack_view_content
    assert ":status=" in pack_view_content
    assert ":actions=" in pack_view_content
    assert "load: loadCurrent" in pack_view_content
    assert "reset: resetToDefaultTemplates" in pack_view_content
    assert "save: saveCurrent" in pack_view_content
    assert '@load="loadCurrent()"' not in pack_view_content
    assert '@save="saveCurrent()"' not in pack_view_content
    assert ":to=\"template.route\"" not in pack_view_content
    assert ':target="collection"' not in pack_view_content
    assert "show-template-summary" in pack_view_content

    main_ts = (frontend_src / "main.ts").read_text()
    assert "name: 'cell_culture_screen_template_pack'" in main_ts
    assert "import('./views/CellCultureScreenTemplatePackView.vue')" in main_ts

    app_vue = (frontend_src / "App.vue").read_text()
    assert "pluginPageSelectorItems" in app_vue
    assert "Cell Culture Screen Template Pack" not in app_vue

    contract_path = frontend_src / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    endpoint_names = [endpoint["name"] for endpoint in contract["endpoints"]]
    assert {
        "path": "/templates/packs/cell-culture-screen",
        "label": "Cell Culture Screen Template Pack",
        "id": "templates-packs-cell-culture-screen",
        "icon": TEMPLATE_PAGE_ICON_PATH,
        "description": "Open Cell Culture Screen Template Pack.",
    } in contract["plugin"]["navItems"]
    assert "getSamplePrepTemplate" in endpoint_names
    assert "getProtocolStepsTemplate" in endpoint_names
    assert "getReagentListTemplate" in endpoint_names
    assert "getDoseResponseTemplate" in endpoint_names
    assert "getFlowCytometryPanelTemplate" in endpoint_names
    assert "getCellCultureScreenTemplatePack" in endpoint_names
    assert "saveCellCultureScreenTemplatePack" in endpoint_names
    _assert_doctor_accepts_generated_frontend(project)

    output = capsys.readouterr().out
    assert "Adding data template pack 'cell-culture-screen':" in output
    assert "Added frontend template pack page" in output
    assert output.count("Generated frontend plugin contract:") == 1


def test_add_data_template_pack_creates_molecular_assay(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template_pack(
        path=str(project),
        pack=DataTemplatePackKind.molecular_assay,
        page=True,
    )

    module_root = project / "src" / "mint_plugin_my_analyzer"
    frontend_src = project / "frontend" / "src"
    assert (module_root / "templates" / "sample_prep.py").exists()
    assert (module_root / "templates" / "calibration_curve.py").exists()
    assert (module_root / "templates" / "qpcr_plate.py").exists()
    assert (module_root / "templates" / "instrument_run.py").exists()
    assert (module_root / "routers" / "sample_prep_template.py").exists()
    assert (module_root / "routers" / "calibration_curve_template.py").exists()
    assert (module_root / "routers" / "qpcr_plate_template.py").exists()
    assert (module_root / "routers" / "instrument_run_template.py").exists()
    assert (module_root / "routers" / "molecular_assay_template_pack.py").exists()
    assert (frontend_src / "views" / "SamplePrepTemplateView.vue").exists()
    assert (frontend_src / "views" / "CalibrationCurveTemplateView.vue").exists()
    assert (frontend_src / "views" / "QpcrPlateTemplateView.vue").exists()
    assert (frontend_src / "views" / "InstrumentRunTemplateView.vue").exists()
    pack_composable = frontend_src / "composables" / "useMolecularAssayTemplatePack.ts"
    assert pack_composable.exists()
    assert "applyTemplateCollection" in pack_composable.read_text()

    client = (frontend_src / "generated" / "mint-plugin.ts").read_text()
    assert "getSamplePrepTemplate" in client
    assert "getCalibrationCurveTemplate" in client
    assert "getQpcrPlateTemplate" in client
    assert "saveQpcrPlateTemplate" in client
    assert "getInstrumentRunTemplate" in client
    assert "getMolecularAssayTemplatePack" in client
    assert "saveMolecularAssayTemplatePack" in client


def test_add_data_template_preset_creates_current_experiment_shortcuts(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template_preset(
        path=str(project),
        preset=DataTemplatePresetKind.wellplate_screen,
        page=True,
    )

    module_root = project / "src" / "mint_plugin_my_analyzer"
    frontend_src = project / "frontend" / "src"
    helper = module_root / "templates" / "wellplate_screen_preset.py"
    composable = frontend_src / "composables" / "useWellplateScreenTemplatePreset.ts"
    view = frontend_src / "views" / "WellplateScreenTemplatePresetView.vue"

    assert helper.exists()
    assert "create_template_preset_collection" in helper.read_text()
    assert 'PRESET_ID = "wellplate-screen"' in helper.read_text()

    composable_content = composable.read_text()
    assert "useBioTemplatePresetWorkspace" in composable_content
    assert "UseBioTemplatePresetWorkspaceOptions" in composable_content
    assert "type TemplatePresetId" in composable_content
    assert "const presetId = 'wellplate-screen' satisfies TemplatePresetId" in composable_content
    assert "return useBioTemplatePresetWorkspace(presetId, options)" in composable_content
    assert "useBioTemplateControls" not in composable_content
    assert "useTemplateCollection" not in composable_content
    assert "createBioTemplatePresetCollectionFromControls" not in composable_content
    assert "watch(" not in composable_content

    view_content = view.read_text()
    assert "BioTemplatePresetWorkspaceView" in view_content
    assert 'preset="wellplate-screen"' in view_content
    assert 'label="Wellplate Screen"' in view_content
    assert "useWellplateScreenTemplatePreset" not in view_content
    assert ':workspace="workspace"' not in view_content
    assert "AppSidebar" not in view_content
    assert "BioTemplateRenderer" not in view_content
    assert "FormBuilder" not in view_content
    assert ":controls=" not in view_content
    assert ":active-view=" not in view_content
    assert "v-model:values" not in view_content
    assert ':forms="controls.sectionSchemas"' not in view_content
    assert "#[`section-${section.id}`]" not in view_content
    assert "componentProps.length" not in view_content

    main_ts = (frontend_src / "main.ts").read_text()
    assert "name: 'wellplate_screen_template_preset'" in main_ts
    assert "import('./views/WellplateScreenTemplatePresetView.vue')" in main_ts

    app_vue = (frontend_src / "App.vue").read_text()
    assert "pluginPageSelectorItems" in app_vue
    assert "Wellplate Screen Preset" not in app_vue

    output = capsys.readouterr().out
    assert "Added data-template preset helper" in output
    assert "Added frontend template preset composable" in output
    assert "Added frontend template preset page" in output
    assert "Generated frontend plugin contract:" in output

    contract_path = frontend_src / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert {
        "path": "/templates/presets/wellplate-screen",
        "label": "Wellplate Screen Preset",
        "id": "templates-presets-wellplate-screen",
        "icon": PRESET_PAGE_ICON_PATH,
        "description": "Open Wellplate Screen Preset.",
    } in contract["plugin"]["navItems"]
    _assert_doctor_accepts_generated_frontend(project)


def test_add_data_template_page_registers_view_and_generates_contract(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.plate_map, page=True)

    view = project / "frontend" / "src" / "views" / "PlateMapTemplateView.vue"
    assert view.exists()
    view_content = view.read_text()
    assert "BioTemplateExperimentWorkspaceView" in view_content
    assert "usePlateMapTemplate" in view_content
    assert "useCurrentExperiment" not in view_content
    assert "currentExperimentId.value ?? 1" not in view_content
    assert "import { watch } from 'vue'" in view_content
    assert "currentExperimentId," in view_content
    assert "hasExperiment" in view_content
    assert "loadCurrent," in view_content
    assert "saveCurrent," in view_content
    assert "error," in view_content
    assert "lastLoadedAt," in view_content
    assert "lastSavedAt," in view_content
    assert "watch(" in view_content
    assert "void loadCurrent().catch(() => undefined)" in view_content
    assert "function loadCurrentTemplate()" not in view_content
    assert "function saveCurrentTemplate()" not in view_content
    assert "return load()" not in view_content
    assert ":status=" in view_content
    assert ":actions=" in view_content
    assert "load: loadCurrent" in view_content
    assert "save: saveCurrent" in view_content
    assert '@load="loadCurrent()"' not in view_content
    assert '@save="saveCurrent()"' not in view_content
    assert "function resetCurrentTemplate()" not in view_content
    assert '@reset="resetToDefaultTemplate()"' not in view_content
    assert "reset: resetToDefaultTemplate" in view_content
    assert "resetToDefaultTemplate" in view_content
    assert ':target="template"' in view_content
    assert "PlateMapEditor" not in view_content

    main_ts = (project / "frontend" / "src" / "main.ts").read_text()
    assert "name: 'plate_map_template'" in main_ts
    assert "import('./views/PlateMapTemplateView.vue')" in main_ts

    app_vue = (project / "frontend" / "src" / "App.vue").read_text()
    assert "pluginPageSelectorItems" in app_vue
    assert "Plate Map Template" not in app_vue
    output = capsys.readouterr().out
    assert "Added frontend template page" in output
    assert "Generated frontend plugin contract:" in output

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert "getPlateMapTemplate" in [endpoint["name"] for endpoint in contract["endpoints"]]
    assert {
        "path": "/templates/plate-map",
        "label": "Plate Map Template",
        "id": "templates-plate-map",
        "icon": TEMPLATE_PAGE_ICON_PATH,
        "description": "Open Plate Map Template.",
    } in contract["plugin"]["navItems"]


def test_add_data_template_page_uses_dataframe_adapter(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.sample_sheet, page=True)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.sample_prep, page=True)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.calibration_curve, page=True)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.flow_cytometry_panel, page=True)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.instrument_run, page=True)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.qpcr_plate, page=True)

    composable = (project / "frontend" / "src" / "composables" / "useSampleSheetTemplate.ts").read_text()
    view = (project / "frontend" / "src" / "views" / "SampleSheetTemplateView.vue").read_text()
    assert "toTemplateDataFrame" in composable
    assert "BioTemplateExperimentWorkspaceView" in view
    assert ':target="template"' in view
    assert "DataFrame" not in view

    prep_composable = (project / "frontend" / "src" / "composables" / "useSamplePrepTemplate.ts").read_text()
    prep_view = (project / "frontend" / "src" / "views" / "SamplePrepTemplateView.vue").read_text()
    assert "toSamplePrepDataFrame" in prep_composable
    assert "ensureTemplateEnvelope" in prep_composable
    assert "BioTemplateExperimentWorkspaceView" in prep_view
    assert ':target="template"' in prep_view
    assert "DataFrame" not in prep_view

    calibration_composable = (
        project / "frontend" / "src" / "composables" / "useCalibrationCurveTemplate.ts"
    ).read_text()
    calibration_view = (project / "frontend" / "src" / "views" / "CalibrationCurveTemplateView.vue").read_text()
    assert "toCalibrationCurveDataFrame" in calibration_composable
    assert "ensureTemplateEnvelope" in calibration_composable
    assert "BioTemplateExperimentWorkspaceView" in calibration_view
    assert ':target="template"' in calibration_view
    assert "DataFrame" not in calibration_view

    flow_composable = (
        project / "frontend" / "src" / "composables" / "useFlowCytometryPanelTemplate.ts"
    ).read_text()
    flow_view = (project / "frontend" / "src" / "views" / "FlowCytometryPanelTemplateView.vue").read_text()
    assert "toFlowPanelDataFrame" in flow_composable
    assert "ensureTemplateEnvelope" in flow_composable
    assert "BioTemplateExperimentWorkspaceView" in flow_view
    assert ':target="template"' in flow_view
    assert "DataFrame" not in flow_view

    run_composable = (project / "frontend" / "src" / "composables" / "useInstrumentRunTemplate.ts").read_text()
    run_view = (project / "frontend" / "src" / "views" / "InstrumentRunTemplateView.vue").read_text()
    assert "toInstrumentRunDataFrame" in run_composable
    assert "ensureTemplateEnvelope" in run_composable
    assert "BioTemplateExperimentWorkspaceView" in run_view
    assert ':target="template"' in run_view
    assert "DataFrame" not in run_view

    qpcr_composable = (project / "frontend" / "src" / "composables" / "useQpcrPlateTemplate.ts").read_text()
    qpcr_view = (project / "frontend" / "src" / "views" / "QpcrPlateTemplateView.vue").read_text()
    assert "toQpcrDataFrame" in qpcr_composable
    assert "toQpcrWellPlateWells" in qpcr_composable
    assert "ensureTemplateEnvelope" in qpcr_composable
    assert "BioTemplateExperimentWorkspaceView" in qpcr_view
    assert ':target="template"' in qpcr_view
    assert "DataFrame" not in qpcr_view


def test_add_data_template_pages_require_current_experiment(tmp_path: Path) -> None:
    for template in DataTemplateKind:
        project = _make_scaffold(tmp_path / template.value, frontend=True)

        cmd_add_data_template(path=str(project), template=template, page=True)

        template_pascal = "".join(part.title() for part in template.value.split("-"))
        view = (project / "frontend" / "src" / "views" / f"{template_pascal}TemplateView.vue").read_text()
        assert "currentExperimentId.value ?? 1" not in view
        assert "currentExperimentId," in view
        assert "useCurrentExperiment" not in view
        assert "loadCurrent," in view
        assert "saveCurrent," in view
        assert "watch(" in view
        assert "void loadCurrent().catch(() => undefined)" in view
        assert ":status=" in view
        assert ":actions=" in view
        assert "load: loadCurrent" in view
        assert "save: saveCurrent" in view
        assert '@load="loadCurrent()"' not in view
        assert '@save="saveCurrent()"' not in view


def test_add_data_template_page_skips_without_frontend(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=False)

    cmd_add_data_template(path=str(project), template=DataTemplateKind.dose_response, page=True)

    assert not (project / "frontend").exists()
    assert "Skipped frontend page" in capsys.readouterr().err


def test_add_data_template_generate_refreshes_contract(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_data_template(
        path=str(project),
        template=DataTemplateKind.dose_response,
        generate=True,
    )

    output = capsys.readouterr().out
    assert "Generated frontend plugin contract:" in output
    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    endpoint_names = [endpoint["name"] for endpoint in contract["endpoints"]]
    assert "getDoseResponseTemplateSchema" in endpoint_names
    assert "getDoseResponseTemplate" in endpoint_names
    assert "saveDoseResponseTemplate" in endpoint_names
    assert "DoseResponseTemplateEnvelope" in contract["schemas"]
    assert "DoseResponseTemplate" in contract["schemas"]

    client = (project / "frontend" / "src" / "generated" / "mint-plugin.ts").read_text()
    assert "export interface DoseResponseTemplateEnvelope" in client
    assert "data: DoseResponseTemplate" in client
    assert "default_template: DoseResponseTemplateEnvelope" in client
    assert "template: DoseResponseTemplateEnvelope" in client


def test_add_data_template_route_serves_default_template(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path)
    cmd_add_data_template(path=str(project), template=DataTemplateKind.plate_map)

    _clear_generated_plugin_modules()
    sys.path.insert(0, str(project / "src"))
    try:
        module = importlib.import_module("mint_plugin_my_analyzer.plugin")
        module.MyAnalyzerPlugin._instance = None
        with TestClient(module.create_standalone_app()) as client:
            schema_response = client.get("/api/my-analyzer/templates/plate-map/schema")
            assert schema_response.status_code == 200
            schema_body = schema_response.json()
            assert schema_body["template_id"] == "plate-map"
            assert schema_body["label"] == "Plate map"
            assert schema_body["default_template"]["template_id"] == "plate-map"
            assert schema_body["default_template"]["data"]["plates"][0]["format"] == 96
            assert schema_body["json_schema"]["title"] == "PlateMapTemplate"

            response = client.get("/api/my-analyzer/templates/plate-map/42")
            assert response.status_code == 200
            body = response.json()
            assert body["experiment_id"] == 42
            assert body["persisted"] is False
            assert body["template"]["template_id"] == "plate-map"
            assert body["template"]["data"]["activePlateId"] == "plate-1"

            save_response = client.post(
                "/api/my-analyzer/templates/plate-map/42",
                json={"template": body["template"], "metadata": {"source": "test"}},
            )
            assert save_response.status_code == 200
            saved_body = save_response.json()
            assert saved_body["persisted"] is False
            assert saved_body["template"]["metadata"]["source"] == "test"
    finally:
        sys.path.remove(str(project / "src"))
        _clear_generated_plugin_modules()


def test_add_r_analysis_creates_bridge_router_and_script(tmp_path: Path) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_r_analysis(path=str(project), name="drp fit")

    module_root = project / "src" / "mint_plugin_my_analyzer"
    assert (project / "r-requirements.txt").read_text() == "jsonlite\n"
    assert (module_root / "r_scripts" / "mint_bridge.R").exists()
    assert (module_root / "r_scripts" / "drp_fit.R").exists()
    schema = (module_root / "schemas" / "drp_fit_r.py").read_text()
    assert "from typing import Any" in schema
    assert "parameters: dict[str, Any]" in schema
    assert "result: dict[str, Any]" in schema
    assert (module_root / "services" / "drp_fit_r.py").exists()
    assert (module_root / "routers" / "drp_fit_r.py").exists()

    script = (module_root / "r_scripts" / "drp_fit.R").read_text()
    assert 'source("r_scripts/mint_bridge.R")' in script
    assert "payload <- mint_read_input()" in script
    assert "parameters <- mint_parameters(payload)" in script
    assert 'threshold <- mint_parameter("threshold", 0.05, payload)' in script
    assert 'normalize <- mint_parameter("normalize", TRUE, payload)' in script
    assert "artifact_dir <- mint_artifact_dir()" in script
    assert "parameters = parameters" in script
    assert "threshold = threshold" in script
    assert "normalize = normalize" in script
    assert "mint_write_output(result)" in script

    helper = (module_root / "r_scripts" / "mint_bridge.R").read_text()
    assert "mint_read_input" in helper
    assert "mint_parameters" in helper
    assert "mint_parameter" in helper
    assert "mint_required_parameter" in helper
    assert "mint_write_output" in helper
    assert "mint_experiment_id" in helper
    assert "mint_artifact_dir" in helper
    assert "mint_artifact_path" in helper

    service = (module_root / "services" / "drp_fit_r.py").read_text()
    assert "from mint_sdk import AnalysisPlugin, RAnalysisBridge, RScriptSpec" in service
    assert "def set_drp_fit_r_plugin(plugin: AnalysisPlugin) -> None:" in service
    assert "def get_drp_fit_r_plugin() -> AnalysisPlugin:" in service
    assert 'artifact_dir=str(Path.cwd() / ".mint" / "r-artifacts" / "drp_fit")' in service

    router = (module_root / "routers" / "drp_fit_r.py").read_text()
    assert "from fastapi import APIRouter, HTTPException" in router
    assert '@router.post("/run/{experiment_id}", response_model=DrpFitRResponse)' in router
    assert "plugin = _get_plugin()" in router
    assert "await plugin.save_analysis(experiment_id, response.result)" in router
    assert "raise HTTPException(status_code=503, detail=str(exc)) from exc" in router

    plugin_content = (module_root / "plugin.py").read_text()
    assert "from mint_plugin_my_analyzer.routers import (\n    analysis,\n    drp_fit_r,\n)" in plugin_content
    assert "from mint_plugin_my_analyzer.services import (\n    drp_fit_r as drp_fit_r_service,\n)" in plugin_content
    assert "drp_fit_r_service.set_drp_fit_r_plugin(self)" in plugin_content
    assert '(drp_fit_r.router, "/r/drp-fit"),' in plugin_content

    composable = (project / "frontend" / "src" / "composables" / "useDrpFitRAnalysis.ts").read_text()
    assert "const endpointName = 'runDrpFit'" in composable
    assert "useCurrentExperiment" in composable
    assert "useRequestSyncState" in composable
    assert "currentExperimentId" in composable
    assert "hasExperiment" in composable
    assert "const request = useRequestSyncState('R analysis request failed.')" in composable
    assert "const loading = computed(() => request.loading.value)" in composable
    assert "const error = computed(() => request.error.value)" in composable
    assert "const lastRunAt = computed(() => request.lastRunAt.value)" in composable
    assert "return request.run(" in composable
    assert "{ success: 'run' }" in composable
    assert "const loading = ref(false)" not in composable
    assert "error = ref<unknown | null>" not in composable
    assert "function runCurrent()" in composable
    assert "return run(requireExperimentId())" in composable
    assert "function runCurrentWithParameters(" in composable
    assert "parameters = ref<Record<string, unknown>>" in composable
    assert "function runWithParameters(" in composable
    assert "nextParameters: Record<string, unknown>" in composable


def test_add_r_analysis_page_registers_view_and_generates_contract(tmp_path: Path, capsys) -> None:
    project = _make_scaffold(tmp_path, frontend=True)

    cmd_add_r_analysis(path=str(project), name="drp fit", page=True)

    view = project / "frontend" / "src" / "views" / "DrpFitRAnalysisView.vue"
    assert view.exists()
    view_content = view.read_text()
    assert "useCurrentExperiment" not in view_content
    assert "ControlWorkspaceView" in view_content
    assert "defineControlModel" in view_content
    assert "const workspaceModel = defineControlModel" in view_content
    assert "threshold" in view_content
    assert "normalize" in view_content
    assert 'v-model="analysisValues"' in view_content
    assert ':model="workspaceModel"' in view_content
    assert ':controls="controls"' not in view_content
    assert ':control-options="controlOptions"' not in view_content
    assert "BaseTextarea" not in view_content
    assert "Parameters JSON" not in view_content
    assert "Drp Fit R Analysis runs through" in view_content
    assert "function runCurrentAnalysis(values: Record<string, unknown>)" in view_content
    assert "currentExperimentId.value ?? 1" not in view_content
    assert "return runCurrentWithParameters({ ...values })" in view_content
    assert "lastRunAt" in view_content
    assert "last run:" in view_content
    assert "Parameters JSON must be an object." not in view_content
    assert "isParameterRecord" not in view_content
    assert ':disabled="!hasExperiment"' in view_content

    main_ts = (project / "frontend" / "src" / "main.ts").read_text()
    app_vue = (project / "frontend" / "src" / "App.vue").read_text()
    assert "name: 'drp_fit_r_analysis'" in main_ts
    assert "import('./views/DrpFitRAnalysisView.vue')" in main_ts
    assert "pluginPageSelectorItems" in app_vue
    assert "label: 'Drp Fit R Analysis'" not in app_vue

    output = capsys.readouterr().out
    assert "Added frontend R analysis page" in output
    assert "Generated frontend plugin contract:" in output

    contract_path = project / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
    contract = json.loads(contract_path.read_text())
    assert "runDrpFit" in [endpoint["name"] for endpoint in contract["endpoints"]]
    assert {
        "path": "/r/drp-fit",
        "label": "Drp Fit R Analysis",
        "id": "r-drp-fit",
        "icon": ANALYSIS_PAGE_ICON_PATH,
        "description": "Open Drp Fit R Analysis.",
    } in contract["plugin"]["navItems"]
