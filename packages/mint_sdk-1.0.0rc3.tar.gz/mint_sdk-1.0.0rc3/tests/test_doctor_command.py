"""Tests for ``mint doctor`` command."""

import json
from pathlib import Path

import pytest
from mint_sdk import deprecated_apis, docs_command, doctor_command
from mint_sdk.contract import generate_contract_files
from mint_sdk.deprecated_apis import (
    DEPRECATED_API_DOC,
    DEPRECATED_FRONTEND_COMPONENTS,
    DEPRECATED_FRONTEND_COMPOSABLES,
    DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS,
    DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS,
    DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS,
    DEPRECATED_FRONTEND_EXPRESSION_PATTERNS,
    DEPRECATED_FRONTEND_IMPORT_PATTERNS,
    DEPRECATED_FRONTEND_TAG_RULES,
    DEPRECATED_FRONTEND_TYPES,
    DEPRECATED_TEXT_PATTERNS,
)
from mint_sdk.doctor_command import apply_fixes, cmd_doctor, run_checks
from typer.testing import CliRunner

runner = CliRunner()


def _make_plugin(
    tmp_path: Path, *, with_frontend: bool = False, with_tests: bool = True, with_claude: bool = True
) -> None:
    """Create a minimal valid plugin project structure."""
    # pyproject.toml
    (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "mint-plugin-test"
version = "0.1.0"
description = "Test plugin"
dependencies = ["mint-sdk>=0.9.0"]

[project.entry-points."mint.plugins"]
test = "mint_plugin_test.plugin:TestPlugin"
""")

    # Source module
    src_dir = tmp_path / "src" / "mint_plugin_test"
    src_dir.mkdir(parents=True)
    (src_dir / "__init__.py").write_text("")
    (src_dir / "plugin.py").write_text("""\
from fastapi import APIRouter
from mint_sdk import AnalysisPlugin, PluginMetadata

router = APIRouter()


@router.get("/health")
async def health():
    return {"status": "healthy"}


class TestPlugin(AnalysisPlugin):
    PLUGIN_ROUTES_PREFIX = "/test"

    @property
    def metadata(self):
        return PluginMetadata(
            name="test",
            version="0.1.0",
            description="Test plugin",
            analysis_type="custom",
            routes_prefix="/test",
            icon="M4 4h16",
        )

    def get_routers(self):
        return [(router, "")]

    async def initialize(self, context=None):
        pass

    async def shutdown(self):
        pass
""")

    if with_tests:
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()
        (tests_dir / "test_plugin.py").write_text("def test_placeholder(): pass")

    if with_claude:
        (tmp_path / "CLAUDE.md").write_text(
            "# CLAUDE.md\n\n"
            "Run `mint docs frontend consolidate`, `mint docs deprecated-apis`, "
            "and `mint docs contract .`; use `useGeneratedPluginContract` and "
            "`PluginWorkspaceView`; use "
            "`PluginWorkspaceView sidebar-content-id=\"...\" show-sidebar-when-empty`; "
            "use `AppSidebar variant=\"analysis\"`; use `useBioTemplatePresetWorkspace`, "
            "`useBioTemplatePackWorkspace`, `BioTemplatePackWorkspaceView`, "
            "`ComponentBindingRenderer`, and `componentBindingsById` before "
            "hand-writing SDK code. Use `SettingsModal access metadata`, "
            "`settings_model json_schema_extra`, `can_access_policy`, "
            "`canAccessByPolicy`, and `SegmentedControl disabledValues` for "
            "permission-gated settings and visible disabled tabs.\n"
        )

    if with_frontend:
        fe_dir = tmp_path / "frontend"
        fe_dir.mkdir()
        (fe_dir / "package.json").write_text(
            json.dumps(
                {
                    "dependencies": {"@morscherlab/mint-sdk": "^0.9.0"},
                }
            )
        )
        generate_contract_files(tmp_path)


class TestRunChecks:
    def test_all_pass_for_valid_plugin(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        results = run_checks(tmp_path)
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_missing_pyproject(self, tmp_path: Path):
        results = run_checks(tmp_path)
        assert not results[0].ok
        assert "not found" in results[0].detail

    def test_missing_entry_point(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'test'\n")
        results = run_checks(tmp_path)
        # pyproject ok, entry point fails
        assert results[0].ok
        assert not results[1].ok
        assert "mint.plugins" in results[1].detail

    def test_bad_entry_point_format(self, tmp_path: Path):
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "test"

[project.entry-points."mint.plugins"]
bad = "no_colon_here"
""")
        results = run_checks(tmp_path)
        assert not results[1].ok
        assert "colon" in results[1].detail

    def test_missing_source_module(self, tmp_path: Path):
        _make_plugin(tmp_path)
        # Remove source
        (tmp_path / "src" / "mint_plugin_test" / "plugin.py").unlink()
        results = run_checks(tmp_path)
        assert not results[2].ok
        assert "not found" in results[2].detail

    def test_missing_plugin_class(self, tmp_path: Path):
        _make_plugin(tmp_path)
        # Overwrite with no class
        (tmp_path / "src" / "mint_plugin_test" / "plugin.py").write_text("x = 1")
        results = run_checks(tmp_path)
        assert not results[3].ok
        assert "not found" in results[3].detail

    def test_missing_sdk_dependency(self, tmp_path: Path):
        _make_plugin(tmp_path)
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "mint-plugin-test"
dependencies = ["fastapi"]

[project.entry-points."mint.plugins"]
test = "mint_plugin_test.plugin:TestPlugin"
""")
        results = run_checks(tmp_path)
        sdk_check = [r for r in results if r.label == "Python SDK dep"][0]
        assert not sdk_check.ok

    def test_missing_frontend_sdk(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        # Overwrite package.json with no SDK dep
        (tmp_path / "frontend" / "package.json").write_text('{"dependencies":{}}')
        results = run_checks(tmp_path)
        fe_check = [r for r in results if r.label == "Frontend SDK dep"][0]
        assert not fe_check.ok

    def test_no_frontend_is_ok(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=False)
        results = run_checks(tmp_path)
        fe_check = [r for r in results if r.label == "Frontend SDK dep"][0]
        assert fe_check.ok  # "no frontend (ok)"

    def test_missing_tests_dir(self, tmp_path: Path):
        _make_plugin(tmp_path, with_tests=False)
        results = run_checks(tmp_path)
        tests_check = [r for r in results if r.label == "Tests"][0]
        assert not tests_check.ok

    def test_missing_ai_instructions(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        results = run_checks(tmp_path)
        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok

    def test_missing_generated_contract_fails_for_frontend_plugin(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        generated = tmp_path / "frontend" / "src" / "generated"
        for path in generated.iterdir():
            path.unlink()

        results = run_checks(tmp_path)

        contract_check = [r for r in results if r.label == "Generated contract"][0]
        assert not contract_check.ok
        assert contract_check.fix_id == "generated-contract"

    def test_legacy_frontend_api_wiring_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyView.vue").write_text("""\
<script setup lang="ts">
import { useApi } from '@morscherlab/mint-sdk'

const prefix = import.meta.env.VITE_API_PREFIX || '/api/test'
const api = useApi({ baseUrl: prefix })
</script>
""")

        results = run_checks(tmp_path)

        wiring_check = [r for r in results if r.label == "Frontend API wiring"][0]
        assert not wiring_check.ok
        assert "LegacyView.vue" in wiring_check.detail
        assert "VITE_API_PREFIX" in wiring_check.detail
        assert "useApi({ baseUrl })" in wiring_check.detail
        assert "generated contract metadata" in wiring_check.explanation
        assert "mint docs frontend-api" in wiring_check.fix_hint
        assert "mint docs contract ." in wiring_check.fix_hint
        assert "useGeneratedPluginClient()" in wiring_check.fix_hint
        assert wiring_check.fix_id is None

    def test_multiline_use_api_base_url_fails_wiring_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyMultilineApi.vue").write_text("""\
<script setup lang="ts">
import { useApi } from '@morscherlab/mint-sdk'

const prefix = '/api/test'
const api = useApi({
  timeout: 1000,
  baseUrl: prefix,
  withAuth: true,
})
</script>
""")

        results = run_checks(tmp_path)

        wiring_check = [r for r in results if r.label == "Frontend API wiring"][0]
        assert not wiring_check.ok
        assert "LegacyMultilineApi.vue" in wiring_check.detail
        assert "useApi({ baseUrl })" in wiring_check.detail

    def test_raw_frontend_api_calls_fail_wiring_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "RawApiView.vue").write_text("""\
<script setup lang="ts">
import axios from 'axios'

const health = await fetch('/api/test/health')
const summary = await axios.get('/api/test/summary')
const api = useApi()
const rows = await api.get('/api/test/rows')
</script>
""")

        results = run_checks(tmp_path)

        wiring_check = [r for r in results if r.label == "Frontend API wiring"][0]
        assert not wiring_check.ok
        assert "RawApiView.vue" in wiring_check.detail
        assert "fetch('/api/...')" in wiring_check.detail
        assert "axios('/api/...')" in wiring_check.detail
        assert "client.get('/api/...')" in wiring_check.detail
        assert "raw `/api/...` calls" in wiring_check.fix_hint

    def test_template_literal_frontend_api_calls_fail_wiring_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "TemplateRawApiView.vue").write_text("""\
<script setup lang="ts">
import axios from 'axios'
import { useApi } from '@morscherlab/mint-sdk'

const api = useApi(`/api/test`)
const rows = await api.get(`/api/test/rows`)
const health = await fetch(`/api/test/health`)
const summary = await axios.get(`/api/test/summary`)
</script>
""")

        results = run_checks(tmp_path)

        wiring_check = [r for r in results if r.label == "Frontend API wiring"][0]
        assert not wiring_check.ok
        assert "TemplateRawApiView.vue" in wiring_check.detail
        assert "useApi('/api/...')" in wiring_check.detail
        assert "fetch('/api/...')" in wiring_check.detail
        assert "axios('/api/...')" in wiring_check.detail
        assert "client.get('/api/...')" in wiring_check.detail

    def test_generated_frontend_client_usage_passes_api_wiring(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ModernView.vue").write_text("""\
<script setup lang="ts">
import { useGeneratedPluginClient } from '../generated/mint-plugin'

const pluginClient = useGeneratedPluginClient()
</script>
""")

        results = run_checks(tmp_path)

        wiring_check = [r for r in results if r.label == "Frontend API wiring"][0]
        assert wiring_check.ok
        assert wiring_check.detail == "contract-first patterns"

    def test_manual_frontend_workspace_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualWorkspace.vue").write_text("""\
<script setup lang="ts">
import { AppSidebar, AppTopBar, FormBuilder } from '@morscherlab/mint-sdk'

const panels = []
const schema = []
</script>

<template>
  <AppTopBar title="Analysis" />
  <AppSidebar :panels="panels" />
  <FormBuilder :schema="schema" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualWorkspace.vue" in guidance_check.detail
        assert "manual AppTopBar + AppSidebar + FormBuilder workspace" in guidance_check.detail
        assert "ControlWorkspaceView + defineControlModel" in guidance_check.detail
        assert "mint docs frontend choose" in guidance_check.fix_hint
        assert "mint docs frontend consolidate" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_mobile_sidebar_shell_gets_responsive_layout_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualMobileSidebar.vue").write_text("""\
<script setup lang="ts">
import { ref } from 'vue'
import { AppSidebar, AppTopBar } from '@morscherlab/mint-sdk'

const sidebarOpen = ref(false)
const panels = {}
</script>

<template>
  <AppTopBar title="Analysis" />
  <button aria-label="Toggle sidebar" :aria-expanded="sidebarOpen">
    Toggle sidebar
  </button>
  <div v-if="sidebarOpen" class="sidebar-backdrop">Sidebar backdrop</div>
  <AppSidebar :panels="panels" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualMobileSidebar.vue" in guidance_check.detail
        assert "manual mobile sidebar behavior" in guidance_check.detail
        assert "AppLayout responsiveSidebar with AppSidebar variant=\"analysis\"" in guidance_check.detail
        assert "analysis sidebars" in guidance_check.fix_hint
        assert "AppLayout responsiveSidebar" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_responsive_sidebar_layout_gets_plugin_workspace_shell_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ResponsiveSidebar.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppSidebar, AppTopBar } from '@morscherlab/mint-sdk'

const panels = {}
</script>

<template>
  <AppLayout responsive-sidebar>
    <template #topbar>
      <AppTopBar title="Analysis" />
    </template>
    <template #sidebar>
      <AppSidebar :panels="panels" />
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ResponsiveSidebar.vue" in guidance_check.detail
        assert "manual AppLayout + AppTopBar + AppSidebar shell" in guidance_check.detail
        assert "PluginWorkspaceView" in guidance_check.detail
        assert "PluginWorkspaceView" in guidance_check.fix_hint

    def test_plugin_workspace_view_skips_manual_shell_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "PluginWorkspaceShell.vue").write_text("""\
<script setup lang="ts">
import { PluginWorkspaceView } from '@morscherlab/mint-sdk'

const panels = {}
</script>

<template>
  <PluginWorkspaceView title="Analysis" :panels="panels" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_route_owned_sidebar_shell_gets_app_sidebar_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "RouteOwnedSidebar.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppTopBar } from '@morscherlab/mint-sdk'
</script>

<template>
  <AppLayout>
    <template #topbar>
      <AppTopBar title="Sequence" />
    </template>
    <template #sidebar>
      <div class="h-full flex flex-col">
        <div id="seqgen-sidebar" class="flex-1 overflow-y-auto" />
        <div class="pinned-actions">Generate</div>
      </div>
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "RouteOwnedSidebar.vue" in guidance_check.detail
        assert "manual route-owned sidebar shell" in guidance_check.detail
        assert "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty with footer slot" in guidance_check.detail
        assert "PluginWorkspaceView sidebarContentId/showSidebarWhenEmpty" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_app_sidebar_content_target_skips_route_owned_shell_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "RouteOwnedAppSidebar.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppSidebar, AppTopBar } from '@morscherlab/mint-sdk'
</script>

<template>
  <AppLayout>
    <template #topbar>
      <AppTopBar title="Sequence" />
    </template>
    <template #sidebar>
      <AppSidebar
        variant="analysis"
        content-id="seqgen-sidebar"
        show-when-empty
      />
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_verbose_analysis_sidebar_chrome_gets_variant_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "VerboseAnalysisSidebar.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppSidebar } from '@morscherlab/mint-sdk'

const panels = {}
</script>

<template>
  <AppLayout>
    <template #sidebar>
      <AppSidebar
        title="Peak Picking"
        subtitle="Current experiment"
        :panels="panels"
        active-view="analysis"
        :floating="false"
        width="20rem"
        collapsible
      />
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "VerboseAnalysisSidebar.vue" in guidance_check.detail
        assert "verbose AppSidebar analysis chrome" in guidance_check.detail
        assert 'AppSidebar variant="analysis"' in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_analysis_sidebar_variant_skips_chrome_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "AnalysisSidebarVariant.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppSidebar } from '@morscherlab/mint-sdk'

const panels = {}
</script>

<template>
  <AppLayout>
    <template #sidebar>
      <AppSidebar
        variant="analysis"
        title="Peak Picking"
        subtitle="Current experiment"
        :panels="panels"
        active-view="analysis"
      />
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_layout_form_page_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualFormPage.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppTopBar, FormBuilder } from '@morscherlab/mint-sdk'

const schema = []
</script>

<template>
  <AppLayout>
    <template #topbar>
      <AppTopBar title="Analysis" />
    </template>

    <FormBuilder :schema="schema" />
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualFormPage.vue" in guidance_check.detail
        assert "manual AppLayout + AppTopBar + FormBuilder page" in guidance_check.detail
        assert "ControlWorkspaceView + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_layout_sidebar_form_page_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualSidebarPage.vue").write_text("""\
<script setup lang="ts">
import { AppLayout, AppSidebar, FormBuilder } from '@morscherlab/mint-sdk'

const panels = []
const schema = []
</script>

<template>
  <AppLayout>
    <template #sidebar>
      <AppSidebar :panels="panels" />
    </template>

    <FormBuilder :schema="schema" />
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualSidebarPage.vue" in guidance_check.detail
        assert "manual AppLayout + AppSidebar + FormBuilder page" in guidance_check.detail
        assert "ControlWorkspaceView + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_aside_mobile_sidebar_gets_responsive_layout_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualAsideSidebar.vue").write_text("""\
<script setup lang="ts">
import { ref } from 'vue'
import { AppTopBar } from '@morscherlab/mint-sdk'

const sidebarOpen = ref(true)
</script>

<template>
  <AppTopBar title="Analysis" />

  <button
    aria-label="Toggle sidebar"
    :aria-expanded="sidebarOpen"
    @click="sidebarOpen = !sidebarOpen"
  >
    Toggle
  </button>

  <!-- Sidebar backdrop for mobile -->
  <div v-if="sidebarOpen" class="lg:hidden fixed inset-0 bg-black/50" @click="sidebarOpen = false" />

  <aside class="w-80 flex-shrink-0 flex flex-col panel">
    <h2>Peak Picking</h2>
  </aside>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualAsideSidebar.vue" in guidance_check.detail
        assert "manual mobile sidebar behavior" in guidance_check.detail
        assert "AppLayout responsiveSidebar with AppSidebar variant=\"analysis\"" in guidance_check.detail
        assert "analysis sidebars" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_responsive_app_layout_with_sidebar_open_model_gets_plugin_workspace_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ResponsiveAnalysisSidebar.vue").write_text("""\
<script setup lang="ts">
import { ref } from 'vue'
import { AppLayout, AppSidebar, AppTopBar } from '@morscherlab/mint-sdk'

const sidebarOpen = ref(false)
const panels = []
</script>

<template>
  <AppLayout responsive-sidebar v-model:sidebarOpen="sidebarOpen">
    <template #topbar>
      <AppTopBar title="Analysis" />
    </template>

    <template #sidebar>
      <AppSidebar
        title="Peak Picking"
        subtitle="exp159"
        :panels="panels"
        active-view="analysis"
        collapsible
      />
    </template>
  </AppLayout>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ResponsiveAnalysisSidebar.vue" in guidance_check.detail
        assert "manual AppLayout + AppTopBar + AppSidebar shell" in guidance_check.detail
        assert "PluginWorkspaceView" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_dose_design_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualDoseDesign.vue").write_text("""\
<script setup lang="ts">
import { DoseCalculator, WellPlate } from '@morscherlab/mint-sdk'

const wells = {}
const selectedWells = []
</script>

<template>
  <WellPlate :wells="wells" />
  <DoseCalculator :target-wells="selectedWells" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualDoseDesign.vue" in guidance_check.detail
        assert "manual WellPlate + DoseCalculator dose design" in guidance_check.detail
        assert "DoseDesignWorkspaceView or BioTemplatePresetWorkspaceView" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_hand_wired_dose_design_workspace_gets_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "HandWiredDoseWorkspace.vue").write_text("""\
<script setup lang="ts">
import {
  ControlWorkspaceView,
  DoseCalculator,
  WellPlate,
  defineDoseDesignControlModel,
} from '@morscherlab/mint-sdk'

const values = {}
const workspaceModel = defineDoseDesignControlModel({ selectedWells: ['A1'] })
</script>

<template>
  <ControlWorkspaceView v-model="values" :model="workspaceModel">
    <template #default="{ componentPropsById }">
      <WellPlate v-bind="componentPropsById.plate" />
      <DoseCalculator v-bind="componentPropsById.dose" />
    </template>
  </ControlWorkspaceView>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "HandWiredDoseWorkspace.vue" in guidance_check.detail
        assert "hand-wired ControlWorkspaceView dose-design slots" in guidance_check.detail
        assert "DoseDesignWorkspaceView for standard WellPlate + DoseCalculator pages" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_dose_design_workspace_view_skips_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "DoseWorkspace.vue").write_text("""\
<script setup lang="ts">
import { DoseDesignWorkspaceView } from '@morscherlab/mint-sdk'

const values = {}
</script>

<template>
  <DoseDesignWorkspaceView v-model="values" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_manual_plate_map_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualPlateMap.vue").write_text("""\
<script setup lang="ts">
import { PlateMapEditor, SampleLegend, WellPlate } from '@morscherlab/mint-sdk'

const samples = []
const wells = {}
</script>

<template>
  <PlateMapEditor :samples="samples" />
  <WellPlate :wells="wells" />
  <SampleLegend :samples="samples" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualPlateMap.vue" in guidance_check.detail
        assert "manual PlateMapEditor + WellPlate + SampleLegend plate map" in guidance_check.detail
        assert "BioTemplatePresetWorkspaceView or useBioTemplatePresetWorkspace" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_bio_template_plate_map_skips_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "TemplatePlateMap.vue").write_text("""\
<script setup lang="ts">
import { BioTemplatePresetWorkspaceView, PlateMapEditor, SampleLegend, WellPlate } from '@morscherlab/mint-sdk'

const values = {}
</script>

<template>
  <BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen" />
  <PlateMapEditor :samples="[]" />
  <WellPlate :wells="{}" />
  <SampleLegend :samples="[]" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_bio_template_pack_bindings_skip_dose_design_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "TemplatePackBindings.vue").write_text("""\
<script setup lang="ts">
import {
  AppSidebar,
  AppTopBar,
  BioTemplateRenderer,
  DoseCalculator,
  WellPlate,
  useBioTemplatePackWorkspace,
} from '@morscherlab/mint-sdk'

const { bindings } = useBioTemplatePackWorkspace('cell-culture-screen')
</script>

<template>
  <AppTopBar v-bind="bindings.topBar.value" title="Cell Culture" />
  <AppSidebar v-bind="bindings.sidebar" />
  <BioTemplateRenderer v-bind="bindings.renderer" />
  <WellPlate v-bind="bindings.componentBindingsById['plate-map:WellPlate'].props" />
  <DoseCalculator v-bind="bindings.componentBindingsById['dose-response:DoseCalculator'].props" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_manual_sample_sheet_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualSampleSheet.vue").write_text("""\
<script setup lang="ts">
import { DataFrame, GroupAssigner, SampleSelector } from '@morscherlab/mint-sdk'

const rows = []
const columns = []
const samples = []
</script>

<template>
  <DataFrame :data="rows" :columns="columns" />
  <SampleSelector :samples="samples" />
  <GroupAssigner :samples="samples" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualSampleSheet.vue" in guidance_check.detail
        assert "manual DataFrame + SampleSelector + GroupAssigner sample sheet" in guidance_check.detail
        assert "BioTemplateExperimentWorkspaceView or useBioTemplateWorkspace" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_lcms_workspace_gets_targeted_metabolomics_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualLcmsWorkspace.vue").write_text("""\
<script setup lang="ts">
import { DataFrame, ExperimentTimeline, ScheduleCalendar } from '@morscherlab/mint-sdk'

const rows = []
const columns = []
const steps = []
const events = []
</script>

<template>
  <ScheduleCalendar :events="events" />
  <ExperimentTimeline :steps="steps" />
  <DataFrame :data="rows" :columns="columns" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualLcmsWorkspace.vue" in guidance_check.detail
        assert "manual LC-MS/metabolomics acquisition workspace" in guidance_check.detail
        assert 'BioTemplatePresetWorkspaceView preset="targeted-metabolomics"' in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_sequence_progress_gets_sdk_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        component_dir = tmp_path / "frontend" / "src" / "components"
        component_dir.mkdir(parents=True)
        (component_dir / "ManualSequenceProgress.vue").write_text("""\
<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{ progress: {
  current_sample: number
  total_samples: number
  elapsed_seconds: number
  estimated_remaining_seconds?: number | null
  avg_sample_seconds?: number | null
} }>()

const percent = computed(() => Math.round((props.progress.current_sample / props.progress.total_samples) * 100))
const remainingLabel = computed(() => props.progress.estimated_remaining_seconds
  ? `${props.progress.estimated_remaining_seconds}s left`
  : null)
</script>

<template>
  <div class="seq-progress">
    <span>{{ progress.current_sample }} / {{ progress.total_samples }}</span>
    <span>{{ percent }}%</span>
    <span v-if="remainingLabel">ETA {{ remainingLabel }}</span>
  </div>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualSequenceProgress.vue" in guidance_check.detail
        assert "manual instrument sequence progress" in guidance_check.detail
        assert "SequenceProgressBar + shared SequenceProgress helpers" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_form_fields_get_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualForm.vue").write_text("""\
<script setup lang="ts">
import { BaseInput, BaseSelect, FormField } from '@morscherlab/mint-sdk'

const methodOptions = ['linear', 'logistic']
</script>

<template>
  <FormField label="Threshold">
    <BaseInput type="number" />
  </FormField>
  <FormField label="Method">
    <BaseSelect :options="methodOptions" />
  </FormField>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualForm.vue" in guidance_check.detail
        assert "manual FormField + base input form" in guidance_check.detail
        assert "FormBuilder + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_single_form_primitive_gets_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualNumericForm.vue").write_text("""\
<script setup lang="ts">
import { DatePicker, FormField, NumberInput } from '@morscherlab/mint-sdk'
</script>

<template>
  <FormField label="Threshold">
    <NumberInput />
  </FormField>
  <FormField label="Start date">
    <DatePicker />
  </FormField>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualNumericForm.vue" in guidance_check.detail
        assert "manual FormField + base input form" in guidance_check.detail
        assert "FormBuilder + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_settings_modal_fields_get_nonblocking_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualSettings.vue").write_text("""\
<script setup lang="ts">
import { BaseInput, BaseSelect, FormField, SettingsModal } from '@morscherlab/mint-sdk'

const methodOptions = ['linear', 'logistic']
</script>

<template>
  <SettingsModal v-model="open" :tabs="['Analysis']">
    <template #tab-Analysis>
      <FormField label="Threshold">
        <BaseInput type="number" />
      </FormField>
      <FormField label="Method">
        <BaseSelect :options="methodOptions" />
      </FormField>
    </template>
  </SettingsModal>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualSettings.vue" in guidance_check.detail
        assert "manual SettingsModal tabs with base form fields" in guidance_check.detail
        assert "SettingsModal :model + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_settings_permission_checks_get_access_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualSettingsPermissions.vue").write_text("""\
<script setup lang="ts">
import { computed } from 'vue'
import { SettingsModal } from '@morscherlab/mint-sdk'

const user = { role_obj: { slug: 'admin' } }
const isAdmin = computed(() => user.role_obj.slug === 'admin')
</script>

<template>
  <SettingsModal v-model="open" :tabs="isAdmin ? ['General', 'Admin'] : ['General']">
    <template #tab-Admin>
      <div v-if="isAdmin">API keys</div>
    </template>
  </SettingsModal>
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualSettingsPermissions.vue" in guidance_check.detail
        assert "manual settings permission checks" in guidance_check.detail
        assert "SettingsModal access metadata or settings_model json_schema_extra" in guidance_check.detail
        assert "component-local role checks" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_settings_access_metadata_skips_permission_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "SettingsAccessMetadata.vue").write_text("""\
<script setup lang="ts">
import { SettingsModal, defineControlModel } from '@morscherlab/mint-sdk'

const settingsModel = defineControlModel({
  controls: {
    apiKey: {
      label: 'API key',
      type: 'text',
      visibleFor: 'admin',
    },
  },
})
</script>

<template>
  <SettingsModal v-model="open" :model="settingsModel" user-type="admin" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_canonical_workspace_entrypoint_skips_component_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "CanonicalWorkspace.vue").write_text("""\
<script setup lang="ts">
import { ControlWorkspaceView, defineControlModel } from '@morscherlab/mint-sdk'

const workspaceModel = defineControlModel({ controls: {} })
</script>

<template>
  <ControlWorkspaceView :model="workspaceModel" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_control_workspace_bindings_skip_manual_workspace_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "WorkspaceBindings.vue").write_text("""\
<script setup lang="ts">
import {
  AppSidebar,
  AppTopBar,
  FormBuilder,
  defineControlModel,
  useControlWorkspace,
} from '@morscherlab/mint-sdk'

const workspaceModel = defineControlModel({ controls: { threshold: 0.05 } })
const workspace = useControlWorkspace(workspaceModel)
const { form, sidebar, topBar } = workspace.bindings
</script>

<template>
  <AppTopBar v-bind="topBar" title="Analysis" />
  <AppSidebar v-bind="sidebar" />
  <FormBuilder v-bind="form" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_manual_split_control_workspace_gets_nonblocking_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "SplitWorkspace.vue").write_text("""\
<script setup lang="ts">
import { ControlWorkspaceView, defineControlModel, useControlWorkspace } from '@morscherlab/mint-sdk'

const workspaceModel = defineControlModel({ controls: { threshold: 0.05 } })
const workspace = useControlWorkspace(workspaceModel.controls, workspaceModel.controlOptions)
</script>

<template>
  <ControlWorkspaceView :workspace="workspace" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "SplitWorkspace.vue" in guidance_check.detail
        assert "manual useControlWorkspace split model binding" in guidance_check.detail
        assert "ControlWorkspaceView :model + defineControlModel" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_manual_topbar_page_selector_gets_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualPageSwitch.vue").write_text("""\
<script setup lang="ts">
import { AppTopBar } from '@morscherlab/mint-sdk'

const pages = [
  { id: 'dashboard', label: 'Dashboard', to: '/', icon: 'M3 13h8' },
  { id: 'analysis', label: 'Analysis', to: '/analysis', icon: 'M4 19h16' },
]
</script>

<template>
  <AppTopBar :page-selector="pages" current-page-selector-id="dashboard" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualPageSwitch.vue" in guidance_check.detail
        assert "manual AppTopBar page selector" in guidance_check.detail
        assert (
            "pluginPageSelectorItems or getPluginPageSelectorItems(contract) "
            "from PluginMetadata.nav_items"
        ) in guidance_check.detail
        assert "PluginMetadata.nav_items" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_generated_topbar_page_selector_skips_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "GeneratedPageSwitch.vue").write_text("""\
<script setup lang="ts">
import { AppTopBar } from '@morscherlab/mint-sdk'
import { pluginPageSelectorItems } from '../generated/mint-plugin'

const pageSelector = pluginPageSelectorItems
</script>

<template>
  <AppTopBar :page-selector="pageSelector" current-page-selector-id="dashboard" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_manual_topbar_subnav_components_get_consolidation_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualTopbarSubnav.vue").write_text("""\
<script setup lang="ts">
import { AppPageSelector, AppPillNav, AppTopBar } from '@morscherlab/mint-sdk'

const pages = [
  { id: 'dashboard', label: 'Dashboard', to: '/' },
  { id: 'analysis', label: 'Analysis', to: '/analysis' },
]
const modes = [
  { id: 'summary', label: 'Summary' },
  { id: 'raw', label: 'Raw' },
]
</script>

<template>
  <AppTopBar title="Analysis" />
  <AppPageSelector :pages="pages" current-page-id="dashboard" />
  <AppPillNav :items="modes" current-id="summary" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualTopbarSubnav.vue" in guidance_check.detail
        assert "standalone retired AppPageSelector page switcher next to AppTopBar" in guidance_check.detail
        assert "AppTopBar pageSelector + pluginPageSelectorItems" in guidance_check.detail
        assert "standalone retired AppPillNav mode switcher next to AppTopBar" in guidance_check.detail
        assert "AppTopBar pillNav / current-pill-id props" in guidance_check.detail
        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppPageSelector component -> AppTopBar" in api_check.detail
        assert "AppPillNav component -> AppTopBar" in api_check.detail

    def test_manual_experiment_shell_gets_app_experiment_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualExperimentShell.vue").write_text("""\
<script setup lang="ts">
import { ref } from 'vue'
import { ExperimentPopover, ExperimentSelectorModal } from '@morscherlab/mint-sdk'

const selectorOpen = ref(false)
</script>

<template>
  <ExperimentPopover @select="selectorOpen = true" />
  <ExperimentSelectorModal :open="selectorOpen" @close="selectorOpen = false" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "ManualExperimentShell.vue" in guidance_check.detail
        assert "manual ExperimentPopover + ExperimentSelectorModal state wiring" in guidance_check.detail
        assert (
            "PluginWorkspaceView experiment-shell or useAppExperiment for AppTopBar experiment shell wiring"
            in guidance_check.detail
        )
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_use_app_experiment_skips_experiment_shell_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "AppExperimentShell.vue").write_text("""\
<script setup lang="ts">
import {
  ExperimentPopover,
  ExperimentSelectorModal,
  useAppExperiment,
} from '@morscherlab/mint-sdk'

const appExperiment = useAppExperiment()
</script>

<template>
  <ExperimentPopover v-bind="appExperiment.popover.value" />
  <ExperimentSelectorModal v-bind="appExperiment.selectorModal.value" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_plugin_nav_items_page_selector_mapping_gets_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "MappedPluginNavItems.vue").write_text("""\
<script setup lang="ts">
import { AppTopBar } from '@morscherlab/mint-sdk'
import { pluginNavItems } from '../generated/mint-plugin'

const pageSelector = pluginNavItems.map(page => ({
  id: page.id,
  label: page.label,
  to: page.path,
  icon: page.icon,
}))
</script>

<template>
  <AppTopBar :page-selector="pageSelector" current-page-selector-id="dashboard" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "MappedPluginNavItems.vue" in guidance_check.detail
        assert "manual AppTopBar page selector" in guidance_check.detail
        assert (
            "pluginPageSelectorItems or getPluginPageSelectorItems(contract) "
            "from PluginMetadata.nav_items"
        ) in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_plugin_workspace_experiment_shell_skips_manual_experiment_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "WorkspaceExperimentShell.vue").write_text("""\
<script setup lang="ts">
import {
  ExperimentPopover,
  ExperimentSelectorModal,
  PluginWorkspaceView,
} from '@morscherlab/mint-sdk'
</script>

<template>
  <PluginWorkspaceView experiment-shell />
  <ExperimentPopover />
  <ExperimentSelectorModal />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert "manual ExperimentPopover + ExperimentSelectorModal state wiring" not in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_plugin_workspace_use_app_experiment_gets_shell_prop_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "WorkspaceManualExperiment.vue").write_text("""\
<script setup lang="ts">
import { PluginWorkspaceView, useAppExperiment } from '@morscherlab/mint-sdk'

const appExperiment = useAppExperiment()
</script>

<template>
  <PluginWorkspaceView title="Analysis" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert "WorkspaceManualExperiment.vue" in guidance_check.detail
        assert "manual useAppExperiment with PluginWorkspaceView" in guidance_check.detail
        assert "PluginWorkspaceView experimentShell" in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_plugin_workspace_experiment_shell_skips_use_app_experiment_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "WorkspaceExperimentShellWithComposable.vue").write_text("""\
<script setup lang="ts">
import { PluginWorkspaceView, useAppExperiment } from '@morscherlab/mint-sdk'

const appExperiment = useAppExperiment()
</script>

<template>
  <PluginWorkspaceView title="Analysis" experiment-shell />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert "manual useAppExperiment with PluginWorkspaceView" not in guidance_check.detail
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_plugin_page_selector_helper_skips_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "HelperPageSelector.vue").write_text("""\
<script setup lang="ts">
import { AppTopBar, getPluginPageSelectorItems } from '@morscherlab/mint-sdk'
import { pluginContract } from '../generated/mint-plugin'

const pageSelector = getPluginPageSelectorItems(pluginContract)
</script>

<template>
  <AppTopBar :page-selector="pageSelector" current-page-selector-id="dashboard" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_contract_page_selector_items_skip_metadata_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ContractPageSelectorItems.vue").write_text("""\
<script setup lang="ts">
import { AppTopBar } from '@morscherlab/mint-sdk'
import { useGeneratedPluginContract } from '../generated/mint-plugin'

const pluginContract = useGeneratedPluginContract()
const pageSelector = pluginContract.pageSelectorItems
</script>

<template>
  <AppTopBar :page-selector="pageSelector" current-page-selector-id="dashboard" />
</template>
""")

        results = run_checks(tmp_path)

        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert guidance_check.ok
        assert guidance_check.detail == "canonical component entrypoints"

    def test_public_component_subpaths_get_nonblocking_root_import_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ComponentSubpath.vue").write_text("""\
<script setup lang="ts">
import { AppSidebar } from '@morscherlab/mint-sdk/components'
import WellPlate from '@morscherlab/mint-sdk/components/WellPlate.vue'
import '@morscherlab/mint-sdk/components'

const asyncComponents = () => import('@morscherlab/mint-sdk/components')
const asyncWellPlate = () => import('@morscherlab/mint-sdk/components/WellPlate.vue')
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert catalog_check.ok
        assert guidance_check.ok
        assert "ComponentSubpath.vue" in guidance_check.detail
        assert "component subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "WellPlate component file import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "side-effect component subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "dynamic component subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "WellPlate dynamic component file import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "Import public components and composables from `@morscherlab/mint-sdk`" in guidance_check.fix_hint
        assert "mint docs frontend consolidate" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_public_composable_subpath_gets_nonblocking_root_import_guidance(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ComposableSubpath.vue").write_text("""\
<script setup lang="ts">
import { useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk/composables'
import '@morscherlab/mint-sdk/composables'

const workspace = useBioTemplatePresetWorkspace('wellplate-screen')
const asyncComposables = () => import('@morscherlab/mint-sdk/composables')
</script>
""")
        (tmp_path / "frontend" / "src" / "sdk-wrapper.ts").write_text("""\
export { useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk/composables'
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        guidance_check = [r for r in results if r.label == "Frontend component guidance"][0]
        assert catalog_check.ok
        assert guidance_check.ok
        assert "ComposableSubpath.vue" in guidance_check.detail
        assert "sdk-wrapper.ts" in guidance_check.detail
        assert "composable subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "side-effect composable subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "dynamic composable subpath import -> root @morscherlab/mint-sdk import" in guidance_check.detail
        assert "`@morscherlab/mint-sdk/templates` for template helpers" in guidance_check.fix_hint
        assert all(r.ok for r in results), [r for r in results if not r.ok]

    def test_unknown_frontend_sdk_imports_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "AbandonedSdkApi.vue").write_text("""\
<script setup lang="ts">
import { RetiredPlate } from '@morscherlab/mint-sdk'
import { createOldTemplateThing } from '@morscherlab/mint-sdk'
import { useLegacyExperiment } from '@morscherlab/mint-sdk/composables'
import { createMissingTemplateCollection } from '@morscherlab/mint-sdk/templates'
import LegacyPlate from '@morscherlab/mint-sdk/components/LegacyPlate.vue'
import type { MissingTypeWidget, PluginContract } from '@morscherlab/mint-sdk'
import * as MintSdk from '@morscherlab/mint-sdk'

const oldWizard = MintSdk.OldWizard
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "AbandonedSdkApi.vue" in catalog_check.detail
        assert "RetiredPlate" in catalog_check.detail
        assert "createOldTemplateThing" in catalog_check.detail
        assert "useLegacyExperiment" in catalog_check.detail
        assert "createMissingTemplateCollection" in catalog_check.detail
        assert "LegacyPlate" in catalog_check.detail
        assert "MissingTypeWidget" in catalog_check.detail
        assert "OldWizard" in catalog_check.detail
        assert "PluginContract" not in catalog_check.detail
        assert "not present in the bundled frontend SDK catalog" in catalog_check.explanation
        assert "mint docs frontend choose" in catalog_check.fix_hint
        assert "mint docs frontend <name>" in catalog_check.fix_hint
        assert "mint docs search" in catalog_check.fix_hint

    def test_unknown_frontend_sdk_namespace_destructure_fails_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "UnknownNamespaceDestructure.vue").write_text("""\
<script setup lang="ts">
import * as MintSdk from '@morscherlab/mint-sdk'
import * as Components from '@morscherlab/mint-sdk/components'
import * as Composables from '@morscherlab/mint-sdk/composables'

const { MissingWidget: LegacyWidget, MissingPanel } = MintSdk
const { InternalPanel } = Components
const { useMissingThing: useLegacyThing } = Composables
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "MissingWidget from @morscherlab/mint-sdk" in catalog_check.detail
        assert "MissingPanel from @morscherlab/mint-sdk" in catalog_check.detail
        assert "InternalPanel from @morscherlab/mint-sdk/components" in catalog_check.detail
        assert "useMissingThing from @morscherlab/mint-sdk/composables" in catalog_check.detail
        assert "unsupported or unknown frontend SDK APIs" in catalog_check.detail

    def test_unknown_frontend_sdk_dynamic_imports_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "UnknownDynamicImport.vue").write_text("""\
<script setup lang="ts">
const MintSdk = await import('@morscherlab/mint-sdk')
const Components = await import('@morscherlab/mint-sdk/components')
const Templates = await import('@morscherlab/mint-sdk/templates')
const oldWizard = MintSdk.OldWizard
const internalPanel = Components.InternalPanel
const missingTemplate = Templates.createMissingTemplateCollection
const directOldWizard = (await import('@morscherlab/mint-sdk')).OldWizard
const directInternalPanel = (await import('@morscherlab/mint-sdk/components')).InternalPanel
const directMissingTemplate = (await import('@morscherlab/mint-sdk/templates')).createMissingTemplateCollection
const directRetiredDynamic = (await import('@morscherlab/mint-sdk')).RetiredDynamic
const directInternalWidget = (await import('@morscherlab/mint-sdk/components')).DirectInternalWidget
const directMissingPreset = (await import('@morscherlab/mint-sdk/templates')).createDirectMissingTemplate
const { MissingWidget: LegacyWidget } = await import('@morscherlab/mint-sdk')
const { useMissingThing } = await import('@morscherlab/mint-sdk/composables')
const thenOldWizard = import('@morscherlab/mint-sdk').then(sdk => sdk.ThenOldWizard)
const thenInternalPanel = import('@morscherlab/mint-sdk/components').then(({ ThenInternalPanel }) => ThenInternalPanel)
const thenMissingTemplate = import('@morscherlab/mint-sdk/templates').then(sdk => sdk.createThenMissingTemplate())
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "OldWizard from @morscherlab/mint-sdk" in catalog_check.detail
        assert "InternalPanel from @morscherlab/mint-sdk/components" in catalog_check.detail
        assert "createMissingTemplateCollection from @morscherlab/mint-sdk/templates" in catalog_check.detail
        assert "RetiredDynamic from @morscherlab/mint-sdk" in catalog_check.detail
        assert "DirectInternalWidget from @morscherlab/mint-sdk/components" in catalog_check.detail
        assert "createDirectMissingTemplate from @morscherlab/mint-sdk/templates" in catalog_check.detail
        assert "MissingWidget from @morscherlab/mint-sdk" in catalog_check.detail
        assert "useMissingThing from @morscherlab/mint-sdk/composables" in catalog_check.detail
        assert "ThenOldWizard from @morscherlab/mint-sdk" in catalog_check.detail
        assert "ThenInternalPanel from @morscherlab/mint-sdk/components" in catalog_check.detail
        assert "createThenMissingTemplate from @morscherlab/mint-sdk/templates" in catalog_check.detail

    def test_private_frontend_sdk_component_subpaths_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "PrivateSdkApi.vue").write_text("""\
<script setup lang="ts">
import ActionItem from '@morscherlab/mint-sdk/components/ActionItem.vue'
import CalendarGridPanel from '@morscherlab/mint-sdk/components/CalendarGridPanel.vue'
import InternalPageSelector from '@morscherlab/mint-sdk/components/internal/AppTopBarPageSelectorInternal.vue'

const internalPillNav = () => import('@morscherlab/mint-sdk/components/internal/AppTopBarPillNavInternal.vue')
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "ActionItem" in catalog_check.detail
        assert "CalendarGridPanel" in catalog_check.detail
        assert "AppTopBarPageSelectorInternal" in catalog_check.detail
        assert "AppTopBarPillNavInternal" in catalog_check.detail
        assert "private APIs" in catalog_check.explanation

    def test_frontend_sdk_composable_subpaths_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "PrivateComposableSubpath.vue").write_text("""\
<script setup lang="ts">
import { useDropdownState } from '@morscherlab/mint-sdk/composables/useDropdownState'
import { useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk/composables/useBioTemplatePresetWorkspace'

const lazyTextSearch = () => import('@morscherlab/mint-sdk/composables/useTextSearch')
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "useDropdownState" in catalog_check.detail
        assert "useBioTemplatePresetWorkspace" in catalog_check.detail
        assert "useTextSearch" in catalog_check.detail
        assert "package subpaths" in catalog_check.explanation
        assert "mint docs frontend choose" in catalog_check.fix_hint
        assert "mint docs frontend <name>" in catalog_check.fix_hint

    def test_private_frontend_sdk_deep_subpaths_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "PrivateDeepSubpath.vue").write_text("""\
<script setup lang="ts">
import ActionItem from '@morscherlab/mint-sdk/src/components/ActionItem.vue'
import { createTemplateEnvelope } from '@morscherlab/mint-sdk/templates/builders'
import '@morscherlab/mint-sdk/styles/variables.css'

const ActionItemAsync = () => import('@morscherlab/mint-sdk/src/components/ActionItem.vue')
const builders = () => import('@morscherlab/mint-sdk/templates/builders')
</script>
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "ActionItem" in catalog_check.detail
        assert "builders" in catalog_check.detail
        assert "variables" in catalog_check.detail
        assert "package subpaths" in catalog_check.explanation

    def test_unknown_frontend_sdk_re_exports_fail_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        src_dir = tmp_path / "frontend" / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        (src_dir / "sdk-wrapper.ts").write_text("""\
export { MissingWidget, type PluginContract } from '@morscherlab/mint-sdk'
export { InternalPanel } from '@morscherlab/mint-sdk/components'
export { useMissingThing } from '@morscherlab/mint-sdk/composables'
export { createMissingTemplateCollection } from '@morscherlab/mint-sdk/templates'
export { default as ActionItem } from '@morscherlab/mint-sdk/components/ActionItem.vue'
export { default as useDropdownState } from '@morscherlab/mint-sdk/composables/useDropdownState'
export * from '@morscherlab/mint-sdk/templates/builders'
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert not catalog_check.ok
        assert "MissingWidget from @morscherlab/mint-sdk" in catalog_check.detail
        assert "InternalPanel from @morscherlab/mint-sdk/components" in catalog_check.detail
        assert "useMissingThing from @morscherlab/mint-sdk/composables" in catalog_check.detail
        assert "createMissingTemplateCollection from @morscherlab/mint-sdk/templates" in catalog_check.detail
        assert "ActionItem from @morscherlab/mint-sdk/components/ActionItem.vue" in catalog_check.detail
        assert "useDropdownState from @morscherlab/mint-sdk/composables/useDropdownState" in catalog_check.detail
        assert "builders from @morscherlab/mint-sdk/templates/builders" in catalog_check.detail
        assert "imported or re-exported names" in catalog_check.explanation

    def test_current_frontend_sdk_imports_pass_catalog_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "CurrentSdkApi.vue").write_text("""\
<script setup lang="ts">
import {
  BaseButton,
  formatTime,
  getBioTemplateComponentProps,
  useTemplateCollection,
  type PluginContract,
} from '@morscherlab/mint-sdk'
import { AppSidebar } from '@morscherlab/mint-sdk/components'
import { useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk/composables'
import {
  createFlowCytometryAssayCollection,
  createWellPlateScreenCollection,
  toTemplateDataFrame,
  type TemplatePresetId,
} from '@morscherlab/mint-sdk/templates'
import WellPlate from '@morscherlab/mint-sdk/components/WellPlate.vue'
import '@morscherlab/mint-sdk/styles'
import * as MintSdk from '@morscherlab/mint-sdk'

const button = MintSdk.BaseButton
const { BaseButton: ButtonFromNamespace } = MintSdk
const contract = null as PluginContract | MintSdk.PluginContract
const presetId = 'wellplate-screen' satisfies TemplatePresetId
const WellPlateAsync = () => import('@morscherlab/mint-sdk/components/WellPlate.vue')
const sdkPromiseButton = import('@morscherlab/mint-sdk').then(sdk => sdk.BaseButton)
const sdkPromiseButtonDestructure = import('@morscherlab/mint-sdk').then(({ BaseButton }) => BaseButton)
const dynamicDefault = (await import('@morscherlab/mint-sdk')).default
const clock = formatTime('09:30')
const workspace = useBioTemplatePresetWorkspace('wellplate-screen')
const collection = createWellPlateScreenCollection()
const flowCollection = createFlowCytometryAssayCollection()
const flowRows = toTemplateDataFrame(flowCollection.templates['assay-matrix'])
const doseProps = getBioTemplateComponentProps(collection, 'DoseCalculator')
</script>
""")
        (tmp_path / "frontend" / "src" / "sdk-wrapper.ts").write_text("""\
export { BaseButton, useTemplateCollection, type PluginContract } from '@morscherlab/mint-sdk'
export { AppSidebar } from '@morscherlab/mint-sdk/components'
export { useBioTemplatePresetWorkspace } from '@morscherlab/mint-sdk/composables'
export {
  createFlowCytometryAssayCollection,
  createWellPlateScreenCollection,
  type TemplatePresetId,
} from '@morscherlab/mint-sdk/templates'
export { default as WellPlate } from '@morscherlab/mint-sdk/components/WellPlate.vue'
""")

        results = run_checks(tmp_path)

        catalog_check = [r for r in results if r.label == "Frontend SDK API catalog"][0]
        assert catalog_check.ok
        assert catalog_check.detail == "imports/re-exports match catalog"

    def test_deprecated_frontend_sdk_api_usage_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyComponents.vue").write_text("""\
<script setup lang="ts">
import { GroupingModal } from '@morscherlab/mint-sdk'
import { ToastNotification } from '@morscherlab/mint-sdk'
import type { FormSection } from '@morscherlab/mint-sdk'
import { type FormFieldRenderer } from '@morscherlab/mint-sdk'
</script>

<template>
  <GroupingModal :open="true" :samples="[]" />
  <ToastNotification />
  <BaseTabs model-value="overview" :tabs="[]" variant="bordered" />
  <AppSidebar
    :items="legacyItems"
    active-id="overview"
    collapsed
    collapsed-width="64px"
  />
  <AppTopBar
    title="Legacy"
    plugin-name="Legacy Plugin"
    floating
    sticky
    :pages="pages"
    current-page-id="overview"
    :tabs="tabs"
    current-tab-id="run"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component -> AutoGroupModal" in api_check.detail
        assert "ToastNotification component -> AppToastContainer" in api_check.detail
        assert "FormSection component -> FormBuilder" in api_check.detail
        assert "FormFieldRenderer component -> FormBuilder" in api_check.detail
        assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in api_check.detail
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pluginName prop -> AppTopBar title/subtitle or pageSelector prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert "AppTopBar current-page-id prop -> AppTopBar current-page-selector-id prop" in api_check.detail
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert "AppTopBar current-tab-id prop -> AppTopBar current-pill-id prop" in api_check.detail
        assert "contract-first and current component APIs" in api_check.explanation
        assert "mint docs deprecated-apis" in api_check.fix_hint
        assert "mint docs frontend choose" in api_check.fix_hint

    def test_app_sidebar_current_collapse_props_are_allowed(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "CurrentSidebarCollapse.vue").write_text("""\
<script setup lang="ts">
import { ref } from 'vue'
import { AppSidebar } from '@morscherlab/mint-sdk'

const collapsed = ref(false)
const panels = { analysis: [] }
</script>

<template>
  <AppSidebar
    variant="analysis"
    :panels="panels"
    active-view="analysis"
    v-model:collapsed="collapsed"
    collapsed-width="3rem"
  />
  <AppSidebar
    variant="analysis"
    :panels="panels"
    active-view="analysis"
    :collapsed="collapsed"
    :collapsed-width="'3rem'"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert api_check.ok
        assert api_check.detail == "none found"

    def test_deprecated_frontend_prop_snippets_in_agent_docs_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        (tmp_path / "CLAUDE.md").write_text("""\
# CLAUDE.md

Prefer this legacy SDK layout:

```vue
<BaseTabs model-value="overview" :tabs="tabs" variant="bordered" />
<AppSidebar :items="legacyItems" active-id="overview" collapsed-width="64px" />
<AppTopBar floating :pages="pages" current-page-id="overview" :tabs="tabs" />
<ControlWorkspaceView navigation="tabs" />
<DoseDesignWorkspaceView navigation="pill" />
```
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in api_check.detail
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppSidebar active-id prop -> AppSidebar active-view prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert (
            "ControlWorkspaceView navigation prop -> ControlWorkspaceView default pill navigation"
            in api_check.detail
        )
        assert (
            "DoseDesignWorkspaceView navigation prop -> DoseDesignWorkspaceView default pill navigation"
            in api_check.detail
        )

    def test_deprecated_frontend_component_subpath_import_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacySubpathImport.vue").write_text("""\
<script setup lang="ts">
import { GroupingModal } from '@morscherlab/mint-sdk/components'
</script>

<template>
  <GroupingModal :open="true" :samples="[]" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component -> AutoGroupModal" in api_check.detail

    def test_deprecated_app_topbar_legacy_navigation_props_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyTopBarNavigation.vue").write_text("""\
<template>
  <AppTopBar
    title="Legacy"
    plugin-name="Legacy Plugin"
    :pages="pages"
    current-page-id="dashboard"
    :tabs="tabs"
    current-tab-id="summary"
  />
  <AppTopBar
    v-bind="{
      pluginName: 'Legacy Plugin',
      pages,
      currentPageId: 'dashboard',
      tabs,
      currentTabId: 'summary',
    }"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppTopBar pluginName prop -> AppTopBar title/subtitle or pageSelector prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert (
            "AppTopBar current-page-id prop -> AppTopBar current-page-selector-id prop"
            in api_check.detail
        )
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert "AppTopBar current-tab-id prop -> AppTopBar current-pill-id prop" in api_check.detail

    def test_deprecated_plugin_workspace_legacy_navigation_props_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyPluginWorkspaceNavigation.vue").write_text("""\
<template>
  <PluginWorkspaceView
    title="Legacy"
    :pages="pages"
    current-page-id="dashboard"
    :tabs="tabs"
    current-tab-id="summary"
  />
  <plugin-workspace-view
    v-bind="{
      pages,
      currentPageId: 'dashboard',
      tabs,
      currentTabId: 'summary',
    }"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "PluginWorkspaceView pages prop -> PluginWorkspaceView pageSelector prop" in api_check.detail
        assert (
            "PluginWorkspaceView current-page-id prop -> PluginWorkspaceView current-page-selector-id prop"
            in api_check.detail
        )
        assert (
            "PluginWorkspaceView tabs prop -> PluginWorkspaceView pillNav prop or model-derived navigation"
            in api_check.detail
        )
        assert (
            "PluginWorkspaceView current-tab-id prop -> PluginWorkspaceView current-pill-id prop"
            in api_check.detail
        )

    def test_deprecated_control_workspace_tabs_navigation_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyControlWorkspaceNavigation.vue").write_text("""\
<template>
  <ControlWorkspaceView navigation="tabs" />
  <ControlWorkspaceView navigation="pill" />
  <ControlWorkspaceView :navigation="'tabs'" />
  <ControlWorkspaceView :navigation="navigationMode" />
  <ControlWorkspaceView v-bind="{ navigation: 'tabs' }" />
  <control-workspace-view v-bind:navigation="'tabs'" />
  <DoseDesignWorkspaceView navigation="tabs" />
  <DoseDesignWorkspaceView :navigation="'pill'" />
  <DoseDesignWorkspaceView v-bind="{ navigation: navigationMode }" />
  <dose-design-workspace-view v-bind:navigation="'tabs'" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert (
            "ControlWorkspaceView navigation prop -> ControlWorkspaceView default pill navigation"
            in api_check.detail
        )
        assert (
            "DoseDesignWorkspaceView navigation prop -> DoseDesignWorkspaceView default pill navigation"
            in api_check.detail
        )

    def test_deprecated_bio_template_preset_workspace_preset_id_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyTemplatePresetWorkspace.vue").write_text("""\
<template>
  <BioTemplatePresetWorkspaceView v-model="values" preset-id="wellplate-screen" />
  <bio-template-preset-workspace-view :presetId="'wellplate-screen'" />
  <BioTemplatePresetWorkspaceView v-bind="{ presetId: 'wellplate-screen' }" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert (
            "BioTemplatePresetWorkspaceView preset-id prop -> BioTemplatePresetWorkspaceView preset prop"
            in api_check.detail
        )
        assert "mint docs deprecated-apis" in api_check.fix_hint

    def test_deprecated_control_workspace_topbar_tabs_helpers_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyControlWorkspaceTopBar.ts").write_text("""\
import { controlsToTopBarTabs, useControlWorkspace } from '@morscherlab/mint-sdk'

const tabs = controlsToTopBarTabs({})
const workspace = useControlWorkspace({})

workspace.topBar.onTabSelect({ id: 'results', label: 'Results' })
console.log(tabs, workspace.topBar.currentTabId, workspace.bindings.topBarTabs.value.currentTabId)
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "controlsToTopBarTabs composable -> controlsToViewItems" in api_check.detail
        assert (
            "ControlWorkspace topBar tab state -> ControlWorkspace topBar.value pill navigation"
            in api_check.detail
        )
        assert (
            "ControlWorkspace topBarTabs binding -> ControlWorkspace topBar binding"
            in api_check.detail
        )

    def test_deprecated_form_builder_primitives_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyFormPrimitives.vue").write_text("""\
<script setup lang="ts">
import { FormSection, FormFieldRenderer } from '@morscherlab/mint-sdk'
import LegacySection from '@morscherlab/mint-sdk/components/FormSection.vue'
import * as MintSdk from '@morscherlab/mint-sdk'

const section = MintSdk.FormSection
const renderer = MintSdk.FormFieldRenderer
</script>

<template>
  <FormSection :section="sectionSchema" :builder="builder" />
  <FormFieldRenderer :field="field" :resolved-props="props" :form="form" />
  <form-section :section="sectionSchema" :builder="builder" />
  <component :is="'FormFieldRenderer'" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "FormSection component -> FormBuilder" in api_check.detail
        assert "FormSection component import -> FormBuilder" in api_check.detail
        assert "FormSection namespace access -> FormBuilder" in api_check.detail
        assert "FormFieldRenderer component -> FormBuilder" in api_check.detail
        assert "FormFieldRenderer namespace access -> FormBuilder" in api_check.detail
        assert "FormFieldRenderer dynamic component -> FormBuilder" in api_check.detail

    def test_deprecated_settings_button_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacySettingsButton.vue").write_text("""\
<script setup lang="ts">
import { SettingsButton } from '@morscherlab/mint-sdk'
import LegacySettingsButton from '@morscherlab/mint-sdk/components/SettingsButton.vue'
import * as MintSdk from '@morscherlab/mint-sdk'

const settingsButton = MintSdk.SettingsButton
</script>

<template>
  <SettingsButton />
  <settings-button />
  <component :is="'SettingsButton'" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "SettingsButton component -> AppTopBar" in api_check.detail
        assert "SettingsButton component import -> AppTopBar" in api_check.detail
        assert "SettingsButton namespace access -> AppTopBar" in api_check.detail
        assert "SettingsButton dynamic component -> AppTopBar" in api_check.detail

    def test_deprecated_frontend_component_default_subpath_import_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyDefaultSubpathImport.vue").write_text("""\
<script setup lang="ts">
import LegacyGrouping from '@morscherlab/mint-sdk/components/GroupingModal.vue'
import LegacyToast from '@morscherlab/mint-sdk/components/ToastNotification.vue'
import * as MintSdk from '@morscherlab/mint-sdk'

const modal = MintSdk.GroupingModal
const toast = MintSdk.ToastNotification
</script>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component import -> AutoGroupModal" in api_check.detail
        assert "GroupingModal namespace access -> AutoGroupModal" in api_check.detail
        assert "ToastNotification component import -> AppToastContainer" in api_check.detail
        assert "ToastNotification namespace access -> AppToastContainer" in api_check.detail

    def test_deprecated_frontend_private_subpath_import_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        src_dir = tmp_path / "frontend" / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        (src_dir / "legacy-private.ts").write_text("""\
import LegacyToast from '@morscherlab/mint-sdk/src/components/ToastNotification.vue'
import legacyApi from '@morscherlab/mint-sdk/src/composables/usePluginApi.ts'

const LegacyFormSection = () => import('@morscherlab/mint-sdk/src/components/FormSection.vue')
const legacyApiModule = () => import('@morscherlab/mint-sdk/src/composables/usePluginApi.ts')

export { default as LegacySettings } from '@morscherlab/mint-sdk/src/components/SettingsButton.vue'
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "ToastNotification component import -> AppToastContainer" in api_check.detail
        assert "FormSection dynamic import -> FormBuilder" in api_check.detail
        assert "SettingsButton component re-export -> AppTopBar" in api_check.detail
        assert "usePluginApi composable import -> useGeneratedPluginClient" in api_check.detail
        assert "usePluginApi dynamic import -> useGeneratedPluginClient" in api_check.detail

    def test_deprecated_frontend_plugin_api_composable_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyApiComposable.vue").write_text("""\
<script setup lang="ts">
import { usePluginApi } from '@morscherlab/mint-sdk'
import LegacyApi from '@morscherlab/mint-sdk/composables/usePluginApi'
import * as MintSdk from '@morscherlab/mint-sdk'

const api = usePluginApi({ fallbackPrefix: '/api/legacy' })
const apiFromSubpath = LegacyApi()
const apiFromNamespace = MintSdk.usePluginApi()
const loadLegacyApi = () => import('@morscherlab/mint-sdk/composables/usePluginApi')
</script>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "usePluginApi composable -> useGeneratedPluginClient" in api_check.detail
        assert "usePluginApi composable import -> useGeneratedPluginClient" in api_check.detail
        assert "usePluginApi dynamic import -> useGeneratedPluginClient" in api_check.detail
        assert "usePluginApi namespace access -> useGeneratedPluginClient" in api_check.detail

    def test_deprecated_frontend_re_exports_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        src_dir = tmp_path / "frontend" / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        (src_dir / "legacy-sdk.ts").write_text("""\
export { GroupingModal as LegacyGroupingModal } from '@morscherlab/mint-sdk'
export type { FormFieldRenderer as LegacyFormFieldRenderer } from '@morscherlab/mint-sdk'
export { default as LegacyToast } from '@morscherlab/mint-sdk/components/ToastNotification.vue'
export type * from '@morscherlab/mint-sdk/components/FormSection.vue'
export { usePluginApi as useLegacyPluginApi } from '@morscherlab/mint-sdk/composables'
export type { usePluginApi as UseLegacyPluginApi } from '@morscherlab/mint-sdk/composables'
export { default as useLegacyApi } from '@morscherlab/mint-sdk/composables/usePluginApi'
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component re-export -> AutoGroupModal" in api_check.detail
        assert "ToastNotification component re-export -> AppToastContainer" in api_check.detail
        assert "FormFieldRenderer component re-export -> FormBuilder" in api_check.detail
        assert "FormSection component re-export -> FormBuilder" in api_check.detail
        assert "usePluginApi composable re-export -> useGeneratedPluginClient" in api_check.detail

    def test_deprecated_frontend_type_only_imports_and_re_exports_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        src_dir = tmp_path / "frontend" / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        (src_dir / "legacy-types.ts").write_text("""\
import type { GroupingModal, UsePluginApiOptions, usePluginApi } from '@morscherlab/mint-sdk'
import type { UsePluginApiOptions as LegacyApiOptions } from '@morscherlab/mint-sdk/composables/usePluginApi'
import type { TopBarPage, TopBarTabOption } from '@morscherlab/mint-sdk/types'

export type { ToastNotification } from '@morscherlab/mint-sdk/components'
export type { usePluginApi as LegacyApiType } from '@morscherlab/mint-sdk/composables'
export type * from '@morscherlab/mint-sdk/components/FormSection.vue'
export type { UsePluginApiOptions as LegacyPluginApiOptions } from '@morscherlab/mint-sdk/composables'
export type { TopBarTab } from '@morscherlab/mint-sdk/types/components'
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component -> AutoGroupModal" in api_check.detail
        assert "ToastNotification component re-export -> AppToastContainer" in api_check.detail
        assert "FormSection component re-export -> FormBuilder" in api_check.detail
        assert "usePluginApi composable -> useGeneratedPluginClient" in api_check.detail
        assert "usePluginApi composable re-export -> useGeneratedPluginClient" in api_check.detail
        assert (
            "UsePluginApiOptions frontend type -> CreatePluginClientOptions / generated client types"
            in api_check.detail
        )
        assert (
            "UsePluginApiOptions frontend type import -> CreatePluginClientOptions / generated client types"
            in api_check.detail
        )
        assert (
            "UsePluginApiOptions frontend type re-export -> CreatePluginClientOptions / generated client types"
            in api_check.detail
        )
        assert "TopBarPage frontend type -> PageSelectorItem" in api_check.detail
        assert "TopBarTabOption frontend type -> PillNavOption" in api_check.detail
        assert "TopBarTab frontend type import -> PillNavItem" in api_check.detail

    def test_deprecated_frontend_namespace_destructure_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyNamespaceDestructure.vue").write_text("""\
<script setup lang="ts">
import * as MintSdk from '@morscherlab/mint-sdk'

const { GroupingModal: LegacyGroupingModal, ToastNotification } = MintSdk
const { usePluginApi: useLegacyApi } = MintSdk
const api = useLegacyApi({ fallbackPrefix: '/api/legacy' })
type LegacyApiOptions = MintSdk.UsePluginApiOptions
</script>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal namespace destructure -> AutoGroupModal" in api_check.detail
        assert "ToastNotification namespace destructure -> AppToastContainer" in api_check.detail
        assert "usePluginApi namespace destructure -> useGeneratedPluginClient" in api_check.detail
        assert (
            "UsePluginApiOptions namespace access -> CreatePluginClientOptions / generated client types"
            in api_check.detail
        )

    def test_deprecated_frontend_dynamic_import_destructure_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyDynamicDestructure.vue").write_text("""\
<script setup lang="ts">
const { GroupingModal } = await import('@morscherlab/mint-sdk')
const { ToastNotification: LegacyToast } = await import('@morscherlab/mint-sdk/components')
const { usePluginApi: useLegacyApi } = await import('@morscherlab/mint-sdk/composables')
const DirectGroupingModal = (await import('@morscherlab/mint-sdk')).GroupingModal
const DirectToastNotification = (await import('@morscherlab/mint-sdk/components')).ToastNotification
const directLegacyApi = (await import('@morscherlab/mint-sdk/composables')).usePluginApi
const callbackGroupingModal = import('@morscherlab/mint-sdk').then(sdk => sdk.GroupingModal)
const callbackToastNotification = import('@morscherlab/mint-sdk/components')
  .then(({ ToastNotification }) => ToastNotification)
const callbackLegacyApi = import('@morscherlab/mint-sdk/composables').then(sdk => sdk.usePluginApi)
const api = useLegacyApi({ fallbackPrefix: '/api/legacy' })
const directApi = directLegacyApi({ fallbackPrefix: '/api/legacy' })
</script>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal dynamic import destructure -> AutoGroupModal" in api_check.detail
        assert "ToastNotification dynamic import destructure -> AppToastContainer" in api_check.detail
        assert "usePluginApi dynamic import destructure -> useGeneratedPluginClient" in api_check.detail
        assert "GroupingModal dynamic import member -> AutoGroupModal" in api_check.detail
        assert "ToastNotification dynamic import member -> AppToastContainer" in api_check.detail
        assert "usePluginApi dynamic import member -> useGeneratedPluginClient" in api_check.detail
        assert "GroupingModal dynamic import then member -> AutoGroupModal" in api_check.detail
        assert "ToastNotification dynamic import then destructure -> AppToastContainer" in api_check.detail
        assert "usePluginApi dynamic import then member -> useGeneratedPluginClient" in api_check.detail

    def test_deprecated_frontend_kebab_case_component_usage_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyKebabComponents.vue").write_text("""\
<template>
  <grouping-modal :open="true" :samples="[]" />
  <toast-notification />
  <base-tabs model-value="overview" :tabs="[]" variant="bordered" />
  <app-sidebar :items="legacyItems" active-id="overview" collapsed collapsed-width="64px" />
  <app-top-bar
    title="Legacy"
    floating
    :pages="pages"
    current-page-id="overview"
    :tabs="tabs"
    current-tab-id="run"
  />
  <control-workspace-view v-bind="workspaceModel" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal component -> AutoGroupModal" in api_check.detail
        assert "ToastNotification component -> AppToastContainer" in api_check.detail
        assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in api_check.detail
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert (
            'ControlWorkspaceView v-bind="workspaceModel" -> ControlWorkspaceView :model="workspaceModel"'
            in api_check.detail
        )

    def test_deprecated_frontend_v_bind_object_props_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyObjectBindings.vue").write_text("""\
<template>
  <BaseTabs v-bind="{ modelValue: 'overview', tabs: [], variant: 'bordered' }" />
  <AppSidebar
    v-bind="{
      items: legacyItems,
      activeId: 'overview',
      collapsed: true,
      collapsedWidth: '64px',
    }"
  />
  <AppSidebar
    v-bind="{
      'active-id': 'overview',
      'collapsed-width': '64px',
    }"
  />
  <AppTopBar
    v-bind="{
      title: 'Legacy',
      floating: true,
      sticky: true,
      pages: pages,
      currentPageId: 'overview',
      tabs: tabs,
      currentTabId: 'run',
    }"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in api_check.detail
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppSidebar active-id prop -> AppSidebar active-view prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar sticky prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert "AppTopBar current-page-id prop -> AppTopBar current-page-selector-id prop" in api_check.detail
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert "AppTopBar current-tab-id prop -> AppTopBar current-pill-id prop" in api_check.detail

    def test_deprecated_frontend_named_v_bind_object_props_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyNamedObjectBindings.vue").write_text("""\
<script setup lang="ts">
const sidebarProps = {
  items,
  activeId: 'overview',
  collapsed,
  collapsedWidth: '64px',
}
const topbarProps = {
  floating,
  sticky: true,
  pages,
  currentPageId: 'overview',
  tabs,
  currentTabId: 'run',
}
const workspaceProps = {
  navigation: 'tabs',
}
</script>

<template>
  <AppSidebar v-bind="sidebarProps" />
  <AppTopBar v-bind="topbarProps" />
  <ControlWorkspaceView v-bind="workspaceProps" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppSidebar active-id prop -> AppSidebar active-view prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar sticky prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert "AppTopBar current-page-id prop -> AppTopBar current-page-selector-id prop" in api_check.detail
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert "AppTopBar current-tab-id prop -> AppTopBar current-pill-id prop" in api_check.detail
        assert (
            "ControlWorkspaceView navigation prop -> ControlWorkspaceView default pill navigation"
            in api_check.detail
        )

    def test_deprecated_frontend_longform_v_bind_props_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyLongformBindings.vue").write_text("""\
<template>
  <BaseTabs
    model-value="overview"
    :tabs="[]"
    v-bind:variant="'bordered'"
  />
  <AppSidebar
    v-bind:items="legacyItems"
    v-bind:active-id="'overview'"
    v-bind:collapsed="isCollapsed"
    v-bind:collapsed-width="'64px'"
  />
  <AppTopBar
    title="Legacy"
    v-bind:floating="true"
    v-bind:sticky="true"
    v-bind:pages="pages"
    v-bind:current-page-id="'overview'"
    v-bind:tabs="tabs"
    v-bind:current-tab-id="'run'"
  />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert 'BaseTabs variant="bordered" -> BaseTabs variant="underline"' in api_check.detail
        assert "AppSidebar items prop -> AppSidebar panels prop" in api_check.detail
        assert "AppSidebar active-id prop -> AppSidebar active-view prop" in api_check.detail
        assert "AppTopBar floating prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar sticky prop -> AppTopBar variant prop" in api_check.detail
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert "AppTopBar current-page-id prop -> AppTopBar current-page-selector-id prop" in api_check.detail
        assert "AppTopBar tabs prop -> AppTopBar pillNav prop" in api_check.detail
        assert "AppTopBar current-tab-id prop -> AppTopBar current-pill-id prop" in api_check.detail

    def test_deprecated_frontend_dynamic_component_usage_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyDynamicComponents.vue").write_text("""\
<script setup lang="ts">
import { resolveComponent } from 'vue'

const legacyModal = resolveComponent('GroupingModal')
const loadLegacyModal = () => import('@morscherlab/mint-sdk/components/GroupingModal.vue')
const legacyRegistry = {
  toast: { component: 'toast-notification' },
}
</script>

<template>
  <component :is="'ToastNotification'" />
  <component is="grouping-modal" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "GroupingModal dynamic import -> AutoGroupModal" in api_check.detail
        assert "GroupingModal dynamic component -> AutoGroupModal" in api_check.detail
        assert "ToastNotification dynamic component -> AppToastContainer" in api_check.detail

    def test_deprecated_package_names_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "mint-plugin-test"
version = "0.1.0"
dependencies = ["mint-sdk>=0.9.0", "mld-sdk>=0.8.0"]

[project.entry-points."mint.plugins"]
test = "mint_plugin_test.plugin:TestPlugin"
""")
        (tmp_path / "frontend" / "package.json").write_text(
            json.dumps(
                {
                    "dependencies": {
                        "@morscherlab/mint-sdk": "^1.0.0",
                        "@morscherlab/mld-sdk": "^0.8.0",
                    },
                }
            )
        )
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "legacy_imports.py"
        plugin_file.write_text("from mld_sdk import AnalysisPlugin\n")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "mld-sdk Python dependency -> mint-sdk" in api_check.detail
        assert "@morscherlab/mld-sdk frontend package -> @morscherlab/mint-sdk" in api_check.detail
        assert "mld_sdk Python package -> mint_sdk" in api_check.detail

    def test_deprecated_python_sdk_compatibility_apis_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text("""\
from fastapi import APIRouter
from mint_sdk import AnalysisPlugin, DesignData, PluginExperimentData, PluginMetadata
from mint_sdk.repositories import PluginExperimentData as RepositoryPluginExperimentData

router = APIRouter()


class TestPlugin(AnalysisPlugin):
    @property
    def metadata(self):
        return PluginMetadata(
            name="test",
            version="0.1.0",
            description="Test plugin",
            analysis_type="custom",
            routes_prefix="/test",
            icon="M4 4h16",
        )

    def get_routers(self):
        return [(router, "")]

    async def initialize(self, context=None):
        self._setup_local_database()
        data_model: type[PluginExperimentData] = RepositoryPluginExperimentData
        self.latest_design_type = data_model or DesignData
        self._teardown_local_database()
        _ = self.local_db

    def get_local_models(self):
        return []
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "PluginExperimentData model -> DesignData" in api_check.detail
        assert "AnalysisPlugin.local_db -> AnalysisPlugin.standalone_db" in api_check.detail
        assert "AnalysisPlugin.get_local_models() override -> AnalysisPlugin.get_shared_models()" in api_check.detail
        assert "AnalysisPlugin._setup_local_database() -> AnalysisPlugin._setup_standalone_db()" in api_check.detail
        assert (
            "AnalysisPlugin._teardown_local_database() -> AnalysisPlugin._teardown_standalone_db()"
            in api_check.detail
        )

    def test_deprecated_docs_and_agent_command_text_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        (tmp_path / "README.md").write_text("""\
# Legacy plugin

Run `mld add endpoint run --method post` after editing the backend.
Mount <ToastNotification /> at the app root.
""")
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "frontend.md").write_text("""\
Install @morscherlab/mld-sdk before using the plugin frontend.
Import { WellPlate } from '@morscherlab/mint-sdk/components'.
Import { useFormBuilder } from '@morscherlab/mint-sdk/composables'.
Use GroupingModal for CSV metadata.
Use usePluginApi() for requests.
Use UsePluginApiOptions for options.
Use import.meta.env.VITE_API_PREFIX before calling useApi({ baseUrl: prefix }).
Call api.get('/api/test/rows') for frontend data.
""")
        cursor_rules_dir = tmp_path / ".cursor" / "rules"
        cursor_rules_dir.mkdir(parents=True)
        (cursor_rules_dir / "mint.mdc").write_text("""\
Use ToastNotification for global messages.
""")
        github_dir = tmp_path / ".github"
        github_dir.mkdir()
        (github_dir / "copilot-instructions.md").write_text("""\
Run mld doctor before shipping.
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "README.md" in api_check.detail
        assert "docs/frontend.md" in api_check.detail
        assert ".cursor/rules/mint.mdc" in api_check.detail
        assert ".github/copilot-instructions.md" in api_check.detail
        assert "mld CLI command -> mint" in api_check.detail
        assert "@morscherlab/mld-sdk frontend package -> @morscherlab/mint-sdk" in api_check.detail
        assert "ToastNotification component docs -> AppToastContainer" in api_check.detail
        assert "usePluginApi composable docs -> useGeneratedPluginClient" in api_check.detail
        assert (
            "UsePluginApiOptions frontend type docs -> CreatePluginClientOptions / generated client types"
            in api_check.detail
        )
        assert "GroupingModal component docs -> AutoGroupModal" in api_check.detail
        assert "component subpath import docs -> root @morscherlab/mint-sdk import" in api_check.detail
        assert "composable subpath import docs -> root @morscherlab/mint-sdk import" in api_check.detail
        assert "VITE_API_PREFIX docs -> useGeneratedPluginClient" in api_check.detail
        assert "useApi({ baseUrl }) docs -> useGeneratedPluginClient" in api_check.detail
        assert "raw /api frontend docs -> useGeneratedPluginClient" in api_check.detail

    def test_deprecated_frontend_prop_snippets_in_docs_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()
        (docs_dir / "frontend.md").write_text("""\
# Frontend Notes

```vue
<AppTopBar :pages="pages" current-page-id="overview" />
<ControlWorkspaceView navigation="tabs" />
<DoseDesignWorkspaceView navigation="pill" />
```
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppTopBar pages prop -> AppTopBar pageSelector prop" in api_check.detail
        assert (
            "ControlWorkspaceView navigation prop -> ControlWorkspaceView default pill navigation"
            in api_check.detail
        )
        assert (
            "DoseDesignWorkspaceView navigation prop -> DoseDesignWorkspaceView default pill navigation"
            in api_check.detail
        )

    def test_deprecated_get_frontend_config_navitems_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            + """\

    def get_frontend_config(self):
        config = super().get_frontend_config()
        config["navItems"] = [{"path": "/", "label": "Dashboard"}]
        return config
"""
        )

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "get_frontend_config navItems -> PluginMetadata.nav_items" in api_check.detail
        assert "mint docs deprecated-apis" in api_check.fix_hint
        assert "mint docs frontend choose" in api_check.fix_hint

    def test_deprecated_plugin_metadata_nav_item_dicts_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            .replace(
                '            icon="M4 4h16",',
                (
                    '            icon="M4 4h16",\n'
                    '            nav_items=[\n'
                    '                {"path": "/", "label": "Dashboard", "id": "dashboard", "icon": "M3 13h8"},\n'
                    '            ],'
                ),
            )
        )

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "PluginMetadata.nav_items dict -> PluginNavItem(...)" in api_check.detail
        assert "mint docs deprecated-apis" in api_check.fix_hint

    def test_plugin_nav_items_without_icons_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            .replace(
                "from mint_sdk import AnalysisPlugin, PluginMetadata",
                "from mint_sdk import AnalysisPlugin, PluginMetadata, PluginNavItem",
            )
            .replace(
                'routes_prefix="/test",',
                (
                    'routes_prefix="/test",\n'
                    '            nav_items=[\n'
                    '                PluginNavItem(path="/", label="Dashboard", id="dashboard"),\n'
                    '            ],'
                ),
            )
        )

        results = run_checks(tmp_path)

        icon_check = [r for r in results if r.label == "Plugin page metadata icons"][0]
        assert not icon_check.ok
        assert "PluginNavItem entries missing icon" in icon_check.detail
        assert "Dashboard (/)" in icon_check.detail
        assert "PluginMetadata.nav_items" in icon_check.explanation
        assert "mint add frontend-page" in icon_check.fix_hint

    def test_plugin_nav_items_without_ids_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            .replace(
                "from mint_sdk import AnalysisPlugin, PluginMetadata",
                "from mint_sdk import AnalysisPlugin, PluginMetadata, PluginNavItem",
            )
            .replace(
                'routes_prefix="/test",',
                (
                    'routes_prefix="/test",\n'
                    '            nav_items=[\n'
                    '                PluginNavItem(path="/", label="Dashboard", icon="M3 13h8"),\n'
                    '            ],'
                ),
            )
        )

        results = run_checks(tmp_path)

        id_check = [r for r in results if r.label == "Plugin page metadata IDs"][0]
        assert not id_check.ok
        assert "PluginNavItem entries missing id" in id_check.detail
        assert "Dashboard (/)" in id_check.detail
        assert "PluginMetadata.nav_items" in id_check.explanation
        assert "mint add frontend-page" in id_check.fix_hint

    def test_frontend_routes_without_plugin_nav_items_fail(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        frontend_src = tmp_path / "frontend" / "src"
        frontend_src.mkdir(parents=True, exist_ok=True)
        (frontend_src / "main.ts").write_text("""\
const routes = [
  { path: '/', name: 'dashboard' },
  { path: '/quality-control', name: 'quality-control' },
]
""")

        results = run_checks(tmp_path)

        coverage_check = [r for r in results if r.label == "Plugin page metadata coverage"][0]
        assert not coverage_check.ok
        assert "frontend routes missing PluginMetadata.nav_items" in coverage_check.detail
        assert "frontend/src/main.ts" in coverage_check.detail
        assert "/quality-control" in coverage_check.detail
        assert "homepage PluginCard" in coverage_check.explanation
        assert "PluginMetadata.nav_items" in coverage_check.explanation
        assert "mint add frontend-page" in coverage_check.fix_hint

    def test_frontend_routes_with_plugin_nav_items_pass(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        frontend_src = tmp_path / "frontend" / "src"
        frontend_src.mkdir(parents=True, exist_ok=True)
        (frontend_src / "main.ts").write_text("""\
const routes = [
  { path: '/', name: 'dashboard' },
  { path: '/quality-control', name: 'quality-control' },
]
""")
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            .replace(
                "from mint_sdk import AnalysisPlugin, PluginMetadata",
                "from mint_sdk import AnalysisPlugin, PluginMetadata, PluginNavItem",
            )
            .replace(
                'routes_prefix="/test",',
                (
                    'routes_prefix="/test",\n'
                    '            nav_items=[\n'
                    '                PluginNavItem(\n'
                    '                    path="/quality-control",\n'
                    '                    label="Quality Control",\n'
                    '                    id="quality-control",\n'
                    '                    icon="M4 4h16",\n'
                    '                ),\n'
                    '            ],'
                ),
            )
        )

        results = run_checks(tmp_path)

        coverage_check = [r for r in results if r.label == "Plugin page metadata coverage"][0]
        assert coverage_check.ok
        assert coverage_check.detail == "frontend routes covered"

    def test_plugin_metadata_without_icon_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(plugin_file.read_text().replace('            icon="M4 4h16",\n', ""))

        results = run_checks(tmp_path)

        icon_check = [r for r in results if r.label == "Plugin metadata icon"][0]
        assert not icon_check.ok
        assert "PluginMetadata entries missing icon" in icon_check.detail
        assert "PluginMetadata.icon" in icon_check.explanation
        assert 'icon="..."' in icon_check.fix_hint

    def test_plugin_metadata_with_icon_passes(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)

        results = run_checks(tmp_path)

        icon_check = [r for r in results if r.label == "Plugin metadata icon"][0]
        assert icon_check.ok
        assert icon_check.detail == "ok"

    def test_plugin_nav_items_with_icons_pass(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            .replace(
                "from mint_sdk import AnalysisPlugin, PluginMetadata",
                "from mint_sdk import AnalysisPlugin, PluginMetadata, PluginNavItem",
            )
            .replace(
                "router = APIRouter()",
                'router = APIRouter()\n\nDASHBOARD_ICON = "M4 4h16"',
            )
            .replace(
                'routes_prefix="/test",',
                (
                    'routes_prefix="/test",\n'
                    '            nav_items=[\n'
                    '                PluginNavItem(\n'
                    '                    path="/", label="Dashboard", id="dashboard", icon=DASHBOARD_ICON,\n'
                    '                ),\n'
                    '            ],'
                ),
            )
        )

        results = run_checks(tmp_path)

        icon_check = [r for r in results if r.label == "Plugin page metadata icons"][0]
        id_check = [r for r in results if r.label == "Plugin page metadata IDs"][0]
        assert icon_check.ok
        assert icon_check.detail == "ok"
        assert id_check.ok
        assert id_check.detail == "ok"

    def test_current_sdk_api_usage_passes_deprecated_api_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        plugin_file = tmp_path / "src" / "mint_plugin_test" / "plugin.py"
        plugin_file.write_text(
            plugin_file.read_text()
            + """\

    def get_frontend_config(self):
        config = super().get_frontend_config()
        config["theme"] = "default"
        return config
"""
        )
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ModernComponents.vue").write_text("""\
<script setup lang="ts">
import { AutoGroupModal, SegmentedControl } from '@morscherlab/mint-sdk'
import { AppToastContainer } from '@morscherlab/mint-sdk'
</script>

<template>
  <AutoGroupModal v-model="open" :samples="[]" />
  <AppToastContainer />
  <BaseTabs model-value="overview" :tabs="[]" variant="underline" />
  <SegmentedControl model-value="general" :options="[]" :disabled-values="['admin']" />
  <AppSidebar :panels="panels" active-view="overview" />
  <AppTopBar
    title="Modern"
    variant="solid"
    :page-selector="pages"
    current-page-selector-id="overview"
    :pill-nav="modes"
    current-pill-id="summary"
    :settings-config="{ tabs: ['General'] }"
  />
  <PluginWorkspaceView
    title="Modern Plugin"
    :page-selector="pages"
    current-page-selector-id="overview"
    :pill-nav="modes"
    current-pill-id="summary"
  />
  <ControlWorkspaceView title="Modern Workspace" />
  <BioTemplatePresetWorkspaceView v-model="values" preset="wellplate-screen" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert api_check.ok
        assert api_check.detail == "none found"

    def test_deprecated_api_catalog_is_shared_by_doctor_and_docs(self):
        assert docs_command._DEPRECATED_API_DOC is DEPRECATED_API_DOC
        assert doctor_command._DEPRECATED_TEXT_PATTERNS is DEPRECATED_TEXT_PATTERNS
        assert doctor_command._DEPRECATED_FRONTEND_IMPORT_PATTERNS is DEPRECATED_FRONTEND_IMPORT_PATTERNS
        assert doctor_command._DEPRECATED_FRONTEND_EXPRESSION_PATTERNS is DEPRECATED_FRONTEND_EXPRESSION_PATTERNS
        assert doctor_command._DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS is DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS
        assert (
            doctor_command._DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS
            is DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS
        )
        assert doctor_command._DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS is DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS
        assert doctor_command._DEPRECATED_FRONTEND_TAG_RULES is DEPRECATED_FRONTEND_TAG_RULES

    def test_retired_app_nav_primitives_fail_deprecated_api_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyNavPrimitives.vue").write_text("""\
<script setup lang="ts">
import { AppPageSelector, AppPillNav } from '@morscherlab/mint-sdk'
</script>

<template>
  <AppPageSelector :pages="pages" current-page-id="dashboard" />
  <AppPillNav :items="modes" current-item-id="summary" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppPageSelector component -> AppTopBar" in api_check.detail
        assert "AppPillNav component -> AppTopBar" in api_check.detail
        assert "mint docs deprecated-apis" in api_check.fix_hint

    def test_retired_app_nav_primitive_subpath_imports_fail_deprecated_api_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "LegacyNavPrimitiveSubpaths.vue").write_text("""\
<script setup lang="ts">
import PageSelector from '@morscherlab/mint-sdk/components/AppPageSelector.vue'
import PillNav from '@morscherlab/mint-sdk/src/components/AppPillNav.vue'

const LazySelector = () => import('@morscherlab/mint-sdk/components/AppPageSelector.vue')
</script>

<template>
  <PageSelector :pages="pages" />
  <PillNav :items="modes" />
</template>
""")

        results = run_checks(tmp_path)

        api_check = [r for r in results if r.label == "Deprecated SDK APIs"][0]
        assert not api_check.ok
        assert "AppPageSelector component import -> AppTopBar" in api_check.detail
        assert "AppPillNav component import -> AppTopBar" in api_check.detail
        assert "AppPageSelector dynamic import -> AppTopBar" in api_check.detail

    def test_deprecated_frontend_components_are_static_after_public_removal(self):
        manifest_path = (
            Path(__file__).resolve().parents[1]
            / "src"
            / "mint_sdk"
            / "docs"
            / "bundled"
            / "frontend.json"
        )
        manifest = json.loads(manifest_path.read_text())
        components = manifest["categories"]["components"]
        expected = {
            item["name"]: item["replacement"]
            for item in components
            if item.get("deprecated") is True
        }

        actual = {component.name: component.replacement for component in DEPRECATED_FRONTEND_COMPONENTS}

        assert expected == {}
        assert actual == {
            "AppPageSelector": "AppTopBar",
            "AppPillNav": "AppTopBar",
            "FormFieldRenderer": "FormBuilder",
            "FormSection": "FormBuilder",
            "GroupingModal": "AutoGroupModal",
            "SettingsButton": "AppTopBar",
            "ToastNotification": "AppToastContainer",
        }

    def test_static_deprecated_frontend_component_fallback_covers_current_wrappers(self):
        expected = {
            "AppPageSelector": "AppTopBar",
            "AppPillNav": "AppTopBar",
            "FormFieldRenderer": "FormBuilder",
            "FormSection": "FormBuilder",
            "GroupingModal": "AutoGroupModal",
            "SettingsButton": "AppTopBar",
            "ToastNotification": "AppToastContainer",
        }
        actual = {
            component.name: component.replacement
            for component in deprecated_apis._STATIC_DEPRECATED_FRONTEND_COMPONENTS
        }

        assert actual == expected

    def test_deprecated_frontend_composables_are_static_after_public_removal(self):
        manifest_path = (
            Path(__file__).resolve().parents[1]
            / "src"
            / "mint_sdk"
            / "docs"
            / "bundled"
            / "frontend.json"
        )
        manifest = json.loads(manifest_path.read_text())
        composables = manifest["categories"]["composables"]
        expected = {
            item["name"]: item["replacement"]
            for item in composables
            if item.get("deprecated") is True
        }

        actual = {composable.name: composable.replacement for composable in DEPRECATED_FRONTEND_COMPOSABLES}

        assert expected == {}
        assert actual == {
            "usePluginApi": "useGeneratedPluginClient",
            "controlsToTopBarTabs": "controlsToViewItems",
        }

    def test_deprecated_frontend_types_cover_retired_type_exports(self):
        actual = {frontend_type.name: frontend_type.replacement for frontend_type in DEPRECATED_FRONTEND_TYPES}

        assert actual == {
            "UsePluginApiOptions": "CreatePluginClientOptions / generated client types",
            "TopBarPage": "PageSelectorItem",
            "TopBarPageInput": "PageSelectorItemInput",
            "TopBarTab": "PillNavItem",
            "TopBarTabInput": "PillNavItemInput",
            "TopBarTabOption": "PillNavOption",
            "TopBarTabOptionInput": "PillNavOptionInput",
        }

    def test_deprecated_frontend_components_generate_all_doctor_rule_shapes(self):
        import_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_IMPORT_PATTERNS}
        expression_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_EXPRESSION_PATTERNS}
        destructure_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS}
        dynamic_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DYNAMIC_COMPONENT_PATTERNS}
        doc_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS}
        tag_names_by_marker = {
            marker: tag_names
            for tag_names, rules in DEPRECATED_FRONTEND_TAG_RULES
            for marker, _, _ in rules
        }

        for component in DEPRECATED_FRONTEND_COMPONENTS:
            assert f"{component.name} component" in import_markers
            assert f"{component.name} component import" in import_markers
            assert f"{component.name} dynamic import" in import_markers
            assert f"{component.name} component re-export" in import_markers
            assert f"{component.name} namespace access" in expression_markers
            assert f"{component.name} dynamic import member" in expression_markers
            assert f"{component.name} dynamic import then member" in expression_markers
            assert f"{component.name} namespace destructure" in destructure_markers
            assert f"{component.name} dynamic import destructure" in destructure_markers
            assert f"{component.name} dynamic import then destructure" in destructure_markers
            assert f"{component.name} dynamic component" in dynamic_markers
            assert f"{component.name} component docs" in doc_markers
            assert tag_names_by_marker[f"{component.name} component"] == (
                component.name,
                component.kebab_name,
            )

    def test_deprecated_frontend_composables_generate_all_doctor_rule_shapes(self):
        import_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_IMPORT_PATTERNS}
        expression_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_EXPRESSION_PATTERNS}
        destructure_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DESTRUCTURE_PATTERNS}
        doc_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS}

        for composable in DEPRECATED_FRONTEND_COMPOSABLES:
            assert f"{composable.name} composable" in import_markers
            assert f"{composable.name} composable import" in import_markers
            assert f"{composable.name} dynamic import" in import_markers
            assert f"{composable.name} composable re-export" in import_markers
            assert f"{composable.name} namespace access" in expression_markers
            assert f"{composable.name} dynamic import member" in expression_markers
            assert f"{composable.name} dynamic import then member" in expression_markers
            assert f"{composable.name} namespace destructure" in destructure_markers
            assert f"{composable.name} dynamic import destructure" in destructure_markers
            assert f"{composable.name} dynamic import then destructure" in destructure_markers
            assert f"{composable.name} composable docs" in doc_markers

    def test_deprecated_frontend_types_generate_doctor_rule_shapes(self):
        import_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_IMPORT_PATTERNS}
        expression_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_EXPRESSION_PATTERNS}
        doc_markers = {marker for marker, _, _ in DEPRECATED_FRONTEND_DOC_TEXT_PATTERNS}

        for frontend_type in DEPRECATED_FRONTEND_TYPES:
            assert f"{frontend_type.name} frontend type" in import_markers
            assert f"{frontend_type.name} frontend type import" in import_markers
            assert f"{frontend_type.name} frontend type re-export" in import_markers
            assert f"{frontend_type.name} namespace access" in expression_markers
            assert f"{frontend_type.name} frontend type docs" in doc_markers

    def test_agents_md_satisfies_ai_check(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs frontend consolidate`, `mint docs deprecated-apis`, "
            "and `mint docs contract .`; use `useGeneratedPluginContract` and "
            "`PluginWorkspaceView`; use "
            "`PluginWorkspaceView sidebar-content-id=\"...\" show-sidebar-when-empty`; "
            "use `AppSidebar variant=\"analysis\"`; use `useBioTemplatePresetWorkspace`, "
            "`useBioTemplatePackWorkspace`, `BioTemplatePackWorkspaceView`, "
            "`ComponentBindingRenderer`, and `componentBindingsById` before "
            "hand-writing SDK code. Use `SettingsModal access metadata`, "
            "`settings_model json_schema_extra`, `can_access_policy`, "
            "`canAccessByPolicy`, and `SegmentedControl disabledValues` for "
            "permission-gated settings and visible disabled tabs.\n"
        )
        results = run_checks(tmp_path)
        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert ai_check.ok
        assert "AGENTS.md" in ai_check.detail

    def test_agents_md_without_consolidation_guidance_is_stale(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs contract .`, use `useGeneratedPluginContract`, "
            "use `AppSidebar variant=\"analysis\"`, and use "
            "`useBioTemplatePresetWorkspace` before hand-writing SDK code.\n"
        )

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert "mint docs frontend consolidate" in ai_check.detail
        assert "mint docs deprecated-apis" in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"

    def test_agents_md_without_analysis_sidebar_guidance_is_stale(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs frontend consolidate`, `mint docs deprecated-apis`, "
            "and `mint docs contract .`. Use `useGeneratedPluginContract` and "
            "`useBioTemplatePresetWorkspace`; use `show-sidebar-when-empty` before "
            "hand-writing SDK code.\n"
        )

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert 'AppSidebar variant="analysis"' in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"

    def test_agents_md_without_route_owned_sidebar_guidance_is_stale(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs frontend consolidate`, `mint docs deprecated-apis`, "
            "and `mint docs contract .`; use `useGeneratedPluginContract` and "
            "`AppSidebar variant=\"analysis\"`; use "
            "`useBioTemplatePresetWorkspace` before hand-writing SDK code.\n"
        )

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert "show-sidebar-when-empty" in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"

    def test_agents_md_without_permission_settings_guidance_is_stale(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs frontend consolidate`, `mint docs deprecated-apis`, "
            "and `mint docs contract .`; use `useGeneratedPluginContract` and "
            "`PluginWorkspaceView`; use "
            "`PluginWorkspaceView sidebar-content-id=\"...\" show-sidebar-when-empty`; "
            "use `AppSidebar variant=\"analysis\"`; use `useBioTemplatePresetWorkspace`, "
            "`useBioTemplatePackWorkspace`, `BioTemplatePackWorkspaceView`, "
            "`ComponentBindingRenderer`, and `componentBindingsById` before "
            "hand-writing SDK code.\n"
        )

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert "SettingsModal access metadata" in ai_check.detail
        assert "settings_model json_schema_extra" in ai_check.detail
        assert "can_access_policy" in ai_check.detail
        assert "canAccessByPolicy" in ai_check.detail
        assert "SegmentedControl disabledValues" in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"

    def test_stale_ai_instructions_fail_with_fix_hint(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text("# AGENTS.md\n\nUse mint docs before coding.\n")

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert "missing current SDK guidance" in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"
        assert "mint doctor --fix" in ai_check.fix_hint

    def test_legacy_template_collection_ai_guidance_fails(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        (tmp_path / "AGENTS.md").write_text(
            "# AGENTS.md\n\n"
            "Run `mint docs contract .`, use `useGeneratedPluginContract`, "
            "and use `useTemplateCollection` before hand-writing SDK code.\n"
        )

        results = run_checks(tmp_path)

        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert not ai_check.ok
        assert "useBioTemplatePresetWorkspace" in ai_check.detail
        assert "BioTemplatePackWorkspaceView" in ai_check.detail
        assert "useBioTemplatePackWorkspace" in ai_check.detail
        assert ai_check.fix_id == "ai-instructions"

    def test_failed_checks_include_explanations_and_fix_ids(self, tmp_path: Path):
        _make_plugin(tmp_path, with_tests=False, with_claude=False)
        results = run_checks(tmp_path)

        tests_check = [r for r in results if r.label == "Tests"][0]
        ai_check = [r for r in results if r.label == "AI instructions"][0]
        assert tests_check.explanation
        assert tests_check.fix_id == "tests"
        assert ai_check.fix_id == "ai-instructions"


class TestApplyFixes:
    def test_apply_safe_fixes_creates_tests_and_agents(self, tmp_path: Path):
        _make_plugin(tmp_path, with_tests=False, with_claude=False)
        results = run_checks(tmp_path)

        applied = apply_fixes(tmp_path, results)

        assert "Created tests/test_plugin.py" in applied
        assert "Created AGENTS.md" in applied
        assert (tmp_path / "tests" / "test_plugin.py").exists()
        assert (tmp_path / "AGENTS.md").exists()
        assert "mint docs contract ." in (tmp_path / "AGENTS.md").read_text()
        assert "mint docs frontend choose" in (tmp_path / "AGENTS.md").read_text()
        assert "mint docs frontend consolidate" in (tmp_path / "AGENTS.md").read_text()
        assert "mint docs deprecated-apis" in (tmp_path / "AGENTS.md").read_text()
        assert "BioTemplatePresetWorkspaceView" in (tmp_path / "AGENTS.md").read_text()
        assert "BioTemplatePackWorkspaceView" in (tmp_path / "AGENTS.md").read_text()
        assert "PluginWorkspaceView" in (tmp_path / "AGENTS.md").read_text()
        assert 'AppSidebar variant="analysis"' in (tmp_path / "AGENTS.md").read_text()
        assert "show-sidebar-when-empty" in (tmp_path / "AGENTS.md").read_text()
        assert "useBioTemplatePresetWorkspace" in (tmp_path / "AGENTS.md").read_text()
        assert "useBioTemplatePackWorkspace" in (tmp_path / "AGENTS.md").read_text()
        assert "SettingsModal access metadata" in (tmp_path / "AGENTS.md").read_text()
        assert "settings_model json_schema_extra" in (tmp_path / "AGENTS.md").read_text()
        assert "can_access_policy" in (tmp_path / "AGENTS.md").read_text()
        assert "canAccessByPolicy" in (tmp_path / "AGENTS.md").read_text()
        assert "SegmentedControl disabledValues" in (tmp_path / "AGENTS.md").read_text()

    def test_apply_safe_fixes_updates_stale_agents(self, tmp_path: Path):
        _make_plugin(tmp_path, with_claude=False)
        agents = tmp_path / "AGENTS.md"
        agents.write_text("# AGENTS.md\n\nUse mint docs before coding.\n")
        results = run_checks(tmp_path)

        applied = apply_fixes(tmp_path, results)

        assert "Updated AI instructions with current SDK discovery" in applied
        content = agents.read_text()
        assert "mint docs contract ." in content
        assert "mint docs frontend choose" in content
        assert "mint docs frontend consolidate" in content
        assert "mint docs deprecated-apis" in content
        assert "useGeneratedPluginContract" in content
        assert "BioTemplatePresetWorkspaceView" in content
        assert "BioTemplatePackWorkspaceView" in content
        assert "PluginWorkspaceView" in content
        assert 'AppSidebar variant="analysis"' in content
        assert "show-sidebar-when-empty" in content
        assert "useBioTemplatePresetWorkspace" in content
        assert "useBioTemplatePackWorkspace" in content
        assert "SettingsModal access metadata" in content
        assert "settings_model json_schema_extra" in content
        assert "can_access_policy" in content
        assert "canAccessByPolicy" in content
        assert "SegmentedControl disabledValues" in content

    def test_apply_safe_fixes_adds_sdk_deps(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        (tmp_path / "pyproject.toml").write_text("""\
[project]
name = "mint-plugin-test"
version = "0.1.0"
description = "Test plugin"
dependencies = ["fastapi"]

[project.entry-points."mint.plugins"]
test = "mint_plugin_test.plugin:TestPlugin"
""")
        (tmp_path / "frontend" / "package.json").write_text('{"dependencies": {}}')
        results = run_checks(tmp_path)

        applied = apply_fixes(tmp_path, results)

        assert "Added mint-sdk to pyproject.toml dependencies" in applied
        assert "Added @morscherlab/mint-sdk to frontend/package.json" in applied
        assert "mint-sdk>=1.0.0a8" in (tmp_path / "pyproject.toml").read_text()
        assert "@morscherlab/mint-sdk" in (tmp_path / "frontend" / "package.json").read_text()

    def test_apply_safe_fixes_regenerates_contract(self, tmp_path: Path):
        _make_plugin(tmp_path, with_frontend=True)
        generated = tmp_path / "frontend" / "src" / "generated"
        for path in generated.iterdir():
            path.unlink()
        results = run_checks(tmp_path)

        applied = apply_fixes(tmp_path, results)

        assert "Regenerated frontend plugin contract" in applied
        assert (generated / "mint-plugin.contract.json").exists()
        assert (generated / "mint-plugin.ts").exists()


class TestCmdDoctor:
    def test_exits_zero_on_success(self, tmp_path: Path):
        _make_plugin(tmp_path)
        cmd_doctor(path=str(tmp_path))  # should not raise

    def test_exits_one_on_failure(self, tmp_path: Path):
        with pytest.raises(SystemExit) as exc_info:
            cmd_doctor(path=str(tmp_path))
        assert exc_info.value.code == 1

    def test_explain_prints_why_and_fix(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]):
        _make_plugin(tmp_path, with_tests=False)
        with pytest.raises(SystemExit):
            cmd_doctor(path=str(tmp_path), explain=True)

        output = capsys.readouterr().out
        assert "why:" in output
        assert "fix:" in output

    def test_explain_prints_nonblocking_component_guidance(
        self,
        tmp_path: Path,
        capsys: pytest.CaptureFixture[str],
    ):
        _make_plugin(tmp_path, with_frontend=True)
        view_dir = tmp_path / "frontend" / "src" / "views"
        view_dir.mkdir(parents=True)
        (view_dir / "ManualWorkspace.vue").write_text("""\
<script setup lang="ts">
import { AppSidebar, AppTopBar, FormBuilder } from '@morscherlab/mint-sdk'

const panels = []
const schema = []
</script>

<template>
  <AppTopBar title="Analysis" />
  <AppSidebar :panels="panels" />
  <FormBuilder :schema="schema" />
</template>
""")

        cmd_doctor(path=str(tmp_path), explain=True)

        output = capsys.readouterr().out
        assert "Frontend component guidance" in output
        assert "non-blocking suggestions" in output
        assert "why: These pages appear to hand-wire lower-level SDK pieces" in output
        assert "fix: Run `mint docs frontend choose`" in output

    def test_json_output_on_success(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]):
        _make_plugin(tmp_path)

        cmd_doctor(path=str(tmp_path), json_output=True)

        payload = json.loads(capsys.readouterr().out)
        assert payload["ok"] is True
        assert payload["failed"] == 0
        assert any(check["label"] == "Generated contract" for check in payload["checks"])

    def test_json_output_on_failure(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]):
        with pytest.raises(SystemExit) as exc_info:
            cmd_doctor(path=str(tmp_path), json_output=True)

        payload = json.loads(capsys.readouterr().out)
        assert exc_info.value.code == 1
        assert payload["ok"] is False
        assert payload["failed"] > 0
        assert payload["checks"][0]["label"] == "pyproject.toml"


class TestCLIIntegration:
    def test_doctor_subcommand_registered(self):
        from mint_sdk.cli import app

        result = runner.invoke(app, ["doctor", "--help"])
        assert result.exit_code == 0
