"""Regression tests for issue #130 — mint docs must work without sqlalchemy.

`mint_sdk.migrations` re-exports `MigrationOps`, `MigrationRunner`, etc., and
`mint_sdk.__getattr__` lazy-loads those names. When sqlalchemy is not
installed (it lives in the ``local-db`` / ``dev`` extras), the module imports
themselves must still succeed — otherwise `mint docs`, which iterates
``mint_sdk.__all__``, crashes on a fresh plugin scaffold.
"""

from __future__ import annotations

import builtins
import importlib
import sys

import pytest

# Names that mint_sdk.__getattr__ lazy-loads from the migrations submodule.
# These are written into mint_sdk.__dict__ on first access; the fixture must
# evict them so subsequent tests actually exercise the lazy loader rather
# than returning a cached reference from an earlier test.
_MIGRATION_LAZY_NAMES = (
    "MigrationOps",
    "MigrationResult",
    "MigrationRunner",
    "PluginMigration",
)


def _is_sqlalchemy(name: str) -> bool:
    return name == "sqlalchemy" or name.startswith("sqlalchemy.")


def _is_migration(name: str) -> bool:
    return name.startswith("mint_sdk.migrations")


@pytest.fixture
def sqlalchemy_absent(monkeypatch):
    """Simulate a runtime where sqlalchemy is not installed.

    Evicts cached migration / sqlalchemy modules from ``sys.modules`` *and*
    clears the lazy-load cache that ``mint_sdk.__getattr__`` writes into the
    package namespace, then blocks future ``import sqlalchemy`` attempts.
    """
    import mint_sdk

    cached_attrs = {
        name: mint_sdk.__dict__.pop(name)
        for name in _MIGRATION_LAZY_NAMES
        if name in mint_sdk.__dict__
    }
    migration_mods = {
        name: sys.modules.pop(name)
        for name in list(sys.modules)
        if _is_migration(name)
    }
    sa_mods = {
        name: sys.modules.pop(name)
        for name in list(sys.modules)
        if _is_sqlalchemy(name)
    }

    real_import = builtins.__import__

    def blocked_import(name, *args, **kwargs):
        if _is_sqlalchemy(name):
            raise ModuleNotFoundError(f"No module named '{name}'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", blocked_import)

    try:
        yield
    finally:
        for name in list(sys.modules):
            if _is_migration(name):
                del sys.modules[name]
        sys.modules.update(migration_mods)
        sys.modules.update(sa_mods)
        for name in _MIGRATION_LAZY_NAMES:
            mint_sdk.__dict__.pop(name, None)
        mint_sdk.__dict__.update(cached_attrs)


@pytest.mark.parametrize(
    "module_name",
    [
        "mint_sdk.migrations.errors",
        "mint_sdk.migrations.base",
        "mint_sdk.migrations.ops",
        "mint_sdk.migrations.locking",
        "mint_sdk.migrations.runner",
        "mint_sdk.migrations",
    ],
)
def test_migration_module_imports_without_sqlalchemy(sqlalchemy_absent, module_name):
    """Every migrations submodule must import even when sqlalchemy is absent."""
    module = importlib.import_module(module_name)
    assert module is not None


def test_migration_ops_class_resolvable_without_sqlalchemy(sqlalchemy_absent):
    """MigrationOps class must be reachable via the lazy SDK __getattr__."""
    import mint_sdk

    cls = getattr(mint_sdk, "MigrationOps", None)
    assert cls is not None
    assert cls.__name__ == "MigrationOps"


def test_extract_python_sdk_runs_without_sqlalchemy(sqlalchemy_absent):
    """Documentation extraction must surface migration symbols.

    `mint docs` calls `extract_python_sdk`, which iterates ``mint_sdk.__all__``
    and triggers lazy imports. A regression that silently drops migration
    exports would still produce a non-empty manifest, so this test verifies
    that ``MigrationOps`` specifically reaches the extracted output.
    """
    from mint_sdk.docs.python_extractor import extract_python_sdk

    manifest = extract_python_sdk()
    assert manifest["sdk"] == "python"

    extracted_names = {
        item["name"]
        for items in manifest["categories"].values()
        for item in items
    }
    assert "MigrationOps" in extracted_names
