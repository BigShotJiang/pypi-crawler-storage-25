"""Tests for the mint init command."""

import re
from pathlib import Path
from unittest.mock import patch

import pytest
from mint_sdk.init_command import (
    PLUGIN_TEMPLATES,
    _build_template_context,
    _get_sdk_version,
    cmd_init,
    derive_names,
    render,
    write_files,
)
from typer.testing import CliRunner

runner = CliRunner()

# Rich injects bold ANSI around `--flag` names in help output (even when
# colors are disabled), so plain substring checks fragment across escape
# sequences. Strip ANSI before flag-substring assertions.
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def _plain(text: str) -> str:
    return _ANSI_RE.sub("", text)

DASHBOARD_ICON_PATH = "M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"
ANALYSIS_ICON_PATH = "M4 19h16M7 16V8m5 8V4m5 12v-6"


class TestDeriveNames:
    def test_simple_name(self):
        names = derive_names("Drug Response Analyzer")
        assert names.slug == "drug-response-analyzer"
        assert names.package_name == "mint-plugin-drug-response-analyzer"
        assert names.module_name == "mint_plugin_drug_response_analyzer"
        assert names.class_name == "DrugResponseAnalyzerPlugin"
        assert names.routes_prefix == "/drug-response-analyzer"

    def test_strips_existing_mint_plugin_prefix(self):
        names = derive_names("mint-plugin-my-tool")
        assert names.slug == "my-tool"
        assert names.package_name == "mint-plugin-my-tool"
        assert names.module_name == "mint_plugin_my_tool"
        assert names.class_name == "MyToolPlugin"

    def test_strips_mint_plugin_prefix_case_insensitive(self):
        names = derive_names("MINT-Plugin-Test")
        assert names.slug == "test"
        assert names.package_name == "mint-plugin-test"

    def test_strips_underscore_prefix(self):
        names = derive_names("mint_plugin_something")
        assert names.slug == "something"
        assert names.package_name == "mint-plugin-something"

    def test_single_word(self):
        names = derive_names("Metabolomics")
        assert names.slug == "metabolomics"
        assert names.package_name == "mint-plugin-metabolomics"
        assert names.module_name == "mint_plugin_metabolomics"
        assert names.class_name == "MetabolomicsPlugin"
        assert names.routes_prefix == "/metabolomics"

    def test_preserves_human_name(self):
        names = derive_names("  My Cool Plugin  ")
        assert names.human == "My Cool Plugin"

    def test_special_characters_become_hyphens(self):
        names = derive_names("MS Data Upload & Analyzer (v2)")
        assert names.slug == "ms-data-upload-analyzer-v2"

    def test_hyphenated_input(self):
        names = derive_names("dose-response")
        assert names.slug == "dose-response"
        assert names.class_name == "DoseResponsePlugin"

    def test_rejects_empty_name(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            derive_names("   ")

    def test_rejects_name_without_alphanumeric(self):
        with pytest.raises(ValueError, match="alphanumeric"):
            derive_names("!!!")

    def test_rejects_name_starting_with_digit(self):
        with pytest.raises(ValueError, match="start with a letter"):
            derive_names("123 Analyzer")


class TestRender:
    def test_replaces_placeholders(self):
        template = "Hello __NAME__, version __VERSION__"
        result = render(template, {"NAME": "World", "VERSION": "1.0"})
        assert result == "Hello World, version 1.0"

    def test_no_placeholders_unchanged(self):
        template = "No placeholders here"
        result = render(template, {"FOO": "bar"})
        assert result == "No placeholders here"

    def test_multiple_occurrences(self):
        template = "__X__ and __X__"
        result = render(template, {"X": "val"})
        assert result == "val and val"

    def test_case_insensitive_keys(self):
        """Context keys are uppercased internally."""
        template = "__MYKEY__"
        result = render(template, {"mykey": "value"})
        assert result == "value"


class TestWriteFiles:
    def test_creates_backend_files(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("Test Plugin"),
            {"description": "A test", "type": "analysis", "include_frontend": "false"},
        )
        created = write_files(tmp_path, context, include_frontend=False)

        assert (tmp_path / "pyproject.toml").exists()
        assert (tmp_path / "src" / "mint_plugin_test_plugin" / "__init__.py").exists()
        assert (tmp_path / "src" / "mint_plugin_test_plugin" / "plugin.py").exists()
        assert (tmp_path / "src" / "mint_plugin_test_plugin" / "routers" / "analysis.py").exists()
        assert (tmp_path / "src" / "mint_plugin_test_plugin" / "schemas" / "responses.py").exists()
        assert (tmp_path / "tests" / "test_plugin.py").exists()
        assert (tmp_path / "scripts" / "dev.sh").exists()
        assert (tmp_path / ".github" / "workflows" / "ci.yml").exists()
        assert "frontend/package.json" not in created

        pyproject = (tmp_path / "pyproject.toml").read_text()
        assert "frontend/dist" not in pyproject

        readme = (tmp_path / "README.md").read_text()
        assert "cd frontend" not in readme

    def test_creates_frontend_files(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("Test Plugin"),
            {"description": "A test", "type": "analysis", "include_frontend": "true"},
        )
        created = write_files(tmp_path, context, include_frontend=True)

        assert (tmp_path / "frontend" / "package.json").exists()
        assert (tmp_path / "frontend" / "vite.config.ts").exists()
        assert (tmp_path / "frontend" / "src" / "App.vue").exists()
        assert (tmp_path / "frontend" / "src" / "views" / "DashboardView.vue").exists()
        assert "frontend/package.json" in created
        package_json = (tmp_path / "frontend" / "package.json").read_text()
        assert '"build": "vue-tsc -b && vite build"' in package_json
        assert "VITE_API_PREFIX" not in package_json

        app_vue = (tmp_path / "frontend" / "src" / "App.vue").read_text()
        assert "PluginWorkspaceView" in app_vue
        assert "AppLayout" not in app_vue
        assert "AppTopBar" not in app_vue
        assert ':show-sidebar="false"' in app_vue
        assert "import { pluginPageSelectorItems } from './generated/mint-plugin'" in app_vue
        assert "const pageSelector = pluginPageSelectorItems" in app_vue
        assert "function normalizeNavPath(path: string)" in app_vue
        assert "const path = normalizeNavPath(route.path)" in app_vue
        assert "pageSelector.find(p => p.to === path)" in app_vue
        assert ':page-selector="pageSelector"' in app_vue
        assert ':current-page-selector-id="currentPageSelectorId"' in app_vue
        assert ':pages="pages"' not in app_vue
        assert ':current-page-id="currentPageId"' not in app_vue
        assert f"icon: '{DASHBOARD_ICON_PATH}'" not in app_vue
        assert f"icon: '{ANALYSIS_ICON_PATH}'" not in app_vue
        assert 'description: "A test"' not in app_vue
        assert "useRouter" not in app_vue
        assert "handlePageSelect" not in app_vue
        assert "@page-select" not in app_vue

        pyproject = (tmp_path / "pyproject.toml").read_text()
        assert '"frontend/dist" = "mint_plugin_test_plugin/frontend"' in pyproject

        readme = (tmp_path / "README.md").read_text()
        assert "cd frontend" in readme

        ci = (tmp_path / ".github" / "workflows" / "ci.yml").read_text()
        assert "Verify generated frontend contract" in ci
        assert "uv run mint sdk generate --check" in ci
        assert "steps.frontend.outputs.HAS_FRONTEND == 'true'" in ci
        assert "Run tests, then build .mint bundle" in readme

    def test_creates_claude_md(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Dose response analysis", "type": "analysis", "ai_assistants": "claude"},
        )
        created = write_files(tmp_path, context, include_frontend=False, ai_keys=["claude"])

        assert (tmp_path / "CLAUDE.md").exists()
        assert "CLAUDE.md" in created

        content = (tmp_path / "CLAUDE.md").read_text()
        assert "mint_plugin_my_analyzer" in content
        assert "MyAnalyzerPlugin" in content
        assert "/my-analyzer" in content
        assert "mint docs contract ." in content
        assert "mint docs frontend choose" in content
        assert "mint docs r-bridge" in content
        assert "mint add r-analysis drp-fit --page" in content
        assert "runWithParameters()" in content
        assert "runCurrentWithParameters()" in content
        assert "mint add data-template --list" in content
        assert "mint add data-template-preset wellplate-screen --page" in content
        assert "mint add data-template-preset elisa-assay --page" in content
        assert "mint add data-template-preset western-blot-assay --page" in content
        assert "mint docs template-preset wellplate-screen" in content
        assert "mint docs template plate-map" in content
        assert "mint add data-template plate-map --page" in content
        assert "ControlWorkspaceView" in content
        assert "PluginWorkspaceView" in content
        assert "before hand-wiring `AppLayout`, `AppTopBar`, and" in content
        assert "experiment-shell" in content
        assert "defineControlModel()" in content
        assert "WellPlate + dose design page" in content
        assert "DoseDesignWorkspaceView" in content
        assert "standard" in content
        assert "`WellPlate` + `DoseCalculator` dose-design page" in content
        assert '<ControlWorkspaceView v-model="values" :model="workspaceModel" />' in content
        assert "componentBindingsById" in content
        assert "ComponentBindingRenderer" in content
        assert "defineDoseDesignControlModel()" in content
        assert "defineWellPlateDoseComponentBindings()" in content
        assert "defineControls()` when you only need a flat field schema" in content
        assert "`useControlWorkspace()` only" in content
        assert "manual access to the generated" in content
        assert 'AppSidebar variant="analysis"' in content
        assert "default their sidebars to the MINT analysis chrome" in content
        assert "show-sidebar-when-empty" in content
        assert "BioTemplatePresetWorkspaceView" in content
        assert "BioTemplatePackWorkspaceView" in content
        assert "useBioTemplatePresetWorkspace()" in content
        assert "useBioTemplatePackWorkspace()" in content
        assert "useBioTemplateWorkspace()" in content
        assert "componentBindingsById['plate-map:WellPlate'].props" in content
        assert "componentBindingsById['dose-response:DoseCalculator'].props" in content
        assert "useTemplateCollection()" in content
        assert "protocol-steps" in content
        assert "assay-matrix" in content
        assert "reagent-list" in content
        assert "sample-prep" in content
        assert "instrument-run" in content
        assert "calibration-curve" in content
        assert "qpcr-plate" in content
        assert "molecular-assay" in content
        assert "mint_sdk.templates" in content
        assert "Import public components and composables from `@morscherlab/mint-sdk`" in content
        assert "`@morscherlab/mint-sdk/templates` for template helpers" in content
        assert "AppTopBar experiment chip + save flow" in content
        assert "useAppExperiment()" in content
        assert "ready-to-bind" in content
        assert "`popover` / `selectorModal`" in content
        assert "useCurrentExperiment()` only when you need a lower-level guard" in content
        assert "useExperimentSave()" in content
        assert "loadCurrent()" in content
        assert "saveCurrent()" in content
        assert "Generated clients can infer" in content
        assert "useGeneratedPluginContract()" in content
        assert "endpoint definitions" in content
        assert "current platform experiment" in content
        assert "Dose response analysis" in content
        assert "Claude Code" in content
        assert "__" not in content  # no unresolved placeholders

    def test_creates_agents_md_for_codex(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Test plugin", "type": "analysis", "ai_assistants": "codex"},
        )
        created = write_files(tmp_path, context, include_frontend=False, ai_keys=["codex"])

        assert (tmp_path / "AGENTS.md").exists()
        assert "AGENTS.md" in created
        assert not (tmp_path / "CLAUDE.md").exists()

        content = (tmp_path / "AGENTS.md").read_text()
        assert "Codex" in content
        assert "mint-sdk-plugin" not in content  # no Claude-specific skill line

    def test_creates_cursorrules(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Test plugin", "type": "analysis", "ai_assistants": "cursor"},
        )
        created = write_files(tmp_path, context, include_frontend=False, ai_keys=["cursor"])

        assert (tmp_path / ".cursorrules").exists()
        assert ".cursorrules" in created

    def test_no_ai_file_when_none(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Test plugin", "type": "analysis", "ai_assistants": ""},
        )
        write_files(tmp_path, context, include_frontend=False, ai_keys=[])

        assert not (tmp_path / "CLAUDE.md").exists()
        assert not (tmp_path / "AGENTS.md").exists()
        assert not (tmp_path / ".cursorrules").exists()

    def test_multiselect_creates_primary_and_symlinks(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Test plugin", "type": "analysis", "ai_assistants": "claude,codex,cursor"},
        )
        created = write_files(
            tmp_path,
            context,
            include_frontend=False,
            ai_keys=["claude", "codex", "cursor"],
        )

        # Primary file is real
        assert (tmp_path / "CLAUDE.md").exists()
        assert not (tmp_path / "CLAUDE.md").is_symlink()
        assert "Claude Code" in (tmp_path / "CLAUDE.md").read_text()

        # Others are symlinks pointing to CLAUDE.md
        assert (tmp_path / "AGENTS.md").is_symlink()
        assert (tmp_path / "AGENTS.md").resolve() == (tmp_path / "CLAUDE.md").resolve()

        assert (tmp_path / ".cursorrules").is_symlink()
        assert (tmp_path / ".cursorrules").resolve() == (tmp_path / "CLAUDE.md").resolve()

        # Created list shows symlinks
        assert "AGENTS.md -> CLAUDE.md" in created
        assert ".cursorrules -> CLAUDE.md" in created

    def test_multiselect_without_claude_uses_codex_as_primary(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Test", "type": "analysis", "ai_assistants": "codex,cursor"},
        )
        created = write_files(
            tmp_path,
            context,
            include_frontend=False,
            ai_keys=["codex", "cursor"],
        )

        # Codex is primary (next in priority after claude)
        assert (tmp_path / "AGENTS.md").exists()
        assert not (tmp_path / "AGENTS.md").is_symlink()

        # Cursor is symlink
        assert (tmp_path / ".cursorrules").is_symlink()
        assert ".cursorrules -> AGENTS.md" in created

    def test_pyproject_contains_entry_point(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Desc", "type": "analysis", "include_frontend": "true"},
        )
        write_files(tmp_path, context, include_frontend=False)

        content = (tmp_path / "pyproject.toml").read_text()
        assert "mint_plugin_my_analyzer.plugin:MyAnalyzerPlugin" in content
        assert 'name = "mint-plugin-my-analyzer"' in content
        assert 'fallback_version = "0.1.0"' in content
        assert "frontend/dist" not in content

    def test_plugin_py_contains_class(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Desc", "type": "analysis"},
        )
        write_files(tmp_path, context, include_frontend=False)

        content = (tmp_path / "src" / "mint_plugin_my_analyzer" / "plugin.py").read_text()
        assert "class MyAnalyzerPlugin(AnalysisPlugin):" in content
        assert "def create_standalone_app():" in content
        assert "PluginNavItem," in content
        assert "nav_items=[" in content
        assert "PluginNavItem(" in content
        assert 'path="/",' in content
        assert 'id="dashboard",' in content
        assert 'id="analysis",' in content
        assert f'icon="{DASHBOARD_ICON_PATH}"' in content
        assert f'icon="{ANALYSIS_ICON_PATH}"' in content
        assert '"icon": "home"' not in content
        assert '"icon": "chart"' not in content
        assert "super().get_frontend_config()" in content

    def test_test_plugin_py_contains_route_tests(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Desc", "type": "analysis"},
        )
        write_files(tmp_path, context, include_frontend=False)

        content = (tmp_path / "tests" / "test_plugin.py").read_text()
        assert "from fastapi.testclient import TestClient" in content
        assert 'client.get("/api/my-analyzer/health")' in content
        assert 'client.post("/api/my-analyzer/analyze/42", json=payload)' in content
        assert "test_analyze_route_rejects_invalid_payload" in content

    def test_request_schema_uses_default_factory(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Analyzer"),
            {"description": "Desc", "type": "analysis"},
        )
        write_files(tmp_path, context, include_frontend=False)

        content = (tmp_path / "src" / "mint_plugin_my_analyzer" / "schemas" / "requests.py").read_text()
        assert "Field(default_factory=dict)" in content

    def test_experiment_design_type(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("MS Designer"),
            {"description": "Desc", "type": "experiment-design"},
        )
        write_files(tmp_path, context, include_frontend=False)

        content = (tmp_path / "src" / "mint_plugin_ms_designer" / "plugin.py").read_text()
        assert "PluginType.EXPERIMENT_DESIGN" in content

    def test_vite_config_has_routes_prefix(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Tool"),
            {"description": "Desc", "type": "analysis"},
        )
        write_files(tmp_path, context, include_frontend=True)

        content = (tmp_path / "frontend" / "vite.config.ts").read_text()
        assert "base: '/my-tool/'" in content

    def test_template_metadata_is_rendered(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("Uploader"),
            {
                "description": "Desc",
                "type": "analysis",
                "template": "file-upload-analysis",
            },
        )
        write_files(tmp_path, context, include_frontend=True)

        readme = (tmp_path / "README.md").read_text()
        service = (tmp_path / "src" / "mint_plugin_uploader" / "services" / "analysis_service.py").read_text()
        view = (tmp_path / "frontend" / "src" / "views" / "AnalysisView.vue").read_text()

        assert PLUGIN_TEMPLATES["file-upload-analysis"]["label"] in readme
        assert 'template="file-upload-analysis"' in service
        assert "Use FileUploader" in view

    def test_biology_template_hints_use_data_template_commands(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("Plate Designer"),
            {
                "description": "Desc",
                "type": "experiment-design",
                "template": "plate-map-designer",
            },
        )
        write_files(tmp_path, context, include_frontend=True)

        readme = (tmp_path / "README.md").read_text()
        view = (tmp_path / "frontend" / "src" / "views" / "AnalysisView.vue").read_text()

        assert "mint add data-template plate-map --page" in readme
        assert "PlateMapTemplate" in view

    def test_data_template_pack_template_scaffolds_pack_and_generated_client(self, tmp_path: Path):
        target = tmp_path / "screen-plugin"

        cmd_init(
            directory=str(target),
            name="Screen Plugin",
            description="Cell culture screen",
            plugin_type="analysis",
            template="cell-culture-screen",
            no_frontend=False,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_screen_plugin"
        assert (module_root / "templates" / "sample_sheet.py").exists()
        assert (module_root / "templates" / "sample_prep.py").exists()
        assert (module_root / "templates" / "plate_map.py").exists()
        assert (module_root / "templates" / "reagent_list.py").exists()
        assert (module_root / "templates" / "protocol_steps.py").exists()
        assert (module_root / "templates" / "dose_response.py").exists()
        assert (module_root / "templates" / "flow_cytometry_panel.py").exists()
        assert (target / "frontend" / "src" / "views" / "SamplePrepTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "ProtocolStepsTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "ReagentListTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "FlowCytometryPanelTemplateView.vue").exists()

        client = (target / "frontend" / "src" / "generated" / "mint-plugin.ts").read_text()
        assert "getSamplePrepTemplate" in client
        assert "getProtocolStepsTemplate" in client
        assert "getReagentListTemplate" in client
        assert "getDoseResponseTemplate" in client
        assert "getFlowCytometryPanelTemplate" in client

        readme = (target / "README.md").read_text()
        assert "Cell Culture Screen" in readme
        assert "sample metadata, sample prep, plate layout" in readme

    def test_data_template_pack_template_without_frontend_scaffolds_backend_only(self, tmp_path: Path):
        target = tmp_path / "omics-plugin"

        cmd_init(
            directory=str(target),
            name="Omics Plugin",
            description="Omics assay",
            plugin_type="analysis",
            template="omics-assay",
            no_frontend=True,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_omics_plugin"
        assert (module_root / "templates" / "sample_sheet.py").exists()
        assert (module_root / "templates" / "sample_prep.py").exists()
        assert (module_root / "templates" / "assay_matrix.py").exists()
        assert (module_root / "templates" / "instrument_run.py").exists()
        assert (module_root / "templates" / "calibration_curve.py").exists()
        assert (module_root / "routers" / "protocol_steps_template.py").exists()
        assert (module_root / "routers" / "sample_prep_template.py").exists()
        assert (module_root / "routers" / "instrument_run_template.py").exists()
        assert (module_root / "routers" / "calibration_curve_template.py").exists()
        assert not (target / "frontend").exists()

    def test_data_template_pack_python_scaffold_keeps_imports_short(self, tmp_path: Path):
        target = tmp_path / "template-pack-collection-demo-3"

        cmd_init(
            directory=str(target),
            name="Template Pack Collection Demo 3",
            description="Cell culture screen",
            plugin_type="analysis",
            template="cell-culture-screen",
            no_frontend=True,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_template_pack_collection_demo_3"
        long_lines = [
            f"{path.relative_to(target)}:{line_no}"
            for path in module_root.rglob("*.py")
            for line_no, line in enumerate(path.read_text().splitlines(), start=1)
            if len(line) > 100
        ]
        plugin_content = (module_root / "plugin.py").read_text()

        assert not long_lines
        assert "from mint_plugin_template_pack_collection_demo_3.routers import (\n" in plugin_content
        assert "from mint_plugin_template_pack_collection_demo_3.services import (\n" in plugin_content
        assert "cell_culture_screen_template_pack_service" in plugin_content

    def test_molecular_assay_template_scaffolds_qpcr_plate(self, tmp_path: Path):
        target = tmp_path / "molecular-plugin"

        cmd_init(
            directory=str(target),
            name="Molecular Plugin",
            description="qPCR assay",
            plugin_type="analysis",
            template="molecular-assay",
            no_frontend=False,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_molecular_plugin"
        assert (module_root / "templates" / "sample_prep.py").exists()
        assert (module_root / "templates" / "instrument_run.py").exists()
        assert (module_root / "templates" / "calibration_curve.py").exists()
        assert (module_root / "templates" / "qpcr_plate.py").exists()
        assert (module_root / "routers" / "sample_prep_template.py").exists()
        assert (module_root / "routers" / "instrument_run_template.py").exists()
        assert (module_root / "routers" / "calibration_curve_template.py").exists()
        assert (module_root / "routers" / "qpcr_plate_template.py").exists()
        assert (target / "frontend" / "src" / "views" / "SamplePrepTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "InstrumentRunTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "CalibrationCurveTemplateView.vue").exists()
        assert (target / "frontend" / "src" / "views" / "QpcrPlateTemplateView.vue").exists()

        client = (target / "frontend" / "src" / "generated" / "mint-plugin.ts").read_text()
        assert "getSamplePrepTemplate" in client
        assert "getInstrumentRunTemplate" in client
        assert "getCalibrationCurveTemplate" in client
        assert "getQpcrPlateTemplate" in client

    def test_data_template_preset_template_scaffolds_preset_workspace(self, tmp_path: Path):
        target = tmp_path / "elisa-plugin"

        cmd_init(
            directory=str(target),
            name="ELISA Plugin",
            description="ELISA assay",
            plugin_type="analysis",
            template="elisa-assay",
            no_frontend=False,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_elisa_plugin"
        assert (module_root / "templates" / "elisa_assay_preset.py").exists()
        assert (target / "frontend" / "src" / "composables" / "useElisaAssayTemplatePreset.ts").exists()
        view = target / "frontend" / "src" / "views" / "ElisaAssayTemplatePresetView.vue"
        assert view.exists()
        view_content = view.read_text()
        assert "BioTemplatePresetWorkspaceView" in view_content
        assert 'preset="elisa-assay"' in view_content

        main_ts = (target / "frontend" / "src" / "main.ts").read_text()
        assert "import('./views/ElisaAssayTemplatePresetView.vue')" in main_ts
        assert "/templates/presets/elisa-assay" in main_ts

        readme = (target / "README.md").read_text()
        assert "ELISA Assay" in readme
        assert "ready-to-save ELISA plate" in readme

    def test_r_analysis_template_metadata_exists(self):
        assert "r-analysis" in PLUGIN_TEMPLATES
        assert PLUGIN_TEMPLATES["r-analysis"]["label"] == "R Analysis"
        assert PLUGIN_TEMPLATES["elisa-assay"]["label"] == "ELISA Assay"
        assert PLUGIN_TEMPLATES["flow-cytometry-assay"]["label"] == "Flow Cytometry Assay"
        assert PLUGIN_TEMPLATES["western-blot-assay"]["label"] == "Western Blot Assay"

    def test_frontend_dashboard_uses_generated_client(self, tmp_path: Path):
        context = _build_template_context(
            derive_names("My Tool"),
            {"description": "Desc", "type": "analysis"},
        )
        write_files(tmp_path, context, include_frontend=True)

        content = (tmp_path / "frontend" / "src" / "views" / "DashboardView.vue").read_text()
        assert "useGeneratedPluginClient" in content
        assert "useGeneratedPluginContract" in content
        assert "useRequestSyncState" in content
        assert "const pluginContract = useGeneratedPluginContract()" in content
        assert "contractHashShort" in content
        assert "healthEndpoint" in content
        assert "useApi({ baseUrl" not in content
        assert "VITE_API_PREFIX || '/api" not in content
        assert "useToast" not in content


class TestCmdInit:
    def test_scaffolds_full_project(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]):
        target = tmp_path / "my-plugin"

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "My Plugin",
                "description": "A test plugin",
                "type": "analysis",
                "include_frontend": "true",
                "ai_assistants": "claude",
            }
            cmd_init(
                directory=str(target),
                name="My Plugin",
                description="A test plugin",
                plugin_type="analysis",
                no_frontend=False,
                no_install=True,
                no_git=True,
                force=False,
            )

        assert (target / "pyproject.toml").exists()
        assert (target / "src" / "mint_plugin_my_plugin" / "plugin.py").exists()
        assert (target / "frontend" / "package.json").exists()
        assert (target / "frontend" / "src" / "generated" / "mint-plugin.contract.json").exists()
        assert (target / "frontend" / "src" / "generated" / "mint-plugin.ts").exists()
        assert (target / "CLAUDE.md").exists()
        output = capsys.readouterr().out
        assert "mint sdk generate" in output
        assert "mint docs frontend choose" in output
        assert "mint docs frontend components" in output
        assert "mint docs contract ." in output
        assert "mint add data-template --list" in output
        assert "mint add data-template-pack --list" in output
        assert "mint add data-template-preset --list" in output
        assert "mint docs r-bridge" in output
        assert "mint docs template-preset wellplate-screen" in output
        assert "mint docs template plate-map" in output
        assert "mint docs frontend BioTemplatePresetWorkspaceView" in output
        assert "mint docs frontend BioTemplatePackWorkspaceView" in output
        assert "mint docs frontend useTemplateCollection" in output
        assert "low-level custom template persistence" in output
        assert "localhost:6006" not in output

    def test_no_frontend_flag(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]):
        target = tmp_path / "backend-only"

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "Backend Only",
                "description": "No frontend",
                "type": "analysis",
                "include_frontend": "false",
                "ai_assistants": "claude",
            }
            cmd_init(
                directory=str(target),
                name="Backend Only",
                description="No frontend",
                plugin_type="analysis",
                no_frontend=True,
                no_install=True,
                no_git=True,
                force=False,
            )

        assert (target / "pyproject.toml").exists()
        assert not (target / "frontend").exists()
        assert "mint sdk generate" not in capsys.readouterr().out

    def test_r_analysis_template_scaffolds_bridge_and_generated_client(self, tmp_path: Path):
        target = tmp_path / "r-plugin"

        cmd_init(
            directory=str(target),
            name="R Plugin",
            description="R analysis",
            plugin_type="analysis",
            template="r-analysis",
            no_frontend=False,
            no_install=True,
            no_git=True,
            force=False,
            yes=True,
        )

        module_root = target / "src" / "mint_plugin_r_plugin"
        assert (target / "r-requirements.txt").exists()
        assert (module_root / "r_scripts" / "analysis.R").exists()
        assert (module_root / "routers" / "analysis_r.py").exists()
        assert (target / "frontend" / "src" / "composables" / "useAnalysisRAnalysis.ts").exists()
        assert (target / "frontend" / "src" / "views" / "AnalysisRAnalysisView.vue").exists()
        long_lines = [
            f"{path.relative_to(target)}:{line_no}"
            for path in module_root.rglob("*.py")
            for line_no, line in enumerate(path.read_text().splitlines(), start=1)
            if len(line) > 100
        ]
        schema = (module_root / "schemas" / "analysis_r.py").read_text()
        service = (module_root / "services" / "analysis_r.py").read_text()
        router = (module_root / "routers" / "analysis_r.py").read_text()
        composable = (
            target / "frontend" / "src" / "composables" / "useAnalysisRAnalysis.ts"
        ).read_text()
        view = (target / "frontend" / "src" / "views" / "AnalysisRAnalysisView.vue").read_text()
        main_ts = (target / "frontend" / "src" / "main.ts").read_text()
        app_vue = (target / "frontend" / "src" / "App.vue").read_text()
        plugin_py = (module_root / "plugin.py").read_text()
        contract_json = (
            target / "frontend" / "src" / "generated" / "mint-plugin.contract.json"
        ).read_text()

        client = (target / "frontend" / "src" / "generated" / "mint-plugin.ts").read_text()
        assert not long_lines
        assert "parameters: dict[str, Any]" in schema
        assert "def set_analysis_r_plugin(plugin: AnalysisPlugin) -> None:" in service
        assert "await plugin.save_analysis(experiment_id, response.result)" in router
        assert "parameters = ref<Record<string, unknown>>" in composable
        assert "useRequestSyncState" in composable
        assert "const lastRunAt = computed(() => request.lastRunAt.value)" in composable
        assert "return request.run(" in composable
        assert "{ success: 'run' }" in composable
        assert "runWithParameters" in composable
        assert "runCurrentWithParameters" in composable
        assert "ControlWorkspaceView" in view
        assert "defineControlModel" in view
        assert "const workspaceModel = defineControlModel" in view
        assert "threshold" in view
        assert "normalize" in view
        assert ':model="workspaceModel"' in view
        assert ':controls="controls"' not in view
        assert ':control-options="controlOptions"' not in view
        assert "BaseTextarea" not in view
        assert "Parameters JSON" not in view
        assert "function runCurrentAnalysis(values: Record<string, unknown>)" in view
        assert "return runCurrentWithParameters({ ...values })" in view
        assert "lastRunAt" in view
        assert "Parameters JSON must be an object." not in view
        assert "isParameterRecord" not in view
        assert "R Analysis runs through" in view
        assert "import('./views/AnalysisRAnalysisView.vue')" in main_ts
        assert "pluginPageSelectorItems" in app_vue
        assert "label: 'R Analysis'" not in app_vue
        assert "path='/r/analysis'" in plugin_py
        assert "label='R Analysis'" in plugin_py
        assert "id='r-analysis'" in plugin_py
        assert '"path": "/r/analysis"' in contract_json
        assert '"label": "R Analysis"' in contract_json
        assert '"id": "r-analysis"' in contract_json
        assert "Analysis R Analysis" not in app_vue
        assert "runAnalysis" in client
        assert "AnalysisRRequest" in client
        assert "AnalysisRResponse" in client
        assert "parameters?: Record<string, unknown>" in client

    def test_rejects_non_empty_dir(self, tmp_path: Path):
        target = tmp_path / "existing"
        target.mkdir()
        (target / "some_file.txt").write_text("content")

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "My Plugin",
                "description": "Desc",
                "type": "analysis",
                "include_frontend": "false",
                "ai_assistants": "claude",
            }
            with pytest.raises(SystemExit):
                cmd_init(
                    directory=str(target),
                    name="My Plugin",
                    description="Desc",
                    plugin_type="analysis",
                    no_frontend=True,
                    no_install=True,
                    no_git=True,
                    force=False,
                )

    def test_force_allows_non_empty_dir(self, tmp_path: Path):
        target = tmp_path / "existing"
        target.mkdir()
        (target / "some_file.txt").write_text("content")

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "My Plugin",
                "description": "Desc",
                "type": "analysis",
                "include_frontend": "false",
                "ai_assistants": "claude",
            }
            cmd_init(
                directory=str(target),
                name="My Plugin",
                description="Desc",
                plugin_type="analysis",
                no_frontend=True,
                no_install=True,
                no_git=True,
                force=True,
            )

        assert (target / "pyproject.toml").exists()

    def test_rejects_invalid_plugin_name(self, tmp_path: Path):
        target = tmp_path / "invalid-name"

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "123 Plugin",
                "description": "Desc",
                "type": "analysis",
                "include_frontend": "false",
                "ai_assistants": "claude",
            }
            with pytest.raises(SystemExit):
                cmd_init(
                    directory=str(target),
                    name="123 Plugin",
                    description="Desc",
                    plugin_type="analysis",
                    no_frontend=True,
                    no_install=True,
                    no_git=True,
                    force=False,
                )

    def test_rejects_invalid_plugin_type(self, tmp_path: Path):
        target = tmp_path / "invalid-type"

        with pytest.raises(SystemExit):
            cmd_init(
                directory=str(target),
                name="Invalid Type",
                description="Desc",
                plugin_type="bogus",
                template=None,
                no_frontend=True,
                no_install=True,
                no_git=True,
                force=False,
                yes=True,
            )


class TestCLIIntegration:
    def test_init_subcommand_registered(self):
        """The init subcommand should be registered in the CLI parser."""
        from mint_sdk.cli import app

        result = runner.invoke(app, ["init", "--help"])
        assert result.exit_code == 0
        assert "--template" in _plain(result.output)

    def test_init_via_main(self, tmp_path: Path):
        """Should be callable through the main CLI entry point."""
        from mint_sdk.cli import app

        target = tmp_path / "cli-test"

        with patch("mint_sdk.init_command.prompt_config") as mock_prompt:
            mock_prompt.return_value = {
                "directory": str(target),
                "name": "CLI Test",
                "description": "Test via CLI",
                "type": "analysis",
                "include_frontend": "false",
                "ai_assistants": "claude",
            }
            result = runner.invoke(
                app,
                [
                    "init",
                    str(target),
                    "--name",
                    "CLI Test",
                    "--no-install",
                    "--no-git",
                    "--no-frontend",
                ],
            )
            assert result.exit_code == 0, result.output

        assert (target / "pyproject.toml").exists()


class TestGetSdkVersion:
    def test_returns_version_string(self):
        version = _get_sdk_version()
        assert version
        assert re.match(r"^\d+\.\d+\.\d+(?:(?:a|b|rc)\d+)?(?:\.dev\d+)?$", version)

    def test_uses_release_fallback_for_dev_distribution_metadata(self):
        with (
            patch(
                "mint_sdk.init_command.importlib_metadata.version",
                return_value="1.0.0a9.dev4+g123",
            ),
            patch("mint_sdk.__version__", "1.0.0a9.dev4+g123"),
        ):
            assert _get_sdk_version() == "1.0.0a8"

    def test_preserves_prerelease_version_from_distribution_metadata(self):
        with (
            patch("mint_sdk.init_command.importlib_metadata.version", return_value="1.0.0a8"),
            patch("mint_sdk.__version__", "1.0.0a8"),
        ):
            assert _get_sdk_version() == "1.0.0a8"

    def test_ignores_old_generated_module_version(self):
        with (
            patch("mint_sdk.init_command.importlib_metadata.version", return_value="0.2.8"),
            patch("mint_sdk.__version__", "0.2.8"),
        ):
            assert _get_sdk_version() == "1.0.0a8"
