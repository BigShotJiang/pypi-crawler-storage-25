"""Tests for the R analysis bridge."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest
from mint_sdk.r import RAnalysisBridge, RBridgeError, RScriptSpec, check_r_environment
from pydantic import BaseModel


class AnalyzeRequest(BaseModel):
    value: float


class AnalyzeResponse(BaseModel):
    doubled: float
    experiment_id: int | None = None


def _write_script(path: Path, body: str) -> Path:
    path.write_text(body)
    return path


@pytest.mark.asyncio
async def test_r_bridge_runs_script_and_validates_output(tmp_path: Path) -> None:
    script = _write_script(
        tmp_path / "analysis.py",
        """\
import json
import os
import sys

with open(sys.argv[1]) as f:
    payload = json.load(f)
with open(sys.argv[2], "w") as f:
    json.dump({
        "doubled": payload["value"] * 2,
        "experiment_id": int(os.environ["MINT_EXPERIMENT_ID"]),
    }, f)
""",
    )
    bridge = RAnalysisBridge(
        RScriptSpec(
            script=str(script),
            input_schema=AnalyzeRequest,
            output_schema=AnalyzeResponse,
            executable=sys.executable,
        )
    )

    result = await bridge.run(payload=AnalyzeRequest(value=2.5), experiment_id=42)

    assert result == AnalyzeResponse(doubled=5.0, experiment_id=42)
    assert bridge.last_run is not None
    assert bridge.last_run.exit_code == 0
    assert bridge.last_run.executable == sys.executable


@pytest.mark.asyncio
async def test_r_bridge_raises_on_nonzero_exit(tmp_path: Path) -> None:
    script = _write_script(
        tmp_path / "fail.py",
        """\
import sys
print("bad input", file=sys.stderr)
sys.exit(7)
""",
    )
    bridge = RAnalysisBridge(
        RScriptSpec(
            script=str(script),
            input_schema=AnalyzeRequest,
            output_schema=AnalyzeResponse,
            executable=sys.executable,
        )
    )

    with pytest.raises(RBridgeError) as exc_info:
        await bridge.run(payload={"value": 1})

    assert exc_info.value.code == "R_BRIDGE_ERROR"
    assert exc_info.value.details["exit_code"] == 7
    assert "bad input" in exc_info.value.details["stderr"]


@pytest.mark.asyncio
async def test_r_bridge_validates_output_schema(tmp_path: Path) -> None:
    script = _write_script(
        tmp_path / "invalid.py",
        """\
import json
import sys
with open(sys.argv[2], "w") as f:
    json.dump({"wrong": "shape"}, f)
""",
    )
    bridge = RAnalysisBridge(
        RScriptSpec(
            script=str(script),
            input_schema=AnalyzeRequest,
            output_schema=AnalyzeResponse,
            executable=sys.executable,
        )
    )

    with pytest.raises(RBridgeError) as exc_info:
        await bridge.run(payload={"value": 1})

    assert "schema validation" in exc_info.value.message


@pytest.mark.asyncio
async def test_r_bridge_exposes_artifact_dir(tmp_path: Path) -> None:
    script = _write_script(
        tmp_path / "artifact.py",
        """\
import json
import os
import pathlib
import sys

artifact_dir = pathlib.Path(os.environ["MINT_R_ARTIFACT_DIR"])
artifact_path = artifact_dir / "result.txt"
artifact_path.write_text("artifact")
with open(sys.argv[2], "w") as f:
    json.dump({"doubled": 2, "experiment_id": None}, f)
""",
    )
    artifact_dir = tmp_path / "artifacts"
    bridge = RAnalysisBridge(
        RScriptSpec(
            script=str(script),
            input_schema=AnalyzeRequest,
            output_schema=AnalyzeResponse,
            executable=sys.executable,
            artifact_dir=str(artifact_dir),
        )
    )

    await bridge.run(payload={"value": 1})

    assert (artifact_dir / "result.txt").read_text() == "artifact"
    assert bridge.last_run is not None
    assert bridge.last_run.extra["artifact_dir"] == str(artifact_dir)


def test_check_r_environment_reports_executable_and_dependency_file(tmp_path: Path) -> None:
    (tmp_path / "renv.lock").write_text("{}")

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    assert checks[0]["ok"] is True
    assert checks[0]["detail"] == sys.executable
    assert checks[1]["ok"] is True
    assert checks[1]["detail"] == "renv.lock found"
    jsonlite_check = [check for check in checks if check["label"] == "R jsonlite package"][0]
    assert jsonlite_check["ok"] is True
    assert jsonlite_check["detail"] == "no R scripts found"
    helper_check = [check for check in checks if check["label"] == "R bridge helper"][0]
    assert helper_check["ok"] is True
    assert helper_check["detail"] == "no R scripts found"


def test_check_r_environment_reports_missing_bridge_helper_for_r_scripts(tmp_path: Path) -> None:
    script_dir = tmp_path / "src" / "mint_plugin_test" / "r_scripts"
    script_dir.mkdir(parents=True)
    (script_dir / "analysis.R").write_text("print('analysis')\n")
    (tmp_path / "r-requirements.txt").write_text("jsonlite\n")

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    helper_check = [check for check in checks if check["label"] == "R bridge helper"][0]
    assert helper_check["ok"] is False
    assert helper_check["detail"] == "1 R script(s), mint_bridge.R missing"
    assert "mint add r-analysis" in helper_check["fix"]
    jsonlite_check = [check for check in checks if check["label"] == "R jsonlite package"][0]
    assert jsonlite_check["ok"] is True
    assert jsonlite_check["detail"] == "jsonlite declared"


def test_check_r_environment_accepts_bridge_helper_for_r_scripts(tmp_path: Path) -> None:
    script_dir = tmp_path / "src" / "mint_plugin_test" / "r_scripts"
    script_dir.mkdir(parents=True)
    (script_dir / "analysis.R").write_text("print('analysis')\n")
    (script_dir / "mint_bridge.R").write_text("mint_read_input <- function() {}\n")
    (tmp_path / "r-requirements.txt").write_text("jsonlite\n")

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    helper_check = [check for check in checks if check["label"] == "R bridge helper"][0]
    assert helper_check["ok"] is True
    assert helper_check["detail"] == "src/mint_plugin_test/r_scripts/mint_bridge.R found"


def test_check_r_environment_reports_missing_jsonlite_for_r_scripts(tmp_path: Path) -> None:
    script_dir = tmp_path / "src" / "mint_plugin_test" / "r_scripts"
    script_dir.mkdir(parents=True)
    (script_dir / "analysis.R").write_text("source('mint_bridge.R')\n")
    (script_dir / "mint_bridge.R").write_text("mint_read_input <- function() {}\n")
    (tmp_path / "r-requirements.txt").write_text("dplyr\n")

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    jsonlite_check = [check for check in checks if check["label"] == "R jsonlite package"][0]
    assert jsonlite_check["ok"] is False
    assert jsonlite_check["detail"] == "jsonlite not declared"
    assert "mint_bridge.R requires it" in jsonlite_check["fix"]


def test_check_r_environment_accepts_jsonlite_from_renv_lock(tmp_path: Path) -> None:
    script_dir = tmp_path / "src" / "mint_plugin_test" / "r_scripts"
    script_dir.mkdir(parents=True)
    (script_dir / "analysis.R").write_text("source('mint_bridge.R')\n")
    (script_dir / "mint_bridge.R").write_text("mint_read_input <- function() {}\n")
    (tmp_path / "renv.lock").write_text('{"Packages": {"jsonlite": {"Package": "jsonlite"}}}')

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    jsonlite_check = [check for check in checks if check["label"] == "R jsonlite package"][0]
    assert jsonlite_check["ok"] is True
    assert jsonlite_check["detail"] == "jsonlite declared"


def test_check_r_environment_accepts_versioned_jsonlite_requirement(tmp_path: Path) -> None:
    script_dir = tmp_path / "src" / "mint_plugin_test" / "r_scripts"
    script_dir.mkdir(parents=True)
    (script_dir / "analysis.R").write_text("source('mint_bridge.R')\n")
    (script_dir / "mint_bridge.R").write_text("mint_read_input <- function() {}\n")
    (tmp_path / "r-requirements.txt").write_text("jsonlite>=1.8\n")

    checks = check_r_environment(executable=sys.executable, project_dir=tmp_path)

    jsonlite_check = [check for check in checks if check["label"] == "R jsonlite package"][0]
    assert jsonlite_check["ok"] is True
    assert jsonlite_check["detail"] == "jsonlite declared"
