from datetime import UTC, datetime

from mint_sdk import (
    InstrumentState,
    InstrumentStatus,
    SampleInfo,
    SequenceProgress,
    build_sequence_progress,
)


def test_sequence_progress_estimates_remaining_and_finish_time() -> None:
    now = datetime(2026, 5, 15, 12, 0, tzinfo=UTC)

    progress = build_sequence_progress(
        current_sample=3,
        total_samples=6,
        elapsed_seconds=180,
        sample_durations=[50, 70, 60],
        current_sample_name="QC 01",
        current_method="targeted-metabolomics.meth",
        now=now,
    )

    assert progress.percent_complete == 50.0
    assert progress.samples_remaining == 3
    assert progress.avg_sample_seconds == 60.0
    assert progress.estimated_remaining_seconds == 180.0
    assert progress.estimated_finish_time == datetime(2026, 5, 15, 12, 3, tzinfo=UTC)
    assert progress.current_sample_name == "QC 01"
    assert progress.current_method == "targeted-metabolomics.meth"


def test_sequence_progress_falls_back_to_elapsed_average() -> None:
    progress = SequenceProgress(
        current_sample=2,
        total_samples=5,
        elapsed_seconds=120,
    )

    assert progress.estimate_remaining_seconds() == 180
    assert progress.with_estimates(now=datetime(2026, 5, 15, 12, 0, tzinfo=UTC)).model_dump(
        mode="json"
    )["estimated_remaining_seconds"] == 180.0


def test_build_sequence_progress_accepts_naive_started_at() -> None:
    progress = build_sequence_progress(
        current_sample=1,
        total_samples=3,
        started_at=datetime(2026, 5, 15, 12, 0),
        now=datetime(2026, 5, 15, 12, 2, tzinfo=UTC),
    )

    assert progress.elapsed_seconds == 120.0
    assert progress.avg_sample_seconds == 120.0


def test_instrument_status_uses_shared_sample_and_progress_payloads() -> None:
    status = InstrumentStatus(
        instrument_id="orbitrap-01",
        state=InstrumentState.RUNNING,
        active_method="neg-pos-switching",
        current_sample=SampleInfo(
            file_name="sample_003.raw",
            sample_id="S003",
            sample_name="Sample 003",
            vial_position="A3",
        ),
        sequence_progress=SequenceProgress(current_sample=3, total_samples=10),
    )

    payload = status.model_dump(mode="json")

    assert status.connected is True
    assert payload["state"] == "running"
    assert payload["current_sample"]["vial_position"] == "A3"
    assert payload["sequence_progress"]["current_sample"] == 3


def test_disconnected_status_reports_not_connected() -> None:
    status = InstrumentStatus(instrument_id="ms-01", state="disconnected")

    assert status.connected is False
