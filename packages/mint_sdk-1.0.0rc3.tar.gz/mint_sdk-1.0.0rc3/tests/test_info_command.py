"""Tests for ``mint info`` command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest import mock

import pytest
from mint_sdk._discover import DiscoveredPlugin
from mint_sdk.info_command import _format_info, _supports_color, cmd_info


@pytest.fixture
def plugin_project(tmp_path: Path) -> Path:
    """Create a minimal plugin project with pyproject.toml and source stub."""
    project = tmp_path / "mint-plugin-test"
    project.mkdir()
    (project / "pyproject.toml").write_text(
        """\
[project]
name = "mint-plugin-test"
version = "1.0.0"
description = "A test plugin"
dependencies = ["mint-sdk>=0.9.0"]

[project.entry-points."mint.plugins"]
test-analysis = "mint_plugin_test.plugin:TestAnalysisPlugin"
"""
    )
    src = project / "src" / "mint_plugin_test"
    src.mkdir(parents=True)
    (src / "plugin.py").write_text('PLUGIN_ROUTES_PREFIX = "/test"\n')
    return project


class TestFormatInfo:
    def _make_plugin(self, **overrides: object) -> DiscoveredPlugin:
        defaults = dict(
            entry_point_name="drp-analysis",
            module_path="mint_plugin_drp.plugin",
            class_name="DRPAnalysisPlugin",
            factory_target="mint_plugin_drp.plugin:create_standalone_app",
            routes_prefix="/drp",
            project_name="mint-plugin-drp",
            project_version="0.2.0",
            project_description="Analyzes dose-response curves",
            has_frontend=True,
        )
        defaults.update(overrides)
        return DiscoveredPlugin(**defaults)  # type: ignore[arg-type]

    def test_contains_all_fields(self) -> None:
        plugin = self._make_plugin()
        output = _format_info(plugin, ">=0.9.4", color=False)

        assert "mint-plugin-drp v0.2.0" in output
        assert "Analyzes dose-response curves" in output
        assert "analysis" in output
        assert "mint_plugin_drp.plugin:DRPAnalysisPlugin" in output
        assert "/drp" in output
        assert ">=0.9.4" in output
        assert "yes" in output

    def test_missing_version(self) -> None:
        plugin = self._make_plugin(project_version=None)
        output = _format_info(plugin, None, color=False)

        assert "mint-plugin-drp" in output
        assert " v" not in output
        assert "(not specified)" in output

    def test_missing_description(self) -> None:
        plugin = self._make_plugin(project_description="")
        output = _format_info(plugin, ">=0.9.0", color=False)

        assert "(no description)" in output

    def test_experiment_design_type(self) -> None:
        plugin = self._make_plugin(class_name="MSExperimentDesignPlugin")
        output = _format_info(plugin, None, color=False)

        assert "experiment-design" in output

    def test_color_bold_header(self) -> None:
        plugin = self._make_plugin()
        output = _format_info(plugin, None, color=True)

        assert "\033[1m" in output
        assert "\033[0m" in output

    def test_no_color_no_ansi(self) -> None:
        plugin = self._make_plugin()
        output = _format_info(plugin, None, color=False)

        assert "\033[" not in output

    def test_frontend_no(self) -> None:
        plugin = self._make_plugin(has_frontend=False)
        output = _format_info(plugin, None, color=False)

        # "Frontend" row should say "no"
        for line in output.splitlines():
            if "Frontend" in line:
                assert "no" in line
                break
        else:
            pytest.fail("No Frontend line found")


class TestSupportsColor:
    def test_no_color_env(self) -> None:
        with mock.patch.dict("os.environ", {"NO_COLOR": "1"}):
            assert _supports_color() is False

    def test_no_color_env_empty(self) -> None:
        """NO_COLOR with any value (even empty string) disables color per spec."""
        with mock.patch.dict("os.environ", {"NO_COLOR": ""}):
            # Empty string is falsy, so _supports_color checks `os.environ.get("NO_COLOR")`
            # which returns "" — a falsy value, so color is NOT disabled.
            # This is consistent with the implementation checking truthiness.
            result = _supports_color()
            # Empty string is falsy, so color is allowed
            assert result is True or result is False  # depends on tty

    def test_dumb_terminal(self) -> None:
        with mock.patch.dict("os.environ", {"TERM": "dumb"}, clear=False):
            with mock.patch("sys.stdout") as mock_stdout:
                mock_stdout.isatty.return_value = True
                assert _supports_color() is False

    def test_not_a_tty(self) -> None:
        with mock.patch.dict("os.environ", {}, clear=False), mock.patch("sys.stdout") as mock_stdout:
            mock_stdout.isatty.return_value = False
            assert _supports_color() is False

    def test_tty_with_color_support(self) -> None:
        env = {k: v for k, v in {"TERM": "xterm-256color"}.items()}
        with mock.patch.dict("os.environ", env, clear=True), mock.patch("sys.stdout") as mock_stdout:
            mock_stdout.isatty.return_value = True
            assert _supports_color() is True


class TestCmdInfo:
    def test_plain_output(self, plugin_project: Path, capsys: pytest.CaptureFixture[str]) -> None:
        cmd_info(path=str(plugin_project), json_output=False)

        captured = capsys.readouterr()
        assert "mint-plugin-test v1.0.0" in captured.out
        assert "A test plugin" in captured.out
        assert "analysis" in captured.out
        assert "/test" in captured.out
        assert ">=0.9.0" in captured.out

    def test_json_output(self, plugin_project: Path, capsys: pytest.CaptureFixture[str]) -> None:
        cmd_info(path=str(plugin_project), json_output=True)

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["name"] == "mint-plugin-test"
        assert data["version"] == "1.0.0"
        assert data["description"] == "A test plugin"
        assert data["entry_point_name"] == "test-analysis"
        assert data["module_path"] == "mint_plugin_test.plugin"
        assert data["class_name"] == "TestAnalysisPlugin"
        assert data["routes_prefix"] == "/test"
        assert data["has_frontend"] is False
        assert data["sdk_requires"] == ">=0.9.0"
