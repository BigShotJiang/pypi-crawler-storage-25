# Fastix

Production-ready FastAPI project scaffolding for teams that want a usable starting point instead of an empty repo.

<p align="center">
  <img src="https://img.shields.io/pypi/v/fastix?label=PyPI" alt="PyPI version">
  <img src="https://img.shields.io/pypi/pyversions/fastix" alt="Supported Python versions">
  <img src="https://img.shields.io/github/actions/workflow/status/developerparesh7205-code/fastix/compatibility.yml?label=CI" alt="CI status">
  <img src="https://img.shields.io/github/license/developerparesh7205-code/fastix" alt="License">
</p>

## What Fastix Does

Fastix is a CLI package that generates FastAPI projects with opinionated defaults for application structure, local development, testing, deployment, and common platform integrations.

It is designed for two workflows:

- Bootstrap a new FastAPI codebase quickly.
- Evolve an existing Fastix-generated project with additional modules later.

## Core Capabilities

- Scaffold monolith and microservices layouts.
- Generate optional Docker or Podman assets.
- Add PostgreSQL, MySQL, or MongoDB support.
- Add Redis, Kafka, or RabbitMQ messaging integrations.
- Add Celery or RQ workers, plus Celery Beat or Kubernetes CronJob scheduling.
- Generate Helm, Kustomize, or raw Kubernetes manifests.
- Include logging, testing, editor tooling, and task runner templates.
- Inspect project state and add supported modules incrementally after generation.

## Installation

```bash
pip install fastix
```

For the interactive prompt flow:

```bash
pip install "fastix[interactive]"
```

## Quick Start

Create a project interactively:

```bash
fastix init
```

Create a project non-interactively:

```bash
fastix init my_api \
  --arch monolith \
  --db postgres \
  --queue redis \
  --worker celery \
  --container docker \
  --k8s helm \
  --logging api_logger \
  --cicd gitlab_ci
```

Create a microservices workspace:

```bash
fastix init platform_api \
  --arch microservices \
  --services gateway,users,orders \
  --protocol grpc \
  --db postgres \
  --queue redis \
  --worker celery \
  --container docker \
  --k8s kustomize \
  --dapr
```

## CLI Commands

### `fastix init`

Generates a new project from the selected architecture and module set.

Examples:

```bash
fastix init billing_api --db postgres --container docker
fastix init --arch microservices
```

### `fastix inspect`

Shows the manifest and active modules for an existing Fastix project.

```bash
fastix inspect .
```

### `fastix add-module`

Adds or switches a supported incremental module in an existing project.

```bash
fastix add-module dapr --path .
fastix add-module container.podman --path .
fastix add-module orchestration.helm --path .
```

### `fastix list-modules`

Lists modules that can be safely added to an existing generated project.

```bash
fastix list-modules
```

### `fastix info`

Prints the current supported architectures, transports, and tooling options.

```bash
fastix info
```

## Supported Options

### Architectures

- `monolith`
- `microservices`

### Databases

- `postgres`
- `mysql`
- `mongodb`
- `none`

### Messaging

- `redis`
- `kafka`
- `rabbitmq`
- `none`

### Workers and Schedulers

- Workers: `celery`, `rq`, `none`
- Schedulers: `celery_beat`, `cronjob`, `none`

### Containers and Orchestration

- Containers: `docker`, `podman`, `none`
- Orchestration: `helm`, `kustomize`, `raw_manifests`, `none`

### Developer Tooling

- Logging: `api_logger`, `none`
- Scripting: `makefile`, `justfile`, `taskfile`, `none`
- CI/CD option in config: `github_actions`, `gitlab_ci`, `none`

## Generated Project Characteristics

Fastix-generated projects can include:

- versioned API routing
- environment-based configuration
- health endpoints
- response and error helper scaffolding
- testing templates
- container and deployment assets
- messaging and background job scaffolding
- optional README and editor config files

The exact output depends on the CLI flags and architecture selected at generation time.

## Local Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev,interactive]'
pytest -q
```

Build the package locally:

```bash
python -m build
python -m twine check dist/*
```

## Repository Automation

This repository is set up to support GitHub-based packaging and release automation.

Recommended repository secrets:

- `PYPI_API_TOKEN`: PyPI token used for package publishing

Recommended release flow:

1. Update version metadata in [pyproject.toml](pyproject.toml) and [src/fastix/__init__.py](src/fastix/__init__.py).
2. Update [CHANGELOG.md](CHANGELOG.md).
3. Push a version tag such as `v0.2.1`.
4. Let GitHub Actions build, validate, and publish the package.

## Contributing

Contributors should keep changes aligned with the current module registry and CLI surface.

Typical extension points:

- Add or update templates under [src/fastix/templates](src/fastix/templates).
- Register new modules in [src/fastix/modules/register.py](src/fastix/modules/register.py).
- Extend CLI options in [src/fastix/cli/main.py](src/fastix/cli/main.py).
- Add or update tests under [tests](tests).

Before opening a PR:

- run `pytest -q`
- run `python -m build`
- verify generated output for the feature you changed

## License

MIT. See [LICENSE](LICENSE).
