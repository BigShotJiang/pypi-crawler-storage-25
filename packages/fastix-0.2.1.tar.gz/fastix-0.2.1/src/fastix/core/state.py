"""Project manifest and incremental update helpers."""

from __future__ import annotations

import json
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - exercised on Python 3.10
    import tomli as tomllib

from pydantic import BaseModel

from fastix import __version__
from fastix.core.config import CICDProvider, Container, Orchestration, ProjectConfig, ScriptingTool

MANIFEST_DIRNAME = ".fastix"
MANIFEST_FILENAME = "project.toml"
MANIFEST_PATH = Path(MANIFEST_DIRNAME) / MANIFEST_FILENAME


class ProjectManifest(BaseModel):
    """Persisted metadata for a generated Fastix project."""

    schema_version: int = 2
    fastix_version: str = __version__
    config: ProjectConfig
    active_modules: list[str]


SUPPORTED_INCREMENTAL_MODULES: dict[str, str] = {
    "dapr": "Enable Dapr manifests and config for a microservices project",
    "devtools.editor": "Add .editorconfig",
    "container.docker": "Add or switch to Docker container files",
    "container.podman": "Add or switch to Podman container files",
    "orchestration.helm": "Add or switch to Helm deployment manifests",
    "orchestration.kustomize": "Add or switch to Kustomize manifests",
    "orchestration.raw_manifests": "Add or switch to raw Kubernetes manifests",
    "scripting.makefile": "Add or switch to a Makefile task runner",
    "scripting.justfile": "Add or switch to a Justfile task runner",
    "scripting.taskfile": "Add or switch to a Taskfile task runner",
    "cicd.github_actions": "Add or switch to a GitHub Actions workflow",
    "cicd.gitlab_ci": "Add or switch to a GitLab CI configuration",
}

REPLACEABLE_MODULE_GROUPS: tuple[set[str], ...] = (
    {"container.docker", "container.podman"},
    {"orchestration.helm", "orchestration.kustomize", "orchestration.raw_manifests"},
    {"scripting.makefile", "scripting.justfile", "scripting.taskfile"},
    {"cicd.github_actions", "cicd.gitlab_ci"},
)


def find_project_root(start: Path) -> Path:
    """Find the nearest Fastix project root by walking upward."""
    current = start.resolve()
    if current.is_file():
        current = current.parent

    for candidate in (current, *current.parents):
        if (candidate / MANIFEST_PATH).exists():
            return candidate

    raise FileNotFoundError(
        "Could not find a Fastix project manifest. "
        "Run this command inside a Fastix-generated project."
    )


def load_manifest(project_root: Path) -> ProjectManifest:
    """Load a Fastix project manifest from disk."""
    manifest_file = project_root / MANIFEST_PATH
    with manifest_file.open("rb") as handle:
        data = tomllib.load(handle)

    return ProjectManifest(
        schema_version=data.get("schema_version", 1),
        fastix_version=data.get("fastix_version", __version__),
        config=ProjectConfig(**data["config"]),
        active_modules=data.get("modules", {}).get("active", []),
    )


def save_manifest(project_root: Path, manifest: ProjectManifest) -> Path:
    """Write the Fastix project manifest to disk."""
    manifest_dir = project_root / MANIFEST_DIRNAME
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest_file = manifest_dir / MANIFEST_FILENAME

    config = manifest.config.model_dump(mode="json")
    lines = [
        f"schema_version = {manifest.schema_version}",
        f"fastix_version = {json.dumps(manifest.fastix_version)}",
        "",
        "[config]",
    ]

    for key, value in config.items():
        lines.append(f"{key} = {json.dumps(value)}")

    lines.extend([
        "",
        "[modules]",
        f"active = {json.dumps(sorted(manifest.active_modules))}",
        "",
    ])

    manifest_file.write_text("\n".join(lines), encoding="utf-8")
    return manifest_file


def apply_incremental_module(config: ProjectConfig, module_name: str) -> ProjectConfig:
    """Return an updated config after enabling a supported module."""
    if module_name not in SUPPORTED_INCREMENTAL_MODULES:
        raise ValueError(
            f"Unsupported incremental module '{module_name}'. "
            "Use 'fastix list-modules' to see supported values."
        )

    updated = config.model_copy(deep=True)

    if module_name == "dapr":
        updated.dapr = True
    elif module_name == "devtools.editor":
        updated.editor_config = True
    elif module_name == "container.docker":
        updated.container = Container.DOCKER
    elif module_name == "container.podman":
        updated.container = Container.PODMAN
    elif module_name == "orchestration.helm":
        updated.orchestration = Orchestration.HELM
    elif module_name == "orchestration.kustomize":
        updated.orchestration = Orchestration.KUSTOMIZE
    elif module_name == "orchestration.raw_manifests":
        updated.orchestration = Orchestration.RAW_MANIFESTS
    elif module_name == "scripting.makefile":
        updated.scripting = ScriptingTool.MAKEFILE
    elif module_name == "scripting.justfile":
        updated.scripting = ScriptingTool.JUSTFILE
    elif module_name == "scripting.taskfile":
        updated.scripting = ScriptingTool.TASKFILE
    elif module_name == "cicd.github_actions":
        updated.cicd = CICDProvider.GITHUB_ACTIONS
    elif module_name == "cicd.gitlab_ci":
        updated.cicd = CICDProvider.GITLAB_CI

    return ProjectConfig(**updated.model_dump())


def get_replaced_modules(previous_modules: list[str], next_module: str) -> list[str]:
    """Return active modules that should be replaced by the incoming module."""
    for group in REPLACEABLE_MODULE_GROUPS:
        if next_module in group:
            return sorted(
                module_name
                for module_name in previous_modules
                if module_name in group and module_name != next_module
            )
    return []
