"""Template engine and project generator."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from jinja2 import Environment, FileSystemLoader, select_autoescape
from rich.console import Console
from rich.tree import Tree

from fastix.core.config import ProjectConfig
from fastix.core.registry import ModuleRegistry
from fastix.core.state import ProjectManifest, save_manifest

console = Console()

TEMPLATES_DIR = Path(__file__).parent.parent / "templates"
SERVICE_APP_MODULE_PREFIXES = ("messaging.", "worker.", "scheduler.celery_beat", "logging.")
SERVICE_TEST_MODULE_PREFIXES = ("testing.",)


class ProjectGenerator:
    """Generates a Fastix project from config and templates."""

    def __init__(
        self,
        config: ProjectConfig,
        output_dir: Path,
        project_dir: Path | None = None,
    ) -> None:
        self.config = config
        self.output_dir = project_dir or output_dir / config.project_name
        self._rendered_files: list[Path] = []
        self._string_env = Environment()

    @classmethod
    def for_existing_project(cls, config: ProjectConfig, project_dir: Path) -> "ProjectGenerator":
        return cls(config=config, output_dir=project_dir.parent, project_dir=project_dir)

    def generate(self) -> Path:
        console.print(
            f"\n[bold green]Generating[/] [cyan]{self.config.project_name}[/] "
            f"({self.config.architecture.value})...\n"
        )

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._render_base_templates()

        active_modules = ModuleRegistry.get_active_modules(self.config)
        for module in active_modules:
            self._render_module(module)

        self.write_manifest(active_modules)
        self._print_tree()

        console.print(
            f"\n[bold green]Done![/] Project created at: "
            f"[cyan]{self.output_dir}[/]\n"
        )
        return self.output_dir

    def apply_modules(self, module_names: list[str]) -> list[Path]:
        rendered_before = len(self._rendered_files)
        active_modules = {module.name: module for module in ModuleRegistry.get_active_modules(self.config)}

        for module_name in module_names:
            module = active_modules.get(module_name)
            if module is None:
                continue
            self._render_module(module)

        self.write_manifest(list(active_modules.values()))
        return self._rendered_files[rendered_before:]

    def collect_module_files(self, module_names: list[str]) -> dict[Path, str]:
        """Render module output to memory for diffing or cleanup decisions."""
        planned: dict[Path, str] = {}
        active_modules = {module.name: module for module in ModuleRegistry.get_active_modules(self.config)}
        for module_name in module_names:
            module = active_modules.get(module_name)
            if module is None:
                continue
            self._collect_module(module, planned)
        return planned

    def remove_files(self, paths: list[Path]) -> list[Path]:
        """Delete generated files and prune empty directories."""
        removed: list[Path] = []
        for path in paths:
            if not path.exists() or not path.is_file():
                continue
            path.unlink()
            removed.append(path)
            self._cleanup_empty_parents(path.parent)
        return removed

    def write_manifest(self, active_modules: list["Module"]) -> Path:  # noqa: F821
        manifest = ProjectManifest(
            config=self.config,
            active_modules=[module.name for module in active_modules],
        )
        return save_manifest(self.output_dir, manifest)

    def _cleanup_empty_parents(self, start_dir: Path) -> None:
        stop = self.output_dir.resolve()
        current = start_dir.resolve()
        while current != stop and current.is_dir():
            try:
                current.rmdir()
            except OSError:
                break
            current = current.parent

    def _render_base_templates(self) -> None:
        template_dir = TEMPLATES_DIR / self.config.architecture.value
        if not template_dir.exists():
            console.print(f"[yellow]Warning:[/] No templates found for {self.config.architecture.value} architecture.")
            return

        self._render_directory(template_dir, self.output_dir)

        if self.config.is_microservices:
            service_template_dir = template_dir / "_service_template"
            if service_template_dir.exists():
                for service_name in self.config.services:
                    service_target = self.output_dir / "services" / service_name
                    self._render_directory(
                        service_template_dir,
                        service_target,
                        extra_context={"service_name": service_name},
                        skip_underscore=False,
                    )

    def _render_module(self, module: "Module") -> None:  # noqa: F821
        if not module.template_dir.exists():
            return

        if self.config.is_microservices and module.name in {"container.docker", "container.podman"}:
            self._render_microservice_container_module(module)
            return

        if self.config.is_microservices and module.name.startswith(SERVICE_APP_MODULE_PREFIXES):
            for service_name in self.config.services:
                self._render_directory(
                    module.template_dir,
                    self.output_dir / "services" / service_name,
                    extra_context={"service_name": service_name},
                )
            return

        if self.config.is_microservices and module.name.startswith(SERVICE_TEST_MODULE_PREFIXES):
            for service_name in self.config.services:
                self._render_directory(
                    module.template_dir,
                    self.output_dir / "services" / service_name,
                    extra_context={"service_name": service_name},
                )
            return

        extra_context = module.context_builder(self.config) if module.context_builder else {}
        target_dir = self._module_target_dir(module.name)
        self._render_directory(module.template_dir, target_dir, extra_context=extra_context)

    def _collect_module(self, module: "Module", planned: dict[Path, str]) -> None:  # noqa: F821
        if not module.template_dir.exists():
            return

        if self.config.is_microservices and module.name in {"container.docker", "container.podman"}:
            self._collect_microservice_container_module(module, planned)
            return

        if self.config.is_microservices and module.name.startswith(SERVICE_APP_MODULE_PREFIXES):
            for service_name in self.config.services:
                self._collect_directory(
                    module.template_dir,
                    self.output_dir / "services" / service_name,
                    planned,
                    extra_context={"service_name": service_name},
                )
            return

        if self.config.is_microservices and module.name.startswith(SERVICE_TEST_MODULE_PREFIXES):
            for service_name in self.config.services:
                self._collect_directory(
                    module.template_dir,
                    self.output_dir / "services" / service_name,
                    planned,
                    extra_context={"service_name": service_name},
                )
            return

        extra_context = module.context_builder(self.config) if module.context_builder else {}
        target_dir = self._module_target_dir(module.name)
        self._collect_directory(module.template_dir, target_dir, planned, extra_context=extra_context)

    def _render_microservice_container_module(self, module: "Module") -> None:  # noqa: F821
        extra_context = module.context_builder(self.config) if module.context_builder else {}
        service_container_files = {"Dockerfile.j2", "Containerfile.j2"}

        self._render_directory(
            module.template_dir,
            self.output_dir,
            extra_context=extra_context,
            include_filter=lambda rel_path: rel_path.name not in service_container_files,
        )
        for service_name in self.config.services:
            self._render_directory(
                module.template_dir,
                self.output_dir / "services" / service_name,
                extra_context={**extra_context, "service_name": service_name},
                include_filter=lambda rel_path: rel_path.name in service_container_files,
            )

    def _collect_microservice_container_module(self, module: "Module", planned: dict[Path, str]) -> None:  # noqa: F821
        extra_context = module.context_builder(self.config) if module.context_builder else {}
        service_container_files = {"Dockerfile.j2", "Containerfile.j2"}

        self._collect_directory(
            module.template_dir,
            self.output_dir,
            planned,
            extra_context=extra_context,
            include_filter=lambda rel_path: rel_path.name not in service_container_files,
        )
        for service_name in self.config.services:
            self._collect_directory(
                module.template_dir,
                self.output_dir / "services" / service_name,
                planned,
                extra_context={**extra_context, "service_name": service_name},
                include_filter=lambda rel_path: rel_path.name in service_container_files,
            )

    def _module_target_dir(self, module_name: str) -> Path:
        if module_name == "dapr" or module_name.startswith("orchestration.") or module_name.startswith("scheduler.cronjob"):
            return self.output_dir / "infra"
        return self.output_dir

    def _render_directory(
        self,
        template_dir: Path,
        target_dir: Path,
        extra_context: dict | None = None,
        skip_underscore: bool = True,
        include_filter: Callable[[Path], bool] | None = None,
    ) -> None:
        planned = self._collect_directory(
            template_dir,
            target_dir,
            {},
            extra_context=extra_context,
            skip_underscore=skip_underscore,
            include_filter=include_filter,
        )
        for output_path, content in planned.items():
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(content, encoding="utf-8")
            self._rendered_files.append(output_path)

    def _collect_directory(
        self,
        template_dir: Path,
        target_dir: Path,
        planned: dict[Path, str],
        extra_context: dict | None = None,
        skip_underscore: bool = True,
        include_filter: Callable[[Path], bool] | None = None,
    ) -> dict[Path, str]:
        env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            autoescape=select_autoescape([]),
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        context = self._build_context(extra_context)

        for template_path in sorted(template_dir.rglob("*")):
            if template_path.is_dir():
                continue

            rel_path = template_path.relative_to(template_dir)
            if include_filter and not include_filter(rel_path):
                continue
            if skip_underscore and any(part.startswith("_") and not part.startswith("__init__") for part in rel_path.parts):
                continue
            if not self._should_render_template(rel_path):
                continue

            rendered_name = self._render_string(str(rel_path), context)
            if rendered_name.endswith(".j2"):
                rendered_name = rendered_name[:-3]

            rel_template = str(template_path.relative_to(template_dir))
            template = env.get_template(rel_template)
            planned[target_dir / rendered_name] = template.render(**context)

        return planned

    def _build_context(self, extra: dict | None = None) -> dict:
        context = {
            "project_name": self.config.project_name,
            "description": self.config.description,
            "author": self.config.author,
            "python_version": self.config.python_version,
            "config": self.config,
            "is_monolith": not self.config.is_microservices,
            "is_microservices": self.config.is_microservices,
            "services": self.config.services,
            "database": self.config.database.value,
            "has_database": self.config.database.value != "none",
            "needs_sqlalchemy": self.config.needs_sqlalchemy,
            "needs_alembic": self.config.needs_alembic,
            "needs_redis": self.config.needs_redis,
            "message_queue": self.config.message_queue.value,
            "has_queue": self.config.message_queue.value != "none",
            "cache": self.config.cache.value,
            "worker": self.config.worker.value,
            "has_worker": self.config.worker.value != "none",
            "scheduler": self.config.scheduler.value,
            "container": self.config.container.value,
            "has_container": self.config.container.value != "none",
            "orchestration": self.config.orchestration.value,
            "has_orchestration": self.config.orchestration.value != "none",
            "dapr": self.config.dapr,
            "native_grpc": self.config.native_grpc,
            "service_protocol": self.config.service_protocol.value,
            "communication_stack": self.config.communication_stack,
            "gitignore": self.config.gitignore,
            "readme": self.config.readme,
            "precommit": self.config.precommit,
            "logging_backend": self.config.logging.value,
            "has_logging": self.config.has_logging,
            "scripting": self.config.scripting.value,
            "cicd": self.config.cicd.value,
            "testing": self.config.testing,
            "factory_boy": self.config.factory_boy,
            "api_versioning": self.config.api_versioning,
            "health_checks": self.config.health_checks,
            "env_example": self.config.env_example,
            "editor_config": self.config.editor_config,
            "shared_responses": self.config.shared_responses,
            "dependencies": self.config.get_dependencies(),
            "dev_dependencies": self.config.get_dev_dependencies(),
            "enabled_basics": self.config.enabled_basics,
        }
        if extra:
            context.update(extra)
        return context

    def _render_string(self, template_str: str, context: dict) -> str:
        return self._string_env.from_string(template_str).render(**context)

    def _should_render_template(self, rel_path: Path) -> bool:
        optional_files = {
            ".env.example.j2": self.config.env_example,
            ".gitignore.j2": self.config.gitignore,
            "README.md.j2": self.config.readme,
            ".editorconfig.j2": self.config.editor_config,
        }

        if "alembic" in rel_path.parts and not self.config.needs_alembic:
            return False
        if "grpc" in rel_path.parts and not self.config.native_grpc:
            return False
        return optional_files.get(rel_path.name, True)

    def _print_tree(self) -> None:
        tree = Tree(f"[bold cyan]{self.config.project_name}/[/]", guide_style="dim")
        dirs_added: dict[str, Tree] = {}

        for file_path in sorted(self._rendered_files):
            rel = file_path.relative_to(self.output_dir)
            current_tree = tree
            for index, part in enumerate(rel.parts[:-1]):
                key = "/".join(rel.parts[: index + 1])
                if key not in dirs_added:
                    dirs_added[key] = current_tree.add(f"[bold blue]{part}/[/]")
                current_tree = dirs_added[key]

            current_tree.add(rel.parts[-1])

        console.print(tree)
