"""Module registry for Fastix.

Each module (database, messaging, etc.) registers itself here.
The registry maps module names to their template directories and
generation logic. This is what makes Fastix extensible — adding
a new module never requires touching core code.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from fastix.core.config import ProjectConfig


@dataclass
class Module:
    """A registered Fastix module.

    Attributes:
        name: Unique module identifier (e.g., 'database.postgres').
        label: Human-readable name shown in CLI.
        template_dir: Path to this module's Jinja2 templates.
        should_include: Function that checks ProjectConfig to decide
            if this module should be included in generation.
        dependencies: Other module names that must be included first.
        context_builder: Optional function that returns extra template
            context specific to this module.
    """

    name: str
    label: str
    template_dir: Path
    should_include: Callable[[ProjectConfig], bool]
    dependencies: list[str] = field(default_factory=list)
    context_builder: Optional[Callable[[ProjectConfig], dict]] = None


class ModuleRegistry:
    """Central registry of all available modules.

    Modules register themselves on import. The generator queries the
    registry to determine which modules to include based on the user's
    ProjectConfig.
    """

    _modules: dict[str, Module] = {}

    @classmethod
    def register(cls, module: Module) -> None:
        """Register a module."""
        cls._modules[module.name] = module

    @classmethod
    def get(cls, name: str) -> Module | None:
        """Get a module by name."""
        return cls._modules.get(name)

    @classmethod
    def get_active_modules(cls, config: ProjectConfig) -> list[Module]:
        """Return all modules that should be included for the given config.

        Respects dependency ordering — if module A depends on module B,
        B will appear first in the returned list.
        """
        active: dict[str, Module] = {}

        for module in cls._modules.values():
            if module.should_include(config):
                cls._resolve_deps(module, active)

        return list(active.values())

    @classmethod
    def _resolve_deps(cls, module: Module, resolved: dict[str, Module]) -> None:
        """Recursively resolve module dependencies."""
        if module.name in resolved:
            return

        for dep_name in module.dependencies:
            dep = cls._modules.get(dep_name)
            if dep:
                cls._resolve_deps(dep, resolved)

        resolved[module.name] = module

    @classmethod
    def all_modules(cls) -> list[Module]:
        """Return all registered modules."""
        return list(cls._modules.values())

    @classmethod
    def clear(cls) -> None:
        """Clear registry (used in testing)."""
        cls._modules.clear()
