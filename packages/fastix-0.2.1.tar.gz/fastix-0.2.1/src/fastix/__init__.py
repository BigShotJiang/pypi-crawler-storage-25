"""Fastix - production-ready FastAPI project generator."""

__version__ = "0.2.1"
APP_NAME = "Fastix"
CLI_NAME = "fastix"
