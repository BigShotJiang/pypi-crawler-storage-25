"""Fastix CLI entry point."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.panel import Panel

from fastix import APP_NAME, CLI_NAME, __version__
from fastix.core.config import (
    Architecture,
    CacheBackend,
    CICDProvider,
    Container,
    Database,
    LoggingBackend,
    MessageQueue,
    Orchestration,
    ProjectConfig,
    Scheduler,
    ScriptingTool,
    TransportProtocol,
    WorkerBackend,
)
from fastix.core.state import (
    SUPPORTED_INCREMENTAL_MODULES,
    apply_incremental_module,
    find_project_root,
    get_replaced_modules,
    load_manifest,
)

console = Console()

app = typer.Typer(
    name=CLI_NAME,
    help="Generate and evolve FastAPI projects with an architecture-first wizard.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def version_callback(value: bool) -> None:
    if value:
        console.print(f"[bold cyan]{APP_NAME}[/] v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=version_callback, is_eager=True),
    ] = None,
) -> None:
    """Fastix — production-ready FastAPI project generator."""


@app.command()
def init(
    project_name: Annotated[Optional[str], typer.Argument(help="Project name")] = None,
    architecture: Annotated[
        Optional[Architecture],
        typer.Option("--arch", help="Architecture: monolith | microservices"),
    ] = None,
    services: Annotated[
        Optional[str],
        typer.Option("--services", help="Comma-separated service names for microservices"),
    ] = None,
    protocol: Annotated[
        Optional[TransportProtocol],
        typer.Option("--protocol", help="Primary microservice protocol: http | grpc"),
    ] = None,
    db: Annotated[
        Optional[Database],
        typer.Option("--db", help="Database: postgres | mysql | mongodb | none"),
    ] = None,
    migrations: Annotated[
        bool,
        typer.Option("--migrations/--no-migrations", help="Generate Alembic support for SQL databases"),
    ] = True,
    queue: Annotated[
        Optional[MessageQueue],
        typer.Option("--queue", help="Message queue: redis | kafka | rabbitmq | none"),
    ] = None,
    cache: Annotated[
        Optional[CacheBackend],
        typer.Option("--cache", help="Cache: redis | none"),
    ] = None,
    worker: Annotated[
        Optional[WorkerBackend],
        typer.Option("--worker", help="Worker: celery | rq | none"),
    ] = None,
    scheduler: Annotated[
        Optional[Scheduler],
        typer.Option("--scheduler", help="Scheduler: celery_beat | cronjob | none"),
    ] = None,
    container: Annotated[
        Optional[Container],
        typer.Option("--container", help="Container: docker | podman | none"),
    ] = None,
    k8s: Annotated[
        Optional[Orchestration],
        typer.Option("--k8s", help="K8s: helm | kustomize | raw_manifests | none"),
    ] = None,
    dapr: Annotated[
        bool,
        typer.Option("--dapr/--no-dapr", help="Enable Dapr integration for microservices"),
    ] = False,
    native_grpc: Annotated[
        bool,
        typer.Option("--native-grpc/--no-native-grpc", help="Generate native gRPC scaffolding for microservices"),
    ] = False,
    scripting: Annotated[
        Optional[ScriptingTool],
        typer.Option("--scripting", help="Task runner: makefile | justfile | taskfile | none"),
    ] = None,
    cicd: Annotated[
        Optional[CICDProvider],
        typer.Option("--cicd", help="CI/CD: github_actions | gitlab_ci | none"),
    ] = None,
    logging_backend: Annotated[
        Optional[LoggingBackend],
        typer.Option("--logging", help="Logging: api_logger | none"),
    ] = None,
    gitignore: Annotated[
        bool,
        typer.Option("--gitignore/--no-gitignore", help="Include .gitignore"),
    ] = True,
    readme: Annotated[
        bool,
        typer.Option("--readme/--no-readme", help="Include tailored README.md"),
    ] = True,
    precommit: Annotated[
        bool,
        typer.Option("--precommit/--no-precommit", help="Include pre-commit config"),
    ] = False,
    testing: Annotated[
        bool,
        typer.Option("--testing/--no-testing", help="Include test setup"),
    ] = True,
    factory_boy: Annotated[
        bool,
        typer.Option("--factory-boy/--no-factory-boy", help="Include Factory Boy helpers"),
    ] = False,
    api_versioning: Annotated[
        bool,
        typer.Option("--api-versioning/--no-api-versioning", help="Include API versioned routes"),
    ] = True,
    health_checks: Annotated[
        bool,
        typer.Option("--health-checks/--no-health-checks", help="Include health endpoints"),
    ] = True,
    env_example: Annotated[
        bool,
        typer.Option("--env-example/--no-env-example", help="Include .env.example"),
    ] = True,
    editor_config: Annotated[
        bool,
        typer.Option("--editor-config/--no-editor-config", help="Include .editorconfig"),
    ] = True,
    shared_responses: Annotated[
        bool,
        typer.Option("--shared-responses/--no-shared-responses", help="Include standard response contracts"),
    ] = True,
    output: Annotated[Path, typer.Option("--output", "-o", help="Output directory")] = Path("."),
) -> None:
    """Generate a new FastAPI project."""
    _load_modules()

    if project_name is None:
        from fastix.cli.prompts import prompt_project_config

        try:
            config = prompt_project_config()
        except RuntimeError as exc:
            console.print(f"[red]{exc}[/]")
            raise typer.Exit(code=1) from exc
    else:
        config = ProjectConfig(
            project_name=project_name,
            architecture=architecture or Architecture.MONOLITH,
            services=[item.strip() for item in (services or "").split(",") if item.strip()],
            service_protocol=protocol or TransportProtocol.HTTP,
            database=db or Database.POSTGRES,
            migrations=migrations,
            message_queue=queue or MessageQueue.NONE,
            cache=cache or CacheBackend.NONE,
            worker=worker or WorkerBackend.NONE,
            scheduler=scheduler or Scheduler.NONE,
            container=container or Container.DOCKER,
            orchestration=k8s or Orchestration.NONE,
            dapr=dapr,
            native_grpc=native_grpc,
            scripting=scripting or ScriptingTool.MAKEFILE,
            cicd=cicd or CICDProvider.GITHUB_ACTIONS,
            logging=logging_backend or LoggingBackend.API_LOGGER,
            gitignore=gitignore,
            readme=readme,
            precommit=precommit,
            testing=testing,
            factory_boy=factory_boy,
            api_versioning=api_versioning,
            health_checks=health_checks,
            env_example=env_example,
            editor_config=editor_config,
            shared_responses=shared_responses,
        )

    _print_summary(config)

    from fastix.core.engine import ProjectGenerator

    generator = ProjectGenerator(config, output_dir=output)
    project_path = generator.generate()
    _print_next_steps(config, project_path)


@app.command("inspect")
def inspect_project(
    path: Annotated[Path, typer.Argument(help="Existing Fastix project path")] = Path("."),
) -> None:
    """Show the current Fastix manifest and enabled modules."""
    root = find_project_root(path)
    manifest = load_manifest(root)

    lines = [
        f"[bold]Root:[/] {root}",
        f"[bold]Project:[/] {manifest.config.project_name}",
        f"[bold]Architecture:[/] {manifest.config.architecture.value}",
        f"[bold]Communication:[/] {manifest.config.communication_stack}",
        f"[bold]Database:[/] {manifest.config.database.value}",
        f"[bold]Migrations:[/] {'yes' if manifest.config.needs_alembic else 'no'}",
        f"[bold]Container:[/] {manifest.config.container.value}",
        f"[bold]K8s:[/] {manifest.config.orchestration.value}",
        f"[bold]CI/CD:[/] {manifest.config.cicd.value}",
        f"[bold]Logging:[/] {manifest.config.logging.value}",
        f"[bold]Basics:[/] {', '.join(manifest.config.enabled_basics) if manifest.config.enabled_basics else 'none'}",
        f"[bold]Modules:[/] {', '.join(manifest.active_modules) if manifest.active_modules else 'none'}",
    ]

    console.print(Panel("\n".join(lines), title="[bold cyan]Project State[/]", border_style="cyan"))


@app.command("add-module")
def add_module(
    module_name: Annotated[str, typer.Argument(help="Module name, for example dapr or cicd.github_actions")],
    path: Annotated[Path, typer.Option("--path", help="Existing Fastix project path")] = Path("."),
) -> None:
    """Add a supported module to an existing Fastix project."""
    _load_modules()
    root = find_project_root(path)
    manifest = load_manifest(root)

    try:
        updated_config = apply_incremental_module(manifest.config, module_name)
    except ValueError as exc:
        console.print(f"[red]{exc}[/]")
        raise typer.Exit(code=1) from exc

    from fastix.core.engine import ProjectGenerator
    from fastix.core.registry import ModuleRegistry

    previous = set(manifest.active_modules)
    current = {module.name for module in ModuleRegistry.get_active_modules(updated_config)}
    new_modules = sorted(current - previous)
    replaced_modules = get_replaced_modules(manifest.active_modules, module_name)

    if not new_modules and not replaced_modules:
        console.print(f"[yellow]No changes needed:[/] '{module_name}' is already active.")
        return

    removed_files: list[Path] = []
    manual_cleanup: list[Path] = []

    if replaced_modules:
        old_generator = ProjectGenerator.for_existing_project(manifest.config, root)
        old_files = old_generator.collect_module_files(replaced_modules)
        new_generator = ProjectGenerator.for_existing_project(updated_config, root)
        incoming_files = new_generator.collect_module_files(new_modules)

        deletable: list[Path] = []
        for file_path, expected_content in old_files.items():
            if file_path in incoming_files or not file_path.exists():
                continue
            current_content = file_path.read_text(encoding="utf-8")
            if current_content == expected_content:
                deletable.append(file_path)
            else:
                manual_cleanup.append(file_path)

        removed_files = new_generator.remove_files(deletable)
        generator = new_generator
    else:
        generator = ProjectGenerator.for_existing_project(updated_config, root)

    rendered = generator.apply_modules(new_modules)

    lines = [
        f"[bold]Project:[/] {updated_config.project_name}",
        f"[bold]Enabled:[/] {', '.join(new_modules) if new_modules else module_name}",
        f"[bold]Files updated:[/] {len(rendered)}",
    ]
    if replaced_modules:
        lines.append(f"[bold]Replaced:[/] {', '.join(replaced_modules)}")
        lines.append(f"[bold]Auto-removed:[/] {len(removed_files)}")

    console.print(
        Panel(
            "\n".join(lines),
            title="[bold green]Module Added[/]",
            border_style="green",
        )
    )

    if manual_cleanup:
        console.print(
            Panel(
                "\n".join(str(path.relative_to(root)) for path in manual_cleanup),
                title="[bold yellow]Manual Cleanup Required[/]",
                subtitle="These files differ from the original generated version and were left in place.",
                border_style="yellow",
            )
        )


@app.command("list-modules")
def list_modules() -> None:
    """List modules that can be added safely to existing Fastix projects today."""
    lines = [f"[bold]{name}[/]: {description}" for name, description in sorted(SUPPORTED_INCREMENTAL_MODULES.items())]
    console.print(Panel("\n".join(lines), title="[bold cyan]Incremental Modules[/]", border_style="cyan"))


@app.command()
def info() -> None:
    """Show available architectures, transports, and tooling."""
    console.print(Panel.fit(
        "[bold]Architectures:[/] monolith, microservices\n"
        "[bold]Microservice transport:[/] http, grpc, optional dapr\n"
        "[bold]Databases:[/] postgres, mysql, mongodb, none\n"
        "[bold]Queues:[/] redis, kafka, rabbitmq, none\n"
        "[bold]Workers:[/] celery, rq, none\n"
        "[bold]Schedulers:[/] celery_beat, cronjob, none\n"
        "[bold]Containers:[/] docker, podman, none\n"
        "[bold]K8s:[/] helm, kustomize, raw_manifests, none\n"
        "[bold]Basics:[/] .gitignore, README, editorconfig, env, testing, shared responses\n"
        "[bold]Logging:[/] api_logger, none\n"
        "[bold]Scripting:[/] makefile, justfile, taskfile, none\n"
        "[bold]CI/CD:[/] github_actions, gitlab_ci, none",
        title="[bold cyan]Fastix Capabilities[/]",
        border_style="cyan",
    ))


def _load_modules() -> None:
    from fastix.modules import register_all_modules

    register_all_modules()


def _print_summary(config: ProjectConfig) -> None:
    lines = [
        f"[bold]Project:[/] {config.project_name}",
        f"[bold]Architecture:[/] {config.architecture.value}",
        f"[bold]Communication:[/] {config.communication_stack}",
        f"[bold]Database:[/] {config.database.value}",
        f"[bold]Migrations:[/] {'yes' if config.needs_alembic else 'no'}",
        f"[bold]Queue:[/] {config.message_queue.value}",
        f"[bold]Worker:[/] {config.worker.value}",
        f"[bold]Container:[/] {config.container.value}",
        f"[bold]K8s:[/] {config.orchestration.value}",
        f"[bold]CI/CD:[/] {config.cicd.value}",
        f"[bold]Logging:[/] {config.logging.value}",
        f"[bold]Basics:[/] {', '.join(config.enabled_basics) if config.enabled_basics else 'none'}",
    ]
    if config.is_microservices:
        lines.insert(2, f"[bold]Services:[/] {', '.join(config.services)}")

    console.print(Panel("\n".join(lines), title="[bold cyan]Configuration[/]", border_style="dim"))


def _print_next_steps(config: ProjectConfig, project_path: Path) -> None:
    steps = [
        f"cd {project_path}",
        "python -m venv .venv && source .venv/bin/activate",
        "pip install -e '.[dev]'",
        "fastix inspect .",
    ]

    if config.precommit:
        steps.append("pre-commit install")
    if config.needs_alembic:
        steps.append("alembic upgrade head")
    if config.container == Container.DOCKER:
        steps.append("docker compose up -d")
    elif config.container == Container.PODMAN:
        steps.append("podman-compose up -d")

    if config.is_microservices:
        steps.append("uvicorn services.gateway.app.main:app --reload" if "gateway" in config.services else f"uvicorn services.{config.services[0]}.app.main:app --reload")
    else:
        steps.append("uvicorn app.main:app --reload")

    console.print(
        Panel(
            "\n".join(f"  [cyan]{index + 1}.[/] {step}" for index, step in enumerate(steps)),
            title="[bold green]Next Steps[/]",
            border_style="green",
        )
    )


if __name__ == "__main__":  # pragma: no cover
    app()
