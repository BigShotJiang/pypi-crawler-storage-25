"""Fastix modules — pluggable infrastructure components."""

from fastix.modules.register import register_all_modules

__all__ = ["register_all_modules"]
