"""Module registration — wires all modules into the registry.

Each module is a self-contained unit with:
- A template directory (Jinja2 files)
- A condition function (when to include it)
- Optional dependencies (other modules that must be included first)

This file is the single place where all modules are registered.
Adding a new module = adding one register() call here.
"""

from __future__ import annotations

from pathlib import Path

from fastix.core.config import (
    CacheBackend,
    CICDProvider,
    Container,
    Database,
    LoggingBackend,
    MessageQueue,
    Orchestration,
    ProjectConfig,
    Scheduler,
    ScriptingTool,
    WorkerBackend,
)
from fastix.core.registry import Module, ModuleRegistry

MODULES_DIR = Path(__file__).parent


def register_all_modules() -> None:
    """Register all available modules."""
    # ── Database ──────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="database.postgres",
        label="PostgreSQL",
        template_dir=MODULES_DIR / "database" / "postgres" / "templates",
        should_include=lambda c: c.database == Database.POSTGRES,
    ))

    ModuleRegistry.register(Module(
        name="database.mysql",
        label="MySQL",
        template_dir=MODULES_DIR / "database" / "mysql" / "templates",
        should_include=lambda c: c.database == Database.MYSQL,
    ))

    ModuleRegistry.register(Module(
        name="database.mongodb",
        label="MongoDB",
        template_dir=MODULES_DIR / "database" / "mongodb" / "templates",
        should_include=lambda c: c.database == Database.MONGODB,
    ))

    # ── Messaging ─────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="messaging.redis",
        label="Redis",
        template_dir=MODULES_DIR / "messaging" / "redis" / "templates",
        should_include=lambda c: (
            c.message_queue == MessageQueue.REDIS or c.needs_redis
        ),
    ))

    ModuleRegistry.register(Module(
        name="messaging.kafka",
        label="Kafka",
        template_dir=MODULES_DIR / "messaging" / "kafka" / "templates",
        should_include=lambda c: c.message_queue == MessageQueue.KAFKA,
    ))

    ModuleRegistry.register(Module(
        name="messaging.rabbitmq",
        label="RabbitMQ",
        template_dir=MODULES_DIR / "messaging" / "rabbitmq" / "templates",
        should_include=lambda c: c.message_queue == MessageQueue.RABBITMQ,
    ))

    # ── Workers ───────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="worker.celery",
        label="Celery",
        template_dir=MODULES_DIR / "worker" / "celery" / "templates",
        should_include=lambda c: c.worker == WorkerBackend.CELERY,
        dependencies=["messaging.redis"],
    ))

    ModuleRegistry.register(Module(
        name="worker.rq",
        label="RQ",
        template_dir=MODULES_DIR / "worker" / "rq" / "templates",
        should_include=lambda c: c.worker == WorkerBackend.RQ,
        dependencies=["messaging.redis"],
    ))

    # ── Scheduler ─────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="scheduler.celery_beat",
        label="Celery Beat",
        template_dir=MODULES_DIR / "scheduler" / "celery_beat" / "templates",
        should_include=lambda c: c.scheduler == Scheduler.CELERY_BEAT,
        dependencies=["worker.celery"],
    ))

    ModuleRegistry.register(Module(
        name="scheduler.cronjob",
        label="Kubernetes CronJob",
        template_dir=MODULES_DIR / "scheduler" / "cronjob" / "templates",
        should_include=lambda c: c.scheduler == Scheduler.CRONJOB,
    ))

    # ── Containers ────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="container.docker",
        label="Docker",
        template_dir=MODULES_DIR / "container" / "docker" / "templates",
        should_include=lambda c: c.container == Container.DOCKER,
    ))

    ModuleRegistry.register(Module(
        name="container.podman",
        label="Podman",
        template_dir=MODULES_DIR / "container" / "podman" / "templates",
        should_include=lambda c: c.container == Container.PODMAN,
    ))

    # ── Orchestration ─────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="orchestration.helm",
        label="Helm",
        template_dir=MODULES_DIR / "orchestration" / "helm" / "templates",
        should_include=lambda c: c.orchestration == Orchestration.HELM,
    ))

    ModuleRegistry.register(Module(
        name="orchestration.kustomize",
        label="Kustomize",
        template_dir=MODULES_DIR / "orchestration" / "kustomize" / "templates",
        should_include=lambda c: c.orchestration == Orchestration.KUSTOMIZE,
    ))

    ModuleRegistry.register(Module(
        name="orchestration.raw_manifests",
        label="Raw K8s Manifests",
        template_dir=MODULES_DIR / "orchestration" / "raw_manifests" / "templates",
        should_include=lambda c: c.orchestration == Orchestration.RAW_MANIFESTS,
    ))

    # ── Dapr ──────────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="dapr",
        label="Dapr",
        template_dir=MODULES_DIR / "dapr" / "templates",
        should_include=lambda c: c.dapr,
    ))

    # ── Dev Tooling ───────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="devtools.precommit",
        label="Pre-commit",
        template_dir=MODULES_DIR / "devtools" / "precommit" / "templates",
        should_include=lambda c: c.precommit,
    ))

    ModuleRegistry.register(Module(
        name="devtools.editor",
        label="EditorConfig",
        template_dir=MODULES_DIR / "devtools" / "editor" / "templates",
        should_include=lambda c: c.editor_config,
    ))

    # ── Testing ───────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="testing.pytest",
        label="Pytest",
        template_dir=MODULES_DIR / "testing" / "pytest" / "templates",
        should_include=lambda c: c.testing,
    ))

    ModuleRegistry.register(Module(
        name="testing.factory_boy",
        label="Factory Boy",
        template_dir=MODULES_DIR / "testing" / "factory_boy" / "templates",
        should_include=lambda c: c.factory_boy,
        dependencies=["testing.pytest"],
    ))

    # ── Scripting ─────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="scripting.makefile",
        label="Makefile",
        template_dir=MODULES_DIR / "scripting" / "makefile" / "templates",
        should_include=lambda c: c.scripting == ScriptingTool.MAKEFILE,
    ))

    ModuleRegistry.register(Module(
        name="scripting.justfile",
        label="Justfile",
        template_dir=MODULES_DIR / "scripting" / "justfile" / "templates",
        should_include=lambda c: c.scripting == ScriptingTool.JUSTFILE,
    ))

    ModuleRegistry.register(Module(
        name="scripting.taskfile",
        label="Taskfile",
        template_dir=MODULES_DIR / "scripting" / "taskfile" / "templates",
        should_include=lambda c: c.scripting == ScriptingTool.TASKFILE,
    ))

    # ── Logging ───────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="logging.api_logger",
        label="API Logger",
        template_dir=MODULES_DIR / "logging" / "api_logger" / "templates",
        should_include=lambda c: c.logging == LoggingBackend.API_LOGGER,
    ))

    # ── CI/CD ─────────────────────────────────────────────────
    ModuleRegistry.register(Module(
        name="cicd.github_actions",
        label="GitHub Actions",
        template_dir=MODULES_DIR / "cicd" / "github_actions" / "templates",
        should_include=lambda c: c.cicd == CICDProvider.GITHUB_ACTIONS,
    ))

    ModuleRegistry.register(Module(
        name="cicd.gitlab_ci",
        label="GitLab CI",
        template_dir=MODULES_DIR / "cicd" / "gitlab_ci" / "templates",
        should_include=lambda c: c.cicd == CICDProvider.GITLAB_CI,
    ))
