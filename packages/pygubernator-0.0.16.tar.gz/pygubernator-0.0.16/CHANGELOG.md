# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

## [0.0.16] - 2026-04-25

### Added

- **Phase 6 UX uplift (System 2-inspired, DAG-native).** Brings the
  agent workbench up to feature parity with the System 2 analyst
  workbench while keeping the DAG engine, replay, and audit
  contracts unchanged.

    - Typed artifact surface: `WorkflowArtifact` model + renderers
      for markdown / table / csv / html / image / json / text, with a
      sandboxed read-only SQL panel for CSV artifacts (§6.1).
    - Active-agents fleet panel mounted on the runs page (§6.2).
    - Step trace with expandable disclosure rows + "Copy as JSON"
      affordance (§6.3).
    - Live thinking-block streaming (`LLM_THINKING_DELTA` event type)
      with OpenAI / Anthropic provider extraction (§6.4).
    - Resizable split-pane workbench layout with localStorage
      persistence and responsive stacking (§6.5).
    - Live DAG with pulse animation on running nodes, agent badges
      on agent / dispatch_agent / llm / llm_planner nodes, real
      layered graph layout with edge classification (`fired` /
      `skipped` / `pending`), edge tooltips with handle names + JSON
      previews (§6.6).
    - Guide conversational orchestrator: new `llm_planner` node,
      `/guide` chat-style page, server-side planner route
      `POST /api/v1/guide/plan` with manual / auto routing modes
      (§6.7).
    - Session rename + breadcrumb, session-summaries card (§6.8 / §6.10).
    - Knowledge → Notebooks editor at `/knowledge/notebooks` for
      editing each `MemoryScope`'s `ContextSurface` directly (§6.9).
    - User-facing docs: `docs/guides/agent-workbench.md` (tour) and
      `docs/reference/system2-comparison.md` (adopt / don't-adopt
      table + translation principles).

### Changed

- **Phase R foundation refactor.** Mechanical / structural cleanup
  of files Phase 6 touched. No behaviour changes; every helper
  round-trips byte-identical responses.

    - New `api/_routes_common.py` carries `paginated_response()`,
      `emit_audit()`, and `workspace_id_of()` helpers. 8 route
      files migrated to use them; 32 `store.create_audit(actor=
      actor["username"], …)` sites collapsed to `emit_audit` calls.
    - New `_compile_agent_spec_or_400()` helper in `routes_agents`
      collapses the load-or-parse-then-compile-then-rescue
      `ConfigError` block across four routes.
    - New `AgentEditorStore.loadCatalog()` action with module-level
      dedupe so concurrent first-mounts of the editor sidebar +
      a node-config picker share one `GET /api/v1/agents` call.
    - `AgentRegistryDetailView` split: extracted
      `VersionLifecycleActions` and `InlineVersionForm` into
      dedicated components and replaced six sibling `useState`
      calls with a single `useReducer` whose `select_provider`
      action atomically updates preset-derived fields.

## [0.0.14] - 2026-04-10

### Added

- Update src/pygubernator/ui/src/components/workflows/WorkflowCanvas.tsx,src/pygubernator/ui/src/hooks/use-collab.ts
- Update src/pygubernator/ui/src/hooks/use-collab.ts
- Update src/pygubernator/ui/src/app/workflows/editor/WorkflowEditorInner.tsx,src/pygubernator/ui/src/hooks/use-collab.ts
- Update package
- Update package
- Update src/pygubernator/ui/src/lib/api.ts,src/pygubernator/ui/src/lib/auth-storage.ts,src/pygubernator/ui/src/lib/constants.ts
- Update package

## [0.0.12] - 2026-04-06

### Added

- Update src/pygubernator/connectors/factory.py

## [0.0.10] - 2026-04-06

### Added

- Update src/pygubernator/ui/next-env.d.ts,src/pygubernator/ui/src/components/workflows/WorkflowCanvas.tsx
- Update src/pygubernator/ui/src/lib/workflow-node-types.ts
- Update package
- Update src/pygubernator/workflow/config/_converter.py
- Update src/pygubernator/workflow/config/_models.py
- Update package
- Update package
- Update package

## [0.0.9] - 2026-04-04

### Added

- Update src/pygubernator/db/migrations/versions/20260331003000_workflow_layouts.py
- Update src/pygubernator/collab/_protocol.py,src/pygubernator/ui/next-env.d.ts

### Documentation

- Update documentation

## [0.0.8] - 2026-03-31

### Added

- Update src/pygubernator/data/seed/31_catalyst_to_pystator_http_process.yaml
- Update package

## [0.0.7] - 2026-03-31

### Added

- Update scripts/ci.sh,src/pygubernator/tools/catalyst_tools.py

## [0.0.4] - 2026-03-24

### Added

- Add open-source LLM provider support, agent/tool workflow nodes, and editor UX improvements
- Add Google Sheets tools for ToolRegistry
- Expand memory node form with database backend selection
- Add persistent memory store backends

### Fixed

- Move LLM/Agent input handle to left side
- Move LLM/Agent output handle to right side
- Auto-save before executing workflow
- Resolve sub-nodes by type match, not just handle name

### Merge

- Bring Google Sheets tools into develop
- Bring memory node frontend form into develop

## [0.0.2] - 2026-03-19
