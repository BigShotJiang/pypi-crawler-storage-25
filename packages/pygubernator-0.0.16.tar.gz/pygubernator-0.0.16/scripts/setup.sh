#!/bin/bash
################################################################################
# Optophi standard dev setup — keep in sync across pycharter, pystator,
# pygubernator, pyactuator, pyalbedo, pycatalyst, pyfortis, pyintake, pyoptima.
#
# Creates venv, installs dev dependencies, optional API/UI extras,
# and pre-commit hooks. Run from the repo root:
#   ./scripts/setup.sh
################################################################################

set -euo pipefail

export PYENV_REHASH_TIMEOUT=0

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

PKG="$(basename "$REPO_ROOT")"
SRC_PKG="src/${PKG}"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info() { echo -e "${BLUE}i${NC} $1"; }
success() { echo -e "${GREEN}ok${NC} $1"; }
warning() { echo -e "${YELLOW}!${NC} $1"; }
error() { echo -e "${RED}x${NC} $1" >&2; }

if ! command -v python3 &> /dev/null; then
    error "Python 3 is not installed."
    exit 1
fi

PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)
if ! [[ "$PYTHON_MAJOR" =~ ^[0-9]+$ ]] || ! [[ "$PYTHON_MINOR" =~ ^[0-9]+$ ]]; then
    error "Could not parse Python version: $PYTHON_VERSION"
    exit 1
fi
if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    error "Python 3.11+ required. Found: $PYTHON_VERSION"
    exit 1
fi

info "Python: $PYTHON_VERSION  package: $PKG"
echo ""

WANT_VENV="$(cd "$REPO_ROOT" && pwd -P)/venv"
if [ -f venv/bin/activate ]; then
    GOT_VENV=$(grep -m1 'export VIRTUAL_ENV=/' venv/bin/activate | sed 's/.*export VIRTUAL_ENV=//; s/\r//' || true)
    if [ -n "${GOT_VENV:-}" ] && [ "$GOT_VENV" != "$WANT_VENV" ]; then
        info "Removing virtual environment (path moved)..."
        rm -rf venv
    fi
fi

if [ ! -d "venv" ] || [ ! -f "venv/bin/python" ]; then
    if [ -d "venv" ]; then
        info "Removing incomplete venv..."
        rm -rf venv
    fi
    info "Creating venv..."
    python3 -m venv venv
    success "venv created"
else
    success "venv already exists"
fi

VENV_PY="$REPO_ROOT/venv/bin/python"
if [ ! -x "$VENV_PY" ]; then
    error "Missing venv interpreter: $VENV_PY"
    exit 1
fi

info "Upgrading pip, setuptools, wheel..."
"$VENV_PY" -m pip install --upgrade pip setuptools wheel --quiet

info "Installing ${PKG} (editable, [dev])..."
if "$VENV_PY" -m pip install -e ".[dev]" --quiet; then
    success "${PKG} installed with dev dependencies"
else
    error "pip install -e .[dev] failed."
    exit 1
fi

if "$VENV_PY" -c "import pre_commit" 2>/dev/null; then
    info "Installing pre-commit hooks..."
    "$VENV_PY" -m pre_commit install
    "$VENV_PY" -m pre_commit install --hook-type pre-push
    success "pre-commit installed"
else
    warning "pre-commit not in venv; add to [dev] extras."
fi

if [ -d "${SRC_PKG}/api" ]; then
    info "Installing [api] extra..."
    if "$VENV_PY" -m pip install -e ".[api]" --quiet; then
        success "API extra installed"
    else
        warning "Optional [api] install failed."
    fi
fi

if [ -d "${SRC_PKG}/ui" ]; then
    info "Installing [ui] extra..."
    if "$VENV_PY" -m pip install -e ".[ui]" --quiet; then
        success "UI extra installed"
    else
        warning "Optional [ui] install failed."
    fi
fi

if [ -f "${SRC_PKG}/ui/package.json" ] && command -v npm &> /dev/null; then
    info "npm install in ${SRC_PKG}/ui ..."
    if (cd "${SRC_PKG}/ui" && npm install --silent --registry https://registry.npmjs.org/); then
        success "UI npm deps installed"
    else
        warning "npm install failed in UI dir."
    fi
elif [ -f "${SRC_PKG}/ui/package.json" ]; then
    warning "npm not found; skip UI npm install."
fi

echo ""
success "Setup complete."
echo ""
echo "Activate:  source venv/bin/activate"
echo "Tests:     pytest"
echo "Coverage:  pytest --cov=${PKG}"
if [ -f mkdocs.yml ]; then
    echo "Docs:      ${PKG} docs serve   # if CLI exposes docs (see README)"
fi
echo "CLI help:  ${PKG} --help   # if console_scripts defined in pyproject.toml"
