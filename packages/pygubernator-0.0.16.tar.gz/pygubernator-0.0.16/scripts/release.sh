#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# release.sh — Optophi standard release helper.
#
# Byte-identical across all 9 Optophi Python package repos:
#   pycharter, pystator, pygubernator, pyactuator, pyalbedo,
#   pycatalyst, pyfortis, pyintake, pyoptima.
#
# Run from the repository root.
#
# Usage:
#   ./scripts/release.sh <command> [options]
#
# Commands:
#   status              One-screen dashboard: branch, open PRs, divergence,
#                       last tag, last CI result.
#   verify              Run the same gates CI runs locally (fail-fast).
#   commit [-m MSG]     git add -A + commit (auto-message if -m missing).
#   push                commit + push current branch.
#   merge-dev           push + merge current branch → develop.
#   merge-main          push develop + open/auto-merge PR develop → main.
#   tag [VERSION]       Check CI on main, then tag and push.
#   release             merge-main + tag (the full release pipeline).
#   dependabot-cleanup  Triage + rebase + merge open Dependabot PRs.
#   help                Show this message.
#
# Environment:
#   RELEASE_PR_WAIT_SECONDS   How long to wait for the develop→main PR
#                             to merge (default 3600).
#   RELEASE_VERSION           Override the tag computed by ``tag`` (e.g.
#                             ``v0.2.0`` for a minor bump).
#   GITHUB_TOKEN / GH_TOKEN   Used for private-repo CI status lookups.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

DEVELOP="develop"
MAIN="main"
REMOTE="origin"

# ─────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────

die()  { echo "ERROR: $*" >&2; exit 1; }
info() { echo "  → $*"; }
warn() { echo "  ! $*" >&2; }

_has_gh() { command -v gh >/dev/null 2>&1; }
_has_jq() { command -v jq >/dev/null 2>&1; }

current_branch() { git branch --show-current; }

has_changes() { [[ -n "$(git status --porcelain)" ]]; }

# GitHub owner/repo from origin (ssh or https URL).
github_owner_repo() {
    local url
    url=$(git remote get-url "$REMOTE" 2>/dev/null || true)
    [[ -n "$url" ]] || return 1
    url="${url%.git}"
    if [[ "$url" =~ github\.com[:/]([^/]+)/(.+)$ ]]; then
        echo "${BASH_REMATCH[1]}/${BASH_REMATCH[2]}"
        return 0
    fi
    return 1
}

# Next patch tag based on latest semver-style vX.Y.Z tag.
next_patch_tag() {
    local latest
    latest=$(git tag --sort=-v:refname | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | head -1 || true)
    if [[ -z "$latest" ]]; then
        echo "v0.0.1"
        return
    fi
    local major minor patch
    IFS='.' read -r major minor patch <<< "${latest#v}"
    echo "v${major}.${minor}.$((patch + 1))"
}

# Latest conclusion for a workflow file on a branch.
ci_conclusion() {
    local branch="$1"
    local workflow="${2:-test.yml}"
    if _has_gh; then
        gh run list --branch="$branch" --workflow="$workflow" --limit=1 \
            --json conclusion --jq '.[0].conclusion // "unknown"' 2>/dev/null \
            || echo "unknown"
        return
    fi
    echo "unknown"
}

# Run a pre-commit-aware commit. Retries once with ``--no-verify`` on
# the documented macOS ``BlockingIOError`` flake.
commit_with_retry() {
    local msg="$1"
    local log
    log=$(mktemp)
    if git commit -m "$msg" 2>&1 | tee "$log"; then
        rm -f "$log"
        return 0
    fi
    if grep -q "BlockingIOError" "$log" 2>/dev/null; then
        warn "pre-commit hit macOS BlockingIOError — retrying with --no-verify once"
        rm -f "$log"
        git commit --no-verify -m "$msg"
        return $?
    fi
    rm -f "$log"
    return 1
}

# Generate a minimal conventional-commits-style message from the staged
# diff. Intentionally dumb — real commit messages should be passed in
# via ``-m``. Used only as a safety net.
generate_commit_message() {
    local files
    files=$(git diff --cached --name-only 2>/dev/null)
    local type="chore"
    local desc="update repository files"

    if [[ -z "$files" ]]; then
        echo "${type}: ${desc}"
        return
    fi

    if echo "$files" | grep -qE "\.github/workflows/"; then
        type="ci"
        desc="update workflow"
    elif echo "$files" | grep -qE "^docs/|^README|^CHANGELOG|^CONTRIBUTING|^SECURITY"; then
        type="docs"
        desc="update documentation"
    elif echo "$files" | grep -qE "test_|tests/"; then
        type="test"
        desc="update tests"
    elif echo "$files" | grep -qE "^src/"; then
        type="feat"
        desc="update source"
    fi

    # If a single file is staged, name it in the summary.
    local file_count
    file_count=$(echo "$files" | wc -l | tr -d ' ')
    if [[ "$file_count" == "1" ]]; then
        desc="update $(echo "$files" | head -1)"
    fi

    echo "${type}: ${desc}"
}

# ─────────────────────────────────────────────────────────────────
# Commands
# ─────────────────────────────────────────────────────────────────

cmd_help() {
    sed -n '/^# Usage:/,/^# ───/p' "$0" | head -n -1 | sed 's/^# \?//'
}

cmd_status() {
    echo "── status ──"
    local branch owner_repo
    branch=$(current_branch)
    owner_repo=$(github_owner_repo 2>/dev/null || echo "(unknown)")

    echo "Repo:           ${owner_repo}"
    echo "Current branch: ${branch}"
    echo "Remote:         ${REMOTE}"

    if has_changes; then
        local n
        n=$(git status --porcelain | wc -l | tr -d ' ')
        echo "Working tree:   ${n} uncommitted change(s)"
    else
        echo "Working tree:   clean"
    fi

    # Divergence develop vs main.
    git fetch "$REMOTE" "$DEVELOP" "$MAIN" --quiet 2>/dev/null || true
    local ahead behind
    ahead=$(git rev-list --count "${REMOTE}/${MAIN}..${REMOTE}/${DEVELOP}" 2>/dev/null || echo "?")
    behind=$(git rev-list --count "${REMOTE}/${DEVELOP}..${REMOTE}/${MAIN}" 2>/dev/null || echo "?")
    echo "develop vs main: develop ahead ${ahead}, main ahead ${behind}"

    # Latest tag.
    local latest_tag
    latest_tag=$(git tag --sort=-v:refname | head -1)
    echo "Latest tag:     ${latest_tag:-(none)}"

    # CI status.
    local ci_dev ci_main ci_sem_dev
    ci_dev=$(ci_conclusion "$DEVELOP" test.yml)
    ci_main=$(ci_conclusion "$MAIN" test.yml)
    ci_sem_dev=$(ci_conclusion "$DEVELOP" semgrep.yml)
    echo "CI on develop:  test=${ci_dev}  semgrep=${ci_sem_dev}"
    echo "CI on main:     test=${ci_main}"

    # Open PRs.
    if _has_gh; then
        local pr_count
        pr_count=$(gh pr list --state open --json number --jq 'length' 2>/dev/null || echo "?")
        echo "Open PRs:       ${pr_count}"
        if [[ "$pr_count" != "0" && "$pr_count" != "?" ]]; then
            gh pr list --state open --json number,title,headRefName \
                --jq '.[] | "  #\(.number) \(.title | .[:70])"' 2>/dev/null || true
        fi
    else
        echo "Open PRs:       (install gh to see)"
    fi
}

# Run the same gate set CI runs. Intentionally exit non-zero on any
# failure so release scripts can bail early.
cmd_verify() {
    echo "── verify ──"
    local failed=()

    if [[ -f pyproject.toml ]]; then
        if command -v ruff >/dev/null 2>&1; then
            info "ruff check"
            ruff check src/ || failed+=("ruff check")
            info "ruff format --check"
            ruff format --check src/ || failed+=("ruff format")
        fi
        if command -v pytest >/dev/null 2>&1; then
            info "pytest"
            pytest -q || failed+=("pytest")
        fi
        if command -v mypy >/dev/null 2>&1 && grep -q "^\[tool.mypy\]" pyproject.toml; then
            info "mypy"
            mypy src/ || failed+=("mypy")
        fi
    fi

    # UI type-check if the package ships one.
    local pkg_name
    pkg_name=$(basename "$(pwd)")
    local ui_dir="src/${pkg_name}/ui"
    if [[ -f "${ui_dir}/package.json" ]] && command -v npm >/dev/null 2>&1; then
        info "UI type-check"
        (cd "$ui_dir" && npm run --silent type-check) || failed+=("UI type-check")
    fi

    # Docs: only strict-build if mkdocs.yml is present.
    if [[ -f mkdocs.yml ]] && command -v mkdocs >/dev/null 2>&1; then
        info "mkdocs build --strict (temp output)"
        local tmp
        tmp=$(mktemp -d)
        mkdocs build --strict --site-dir "$tmp" >/dev/null 2>&1 \
            || failed+=("mkdocs build")
        rm -rf "$tmp"
    fi

    if [[ ${#failed[@]} -gt 0 ]]; then
        echo ""
        die "Verify failed: ${failed[*]}"
    fi
    info "All gates passed."
}

cmd_commit() {
    echo "── commit ──"
    local msg=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -m) msg="$2"; shift 2 ;;
            *)  die "Unknown option to commit: $1" ;;
        esac
    done
    if ! has_changes; then
        info "Working tree clean; nothing to commit."
        return 0
    fi
    git add -A
    if [[ -z "$msg" ]]; then
        msg=$(generate_commit_message)
        warn "No -m supplied; using auto-generated message: ${msg}"
        warn "For real work, prefer: ./scripts/release.sh commit -m \"feat: ...\""
    fi
    info "Committing: ${msg}"
    commit_with_retry "$msg"
    info "Committed."
}

cmd_push() {
    if has_changes; then
        cmd_commit "$@"
    fi
    local branch
    branch=$(current_branch)
    echo "── push ${branch} ──"
    git push "$REMOTE" "$branch"
    info "Pushed to ${REMOTE}/${branch}."
}

cmd_merge_dev() {
    local branch
    branch=$(current_branch)
    if [[ "$branch" == "$DEVELOP" ]]; then
        cmd_push
        return 0
    fi
    cmd_push
    echo "── merge ${branch} → ${DEVELOP} ──"
    git checkout "$DEVELOP"
    git pull "$REMOTE" "$DEVELOP" --rebase 2>/dev/null || true
    git merge "$branch" --no-edit
    git push "$REMOTE" "$DEVELOP"
    info "Merged ${branch} → ${DEVELOP} and pushed."
    git checkout "$branch"
}

# Merge develop → main via GitHub PR. Main is always PR-protected.
cmd_merge_main() {
    cmd_merge_dev

    echo "── merge ${DEVELOP} → ${MAIN} (PR) ──"

    _has_gh || die "merge-main requires 'gh' CLI. Install https://cli.github.com/ and run 'gh auth login'."
    gh auth status >/dev/null 2>&1 || die "gh is not logged in. Run: gh auth login"

    local gh_repo
    gh_repo=$(github_owner_repo) || die "Could not parse owner/repo from remote '${REMOTE}'."
    export GH_REPO="$gh_repo"
    info "GitHub repo: ${gh_repo}"
    gh repo view "$gh_repo" >/dev/null 2>&1 \
        || die "gh cannot access '${gh_repo}'. Check 'git remote -v' and 'gh auth status'."

    git fetch "$REMOTE" "$DEVELOP" "$MAIN"

    local ahead
    ahead=$(git rev-list --count "${REMOTE}/${MAIN}..${REMOTE}/${DEVELOP}" 2>/dev/null || echo "0")
    if [[ "$ahead" -eq 0 ]]; then
        info "No commits on ${DEVELOP} that aren't already on ${MAIN}; nothing to merge."
        return 0
    fi

    git push "$REMOTE" "$DEVELOP"

    local pr_num
    pr_num=$(gh pr list --base "$MAIN" --head "$DEVELOP" --state open \
        --json number --jq '.[0].number // empty')
    if [[ -z "$pr_num" ]]; then
        info "Opening PR ${DEVELOP} → ${MAIN}..."
        gh pr create --base "$MAIN" --head "$DEVELOP" \
            --title "chore: merge ${DEVELOP} into ${MAIN}" \
            --body "Automated merge from \`scripts/release.sh merge-main\`."
        pr_num=$(gh pr list --base "$MAIN" --head "$DEVELOP" --state open \
            --json number --jq '.[0].number // empty')
        [[ -n "$pr_num" ]] || die "Failed to create or find PR ${DEVELOP} → ${MAIN}."
    else
        info "Using existing PR #${pr_num}."
    fi

    # --auto waits for required status checks; fall through to immediate
    # merge if --auto isn't available (e.g. all checks already green).
    # Use --squash because main has ``required_linear_history`` enabled
    # (no merge commits allowed). Squash collapses the develop commits
    # into a single release commit on main, which keeps git log readable.
    info "Requesting auto-merge on PR #${pr_num}..."
    if ! gh pr merge "$pr_num" --squash --auto 2>/dev/null; then
        info "Auto-merge unavailable — trying immediate squash-merge."
        gh pr merge "$pr_num" --squash \
            || die "PR #${pr_num} could not be merged. Check status: gh pr view ${pr_num} --web"
    fi

    info "Waiting for PR #${pr_num} to merge..."
    local waited=0 max="${RELEASE_PR_WAIT_SECONDS:-3600}"
    while :; do
        local state
        state=$(gh pr view "$pr_num" --json state --jq '.state' 2>/dev/null || echo UNKNOWN)
        case "$state" in
            MERGED)
                info "PR #${pr_num} merged."
                break
                ;;
            OPEN)
                if [[ "$waited" -ge "$max" ]]; then
                    die "Timed out after ${max}s waiting for PR #${pr_num} to merge."
                fi
                ;;
            *)
                die "PR #${pr_num} is in unexpected state: ${state}"
                ;;
        esac
        sleep 5
        waited=$((waited + 5))
    done

    git fetch "$REMOTE" "$MAIN"
}

cmd_tag() {
    local override="${1:-${RELEASE_VERSION:-}}"
    echo "── tag ──"

    info "Checking CI on ${MAIN}..."
    local status
    status=$(ci_conclusion "$MAIN" test.yml)
    if [[ "$status" == "failure" ]]; then
        die "CI is failing on ${MAIN}. Fix before tagging."
    elif [[ "$status" == "success" ]]; then
        info "CI on ${MAIN}: success."
    else
        warn "CI on ${MAIN}: ${status} (proceeding anyway)."
    fi

    local branch
    branch=$(current_branch)
    git checkout "$MAIN"
    git pull "$REMOTE" "$MAIN" --rebase 2>/dev/null || true

    local tag
    if [[ -n "$override" ]]; then
        [[ "$override" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ ]] \
            || die "Override tag '${override}' is not vMAJOR.MINOR.PATCH."
        tag="$override"
    else
        tag=$(next_patch_tag)
    fi

    if git rev-parse "$tag" >/dev/null 2>&1; then
        die "Tag ${tag} already exists locally. Delete it or use a different version."
    fi
    if git ls-remote --tags "$REMOTE" "refs/tags/${tag}" | grep -q "$tag"; then
        die "Tag ${tag} already exists on ${REMOTE}. Use a different version."
    fi

    info "Creating tag: ${tag}"
    git tag "$tag"
    git push "$REMOTE" "$tag"
    info "Pushed ${tag}. publish.yml will: run tests, generate changelog,"
    info "create GitHub Release, publish to PyPI."

    git checkout "$branch"
}

cmd_release() {
    echo "════════════════════════════════"
    echo " Full release pipeline"
    echo "════════════════════════════════"
    cmd_merge_main
    cmd_tag
    echo "════════════════════════════════"
    echo " Release complete."
    echo "════════════════════════════════"
}

# Rebase + merge open Dependabot PRs. Real failures (test failures, type
# errors) are surfaced as blockers — stale CI on PRs whose base has
# moved are rebased via @dependabot rebase.
cmd_dependabot_cleanup() {
    echo "── dependabot-cleanup ──"
    _has_gh || die "dependabot-cleanup requires 'gh' CLI."
    local owner_repo
    owner_repo=$(github_owner_repo) || die "Could not parse owner/repo."

    local prs
    prs=$(gh pr list --repo "$owner_repo" --author "app/dependabot" \
        --state open --json number --jq '.[].number')
    if [[ -z "$prs" ]]; then
        info "No open Dependabot PRs."
        return 0
    fi

    echo "Found $(echo "$prs" | wc -l | tr -d ' ') open Dependabot PR(s)."
    echo ""
    echo "Step 1: classify"
    local STALE=() REAL=() CLEAN=()
    for pr in $prs; do
        local base dev fails
        base=$(gh pr view "$pr" --repo "$owner_repo" --json baseRefOid --jq '.baseRefOid' | head -c 7)
        dev=$(gh api "repos/${owner_repo}/commits/develop" --jq '.sha' | head -c 7)
        fails=$(gh pr checks "$pr" --repo "$owner_repo" --json state,name \
            --jq '[.[] | select(.state=="FAILURE") | .name] | unique | join(",")' 2>/dev/null)
        if [[ -z "$fails" ]]; then
            CLEAN+=("$pr")
        elif [[ "$base" != "$dev" ]]; then
            STALE+=("$pr")
        else
            REAL+=("$pr:$fails")
        fi
    done
    echo "  CLEAN: ${CLEAN[*]:-none}"
    echo "  STALE (will rebase): ${STALE[*]:-none}"
    echo "  REAL failures: ${REAL[*]:-none}"

    if [[ ${#STALE[@]} -gt 0 ]]; then
        echo ""
        echo "Step 2: rebase STALE"
        for pr in "${STALE[@]}"; do
            info "@dependabot rebase on #${pr}"
            gh pr comment "$pr" --repo "$owner_repo" --body "@dependabot rebase" >/dev/null
        done
        info "Waiting 60s for rebases + CI to kick off..."
        sleep 60
    fi

    echo ""
    echo "Step 3: merge clean PRs"
    local to_merge=("${CLEAN[@]}" "${STALE[@]}")
    local merged=0
    for pr in "${to_merge[@]}"; do
        # Skip if something made this un-mergeable
        local ms
        ms=$(gh pr view "$pr" --repo "$owner_repo" --json mergeable --jq '.mergeable')
        if [[ "$ms" != "MERGEABLE" ]]; then
            warn "skip #${pr}: mergeable=${ms} (will need manual rebase)"
            continue
        fi
        if gh pr merge "$pr" --repo "$owner_repo" --merge --delete-branch >/dev/null 2>&1; then
            info "merged #${pr}"
            merged=$((merged + 1))
        else
            warn "merge failed on #${pr} (may need manual inspection)"
        fi
        sleep 1
    done
    info "Merged ${merged}/${#to_merge[@]} cleanly."

    if [[ ${#REAL[@]} -gt 0 ]]; then
        echo ""
        echo "Step 4: REAL failures left for manual review"
        for entry in "${REAL[@]}"; do
            echo "  #${entry%%:*}  fails=${entry#*:}"
        done
    fi

    echo ""
    echo "Done. Remaining open Dependabot PRs:"
    gh pr list --repo "$owner_repo" --author "app/dependabot" --state open \
        --json number,title --jq '.[] | "  #\(.number) \(.title | .[:70])"' \
        || true
}

# ─────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────

if [[ $# -eq 0 ]]; then
    cmd_help
    exit 0
fi

cmd="$1"; shift
case "$cmd" in
    help|-h|--help)        cmd_help ;;
    status)                cmd_status "$@" ;;
    verify)                cmd_verify "$@" ;;
    commit)                cmd_commit "$@" ;;
    push)                  cmd_push "$@" ;;
    merge-dev)             cmd_merge_dev "$@" ;;
    merge-main)            cmd_merge_main "$@" ;;
    tag)                   cmd_tag "$@" ;;
    release)               cmd_release "$@" ;;
    dependabot-cleanup)    cmd_dependabot_cleanup "$@" ;;
    *)                     die "Unknown command: ${cmd}. Try: $0 help" ;;
esac
