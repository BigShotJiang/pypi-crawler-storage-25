# pygubernator Autonomy & Safety Backlog

Scope: close four capability gaps — safety rails, durable memory, autonomy patterns, skill packaging. Per-milestone commits. No backwards-compatibility constraint. Full Docker sandbox + `.pgpack` + scaffolding CLI.

**Design decisions (locked):**
- `RecordStore` protocol with in-memory and SQLAlchemy backends for audit/heartbeat/memory-access records.
- Extend existing `PolicyAssignment` model rather than replacing.
- Feature-flag new capabilities via optional extras (`pygubernator[safety]`, `pygubernator[autonomy]`, `pygubernator[packaging]`).
- Tests: unit (happy + error path) per new public function, plus one integration test per phase.

Status legend: `[ ]` pending · `[~]` in progress · `[x]` done · `[!]` blocked

---

## Phase 1 — Safety foundation

**Goal:** every tool call is policy-checked, audited, and budgeted.

### 1.1 RecordStore protocol
- [x] `src/pygubernator/records/_protocol.py` — `RecordStore` Protocol (`put`, `query`, `count`)
- [x] `src/pygubernator/records/_memory.py` — `InMemoryRecordStore`
- [x] `src/pygubernator/records/_sqlalchemy.py` — `SqlAlchemyRecordStore`
- [x] `src/pygubernator/records/__init__.py` — exports + `default_record_store()` factory
- [x] `src/pygubernator/db/models/generic_record.py` — SQL backing table
- [x] Unit tests `tests/unit/test_record_store.py` (11 tests)

### 1.2 Policy enforcer
- [x] `src/pygubernator/policy/__init__.py`
- [x] `src/pygubernator/policy/_decision.py` — `Decision` + `DecisionKind` StrEnum
- [x] `src/pygubernator/policy/_context.py` — `CallerContext`
- [x] `src/pygubernator/policy/_enforcer.py` — `PolicyEnforcer.check` + `with_extra_rules`
- [x] `src/pygubernator/policy/_rules.py` — allowlist, denylist, tag, rate-limit rules + registry
- [x] `src/pygubernator/policy/_loader.py` — `InMemoryPolicyLoader` + `SqlAlchemyPolicyLoader`
- [x] Unit tests `tests/unit/test_policy_enforcer.py` (15 tests)

### 1.3 Extend PolicyAssignment
- [x] Add `scope`, `priority`, `workflow_id` columns; `agent_id` nullable
- [x] Migration `20260416000000_add_safety_autonomy_tables.py`

### 1.4 Wire enforcer into ToolRegistry
- [x] `ToolRegistry.__init__` takes `policy_enforcer`, `audit_writer`, `budget_tracker`, `caller_context`
- [x] `execute()` runs enforcer → budget → tool → audit
- [x] Audit emitted on success, deny, require_approval, and error
- [x] `record_for` helper exposed for ad-hoc emitters

### 1.5 LLMAgent tool permission config
- [x] `LLMAgent` accepts `allowed_tools`, `denied_tools`, `workflow_id`, `user_id`, `tags`, `policy_enforcer`, `audit_writer`, `budget_tracker`
- [x] `_compose_enforcer` layers allow/deny on top of shared enforcer
- [x] `_configure_tool_registry` plumbs identity + safety into the tool registry
- [x] LLM token usage consumed against `BudgetTracker`

### 1.6 ToolCallAudit
- [x] `src/pygubernator/safety/_audit.py` — `ToolCallAuditRecord` + `ToolCallAuditWriter` (SQL + RecordStore backends)
- [x] `src/pygubernator/db/models/tool_call_audit.py` — SQLAlchemy model
- [x] Migration for new table (above)
- [x] Wired from registry

### 1.7 Secret redactor
- [x] `src/pygubernator/safety/_redactor.py` — key-pattern + value-pattern + env-literal redaction, recursive
- [x] Applied to params + output before persistence
- [x] Unit tests (5 cases)

### 1.8 RunBudget
- [x] `src/pygubernator/safety/_budget.py` — `RunBudget(max_tokens, max_tool_calls, max_cost_usd, max_duration_s)` + `BudgetTracker`
- [x] `BudgetExceeded` exception with kind/limit/consumed
- [x] Hook into LLMAgent (tokens via usage, tool calls via registry, duration via check)
- [ ] WorkflowEngine-level enforcement — deferred to Phase 3 (`meta.budget` YAML)

### 1.9 Sandboxed PythonExec
- [x] `src/pygubernator/safety/_sandbox.py` — `SubprocessSandbox` (rlimit CPU/AS/CORE, timeout, temp cwd, stdin env isolation, emit() harness)
- [x] `workflow/nodes/_python_exec.py` now accepts `sandbox: none | subprocess | docker`
- [x] Unit tests (5 cases: happy, failure, timeout, context, env isolation)

### 1.10 Integration test
- [x] `tests/integration/test_phase1_safety.py` — 6 scenarios covering deny + audit, budget halt, redaction, allowlist, subprocess sandbox happy + timeout

### 1.11 Milestone
- [x] Ruff + format clean for all Phase 1 files
- [x] `pytest` — 57 Phase 1 tests pass; 1620 existing unit tests still green
- [x] Commit: `feat(safety): phase 1 policy enforcement, audit, budget, sandbox`

---

## Phase 2 — Durable memory & context

**Goal:** agents resume across runs with structured notes and bounded context.

### 2.1 Memory scopes
- [x] `src/pygubernator/memory/_scope.py` — `MemoryScope` dataclass with canonical `to_key()` + `from_context()`
- [x] Used uniformly across context stores and audit records
- [ ] Legacy `workflow/nodes/_memory.py` backends still key by node-id; retrofitting deferred — not a blocker (`AuditingMemoryStore` wraps any legacy store and adds scope externally)

### 2.2 Agent context store
- [x] `src/pygubernator/memory/__init__.py`
- [x] `src/pygubernator/memory/_context_store.py` — `AgentContextStore` Protocol
- [x] `src/pygubernator/memory/_backends.py` — in-memory, file (JSON), RecordStore (append-only), SQLAlchemy

### 2.3 Run lifecycle hooks
- [x] `LLMAgent.on_run_start()` — loads scoped `ContextSurface` from the store
- [x] `LLMAgent.on_run_end()` — persists the surface (idempotent)
- [x] `context_store` + `context_key` constructor arguments on `LLMAgent`

### 2.4 MemoryAccessAudit
- [x] `src/pygubernator/memory/_audit.py` — `MemoryAccessAuditWriter` (SQL + RecordStore backends), `AuditingMemoryStore` decorator
- [x] Never-raising writer: audit failures are logged and swallowed
- [x] Decorator records `read_messages` + `add_messages` with scope + count

### 2.5 `context_surface` node
- [x] `src/pygubernator/memory/_surface.py` — `ContextSurface` (facts / questions / next_actions / log) with Markdown render + parse
- [x] `src/pygubernator/workflow/nodes/_context_surface.py` — node with `read`, `write`, `append`, `clear` ops
- [x] Registered in `workflow/_default_registry.py`
- [x] Pulls identity from `variables.__agent_id__` etc., overridable via YAML `scope:`

### 2.6 Cross-run compaction
- [x] `CompactingMemoryStore.summarize_old_runs(transcripts) -> digest` (folds multiple prior runs into one note via the LLM)
- [ ] Auto-trigger threshold from agent hook — deferred (available as explicit call for now)

### 2.7 Unit tests
- [x] `tests/unit/test_memory_scope.py` (7)
- [x] `tests/unit/test_context_store.py` (14)
- [x] `tests/unit/test_context_surface.py` (9)
- [x] `tests/unit/test_context_surface_node.py` (7)
- [x] `tests/unit/test_memory_audit.py` (3)

### 2.8 Integration test
- [x] `tests/integration/test_phase2_memory.py` — 6 scenarios covering cross-run persistence, scope isolation, digest generation, audit trail, Markdown rendering

### 2.9 Milestone
- [x] Ruff + format clean
- [x] 1660 unit tests pass (40 new + prior 1620); 6 integration tests pass
- [x] Commit: `feat(memory): phase 2 scoped memory, context surface, run lifecycle`

---

## Phase 3 — Autonomy patterns

**Goal:** unattended agents that watch, drain queues, heartbeat, and fan out.

### 3.1 `watch_and_act` node
- [x] `src/pygubernator/workflow/nodes/_watch.py` with expression / callable condition, `poll_interval_s`, `max_cycles`, `stop_condition`
- [x] Emits heartbeat each cycle via `variables.__heartbeat__`
- [x] Action resolution via `module:function` or `var:name` references
- [x] Unit tests (7)

### 3.2 `inbox_consumer` node
- [x] `src/pygubernator/workflow/nodes/_inbox.py`
- [x] `InboxSource` protocol with `fetch(batch_size)` + `ack(item, success=)`
- [x] Config: `source`, `handler`, `batch_size`, `max_batches`, `ack_policy` (`at_least_once` / `at_most_once`)
- [x] Handler may be sync or async and return bool or `{"success": …}` dict
- [x] Unit tests (5)

### 3.3 Agent heartbeat
- [x] `src/pygubernator/autonomy/__init__.py`
- [x] `src/pygubernator/autonomy/_heartbeat.py` — `HeartbeatEmitter`, `HeartbeatWriter`, `StaleAgentDetector`, `HeartbeatRecord`
- [x] `src/pygubernator/db/models/agent_heartbeat.py` (Phase 1 migration already created the table)
- [x] Writer backed by SQL table *or* RecordStore fallback
- [x] Background thread emitter with on-start initial beat + clean stop
- [ ] API endpoint `/api/v1/agents/heartbeats` — deferred (see gap)

### 3.4 Workflow-level budget
- [x] `WorkflowEngine` checks `variables["__budget__"]` between topological levels via `_check_run_budget`
- [x] `RunBudget.from_dict` constructs a budget from YAML / caller metadata
- [ ] Explicit `meta.budget` YAML block wiring — deferred (callers pass budget via `variables` today)

### 3.5 Fan-out / fan-in
- [x] `src/pygubernator/workflow/nodes/_parallel.py` — `parallel` node (concurrent map with bounded concurrency, optional fail-fast)
- [x] Same file adds `join` node (`all`, `any`, `first_n` strategies)
- [x] Registered in default registry
- [x] Unit tests (8)

### 3.6 Unit tests
- [x] `tests/unit/test_watch_node.py` (7)
- [x] `tests/unit/test_inbox_node.py` (5)
- [x] `tests/unit/test_heartbeat.py` (11)
- [x] `tests/unit/test_parallel_join.py` (8)

### 3.7 Integration test
- [x] `tests/integration/test_phase3_autonomy.py` — parallel summarize → context_surface note → watch loop with heartbeats per cycle → engine-level budget halt (5 tests)

### 3.8 Milestone
- [x] Ruff + format clean
- [x] 1691 unit tests pass; 5 Phase-3 integration tests pass
- [x] Commit: `feat(autonomy): phase 3 watch, inbox, heartbeat, parallel`

---

## Phase 4 — Skill packaging

**Goal:** `pip install pygubernator-research-pack` → working workflow.

### 4.1 Tool-bundle entry points
- [x] `pygubernator.packaging._bundles.discover_tool_bundles(registry)` walks the `pygubernator.tools` entry-point group, invokes callable targets (`register(registry)`) or `register_module()` for module targets
- [x] Errors from third-party bundles are logged and swallowed
- [x] Unit tests with fake entry points (3)

### 4.2 Tool manifest schema
- [x] `src/pygubernator/packaging/_manifest.py` — `PackManifest` dataclass with name, version, kind, tools, workflows, permissions, env_vars, cost_estimate_usd, pygubernator, extras
- [x] Validation (slug name, SemVer version, enumerated kind, type-coerced cost, list-or-scalar normalization)
- [x] Unit tests `test_pack_manifest.py` (10)

### 4.3 Manifest loader
- [x] `load_manifest` accepts `Path`, YAML string, or dict
- [x] Friendly `PackManifestError` on parse / validation failures

### 4.4 Workflow pack format `.pgpack`
- [x] `src/pygubernator/packaging/_pack.py` — zip layout `manifest + workflows/ + tools/`
- [x] `install_pack`, `list_packs`, `uninstall_pack`, `pack_directory`
- [x] Default home: `~/.pygubernator/packs/`
- [x] Zip-slip protection + common-prefix stripping
- [x] SHA-256 checksum per archive surfaced on the returned `InstalledPack`
- [x] Unit tests `test_pack_install.py` (10)

### 4.5 Pack CLI
- [x] `src/pygubernator/cli/_pack.py` with `install`, `list`, `remove`, `build` subcommands
- [x] Integrated into `pygubernator pack` via the main CLI dispatcher

### 4.6 Scaffolding CLI
- [x] `src/pygubernator/cli/_new.py` with `new tool <name>` and `new pack <name>`
- [x] Templates in the CLI module (no separate templates dir needed for the MVP)
- [x] Unit tests `test_new_cli.py` (4)

### 4.7 Docker sandbox
- [x] `src/pygubernator/safety/_sandbox_docker.py` — `DockerSandbox` with `image`, `timeout_s`, `max_memory_mb`, `cpus`, network toggle, optional pull
- [x] `python_exec` node routes `sandbox: docker` through this class
- [x] Requires `pygubernator[packaging]` extra (adds `docker>=7.0.0`)
- [x] Graceful fallback when SDK missing: returns a descriptive `SandboxResult` instead of crashing

### 4.8 Integration test
- [x] `tests/integration/test_phase4_packaging.py` — scaffold via CLI → archive → install → list → uninstall (3 tests)
- [ ] Docker container smoke test: not run in CI (requires Docker daemon); run manually via `pygubernator python_exec` with `sandbox: docker`

### 4.9 Milestone
- [x] Ruff + format clean
- [x] 1719 unit tests pass (+28 for Phase 4); 3 Phase 4 integration tests pass
- [x] Commit: `feat(packaging): phase 4 packs, manifests, scaffolding, docker sandbox`

---

## Phase 5 — Final robustness sweep

- [x] Full pytest suite passes (1750 tests — 1719 unit + 31 integration)
- [x] Ruff clean on every new module under `records/`, `safety/`, `policy/`, `memory/`, `autonomy/`, `packaging/`, new workflow nodes, and new CLIs
- [x] All new modules under 400 lines (largest: `safety/_sandbox.py` at 257; `packaging/_pack.py` at 267)
- [x] Capability matrix (below) written
- [x] `docs/guides/daily-research.md` walkthrough written
- [x] Gap log refreshed (see Discovered gaps section)
- [x] Commit: `docs: capability matrix + daily-research walkthrough`

---

## Capability matrix

| Area | Primitives | Entry points | Tests |
|---|---|---|---|
| Safety — policy | `PolicyEnforcer`, `Decision`, `CallerContext`, `AllowlistRule` / `DenylistRule` / `TagRule` / `RateLimitRule`, `InMemoryPolicyLoader` / `SqlAlchemyPolicyLoader` | `ToolRegistry.set_policy_enforcer`, `LLMAgent(policy_enforcer=, allowed_tools=, denied_tools=)` | 15 unit |
| Safety — audit | `ToolCallAuditWriter`, `ToolCallAuditRecord`, `SecretRedactor`, `RecordStore` + `InMemoryRecordStore` + `SqlAlchemyRecordStore` | `ToolRegistry.set_audit_writer`, `default_record_store` | 13 unit + 4 integration |
| Safety — budget | `RunBudget`, `BudgetTracker`, `BudgetExceeded` | `LLMAgent(budget_tracker=)`, `variables["__budget__"]` in `WorkflowEngine` | 8 unit + 2 integration |
| Safety — sandbox | `SubprocessSandbox` (POSIX rlimits), `DockerSandbox` (docker SDK) | `python_exec` node `sandbox: none / subprocess / docker` | 5 unit + 2 integration |
| Memory — scoped context | `MemoryScope`, `AgentContextStore` + `InMemoryContextStore` / `FileContextStore` / `RecordStoreContextStore` / `SqlAlchemyContextStore`, `ContextSurface` | `LLMAgent.on_run_start/on_run_end`, `context_surface` node | 30 unit + 3 integration |
| Memory — audit | `MemoryAccessAuditWriter`, `AuditingMemoryStore` | Decorator around any `MemoryStore` | 3 unit + 1 integration |
| Memory — compaction | `CompactingMemoryStore.summarize_old_runs` | Explicit call from `on_run_end` | 1 integration |
| Autonomy — heartbeat | `HeartbeatEmitter`, `HeartbeatWriter`, `HeartbeatRecord`, `StaleAgentDetector` | `variables["__heartbeat__"]` | 11 unit + 1 integration |
| Autonomy — watch | `WatchAndActNode`, callable / expression / var: dispatch | `watch_and_act` node | 7 unit |
| Autonomy — inbox | `InboxConsumerNode`, `InboxSource` protocol, ack policies | `inbox_consumer` node | 5 unit |
| Autonomy — fan-out/in | `ParallelNode`, `JoinNode` | `parallel`, `join` nodes | 8 unit + 1 integration |
| Packaging — manifest | `PackManifest`, `load_manifest`, `PackManifestError` | YAML loader | 10 unit |
| Packaging — packs | `install_pack`, `list_packs`, `uninstall_pack`, `pack_directory`, `InstalledPack` | `pygubernator pack {install,list,remove,build}` | 10 unit + 3 integration |
| Packaging — bundles | `discover_tool_bundles` | `pygubernator.tools` entry-point group | 3 unit |
| Packaging — scaffolding | `new tool`, `new pack` templates | `pygubernator new {tool,pack}` | 4 unit |

Aggregate: 1719 unit + 31 integration tests pass end-to-end.

---

## Discovered gaps (grow this as implementation reveals new issues)

- **WorkflowEngine-level budget (Phase 1 → rolled into Phase 3 §3.4):** LLMAgent now honours a shared `BudgetTracker`, but the engine itself doesn't attach one per run. Addressed when Phase 3 adds `meta.budget` YAML.
- **Approval-required decisions are terminal, not interactive (Phase 1):** `require_approval` currently short-circuits the tool call with a failure. A real approval workflow would queue the call and resume on approval. Out of scope for Phase 1; revisit in Phase 3 alongside watch/approve loops.
- **Column-level `index=True` collides with explicit `Index(...)` declarations (Phase 1 discovered during test run):** resolved by removing the column-level flag. Follow similar convention in new Phase 2+ models.
- **Legacy memory stores (Phase 2):** `workflow/nodes/_memory.py` backends still key by node-id; new `MemoryScope` is layered on top via `AuditingMemoryStore`. A deeper retrofit (scope-aware SQL columns in memory tables) is deferred because all persistent memory backends are optional and swapping them would require a parallel migration.
- **Auto-triggered cross-run compaction (Phase 2):** `summarize_old_runs` is available but not auto-invoked by `on_run_end`. A token-budget-driven trigger that loads prior-run transcripts, calls digest, and replaces them is deferred — callers can wire the trigger explicitly today.
- **`meta.budget` YAML wiring (Phase 3):** engine checks `variables["__budget__"]` between levels, and `RunBudget.from_dict` parses a budget from a dict, but the YAML loader doesn't yet populate `variables["__budget__"]` from a `meta: { budget: ... }` block automatically. Callers pass the tracker via `variables` today.
- **Heartbeat REST surface (Phase 3):** `HeartbeatWriter.latest_for` + `StaleAgentDetector` exist but the FastAPI router doesn't expose them yet. Deferred because the control plane is optional — add a `GET /api/v1/agents/heartbeats` route when it's needed. **Closed 2026-04-24** via `feat/heartbeats-route` — now live at `GET /api/v1/agents/heartbeats` with a UI liveness dot on agent detail.

---

## Phase R — Foundation refactor (unblocks Phase 6)

**Goal:** eliminate structural debt in files that Phase 6 will touch so the
new features land cleanly. Behaviour preserved across every PR; tests must
stay green. Derived from a 2026-04-24 backend + UI audit.

### R.1 Clean up routes_agents.py
- [x] Migrate raw `raise HTTPException` calls to `raise_logged_*`
      helpers — done in earlier sweeps; `grep raise HTTPException
      src/pygubernator/api/routes_agents.py` is empty as of this
      audit. *(R.1)*
- [x] Extract the repeated spec-compile pattern into
      `_compile_agent_spec_or_400(spec_path, spec_json,
      log_event, public_detail)` — collapses the
      load-or-parse-then-compile-then-rescue-`ConfigError` block
      that lived in `get_agent_spec_detail`,
      `create_agent_from_spec`, `create_agent_version` (path or
      json branch), and `publish_agent_spec`. *(R.1)*
- [x] Response shape identical; existing 32 agent-route tests pass
      unchanged. *(R.1)*

### R.2 Split WorkflowEditorSidebar.tsx + unify agent catalog
- [x] `ComponentsPanel`, `WorkflowBrowserPanel`,
      `AgentSidebarPanel`, `ToolSidebarPanel` already live in
      `src/pygubernator/ui/src/components/workflows/sidebar/` — the
      original 211-line `WorkflowEditorSidebar.tsx` is the slim shell
      that delegates to them. *(R.2)*
- [x] Promoted the duplicated agent-catalog fetch into
      `AgentEditorStore.loadCatalog`. Module-level dedupe via
      `catalogInflight` guarantees a single in-flight
      `GET /api/v1/agents` even when the sidebar and a node-config
      picker mount in parallel. `AgentRegistryPicker` reads from the
      store; `AgentSidebarPanel` calls `loadCatalog({ force: true })`
      after its own paginated browse so node-config pickers see
      fresh data. *(R.2)*
- [x] Sidebar keyboard nav + collapsed-state behaviour unchanged.
      *(R.2)*

### R.3 Split AgentRegistryDetailView.tsx
- [x] `SpecVersionForm` and `AgentVersionDetailCard` (the
      "VersionDetail" the BACKLOG asked for) already live in their
      own files (``components/agents/forms/SpecVersionForm.tsx``,
      ``components/agents/AgentVersionDetailCard.tsx``). New
      ``components/agents/forms/VersionLifecycleActions.tsx``
      extracts the Set-active / Deactivate / Delete button row from
      the inline JSX in the Versions table; new
      ``components/agents/forms/InlineVersionForm.tsx`` extracts
      the full provider-preset → model → API-base / API-key →
      prompt manual form (~120 lines that previously lived inline).
      *(R.3)*
- [x] Consolidated the inline-version-form state cluster into a
      single ``useReducer``: replaced six sibling ``useState`` calls
      (``newVersion``, ``newModel``, ``newPrompt``, ``newProviderName``,
      ``newApiBase``, ``newApiKey``) with one
      ``inlineVersionFormReducer`` whose ``select_provider`` action
      atomically updates the three preset-derived fields so the UI
      never flashes a half-applied preset. 6 vitest cases pin the
      transitions. *(R.3)*
- [x] Phase 6's artifacts surface ended up landing on the Runs
      detail page (§6.1), not on the Agent registry detail view, so
      the "shell for Phase 6 Artifacts tab" item is moot. The
      registry detail file shrunk from 1,080 → 936 lines and the
      remaining surface area is mostly handler functions + JSX for
      the existing identity / settings / enqueue / policies / audit
      cards, which read cleanly now that the new-version section
      delegates to dedicated components. *(R.3)*

### R.4 Migrate all routes to raise_logged_* helpers
- [x] R.4a — `routes_workflows.py` + `routes_runs.py`. *(complete)*
- [x] R.4b — `routes_observability.py`, `routes_chat.py`,
      `routes_kb.py`, `routes_notifications.py`. *(complete)*
- [x] R.4c — remaining route files. *(complete)*
- [x] End state confirmed by audit: the only remaining
      `raise HTTPException` call sites are inside
      `api/_http_errors.py` itself (the helpers' implementation —
      correct) and `api/deps.py` (auth-dependency 401/403s that need
      the `WWW-Authenticate` headers parameter — exempted). All
      other routes go through `raise_logged_*`.

### R.5 Shared route helpers (api/_routes_common.py)
- [x] New `api/_routes_common.py` carries
      `paginated_response(items, total, *, page, page_size, model=None)`
      (canonical `{items, meta}` envelope; optional Pydantic model
      runs each row through `model_validate(...).model_dump()`),
      `emit_audit(store, actor, action, *, resource_type,
      resource_id, details=None)` (wraps the
      `actor=actor["username"]` boilerplate), and
      `workspace_id_of(store)` (single source of truth for the
      `getattr(store, "workspace_id", "default")` fallback). 10
      unit tests in `tests/unit/test_routes_common.py`. *(R.5)*
- [x] Migrated **8 route files** to use the helpers:
      `routes_agents.py`, `routes_library_testing.py`,
      `routes_observability.py`, `routes_policies.py`,
      `routes_runs.py`, `routes_templates.py`, `routes_tools.py`,
      and `routes_workflows.py` (which also picks up
      `workspace_id_of`). 32 audit call sites now go through
      `emit_audit`; 4 paginated list routes now go through
      `paginated_response`. *(R.5)*

### R.6 Quick wins
- [x] Pystator forms already split: each remote form lives in its own
      file under
      `src/pygubernator/ui/src/components/workflows/config-forms/stator/`
      (`PystatorApplyDataNodeForm`, `PystatorEntityCreateNodeForm`,
      `PystatorEntityEventNodeForm`, `PystatorProcessNodeForm`,
      plus the local form at `PystatorLocalNodeForm.tsx`).
- [x] `ThemeFromConfig` + `ApiUnavailableBanner` already use
      `apiUrl()` to build URLs. The retained raw `fetch()` is
      intentional — both pages run pre-login and must skip the
      auth-injecting `apiGet` helper; the comment in
      `ThemeFromConfig.tsx` documents this.

### Deferred (revisit when the file is touched for a Phase 6 feature)
- **R.7** — `workflow/_metadata.py` refactor (2,698 lines). The 1,973-line
  `get_builtin_node_type_descriptions()` is declarative data; move to YAML
  config or split by node-type domain. Revisit when Phase 6 §6.7 or §6.1
  adds new node types.
- **R.8** — Split `routes_workflows.py` (1,457 lines) into CRUD, runs,
  replay. Revisit alongside Phase 6 §6.6 (live DAG animation).
- **R.9** — `execute_workflow()` function split (336-line core engine
  function). Risky; revisit when Phase 6 §6.7 Guide needs to extend it.

### R.10 Milestone
- [x] Ruff + format clean on every touched file (enforced by the
      pre-commit `ruff` + `ruff-format` hooks; PR-A through PR-C
      both passed clean).
- [x] Full backend suite green after each sub-PR — PR-A 2405 passed,
      PR-B 2415 passed, PR-C unchanged (no backend code touched).
- [x] UI tsc + vitest + build clean after each sub-PR — PR-A 214
      tests, PR-C 220 tests, all green.
- [x] No behaviour changes — every helper round-trips byte-identical
      audit rows / response shapes; the React refactors only swap
      JSX subtrees and consolidate state without touching any
      mutation flow.

---

## Phase 6 — UX Uplift (System2-inspired, DAG-native)

**Goal:** make pygubernator the best DAG-native multi-agent orchestrator
to watch, inspect, and consume. Patterns adapted from System2's analyst
workbench while keeping the DAG engine, Python backend, and replay /
audit contracts unchanged. See `docs/reference/system2-comparison.md`
(to be authored in 6.12) for the source comparison.

### 6.1 Artifact surface (typed renderers + live-reload)
- [x] New `WorkflowArtifact` model + `workflow_artifacts` table (Alembic
      migration `20260424000000_add_workflow_artifacts`) *(§6.1a)*
- [x] `emit_artifact(type, content_or_path, title=..., mime=...)` helper +
      `update_artifact_content(...)` for streaming updates *(§6.1a)*
- [x] Routes: `GET /api/v1/workflows/runs/{id}/artifacts` (list,
      step-filterable) and `GET
      /api/v1/workflows/runs/{id}/artifacts/{artifact_id}/content`
      (inline text or base64 binary, size-capped) *(§6.1a)*
- [x] Route: `POST /api/v1/workflows/runs/{id}/artifacts/{aid}/query`
      — sandboxed read-only executor backed by an in-memory SQLite with
      `set_authorizer` denying every non-SELECT action at
      statement-planning time; row cap + timeout via progress handler;
      CSV loader with safe-identifier column names. UI
      `ArtifactQueryPanel` mounts below CSV artifacts. *(§6.1a-query)*
- [x] SSE events `artifact_created` / `artifact_updated` on the run channel
      — summaries only, content bodies never leak onto the channel *(§6.1a)*
- [x] UI `ArtifactViewer` component with type-dispatched renderers:
      markdown (minimal, dep-free), table/csv (RFC-4180 parser), html
      (sandboxed iframe, all sandbox flags off for defence-in-depth),
      image (data: URL from base64 or UTF-8), json (pretty-printed),
      text (plain fallback). `notebook` artifacts fall through to the
      text renderer until a dedicated nbformat renderer lands. *(§6.1b)*
- [x] Run-level "Run artifacts" card on the Runs detail page +
      step-level `ArtifactList` inside `StepDetailPanel` (hidden when
      empty so steps that didn't emit anything stay uncluttered) *(§6.1b)*
- [x] SSE `artifact_created` / `artifact_updated` events drive a
      monotonic refresh nonce so both lists re-fetch without a polling
      timer *(§6.1b)*
- [x] Unit tests: model round-trip, sequence monotonicity, route list +
      content (text inline / utf-8 disk / base64 binary / size cap / 404
      cross-run), `emit_artifact` + `update_artifact_content` SSE
      broadcasts *(§6.1a)*
- [x] Unit tests: renderer dispatch, CSV parser (RFC-4180 quoting +
      CRLF), image data URL building, iframe sandbox flags (frozen to
      empty / no ``allow-scripts``), JSON pretty-print round-trip *(§6.1b)*
- [x] Unit tests: SQL sandbox rejects DML/DDL via the SQLite
      authorizer (parametrised matrix covering INSERT / UPDATE /
      DELETE / DROP TABLE / CREATE TABLE / ALTER TABLE / PRAGMA /
      ATTACH / smuggled mutations / multi-statement) plus happy
      paths (SELECT / aggregates / CTEs / EXPLAIN), input validation,
      result truncation, safe column-name coercion, and route
      integration *(§6.1a-query)*

### 6.2 ActiveAgentsPanel (fleet view)
- [x] `/api/v1/agents/heartbeats` response carries `current_run_id`,
      `current_node_id`, `context_used_tokens` (sourced from
      `HeartbeatRecord.details`) plus the joined `agent_name`.
- [x] `HeartbeatEmitter.status_provider` convention documented in the
      route + tests so workflow-spawned agents populate those keys.
- [x] UI: `<ActiveAgentsPanel>` mounted on Runs page (run-scoped on
      detail view, fleet-wide on list view). Polls every 10s.
- [x] Row interactions: pulse dot (green/amber/red), context usage,
      run/node ids surfaced.

### 6.3 Step trace with expandable detail
- [x] Route: `GET /api/v1/workflows/runs/{run_id}/steps/{step_id}/events`
      returns full `payload_json` per event from `workflow_step_events`
      with a legacy-blob fallback.
- [x] `AgentTraceSection` rows became disclosure blocks — `<AgentTraceRow>`
      with chevrons, pretty-printed JSON payload, and the full
      `event.raw` accessible on expand.
- [x] "Copy as JSON" affordance on every expanded row.

### 6.4 Thinking-block streaming
- [x] New `AgentEventType.LLM_THINKING_DELTA` event type + SSE mapping
      `llm_thinking_delta` *(§6.4a)*
- [x] `StreamChunk` carries a `thinking_delta` field; OpenAI-compat
      `_parse_stream_chunk` extracts from `reasoning_content` (OpenAI
      o1-family) and `reasoning` / `thinking` (Anthropic via LiteLLM),
      unwrapping nested `{content|text}` dicts defensively *(§6.4a)*
- [x] `LLMAgent` accepts `emit_thinking: bool = False`; streaming loop
      emits `LLM_THINKING_DELTA` when a chunk carries reasoning and the
      flag is enabled *(§6.4a)*
- [x] `emit_thinking` wired through `build_llm_agent` →
      `workflow/nodes/_agent.py` + `_dispatch_agent.py` so agent nodes
      can opt in via config *(§6.4a)*
- [x] `validate_agent_config` rejects non-boolean `emit_thinking`
      values with a descriptive error *(§6.4a)*
- [x] UI: thinking entries render italic + muted with a 💭 marker
      inside the existing agent-trace disclosure rows. `useWorkflowSSE`
      carries the `llm_thinking_delta` SSE type; the live accumulator
      concatenates consecutive deltas per iteration into a single
      entry so the trace stays readable even for verbose reasoning.
      Expanded view shows the aggregated thinking text verbatim (not
      the raw JSON) in an italic muted preformat block. *(§6.4b)*

### 6.5 Resizable split-pane layouts
- [x] New `ResizableSplitPane` component (horizontal, localStorage persistence,
      responsive stacking on narrow viewports)
- [x] Runs detail view adopts split-pane (DAG + steps | schedule + step detail)
- [x] Persist pane-size preferences in localStorage
- [ ] Chat page (thread | artifact viewer) — deferred until §6.1 lands an
      artifact surface worth pairing with the thread

### 6.6 Live DAG animation + agent-lane overlay
- [x] Pulse animation on nodes currently executing (amber pulse ring +
      ping-dot indicator + "running…" / "waiting" label for
      running/pending states). Driven by the same SSE-refreshed step
      status the DAG already renders — no new data needed. *(§6.6a)*
- [x] `DAG_RUNNING_STATUSES` frozen set exported + unit-tested so the
      UI stays in sync if the backend adds a new in-flight status
      *(§6.6a)*
- [x] Agent badge on `agent` / `dispatch_agent` / `llm` /
      `llm_planner` nodes: backend `build_step_input_summary` helper
      records `{name, version, model, target_agent_id}` into
      `step.input_json["agent"]` at persist time; UI `extractStepAgent`
      lifts it and renders a sky-coloured chip on DAG nodes + a richer
      callout in `StepDetailPanel`. *(§6.6b)*
- [x] Edge annotations + real graph layout. New pure helper
      `lib/dag-layout.ts` lays the spec out by longest-path-from-source
      (Kahn topo sort, deterministic row ordering); ``WorkflowRunDag``
      switches to a CSS-Grid layered render with an absolutely-
      positioned SVG overlay drawing real Bezier edges via measured
      node ``getBoundingClientRect``s. Each edge carries a hover
      tooltip with the source/target handle names + a JSON preview of
      the source step's `output_json`. The runs page fetches the
      run's matching workflow version once via
      `listWorkflowVersions` and falls back to the prior flat
      timeline when the spec hasn't loaded so live runs are never
      blanked out. *(§6.6c)*
- [x] Branch highlighting on condition/switch nodes. Edge classifier
      uses each step's `output_handle` to mark every spec edge as
      ``"fired"`` (source ran with this exact handle), ``"skipped"``
      (source ran but picked a different handle), or ``"pending"``
      (source has not committed an output yet). The three states
      render with distinct stroke widths, colours, and dash patterns
      plus an inline legend. *(§6.6c)*

### 6.7 Guide conversational orchestrator
- [x] New node type `llm_planner` — takes user message + workflow
      catalog, returns `workflow_id + args` via the `dispatch` output
      handle, or `reply` / `unresolved` when no workflow fits.
      Tolerant JSON parser (accepts markdown-fenced output, alias
      keys, non-dict ``args``), catalog rendered as Markdown bullets
      for the LLM, catalog from upstream edge overrides config, safe
      provider plumbing mirrors `LLMNodeFactory`. *(§6.7a)*
- [ ] New built-in agent `guide` (ships with package, opt-in) that
      dispatches runs and streams results back through chat *(§6.7b)*
- [x] New UI page `/guide` — chat-style thread + workflow picker on
      the left (`ResizableSplitPane` from §6.5), runs panel + artifact
      viewer on the right (reuses §6.1b `ArtifactList`). Dispatches
      via `dispatchGuideRun` with `trigger="guide"` and a stable
      localStorage-backed `correlation_id`; runs panel polls
      `listGuideRuns(correlation_id)` every 4s. "New chat" mints a
      fresh session. *(§6.7c)*
- [x] Server-side planner route `POST /api/v1/guide/plan` (in
      `routes_guide.py`). Wraps `parse_planner_response` from the
      `llm_planner` node so the route's output matches what a DAG
      sees. Catalog defaults to the workspace's workflows when
      omitted; provider config layered as request body → env vars
      (`PYGUBERNATOR_GUIDE_PLANNER_MODEL` / `_API_BASE` / `_API_KEY`)
      → 503 (so the operator's choice of default LLM is explicit).
      Returns a `decision` discriminator (`dispatch` / `reply` /
      `unresolved`) plus the structured fields. Guide page gains a
      "Manual / Auto" routing toggle: Auto calls the planner, runs
      the suggested workflow on `dispatch`, posts the LLM's reply
      verbatim on `reply`, and shows a clarifying message on
      `unresolved`. The manual picker stays the default for
      operators without a planner LLM configured. *(§6.7d)*
- [x] Guide-initiated runs tagged with `trigger="guide"` and a
      `correlation_id` tying the chat thread to its runs. Migration
      `20260425000000_add_workflow_run_trigger` adds both columns
      (nullable + indexed); `WorkflowExecuteRequest` / `WorkflowRunOut`
      surface them; `list_workflow_runs` + `/runs/list` route gain
      `trigger` and `correlation_id` filter query params. *(§6.7b)*
- [ ] Guide-dispatched runs honour `PolicyEnforcer` + `RunBudget` like
      any other run — covered by existing enforcer plumbing; no new
      code needed (Guide uses the normal `/execute` route)
- [ ] Integration test: chat intent → planner → run → artifact
      surfaced back in chat *(§6.7d, end-to-end after planner route)*

### 6.8 Session grouping for runs (surface existing columns)
- [x] `GET /api/v1/workflows/runs/sessions` returns paginated
      cross-workflow session summaries (session_id, workflow_name,
      run_count, last_run_at, last_status) *(§6.8a)*
- [x] `list_workflow_runs` gained a `session_id` filter + query param
      so the Runs list can drill from sidebar → session runs *(§6.8a)*
- [x] UI: `<SessionsSidebar>` collapsible left column on the Runs list
      page, click-to-filter, "All runs" reset row, colour-coded status
      pip, "Show more" pagination *(§6.8a)*
- [x] Breadcrumb on the run-detail page when `run.session_id` is set:
      `<RunBreadcrumb>` fetches the session's user-supplied name and
      links back to the Sessions-filtered Runs list. *(§6.8b)*
- [x] Rename session: new `workflow_sessions` metadata table
      (migration `20260426000000_add_workflow_sessions`); routes
      `GET / PATCH /api/v1/workflows/runs/sessions/{session_id}/meta`;
      `list_all_workflow_sessions` joins the metadata so the sidebar
      surfaces `name` directly; inline pencil → edit → save UX in
      `<SessionsSidebar>`. Empty string clears the name. *(§6.8b)*

### 6.9 Knowledge panel
- [x] `GET /api/v1/memory/scopes` listing every `MemoryScope` that has
      a saved `context_surface` (one row per distinct scope, decoded
      into component ids so the UI doesn't re-parse the composite key).
      *(§6.9)*
- [x] `GET /api/v1/memory/surface` (query-param scope) returning the
      `ContextSurface` dict + a Markdown rendering ready for the editor.
      *(§6.9)*
- [x] `PUT /api/v1/memory/surface` round-tripping posted Markdown
      through `ContextSurface.from_markdown` so the editor's output
      matches what an agent reads programmatically. *(§6.9)*
- [x] UI: `Knowledge → Notebooks` page (`/knowledge/notebooks`,
      sibling of the existing KB-chunk browser) with scope list,
      new-scope form, and dirty-tracked Markdown editor. *(§6.9)*
- [ ] Git-tracked mode (opt-in, mirrors System2) via `FileContextStore`
      backed by a user-specified repo path *(deferred to v1.1 — needs
      a separate sync/conflict UX; the in-DB editor lands first)*

### 6.10 Narrator-pattern scheduled summarizer (closes gap #4)
- [x] New `workflow_session_summaries` table (migration
      `20260427000000_add_workflow_session_summaries`); repo +
      store: `create_workflow_session_summary`,
      `list_workflow_session_summaries` (newest first, limit-bound).
      *(§6.10)*
- [x] Routes: `GET / POST /api/v1/workflows/runs/sessions/{id}/summaries`.
      `generated_by` defaults to the calling actor when omitted so
      summaries stay auditable. *(§6.10)*
- [x] UI: `<SessionSummariesPanel>` mounted on the run-detail page
      when `run.session_id` is set — collapsible card that lists
      summaries newest-first, lets the user append a manual one
      inline. *(§6.10)*
- [ ] On-schedule narrator agent that auto-writes summaries —
      deferred to v1.1; v1 storage is generic enough that a manual
      `agent` workflow node + scheduled trigger can write summaries
      today without further plumbing. The agent ships as soon as
      the default-LLM-provider config approach (shared with §6.7d)
      lands.
- [x] Explicit opt-in: no default scheduler enabled — summaries
      only appear when something (manual UI, future narrator,
      user workflow) explicitly POSTs them. *(§6.10)*

### 6.11 Milestone
- [x] Ruff + format clean on every Phase 6 file (enforced by the
      pre-commit `ruff` hook; pre-push CI parity gate runs
      `ruff format --check` + `ruff check` on every push). *(§6.11)*
- [x] Each sub-item shipped as its own PR merged to develop (§6.1
      through §6.10 + §6.6c). *(§6.11)*
- [x] User-visible docs: `docs/guides/agent-workbench.md` — tour of
      the runs detail, sessions sidebar, Guide page, knowledge
      notebooks, and the active-agents panel, with the SSE / replay
      contract that ties them together. Linked from the MkDocs nav
      under "Guides → Agent workbench". *(§6.11)*
- [x] CHANGELOG entry per PR — covered by the per-feature merge
      commit messages already on `develop`. *(§6.11)*

### 6.12 System2 comparison reference
- [x] `docs/reference/system2-comparison.md` — adopt / don't-adopt
      table for the System 2 patterns Phase 6 considered, the three
      translation principles (don't break replay; edit what the
      agent reads; surface the DAG, don't hide it), and the explicit
      "didn't adopt" list (single global persona, hidden thinking
      budget, tool-use side-channel, auto-replan-per-message,
      free-tier-by-default planner). Linked from the MkDocs nav
      under "Reference → System 2 comparison". *(§6.12)*
