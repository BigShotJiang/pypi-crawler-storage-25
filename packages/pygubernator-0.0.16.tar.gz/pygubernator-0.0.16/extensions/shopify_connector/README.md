# Shopify Connector Extension

`pygubernator-shopify-connector` adds Shopify source/sink factories through
entry points:

- `pygubernator.sources -> shopify`
- `pygubernator.sinks -> shopify`

After installing the package in the same environment as `pygubernator`, the
control-plane startup plugin discovery loads both connector types.

## Environment variables

- `PYGUBERNATOR_SHOPIFY_STORE_DOMAIN` (for example: `acme.myshopify.com`)
- `PYGUBERNATOR_SHOPIFY_ACCESS_TOKEN`
- `PYGUBERNATOR_SHOPIFY_API_VERSION` (optional, default `2025-01`)

## Example workflow node config

```yaml
nodes:
  pull_orders:
    type: source
    config:
      source_type: shopify
      source_config:
        store_domain: "${PYGUBERNATOR_SHOPIFY_STORE_DOMAIN}"
        access_token: "${PYGUBERNATOR_SHOPIFY_ACCESS_TOKEN}"
        resource: "orders"
        api_version: "${PYGUBERNATOR_SHOPIFY_API_VERSION}"
        params:
          status: "open"
          limit: "50"
```
