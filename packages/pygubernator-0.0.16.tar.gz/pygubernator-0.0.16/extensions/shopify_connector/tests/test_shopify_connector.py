from __future__ import annotations

from typing import Any

from pygubernator_shopify_connector.sink import FACTORY as SINK_FACTORY
from pygubernator_shopify_connector.sink import ShopifySink
from pygubernator_shopify_connector.source import FACTORY as SOURCE_FACTORY
from pygubernator_shopify_connector.source import ShopifySource


class _Resp:
    def __init__(self, payload: Any) -> None:
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> Any:
        return self._payload


def test_shopify_source_reads_records(monkeypatch) -> None:
    def _fake_get(*args, **kwargs):  # noqa: ANN002, ANN003
        return _Resp({"orders": [{"id": 1}, {"id": 2}]})

    import httpx

    monkeypatch.setattr(httpx, "get", _fake_get)
    source = ShopifySource(
        store_domain="acme.myshopify.com",
        access_token="token",
        resource="orders",
    )
    result = source.read()
    assert result.success is True
    assert result.records_read == 2
    assert result.source_type == "shopify"


def test_shopify_sink_upsert_create_when_id_missing(monkeypatch) -> None:
    calls: list[tuple[str, str]] = []

    class _Client:
        def __init__(self, **kwargs) -> None:  # noqa: ANN003
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
            return None

        def request(self, method: str, url: str, **kwargs):  # noqa: ANN003
            calls.append((method, url))
            return _Resp({})

    import httpx

    monkeypatch.setattr(httpx, "Client", _Client)
    sink = ShopifySink(
        store_domain="acme.myshopify.com",
        access_token="token",
        resource="orders",
        mode="upsert",
    )
    result = sink.send([{"name": "A"}], {})
    assert result.success is True
    assert result.records_sent == 1
    assert calls[0][0] == "POST"


def test_shopify_factories_expose_connector_specs() -> None:
    source_spec = SOURCE_FACTORY.spec
    sink_spec = SINK_FACTORY.spec

    assert source_spec is not None
    assert sink_spec is not None
    assert source_spec.kind == "source"
    assert source_spec.type_name == "shopify"
    assert "store_domain" in {field.key for field in source_spec.fields}
    assert sink_spec.kind == "sink"
    assert sink_spec.type_name == "shopify"
    assert "mode" in {field.key for field in sink_spec.fields}
