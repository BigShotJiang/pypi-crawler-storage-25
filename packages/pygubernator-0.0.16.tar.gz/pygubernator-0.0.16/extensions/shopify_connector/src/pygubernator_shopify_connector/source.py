"""Shopify source connector for pygubernator."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    ConnectorFieldSpec,
    ConnectorSpec,
)


def _normalize_store_domain(raw: str) -> str:
    domain = raw.strip().removeprefix("https://").removeprefix("http://")
    return domain.rstrip("/")


def _resource_endpoint(resource: str) -> str:
    base = resource.strip().strip("/")
    if not base:
        raise ValueError("resource must be non-empty")
    if not base.endswith(".json"):
        return f"{base}.json"
    return base


class ShopifySource:
    """Read Shopify resources using the Admin REST API."""

    def __init__(
        self,
        *,
        store_domain: str,
        access_token: str,
        resource: str = "orders",
        api_version: str = "2025-01",
        params: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._store_domain = _normalize_store_domain(store_domain)
        self._access_token = access_token.strip()
        self._resource = resource.strip() or "orders"
        self._api_version = api_version.strip() or "2025-01"
        self._params = dict(params or {})
        self._timeout = timeout

    def read(self) -> SourceResult:
        try:
            import httpx
        except ImportError as exc:
            raise SourceError(
                "httpx is required for ShopifySource",
                source_type="shopify",
            ) from exc

        endpoint = _resource_endpoint(self._resource)
        url = f"https://{self._store_domain}/admin/api/{self._api_version}/{endpoint}"
        headers = {
            "X-Shopify-Access-Token": self._access_token,
            "Accept": "application/json",
        }
        try:
            response = httpx.get(
                url,
                headers=headers,
                params=self._params,
                timeout=self._timeout,
            )
            response.raise_for_status()
            payload = response.json()
        except Exception as exc:
            raise SourceError(
                f"Shopify read failed: {exc}",
                source_type="shopify",
            ) from exc

        records = self._extract_records(payload)
        return SourceResult(
            success=True,
            records=records,
            records_read=len(records),
            source_type="shopify",
            metadata={
                "store_domain": self._store_domain,
                "resource": self._resource,
                "api_version": self._api_version,
            },
        )

    def close(self) -> None:
        """No-op."""

    def _extract_records(self, payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]

        if isinstance(payload, dict):
            if self._resource in payload and isinstance(payload[self._resource], list):
                return [
                    item for item in payload[self._resource] if isinstance(item, dict)
                ]
            singular = self._resource.rstrip("s")
            if singular in payload and isinstance(payload[singular], dict):
                return [payload[singular]]
            return [payload]

        raise SourceError(
            f"Unexpected Shopify payload type: {type(payload).__name__}",
            source_type="shopify",
        )


def _validate(config: dict[str, Any]) -> None:
    if not config.get("store_domain"):
        raise SourceError(
            "Shopify source requires 'store_domain'", source_type="shopify"
        )
    if not config.get("access_token"):
        raise SourceError(
            "Shopify source requires 'access_token'", source_type="shopify"
        )


def _build(config: dict[str, Any]) -> ShopifySource:
    return ShopifySource(
        store_domain=str(config["store_domain"]),
        access_token=str(config["access_token"]),
        resource=str(config.get("resource", "orders")),
        api_version=str(config.get("api_version", "2025-01")),
        params=config.get("params"),
        timeout=float(config.get("timeout", 30.0)),
    )


def _factory() -> Any:
    from pygubernator.connectors._source_registry import SourceFactory

    return SourceFactory(
        type_name="shopify",
        build=_build,
        validate=_validate,
        description="Reads records from Shopify Admin REST resources.",
        spec=ConnectorSpec(
            version=CONNECTOR_SPEC_V1,
            kind="source",
            type_name="shopify",
            display_name="Shopify",
            description="Read records from Shopify Admin REST resources.",
            fields=(
                ConnectorFieldSpec(
                    key="store_domain",
                    label="Store domain",
                    required=True,
                    description="Shop domain, e.g. acme.myshopify.com.",
                    placeholder="acme.myshopify.com",
                ),
                ConnectorFieldSpec(
                    key="access_token",
                    label="Access token",
                    required=True,
                    secret=True,
                    description="Admin API access token for the target store.",
                ),
                ConnectorFieldSpec(
                    key="resource",
                    label="Resource",
                    required=True,
                    default="orders",
                    description="REST resource path, e.g. orders or customers.",
                ),
                ConnectorFieldSpec(
                    key="api_version",
                    label="API version",
                    default="2025-01",
                    description="Shopify Admin API version.",
                ),
                ConnectorFieldSpec(
                    key="params",
                    field_type="object",
                    label="Query params",
                    default={},
                    description="Optional query string parameters.",
                ),
                ConnectorFieldSpec(
                    key="timeout",
                    field_type="number",
                    label="Timeout (seconds)",
                    default=30,
                    description="HTTP request timeout in seconds.",
                ),
            ),
        ),
    )


FACTORY = _factory()
