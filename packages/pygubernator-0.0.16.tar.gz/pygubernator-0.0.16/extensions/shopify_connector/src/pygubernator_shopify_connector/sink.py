"""Shopify sink connector for pygubernator."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    ConnectorFieldSpec,
    ConnectorSpec,
)


def _normalize_store_domain(raw: str) -> str:
    domain = raw.strip().removeprefix("https://").removeprefix("http://")
    return domain.rstrip("/")


def _resource_endpoint(resource: str) -> str:
    base = resource.strip().strip("/")
    if not base:
        raise ValueError("resource must be non-empty")
    return base


class ShopifySink:
    """Write records to Shopify Admin REST resources."""

    def __init__(
        self,
        *,
        store_domain: str,
        access_token: str,
        resource: str = "orders",
        api_version: str = "2025-01",
        mode: str = "create",
        id_field: str = "id",
        timeout: float = 30.0,
        dry_run: bool = False,
    ) -> None:
        self._store_domain = _normalize_store_domain(store_domain)
        self._access_token = access_token.strip()
        self._resource = _resource_endpoint(resource)
        self._api_version = api_version.strip() or "2025-01"
        self._mode = mode.strip().lower() or "create"
        self._id_field = id_field.strip() or "id"
        self._timeout = timeout
        self._dry_run = dry_run
        if self._mode not in {"create", "update", "upsert"}:
            raise SinkError(
                f"Unsupported Shopify sink mode: {self._mode}",
                sink_type="shopify",
            )

    def send(
        self, records: list[dict[str, Any]], metadata: dict[str, Any]
    ) -> SinkResult:
        if not records:
            return SinkResult(success=True, records_sent=0, sink_type="shopify")
        if self._dry_run:
            return SinkResult(
                success=True,
                records_sent=len(records),
                sink_type="shopify",
                metadata={"dry_run": True, "resource": self._resource},
            )

        try:
            import httpx
        except ImportError as exc:
            raise SinkError(
                "httpx is required for ShopifySink",
                sink_type="shopify",
            ) from exc

        headers = {
            "X-Shopify-Access-Token": self._access_token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        errors: list[str] = []
        sent = 0
        with httpx.Client(timeout=self._timeout) as client:
            for record in records:
                try:
                    method, url, body = self._request_shape(record)
                    response = client.request(
                        method=method, url=url, headers=headers, json=body
                    )
                    response.raise_for_status()
                    sent += 1
                except Exception as exc:
                    errors.append(str(exc))

        return SinkResult(
            success=len(errors) == 0,
            records_sent=sent,
            sink_type="shopify",
            errors=tuple(errors),
            metadata={
                "resource": self._resource,
                "mode": self._mode,
                "store_domain": self._store_domain,
            },
        )

    def close(self) -> None:
        """No-op."""

    def _request_shape(self, record: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
        singular = self._resource.rstrip("s")
        root = (
            f"https://{self._store_domain}/admin/api/"
            f"{self._api_version}/{self._resource}"
        )
        record_id = record.get(self._id_field)
        if self._mode == "create":
            return "POST", f"{root}.json", {singular: record}
        if self._mode == "update":
            if not record_id:
                raise SinkError(
                    f"Shopify update mode requires '{self._id_field}' in each record",
                    sink_type="shopify",
                )
            return "PUT", f"{root}/{record_id}.json", {singular: record}
        if record_id:
            return "PUT", f"{root}/{record_id}.json", {singular: record}
        return "POST", f"{root}.json", {singular: record}


def _validate(config: dict[str, Any]) -> None:
    if not config.get("store_domain"):
        raise SinkError("Shopify sink requires 'store_domain'", sink_type="shopify")
    if not config.get("access_token"):
        raise SinkError("Shopify sink requires 'access_token'", sink_type="shopify")
    if not config.get("resource"):
        raise SinkError("Shopify sink requires 'resource'", sink_type="shopify")


def _build(config: dict[str, Any]) -> ShopifySink:
    return ShopifySink(
        store_domain=str(config["store_domain"]),
        access_token=str(config["access_token"]),
        resource=str(config["resource"]),
        api_version=str(config.get("api_version", "2025-01")),
        mode=str(config.get("mode", "create")),
        id_field=str(config.get("id_field", "id")),
        timeout=float(config.get("timeout", 30.0)),
        dry_run=bool(config.get("dry_run", False)),
    )


def _factory() -> Any:
    from pygubernator.connectors._sink_registry import SinkFactory

    return SinkFactory(
        type_name="shopify",
        build=_build,
        validate=_validate,
        description="Writes records to Shopify Admin REST resources.",
        spec=ConnectorSpec(
            version=CONNECTOR_SPEC_V1,
            kind="sink",
            type_name="shopify",
            display_name="Shopify",
            description="Write records to Shopify Admin REST resources.",
            fields=(
                ConnectorFieldSpec(
                    key="store_domain",
                    label="Store domain",
                    required=True,
                    description="Shop domain, e.g. acme.myshopify.com.",
                    placeholder="acme.myshopify.com",
                ),
                ConnectorFieldSpec(
                    key="access_token",
                    label="Access token",
                    required=True,
                    secret=True,
                    description="Admin API access token for the target store.",
                ),
                ConnectorFieldSpec(
                    key="resource",
                    label="Resource",
                    required=True,
                    default="orders",
                    description="REST resource path, e.g. orders or customers.",
                ),
                ConnectorFieldSpec(
                    key="api_version",
                    label="API version",
                    default="2025-01",
                    description="Shopify Admin API version.",
                ),
                ConnectorFieldSpec(
                    key="mode",
                    label="Mode",
                    choices=("create", "update", "upsert"),
                    default="create",
                    description="Create records, update by id, or upsert.",
                ),
                ConnectorFieldSpec(
                    key="id_field",
                    label="ID field",
                    default="id",
                    description="Record key used for update and upsert operations.",
                ),
                ConnectorFieldSpec(
                    key="timeout",
                    field_type="number",
                    label="Timeout (seconds)",
                    default=30,
                    description="HTTP request timeout in seconds.",
                ),
                ConnectorFieldSpec(
                    key="dry_run",
                    field_type="boolean",
                    label="Dry run",
                    default=False,
                    description="Validate and count records without API writes.",
                ),
            ),
        ),
    )


FACTORY = _factory()
