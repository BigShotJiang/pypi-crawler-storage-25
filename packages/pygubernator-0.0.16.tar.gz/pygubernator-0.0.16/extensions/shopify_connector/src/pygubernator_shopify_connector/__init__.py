"""Shopify source/sink connector extension for pygubernator."""

from __future__ import annotations

from pygubernator_shopify_connector.sink import FACTORY as SHOPIFY_SINK_FACTORY
from pygubernator_shopify_connector.source import FACTORY as SHOPIFY_SOURCE_FACTORY

__all__ = ["SHOPIFY_SOURCE_FACTORY", "SHOPIFY_SINK_FACTORY"]
