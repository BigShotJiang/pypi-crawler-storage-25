#!/bin/bash
set -euo pipefail

# ---------------------------------------------------------------------------
# PyGubernator Docker Entrypoint
#
# Dispatches to the correct CLI command based on SERVICE env var or first arg.
# Optionally runs DB migrations before starting the service.
# Uses exec for proper PID 1 signal forwarding (graceful shutdown).
#
# Note: pygubernator does not yet have a standalone worker process.
# Workflow execution and background tasks (sweeper, scheduler) run as
# threads inside the API server. The "worker" command starts the API
# in worker mode (no UI serving, same process).
# ---------------------------------------------------------------------------

# --- Run DB migrations if requested ----------------------------------------
if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
    echo "[entrypoint] Running database migrations..."
    pygubernator db upgrade || echo "[entrypoint] WARNING: Migration failed (may already be current)"
fi

# --- Dispatch based on first argument or SERVICE env var -------------------
SERVICE_CMD="${1:-${SERVICE:-api}}"

case "$SERVICE_CMD" in
    api)
        echo "[entrypoint] Starting PyGubernator API server..."
        exec pygubernator api \
            --host "${API_HOST:-0.0.0.0}" \
            --port "${API_PORT:-8010}" \
            --no-reload
        ;;
    ui)
        echo "[entrypoint] Starting PyGubernator UI server..."
        exec pygubernator ui serve \
            --host "${UI_HOST:-0.0.0.0}" \
            --port "${UI_PORT:-3010}"
        ;;
    *)
        # Pass through any other command (e.g., bash, sh, pygubernator db upgrade)
        exec "$@"
        ;;
esac
