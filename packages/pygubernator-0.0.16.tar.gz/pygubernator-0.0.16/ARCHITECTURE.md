# Architecture of PyGubernator

This document describes the philosophy and layered architecture that every
change to PyGubernator must respect. Read it before contributing.

Two ideas power every package in the Optophi family:

1. **Configuration-Driven Engineering (CDE).** The domain artifacts that the
   system reasons about — in PyGubernator, the agent specs, tool registries,
   and pipeline DSL — are expressed as **configuration** (YAML / JSON),
   not as code. A new agent is a registered spec, not a new Python class.
2. **Layered architecture around a stateless core.** The heart of the package
   is a pure, stateless tool API. Everything else — persistence, HTTP, UI,
   workers — is a shell that calls the core.

These two ideas, taken together, are what make the package composable,
testable, and safely evolvable.

---

## The layered architecture

```
            ┌───────────────┐  ┌───────────────┐
            │  HTTP wrapper │  │   UI wrapper  │
            │   (FastAPI)   │  │   (Next.js)   │
            └───────┬───────┘  └───────┬───────┘
                    │                  │
                    ▼                  ▼
          ┌──────────────────────────────────┐
          │         STATELESS CORE           │
          │   (signature tool API, pure)     │
          │   domain artifacts = YAML/JSON   │
          └─────────────┬────────────────────┘
                        │
                        ▼
                ┌──────────────┐             ┌───────────────┐
                │    STORE     │ ◄──────────►│    WORKER     │
                │   (client)   │             │ (async svc)   │
                └──────┬───────┘             └───────────────┘
                       │
          ┌────────────┼────────────┐
          ▼            ▼            ▼
       SQLite      Postgres      MongoDB
      (testing)     (SQL)       (NoSQL)
```

### Layer definitions

**Stateless core.** The signature functionality: instantiating an agent
from a registered spec, binding tools, dispatching events via stream or
batch runners. Pure tool API: spec + message in, agent invocation result
out. Runners (`_stream.py`, `_batch.py`) compose the pure step function;
they do not hold agent state.

**Store.** Persistence client for agent specs, agent versions, run state,
and event history. Supports **SQLite, Postgres, and MongoDB**. SQLAlchemy
models and Alembic migrations live here.

**HTTP wrapper.** FastAPI control plane exposing `/agents`, `/runs`,
`/observability`, `/policies`. Thin routes.

**UI wrapper.** Next.js app for agent management, run inspection, and
event tracing.

**Worker.** The runners can be embedded in a long-running worker that
consumes from Kafka, an HTTP source, or a file source. The worker uses
the runner as a library; it does not extend the core.

---

## The two laws

### Law 1: the core is stateless

- Agents are *instantiated* from specs per invocation. Agent state between
  invocations lives in the store, not in memory.
- Runners are pure orchestrators over the agent step function.
- Connectors (Kafka, HTTP, file, in-memory) are plugin transports; the
  core composes them without holding transport state.

### Law 2: domain artifacts are configuration

- Agent specs live in the registry, keyed by `agent_id` and version.
- Tool metadata — name, signature, description — is data, loaded from
  the version spec.
- Pipelines and policies are declarative.

Breaking either law means the architecture has leaked. Stop and reconsider.

---

## PyGubernator layer map

| Layer        | Where in the repo                                              |
|--------------|----------------------------------------------------------------|
| Core (agents)| `src/pygubernator/agents/`, `dsl.py` — `PipelineAgent`,        |
|              | `LLMAgent`, tool binding                                       |
| Core (runners)| `src/pygubernator/runners/` — `_stream.py`, `_batch.py`       |
| Core (transport)| `src/pygubernator/connectors/` — Kafka, HTTP, file,         |
|              | in-memory sources; registry pattern                            |
| Store        | `src/pygubernator/db/` — SQLAlchemy, Alembic; agent versions,  |
|              | run states, events                                             |
| HTTP wrapper | `src/pygubernator/api/`                                        |
| UI wrapper   | `src/pygubernator/ui/` (built separately)                      |
| Worker       | Runners embedded in long-running processes; no dedicated       |
|              | worker module yet                                              |
| Config       | `src/pygubernator/config/`, `data/` — agent YAML specs         |

---

## Cross-package integration

PyGubernator integrates with PyStator for agent lifecycle FSMs:
transitions of an agent run (pending → running → succeeded / failed) are
governed by a PyStator machine. The sanctioned bridge is the
`state_machine_name` on the agent spec and the `context_validator` hook
on the PyStator orchestrator. Do not import PyStator internals directly.

Collaboration integrations (Google Sheets, Slack, Obsidian) live in a
separate `collab` module and are optional extras. They consume the core's
public API; they do not extend it.

---

## What this architecture gives you

- **Registered-not-coded agents.** A new agent is a version spec in the
  registry.
- **Transport flexibility.** The same agent runs against Kafka, HTTP,
  files, or in-memory sources without change.
- **Observable by construction.** Events, tracing, and metrics are part
  of the runner, not bolted on.

---

## What to do if a change does not fit

If a change feels like it needs an in-memory agent cache, a branch on
transport type inside the core, or a hand-coded Python agent for a
specific use case, **stop**. Register a new agent spec, or extend the
runner's public composition points.

See `CONTRIBUTING.md` for how to propose changes, and `.claude/skills/` for
the AI-assisted contribution skills that enforce this architecture.
