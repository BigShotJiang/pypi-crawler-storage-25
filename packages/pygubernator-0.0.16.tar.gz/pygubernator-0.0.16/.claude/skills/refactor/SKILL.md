---
name: refactor
description: Use ONLY when the user explicitly asks to refactor, simplify, or optimize existing code. Covers all three modes through one dispatcher. Never fires proactively — not during /verify, not as a "while I'm here" side effect of other work, not to clean up code an agent wrote moments ago. The user must name the task.
---

# Skill: refactor

## When this skill fires

Only when the user has **explicitly asked** for one of:

- **Refactor** — restructure code without changing behavior.
- **Simplify** — remove code, collapse an abstraction, delete dead code.
- **Optimize** — improve performance.

Trigger words: "refactor", "simplify", "optimize", "clean up", "speed up",
"reduce complexity of", "DRY up", "remove unused".

Do **not** invoke this skill:

- As part of `/verify` or any other skill's flow.
- When an agent notices a code smell while doing unrelated work.
- To tidy up code you just wrote. (If the first draft needs cleanup,
  finish the first draft properly instead.)
- During a "cleanup" or "audit" pass the user didn't authorise.

The project's rules (see `CLAUDE.md`) explicitly forbid refactoring
without a clear reason or explicit request. This skill is how those
requests get executed safely — not how they get generated.

## Goal

Change the shape, size, or speed of code **without breaking the feature
it implements**. Behavior preservation is the primary invariant.

## Step 1: Name the mode

Before any other step, the skill asks: is this **refactor**, **simplify**,
or **optimize**? These share safeguards but differ in goal and in the
primary way they go wrong.

| Mode | Goal | Primary failure |
|---|---|---|
| Refactor | Restructure; behavior unchanged | Silent behavior change |
| Simplify | Remove or collapse | Deleting something still in use |
| Optimize | Improve performance | Losing clarity or correctness |

A single task may combine modes (e.g. "simplify and speed up this
function"). In that case, run the gates for each mode that applies.

## Step 2: Architectural gates (all modes)

Before writing any change, confirm each of these. If any is unclear,
stop and ask the user.

- **Layer scope.** Which layer(s) are touched — core, store, HTTP
  wrapper, UI wrapper, worker? A refactor that **moves logic across
  layers** is a redesign; stop this skill and run `/plan` instead.
- **Public API contract.** Anything in `__all__`, exported function
  signatures, default values, environment variable names, connection
  URLs, and CLI flags are contracts. Preserving behavior means
  preserving these. A change here is a signature change, not a
  refactor.
- **Configuration shape.** YAML/JSON shapes under `data/seed/` and
  `data/templates/` must not change silently. A shape change is a
  `/config-change`, not a refactor.
- **Store backend parity.** Any change under the store must keep
  SQLite, Postgres, and MongoDB implementations in sync.
- **Stateless core.** A refactor must not introduce hidden state in a
  module claimed to be pure. If the refactor's natural shape wants
  state, you are hitting a law (`ARCHITECTURE.md` Law 1) — stop and
  discuss.

## Step 3: Mode-specific steps

### 3a. Refactor

Behavior-preserving restructuring.

- **Characterization tests first.** Before touching the code, confirm
  there are tests that capture the current behavior. If there aren't,
  write them *first*, commit them, then refactor. Tests written after
  a refactor prove the refactored version works — they do not prove it
  matches the old version.
- **Small steps.** One refactoring move per commit where reasonable.
  Easier to review, easier to bisect if something breaks.
- **Run `/verify` after each step.** Including integration tests.
- **Signature diff.** Compare the public API surface against `main`
  before committing. No silent signature changes.
- **Do not bundle.** A refactor PR contains the refactor. Bug fixes,
  formatting sweeps, or dependency bumps go in separate PRs.

### 3b. Simplify

Removing code, collapsing abstractions, deleting what is not needed.

Use the tiered removal rules. Match the symbol you're removing to its
tier and follow the rule.

| Tier | Examples | Rule |
|---|---|---|
| **1. Trivial** | unused imports (F401), unused locals (F841), dead branches after `if False`, commented-out code, orphan comments | Just remove. Ruff already flags most. |
| **2. Internal** | private helpers (`_foo`), internal modules (`_types.py`), private class methods, unexported classes | Grep the package. If nothing references it, remove. Include the seed/template grep below. |
| **3. Public** | anything in `__all__`, any symbol imported from outside the package, anything documented in `docs/reference/`, any Protocol implementation registered as a plugin | Deprecate first: `warnings.warn(..., category=DeprecationWarning, stacklevel=2)` in the next minor release. Remove in the next major. |
| **4. Signature** | unused function parameters, unused config fields, optional kwargs nothing passes | Treat as a signature change. Deprecate for one minor release (document in changelog). Remove in next major. |

**The seed/template grep.** Some packages in this family use
**registry-driven dispatch** — symbols looked up by string name from
YAML, not by `import` (PyGubernator agent registry, PyStator
guards/actions/hooks, PyCatalyst generators, PyOptima objectives and
constraints). Python grep will not find these references.

For any Tier 2 or higher removal, also grep:

- `data/seed/**`
- `data/templates/**`
- `configs/**`
- Any fixture or example directory the package uses

If the symbol name appears as a string in any of those, the code is
live. Do not remove.

**"Looks unused" ≠ "is unused".** When in doubt, deprecate; do not
delete.

### 3c. Optimize

Performance improvements.

First, name the kind of win:

- **Algorithmic** — asymptotic complexity improves (O(n²) → O(n log n),
  N+1 query collapsed, eager → lazy, cache added, redundant pass
  removed). The argument is theoretical.
- **Tuning** — constant-factor win (hot loop rewrite, vectorization,
  allocation reduction). The argument requires measurement.

**Algorithmic wins:**

- Explain the complexity change in the PR description in one or two
  sentences.
- A benchmark is nice-to-have, not required.
- Confirm correctness with existing tests and a fresh test case at
  whatever scale the old code struggled with.

**Tuning wins:**

- **Profile or benchmark before touching anything.** Do not optimize on
  intuition.
- Add a `pytest-benchmark` case in `tests/perf/` or alongside the
  relevant unit test. Measure the current baseline.
- Make the change.
- Run the benchmark again. Paste before-and-after numbers into the PR.
- If the win is under ~15%, ask whether it's worth the code-clarity
  cost.
- Add a `# why` comment at the optimization site. Performance
  optimizations are one of the rare places comments earn their keep —
  the next refactor will otherwise undo the win without realising.

**Across both sub-modes:**

- Prefer the version of the code a future reader can follow. An
  unreadable 2× speed-up is rarely worth a readable 1.5× speed-up.
- If the optimization depends on an implementation detail of a library
  or the interpreter, say so in the `# why` comment — those details
  change.

## Step 4: Verify (end-to-end)

Refactor, simplify, and optimize all require the *end-to-end*
verification that `CLAUDE.md` demands — green unit tests are not
sufficient.

- Run `/verify` end-to-end: Ruff, pre-commit, `pytest` (unit +
  integration, all relevant backends).
- **Exercise the actual feature.**
  - Core change: run a representative call with real input.
  - Store change: round-trip against each supported backend.
  - HTTP wrapper: hit the endpoint.
  - UI: load the page.
  - Worker: run it against a real queue.
- If you cannot exercise the feature yourself, say so explicitly in
  the PR, list what the user should verify manually, and do not claim
  the work is done.

## Step 5: Ship

Use `/ship`. Commit type:

- `refactor:` — behavior-preserving restructuring.
- `perf:` — optimization.
- `refactor:` or `chore:` — dead-code removal, depending on scope. A
  Tier 3 public removal is `refactor!:` with a `BREAKING CHANGE:`
  footer in the major-release PR.

PR description must add to the standard `/ship` template:

- **Mode:** refactor / simplify / optimize (and which of 3a / 3b / 3c).
- **Behavior preservation claim:** explicit. Link to the tests that
  demonstrate it.
- **For simplify:** which tier, and evidence the symbol was unused
  (including seed/template grep result).
- **For optimize:** algorithmic vs. tuning, and benchmark numbers for
  tuning.
- **Out of scope:** call out anything the PR deliberately did **not**
  touch. This prevents reviewers from wondering whether adjacent
  smells got cleaned up silently.

## Done criteria

- The mode is explicitly named (refactor / simplify / optimize).
- The relevant architectural gates passed.
- Mode-specific steps completed.
- `/verify` is green, end-to-end.
- `/ship` template filled, with behavior-preservation evidence.

## Common mistakes to avoid

- **Scope creep.** "While I was in there, I also …" — no. One refactor
  per PR. File a separate issue for the other thing.
- **Refactoring without characterization tests.** If the tests are
  thin, *write tests first*, commit them, then refactor. The tests are
  the specification.
- **Treating a signature change as a refactor.** Any change to
  `__all__`, parameter names, defaults, env var names, or config shape
  is a contract break. It deserves its own plan, its own PR, its own
  version bump.
- **Deleting based on Python grep alone.** For any registry-driven
  symbol (guard, action, hook, generator, objective, constraint,
  agent), also grep seed and template directories for the name as a
  string.
- **Optimizing on intuition.** No profile, no benchmark, no change.
- **"Tests pass" as end-to-end evidence.** Tests prove the tests pass.
  Exercise the feature.
- **Rewriting readable code into clever code.** Fewer lines is not a
  goal. Fewer concepts is.
- **Bundling unrelated cleanup.** A renamed variable here, an
  isort-reordered import there — if it isn't the refactor, it doesn't
  belong in the refactor PR.
