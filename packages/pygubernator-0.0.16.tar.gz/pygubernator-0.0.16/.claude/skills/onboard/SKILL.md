---
name: onboard
description: Use on the first contribution to an Optophi package, or when starting work in an unfamiliar area of one. Orients the contributor around the stateless core, configuration-driven domain artifacts, and the layer map before any code is written. Produces or updates AGENTS.md so future contributors inherit the map.
---

# Skill: onboard

## When this skill fires

- First time cloning or contributing to a package in this family.
- First time touching an area of a package you haven't worked in
  (e.g. the worker, when you've only touched the core).
- A new collaborator joins and needs to ramp.
- The package has grown and `AGENTS.md` is out of date.

## Goal

Before writing any code, the contributor can name (a) which layer they are
about to touch, (b) what the domain artifacts for the package look like,
and (c) what the public API surface is.

## Steps

### 1. Install and verify the toolchain works

From the package root:

```
python3 -m venv venv
source venv/bin/activate
pip install -U pip
pip install -e ".[dev]"
pre-commit install
pytest tests/unit
```

If the repo provides `scripts/setup.sh`, prefer that.

If the package has a UI:

```
cd src/<package>/ui
npm ci
npm run type-check
```

### 2. Read in this order

1. **`README.md`** — purpose and audience.
2. **`ARCHITECTURE.md`** — the philosophy (configuration-driven
   engineering, stateless core) and the layer map. This is the document
   that matters most; read it slowly.
3. **`CONTRIBUTING.md`** — development setup, commit conventions,
   branching workflow.
4. **`CODE_OF_CONDUCT.md`** and **`SECURITY.md`** — non-optional.
5. **`pyproject.toml`** — extras (`[api]`, `[db]`, `[ui]`, `[dev]`),
   entry points, Ruff / mypy configuration. Note: Ruff and mypy configs
   can differ between packages.
6. **Top-level `src/<package>/__init__.py`** — this is the public API
   surface.
7. **`data/seed/*.yaml`** — the vocabulary of the domain. This is what
   users actually author.
8. **`protocols.py`** or **`_types.py`** — the pluggable interfaces.
   Every extension point lives here.
9. **The core modules** (parse / build / engine), then the store, then
   the HTTP wrapper, then the worker. Read inward-out, not outward-in.

### 3. Draw the layer map for this package

Sketch — literally, for yourself — which modules belong to which layer:

- Core (parse / build / engine)
- Store
- HTTP wrapper
- UI wrapper
- Worker
- Configuration (seed, templates)

Cross-check your sketch against the "layer map" table in
`ARCHITECTURE.md`. If they disagree, the architecture doc is stale —
propose an update.

### 4. Learn the package's extension patterns

For each of these, find the canonical example in the codebase:

- **How to add a new plugin.** Look for the Protocol, then the factory
  function that builds an implementation with captured dependencies.
- **How to add a new error.** Look for the `ErrorCode` enum and the
  exception hierarchy under the package's base error.
- **How to add domain artifacts.** Open a seed file; confirm where the
  Pydantic validator lives; note the identifier rules.
- **How the store reaches each backend.** Find the SQLite, Postgres,
  and MongoDB implementations. Confirm they share a common interface.
- **Cross-package bridge points.** PyCharter ↔ PyStator bindings are
  documented in each package's `ARCHITECTURE.md`.

### 5. Produce or update `AGENTS.md`

`AGENTS.md` at the package root is the entry point for AI-assisted
contributors. On onboarding, update it if:

- The layer map has changed.
- Public API in `__all__` has grown or shrunk.
- A new extension pattern is worth documenting.
- The set of skills under `.claude/skills/` has changed.

Keep `AGENTS.md` concise — it is an index, not a tutorial. The long-form
content belongs in `ARCHITECTURE.md`.

### 6. Report back

Before starting code, say out loud (or in chat) for the area you are
about to touch:

- The **layer** you expect to change.
- The **public API** that will be affected, if any.
- The **configuration** that will be affected, if any.
- The **backends** that need to be covered, if the store is affected.

Then run `/plan` for the actual change.

## Done criteria

- `pip install -e ".[dev]"` succeeded. `pytest tests/unit` passes on
  main.
- The contributor can name the layer they will touch and one or two
  related protocols or seed files.
- `AGENTS.md` reflects the current state of the package.

## Common mistakes to avoid

- Skipping `ARCHITECTURE.md` because "I know Python packages." This
  family of packages has a specific shape — read it.
- Assuming the layer boundaries from one Optophi package transfer
  identically to another. They rhyme, but specifics differ.
- Reading outward-in (starting from the HTTP routes). You will think
  the routes hold logic they shouldn't, and then replicate that
  confusion in your change.
- Skipping the `data/seed/` tour. The seed data *is* the specification.
