---
name: ship
description: At commit and pull request time for any Optophi package. Produces Conventional Commits, a complete PR description that surfaces layer impact, public API changes, backend parity, and cross-package effects, and updates the changelog consistently.
---

# Skill: ship

## When this skill fires

- Immediately before `git commit` on a change that is ready to ship.
- When opening or updating a pull request.
- When the user says "ship it", "commit this", "open the PR", or similar.

Do not use this skill to commit work-in-progress. Commit work-in-progress
only when the user explicitly asks, and do not follow this template.

## Goal

Produce commits and a PR description that a reviewer — human or tool — can
evaluate without reading the chat history.

## Steps

### 1. Scope the change

- [ ] The working tree contains exactly one coherent change (or a
      reviewable sequence of commits telling one story).
- [ ] No unrelated formatting sweeps, drive-by renames, or bundled
      refactors.
- [ ] `/verify` has been run and is green.

### 2. Write the commit message

Conventional Commits. Format:

```
<type>: <imperative, lowercase, no trailing period>

<why, not what — one short paragraph, wrap at 72 cols>

Refs #<issue>
```

Types used by this project: `feat`, `fix`, `refactor`, `perf`, `docs`,
`test`, `chore`, `ci`.

Breaking change: add `!` after the type, and include a `BREAKING CHANGE:`
footer describing the migration.

Good:

```
feat: add mongodb backend to contract_store

Backend parity brings contract_store in line with semantic_store. Uses
the same translation layer; no changes to the core API.

Refs #124
```

Bad:

```
update code
```

### 3. Draft the PR description

Use this template. Fill every section or write "n/a" with a reason.

```
## Summary

<1–3 bullets on what changed>

## Layer(s) touched

- [ ] Core
- [ ] Store
- [ ] HTTP wrapper
- [ ] UI wrapper
- [ ] Worker
- [ ] Configuration / seed data
- [ ] Docs / tests / tooling only

## Public API changes

- Added: …
- Removed: …
- Changed: …
- `__all__` diff: …

## Configuration / schema changes

- Backward compatible? yes / no
- Migration required? …
- Seed data updated? …

## Backend parity

If the store changed, check each backend that has been covered:

- [ ] SQLite
- [ ] Postgres
- [ ] MongoDB

## Cross-package impact

Does this change the sanctioned bridge points between sibling packages
(e.g. PyCharter ↔ PyStator)? If yes, describe.

## Test plan

- Unit tests: …
- Integration tests: …
- Manual verification: …

## Risk

Anything reviewers should look at twice: new dependencies, perf-sensitive
paths, security-relevant changes, deprecations.
```

### 4. Update the changelog

- [ ] If the project uses `CHANGELOG.md` with Keep-a-Changelog-style
      entries, add one in the same commit.
- [ ] If the project generates notes from Conventional Commits (git-cliff,
      release-please), the commit message itself is the entry — make it
      user-readable.

### 5. Target the right branch

- Feature work → `develop`.
- Hotfix → `main`.
- Do not force-push shared branches.

### 6. Confirm before pushing

Destructive or publicly visible actions — `git push`, opening a PR,
merging — require explicit user confirmation unless the user has already
authorised the full sequence for this change. Do not push on your own
initiative.

## Done criteria

- The commit message follows Conventional Commits and explains *why*.
- The PR description has every section filled.
- The changelog is consistent with project style.
- The user has authorised the push.

## Common mistakes to avoid

- Writing a commit message that restates the diff.
- Omitting the "Layer(s) touched" section because the change feels
  obvious. It's not obvious to a reviewer who didn't live the change.
- Calling a breaking change "fix" because it fixes something. If the
  public API changed incompatibly, it is `feat!:` or `refactor!:`.
- Bundling a changelog rewrite, a dependency bump, and a bug fix into
  one PR. Split them.

## Release automation with `scripts/release.sh`

This package ships a single entry point for the commit / push / merge /
tag flow: ``scripts/release.sh``. Drive it rather than reinventing
``git`` + ``gh`` invocations.

### Sub-commands

| Command | What it does | When to use |
|---|---|---|
| ``./scripts/release.sh verify`` | Run the same gates CI runs — pytest, ruff check + format, mypy, mkdocs strict build, UI type-check — fail-fast locally. | Before every push. |
| ``./scripts/release.sh status`` | One-screen dashboard — open PRs, develop vs main divergence, latest tag, latest CI conclusion. | At the start of a session or before a release. |
| ``./scripts/release.sh commit [-m "msg"]`` | ``git add -A`` + commit. Generates a Conventional Commits message from the staged diff if ``-m`` is not supplied. | Only when you want the auto-generated message. Prefer ``-m`` for real work. |
| ``./scripts/release.sh push`` | commit + push current branch | After ``verify`` passes. |
| ``./scripts/release.sh merge-dev`` | push + merge current branch → ``develop`` (local fast-forward when no protection on ``develop``). | Feature-branch integration. |
| ``./scripts/release.sh merge-main`` | push ``develop`` + open/merge PR ``develop`` → ``main`` with ``gh pr merge --auto``. | Release prep. Main is PR-protected; this is the only supported path. |
| ``./scripts/release.sh tag`` | Check CI on ``main``, then tag next patch version and push — kicks off ``publish.yml``. | After ``merge-main`` succeeds. |
| ``./scripts/release.sh release`` | Full pipeline: ``merge-main`` then ``tag``. | The standard "ship a release" command. |
| ``./scripts/release.sh dependabot-cleanup`` | Triage + rebase + merge open Dependabot PRs. Classifies real failures vs stale CI. | Weekly; or when the Dependabot backlog feels too big. |

### When this skill picks ``release.sh`` vs raw ``git``

- **Feature branch, in-flight commit** → raw ``git commit`` + ``git push``. ``release.sh push`` is also fine but its auto-message is weaker than one written by the ``ship`` skill.
- **Feature branch, ready to merge to ``develop``** → ``release.sh merge-dev``.
- **Develop is ready to release** → ``release.sh release``.
- **Opening a standalone PR (not ``develop → main``)** → raw ``gh pr create``. ``release.sh`` does not wrap feature-branch PRs on purpose; each PR is reviewable on its own.

### Known pitfalls

- **Pre-commit ``BlockingIOError``.** The ``pre-commit`` framework occasionally
  fails with ``[Errno 35] write could not complete without blocking`` on
  macOS. ``release.sh`` retries once with ``--no-verify`` and surfaces a
  warning. Do NOT routinely pass ``--no-verify`` — the retry is only for
  this specific flake.
- **``gh`` token scope.** Merging a PR that touches ``.github/workflows/*``
  needs the ``workflow`` scope on the ``gh`` token. Run ``gh auth refresh
  -h github.com -s workflow`` once. If the merge fails with
  ``OAuth App ... workflow scope`` the user needs to re-auth.
- **``main`` requires PR.** ``git push`` to ``main`` always fails — that's
  intentional. Use ``release.sh merge-main`` or let ``release.sh release``
  drive it for you.
- **Required status checks.** If the repo's ``main`` has required status
  checks, ``gh pr merge --auto`` waits for them. Do not bypass. If a
  check is legitimately stuck (e.g. GHAS-only SARIF upload on a private
  repo), fix the workflow, don't bypass.

### Branch protection posture

- ``develop``: no rules (fast-forward pushes allowed for velocity).
- ``main``: PR required, non-fast-forward protected, delete protected,
  required status checks (tests + Semgrep) where enabled, linear history.
  No review requirement in solo-maintainer phase.

Shipping a change to ``main`` therefore means: feature branch → PR to
``develop`` (or direct push to ``develop`` for internal work) → PR from
``develop`` to ``main`` → tag. ``release.sh release`` walks that whole
sequence.
