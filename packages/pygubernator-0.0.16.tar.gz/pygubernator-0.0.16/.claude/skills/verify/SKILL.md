---
name: verify
description: Before committing any non-trivial change to an Optophi package. Runs the layer-boundary gates (core purity, store parity, wrapper thinness, worker discipline) plus the standard Python hygiene checks. Use after implementing a change and before writing the commit message.
---

# Skill: verify

## When this skill fires

- After finishing a code change, before `git commit`.
- After any automated fixer (Ruff, formatters) has run.
- Before handing the change back to the user for review.

Re-run this skill if the change is amended.

## Goal

Catch every violation that would waste the user's or a maintainer's review
time: architecture leaks, missing tests, style breaks, public API hygiene
gaps.

## Steps

### 1. Automated checks first

From the package root (the directory with `pyproject.toml`):

```
ruff check <modified paths> --fix
ruff format <modified paths>
pre-commit run --files <modified paths>
pytest
```

For UI changes:

```
cd src/<package>/ui
npm run type-check
```

Re-stage files after hooks modify them. Repeat until clean.

### 2. Layer-boundary gates

These are the checks that matter most for this package family. Read every
diff hunk through each lens.

**Core purity (for any file under the core).**

- [ ] No imports from `api/`, `ui/`, worker modules, or the store's
      backend-specific code.
- [ ] No `open()`, no `requests.`, no DB calls, no filesystem writes
      outside the `parse` stage (which only reads declared YAML/JSON).
- [ ] No module-level mutable state, no new singletons, no hidden caches
      that outlive a call.
- [ ] Functions claimed to be pure are reproducible given the same inputs.

**Configuration-driven (for any new domain concept).**

- [ ] The concept is represented in YAML/JSON, not as a hardcoded Python
      class.
- [ ] The schema has a Pydantic validator; invalid configuration fails at
      load time with a clear error.
- [ ] If identifiers are added, they follow the package's identifier rules
      (lowercase + underscores unless the package documents otherwise).
- [ ] Seed data under `data/seed/` has been updated or extended as needed.

**Store gates (for any file under the store).**

- [ ] Any new store method is implemented for **SQLite, Postgres, and
      MongoDB**. Integration tests exercise all three.
- [ ] The store contains only translation, not business logic.
- [ ] Connection and credentials come from config/env, never hardcoded.

**Wrapper gates (HTTP / UI).**

- [ ] Routes are thin: validate → call core/store → respond. No business
      logic in the route body.
- [ ] No direct DB access from routes — go through the store.
- [ ] UI changes reuse existing Optophi components and tokens; no new
      bespoke design without a visible reason.

**Worker gates.**

- [ ] Worker uses only public core + store API.
- [ ] Handlers are idempotent. Graceful shutdown is honoured.
- [ ] No in-memory state that would be lost on restart — state goes to
      the store.

### 3. Standard Python hygiene

- [ ] `from __future__ import annotations` on every touched `.py` file.
- [ ] Modern typing: `dict[str, Any]`, `str | None`, `A | B`. No
      `Dict` / `List` / `Optional` / `Union` from `typing`.
- [ ] Public API: type hints, Google-style docstring, listed in `__all__`
      of the module's `__init__.py` if it's meant to be imported.
- [ ] Exceptions inherit from the package's base exception and carry an
      `ErrorCode` where the package uses one.
- [ ] Pluggable interfaces are `typing.Protocol` with `@runtime_checkable`,
      not ABCs. Implementations via factory functions.
- [ ] Immutable value objects are `@dataclass(frozen=True, slots=True)`.
      Validated external input uses Pydantic v2.
- [ ] No f-strings in logging calls; use `logger.info("x %s", y)` lazy
      formatting.
- [ ] No `print` in production code; no bare `except:` or silent
      `except Exception: pass`.
- [ ] No mutable default arguments.
- [ ] Every touched file is < 400 lines. If larger, propose a split.

### 4. Tests

- [ ] Happy-path test for every new or changed public function.
- [ ] At least one error-path test (bad input, missing config, failing
      backend).
- [ ] Correct marker: `@pytest.mark.unit` or `@pytest.mark.integration`.
- [ ] Integration tests cover the touched backend(s).
- [ ] `pytest` passes locally.

### 5. Review the diff once more

- [ ] Every changed line is something the user would defend in review.
- [ ] No unrelated refactors, formatting-only sweeps, or drive-by renames
      snuck in.
- [ ] No secrets, tokens, real URLs, or PII in code, fixtures, or logs.

## Done criteria

- All boxes are checked or there is a written reason for any that aren't.
- Ruff, pre-commit, and pytest are green on the current tree.
- The diff is scoped to one coherent change.

## Common mistakes to avoid

- Treating Ruff-green as "done". Ruff does not catch architecture
  violations.
- Skipping integration tests because unit tests pass. The core is pure;
  most bugs live at the boundaries.
- Adding a field to one store backend and planning to add it to the
  others "later". Backend parity is enforced per-change, not per-release.
- Silent changes to function signatures, default values, env var names, or
  connection URLs — these are contract breaks even when tests pass.
