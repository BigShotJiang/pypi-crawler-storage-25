---
name: config-change
description: Use whenever a change touches declared domain artifacts — YAML/JSON under data/seed/, Pydantic schema validators, FSM definitions, contract definitions, or the loader that parses them. Configuration-driven engineering means these changes carry more risk than typical code changes, because they define what the system is.
---

# Skill: config-change

## When this skill fires

- Any edit to files under `data/seed/**` or `data/templates/**`.
- Any change to the Pydantic models that validate configuration shape.
- Any change to the parser, loader, or schema converter in the core.
- Any change to identifier validation rules.
- Any change to how domain artifacts are versioned or migrated.

## Why this is its own skill

Configuration-Driven Engineering is one of the package's two laws (see
`ARCHITECTURE.md`). Domain artifacts live in configuration so non-engineers
can author them, so artifacts can be versioned and diffed as data, and so
the engine stays small. That means configuration changes are **user-visible
contract changes** — treat them as such.

## Steps

### 1. Identify the kind of change

- **Additive** — a new optional field, a new artifact, an additional
  identifier. Usually backward compatible.
- **Rename or remove** — field renamed, removed, or its type changed.
  Breaking.
- **Required-field addition** — new field that existing artifacts don't
  set. Breaking without a default.
- **Semantics change** — same shape, different meaning (e.g. `retry_count`
  now means "including first attempt" instead of "excluding"). Subtle and
  dangerous; treat as breaking.

Name the kind of change explicitly in the PR description.

### 2. Validate the full lifecycle

A configuration change must survive the full parse → store → build pipeline:

- [ ] **Parse** — load the changed artifact through the parser. Invalid
      shapes fail at load time with a clear, actionable error message.
- [ ] **Store** — round-trip through each supported backend: SQLite,
      Postgres, MongoDB. Reading back must yield an equivalent object.
- [ ] **Build** — construct the runtime artifact (validator, pipeline,
      state machine, entity session) from the parsed/persisted form.
- [ ] **Execute** — exercise the artifact's signature behaviour against a
      realistic input.

If the parser or schema changed, also load every existing seed file and
confirm they still parse.

### 3. Identifier rules

- Identifiers in YAML (states, triggers, contract names, rule names) are
  lowercase + underscores only, unless the package's existing seed data
  documents a different convention.
- Use the package's identifier validation helper (for example,
  PyStator's `_validate_name()`). Do not add a new validator.
- Identifier collisions across the artifact must fail at parse time, not
  at build time.

### 4. Schema evolution

- [ ] Is this change backward compatible with existing seed data? Load
      every file under `data/seed/` and confirm it still parses.
- [ ] If breaking, does it warrant a major version bump?
- [ ] Is there a migration path? A script, a note in the changelog, or
      both.
- [ ] Is the schema still documented in `docs/reference/`? Update it in
      the same PR.

### 5. Cross-package implications

- For a PyStator FSM change: verify the `context_validator` hook contract
  still holds. Test hierarchical / parallel transitions if they are
  affected.
- For a PyCharter contract change: verify `validate_for_state` still
  passes for each FSM state bound to the contract.
- For any change to `metadata.governance_rules.lifecycle`: this is a
  sanctioned bridge point — changes here affect both packages.

### 6. Tests

- [ ] Unit tests cover the schema validator with valid and invalid input.
- [ ] Integration tests cover the parse → store → build lifecycle.
- [ ] Backend-parity tests confirm the store round-trips the new shape
      across SQLite, Postgres, and MongoDB.

## Output

Before committing, produce:

- A short summary of the change kind (additive / rename / remove / required
  / semantic).
- The list of seed files touched or validated.
- Confirmation that parse → store → build → execute succeeded for at
  least one realistic artifact.
- Migration notes, if breaking.

## Done criteria

- Every existing seed file still parses under the new schema, or a
  migration note explains which do not and why.
- Store round-trip succeeds across all three backends.
- Docs in `docs/reference/` are updated.
- PR description flags this as a configuration change and calls out
  backward-compatibility.

## Common mistakes to avoid

- Adding a new required field without a default or a migration.
- Renaming a field in the schema but forgetting to update seed data.
- Testing the new artifact only — forgetting to verify existing artifacts
  still parse.
- Validating at build time what should have failed at parse time. Fail
  fast.
- Relying on SQLite-only integration tests when Postgres or MongoDB has
  a different representation (JSONB vs. document).
