---
name: plan
description: Before implementing any non-trivial change to an Optophi package. Forces explicit decisions about which architectural layer is touched, whether the core stays stateless, and whether new domain concepts belong in configuration rather than code. Use for features, bug fixes beyond a line or two, refactors, and any change that adds public API.
---

# Skill: plan

## When this skill fires

- Any change that adds, removes, or changes public API.
- Any change that touches more than ~20 lines or more than one module.
- Any new domain concept (a new rule, shape, step, state, trigger, etc.).
- Any change that might cross the core / store / wrapper / worker boundary.
- A bug fix whose root cause is unclear after a first look.

If the change is a typo fix, a docstring tweak, or a purely mechanical lint
pass, skip this skill.

## Goal

Produce a short plan the user can approve *before* code is written. The plan
names the layer, defends statelessness and configuration-driven-ness, and
calls out backend parity and cross-package impact.

## Steps

### Step 0: Branch setup

Before any architectural analysis:

- If the current branch is `develop` or `main`, **stop**. Run
  `/branch <ticket> [description]` first, or ask the user which branch
  to work on.
- If the task came with a ticket reference (issue number, Jira key),
  the branch name should include it — `/branch` handles the naming.
- If a branch for this work already exists, switch to it rather than
  creating a new one.
- Skip this step only if the user has explicitly said to plan without
  creating a branch (e.g. an exploratory discussion).

### Step 1 onwards: Architectural questions

Before writing code, answer each question. If any answer is unclear, stop
and ask the user.

1. **Which layer does this change live in?**
   - Core / store / HTTP wrapper / UI wrapper / worker.
   - A change that seems to span layers is a design smell — re-scope, or
     split into a sequence of single-layer changes.

2. **If the change is in the core:**
   - Does it stay stateless? No module-level mutable state, no singletons,
     no I/O, no persistence, no network.
   - Is the new domain concept expressible as configuration? If you are
     about to write a Python class that encodes a specific contract, FSM,
     rule, or schema, **stop**. It belongs in YAML/JSON with a Pydantic
     validator.
   - Which stage does it touch: `parse`, `store`, or `build`?

3. **If the change is in the store:**
   - Does it apply to all three backends (SQLite, Postgres, MongoDB)? If
     not, justify why — the default is parity.
   - Is it pure translation between core objects and persistence? No
     business logic in the store.

4. **If the change is in a wrapper (HTTP or UI):**
   - Is the underlying capability already in the core? If not, the core
     change comes first, in a separate PR.
   - Routes must remain thin: validate → call core/store → respond.
   - For UI, reuse existing Optophi design components before introducing
     new ones.

5. **If the change is in a worker:**
   - Does it use only the core's and store's public API?
   - What is the failure / retry / DLQ behaviour?
   - Is the handler idempotent? Long-running services must tolerate
     restarts and duplicate events.

6. **Cross-package impact.**
   - Does this affect the sanctioned bridge points between sibling packages
     (e.g. PyCharter ↔ PyStator)? Flag it.
   - Any other cross-package import is out of bounds; propose a new,
     named bridge if one is genuinely needed.

## Output

A short plan, written for the user, containing:

- **Layer(s) touched.**
- **What changes** (1–3 bullets).
- **Domain artifact changes**, if any, and why they belong in configuration.
- **Backend parity** — if the store changes, which backends are covered.
- **Cross-package impact** — none / bridge-point only / requires discussion.
- **Test plan** — unit, integration, backend coverage.

Get the user's approval on the plan before writing code.

## Done criteria

- The plan names exactly one primary layer.
- Stateless core and configuration-driven rules have been checked.
- The user has said go.

## Common mistakes to avoid

- "I'll put this in the route for now and refactor later" — no. It belongs
  in the core before the wrapper can expose it.
- "I'll add a Python class for this new rule type" — no. Rules live in
  configuration. Extend the schema, not the class hierarchy.
- "I'll only implement the Postgres store; SQLite and Mongo can come
  later" — no. Store parity is a gate, not a follow-up.
- "I can skip the plan for this one; it's obvious" — the skill exists
  because these boundaries are easy to cross by accident. Take the minute.
