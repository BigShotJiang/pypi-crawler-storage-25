---
name: release
description: Use when the user asks to "release", "tag", "publish", "cut a version", or "ship to PyPI" for an Optophi package. Drives ``scripts/release.sh`` end-to-end with appropriate safety checks, retries, and diagnostics. This skill fires AFTER the change is merged to ``develop`` and tested — it does not write code.
---

# Skill: release

## When this skill fires

- The user says: "release", "cut a release", "tag a version", "publish to PyPI", "ship it to main".
- The user asks for a dry-run / status check before a release.
- An in-flight release fails and the user asks to resume.

Do NOT fire this skill when:

- The user is mid-development and wants to commit feature work. Use the
  ``ship`` skill for that.
- Code changes are still pending on ``develop``. Release only after the
  code that is supposed to ship is already merged.
- ``main`` has open PRs or uncommitted work locally.

## Goal

Take an Optophi package from "code is on ``develop``" to "tagged, published
to PyPI, and released on GitHub" in one fleet-consistent flow, while
respecting branch-protection rules.

## Pre-flight checks

Before running ``release.sh``, verify:

### 1. Repo is clean

```bash
./scripts/release.sh status
```

Must show:

- ``Working tree: clean``
- ``Current branch: develop`` (or a release-prep branch about to merge)
- ``Open PRs: 0`` (or only the release PR itself)
- ``develop vs main: develop is ahead by N commits`` (the N to be released)
- ``Last CI on develop: success``

If any of those is off, diagnose before proceeding — don't release on top
of broken state.

### 2. Local gates pass

```bash
./scripts/release.sh verify
```

This runs the same set CI runs — pytest, ruff check, ruff format --check,
mypy, mkdocs strict build, UI type-check. A failure here will also fail
in CI; fix locally first to avoid the tag → failed-publish loop.

### 3. CHANGELOG is coherent

The ``publish.yml`` workflow generates GitHub release notes automatically
via ``git-cliff`` from Conventional Commits on each commit. If
``CHANGELOG.md`` exists in the repo, it needs a new entry too. Update it
(as its own commit) before tagging.

## Release procedure

Once pre-flight is green:

```bash
./scripts/release.sh release
```

That is equivalent to:

1. ``merge-main`` — open PR ``develop → main``, auto-merge when required
   checks pass, wait for the merge.
2. ``tag`` — check CI conclusion on ``main`` is green, create next patch
   tag (``v0.0.N``), push it.
3. Tag push triggers ``publish.yml`` which:
   - Runs pytest
   - Generates release notes via ``git-cliff``
   - Builds UI (if package has one)
   - Builds wheel and sdist
   - Publishes to PyPI via trusted publishing
   - Creates GitHub Release with the generated notes

The skill should **watch the publish run** and report its status, not
return immediately after tagging.

## What the skill must report back

- The PR number that merged ``develop → main``.
- The new tag name.
- Direct link to the ``publish.yml`` run.
- PyPI release URL once the workflow finishes.
- GitHub release URL once the workflow finishes.

## Versioning rules

``release.sh tag`` bumps the **patch** version by default (v0.0.N →
v0.0.N+1). For minor or major bumps, either:

- Set ``RELEASE_VERSION=v1.2.0`` env var before running ``tag`` — the
  script will use that exact tag instead, OR
- Create the tag manually with ``git tag -a`` + ``git push`` before
  ``release.sh tag`` runs.

Semver reminder:

- ``feat`` or ``fix`` commits without breaking changes → patch bump is fine.
- ``feat`` changing public API → minor bump.
- Anything with ``BREAKING CHANGE:`` footer or ``!`` suffix → major bump.

If the commits since the last tag include a breaking change and the
skill is about to tag a patch, STOP and flag it to the user.

## Failure-mode playbook

### "gh auth refresh required" — workflow scope missing

```
! refusing to allow an OAuth App to create or update workflow ... without `workflow` scope
```

Fix:

```bash
gh auth refresh -h github.com -s workflow
```

Then retry ``release.sh release``.

### "Pre-commit BlockingIOError" on macOS

The Python stdlib ``pre_commit.output.write_line_b`` occasionally hits
``[Errno 35] write could not complete without blocking``. ``release.sh``
retries once with ``--no-verify`` and logs a warning. If the retry fails
too, run tests manually then ``git commit --no-verify``.

### Required status check stuck

If ``gh pr merge --auto`` is waiting but a check is legitimately stuck,
inspect the Actions run. Typical causes:

- GitHub Actions billing exhausted (check
  ``https://github.com/organizations/optophi/settings/billing``)
- Self-hosted runner offline
- GHAS SARIF upload returning 403 (private repo without Advanced Security
  — expected; the workflow already has ``continue-on-error`` on upload)

### CI on ``main`` is failing when trying to tag

``release.sh tag`` explicitly refuses to tag on a failing main. Do not
bypass. Fix the failure on ``develop``, re-run ``merge-main``, then tag.

### Tag was pushed but publish.yml failed

Check the run. If the failure is recoverable (flaky test, transient PyPI
error):

- Delete the tag locally and remotely: ``git tag -d vX.Y.Z && git push
  origin :refs/tags/vX.Y.Z``
- Fix the cause on ``develop`` if needed
- Re-run ``release.sh release``

If the workflow succeeded but the PyPI step failed, DO NOT delete the
tag — just re-run the workflow via the Actions UI. The tag is canonical
once pushed.

## Fleet-wide invariants

The ``release.sh`` script is **byte-identical** across all 9 Optophi
Python packages. When rewriting or extending it, the change lands in all
9 repos in the same PR wave. Drift between repos is a maintenance debt
the team has explicitly rejected.

Same applies to:

- ``publish.yml`` workflow (build + release notes + PyPI publish)
- ``.semgrep.yml`` (rule overrides)
- ``dependabot.yml``

## Done criteria

- ``release.sh release`` exited 0.
- ``publish.yml`` run on the new tag exited 0.
- PyPI version page returns 200.
- GitHub Release exists with the generated notes.
- The skill has reported all URLs to the user.
- ``scripts/release.sh status`` shows a clean state (no open PRs, main
  == develop minus the potential doc-only follow-ups).
