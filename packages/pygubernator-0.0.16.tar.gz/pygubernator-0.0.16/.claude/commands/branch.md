---
description: Create a git branch for a ticket using the Optophi naming convention and branch-base rules
argument-hint: [ticket-or-issue] [short-description-or-hotfix-flag]
allowed-tools: Bash(git status:*), Bash(git branch:*), Bash(git checkout:*), Bash(git switch:*), Bash(git rev-parse:*), Bash(git remote:*), Bash(pwd:*), Bash(gh issue view:*), Bash(command -v gh:*)
---

## Context

- Working directory: !`pwd`
- Current branch: !`git branch --show-current`
- Git status: !`git status --short --branch`
- Repo root: !`git rev-parse --show-toplevel`
- `gh` available: !`command -v gh >/dev/null 2>&1 && echo yes || echo no`

## Task

Create a git branch for ticket/issue: **$1**
Optional short description or hotfix flag: **$2**

Follow this workflow:

1. **Pick the base branch.**
   - Default: `develop` (per `CONTRIBUTING.md` — feature work branches
     from `develop`, not `main`).
   - If `$2` contains `hotfix`, `--from=main`, or the task is clearly a
     hotfix (production-critical), use `main` instead.
   - Do **not** automatically `git fetch` or `git pull`. Local state
     varies; let the user trigger updates explicitly if they want.
   - If the chosen base branch does not exist locally, stop and tell
     the user.

2. **Pick the branch prefix** using the Conventional Commit type this
   work will produce:

   | Type of change | Prefix |
   |---|---|
   | New feature | `feat/` |
   | Bug fix | `fix/` |
   | Refactor (behavior unchanged) | `refactor/` |
   | Performance | `perf/` |
   | Docs only | `docs/` |
   | Tests only | `test/` |
   | Chore / tooling / CI | `chore/` |

   If the type is ambiguous from `$1` and `$2`, default to `feat/` and
   say so in the output so the user can correct you.

3. **Build the slug.**
   - Normalize the ticket reference:
     - Numeric `123` stays `123`.
     - `ABC-123`-style keys become lowercase, e.g. `abc-123`.
     - If `$1` is non-numeric and not key-shaped, use it directly as
       the slug head.
   - Build the description slug from `$2` (and, optionally, the `gh`
     lookup below):
     - lowercase
     - hyphen-separated
     - strip special characters
     - keep concise (≤ 5 words is a good rule of thumb)
   - Final shape: `<prefix>/<ticket>-<slug>`.

4. **Optional: enrich from GitHub.** If `gh` is available and `$1` is a
   numeric issue number, try:
   ```
   gh issue view $1 --json title -q .title
   ```
   If that succeeds, use the title to refine the slug (merge with
   anything `$2` supplied). If `gh` is not installed or the call fails,
   fall back to `$2` silently. Never block on GitHub being reachable.

5. **Pre-flight checks.**
   - If `git status` shows uncommitted changes, warn the user and ask
     whether to stash, commit, or stop before creating the branch.
   - If the target branch already exists, do **not** fail silently:
     report it and offer to switch to it instead.

6. **Create and switch.**
   - `git switch -c <branch-name> <base>` to create and switch.
   - `git switch <branch-name>` if it already exists.

7. **Confirm and suggest next.**
   - Report the final branch name, the base it was cut from, and
     whether it was created or switched-to.
   - Suggest `/plan <task>` as the next step so the architectural
     analysis runs before code is written.

## Output

Keep it short and action-oriented:

- **Proposed:** `<prefix>/<ticket>-<slug>` from `<base>`.
- **Action:** created / switched to / skipped (with reason).
- **Notes:** any judgment calls (inferred prefix, `gh` fallback, slug
  truncation).
- **Next:** `/plan <task>`.

If anything is unclear — ambiguous prefix, uncommitted changes, missing
base branch — stop and ask rather than guessing.
