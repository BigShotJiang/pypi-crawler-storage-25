# API reference

Reference pages under **API reference** use **[mkdocstrings](https://mkdocstrings.github.io/)** (Google-style docstrings). Install **`pygubernator[docs]`** (included in **`[dev]`**), then from the repository root run **`pygubernator docs serve`** or **`mkdocs serve`**.

## Layout

```text
pygubernator (package)
├── agents          # LLM, pipeline, state-machine agents
├── builder         # Fluent Agent builder
├── workflow        # DAG engine and node types
├── llm             # Provider abstraction
├── config          # AgentSettings, control-plane settings, auth helpers
├── api             # FastAPI app (optional [api] extra)
├── client          # ControlPlaneClient for HTTP API
├── db              # SQLAlchemy models, repositories (optional [api])
├── runners         # run_stream_with_db, run_batch_with_db, …
├── spec            # create_llm_agent_from_version, …
└── errors          # GubernatorError hierarchy
```

## Pages

| Page | Content |
|------|---------|
| [Errors](errors.md) | `GubernatorError`, `ErrorCode`, typed exceptions |

For REST endpoints, run **`pygubernator api`** and open **`/docs`** (OpenAPI / Swagger).

## Generating from a clean tree

Some modules pull in optional dependencies (**FastAPI**, **SQLAlchemy**, …). If **`mkdocs build`** fails on import errors, install **`pygubernator[api]`** or **`pygubernator[dev]`** and retry.
