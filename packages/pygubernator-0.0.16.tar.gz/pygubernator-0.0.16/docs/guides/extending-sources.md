# Extending pygubernator: sources

A **source** reads a batch of records from somewhere and hands it to
the rest of a workflow. Built-in sources include in-memory, file, HTTP,
and SQL via SQLAlchemy. Add a new source whenever you need to pull
data from a system that pygubernator doesn't speak natively (Stripe,
Salesforce, an internal Redshift cluster, etc.).

This guide shows you how to:

1. Implement a source that satisfies the `Source` (or `AsyncSource`)
   protocol.
2. Wrap it in a `SourceFactory` and register it.
3. Test it with `FakeSource` patterns.
4. Distribute it as a plug-in.

The design intentionally mirrors [extending sinks](extending-sinks.md)
— the same registry, plugin discovery mechanism, and testing pattern
apply.

---

## 1. Implement the source

```python
# my_sources/stripe_charges.py
from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError


class StripeChargesSource:
    """Read recent Stripe charges as flat records."""

    def __init__(self, *, api_key: str, limit: int = 100) -> None:
        self._api_key = api_key
        self._limit = limit

    def read(self) -> SourceResult:
        try:
            charges = _fetch_stripe_charges(self._api_key, self._limit)
        except Exception as exc:
            raise SourceError(
                f"Stripe read failed: {exc}",
                source_type="stripe_charges",
            ) from exc
        records = [_charge_to_record(c) for c in charges]
        return SourceResult(
            success=True,
            records=records,
            records_read=len(records),
            source_type="stripe_charges",
            metadata={"limit": self._limit},
        )

    def close(self) -> None:
        """Release any held connections."""


def _fetch_stripe_charges(api_key: str, limit: int) -> list[dict]:
    raise NotImplementedError("call stripe SDK here")


def _charge_to_record(charge: dict) -> dict:
    return {"id": charge["id"], "amount": charge["amount"]}
```

If your source talks to an async API, implement
`pygubernator.connectors.AsyncSource` instead — same shape, but `read`
and `close` are `async def`.

---

## 2. Wrap it in a `SourceFactory`

```python
# my_sources/stripe_charges.py (continued)
from pygubernator.connectors import SourceFactory


def _validate(config: dict[str, Any]) -> None:
    if not config.get("api_key"):
        raise SourceError(
            "Stripe source requires 'api_key'",
            source_type="stripe_charges",
        )


def _build(config: dict[str, Any]) -> StripeChargesSource:
    return StripeChargesSource(
        api_key=config["api_key"],
        limit=int(config.get("limit", 100)),
    )


FACTORY = SourceFactory(
    type_name="stripe_charges",
    build=_build,
    validate=_validate,
    description="Reads recent Stripe charges.",
)
```

---

## 3. Register the source

### a) Direct registration

```python
from pygubernator.connectors import DEFAULT_SOURCE_REGISTRY
from my_sources.stripe_charges import FACTORY

DEFAULT_SOURCE_REGISTRY.register(FACTORY)
```

After registration, workflows can use the source:

```yaml
nodes:
  pull_charges:
    type: source
    config:
      source_type: stripe_charges
      source_config:
        api_key: "${STRIPE_API_KEY}"
        limit: 50
```

### b) Setuptools entry point

```toml
# pyproject.toml of your plugin package
[project.entry-points."pygubernator.sources"]
stripe-charges = "my_sources.stripe_charges:FACTORY"
```

The entry point may resolve to:

- a `SourceFactory` instance, or
- a callable `register(registry)` that registers one or more factories.

Hosts call `discover_source_plugins()` at startup to pick up every
advertised entry point.

---

## 4. Test the source

For consumer-side tests, use `FakeSource`:

```python
from pygubernator.testing import FakeSource

from my_app.ingest import ingest_recent_charges


def test_ingest_uses_source_records() -> None:
    source = FakeSource(records=[{"id": "ch_1"}, {"id": "ch_2"}])
    ingest_recent_charges(source)
    assert source.read_count == 1


def test_ingest_handles_read_failure() -> None:
    source = FakeSource()
    source.fail_next_read(RuntimeError("network blip"))
    with pytest.raises(RuntimeError):
        ingest_recent_charges(source)
```

Script different batches per call when you're testing pagination /
catch-up logic:

```python
source = FakeSource(scripted_batches=[
    [{"id": "ch_1"}, {"id": "ch_2"}],
    [{"id": "ch_3"}],
    [],  # empty signals end of stream
])
```

`FakeAsyncSource` is the awaited variant.

For factory + registry wiring:

```python
from pygubernator.connectors import SourceFactoryRegistry
from my_sources.stripe_charges import FACTORY


def test_factory_registers_and_validates() -> None:
    registry = SourceFactoryRegistry()
    registry.register(FACTORY)
    assert "stripe_charges" in registry

    with pytest.raises(SourceError):
        registry.create("stripe_charges", {})

    source = registry.create("stripe_charges", {"api_key": "sk_test_..."})
    assert isinstance(source, StripeChargesSource)
```

---

## Checklist before shipping

- [ ] Source class implements `read() -> SourceResult` and
      `close() -> None` (or async equivalents).
- [ ] Errors raised as `SourceError(..., source_type=...)`.
- [ ] Factory's `validate` rejects missing required config keys.
- [ ] At least one happy-path and one error-path test using
      `FakeSource` for consumers + a direct test of the real source
      class.
- [ ] `pygubernator.sources` entry point declared in `pyproject.toml`.
