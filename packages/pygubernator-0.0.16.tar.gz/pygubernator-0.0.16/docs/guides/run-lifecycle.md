# Run Lifecycle

This document explains how runs work in PyGubernator, including HTTP vs database patterns and `run_id` threading.

For wiring the control plane to Python runners, see **[Registry ↔ runtime integration](integration.md)**.

## Run States

Runs progress through these states:

1. **queued** - Run created, waiting to start
2. **running** - Run actively executing
3. **succeeded** - Run completed successfully
4. **failed** - Run completed with errors
5. **cancelled** - Run was cancelled

## Creating Runs

### Via HTTP API

```bash
POST /api/v1/runs
{
  "agent_id": "...",
  "agent_version_id": "...",
  "correlation_id": "...",
  "trigger": "manual",
  "metadata_json": {}
}
```

Returns a `RunOut` with `id`, `status: "queued"`, and `created_at`.

### Via Database (Shared Access)

```python
from pygubernator.db.repositories import create_run
from pygubernator.db.session import SessionLocal

db = SessionLocal()
try:
    run = create_run(
        db,
        agent_id=agent_id,
        agent_version_id=version_id,
        status="queued"
    )
    db.commit()
    run_id = run.id
finally:
    db.close()
```

## Run ID Threading

The `run_id` connects execution events to the run record in the database.

### Automatic Threading

When using `run_stream_with_db` or `run_batch_with_db`:

1. Run record is created (or you provide existing `run_id`)
2. `run_id` is set on the agent via `agent.set_run_id(run_id)`
3. All `AgentEvent` instances automatically include `run_id`
4. `DatabaseEventHandler` persists events with `run_id`

### Manual Threading

If using `run_stream` or `run_batch` directly:

```python
# Set run_id on agent
agent.set_run_id(run_id)

# Or pass in constructor
agent = LLMAgent(..., run_id=run_id)

# Or pass to runner
result = await run_stream(agent, transport, topic, run_id=run_id)
```

## Status Updates

### Automatic (with `*_with_db` helpers)

The convenience helpers automatically update run status:

- **queued** → **running** when execution starts
- **running** → **succeeded** or **failed** when execution completes
- Sets `started_at`, `ended_at`, `duration_ms`, `error_message`

### Manual

If managing status yourself:

```python
from pygubernator.db.repositories import get_run, update_run
from datetime import UTC, datetime

# Start
run = get_run(db, run_id)
update_run(db, run, status="running", started_at=datetime.now(UTC))
db.commit()

# Complete
ended_at = datetime.now(UTC)
duration_ms = int((ended_at - run.started_at).total_seconds() * 1000)
update_run(
    db,
    run,
    status="succeeded",
    ended_at=ended_at,
    duration_ms=duration_ms
)
db.commit()
```

## Events and Observability

Events are automatically correlated to runs via `run_id`:

- `RUN_STARTED` - When run begins
- `RUN_COMPLETED` - When run finishes
- `STEP_*` - Pipeline step events
- `TOOL_CALL_*` - Tool execution events
- `AGENT_*` - Agent lifecycle events

All events with `run_id` are persisted by `DatabaseEventHandler` to:
- `run_events` table (general events)
- `tool_calls` table (tool-specific events)

## HTTP vs Database Patterns

### HTTP Pattern

Worker only has HTTP access:

```python
# Create run
run = await client.create_run(agent_id=agent_id)
run_id = run["id"]

# Execute
result = await run_stream(agent, transport, topic, run_id=run_id)

# Post events (optional)
await client.post_event(run_id, "run.completed", "info")
```

**Pros:**
- No database dependency
- Works across networks
- Scales independently

**Cons:**
- Manual status updates
- Manual event posting (if desired)
- Network latency

### Database Pattern

Worker shares database:

```python
# Execute with automatic lifecycle
result = await run_stream_with_db(
    agent=agent,
    transport=transport,
    topic=topic,
    db_session_factory=SessionLocal,
    agent_id=agent_id
)
```

**Pros:**
- Automatic status updates
- Automatic event persistence
- Real-time UI updates
- Transactional consistency

**Cons:**
- Requires database access
- Must be on same network (or VPN)

## Best Practices

1. **Always set run_id**: Even if not using database, setting `run_id` enables future observability
2. **Use `*_with_db` helpers**: When possible, use the convenience helpers for automatic lifecycle management
3. **Handle errors**: Ensure run status is updated even on exceptions
4. **Correlation IDs**: Use `correlation_id` to link runs to external systems
5. **Metadata**: Store useful context in `metadata_json` for debugging

## Example: Complete Lifecycle

```python
from pygubernator.client import ControlPlaneClient
from pygubernator.spec import create_llm_agent_from_version
from pygubernator.runners import run_batch_with_db
from pygubernator.db.session import SessionLocal
from pygubernator.db.models import AgentVersion

# 1. Get agent/version info
async with ControlPlaneClient(api_url, token=token) as client:
    agent = await client.get_agent(agent_id)
    versions = await client.list_agents(agent_id=agent_id)
    version_id = agent["current_version_id"]

# 2. Load version and create agent
db = SessionLocal()
try:
    version = db.get(AgentVersion, version_id)
    agent = create_llm_agent_from_version(
        version,
        llm_provider_factory=lambda m: LiteLLMProvider(model=m or "gpt-4o-mini")
    )
finally:
    db.close()

# 3. Execute with automatic lifecycle
result = await run_batch_with_db(
    agent=agent,
    transport=transport,
    topic="input",
    db_session_factory=SessionLocal,
    agent_id=agent_id,
    agent_version_id=version_id
)

# 4. Check result
print(f"Success: {result.success}, Processed: {result.messages_processed}")
```
