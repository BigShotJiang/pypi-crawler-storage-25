# Canonical Use Cases

These examples define the three workflows PyGubernator should support cleanly
end to end:

1. **Agent with tools**
2. **Scheduled data-processing workflow**
3. **Human-in-the-loop approval flow**

All three are available in the repository under `examples/`.

## Agent With Tools

Example: `examples/canonical_agent_with_tools.yaml`

This pattern is for an LLM or agent node that is wired to one or more tool
sub-nodes. The key product expectations are:

- tool configuration is reusable and validated
- the agent prompt and tool context stay explicit
- runs remain observable and replayable

## Scheduled Data-Processing Workflow

Example: `examples/canonical_scheduled_pipeline.yaml`

This pattern is for cron-driven workflows. Two layers matter:

- the workflow definition, which can start from `schedule_trigger`
- the scheduler job, which controls timezone, overlap policy, and misfire policy

Current scheduler behavior supports:

- timezone-aware next-run calculation
- overlap handling with `concurrency_policy`
- delayed-run handling with `misfire_policy` and `misfire_grace_seconds`
- injected `_schedule` lineage in workflow input

## Human-In-The-Loop Approval Flow

Example: `examples/canonical_approval_flow.yaml`

This pattern is for workflows that must pause for a reviewer. The approval node
now supports:

- explicit allowed decisions
- required reviewer comments
- reviewer-facing context via `details_markdown`
- reviewer metadata surfaced through the API

## Suggested Next Step

Start with one of the canonical example files, load it through the workflow
editor or API, then adapt the prompt, tools, or schedule policy to your domain.
