# The agent workbench

PyGubernator's UI is built around the *agent workbench* — a small set of
pages that let an operator watch, inspect, and steer multi-agent
workflows without dropping into a SQL session. This guide is a tour of
the surfaces that landed in Phase 6 and how they fit together.

It is meant to be read in order; each section maps to a route in the
control-plane UI and the backend story behind it.

---

## Runs detail (`/runs/{run_id}`)

The runs detail view is the workbench's home. It is a split-pane page:

- **Left:** the **DAG viewer**, **step table**, and **artifacts**.
- **Right:** the per-step **detail panel** with the agent trace,
  artifacts, and (when the run is part of a session) the **session
  summaries** card.

### The DAG viewer

The DAG viewer is a layered topological layout: nodes are placed in
columns by *longest-path-from-source* and edges are drawn as real Bezier
curves between the node anchors. Layout is deterministic across
re-renders, so the graph does not shuffle when a step transitions to
`running`.

Edges are colour-coded by the source step's `output_handle`:

| State       | Visual                               | Meaning                                                                                    |
|-------------|--------------------------------------|--------------------------------------------------------------------------------------------|
| `fired`     | solid emerald, thicker, arrow marker | The source ran and emitted this exact handle.                                              |
| `skipped`   | dashed grey                          | The source ran but picked a different handle — this branch was *not* taken.                |
| `pending`   | dotted faint                         | The source has not committed an output yet (still pending or running).                     |

This is what closes the "branch highlighting on condition / switch
nodes" requirement: a `condition` node that fired the `true` handle
shows the `true` edge as solid and the `false` edge as dashed grey, so
the path the run took is visible at a glance.

Hovering over an edge reveals an SVG `<title>` tooltip with the
source/target handle names and a truncated JSON preview of the source
step's `output_json`. That preview is the same dict the next node
received as `input_data`, so it doubles as a quick "what flowed along
this edge?" probe.

If the run's matching workflow version isn't loaded yet (or the run is
a legacy one without a recorded `workflow_version_id`), the viewer
falls back to a flat timeline so a live run is never blanked out.

### Live updates

While a run is `pending` or `running`, the page subscribes to the
run's SSE channel. Events that fire while the page is open:

- `node_started` / `node_completed` / `node_failed` — repaints the DAG
  status (and switches the in-flight node's pulse ring on/off).
- `llm_thinking_delta` — appends a 💭-prefixed entry into the agent
  trace inside the step detail panel.
- `tool_call_*` / `llm_*` — populate the live trace before the node
  completes and the buffered `output_json._child_events` is persisted.
- `artifact_created` / `artifact_updated` — bumps a monotonic
  refresh nonce so the artifacts list refetches without a polling
  timer.

When the run reaches a terminal status the SSE connection closes and a
5-second polling refresh keeps the detail in sync until the user
navigates away.

### The agent trace

Each LLM-backed step (`agent`, `dispatch_agent`, `llm`, `llm_planner`)
records an agent trace under the `workflow_step_events` table. The
trace is rendered as a list of disclosure rows in the step detail
panel: chevron to expand, pretty-printed JSON of the event payload,
plus a "Copy as JSON" affordance for paste-into-issue debugging.

`llm_thinking_delta` events render italic + muted with a 💭 prefix and
are concatenated per LLM iteration so the trace stays readable even
for verbose chain-of-thought models.

### Artifacts

Workflow nodes call `emit_artifact(...)` (and
`update_artifact_content(...)` for streaming updates) to attach typed
artifacts to a run. The artifacts list at the run level shows every
artifact emitted, and inside each step's detail panel the
`<ArtifactList>` is hidden when empty so steps that didn't emit
anything stay uncluttered.

The artifact viewer dispatches by `type`:

| Type        | Renderer                                                                  |
|-------------|---------------------------------------------------------------------------|
| `markdown`  | Minimal dep-free Markdown (no script execution, no HTML pass-through).    |
| `table`/`csv` | RFC-4180-aware CSV parser with handles `{` `,` quoted, CRLF, escaped quotes. |
| `html`      | Sandboxed `<iframe>` with **all** sandbox flags off (defence-in-depth).   |
| `image`     | `data:` URL built from base64 or UTF-8 content.                           |
| `json`      | Pretty-printed JSON with copy-to-clipboard.                               |
| `text`      | Plain `<pre>` fallback.                                                   |

CSV artifacts mount a `<ArtifactQueryPanel>` with a sandboxed read-only
SQL prompt: queries run against an in-memory SQLite where the artifact
is loaded as a single table; the SQLite `set_authorizer` hook denies
every non-SELECT action at statement-planning time (DML, DDL, PRAGMA,
ATTACH — all rejected before execution begins). Row count and runtime
are capped via a SQLite progress handler.

---

## Sessions sidebar (Runs page)

The sessions sidebar groups runs that share a `session_id` so an
operator can follow a multi-run conversation without juggling URLs.

A session can be **renamed** and **annotated** in place: click the
pencil icon next to the session id, type a name, save. The
`workflow_sessions` table backs the metadata; partial updates are
supported (an empty string clears the name back to the raw
`session_id` fallback). The **breadcrumb** at the top of any run that
belongs to a session links back to the sidebar with the session
selected.

### Session summaries

Below the run detail, the **Session summaries** card lists every
summary attached to the session (newest first) and lets the operator
add one inline. Summaries are written to `workflow_session_summaries`
and tagged with `generated_by` (defaults to the actor's username when
omitted) so a future LLM-narrator agent can be the author too. This
is the "narrator pattern" — a slow loop that reads a session's runs
and produces a human-readable digest the operator can search through
without replaying every step.

Manual-entry summaries land today; an automated narrator that runs on
a schedule and writes summaries on the operator's behalf is a v1.1
follow-up.

---

## Guide (`/guide`)

The Guide page is a chat-style workflow dispatcher. Type a goal, run
the workflow that fits, watch the run unfold in the runs panel on the
right.

### Routing modes

The composer offers two routing modes:

- **Manual** — pick a workflow from the dropdown; the chat message is
  forwarded as `args.message`. This is the dependency-free path.
- **Auto** — the message is sent to `POST /api/v1/guide/plan`, which
  asks the configured LLM to pick a workflow from the catalog. The
  page acts on the planner's `decision`:

    - `dispatch` → run the picked workflow with
      `args = { message, ...planner_args }` so existing single-input
      workflows still work.
    - `reply` → append the LLM's text to the thread (no run started).
    - `unresolved` → surface the planner's reason as a clarifying
      message and let the user fall back to the manual picker.

The planner provider is configured server-side via the
`PYGUBERNATOR_GUIDE_PLANNER_MODEL`, `PYGUBERNATOR_GUIDE_PLANNER_API_BASE`,
and `PYGUBERNATOR_GUIDE_PLANNER_API_KEY` env vars (or per-request
overrides on the body). When no model is configured the route returns
503 — there is no silent fallback to a free-tier cloud model.

Manual stays the default so operators without a planner LLM
configured see no behaviour change.

### Sessions and correlation

Every dispatch is tagged `trigger="guide"` and shares a stable
`correlation_id` minted when the chat session opens. The runs panel on
the right polls `GET /api/v1/workflows/runs/list?correlation_id=…`
every four seconds, so every run spawned in a chat is reachable from
within that chat. "New chat" mints a fresh `correlation_id` and clears
the thread.

---

## Knowledge → Notebooks (`/knowledge/notebooks`)

Notebooks are the agent's long-lived state, made editable. Each entry
is a `MemoryScope` (any combination of `agent_id`, `workflow_id`,
`user_id`, `run_id`) that has a saved `context_surface` —
`ContextSurface`'s 4-section Markdown document (`facts`,
`questions`, `next_actions`, `log`).

The page is a sibling of the existing knowledge-base chunk browser at
`/knowledge`. It has two cards:

- **Left:** a list of every scope with a saved surface, decoded from
  the composite key into "agent X · wf Y" so the operator does not
  re-parse the pipe-delimited format. A "New scope" form mints a
  brand-new entry.
- **Right:** a dirty-tracked Markdown editor. Save round-trips the
  Markdown through `ContextSurface.from_markdown()` so what the
  operator sees is byte-identical to what an agent reads programmatically.

A 404 from `GET /api/v1/memory/surface` (a brand-new scope) falls back
to the empty 4-section template so the user types into a structured
shell, not a blank page.

---

## Active agents panel

`<ActiveAgentsPanel>` is mounted on both the Runs list and the Runs
detail view. It polls `/api/v1/agents/heartbeats` every 10 seconds
and shows:

- A pulse dot (green / amber / red) for liveness.
- The agent's current `run_id` and `node_id` (when running).
- Context-window usage (`context_used_tokens`).
- The joined `agent_name` for quick reading.

Workflow-spawned agents populate those keys via the
`HeartbeatEmitter.status_provider` convention; the route docstring +
tests pin the contract so a future heartbeat-payload refactor cannot
silently break the panel.

---

## Putting it together

A typical operator session in the workbench looks like:

1. Open `/guide`, mint a chat, type a goal in **Auto** mode. The
   planner picks a workflow; the run starts.
2. The runs panel on the right shows the run; click into it to land
   on the run detail page.
3. Watch the DAG: the in-flight node pulses, the fired branch is
   solid emerald, the skipped branch is dashed grey.
4. Click an artifact — markdown renders inline; a CSV artifact opens
   the SQL query panel for ad-hoc inspection.
5. The session-summaries card grows as the chat continues; rename
   the session via the sidebar pencil for easy retrieval next week.
6. If an agent is "remembering" something wrong, jump to
   `/knowledge/notebooks`, find the scope, edit its facts /
   next-actions in place, save. The next run reads exactly what was
   typed.

That loop — *watch a run, inspect what flowed, edit the agent's
state* — is the workbench in one paragraph. Every page on this tour
exists to make one of those three verbs faster.
