# Canonical Use Cases Backlog

This backlog tracks the implementation work needed to make PyGubernator
production-ready for three canonical workflows:

1. Agent with tools
2. Scheduled data-processing workflow
3. Human-in-the-loop approval flow

The goal is to close gaps systematically while preserving the existing
architecture:

- stateless runtime logic in `pygubernator.workflow`
- orchestration in `pygubernator.api.services`
- persistence in `pygubernator.db`
- editor UX in `pygubernator.ui`

## Status

### Milestone 1: Agent With Tools

- [x] Create and track the canonical backlog in-repo
- [x] Unify workflow tool loading across `agent` and `tool` nodes
- [x] Add static validation and lint coverage for `agent` and `tool` configs
- [x] Align Agent/Tool editor forms with the runtime contract
- [x] Expand test coverage for direct-call and factory-based tool loading

### Milestone 2: Human-In-The-Loop Approval Flow

- [x] Make approval decisions explicit and validated
- [x] Add typed request/response models for approval APIs
- [x] Extend approval config for reviewer-facing UX and stricter semantics
- [x] Improve approval listing/detail surfaces for operators and reviewers
- [x] Add coverage for rejection, invalid decisions, and resumed execution

### Milestone 3: Scheduled Data-Processing Workflow

- [x] Make scheduled jobs timezone-aware end-to-end
- [x] Add scheduler ownership/claiming semantics for safe execution
- [x] Add operational controls: concurrency and misfire policy
- [x] Improve schedule lineage in workflow run observability
- [x] Add coverage for timezone handling and scheduler robustness

### Milestone 4: Canonical Golden Paths

- [x] Add first-class examples for the three canonical workflows
- [x] Add documentation for the golden paths and operational expectations
- [x] Add validation coverage for the canonical workflows

### Milestone 5: Control-Plane UI Completion

- [x] Extend the schedules admin page for timezone and execution-policy editing
- [x] Surface schedule lineage clearly in workflow run detail
- [x] Add a reviewer-facing approval panel for paused workflow runs
- [x] Surface `awaiting_approval` state consistently in run browsing UX

## Immediate Next Focus

Current execution focus is Milestone 5. The next patch set should close the
remaining control-plane UX gaps so the new scheduler and approval semantics are
fully operable from the UI, not just the API.

## Newly Closed Robustness Gaps

- [x] Roll back failed SQLAlchemy sessions before claim release in background
  workflow execution paths
- [x] Preserve `awaiting_approval` state in the background workflow runner
- [x] Resume approval checkpoints using the current keyword-only engine API
- [x] Replace the broken shared UI `Switch` primitive dependency with a local
  implementation so frontend type-checks do not rely on an unresolved package
- [x] Exclude generated `ui/static/**` assets from ESLint so lint results stay
  focused on source hygiene instead of build artifacts

## Remaining UI Warning Follow-Up

- [ ] Clean up existing React hook dependency warnings in non-canonical UI
  surfaces (`LibraryTestJobDetailInner`, `CanvasSearch`, and some workflow
  config forms)

## Known Hygiene Follow-Up

- [x] Migrate FastAPI startup hooks from deprecated `on_event()` handlers to
  lifespan handlers
