# ADR-001: PyGubernator layers (core, spec, agent_store)

## Context

PyGubernator is organized into three layers:

1. **`pygubernator.core`** — Stateless runtime: agents, tools, LLM, transport, types. No SQLAlchemy or FastAPI.
2. **`pygubernator.spec`** — Configuration-driven assembly: `AgentVersionLike`, `create_llm_agent_from_version`, workflow YAML loaders (`WorkflowLoader` via lazy import).
3. **`pygubernator.agent_store`** — Persistence: `AgentStoreClient` (ABC), `SQLAlchemyAgentStore`, `InMemoryAgentStore` (SQLite `:memory:`).

The control-plane FastAPI app depends on `SQLAlchemyAgentStore` per request via `get_agent_store()`.

## AgentStoreClient method surface

Mirrors former `pygubernator.db.repositories` operations: agents and versions, runs/events/tool calls, workflows and step runs, audit, policies, incidents.

## Core public namespace

Import from `pygubernator.core` for a focused API; `import pygubernator` remains available with lazy-loaded symbols for convenience.
