# Daily research workflow

This guide walks through the "daily AI news" use case end-to-end: a
scheduled agent that searches the web, summarizes articles in
parallel, writes notes to a durable context surface, and halts if the
run exceeds its token budget.

## 1. Prerequisites

```sh
pip install pygubernator[integrations,packaging]
```

Supply an LLM key via environment (e.g. `OPENAI_API_KEY`), and —
optionally — a search provider key if you ship one as a custom tool
(Tavily, Brave, Serper). No custom tools are required for the core
shape below; the example uses a stub.

## 2. Safety: enforce policy + audit + budget

```python
from pygubernator.policy import (
    AllowlistRule, CallerContext, PolicyEnforcer,
)
from pygubernator.records import InMemoryRecordStore
from pygubernator.safety import (
    BudgetTracker, RunBudget, ToolCallAuditWriter,
)
from pygubernator.tools import ToolRegistry

records = InMemoryRecordStore()
enforcer = PolicyEnforcer(
    extra_rules=[AllowlistRule(tools=frozenset({"search_news", "fetch_url"}))],
)
audit = ToolCallAuditWriter(record_store=records)
budget = BudgetTracker(budget=RunBudget(
    max_tokens=20_000, max_tool_calls=50, max_cost_usd=0.50,
))
tools = ToolRegistry(
    policy_enforcer=enforcer,
    audit_writer=audit,
    budget_tracker=budget,
    caller_context=CallerContext(agent_id="daily-research"),
)
```

Every tool call the agent makes now flows through `enforcer` (deny
anything not on the allowlist), gets written to `records` via
`audit`, and is counted against `budget`. Budget exhaustion raises
`BudgetExceeded`, which `LLMAgent` surfaces in the run result.

## 3. Memory: durable context across runs

```python
from pathlib import Path
from pygubernator.memory import FileContextStore, MemoryScope

context = FileContextStore(root=Path.home() / ".pygubernator" / "context")
scope = MemoryScope(agent_id="daily-research")
```

Pass `context_store=context` to your `LLMAgent`. On each run the
agent's `ContextSurface` (facts / questions / next_actions / log)
reloads from disk, and `on_run_end()` writes it back.

## 4. Autonomy: parallel summarize + heartbeat

A minimal YAML workflow looks like this. The `variables` bag carries
the shared budget tracker and an in-process heartbeat emitter.

```yaml
meta:
  name: daily-research
  version: 0.1.0
nodes:
  fetch:
    type: http
    config:
      url: "{{ variables.news_url }}"
  summarize:
    type: parallel
    config:
      handler: "var:summarize_article"   # injected at run time
      concurrency: 4
  note:
    type: context_surface
    config:
      operation: append
      section: log
      item: "Summarized {{ input_data.count }} articles"
  heartbeat_end:
    type: watch_and_act
    config:
      condition: True
      action: "var:mark_done"
      poll_interval_s: 0
      max_cycles: 1
edges:
  - { source: fetch, target: summarize }
  - { source: summarize, target: note }
  - { source: note, target: heartbeat_end }
```

Inject identity + safety into `variables` when you call the engine:

```python
from pygubernator.autonomy import HeartbeatEmitter, HeartbeatWriter

heartbeats = HeartbeatWriter(record_store=records)
emitter = HeartbeatEmitter(
    agent_id="daily-research", writer=heartbeats, interval_s=30,
)
emitter.start()
try:
    result = await engine.run(
        input_data={},
        variables={
            "__agent_id__": "daily-research",
            "__heartbeat__": emitter,
            "__budget__": budget,
            "summarize_article": your_async_fn,
            "mark_done": another_async_fn,
        },
    )
finally:
    emitter.stop()
```

`_check_run_budget` in the engine checks `variables["__budget__"]`
between topological levels and aborts the run with a clear error
when the wall-clock limit fires.

## 5. Packaging: distribute the workflow

```sh
pygubernator new pack daily-research
cd daily-research
# Edit workflows/daily-research-demo.yaml to the shape above.
pygubernator pack build . --output daily-research-0.1.0.pgpack
pygubernator pack install daily-research-0.1.0.pgpack
pygubernator pack list
```

Installed packs land in `~/.pygubernator/packs/daily-research/`. Tool
bundles advertised via the `pygubernator.tools` entry-point group are
picked up automatically when you call
`discover_tool_bundles(registry)`.

## 6. Operator dashboard surfaces

- **Tool-call audit:** `records.query("tool_call_audit", scope="daily-research")`
  returns every call, including deny decisions and sanitized params.
- **Memory access:** `records.query("memory_access_audit", scope=scope.to_key())`
  shows every read/write against the context surface.
- **Heartbeats:** `heartbeats.latest_for("daily-research")` returns the
  most recent beat; `StaleAgentDetector` bulk-checks a fleet.

## 7. Going further

- Swap `InMemoryRecordStore` for `SqlAlchemyRecordStore` so audit
  history survives restarts.
- Replace the handler closures with real search + summarize tools
  packaged as entry points under `pygubernator.tools`.
- For untrusted snippets, route `python_exec` through
  `sandbox: subprocess` (POSIX rlimits) or `sandbox: docker`
  (`pygubernator[packaging]`).
