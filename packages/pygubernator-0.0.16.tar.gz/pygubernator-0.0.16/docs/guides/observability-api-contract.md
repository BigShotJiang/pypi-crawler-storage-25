# Observability API Contract

## GET `/api/v1/observability/metrics`
Query:
- `window`: `15m | 1h | 24h | 7d` (default: `24h`)

Response:
- `totals`: global aggregate metrics
- `window`: selected range metadata
- `series`: bucketed points with runs/failures/successes/avg latency/cost

## GET `/api/v1/observability/incidents`
Query:
- `status` (optional)
- `severity` (optional)
- `owner` (optional)
- `limit` (default 100, max 500)

Response:
- `items[]`: incident records

## GET `/api/v1/observability/incidents/{id}`
Response:
- Incident record by id.

## POST `/api/v1/observability/incidents`
Body:
- `title`, `severity`, optional `run_id`, `alert_id`, `owner`, `details`

## POST `/api/v1/observability/incidents/{id}/ack`
- Marks incident acknowledged.

## POST `/api/v1/observability/incidents/{id}/silence`
Body:
- `until`: ISO datetime

## POST `/api/v1/observability/incidents/{id}/resolve`
- Marks incident resolved.

## POST `/api/v1/observability/incidents/{id}/assign`
Body:
- `owner`: string

## GET `/api/v1/policies/alerts`
Response additions:
- `open_incidents`: number
- `firing`: bool (true when unresolved incidents exist for rule)

## GET `/api/v1/policies/alerts/history`
Query:
- `alert_id` (optional)
- `limit` (default 100, max 500)

Response:
- Alert-linked incident history items ordered by recent first.

## POST `/api/v1/policies/alerts/{id}/toggle`
Body:
- `enabled`: bool

Response:
- `ok`, `id`, `enabled`

## GET `/api/v1/runs`
New query params:
- `has_error` (optional bool)
- `created_from` (optional datetime)
- `created_to` (optional datetime)
- `sort_by`: `created_at | duration_ms | cost_usd_micros`
- `sort_order`: `asc | desc`

Response additions:
- `facets.statuses[]` with count by status

## POST `/api/v1/runs/{id}/control`
Body:
- `action`: `cancel | requeue | restart`

Notes:
- Terminal runs reject `cancel`.
- `running` runs reject `requeue` and `restart`.

## POST `/api/v1/runs/{id}/replay`
Response:
- `new_run_id` for newly queued replay run.
