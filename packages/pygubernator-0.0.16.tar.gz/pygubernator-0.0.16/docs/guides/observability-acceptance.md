# Observability Acceptance Criteria

- Metrics endpoint supports all defined windows and returns non-empty series buckets for active ranges.
- Incident API supports create/list and all lifecycle actions.
- Incident detail endpoint resolves by id.
- Incident lifecycle actions are audit logged.
- Runs endpoint supports error filtering and status facets.
- Observability overview page renders KPI + incident summary.
- Incident page supports acknowledge, silence, resolve, assign actions.
- Incident page supports owner and status filtering.
- Incident detail page shows linked run/alert context and audit trail.
- Runs explorer supports status and error filtering.
- Run detail page supports cancel/requeue/restart/replay actions with confirmation.
- Run detail page supports timeline drilldown by entry type and event level.
- Alerts page shows rule firing state and alert history.
- Alerts page supports creating rules and toggling enable/disable state.
- All new UI pages preserve existing styling patterns and route navigation.
