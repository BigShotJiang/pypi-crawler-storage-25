# Extending pygubernator: sinks

A **sink** receives a batch of records from a workflow. Built-in sinks
include file, HTTP, database, Kafka, RabbitMQ, S3, console, and
in-memory variants. Add a new sink whenever you need to push workflow
output to a system that pygubernator doesn't speak natively (Notion,
Pinecone, BigQuery, your internal warehouse, etc.).

This guide shows you how to:

1. Implement a sink that satisfies the `Sink` (or `AsyncSink`)
   protocol.
2. Wrap it in a `SinkFactory` and register it.
3. Test it with `FakeSink` patterns.
4. Distribute it as a plug-in.

---

## 1. Implement the sink

Sinks are plain Python objects. The protocol is two methods:

```python
# my_sinks/notion.py
from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError


class NotionSink:
    """Push records as rows to a Notion database."""

    def __init__(self, *, database_id: str, token: str) -> None:
        self._database_id = database_id
        self._token = token

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        # Real implementation would call notion-client here.
        try:
            for record in records:
                _create_notion_page(self._database_id, self._token, record)
        except Exception as exc:
            raise SinkError(
                f"Notion write failed: {exc}",
                sink_type="notion",
            ) from exc

        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="notion",
            metadata={"database_id": self._database_id},
        )

    def close(self) -> None:
        """Release any resources (no-op for stateless HTTP sinks)."""


def _create_notion_page(database_id: str, token: str, record: dict) -> None:
    raise NotImplementedError("call notion-client here")
```

If your sink talks to an async API, implement
`pygubernator.connectors.AsyncSink` instead — same shape, but `send`
and `close` are `async def`. Both protocols are runtime-checkable.

---

## 2. Wrap it in a `SinkFactory`

`SinkFactory` is a frozen dataclass that captures the three things the
registry needs:

- `type_name` — stable identifier used in workflow YAML.
- `validate(config)` — raise `SinkError` when required keys are missing.
- `build(config)` — return a configured sink instance.

Putting the factory at the bottom of the same module keeps related
code together and is the pattern every built-in sink follows.

```python
# my_sinks/notion.py (continued)
from pygubernator.connectors import SinkFactory


def _validate(config: dict[str, Any]) -> None:
    for key in ("database_id", "token"):
        if not config.get(key):
            raise SinkError(
                f"Notion sink requires '{key}' in config",
                sink_type="notion",
            )


def _build(config: dict[str, Any]) -> NotionSink:
    return NotionSink(
        database_id=config["database_id"],
        token=config["token"],
    )


FACTORY = SinkFactory(
    type_name="notion",
    build=_build,
    validate=_validate,
    description="Writes records to a Notion database.",
)
```

---

## 3. Register the sink

### a) Direct registration (in-process)

```python
from pygubernator.connectors import DEFAULT_SINK_REGISTRY
from my_sinks.notion import FACTORY

DEFAULT_SINK_REGISTRY.register(FACTORY)
```

After registration, every workflow can use the sink:

```yaml
nodes:
  publish:
    type: sink
    config:
      sink_type: notion
      sink_config:
        database_id: "abc123"
        token: "secret_..."
```

### b) Setuptools entry point

```toml
# pyproject.toml of your plugin package
[project.entry-points."pygubernator.sinks"]
notion = "my_sinks.notion:FACTORY"
```

The entry point may resolve to:

- a `SinkFactory` instance (recommended), or
- a callable `register(registry)` that registers one or more factories.

Hosts call `discover_sink_plugins()` (or
`SinkFactoryRegistry.discover_plugins`) at startup to pick up every
advertised entry point.

---

## 4. Test the sink

For unit tests of your sink class, use a real `NotionSink` against a
mocked transport (`pytest-httpx`, `responses`, etc.).

For tests of code that *consumes* a sink — a workflow node, a recipe
runner, an integration helper — use `FakeSink` from
`pygubernator.testing`. It satisfies the `Sink` protocol and records
everything for assertions:

```python
import pytest

from pygubernator.testing import FakeSink

from my_app.publisher import publish_via_sink


def test_publisher_emits_one_batch_per_user() -> None:
    sink = FakeSink(sink_type="notion")
    publish_via_sink(sink, users=[{"id": 1}, {"id": 2}])

    assert sink.batch_count == 1
    assert sink.records == [{"id": 1}, {"id": 2}]
    assert sink.last_metadata == {"schema": "user"}


def test_publisher_handles_send_failure() -> None:
    sink = FakeSink()
    sink.fail_next_send(RuntimeError("transient"))
    with pytest.raises(RuntimeError):
        publish_via_sink(sink, users=[{"id": 1}])
```

`FakeAsyncSink` is the awaited variant, useful for async pipeline
tests.

To verify your factory and registry wiring end-to-end:

```python
from pygubernator.connectors import SinkFactoryRegistry
from my_sinks.notion import FACTORY


def test_factory_registers_and_validates() -> None:
    registry = SinkFactoryRegistry()
    registry.register(FACTORY)
    assert "notion" in registry

    with pytest.raises(SinkError):
        registry.create("notion", {})  # missing database_id / token

    sink = registry.create(
        "notion",
        {"database_id": "x", "token": "y"},
    )
    assert isinstance(sink, NotionSink)
```

---

## Checklist before shipping

- [ ] Sink class implements `send(records, metadata) -> SinkResult`
      and `close() -> None` (or async equivalents).
- [ ] Errors raised as `SinkError(..., sink_type=...)` so the engine
      can route + audit them properly.
- [ ] Factory's `validate` rejects missing required config keys with
      a clear message.
- [ ] At least one happy-path and one error-path test using
      `FakeSink` for consumers + a direct test of the real sink class.
- [ ] `pygubernator.sinks` entry point declared in `pyproject.toml`.
