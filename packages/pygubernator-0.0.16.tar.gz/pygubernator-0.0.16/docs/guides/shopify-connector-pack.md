# Shopify Connector Pack

`pygubernator` now includes a reference Shopify connector extension package under:

- `extensions/shopify_connector`

It is distributed as a normal Python package with entry points:

- `pygubernator.sources -> shopify`
- `pygubernator.sinks -> shopify`

## Install locally

```bash
pip install -e extensions/shopify_connector
```

Because the API startup now runs connector plugin discovery, installing the
package is enough for workflows to use:

- `source_type: shopify`
- `sink_type: shopify`

## Required credentials

Configure these in admin credentials or environment:

- `PYGUBERNATOR_SHOPIFY_STORE_DOMAIN`
- `PYGUBERNATOR_SHOPIFY_ACCESS_TOKEN`
- `PYGUBERNATOR_SHOPIFY_API_VERSION` (optional, defaults to `2025-01`)

## Canonical workflows

Reference workflows are provided in:

- `examples/shopify_orders_ingest.yaml`
- `examples/shopify_fulfillment_sync.yaml`
- `examples/shopify_daily_reconciliation.yaml`
