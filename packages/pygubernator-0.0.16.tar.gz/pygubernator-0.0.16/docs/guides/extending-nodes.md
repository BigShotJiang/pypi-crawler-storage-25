# Extending pygubernator: nodes

A **node** is a single block in a workflow DAG. Nodes have explicit
input/output ports, configuration fields, and an `execute` method.
Reach for a node (rather than a tool) when you want a building block
that:

- shows up in the visual editor's palette,
- declares typed input/output schemas,
- has its own configuration form, and
- can be wired into a deterministic graph.

This guide shows you how to:

1. Implement a `Node` and a `NodeFactory`.
2. Test it with `NodeTestHarness`.
3. Distribute it as a plug-in.

---

## 1. Implement the node

A node is any object that satisfies the
`pygubernator.workflow.Node` protocol — a `node_type` string and an
async `execute(context)` method that returns a `NodeResult`.

```python
# my_nodes/uppercase.py
from __future__ import annotations

from typing import Any

from pygubernator.workflow._types import (
    NodeContext,
    NodeResult,
    NodeStatus,
)


class UppercaseNode:
    """Uppercase a single string from upstream input."""

    node_type = "uppercase"

    def __init__(self, node_id: str, config: dict[str, Any]) -> None:
        self._node_id = node_id
        self._key = str(config.get("key", "text"))

    async def execute(self, context: NodeContext) -> NodeResult:
        value = context.input_data.get(self._key, "")
        if not isinstance(value, str):
            return NodeResult(
                node_id=self._node_id,
                status=NodeStatus.FAILED,
                error=f"Expected str at '{self._key}', got {type(value).__name__}",
            )
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.SUCCESS,
            output={self._key: value.upper()},
        )


class UppercaseNodeFactory:
    """Factory pygubernator uses to construct nodes."""

    def create(self, node_id: str, config: dict[str, Any]) -> UppercaseNode:
        return UppercaseNode(node_id, config)
```

`NodeFactory` is a one-method protocol. The runtime calls
`factory.create(node_id, config)` whenever a workflow that uses your
node type needs a fresh instance.

> Optional: declare a `NodeTypeDescription` to populate the visual
> editor's palette + inspector. See the existing
> `pygubernator/workflow/_metadata.py` for examples (`category`,
> `display_name`, `inputs`, `outputs`, `fields`,
> `required_credentials`, etc.). Plug-ins can register descriptions
> via `NodeTypeRegistry.register_description`.

---

## 2. Test the node

Use `NodeTestHarness` from `pygubernator.testing`:

```python
# tests/test_uppercase_node.py
import pytest

from pygubernator.testing import NodeTestHarness
from pygubernator.workflow._types import NodeStatus

from my_nodes.uppercase import UppercaseNodeFactory


@pytest.mark.asyncio
async def test_uppercases_value() -> None:
    harness = NodeTestHarness(UppercaseNodeFactory())
    result = await harness.execute(
        config={"key": "name"},
        input_data={"name": "alice"},
    )
    assert result.status is NodeStatus.SUCCESS
    assert result.output == {"name": "ALICE"}


@pytest.mark.asyncio
async def test_returns_failed_result_on_non_string() -> None:
    harness = NodeTestHarness(UppercaseNodeFactory())
    result = await harness.execute(input_data={"text": 42})
    assert result.status is NodeStatus.FAILED
    assert "Expected str" in (result.error or "")
```

The harness builds the node through the factory exactly as the
`WorkflowEngine` does, then runs `execute` against a context you
control. You can inspect `harness.last_node` and `harness.last_context`
after a run for deeper assertions.

---

## 3. Register the node with the runtime

### a) Direct registration

```python
from pygubernator.workflow import NodeTypeRegistry
from my_nodes.uppercase import UppercaseNodeFactory

registry = NodeTypeRegistry()
registry.register("uppercase", UppercaseNodeFactory())
```

### b) Setuptools entry point

```toml
# pyproject.toml of your plugin package
[project.entry-points."pygubernator.nodes"]
uppercase = "my_nodes.uppercase:UppercaseNodeFactory"
```

The entry point must resolve to a **factory class** (not an instance —
pygubernator instantiates it for you). At startup the host calls
`registry.discover_plugins(group="pygubernator.nodes")` to register
every advertised type.

See the [plug-in distribution guide](plugin-distribution.md) for the
complete `pyproject.toml` boilerplate.

---

## Tips

- Nodes should be **stateless** between executions. Per-run state
  belongs on `NodeContext.variables`, not on `self`.
- Long-running I/O — keep it inside `execute` so the engine can
  cancel and retry properly.
- Validation belongs in your factory's `create` (raise early) or in
  the first lines of `execute` (return `NodeStatus.FAILED` with a
  descriptive `error`). Don't `raise`; the engine converts unhandled
  exceptions to failures, but a returned `NodeResult` is more
  observable.
- If your node needs an external credential (an API key, OAuth token,
  etc.), declare it on the `NodeTypeDescription.required_credentials`
  tuple — the editor will show an inline credential prompt before the
  user runs the workflow.

---

## Checklist before shipping

- [ ] Class implements `node_type` (str) and async `execute`.
- [ ] Factory implements `create(node_id, config) -> Node`.
- [ ] At least one happy-path test and one failure-path test using
      `NodeTestHarness`.
- [ ] (Optional) `NodeTypeDescription` registered for editor support.
- [ ] `pygubernator.nodes` entry point declared in `pyproject.toml`.
