# Extending pygubernator: tools

A **tool** is a single async function an agent can call. Tools are the
smallest unit of extensibility — if all you need is "let the agent
search the web" or "let the agent send an email", a tool is the right
shape.

This guide shows you how to:

1. Write a tool with the `@tool` decorator.
2. Test it with `ToolTestHarness`.
3. Distribute it as a plug-in package other people can `pip install`.

> Looking for nodes, sinks, or sources instead?
> See [extending nodes](extending-nodes.md), [extending sinks](extending-sinks.md),
> [extending sources](extending-sources.md), and the
> [plug-in distribution guide](plugin-distribution.md).

---

## 1. Write a tool

Tools live in any Python module. The `@tool` decorator turns a regular
async function into something pygubernator can register and call.

```python
# my_tools/web.py
from __future__ import annotations

import httpx

from pygubernator.tools import tool


@tool(description="Fetch a URL and return its body as text.")
async def fetch_url(url: str, timeout: float = 10.0) -> dict[str, str]:
    """Return the response body of ``url``.

    Args:
        url: Absolute http(s) URL to fetch.
        timeout: Request timeout in seconds.
    """
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.get(url)
        resp.raise_for_status()
    return {"url": url, "body": resp.text}
```

Key things the decorator does:

- **Name** defaults to the function name (`fetch_url`).
- **Description** defaults to the docstring's first line if you omit
  it.
- **JSON Schema** for parameters is inferred from your type
  annotations — `str`, `int`, `float`, `bool`, `list[T]`, `dict`,
  unions with `None`. Override with `parameters_schema=...` when you
  need something custom.

A tool can be sync or async; pygubernator awaits the result either
way.

---

## 2. Test the tool

Use `ToolTestHarness` from `pygubernator.testing`. It runs your tool
through the same pipeline production agents use, so policy, audit, and
budget hooks all fire — but defaults to no-op so a vanilla harness
"just works".

```python
# tests/test_fetch_url.py
import pytest

from pygubernator.testing import ToolTestHarness

from my_tools.web import fetch_url


@pytest.mark.asyncio
async def test_fetch_url_returns_body(httpx_mock):  # using pytest-httpx
    httpx_mock.add_response(url="https://example.com", text="hello")

    harness = ToolTestHarness(fetch_url)
    result = await harness.call({"url": "https://example.com"})

    assert result.success is True
    assert result.output["body"] == "hello"


@pytest.mark.asyncio
async def test_fetch_url_failure_propagates_error():
    @tool()
    async def boom() -> dict:
        raise RuntimeError("nope")

    harness = ToolTestHarness(boom)
    result = await harness.call({})

    assert result.success is False
    assert "nope" in (result.error or "")
```

When you have multiple tools to test together:

```python
harness = ToolTestHarness(tool_a, tool_b)
result = await harness.call("tool_a", {"x": 1})  # name required
```

---

## 3. Register tools with the runtime

You have three ways to surface your tools to a `ToolRegistry`:

### a) Direct registration (in-process)

```python
from pygubernator.tools import ToolRegistry
from my_tools.web import fetch_url

registry = ToolRegistry()
registry.register(fetch_url)
```

### b) Module-level scan

If your module exposes several `@tool`-decorated functions, register
them all at once:

```python
import my_tools.web

registry.register_module(my_tools.web)  # registers every @tool in the module
```

### c) Setuptools entry point (the contributor-friendly way)

Publish your package with a `pygubernator.tools` entry point. The
control plane (and any host calling `discover_tool_bundles`) will
load and register your tools at startup:

```toml
# pyproject.toml of your plugin package
[project.entry-points."pygubernator.tools"]
my-web-tools = "my_tools.web:register"
```

…where `register` is a callable that registers your tools:

```python
# my_tools/web.py (continued)
def register(registry):
    """Entry point hook — pygubernator calls this with a ToolRegistry."""
    registry.register_module(__import__(__name__, fromlist=["register"]))
```

A bundle's `register` callable can also accept and return individual
tools — `pygubernator.packaging.discover_tool_bundles` handles both
shapes.

See the [plug-in distribution guide](plugin-distribution.md) for the
full `pyproject.toml` boilerplate (`build-backend`, classifiers,
versioning, etc.).

---

## 4. What about safety?

Every tool call in pygubernator passes through:

1. **Policy enforcement** (allow / deny / require approval).
2. **Budget tracking** (per-run call caps).
3. **Audit logging** (full call record with policy decision, params,
   output, duration).

You don't need to do anything in your tool to opt in — the
`ToolRegistry` wires these in. If you want to test policy interactions,
construct the registry yourself and pass it into the harness:

```python
from pygubernator.policy import PolicyEnforcer
from pygubernator.tools import ToolRegistry
from pygubernator.testing import ToolTestHarness

enforcer = MyEnforcer(...)
registry = ToolRegistry(policy_enforcer=enforcer)
harness = ToolTestHarness(my_tool, registry=registry)
```

---

## Checklist before shipping

- [ ] Function is `async def` (or sync — pygubernator handles both).
- [ ] All parameters are typed; the inferred JSON Schema looks right.
- [ ] Docstring describes what the tool returns.
- [ ] At least one happy-path and one error-path test using
      `ToolTestHarness`.
- [ ] `pygubernator.tools` entry point declared in `pyproject.toml` if
      you're publishing a plug-in package.
