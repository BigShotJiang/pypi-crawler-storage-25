# Tools editor v1 (Option A)

Tools editor v1 introduces first-class **Tool** resources that are managed alongside workflows and agents.

## Why this exists

- Tool definitions become versioned API resources (`tools`, `tool_versions`) instead of ad-hoc inline config.
- Operators can draft, publish, and test tool workflow subgraphs before attaching them to workflows/agents.
- Tool tests execute under a dedicated `tool_test` profile with node allowlisting.

## API surface

Protected endpoints are exposed under `/api/v1/tools`:

- `GET /api/v1/tools`
- `POST /api/v1/tools`
- `GET /api/v1/tools/{tool_id}`
- `PATCH /api/v1/tools/{tool_id}`
- `GET /api/v1/tools/{tool_id}/versions`
- `POST /api/v1/tools/{tool_id}/versions`
- `POST /api/v1/tools/{tool_id}/versions/{version_id}/publish`
- `POST /api/v1/tools/{tool_id}/versions/{version_id}/test`

Tool version payloads carry a `spec_json.workflow_spec` object, which is executed by the tool test endpoint.

## UI integration

The workflow editor shell now supports a third top-level area:

- `Workflow`
- `Agents`
- `Tools`

When `?area=tools` is active, the left panel switches to tools-specific sub-tabs:

- `Browse` (catalog)
- `Definition` (metadata + JSON workflow spec)
- `Test` (sample input and execution result)

## Validation and integration hooks

Workflow and agent version saves now validate version-pinned tool catalog references:

- `tool_id`
- `tool_version_id`

If references are missing or mismatched, API saves fail with `400`.

## Security boundaries in v1

- Tool tests are executed with an explicit node allowlist (`tool_test` profile).
- Tool catalog refs in runtime tool nodes are not auto-resolved by generic workflow runtime; callers must resolve them intentionally.
- Authoring remains auditable through existing `audit_logs` events.
