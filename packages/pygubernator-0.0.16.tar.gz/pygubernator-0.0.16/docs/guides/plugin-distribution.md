# Distributing a pygubernator plug-in

This guide is the cross-cutting reference for everything specific to
publishing a pygubernator extension as an installable package — the
`pyproject.toml`, the entry-point groups, the discovery mechanism, and
the conventions that keep plug-ins working across pygubernator
versions.

For the per-extension concept guides, start with:

- [Extending tools](extending-tools.md)
- [Extending nodes](extending-nodes.md)
- [Extending sinks](extending-sinks.md)
- [Extending sources](extending-sources.md)

---

## 1. Anatomy of a plug-in package

```
my-pygubernator-plugin/
├── pyproject.toml
├── README.md
├── src/
│   └── my_plugin/
│       ├── __init__.py
│       ├── tools.py        # @tool functions + register hook
│       ├── nodes.py        # NodeFactory classes
│       ├── sinks.py        # SinkFactory at module scope
│       └── sources.py      # SourceFactory at module scope
└── tests/
    ├── conftest.py
    ├── test_tools.py
    ├── test_nodes.py
    ├── test_sinks.py
    └── test_sources.py
```

You don't have to ship all four extension types in one package — most
plug-ins ship one or two. The structure above is just the "everything
in one repo" layout we use in our scaffolds (`pygubernator new`).

---

## 2. The `pyproject.toml` template

```toml
[build-system]
requires = ["setuptools>=77.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "my-pygubernator-plugin"
version = "0.1.0"
description = "Adds Notion sink, Stripe source, and a few helper tools to pygubernator."
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
authors = [{ name = "Jane Doe", email = "jane@example.com" }]
classifiers = [
    "Development Status :: 4 - Beta",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Framework :: Pygubernator",
]
dependencies = [
    "pygubernator>=0.1,<1.0",
    # Add per-extension transport / SDK deps here:
    # "notion-client>=2.0",
    # "stripe>=10.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    "ruff>=0.9",
]

[project.urls]
Homepage = "https://github.com/jane/my-pygubernator-plugin"
Issues   = "https://github.com/jane/my-pygubernator-plugin/issues"

[tool.setuptools.packages.find]
where = ["src"]

# --- Entry-point groups (declare only what you ship) ---------------

[project.entry-points."pygubernator.tools"]
my-utility-tools = "my_plugin.tools:register"

[project.entry-points."pygubernator.nodes"]
my-uppercase = "my_plugin.nodes:UppercaseNodeFactory"

[project.entry-points."pygubernator.sinks"]
notion = "my_plugin.sinks:FACTORY"

[project.entry-points."pygubernator.sources"]
stripe-charges = "my_plugin.sources:FACTORY"
```

### Pin pygubernator with care

Use a compatible-range constraint (`>=0.1,<1.0`) rather than an exact
pin. Operators install your plug-in into existing pygubernator
deployments — a tight pin makes upgrades painful and offers little
real safety. The four entry-point groups below are part of the
documented public API and follow SemVer.

---

## 3. The four entry-point groups

| Group                       | What the entry point resolves to                              | Discovered by                                                               |
|-----------------------------|---------------------------------------------------------------|-----------------------------------------------------------------------------|
| `pygubernator.tools`        | A callable `register(registry)` or a `@tool`-decorated module | `pygubernator.packaging.discover_tool_bundles(registry)`                    |
| `pygubernator.nodes`        | A `NodeFactory` **class** (instantiated at registration)      | `NodeTypeRegistry.discover_plugins(group="pygubernator.nodes")`             |
| `pygubernator.sinks`        | A `SinkFactory` instance, **or** a `register(registry)` hook  | `pygubernator.connectors.discover_sink_plugins()`                           |
| `pygubernator.sources`      | A `SourceFactory` instance, **or** a `register(registry)` hook | `pygubernator.connectors.discover_source_plugins()`                         |

Hosts (the API server, the worker, an embedded library consumer) are
expected to call the corresponding `discover_*` helper at startup. The
control plane API does this automatically.

---

## 4. Local development loop

1. **Install in editable mode** so changes to your plug-in are picked
   up immediately:

   ```bash
   pip install -e .[dev]
   pip install pygubernator[api,dev]   # if you also want to run the host
   ```

2. **Verify discovery** without spinning up the full server:

   ```python
   from pygubernator.connectors import (
       DEFAULT_SINK_REGISTRY,
       DEFAULT_SOURCE_REGISTRY,
       discover_sink_plugins,
       discover_source_plugins,
   )
   from pygubernator.workflow import NodeTypeRegistry

   discover_sink_plugins()
   discover_source_plugins()
   nodes = NodeTypeRegistry()
   nodes.discover_plugins(group="pygubernator.nodes")

   print("sinks:", DEFAULT_SINK_REGISTRY.list_types())
   print("sources:", DEFAULT_SOURCE_REGISTRY.list_types())
   print("nodes:", nodes.list_types())
   ```

3. **Run your tests** with the harnesses from
   `pygubernator.testing` — `FakeSink`, `FakeSource`, `ToolTestHarness`,
   `NodeTestHarness`. Every concept guide includes a worked example.

---

## 5. Connector Spec v1 (schema-first metadata)

`SinkFactory` and `SourceFactory` now accept an optional `spec=` field
with a versioned `ConnectorSpec` payload. This drives:

- registry-side validation,
- `/api/v1/workflows/node-types` connector field metadata, and
- metadata-driven editor forms without hard-coded connector logic.

```python
from pygubernator.connectors import SourceFactory
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    ConnectorFieldSpec,
    ConnectorSpec,
)

FACTORY = SourceFactory(
    type_name="acme",
    build=_build,
    validate=_validate,
    description="Reads records from ACME.",
    spec=ConnectorSpec(
        version=CONNECTOR_SPEC_V1,
        kind="source",
        type_name="acme",
        display_name="ACME",
        fields=(
            ConnectorFieldSpec(key="endpoint", required=True),
            ConnectorFieldSpec(key="api_key", secret=True),
        ),
    ),
)
```

### Backward compatibility

Legacy factories that omit `spec=` are still supported. pygubernator
auto-generates a minimal v1 spec from `type_name` and `description`, so
existing plug-ins continue to load.

---

## 6. Scaffolding paired connector packages

Use the connector scaffolder for a package that exports both a source
and sink entry point with Connector Spec v1 metadata:

```bash
pygubernator new connector shopify-connector
```

This generates:

- one installable package under `src/<module>/`,
- `source.py` and `sink.py` with `FACTORY` objects,
- dual entry points in `pyproject.toml` (`pygubernator.sources` and
  `pygubernator.sinks`), and
- starter tests that assert spec metadata registration.

---

## 7. Versioning and stability

- **`SinkFactory` / `SourceFactory`** — frozen dataclasses with
  defaulted fields. Adding a new field at the end is backward
  compatible; positional ordering of existing fields is part of the
  contract.
- **`Tool`, `Node`, `NodeFactory`, `Sink`, `Source` protocols** —
  runtime-checkable; we reserve the right to *add* methods in major
  versions only. Existing methods do not change shape within a major.
- **Entry-point group names** never change within a major version.
- **`@tool` decorator** is part of the public API and follows SemVer.

When pygubernator releases a major version, plug-ins should bump the
upper bound of their `pygubernator>=…,<…` constraint after testing
against the new major.

---

## 8. CI / publishing checklist

- [ ] `pyproject.toml` declares only the entry-point groups the
      package actually populates.
- [ ] All extensions have happy-path and error-path tests using the
      `pygubernator.testing` harnesses.
- [ ] `ruff check` + `ruff format` pass on the package and tests.
- [ ] Local discovery script (section 4) prints your extensions.
- [ ] README documents required environment variables, credentials,
      and any one-time setup.
- [ ] Build the wheel: `python -m build`.
- [ ] Smoke-install in a fresh venv: `pip install dist/*.whl
      pygubernator[api]` and confirm discovery still finds it.
- [ ] Publish: `twine upload dist/*`.

---

## 9. Submitting a plug-in to the community list

There is no central registry yet. We're tracking community plug-ins in
[GitHub Discussions](https://github.com/optophi/pygubernator/discussions);
open a thread with:

- the package name,
- a one-line description,
- a link to the repo,
- the extension types it ships (tool / node / sink / source).

If your plug-in is broadly useful and you want it considered for
inclusion in `pygubernator` core, open an issue tagged
`integration-proposal` first to discuss scope and maintenance.
