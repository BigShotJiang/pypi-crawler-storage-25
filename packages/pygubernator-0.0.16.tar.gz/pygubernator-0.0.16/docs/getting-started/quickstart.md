# Quick start

## Core library

Install the core package:

```bash
pip install pygubernator
```

Minimal usage patterns (see the package docstring and `examples/` in the repository):

```python
from pygubernator import Message, InMemoryTransport, run_stream
from pygubernator.agents import PipelineAgent

# Define agents, wire a transport, then run_stream / run_batch as needed.
```

## Control plane (optional)

For the HTTP API and UI:

```bash
pip install "pygubernator[api,ui]"
pygubernator db upgrade    # when using a database-backed control plane
pygubernator api           # default http://127.0.0.1:8010
```

In another terminal (UI development):

```bash
cd src/pygubernator/ui && npm install && cd ../../..
pygubernator ui dev --api-url http://127.0.0.1:8010
```

## Registry-driven runs

To create agents and runs through the API and execute them from Python with database-backed observability, see the [integration guide](../guides/integration.md) and [run lifecycle](../guides/run-lifecycle.md).

## Canonical workflows

For the three primary product workflows, start with the repository examples and
the guide in [Canonical Use Cases](../guides/canonical-use-cases.md):

- `examples/canonical_agent_with_tools.yaml`
- `examples/canonical_scheduled_pipeline.yaml`
- `examples/canonical_approval_flow.yaml`

## Rename note

This distribution was previously **pykairos**. Use **`import pygubernator`**, **`pip install pygubernator`**, and environment variables prefixed with **`PYGUBERNATOR_`**. The base exception is **`GubernatorError`**.
