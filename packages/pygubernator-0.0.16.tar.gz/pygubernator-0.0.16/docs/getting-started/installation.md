# Installation

## Requirements

- **Python 3.11+**

## Core

```bash
pip install pygubernator
```

Core depends on **PyYAML** and **pystator**.

## Optional extras

```bash
pip install pygubernator[api]        # FastAPI control plane, DB, Kafka, tracing, …
pip install pygubernator[ui]         # Serve embedded UI (static + proxy)
pip install pygubernator[workflow]   # DAG engine, LiteLLM, Google/Slack/Obsidian, pycharter/pycatalyst
pip install pygubernator[collab]     # Socket.IO relay for real-time collaboration (optional)
pip install pygubernator[docs]       # MkDocs + Material + mkdocstrings (this site)
pip install pygubernator[dev]        # api + ui + workflow + collab + tests, Ruff, mypy, pre-commit, Marimo, **docs**
pip install pygubernator[all]        # api + ui + workflow + collab (same as `[all]` in `pyproject.toml`)
```

Local **llama.cpp** models: `pip install llama-cpp-python` (not bundled in an extra).

## Documentation CLI

With `[docs]` or `[dev]`:

```bash
pygubernator docs serve   # http://127.0.0.1:5010 by default
pygubernator docs build   # writes site/
```

## Configuration

Control-plane and agent settings support the **`PYGUBERNATOR_`** environment prefix and an optional **`pygubernator.cfg`** file (see the repository **`pygubernator.cfg.example`**).

## Next

[Quick start](quickstart.md) · [Integration guide](../guides/integration.md)
