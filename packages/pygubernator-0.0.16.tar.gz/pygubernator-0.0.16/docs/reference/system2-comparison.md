# System 2 comparison

This is institutional memory for **why** Phase 6 looks the way it
does. It captures which patterns from System 2's analyst workbench we
adopted, which we explicitly didn't, and how each adopted pattern was
translated into a DAG-native equivalent that fits PyGubernator's
existing replay / audit contracts.

It is a *reference* document — read it when you're trying to
understand a Phase 6 design decision after the fact, or when proposing
a new feature you think should also come from System 2.

## Source comparison

System 2 ships an "analyst workbench" UI on top of an LLM-driven
research agent. The features that influenced Phase 6:

| System 2 feature                               | Adopted? | DAG-native translation                                                                                                                             |
|------------------------------------------------|----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Typed artifact panel (markdown / table / image / html / json) | **Yes** (§6.1) | New `WorkflowArtifact` model + typed renderers. Sandboxed iframe for HTML, RFC-4180 CSV parser, sandboxed read-only SQLite for ad-hoc CSV queries. |
| Markdown notebook the agent reads & writes      | **Yes** (§6.9) | `ContextSurface` (already in core) gets an editor at `/knowledge/notebooks`. The editor edits **the same store** an agent reads, no shadow notebook. |
| Live thinking-block streaming                   | **Yes** (§6.4) | New `LLM_THINKING_DELTA` event type + UI rendering with 💭 marker. OpenAI `reasoning_content` and Anthropic `reasoning` / `thinking` both supported. |
| Step trace with expandable detail               | **Yes** (§6.3) | `AgentTraceRow` disclosure rows with chevrons, pretty-printed JSON, "Copy as JSON". Backed by the existing `workflow_step_events` table (no new model). |
| Resizable split-pane workbench layout           | **Yes** (§6.5) | New `<ResizableSplitPane>` component with localStorage persistence + responsive stacking on narrow viewports.                                       |
| Conversational orchestrator that picks workflows | **Yes** (§6.7) | New `llm_planner` node type + Guide page with manual / auto routing. Server-side planner route reuses the node's parser so DAG and HTTP plans agree. |
| Live DAG with branch highlighting               | **Yes** (§6.6) | Real layered graph (longest-path-from-source) with edge classification by source step's `output_handle`. Pulse animation on in-flight nodes.       |
| Active-agent fleet view (who's doing what)      | **Yes** (§6.2) | `<ActiveAgentsPanel>` polls `/api/v1/agents/heartbeats`. Workflow-spawned agents populate `current_run_id` / `current_node_id` via the existing `HeartbeatEmitter.status_provider` hook. |
| Session rename + breadcrumb                     | **Yes** (§6.8) | New `workflow_sessions` table for user-supplied display names; inline rename UX in the sessions sidebar; `<RunBreadcrumb>` linking back from a run. |
| Narrator-pattern scheduled summarizer           | **Yes** (§6.10, partial) | New `workflow_session_summaries` table + manual-entry UI. Scheduled LLM-narrator that auto-summarises is a v1.1 follow-up.                          |
| Git-backed notebook (sync across operators)     | **No (v1.1)** | The in-DB editor is the v1 default; a `FileContextStore`-backed git mode is queued for v1.1 because it needs its own sync/conflict UX.              |
| Single global agent persona                     | **No**   | PyGubernator already has multi-agent + workflow scoping. Adopting a global persona would have collapsed `MemoryScope` and we explicitly don't want that. |
| Hidden-from-user "thinking budget"              | **No**   | `emit_thinking` is opt-in per agent config. We surface what the LLM thinks, not what it considered budget-eligible.                                |
| Tool-use as a notebook side-channel             | **No**   | Tool calls are first-class `AgentEventType.TOOL_*` events on the trace + their own audit tables. They never bypass the DAG.                         |
| Auto-replan on every chat message               | **No**   | The planner runs *only* when the user sends a message in **Auto** mode. Manual mode never invokes the LLM. Cost is opt-in.                          |

## Translation principles

Three rules guided which adaptations made sense:

### 1. Don't break replay

Every Phase 6 feature has to work with the existing replay contract:
**every effect (LLM call, tool call, artifact emit) is an event on a
durable channel; replay re-derives state from those events**.

This is why `WorkflowArtifact` is its own table (replayable separately
from the run output), why `LLM_THINKING_DELTA` is a *new* event type
on the existing channel (not a side-channel), and why the planner
route is **stateless** — it never writes the decision back, so
running it twice on the same message is free.

### 2. Edit what the agent reads, not a shadow copy

System 2's notebook lives next to the agent's prompt; an operator
edit is what the agent sees on its next run. That principle drives
§6.9 (`/knowledge/notebooks`): the UI is editing the same
`RecordStoreContextStore` an agent uses, under the conventional
`"context_surface"` key. There is no separate "operator notebook"
that the agent has to merge with its real state.

The same principle blocked Git-backed mode from v1: a Git checkout +
DB store + agent-runtime triple needs explicit conflict resolution
UX, which is more design work than the in-DB editor warranted to
unlock the System-2 use case.

### 3. Surface the DAG, don't hide it

System 2 hides its agent's plan inside the chat; we show it.
The Guide page in **Auto** mode tells the user which workflow the
planner picked (`Started ${name}`), and the planner's `decision`
return shape is part of the public response so a UI can show "the
planner chose this because *X*" without re-parsing the LLM's reply.

This is also why §6.6c invested in a real graph layout instead of a
flat timeline. The DAG is the user's mental model of what the agent
is doing; making it harder to read makes the system harder to trust.

## What we explicitly didn't adopt

A short list of things System 2 ships that we decided not to:

- **Single-agent persona.** PyGubernator's multi-agent scoping
  (`MemoryScope`) is more flexible; collapsing to one global persona
  would have meant rewriting the memory backend.
- **Hidden thinking budget.** We expose `emit_thinking` per-agent so
  operators choose, not the LLM provider.
- **Tool-use side-channel.** Every tool call is a first-class event;
  there is no shortcut path that bypasses the DAG.
- **Auto-replan-on-every-message.** Auto mode is opt-in; the planner
  only runs when the user explicitly chooses it.
- **Free-tier-by-default planner.** When no planner model is
  configured the route returns 503. The operator chooses the model;
  we never silently call a cloud provider.

## Changing this document

This is a reference, not a roadmap. When a new Phase 6 feature ships:

1. Add a row to the table above with the System 2 mapping (or "no
   System 2 source").
2. If the feature pushed back on a System 2 pattern, add a bullet to
   "What we explicitly didn't adopt".

When proposing a new feature:

1. Find the closest System 2 row in the table.
2. State whether you'd want to adopt or push back.
3. State which translation principle covers your design (or propose
   a new one).

That ordering — *map first, then design* — is what kept Phase 6
coherent across nine sub-PRs.
