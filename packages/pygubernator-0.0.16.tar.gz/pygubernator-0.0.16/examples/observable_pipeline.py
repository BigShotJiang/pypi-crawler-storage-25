"""Example: Pipeline agent with OpenTelemetry tracing.

Demonstrates:
- PipelineAgent with three steps
- EventBus with OTelEventHandler for distributed tracing
- MetricsEventHandler for operational metrics

Usage:
    python examples/observable_pipeline.py
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pygubernator._events import EventBus
from pygubernator._handlers import LoggingEventHandler, MetricsEventHandler
from pygubernator._types import Message, StepResult
from pygubernator.agents._pipeline import PipelineAgent, PipelineStep

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger(__name__)


# -- Pipeline steps --


class FetchStep(PipelineStep):
    """Fetches data from a source."""

    async def execute(self, data: Any) -> StepResult:
        records = [{"id": i, "value": i * 10} for i in range(5)]
        return StepResult(
            step_name=self.name,
            success=True,
            data=records,
            duration_ms=10.0,
        )


class EnrichStep(PipelineStep):
    """Enriches records with computed fields."""

    async def execute(self, data: Any) -> StepResult:
        enriched = [{**r, "enriched": True} for r in data]
        return StepResult(
            step_name=self.name,
            success=True,
            data=enriched,
            duration_ms=5.0,
        )


class SinkStep(PipelineStep):
    """Writes records to a sink."""

    async def execute(self, data: Any) -> StepResult:
        return StepResult(
            step_name=self.name,
            success=True,
            data={"written": len(data)},
            duration_ms=15.0,
        )


async def main() -> None:
    """Run the observable pipeline example."""
    # Set up event bus
    bus = EventBus()
    bus.add_handler(LoggingEventHandler())
    metrics_handler = MetricsEventHandler()
    bus.add_handler(metrics_handler)

    # Optionally add OTel tracing (requires opentelemetry-sdk)
    try:
        from pygubernator.observability._tracing import (
            OTelEventHandler,
            configure_tracing,
        )

        configure_tracing(service_name="pipeline-example")
        bus.add_handler(OTelEventHandler())
        logger.info("OpenTelemetry tracing enabled")
    except ImportError:
        logger.info("OpenTelemetry not available, skipping tracing")

    # Create pipeline agent
    agent = PipelineAgent(
        agent_id="observable-pipeline",
        steps=[
            FetchStep("fetch"),
            EnrichStep("enrich"),
            SinkStep("sink"),
        ],
        event_bus=bus,
    )

    # Process messages
    for i in range(3):
        msg = Message(topic="jobs", payload={"job_id": i})
        result = await agent.process(msg)
        logger.info("Job %d: success=%s", i, result.success)

    # Print metrics summary
    m = metrics_handler.get_metrics()
    logger.info("Metrics counters: %s", m["counters"])
    logger.info(
        "Metrics durations: %s",
        {k: f"{len(v)} samples" for k, v in m["durations"].items()},
    )


if __name__ == "__main__":
    asyncio.run(main())
