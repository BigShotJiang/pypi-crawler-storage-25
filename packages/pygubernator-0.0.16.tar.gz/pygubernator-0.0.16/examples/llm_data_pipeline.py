"""Example: LLM agent using catalyst/charter/stator tools.

Demonstrates an LLM agent that can:
- Generate mock data via pycatalyst tools
- Validate data via pycharter tools
- Manage state machines via pystator tools

Usage:
    python examples/llm_data_pipeline.py

Note: Requires pycatalyst, pycharter to be installed for real
tool execution. This example uses mock tools for demonstration.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pygubernator._events import EventBus
from pygubernator._handlers import LoggingEventHandler, MetricsEventHandler
from pygubernator._types import Message
from pygubernator.agents._llm import LLMAgent
from pygubernator.llm._messages import LLMResponse, ToolCall
from pygubernator.tools._decorator import tool
from pygubernator.tools._registry import ToolRegistry

logging.basicConfig(level=logging.INFO, format="%(name)s | %(message)s")
logger = logging.getLogger(__name__)


# -- Mock LLM provider for demonstration --


class MockLLMProvider:
    """Simulates an LLM that calls tools."""

    def __init__(self) -> None:
        self._step = 0

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        self._step += 1

        if self._step == 1:
            return LLMResponse(
                content="Generating data...",
                tool_calls=(
                    ToolCall(
                        id="tc1",
                        name="mock_generate",
                        arguments={"count": 3},
                    ),
                ),
                finish_reason="tool_calls",
            )
        if self._step == 2:
            return LLMResponse(
                content="Validating records...",
                tool_calls=(
                    ToolCall(
                        id="tc2",
                        name="mock_validate",
                        arguments={"data": "generated"},
                    ),
                ),
                finish_reason="tool_calls",
            )
        return LLMResponse(
            content="Pipeline complete! Generated 3 records, all valid.",
            finish_reason="stop",
        )


# -- Mock tools --


@tool(description="Generate mock data records")
async def mock_generate(count: int = 5) -> list[dict[str, Any]]:
    """Generate count mock records.

    Args:
        count: Number of records.
    """
    return [{"id": i, "name": f"item-{i}"} for i in range(count)]


@tool(description="Validate data records")
async def mock_validate(data: str = "") -> dict[str, Any]:
    """Validate records.

    Args:
        data: Data reference.
    """
    return {"valid": True, "errors": []}


async def main() -> None:
    """Run the LLM data pipeline example."""
    # Set up event bus with handlers
    bus = EventBus()
    bus.add_handler(LoggingEventHandler())
    metrics = MetricsEventHandler()
    bus.add_handler(metrics)

    # Register tools
    registry = ToolRegistry()
    registry.register(mock_generate)
    registry.register(mock_validate)

    # Create agent
    agent = LLMAgent(
        agent_id="data-pipeline-llm",
        llm_provider=MockLLMProvider(),
        tool_registry=registry,
        system_prompt=(
            "You are a data pipeline agent. Generate mock data, "
            "validate it, and report the results."
        ),
        event_bus=bus,
    )

    # Process a message
    msg = Message(
        topic="commands",
        payload={"content": "Generate and validate 3 data records"},
    )

    logger.info("Starting LLM data pipeline...")
    result = await agent.process(msg)

    logger.info(
        "Result: success=%s, iterations=%d",
        result.success,
        result.metadata["iterations"],
    )
    logger.info("Tool calls: %d", len(result.metadata["tool_results"]))
    logger.info("Metrics: %s", metrics.get_metrics()["counters"])


if __name__ == "__main__":
    asyncio.run(main())
