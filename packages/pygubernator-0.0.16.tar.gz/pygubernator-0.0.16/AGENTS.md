# AGENTS.md

Entry point for AI coding assistants (Claude Code, Cursor, Codex, and
similar) contributing to this package.

Human contributors: read `CONTRIBUTING.md` instead. Both documents point
at the same architecture and workflow; the content is the same, the
framing differs.

---

## Read these first

1. **`ARCHITECTURE.md`** — the philosophy and the layer map. This is the
   most important document in the repository. Every rule below flows from
   it. Read it in full before proposing any code change.
2. **`CONTRIBUTING.md`** — setup, commit conventions, branching workflow.
3. **`CODE_OF_CONDUCT.md`** and **`SECURITY.md`** — non-optional.
4. **`README.md`** — purpose and audience.

---

## The two laws

Every package in this family obeys:

1. **The core is stateless.** No hidden state, no I/O, no persistence, no
   network. Pure tool API.
2. **Domain artifacts are configuration.** New domain concepts go in
   YAML/JSON under `data/seed/`, validated by Pydantic. Not new Python
   classes.

Violating either law is a rejected change. See `ARCHITECTURE.md` for why.

---

## The layer map

```
            ┌───────────────┐  ┌───────────────┐
            │  HTTP wrapper │  │   UI wrapper  │
            │   (FastAPI)   │  │   (Next.js)   │
            └───────┬───────┘  └───────┬───────┘
                    │                  │
                    ▼                  ▼
          ┌──────────────────────────────────┐
          │         STATELESS CORE           │
          │   (signature tool API, pure)     │
          │   domain artifacts = YAML/JSON   │
          └─────────────┬────────────────────┘
                        │
                        ▼
                ┌──────────────┐             ┌───────────────┐
                │    STORE     │ ◄──────────►│    WORKER     │
                │   (client)   │             │ (async svc)   │
                └──────┬───────┘             └───────────────┘
                       │
          ┌────────────┼────────────┐
          ▼            ▼            ▼
       SQLite      Postgres      MongoDB
      (testing)     (SQL)       (NoSQL)
```

- **Core** has no I/O, no persistence, no network. Pure functions.
- **Store** is a translation layer; every method supports SQLite,
  Postgres, and MongoDB.
- **HTTP / UI wrappers** are thin. No business logic in routes or
  components.
- **Worker** is async, long-running, uses only public core + store API.
- Inner layers never import from outer layers.

The per-package layer map lives in `ARCHITECTURE.md`.

---

## The skills

This repository ships five skills under `.claude/skills/`. Each is a
`SKILL.md` with a specific trigger and checklist. Invoke the one whose
trigger matches the task.

| Skill | Trigger |
|---|---|
| **`/plan`** | Before any non-trivial change. Forces layer, statelessness, and config-driven decisions. |
| **`/verify`** | Before committing. Runs layer-boundary gates plus standard hygiene. |
| **`/config-change`** | When touching YAML/JSON seed data, schema validators, or domain artifact definitions. |
| **`/ship`** | At commit and PR time. Produces Conventional Commits and a complete PR description. |
| **`/onboard`** | First contribution, or first time in an unfamiliar area of the package. |
| **`/refactor`** | Only when the user explicitly asks to refactor, simplify, or optimize. Never fires proactively. |

Read each `SKILL.md` once on onboarding, then re-read the one whose
trigger matches each task.

Skills are portable: the same workflows apply in Cursor
(`.cursor/rules/`) and Codex (`AGENTS.md` sections). If you work in
those tools, mirror the skill steps rather than inventing parallel
workflows.

---

## Hard rules

These are the shortest summary of what the skills enforce. If any change
violates one of these, stop and re-plan:

- Do not import from `api/`, `ui/`, or worker modules inside the core.
- Do not add persistence, network, or filesystem writes inside the core.
- Do not hardcode a domain artifact as a Python class; use configuration.
- Do not add a store method without implementations for SQLite, Postgres,
  and MongoDB.
- Do not put business logic in HTTP routes or UI components.
- Do not introduce cross-package coupling outside the sanctioned bridge
  points (see `ARCHITECTURE.md`).
- Do not silently change public API, function signatures, default values,
  or environment variable names. These are contract breaks.
- Do not commit secrets, real PII, production URLs, or generated files.
- Do not force-push shared branches or skip pre-commit hooks.

---

## Standard Python hygiene (enforced by `/verify`)

- `from __future__ import annotations` on every touched `.py` file.
- Modern typing: `dict[str, Any]`, `str | None`, `A | B`. No `Dict` /
  `List` / `Optional` / `Union` from `typing`.
- Google-style docstrings on public API; member of `__all__`.
- `typing.Protocol` with `@runtime_checkable` for pluggable interfaces,
  factory functions for implementations. No ABCs.
- `@dataclass(frozen=True, slots=True)` for immutable value objects.
  Pydantic v2 for validated external input.
- Package-base exception + `ErrorCode` for new failure modes.
- Lazy `%s` logging; no f-strings in log calls.
- Module < 400 lines, function < 50 lines.
- Ruff (line-length per repo's `pyproject.toml`) and pre-commit pass.

---

## When requirements are unclear

Ask. Do not guess. The skills are designed so that a short `/plan` doc
surfaces unknowns before they reach code. If you are blocked on a product
decision — a new telemetry signal, a breaking API, a new dependency —
summarise the options and stop at the boundary.

---

## Disclosure

Follow the project's policy on AI-assisted contribution disclosure, if
any. Regardless of policy, write commits and PR descriptions that stand
on their own without the chat history.
