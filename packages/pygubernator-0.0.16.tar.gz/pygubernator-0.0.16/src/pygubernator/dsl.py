"""Declarative Python DSL for defining workflows.

Express workflows using the ``@workflow`` decorator and ``>>`` operator
instead of YAML or manual spec construction.

Example::

    from pygubernator.dsl import workflow, node

    @workflow("greet")
    def greet_pipeline():
        data = node("input")
        greeting = data >> node("template", config={"template": "Hi {{ name }}"})
        greeting >> node("output")

    result = greet_pipeline.run({"name": "Alice"})
    print(result.output)
"""

from __future__ import annotations

import threading
from typing import Any

from pygubernator.testing import WorkflowSpecBuilder
from pygubernator.workflow._facade import Workflow

# ---------------------------------------------------------------------------
# Thread-local context for tracking the workflow being defined
# ---------------------------------------------------------------------------

_context_var: threading.local = threading.local()


def _current_context() -> _WorkflowContext:
    """Return the active workflow context.

    Raises:
        RuntimeError: If called outside a ``@workflow`` decorated function.
    """
    ctx = getattr(_context_var, "current", None)
    if ctx is None:
        raise RuntimeError(
            "node() must be called inside a @workflow decorated function"
        )
    return ctx


class _WorkflowContext:
    """Tracks nodes and edges during DSL workflow definition."""

    def __init__(self, name: str, version: str) -> None:
        self._builder = WorkflowSpecBuilder(name, version)
        self._node_counter = 0

    def add_node(
        self,
        node_type: str,
        node_id: str | None,
        config: dict[str, Any] | None,
    ) -> str:
        """Register a node and return its ID."""
        if node_id is None:
            self._node_counter += 1
            node_id = f"{node_type}_{self._node_counter}"
        self._builder.add_node(node_id, node_type, config=config)
        return node_id

    def connect(
        self,
        source_id: str,
        target_id: str,
        *,
        condition: str | None = None,
        source_handle: str | None = None,
    ) -> None:
        """Register an edge between two nodes."""
        self._builder.connect(
            source_id,
            target_id,
            condition=condition,
            source_handle=source_handle,
        )

    def build(self) -> Workflow:
        """Build and return a Workflow from the collected nodes and edges."""
        spec = self._builder.build()
        return Workflow(spec)


# ---------------------------------------------------------------------------
# NodeProxy — the >> operator target
# ---------------------------------------------------------------------------


class NodeProxy:
    """Proxy object returned by :func:`node`.

    Supports the ``>>`` operator to chain nodes into a pipeline::

        data = node("input")
        processed = data >> node("template", config={...})
        processed >> node("output")

    Attributes:
        node_id: The unique identifier of the underlying node.
        node_type: The type of the underlying node.
    """

    def __init__(self, node_id: str, node_type: str) -> None:
        self.node_id = node_id
        self.node_type = node_type

    def __rshift__(self, other: NodeProxy) -> NodeProxy:
        """Connect this node to *other* and return *other* for chaining.

        Args:
            other: The downstream node proxy.

        Returns:
            The *other* proxy (enables ``a >> b >> c``).
        """
        _current_context().connect(self.node_id, other.node_id)
        return other

    def __repr__(self) -> str:
        return f"NodeProxy({self.node_id!r}, {self.node_type!r})"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def node(
    node_type: str,
    *,
    node_id: str | None = None,
    config: dict[str, Any] | None = None,
) -> NodeProxy:
    """Declare a node in the current workflow context.

    Must be called inside a ``@workflow`` decorated function.

    Args:
        node_type: Node type identifier (e.g. ``"input"``, ``"template"``).
        node_id: Optional explicit node ID (auto-generated if omitted).
        config: Node-specific configuration dict.

    Returns:
        A :class:`NodeProxy` that can be chained with ``>>``.

    Example::

        data = node("input")
        result = data >> node("template", config={"template": "{{ x }}"})
    """
    ctx = _current_context()
    actual_id = ctx.add_node(node_type, node_id, config)
    return NodeProxy(actual_id, node_type)


def workflow(
    name: str,
    *,
    version: str = "1.0.0",
) -> Any:
    """Decorator that converts a function into a :class:`Workflow`.

    The decorated function's body uses :func:`node` and ``>>``
    to declare the workflow graph.  The decorator executes the
    function once at import time to capture the graph, then
    replaces it with a ready-to-run :class:`Workflow` object.

    Args:
        name: Workflow name.
        version: Workflow version string.

    Returns:
        A decorator that returns a :class:`Workflow`.

    Example::

        @workflow("etl")
        def my_pipeline():
            node("input") >> node("template", config={...}) >> node("output")

        result = my_pipeline.run({"key": "val"})
    """

    def decorator(fn: Any) -> Workflow:
        ctx = _WorkflowContext(name, version)
        token = getattr(_context_var, "current", None)
        _context_var.current = ctx
        try:
            fn()
        finally:
            _context_var.current = token
        return ctx.build()

    return decorator
