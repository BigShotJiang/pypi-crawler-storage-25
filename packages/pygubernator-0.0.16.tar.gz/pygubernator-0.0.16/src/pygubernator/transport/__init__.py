"""Message transport layer for pygubernator agents."""

from __future__ import annotations

from pygubernator.transport._memory import InMemoryTransport

__all__ = ["InMemoryTransport"]

# KafkaTransport is optional (requires confluent-kafka)
try:
    from pygubernator.transport._kafka import KafkaTransport

    __all__.append("KafkaTransport")
except ImportError:
    KafkaTransport = None  # type: ignore[assignment,misc]
