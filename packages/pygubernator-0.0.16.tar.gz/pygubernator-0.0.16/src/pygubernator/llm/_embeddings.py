"""Embedding provider abstraction for vector search and RAG.

Provides a protocol-based embedding interface with implementations
for OpenAI-compatible APIs and local sentence-transformers models.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@runtime_checkable
class EmbeddingProvider(Protocol):
    """Generates vector embeddings from text.

    Implementations wrap specific embedding APIs (OpenAI, Hugging Face,
    local sentence-transformers, etc.).
    """

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for a batch of texts.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors (one per input text).
        """
        ...

    @property
    def dimension(self) -> int:
        """Dimensionality of the embedding vectors."""
        ...


class OpenAIEmbeddingProvider:
    """Embeddings via an OpenAI-compatible API.

    Supports OpenAI, Azure OpenAI, and any provider that implements
    the ``/v1/embeddings`` endpoint.

    Args:
        model: Embedding model name (e.g. ``"text-embedding-3-small"``).
        api_key: API key.  Defaults to ``OPENAI_API_KEY`` env var.
        api_base: Base URL.  Defaults to ``https://api.openai.com/v1``.
        dimension: Embedding vector size (model-dependent).
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        dimension: int = 1536,
    ) -> None:
        try:
            import httpx  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "httpx is required for OpenAIEmbeddingProvider: "
                "pip install pygubernator[integrations]"
            ) from exc
        self._model = model
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self._api_base = (api_base or "https://api.openai.com/v1").rstrip("/")
        self._dimension = dimension

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Call the embeddings API.

        Args:
            texts: Texts to embed.

        Returns:
            Embedding vectors.

        Raises:
            RuntimeError: If the API call fails.
        """
        import httpx

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self._api_base}/embeddings",
                json={"input": texts, "model": self._model},
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                timeout=60.0,
            )
            resp.raise_for_status()
            data = resp.json()

        embeddings = [item["embedding"] for item in data["data"]]
        logger.debug(
            "Generated %d embeddings (model=%s, dim=%d)",
            len(embeddings),
            self._model,
            self._dimension,
        )
        return embeddings

    @property
    def dimension(self) -> int:
        """Embedding vector dimensionality."""
        return self._dimension


class LocalEmbeddingProvider:
    """Embeddings via sentence-transformers (runs locally, no API).

    Args:
        model_name: Hugging Face model identifier.
        dimension: Override for embedding dimension (auto-detected if None).

    Requires the ``sentence-transformers`` package::

        pip install sentence-transformers
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        *,
        dimension: int | None = None,
    ) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise ImportError(
                "sentence-transformers is required for LocalEmbeddingProvider: "
                "pip install sentence-transformers"
            ) from exc
        self._model = SentenceTransformer(model_name)
        self._dimension = (
            dimension or self._model.get_sentence_embedding_dimension() or 384
        )

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings locally.

        Args:
            texts: Texts to embed.

        Returns:
            Embedding vectors as lists of floats.
        """
        import asyncio

        loop = asyncio.get_running_loop()
        vectors = await loop.run_in_executor(
            None, lambda: self._model.encode(texts).tolist()
        )
        logger.debug(
            "Generated %d local embeddings (dim=%d)",
            len(vectors),
            self._dimension,
        )
        return vectors

    @property
    def dimension(self) -> int:
        """Embedding vector dimensionality."""
        return self._dimension


def create_embedding_provider(
    model: str,
    **kwargs: Any,
) -> EmbeddingProvider:
    """Create an embedding provider from a model name.

    Auto-detects the provider type:
    - Names starting with ``"local/"`` use :class:`LocalEmbeddingProvider`
    - All others use :class:`OpenAIEmbeddingProvider`

    Args:
        model: Model identifier (e.g. ``"text-embedding-3-small"``,
            ``"local/all-MiniLM-L6-v2"``).
        **kwargs: Passed to the provider constructor.

    Returns:
        Configured embedding provider.
    """
    if model.startswith("local/"):
        local_model = model.removeprefix("local/")
        return LocalEmbeddingProvider(local_model, **kwargs)
    return OpenAIEmbeddingProvider(model, **kwargs)
