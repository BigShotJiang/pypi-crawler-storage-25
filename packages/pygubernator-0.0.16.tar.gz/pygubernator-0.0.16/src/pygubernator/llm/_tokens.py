"""Token counting utilities for context budget management."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    import tiktoken

    _HAS_TIKTOKEN = True
except ImportError:
    _HAS_TIKTOKEN = False

_FALLBACK_CHARS_PER_TOKEN = 4


def count_tokens(text: str, model: str = "") -> int:
    """Estimate the number of tokens in a text string.

    Uses tiktoken for accurate counts when available and the model
    is recognized. Falls back to a character-based estimator.

    Args:
        text: The text to count tokens for.
        model: Optional model name for tiktoken encoding lookup.

    Returns:
        Estimated token count.
    """
    if _HAS_TIKTOKEN and model:
        try:
            enc = tiktoken.encoding_for_model(model)
            return len(enc.encode(text))
        except (KeyError, Exception):
            logger.debug(
                "tiktoken encoding lookup failed for model %s, "
                "falling back to char-based estimate",
                model,
            )
    # Fallback: ~4 chars per token on average
    return max(1, len(text) // _FALLBACK_CHARS_PER_TOKEN)


def count_messages_tokens(
    messages: list[dict[str, Any]],
    model: str = "",
) -> int:
    """Count total tokens across a list of messages.

    Accounts for role and content of each message, plus per-message
    overhead (~4 tokens per message for formatting).

    Args:
        messages: List of message dicts with role and content.
        model: Optional model name for tiktoken.

    Returns:
        Estimated total token count.
    """
    total = 0
    for msg in messages:
        role = str(msg.get("role", ""))
        content = str(msg.get("content", ""))
        total += count_tokens(role + content, model) + 4
    return total
