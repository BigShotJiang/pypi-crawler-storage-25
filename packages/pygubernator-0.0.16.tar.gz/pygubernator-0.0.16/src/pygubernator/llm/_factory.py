"""Factory functions for creating LLM providers with auto-detection."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.llm._config import (
    KNOWN_PROVIDERS,
    ProviderConfig,
    ProviderType,
)

logger = logging.getLogger(__name__)


def _normalize_openai_compat_base(api_base: str) -> str:
    """Ensure Ollama OpenAI endpoints use .../v1 (not bare :11434 root)."""
    b = api_base.strip().rstrip("/")
    if "/v1" in b:
        return b
    # Bare Ollama listen address without /v1 → chat completions 404 or wrong path
    if ":11434" in b and b.startswith(("http://", "https://")):
        return f"{b}/v1"
    return b


def create_provider(
    model: str,
    *,
    api_base: str | None = None,
    api_key: str | None = None,
    max_tokens: int = 4096,
    temperature: float = 0.0,
    **kwargs: Any,
) -> Any:
    """Create the appropriate LLM provider from a model string.

    Auto-detects the provider backend from the model identifier:

    - Ends with ``.gguf`` → ``LocalLLMProvider``
    - Starts with ``ollama/`` → ``OpenAICompatibleProvider`` with
      Ollama defaults
    - Starts with ``deepseek-`` → ``OpenAICompatibleProvider`` with
      Deepseek defaults
    - Starts with ``glm-`` → ``OpenAICompatibleProvider`` with
      GLM defaults
    - ``api_base`` is provided → ``OpenAICompatibleProvider``
    - Otherwise → ``LiteLLMProvider`` (cloud fallback)

    Args:
        model: Model identifier or file path.
        api_base: Server URL (triggers OpenAICompatibleProvider).
        api_key: API key for authentication.
        max_tokens: Maximum response tokens.
        temperature: Sampling temperature.
        **kwargs: Additional provider-specific parameters.

    Returns:
        Configured LLMProvider instance.

    Examples:
        >>> provider = create_provider("./models/llama3.gguf")
        >>> provider = create_provider("ollama/llama3.1")
        >>> provider = create_provider("deepseek-chat", api_key="sk-...")
        >>> provider = create_provider("gpt-4o")
    """
    if model.endswith(".gguf"):
        return _create_local(model, max_tokens, temperature, **kwargs)

    if model.startswith("ollama/"):
        model_name = model[len("ollama/") :]
        preset = KNOWN_PROVIDERS["ollama"]
        base = api_base or preset.default_api_base or ""
        base = _normalize_openai_compat_base(base)
        return _create_openai_compat(
            base, model_name, api_key, max_tokens, temperature, **kwargs
        )

    if model.startswith("deepseek-"):
        preset = KNOWN_PROVIDERS["deepseek"]
        base = api_base or preset.default_api_base or ""
        return _create_openai_compat(
            base, model, api_key, max_tokens, temperature, **kwargs
        )

    if model.startswith("glm-"):
        preset = KNOWN_PROVIDERS["glm"]
        base = api_base or preset.default_api_base or ""
        return _create_openai_compat(
            base, model, api_key, max_tokens, temperature, **kwargs
        )

    if api_base:
        return _create_openai_compat(
            _normalize_openai_compat_base(api_base),
            model,
            api_key,
            max_tokens,
            temperature,
            **kwargs,
        )

    return _create_litellm(model, api_key, api_base, max_tokens, temperature)


def create_provider_from_config(config: ProviderConfig) -> Any:
    """Create an LLM provider from a typed ProviderConfig.

    Args:
        config: Structured provider configuration.

    Returns:
        Configured LLMProvider instance.
    """
    if config.provider_type == ProviderType.LOCAL:
        path = config.model_path or config.model
        return _create_local(
            path,
            config.max_tokens,
            config.temperature,
            n_ctx=config.n_ctx,
            n_gpu_layers=config.n_gpu_layers,
            top_p=config.top_p,
            top_k=config.top_k,
        )

    if config.provider_type == ProviderType.OPENAI_COMPATIBLE:
        base = _normalize_openai_compat_base(config.api_base or "")
        return _create_openai_compat(
            base,
            config.model,
            config.api_key,
            config.max_tokens,
            config.temperature,
            top_p=config.top_p,
            timeout=config.request_timeout,
        )

    return _create_litellm(
        config.model,
        config.api_key,
        config.api_base,
        config.max_tokens,
        config.temperature,
    )


def _create_openai_compat(
    api_base: str,
    model: str,
    api_key: str | None,
    max_tokens: int,
    temperature: float,
    **kwargs: Any,
) -> Any:
    """Create an OpenAICompatibleProvider."""
    from pygubernator.llm._openai_compat import OpenAICompatibleProvider

    timeout_kw = kwargs.get("timeout")
    if timeout_kw is None:
        timeout_kw = kwargs.get("request_timeout")

    return OpenAICompatibleProvider(
        api_base=api_base,
        model=model,
        api_key=api_key,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=kwargs.get("top_p"),
        timeout=timeout_kw,
    )


def _create_local(
    model_path: str,
    max_tokens: int,
    temperature: float,
    **kwargs: Any,
) -> Any:
    """Create a LocalLLMProvider."""
    from pygubernator.llm._local import LocalLLMProvider

    return LocalLLMProvider(
        model_path=model_path,
        max_tokens=max_tokens,
        temperature=temperature,
        n_ctx=kwargs.get("n_ctx", 4096),
        n_gpu_layers=kwargs.get("n_gpu_layers", -1),
        top_p=kwargs.get("top_p"),
        top_k=kwargs.get("top_k"),
    )


def _create_litellm(
    model: str,
    api_key: str | None,
    api_base: str | None,
    max_tokens: int,
    temperature: float,
) -> Any:
    """Create a LiteLLMProvider."""
    from pygubernator.llm._provider import LiteLLMProvider

    return LiteLLMProvider(
        model=model,
        api_key=api_key,
        api_base=api_base,
        max_tokens=max_tokens,
        temperature=temperature,
    )
