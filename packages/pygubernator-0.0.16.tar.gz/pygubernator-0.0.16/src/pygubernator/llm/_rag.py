"""Retrieval-Augmented Generation (RAG) utilities.

Stateless helpers that combine embedding generation, vector search,
and context formatting for use in agent and workflow pipelines.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from pygubernator.llm._embeddings import EmbeddingProvider

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RetrievedContext:
    """A chunk of context retrieved via semantic search.

    Args:
        text: The retrieved text content.
        score: Similarity score (higher = more relevant).
        metadata: Additional metadata from the vector store.
    """

    text: str
    score: float
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary."""
        return {
            "text": self.text,
            "score": self.score,
            "metadata": self.metadata,
        }


async def retrieve(
    query: str,
    store: Any,
    embedding_provider: EmbeddingProvider,
    *,
    limit: int = 5,
    min_score: float = 0.0,
) -> list[RetrievedContext]:
    """Embed a query and search a vector store for relevant contexts.

    The *store* must implement a ``search(vector, limit)`` method that
    returns a list of dicts with ``text``, ``score``, and optional
    ``metadata`` keys.  This is compatible with the Chroma, Pinecone,
    and Qdrant store patterns used in pygubernator's memory backends.

    Args:
        query: The search query text.
        store: A vector store with a ``search(vector, limit)`` method.
        embedding_provider: Provider for generating the query embedding.
        limit: Maximum number of results to return.
        min_score: Minimum similarity score threshold.

    Returns:
        Ranked list of retrieved contexts.
    """
    vectors = await embedding_provider.embed([query])
    if not vectors:
        return []
    query_vector = vectors[0]

    search_fn = getattr(store, "search", None)
    if search_fn is None:
        logger.warning(
            "Store %s does not implement search(); returning empty",
            type(store).__name__,
        )
        return []

    raw_results = search_fn(query_vector, limit)
    if not raw_results:
        return []

    contexts: list[RetrievedContext] = []
    for item in raw_results:
        if isinstance(item, dict):
            score = float(item.get("score", 0.0))
            text = str(item.get("text", item.get("content", "")))
            meta = item.get("metadata", {})
        else:
            # Tuple-style (text, score, metadata) or similar
            text = str(getattr(item, "text", str(item)))
            score = float(getattr(item, "score", 0.0))
            meta = getattr(item, "metadata", {})

        if score >= min_score:
            contexts.append(RetrievedContext(text=text, score=score, metadata=meta))

    contexts.sort(key=lambda c: c.score, reverse=True)
    logger.debug(
        "Retrieved %d contexts (query=%s, limit=%d, min_score=%.2f)",
        len(contexts),
        query[:50],
        limit,
        min_score,
    )
    return contexts


def format_rag_context(
    contexts: list[RetrievedContext],
    *,
    max_chars: int = 8000,
    separator: str = "\n\n---\n\n",
) -> str:
    """Format retrieved contexts into a prompt-ready string.

    Concatenates context texts, respecting the character budget.
    Higher-scored contexts appear first.

    Args:
        contexts: Retrieved contexts (assumed pre-sorted by score).
        max_chars: Maximum total characters in the output.
        separator: String between each context chunk.

    Returns:
        Formatted context string ready for injection into a prompt.
    """
    if not contexts:
        return ""

    parts: list[str] = []
    total = 0

    for ctx in contexts:
        text = ctx.text.strip()
        if not text:
            continue
        if total + len(text) + len(separator) > max_chars:
            remaining = max_chars - total
            if remaining > 50:
                parts.append(text[:remaining] + "...")
            break
        parts.append(text)
        total += len(text) + len(separator)

    return separator.join(parts)
