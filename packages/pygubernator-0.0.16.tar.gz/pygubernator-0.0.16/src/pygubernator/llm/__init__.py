"""LLM provider and message types."""

from __future__ import annotations

from pygubernator.llm._config import (
    KNOWN_PROVIDERS,
    ProviderConfig,
    ProviderPreset,
    ProviderType,
)
from pygubernator.llm._embeddings import (
    EmbeddingProvider,
    OpenAIEmbeddingProvider,
    create_embedding_provider,
)
from pygubernator.llm._factory import create_provider, create_provider_from_config
from pygubernator.llm._local import LocalLLMProvider
from pygubernator.llm._messages import (
    ChatMessage,
    ChatRole,
    LLMResponse,
    StreamChunk,
    ToolCall,
    ToolCallDelta,
)
from pygubernator.llm._openai_compat import OpenAICompatibleProvider
from pygubernator.llm._provider import LiteLLMProvider
from pygubernator.llm._rag import (
    RetrievedContext,
    format_rag_context,
    retrieve,
)

__all__ = [
    "ChatMessage",
    "ChatRole",
    "EmbeddingProvider",
    "KNOWN_PROVIDERS",
    "LLMResponse",
    "LiteLLMProvider",
    "LocalLLMProvider",
    "OpenAICompatibleProvider",
    "OpenAIEmbeddingProvider",
    "ProviderConfig",
    "ProviderPreset",
    "ProviderType",
    "RetrievedContext",
    "StreamChunk",
    "ToolCall",
    "ToolCallDelta",
    "create_embedding_provider",
    "create_provider",
    "create_provider_from_config",
    "format_rag_context",
    "retrieve",
]
