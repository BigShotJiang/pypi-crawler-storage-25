"""Local LLM provider using llama-cpp-python for GGUF models."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from pygubernator.errors import LLMError
from pygubernator.llm._messages import LLMResponse

logger = logging.getLogger(__name__)

_PROVIDER_NAME = "local"


class LocalLLMProvider:
    """LLM provider for running GGUF models locally via llama-cpp-python.

    Loads a model into memory and runs inference in-process. No network
    calls required.

    Args:
        model_path: Path to a ``.gguf`` model file.
        n_ctx: Context window size.
        n_gpu_layers: Number of GPU layers (-1 for all available).
        max_tokens: Maximum tokens per response.
        temperature: Sampling temperature.
        top_p: Nucleus sampling parameter.
        top_k: Top-k sampling parameter.
        verbose: Whether to enable llama.cpp verbose output.
    """

    def __init__(
        self,
        model_path: str,
        n_ctx: int = 4096,
        n_gpu_layers: int = -1,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        top_p: float | None = None,
        top_k: int | None = None,
        verbose: bool = False,
    ) -> None:
        self._model_path = model_path
        self._n_ctx = n_ctx
        self._n_gpu_layers = n_gpu_layers
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._top_p = top_p
        self._top_k = top_k
        self._verbose = verbose
        self._llm: Any = None

    def _ensure_loaded(self) -> Any:
        """Load the model if not already loaded."""
        if self._llm is not None:
            return self._llm

        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise LLMError(
                "llama-cpp-python is required for LocalLLMProvider. "
                "Install with: pip install llama-cpp-python",
                provider=_PROVIDER_NAME,
            ) from exc

        logger.info("Loading GGUF model from %s", self._model_path)
        self._llm = Llama(
            model_path=self._model_path,
            n_ctx=self._n_ctx,
            n_gpu_layers=self._n_gpu_layers,
            verbose=self._verbose,
        )
        return self._llm

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Run chat completion locally.

        Args:
            messages: Conversation messages in OpenAI format.
            tools: Tool schemas (logged as warning if provided,
                as most local models have limited tool support).

        Returns:
            LLM response with generated content.

        Raises:
            LLMError: If inference fails.
        """
        if tools:
            logger.warning(
                "Tool calling requested but most local GGUF models "
                "have limited tool-calling support. Tools will be "
                "included in the request but may not work as expected."
            )

        llm = self._ensure_loaded()
        kwargs = self._build_kwargs(messages, tools)

        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None,
                lambda: llm.create_chat_completion(**kwargs),
            )
        except Exception as exc:
            raise LLMError(
                f"Local LLM inference failed: {exc}",
                provider=_PROVIDER_NAME,
                context={"model_path": self._model_path},
            ) from exc

        return self._parse_response(response)

    def _build_kwargs(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Build kwargs for llama-cpp create_chat_completion."""
        kwargs: dict[str, Any] = {
            "messages": messages,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }
        if self._top_p is not None:
            kwargs["top_p"] = self._top_p
        if self._top_k is not None:
            kwargs["top_k"] = self._top_k
        if tools:
            kwargs["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t["name"],
                        "description": t.get("description", ""),
                        "parameters": t.get("parameters", {}),
                    },
                }
                for t in tools
            ]
        return kwargs

    @staticmethod
    def _parse_response(response: dict[str, Any]) -> LLMResponse:
        """Parse llama-cpp response into LLMResponse."""
        choices = response.get("choices", [])
        if not choices:
            return LLMResponse(content="", finish_reason="stop")

        choice = choices[0]
        message = choice.get("message", {})
        content = message.get("content") or ""

        usage_data = response.get("usage") or {}
        usage: dict[str, int] = {}
        if usage_data:
            usage = {
                "prompt_tokens": usage_data.get("prompt_tokens", 0),
                "completion_tokens": usage_data.get("completion_tokens", 0),
                "total_tokens": usage_data.get("total_tokens", 0),
            }

        return LLMResponse(
            content=content,
            finish_reason=choice.get("finish_reason") or "stop",
            usage=usage,
            model=response.get("model") or "",
        )
