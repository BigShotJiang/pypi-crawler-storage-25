"""Middleware protocol and chain for cross-cutting concerns."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any, Protocol, runtime_checkable

from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent

# Type alias for the next-function in the middleware chain.
NextFn = Callable[[Message, BaseAgent], Coroutine[Any, Any, AgentResult]]


@runtime_checkable
class Middleware(Protocol):
    """Protocol for middleware that wraps agent message processing.

    Middleware follows an onion pattern: each middleware receives the
    message, agent, and a ``next_fn`` that invokes the next layer
    (or the agent itself at the innermost layer).
    """

    async def __call__(
        self,
        message: Message,
        agent: BaseAgent,
        next_fn: NextFn,
    ) -> AgentResult:
        """Process the message, optionally delegating to next_fn.

        Args:
            message: The incoming message.
            agent: The agent processing the message.
            next_fn: Callable that invokes the next middleware or agent.

        Returns:
            The agent result, possibly modified.
        """
        ...


class MiddlewareChain:
    """Wraps an agent with an ordered list of middleware.

    Middleware is applied in order: the first middleware in the list
    is the outermost layer. Each calls ``next_fn`` to proceed inward.

    Args:
        agent: The agent to wrap.
        middleware: Ordered list of middleware.
    """

    def __init__(
        self,
        agent: BaseAgent,
        middleware: list[Middleware] | None = None,
    ) -> None:
        self._agent = agent
        self._middleware: list[Middleware] = list(middleware or [])

    def add(self, mw: Middleware) -> None:
        """Append a middleware to the chain.

        Args:
            mw: Middleware to add.
        """
        self._middleware.append(mw)

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the middleware chain and agent.

        Args:
            message: The message to process.

        Returns:
            Result from the agent, after middleware processing.
        """
        agent = self._agent

        async def agent_call(msg: Message, _agent: BaseAgent) -> AgentResult:
            return await _agent.process(msg)

        chain: NextFn = agent_call
        for mw in reversed(self._middleware):
            chain = _wrap(mw, chain)

        return await chain(message, agent)


def _wrap(mw: Middleware, next_fn: NextFn) -> NextFn:
    """Create a closure that binds a middleware to its next function."""

    async def wrapped(message: Message, agent: BaseAgent) -> AgentResult:
        return await mw(message, agent, next_fn)

    return wrapped
