"""Tool-bundle / workflow-pack manifest.

The manifest is a YAML or JSON document (``pygubernator_manifest.yaml``
by default) shipped at the root of a pack archive or the package
directory of a tool bundle. It is intentionally small; anything more
specific lives in rule or tool implementations.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pygubernator.errors import GubernatorError

logger = logging.getLogger(__name__)

DEFAULT_MANIFEST_NAME = "pygubernator_manifest.yaml"

_VERSION_PATTERN = re.compile(r"^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.\-]+)?$")
_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_\-]{1,63}$")


class PackManifestError(GubernatorError):
    """Raised when a pack manifest fails validation."""


@dataclass(frozen=True, slots=True)
class PackManifest:
    """Validated metadata for a tool bundle or workflow pack.

    Args:
        name: Slug identifying the pack (lowercase, 2-64 chars).
        version: SemVer string (``MAJOR.MINOR.PATCH[-prerelease]``).
        description: Short one-line description.
        kind: ``tool_bundle`` or ``workflow_pack``.
        tools: Tool entries advertised by the bundle, each either
            ``module:function`` or ``module:factory``.
        workflows: Relative paths to YAML workflows included in the
            pack (workflow packs only).
        permissions: Tool names this pack claims it *will* call. Used
            as the default allowlist when registering in a
            ``ToolRegistry``.
        env_vars: Environment variables the pack expects at runtime.
        cost_estimate_usd: Rough per-run cost for display / budgeting.
        pygubernator: Semver range the pack is compatible with
            (``>=0.0.1,<1.0.0``). Free-form; checked by caller.
        extras: Free-form metadata (author, license, tags, ...).
    """

    name: str
    version: str
    description: str = ""
    kind: str = "tool_bundle"
    tools: tuple[str, ...] = ()
    workflows: tuple[str, ...] = ()
    permissions: tuple[str, ...] = ()
    env_vars: tuple[str, ...] = ()
    cost_estimate_usd: float | None = None
    pygubernator: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PackManifest:
        """Build a manifest from a loaded dict and validate it.

        Args:
            data: Parsed YAML/JSON body.

        Returns:
            A validated ``PackManifest``.

        Raises:
            PackManifestError: On missing required keys or invalid values.
        """
        if not isinstance(data, dict):
            raise PackManifestError("manifest body must be a mapping")

        name = data.get("name")
        version = data.get("version")
        if not isinstance(name, str) or not _NAME_PATTERN.match(name):
            raise PackManifestError(
                "manifest.name must be lowercase slug [a-z][a-z0-9_-]{1,63}"
            )
        if not isinstance(version, str) or not _VERSION_PATTERN.match(version):
            raise PackManifestError("manifest.version must be SemVer (X.Y.Z)")

        kind = str(data.get("kind", "tool_bundle")).lower()
        if kind not in {"tool_bundle", "workflow_pack"}:
            raise PackManifestError(
                f"manifest.kind must be 'tool_bundle' or 'workflow_pack'; got '{kind}'"
            )

        return cls(
            name=name,
            version=version,
            description=str(data.get("description", "")),
            kind=kind,
            tools=_str_tuple(data.get("tools", ())),
            workflows=_str_tuple(data.get("workflows", ())),
            permissions=_str_tuple(data.get("permissions", ())),
            env_vars=_str_tuple(data.get("env_vars", ())),
            cost_estimate_usd=_maybe_float(data.get("cost_estimate_usd")),
            pygubernator=(
                str(data["pygubernator"])
                if data.get("pygubernator") is not None
                else None
            ),
            extras=_stringify_keys(data.get("extras", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize the manifest as a dict suitable for YAML dump."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "kind": self.kind,
            "tools": list(self.tools),
            "workflows": list(self.workflows),
            "permissions": list(self.permissions),
            "env_vars": list(self.env_vars),
            "cost_estimate_usd": self.cost_estimate_usd,
            "pygubernator": self.pygubernator,
            "extras": dict(self.extras),
        }


def load_manifest(source: str | Path | dict[str, Any]) -> PackManifest:
    """Load and validate a manifest from a path, YAML string, or dict.

    Args:
        source: Path to a manifest file, a YAML/JSON document string,
            or a pre-parsed dict.

    Returns:
        A validated ``PackManifest``.

    Raises:
        PackManifestError: If parsing or validation fails.
    """
    if isinstance(source, PackManifest):
        return source
    if isinstance(source, dict):
        return PackManifest.from_dict(source)
    if isinstance(source, Path):
        if not source.exists():
            raise PackManifestError(f"manifest not found: {source}")
        text = source.read_text(encoding="utf-8")
    elif isinstance(source, str):
        path = Path(source)
        text = path.read_text(encoding="utf-8") if path.exists() else source
    else:
        raise PackManifestError("manifest source must be a path, YAML string, or dict")

    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - PyYAML is a core dep
        raise PackManifestError("PyYAML is required to load manifests") from exc

    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise PackManifestError(f"manifest YAML parse error: {exc}") from exc

    return PackManifest.from_dict(data or {})


def _str_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, list | tuple):
        return tuple(str(v) for v in value)
    raise PackManifestError(f"expected list of strings, got {type(value).__name__}")


def _maybe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise PackManifestError(
            f"cost_estimate_usd must be numeric, got {value!r}"
        ) from exc


def _stringify_keys(value: Any) -> dict[str, Any]:
    if not value:
        return {}
    if not isinstance(value, dict):
        raise PackManifestError("extras must be a mapping")
    return {str(k): v for k, v in value.items()}
