"""Workflow pack: distribute a ``.pgpack`` zip of manifest + YAML + tools.

A pack is a zip with the following layout:

    pack_root/
        pygubernator_manifest.yaml   # required
        workflows/*.yaml             # optional workflow YAMLs
        tools/                       # optional Python tool bundle
        templates/                   # optional Jinja templates

Install extracts the archive to ``~/.pygubernator/packs/<name>/`` by
default. List returns installed packs. Uninstall removes the extracted
tree. Signature verification is out of scope for this MVP; callers can
wrap the archive in a signed transport.
"""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pygubernator.errors import GubernatorError
from pygubernator.packaging._manifest import (
    DEFAULT_MANIFEST_NAME,
    PackManifest,
    load_manifest,
)

logger = logging.getLogger(__name__)
PACK_SIGNATURE_FILE = "pygubernator_signature.json"


class PackInstallError(GubernatorError):
    """Raised when a pack cannot be installed or removed."""


@dataclass(frozen=True, slots=True)
class InstalledPack:
    """A pack that has been unpacked into the local pack home.

    Args:
        manifest: Parsed and validated manifest.
        path: Root directory of the installed pack on disk.
        checksum: SHA-256 of the source archive, if known.
    """

    manifest: PackManifest
    path: Path
    checksum: str | None = None
    verification: dict[str, Any] | None = None

    @property
    def workflow_paths(self) -> list[Path]:
        """Absolute paths to workflow YAMLs listed in the manifest."""
        return [self.path / rel for rel in self.manifest.workflows]


def default_pack_home() -> Path:
    """Return the default ``~/.pygubernator/packs`` directory."""
    root = Path.home() / ".pygubernator" / "packs"
    root.mkdir(parents=True, exist_ok=True)
    return root


def install_pack(
    archive: Path | str,
    *,
    home: Path | None = None,
    force: bool = False,
    verify: bool = False,
    verify_strict: bool = False,
    trusted_key_ids: tuple[str, ...] = (),
) -> InstalledPack:
    """Install a ``.pgpack`` archive into the local pack home.

    Args:
        archive: Path to the ``.pgpack`` zip.
        home: Override for the install root (defaults to
            ``~/.pygubernator/packs``).
        force: Overwrite any existing install with the same name.
        verify: Enable optional signature metadata checks.
        verify_strict: Require a valid signature envelope.
        trusted_key_ids: Allowed signature key IDs.

    Returns:
        An ``InstalledPack`` describing the unpacked layout.

    Raises:
        PackInstallError: On missing archive, invalid zip, missing
            manifest, or conflict when ``force`` is false.
    """
    archive_path = Path(archive)
    if not archive_path.exists():
        raise PackInstallError(f"archive not found: {archive_path}")

    root = Path(home) if home is not None else default_pack_home()
    root.mkdir(parents=True, exist_ok=True)

    checksum = _sha256(archive_path)
    verification = _evaluate_signature_policy(
        archive_path,
        verify=verify,
        verify_strict=verify_strict,
        trusted_key_ids=trusted_key_ids,
    )

    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            names = zf.namelist()
            manifest_name = _find_manifest(names)
            if manifest_name is None:
                raise PackInstallError(
                    f"archive missing {DEFAULT_MANIFEST_NAME}: {archive_path}"
                )
            with zf.open(manifest_name) as fh:
                manifest_bytes = fh.read()
            manifest = load_manifest(manifest_bytes.decode("utf-8"))

            dest = root / manifest.name
            if dest.exists():
                if not force:
                    raise PackInstallError(
                        f"pack already installed: {manifest.name} (use force=True)"
                    )
                shutil.rmtree(dest)
            dest.mkdir(parents=True)

            # Strip a common leading directory so the archive can be
            # produced either with or without a top-level folder.
            common_prefix = _common_prefix(names)
            for member in zf.infolist():
                rel = member.filename[len(common_prefix) :]
                if not rel or rel.endswith("/"):
                    continue
                target = dest / rel
                if not _is_within(dest, target):
                    raise PackInstallError(f"unsafe path in archive: {member.filename}")
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
    except zipfile.BadZipFile as exc:
        raise PackInstallError(f"invalid zip archive: {archive_path}") from exc

    logger.info("installed pack %s@%s at %s", manifest.name, manifest.version, dest)
    return InstalledPack(
        manifest=manifest,
        path=dest,
        checksum=checksum,
        verification=verification,
    )


def list_packs(home: Path | None = None) -> list[InstalledPack]:
    """List packs installed under ``home`` (default ``~/.pygubernator/packs``).

    Packs missing a manifest or failing validation are skipped with a
    warning; callers can use ``uninstall_pack`` to remove them.
    """
    root = Path(home) if home is not None else default_pack_home()
    if not root.exists():
        return []
    packs: list[InstalledPack] = []
    for entry in sorted(root.iterdir()):
        if not entry.is_dir():
            continue
        manifest_path = entry / DEFAULT_MANIFEST_NAME
        if not manifest_path.exists():
            logger.warning("skipping %s: missing manifest", entry)
            continue
        try:
            manifest = load_manifest(manifest_path)
        except Exception as exc:
            logger.warning("skipping %s: invalid manifest (%s)", entry, exc)
            continue
        packs.append(InstalledPack(manifest=manifest, path=entry))
    return packs


def uninstall_pack(name: str, *, home: Path | None = None) -> bool:
    """Remove an installed pack. Returns True when something was removed."""
    root = Path(home) if home is not None else default_pack_home()
    target = root / name
    if not target.exists():
        return False
    shutil.rmtree(target)
    logger.info("removed pack %s", name)
    return True


def pack_directory(
    source_dir: Path | str, destination: Path | str | None = None
) -> Path:
    """Produce a ``.pgpack`` archive from a directory containing a manifest.

    Args:
        source_dir: Directory whose root holds ``pygubernator_manifest.yaml``.
        destination: Optional output ``.pgpack`` path. Defaults to
            ``<name>-<version>.pgpack`` next to ``source_dir``.

    Returns:
        Path to the created archive.

    Raises:
        PackInstallError: If ``source_dir`` has no manifest.
    """
    src = Path(source_dir)
    manifest_path = src / DEFAULT_MANIFEST_NAME
    if not manifest_path.exists():
        raise PackInstallError(f"{DEFAULT_MANIFEST_NAME} not found in {src}")
    manifest = load_manifest(manifest_path)
    if destination is None:
        destination = src.parent / f"{manifest.name}-{manifest.version}.pgpack"
    out = Path(destination)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for entry in _walk(src):
            rel = entry.relative_to(src)
            zf.write(entry, arcname=str(rel))
    return out


# ----------------------------------------------------------------------
# Internal helpers
# ----------------------------------------------------------------------


def _find_manifest(names: list[str]) -> str | None:
    for name in names:
        tail = name.rsplit("/", 1)[-1]
        if tail == DEFAULT_MANIFEST_NAME:
            return name
    return None


def _common_prefix(names: list[str]) -> str:
    if not names:
        return ""
    split = [n.split("/", 1) for n in names if not n.endswith("/")]
    if not split:
        return ""
    first = split[0][0]
    if all(len(parts) > 1 and parts[0] == first for parts in split):
        return f"{first}/"
    return ""


def _walk(root: Path) -> list[Path]:
    results: list[Path] = []
    for entry in sorted(root.rglob("*")):
        if entry.is_file():
            results.append(entry)
    return results


def _is_within(root: Path, candidate: Path) -> bool:
    try:
        candidate.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def inspect_pack_signature(
    archive: Path | str,
    *,
    signature_filename: str = PACK_SIGNATURE_FILE,
) -> dict[str, Any] | None:
    """Return signature metadata from a pack archive, if present."""

    archive_path = Path(archive)
    if not archive_path.exists():
        raise PackInstallError(f"archive not found: {archive_path}")
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            names = zf.namelist()
            signature_name = _find_signature_file(names, signature_filename)
            if signature_name is None:
                return None
            with zf.open(signature_name) as fh:
                payload = json.loads(fh.read().decode("utf-8"))
    except zipfile.BadZipFile as exc:
        raise PackInstallError(f"invalid zip archive: {archive_path}") from exc
    except json.JSONDecodeError as exc:
        raise PackInstallError(
            f"invalid signature metadata JSON in {archive_path}: {exc}"
        ) from exc
    if not isinstance(payload, dict):
        raise PackInstallError(
            f"signature metadata must be a JSON object in {archive_path}"
        )
    return payload


def _evaluate_signature_policy(
    archive: Path,
    *,
    verify: bool,
    verify_strict: bool,
    trusted_key_ids: tuple[str, ...],
) -> dict[str, Any] | None:
    if not (verify or verify_strict or trusted_key_ids):
        return None

    envelope = inspect_pack_signature(archive)
    if envelope is None:
        if verify_strict or trusted_key_ids:
            raise PackInstallError(
                "pack signature metadata is required by verification policy "
                f"({PACK_SIGNATURE_FILE} missing)"
            )
        logger.warning(
            "pack signature metadata is missing (%s); install continuing in non-strict mode",
            PACK_SIGNATURE_FILE,
        )
        return {"present": False, "verified": False}

    key_id = str(envelope.get("key_id", "")).strip()
    if trusted_key_ids and key_id not in set(trusted_key_ids):
        raise PackInstallError(
            "pack signature key_id is not trusted: "
            f"{key_id or '<missing>'}. trusted={list(trusted_key_ids)}"
        )

    required_fields = ("scheme", "signature")
    missing = [
        field for field in required_fields if not str(envelope.get(field, "")).strip()
    ]
    if verify_strict and missing:
        raise PackInstallError(
            f"pack signature metadata missing required field(s): {', '.join(missing)}"
        )

    # Cryptographic verification is intentionally left as host-pluggable.
    # This scaffold enforces envelope presence/shape/trust policy.
    return {
        "present": True,
        "verified": not missing,
        "key_id": key_id or None,
        "scheme": envelope.get("scheme"),
    }


def _find_signature_file(names: list[str], signature_filename: str) -> str | None:
    for name in names:
        tail = name.rsplit("/", 1)[-1]
        if tail == signature_filename:
            return name
    return None


__all__ = [
    "InstalledPack",
    "PACK_SIGNATURE_FILE",
    "PackInstallError",
    "default_pack_home",
    "install_pack",
    "inspect_pack_signature",
    "list_packs",
    "pack_directory",
    "uninstall_pack",
]


_ = Any
