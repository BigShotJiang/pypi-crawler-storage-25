"""Installable skill packs and tool bundles.

Exposes:

- ``PackManifest``: pydantic-compatible metadata for a pack or tool
  bundle (name, version, permissions, cost, env vars, version range).
- ``PackManifestError``: raised when a manifest fails validation.
- ``load_manifest``: parse and validate a manifest YAML/dict.
- ``install_pack`` / ``list_packs`` / ``uninstall_pack``: manage
  ``.pgpack`` archives in the user's pack directory.
- ``discover_tool_bundles``: auto-register tools advertised through
  the ``pygubernator.tools`` setuptools entry-point group.

See ``pygubernator.cli._pack`` and ``pygubernator.cli._new`` for the
CLI frontends.
"""

from __future__ import annotations

from pygubernator.packaging._bundles import (
    discover_sink_bundles,
    discover_source_bundles,
    discover_tool_bundles,
)
from pygubernator.packaging._manifest import (
    DEFAULT_MANIFEST_NAME,
    PackManifest,
    PackManifestError,
    load_manifest,
)
from pygubernator.packaging._pack import (
    PACK_SIGNATURE_FILE,
    PackInstallError,
    default_pack_home,
    inspect_pack_signature,
    install_pack,
    list_packs,
    uninstall_pack,
)

__all__ = [
    "DEFAULT_MANIFEST_NAME",
    "PACK_SIGNATURE_FILE",
    "PackInstallError",
    "PackManifest",
    "PackManifestError",
    "default_pack_home",
    "discover_sink_bundles",
    "discover_source_bundles",
    "discover_tool_bundles",
    "install_pack",
    "inspect_pack_signature",
    "list_packs",
    "load_manifest",
    "uninstall_pack",
]
