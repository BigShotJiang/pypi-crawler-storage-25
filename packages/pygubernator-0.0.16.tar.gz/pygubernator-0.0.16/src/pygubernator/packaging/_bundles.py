"""Plugin auto-discovery via setuptools entry points.

Third-party packages advertise extension bundles under one of the
pygubernator entry-point groups. The currently supported groups are:

- ``pygubernator.tools`` — see :func:`discover_tool_bundles`.
- ``pygubernator.sinks`` — see :func:`discover_sink_bundles`.
- ``pygubernator.sources`` — see :func:`discover_source_bundles`.
- ``pygubernator.nodes`` — consumed by
  :meth:`pygubernator.workflow.NodeTypeRegistry.discover_plugins`.

Example ``pyproject.toml``::

    [project.entry-points."pygubernator.tools"]
    my-search-tools = "my_pkg.tools:register"

    [project.entry-points."pygubernator.sinks"]
    my-notion-sink = "my_pkg.sinks:FACTORY"

    [project.entry-points."pygubernator.sources"]
    my-airtable-source = "my_pkg.sources:FACTORY"

Tool bundles resolve to either a callable ``register(registry)`` or a
module of ``@tool``-decorated functions. Sink/source bundles resolve to
either a ``SinkFactory``/``SourceFactory`` instance or a callable
``register(registry)`` that adds one or more factories.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pygubernator.connectors._sink_registry import SinkFactoryRegistry
    from pygubernator.connectors._source_registry import SourceFactoryRegistry
    from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)

ENTRY_POINT_GROUP = "pygubernator.tools"
SINK_ENTRY_POINT_GROUP = "pygubernator.sinks"
SOURCE_ENTRY_POINT_GROUP = "pygubernator.sources"
NODE_ENTRY_POINT_GROUP = "pygubernator.nodes"


def discover_tool_bundles(
    registry: ToolRegistry,
    *,
    group: str = ENTRY_POINT_GROUP,
) -> int:
    """Register tools from every entry point in ``group``.

    Each entry point must resolve to either:

    - a callable ``register(registry)``, or
    - a module where ``@tool``-decorated functions live (the registry's
      ``register_module`` is used).

    Args:
        registry: The registry to populate.
        group: Entry-point group name.

    Returns:
        Number of tools that were registered across all bundles.
    """
    from importlib.metadata import entry_points

    from pygubernator.tools._decorator import _DecoratedTool

    total = 0
    for ep in entry_points(group=group):
        try:
            target = ep.load()
        except Exception:
            logger.warning(
                "failed to load tool bundle entry point: %s (%s)",
                ep.name,
                ep.value,
                exc_info=True,
            )
            continue

        added_before = len(registry)
        try:
            if callable(target):
                result = target(registry)
                # If the entry point returned a decorated tool, register it.
                if isinstance(result, _DecoratedTool):
                    registry.register(result)
                elif isinstance(result, list):
                    for item in result:
                        if isinstance(item, _DecoratedTool):
                            registry.register(item)
            else:
                registry.register_module(target)
        except Exception:
            logger.warning(
                "tool bundle entry point raised: %s (%s)",
                ep.name,
                ep.value,
                exc_info=True,
            )
            continue

        added = len(registry) - added_before
        if added:
            logger.info("registered %d tool(s) from bundle %s", added, ep.name)
        total += added
    return total


def discover_sink_bundles(
    registry: SinkFactoryRegistry,
    *,
    group: str = SINK_ENTRY_POINT_GROUP,
) -> int:
    """Register sink factories from every entry point in ``group``.

    Thin wrapper over
    :meth:`pygubernator.connectors._sink_registry.SinkFactoryRegistry.discover_plugins`
    kept in the packaging module for symmetry with
    :func:`discover_tool_bundles`.

    Args:
        registry: The sink registry to populate.
        group: Entry-point group name.

    Returns:
        Number of sink types newly registered across all bundles.
    """
    return registry.discover_plugins(group=group)


def discover_source_bundles(
    registry: SourceFactoryRegistry,
    *,
    group: str = SOURCE_ENTRY_POINT_GROUP,
) -> int:
    """Register source factories from every entry point in ``group``.

    Thin wrapper over
    :meth:`pygubernator.connectors._source_registry.SourceFactoryRegistry.discover_plugins`
    kept in the packaging module for symmetry with
    :func:`discover_tool_bundles`.

    Args:
        registry: The source registry to populate.
        group: Entry-point group name.

    Returns:
        Number of source types newly registered across all bundles.
    """
    return registry.discover_plugins(group=group)
