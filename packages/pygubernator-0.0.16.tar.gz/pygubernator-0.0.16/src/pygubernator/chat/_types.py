"""Chat-specific value objects."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ChatTurn:
    """Result of a single chat turn.

    Attributes:
        response: The assistant's final text response.
        tool_calls: List of tool call dicts executed during this turn.
        iterations: Number of think-act-observe iterations used.
    """

    response: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    iterations: int = 0
