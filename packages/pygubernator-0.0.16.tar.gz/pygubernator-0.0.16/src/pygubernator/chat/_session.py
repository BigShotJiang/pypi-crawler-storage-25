"""Multi-turn conversation session for interactive chat."""

from __future__ import annotations

import json
import logging
from typing import Any

from pygubernator._protocols import LLMProvider
from pygubernator._types import ToolResult
from pygubernator.chat._types import ChatTurn
from pygubernator.llm._messages import LLMResponse
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)


class ChatSession:
    """Multi-turn conversation wrapper around an LLM provider.

    Maintains conversation history across turns and runs the
    think-act-observe loop for each user message, feeding
    accumulated context to the LLM.

    Args:
        llm_provider: LLM provider implementing the LLMProvider protocol.
        tool_registry: Registry of available tools.
        system_prompt: System prompt for the conversation.
        max_iterations: Maximum tool-calling iterations per turn.
    """

    def __init__(
        self,
        llm_provider: LLMProvider,
        tool_registry: ToolRegistry,
        system_prompt: str = "",
        max_iterations: int = 10,
    ) -> None:
        self._llm = llm_provider
        self._tools = tool_registry
        self._system_prompt = system_prompt
        self._max_iterations = max_iterations
        self._history: list[dict[str, Any]] = []
        if system_prompt:
            self._history.append({"role": "system", "content": system_prompt})

    async def send(self, user_message: str) -> ChatTurn:
        """Send a user message and get an assistant response.

        Appends the user message to history, runs the
        think-act-observe loop, and returns the result.

        Args:
            user_message: The user's input text.

        Returns:
            ChatTurn with the response, tool calls, and iteration count.
        """
        self._history.append({"role": "user", "content": user_message})

        tool_schemas = self._tools.get_schemas()
        all_tool_calls: list[dict[str, Any]] = []
        final_content = ""
        iterations = 0

        for iteration in range(self._max_iterations):
            iterations = iteration + 1

            response: LLMResponse = await self._llm.chat(
                self._history, tools=tool_schemas or None
            )

            if not response.has_tool_calls:
                final_content = response.content
                self._history.append({"role": "assistant", "content": final_content})
                break

            # Append assistant message with tool calls
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": response.content,
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": (
                                json.dumps(tc.arguments)
                                if isinstance(tc.arguments, dict)
                                else tc.arguments
                            ),
                        },
                    }
                    for tc in response.tool_calls
                ],
            }
            self._history.append(assistant_msg)

            # Execute each tool call
            for tc in response.tool_calls:
                call_info = {
                    "name": tc.name,
                    "arguments": tc.arguments,
                }
                all_tool_calls.append(call_info)
                logger.debug("Calling tool %s with %s", tc.name, tc.arguments)

                if self._tools.has(tc.name):
                    result = await self._tools.execute(tc.name, tc.arguments)
                else:
                    result = ToolResult(
                        tool_name=tc.name,
                        success=False,
                        output=None,
                        error=f"Tool '{tc.name}' not found",
                    )

                self._history.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": (
                            str(result.output) if result.success else str(result.error)
                        ),
                    }
                )
        else:
            # Max iterations reached
            final_content = response.content  # type: ignore[possibly-undefined]
            self._history.append({"role": "assistant", "content": final_content})

        return ChatTurn(
            response=final_content,
            tool_calls=all_tool_calls,
            iterations=iterations,
        )

    @property
    def history(self) -> list[dict[str, Any]]:
        """Return a copy of the conversation history."""
        return list(self._history)

    def clear(self) -> None:
        """Reset conversation history, keeping only the system prompt."""
        self._history.clear()
        if self._system_prompt:
            self._history.append({"role": "system", "content": self._system_prompt})
