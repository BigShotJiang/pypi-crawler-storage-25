"""Built-in demo data for the chat CLI.

Provides ready-to-use schemas, validators, and state machines so that
``pygubernator chat`` works out of the box without extra config.
"""

from __future__ import annotations

from typing import Any


def create_demo_schemas() -> dict[str, Any]:
    """Create demo pycatalyst schemas.

    Returns:
        Mapping of schema name to SchemaSpec objects.

    Raises:
        RuntimeError: If pycatalyst is not installed.
    """
    try:
        from pycatalyst.schema import SchemaBuilder
    except ImportError as exc:
        raise RuntimeError(
            "pycatalyst is required for demo schemas. "
            "Install with: pip install pycatalyst"
        ) from exc

    builder = SchemaBuilder()
    builder.add_field("order_id", type="uuid")
    builder.add_field("customer_name", type="string")
    builder.add_field("amount", type="float", min=0.01, max=10000.0)
    builder.add_field(
        "status",
        type="enum",
        values=["new", "pending", "completed"],
    )
    builder.add_field("quantity", type="integer", min=1, max=100)

    return {"orders": builder.build()}


def create_demo_validators() -> dict[str, Any]:
    """Create demo pycharter validators.

    Returns:
        Mapping of contract name to Validator objects.

    Raises:
        RuntimeError: If pycharter is not installed.
    """
    try:
        from pycharter import Validator
    except ImportError as exc:
        raise RuntimeError(
            "pycharter is required for demo validators. "
            "Install with: pip install pycharter"
        ) from exc

    contract = {
        "name": "orders",
        "version": "1.0.0",
        "fields": {
            "order_id": {
                "type": "string",
                "required": True,
            },
            "customer_name": {
                "type": "string",
                "required": True,
            },
            "amount": {
                "type": "float",
                "required": True,
                "min": 0.01,
                "max": 10000.0,
            },
            "status": {
                "type": "string",
                "required": True,
                "allowed": ["new", "pending", "completed"],
            },
            "quantity": {
                "type": "integer",
                "required": True,
                "min": 1,
                "max": 100,
            },
        },
    }

    return {"orders": Validator(contract)}


def create_demo_machines() -> dict[str, Any]:
    """Create demo pystator state machines.

    Returns:
        Mapping of machine name to StateMachine objects.
    """
    from pystator import StateMachine

    config = {
        "name": "order_lifecycle",
        "initial": "pending",
        "states": [
            "pending",
            "submitted",
            "validated",
            "completed",
            "error",
        ],
        "transitions": [
            {
                "trigger": "submit",
                "source": "pending",
                "dest": "submitted",
            },
            {
                "trigger": "validate",
                "source": "submitted",
                "dest": "validated",
            },
            {
                "trigger": "complete",
                "source": "validated",
                "dest": "completed",
            },
            {
                "trigger": "fail",
                "source": ["pending", "submitted", "validated"],
                "dest": "error",
            },
        ],
    }

    return {"order_lifecycle": StateMachine.from_dict(config)}


def create_demo_system_prompt() -> str:
    """Create a system prompt describing the available demo tools.

    Returns:
        System prompt string for the chat session.
    """
    return (
        "You are a helpful data engineering assistant with access "
        "to the following tools:\n\n"
        "**Data Generation (pycatalyst):**\n"
        "- generate_data: Generate mock data records. "
        "Available schema: 'orders' (fields: order_id, "
        "customer_name, amount, status, quantity)\n"
        "- build_schema: Build a new schema from field "
        "definitions\n\n"
        "**Data Validation (pycharter):**\n"
        "- validate_record: Validate a single record against "
        "a data contract. Available contract: 'orders'\n"
        "- validate_batch: Validate a batch of records. "
        "Available contract: 'orders'\n\n"
        "**State Machines (pystator):**\n"
        "- create_session: Create an entity session. "
        "Available machine: 'order_lifecycle' "
        "(pending -> submitted -> validated -> completed, "
        "with error state)\n"
        "- send_event: Send a trigger to an entity session. "
        "Triggers: submit, validate, complete, fail\n"
        "- get_state: Get entity's current state\n"
        "- list_triggers: List available triggers for an "
        "entity\n\n"
        "When the user asks you to do something, use the "
        "appropriate tools. For example, you can generate "
        "orders, validate them, and then drive them through "
        "the order lifecycle state machine."
    )
