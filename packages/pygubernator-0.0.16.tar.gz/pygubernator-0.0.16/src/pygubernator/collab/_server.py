"""Stateless Socket.IO relay server for collaboration.

Replicates excalidraw-room's architecture: the server never
decrypts data. It relays encrypted messages between clients
in the same room.
"""

from __future__ import annotations

import logging
from typing import Any

import socketio

from pygubernator.collab._protocol import (
    EVENT_CLIENT_BROADCAST,
    EVENT_FIRST_IN_ROOM,
    EVENT_INIT_ROOM,
    EVENT_JOIN_ROOM,
    EVENT_NEW_USER,
    EVENT_ROOM_USER_CHANGE,
    EVENT_SERVER_BROADCAST,
    EVENT_SERVER_VOLATILE_BROADCAST,
)

logger = logging.getLogger(__name__)


def create_collab_app(
    cors_allowed_origins: str | list[str] = "*",
) -> _MountPathFixup:
    """Create an ASGI app wrapping the collaboration relay.

    Mount this on your FastAPI app::

        app.mount("/collab", create_collab_app())

    Args:
        cors_allowed_origins: CORS origins for Socket.IO.

    Returns:
        ASGI application handling Socket.IO connections.
    """
    sio = socketio.AsyncServer(
        async_mode="asgi",
        cors_allowed_origins=cors_allowed_origins,
        logger=False,
    )

    @sio.event
    async def connect(sid: str, environ: dict[str, Any]) -> None:
        """Handle new client connection."""
        logger.info("connect  sid=%s", sid[:8])
        await sio.emit(EVENT_INIT_ROOM, to=sid)

    @sio.on(EVENT_JOIN_ROOM)
    async def join_room(sid: str, room_id: str) -> None:
        """Handle a client joining a collaboration room."""
        await sio.enter_room(sid, room_id)
        members = _get_room_members(sio, room_id)
        if len(members) <= 1:
            await sio.emit(EVENT_FIRST_IN_ROOM, to=sid)
            logger.info(
                "first-in-room  sid=%s  room=%s",
                sid[:8],
                room_id[:8],
            )
        else:
            await sio.emit(
                EVENT_NEW_USER,
                {"socketId": sid},
                room=room_id,
                skip_sid=sid,
            )
            logger.info(
                "join-room  sid=%s  room=%s  members=%d",
                sid[:8],
                room_id[:8],
                len(members),
            )
        await sio.emit(
            EVENT_ROOM_USER_CHANGE,
            members,
            room=room_id,
        )

    @sio.on(EVENT_SERVER_BROADCAST)
    async def server_broadcast(
        sid: str,
        room_id: str,
        encrypted_data: Any,
        iv: Any,
    ) -> None:
        """Relay an encrypted broadcast to all other room members."""
        members = _get_room_members(sio, room_id)
        logger.debug(
            "broadcast  from=%s  room=%s  recipients=%d",
            sid[:8],
            room_id[:8],
            max(0, len(members) - 1),
        )
        await sio.emit(
            EVENT_CLIENT_BROADCAST,
            (encrypted_data, iv),
            room=room_id,
            skip_sid=sid,
        )

    @sio.on(EVENT_SERVER_VOLATILE_BROADCAST)
    async def server_volatile_broadcast(
        sid: str,
        room_id: str,
        encrypted_data: Any,
        iv: Any,
    ) -> None:
        """Relay a volatile broadcast (e.g. cursor moves)."""
        await sio.emit(
            EVENT_CLIENT_BROADCAST,
            (encrypted_data, iv),
            room=room_id,
            skip_sid=sid,
        )

    @sio.event
    async def disconnect(sid: str) -> None:
        """Handle client disconnection and notify remaining members."""
        rooms = [r for r in sio.rooms(sid) if r != sid]
        logger.info("disconnect  sid=%s  rooms=%s", sid[:8], rooms)
        for room_id in rooms:
            remaining = [m for m in _get_room_members(sio, room_id) if m != sid]
            await sio.emit(
                EVENT_ROOM_USER_CHANGE,
                remaining,
                room=room_id,
            )

    return _MountPathFixup(socketio.ASGIApp(sio, socketio_path="socket.io"))


class _MountPathFixup:
    """Adapt scope['path'] for sub-apps mounted via Starlette's ``Mount``.

    Starlette >= 0.52 no longer strips the mount prefix from
    scope['path']; it records the prefix in scope['root_path']
    instead.  python-engineio reads scope['path'] directly for
    route matching, so a Socket.IO app mounted at ``/collab``
    sees ``/collab/socket.io`` and fails to match its
    ``socketio_path="socket.io"``.

    This thin ASGI wrapper restores the pre-0.52 behaviour by
    stripping ``root_path`` from ``path`` before forwarding.
    """

    def __init__(self, app: socketio.ASGIApp) -> None:
        self._app = app

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] in ("http", "websocket"):
            root = scope.get("root_path", "")
            path = scope.get("path", "")
            if root and path.startswith(root):
                scope = dict(scope, path=path[len(root) :] or "/")
        await self._app(scope, receive, send)


def _get_room_members(
    sio: socketio.AsyncServer,
    room_id: str,
) -> list[str]:
    """Get list of socket IDs in a room.

    Args:
        sio: The Socket.IO server instance.
        room_id: The room to query.

    Returns:
        List of socket ID strings in the room.
    """
    try:
        return [sid for sid, _ in sio.manager.get_participants("/", room_id)]
    except Exception:
        return []
