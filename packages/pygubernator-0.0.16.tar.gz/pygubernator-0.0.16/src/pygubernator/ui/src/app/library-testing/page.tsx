import { Suspense } from "react";

import { PageLoading } from "@/components/LoadingSpinner";
import LibraryTestingPageInner from "./LibraryTestingPageInner";

export default function LibraryTestingPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <LibraryTestingPageInner />
    </Suspense>
  );
}
