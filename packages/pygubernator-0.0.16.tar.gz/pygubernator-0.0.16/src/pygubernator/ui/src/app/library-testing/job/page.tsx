import { Suspense } from "react";

import { PageLoading } from "@/components/LoadingSpinner";
import LibraryTestJobDetailInner from "./LibraryTestJobDetailInner";

export default function LibraryTestJobDetailPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <LibraryTestJobDetailInner />
    </Suspense>
  );
}
