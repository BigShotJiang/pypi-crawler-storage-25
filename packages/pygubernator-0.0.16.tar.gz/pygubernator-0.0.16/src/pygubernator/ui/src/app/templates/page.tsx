"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, Sparkles } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import TemplateCard from "@/components/templates/TemplateCard";
import TemplateDetailDrawer from "@/components/templates/TemplateDetailDrawer";
import { templatesApi, type TemplateSummary } from "@/lib/api/templates";

const ALL_TAG = "all";

export default function TemplatesPage() {
  const [templates, setTemplates] = useState<TemplateSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [activeTag, setActiveTag] = useState<string>(ALL_TAG);
  const [selected, setSelected] = useState<TemplateSummary | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    templatesApi
      .list()
      .then((res) => {
        if (!cancelled) setTemplates(res.items);
      })
      .catch((exc) => {
        if (cancelled) return;
        const message = exc instanceof Error ? exc.message : "Failed to load templates";
        setError(message);
        setTemplates([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const tags = useMemo<string[]>(() => {
    if (!templates) return [];
    const seen = new Set<string>();
    for (const t of templates) for (const tag of t.tags) seen.add(tag);
    return Array.from(seen).sort();
  }, [templates]);

  const filtered = useMemo<TemplateSummary[]>(() => {
    if (!templates) return [];
    const q = query.trim().toLowerCase();
    return templates.filter((t) => {
      if (activeTag !== ALL_TAG && !t.tags.includes(activeTag)) return false;
      if (!q) return true;
      const hay = `${t.title} ${t.summary} ${t.tags.join(" ")}`.toLowerCase();
      return hay.includes(q);
    });
  }, [templates, query, activeTag]);

  return (
    <PageContainer>
      <div className="flex flex-col gap-6 pb-12 pt-4">
        <header className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" aria-hidden="true" />
            <h1 className="text-2xl font-semibold tracking-tight">Templates</h1>
          </div>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Start from a ready-made workflow. Each template is fully editable
            after import — tweak prompts, change the schedule, swap nodes.
          </p>
        </header>

        <section
          aria-label="Filter templates"
          className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="relative w-full max-w-sm">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search templates…"
              aria-label="Search templates"
              className="pl-9"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <FilterChip
              label="All"
              active={activeTag === ALL_TAG}
              onClick={() => setActiveTag(ALL_TAG)}
            />
            {tags.map((tag) => (
              <FilterChip
                key={tag}
                label={tag}
                active={activeTag === tag}
                onClick={() => setActiveTag(tag)}
              />
            ))}
          </div>
        </section>

        {error && (
          <div
            role="alert"
            className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"
          >
            {error}
          </div>
        )}

        {loading ? (
          <p className="text-sm text-muted-foreground">Loading templates…</p>
        ) : filtered.length === 0 ? (
          <EmptyState hasFilter={query.trim().length > 0 || activeTag !== ALL_TAG} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((t) => (
              <TemplateCard key={t.slug} template={t} onSelect={setSelected} />
            ))}
          </div>
        )}
      </div>

      <TemplateDetailDrawer
        template={selected}
        onClose={() => setSelected(null)}
      />
    </PageContainer>
  );
}

interface FilterChipProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

function FilterChip({ label, active, onClick }: FilterChipProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "rounded-full border border-primary bg-primary/10 px-3 py-1 text-xs font-medium text-primary"
          : "rounded-full border bg-background px-3 py-1 text-xs font-medium text-muted-foreground hover:text-foreground"
      }
      aria-pressed={active}
    >
      {label}
    </button>
  );
}

function EmptyState({ hasFilter }: { hasFilter: boolean }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed bg-muted/20 p-10 text-center">
      <Badge variant="outline" className="font-normal">
        No matches
      </Badge>
      <p className="text-sm text-muted-foreground">
        {hasFilter
          ? "Try a different search or remove the tag filter."
          : "Templates will appear here once the server has any registered."}
      </p>
    </div>
  );
}
