import { Suspense } from "react";

import RunsPageInner from "./RunsPageInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function RunsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <RunsPageInner />
    </Suspense>
  );
}
