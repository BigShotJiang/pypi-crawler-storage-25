"use client";

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MessageSquare } from "lucide-react";

import { ChatSessionList } from "@/components/chat/ChatSessionList";
import { ChatMessageThread } from "@/components/chat/ChatMessageThread";
import { NewChatForm } from "@/components/chat/NewChatForm";

export default function ChatPage() {
  return (
    <Suspense fallback={null}>
      <ChatPageInner />
    </Suspense>
  );
}

function ChatPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialModel = searchParams.get("model")?.trim() || undefined;
  const initialTitle = searchParams.get("title")?.trim() || undefined;
  const initialSystemPrompt =
    searchParams.get("system_prompt")?.trim() || undefined;
  const hasInitialFromQuery = useMemo(
    () => Boolean(initialModel || initialTitle || initialSystemPrompt),
    [initialModel, initialTitle, initialSystemPrompt],
  );

  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [showNewChat, setShowNewChat] = useState(hasInitialFromQuery);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Strip the deep-link query params after we hydrate state — the form
  // owns the values from here and we don't want a refresh to re-trigger
  // the auto-open every time.
  useEffect(() => {
    if (hasInitialFromQuery) {
      router.replace("/chat/", { scroll: false });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNewChat = useCallback(() => {
    setShowNewChat(true);
    setSelectedSession(null);
  }, []);

  const handleSessionCreated = useCallback((sessionId: string) => {
    setShowNewChat(false);
    setSelectedSession(sessionId);
    setRefreshTrigger((n) => n + 1);
  }, []);

  const handleCancelNewChat = useCallback(() => {
    setShowNewChat(false);
  }, []);

  const handleSelect = useCallback((id: string) => {
    if (!id) {
      setSelectedSession(null);
      return;
    }
    setShowNewChat(false);
    setSelectedSession(id);
  }, []);

  const handleMessageSent = useCallback(() => {
    setRefreshTrigger((n) => n + 1);
  }, []);

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="border-b border-border px-4 py-3">
        <h1 className="text-2xl font-bold text-foreground tracking-tight">
          Chat
        </h1>
      </div>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="w-[250px] shrink-0">
          <ChatSessionList
            selectedId={selectedSession}
            onSelect={handleSelect}
            onNewChat={handleNewChat}
            refreshTrigger={refreshTrigger}
          />
        </div>

        {/* Main content area */}
        <div className="flex-1 flex flex-col">
          {showNewChat && (
            <NewChatForm
              onCreated={handleSessionCreated}
              onCancel={handleCancelNewChat}
              initialModel={initialModel}
              initialTitle={initialTitle}
              initialSystemPrompt={initialSystemPrompt}
            />
          )}

          {!showNewChat && selectedSession && (
            <ChatMessageThread
              sessionId={selectedSession}
              onMessageSent={handleMessageSent}
            />
          )}

          {!showNewChat && !selectedSession && (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <MessageSquare className="h-12 w-12 mb-3 opacity-30" />
              <p className="text-sm">
                Select a conversation or start a new chat.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
