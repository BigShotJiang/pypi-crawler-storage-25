"use client";

/**
 * Knowledge → Notebooks editor (Phase 6 §6.9).
 *
 * Lists every memory scope that has a saved ``ContextSurface`` (an
 * agent's structured Markdown notebook) and lets the operator edit
 * the surface in place. Saving round-trips through the server's
 * ``ContextSurface.from_markdown`` parser so the editor's output
 * matches what an agent reads programmatically.
 *
 * Sibling page to ``/knowledge`` (the KB-chunk browser); kept
 * separate because the two surfaces are conceptually distinct (KB
 * chunks come from ``kb_ingest`` pipelines; notebooks are the agent's
 * long-lived state).
 */

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { BookOpen, Plus, Save, RefreshCw } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  ApiError,
  getContextSurface,
  listMemoryScopes,
  putContextSurface,
} from "@/lib/api";
import type { MemoryScopeQuery, MemoryScopeRow } from "@/lib/api";
import { cn } from "@/lib/utils";

interface ScopeFormState {
  agent_id: string;
  workflow_id: string;
  user_id: string;
  run_id: string;
}

const EMPTY_SCOPE: ScopeFormState = {
  agent_id: "",
  workflow_id: "",
  user_id: "",
  run_id: "",
};

const EMPTY_MARKDOWN_TEMPLATE =
  "## facts\n\n## questions\n\n## next_actions\n\n## log\n";

function rowToQuery(row: MemoryScopeRow): MemoryScopeQuery {
  return {
    agent_id: row.agent_id,
    workflow_id: row.workflow_id,
    user_id: row.user_id,
    run_id: row.run_id,
  };
}

function formToQuery(form: ScopeFormState): MemoryScopeQuery {
  return {
    agent_id: form.agent_id.trim() || undefined,
    workflow_id: form.workflow_id.trim() || undefined,
    user_id: form.user_id.trim() || undefined,
    run_id: form.run_id.trim() || undefined,
  };
}

function describeScope(row: MemoryScopeRow): string {
  const parts: string[] = [];
  if (row.agent_id) parts.push(`agent=${row.agent_id}`);
  if (row.workflow_id) parts.push(`wf=${row.workflow_id}`);
  if (row.user_id) parts.push(`user=${row.user_id}`);
  if (row.run_id) parts.push(`run=${row.run_id}`);
  return parts.length > 0 ? parts.join(" · ") : row.key;
}

export default function KnowledgeNotebooksPage() {
  const [scopes, setScopes] = useState<MemoryScopeRow[]>([]);
  const [scopesLoading, setScopesLoading] = useState(true);
  const [selected, setSelected] = useState<MemoryScopeQuery | null>(null);
  const [markdown, setMarkdown] = useState<string>("");
  const [serverMarkdown, setServerMarkdown] = useState<string>("");
  const [editorLoading, setEditorLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newScope, setNewScope] = useState<ScopeFormState>(EMPTY_SCOPE);

  const loadScopes = useCallback(async () => {
    setScopesLoading(true);
    setError(null);
    try {
      const data = await listMemoryScopes();
      setScopes(data.items);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load scopes");
    } finally {
      setScopesLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadScopes();
  }, [loadScopes]);

  const loadSurface = useCallback(async (scope: MemoryScopeQuery) => {
    setEditorLoading(true);
    setError(null);
    try {
      const data = await getContextSurface(scope);
      setMarkdown(data.markdown);
      setServerMarkdown(data.markdown);
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) {
        // Brand-new scope — start with the empty template so the user
        // can type into a structured shell rather than a blank page.
        setMarkdown(EMPTY_MARKDOWN_TEMPLATE);
        setServerMarkdown("");
      } else {
        setError(
          err instanceof ApiError ? err.message : "Could not load surface",
        );
      }
    } finally {
      setEditorLoading(false);
    }
  }, []);

  const handleSelectScope = useCallback(
    (scope: MemoryScopeQuery) => {
      setSelected(scope);
      void loadSurface(scope);
    },
    [loadSurface],
  );

  const handleSave = useCallback(async () => {
    if (!selected) return;
    setSaving(true);
    setError(null);
    try {
      const data = await putContextSurface(selected, { markdown });
      setMarkdown(data.markdown);
      setServerMarkdown(data.markdown);
      await loadScopes();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save");
    } finally {
      setSaving(false);
    }
  }, [loadScopes, markdown, selected]);

  const handleCreateNewScope = useCallback(() => {
    const scope = formToQuery(newScope);
    if (!Object.values(scope).some(Boolean)) {
      setError("Provide at least one of agent / workflow / user / run id.");
      return;
    }
    setCreating(false);
    setNewScope(EMPTY_SCOPE);
    handleSelectScope(scope);
  }, [handleSelectScope, newScope]);

  const dirty = selected !== null && markdown !== serverMarkdown;

  return (
    <PageContainer>
      <div className="flex flex-col gap-6 pb-12 pt-4">
        <header className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" aria-hidden />
            <h1 className="text-2xl font-semibold tracking-tight">
              Notebooks
            </h1>
          </div>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Edit each memory scope&apos;s long-lived ContextSurface — the
            structured Markdown an agent reads on its next run. Sections
            are <code>facts</code>, <code>questions</code>,{" "}
            <code>next_actions</code>, and <code>log</code>; everything
            else is discarded on save.
          </p>
          <p className="text-xs text-muted-foreground">
            Looking for the chunk browser?{" "}
            <Link href="/knowledge/" className="underline">
              Knowledge base
            </Link>
            .
          </p>
        </header>

        {error ? (
          <p className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
            {error}
          </p>
        ) : null}

        <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-sm">Scopes</CardTitle>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => void loadScopes()}
                  disabled={scopesLoading}
                  aria-label="Refresh scopes"
                >
                  <RefreshCw
                    className={cn(
                      "h-3 w-3",
                      scopesLoading && "animate-spin",
                    )}
                  />
                </Button>
              </div>
              <CardDescription className="text-xs">
                {scopes.length} scope{scopes.length === 1 ? "" : "s"}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-2">
              <ul className="flex flex-col gap-1">
                {scopes.map((row) => {
                  const query = rowToQuery(row);
                  const isSelected = selected?.agent_id === query.agent_id
                    && selected?.workflow_id === query.workflow_id
                    && selected?.user_id === query.user_id
                    && selected?.run_id === query.run_id;
                  return (
                    <li key={row.key}>
                      <button
                        type="button"
                        onClick={() => handleSelectScope(query)}
                        aria-pressed={isSelected}
                        className={cn(
                          "w-full truncate rounded px-2 py-1.5 text-left text-xs font-mono transition-colors hover:bg-muted",
                          isSelected && "bg-muted font-semibold",
                        )}
                        title={row.key}
                      >
                        {describeScope(row)}
                      </button>
                    </li>
                  );
                })}
              </ul>

              {scopes.length === 0 && !scopesLoading ? (
                <p className="text-xs text-muted-foreground">
                  No notebooks yet. Create one below or have an agent
                  call <code>store.set(scope, &quot;context_surface&quot;, …)</code>.
                </p>
              ) : null}

              {creating ? (
                <div className="flex flex-col gap-2 rounded border bg-muted/20 p-2">
                  <Input
                    placeholder="agent_id"
                    value={newScope.agent_id}
                    onChange={(e) =>
                      setNewScope((s) => ({ ...s, agent_id: e.target.value }))
                    }
                    className="h-8"
                  />
                  <Input
                    placeholder="workflow_id"
                    value={newScope.workflow_id}
                    onChange={(e) =>
                      setNewScope((s) => ({
                        ...s,
                        workflow_id: e.target.value,
                      }))
                    }
                    className="h-8"
                  />
                  <Input
                    placeholder="user_id"
                    value={newScope.user_id}
                    onChange={(e) =>
                      setNewScope((s) => ({ ...s, user_id: e.target.value }))
                    }
                    className="h-8"
                  />
                  <div className="flex items-center gap-2">
                    <Button size="sm" onClick={handleCreateNewScope}>
                      Open editor
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setCreating(false);
                        setNewScope(EMPTY_SCOPE);
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setCreating(true)}
                >
                  <Plus className="mr-1 h-3 w-3" />
                  New scope
                </Button>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">
                {selected ? "Editor" : "Select a scope"}
              </CardTitle>
              {selected ? (
                <CardDescription className="font-mono text-xs">
                  {describeScope({
                    key: "",
                    agent_id: selected.agent_id ?? null,
                    workflow_id: selected.workflow_id ?? null,
                    user_id: selected.user_id ?? null,
                    run_id: selected.run_id ?? null,
                  })}
                </CardDescription>
              ) : null}
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              {selected ? (
                <>
                  <textarea
                    value={markdown}
                    onChange={(e) => setMarkdown(e.target.value)}
                    rows={20}
                    spellCheck
                    disabled={editorLoading || saving}
                    className="w-full rounded-md border bg-background px-3 py-2 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
                    aria-label="ContextSurface markdown"
                  />
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[10px] text-muted-foreground">
                      Sections: <code>## facts</code> ·{" "}
                      <code>## questions</code> ·{" "}
                      <code>## next_actions</code> · <code>## log</code>.
                      Bullets become individual entries.
                    </p>
                    <Button
                      size="sm"
                      onClick={() => void handleSave()}
                      disabled={!dirty || saving || editorLoading}
                    >
                      <Save className="mr-1 h-3 w-3" />
                      {saving ? "Saving…" : "Save"}
                    </Button>
                  </div>
                </>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Pick a scope on the left or open a new one to start
                  editing its notebook.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}
