import HomeLanding from "@/components/home/HomeLanding";

/**
 * Landing route (``/``). Renders guided paths + setup checklist.
 * Replaces the previous redirect-to-``/agents`` behaviour so new users
 * have a front door.
 */
export default function HomePage() {
  return <HomeLanding />;
}
