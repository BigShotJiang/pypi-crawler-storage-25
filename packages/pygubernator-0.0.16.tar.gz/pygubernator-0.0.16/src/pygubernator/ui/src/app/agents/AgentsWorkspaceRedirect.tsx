"use client";

import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import { PageLoading } from "@/components/LoadingSpinner";
import { ROUTES } from "@/lib/constants";

/**
 * Legacy `/agents` URLs redirect into the workflow workspace agents area.
 * Maps `?id=` → `?area=agents&agent_id=` and `?q=` → `agent_q=`.
 */
export default function AgentsWorkspaceRedirect() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const id = searchParams.get("id");
    const q = searchParams.get("q");
    const next = new URLSearchParams();
    next.set("area", "agents");
    if (id) next.set("agent_id", id);
    if (q) next.set("agent_q", q);
    router.replace(`${ROUTES.WORKFLOW_EDITOR}?${next.toString()}`, { scroll: false });
  }, [router, searchParams]);

  return <PageLoading message="Opening agents workspace…" />;
}
