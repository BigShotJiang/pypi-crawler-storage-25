"use client";

import { useCallback, useEffect, useState } from "react";
import { Copy, RefreshCw } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { apiGet, apiPost, apiPatch, apiDelete, ApiError } from "@/lib/api";
import { useToast } from "@/components/ui/toaster";
import { formatDateTimeShort } from "@/lib/utils";
import { getApiBaseUrl } from "@/lib/settings";

/* ---------- Types ---------- */

interface Webhook {
  id: string;
  workflow_id: string;
  name: string;
  token: string;
  webhook_url: string;
  enabled: boolean;
  trigger_count: number;
  last_triggered_at: string | null;
  created_at: string;
}

interface WorkflowItem {
  id: string;
  name: string;
}

/* ---------- Component ---------- */

export default function WebhooksPage() {
  const { toast } = useToast();
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [workflows, setWorkflows] = useState<WorkflowItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formWorkflowId, setFormWorkflowId] = useState("");
  const [saving, setSaving] = useState(false);

  const loadWebhooks = useCallback(async () => {
    try {
      const data = await apiGet<{ items: Webhook[] }>(
        "/api/v1/admin/webhooks"
      );
      setWebhooks(data.items);
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) {
        setError("Unable to connect to API.");
      } else {
        setError(e instanceof Error ? e.message : "Failed to load webhooks.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const loadWorkflows = useCallback(async () => {
    try {
      const data = await apiGet<{ items: WorkflowItem[] }>(
        "/api/v1/workflows",
        { page_size: 100 }
      );
      setWorkflows(data.items);
    } catch {
      // Non-critical
    }
  }, []);

  useEffect(() => {
    Promise.all([loadWebhooks(), loadWorkflows()]);
  }, [loadWebhooks, loadWorkflows]);

  function resetForm() {
    setFormName("");
    setFormWorkflowId("");
    setEditing(null);
  }

  function handleAdd() {
    resetForm();
    setEditing("new");
  }

  async function handleSave() {
    setError(null);
    setSaving(true);
    try {
      if (editing === "new") {
        await apiPost<object, Webhook>(
          "/api/v1/admin/webhooks",
          { workflow_id: formWorkflowId, name: formName }
        );
        toast("Webhook created", "success");
      } else {
        await apiPatch<object, Webhook>(
          `/api/v1/admin/webhooks/${editing}`,
          { name: formName }
        );
        toast("Webhook updated", "success");
      }
      await loadWebhooks();
      resetForm();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to save webhook.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    const confirmed = window.confirm("Delete this webhook?");
    if (!confirmed) return;
    try {
      await apiDelete(`/api/v1/admin/webhooks/${id}`);
      toast("Webhook deleted", "success");
      await loadWebhooks();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to delete.", "error");
    }
  }

  async function handleToggle(webhook: Webhook) {
    try {
      await apiPatch<object, Webhook>(
        `/api/v1/admin/webhooks/${webhook.id}`,
        { enabled: !webhook.enabled }
      );
      await loadWebhooks();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to toggle.", "error");
    }
  }

  async function handleRegenerate(webhook: Webhook) {
    const confirmed = window.confirm(
      "Regenerate token? The old URL will stop working."
    );
    if (!confirmed) return;
    try {
      await apiPost<object, Webhook>(
        `/api/v1/admin/webhooks/${webhook.id}/regenerate`
      );
      toast("Token regenerated", "success");
      await loadWebhooks();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to regenerate.", "error");
    }
  }

  function copyUrl(webhook: Webhook) {
    const baseUrl = getApiBaseUrl() || window.location.origin;
    const fullUrl = `${baseUrl}${webhook.webhook_url}`;
    navigator.clipboard.writeText(fullUrl).then(
      () => toast("URL copied to clipboard", "success"),
      () => toast("Failed to copy URL", "error")
    );
  }

  const workflowName = (wfId: string) =>
    workflows.find((w) => w.id === wfId)?.name ?? wfId.slice(0, 12) + "...";

  return (
    <PageContainer>
      <PageHeader
        title="Webhooks"
        description="Manage webhook triggers for workflows"
        actions={
          !editing ? (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => void loadWebhooks()}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button size="sm" onClick={handleAdd}>
                + Add Webhook
              </Button>
            </div>
          ) : undefined
        }
      />

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-800 mb-4">
          {error}
        </div>
      )}

      {/* Inline form */}
      {editing && (
        <div className="rounded-lg border p-4 space-y-4 mb-6 bg-card">
          <h3 className="text-sm font-semibold">
            {editing === "new" ? "Add Webhook" : "Edit Webhook"}
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="wh-name" className="text-sm font-medium">
                Name
              </label>
              <Input
                id="wh-name"
                placeholder="My webhook"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>
            {editing === "new" && (
              <div className="space-y-2">
                <label htmlFor="wh-workflow" className="text-sm font-medium">
                  Workflow
                </label>
                <select
                  id="wh-workflow"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  value={formWorkflowId}
                  onChange={(e) => setFormWorkflowId(e.target.value)}
                >
                  <option value="">Select workflow...</option>
                  {workflows.map((wf) => (
                    <option key={wf.id} value={wf.id}>
                      {wf.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
          <div className="flex gap-2 border-t pt-4">
            <Button variant="outline" onClick={resetForm} disabled={saving}>
              Cancel
            </Button>
            <Button
              onClick={() => void handleSave()}
              disabled={saving || (editing === "new" && !formWorkflowId)}
            >
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      {loading && (
        <p className="text-sm text-muted-foreground">Loading webhooks...</p>
      )}
      {!loading && !editing && webhooks.length === 0 && (
        <p className="text-sm text-muted-foreground py-8 text-center">
          No webhooks configured yet. Click &quot;Add Webhook&quot; to create one.
        </p>
      )}
      {!loading && webhooks.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Workflow</TableHead>
              <TableHead>Webhook URL</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Triggers</TableHead>
              <TableHead>Last Triggered</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {webhooks.map((wh) => (
              <TableRow key={wh.id}>
                <TableCell className="font-medium">
                  {wh.name || wh.id.slice(0, 8) + "..."}
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {workflowName(wh.workflow_id)}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <code className="text-xs font-mono truncate max-w-[200px]">
                      {wh.webhook_url}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={() => copyUrl(wh)}
                      title="Copy full URL"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell>
                  {wh.enabled ? (
                    <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-100">
                      Enabled
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Disabled</Badge>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {wh.trigger_count}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {formatDateTimeShort(wh.last_triggered_at)}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => void handleToggle(wh)}
                    >
                      {wh.enabled ? "Disable" : "Enable"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => void handleRegenerate(wh)}
                    >
                      Regenerate
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => void handleDelete(wh.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </PageContainer>
  );
}
