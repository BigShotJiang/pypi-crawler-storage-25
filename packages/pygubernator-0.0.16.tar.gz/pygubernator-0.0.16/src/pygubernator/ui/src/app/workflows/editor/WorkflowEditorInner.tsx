"use client";

import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";

import {
  Panel as ResPanel,
  Group as ResGroup,
  Separator as ResSep,
} from "react-resizable-panels";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { ResizableWorkspaceLayout } from "@/components/layout/ResizableWorkspaceLayout";
import WorkflowCanvas from "@/components/workflows/WorkflowCanvas";
import WorkflowEditorSidebar from "@/components/workflows/WorkflowEditorSidebar";
import WorkflowEditorToolbar from "@/components/workflows/WorkflowEditorToolbar";
import WorkflowInspectorPanel from "@/components/workflows/WorkflowInspectorPanel";
import { useResolvedSchemas } from "@/hooks/useResolvedSchemas";
import { WorkflowCompanionPanel } from "@/components/workflows/WorkflowCompanionPanel";
import AgentEditorSurface from "@/components/agents/AgentEditorSurface";
import ToolEditorSurface from "@/components/tools/ToolEditorSurface";
import { CommandPalette } from "@/components/workflows/CommandPalette";
import { ExecuteInputDialog } from "@/components/workflows/ExecuteInputDialog";
import { useToast } from "@/components/ui/toaster";
import { apiGet, apiPost, apiPut } from "@/lib/api";
import { collabBroadcast, setCollabLayoutHandler } from "@/hooks/use-collab";
import { ROUTES, WORKFLOW_EDITOR_LAST_ID_KEY } from "@/lib/constants";
import type { WorkflowItem, VersionRow, SpecJson, StepItem, WorkflowNodeTypeItem } from "@/lib/types/workflow";
import {
  useWorkflowEditorStore,
  DRAFT_SESSION_KEY,
  selectSpec,
  selectSetSpec,
  selectAddNode,
  selectRemoveNode,
  selectUpdateNodeConfig,
  selectUpdateNodeSpec,
  selectUpdateNodes,
  selectUpdateEdges,
  selectSelectedNodeIds,
  selectSetSelectedNodeIds,
  selectPastLength,
  selectFutureLength,
  selectUndo,
  selectRedo,
  selectRunOverlay,
  selectLastRunId,
  selectSetRunOverlay,
  selectSetLastRunId,
  selectBottomPanelOpen,
  selectMarkSaved,
  selectWorkflow,
  selectVersions,
  selectVersionsLoading,
  selectCurrentVersion,
  selectSaveVersion,
  selectSaveName,
  selectLoadedVersionId,
  selectInspectorNodeId,
  selectPaletteOpen,
  selectInputDialogOpen,
  selectHydrateFromServer,
  selectClearSessionSnapshot,
  selectPersistEditorMeta,
  selectPromoteDraftSnapshotToWorkflowId,
  selectSetVersionsLoading,
} from "@/stores/workflow-editor";
import { useWorkflowShortcuts } from "@/hooks/useWorkflowShortcuts";
import { useWorkflowNodeTypes } from "@/hooks/useWorkflowNodeTypes";
import { usePolling } from "@/hooks/usePolling";
import { useWorkflowSSE } from "@/hooks/useWorkflowSSE";
import type { SSEEvent } from "@/hooks/useWorkflowSSE";

export default function WorkflowEditorInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  const workflowIdParam = searchParams.get("id");
  const wantBlankCanvas = searchParams.get("new") === "1";
  const agentsEditorEnabled =
    process.env.NEXT_PUBLIC_PYGUBERNATOR_AGENTS_EDITOR_MODE !== "0";
  const toolsEditorEnabled =
    process.env.NEXT_PUBLIC_PYGUBERNATOR_TOOLS_EDITOR_MODE !== "0";
  const editorArea =
    agentsEditorEnabled && searchParams.get("area") === "agents"
      ? "agents"
      : toolsEditorEnabled && searchParams.get("area") === "tools"
        ? "tools"
      : "workflow";

  const [loading, setLoading] = useState(() => Boolean(workflowIdParam));

  /** Restore last `?id=` after nav to bare `/workflows/editor/`, or honor `?new=1` for a blank draft. */
  useLayoutEffect(() => {
    if (typeof window === "undefined") return;
    if (wantBlankCanvas) {
      sessionStorage.removeItem(WORKFLOW_EDITOR_LAST_ID_KEY);
      setLoading(false);
      router.replace(ROUTES.WORKFLOW_EDITOR);
      return;
    }
    if (workflowIdParam) return;
    const last = sessionStorage.getItem(WORKFLOW_EDITOR_LAST_ID_KEY);
    if (last) {
      setLoading(true);
      router.replace(
        `${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(last)}`,
      );
    }
  }, [workflowIdParam, wantBlankCanvas, router]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (workflowIdParam) {
      sessionStorage.setItem(WORKFLOW_EDITOR_LAST_ID_KEY, workflowIdParam);
    }
  }, [workflowIdParam]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [fitViewTrigger, setFitViewTrigger] = useState(0);
  const [savedPositions, setSavedPositions] = useState<
    Record<string, { x: number; y: number }>
  >({});
  const positionSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  /** Elapsed time while a run is tracked (after execute returns until terminal). */
  const [runElapsedSec, setRunElapsedSec] = useState(0);
  const quickAddRef = useRef<(() => void) | null>(null);
  const { nodeTypes: paletteNodeTypes } = useWorkflowNodeTypes();


  const spec = useWorkflowEditorStore(selectSpec);
  const setSpec = useWorkflowEditorStore(selectSetSpec);
  const addNode = useWorkflowEditorStore(selectAddNode);
  const removeNode = useWorkflowEditorStore(selectRemoveNode);
  const updateNodeConfig = useWorkflowEditorStore(selectUpdateNodeConfig);
  const updateNodeSpec = useWorkflowEditorStore(selectUpdateNodeSpec);
  const updateNodes = useWorkflowEditorStore(selectUpdateNodes);
  const updateEdges = useWorkflowEditorStore(selectUpdateEdges);
  const selectedNodeIds = useWorkflowEditorStore(selectSelectedNodeIds);
  const setSelectedNodeIds = useWorkflowEditorStore(selectSetSelectedNodeIds);
  const canUndo = useWorkflowEditorStore(selectPastLength) > 0;
  const canRedo = useWorkflowEditorStore(selectFutureLength) > 0;
  const undo = useWorkflowEditorStore(selectUndo);
  const redo = useWorkflowEditorStore(selectRedo);
  const runOverlay = useWorkflowEditorStore(selectRunOverlay);
  const lastRunId = useWorkflowEditorStore(selectLastRunId);
  /** Avoid duplicate completion toasts when both SSE and polling observe the same finish. */
  const runCompletionToastSentRef = useRef(false);
  const setRunOverlay = useWorkflowEditorStore(selectSetRunOverlay);
  const setLastRunId = useWorkflowEditorStore(selectSetLastRunId);

  useEffect(() => {
    if (!lastRunId) {
      setRunElapsedSec(0);
      return;
    }
    setRunElapsedSec(0);
    const interval = setInterval(() => setRunElapsedSec((s) => s + 1), 1000);
    return () => clearInterval(interval);
  }, [lastRunId]);

  const bottomPanelOpen = useWorkflowEditorStore(selectBottomPanelOpen);
  const markSaved = useWorkflowEditorStore(selectMarkSaved);

  const workflow = useWorkflowEditorStore(selectWorkflow);
  const versions = useWorkflowEditorStore(selectVersions);
  const versionsLoading = useWorkflowEditorStore(selectVersionsLoading);
  const currentVersion = useWorkflowEditorStore(selectCurrentVersion);
  const loadedVersionId = useWorkflowEditorStore(selectLoadedVersionId);
  const saveVersion = useWorkflowEditorStore(selectSaveVersion);
  const saveName = useWorkflowEditorStore(selectSaveName);
  const inspectorNodeId = useWorkflowEditorStore(selectInspectorNodeId);
  const resolvedSchemas = useResolvedSchemas(spec as Record<string, unknown> | null);
  const paletteOpen = useWorkflowEditorStore(selectPaletteOpen);
  const inputDialogOpen = useWorkflowEditorStore(selectInputDialogOpen);

  const hydrateFromServer = useWorkflowEditorStore(selectHydrateFromServer);
  const clearSessionSnapshot = useWorkflowEditorStore(selectClearSessionSnapshot);
  const persistEditorMeta = useWorkflowEditorStore(selectPersistEditorMeta);
  const promoteDraftSnapshotToWorkflowId = useWorkflowEditorStore(
    selectPromoteDraftSnapshotToWorkflowId,
  );
  const setVersionsLoading = useWorkflowEditorStore(selectSetVersionsLoading);

  const workflowId = workflowIdParam;
  const isDraft = !workflowId;

  const setEditorArea = useCallback(
    (next: "workflow" | "agents" | "tools") => {
      if (next === "agents" && !agentsEditorEnabled) {
        return;
      }
      if (next === "tools" && !toolsEditorEnabled) {
        return;
      }
      const params = new URLSearchParams(searchParams.toString());
      if (next === "workflow") {
        params.delete("area");
        params.delete("agent_id");
        params.delete("agent_q");
      } else {
        params.set("area", next);
      }
      const query = params.toString();
      router.replace(query ? `${ROUTES.WORKFLOW_EDITOR}?${query}` : ROUTES.WORKFLOW_EDITOR, {
        scroll: false,
      });
    },
    [agentsEditorEnabled, router, searchParams, toolsEditorEnabled],
  );

  const loadWorkflowFromServer = useCallback(
    async (forceServer: boolean, stillValid?: () => boolean) => {
      const id = workflowIdParam;
      if (!id) return;

      if (forceServer) {
        clearSessionSnapshot(id);
      }

      setLoading(true);
      setError(null);
      try {
        const [wf, versionsRes] = await Promise.all([
          apiGet<WorkflowItem>(`/api/v1/workflows/${id}`),
          apiGet<{ items: VersionRow[] }>(`/api/v1/workflows/${id}/versions`),
        ]);
        if (stillValid && !stillValid()) return;
        const loadedVersions = versionsRes.items ?? [];
        const active =
          loadedVersions.find((v) => v.active) ?? loadedVersions[0] ?? null;
        hydrateFromServer({
          workflow: wf,
          versions: loadedVersions,
          activeSpec: active?.spec_json ?? { meta: {}, nodes: {}, edges: [] },
          loadedVersionId: active?.id ?? null,
          currentVersion: active?.version ?? "",
          saveVersion: active ? bumpPatch(active.version) : "1.0.0",
          saveName: wf.name,
        });
        // Center the canvas on the loaded workflow after hydration
        setFitViewTrigger((n) => n + 1);
        // Load layout positions separately from the spec
        const ver = active?.version ?? "";
        if (ver) {
          apiGet<{ positions: Record<string, { x: number; y: number }> }>(
            "/api/v1/layouts",
            { workflow_id: id, workflow_version: ver },
          )
            .then((res) => {
              if (stillValid && !stillValid()) return;
              if (res.positions && Object.keys(res.positions).length > 0) {
                setSavedPositions(res.positions);
              }
            })
            .catch(() => {/* fall back to spec-embedded positions */});
        }
      } catch {
        if (stillValid && !stillValid()) return;
        if (typeof window !== "undefined") {
          sessionStorage.removeItem(WORKFLOW_EDITOR_LAST_ID_KEY);
        }
        router.replace(ROUTES.WORKFLOW_EDITOR);
      } finally {
        if (!stillValid || stillValid()) setLoading(false);
      }
    },
    [workflowIdParam, router, hydrateFromServer, clearSessionSnapshot],
  );

  const handlePositionChange = useCallback(
    (positions: Record<string, { x: number; y: number }>) => {
      setSavedPositions((prev) => ({ ...prev, ...positions }));

      // Broadcast to collaborators immediately
      collabBroadcast({
        type: "CONFIG_UPDATE",
        payload: { _layoutPositions: positions },
      });

      // Debounced persist to layout API
      if (positionSaveTimerRef.current) clearTimeout(positionSaveTimerRef.current);
      positionSaveTimerRef.current = setTimeout(() => {
        const wfId = workflowIdParam;
        const ver = useWorkflowEditorStore.getState().currentVersion;
        if (!wfId || !ver) return;
        apiPut<{ positions: typeof positions }, { ok: boolean }>(
          `/api/v1/layouts/${encodeURIComponent(wfId)}/${encodeURIComponent(ver)}`,
          { positions },
        ).catch(() => {/* layout save failed — non-critical */});
      }, 500);
    },
    [workflowIdParam],
  );

  // Wire collab handler so remote position updates flow into savedPositions
  useEffect(() => {
    setCollabLayoutHandler((positions) => {
      setSavedPositions((prev) => ({ ...prev, ...positions }));
    });
    return () => setCollabLayoutHandler(null);
  }, []);

  useEffect(() => {
    const key = workflowIdParam ?? DRAFT_SESSION_KEY;
    const store = useWorkflowEditorStore.getState();
    const restored = store.switchSession(key);
    store.resetForDraftIfNeeded(key, restored);

    if (!workflowIdParam) {
      // Draft mode — use cache or start fresh
      if (!restored) {
        setLoading(false);
        setError(null);
      } else {
        setLoading(false);
      }
      return;
    }

    // Named workflow — always verify with server to ensure fresh spec.
    // The restored session preserves undo history and viewport, but
    // spec must come from the server to avoid stale/empty canvases.
    let cancelled = false;
    void loadWorkflowFromServer(false, () => !cancelled);

    return () => {
      cancelled = true;
    };
  }, [workflowIdParam, loadWorkflowFromServer]);

  const refreshVersions = useCallback(
    async (id: string) => {
      setVersionsLoading(true);
      try {
        const result = await apiGet<{ items: VersionRow[] }>(
          `/api/v1/workflows/${id}/versions`,
        );
        const items = result.items ?? [];
        const active = items.find((v) => v.active) ?? items[0] ?? null;
        useWorkflowEditorStore.setState({
          versions: items,
          currentVersion: active?.version ?? "",
        });
        return items;
      } finally {
        setVersionsLoading(false);
      }
    },
    [setVersionsLoading],
  );

  const handleSelectVersion = useCallback(
    (versionId: string) => {
      const selected = versions.find((v) => v.id === versionId);
      if (!selected) return;
      setSpec(selected.spec_json, { replaceHistory: true });
      persistEditorMeta({
        currentVersion: selected.version,
        saveVersion: bumpPatch(selected.version),
        loadedVersionId: selected.id,
      });
      markSaved();
      setRunOverlay(null);
    },
    [versions, setSpec, markSaved, setRunOverlay, persistEditorMeta],
  );

  const saveWorkflow = useCallback(async () => {
    if (!saveVersion.trim()) return;
    setBusy(true);
    setError(null);

    try {
      let targetId = workflowId;

      if (!targetId) {
        const name =
          saveName.trim() || `Workflow ${new Date().toLocaleString()}`;
        const created = await apiPost<
          { name: string; owner: string },
          WorkflowItem
        >("/api/v1/workflows", { name, owner: "system" });
        targetId = created.id;
        useWorkflowEditorStore.setState({
          workflow: created,
          saveName: created.name,
        });
        promoteDraftSnapshotToWorkflowId(targetId);
        router.replace(
          `${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(targetId)}`,
        );
      }

      await apiPost<{ version: string; spec_json: SpecJson }, VersionRow>(
        `/api/v1/workflows/${targetId}/versions`,
        { version: saveVersion.trim(), spec_json: spec },
      );
      const savedVersion = saveVersion.trim();
      const updatedVersions = await refreshVersions(targetId);
      if (!updatedVersions.some((v) => v.version === savedVersion)) {
        persistEditorMeta({ currentVersion: savedVersion });
      }
      markSaved();
      toast(`Saved as version ${savedVersion}`, "success");
      persistEditorMeta({ saveVersion: bumpPatch(savedVersion) });
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  }, [
    workflowId,
    saveVersion,
    saveName,
    spec,
    toast,
    router,
    markSaved,
    refreshVersions,
    promoteDraftSnapshotToWorkflowId,
    persistEditorMeta,
  ]);

  const executeWorkflow = useCallback(
    async (inputJson: Record<string, unknown> = {}, sessionId?: string) => {
      persistEditorMeta({ inputDialogOpen: false });
      setBusy(true);
      setError(null);
      setRunOverlay(null);
      runCompletionToastSentRef.current = false;

      try {
        let targetId = workflowId;
        if (!targetId) {
          const name =
            saveName.trim() || `Workflow ${new Date().toLocaleString()}`;
          const created = await apiPost<
            { name: string; owner: string },
            WorkflowItem
          >("/api/v1/workflows", { name, owner: "system" });
          targetId = created.id;
          useWorkflowEditorStore.setState({
            workflow: created,
            saveName: created.name,
          });
          promoteDraftSnapshotToWorkflowId(targetId);
          router.replace(
            `${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(targetId)}`,
          );
        }

        await apiPost<{ version: string; spec_json: SpecJson }, VersionRow>(
          `/api/v1/workflows/${targetId}/versions`,
          { version: saveVersion.trim() || "1.0.0", spec_json: spec },
        );
        const savedVersion = saveVersion.trim() || "1.0.0";
        const updatedVersions = await refreshVersions(targetId);
        if (!updatedVersions.some((v) => v.version === savedVersion)) {
          persistEditorMeta({ currentVersion: savedVersion });
        }
        persistEditorMeta({ saveVersion: bumpPatch(savedVersion) });

        const res = await apiPost<
          {
            input_json: Record<string, unknown>;
            session_id?: string;
            version_id?: string;
          },
          { run: { id: string; status: string } }
        >(`/api/v1/workflows/${targetId}/execute`, {
          input_json: inputJson,
          session_id: sessionId,
          version_id: loadedVersionId || undefined,
        });
        setLastRunId(res.run.id);
        // Auto-open the companion panel so the user can follow execution
        if (!useWorkflowEditorStore.getState().bottomPanelOpen) {
          useWorkflowEditorStore.setState({ bottomPanelOpen: true });
        }
        toast(
          `Workflow executing... Run ID: ${res.run.id.slice(0, 8)}`,
          "default",
        );
      } catch (e) {
        const err = e instanceof Error ? e : new Error(String(e));
        setError(err);
        toast(err.message, "error");
      } finally {
        setBusy(false);
      }
    },
    [
      workflowId,
      saveName,
      saveVersion,
      spec,
      loadedVersionId,
      toast,
      router,
      setRunOverlay,
      setLastRunId,
      refreshVersions,
      promoteDraftSnapshotToWorkflowId,
      persistEditorMeta,
    ],
  );

  const pollRun = useCallback(async () => {
    if (!lastRunId || !workflowId) return;
    try {
      const data = await apiGet<{
        run: {
          id: string;
          status: string;
          error_message: string | null;
        };
        steps: Array<{
          id: string;
          workflow_run_id: string;
          node_id: string;
          node_type: string;
          status: string;
          input_json: Record<string, unknown>;
          output_json: Record<string, unknown>;
          error_message: string | null;
          output_handle: string;
          started_at: string | null;
          completed_at: string | null;
          duration_ms: number | null;
        }>;
      }>(`/api/v1/workflows/runs/${lastRunId}`);
      const overlay: Record<string, (typeof data.steps)[0]> = {};
      for (const step of data.steps ?? []) {
        overlay[step.node_id] = step;
      }
      setRunOverlay(overlay);
      const terminal = ["completed", "failed", "cancelled", "success"];
      if (terminal.includes(data.run.status)) {
        if (!runCompletionToastSentRef.current) {
          runCompletionToastSentRef.current = true;
          const st = data.run.status;
          if (st === "failed") {
            if (data.run.error_message) {
              toast(`Run failed: ${data.run.error_message}`, "error");
            } else {
              toast("Workflow run failed", "error");
            }
          } else if (st === "completed" || st === "success") {
            toast("Workflow completed successfully", "success");
          } else if (st === "cancelled") {
            toast("Workflow run cancelled", "default");
          }
        }
        setLastRunId(null);
      }
    } catch {
      // Silently ignore poll errors
    }
  }, [lastRunId, workflowId, setRunOverlay, setLastRunId, toast]);

  const handleSSEEvent = useCallback(
    (event: SSEEvent) => {
      const prev = useWorkflowEditorStore.getState().runOverlay ?? {};
      if (event.type === "node_started") {
        setRunOverlay({
          ...prev,
          [event.node_id!]: {
            ...prev[event.node_id!],
            node_id: event.node_id!,
            status: "running",
          } as unknown as StepItem,
        });
      }
      if (event.type === "node_completed" || event.type === "node_failed") {
        setRunOverlay({
          ...prev,
          [event.node_id!]: {
            ...prev[event.node_id!],
            node_id: event.node_id!,
            status: event.type === "node_completed" ? "success" : "failed",
            output_json: event.output ?? {},
            error_message: event.error ?? null,
            duration_ms: event.duration_ms ?? null,
          } as unknown as StepItem,
        });
      }
      if (event.type === "node_failed" && event.error) {
        toast(`Node ${event.node_id} failed: ${event.error}`, "error");
      }
      if (event.type === "workflow_completed") {
        runCompletionToastSentRef.current = true;
        const ok = event.success !== false;
        toast(
          ok ? "Workflow completed successfully" : "Workflow completed with errors",
          ok ? "success" : "error",
        );
        void pollRun();
        setTimeout(() => setLastRunId(null), 1000);
      }
      if (event.type === "done") {
        void pollRun();
        setTimeout(() => setLastRunId(null), 1000);
      }
    },
    [setRunOverlay, pollRun, setLastRunId, toast],
  );

  const { connected: sseConnected } = useWorkflowSSE(lastRunId, handleSSEEvent);

  usePolling(pollRun, 2000, !!lastRunId && !sseConnected);

  const openExecuteDialog = useCallback(() => {
    persistEditorMeta({ inputDialogOpen: true });
  }, [persistEditorMeta]);

  const shortcutActions = useMemo(
    () => ({
      onSave: () => void saveWorkflow(),
      onExecute: openExecuteDialog,
      onFitView: () => setFitViewTrigger((n) => n + 1),
      onOpenPalette: () => persistEditorMeta({ paletteOpen: true }),
      onOpenInspector: (nodeId: string) =>
        persistEditorMeta({ inspectorNodeId: nodeId }),
      onQuickAdd: () => quickAddRef.current?.(),
    }),
    [saveWorkflow, openExecuteDialog, persistEditorMeta],
  );

  useWorkflowShortcuts(shortcutActions);

  const toolbarRunStatus = useMemo(() => {
    if (!lastRunId) return null;
    if (!runOverlay || Object.keys(runOverlay).length === 0) return "running";
    return inferRunStatus(runOverlay) ?? "running";
  }, [lastRunId, runOverlay]);

  const nodes = spec.nodes ?? {};
  const edges = spec.edges ?? [];

  useEffect(() => {
    if (!inspectorNodeId) return;
    const n = spec.nodes ?? {};
    if (!n[inspectorNodeId]) {
      persistEditorMeta({ inspectorNodeId: null });
    }
  }, [inspectorNodeId, spec.nodes, persistEditorMeta]);

  if (loading) {
    return (
      <div
        className="flex items-center justify-center"
        style={{ height: "calc(100vh - 4rem)" }}
      >
        <PageLoading message="Loading editor..." />
      </div>
    );
  }

  const canvasContent = (
    <div className="relative h-full w-full overflow-hidden">
      <WorkflowCanvas
        nodes={nodes}
        edges={edges}
        selectedNodeIds={selectedNodeIds}
        onSelectNodeIds={setSelectedNodeIds}
        onNodesChange={updateNodes}
        onEdgesChange={updateEdges}
        onRemoveNode={removeNode}
        onAddNode={addNode}
        onOpenInspector={(nodeId) =>
          persistEditorMeta({ inspectorNodeId: nodeId })
        }
        onCloseInspector={() => persistEditorMeta({ inspectorNodeId: null })}
        runOverlay={runOverlay}
        resolvedSchemas={resolvedSchemas}
        fitViewTrigger={fitViewTrigger}
        onQuickAddRef={quickAddRef}
        savedPositions={savedPositions}
        onPositionChange={handlePositionChange}
      />
    </div>
  );

  return (
    <ResizableWorkspaceLayout
      renderSidebar={(api) => (
        <WorkflowEditorSidebar
          {...api}
          editorArea={editorArea}
          agentsEnabled={agentsEditorEnabled}
          toolsEnabled={toolsEditorEnabled}
          onEditorAreaChange={setEditorArea}
          onAddNode={addNode}
          spec={spec}
          onSpecChange={setSpec}
        />
      )}
    >
      <div className="relative flex flex-col flex-1 h-full overflow-hidden">
        {editorArea === "workflow" ? (
          <WorkflowEditorToolbar
            workflowName={
              workflow?.name ?? (isDraft ? "New Workflow" : "Workflow Editor")
            }
            workflowId={workflowId ?? ""}
            saveVersion={saveVersion}
            onSaveVersionChange={(v) => persistEditorMeta({ saveVersion: v })}
            currentVersion={currentVersion}
            versions={versions}
            versionsLoading={versionsLoading}
            onSelectVersion={handleSelectVersion}
            onSave={() => void saveWorkflow()}
            onExecute={openExecuteDialog}
            onSaveAndExecute={() => {
              void (async () => {
                await saveWorkflow();
                openExecuteDialog();
              })();
            }}
            onReload={() => void loadWorkflowFromServer(true)}
            onUndo={undo}
            onRedo={redo}
            canUndo={canUndo}
            canRedo={canRedo}
            busy={busy}
            loading={loading}
            lastRunId={lastRunId}
            runStatus={toolbarRunStatus}
            runElapsedSec={runElapsedSec}
            sseConnected={sseConnected}
            isDraft={isDraft}
            saveName={saveName}
            onSaveNameChange={(name) => persistEditorMeta({ saveName: name })}
          />
        ) : null}
        {editorArea === "workflow" ? (
          <WorkflowInspectorPanel
            nodeId={inspectorNodeId}
            nodeSpec={
              inspectorNodeId ? (nodes[inspectorNodeId] ?? null) : null
            }
            workflowEdges={edges}
            workflowNodes={nodes}
            resolvedSchemas={resolvedSchemas}
            onUpdateConfig={(config) =>
              inspectorNodeId && updateNodeConfig(inspectorNodeId, config)
            }
            onUpdateNodeSpec={(node) =>
              inspectorNodeId && updateNodeSpec(inspectorNodeId, node)
            }
            onRemoveNode={() => inspectorNodeId && removeNode(inspectorNodeId)}
            onClose={() => persistEditorMeta({ inspectorNodeId: null })}
            runStep={
              inspectorNodeId && runOverlay
                ? (runOverlay[inspectorNodeId] ?? null)
                : null
            }
            nodeSchemas={
              inspectorNodeId && resolvedSchemas
                ? (resolvedSchemas[inspectorNodeId] ?? null)
                : null
            }
          />
        ) : null}

        {editorArea === "agents" ? (
          <AgentEditorSurface />
        ) : editorArea === "tools" ? (
          <ToolEditorSurface />
        ) : bottomPanelOpen ? (
          <ResGroup
            id="wf-editor-vertical"
            orientation="vertical"
            style={{ flex: "1 1 0%", minHeight: 0 }}
          >
            <ResPanel id="wf-editor-main" defaultSize={75} minSize={15}>
              {canvasContent}
            </ResPanel>
            <ResSep
              className="shrink-0 bg-border hover:bg-primary/50 transition-colors cursor-row-resize"
              style={{ height: 6 }}
            />
            <ResPanel id="wf-editor-companion" defaultSize={25} minSize={10}>
              <div className="h-full overflow-hidden">
                <WorkflowCompanionPanel resolvedSchemas={resolvedSchemas} />
              </div>
            </ResPanel>
          </ResGroup>
        ) : (
          canvasContent
        )}

        {editorArea === "workflow" && paletteOpen && (
          <CommandPalette
            onClose={() => persistEditorMeta({ paletteOpen: false })}
            onSave={() => void saveWorkflow()}
            onExecute={openExecuteDialog}
            onFitView={() => setFitViewTrigger((n) => n + 1)}
            nodeTypes={paletteNodeTypes}
            onAddNode={addNode}
          />
        )}
        {editorArea === "workflow" && inputDialogOpen && (
          <ExecuteInputDialog
            spec={spec}
            busy={busy}
            workflowId={workflowId ?? null}
            onExecute={(inputJson, sessionId) => void executeWorkflow(inputJson, sessionId)}
            onClose={() => persistEditorMeta({ inputDialogOpen: false })}
          />
        )}
        {error && (
          <div className="absolute bottom-3 left-3 right-3 z-10">
            <ErrorDisplay error={error} />
          </div>
        )}
      </div>
    </ResizableWorkspaceLayout>
  );
}

function bumpPatch(version: string): string {
  const parts = version.split(".");
  if (parts.length === 3) {
    const patch = parseInt(parts[2], 10);
    if (!isNaN(patch)) return `${parts[0]}.${parts[1]}.${patch + 1}`;
  }
  return version;
}

function inferRunStatus(
  overlay: Record<string, { status: string }>,
): string | null {
  const statuses = Object.values(overlay).map((s) => s.status);
  if (statuses.length === 0) return null;
  if (statuses.some((s) => s === "failed")) return "failed";
  if (statuses.some((s) => s === "running")) return "running";
  if (statuses.every((s) => s === "completed" || s === "success")) {
    return "completed";
  }
  return "running";
}
