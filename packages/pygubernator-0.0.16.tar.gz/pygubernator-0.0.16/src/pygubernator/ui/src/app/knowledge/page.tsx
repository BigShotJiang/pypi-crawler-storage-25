"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { BookOpen, Filter, RefreshCw, Search } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageContainer } from "@/components/layout/PageContainer";
import KBChunkCard from "@/components/knowledge/KBChunkCard";
import KBChunkDrawer from "@/components/knowledge/KBChunkDrawer";
import KBGovernanceBanner from "@/components/knowledge/KBGovernanceBanner";
import KBSchemeIOControls from "@/components/knowledge/KBSchemeIOControls";
import { useToast } from "@/components/ui/toaster";
import { ApiError } from "@/lib/api";
import { kbApi, type BindingState, type KBChunk } from "@/lib/api/kb";

type Mode = "browse" | "search";

interface ScopeFilter {
  agent_id: string;
  workflow_id: string;
  run_id: string;
  contract_id: string;
  concept: string;
  binding_state: BindingState | "";
}

const EMPTY_SCOPE: ScopeFilter = {
  agent_id: "",
  workflow_id: "",
  run_id: "",
  contract_id: "",
  concept: "",
  binding_state: ""
};

const PAGE_SIZE = 25;

export default function KnowledgePage() {
  const { toast } = useToast();
  const [mode, setMode] = useState<Mode>("browse");
  const [filters, setFilters] = useState<ScopeFilter>(EMPTY_SCOPE);
  const [chunks, setChunks] = useState<KBChunk[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<KBChunk | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchDraft, setSearchDraft] = useState("");

  const hasFilter = useMemo(
    () => Object.values(filters).some((v) => v !== ""),
    [filters]
  );

  const loadChunks = useCallback(
    async (targetPage: number) => {
      setLoading(true);
      setError(null);
      try {
        const res = await kbApi.list({
          agent_id: filters.agent_id || undefined,
          workflow_id: filters.workflow_id || undefined,
          run_id: filters.run_id || undefined,
          contract_id: filters.contract_id || undefined,
          concept: filters.concept || undefined,
          binding_state: filters.binding_state || undefined,
          page: targetPage,
          page_size: PAGE_SIZE
        });
        setChunks(res.items);
        setTotal(res.meta.total);
      } catch (exc) {
        const message = exc instanceof Error ? exc.message : "Failed to load";
        setError(message);
        setChunks([]);
        setTotal(0);
      } finally {
        setLoading(false);
      }
    },
    [filters]
  );

  const runSearch = useCallback(
    async (query: string) => {
      const trimmed = query.trim();
      if (!trimmed) {
        setMode("browse");
        return;
      }
      setMode("search");
      setLoading(true);
      setError(null);
      try {
        const res = await kbApi.search({
          query: trimmed,
          limit: 20,
          scope_filter: filters.agent_id
            ? { agent_id: filters.agent_id }
            : undefined,
          concept_filter: filters.concept ? [filters.concept] : undefined,
          contract_filter: filters.contract_id ? [filters.contract_id] : undefined
        });
        setChunks(res.items);
        setTotal(res.count);
        setSearchQuery(trimmed);
      } catch (exc) {
        const message =
          exc instanceof ApiError
            ? exc.message
            : exc instanceof Error
              ? exc.message
              : "Search failed";
        setError(message);
        setChunks([]);
        setTotal(0);
        toast(`Search failed: ${message}`, "error");
      } finally {
        setLoading(false);
      }
    },
    [filters, toast]
  );

  useEffect(() => {
    if (mode === "browse") {
      void loadChunks(page);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, page, filters]);

  function handleClearFilters() {
    setFilters(EMPTY_SCOPE);
    setPage(1);
  }

  function handleBindingChanged(updated: KBChunk) {
    setChunks((prev) =>
      prev.map((item) => (item.chunk_id === updated.chunk_id ? updated : item))
    );
    setSelected(updated);
  }

  function handleScopeDeleted() {
    setSelected(null);
    if (mode === "browse") void loadChunks(page);
  }

  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <PageContainer>
      <div className="flex flex-col gap-6 pb-12 pt-4">
        <header className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" aria-hidden="true" />
            <h1 className="text-2xl font-semibold tracking-tight">Knowledge base</h1>
          </div>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Every chunk written by a <code>kb_ingest</code> node lands here.
            Browse by scope or concept, search semantically, and promote
            binding states from suggested to approved.
          </p>
        </header>

        <KBGovernanceBanner />

        <KBSchemeIOControls />

        <form
          onSubmit={(event) => {
            event.preventDefault();
            void runSearch(searchDraft);
          }}
          className="flex flex-col gap-3 sm:flex-row sm:items-center"
        >
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={searchDraft}
              onChange={(e) => setSearchDraft(e.target.value)}
              placeholder="Semantic search (press Enter)…"
              aria-label="Search the knowledge base"
              className="pl-9"
            />
          </div>
          <Button type="submit" disabled={!searchDraft.trim() || loading}>
            Search
          </Button>
          {mode === "search" && (
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setMode("browse");
                setSearchQuery("");
                setSearchDraft("");
                setPage(1);
              }}
            >
              Back to browse
            </Button>
          )}
        </form>

        <section
          aria-label="Filters"
          className="flex flex-col gap-3 rounded-md border bg-muted/10 p-3"
        >
          <div className="flex items-center gap-2 text-sm font-medium">
            <Filter className="h-4 w-4" aria-hidden="true" />
            Filters
            {hasFilter && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleClearFilters}
                className="ml-auto h-7 px-2 text-xs"
              >
                Clear
              </Button>
            )}
          </div>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            <FilterInput
              label="Agent id"
              value={filters.agent_id}
              onChange={(value) =>
                setFilters((prev) => ({ ...prev, agent_id: value }))
              }
            />
            <FilterInput
              label="Workflow id"
              value={filters.workflow_id}
              onChange={(value) =>
                setFilters((prev) => ({ ...prev, workflow_id: value }))
              }
            />
            <FilterInput
              label="Run id"
              value={filters.run_id}
              onChange={(value) =>
                setFilters((prev) => ({ ...prev, run_id: value }))
              }
            />
            <FilterInput
              label="Concept"
              placeholder="pygubernator:Person"
              value={filters.concept}
              onChange={(value) =>
                setFilters((prev) => ({ ...prev, concept: value }))
              }
            />
            <FilterInput
              label="Contract id"
              value={filters.contract_id}
              onChange={(value) =>
                setFilters((prev) => ({ ...prev, contract_id: value }))
              }
            />
            <FilterSelect
              label="Binding state"
              value={filters.binding_state}
              onChange={(value) =>
                setFilters((prev) => ({
                  ...prev,
                  binding_state: value as ScopeFilter["binding_state"]
                }))
              }
            />
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              {mode === "search" ? (
                <>
                  {total} hit{total === 1 ? "" : "s"} for{" "}
                  <Badge variant="outline" className="font-normal">
                    {searchQuery}
                  </Badge>
                </>
              ) : (
                `${total.toLocaleString()} chunk${total === 1 ? "" : "s"}`
              )}
            </p>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() =>
                mode === "browse" ? void loadChunks(page) : void runSearch(searchQuery)
              }
              disabled={loading}
              className="gap-1.5 text-xs"
            >
              <RefreshCw
                className={loading ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"}
                aria-hidden="true"
              />
              Refresh
            </Button>
          </div>
          {error && (
            <div
              role="alert"
              className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"
            >
              {error}
            </div>
          )}
          {chunks.length === 0 && !loading ? (
            <EmptyState mode={mode} hasFilter={hasFilter} />
          ) : (
            <div className="flex flex-col gap-3">
              {chunks.map((chunk) => (
                <KBChunkCard
                  key={chunk.chunk_id}
                  chunk={chunk}
                  showScore={mode === "search"}
                  selected={selected?.chunk_id === chunk.chunk_id}
                  onSelect={setSelected}
                />
              ))}
            </div>
          )}
          {mode === "browse" && total > PAGE_SIZE && (
            <Pagination
              page={page}
              pageCount={pageCount}
              onChange={setPage}
              disabled={loading}
            />
          )}
        </section>
      </div>
      <KBChunkDrawer
        chunk={selected}
        onClose={() => setSelected(null)}
        onBindingChanged={handleBindingChanged}
        onScopeDeleted={handleScopeDeleted}
      />
    </PageContainer>
  );
}

interface FilterInputProps {
  label: string;
  value: string;
  placeholder?: string;
  onChange: (value: string) => void;
}

function FilterInput({ label, value, placeholder, onChange }: FilterInputProps) {
  return (
    <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
      {label}
      <Input
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="h-8"
      />
    </label>
  );
}

interface FilterSelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
}

function FilterSelect({ label, value, onChange }: FilterSelectProps) {
  return (
    <label className="flex flex-col gap-1 text-xs font-medium text-muted-foreground">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-8 rounded-md border border-input bg-background px-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
      >
        <option value="">Any</option>
        <option value="unmapped">Unmapped</option>
        <option value="suggested">Suggested</option>
        <option value="mapped">Mapped</option>
        <option value="approved">Approved</option>
      </select>
    </label>
  );
}

interface EmptyStateProps {
  mode: Mode;
  hasFilter: boolean;
}

function EmptyState({ mode, hasFilter }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed bg-muted/20 p-10 text-center">
      <Badge variant="outline" className="font-normal">
        No chunks
      </Badge>
      <p className="text-sm text-muted-foreground">
        {mode === "search"
          ? "No chunks matched your query."
          : hasFilter
            ? "No chunks match these filters."
            : "Run a workflow containing a kb_ingest node to populate this page."}
      </p>
    </div>
  );
}

interface PaginationProps {
  page: number;
  pageCount: number;
  onChange: (page: number) => void;
  disabled?: boolean;
}

function Pagination({ page, pageCount, onChange, disabled }: PaginationProps) {
  return (
    <div className="flex items-center justify-center gap-2 pt-2 text-xs">
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => onChange(Math.max(1, page - 1))}
        disabled={disabled || page <= 1}
      >
        Previous
      </Button>
      <span>
        Page {page} of {pageCount}
      </span>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => onChange(Math.min(pageCount, page + 1))}
        disabled={disabled || page >= pageCount}
      >
        Next
      </Button>
    </div>
  );
}
