import { Suspense } from "react";

import { PageLoading } from "@/components/LoadingSpinner";
import GuidePageInner from "./GuidePageInner";

export default function GuidePage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <GuidePageInner />
    </Suspense>
  );
}
