import { Suspense } from "react";

import { PageLoading } from "@/components/LoadingSpinner";
import KnowledgeNotebooksPage from "./KnowledgeNotebooksPage";

export default function NotebooksRoute() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <KnowledgeNotebooksPage />
    </Suspense>
  );
}
