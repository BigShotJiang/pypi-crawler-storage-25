import { Suspense } from "react";

import WorkflowEditorInner from "./WorkflowEditorInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function WorkflowEditorPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading editor..." />}>
      <WorkflowEditorInner />
    </Suspense>
  );
}
