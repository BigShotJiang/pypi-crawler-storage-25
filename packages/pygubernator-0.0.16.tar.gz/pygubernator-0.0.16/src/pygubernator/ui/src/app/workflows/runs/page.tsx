import { redirect } from "next/navigation";

import { ROUTES } from "@/lib/constants";

/**
 * Redirect legacy /workflows/runs/ to the consolidated /runs/ page.
 * Preserves query params (run_id, workflow_id) so deep links keep working.
 */
export default function WorkflowRunsPage({
  searchParams,
}: {
  searchParams: Record<string, string | string[] | undefined>;
}) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(searchParams)) {
    if (typeof value === "string") {
      params.set(key, value);
    }
  }
  const qs = params.toString();
  redirect(`${ROUTES.RUNS}${qs ? `?${qs}` : ""}`);
}
