"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

import { apiGet, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";

type Job = {
  id: string;
  current_state: string;
  name: string;
  created_by: string;
  created_at: string;
  last_workflow_run_id?: string | null;
  last_error_message?: string | null;
};

export default function LibraryTestingPageInner() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [name, setName] = useState("");
  const [repoPath, setRepoPath] = useState("");
  const [requirements, setRequirements] = useState("");

  async function refresh() {
    const data = await apiGet<{ items: Job[] }>("/api/v1/library-testing/jobs");
    setJobs(data.items);
  }

  useEffect(() => {
    void refresh().catch((e) => setError(e instanceof Error ? e.message : "Failed to load jobs"));
  }, []);

  const requirementsList = useMemo(() => {
    const parts = requirements
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    return parts;
  }, [requirements]);

  async function createJob() {
    setBusy(true);
    setError(null);
    try {
      await apiPost<
        { name: string; spec_json: Record<string, unknown> },
        Job
      >("/api/v1/library-testing/jobs", {
        name,
        spec_json: {
          repo_path: repoPath,
          requirements: requirementsList,
          pytest_args: ["-q"]
        }
      });
      setName("");
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to create job");
    } finally {
      setBusy(false);
    }
  }

  async function runJob(jobId: string) {
    setBusy(true);
    setError(null);
    try {
      await apiPost<object, { ok: boolean; workflow_run_id: string }>(
        `/api/v1/library-testing/jobs/${jobId}/run`,
        {}
      );
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to start run");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex items-baseline justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Library testing</h1>
          <p className="text-sm text-muted-foreground">
            Create and run isolated library/module test jobs (Phase 1).
          </p>
        </div>
        <button
          className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
          onClick={() => void refresh()}
          disabled={busy}
        >
          Refresh
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-md border border-destructive/30 bg-destructive/10 text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-lg border border-border p-4">
          <div className="font-medium mb-3">New job</div>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground">Name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border border-border bg-background"
                placeholder="e.g. pandas-compat-check"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Repo path (local)</label>
              <input
                value={repoPath}
                onChange={(e) => setRepoPath(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border border-border bg-background"
                placeholder="/path/to/repo"
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Requirements (one per line)</label>
              <textarea
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border border-border bg-background min-h-[120px]"
                placeholder={"pytest\npandas==2.2.3"}
              />
            </div>
            <button
              className="px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50"
              onClick={() => void createJob()}
              disabled={busy || !repoPath}
            >
              Create job
            </button>
          </div>
        </div>

        <div className="rounded-lg border border-border p-4">
          <div className="font-medium mb-3">Jobs</div>
          {jobs.length === 0 ? (
            <div className="text-sm text-muted-foreground">No jobs yet.</div>
          ) : (
            <div className="space-y-3">
              {jobs.map((j) => (
                <div key={j.id} className="rounded-md border border-border p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-medium">{j.name || j.id.slice(0, 8)}</div>
                      <div className="text-xs mt-1">
                        <Link
                          className="underline"
                          href={`${ROUTES.LIBRARY_TESTING}job/?jobId=${encodeURIComponent(j.id)}`}
                        >
                          View details
                        </Link>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        state: <span className="font-mono">{j.current_state}</span> • created_by:{" "}
                        {j.created_by}
                      </div>
                      {j.last_error_message && (
                        <div className="text-xs text-destructive mt-1">{j.last_error_message}</div>
                      )}
                      {j.last_workflow_run_id && (
                        <div className="text-xs mt-1">
                          last_run:{" "}
                          <Link
                            className="underline"
                            href={`/runs/?id=${encodeURIComponent(j.last_workflow_run_id)}`}
                          >
                            {j.last_workflow_run_id.slice(0, 8)}
                          </Link>
                        </div>
                      )}
                    </div>
                    <button
                      className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                      onClick={() => void runJob(j.id)}
                      disabled={busy}
                    >
                      Run
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
