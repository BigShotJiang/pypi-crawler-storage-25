import { Suspense } from "react";

import AgentsWorkspaceRedirect from "./AgentsWorkspaceRedirect";
import { PageLoading } from "@/components/LoadingSpinner";

export default function AgentsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <AgentsWorkspaceRedirect />
    </Suspense>
  );
}
