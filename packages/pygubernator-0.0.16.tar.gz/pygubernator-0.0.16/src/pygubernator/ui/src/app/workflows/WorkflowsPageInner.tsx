"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Plus, RefreshCw, Play, Pencil, Trash2 } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Pagination } from "@/components/common/Pagination";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading, TableSkeleton } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import { useToast } from "@/components/ui/toaster";
import { WorkflowRunStatusBanner } from "@/components/workflows/WorkflowRunStatusBanner";
import { usePolling } from "@/hooks/usePolling";
import { useWorkflowSSE } from "@/hooks/useWorkflowSSE";
import type { SSEEvent } from "@/hooks/useWorkflowSSE";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

interface WorkflowItem {
  id: string;
  name: string;
  description: string;
  owner: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface VersionRow {
  id: string;
  workflow_id: string;
  version: string;
  spec_json: Record<string, unknown>;
  active: boolean;
  created_at: string;
  created_by: string;
}

interface WorkflowRunDetail {
  run: {
    id: string;
    workflow_id: string;
    status: string;
    duration_ms: number | null;
    started_at: string | null;
    completed_at: string | null;
  };
  steps: Array<{ node_id: string; status: string }>;
}

export default function WorkflowsPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const id = searchParams.get("id");
  const qParam = searchParams.get("q") ?? "";

  const [searchDraft, setSearchDraft] = useState(qParam);
  const [page, setPage] = useState(1);
  const [list, setList] = useState<{ items: WorkflowItem[]; meta: { total: number; page: number; page_size: number } } | null>(null);
  const [detail, setDetail] = useState<{ workflow: WorkflowItem; versions: VersionRow[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const [newWfName, setNewWfName] = useState("");
  const [newWfDesc, setNewWfDesc] = useState("");
  const [newWfOwner, setNewWfOwner] = useState("system");

  const [editStatus, setEditStatus] = useState("");
  const [editDesc, setEditDesc] = useState("");

  const [newVersion, setNewVersion] = useState("");
  const [newSpec, setNewSpec] = useState("{}");

  const [confirmDelete, setConfirmDelete] = useState(false);

  const [trackedRunId, setTrackedRunId] = useState<string | null>(null);
  const [runDetail, setRunDetail] = useState<WorkflowRunDetail | null>(null);
  const [stopBusy, setStopBusy] = useState(false);

  useEffect(() => { setSearchDraft(qParam); }, [qParam, id]);

  const activeRunStorageKey = id ? `pygubernator-wf-active-run-${id}` : null;

  useEffect(() => {
    setTrackedRunId(null);
    setRunDetail(null);
  }, [id]);

  useEffect(() => {
    if (!id || typeof window === "undefined") return;
    const k = `pygubernator-wf-active-run-${id}`;
    const saved = sessionStorage.getItem(k);
    if (saved) setTrackedRunId(saved);
  }, [id]);

  const fetchRunDetail = useCallback(
    async (rid: string) => {
      try {
        const data = await apiGet<WorkflowRunDetail>(`/api/v1/workflows/runs/${rid}`);
        if (id && data.run.workflow_id !== id) {
          setRunDetail(null);
          setTrackedRunId(null);
          return;
        }
        setRunDetail(data);
      } catch {
        setRunDetail(null);
        setTrackedRunId(null);
        if (id && typeof window !== "undefined") {
          sessionStorage.removeItem(`pygubernator-wf-active-run-${id}`);
        }
      }
    },
    [id],
  );

  useEffect(() => {
    if (!trackedRunId) {
      setRunDetail(null);
      return;
    }
    void fetchRunDetail(trackedRunId);
  }, [trackedRunId, fetchRunDetail]);

  const runStatus = runDetail?.run.status;
  const isRunPolling =
    !!trackedRunId &&
    (runStatus === "running" || runStatus === "pending");

  usePolling(
    () => (trackedRunId ? fetchRunDetail(trackedRunId) : Promise.resolve()),
    2500,
    isRunPolling,
  );

  const handleWorkflowSSE = useCallback(
    (event: SSEEvent) => {
      if (
        event.type === "workflow_completed" ||
        event.type === "done" ||
        event.type === "node_started" ||
        event.type === "node_completed" ||
        event.type === "node_failed"
      ) {
        if (trackedRunId) void fetchRunDetail(trackedRunId);
      }
    },
    [trackedRunId, fetchRunDetail],
  );

  useWorkflowSSE(trackedRunId, handleWorkflowSSE);

  useEffect(() => {
    if (!activeRunStorageKey || !runDetail) return;
    const st = runDetail.run.status;
    if (["completed", "failed", "cancelled"].includes(st)) {
      sessionStorage.removeItem(activeRunStorageKey);
    }
  }, [activeRunStorageKey, runDetail]);

  const loadList = useCallback(async (p: number = page) => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiGet<{ items: WorkflowItem[]; meta: { total: number; page: number; page_size: number } }>(
        "/api/v1/workflows", { page: p, page_size: 25, q: qParam.trim() || undefined }
      );
      setList(data);
      setDetail(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [qParam, page]);

  const loadDetail = useCallback(async (wfId: string) => {
    setLoading(true);
    setError(null);
    try {
      const [wf, versions] = await Promise.all([
        apiGet<WorkflowItem>(`/api/v1/workflows/${wfId}`),
        apiGet<{ items: VersionRow[] }>(`/api/v1/workflows/${wfId}/versions`),
      ]);
      setDetail({ workflow: wf, versions: versions.items });
      setList(null);
      setEditStatus(wf.status);
      setEditDesc(wf.description);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (id) loadDetail(id);
    else loadList(page);
  }, [id, loadDetail, loadList, page]);

  const refresh = () => { if (id) loadDetail(id); else loadList(page); };

  const handlePageChange = (p: number) => {
    setPage(p);
    loadList(p);
  };

  const applySearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    const q = searchDraft.trim();
    router.push(q ? `${ROUTES.WORKFLOWS}?q=${encodeURIComponent(q)}` : ROUTES.WORKFLOWS);
  };

  const createWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWfName.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const created = await apiPost<
        { name: string; description: string; owner: string },
        WorkflowItem
      >("/api/v1/workflows", {
        name: newWfName.trim(),
        description: newWfDesc.trim(),
        owner: newWfOwner.trim() || "system",
      });
      setNewWfName("");
      setNewWfDesc("");
      toast(`Created workflow "${created.name}".`, "success");
      router.push(`${ROUTES.WORKFLOWS}?id=${encodeURIComponent(created.id)}`);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const saveWorkflowMeta = async () => {
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPatch<
        { status: string; description: string },
        WorkflowItem
      >(`/api/v1/workflows/${id}`, { status: editStatus, description: editDesc });
      setDetail((d) => d ? { ...d, workflow: updated } : null);
      toast("Workflow updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const deleteWorkflow = async () => {
    if (!id) return;
    setConfirmDelete(false);
    setBusy(true);
    setError(null);
    try {
      await apiDelete<WorkflowItem>(`/api/v1/workflows/${id}`);
      toast("Workflow deleted.", "success");
      router.push(ROUTES.WORKFLOWS);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const activateVersion = async (versionId: string) => {
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      await apiPost<Record<string, never>, WorkflowItem>(
        `/api/v1/workflows/${id}/versions/${versionId}/activate`
      );
      setDetail((d) =>
        d ? { ...d, versions: d.versions.map((v) => ({ ...v, active: v.id === versionId })) } : null
      );
      toast("Active version updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const submitNewVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !newVersion.trim()) return;
    setBusy(true);
    setError(null);
    try {
      let specJson: Record<string, unknown> = {};
      try { specJson = JSON.parse(newSpec); } catch { /* keep empty */ }
      const v = await apiPost<
        { version: string; spec_json: Record<string, unknown> },
        VersionRow
      >(`/api/v1/workflows/${id}/versions`, {
        version: newVersion.trim(),
        spec_json: specJson,
      });
      setDetail((d) => d ? { ...d, versions: [v, ...d.versions] } : null);
      setNewVersion("");
      setNewSpec("{}");
      toast(`Version ${v.version} created.`, "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const dismissRunBanner = () => {
    setTrackedRunId(null);
    setRunDetail(null);
    if (activeRunStorageKey && typeof window !== "undefined") {
      sessionStorage.removeItem(activeRunStorageKey);
    }
  };

  const cancelTrackedRun = async () => {
    if (!trackedRunId) return;
    setStopBusy(true);
    try {
      await apiPost<Record<string, never>, { message?: string }>(
        `/api/v1/workflows/runs/${trackedRunId}/cancel`,
        {},
      );
      toast("Stop requested — run ends after the current DAG level.", "success");
      void fetchRunDetail(trackedRunId);
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      toast(err.message, "error");
    } finally {
      setStopBusy(false);
    }
  };

  const executeWorkflow = async () => {
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      const res = await apiPost<
        { input_json: Record<string, unknown> },
        { run: { id: string; status: string } }
      >(`/api/v1/workflows/${id}/execute`, { input_json: {} });
      const rid = res.run.id;
      setTrackedRunId(rid);
      if (typeof window !== "undefined") {
        sessionStorage.setItem(`pygubernator-wf-active-run-${id}`, rid);
      }
      void fetchRunDetail(rid);
      toast(`Run ${rid.slice(0, 8)}… started`, "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  if (loading && !list && !detail) {
    return <PageContainer><PageLoading message="Loading workflows..." /></PageContainer>;
  }

  if (id && detail) {
    const { workflow, versions } = detail;
    return (
      <PageContainer>
        <PageHeader
          title={workflow.name}
          description={`Owner ${workflow.owner} · ${workflow.status}`}
          actions={
            <>
              <Button variant="outline" size="sm" onClick={refresh} disabled={loading || busy}>
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Button variant="secondary" size="sm" onClick={() => void executeWorkflow()} disabled={busy || versions.length === 0}>
                <Play className="h-4 w-4 mr-1" /> Execute
              </Button>
              <Link
                href={`${ROUTES.WORKFLOW_EDITOR}?id=${encodeURIComponent(workflow.id)}`}
                className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
              >
                <Pencil className="h-4 w-4 mr-1" /> Editor
              </Link>
              <Link
                href={`${ROUTES.WORKFLOW_RUNS}?workflow_id=${encodeURIComponent(workflow.id)}`}
                className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
              >
                View runs
              </Link>
              <Button variant="destructive" size="sm" onClick={() => setConfirmDelete(true)} disabled={busy}>
                <Trash2 className="h-4 w-4 mr-1" /> Delete
              </Button>
              <Link href={ROUTES.WORKFLOWS} className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}>
                Back to list
              </Link>
            </>
          }
        />
        {error && <ErrorDisplay error={error} className="mb-4" />}

        {trackedRunId &&
          runDetail &&
          runDetail.run.workflow_id === workflow.id &&
          runDetail.run.id === trackedRunId && (
            <WorkflowRunStatusBanner
              workflowId={workflow.id}
              run={runDetail.run}
              steps={runDetail.steps}
              onStop={cancelTrackedRun}
              onDismiss={dismissRunBanner}
              stopBusy={stopBusy}
            />
          )}

        <ConfirmDialog
          open={confirmDelete}
          title="Delete workflow"
          description={`Are you sure you want to delete "${workflow.name}"? This will soft-delete the workflow.`}
          confirmLabel="Delete"
          variant="destructive"
          onConfirm={() => void deleteWorkflow()}
          onCancel={() => setConfirmDelete(false)}
        />

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Workflow settings</CardTitle>
              <CardDescription>Status and description</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Status</label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                >
                  <option value="active">active</option>
                  <option value="paused">paused</option>
                  <option value="archived">archived</option>
                </select>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Description</label>
                <Input value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
              </div>
              <Button size="sm" onClick={() => void saveWorkflowMeta()} disabled={busy}>
                Save changes
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">New version</CardTitle>
              <CardDescription>Upload a new workflow spec</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-3 text-sm" onSubmit={(e) => void submitNewVersion(e)}>
                <Input
                  placeholder="Version label (e.g. 1.0.0)"
                  value={newVersion}
                  onChange={(e) => setNewVersion(e.target.value)}
                  required
                />
                <textarea
                  className="flex min-h-[88px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 font-mono"
                  placeholder="Spec JSON"
                  value={newSpec}
                  onChange={(e) => setNewSpec(e.target.value)}
                />
                <Button type="submit" size="sm" disabled={busy}>
                  <Plus className="h-4 w-4 mr-1" /> Create version
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Versions</CardTitle>
            <CardDescription>Manage workflow versions</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Version</TableHead>
                  <TableHead>Created by</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {versions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-muted-foreground">
                      No versions yet. Add one above.
                    </TableCell>
                  </TableRow>
                ) : (
                  versions.map((v) => (
                    <TableRow key={v.id}>
                      <TableCell className="font-medium">
                        {v.version}
                        {v.active && <span className="ml-2 text-xs text-primary font-normal">active</span>}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">{v.created_by}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{formatDateTimeShort(v.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={busy || v.active}
                          onClick={() => void activateVersion(v.id)}
                        >
                          Set active
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <p className="mt-4 text-xs text-muted-foreground">
          ID <span className="font-mono">{workflow.id}</span> · Created {formatDateTimeShort(workflow.created_at)} · Updated {formatDateTimeShort(workflow.updated_at)}
        </p>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Workflows"
        description={list ? `${list.meta.total} workflow(s) registered` : "DAG workflow orchestration"}
        actions={
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        }
      />
      {error && <ErrorDisplay error={error} className="mb-4" />}

      <div className="grid gap-4 lg:grid-cols-2 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Search</CardTitle>
            <CardDescription>Filter by name or owner</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="flex flex-wrap gap-2" onSubmit={applySearch}>
              <Input
                className="max-w-md flex-1 min-w-[12rem]"
                placeholder="Name or owner..."
                value={searchDraft}
                onChange={(e) => setSearchDraft(e.target.value)}
              />
              <Button type="submit" variant="secondary" size="sm">Search</Button>
              {qParam && (
                <Button type="button" variant="ghost" size="sm" onClick={() => router.push(ROUTES.WORKFLOWS)}>
                  Clear
                </Button>
              )}
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">New workflow</CardTitle>
            <CardDescription>Create a workflow definition</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-3" onSubmit={(e) => void createWorkflow(e)}>
              <Input placeholder="Unique name" value={newWfName} onChange={(e) => setNewWfName(e.target.value)} required />
              <Input placeholder="Description (optional)" value={newWfDesc} onChange={(e) => setNewWfDesc(e.target.value)} />
              <Input placeholder="Owner (default: system)" value={newWfOwner} onChange={(e) => setNewWfOwner(e.target.value)} />
              <Button type="submit" size="sm" disabled={busy}>
                <Plus className="h-4 w-4 mr-1" /> Create workflow
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {loading && list ? <TableSkeleton rows={6} /> : null}
      {!loading && list && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.items.map((wf) => (
                <TableRow key={wf.id}>
                  <TableCell>
                    <Link
                      href={`${ROUTES.WORKFLOWS}?id=${encodeURIComponent(wf.id)}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {wf.name}
                    </Link>
                  </TableCell>
                  <TableCell className="text-muted-foreground">{wf.owner}</TableCell>
                  <TableCell>{wf.status}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{formatDateTimeShort(wf.updated_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <Pagination
            page={list.meta.page ?? page}
            pageSize={list.meta.page_size ?? 25}
            total={list.meta.total}
            onPageChange={handlePageChange}
          />
        </>
      )}
    </PageContainer>
  );
}
