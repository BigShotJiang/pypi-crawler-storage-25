"use client";

import { useState } from "react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import {
  ApiServerCard,
  CredentialsCard,
  DatabaseConfigCard,
  LocalOllamaModelsCard,
  ServerBindCard,
  ServerRuntimeOverview,
} from "@/components/settings";
import { Button } from "@/components/ui/button";
import {
  getSettings,
  saveSettings,
  type AppSettings,
} from "@/lib/settings";
import { Loader2 } from "lucide-react";
import {
  useAppConfigStore,
  selectAppName,
  selectVersion,
} from "@/stores/app-config";

export default function SettingsPage() {
  const appName = useAppConfigStore(selectAppName);
  const version = useAppConfigStore(selectVersion);
  const [settings, setSettings] = useState<AppSettings>(getSettings());
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const handleSave = () => {
    setSaving(true);
    setMessage(null);
    try {
      saveSettings(settings);
      setMessage({
        type: "success",
        text: "Settings saved. Reload if the API URL should apply everywhere.",
      });
      setTimeout(() => window.location.reload(), 800);
    } catch (e) {
      setMessage({ type: "error", text: String(e) });
    } finally {
      setSaving(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader
        title="Settings"
        description={
          version
            ? `Configure ${appName} API URL, server bind info, and database tools (${version}).`
            : `Configure ${appName} API URL, server bind info, and database tools.`
        }
      />

      {message && (
        <div
          role="status"
          className={`mt-4 rounded-md border px-3 py-2 text-sm ${
            message.type === "success"
              ? "border-green-200 bg-green-50 text-green-800"
              : "border-red-200 bg-red-50 text-red-800"
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="mt-8 space-y-6">
        <ServerRuntimeOverview />

        <LocalOllamaModelsCard />

        <ApiServerCard
          url={settings.apiServer.url}
          onUrlChange={(url) =>
            setSettings((s) => ({
              ...s,
              apiServer: { ...s.apiServer, url },
            }))
          }
        />
        <ServerBindCard />
        <DatabaseConfigCard
          enabled={settings.database.enabled}
          connectionString={settings.database.connectionString ?? ""}
          host={settings.database.host ?? ""}
          port={
            settings.database.port != null ? String(settings.database.port) : ""
          }
          database={settings.database.database ?? ""}
          username={settings.database.username ?? ""}
          password={settings.database.password ?? ""}
          onEnabledChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, enabled: v },
            }))
          }
          onConnectionStringChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, connectionString: v },
            }))
          }
          onHostChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, host: v },
            }))
          }
          onPortChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: {
                ...s.database,
                port: v ? parseInt(v, 10) : undefined,
              },
            }))
          }
          onDatabaseChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, database: v },
            }))
          }
          onUsernameChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, username: v },
            }))
          }
          onPasswordChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, password: v },
            }))
          }
        />
        <CredentialsCard />
      </div>

      <div className="flex justify-end mt-6">
        <Button onClick={handleSave} disabled={saving} size="lg">
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save settings"
          )}
        </Button>
      </div>
    </PageContainer>
  );
}
