"use client";

/**
 * Guide page — chat-style workflow dispatcher (Phase 6 §6.7c).
 *
 * Left pane: a conversational thread. The user types a goal, picks the
 * workflow that best matches, and the page dispatches a run tagged
 * ``trigger="guide"`` + ``correlation_id=<sessionId>``. Each dispatch
 * appends a system "run started" line to the thread; live status
 * updates polled from the runs route swap the line in place when the
 * run completes.
 *
 * Right pane: the runs panel. Lists every run spawned in this chat
 * (via the ``correlation_id`` filter shipped in §6.7b) and embeds the
 * existing ``ArtifactList`` for the currently-selected run so users
 * see workflow outputs without leaving the page.
 *
 * The page supports two routing modes (Phase 6 §6.7d):
 *
 * - **Auto** — the user's message is sent to ``POST /api/v1/guide/plan``,
 *   which asks the configured LLM to pick a workflow. On a
 *   ``"dispatch"`` decision the page runs that workflow with the
 *   planner-suggested args; on ``"reply"`` it appends the LLM's
 *   message to the thread without dispatching; on ``"unresolved"``
 *   it surfaces a clarifying note and falls back to the manual picker.
 * - **Manual** — the user picks a workflow from the dropdown and the
 *   chat message is forwarded as ``args.message``. This is the
 *   dependency-free path that worked before §6.7d, kept for users
 *   without a planner LLM configured server-side.
 */

import { useCallback, useEffect, useState } from "react";
import { Bot, Plus, Send, User } from "lucide-react";

import { ArtifactList } from "@/components/artifacts/ArtifactList";
import { GuideRunCard } from "@/components/guide/GuideRunCard";
import { PageContainer } from "@/components/layout/PageContainer";
import { ResizableSplitPane } from "@/components/layout/ResizableSplitPane";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PageHeader } from "@/components/common/PageHeader";
import {
  ApiError,
  dispatchGuideRun,
  listGuideRuns,
  listGuideWorkflows,
  planGuideMessage,
} from "@/lib/api";
import type { GuideRunSummary, GuideWorkflowSummary } from "@/lib/api";
import {
  clearStoredGuideSessionId,
  ensureGuideSessionId,
  newGuideSessionId,
  writeStoredGuideSessionId,
} from "@/lib/guide-session";

interface ThreadMessage {
  id: string;
  /** ``"user"`` for the typed prompt, ``"system"`` for "run started" lines. */
  role: "user" | "system";
  text: string;
  /** When set, this thread entry references one dispatched run. */
  runId?: string;
  timestamp: number;
}

const POLL_MS = 4000;

type RoutingMode = "auto" | "manual";

export default function GuidePageInner() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [workflows, setWorkflows] = useState<GuideWorkflowSummary[]>([]);
  const [workflowsLoading, setWorkflowsLoading] = useState(true);
  const [selectedWorkflowId, setSelectedWorkflowId] = useState<string>("");
  const [messages, setMessages] = useState<ThreadMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [runs, setRuns] = useState<GuideRunSummary[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [routingMode, setRoutingMode] = useState<RoutingMode>("manual");

  // Mint / restore the chat session id once on mount.
  useEffect(() => {
    setSessionId(ensureGuideSessionId());
  }, []);

  // Load workflows for the picker.
  useEffect(() => {
    let cancelled = false;
    setWorkflowsLoading(true);
    void (async () => {
      try {
        const items = await listGuideWorkflows();
        if (!cancelled) {
          setWorkflows(items);
          if (items.length > 0 && !selectedWorkflowId) {
            setSelectedWorkflowId(items[0].id);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof ApiError ? err.message : "Could not load workflows",
          );
        }
      } finally {
        if (!cancelled) setWorkflowsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // selectedWorkflowId intentionally omitted — initial seeding only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refreshRuns = useCallback(async () => {
    if (!sessionId) return;
    try {
      const items = await listGuideRuns(sessionId);
      setRuns(items);
      // Keep the selection live: if the user hasn't picked one or the
      // selected run was deleted, fall through to the most recent.
      setSelectedRunId((prev) => {
        if (prev && items.some((r) => r.id === prev)) return prev;
        return items.length > 0 ? items[0].id : null;
      });
    } catch (err) {
      // Polling errors stay quiet — surfacing them every 4s would be
      // worse UX than letting a single retry recover. Dispatch errors
      // surface via the bigger error banner instead.
      if (err instanceof ApiError && err.status !== 404) {
        // eslint-disable-next-line no-console
        console.warn("guide run poll failed", err.message);
      }
    }
  }, [sessionId]);

  // Initial load + 4s poll for run updates.
  useEffect(() => {
    if (!sessionId) return;
    void refreshRuns();
    const id = window.setInterval(() => void refreshRuns(), POLL_MS);
    return () => window.clearInterval(id);
  }, [sessionId, refreshRuns]);

  const handleNewChat = useCallback(() => {
    clearStoredGuideSessionId();
    const fresh = newGuideSessionId();
    writeStoredGuideSessionId(fresh);
    setSessionId(fresh);
    setMessages([]);
    setRuns([]);
    setSelectedRunId(null);
    setError(null);
  }, []);

  const appendSystemMessage = useCallback(
    (text: string, runId?: string) => {
      setMessages((prev) => [
        ...prev,
        {
          id: `m-${Date.now()}-${prev.length}`,
          role: "system",
          text,
          runId,
          timestamp: Date.now(),
        },
      ]);
    },
    [],
  );

  const dispatchWorkflow = useCallback(
    async (workflowId: string, args: Record<string, unknown>) => {
      if (!sessionId) return;
      const workflow = workflows.find((w) => w.id === workflowId);
      const data = await dispatchGuideRun({
        workflow_id: workflowId,
        args,
        correlation_id: sessionId,
      });
      appendSystemMessage(
        `Started ${workflow?.name ?? "workflow"} (run ${data.run.id.slice(0, 8)}…)`,
        data.run.id,
      );
      setSelectedRunId(data.run.id);
      void refreshRuns();
    },
    [appendSystemMessage, refreshRuns, sessionId, workflows],
  );

  const handleDispatch = useCallback(async () => {
    if (!sessionId || !draft.trim()) return;
    if (routingMode === "manual" && !selectedWorkflowId) return;
    setBusy(true);
    setError(null);
    const promptText = draft.trim();
    setDraft("");
    setMessages((prev) => [
      ...prev,
      {
        id: `m-${Date.now()}`,
        role: "user",
        text: promptText,
        timestamp: Date.now(),
      },
    ]);
    try {
      if (routingMode === "auto") {
        // Auto mode — ask the server which workflow fits, then act on
        // the planner's decision. The catalog mirrors what the manual
        // dropdown shows so the LLM picks from the same set the user
        // sees.
        const decision = await planGuideMessage({
          user_message: promptText,
          catalog: workflows.map((w) => ({
            workflow_id: w.id,
            name: w.name,
            description: w.description ?? null,
          })),
        });
        if (decision.decision === "dispatch" && decision.workflow_id) {
          // ``message`` is the field most workflow input nodes look at;
          // we merge the planner-suggested args on top so the workflow
          // sees both the structured suggestion and the original
          // prompt as a fallback.
          const args: Record<string, unknown> = {
            message: promptText,
            ...(decision.args ?? {}),
          };
          await dispatchWorkflow(decision.workflow_id, args);
        } else if (decision.decision === "reply" && decision.reply) {
          appendSystemMessage(decision.reply);
        } else {
          appendSystemMessage(
            decision.reason ??
              "I couldn't pick a workflow for that — try the manual picker.",
          );
        }
      } else {
        // Manual mode — same UX as before §6.7d.
        await dispatchWorkflow(selectedWorkflowId, { message: promptText });
      }
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Could not dispatch run",
      );
    } finally {
      setBusy(false);
    }
  }, [
    appendSystemMessage,
    dispatchWorkflow,
    draft,
    routingMode,
    selectedWorkflowId,
    sessionId,
    workflows,
  ]);

  const leftPane = (
    <Card className="flex h-full min-h-0 flex-col">
      <CardHeader className="shrink-0">
        <div className="flex items-center justify-between gap-2">
          <div>
            <CardTitle className="text-lg">Guide</CardTitle>
            <CardDescription>
              Conversational workflow dispatcher. Type a goal, pick the
              workflow that fits, run it.
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNewChat}
            title="Start a fresh chat (mints a new session id)"
          >
            <Plus className="mr-1 h-3 w-3" />
            New chat
          </Button>
        </div>
        {sessionId ? (
          <p className="text-[10px] font-mono text-muted-foreground">
            session {sessionId.slice(0, 12)}…
          </p>
        ) : null}
      </CardHeader>
      <CardContent className="flex flex-1 min-h-0 flex-col gap-3">
        <div className="flex-1 min-h-0 overflow-y-auto rounded-md border bg-muted/10 p-3">
          {messages.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Start a conversation by describing what you want done.
            </p>
          ) : (
            <ol className="flex flex-col gap-2">
              {messages.map((msg) => (
                <li
                  key={msg.id}
                  className="flex items-start gap-2 text-sm"
                >
                  {msg.role === "user" ? (
                    <User className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  ) : (
                    <Bot className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                  <span
                    className={
                      msg.role === "user"
                        ? "font-medium"
                        : "italic text-muted-foreground"
                    }
                  >
                    {msg.text}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>

        {error ? (
          <p className="rounded-md border border-red-200 bg-red-50 px-2 py-1 text-xs text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
            {error}
          </p>
        ) : null}

        <div className="shrink-0 space-y-2 border-t pt-3">
          <fieldset
            className="flex items-center gap-2 text-xs"
            aria-label="Routing mode"
          >
            <legend className="sr-only">Routing mode</legend>
            <span className="font-medium text-muted-foreground">Routing:</span>
            <label className="flex items-center gap-1">
              <input
                type="radio"
                name="guide-routing-mode"
                value="manual"
                checked={routingMode === "manual"}
                onChange={() => setRoutingMode("manual")}
              />
              Manual picker
            </label>
            <label className="flex items-center gap-1">
              <input
                type="radio"
                name="guide-routing-mode"
                value="auto"
                checked={routingMode === "auto"}
                onChange={() => setRoutingMode("auto")}
              />
              Auto (LLM picks)
            </label>
          </fieldset>

          {routingMode === "manual" ? (
            <>
              <label
                htmlFor="guide-workflow-picker"
                className="text-xs font-medium text-muted-foreground"
              >
                Workflow
              </label>
              <select
                id="guide-workflow-picker"
                value={selectedWorkflowId}
                onChange={(e) => setSelectedWorkflowId(e.target.value)}
                disabled={workflowsLoading || workflows.length === 0}
                className="w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                {workflowsLoading ? (
                  <option>Loading…</option>
                ) : workflows.length === 0 ? (
                  <option>No workflows available — author one first.</option>
                ) : (
                  workflows.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name}
                    </option>
                  ))
                )}
              </select>
            </>
          ) : (
            <p className="text-[11px] text-muted-foreground">
              Auto mode asks the server-configured LLM which of your{" "}
              {workflows.length} workflow{workflows.length === 1 ? "" : "s"}{" "}
              fits the message; falls back to a chat reply when no workflow
              is a good match. Configure the planner model with{" "}
              <code>PYGUBERNATOR_GUIDE_PLANNER_MODEL</code>.
            </p>
          )}
          <div className="flex items-end gap-2">
            <Input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="What would you like to do?"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void handleDispatch();
                }
              }}
              disabled={busy || !sessionId}
              aria-label="Guide message"
            />
            <Button
              onClick={() => void handleDispatch()}
              disabled={
                busy ||
                !sessionId ||
                !draft.trim() ||
                (routingMode === "manual" && !selectedWorkflowId)
              }
              size="sm"
            >
              <Send className="mr-1 h-3 w-3" />
              {busy ? "Dispatching…" : "Send"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const rightPane = (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <Card className="shrink-0">
        <CardHeader>
          <CardTitle className="text-base">Runs in this chat</CardTitle>
          <CardDescription>
            {runs.length} dispatched · click to inspect artifacts below
          </CardDescription>
        </CardHeader>
        <CardContent>
          {runs.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Nothing dispatched yet. Send a message to start a run.
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {runs.map((run) => (
                <li key={run.id}>
                  <GuideRunCard
                    run={run}
                    isSelected={run.id === selectedRunId}
                    onSelect={() => setSelectedRunId(run.id)}
                  />
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card className="flex-1 min-h-0">
        <CardHeader>
          <CardTitle className="text-base">Run artifacts</CardTitle>
          <CardDescription>
            Outputs from the selected run.
          </CardDescription>
        </CardHeader>
        <CardContent className="h-full min-h-0 overflow-auto">
          {selectedRunId ? (
            <ArtifactList runId={selectedRunId} hideWhenEmpty={false} />
          ) : (
            <p className="text-xs text-muted-foreground">
              Select a run to see its artifacts.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );

  return (
    <PageContainer>
      <PageHeader
        title="Guide"
        description="Have a conversation with your workflows."
      />
      <ResizableSplitPane
        storageKey="pygubernator_guide_split"
        defaultLeftSize={55}
        minLeftSize={35}
        minRightSize={30}
        leftPane={leftPane}
        rightPane={rightPane}
      />
    </PageContainer>
  );
}
