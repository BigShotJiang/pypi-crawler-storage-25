import { Suspense } from "react";

import IncidentsPageInner from "./IncidentsPageInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function IncidentsPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <IncidentsPageInner />
    </Suspense>
  );
}
