import { Suspense } from "react";

import ObservabilityOverviewInner from "./ObservabilityOverviewInner";
import { PageLoading } from "@/components/LoadingSpinner";

export default function ObservabilityPage() {
  return (
    <Suspense fallback={<PageLoading message="Loading…" />}>
      <ObservabilityOverviewInner />
    </Suspense>
  );
}
