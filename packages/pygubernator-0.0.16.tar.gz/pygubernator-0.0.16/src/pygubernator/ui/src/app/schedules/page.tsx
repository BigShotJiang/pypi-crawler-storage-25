"use client";

import { useCallback, useEffect, useState } from "react";
import { Play, RefreshCw } from "lucide-react";

import { PageContainer } from "@/components/layout/PageContainer";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { apiGet, apiPost, apiPatch, apiDelete, ApiError } from "@/lib/api";
import { useToast } from "@/components/ui/toaster";
import { formatDateTimeShort } from "@/lib/utils";
import ScheduleBuilder from "@/components/schedules/ScheduleBuilder";
import RunHistoryChip from "@/components/schedules/RunHistoryChip";

/* ---------- Types ---------- */

interface ScheduledJob {
  id: string;
  workflow_id: string;
  name: string;
  description: string;
  cron_expression: string;
  timezone: string;
  input_json: Record<string, unknown>;
  enabled: boolean;
  concurrency_policy: string;
  misfire_policy: string;
  misfire_grace_seconds: number;
  last_run_at: string | null;
  next_run_at: string | null;
  last_status: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

interface WorkflowItem {
  id: string;
  name: string;
}

const CONCURRENCY_OPTIONS = [
  {
    value: "allow",
    label: "Allow overlap",
    description: "Fire scheduled runs even if a previous run is still active.",
  },
  {
    value: "skip",
    label: "Skip overlap",
    description: "Do not start a new run when the previous run is still active.",
  },
] as const;

const MISFIRE_OPTIONS = [
  {
    value: "fire_now",
    label: "Fire now",
    description: "Run late jobs immediately when the scheduler catches up.",
  },
  {
    value: "skip",
    label: "Skip",
    description: "Skip overdue runs after the grace window expires.",
  },
] as const;

/* ---------- Component ---------- */

export default function SchedulesPage() {
  const { toast } = useToast();
  const [jobs, setJobs] = useState<ScheduledJob[]>([]);
  const [workflows, setWorkflows] = useState<WorkflowItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formDescription, setFormDescription] = useState("");
  const [formWorkflowId, setFormWorkflowId] = useState("");
  const [formCron, setFormCron] = useState("");
  const [formTimezone, setFormTimezone] = useState("UTC");
  const [formInputJson, setFormInputJson] = useState("{}");
  const [formEnabled, setFormEnabled] = useState(true);
  const [formConcurrencyPolicy, setFormConcurrencyPolicy] =
    useState("allow");
  const [formMisfirePolicy, setFormMisfirePolicy] = useState("fire_now");
  const [formMisfireGraceSeconds, setFormMisfireGraceSeconds] =
    useState("60");
  const [saving, setSaving] = useState(false);

  const loadJobs = useCallback(async () => {
    try {
      const data = await apiGet<{ items: ScheduledJob[] }>(
        "/api/v1/admin/schedules"
      );
      setJobs(data.items);
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) {
        setError("Unable to connect to API.");
      } else {
        setError(e instanceof Error ? e.message : "Failed to load schedules.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const loadWorkflows = useCallback(async () => {
    try {
      const data = await apiGet<{ items: WorkflowItem[] }>(
        "/api/v1/workflows",
        { page_size: 100 }
      );
      setWorkflows(data.items);
    } catch {
      // Non-critical
    }
  }, []);

  useEffect(() => {
    Promise.all([loadJobs(), loadWorkflows()]);
  }, [loadJobs, loadWorkflows]);

  function resetForm() {
    setFormName("");
    setFormDescription("");
    setFormWorkflowId("");
    setFormCron("");
    setFormTimezone("UTC");
    setFormInputJson("{}");
    setFormEnabled(true);
    setFormConcurrencyPolicy("allow");
    setFormMisfirePolicy("fire_now");
    setFormMisfireGraceSeconds("60");
    setEditing(null);
  }

  function handleAdd() {
    resetForm();
    setEditing("new");
  }

  function handleEdit(job: ScheduledJob) {
    setFormName(job.name);
    setFormDescription(job.description);
    setFormWorkflowId(job.workflow_id);
    setFormCron(job.cron_expression);
    setFormTimezone(job.timezone);
    setFormInputJson(JSON.stringify(job.input_json, null, 2));
    setFormEnabled(job.enabled);
    setFormConcurrencyPolicy(job.concurrency_policy);
    setFormMisfirePolicy(job.misfire_policy);
    setFormMisfireGraceSeconds(String(job.misfire_grace_seconds));
    setEditing(job.id);
  }

  async function handleSave() {
    setError(null);
    setSaving(true);
    let parsedInput: Record<string, unknown> = {};
    let parsedGraceSeconds = 60;
    try {
      parsedInput = JSON.parse(formInputJson);
    } catch {
      setError("Invalid JSON in input field.");
      setSaving(false);
      return;
    }
    try {
      parsedGraceSeconds = Number.parseInt(formMisfireGraceSeconds, 10);
    } catch {
      setError("Misfire grace seconds must be a whole number.");
      setSaving(false);
      return;
    }
    if (Number.isNaN(parsedGraceSeconds) || parsedGraceSeconds < 0) {
      setError("Misfire grace seconds must be 0 or greater.");
      setSaving(false);
      return;
    }
    try {
      if (editing === "new") {
        await apiPost<object, ScheduledJob>(
          "/api/v1/admin/schedules",
          {
            workflow_id: formWorkflowId,
            name: formName,
            description: formDescription,
            cron: formCron,
            timezone: formTimezone,
            input_json: parsedInput,
            enabled: formEnabled,
            concurrency_policy: formConcurrencyPolicy,
            misfire_policy: formMisfirePolicy,
            misfire_grace_seconds: parsedGraceSeconds,
          }
        );
        toast("Schedule created", "success");
      } else {
        await apiPatch<object, ScheduledJob>(
          `/api/v1/admin/schedules/${editing}`,
          {
            name: formName,
            description: formDescription,
            cron: formCron,
            timezone: formTimezone,
            input_json: parsedInput,
            enabled: formEnabled,
            concurrency_policy: formConcurrencyPolicy,
            misfire_policy: formMisfirePolicy,
            misfire_grace_seconds: parsedGraceSeconds,
          }
        );
        toast("Schedule updated", "success");
      }
      await loadJobs();
      resetForm();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to save schedule.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    const confirmed = window.confirm("Delete this schedule?");
    if (!confirmed) return;
    try {
      await apiDelete(`/api/v1/admin/schedules/${id}`);
      toast("Schedule deleted", "success");
      await loadJobs();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to delete.", "error");
    }
  }

  async function handleToggle(job: ScheduledJob) {
    try {
      await apiPatch<object, ScheduledJob>(
        `/api/v1/admin/schedules/${job.id}`,
        { enabled: !job.enabled }
      );
      await loadJobs();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to toggle.", "error");
    }
  }

  async function handleTrigger(job: ScheduledJob) {
    try {
      const data = await apiPost<object, { ok: boolean; run_id: string }>(
        `/api/v1/admin/schedules/${job.id}/trigger`
      );
      toast(`Triggered! Run: ${data.run_id.slice(0, 8)}...`, "success");
      await loadJobs();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to trigger.", "error");
    }
  }

  const workflowName = (wfId: string) =>
    workflows.find((w) => w.id === wfId)?.name ?? wfId.slice(0, 12) + "...";

  return (
    <PageContainer>
      <PageHeader
        title="Schedules"
        description="Manage scheduled workflow triggers"
        actions={
          !editing ? (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => void loadJobs()}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-1 ${loading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button size="sm" onClick={handleAdd}>
                + Add Schedule
              </Button>
            </div>
          ) : undefined
        }
      />

      {error && (
        <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-800 mb-4">
          {error}
        </div>
      )}

      {editing && (
        <div className="rounded-lg border p-4 space-y-4 mb-6 bg-card">
          <h3 className="text-sm font-semibold">
            {editing === "new" ? "Add Schedule" : "Edit Schedule"}
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="sched-name" className="text-sm font-medium">Name</label>
              <Input id="sched-name" placeholder="My daily job" value={formName} onChange={(e) => setFormName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <label htmlFor="sched-timezone" className="text-sm font-medium">Timezone</label>
              <Input
                id="sched-timezone"
                placeholder="UTC"
                value={formTimezone}
                onChange={(e) => setFormTimezone(e.target.value)}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <label htmlFor="sched-description" className="text-sm font-medium">Description</label>
              <Input
                id="sched-description"
                placeholder="What this schedule is responsible for"
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="sched-workflow" className="text-sm font-medium">Workflow</label>
              <select
                id="sched-workflow"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={formWorkflowId} onChange={(e) => setFormWorkflowId(e.target.value)} disabled={editing !== "new"}
              >
                <option value="">Select workflow...</option>
                {workflows.map((wf) => (
                  <option key={wf.id} value={wf.id}>{wf.name}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="space-y-2">
            <span className="text-sm font-medium">Schedule</span>
            <ScheduleBuilder
              cron={formCron}
              timezone={formTimezone}
              onCronChange={setFormCron}
            />
            <p className="text-xs text-muted-foreground">
              Pick a friendly cadence above, or switch to <em>Advanced</em> for a raw cron
              expression. Times are evaluated in the configured IANA timezone.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label htmlFor="sched-concurrency" className="text-sm font-medium">Concurrency policy</label>
              <select
                id="sched-concurrency"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={formConcurrencyPolicy}
                onChange={(e) => setFormConcurrencyPolicy(e.target.value)}
              >
                {CONCURRENCY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <p className="text-xs text-muted-foreground">
                {CONCURRENCY_OPTIONS.find((option) => option.value === formConcurrencyPolicy)?.description}
              </p>
            </div>
            <div className="space-y-2">
              <label htmlFor="sched-misfire" className="text-sm font-medium">Misfire policy</label>
              <select
                id="sched-misfire"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={formMisfirePolicy}
                onChange={(e) => setFormMisfirePolicy(e.target.value)}
              >
                {MISFIRE_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <p className="text-xs text-muted-foreground">
                {MISFIRE_OPTIONS.find((option) => option.value === formMisfirePolicy)?.description}
              </p>
            </div>
            <div className="space-y-2">
              <label htmlFor="sched-grace" className="text-sm font-medium">Misfire grace seconds</label>
              <Input
                id="sched-grace"
                inputMode="numeric"
                value={formMisfireGraceSeconds}
                onChange={(e) => setFormMisfireGraceSeconds(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Controls how long an overdue schedule remains eligible before a skip policy drops it.
              </p>
            </div>
          </div>
          <div className="space-y-2">
            <label htmlFor="sched-input" className="text-sm font-medium">Input JSON</label>
            <textarea
              id="sched-input"
              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              value={formInputJson} onChange={(e) => setFormInputJson(e.target.value)}
            />
          </div>
          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <label htmlFor="sched-enabled" className="text-sm font-medium">Enabled</label>
              <p className="text-xs text-muted-foreground">
                Disable the schedule without deleting its configuration or history.
              </p>
            </div>
            <Switch
              id="sched-enabled"
              checked={formEnabled}
              onCheckedChange={setFormEnabled}
            />
          </div>
          <div className="flex gap-2 border-t pt-4">
            <Button variant="outline" onClick={resetForm} disabled={saving}>Cancel</Button>
            <Button onClick={() => void handleSave()} disabled={saving || !formCron || (editing === "new" && !formWorkflowId)}>
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      {loading && (
        <p className="text-sm text-muted-foreground">Loading schedules...</p>
      )}
      {!loading && !editing && jobs.length === 0 && (
        <p className="text-sm text-muted-foreground py-8 text-center">
          No scheduled jobs yet. Click &quot;Add Schedule&quot; to create one.
        </p>
      )}
      {!loading && jobs.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Workflow</TableHead>
              <TableHead>Cron</TableHead>
              <TableHead>Policy</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Last Status</TableHead>
              <TableHead>Last Run</TableHead>
              <TableHead>Next Run</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {jobs.map((job) => (
              <TableRow key={job.id}>
                <TableCell className="font-medium">
                  {job.name || job.id.slice(0, 8) + "..."}
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {workflowName(job.workflow_id)}
                </TableCell>
                <TableCell className="font-mono text-xs">
                  <div>{job.cron_expression}</div>
                  <div className="text-[11px] text-muted-foreground">
                    {job.timezone}
                  </div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  <div>{job.concurrency_policy}</div>
                  <div>
                    {job.misfire_policy}
                    {" · "}
                    grace {job.misfire_grace_seconds}s
                  </div>
                </TableCell>
                <TableCell>
                  {job.enabled ? (
                    <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-100">
                      Enabled
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Disabled</Badge>
                  )}
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {job.last_status || "—"}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  <div className="flex flex-col gap-1">
                    <span>{formatDateTimeShort(job.last_run_at)}</span>
                    <RunHistoryChip scheduleId={job.id} />
                  </div>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {formatDateTimeShort(job.next_run_at)}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      title="Trigger Now"
                      onClick={() => void handleTrigger(job)}
                    >
                      <Play className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => void handleToggle(job)}
                    >
                      {job.enabled ? "Disable" : "Enable"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(job)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => void handleDelete(job.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </PageContainer>
  );
}
