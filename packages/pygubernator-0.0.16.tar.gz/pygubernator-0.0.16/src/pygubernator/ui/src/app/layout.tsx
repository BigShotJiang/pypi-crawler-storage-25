import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "./globals.css";

import ErrorBoundary from "@/components/ErrorBoundary";
import AppShell from "@/components/AppShell";
import ThemeFromConfig from "@/components/ThemeFromConfig";
import ThemeSync from "@/components/ThemeSync";
import { ToastProvider } from "@/components/ui/toaster";
import ToastPortal from "@/components/ui/ToastPortal";
import { THEME_STORAGE_KEY } from "@/lib/constants";

export const metadata: Metadata = {
  title: "PyGubernator — Control Plane",
  description: "Agent registry, runs, observability, and policies."
};

export const viewport: Viewport = { width: "device-width", initialScale: 1 };

const THEME_SCRIPT = (key: string) =>
  `(function(){var k="${key}";var theme=(window.__APP_CONFIG__&&window.__APP_CONFIG__.theme)||(typeof localStorage!=="undefined"?localStorage.getItem(k):null)||"light";var resolved=theme==="system"?(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"):theme;var el=document.documentElement;if(resolved==="dark"){el.classList.add("dark");el.removeAttribute("data-theme");}else{el.classList.remove("dark");var named=["ocean","forest","sunset","high-contrast","sepia","violet","evergreen"];if(named.indexOf(resolved)!==-1)el.setAttribute("data-theme",resolved);else el.removeAttribute("data-theme");}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <Script
          id="pygubernator-theme-init"
          strategy="beforeInteractive"
          dangerouslySetInnerHTML={{ __html: THEME_SCRIPT(THEME_STORAGE_KEY) }}
        />
        <ThemeFromConfig />
        <ThemeSync />
        <ToastProvider>
          <ErrorBoundary>
            <AppShell>{children}</AppShell>
          </ErrorBoundary>
          <ToastPortal />
        </ToastProvider>
      </body>
    </html>
  );
}
