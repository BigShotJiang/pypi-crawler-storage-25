"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

import { apiGet, apiPost } from "@/lib/api";

type Job = {
  id: string;
  name: string;
  current_state: string;
  created_by: string;
  created_at: string;
  last_workflow_run_id?: string | null;
  last_error_message?: string | null;
  spec_json?: Record<string, unknown>;
};

type JobEvent = {
  id: string;
  trigger: string;
  actor: string;
  created_at: string;
  from_state: string;
  to_state: string;
  success: number;
  error_message?: string | null;
  workflow_run_id?: string | null;
};

type WorkflowStep = {
  id: string;
  node_id: string;
  node_type: string;
  status: string;
  output_json: any;
  error_message?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  duration_ms?: number | null;
};

export default function LibraryTestJobDetailInner() {
  const searchParams = useSearchParams();
  const jobId = searchParams.get("jobId") ?? "";

  const [job, setJob] = useState<Job | null>(null);
  const [events, setEvents] = useState<JobEvent[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [replayRunId, setReplayRunId] = useState<string | null>(null);
  const [diff, setDiff] = useState<any | null>(null);
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [expandedNodeId, setExpandedNodeId] = useState<string | null>(null);

  const stepElsRef = useRef<Record<string, HTMLDivElement | null>>({});

  async function refresh() {
    if (!jobId) return;
    const j = await apiGet<Job>(`/api/v1/library-testing/jobs/${jobId}`);
    const e = await apiGet<{ items: JobEvent[] }>(`/api/v1/library-testing/jobs/${jobId}/events`);
    setJob(j);
    setEvents(e.items);
    if (j.last_workflow_run_id) {
      const r = await apiGet<{ run: any; steps: WorkflowStep[] }>(
        `/api/v1/workflows/runs/${j.last_workflow_run_id}`
      );
      setSteps(r.steps ?? []);
    } else {
      setSteps([]);
    }
  }

  useEffect(() => {
    if (!jobId) {
      setError("Missing jobId query parameter");
      return;
    }
    void refresh().catch((e) => setError(e instanceof Error ? e.message : "Failed to load job"));
  }, [jobId]);

  const lastRunId = job?.last_workflow_run_id ?? null;

  const firstFailedStep = useMemo(() => {
    return (
      steps
        .filter((s) => s.node_id !== "__run__")
        .find((s) => String(s.status).toLowerCase() === "failed") ?? null
    );
  }, [steps]);

  const failureReport = useMemo(() => {
    if (!firstFailedStep) return null;
    const parts: string[] = [];
    parts.push(`LibraryTestJob failure report`);
    parts.push(`job_id: ${jobId}`);
    if (job?.name) parts.push(`job_name: ${job.name}`);
    if (lastRunId) parts.push(`workflow_run_id: ${lastRunId}`);
    parts.push(`failed_node_id: ${firstFailedStep.node_id}`);
    parts.push(`failed_node_type: ${firstFailedStep.node_type}`);
    if (firstFailedStep.error_message) parts.push(`error: ${firstFailedStep.error_message}`);
    return parts.join("\n");
  }, [firstFailedStep, job?.name, jobId, lastRunId]);

  const specSummary = useMemo(() => {
    if (!job?.spec_json) return null;
    const rp = job.spec_json["repo_path"];
    const req = job.spec_json["requirements"];
    return {
      repo_path: typeof rp === "string" ? rp : null,
      requirements: Array.isArray(req) ? req : null,
    };
  }, [job?.spec_json]);

  async function runJob() {
    if (!jobId) return;
    setBusy(true);
    setError(null);
    try {
      await apiPost<object, { ok: boolean; workflow_run_id: string }>(
        `/api/v1/library-testing/jobs/${jobId}/run`,
        {}
      );
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to start run");
    } finally {
      setBusy(false);
    }
  }

  async function replayRecorded() {
    if (!lastRunId) return;
    setBusy(true);
    setError(null);
    setDiff(null);
    try {
      const res = await apiPost<object, { ok: boolean; new_run_id: string }>(
        `/api/v1/workflows/runs/${lastRunId}/replay`,
        {}
      );
      setReplayRunId(res.new_run_id);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Replay failed");
    } finally {
      setBusy(false);
    }
  }

  async function loadDiff() {
    if (!lastRunId || !replayRunId) return;
    setBusy(true);
    setError(null);
    try {
      const d = await apiGet<any>("/api/v1/replay/workflow-runs/diff", {
        left_run_id: lastRunId,
        right_run_id: replayRunId
      });
      setDiff(d);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Diff failed");
    } finally {
      setBusy(false);
    }
  }

  function jumpToNode(nodeId: string) {
    const el = stepElsRef.current[nodeId];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  async function copyFailureReport() {
    if (!failureReport) return;
    try {
      await navigator.clipboard.writeText(failureReport);
    } catch {
      setError("Copy failed (clipboard permission denied?)");
    }
  }

  useEffect(() => {
    if (firstFailedStep && expandedNodeId == null) {
      setExpandedNodeId(firstFailedStep.node_id);
    }
  }, [firstFailedStep, expandedNodeId]);

  if (!jobId) {
    return (
      <div className="max-w-5xl mx-auto p-6">
        <div className="rounded-md border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
          Missing <span className="font-mono">jobId</span> query parameter.
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex items-baseline justify-between mb-6">
        <div>
          <div className="text-sm text-muted-foreground">
            <Link className="underline" href="/library-testing/">
              Library testing
            </Link>{" "}
            / {jobId.slice(0, 8)}
          </div>
          <h1 className="text-2xl font-bold mt-1">{job?.name || "Job"}</h1>
          <div className="text-sm text-muted-foreground mt-1">
            state: <span className="font-mono">{job?.current_state}</span>
            {job?.last_error_message ? (
              <span className="text-destructive"> • {job.last_error_message}</span>
            ) : null}
          </div>
        </div>
        <div className="flex gap-2">
          <button
            className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
            onClick={() => void refresh()}
            disabled={busy}
          >
            Refresh
          </button>
          <button
            className="px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50"
            onClick={() => void runJob()}
            disabled={busy}
          >
            Run
          </button>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-md border border-destructive/30 bg-destructive/10 text-sm">
          {error}
        </div>
      )}

      {firstFailedStep && (
        <div className="mb-6 p-4 rounded-lg border border-destructive/30 bg-destructive/10">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="font-medium">Failure detected</div>
              <div className="text-sm text-muted-foreground mt-1">
                <span className="font-mono">{firstFailedStep.node_id}</span>{" "}
                <span className="text-muted-foreground">({firstFailedStep.node_type})</span>
                {firstFailedStep.error_message ? (
                  <span className="text-destructive"> • {firstFailedStep.error_message}</span>
                ) : null}
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                onClick={() => jumpToNode(firstFailedStep.node_id)}
              >
                Jump to node
              </button>
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
                onClick={() => void copyFailureReport()}
              >
                Copy report
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <div className="rounded-lg border border-border p-4">
            <div className="font-medium mb-3">Workflow steps</div>
            {steps.length === 0 ? (
              <div className="text-sm text-muted-foreground">No workflow run recorded yet.</div>
            ) : (
              <div className="space-y-3">
                {steps.map((step) => {
                  const failed = String(step.status).toLowerCase() === "failed";
                  const expanded = expandedNodeId === step.node_id;
                  return (
                    <div
                      key={step.id}
                      ref={(el) => {
                        stepElsRef.current[step.node_id] = el;
                      }}
                      className={`rounded-md border p-3 ${failed ? "border-destructive/40 bg-destructive/5" : "border-border"}`}
                    >
                      <button
                        className="w-full text-left"
                        onClick={() =>
                          setExpandedNodeId((prev) => (prev === step.node_id ? null : step.node_id))
                        }
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <div className="font-medium">
                              {step.node_id}{" "}
                              <span className="text-xs text-muted-foreground">({step.node_type})</span>
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              status: <span className="font-mono">{step.status}</span>
                              {step.duration_ms != null ? ` • ${step.duration_ms}ms` : ""}
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {expanded ? "Hide" : "Show"}
                          </div>
                        </div>
                      </button>
                      {expanded && (
                        <div className="mt-3 space-y-3">
                          {step.error_message && (
                            <div className="text-sm text-destructive">{step.error_message}</div>
                          )}
                          <pre className="text-[11px] bg-muted/50 rounded p-3 overflow-auto max-h-[220px]">
                            {JSON.stringify(step.output_json ?? {}, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="rounded-lg border border-border p-4">
            <div className="font-medium mb-3">Replay & diff</div>
            <div className="flex flex-wrap gap-2">
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted disabled:opacity-50"
                onClick={() => void replayRecorded()}
                disabled={busy || !lastRunId}
              >
                Replay last run
              </button>
              <button
                className="px-3 py-2 rounded-md border border-border text-sm hover:bg-muted disabled:opacity-50"
                onClick={() => void loadDiff()}
                disabled={busy || !lastRunId || !replayRunId}
              >
                Load diff
              </button>
            </div>
            {replayRunId && (
              <div className="text-sm text-muted-foreground mt-3">
                replay_run_id: <span className="font-mono">{replayRunId}</span>
              </div>
            )}
            {diff && (
              <pre className="mt-3 text-[11px] bg-muted/50 rounded p-3 overflow-auto max-h-[260px]">
                {JSON.stringify(diff, null, 2)}
              </pre>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-lg border border-border p-4">
            <div className="font-medium mb-3">Job</div>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-muted-foreground">Job ID:</span>{" "}
                <span className="font-mono">{jobId}</span>
              </div>
              {job?.created_by && (
                <div>
                  <span className="text-muted-foreground">Created by:</span> {job.created_by}
                </div>
              )}
              {specSummary?.repo_path && (
                <div>
                  <span className="text-muted-foreground">Repo:</span>{" "}
                  <span className="font-mono break-all">{String(specSummary.repo_path)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="rounded-lg border border-border p-4">
            <div className="font-medium mb-3">Events</div>
            {events.length === 0 ? (
              <div className="text-sm text-muted-foreground">No events yet.</div>
            ) : (
              <div className="space-y-3">
                {events.map((event) => (
                  <div key={event.id} className="rounded-md border border-border p-3">
                    <div className="font-medium text-sm">{event.trigger}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {event.from_state} → {event.to_state} • {event.actor}
                    </div>
                    {event.error_message && (
                      <div className="text-xs text-destructive mt-1">{event.error_message}</div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {failureReport && (
            <div className="rounded-lg border border-border p-4">
              <div className="font-medium mb-3">Failure report</div>
              <pre className="text-[11px] bg-muted/50 rounded p-3 overflow-auto max-h-[260px] whitespace-pre-wrap">
                {failureReport}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
