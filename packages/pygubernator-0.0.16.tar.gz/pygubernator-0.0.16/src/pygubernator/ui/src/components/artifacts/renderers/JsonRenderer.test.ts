import { describe, expect, it } from "vitest";

import { prettyPrintJson } from "./JsonRenderer";

describe("prettyPrintJson", () => {
  it("indents well-formed JSON with two spaces", () => {
    expect(prettyPrintJson('{"a":1,"b":[2,3]}')).toBe(
      '{\n  "a": 1,\n  "b": [\n    2,\n    3\n  ]\n}',
    );
  });

  it("returns the original string when input is not valid JSON", () => {
    const raw = "not { json";
    expect(prettyPrintJson(raw)).toBe(raw);
  });

  it("preserves unicode characters", () => {
    expect(prettyPrintJson('{"msg":"héllo"}')).toContain("héllo");
  });
});
