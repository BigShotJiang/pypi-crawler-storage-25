"use client";

/**
 * Panel that lists artifacts for a run (or one step within a run) and
 * renders the selected artifact via ``ArtifactViewer``.
 *
 * Designed to be dropped into any container (Card, right-pane of a
 * split-layout, tab body). The component is intentionally self-
 * contained — it fetches its own data through ``useRunArtifacts`` so
 * callers don't have to plumb state down, and callers can ask to
 * ``refresh`` on demand (e.g. when an ``artifact_created`` SSE event
 * fires) via a ref.
 */

import { useEffect, useState } from "react";
import { FileText, RefreshCw } from "lucide-react";

import { useRunArtifacts } from "@/hooks/useRunArtifacts";
import type { WorkflowArtifactSummary } from "@/lib/api";
import { cn } from "@/lib/utils";
import { ArtifactViewer } from "./ArtifactViewer";

export interface ArtifactListProps {
  runId: string;
  /** Optional step scope. When null, shows all run artifacts. */
  stepId?: string | null;
  /**
   * Monotonic tick that bumps when an ``artifact_created`` /
   * ``artifact_updated`` SSE event fires. The component re-fetches when
   * this changes so live runs stay current without a polling timer.
   */
  refreshNonce?: number;
  /** Title rendered above the list. Defaults to "Artifacts". */
  heading?: string;
  /**
   * When ``true``, render nothing at all while the list is empty +
   * error-free. Useful for step-level mounts inside ``StepDetailPanel``
   * where an empty state would clutter every step that didn't emit an
   * artifact.
   */
  hideWhenEmpty?: boolean;
  className?: string;
}

export function ArtifactList({
  runId,
  stepId = null,
  refreshNonce = 0,
  heading = "Artifacts",
  hideWhenEmpty = false,
  className,
}: ArtifactListProps) {
  const { items, loading, error, refresh } = useRunArtifacts(runId, stepId);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  if (hideWhenEmpty && !loading && !error && items.length === 0) {
    return null;
  }

  // Re-fetch whenever the parent bumps the nonce (e.g. after an SSE event).
  useEffect(() => {
    if (refreshNonce > 0) {
      void refresh();
    }
  }, [refreshNonce, refresh]);

  // Auto-select the first artifact when the list becomes non-empty so
  // the viewer has something to show without requiring a click.
  useEffect(() => {
    if (selectedId && items.some((a) => a.id === selectedId)) return;
    setSelectedId(items.length > 0 ? items[0].id : null);
  }, [items, selectedId]);

  const selected = items.find((a) => a.id === selectedId) ?? null;

  return (
    <div className={className}>
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <h4 className="text-sm font-medium">{heading}</h4>
          <span className="text-xs text-muted-foreground">({items.length})</span>
        </div>
        <button
          type="button"
          onClick={() => void refresh()}
          className="inline-flex items-center gap-1 rounded border border-border/60 bg-background/80 px-1.5 py-0.5 text-xs hover:bg-muted"
          aria-label="Refresh artifact list"
          disabled={loading}
        >
          <RefreshCw
            className={cn("h-3 w-3", loading && "animate-spin")}
          />
          Refresh
        </button>
      </div>

      {error && (
        <p className="mb-2 text-xs text-red-600">{error}</p>
      )}

      {!error && items.length === 0 && !loading && (
        <p className="text-xs text-muted-foreground">
          No artifacts have been emitted for this {stepId ? "step" : "run"} yet.
        </p>
      )}

      {items.length > 0 && (
        <div className="grid gap-3 md:grid-cols-[220px_1fr]">
          <ul className="flex flex-col gap-1 overflow-auto rounded-md border p-1">
            {items.map((item) => (
              <ArtifactListRow
                key={item.id}
                artifact={item}
                isSelected={item.id === selectedId}
                onSelect={() => setSelectedId(item.id)}
              />
            ))}
          </ul>
          <div className="min-w-0">
            {selected ? (
              <ArtifactViewer artifact={selected} runId={runId} />
            ) : (
              <p className="text-xs text-muted-foreground">
                Select an artifact to preview it.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface ArtifactListRowProps {
  artifact: WorkflowArtifactSummary;
  isSelected: boolean;
  onSelect: () => void;
}

function ArtifactListRow({
  artifact,
  isSelected,
  onSelect,
}: ArtifactListRowProps) {
  return (
    <li>
      <button
        type="button"
        onClick={onSelect}
        aria-pressed={isSelected}
        className={cn(
          "flex w-full flex-col items-start gap-0.5 rounded px-2 py-1.5 text-left transition-colors hover:bg-muted",
          isSelected && "bg-muted",
        )}
      >
        <span className="truncate text-sm font-medium">
          {artifact.title || `Artifact #${artifact.sequence_num + 1}`}
        </span>
        <span className="truncate text-[10px] text-muted-foreground">
          {artifact.artifact_type}
          {artifact.mime ? ` · ${artifact.mime}` : ""}
        </span>
      </button>
    </li>
  );
}
