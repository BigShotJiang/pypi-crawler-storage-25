'use client'

import { Users, Link, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useCollabStore, selectIsActive } from '@/stores/collab'
import { useCollab } from '@/hooks/use-collab'
import { ShareDialog } from './ShareDialog'
import { CollaboratorAvatars } from './CollaboratorAvatars'

/**
 * Toolbar button that starts or manages a collaboration session.
 *
 * When inactive, shows a single "Share" button. When active, shows
 * collaborator avatars, a share-link button, and a disconnect button.
 */
export function ShareButton() {
  const isActive = useCollabStore(selectIsActive)
  const setDialogOpen = useCollabStore((s) => s.setShareDialogOpen)
  const { startSession, disconnect } = useCollab()

  if (isActive) {
    return (
      <div className="flex items-center gap-1">
        <CollaboratorAvatars />
        <Button
          variant="outline"
          size="sm"
          onClick={() => setDialogOpen(true)}
          className="gap-1.5"
        >
          <Link className="h-3.5 w-3.5" />
          Share
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={disconnect}
          title="Leave session"
          aria-label="Leave session"
        >
          <LogOut className="h-3.5 w-3.5" />
        </Button>
        <ShareDialog />
      </div>
    )
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        onClick={startSession}
        className="gap-1.5"
      >
        <Users className="h-3.5 w-3.5" />
        Share
      </Button>
      <ShareDialog />
    </>
  )
}
