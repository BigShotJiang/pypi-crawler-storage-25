import { describe, expect, it } from "vitest";

import {
  INITIAL_INLINE_VERSION_FORM,
  inlineVersionFormReducer,
  type InlineVersionFormState,
  type ProviderPreset,
} from "./inline-version-form-state";

const ollamaPreset: ProviderPreset = {
  name: "ollama",
  description: "Local OpenAI-compatible server",
  default_api_base: "http://localhost:11434/v1",
  models: ["llama3.1", "mistral"],
  provider_type: "openai_compatible",
  requires_api_key: false,
};

const openaiPreset: ProviderPreset = {
  name: "openai",
  description: "OpenAI cloud",
  default_api_base: null,
  models: ["gpt-4o", "gpt-4o-mini"],
  provider_type: "openai",
  requires_api_key: true,
};

function makeState(overrides: Partial<InlineVersionFormState> = {}): InlineVersionFormState {
  return { ...INITIAL_INLINE_VERSION_FORM, ...overrides };
}

describe("inlineVersionFormReducer", () => {
  it("set_field updates exactly one field", () => {
    const state = makeState();
    const next = inlineVersionFormReducer(state, {
      type: "set_field",
      field: "version",
      value: "1.0.0",
    });
    expect(next.version).toBe("1.0.0");
    expect(next.model).toBe("");
  });

  it("select_provider with a preset fills api_base / model and clears api_key", () => {
    const state = makeState({ api_key: "stale-key" });
    const next = inlineVersionFormReducer(state, {
      type: "select_provider",
      provider_name: "ollama",
      preset: ollamaPreset,
    });
    expect(next.provider_name).toBe("ollama");
    expect(next.api_base).toBe("http://localhost:11434/v1");
    expect(next.model).toBe("llama3.1");
    expect(next.api_key).toBe("");
  });

  it("select_provider with a key-required preset still clears api_key", () => {
    // Switching providers must never leak a key from a previous one.
    const state = makeState({ api_key: "sk-leak" });
    const next = inlineVersionFormReducer(state, {
      type: "select_provider",
      provider_name: "openai",
      preset: openaiPreset,
    });
    expect(next.api_key).toBe("");
    expect(next.api_base).toBe("");
    expect(next.model).toBe("gpt-4o");
  });

  it("select_provider with no preset clears all preset-derived fields", () => {
    const state = makeState({
      provider_name: "ollama",
      api_base: "http://localhost:11434/v1",
      model: "llama3.1",
      api_key: "stale",
    });
    const next = inlineVersionFormReducer(state, {
      type: "select_provider",
      provider_name: "",
      preset: undefined,
    });
    expect(next.provider_name).toBe("");
    expect(next.api_base).toBe("");
    expect(next.model).toBe("");
    expect(next.api_key).toBe("");
  });

  it("set_field on an unrelated field does not disturb preset-derived state", () => {
    // After picking a preset the user types into ``prompt`` — none of
    // the preset-derived fields should churn.
    let state = inlineVersionFormReducer(makeState(), {
      type: "select_provider",
      provider_name: "ollama",
      preset: ollamaPreset,
    });
    state = inlineVersionFormReducer(state, {
      type: "set_field",
      field: "prompt",
      value: "be helpful",
    });
    expect(state.prompt).toBe("be helpful");
    expect(state.api_base).toBe("http://localhost:11434/v1");
    expect(state.model).toBe("llama3.1");
  });

  it("reset returns to initial state regardless of prior values", () => {
    const state = makeState({
      version: "1.2.3",
      provider_name: "ollama",
      api_base: "http://localhost:11434/v1",
    });
    const next = inlineVersionFormReducer(state, { type: "reset" });
    expect(next).toEqual(INITIAL_INLINE_VERSION_FORM);
  });
});
