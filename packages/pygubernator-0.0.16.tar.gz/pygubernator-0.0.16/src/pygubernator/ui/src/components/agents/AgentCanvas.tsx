"use client";

import { memo, useCallback, useEffect, useMemo } from "react";
import {
  addEdge,
  Background,
  Controls,
  ReactFlow,
  ReactFlowProvider,
  useEdgesState,
  useNodesState,
  type Connection,
  type Edge,
  type Node,
  type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { cn } from "@/lib/utils";
import { componentPresetByType } from "@/lib/agent-components";
import {
  useAgentEditorStore,
  type AgentBuilderNode,
  type AgentBuilderSpec,
} from "@/stores/agent-editor";

interface AgentCanvasNodeData extends Record<string, unknown> {
  label: string;
  nodeType: string;
}

function nodeTone(type: string): string {
  if (type === "chat_model") return "border-cyan-500/40 bg-cyan-500/5";
  if (type === "tool") return "border-amber-500/40 bg-amber-500/5";
  if (type === "memory") return "border-violet-500/40 bg-violet-500/5";
  if (type === "router") return "border-emerald-500/40 bg-emerald-500/5";
  if (type === "validator") return "border-rose-500/40 bg-rose-500/5";
  return "border-border/60 bg-background";
}

const AgentCanvasNode = memo(function AgentCanvasNode({
  data,
  selected,
}: NodeProps<Node<AgentCanvasNodeData>>) {
  return (
    <div
      className={cn(
        "min-w-[180px] rounded-md border px-3 py-2 shadow-sm",
        nodeTone(data.nodeType),
        selected ? "ring-1 ring-primary/50" : "",
      )}
    >
      <p className="text-xs font-semibold">{data.label}</p>
      <p className="mt-1 text-[11px] text-muted-foreground">{data.nodeType}</p>
    </div>
  );
});

const NODE_TYPES = { agentBuilderNode: AgentCanvasNode };

function specToFlow(spec: AgentBuilderSpec): { nodes: Node[]; edges: Edge[] } {
  const nodes: Node[] = Object.entries(spec.nodes).map(([id, node], index) => ({
    id,
    type: "agentBuilderNode",
    position: node.position ?? { x: 150 + index * 220, y: 220 },
    data: {
      label: node.label ?? node.type,
      nodeType: node.type,
    } satisfies AgentCanvasNodeData,
  }));
  const edges: Edge[] = spec.edges.map((edge, index) => ({
    id: `e-${index}-${edge.source}-${edge.target}`,
    source: edge.source,
    target: edge.target,
  }));
  return { nodes, edges };
}

function flowToSpec(nodes: Node[], edges: Edge[], prevNodes: Record<string, AgentBuilderNode>) {
  const nextNodes: Record<string, AgentBuilderNode> = {};
  for (const node of nodes) {
    const prev = prevNodes[node.id];
    if (!prev) continue;
    nextNodes[node.id] = {
      ...prev,
      position: { x: Math.round(node.position.x), y: Math.round(node.position.y) },
    };
  }
  return {
    nodes: nextNodes,
    edges: edges.map((edge) => ({ source: edge.source, target: edge.target })),
  };
}

function AgentCanvasInner() {
  const spec = useAgentEditorStore((s) => s.spec);
  const updateNodesAndEdges = useAgentEditorStore((s) => s.updateNodesAndEdges);
  const selectedNodeId = useAgentEditorStore((s) => s.selectedNodeId);
  const setSelectedNodeId = useAgentEditorStore((s) => s.setSelectedNodeId);

  const initial = useMemo(() => specToFlow(spec), [spec]);
  const [nodes, setNodes, onNodesChange] = useNodesState(initial.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initial.edges);

  useEffect(() => {
    setNodes(initial.nodes);
    setEdges(initial.edges);
  }, [initial, setNodes, setEdges]);

  const onConnect = useCallback(
    (connection: Connection) => {
      setEdges((current) => {
        const next = addEdge(connection, current);
        const updated = flowToSpec(nodes, next, spec.nodes);
        updateNodesAndEdges(updated.nodes, updated.edges);
        return next;
      });
    },
    [nodes, spec.nodes, setEdges, updateNodesAndEdges],
  );

  const isValidConnection = useCallback(
    (connection: Connection | Edge) => {
      if (!connection.source || !connection.target) return false;
      if (connection.source === connection.target) return false;
      const source = spec.nodes[connection.source];
      const target = spec.nodes[connection.target];
      if (!source || !target) return false;
      const preset = componentPresetByType(source.type);
      if (!preset?.acceptsTargets) return true;
      return preset.acceptsTargets.includes(target.type as never);
    },
    [spec.nodes],
  );

  return (
    <div className="h-full w-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={(changes) => {
          onNodesChange(changes);
          setNodes((current) => {
            const updated = flowToSpec(current, edges, spec.nodes);
            updateNodesAndEdges(updated.nodes, updated.edges);
            return current;
          });
        }}
        onEdgesChange={(changes) => {
          onEdgesChange(changes);
          setEdges((current) => {
            const updated = flowToSpec(nodes, current, spec.nodes);
            updateNodesAndEdges(updated.nodes, updated.edges);
            return current;
          });
        }}
        onConnect={onConnect}
        isValidConnection={isValidConnection}
        nodeTypes={NODE_TYPES}
        fitView
        onNodeClick={(_, node) => setSelectedNodeId(node.id)}
        onPaneClick={() => setSelectedNodeId(null)}
      >
        <Background />
        <Controls />
      </ReactFlow>
      {nodes.length === 0 ? (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="rounded-md border border-dashed border-border/60 bg-background/80 px-4 py-3 text-xs text-muted-foreground">
            Add an agent component from the sidebar to start building.
          </div>
        </div>
      ) : null}
      {selectedNodeId ? (
        <div className="pointer-events-none absolute bottom-3 left-3 rounded bg-background/90 px-2 py-1 text-[11px] text-muted-foreground shadow">
          Selected: {selectedNodeId}
        </div>
      ) : null}
    </div>
  );
}

export default function AgentCanvas() {
  return (
    <ReactFlowProvider>
      <AgentCanvasInner />
    </ReactFlowProvider>
  );
}
