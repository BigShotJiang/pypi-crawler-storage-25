"use client";

import { AlertCircle, CheckCircle2, FileText, Plus } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { parseSpecText, type SpecValidation } from "@/lib/agent-spec";
import { cn } from "@/lib/utils";

export interface SpecVersionFormProps {
  specText: string;
  onSpecTextChange: (value: string) => void;
  parsedSpec: ReturnType<typeof parseSpecText> | null;
  validation: SpecValidation | null;
  validating: boolean;
  onValidate: () => void;
  specVersion: string;
  onSpecVersionChange: (value: string) => void;
  submitDisabled: boolean;
  onSubmit: (e: React.FormEvent) => void;
  onBrowseCatalog: () => void;
}

/**
 * Authoring form for creating an :class:`AgentVersion` from a pasted
 * YAML or JSON spec. Users paste, click Validate (hits the server-side
 * compiler), review the fingerprint / errors, then Publish.
 */
export function SpecVersionForm({
  specText,
  onSpecTextChange,
  parsedSpec,
  validation,
  validating,
  onValidate,
  specVersion,
  onSpecVersionChange,
  submitDisabled,
  onSubmit,
  onBrowseCatalog,
}: SpecVersionFormProps) {
  return (
    <form className="space-y-3" onSubmit={onSubmit}>
      <div>
        <div className="mb-1 flex items-center justify-between">
          <label className="block text-xs text-muted-foreground" htmlFor="new-spec-text">
            Spec (YAML or JSON)
          </label>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="h-6 gap-1 text-[11px]"
            onClick={onBrowseCatalog}
          >
            <FileText className="h-3 w-3" />
            Browse catalog
          </Button>
        </div>
        <textarea
          id="new-spec-text"
          className="flex min-h-[180px] w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-xs ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          placeholder={[
            "name: researcher",
            "model: gpt-4o",
            "prompt: You are a news researcher.",
            "tools:",
            "  search_docs:",
            "    module: mypkg.tools",
            "    function: search",
          ].join("\n")}
          value={specText}
          onChange={(e) => onSpecTextChange(e.target.value)}
        />
      </div>

      {parsedSpec?.ok === false && (
        <div className="flex items-start gap-2 rounded border border-red-300 bg-red-50 px-2 py-1.5 text-[11px] text-red-800 dark:border-red-700 dark:bg-red-950/40 dark:text-red-200">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>{parsedSpec.error}</span>
        </div>
      )}

      {validation && (
        <div
          className={cn(
            "rounded border px-2 py-1.5 text-[11px]",
            validation.valid
              ? "border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-200"
              : "border-red-300 bg-red-50 text-red-800 dark:border-red-700 dark:bg-red-950/40 dark:text-red-200",
          )}
        >
          <div className="flex items-center gap-2">
            {validation.valid ? (
              <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
            ) : (
              <AlertCircle className="h-3.5 w-3.5 shrink-0" />
            )}
            <span className="font-medium">
              {validation.valid ? "Spec is valid" : "Spec is invalid"}
            </span>
            {validation.fingerprint && (
              <code className="font-mono text-[10px] opacity-80">
                fp: {validation.fingerprint.slice(0, 12)}
              </code>
            )}
          </div>
          {validation.errors.length > 0 && (
            <ul className="mt-1 list-disc space-y-0.5 pl-5">
              {validation.errors.map((err, idx) => (
                <li key={idx}>{err}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="flex items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={onValidate}
          disabled={!parsedSpec?.ok || validating}
        >
          {validating ? "Validating…" : "Validate"}
        </Button>
        <Input
          placeholder="Version label"
          value={specVersion}
          onChange={(e) => onSpecVersionChange(e.target.value)}
          className="max-w-[200px]"
        />
        <Button type="submit" size="sm" disabled={submitDisabled}>
          <Plus className="mr-1 h-4 w-4" />
          Publish version
        </Button>
      </div>
      <p className="text-[10px] text-muted-foreground">
        Paste a YAML or JSON agent spec. Validate runs the server compiler
        and returns a fingerprint you can cross-reference later.
      </p>
    </form>
  );
}
