"use client";

import { useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import AgentCanvas from "@/components/agents/AgentCanvas";
import AgentEditorToolbar from "@/components/agents/AgentEditorToolbar";
import AgentInspectorPanel from "@/components/agents/AgentInspectorPanel";
import AgentRegistryDetailView from "@/components/agents/AgentRegistryDetailView";
import { apiGet } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { hydrateAgentEditorFromVersion } from "@/stores/agent-editor";

export default function AgentEditorSurface() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const agentId = searchParams.get("agent_id");

  const clearAgentId = useCallback(() => {
    const params = new URLSearchParams(searchParams.toString());
    params.delete("agent_id");
    const q = params.toString();
    router.replace(q ? `${ROUTES.WORKFLOW_EDITOR}?${q}` : ROUTES.WORKFLOW_EDITOR, { scroll: false });
  }, [router, searchParams]);

  const openActiveVersionInBuilder = useCallback(async () => {
    if (!agentId) return;
    const dash = await apiGet<{
      agent: { id: string; name: string };
      versions: Array<{
        id: string;
        version: string;
        active: boolean;
        model: string | null;
        prompt: string | null;
        tools: Record<string, unknown>;
        config: Record<string, unknown>;
        spec_json?: Record<string, unknown>;
      }>;
    }>(`/api/v1/agents/${agentId}/dashboard`);
    const active = dash.versions.find((v) => v.active) ?? dash.versions[0];
    if (!active || !dash.agent) {
      clearAgentId();
      return;
    }
    hydrateAgentEditorFromVersion({
      agentId: dash.agent.id,
      agentName: dash.agent.name,
      version: active.version,
      specJson:
        active.spec_json && typeof active.spec_json === "object" ? active.spec_json : null,
      model: active.model,
      prompt: active.prompt,
      tools: active.tools ?? {},
      config: active.config ?? {},
    });
    clearAgentId();
  }, [agentId, clearAgentId]);

  if (agentId) {
    return (
      <AgentRegistryDetailView
        agentId={agentId}
        onBack={clearAgentId}
        onOpenInBuilder={() => void openActiveVersionInBuilder()}
      />
    );
  }

  return (
    <div className="relative h-full min-h-0 w-full overflow-hidden">
      <AgentEditorToolbar />
      <AgentCanvas />
      <AgentInspectorPanel />
    </div>
  );
}
