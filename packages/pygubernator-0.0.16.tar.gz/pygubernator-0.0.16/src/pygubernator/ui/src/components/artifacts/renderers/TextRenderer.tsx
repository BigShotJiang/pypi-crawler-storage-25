"use client";

/** Plain-text artifact renderer. Used for ``text`` and ``notebook`` v1. */

export interface TextRendererProps {
  content: string;
  className?: string;
}

export function TextRenderer({ content, className }: TextRendererProps) {
  return (
    <pre
      className={`whitespace-pre-wrap rounded-md bg-muted p-2 font-mono text-xs leading-snug ${
        className ?? ""
      }`}
    >
      {content}
    </pre>
  );
}
