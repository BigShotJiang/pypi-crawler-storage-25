'use client'

import { useCollabStore, selectCollaborators } from '@/stores/collab'

/** Small avatar stack showing active collaborators in the room. */
export function CollaboratorAvatars() {
  const collaborators = useCollabStore(selectCollaborators)

  if (collaborators.length === 0) return null

  const MAX_VISIBLE = 5

  return (
    <div className="flex -space-x-1.5">
      {collaborators.slice(0, MAX_VISIBLE).map((c) => (
        <div
          key={c.socketId}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 border-background text-[10px] font-bold text-white"
          style={{ backgroundColor: c.color }}
          title={c.username || 'Anonymous'}
        >
          {(c.username || '?')[0].toUpperCase()}
        </div>
      ))}
      {collaborators.length > MAX_VISIBLE && (
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 border-background bg-muted text-[10px] font-medium text-muted-foreground">
          +{collaborators.length - MAX_VISIBLE}
        </div>
      )}
    </div>
  )
}
