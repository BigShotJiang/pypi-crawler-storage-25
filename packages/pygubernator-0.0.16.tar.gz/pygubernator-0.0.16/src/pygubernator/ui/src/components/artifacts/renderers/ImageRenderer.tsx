"use client";

/** Image artifact renderer that builds a data URL from the API payload. */

export interface ImageRendererProps {
  /** Inline text (``utf-8``) or base64 (``base64``) content from the API. */
  content: string;
  /** ``"utf-8"`` or ``"base64"``. */
  encoding: "utf-8" | "base64";
  mime: string | null;
  title?: string;
  className?: string;
}

/** Build a ``data:...`` URL suitable for an ``<img src>`` attribute. */
export function buildImageDataUrl(
  content: string,
  encoding: "utf-8" | "base64",
  mime: string | null,
): string {
  const resolvedMime = mime || "application/octet-stream";
  if (encoding === "base64") {
    return `data:${resolvedMime};base64,${content}`;
  }
  // UTF-8 (SVG, typically): URL-encode the payload so the browser parses it.
  return `data:${resolvedMime};utf8,${encodeURIComponent(content)}`;
}

export function ImageRenderer({
  content,
  encoding,
  mime,
  title,
  className,
}: ImageRendererProps) {
  const src = buildImageDataUrl(content, encoding, mime);
  return (
    <div className={className}>
      {/*
        eslint-disable-next-line @next/next/no-img-element --
        Intentional: artifact images come from a data: URL, not an asset
        path, so ``next/image`` can't optimise them.
      */}
      <img
        src={src}
        alt={title ?? "Artifact image"}
        className="max-w-full rounded-md border"
      />
    </div>
  );
}
