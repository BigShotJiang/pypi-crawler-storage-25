"use client";

import { useEffect, useMemo, useState } from "react";
import { FileText, Search, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  dumpSpecToYaml,
  getAgentSpecDetail,
  listAgentSpecs,
  type AgentSpecSummary,
} from "@/lib/agent-spec";

interface AgentSpecCatalogDialogProps {
  /**
   * Called with the YAML-dumped spec text when a catalog entry is picked.
   *
   * The caller is expected to close the dialog after handling the value
   * (it typically feeds straight into the authoring textarea).
   */
  onSelect: (yamlText: string, source: AgentSpecSummary) => void;
  onClose: () => void;
}

/**
 * Modal that lists file-based agent specs from the backend catalog
 * (``GET /api/v1/agents/specs``) and loads the compiled YAML into the
 * authoring textarea when a row is picked.
 *
 * Catalog entries live under ``agents/specs/`` on the server; the
 * "from spec" authoring flow otherwise requires users to paste the
 * YAML by hand. Picking from the catalog speeds up the common case of
 * "start from a known-good example and tweak" without losing the
 * round-trip through Validate + Publish.
 */
export function AgentSpecCatalogDialog({
  onSelect,
  onClose,
}: AgentSpecCatalogDialogProps) {
  const [items, setItems] = useState<AgentSpecSummary[] | null>(null);
  const [query, setQuery] = useState("");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [pickingPath, setPickingPath] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const list = await listAgentSpecs();
        if (!cancelled) setItems(list);
      } catch (err) {
        if (!cancelled) {
          setLoadError(
            err instanceof Error ? err.message : "Failed to load spec catalog",
          );
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const filtered = useMemo(() => {
    const source = items ?? [];
    const q = query.trim().toLowerCase();
    if (!q) return source;
    return source.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.path.toLowerCase().includes(q) ||
        s.owner.toLowerCase().includes(q),
    );
  }, [items, query]);

  const pick = async (entry: AgentSpecSummary) => {
    setPickingPath(entry.path);
    try {
      const detail = await getAgentSpecDetail(entry.path);
      const yamlText = dumpSpecToYaml(detail.spec_json);
      onSelect(yamlText, entry);
    } catch (err) {
      setLoadError(
        err instanceof Error ? err.message : "Failed to load spec detail",
      );
    } finally {
      setPickingPath(null);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 pt-[10vh]"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-lg border bg-background shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b px-4 py-3">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">Spec catalog</h2>
          </div>
          <button
            className="text-muted-foreground hover:text-foreground"
            onClick={onClose}
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3 p-4">
          <div className="flex items-center gap-2 rounded-md border border-input px-2">
            <Search className="h-3.5 w-3.5 text-muted-foreground" />
            <input
              autoFocus
              className="flex-1 bg-transparent py-1.5 text-sm outline-none"
              placeholder="Filter by name, path, or owner…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          {loadError && (
            <p className="text-xs text-red-600 dark:text-red-400">{loadError}</p>
          )}

          {items === null && !loadError && (
            <p className="text-xs text-muted-foreground">Loading catalog…</p>
          )}

          {items !== null && filtered.length === 0 && !loadError && (
            <p className="text-xs italic text-muted-foreground">
              {items.length === 0
                ? "No file-based specs found on the server (agents/specs/ is empty or missing)."
                : "No catalog entries match the filter."}
            </p>
          )}

          <ul className="max-h-[45vh] divide-y divide-border/40 overflow-y-auto">
            {filtered.map((entry) => (
              <li key={entry.path}>
                <button
                  type="button"
                  className="flex w-full flex-col gap-0.5 rounded px-2 py-2 text-left hover:bg-muted disabled:opacity-60"
                  onClick={() => void pick(entry)}
                  disabled={pickingPath !== null}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{entry.name}</span>
                    <span className="text-[10px] text-muted-foreground">
                      owner: {entry.owner}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <code className="truncate font-mono">{entry.path}</code>
                    {entry.fingerprint && (
                      <span className="shrink-0 font-mono opacity-80">
                        fp: {entry.fingerprint.slice(0, 8)}
                      </span>
                    )}
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex items-center justify-end border-t px-4 py-2">
          <Button size="sm" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
