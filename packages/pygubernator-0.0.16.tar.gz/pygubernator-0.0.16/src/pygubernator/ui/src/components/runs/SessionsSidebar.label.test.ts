import { describe, expect, it } from "vitest";

import { displaySessionLabel } from "./SessionsSidebar";

const baseSession = {
  session_id: "abcdef0123456789",
  workflow_id: "wf-1",
  workflow_name: "wf",
  run_count: 1,
  last_run_at: null,
  last_status: null,
  name: null as string | null,
};

describe("displaySessionLabel", () => {
  it("returns the trimmed user name when present", () => {
    expect(
      displaySessionLabel({ ...baseSession, name: "  Friday daily  " }),
    ).toBe("Friday daily");
  });

  it("falls back to the truncated session id when no name", () => {
    expect(
      displaySessionLabel({ ...baseSession, session_id: "abcdef0123456789" }),
    ).toBe("abcdef012345…");
  });

  it("returns the raw id when shorter than 12 chars", () => {
    expect(
      displaySessionLabel({ ...baseSession, session_id: "short" }),
    ).toBe("short");
  });

  it("treats whitespace-only name as empty and falls back", () => {
    expect(
      displaySessionLabel({ ...baseSession, name: "   ", session_id: "xyz" }),
    ).toBe("xyz");
  });
});
