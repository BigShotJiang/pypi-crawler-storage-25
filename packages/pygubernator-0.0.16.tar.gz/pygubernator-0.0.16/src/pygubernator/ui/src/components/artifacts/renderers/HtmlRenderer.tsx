"use client";

/**
 * Sandboxed HTML artifact renderer.
 *
 * Renders arbitrary HTML inside an ``<iframe srcDoc>`` with a strict
 * sandbox so artifact content cannot access the host document's cookies,
 * storage, or parent frame. The sandbox flags intentionally omit
 * ``allow-same-origin`` and ``allow-top-navigation``; a future message-
 * passing bridge for interactive artifacts would add ``allow-scripts``
 * and wire up ``postMessage`` listeners, but v1 opts for defence-in-
 * depth instead of interactivity.
 *
 * Callers control the iframe height via ``height`` prop; the default
 * works for small HTML fragments. Users scroll within the frame for
 * larger content.
 */

export interface HtmlRendererProps {
  content: string;
  title?: string;
  /** CSS height for the iframe. Defaults to 480px. */
  height?: string;
  className?: string;
}

/**
 * Sandbox flags applied to artifact iframes.
 *
 * Intentionally tight:
 * - No ``allow-same-origin``: the frame can't touch the parent's cookies
 *   or localStorage and XHRs are treated as cross-origin.
 * - No ``allow-scripts``: content can't run JavaScript.
 * - No ``allow-top-navigation``: can't escape into the parent tab.
 * - No ``allow-forms``: can't submit forms.
 *
 * The result: static HTML renders (headings, paragraphs, tables, styles,
 * images sourced from the srcDoc itself) but any attempt to script,
 * navigate, or exfiltrate data is blocked by the browser.
 */
export const ARTIFACT_IFRAME_SANDBOX = "";

export function HtmlRenderer({
  content,
  title,
  height = "480px",
  className,
}: HtmlRendererProps) {
  return (
    <div className={className}>
      <iframe
        title={title ?? "Artifact preview"}
        srcDoc={content}
        sandbox={ARTIFACT_IFRAME_SANDBOX}
        className="w-full rounded-md border"
        style={{ height }}
      />
      <p className="mt-2 text-xs text-muted-foreground">
        HTML is rendered in a sandboxed iframe. Scripts, forms, and
        cross-origin requests are disabled.
      </p>
    </div>
  );
}
