"use client";

import { useEffect, useState, useCallback } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { apiGet, apiPost, apiPatch, apiDelete, ApiError } from "@/lib/api";

interface Credential {
  id: string;
  provider: string;
  name: string;
  env_var: string;
  value_preview: string;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

interface ProviderDef {
  env_var: string;
  type: string;
}

type KnownProviders = Record<string, ProviderDef>;

const CUSTOM_PROVIDER = "__custom__";

/** Human-friendly labels for provider keys. */
const PROVIDER_LABELS: Record<string, string> = {
  google_sheets: "Google Sheets",
  google_docs: "Google Docs",
  slack: "Slack",
  notion: "Notion",
  sql: "SQL Database",
  http: "HTTP / REST",
  obsidian: "Obsidian Vault",
  python: "Python Execution",
  db_sqlite: "SQLite Database Path",
  db_postgres: "Postgres DSN",
  db_mongodb_uri: "MongoDB URI",
  db_mongodb_database: "MongoDB Database Name",
  db_redis: "Redis URL",
  catalyst: "Mock Data (pycatalyst)",
  stator: "State Machine (pystator)",
};

/** Contextual value field config based on credential type. */
function valueFieldMeta(credType: string): {
  label: string;
  placeholder: string;
  help: string;
} {
  switch (credType) {
    case "file_path":
      return {
        label: "File Path",
        placeholder: "/path/to/service-account.json",
        help: "Absolute path to the credentials file on the server.",
      };
    case "token":
      return {
        label: "API Key / Token",
        placeholder: "sk-... or xoxb-...",
        help: "The API key or bot token for this service.",
      };
    case "connection_string":
      return {
        label: "Connection String",
        placeholder: "postgresql://user:pass@host:5432/dbname",
        help: "Database connection URI.",
      };
    case "url":
      return {
        label: "Base URL",
        placeholder: "https://api.example.com",
        help: "The base URL for API requests.",
      };
    case "text":
      return {
        label: "Value",
        placeholder: "e.g. pandas,numpy,requests",
        help: "Configuration value for this integration.",
      };
    default:
      return {
        label: "Value",
        placeholder: "API key, token, or path",
        help: "",
      };
  }
}

export function CredentialsCard() {
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [providers, setProviders] = useState<KnownProviders>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<string | null>(null);

  // Form state
  const [formProvider, setFormProvider] = useState("");
  const [formName, setFormName] = useState("");
  const [formEnvVar, setFormEnvVar] = useState("");
  const [formValue, setFormValue] = useState("");
  const [formEnabled, setFormEnabled] = useState(true);
  const [showValue, setShowValue] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadCredentials = useCallback(async () => {
    try {
      const data = await apiGet<{ items: Credential[] }>(
        "/api/v1/admin/credentials"
      );
      setCredentials(data.items ?? []);
    } catch (e) {
      if (e instanceof ApiError && e.status === 403) {
        setError("Admin access required to manage credentials.");
      } else if (e instanceof ApiError && e.status === 0) {
        setError("Unable to connect to the API server.");
      } else {
        setError(
          e instanceof Error ? e.message : "Failed to load credentials."
        );
      }
    }
  }, []);

  const loadProviders = useCallback(async () => {
    try {
      const data = await apiGet<{ providers: KnownProviders }>(
        "/api/v1/admin/credentials/providers"
      );
      setProviders(data.providers ?? {});
    } catch {
      // Non-critical: fall back to empty providers
    }
  }, []);

  useEffect(() => {
    async function init() {
      setLoading(true);
      await Promise.all([loadCredentials(), loadProviders()]);
      setLoading(false);
    }
    init();
  }, [loadCredentials, loadProviders]);

  function resetForm() {
    setFormProvider("");
    setFormName("");
    setFormEnvVar("");
    setFormValue("");
    setFormEnabled(true);
    setShowValue(false);
    setEditing(null);
  }

  function handleAdd() {
    resetForm();
    setEditing("new");
  }

  function handleEdit(cred: Credential) {
    setFormProvider(
      Object.keys(providers).includes(cred.provider)
        ? cred.provider
        : CUSTOM_PROVIDER
    );
    setFormName(cred.name);
    setFormEnvVar(cred.env_var);
    setFormValue("");
    setFormEnabled(cred.enabled);
    setShowValue(false);
    setEditing(cred.id);
  }

  function handleProviderChange(value: string) {
    setFormProvider(value);
    if (value !== CUSTOM_PROVIDER && providers[value]) {
      setFormEnvVar(providers[value].env_var);
      if (!formName) {
        setFormName(value);
      }
    } else if (value === CUSTOM_PROVIDER) {
      setFormEnvVar("");
    }
  }

  async function handleSave() {
    setError(null);
    setSaving(true);
    try {
      const provider =
        formProvider === CUSTOM_PROVIDER ? formName : formProvider;
      if (editing === "new") {
        await apiPost<object, Credential>(
          "/api/v1/admin/credentials",
          {
            provider,
            name: formName,
            env_var: formEnvVar,
            value: formValue,
            enabled: formEnabled,
          }
        );
      } else {
        const body: Record<string, unknown> = {
          provider,
          name: formName,
          env_var: formEnvVar,
          enabled: formEnabled,
        };
        if (formValue) {
          body.value = formValue;
        }
        await apiPatch<Record<string, unknown>, Credential>(
          `/api/v1/admin/credentials/${editing}`,
          body
        );
      }
      await loadCredentials();
      resetForm();
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Failed to save credential."
      );
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    setError(null);
    try {
      await apiDelete(`/api/v1/admin/credentials/${id}`);
      await loadCredentials();
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Failed to delete credential."
      );
    }
  }

  const providerKeys = Object.keys(providers);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="space-y-1.5">
            <CardTitle>Integration Credentials</CardTitle>
            <CardDescription>
              Manage API keys and tokens for connected services.
            </CardDescription>
          </div>
          {!editing && (
            <Button size="sm" onClick={handleAdd}>
              + Add
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <div className="rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-800">
            {error}
          </div>
        )}

        {loading && (
          <p className="text-sm text-muted-foreground">
            Loading credentials...
          </p>
        )}

        {/* ---------- Form view (add / edit) ---------- */}
        {editing && (
          <div className="space-y-4 border-t pt-4">
            <h4 className="text-sm font-medium">
              {editing === "new"
                ? "Add Credential"
                : "Edit Credential"}
            </h4>

            {/* Provider select */}
            <div className="space-y-2">
              <label
                htmlFor="cred-provider"
                className="text-sm font-medium"
              >
                Provider
              </label>
              <select
                id="cred-provider"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={formProvider}
                onChange={(e) => handleProviderChange(e.target.value)}
              >
                <option value="">Select a provider...</option>
                {providerKeys.map((key) => (
                  <option key={key} value={key}>
                    {PROVIDER_LABELS[key] ?? key}
                  </option>
                ))}
                <option value={CUSTOM_PROVIDER}>Custom</option>
              </select>
            </div>

            {/* Name + Env Var */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label
                  htmlFor="cred-name"
                  className="text-sm font-medium"
                >
                  Name
                </label>
                <Input
                  id="cred-name"
                  type="text"
                  placeholder="e.g. OpenAI Production"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label
                  htmlFor="cred-env-var"
                  className="text-sm font-medium"
                >
                  Env Var
                </label>
                <Input
                  id="cred-env-var"
                  type="text"
                  placeholder="e.g. OPENAI_API_KEY"
                  className="font-mono text-sm"
                  value={formEnvVar}
                  onChange={(e) => setFormEnvVar(e.target.value)}
                  readOnly={
                    formProvider !== CUSTOM_PROVIDER &&
                    formProvider !== ""
                  }
                />
              </div>
            </div>

            {/* Value — contextual label based on provider type */}
            {(() => {
              const credType =
                formProvider &&
                formProvider !== CUSTOM_PROVIDER &&
                providers[formProvider]
                  ? providers[formProvider].type
                  : "";
              const meta = valueFieldMeta(credType);
              return (
                <div className="space-y-2">
                  <label
                    htmlFor="cred-value"
                    className="text-sm font-medium"
                  >
                    {meta.label}
                  </label>
                  <div className="relative">
                    <Input
                      id="cred-value"
                      type={showValue ? "text" : "password"}
                      placeholder={
                        editing !== "new"
                          ? "Leave blank to keep existing value"
                          : meta.placeholder
                      }
                      className={
                        credType === "file_path" ||
                        credType === "connection_string" ||
                        credType === "url"
                          ? "font-mono text-sm"
                          : ""
                      }
                      value={formValue}
                      onChange={(e) =>
                        setFormValue(e.target.value)
                      }
                    />
                    <button
                      type="button"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground"
                      onClick={() => setShowValue((v) => !v)}
                    >
                      {showValue ? "Hide" : "Show"}
                    </button>
                  </div>
                  {editing !== "new" ? (
                    <p className="text-xs text-muted-foreground">
                      Leave blank to keep the existing value.
                    </p>
                  ) : meta.help ? (
                    <p className="text-xs text-muted-foreground">
                      {meta.help}
                    </p>
                  ) : null}
                </div>
              );
            })()}

            {/* Enabled toggle */}
            <div className="flex items-center gap-2">
              <input
                id="cred-enabled"
                type="checkbox"
                className="h-4 w-4 rounded border-input"
                checked={formEnabled}
                onChange={(e) => setFormEnabled(e.target.checked)}
              />
              <label
                htmlFor="cred-enabled"
                className="text-sm font-medium"
              >
                Enabled
              </label>
            </div>

            {/* Actions */}
            <div className="flex gap-2 border-t pt-4">
              <Button
                variant="outline"
                onClick={resetForm}
                disabled={saving}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={
                  saving ||
                  !formName ||
                  !formEnvVar ||
                  (editing === "new" && !formValue)
                }
              >
                {saving ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        )}

        {/* ---------- List view ---------- */}
        {!loading && !editing && credentials.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No credentials configured yet.
          </p>
        )}

        {!loading && !editing && credentials.length > 0 && (
          <div className="space-y-2">
            {/* Header row */}
            <div className="hidden sm:grid sm:grid-cols-[1fr_1fr_1fr_auto_auto] gap-4 px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
              <span>Provider</span>
              <span>Name</span>
              <span>Env Var</span>
              <span>Status</span>
              <span>Actions</span>
            </div>

            {credentials.map((cred) => (
              <div
                key={cred.id}
                className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_1fr_auto_auto] gap-2 sm:gap-4 items-center rounded-md border px-3 py-3 text-sm"
              >
                <div>
                  <Badge variant="secondary">{cred.provider}</Badge>
                </div>
                <div className="truncate">{cred.name}</div>
                <div className="font-mono text-xs text-muted-foreground truncate">
                  {cred.env_var}
                </div>
                <div>
                  {cred.enabled ? (
                    <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-100">
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary">Disabled</Badge>
                  )}
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(cred)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(cred.id)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
