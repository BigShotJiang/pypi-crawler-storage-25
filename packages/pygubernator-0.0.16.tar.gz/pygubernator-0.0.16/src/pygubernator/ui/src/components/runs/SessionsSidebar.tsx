"use client";

/**
 * Collapsible sidebar that lists cross-workflow sessions on the Runs
 * page. Clicking a session filters the runs list to just that session;
 * clicking the "All runs" reset row removes the filter.
 *
 * The list is paginated server-side; this v1 surface loads the first
 * 25 sessions and exposes a "Show more" button to page through. Keeping
 * pagination in-component (rather than wiring a full Pagination bar)
 * avoids mid-page re-flow as sessions are shown inline with the runs
 * table.
 */

import { useCallback, useEffect, useState } from "react";
import { Check, Clock, Layers, Pencil, RefreshCw, X } from "lucide-react";

import { getAllWorkflowSessions, updateSessionMeta } from "@/lib/api";
import type { WorkflowSessionSummary } from "@/lib/api";
import { cn, formatDateTimeShort } from "@/lib/utils";

export interface SessionsSidebarProps {
  /** Currently-selected session id (from URL query). */
  selectedSessionId: string | null;
  /** Called with a session id to activate the filter, or ``null`` to clear. */
  onSelectSession: (sessionId: string | null) => void;
  /** Optional workflow scope; when set, only sessions from that workflow load. */
  workflowId?: string | null;
  className?: string;
}

const PAGE_SIZE = 25;

/**
 * Pick the human-facing label for a session row.
 *
 * Prefers the user-supplied ``name`` when present; otherwise falls back
 * to the first 12 chars of the raw session id (with an ellipsis when
 * truncation kicked in). Exported for unit tests so the precedence
 * stays pinned.
 */
export function displaySessionLabel(session: WorkflowSessionSummary): string {
  if (session.name && session.name.trim()) return session.name.trim();
  const id = session.session_id;
  return id.length > 12 ? `${id.slice(0, 12)}…` : id;
}

/** Colour for the status pip next to each session row. Exported for unit tests. */
export function statusDotColor(status: string | null): string {
  switch (status) {
    case "completed":
    case "success":
      return "bg-emerald-500";
    case "failed":
    case "error":
      return "bg-red-500";
    case "running":
      return "bg-amber-500";
    case "pending":
      return "bg-slate-400";
    case "cancelled":
      return "bg-slate-500";
    default:
      return "bg-muted";
  }
}

export function SessionsSidebar({
  selectedSessionId,
  onSelectSession,
  workflowId,
  className,
}: SessionsSidebarProps) {
  const [items, setItems] = useState<WorkflowSessionSummary[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (targetPage: number, reset: boolean) => {
      setLoading(true);
      setError(null);
      try {
        const data = await getAllWorkflowSessions({
          page: targetPage,
          page_size: PAGE_SIZE,
          workflow_id: workflowId ?? undefined,
        });
        setTotal(data.meta.total);
        setItems((prev) => (reset ? data.items : [...prev, ...data.items]));
      } catch {
        setError("Could not load sessions");
      } finally {
        setLoading(false);
      }
    },
    [workflowId],
  );

  useEffect(() => {
    setPage(1);
    void load(1, true);
  }, [load]);

  const hasMore = items.length < total;

  return (
    <aside
      className={cn(
        "flex flex-col gap-2 rounded-lg border bg-muted/20 p-3",
        className,
      )}
      aria-label="Sessions"
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Layers className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-medium">Sessions</h3>
          <span className="text-xs text-muted-foreground">({total})</span>
        </div>
        <button
          type="button"
          className="inline-flex items-center gap-1 rounded border border-border/60 bg-background/80 px-1.5 py-0.5 text-xs hover:bg-muted"
          onClick={() => {
            setPage(1);
            void load(1, true);
          }}
          aria-label="Refresh sessions"
          disabled={loading}
        >
          <RefreshCw className={cn("h-3 w-3", loading && "animate-spin")} />
          Refresh
        </button>
      </div>

      {error ? (
        <p className="text-xs text-red-600">{error}</p>
      ) : null}

      <ul className="flex flex-col gap-1">
        <li>
          <button
            type="button"
            onClick={() => onSelectSession(null)}
            aria-pressed={selectedSessionId === null}
            className={cn(
              "flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm transition-colors hover:bg-muted",
              selectedSessionId === null && "bg-muted font-medium",
            )}
          >
            <span className="h-2 w-2 shrink-0 rounded-full bg-primary/50" />
            All runs
          </button>
        </li>
        {items.map((sess) => (
          <SessionRow
            key={sess.session_id}
            session={sess}
            isSelected={selectedSessionId === sess.session_id}
            onSelect={() => onSelectSession(sess.session_id)}
            onRenamed={(newName) => {
              setItems((prev) =>
                prev.map((s) =>
                  s.session_id === sess.session_id
                    ? { ...s, name: newName }
                    : s,
                ),
              );
            }}
          />
        ))}
      </ul>

      {!error && items.length === 0 && !loading && (
        <p className="text-xs text-muted-foreground">
          No sessions yet. Sessions are created when a run is started with a
          <code className="mx-1 rounded bg-muted px-1 py-0.5 font-mono text-[10px]">
            session_id
          </code>
          so follow-up runs can share memory.
        </p>
      )}

      {hasMore && (
        <button
          type="button"
          className="mt-1 text-xs text-primary underline-offset-2 hover:underline"
          onClick={() => {
            const next = page + 1;
            setPage(next);
            void load(next, false);
          }}
          disabled={loading}
        >
          Show more
        </button>
      )}
    </aside>
  );
}

interface SessionRowProps {
  session: WorkflowSessionSummary;
  isSelected: boolean;
  onSelect: () => void;
  onRenamed: (newName: string | null) => void;
}

/**
 * One session list item with optional inline rename.
 *
 * Click the row to filter runs by that session; click the pencil icon
 * (visible on the selected row only) to flip into a small rename
 * editor that calls ``updateSessionMeta`` on save and merges the new
 * name back into the parent's local state via ``onRenamed``.
 */
function SessionRow({
  session,
  isSelected,
  onSelect,
  onRenamed,
}: SessionRowProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<string>(session.name ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const beginEdit = (event: React.MouseEvent) => {
    event.stopPropagation();
    setDraft(session.name ?? "");
    setError(null);
    setEditing(true);
  };

  const cancelEdit = (event: React.MouseEvent) => {
    event.stopPropagation();
    setEditing(false);
    setError(null);
  };

  const submit = async (event: React.MouseEvent | React.KeyboardEvent) => {
    event.stopPropagation();
    setSaving(true);
    setError(null);
    try {
      const result = await updateSessionMeta(session.session_id, {
        // The route treats empty string as "clear" — that's the desired
        // behaviour when a user wipes the input box.
        name: draft.trim() === "" ? "" : draft.trim(),
      });
      onRenamed(result.name);
      setEditing(false);
    } catch {
      setError("Could not save name");
    } finally {
      setSaving(false);
    }
  };

  const label = displaySessionLabel(session);

  return (
    <li>
      <div
        className={cn(
          "flex w-full flex-col gap-0.5 rounded px-2 py-1.5 text-left transition-colors hover:bg-muted",
          isSelected && "bg-muted",
        )}
      >
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "h-2 w-2 shrink-0 rounded-full",
              statusDotColor(session.last_status),
            )}
          />
          {editing ? (
            <input
              type="text"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void submit(e);
                } else if (e.key === "Escape") {
                  e.preventDefault();
                  setEditing(false);
                }
              }}
              autoFocus
              disabled={saving}
              placeholder={session.session_id.slice(0, 12)}
              aria-label="Session name"
              className="flex-1 min-w-0 rounded border bg-background px-1 py-0.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          ) : (
            <button
              type="button"
              className="flex-1 min-w-0 truncate text-left text-sm font-medium"
              onClick={onSelect}
              aria-pressed={isSelected}
              title={session.session_id}
            >
              {label}
            </button>
          )}
          {isSelected && !editing ? (
            <button
              type="button"
              onClick={beginEdit}
              className="shrink-0 rounded p-0.5 text-muted-foreground hover:bg-background hover:text-foreground"
              aria-label="Rename session"
            >
              <Pencil className="h-3 w-3" />
            </button>
          ) : null}
          {editing ? (
            <>
              <button
                type="button"
                onClick={(e) => void submit(e)}
                className="shrink-0 rounded p-0.5 text-emerald-600 hover:bg-background"
                aria-label="Save session name"
                disabled={saving}
              >
                <Check className="h-3 w-3" />
              </button>
              <button
                type="button"
                onClick={cancelEdit}
                className="shrink-0 rounded p-0.5 text-muted-foreground hover:bg-background"
                aria-label="Cancel rename"
                disabled={saving}
              >
                <X className="h-3 w-3" />
              </button>
            </>
          ) : null}
        </div>
        <button
          type="button"
          onClick={onSelect}
          className="flex items-center justify-between gap-2 text-[10px] text-muted-foreground"
        >
          <span className="truncate">{session.workflow_name}</span>
          <span className="shrink-0 flex items-center gap-1">
            <Clock className="h-2.5 w-2.5" />
            {formatDateTimeShort(session.last_run_at)}
          </span>
        </button>
        <div className="text-[10px] text-muted-foreground">
          {session.run_count} run{session.run_count === 1 ? "" : "s"}
          {session.last_status ? ` · ${session.last_status}` : ""}
        </div>
        {error ? (
          <p className="text-[10px] text-red-600">{error}</p>
        ) : null}
      </div>
    </li>
  );
}
