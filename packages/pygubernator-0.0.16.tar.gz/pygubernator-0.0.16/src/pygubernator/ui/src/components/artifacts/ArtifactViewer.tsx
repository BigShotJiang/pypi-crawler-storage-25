"use client";

/**
 * Top-level artifact viewer used on the Runs detail view and (Phase
 * 6 §6.1c) the Chat page.
 *
 * Given an artifact summary + its parent run id, the viewer fetches the
 * content on mount via ``getArtifactContent`` and dispatches to the
 * type-specific renderer. Renderer modules stay small and
 * single-responsibility so a regression in one (e.g. CSV parsing) can
 * never break an unrelated type (e.g. HTML).
 *
 * Refetch triggers on ``artifact.updated_at`` so live-reload flows —
 * where a long-running node emits a skeleton then streams in the
 * finished payload — transparently re-fetch when the timestamp moves.
 */

import { type ReactNode, useEffect, useState } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";

import {
  type WorkflowArtifactContent,
  type WorkflowArtifactSummary,
  ApiError,
  getArtifactContent,
} from "@/lib/api";
import { ArtifactQueryPanel } from "./ArtifactQueryPanel";
import { HtmlRenderer } from "./renderers/HtmlRenderer";
import { ImageRenderer } from "./renderers/ImageRenderer";
import { JsonRenderer } from "./renderers/JsonRenderer";
import { MarkdownRenderer } from "./renderers/MarkdownRenderer";
import { TableRenderer } from "./renderers/TableRenderer";
import { TextRenderer } from "./renderers/TextRenderer";

export interface ArtifactViewerProps {
  /** Summary row from the list endpoint — tells us what type to render. */
  artifact: WorkflowArtifactSummary;
  /** Run id — needed to build the content route URL. */
  runId: string;
  className?: string;
}

/**
 * Renderer discriminator. Exported so tests and other call sites can
 * verify dispatch without mounting React.
 */
export type ArtifactRendererKind =
  | "markdown"
  | "table"
  | "html"
  | "image"
  | "json"
  | "text";

/**
 * Map an artifact's declared ``artifact_type`` to the renderer we will
 * use. Unknown types fall through to the plain-text renderer so the user
 * still sees *something*, and the unknown type is preserved in the
 * viewer header so they know what was served.
 */
export function pickRenderer(artifactType: string): ArtifactRendererKind {
  switch (artifactType) {
    case "markdown":
      return "markdown";
    case "table":
    case "csv":
      return "table";
    case "html":
      return "html";
    case "image":
      return "image";
    case "json":
      return "json";
    default:
      // Notebook, text, and any future type land here until we add a
      // dedicated renderer for them.
      return "text";
  }
}

function renderBody(
  renderer: ArtifactRendererKind,
  payload: WorkflowArtifactContent,
  title: string | null,
): ReactNode {
  switch (renderer) {
    case "markdown":
      return <MarkdownRenderer content={payload.content} />;
    case "table":
      return <TableRenderer content={payload.content} />;
    case "html":
      return (
        <HtmlRenderer content={payload.content} title={title ?? undefined} />
      );
    case "image":
      return (
        <ImageRenderer
          content={payload.content}
          encoding={payload.encoding}
          mime={payload.mime}
          title={title ?? undefined}
        />
      );
    case "json":
      return <JsonRenderer content={payload.content} />;
    default:
      return <TextRenderer content={payload.content} />;
  }
}

export function ArtifactViewer({
  artifact,
  runId,
  className,
}: ArtifactViewerProps) {
  const [content, setContent] = useState<WorkflowArtifactContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    void (async () => {
      try {
        const payload = await getArtifactContent(runId, artifact.id);
        if (!cancelled) {
          setContent(payload);
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof ApiError ? err.message : "Could not load artifact",
          );
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // Refetch when the artifact row is mutated server-side (updated_at
    // moves whenever ``update_artifact_content`` is called).
  }, [runId, artifact.id, artifact.updated_at]);

  const renderer = pickRenderer(artifact.artifact_type);
  const headerSuffix =
    renderer === "text" && artifact.artifact_type !== "text"
      ? ` · rendered as text (unknown type "${artifact.artifact_type}")`
      : "";

  return (
    <div className={className}>
      <div className="mb-2 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate font-medium text-sm">
            {artifact.title || `Artifact #${artifact.sequence_num + 1}`}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {artifact.artifact_type}
            {artifact.mime ? ` · ${artifact.mime}` : ""}
            {headerSuffix}
          </p>
        </div>
        {loading && (
          <RefreshCw className="h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 p-2 text-xs text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
          <AlertCircle className="mt-0.5 h-3 w-3 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {!error && content && renderBody(renderer, content, artifact.title)}

      {!error && content && renderer === "table" && artifact.has_content ? (
        <ArtifactQueryPanel
          runId={runId}
          artifactId={artifact.id}
          className="mt-4 rounded-md border bg-muted/20 p-3"
        />
      ) : null}

      {!error && !content && !loading && (
        <p className="text-sm text-muted-foreground">
          No content available for this artifact.
        </p>
      )}
    </div>
  );
}
