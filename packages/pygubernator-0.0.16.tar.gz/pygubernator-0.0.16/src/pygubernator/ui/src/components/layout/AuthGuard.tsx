"use client";

import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";

import LoadingSpinner from "@/components/LoadingSpinner";
import { ROUTES } from "@/lib/constants";
import {
  selectApiUnavailable,
  selectAuthDisabled,
  selectLoading,
  selectUser,
  useAuthStore
} from "@/stores/auth";

const RETURN_URL_KEY = "pygubernator_return_url";

function isPublicPath(pathname: string | null): boolean {
  if (!pathname) return false;
  const normalized = pathname.replace(/\/+$/, "") || "/";
  return normalized === ROUTES.LOGIN || normalized === ROUTES.SETTINGS.replace(/\/+$/, "");
}

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const user = useAuthStore(selectUser);
  const loading = useAuthStore(selectLoading);
  const authDisabled = useAuthStore(selectAuthDisabled);
  const apiUnavailable = useAuthStore(selectApiUnavailable);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (isPublicPath(pathname)) return;
    if (apiUnavailable || authDisabled || user) return;
    sessionStorage.setItem(RETURN_URL_KEY, pathname || ROUTES.HOME);
    router.replace(ROUTES.LOGIN);
  }, [loading, pathname, user, authDisabled, apiUnavailable, router]);

  if (isPublicPath(pathname)) {
    return <>{children}</>;
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <LoadingSpinner />
      </div>
    );
  }

  if (apiUnavailable || authDisabled || user) {
    return <>{children}</>;
  }

  return null;
}
