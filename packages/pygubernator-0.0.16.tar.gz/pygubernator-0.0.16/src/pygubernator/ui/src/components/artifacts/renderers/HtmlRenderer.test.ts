import { describe, expect, it } from "vitest";

import { ARTIFACT_IFRAME_SANDBOX } from "./HtmlRenderer";

describe("ARTIFACT_IFRAME_SANDBOX", () => {
  /*
   * The HTML artifact renderer must ship with the tightest possible
   * sandbox so artifact content cannot access cookies, run scripts, or
   * navigate the host tab.
   *
   * Encoding an empty string as the ``sandbox`` attribute value applies
   * *all* sandbox restrictions. These tests guard against an accidental
   * loosening (e.g. adding ``allow-scripts`` during debugging).
   */

  it("is an empty string (all restrictions enabled)", () => {
    expect(ARTIFACT_IFRAME_SANDBOX).toBe("");
  });

  it.each([
    "allow-scripts",
    "allow-same-origin",
    "allow-top-navigation",
    "allow-popups",
    "allow-forms",
    "allow-modals",
  ])("must not contain %s", (flag) => {
    expect(ARTIFACT_IFRAME_SANDBOX).not.toContain(flag);
  });
});
