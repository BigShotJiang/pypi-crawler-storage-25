"use client";

/**
 * Compact run summary tile used in the Guide thread (Phase 6 §6.7c).
 *
 * One card per dispatched run — shows status pip, workflow name,
 * elapsed time, and any error preview. Clicking the card surfaces the
 * underlying run (the parent fires ``onSelect``) so the right-pane
 * artifact viewer focuses on it.
 */

import Link from "next/link";
import { CircleAlert, CircleCheck, CircleDashed, Loader2 } from "lucide-react";

import { ROUTES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { GuideRunSummary } from "@/lib/api";

export interface GuideRunCardProps {
  run: GuideRunSummary;
  isSelected: boolean;
  onSelect: () => void;
}

/**
 * Render the right icon + colour for a run status. Exported so tests
 * can pin the mapping without mounting React, and so future surfaces
 * (e.g. the Runs sidebar) can reuse the same vocabulary.
 */
export function statusVisuals(status: string): {
  Icon: typeof CircleCheck;
  className: string;
  spin: boolean;
} {
  switch (status) {
    case "completed":
    case "success":
      return {
        Icon: CircleCheck,
        className: "text-emerald-600 dark:text-emerald-400",
        spin: false,
      };
    case "failed":
    case "error":
      return {
        Icon: CircleAlert,
        className: "text-red-600 dark:text-red-400",
        spin: false,
      };
    case "running":
      return {
        Icon: Loader2,
        className: "text-amber-600 dark:text-amber-400",
        spin: true,
      };
    default:
      return {
        Icon: CircleDashed,
        className: "text-muted-foreground",
        spin: false,
      };
  }
}

function formatElapsed(durationMs: number | null): string {
  if (durationMs == null) return "—";
  if (durationMs < 1000) return `${durationMs}ms`;
  return `${(durationMs / 1000).toFixed(1)}s`;
}

export function GuideRunCard({
  run,
  isSelected,
  onSelect,
}: GuideRunCardProps) {
  const { Icon, className, spin } = statusVisuals(run.status);
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={isSelected}
      className={cn(
        "flex w-full items-start gap-2 rounded-md border bg-card px-3 py-2 text-left transition-colors hover:bg-muted/60",
        isSelected && "ring-2 ring-primary",
      )}
    >
      <Icon
        className={cn("mt-0.5 h-4 w-4 shrink-0", className, spin && "animate-spin")}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="truncate text-sm font-medium">
            {run.workflow_name || run.workflow_id.slice(0, 8)}
          </span>
          <span className="shrink-0 text-[10px] font-mono text-muted-foreground">
            {formatElapsed(run.duration_ms)}
          </span>
        </div>
        <div className="flex items-baseline justify-between gap-2 text-[10px] text-muted-foreground">
          <span className="truncate">run {run.id.slice(0, 8)}…</span>
          <Link
            className="shrink-0 underline-offset-2 hover:underline"
            href={`${ROUTES.RUNS}?run_id=${run.id}`}
            onClick={(e) => e.stopPropagation()}
          >
            Open
          </Link>
        </div>
        {run.error_message ? (
          <p className="mt-1 truncate text-[11px] text-red-600 dark:text-red-400">
            {run.error_message}
          </p>
        ) : null}
      </div>
    </button>
  );
}
