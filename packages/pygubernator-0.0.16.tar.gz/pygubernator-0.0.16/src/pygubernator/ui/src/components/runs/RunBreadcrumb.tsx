"use client";

/**
 * Breadcrumb shown above the run-detail header (Phase 6 §6.8b).
 *
 * When a run is part of a multi-turn session, render a clickable
 * "session → run" trail so the user can hop back to the sidebar
 * filter without losing context. The session crumb fetches its
 * user-supplied display name when one exists; otherwise the raw id
 * (truncated) acts as the label.
 */

import { useEffect, useState } from "react";
import Link from "next/link";
import { ChevronRight, Layers } from "lucide-react";

import { ROUTES } from "@/lib/constants";
import { getSessionMeta } from "@/lib/api";

export interface RunBreadcrumbProps {
  /** Session id pulled from ``run.session_id``. ``null`` hides the crumb. */
  sessionId: string | null;
  /** Run id for the trailing crumb. */
  runId: string;
  /** Optional workflow id, propagated as a sidebar query filter. */
  workflowId?: string | null;
}

function fallbackLabel(sessionId: string): string {
  return sessionId.length > 12
    ? `${sessionId.slice(0, 12)}…`
    : sessionId;
}

export function RunBreadcrumb({
  sessionId,
  runId,
  workflowId,
}: RunBreadcrumbProps) {
  const [name, setName] = useState<string | null>(null);

  useEffect(() => {
    if (!sessionId) {
      setName(null);
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const meta = await getSessionMeta(sessionId);
        if (!cancelled) setName(meta.name ?? null);
      } catch {
        if (!cancelled) setName(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  if (!sessionId) return null;

  // Build the Runs-list URL filtered to this session so clicking the
  // session crumb returns the user to the sidebar context.
  const params = new URLSearchParams();
  if (workflowId) params.set("workflow_id", workflowId);
  params.set("session_id", sessionId);
  const sessionHref = `${ROUTES.RUNS}?${params.toString()}`;
  const sessionLabel = name && name.trim() ? name.trim() : fallbackLabel(sessionId);

  return (
    <nav
      aria-label="Run breadcrumb"
      className="mb-2 flex items-center gap-1 text-xs text-muted-foreground"
    >
      <Layers className="h-3 w-3 shrink-0" />
      <Link
        href={sessionHref}
        className="font-medium hover:underline"
      >
        {sessionLabel}
      </Link>
      <ChevronRight className="h-3 w-3 shrink-0" />
      <span className="font-mono">run {runId.slice(0, 8)}…</span>
    </nav>
  );
}
