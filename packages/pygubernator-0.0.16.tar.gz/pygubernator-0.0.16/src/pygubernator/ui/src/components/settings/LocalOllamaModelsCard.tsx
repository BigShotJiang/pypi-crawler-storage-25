"use client";

import { useCallback, useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ApiError,
  deleteLocalOllamaModel,
  getLocalOllamaStatus,
  pullLocalOllamaModel,
  type LocalOllamaStatusResponse,
} from "@/lib/api";
import { selectIsAdmin, useAuthStore } from "@/stores/auth";
import { CheckCircle2, Loader2, Trash2, XCircle } from "lucide-react";

const DEFAULT_BASE = "http://127.0.0.1:11434";

function formatBytes(n: number | null | undefined): string {
  if (n == null || n <= 0) return "—";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  const decimals = v < 10 && i > 0 ? 1 : 0;
  return `${v.toFixed(decimals)} ${units[i]}`;
}

function getApiErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof ApiError) return error.message || fallback;
  if (error instanceof Error) return error.message || fallback;
  return fallback;
}

export function LocalOllamaModelsCard() {
  const isAdmin = useAuthStore(selectIsAdmin);
  const [baseDraft, setBaseDraft] = useState(DEFAULT_BASE);
  const [status, setStatus] = useState<LocalOllamaStatusResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);

  const [pullOpen, setPullOpen] = useState(false);
  const [pullName, setPullName] = useState("");
  const [pullBusy, setPullBusy] = useState(false);
  const [pullError, setPullError] = useState<string | null>(null);

  const basePayload = useCallback(() => {
    const t = baseDraft.trim();
    return t ? { base_url: t } : {};
  }, [baseDraft]);

  const refresh = useCallback(async () => {
    setLoading(true);
    setListError(null);
    try {
      const t = baseDraft.trim();
      const res = await getLocalOllamaStatus(t || undefined);
      setStatus(res);
    } catch (e) {
      setStatus(null);
      setListError(getApiErrorMessage(e, "Failed to load Ollama status"));
    } finally {
      setLoading(false);
    }
  }, [baseDraft]);

  useEffect(() => {
    void refresh();
    // Intentionally load once on mount; user refreshes after editing base URL.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePull = async () => {
    if (!pullName.trim()) {
      setPullError("Enter a model name (e.g. llama3.2 or mistral:7b).");
      return;
    }
    setPullBusy(true);
    setPullError(null);
    try {
      const res = await pullLocalOllamaModel({
        ...basePayload(),
        name: pullName.trim(),
      });
      if (!res.ok) {
        setPullError(res.detail || "Pull failed");
        return;
      }
      setPullOpen(false);
      setPullName("");
      await refresh();
    } catch (e) {
      setPullError(getApiErrorMessage(e, "Pull failed"));
    } finally {
      setPullBusy(false);
    }
  };

  const handleDelete = async (name: string) => {
    if (
      !window.confirm(
        `Remove model "${name}" from Ollama on this server? This cannot be undone.`
      )
    ) {
      return;
    }
    try {
      const res = await deleteLocalOllamaModel({ ...basePayload(), name });
      if (!res.ok) {
        setListError(res.detail || "Delete failed");
        return;
      }
      await refresh();
    } catch (e) {
      setListError(getApiErrorMessage(e, "Delete failed"));
    }
  };

  const reachable = status?.reachable === true;
  const models = status?.models ?? [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Local models (Ollama)</CardTitle>
        <CardDescription>
          The control plane API talks to Ollama from the machine where the API runs
          (not from your browser). Use{" "}
          <code className="text-xs bg-muted px-1 py-0.5 rounded">
            host.docker.internal
          </code>{" "}
          instead of <code className="text-xs bg-muted px-1 py-0.5 rounded">localhost</code>{" "}
          when the API runs in Docker and Ollama runs on the host.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium" htmlFor="ollama-base-url">
            Ollama base URL
          </label>
          <Input
            id="ollama-base-url"
            placeholder={DEFAULT_BASE}
            value={baseDraft}
            onChange={(e) => setBaseDraft(e.target.value)}
          />
          <p className="text-[11px] text-muted-foreground">
            Native API root (not <code className="text-xs">.../v1</code>). Paste{" "}
            <code className="text-xs">http://localhost:11434/v1</code> and it will be normalized.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button type="button" variant="secondary" onClick={() => void refresh()} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking…
              </>
            ) : (
              "Refresh"
            )}
          </Button>
          {status && (
            <span className="inline-flex items-center gap-1.5 text-sm">
              {reachable ? (
                <>
                  <CheckCircle2 className="h-4 w-4 text-green-600" aria-hidden />
                  <span>Reachable</span>
                </>
              ) : (
                <>
                  <XCircle className="h-4 w-4 text-destructive" aria-hidden />
                  <span>Not reachable</span>
                </>
              )}
              <span className="text-muted-foreground">({status.base_url})</span>
            </span>
          )}
        </div>

        {listError && (
          <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
            {listError}
          </div>
        )}

        {status?.error && !listError && (
          <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
            {status.error}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-muted-foreground">
            {models.length} model{models.length === 1 ? "" : "s"} installed
          </p>
          <Button
            type="button"
            onClick={() => {
              setPullError(null);
              setPullOpen(true);
            }}
            disabled={!isAdmin}
            title={!isAdmin ? "Administrator role required" : undefined}
          >
            Pull model…
          </Button>
        </div>
        {!isAdmin && (
          <p className="text-[11px] text-muted-foreground">
            Pulling and deleting models requires an administrator account.
          </p>
        )}

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Size</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {models.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} className="text-muted-foreground">
                  {reachable
                    ? "No models yet. Pull one or run ollama pull from a terminal."
                    : "Connect to Ollama above, then refresh."}
                </TableCell>
              </TableRow>
            ) : (
              models.map((m) => (
                <TableRow key={m.name}>
                  <TableCell className="font-mono text-xs">{m.name}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {formatBytes(m.size ?? undefined)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="text-destructive hover:text-destructive"
                      disabled={!isAdmin}
                      onClick={() => void handleDelete(m.name)}
                      aria-label={`Delete ${m.name}`}
                      title={!isAdmin ? "Administrator role required" : "Remove model"}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        <Dialog open={pullOpen} onOpenChange={setPullOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Pull model</DialogTitle>
            </DialogHeader>
            <div className="space-y-2 py-2">
              <label className="text-sm font-medium" htmlFor="pull-model-name">
                Model name
              </label>
              <Input
                id="pull-model-name"
                placeholder="llama3.2, mistral, qwen2.5:7b…"
                value={pullName}
                onChange={(e) => setPullName(e.target.value)}
              />
              {pullError && (
                <p className="text-sm text-destructive" role="alert">
                  {pullError}
                </p>
              )}
              <p className="text-[11px] text-muted-foreground">
                Large downloads can take several minutes; keep this tab open until finished.
              </p>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPullOpen(false)}>
                Cancel
              </Button>
              <Button type="button" onClick={() => void handlePull()} disabled={pullBusy}>
                {pullBusy ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Pulling…
                  </>
                ) : (
                  "Pull"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
