"use client";

import { useCallback, useEffect, useState } from "react";
import { Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { apiGet, apiDelete, ApiError } from "@/lib/api";
import { cn } from "@/lib/utils";

interface ChatSession {
  id: string;
  title: string;
  model: string;
  message_count: number;
  created_at: string;
  updated_at: string;
}

interface ChatSessionListProps {
  selectedId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  refreshTrigger: number;
}

export function ChatSessionList({
  selectedId,
  onSelect,
  onNewChat,
  refreshTrigger,
}: ChatSessionListProps) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadSessions = useCallback(async () => {
    try {
      const data = await apiGet<{ items: ChatSession[] }>(
        "/api/v1/chat/sessions"
      );
      setSessions(data.items);
    } catch (e) {
      if (e instanceof ApiError && e.status === 0) {
        setError("Unable to connect to API.");
      } else {
        setError(e instanceof Error ? e.message : "Failed to load sessions.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSessions();
  }, [loadSessions, refreshTrigger]);

  const handleDelete = useCallback(
    async (e: React.MouseEvent, sessionId: string) => {
      e.stopPropagation();
      const confirmed = window.confirm("Delete this chat session?");
      if (!confirmed) return;
      try {
        await apiDelete(`/api/v1/chat/sessions/${sessionId}`);
        await loadSessions();
        if (selectedId === sessionId) {
          onSelect("");
        }
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to delete session."
        );
      }
    },
    [loadSessions, selectedId, onSelect]
  );

  return (
    <div className="flex flex-col h-full border-r border-border">
      <div className="p-3 border-b border-border">
        <Button size="sm" className="w-full" onClick={onNewChat}>
          + New Chat
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {loading && (
          <p className="p-3 text-sm text-muted-foreground">Loading...</p>
        )}
        {error && (
          <p className="p-3 text-sm text-red-600">{error}</p>
        )}
        {!loading && sessions.length === 0 && (
          <p className="p-3 text-sm text-muted-foreground">
            No chat sessions yet.
          </p>
        )}
        {sessions.map((session) => (
          <button
            key={session.id}
            type="button"
            onClick={() => onSelect(session.id)}
            className={cn(
              "w-full text-left px-3 py-2.5 border-b border-border",
              "hover:bg-muted/50 transition-colors group",
              selectedId === session.id && "bg-muted"
            )}
          >
            <div className="flex items-start justify-between gap-1">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {session.title}
                </p>
                <p className="text-xs text-muted-foreground truncate">
                  {session.model} &middot; {session.message_count} msgs
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "h-6 w-6 p-0 opacity-0 group-hover:opacity-100",
                  "text-destructive hover:text-destructive"
                )}
                onClick={(e) => void handleDelete(e, session.id)}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
