"use client";

import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Clock, Loader2, Sparkles } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ApiError } from "@/lib/api";
import { kbApi, type BindingEvent } from "@/lib/api/kb";

interface KBBindingHistoryPanelProps {
  /** Chunk id — becomes the ``field_path=chunk:{id}`` filter. */
  chunkId: string;
  /** Contract id for extra filtering; falls back to chunk-only when null. */
  contractId: string | null;
}

/**
 * Timeline of binding-lifecycle events for a single chunk.
 *
 * Pulls ``/api/v1/kb/bindings/events?field_path=chunk:{id}`` (proxied to
 * pycharter's `/semantic/bindings/events`). Each row shows the state
 * transition, the actor, and the audit reason. Oldest first.
 *
 * Layout is pure document flow: one ``<ol>`` with each event as an
 * ``<li>`` grid row. No absolute positioning.
 */
export default function KBBindingHistoryPanel({
  chunkId,
  contractId
}: KBBindingHistoryPanelProps) {
  const [events, setEvents] = useState<BindingEvent[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setStatus("loading");
    setError(null);
    try {
      const res = await kbApi.bindingEvents({
        field_path: `chunk:${chunkId}`,
        contract_id: contractId ?? undefined
      });
      setEvents(res.items);
      setStatus("idle");
    } catch (exc) {
      setEvents([]);
      setStatus("error");
      setError(
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Failed to load history"
      );
    }
  }, [chunkId, contractId]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          <Clock className="h-3.5 w-3.5" aria-hidden="true" />
          Binding history
        </div>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          onClick={() => void load()}
          disabled={status === "loading"}
          className="text-xs"
        >
          {status === "loading" ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
          ) : null}
          Refresh
        </Button>
      </div>

      {status === "error" && (
        <p className="rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
          {error ?? "Could not load history"}
        </p>
      )}

      {status === "idle" && events.length === 0 && (
        <p className="text-xs text-muted-foreground">
          No binding events recorded yet for this chunk. Promote the binding to
          log one.
        </p>
      )}

      {events.length > 0 && (
        <ol className="flex flex-col gap-2">
          {events.map((event) => (
            <li
              key={`${event.timestamp}|${event.concept_id}|${event.to_state}`}
              className="flex flex-col gap-1 rounded-md border bg-background px-3 py-2 text-xs"
            >
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge variant="outline" className="font-normal">
                  {event.from_state}
                </Badge>
                <ArrowRight
                  className="h-3 w-3 shrink-0 text-muted-foreground"
                  aria-hidden="true"
                />
                <Badge
                  variant="outline"
                  className={`font-normal ${
                    event.to_state === "approved"
                      ? "border-emerald-500/50 text-emerald-600"
                      : event.to_state === "unmapped"
                        ? "border-muted-foreground/40 text-muted-foreground"
                        : ""
                  }`}
                >
                  {event.to_state}
                </Badge>
                <span className="ml-auto text-[11px] text-muted-foreground">
                  {new Date(event.timestamp).toLocaleString()}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Sparkles className="h-3 w-3" aria-hidden="true" />
                  {event.concept_id}
                </span>
                <span>actor: {event.actor || "—"}</span>
                {event.reason && <span>• {event.reason}</span>}
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
