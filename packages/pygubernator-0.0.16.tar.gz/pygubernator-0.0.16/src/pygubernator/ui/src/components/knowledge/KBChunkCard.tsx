"use client";

import { BookMarked, KeyRound, Scale } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { KBChunk } from "@/lib/api/kb";

interface KBChunkCardProps {
  chunk: KBChunk;
  /** When true, renders a score badge (for search results). */
  showScore?: boolean;
  /** Highlights the card — use when the chunk is selected in the drawer. */
  selected?: boolean;
  onSelect: (chunk: KBChunk) => void;
}

const BINDING_COLOURS: Record<KBChunk["binding_state"], string> = {
  unmapped: "border-muted-foreground/30 text-muted-foreground",
  suggested: "border-amber-500/40 text-amber-700 dark:text-amber-300",
  mapped: "border-emerald-500/40 text-emerald-700 dark:text-emerald-300",
  approved: "border-primary/40 text-primary"
};

export default function KBChunkCard({
  chunk,
  showScore = false,
  selected = false,
  onSelect
}: KBChunkCardProps) {
  const preview = chunk.text.length > 280 ? `${chunk.text.slice(0, 280)}…` : chunk.text;
  const badgeClass = BINDING_COLOURS[chunk.binding_state];

  return (
    <button
      type="button"
      onClick={() => onSelect(chunk)}
      className={cn(
        "w-full rounded-lg text-left transition-shadow",
        "hover:shadow-md focus-visible:outline-none focus-visible:ring-2",
        "focus-visible:ring-primary",
        selected && "ring-2 ring-primary"
      )}
    >
      <Card className="flex w-full flex-col gap-3 border-border/60 p-4">
        <div className="flex items-center gap-2 text-xs">
          <Badge variant="outline" className={cn("font-normal", badgeClass)}>
            {chunk.binding_state}
          </Badge>
          {showScore && (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <Scale className="h-3 w-3" aria-hidden="true" />
              {chunk.score.toFixed(3)}
            </span>
          )}
          {chunk.contract_id && (
            <span className="inline-flex items-center gap-1 text-muted-foreground">
              <BookMarked className="h-3 w-3" aria-hidden="true" />
              {chunk.contract_id}
            </span>
          )}
          {chunk.source_uri && (
            <span className="truncate text-muted-foreground">
              · {chunk.source_uri}
            </span>
          )}
        </div>
        <p className="whitespace-pre-wrap text-sm leading-relaxed">{preview}</p>
        {chunk.concept_refs.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
            <KeyRound
              className="h-3 w-3 text-muted-foreground"
              aria-hidden="true"
            />
            {chunk.concept_refs.map((concept) => (
              <Badge key={concept} variant="outline" className="font-normal">
                {concept}
              </Badge>
            ))}
          </div>
        )}
      </Card>
    </button>
  );
}
