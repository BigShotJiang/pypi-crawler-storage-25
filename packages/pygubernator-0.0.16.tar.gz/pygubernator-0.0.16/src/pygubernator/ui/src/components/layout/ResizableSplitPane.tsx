"use client";

/**
 * ResizableSplitPane – two-column resizable layout with localStorage persistence.
 *
 * Renders a horizontal split-pane on wide viewports (lg+ when `responsive=true`)
 * and stacks vertically on narrow viewports. Pane sizes persist across reloads
 * under the provided `storageKey`.
 *
 * Designed for "list + detail" pages (e.g. Runs detail: DAG/steps on the left,
 * step detail panel on the right). For the sidebar+main shell layout, use
 * `ResizableWorkspaceLayout` instead.
 */

import {
  type ReactNode,
  useCallback,
  useEffect,
  useState,
} from "react";
import {
  Panel,
  Group,
  Separator,
  type PanelSize,
} from "react-resizable-panels";

import { cn } from "@/lib/utils";

export interface ResizableSplitPaneProps {
  /** Left pane content. */
  leftPane: ReactNode;
  /** Right pane content. */
  rightPane: ReactNode;
  /** localStorage key used to persist pane sizes. Required. */
  storageKey: string;
  /** Default left pane size as a percentage (0-100). Defaults to 65. */
  defaultLeftSize?: number;
  /** Minimum left pane size as a percentage. Defaults to 30. */
  minLeftSize?: number;
  /** Minimum right pane size as a percentage. Defaults to 20. */
  minRightSize?: number;
  /** CSS height for the split-pane container. Defaults to calc(100vh - 14rem). */
  height?: string;
  /** Stack vertically below `lg` when true (default). */
  responsive?: boolean;
  /** Optional className for the root container. */
  className?: string;
}

/** Read a persisted left-pane size from localStorage, ignoring invalid values. */
export function readStoredSplitSize(
  key: string,
  fallback: number,
): number {
  if (typeof window === "undefined") {
    return fallback;
  }
  try {
    const raw = window.localStorage.getItem(key);
    if (raw == null) {
      return fallback;
    }
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || parsed <= 0 || parsed >= 100) {
      return fallback;
    }
    return parsed;
  } catch {
    return fallback;
  }
}

/** Persist a left-pane size to localStorage. Errors are swallowed. */
export function writeStoredSplitSize(key: string, value: number): void {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.localStorage.setItem(key, String(Math.round(value * 100) / 100));
  } catch {
    // ignore quota/private-mode errors
  }
}

export function ResizableSplitPane({
  leftPane,
  rightPane,
  storageKey,
  defaultLeftSize = 65,
  minLeftSize = 30,
  minRightSize = 20,
  height = "calc(100vh - 14rem)",
  responsive = true,
  className,
}: ResizableSplitPaneProps) {
  // Resolve persisted size only after mount to avoid SSR hydration mismatches.
  const [initialLeftSize, setInitialLeftSize] =
    useState<number>(defaultLeftSize);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setInitialLeftSize(readStoredSplitSize(storageKey, defaultLeftSize));
    setIsHydrated(true);
  }, [storageKey, defaultLeftSize]);

  const onLeftResize = useCallback(
    (size: PanelSize) => {
      writeStoredSplitSize(storageKey, size.asPercentage);
    },
    [storageKey],
  );

  const groupId = `split-${storageKey}`;
  const separatorClass =
    "w-1.5 shrink-0 bg-border transition-colors";

  const splitPane = isHydrated ? (
    <Group
      id={`${groupId}-group`}
      orientation="horizontal"
      className="h-full w-full"
    >
      <Panel
        id={`${groupId}-left`}
        defaultSize={String(initialLeftSize)}
        minSize={String(minLeftSize)}
        className="flex flex-col min-w-0"
        onResize={onLeftResize}
      >
        <div className="h-full overflow-y-auto pr-2">{leftPane}</div>
      </Panel>
      <Separator className={separatorClass} />
      <Panel
        id={`${groupId}-right`}
        defaultSize={String(100 - initialLeftSize)}
        minSize={String(minRightSize)}
        className="flex flex-col min-w-0"
      >
        <div className="h-full overflow-y-auto pl-2">{rightPane}</div>
      </Panel>
    </Group>
  ) : null;

  if (!responsive) {
    return (
      <div className={cn(className)} style={{ height }}>
        {splitPane}
      </div>
    );
  }

  return (
    <>
      <div className={cn("block lg:hidden space-y-4", className)}>
        <div>{leftPane}</div>
        <div>{rightPane}</div>
      </div>
      <div className={cn("hidden lg:block", className)} style={{ height }}>
        {splitPane}
      </div>
    </>
  );
}
