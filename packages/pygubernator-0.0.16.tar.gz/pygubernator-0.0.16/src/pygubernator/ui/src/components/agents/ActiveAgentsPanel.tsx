"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Activity, ChevronDown, ChevronRight, RefreshCw } from "lucide-react";

import { Button } from "@/components/ui/button";
import { apiGet } from "@/lib/api";
import { cn, formatDateTimeShort } from "@/lib/utils";

/**
 * Shape returned by ``GET /api/v1/agents/heartbeats``.
 *
 * Mirrors the Pydantic ``AgentHeartbeatOut`` model — the fields the
 * panel renders directly (``agent_name``, ``current_node_id``,
 * ``context_used_tokens``) are populated server-side via the registry
 * join + ``HeartbeatEmitter.status_provider`` convention.
 */
interface HeartbeatItem {
  agent_id: string;
  agent_name: string | null;
  run_id: string | null;
  workflow_id: string | null;
  current_node_id: string | null;
  context_used_tokens: number | null;
  status: string;
  details: Record<string, unknown>;
  created_at: string;
  seconds_since_beat: number;
  is_stale: boolean;
}

interface HeartbeatsResponse {
  items: HeartbeatItem[];
  threshold_s: number;
}

interface ActiveAgentsPanelProps {
  /**
   * Scope the list to a single workflow run. When set, only agents
   * whose heartbeats carry a matching ``run_id`` are shown; leave unset
   * for a true fleet-wide view.
   */
  runId?: string;
  /** Poll interval in seconds. Defaults to 10 s — good tradeoff between
   *  "what's running right now" feedback and wasted round-trips. */
  pollIntervalS?: number;
  /** Initial collapsed state. Defaults to expanded on the Runs page so
   *  users notice the new surface. */
  initiallyCollapsed?: boolean;
}

function formatAge(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s ago`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m ago`;
  return `${Math.round(seconds / 3600)}h ago`;
}

function formatTokens(tokens: number | null): string | null {
  if (tokens == null) return null;
  if (tokens < 1000) return `${tokens} tok`;
  return `${(tokens / 1000).toFixed(1)}k tok`;
}

/**
 * Fleet-view panel that shows every agent currently emitting heartbeats.
 *
 * Polls ``/api/v1/agents/heartbeats`` on a configurable cadence.
 * Renders each agent as a row with name, status, current node (when
 * emitters populate it via the convention), context-usage count, and
 * an age stamp. A red dot marks stale agents (``is_stale=true``).
 *
 * Designed as a collapsible card that can be mounted on the Runs page
 * or Workflow Editor — Phase 6 §6.2. Renders nothing when no agents
 * are emitting, so users aren't distracted by a near-empty widget.
 */
export function ActiveAgentsPanel({
  runId,
  pollIntervalS = 10,
  initiallyCollapsed = false,
}: ActiveAgentsPanelProps) {
  const [collapsed, setCollapsed] = useState(initiallyCollapsed);
  const [items, setItems] = useState<HeartbeatItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const cancelledRef = useRef(false);

  const load = useCallback(async () => {
    try {
      const res = await apiGet<HeartbeatsResponse>("/api/v1/agents/heartbeats");
      if (cancelledRef.current) return;
      const filtered = runId
        ? res.items.filter((item) => item.run_id === runId)
        : res.items;
      setItems(filtered);
      setError(null);
    } catch (err) {
      if (cancelledRef.current) return;
      setError(err instanceof Error ? err.message : "Failed to load agents");
    } finally {
      if (!cancelledRef.current) setLoading(false);
    }
  }, [runId]);

  useEffect(() => {
    cancelledRef.current = false;
    void load();
    const intervalMs = Math.max(2000, pollIntervalS * 1000);
    const timer = window.setInterval(() => {
      void load();
    }, intervalMs);
    return () => {
      cancelledRef.current = true;
      window.clearInterval(timer);
    };
  }, [load, pollIntervalS]);

  // Don't render anything when there are no active agents — a permanent
  // empty widget would just add noise. Render while still loading so
  // the header doesn't flicker in/out on poll reloads.
  if (!loading && items.length === 0 && !error) return null;

  return (
    <div className="mb-4 rounded-lg border border-border/60 bg-background/60">
      <button
        type="button"
        onClick={() => setCollapsed((v) => !v)}
        className="flex w-full items-center gap-2 rounded-t-lg px-3 py-2 text-left transition-colors hover:bg-muted/40"
        aria-expanded={!collapsed}
      >
        {collapsed ? (
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
        )}
        <Activity className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-semibold">Active agents</span>
        <span className="text-xs text-muted-foreground">
          ({items.length})
        </span>
        {runId ? (
          <span className="ml-1 rounded border border-border/50 bg-muted/40 px-1.5 py-0.5 text-[10px] text-muted-foreground">
            this run
          </span>
        ) : null}
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="ml-auto h-7 px-2 text-xs"
          onClick={(e) => {
            e.stopPropagation();
            setLoading(true);
            void load();
          }}
          disabled={loading}
        >
          <RefreshCw className={cn("mr-1 h-3 w-3", loading && "animate-spin")} />
          Refresh
        </Button>
      </button>

      {!collapsed && (
        <div className="border-t border-border/60 px-3 py-2">
          {error ? (
            <p className="text-xs text-red-600 dark:text-red-400">{error}</p>
          ) : items.length === 0 ? (
            <p className="py-2 text-center text-xs italic text-muted-foreground">
              Waiting for heartbeats…
            </p>
          ) : (
            <ul className="space-y-1">
              {items.map((item) => (
                <AgentRow key={item.agent_id} item={item} />
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function AgentRow({ item }: { item: HeartbeatItem }) {
  const label = item.agent_name ?? item.agent_id;
  const age = formatAge(item.seconds_since_beat);
  const tokens = formatTokens(item.context_used_tokens);
  const statusTone = item.is_stale
    ? "bg-red-500"
    : item.status === "idle"
      ? "bg-amber-400"
      : "bg-emerald-500";
  const title = item.is_stale
    ? `Stale: last beat ${age}`
    : `Live: last beat ${age} · ${item.status}`;

  return (
    <li
      className="flex items-center gap-2 rounded px-2 py-1.5 text-xs hover:bg-muted/40"
      title={title}
    >
      <span
        className={cn(
          "inline-block h-2 w-2 shrink-0 rounded-full",
          statusTone,
          !item.is_stale && "animate-pulse",
        )}
        aria-hidden="true"
      />
      <span className="min-w-0 flex-1 truncate font-medium">{label}</span>
      {item.current_node_id ? (
        <span className="truncate font-mono text-[10px] text-muted-foreground">
          {item.current_node_id}
        </span>
      ) : null}
      {tokens ? (
        <span className="shrink-0 rounded border border-border/50 bg-background/80 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
          {tokens}
        </span>
      ) : null}
      <span className="shrink-0 text-[10px] text-muted-foreground" title={formatDateTimeShort(item.created_at)}>
        {age}
      </span>
    </li>
  );
}
