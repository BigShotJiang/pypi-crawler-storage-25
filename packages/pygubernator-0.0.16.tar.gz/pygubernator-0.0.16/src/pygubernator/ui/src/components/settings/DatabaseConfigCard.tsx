"use client";

import { useDatabaseConfig } from "@/hooks/useDatabaseConfig";
import type { DatabaseTestRequest } from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";

interface DatabaseConfigCardProps {
  enabled: boolean;
  connectionString: string;
  host: string;
  port: string;
  database: string;
  username: string;
  password: string;
  onEnabledChange: (v: boolean) => void;
  onConnectionStringChange: (v: string) => void;
  onHostChange: (v: string) => void;
  onPortChange: (v: string) => void;
  onDatabaseChange: (v: string) => void;
  onUsernameChange: (v: string) => void;
  onPasswordChange: (v: string) => void;
}

export function DatabaseConfigCard({
  enabled,
  connectionString,
  host,
  port,
  database,
  username,
  password,
  onEnabledChange,
  onConnectionStringChange,
  onHostChange,
  onPortChange,
  onDatabaseChange,
  onUsernameChange,
  onPasswordChange,
}: DatabaseConfigCardProps) {
  const { config: dbConfig, testing, testResult, test } = useDatabaseConfig();

  const handleTest = () => {
    const body: DatabaseTestRequest = {
      connection_string: connectionString || undefined,
      host: host || undefined,
      port: port ? parseInt(port, 10) : undefined,
      database: database || undefined,
      username: username || undefined,
      password: password || undefined,
    };
    void test(body);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Database configuration</CardTitle>
        <CardDescription>
          The control plane database is set on the server via{" "}
          <code className="text-xs bg-muted px-1 py-0.5 rounded">
            PYGUBERNATOR_DATABASE_URL
          </code>{" "}
          or{" "}
          <code className="text-xs bg-muted px-1 py-0.5 rounded">
            pygubernator.cfg
          </code>
          . Below shows what the API is using; you can test a different
          connection string without changing the server.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {dbConfig && (
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            {dbConfig.message}
            {dbConfig.workflow_count >= 0 && (
              <span className="ml-2">
                Workflows stored: {dbConfig.workflow_count}
              </span>
            )}
          </div>
        )}
        <div className="flex items-center justify-between gap-4">
          <div className="space-y-0.5">
            <span className="text-sm font-medium">Show connection test fields</span>
            <p className="text-sm text-muted-foreground">
              Expand to try credentials for Postgres or another URL
            </p>
          </div>
          <input
            type="checkbox"
            className="h-4 w-4 rounded border-input"
            checked={enabled}
            onChange={(e) => onEnabledChange(e.target.checked)}
            aria-label="Show database connection test fields"
          />
        </div>

        {enabled && (
          <div className="space-y-4 pt-4 border-t">
            <div className="space-y-2">
              <label
                htmlFor="db-connection-string"
                className="text-sm font-medium"
              >
                Connection string (optional)
              </label>
              <Input
                id="db-connection-string"
                type="text"
                value={connectionString}
                onChange={(e) => onConnectionStringChange(e.target.value)}
                placeholder="postgresql://user:password@host:5432/pygubernator or sqlite:///pygubernator.db"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="db-host" className="text-sm font-medium">
                  Host
                </label>
                <Input
                  id="db-host"
                  type="text"
                  value={host}
                  onChange={(e) => onHostChange(e.target.value)}
                  placeholder="localhost"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="db-port" className="text-sm font-medium">
                  Port
                </label>
                <Input
                  id="db-port"
                  type="number"
                  value={port}
                  onChange={(e) => onPortChange(e.target.value)}
                  placeholder="5432"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="db-name" className="text-sm font-medium">
                Database
              </label>
              <Input
                id="db-name"
                type="text"
                value={database}
                onChange={(e) => onDatabaseChange(e.target.value)}
                placeholder="pygubernator"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="db-username" className="text-sm font-medium">
                  Username
                </label>
                <Input
                  id="db-username"
                  type="text"
                  value={username}
                  onChange={(e) => onUsernameChange(e.target.value)}
                  placeholder="user"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="db-password" className="text-sm font-medium">
                  Password
                </label>
                <Input
                  id="db-password"
                  type="password"
                  value={password}
                  onChange={(e) => onPasswordChange(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleTest}
                disabled={testing}
              >
                {testing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  "Test connection"
                )}
              </Button>
              {testResult && (
                <span className="inline-flex items-center gap-1 text-sm">
                  {testResult.success ? (
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  {testResult.message}
                </span>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
