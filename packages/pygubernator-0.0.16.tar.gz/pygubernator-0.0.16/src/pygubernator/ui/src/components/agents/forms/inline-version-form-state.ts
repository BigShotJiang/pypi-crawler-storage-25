/**
 * Reducer-backed state for the manual ``InlineVersionForm`` (Phase R §R.3).
 *
 * Replaces seven sibling ``useState`` calls that previously lived in
 * ``AgentRegistryDetailView``. Picking a provider preset has to update
 * three fields at once (``api_base``, ``model``, ``api_key``), which is
 * exactly the case where ``useReducer`` keeps the transition atomic
 * and self-documenting.
 */

export interface ProviderPreset {
  name: string;
  description: string;
  default_api_base: string | null;
  models: string[];
  provider_type: string;
  requires_api_key: boolean;
}

/** Mutable fields the form binds to. */
export interface InlineVersionFormState {
  version: string;
  model: string;
  prompt: string;
  provider_name: string;
  api_base: string;
  api_key: string;
}

export const INITIAL_INLINE_VERSION_FORM: InlineVersionFormState = {
  version: "",
  model: "",
  prompt: "",
  provider_name: "",
  api_base: "",
  api_key: "",
};

/** Discriminated action set for {@link inlineVersionFormReducer}. */
export type InlineVersionFormAction =
  | {
      type: "set_field";
      field: keyof InlineVersionFormState;
      value: string;
    }
  | {
      /**
       * Atomic provider-preset selection: clearing this single action
       * updates ``provider_name`` and the preset-derived defaults
       * (``api_base``, ``model``, ``api_key``) in one transition so
       * the UI never flashes a half-applied preset.
       */
      type: "select_provider";
      provider_name: string;
      preset: ProviderPreset | undefined;
    }
  | { type: "reset" };

export function inlineVersionFormReducer(
  state: InlineVersionFormState,
  action: InlineVersionFormAction,
): InlineVersionFormState {
  switch (action.type) {
    case "set_field":
      return { ...state, [action.field]: action.value };
    case "select_provider": {
      if (!action.preset) {
        return {
          ...state,
          provider_name: action.provider_name,
          api_base: "",
          model: "",
          api_key: "",
        };
      }
      return {
        ...state,
        provider_name: action.provider_name,
        api_base: action.preset.default_api_base ?? "",
        model: action.preset.models[0] ?? "",
        api_key: "",
      };
    }
    case "reset":
      return INITIAL_INLINE_VERSION_FORM;
  }
}
