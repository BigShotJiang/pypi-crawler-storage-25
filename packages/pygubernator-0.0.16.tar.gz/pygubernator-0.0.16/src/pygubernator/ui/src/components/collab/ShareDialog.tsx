'use client'

import { useState } from 'react'
import { Copy, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog'
import {
  useCollabStore,
  selectShareDialogOpen,
  selectRoomInfo,
  selectCollaborators,
} from '@/stores/collab'

/** Dialog that shows the shareable room link and the current collaborator list. */
export function ShareDialog() {
  const open = useCollabStore(selectShareDialogOpen)
  const setOpen = useCollabStore((s) => s.setShareDialogOpen)
  const roomInfo = useCollabStore(selectRoomInfo)
  const collaborators = useCollabStore(selectCollaborators)
  const [copied, setCopied] = useState(false)

  if (!roomInfo) return null

  const shareUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}${window.location.pathname}#room=${roomInfo.roomId},${roomInfo.roomKey}`
      : ''

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shareUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Share Collaboration Link</DialogTitle>
          <DialogDescription>
            Anyone with this link can join and edit in real-time. The link
            includes an encryption key — share it securely.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Shareable link */}
          <div className="flex gap-2">
            <input
              readOnly
              value={shareUrl}
              className="h-9 flex-1 truncate rounded-md border border-input bg-muted px-3 font-mono text-sm"
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <Button variant="outline" size="sm" onClick={handleCopy}>
              {copied ? (
                <Check className="h-4 w-4 text-green-600" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>

          {/* Collaborators */}
          {collaborators.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium">In this session</p>
              <div className="space-y-1.5">
                {collaborators.map((c) => (
                  <div
                    key={c.socketId}
                    className="flex items-center gap-2 text-sm"
                  >
                    <div
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-white"
                      style={{ backgroundColor: c.color }}
                    >
                      {(c.username || '?')[0].toUpperCase()}
                    </div>
                    <span className="truncate">
                      {c.username || 'Anonymous'}
                    </span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {c.userState === 'active'
                        ? '\u25CF'
                        : c.userState === 'idle'
                          ? '\u25CB'
                          : '\u2014'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
