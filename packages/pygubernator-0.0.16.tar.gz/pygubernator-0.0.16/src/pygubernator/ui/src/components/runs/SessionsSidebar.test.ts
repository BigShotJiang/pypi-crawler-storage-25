import { describe, expect, it } from "vitest";

import { statusDotColor } from "./SessionsSidebar";

describe("statusDotColor", () => {
  /*
   * Freezes the colour tokens used for session status pips so a
   * refactor of the Tailwind class list doesn't silently change the
   * UX signal (e.g. a failed session turning green).
   */

  it.each([
    ["completed", "bg-emerald-500"],
    ["success", "bg-emerald-500"],
    ["failed", "bg-red-500"],
    ["error", "bg-red-500"],
    ["running", "bg-amber-500"],
    ["pending", "bg-slate-400"],
    ["cancelled", "bg-slate-500"],
  ])("maps %s -> %s", (status, expected) => {
    expect(statusDotColor(status)).toBe(expected);
  });

  it("returns a muted default for null and unknown statuses", () => {
    expect(statusDotColor(null)).toBe("bg-muted");
    expect(statusDotColor("unknown")).toBe("bg-muted");
    expect(statusDotColor("")).toBe("bg-muted");
  });
});
