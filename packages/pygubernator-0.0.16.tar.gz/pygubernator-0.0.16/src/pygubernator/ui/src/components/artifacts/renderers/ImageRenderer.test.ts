import { describe, expect, it } from "vitest";

import { buildImageDataUrl } from "./ImageRenderer";

describe("buildImageDataUrl", () => {
  it("wraps base64 payloads with the declared MIME type", () => {
    expect(buildImageDataUrl("ABC==", "base64", "image/png")).toBe(
      "data:image/png;base64,ABC==",
    );
  });

  it("URL-encodes UTF-8 SVG payloads", () => {
    const svg = '<svg xmlns="http://example.com/svg"/>';
    const url = buildImageDataUrl(svg, "utf-8", "image/svg+xml");
    expect(url.startsWith("data:image/svg+xml;utf8,")).toBe(true);
    expect(url).toContain(encodeURIComponent(svg));
  });

  it("falls back to application/octet-stream when MIME is null", () => {
    expect(buildImageDataUrl("ABC==", "base64", null)).toBe(
      "data:application/octet-stream;base64,ABC==",
    );
  });
});
