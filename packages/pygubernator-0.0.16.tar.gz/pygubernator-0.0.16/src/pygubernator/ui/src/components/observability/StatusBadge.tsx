"use client";

import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function StatusBadge({ label }: { label: string }) {
  const l = label.toLowerCase();
  const variant =
    l === "resolved" || l === "succeeded"
      ? "secondary"
      : l === "failed" || l === "open"
        ? "destructive"
        : "outline";
  return (
    <Badge variant={variant} className={cn("capitalize")}>
      {label}
    </Badge>
  );
}
