"use client";

/**
 * Version-lifecycle button row used in the Versions table on the
 * agent registry detail view (Phase R §R.3).
 *
 * Three actions: ``Set active``, ``Deactivate``, and a destructive
 * ``Delete`` icon button. Behaviour rules baked into the disabled /
 * title props match the backend's ``activate / deactivate /
 * soft_delete_agent_version`` invariants:
 *
 * - The active version cannot be deleted (must deactivate first).
 * - "Set active" is hidden for the already-active version.
 * - "Deactivate" only fires when the row is active.
 *
 * Pure presentation: every action is forwarded to a parent callback
 * so the parent owns the API plumbing + audit / refresh choreography.
 */

import { Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";

interface VersionLifecycleActionsProps {
  versionId: string;
  versionLabel: string;
  isActive: boolean;
  busy: boolean;
  onActivate: () => void;
  onDeactivate: () => void;
  onDelete: () => void;
}

export function VersionLifecycleActions({
  versionId,
  versionLabel,
  isActive,
  busy,
  onActivate,
  onDeactivate,
  onDelete,
}: VersionLifecycleActionsProps) {
  return (
    <div className="inline-flex items-center gap-1">
      <Button
        variant="outline"
        size="sm"
        disabled={busy || isActive}
        onClick={onActivate}
      >
        Set active
      </Button>
      <Button
        variant="outline"
        size="sm"
        disabled={busy || !isActive}
        onClick={onDeactivate}
        title={
          isActive
            ? "Clear the active flag (agent ends up with no active version)"
            : "Already inactive"
        }
      >
        Deactivate
      </Button>
      <Button
        variant="outline"
        size="sm"
        disabled={busy || isActive}
        onClick={onDelete}
        title={
          isActive
            ? "Deactivate first — the active version cannot be deleted"
            : "Soft-delete this version"
        }
        aria-label={`Delete version ${versionLabel}`}
        data-version-id={versionId}
      >
        <Trash2 className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
