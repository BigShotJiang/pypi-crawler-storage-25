import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const KEY = "pygubernator_test_split";

/**
 * Minimal in-memory localStorage stub used to exercise the split-pane helpers
 * under the node test environment (the UI tests are configured with
 * `environment: "node"`, so `window` is not provided).
 */
function installFakeLocalStorage(): {
  store: Record<string, string>;
  setItemSpy: ReturnType<typeof vi.fn>;
  getItemSpy: ReturnType<typeof vi.fn>;
} {
  const store: Record<string, string> = {};
  const setItemSpy = vi.fn((key: string, value: string) => {
    store[key] = value;
  });
  const getItemSpy = vi.fn((key: string): string | null => {
    return Object.prototype.hasOwnProperty.call(store, key)
      ? store[key]
      : null;
  });
  const removeItemSpy = vi.fn((key: string) => {
    delete store[key];
  });
  const clearSpy = vi.fn(() => {
    for (const k of Object.keys(store)) delete store[k];
  });

  const fakeWindow = {
    localStorage: {
      setItem: setItemSpy,
      getItem: getItemSpy,
      removeItem: removeItemSpy,
      clear: clearSpy,
    },
  };
  (globalThis as unknown as { window: unknown }).window = fakeWindow;
  return { store, setItemSpy, getItemSpy };
}

function uninstallFakeLocalStorage(): void {
  delete (globalThis as unknown as { window?: unknown }).window;
}

describe("ResizableSplitPane storage helpers", () => {
  let helpers: typeof import("./ResizableSplitPane");

  beforeEach(async () => {
    installFakeLocalStorage();
    vi.resetModules();
    helpers = await import("./ResizableSplitPane");
  });

  afterEach(() => {
    uninstallFakeLocalStorage();
    vi.restoreAllMocks();
  });

  it("returns fallback when key is absent", () => {
    expect(helpers.readStoredSplitSize(KEY, 65)).toBe(65);
  });

  it("round-trips a valid percentage", () => {
    helpers.writeStoredSplitSize(KEY, 42.5);
    expect(helpers.readStoredSplitSize(KEY, 65)).toBe(42.5);
  });

  it("ignores non-numeric stored values", () => {
    (globalThis as unknown as { window: { localStorage: Storage } }).window.localStorage.setItem(
      KEY,
      "not-a-number",
    );
    expect(helpers.readStoredSplitSize(KEY, 65)).toBe(65);
  });

  it.each([
    ["0", 0],
    ["100", 100],
    ["-5", -5],
    ["150", 150],
  ])("ignores out-of-range %s", (raw) => {
    (globalThis as unknown as { window: { localStorage: Storage } }).window.localStorage.setItem(
      KEY,
      raw,
    );
    expect(helpers.readStoredSplitSize(KEY, 65)).toBe(65);
  });

  it("rounds stored value to two decimals", () => {
    helpers.writeStoredSplitSize(KEY, 33.333333);
    const win = (globalThis as unknown as { window: { localStorage: Storage } }).window;
    expect(win.localStorage.getItem(KEY)).toBe("33.33");
  });

  it("swallows setItem errors (e.g. quota exceeded)", () => {
    const win = (globalThis as unknown as { window: { localStorage: Storage } }).window;
    win.localStorage.setItem = vi.fn(() => {
      throw new Error("quota exceeded");
    });
    expect(() => helpers.writeStoredSplitSize(KEY, 50)).not.toThrow();
  });

  it("swallows getItem errors and returns fallback", () => {
    const win = (globalThis as unknown as { window: { localStorage: Storage } }).window;
    win.localStorage.getItem = vi.fn(() => {
      throw new Error("access denied");
    });
    expect(helpers.readStoredSplitSize(KEY, 70)).toBe(70);
  });

  it("returns fallback when window is undefined (SSR)", () => {
    uninstallFakeLocalStorage();
    expect(helpers.readStoredSplitSize(KEY, 80)).toBe(80);
    expect(() => helpers.writeStoredSplitSize(KEY, 25)).not.toThrow();
  });
});
