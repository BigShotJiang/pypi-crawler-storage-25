"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";

import { cn } from "@/lib/utils";
import { ROUTES } from "@/lib/constants";

const items = [
  { href: ROUTES.OBSERVABILITY, label: "Overview" },
  { href: ROUTES.OBS_INCIDENTS, label: "Incidents" },
  { href: ROUTES.OBS_RUNS, label: "Runs explorer" },
  { href: ROUTES.OBS_ALERTS, label: "Alerts" }
];

export function ObservabilityTabs() {
  const pathname = usePathname();
  const params = useSearchParams();
  const windowParam = params.get("window") ?? "24h";

  return (
    <div className="flex flex-wrap gap-2 border-b border-border pb-3 mb-6">
      {items.map((item) => {
        const base = item.href.replace(/\/$/, "");
        const path = pathname?.replace(/\/$/, "") ?? "";
        const active = path === base || path.startsWith(`${base}/`);
        const href = `${item.href}?window=${encodeURIComponent(windowParam)}`;
        return (
          <Link
            key={item.href}
            href={href}
            className={cn(
              "rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              active
                ? "bg-primary/15 text-primary border border-primary/30"
                : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground border border-transparent"
            )}
          >
            {item.label}
          </Link>
        );
      })}
    </div>
  );
}
