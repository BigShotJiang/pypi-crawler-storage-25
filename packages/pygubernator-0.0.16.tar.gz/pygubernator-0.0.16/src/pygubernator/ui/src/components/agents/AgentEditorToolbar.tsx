"use client";

import { useMemo, useState } from "react";
import { Loader2, Play, Redo2, Save, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiPost } from "@/lib/api";
import { builderSpecToAgentSpecJson, useAgentEditorStore } from "@/stores/agent-editor";

export default function AgentEditorToolbar() {
  const spec = useAgentEditorStore((s) => s.spec);
  const selectedAgentId = useAgentEditorStore((s) => s.selectedAgentId);
  const selectedAgentName = useAgentEditorStore((s) => s.selectedAgentName);
  const saveVersion = useAgentEditorStore((s) => s.saveVersion);
  const setSaveVersion = useAgentEditorStore((s) => s.setSaveVersion);
  const undo = useAgentEditorStore((s) => s.undo);
  const redo = useAgentEditorStore((s) => s.redo);
  const canUndo = useAgentEditorStore((s) => s.past.length > 0);
  const canRedo = useAgentEditorStore((s) => s.future.length > 0);
  const markSaved = useAgentEditorStore((s) => s.markSaved);

  const [publishing, setPublishing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const displayName = useMemo(
    () => spec.meta.name || selectedAgentName || "Agent Builder",
    [spec.meta.name, selectedAgentName],
  );

  const publish = async () => {
    if (!selectedAgentId || !saveVersion.trim()) return;
    setPublishing(true);
    setMessage(null);
    try {
      await apiPost(
        `/api/v1/agents/${selectedAgentId}/versions`,
        {
          version: saveVersion.trim(),
          spec_json: builderSpecToAgentSpecJson(spec),
        },
      );
      markSaved();
      setMessage(`Published ${displayName} v${saveVersion.trim()}`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Failed to publish";
      setMessage(detail);
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="absolute right-3 top-3 z-10 flex items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm">
      <span className="max-w-[200px] truncate text-sm font-medium">{displayName}</span>
      <Input
        className="h-8 w-24"
        placeholder="Version"
        value={saveVersion}
        onChange={(event) => setSaveVersion(event.target.value)}
      />
      <Button variant="ghost" size="sm" disabled={!canUndo} onClick={undo} aria-label="Undo">
        <Undo2 className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="sm" disabled={!canRedo} onClick={redo} aria-label="Redo">
        <Redo2 className="h-4 w-4" />
      </Button>
      <Button
        variant="outline"
        size="sm"
        disabled={!selectedAgentId || publishing || !saveVersion.trim()}
        onClick={() => void publish()}
      >
        {publishing ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Save className="mr-1.5 h-4 w-4" />}
        Publish
      </Button>
      <Button variant="secondary" size="sm" disabled>
        <Play className="mr-1.5 h-4 w-4" />
        Run
      </Button>
      {message ? (
        <span className="max-w-[260px] truncate text-[11px] text-muted-foreground">{message}</span>
      ) : null}
    </div>
  );
}
