"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

import { ROUTES } from "@/lib/constants";
import { runsApi, type WorkflowRunSummary } from "@/lib/api/runs";
import { cn } from "@/lib/utils";

interface RunHistoryChipProps {
  scheduleId: string;
  /** How many recent runs to show. Defaults to 5. */
  count?: number;
}

const STATUS_DOT: Record<string, { className: string; label: string }> = {
  completed: { className: "bg-emerald-500", label: "Completed" },
  success: { className: "bg-emerald-500", label: "Success" },
  failed: { className: "bg-red-500", label: "Failed" },
  running: { className: "bg-amber-500 animate-pulse", label: "Running" },
  pending: { className: "bg-slate-300", label: "Pending" },
  cancelled: { className: "bg-amber-400", label: "Cancelled" },
  triggered: { className: "bg-sky-400", label: "Triggered" },
};

function dotFor(status: string): { className: string; label: string } {
  return STATUS_DOT[status] ?? { className: "bg-slate-400", label: status };
}

function formatRelative(iso: string | null): string {
  if (!iso) return "";
  const date = new Date(iso);
  const diff = Date.now() - date.getTime();
  if (Number.isNaN(diff)) return iso;
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

/**
 * Inline strip of coloured dots — one per recent run for a scheduled
 * job — surfaced beside the schedule's "Last run" column. Newest run
 * is rendered leftmost. Hover any dot for the timestamp + status.
 *
 * Falls back to a small "—" when the schedule has no runs yet so the
 * column never collapses to zero width.
 */
export default function RunHistoryChip({ scheduleId, count = 5 }: RunHistoryChipProps) {
  const [runs, setRuns] = useState<WorkflowRunSummary[] | null>(null);

  useEffect(() => {
    if (!scheduleId) return;
    let cancelled = false;
    void runsApi
      .listBySchedule({ scheduleId, pageSize: count })
      .then((res) => {
        if (cancelled) return;
        setRuns(res.items);
      })
      .catch(() => {
        if (cancelled) return;
        setRuns([]);
      });
    return () => {
      cancelled = true;
    };
  }, [scheduleId, count]);

  if (runs === null) {
    return (
      <span
        aria-label="Loading recent runs"
        className="inline-block h-2 w-12 animate-pulse rounded-full bg-muted"
      />
    );
  }

  if (runs.length === 0) {
    return (
      <span className="text-[11px] text-muted-foreground" title="No runs yet">
        —
      </span>
    );
  }

  return (
    <Link
      href={`${ROUTES.RUNS}?search=${encodeURIComponent(`scheduler:${scheduleId}`)}`}
      aria-label={`View ${runs.length} recent runs`}
      className="inline-flex items-center gap-1 rounded-full px-1 py-0.5 hover:bg-muted/60"
    >
      {runs.map((run) => {
        const meta = dotFor(run.status);
        const at = formatRelative(run.completed_at ?? run.started_at);
        const tooltip = at ? `${meta.label} · ${at}` : meta.label;
        return (
          <span
            key={run.id}
            title={tooltip}
            aria-label={tooltip}
            className={cn("h-2 w-2 rounded-full", meta.className)}
          />
        );
      })}
    </Link>
  );
}
