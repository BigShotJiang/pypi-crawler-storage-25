"use client";

import Link from "next/link";
import { Check, Circle, X } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ROUTES } from "@/lib/constants";
import {
  SETUP_TASKS_TOTAL,
  selectAllSetupTasksDone,
  selectOnboardingDismissed,
  selectOnboardingTasks,
  selectSetupTasksDone,
  useOnboardingStore,
  type SetupTaskId
} from "@/stores/onboarding";

interface ChecklistItem {
  id: SetupTaskId;
  label: string;
  description: string;
  href: string;
  actionLabel: string;
}

const ITEMS: ChecklistItem[] = [
  {
    id: "credentials_added",
    label: "Add an API key",
    description: "Link at least one provider (OpenAI, Anthropic, etc.) so LLM nodes can run.",
    href: ROUTES.SETTINGS,
    actionLabel: "Open Settings"
  },
  {
    id: "first_workflow_saved",
    label: "Save your first workflow",
    description: "Start from a template or build from scratch in the editor.",
    href: ROUTES.WORKFLOW_EDITOR,
    actionLabel: "Open editor"
  },
  {
    id: "first_run_completed",
    label: "Watch a run complete",
    description: "Execute a workflow at least once — success or failure both count.",
    href: ROUTES.RUNS,
    actionLabel: "View runs"
  }
];

/**
 * Sticky checklist shown on the landing page until every setup task is
 * complete (or the user dismisses it). State is persisted via the
 * onboarding Zustand store.
 */
export default function SetupChecklist() {
  const tasks = useOnboardingStore(selectOnboardingTasks);
  const done = useOnboardingStore(selectSetupTasksDone);
  const allDone = useOnboardingStore(selectAllSetupTasksDone);
  const dismissed = useOnboardingStore(selectOnboardingDismissed);
  const dismiss = useOnboardingStore((s) => s.dismiss);

  if (dismissed || allDone) return null;

  return (
    <Card className="border-primary/40">
      <CardHeader className="flex flex-row items-start justify-between gap-4 pb-3">
        <div className="flex flex-col gap-1">
          <CardTitle className="text-lg">Set up pygubernator</CardTitle>
          <p className="text-sm text-muted-foreground">
            {done} of {SETUP_TASKS_TOTAL} complete · finish these once and you&apos;re good
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={dismiss}
          aria-label="Dismiss setup checklist"
          className="h-8 w-8 p-0"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="space-y-2.5">
        {ITEMS.map((item) => {
          const isDone = tasks[item.id];
          return (
            <div
              key={item.id}
              className="flex items-start gap-3 rounded-md border bg-background p-3"
            >
              <div className="mt-0.5 shrink-0">
                {isDone ? (
                  <Check className="h-4 w-4 text-primary" aria-label="Complete" />
                ) : (
                  <Circle className="h-4 w-4 text-muted-foreground" aria-label="Pending" />
                )}
              </div>
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={
                      isDone
                        ? "text-sm font-medium text-muted-foreground line-through"
                        : "text-sm font-medium"
                    }
                  >
                    {item.label}
                  </span>
                  {!isDone && (
                    <Link
                      href={item.href}
                      className="text-xs font-medium text-primary hover:underline whitespace-nowrap"
                    >
                      {item.actionLabel} →
                    </Link>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">{item.description}</span>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
