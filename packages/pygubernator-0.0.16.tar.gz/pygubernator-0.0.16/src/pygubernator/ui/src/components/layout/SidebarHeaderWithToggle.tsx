'use client';

import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

type SidebarDisplayMode = 'expanded' | 'compact' | 'collapsed';

export interface SidebarHeaderWithToggleProps {
  /** When true, only the expand chevron is shown (centered). */
  isCollapsed: boolean;
  /** Sidebar display mode for responsive header content. */
  displayMode?: SidebarDisplayMode;
  /** Called when user clicks the toggle (collapse or expand). */
  onToggle: () => void;
  /** Content shown on the left when expanded (e.g. title or tabs). Omitted when collapsed. */
  children?: React.ReactNode;
  /** Optional class name for the header container. */
  className?: string;
}

/**
 * Sidebar header: bar with optional left content and collapse/expand chevron.
 */
export function SidebarHeaderWithToggle({
  isCollapsed,
  displayMode = isCollapsed ? 'collapsed' : 'expanded',
  onToggle,
  children,
  className,
}: SidebarHeaderWithToggleProps) {
  const showChildren = displayMode !== 'collapsed';
  return (
    <div
      className={cn(
        'flex items-center gap-2 px-3 py-2.5 border-b border-border/50 bg-muted/30 shrink-0',
        isCollapsed ? 'justify-center' : 'justify-between',
        className
      )}
    >
      {showChildren && children}
      <button
        type="button"
        onClick={onToggle}
        className="p-1.5 rounded-md hover:bg-muted transition-all duration-200 hover:scale-105 active:scale-95 shrink-0"
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {isCollapsed ? (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronLeft className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
    </div>
  );
}
