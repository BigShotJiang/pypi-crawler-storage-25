"use client";

import { useEffect, useMemo, useState } from "react";
import { CalendarClock, Code2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { schedulesApi } from "@/lib/api/schedules";

export type ScheduleMode = "every_day" | "weekdays" | "weekly" | "monthly" | "advanced";

interface ScheduleBuilderProps {
  /** Current cron expression (controlled). */
  cron: string;
  /** Current IANA timezone (controlled). */
  timezone: string;
  /** Called whenever the cron expression changes through any mode. */
  onCronChange: (cron: string) => void;
  /** Optional handler if the parent wants to track preview-derived errors. */
  onError?: (error: string | null) => void;
}

interface ModeTab {
  id: ScheduleMode;
  label: string;
}

const MODE_TABS: ModeTab[] = [
  { id: "every_day", label: "Every day" },
  { id: "weekdays", label: "Weekdays" },
  { id: "weekly", label: "Weekly" },
  { id: "monthly", label: "Monthly" },
  { id: "advanced", label: "Advanced" },
];

const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface ParsedTime {
  hour: number;
  minute: number;
}

function pad(n: number): string {
  return n.toString().padStart(2, "0");
}

function parseHourMinute(value: string): ParsedTime {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value.trim());
  if (!match) return { hour: 9, minute: 0 };
  const hour = Math.min(23, Math.max(0, Number(match[1])));
  const minute = Math.min(59, Math.max(0, Number(match[2])));
  return { hour, minute };
}

function buildCron({
  mode,
  time,
  weeklyDays,
  monthlyDay,
}: {
  mode: ScheduleMode;
  time: ParsedTime;
  weeklyDays: number[];
  monthlyDay: number;
}): string {
  const m = `${time.minute}`;
  const h = `${time.hour}`;
  switch (mode) {
    case "every_day":
      return `${m} ${h} * * *`;
    case "weekdays":
      return `${m} ${h} * * 1-5`;
    case "weekly": {
      const sorted = [...weeklyDays].sort((a, b) => a - b);
      const days = sorted.length === 0 ? "*" : sorted.join(",");
      return `${m} ${h} * * ${days}`;
    }
    case "monthly": {
      const day = Math.min(31, Math.max(1, monthlyDay));
      return `${m} ${h} ${day} * *`;
    }
    case "advanced":
      // Caller manages the cron field directly in advanced mode.
      return "";
  }
}

/**
 * Best-effort detection of which builder mode an existing cron string
 * came from. When in doubt, fall back to ``"advanced"`` so the user
 * sees the raw expression and is never surprised by silent rewrites.
 */
function detectMode(cron: string): {
  mode: ScheduleMode;
  time: ParsedTime;
  weeklyDays: number[];
  monthlyDay: number;
} {
  const fields = cron.trim().split(/\s+/);
  const fallback = {
    mode: "advanced" as ScheduleMode,
    time: { hour: 9, minute: 0 },
    weeklyDays: [1, 2, 3, 4, 5],
    monthlyDay: 1,
  };
  if (fields.length !== 5) return fallback;
  const [m, h, dom, mon, dow] = fields;
  if (mon !== "*") return fallback;
  const minute = Number(m);
  const hour = Number(h);
  if (
    !Number.isInteger(minute) ||
    !Number.isInteger(hour) ||
    minute < 0 ||
    minute > 59 ||
    hour < 0 ||
    hour > 23
  ) {
    return fallback;
  }
  const time = { hour, minute };
  // Every day
  if (dom === "*" && dow === "*") {
    return { ...fallback, mode: "every_day", time };
  }
  // Weekdays
  if (dom === "*" && dow === "1-5") {
    return { ...fallback, mode: "weekdays", time, weeklyDays: [1, 2, 3, 4, 5] };
  }
  // Weekly with explicit day list (e.g. "1,3,5")
  if (dom === "*" && /^[0-6](,[0-6])*$/.test(dow)) {
    return {
      ...fallback,
      mode: "weekly",
      time,
      weeklyDays: dow.split(",").map(Number),
    };
  }
  // Monthly
  if (dow === "*" && /^\d{1,2}$/.test(dom)) {
    return { ...fallback, mode: "monthly", time, monthlyDay: Number(dom) };
  }
  return fallback;
}

interface NextFiresPreviewProps {
  cron: string;
  timezone: string;
}

function NextFiresPreview({ cron, timezone }: NextFiresPreviewProps) {
  const [fires, setFires] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Debounce: don't hammer the API on every keystroke.
  useEffect(() => {
    if (!cron.trim()) {
      setFires([]);
      setError(null);
      return;
    }
    let cancelled = false;
    const handle = window.setTimeout(() => {
      setLoading(true);
      void schedulesApi
        .previewCron({ cron, timezone, count: 3 })
        .then((res) => {
          if (cancelled) return;
          if (res.ok) {
            setFires(res.next_fires_iso);
            setError(null);
          } else {
            setFires([]);
            setError(res.error ?? "Unable to preview schedule.");
          }
        })
        .catch((exc) => {
          if (cancelled) return;
          const message = exc instanceof Error ? exc.message : "Preview failed";
          setError(message);
          setFires([]);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }, 300);
    return () => {
      cancelled = true;
      window.clearTimeout(handle);
    };
  }, [cron, timezone]);

  if (loading && fires === null) {
    return <p className="text-xs text-muted-foreground">Calculating next fires…</p>;
  }
  if (error) {
    return <p className="text-xs text-destructive">{error}</p>;
  }
  if (!fires || fires.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col gap-1">
      <p className="text-xs font-medium text-muted-foreground">Next 3 runs</p>
      <ul className="flex flex-col gap-0.5 text-xs">
        {fires.map((iso) => (
          <li key={iso} className="flex items-center gap-2">
            <CalendarClock
              className="h-3 w-3 text-muted-foreground"
              aria-hidden="true"
            />
            <span className="font-mono text-[11px]">{formatLocalIso(iso)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function formatLocalIso(iso: string): string {
  // The server returns ISO strings already in the requested timezone,
  // so we just trim the trailing offset for display.
  try {
    const date = new Date(iso);
    return date.toLocaleString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export default function ScheduleBuilder({
  cron,
  timezone,
  onCronChange,
  onError,
}: ScheduleBuilderProps) {
  const detected = useMemo(() => detectMode(cron), [cron]);
  const [mode, setMode] = useState<ScheduleMode>(detected.mode);
  const [time, setTime] = useState<ParsedTime>(detected.time);
  const [weeklyDays, setWeeklyDays] = useState<number[]>(detected.weeklyDays);
  const [monthlyDay, setMonthlyDay] = useState<number>(detected.monthlyDay);

  // Re-sync to props when the parent loads an existing schedule for
  // editing — but only if the detected mode actually changed (avoid
  // looping on every keystroke).
  useEffect(() => {
    setMode(detected.mode);
    setTime(detected.time);
    setWeeklyDays(detected.weeklyDays);
    setMonthlyDay(detected.monthlyDay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cron]);

  // Push generated cron to the parent for builder modes.
  useEffect(() => {
    if (mode === "advanced") return;
    const generated = buildCron({ mode, time, weeklyDays, monthlyDay });
    if (generated && generated !== cron) {
      onCronChange(generated);
      onError?.(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, time, weeklyDays, monthlyDay]);

  const timeValue = `${pad(time.hour)}:${pad(time.minute)}`;

  return (
    <div className="flex flex-col gap-3 rounded-md border bg-muted/20 p-3">
      <div className="flex flex-wrap gap-1.5">
        {MODE_TABS.map((tab) => {
          const active = mode === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setMode(tab.id)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                active
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-background text-muted-foreground hover:text-foreground",
              )}
              aria-pressed={active}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {mode !== "advanced" && (
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="flex flex-col gap-1">
            <label htmlFor="builder-time" className="text-xs font-medium">
              Time
            </label>
            <Input
              id="builder-time"
              type="time"
              value={timeValue}
              onChange={(e) => setTime(parseHourMinute(e.target.value))}
              className="w-32"
            />
          </div>
          {mode === "weekly" && (
            <div className="flex flex-col gap-1">
              <span className="text-xs font-medium">On days</span>
              <div className="flex gap-1">
                {DAY_LABELS.map((label, dayIdx) => {
                  const active = weeklyDays.includes(dayIdx);
                  return (
                    <button
                      key={label}
                      type="button"
                      onClick={() =>
                        setWeeklyDays((prev) =>
                          prev.includes(dayIdx)
                            ? prev.filter((d) => d !== dayIdx)
                            : [...prev, dayIdx],
                        )
                      }
                      className={cn(
                        "h-8 w-9 rounded-md border text-xs font-medium transition-colors",
                        active
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-background text-muted-foreground hover:text-foreground",
                      )}
                      aria-pressed={active}
                    >
                      {label.slice(0, 1)}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          {mode === "monthly" && (
            <div className="flex flex-col gap-1">
              <label htmlFor="builder-dom" className="text-xs font-medium">
                On day of month
              </label>
              <Input
                id="builder-dom"
                type="number"
                min={1}
                max={31}
                value={monthlyDay}
                onChange={(e) =>
                  setMonthlyDay(
                    Math.min(31, Math.max(1, Number(e.target.value) || 1)),
                  )
                }
                className="w-24"
              />
            </div>
          )}
        </div>
      )}

      {mode === "advanced" && (
        <div className="flex flex-col gap-1">
          <label htmlFor="builder-raw-cron" className="text-xs font-medium">
            Cron expression
          </label>
          <Input
            id="builder-raw-cron"
            value={cron}
            onChange={(e) => onCronChange(e.target.value)}
            placeholder="0 9 * * 1-5"
            className="font-mono text-sm"
          />
          <p className="text-[11px] text-muted-foreground">
            Standard 5-field cron — minute hour day-of-month month day-of-week.
          </p>
        </div>
      )}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-0.5">
          <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
            Cron
          </span>
          <span className="font-mono text-xs">{cron || "—"}</span>
        </div>
        {mode !== "advanced" && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setMode("advanced")}
            className="self-end text-xs text-muted-foreground"
          >
            <Code2 className="mr-1 h-3 w-3" aria-hidden="true" />
            Edit raw cron
          </Button>
        )}
      </div>

      <NextFiresPreview cron={cron} timezone={timezone} />
    </div>
  );
}
