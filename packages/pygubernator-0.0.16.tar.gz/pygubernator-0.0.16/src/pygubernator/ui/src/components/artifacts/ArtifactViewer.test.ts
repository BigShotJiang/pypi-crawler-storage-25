import { describe, expect, it } from "vitest";

import { pickRenderer } from "./ArtifactViewer";

describe("pickRenderer", () => {
  it.each([
    ["markdown", "markdown"],
    ["table", "table"],
    ["csv", "table"],
    ["html", "html"],
    ["image", "image"],
    ["json", "json"],
    ["text", "text"],
    // Unknown types fall through to the plain-text renderer so the user
    // still sees *something* rather than a blank panel.
    ["notebook", "text"],
    ["pdf", "text"],
    ["", "text"],
  ])("maps %s -> %s", (input, expected) => {
    expect(pickRenderer(input)).toBe(expected);
  });
});
