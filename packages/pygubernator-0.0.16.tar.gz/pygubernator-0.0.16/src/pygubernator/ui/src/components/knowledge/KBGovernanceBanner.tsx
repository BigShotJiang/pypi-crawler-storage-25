"use client";

import { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Loader2,
  ShieldCheck
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toaster";
import { ApiError } from "@/lib/api";
import { kbApi, type GovernanceReport } from "@/lib/api/kb";

/**
 * Compact "Check governance" banner embedded in the ``/knowledge`` header.
 *
 * First render: a single button. Clicking it calls the SHACL validator
 * via the pygubernator proxy → pycharter route, then swaps the button
 * for a conforms-or-violation summary. An expand toggle reveals the
 * individual violations (focus IRI, path, message, severity).
 *
 * Layout is pure flex / document-flow — no absolute positioning. The
 * banner collapses gracefully on narrow viewports: the summary wraps,
 * and the violation list uses its own `<ul>` stacked vertically.
 */
export default function KBGovernanceBanner() {
  const { toast } = useToast();
  const [report, setReport] = useState<GovernanceReport | null>(null);
  const [running, setRunning] = useState(false);
  const [expanded, setExpanded] = useState(false);

  async function runCheck() {
    setRunning(true);
    try {
      const result = await kbApi.validateGovernance({});
      setReport(result);
      setExpanded(!result.conforms);
      toast(
        result.conforms
          ? "Governance: no violations"
          : `Governance: ${result.error_count} violation(s)`,
        result.conforms ? "success" : "error"
      );
    } catch (exc) {
      const message =
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Governance check failed";
      toast(`Governance check failed: ${message}`, "error");
    } finally {
      setRunning(false);
    }
  }

  if (report === null) {
    return (
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border bg-muted/10 px-3 py-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ShieldCheck className="h-4 w-4" aria-hidden="true" />
          <span>Validate the concept graph against the bundled SHACL shapes.</span>
        </div>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => void runCheck()}
          disabled={running}
          className="gap-1.5"
        >
          {running ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
          ) : (
            <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
          )}
          Check governance
        </Button>
      </div>
    );
  }

  const conforms = report.conforms;
  return (
    <div
      className={`rounded-md border px-3 py-2 ${
        conforms
          ? "border-emerald-500/30 bg-emerald-500/5"
          : "border-destructive/40 bg-destructive/5"
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 text-sm">
          {conforms ? (
            <CheckCircle2 className="h-4 w-4 text-emerald-500" aria-hidden="true" />
          ) : (
            <AlertTriangle className="h-4 w-4 text-destructive" aria-hidden="true" />
          )}
          <span className="font-medium">
            {conforms
              ? "Governance: conforms"
              : `Governance: ${report.error_count} violation${
                  report.error_count === 1 ? "" : "s"
                }`}
          </span>
          {report.warning_count > 0 && (
            <Badge variant="outline" className="font-normal">
              {report.warning_count} warning{report.warning_count === 1 ? "" : "s"}
            </Badge>
          )}
          {report.info_count > 0 && (
            <Badge variant="outline" className="font-normal">
              {report.info_count} info
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => void runCheck()}
            disabled={running}
            className="gap-1.5 text-xs"
          >
            {running ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
            )}
            Re-check
          </Button>
          {report.violations.length > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setExpanded((prev) => !prev)}
              className="gap-1.5 text-xs"
              aria-expanded={expanded}
            >
              {expanded ? (
                <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
              )}
              {expanded ? "Hide" : "Show"} details
            </Button>
          )}
        </div>
      </div>

      {expanded && report.violations.length > 0 && (
        <ul className="mt-3 flex flex-col gap-2">
          {report.violations.map((violation, idx) => (
            <li
              key={`${violation.focus_node}|${violation.path}|${idx}`}
              className="rounded-md border bg-background px-3 py-2 text-xs"
            >
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  variant="outline"
                  className={`font-normal ${
                    violation.severity === "Violation"
                      ? "border-destructive/50 text-destructive"
                      : violation.severity === "Warning"
                        ? "border-amber-500/50 text-amber-600"
                        : ""
                  }`}
                >
                  {violation.severity}
                </Badge>
                <span className="truncate font-mono text-[11px]">
                  {violation.focus_node}
                </span>
                {violation.path && (
                  <span className="truncate text-[11px] text-muted-foreground">
                    path: {violation.path}
                  </span>
                )}
              </div>
              {violation.message && (
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {violation.message}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
