"use client";

import { useEffect } from "react";

import { apiUrl } from "@/lib/api";
import { APP_NAME, THEME_STORAGE_KEY } from "@/lib/constants";
import { useAppConfigStore, selectSetAppConfig } from "@/stores/app-config";

function persistTheme(theme: string) {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    /* ignore */
  }
}

/**
 * Load theme / app name from `/api/v1/ui/config` (backed by pygubernator.cfg + env).
 *
 * We always fetch when the API is reachable. Do not skip fetch just because
 * `window.__APP_CONFIG__` exists — that blocks dev (Next never injects it) and can
 * leave stale values from a previous `pygubernator ui serve` session. Server-injected
 * HTML from `ui serve` is still overwritten after fetch succeeds.
 */
export default function ThemeFromConfig() {
  const setAppConfig = useAppConfigStore(selectSetAppConfig);

  useEffect(() => {
    if (typeof window === "undefined") return;

    // Unauthenticated endpoint: theme + app name live in ``pygubernator.cfg``
    // and are safe to expose pre-login, so we bypass ``apiGet`` (which adds
    // auth headers) and go through ``apiUrl()`` directly for URL building.
    const url = apiUrl("/api/v1/ui/config");

    fetch(url, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { theme?: string; app_name?: string } | null) => {
        if (!data) {
          // Fallback: optional server-injected script (pygubernator ui serve)
          if (window.__APP_CONFIG__?.theme || window.__APP_CONFIG__?.appName) {
            setAppConfig({
              appName: window.__APP_CONFIG__?.appName ?? APP_NAME,
              theme: window.__APP_CONFIG__?.theme ?? "light",
              version: window.__APP_CONFIG__?.version ?? ""
            });
            persistTheme(window.__APP_CONFIG__?.theme ?? "light");
          }
          return;
        }
        const theme = data.theme ?? "light";
        const appName = data.app_name?.trim() || APP_NAME;
        setAppConfig({
          appName,
          theme,
          version: window.__APP_CONFIG__?.version ?? ""
        });
        if (typeof document !== "undefined") {
          document.title = `${appName} — Control Plane`;
        }
        persistTheme(theme);
        window.__APP_CONFIG__ = {
          ...window.__APP_CONFIG__,
          theme,
          appName
        };
      })
      .catch(() => {
        if (window.__APP_CONFIG__?.theme || window.__APP_CONFIG__?.appName) {
          setAppConfig({
            appName: window.__APP_CONFIG__?.appName ?? APP_NAME,
            theme: window.__APP_CONFIG__?.theme ?? "light",
            version: window.__APP_CONFIG__?.version ?? ""
          });
          persistTheme(window.__APP_CONFIG__?.theme ?? "light");
        }
      });
  }, [setAppConfig]);

  return null;
}
