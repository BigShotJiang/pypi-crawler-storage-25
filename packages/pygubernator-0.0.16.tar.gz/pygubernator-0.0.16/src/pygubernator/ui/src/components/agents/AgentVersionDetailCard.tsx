"use client";

import type { AgentRegistryVersionRow } from "@/components/agents/AgentRegistryDetailView";

/**
 * Read-only details pane for a single :class:`AgentVersion`.
 *
 * Rendered inline below the row in the registry's version table when a
 * user expands it. All content is presentation — no fetching, no state.
 */
export function AgentVersionDetailCard({
  version,
}: {
  version: AgentRegistryVersionRow;
}) {
  const toolEntries = Object.entries(version.tools ?? {});
  const configEntries = Object.entries(version.config ?? {});
  return (
    <div className="space-y-3 text-xs">
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
        <dt className="text-muted-foreground">Version id</dt>
        <dd className="break-all font-mono">{version.id}</dd>
        <dt className="text-muted-foreground">Model</dt>
        <dd>{version.model ?? <em className="text-muted-foreground">—</em>}</dd>
        {version.spec_fingerprint ? (
          <>
            <dt className="text-muted-foreground">Spec fingerprint</dt>
            <dd className="break-all font-mono">{version.spec_fingerprint}</dd>
          </>
        ) : null}
        {version.spec_path ? (
          <>
            <dt className="text-muted-foreground">Spec path</dt>
            <dd className="break-all font-mono">{version.spec_path}</dd>
          </>
        ) : null}
      </dl>

      {version.prompt ? (
        <details>
          <summary className="cursor-pointer font-medium text-muted-foreground">
            System prompt
          </summary>
          <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap rounded border bg-background p-2">
            {version.prompt}
          </pre>
        </details>
      ) : null}

      <div>
        <p className="font-medium text-muted-foreground">Tools ({toolEntries.length})</p>
        {toolEntries.length === 0 ? (
          <p className="italic text-muted-foreground">No tools bound.</p>
        ) : (
          <ul className="flex flex-wrap gap-1">
            {toolEntries.map(([name]) => (
              <li
                key={name}
                className="rounded border bg-background px-1.5 py-0.5 font-mono"
                title={JSON.stringify(version.tools?.[name], null, 2)}
              >
                {name}
              </li>
            ))}
          </ul>
        )}
      </div>

      {configEntries.length > 0 ? (
        <details>
          <summary className="cursor-pointer font-medium text-muted-foreground">
            Config ({configEntries.length})
          </summary>
          <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded border bg-background p-2">
            {JSON.stringify(version.config, null, 2)}
          </pre>
        </details>
      ) : null}

      {version.spec_json ? (
        <details>
          <summary className="cursor-pointer font-medium text-muted-foreground">
            Compiled spec
          </summary>
          <pre className="mt-1 max-h-64 overflow-auto whitespace-pre-wrap rounded border bg-background p-2">
            {JSON.stringify(version.spec_json, null, 2)}
          </pre>
        </details>
      ) : null}
    </div>
  );
}
