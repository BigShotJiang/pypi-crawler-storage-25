"use client";

import { useEffect, useState } from "react";

import { apiGet } from "@/lib/api";

/**
 * Latest heartbeat payload returned by ``GET /api/v1/agents/heartbeats``.
 *
 * Mirrors the Pydantic ``AgentHeartbeatOut`` model. The fields we care
 * about for the indicator itself are ``is_stale`` and
 * ``seconds_since_beat``; the rest come along for the tooltip.
 */
interface HeartbeatItem {
  agent_id: string;
  run_id: string | null;
  workflow_id: string | null;
  status: string;
  created_at: string;
  seconds_since_beat: number;
  is_stale: boolean;
  details?: Record<string, unknown>;
}

interface HeartbeatsResponse {
  items: HeartbeatItem[];
  threshold_s: number;
}

interface AgentHeartbeatIndicatorProps {
  /** Agent whose latest heartbeat we want to show. */
  agentId: string;
  /** Stale cutoff override (seconds). Defaults to the server-side default. */
  thresholdSeconds?: number;
}

function formatAge(seconds: number): string {
  if (seconds < 60) return `${Math.round(seconds)}s ago`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m ago`;
  return `${Math.round(seconds / 3600)}h ago`;
}

/**
 * Compact liveness dot for an agent's most recent heartbeat.
 *
 * Renders nothing when the agent has no heartbeat rows — that's the
 * steady state for non-autonomous agents and we don't want a neutral
 * grey dot cluttering every agent's header. For autonomous agents the
 * dot is green (fresh) or red (stale), with a tooltip carrying the age
 * plus run / workflow context.
 */
export function AgentHeartbeatIndicator({
  agentId,
  thresholdSeconds,
}: AgentHeartbeatIndicatorProps) {
  const [beat, setBeat] = useState<HeartbeatItem | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const params: Record<string, string | number> = { agent_id: agentId };
    if (thresholdSeconds !== undefined) {
      params.threshold_s = thresholdSeconds;
    }
    void (async () => {
      try {
        const res = await apiGet<HeartbeatsResponse>(
          "/api/v1/agents/heartbeats",
          params,
        );
        if (cancelled) return;
        setBeat(res.items[0] ?? null);
      } catch {
        // Silent — the indicator is purely informational; a failing
        // fetch shouldn't break the surrounding agent detail view.
      } finally {
        if (!cancelled) setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [agentId, thresholdSeconds]);

  if (!loaded || beat === null) return null;

  const age = formatAge(beat.seconds_since_beat);
  const title = beat.is_stale
    ? `Stale: last beat ${age} (status: ${beat.status})`
    : `Live: last beat ${age} (status: ${beat.status})`;

  return (
    <span
      className="inline-flex items-center gap-1 text-[10px] text-muted-foreground"
      title={title}
      aria-label={title}
    >
      <span
        className={`inline-block h-2 w-2 rounded-full ${
          beat.is_stale ? "bg-red-500" : "bg-green-500"
        }`}
        aria-hidden="true"
      />
      <span>{beat.is_stale ? "stale" : "alive"}</span>
    </span>
  );
}
