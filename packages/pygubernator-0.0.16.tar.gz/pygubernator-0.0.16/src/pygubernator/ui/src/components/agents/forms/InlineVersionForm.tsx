"use client";

/**
 * Manual / inline ``AgentVersion`` create form (Phase R §R.3).
 *
 * The "Inline" tab on the new-version section: provider preset →
 * model dropdown → optional API base / key → optional system
 * prompt. State is owned by the parent via a ``useReducer`` so we
 * keep the field cluster (``version``, ``model``, ``prompt``,
 * ``provider_name``, ``api_base``, ``api_key``) in one place
 * instead of seven sibling ``useState`` calls.
 *
 * Pure presentation: the parent provides ``state`` + ``dispatch``
 * and an ``onSubmit`` handler; all API calls live in the parent.
 */

import type { FormEvent } from "react";
import { Plus } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import type {
  InlineVersionFormAction,
  InlineVersionFormState,
  ProviderPreset,
} from "./inline-version-form-state";

interface InlineVersionFormProps {
  state: InlineVersionFormState;
  dispatch: (action: InlineVersionFormAction) => void;
  providerPresets: ProviderPreset[];
  busy: boolean;
  onSubmit: (event: FormEvent) => void;
}

export function InlineVersionForm({
  state,
  dispatch,
  providerPresets,
  busy,
  onSubmit,
}: InlineVersionFormProps) {
  const preset = providerPresets.find((p) => p.name === state.provider_name);

  return (
    <form className="grid gap-3 md:grid-cols-2" onSubmit={onSubmit}>
      <Input
        placeholder="Version label (e.g. 1.0.0)"
        value={state.version}
        onChange={(e) =>
          dispatch({ type: "set_field", field: "version", value: e.target.value })
        }
        required
      />
      <div className="flex flex-col gap-1">
        <select
          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          value={state.provider_name}
          onChange={(e) => {
            const name = e.target.value;
            const next = providerPresets.find((p) => p.name === name);
            dispatch({ type: "select_provider", provider_name: name, preset: next });
          }}
        >
          <option value="">Provider (optional)</option>
          {providerPresets.map((p) => (
            <option key={p.name} value={p.name}>
              {p.name.charAt(0).toUpperCase() + p.name.slice(1)} — {p.description}
            </option>
          ))}
        </select>
      </div>

      {preset === undefined ? (
        <Input
          placeholder="Model (optional)"
          value={state.model}
          onChange={(e) =>
            dispatch({ type: "set_field", field: "model", value: e.target.value })
          }
        />
      ) : (
        <ProviderFields
          preset={preset}
          state={state}
          dispatch={dispatch}
        />
      )}

      <div className="md:col-span-2">
        <textarea
          className="flex min-h-[88px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          placeholder="System prompt (optional)"
          value={state.prompt}
          onChange={(e) =>
            dispatch({ type: "set_field", field: "prompt", value: e.target.value })
          }
        />
      </div>

      <div className="md:col-span-2">
        <Button type="submit" size="sm" disabled={busy}>
          <Plus className="mr-1 h-4 w-4" /> Create version
        </Button>
      </div>
    </form>
  );
}

interface ProviderFieldsProps {
  preset: ProviderPreset;
  state: InlineVersionFormState;
  dispatch: (action: InlineVersionFormAction) => void;
}

function ProviderFields({ preset, state, dispatch }: ProviderFieldsProps) {
  return (
    <>
      {preset.models.length > 0 ? (
        <div className="flex flex-col gap-1">
          <select
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            value={state.model}
            onChange={(e) =>
              dispatch({
                type: "set_field",
                field: "model",
                value: e.target.value,
              })
            }
          >
            {preset.models.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </div>
      ) : (
        <Input
          placeholder="Model name (e.g. llama3.1)"
          value={state.model}
          onChange={(e) =>
            dispatch({
              type: "set_field",
              field: "model",
              value: e.target.value,
            })
          }
        />
      )}

      {preset.provider_type === "openai_compatible" ? (
        <div className="flex flex-col gap-1">
          <Input
            placeholder="API Base URL"
            value={state.api_base}
            onChange={(e) =>
              dispatch({
                type: "set_field",
                field: "api_base",
                value: e.target.value,
              })
            }
          />
          <p className="text-[10px] text-muted-foreground">
            Server endpoint (pre-filled from preset)
          </p>
        </div>
      ) : null}

      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <Input
            type="password"
            placeholder={
              preset.requires_api_key ? "API Key (required)" : "API Key (optional)"
            }
            value={state.api_key}
            onChange={(e) =>
              dispatch({
                type: "set_field",
                field: "api_key",
                value: e.target.value,
              })
            }
          />
          <span
            className={cn(
              "shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium",
              preset.requires_api_key
                ? "bg-red-100 text-red-700"
                : "bg-green-100 text-green-700",
            )}
          >
            {preset.requires_api_key ? "Key required" : "No key needed"}
          </span>
        </div>
        {!preset.requires_api_key ? (
          <p className="text-[10px] text-muted-foreground">
            Leave blank for local servers
          </p>
        ) : null}
      </div>
    </>
  );
}
