"use client";

import { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAgentEditorStore } from "@/stores/agent-editor";
import { componentPresetByType } from "@/lib/agent-components";

function NumberField({
  value,
  onChange,
}: {
  value: unknown;
  onChange: (next: number) => void;
}) {
  return (
    <Input
      type="number"
      value={typeof value === "number" ? value : 0}
      onChange={(event) => onChange(Number(event.target.value))}
    />
  );
}

export default function AgentInspectorPanel() {
  const selectedNodeId = useAgentEditorStore((s) => s.selectedNodeId);
  const spec = useAgentEditorStore((s) => s.spec);
  const updateNodeConfig = useAgentEditorStore((s) => s.updateNodeConfig);
  const updateNode = useAgentEditorStore((s) => s.updateNode);
  const setSelectedNodeId = useAgentEditorStore((s) => s.setSelectedNodeId);

  const node = useMemo(
    () => (selectedNodeId ? spec.nodes[selectedNodeId] ?? null : null),
    [selectedNodeId, spec.nodes],
  );
  const [rawConfig, setRawConfig] = useState("{}");
  const [parseError, setParseError] = useState<string | null>(null);

  useEffect(() => {
    if (!node) return;
    setRawConfig(JSON.stringify(node.config ?? {}, null, 2));
    setParseError(null);
  }, [node]);

  if (!node || !selectedNodeId) return null;
  const preset = componentPresetByType(node.type);
  const config = node.config ?? {};

  const patchConfig = (key: string, value: unknown) => {
    updateNodeConfig(selectedNodeId, { ...config, [key]: value });
  };

  return (
    <div className="absolute inset-y-0 right-0 z-20 flex w-[340px] flex-col border-l bg-background shadow-lg">
      <div className="flex items-center justify-between border-b px-4 py-3">
        <div>
          <p className="text-sm font-semibold">{node.label ?? selectedNodeId}</p>
          <p className="text-xs text-muted-foreground">{node.type}</p>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setSelectedNodeId(null)}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-3 overflow-y-auto p-4">
        <label className="block space-y-1">
          <span className="text-xs text-muted-foreground">Component label</span>
          <Input
            value={node.label ?? ""}
            onChange={(event) =>
              updateNode(selectedNodeId, { label: event.target.value })
            }
          />
        </label>

        {node.type === "chat_model" ? (
          <>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Model</span>
              <Input
                value={typeof config.model === "string" ? config.model : ""}
                onChange={(event) => patchConfig("model", event.target.value)}
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Provider</span>
              <Input
                value={
                  typeof config.provider === "string" ? config.provider : ""
                }
                onChange={(event) =>
                  patchConfig("provider", event.target.value)
                }
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Temperature</span>
              <NumberField
                value={config.temperature}
                onChange={(next) => patchConfig("temperature", next)}
              />
            </label>
          </>
        ) : null}

        {node.type === "tool" ? (
          <>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Name</span>
              <Input
                value={typeof config.name === "string" ? config.name : ""}
                onChange={(event) => patchConfig("name", event.target.value)}
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Module</span>
              <Input
                value={typeof config.module === "string" ? config.module : ""}
                onChange={(event) => patchConfig("module", event.target.value)}
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Function</span>
              <Input
                value={
                  typeof config.function === "string" ? config.function : ""
                }
                onChange={(event) =>
                  patchConfig("function", event.target.value)
                }
              />
            </label>
          </>
        ) : null}

        {node.type === "memory" ? (
          <>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Namespace</span>
              <Input
                value={
                  typeof config.namespace === "string" ? config.namespace : ""
                }
                onChange={(event) =>
                  patchConfig("namespace", event.target.value)
                }
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Strategy</span>
              <Input
                value={
                  typeof config.strategy === "string" ? config.strategy : ""
                }
                onChange={(event) =>
                  patchConfig("strategy", event.target.value)
                }
              />
            </label>
          </>
        ) : null}

        {node.type === "router" ? (
          <>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Strategy</span>
              <Input
                value={
                  typeof config.strategy === "string" ? config.strategy : ""
                }
                onChange={(event) =>
                  patchConfig("strategy", event.target.value)
                }
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">
                Default target
              </span>
              <Input
                value={
                  typeof config.default_target === "string"
                    ? config.default_target
                    : ""
                }
                onChange={(event) =>
                  patchConfig("default_target", event.target.value)
                }
              />
            </label>
          </>
        ) : null}

        {node.type === "validator" ? (
          <>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Mode</span>
              <Input
                value={typeof config.mode === "string" ? config.mode : ""}
                onChange={(event) => patchConfig("mode", event.target.value)}
              />
            </label>
            <label className="block space-y-1">
              <span className="text-xs text-muted-foreground">Policy</span>
              <Input
                value={typeof config.policy === "string" ? config.policy : ""}
                onChange={(event) => patchConfig("policy", event.target.value)}
              />
            </label>
          </>
        ) : null}

        {preset?.description ? (
          <p className="text-[11px] text-muted-foreground">{preset.description}</p>
        ) : null}

        <label className="block space-y-1">
          <span className="text-xs text-muted-foreground">Config JSON</span>
          <textarea
            className="min-h-[180px] w-full rounded-md border border-input bg-background px-3 py-2 text-xs"
            value={rawConfig}
            onChange={(event) => {
              const next = event.target.value;
              setRawConfig(next);
              try {
                const parsed = JSON.parse(next) as Record<string, unknown>;
                updateNodeConfig(selectedNodeId, parsed);
                setParseError(null);
              } catch {
                setParseError("Invalid JSON");
              }
            }}
          />
          {parseError ? (
            <span className="text-[11px] text-destructive">{parseError}</span>
          ) : null}
        </label>
      </div>
    </div>
  );
}
