import { describe, expect, it } from "vitest";

import { parseCsv } from "./TableRenderer";

describe("parseCsv", () => {
  it("parses a simple two-row CSV", () => {
    expect(parseCsv("a,b,c\n1,2,3")).toEqual([
      ["a", "b", "c"],
      ["1", "2", "3"],
    ]);
  });

  it("handles quoted fields with embedded commas", () => {
    expect(parseCsv('name,note\n"Smith, Jr.",hello')).toEqual([
      ["name", "note"],
      ["Smith, Jr.", "hello"],
    ]);
  });

  it("handles escaped double-quotes inside quoted fields", () => {
    expect(parseCsv('title\n"She said ""hi"""')).toEqual([
      ["title"],
      ['She said "hi"'],
    ]);
  });

  it("handles embedded newlines inside quoted fields", () => {
    expect(parseCsv('title\n"line1\nline2"')).toEqual([
      ["title"],
      ["line1\nline2"],
    ]);
  });

  it("handles CRLF line endings", () => {
    expect(parseCsv("a,b\r\n1,2\r\n3,4")).toEqual([
      ["a", "b"],
      ["1", "2"],
      ["3", "4"],
    ]);
  });

  it("drops a trailing empty row produced by a final newline", () => {
    expect(parseCsv("a,b\n1,2\n")).toEqual([
      ["a", "b"],
      ["1", "2"],
    ]);
  });

  it("respects a custom delimiter (TSV)", () => {
    expect(parseCsv("a\tb\n1\t2", "\t")).toEqual([
      ["a", "b"],
      ["1", "2"],
    ]);
  });

  it("returns an empty array for empty input", () => {
    expect(parseCsv("")).toEqual([]);
  });
});
