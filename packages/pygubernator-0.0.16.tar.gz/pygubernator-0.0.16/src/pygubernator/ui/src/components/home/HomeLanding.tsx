"use client";

import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRight,
  BookOpen,
  MessageSquare,
  Sparkles,
  Workflow
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { PageContainer } from "@/components/layout/PageContainer";
import { ROUTES } from "@/lib/constants";
import { useAppConfigStore, selectAppName } from "@/stores/app-config";
import SetupChecklist from "@/components/home/SetupChecklist";

interface GuidedPath {
  title: string;
  description: string;
  href: string;
  cta: string;
  Icon: LucideIcon;
  accent: string;
}

// The three guided paths map to the three task clusters a new user
// typically wants: "use a pre-made workflow", "try an agent", "build
// from scratch". Keep the list to three so the landing stays focused.
const GUIDED_PATHS: GuidedPath[] = [
  {
    title: "Start from a template",
    description:
      "Pick a ready-made workflow — scrape a URL, run daily research, post to Slack — and customize it in minutes.",
    href: ROUTES.TEMPLATES,
    cta: "Browse templates",
    Icon: Sparkles,
    accent: "text-primary"
  },
  {
    title: "Chat with an agent",
    description:
      "Talk to a pre-configured agent to try tool use, memory, and policy enforcement without wiring any nodes.",
    href: ROUTES.CHAT,
    cta: "Open chat",
    Icon: MessageSquare,
    accent: "text-sky-500"
  },
  {
    title: "Build from scratch",
    description:
      "Drop into a blank canvas and wire nodes together. Great for custom integrations and learning by doing.",
    href: `${ROUTES.WORKFLOW_EDITOR}?new=1`,
    cta: "Open editor",
    Icon: Workflow,
    accent: "text-emerald-500"
  }
];

/**
 * Landing page shown at ``/`` after login. Three guided paths plus a
 * setup checklist. Keeps the page short so a new user can see every
 * next step without scrolling.
 */
export default function HomeLanding() {
  const appName = useAppConfigStore(selectAppName);

  return (
    <PageContainer>
      <div className="flex flex-col gap-8 pb-12 pt-4">
        <header className="flex flex-col gap-2">
          <h1 className="text-3xl font-semibold tracking-tight">Welcome to {appName}</h1>
          <p className="max-w-2xl text-sm text-muted-foreground">
            Pygubernator is a config-driven workflow and multi-agent platform. Pick a path to get
            started — you can always switch later.
          </p>
        </header>

        <SetupChecklist />

        <section aria-labelledby="guided-paths-heading" className="flex flex-col gap-4">
          <h2 id="guided-paths-heading" className="text-lg font-semibold">
            Pick a starting point
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {GUIDED_PATHS.map((path) => {
              const Icon = path.Icon;
              return (
                <Link
                  key={path.title}
                  href={path.href}
                  className="group rounded-lg transition-shadow hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                >
                  <Card className="h-full border-border/60">
                    <CardHeader className="pb-3">
                      <div className="flex items-center gap-2">
                        <Icon className={`h-5 w-5 ${path.accent}`} aria-hidden="true" />
                        <CardTitle className="text-base">{path.title}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent className="flex h-full flex-col justify-between gap-4 pt-0">
                      <CardDescription className="text-sm leading-relaxed">
                        {path.description}
                      </CardDescription>
                      <span className="flex items-center gap-1 text-sm font-medium text-primary">
                        {path.cta}
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                      </span>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </section>

        <section aria-labelledby="learn-heading" className="flex flex-col gap-3">
          <h2 id="learn-heading" className="text-lg font-semibold">
            Learn the basics
          </h2>
          <div className="flex flex-wrap gap-3">
            <Link
              href="https://github.com/statfyi/pygubernator#readme"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-md border bg-background px-3 py-2 text-sm font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <BookOpen className="h-4 w-4" aria-hidden="true" />
              Read the docs
            </Link>
            <Link
              href={`${ROUTES.WORKFLOW_EDITOR}?area=agents`}
              className="inline-flex items-center gap-2 rounded-md border bg-background px-3 py-2 text-sm font-medium hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
            >
              <Workflow className="h-4 w-4" aria-hidden="true" />
              See existing agents
            </Link>
          </div>
        </section>
      </div>
    </PageContainer>
  );
}
