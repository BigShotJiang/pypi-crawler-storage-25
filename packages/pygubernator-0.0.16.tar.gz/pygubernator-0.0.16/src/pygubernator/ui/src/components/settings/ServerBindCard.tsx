"use client";

import { useEffect, useState } from "react";

import { getControlPlaneInfo, ApiError } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export function ServerBindCard() {
  const [text, setText] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const info = await getControlPlaneInfo();
        if (cancelled) {
          return;
        }
        setText(
          `API listens on ${info.api_host}:${info.api_port} (public URL ${info.api_url}). UI dev server: ${info.ui_host}:${info.ui_port}.`
        );
      } catch (e) {
        if (!cancelled) {
          setError(
            e instanceof ApiError
              ? e.message
              : "Could not load server bind settings."
          );
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Server bind address</CardTitle>
        <CardDescription>
          From the running API process (environment and{" "}
          <code className="text-xs bg-muted px-1 py-0.5 rounded">
            pygubernator.cfg
          </code>
          ). This is not the same as the browser URL above unless they match.
        </CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        {error && <p className="text-destructive">{error}</p>}
        {text && !error && <p>{text}</p>}
        {!text && !error && <p>Loading…</p>}
      </CardContent>
    </Card>
  );
}
