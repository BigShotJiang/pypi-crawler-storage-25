"use client";

import { useState } from "react";
import {
  BookMarked,
  CheckCircle2,
  Clock,
  ExternalLink,
  KeyRound,
  Loader2,
  Network,
  ShieldQuestion,
  Trash2,
  X
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toaster";
import { ApiError } from "@/lib/api";
import { kbApi, type BindingState, type KBChunk } from "@/lib/api/kb";

import KBBindingHistoryPanel from "./KBBindingHistoryPanel";
import KBConceptGraphPanel from "./KBConceptGraphPanel";

interface KBChunkDrawerProps {
  chunk: KBChunk | null;
  onClose: () => void;
  /** Called after a promotion; receives the updated chunk so the caller refreshes. */
  onBindingChanged: (updated: KBChunk) => void;
  /** Called after a bulk-delete by scope (the chunk's own scope is used). */
  onScopeDeleted?: () => void;
}

const STATES: readonly BindingState[] = [
  "unmapped",
  "suggested",
  "mapped",
  "approved"
];

type DrawerTab = "overview" | "concept-graph" | "history";

const TABS: { id: DrawerTab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "concept-graph", label: "Concept graph" },
  { id: "history", label: "History" }
];

/**
 * Right-hand drawer that renders the full text of a chunk, its
 * bindings, and the single-click binding-state promotion buttons.
 *
 * The drawer is a controlled overlay — render it unconditionally and
 * pass ``chunk=null`` to hide it.
 */
export default function KBChunkDrawer({
  chunk,
  onClose,
  onBindingChanged,
  onScopeDeleted
}: KBChunkDrawerProps) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [activeTab, setActiveTab] = useState<DrawerTab>("overview");

  if (chunk === null) return null;

  async function promote(state: BindingState) {
    if (!chunk) return;
    setBusy(true);
    try {
      await kbApi.promoteBinding(chunk.chunk_id, state);
      onBindingChanged({ ...chunk, binding_state: state });
      toast(`Binding state → ${state}`, "success");
    } catch (exc) {
      const message =
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Promotion failed";
      toast(`Promote failed: ${message}`, "error");
    } finally {
      setBusy(false);
    }
  }

  async function deleteScope() {
    if (!chunk) return;
    // Prefer the narrowest scope available so bulk delete is obvious.
    const meta = chunk.metadata ?? {};
    const scope = {
      run_id:
        typeof meta.run_id === "string" ? String(meta.run_id) : undefined,
      workflow_id:
        typeof meta.workflow_id === "string"
          ? String(meta.workflow_id)
          : undefined,
      agent_id:
        typeof meta.agent_id === "string" ? String(meta.agent_id) : undefined
    };
    const narrowest = scope.run_id
      ? { run_id: scope.run_id }
      : scope.workflow_id
        ? { workflow_id: scope.workflow_id }
        : scope.agent_id
          ? { agent_id: scope.agent_id }
          : null;
    if (!narrowest) {
      toast(
        "This chunk has no scope metadata — delete skipped for safety.",
        "error"
      );
      return;
    }
    if (
      !window.confirm(
        `Delete every chunk in scope ${Object.entries(narrowest)
          .map(([k, v]) => `${k}=${v}`)
          .join(", ")}?`
      )
    ) {
      return;
    }
    setBusy(true);
    try {
      const res = await kbApi.bulkDelete(narrowest);
      toast(`Removed ${res.removed} chunk(s)`, "success");
      onScopeDeleted?.();
      onClose();
    } catch (exc) {
      const message =
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Delete failed";
      toast(`Delete failed: ${message}`, "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <aside
      role="dialog"
      aria-label="Chunk detail"
      className="fixed inset-y-0 right-0 z-40 flex w-full max-w-xl flex-col border-l bg-background shadow-xl"
    >
      <header className="flex items-start justify-between gap-3 border-b px-5 py-4">
        <div className="flex min-w-0 flex-col gap-1">
          <p className="truncate text-sm font-medium">{chunk.chunk_id}</p>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="outline" className="font-normal">
              {chunk.binding_state}
            </Badge>
            {chunk.contract_id && (
              <span className="inline-flex items-center gap-1">
                <BookMarked className="h-3 w-3" aria-hidden="true" />
                {chunk.contract_id}
              </span>
            )}
            {chunk.source_uri && (
              <a
                href={chunk.source_uri}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-primary hover:underline"
              >
                <ExternalLink className="h-3 w-3" aria-hidden="true" />
                source
              </a>
            )}
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="h-8 w-8 p-0"
          aria-label="Close chunk detail"
        >
          <X className="h-4 w-4" aria-hidden="true" />
        </Button>
      </header>

      <nav
        role="tablist"
        aria-label="Chunk detail tabs"
        className="flex items-center gap-1 border-b px-5 pt-2"
      >
        {TABS.map((tab) => {
          const active = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={active}
              id={`kb-tab-${tab.id}`}
              aria-controls={`kb-tabpanel-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-1.5 rounded-t-md border border-b-0 px-3 py-1.5 text-xs font-medium transition-colors ${
                active
                  ? "border-border bg-background text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.id === "concept-graph" && (
                <Network className="h-3.5 w-3.5" aria-hidden="true" />
              )}
              {tab.id === "history" && (
                <Clock className="h-3.5 w-3.5" aria-hidden="true" />
              )}
              {tab.label}
            </button>
          );
        })}
      </nav>

      <div
        role="tabpanel"
        id={`kb-tabpanel-${activeTab}`}
        aria-labelledby={`kb-tab-${activeTab}`}
        className="flex-1 overflow-y-auto px-5 py-4"
      >
        {activeTab === "overview" && (
          <>
            <div className="mb-4 flex flex-col gap-2">
              <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Chunk text
              </span>
              <pre className="whitespace-pre-wrap rounded-md border bg-muted/30 p-3 text-xs leading-relaxed">
                {chunk.text}
              </pre>
            </div>

            {chunk.concept_refs.length > 0 && (
              <section className="mb-4 flex flex-col gap-2">
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Concept bindings
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <KeyRound
                    className="h-3 w-3 text-muted-foreground"
                    aria-hidden="true"
                  />
                  {chunk.concept_refs.map((concept) => (
                    <Badge
                      key={concept}
                      variant="outline"
                      className="font-normal"
                    >
                      {concept}
                    </Badge>
                  ))}
                </div>
              </section>
            )}

            {Object.keys(chunk.metadata ?? {}).length > 0 && (
              <section className="mb-4 flex flex-col gap-2">
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Metadata
                </span>
                <pre className="overflow-auto rounded-md border bg-muted/30 p-3 text-[11px] leading-relaxed">
                  {JSON.stringify(chunk.metadata, null, 2)}
                </pre>
              </section>
            )}
          </>
        )}

        {activeTab === "concept-graph" && (
          <KBConceptGraphPanel conceptRefs={chunk.concept_refs} />
        )}

        {activeTab === "history" && (
          <KBBindingHistoryPanel
            chunkId={chunk.chunk_id}
            contractId={chunk.contract_id}
          />
        )}
      </div>

      <footer className="flex flex-col gap-3 border-t px-5 py-4">
        <div className="flex flex-col gap-1">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Promote binding
          </span>
          <div className="flex flex-wrap gap-2">
            {STATES.map((state) => (
              <Button
                key={state}
                type="button"
                variant={state === chunk.binding_state ? "default" : "outline"}
                size="sm"
                onClick={() => void promote(state)}
                disabled={busy || state === chunk.binding_state}
                className="gap-1.5 text-xs"
              >
                {state === "approved" ? (
                  <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                ) : (
                  <ShieldQuestion
                    className="h-3.5 w-3.5"
                    aria-hidden="true"
                  />
                )}
                {state}
              </Button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] text-muted-foreground">
            Deletions are bulk by scope — can&apos;t be undone.
          </span>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            onClick={() => void deleteScope()}
            disabled={busy}
          >
            {busy ? (
              <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
            ) : (
              <Trash2 className="mr-1 h-3.5 w-3.5" />
            )}
            Delete scope
          </Button>
        </div>
      </footer>
    </aside>
  );
}
