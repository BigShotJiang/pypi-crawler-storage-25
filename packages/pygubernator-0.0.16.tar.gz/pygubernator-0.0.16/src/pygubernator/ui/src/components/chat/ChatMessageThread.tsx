"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiGet, apiPost, ApiError } from "@/lib/api";
import { cn } from "@/lib/utils";

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface ChatMessageThreadProps {
  sessionId: string;
  onMessageSent: () => void;
}

export function ChatMessageThread({
  sessionId,
  onMessageSent,
}: ChatMessageThreadProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, []);

  useEffect(() => {
    async function loadMessages() {
      setLoading(true);
      setError(null);
      try {
        const data = await apiGet<{ messages: ChatMessage[] }>(
          `/api/v1/chat/sessions/${sessionId}/messages`
        );
        setMessages(data.messages);
      } catch (e) {
        if (e instanceof ApiError && e.status === 404) {
          setError("Session not found.");
        } else {
          setError(
            e instanceof Error ? e.message : "Failed to load messages."
          );
        }
      } finally {
        setLoading(false);
      }
    }
    loadMessages();
  }, [sessionId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || sending) return;

    setInput("");
    setSending(true);
    setError(null);

    // Optimistically add user message
    setMessages((prev) => [...prev, { role: "user", content: text }]);

    try {
      const data = await apiPost<
        { message: string },
        { response: string; session_id: string; message_count: number }
      >(`/api/v1/chat/sessions/${sessionId}/messages`, {
        message: text,
      });
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.response },
      ]);
      onMessageSent();
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Failed to send message."
      );
      // Remove the optimistic user message on failure
      setMessages((prev) => prev.slice(0, -1));
      setInput(text);
    } finally {
      setSending(false);
    }
  }, [input, sending, sessionId, onMessageSent]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        void handleSend();
      }
    },
    [handleSend]
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-sm text-muted-foreground">Loading messages...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Messages area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-sm text-muted-foreground text-center pt-8">
            No messages yet. Send a message to start the conversation.
          </p>
        )}
        {messages.map((msg, idx) => (
          <MessageBubble key={idx} message={msg} />
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className="rounded-lg px-4 py-2 bg-muted text-muted-foreground text-sm">
              <span className="animate-pulse">Thinking...</span>
            </div>
          </div>
        )}
      </div>

      {/* Error display */}
      {error && (
        <div className="px-4 pb-2">
          <div className="rounded-md border border-red-200 bg-red-50 p-2 text-sm text-red-800">
            {error}
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="border-t border-border p-4">
        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={sending}
            className="flex-1"
          />
          <Button
            onClick={() => void handleSend()}
            disabled={!input.trim() || sending}
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const isSystem = message.role === "system";

  if (isSystem) {
    return (
      <div className="flex justify-center">
        <div className="rounded-lg px-4 py-2 bg-muted/50 text-xs text-muted-foreground italic max-w-[80%]">
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "rounded-lg px-4 py-2 max-w-[80%] text-sm whitespace-pre-wrap",
          isUser
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-foreground"
        )}
      >
        {message.content}
      </div>
    </div>
  );
}
