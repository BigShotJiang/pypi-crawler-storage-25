"use client";

/**
 * Inline SQL sandbox for CSV / table artifacts (Phase 6 §6.1a-query).
 *
 * Renders below the CSV preview on an artifact view. Users type a
 * SELECT statement against the virtual ``artifact`` table, hit Run,
 * and the results appear as a second table with a truncated-row
 * indicator when the server caps the result set. Errors come back
 * from the sandbox as descriptive messages (e.g. "INSERT is not
 * allowed in the artifact SQL sandbox") and are rendered verbatim.
 */

import { useState } from "react";
import { Play } from "lucide-react";

import { Button } from "@/components/ui/button";
import { ApiError, queryArtifact } from "@/lib/api";
import type { ArtifactQueryResult } from "@/lib/api";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface ArtifactQueryPanelProps {
  runId: string;
  artifactId: string;
  /** Default value shown in the textarea when the panel mounts. */
  initialSql?: string;
  className?: string;
}

const DEFAULT_SQL = "SELECT * FROM artifact LIMIT 10";

export function ArtifactQueryPanel({
  runId,
  artifactId,
  initialSql,
  className,
}: ArtifactQueryPanelProps) {
  const [sql, setSql] = useState(initialSql ?? DEFAULT_SQL);
  const [result, setResult] = useState<ArtifactQueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [running, setRunning] = useState(false);

  const handleRun = async () => {
    setRunning(true);
    setError(null);
    try {
      const data = await queryArtifact(runId, artifactId, sql);
      setResult(data);
    } catch (err) {
      setResult(null);
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError("Query failed");
      }
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className={className}>
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-sm font-medium">Query this artifact</p>
        <span className="text-xs text-muted-foreground">
          Read-only · table name is <code>artifact</code>
        </span>
      </div>

      <textarea
        value={sql}
        onChange={(e) => setSql(e.target.value)}
        rows={3}
        spellCheck={false}
        className="w-full rounded-md border bg-background px-3 py-2 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/40"
        placeholder={DEFAULT_SQL}
        aria-label="SQL query"
      />

      <div className="mt-2 flex items-center gap-2">
        <Button
          onClick={() => void handleRun()}
          disabled={running || sql.trim().length === 0}
          size="sm"
        >
          <Play className="mr-1 h-3 w-3" />
          {running ? "Running…" : "Run"}
        </Button>
        {result && !error ? (
          <span className="text-xs text-muted-foreground">
            {result.row_count} row{result.row_count === 1 ? "" : "s"} ·{" "}
            {result.elapsed_ms}ms
            {result.truncated ? " · truncated" : ""}
          </span>
        ) : null}
      </div>

      {error ? (
        <p className="mt-2 rounded-md border border-red-200 bg-red-50 p-2 text-xs text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
          {error}
        </p>
      ) : null}

      {result && !error && result.row_count > 0 ? (
        <div className="mt-3 overflow-auto rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                {result.columns.map((c) => (
                  <TableHead key={c}>{c}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {result.rows.map((row, rIdx) => (
                <TableRow key={rIdx}>
                  {row.map((cell, cIdx) => (
                    <TableCell key={cIdx} className="font-mono text-xs">
                      {cell === null ? "" : String(cell)}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : null}

      {result && !error && result.row_count === 0 ? (
        <p className="mt-3 text-xs text-muted-foreground">
          Query returned zero rows.
        </p>
      ) : null}
    </div>
  );
}
