"use client";

/**
 * Minimal, dependency-free Markdown renderer for workflow artifacts.
 *
 * Covers the subset of Markdown that workflow reports typically emit:
 * ATX headings, paragraphs, fenced code blocks, inline code, bold,
 * italic, and nested unordered / ordered lists. Tables, links, images,
 * and blockquotes are out of scope for v1 — they render as literal text
 * rather than silently breaking. A future pass can swap this for
 * ``react-markdown + remark-gfm`` if richer content becomes common.
 *
 * Safety: we never set ``dangerouslySetInnerHTML``. Inline formatting is
 * rendered via React element trees built from escaped segments.
 */

import { Fragment, type ReactNode } from "react";

/** Rendering options for callers that want to override defaults. */
export interface MarkdownRendererProps {
  content: string;
  className?: string;
}

/** Inline-formatted children derived from a raw span of text. */
function renderInline(text: string): ReactNode {
  // Order matters: code first (greedy), then bold, then italic.
  const nodes: ReactNode[] = [];
  let remaining = text;
  let key = 0;

  const patterns: {
    re: RegExp;
    render: (m: RegExpMatchArray) => ReactNode;
  }[] = [
    {
      re: /`([^`]+)`/,
      render: (m) => (
        <code
          key={`inline-${key}`}
          className="rounded bg-muted px-1 py-0.5 font-mono text-[0.9em]"
        >
          {m[1]}
        </code>
      ),
    },
    {
      re: /\*\*([^*]+)\*\*/,
      render: (m) => <strong key={`b-${key}`}>{m[1]}</strong>,
    },
    {
      re: /(?<!\*)\*([^*]+)\*(?!\*)/,
      render: (m) => <em key={`i-${key}`}>{m[1]}</em>,
    },
  ];

  while (remaining.length > 0) {
    let bestIdx = -1;
    let bestMatch: RegExpMatchArray | null = null;
    let bestRender: ((m: RegExpMatchArray) => ReactNode) | null = null;

    for (const { re, render } of patterns) {
      const m = remaining.match(re);
      if (m && m.index !== undefined && (bestIdx === -1 || m.index < bestIdx)) {
        bestIdx = m.index;
        bestMatch = m;
        bestRender = render;
      }
    }

    if (!bestMatch || bestIdx < 0 || !bestRender) {
      nodes.push(<Fragment key={`txt-${key}`}>{remaining}</Fragment>);
      break;
    }
    if (bestIdx > 0) {
      nodes.push(
        <Fragment key={`txt-${key}`}>{remaining.slice(0, bestIdx)}</Fragment>,
      );
    }
    nodes.push(bestRender(bestMatch));
    remaining = remaining.slice(bestIdx + bestMatch[0].length);
    key += 1;
  }
  return <>{nodes}</>;
}

interface Block {
  kind:
    | "heading"
    | "paragraph"
    | "code"
    | "ul"
    | "ol";
  level?: number;
  language?: string | null;
  text?: string;
  items?: string[];
}

/** Tokenise raw Markdown into a flat sequence of block-level nodes. */
function tokenise(raw: string): Block[] {
  const blocks: Block[] = [];
  const lines = raw.replace(/\r\n/g, "\n").split("\n");
  let idx = 0;

  while (idx < lines.length) {
    const line = lines[idx];

    if (line.startsWith("```")) {
      const language = line.slice(3).trim() || null;
      const buf: string[] = [];
      idx += 1;
      while (idx < lines.length && !lines[idx].startsWith("```")) {
        buf.push(lines[idx]);
        idx += 1;
      }
      // Consume the closing fence if present.
      if (idx < lines.length) idx += 1;
      blocks.push({ kind: "code", language, text: buf.join("\n") });
      continue;
    }

    const heading = /^(#{1,6})\s+(.*)$/.exec(line);
    if (heading) {
      blocks.push({
        kind: "heading",
        level: heading[1].length,
        text: heading[2].trim(),
      });
      idx += 1;
      continue;
    }

    const bullet = /^\s*[-*]\s+(.+)$/.exec(line);
    if (bullet) {
      const items: string[] = [];
      while (idx < lines.length) {
        const m = /^\s*[-*]\s+(.+)$/.exec(lines[idx]);
        if (!m) break;
        items.push(m[1]);
        idx += 1;
      }
      blocks.push({ kind: "ul", items });
      continue;
    }

    const ordered = /^\s*\d+\.\s+(.+)$/.exec(line);
    if (ordered) {
      const items: string[] = [];
      while (idx < lines.length) {
        const m = /^\s*\d+\.\s+(.+)$/.exec(lines[idx]);
        if (!m) break;
        items.push(m[1]);
        idx += 1;
      }
      blocks.push({ kind: "ol", items });
      continue;
    }

    if (line.trim() === "") {
      idx += 1;
      continue;
    }

    // Paragraph: gather consecutive non-blank, non-special lines.
    const paraBuf: string[] = [line];
    idx += 1;
    while (idx < lines.length) {
      const next = lines[idx];
      if (
        next.trim() === "" ||
        next.startsWith("```") ||
        /^#{1,6}\s/.test(next) ||
        /^\s*[-*]\s+/.test(next) ||
        /^\s*\d+\.\s+/.test(next)
      ) {
        break;
      }
      paraBuf.push(next);
      idx += 1;
    }
    blocks.push({ kind: "paragraph", text: paraBuf.join("\n") });
  }
  return blocks;
}

function renderBlock(block: Block, key: number): ReactNode {
  if (block.kind === "heading") {
    const level = Math.min(Math.max(block.level ?? 1, 1), 6);
    const sizes: Record<number, string> = {
      1: "text-2xl",
      2: "text-xl",
      3: "text-lg",
      4: "text-base",
      5: "text-sm",
      6: "text-xs",
    };
    const cls = `font-semibold ${sizes[level]} mt-4 mb-2 first:mt-0`;
    const text = renderInline(block.text ?? "");
    switch (level) {
      case 1:
        return (
          <h1 key={key} className={cls}>
            {text}
          </h1>
        );
      case 2:
        return (
          <h2 key={key} className={cls}>
            {text}
          </h2>
        );
      case 3:
        return (
          <h3 key={key} className={cls}>
            {text}
          </h3>
        );
      case 4:
        return (
          <h4 key={key} className={cls}>
            {text}
          </h4>
        );
      case 5:
        return (
          <h5 key={key} className={cls}>
            {text}
          </h5>
        );
      default:
        return (
          <h6 key={key} className={cls}>
            {text}
          </h6>
        );
    }
  }
  if (block.kind === "code") {
    return (
      <pre
        key={key}
        className="my-2 overflow-auto rounded-md bg-muted p-2 font-mono text-xs"
        data-language={block.language ?? undefined}
      >
        {block.text}
      </pre>
    );
  }
  if (block.kind === "ul") {
    return (
      <ul key={key} className="my-2 ml-5 list-disc space-y-1 text-sm">
        {(block.items ?? []).map((item, i) => (
          <li key={i}>{renderInline(item)}</li>
        ))}
      </ul>
    );
  }
  if (block.kind === "ol") {
    return (
      <ol key={key} className="my-2 ml-5 list-decimal space-y-1 text-sm">
        {(block.items ?? []).map((item, i) => (
          <li key={i}>{renderInline(item)}</li>
        ))}
      </ol>
    );
  }
  return (
    <p key={key} className="my-2 text-sm leading-relaxed">
      {renderInline(block.text ?? "")}
    </p>
  );
}

export function MarkdownRenderer({
  content,
  className,
}: MarkdownRendererProps) {
  const blocks = tokenise(content);
  return (
    <div className={className}>
      {blocks.map((block, idx) => renderBlock(block, idx))}
    </div>
  );
}
