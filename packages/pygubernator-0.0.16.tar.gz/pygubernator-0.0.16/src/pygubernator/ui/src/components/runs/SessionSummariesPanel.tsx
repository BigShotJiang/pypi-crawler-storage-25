"use client";

/**
 * Narrator-pattern summaries surface (Phase 6 §6.10).
 *
 * Lists narrative summaries for a session — paragraphs about what
 * happened across many runs — and lets the user append a fresh
 * summary inline. Typically populated by a scheduled narrator agent
 * (v1.1 follow-up); v1 ships the storage so any workflow-driven
 * approach can write today.
 */

import { useCallback, useEffect, useState } from "react";
import { ChevronDown, ChevronRight, Send, Sparkles } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ApiError,
  createSessionSummary,
  listSessionSummaries,
} from "@/lib/api";
import type { SessionSummary } from "@/lib/api";
import { cn, formatDateTimeShort } from "@/lib/utils";

export interface SessionSummariesPanelProps {
  sessionId: string;
  className?: string;
}

export function SessionSummariesPanel({
  sessionId,
  className,
}: SessionSummariesPanelProps) {
  const [items, setItems] = useState<SessionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(true);
  const [draft, setDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await listSessionSummaries(sessionId);
      setItems(data.items);
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Could not load summaries",
      );
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const handleSubmit = useCallback(async () => {
    const text = draft.trim();
    if (!text) return;
    setSubmitting(true);
    setError(null);
    try {
      const created = await createSessionSummary(sessionId, {
        content: text,
        generated_by: "manual",
      });
      setItems((prev) => [created, ...prev]);
      setDraft("");
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Could not save summary",
      );
    } finally {
      setSubmitting(false);
    }
  }, [draft, sessionId]);

  return (
    <Card className={className}>
      <CardHeader>
        <button
          type="button"
          className="flex w-full items-center justify-between gap-2 text-left"
          onClick={() => setExpanded((v) => !v)}
          aria-expanded={expanded}
        >
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-500" />
            <CardTitle className="text-base">Session summaries</CardTitle>
            <span className="text-xs text-muted-foreground">
              ({items.length})
            </span>
          </div>
          {expanded ? (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          )}
        </button>
        <CardDescription>
          Narrative summaries written by a narrator agent or by you.
        </CardDescription>
      </CardHeader>
      {expanded ? (
        <CardContent className="space-y-3">
          {error ? (
            <p className="rounded-md border border-red-200 bg-red-50 px-2 py-1 text-xs text-red-700 dark:border-red-900 dark:bg-red-950/30 dark:text-red-300">
              {error}
            </p>
          ) : null}

          {loading && items.length === 0 ? (
            <p className="text-xs text-muted-foreground">Loading…</p>
          ) : items.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              No summaries yet for this session.
            </p>
          ) : (
            <ol className="flex flex-col gap-2">
              {items.map((entry) => (
                <li
                  key={entry.id}
                  className={cn(
                    "rounded-md border bg-muted/20 p-2 text-sm",
                  )}
                >
                  <p className="whitespace-pre-wrap">{entry.content}</p>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {formatDateTimeShort(entry.generated_at)}
                    {entry.generated_by ? ` · ${entry.generated_by}` : ""}
                    {entry.model ? ` · ${entry.model}` : ""}
                  </p>
                </li>
              ))}
            </ol>
          )}

          <div className="space-y-1 border-t pt-2">
            <label
              htmlFor={`summary-draft-${sessionId}`}
              className="text-xs font-medium text-muted-foreground"
            >
              Add a manual summary
            </label>
            <textarea
              id={`summary-draft-${sessionId}`}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={3}
              className="w-full rounded-md border bg-background px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              placeholder="What happened in this session?"
            />
            <div className="flex justify-end">
              <Button
                size="sm"
                onClick={() => void handleSubmit()}
                disabled={submitting || !draft.trim()}
              >
                <Send className="mr-1 h-3 w-3" />
                {submitting ? "Saving…" : "Save"}
              </Button>
            </div>
          </div>
        </CardContent>
      ) : null}
    </Card>
  );
}
