"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  Circle,
  Info,
  Loader2,
  Sparkles
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ApiError } from "@/lib/api";
import {
  kbApi,
  type InferredRelationship
} from "@/lib/api/kb";

type Direction = "outgoing" | "incoming" | "both";

interface KBConceptGraphPanelProps {
  /** Concept ids the parent chunk is bound to. */
  conceptRefs: readonly string[];
}

/**
 * "Concept graph" tab inside :component:`KBChunkDrawer`.
 *
 * Lets the reviewer pick one of the chunk's bound concepts and see the
 * stated + reasoner-inferred relationships that touch it. The reasoner
 * call is proxied by pygubernator to pycharter's
 * ``/api/v1/semantic/reasoning/{concept_id}`` route, so the panel
 * degrades gracefully (empty state) when pycharter is unreachable.
 *
 * Layout prefers document flow: the concept picker is a flex row of
 * chips, and the edge list below is a ``<ul>`` where each row is a
 * grid of (source) → (type) → (target). No absolute positioning.
 */
export default function KBConceptGraphPanel({
  conceptRefs
}: KBConceptGraphPanelProps) {
  const [selected, setSelected] = useState<string | null>(
    conceptRefs[0] ?? null
  );
  const [direction, setDirection] = useState<Direction>("both");
  const [onlyInferred, setOnlyInferred] = useState(false);
  const [rows, setRows] = useState<InferredRelationship[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  // Keep selection valid when the chunk changes.
  useEffect(() => {
    if (selected && conceptRefs.includes(selected)) return;
    setSelected(conceptRefs[0] ?? null);
  }, [conceptRefs, selected]);

  const load = useCallback(
    async (conceptId: string, dir: Direction, inferredOnly: boolean) => {
      setStatus("loading");
      setError(null);
      try {
        const res = await kbApi.inferredRelationships(conceptId, {
          direction: dir,
          only_inferred: inferredOnly
        });
        setRows(res.items);
        setStatus("idle");
      } catch (exc) {
        setRows([]);
        setStatus("error");
        setError(
          exc instanceof ApiError
            ? exc.message
            : exc instanceof Error
              ? exc.message
              : "Reasoner unavailable"
        );
      }
    },
    []
  );

  useEffect(() => {
    if (selected === null) {
      setRows([]);
      return;
    }
    void load(selected, direction, onlyInferred);
  }, [load, selected, direction, onlyInferred]);

  if (conceptRefs.length === 0) {
    return (
      <div className="flex flex-col items-start gap-2 rounded-md border bg-muted/20 p-3 text-xs text-muted-foreground">
        <Info className="h-3.5 w-3.5" aria-hidden="true" />
        <p>
          This chunk has no concept bindings yet. Once a concept is bound, the
          reasoner view lights up.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <section className="flex flex-col gap-1.5">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Concept
        </span>
        <div
          className="flex flex-wrap gap-1.5"
          role="radiogroup"
          aria-label="Select concept"
        >
          {conceptRefs.map((concept) => {
            const active = concept === selected;
            return (
              <button
                key={concept}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => setSelected(concept)}
                className={`rounded-full border px-2.5 py-0.5 text-xs transition-colors ${
                  active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-muted-foreground/30 hover:bg-accent"
                }`}
              >
                {concept}
              </button>
            );
          })}
        </div>
      </section>

      <section className="flex flex-col gap-2">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Filters
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <div
            role="radiogroup"
            aria-label="Edge direction"
            className="inline-flex rounded-md border text-xs"
          >
            {(["outgoing", "incoming", "both"] as Direction[]).map((dir) => (
              <button
                key={dir}
                type="button"
                role="radio"
                aria-checked={direction === dir}
                onClick={() => setDirection(dir)}
                className={`px-2.5 py-1 capitalize ${
                  direction === dir
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground hover:bg-accent/50"
                }`}
              >
                {dir}
              </button>
            ))}
          </div>
          <label className="inline-flex items-center gap-1.5 text-xs">
            <input
              type="checkbox"
              checked={onlyInferred}
              onChange={(event) => setOnlyInferred(event.target.checked)}
              className="h-3.5 w-3.5 accent-primary"
            />
            Only inferred
          </label>
        </div>
      </section>

      <section className="flex flex-col gap-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Relationships
          </span>
          {status === "loading" && (
            <Loader2
              className="h-3.5 w-3.5 animate-spin text-muted-foreground"
              aria-label="Loading"
            />
          )}
        </div>

        {status === "error" && (
          <p className="rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive">
            {error ?? "Reasoner unavailable"}
          </p>
        )}

        {status !== "loading" && rows.length === 0 && status !== "error" && (
          <p className="text-xs text-muted-foreground">
            No edges match the current filters.
          </p>
        )}

        <ul className="flex flex-col gap-1.5">
          {rows.map((row) => (
            <li
              key={`${row.source_id}|${row.relationship_type}|${row.target_id}`}
              className="flex items-center justify-between gap-3 rounded-md border bg-background px-3 py-2 text-xs"
            >
              <div className="flex min-w-0 flex-wrap items-center gap-1.5">
                <span className="truncate font-medium">{row.source_id}</span>
                <ArrowRight
                  className="h-3 w-3 shrink-0 text-muted-foreground"
                  aria-hidden="true"
                />
                <Badge variant="outline" className="font-normal">
                  {row.relationship_type}
                </Badge>
                <ArrowRight
                  className="h-3 w-3 shrink-0 text-muted-foreground"
                  aria-hidden="true"
                />
                <span className="truncate font-medium">{row.target_id}</span>
              </div>
              <span
                className="inline-flex shrink-0 items-center gap-1 text-[10px] text-muted-foreground"
                title={row.inferred ? "Inferred by OWL-RL reasoner" : "Stated"}
              >
                {row.inferred ? (
                  <Sparkles className="h-3 w-3" aria-hidden="true" />
                ) : (
                  <Circle className="h-2 w-2 fill-current" aria-hidden="true" />
                )}
                {row.inferred ? "inferred" : "stated"}
              </span>
            </li>
          ))}
        </ul>

        <div className="flex justify-end">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() =>
              selected && void load(selected, direction, onlyInferred)
            }
            disabled={selected === null || status === "loading"}
            className="text-xs"
          >
            Refresh
          </Button>
        </div>
      </section>
    </div>
  );
}
