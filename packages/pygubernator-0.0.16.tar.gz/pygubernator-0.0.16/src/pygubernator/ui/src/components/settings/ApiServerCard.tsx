"use client";

import { useAppConfigStore, selectAppName } from "@/stores/app-config";
import { useApiHealth } from "@/hooks/useApiHealth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";

interface ApiServerCardProps {
  url: string;
  onUrlChange: (url: string) => void;
}

export function ApiServerCard({ url, onUrlChange }: ApiServerCardProps) {
  const appName = useAppConfigStore(selectAppName);
  const { testing, result, test } = useApiHealth();

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Server</CardTitle>
        <CardDescription>
          {`URL of the ${appName} API this browser will call (saved in localStorage). Default matches `}
          <code className="text-xs bg-muted px-1 py-0.5 rounded">
            PYGUBERNATOR_API_URL
          </code>
          {` / dev proxy.`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label htmlFor="api-url" className="text-sm font-medium">
            API Server URL
          </label>
          <Input
            id="api-url"
            type="text"
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            placeholder="http://127.0.0.1:8010"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => test(url)}
            disabled={testing}
          >
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              "Test connection"
            )}
          </Button>
          {result && (
            <span className="inline-flex items-center gap-1 text-sm">
              {result.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {result.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
