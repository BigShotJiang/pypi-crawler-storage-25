import { describe, expect, it } from "vitest";
import {
  CircleAlert,
  CircleCheck,
  CircleDashed,
  Loader2,
} from "lucide-react";

import { statusVisuals } from "./GuideRunCard";

describe("statusVisuals", () => {
  /*
   * Pins the icon + colour vocabulary used for run status pips. A
   * regression here would silently change the UX signal users learn
   * to read at a glance — guard rails belong in tests, not in PR
   * review eyeballs.
   */

  it.each([
    ["completed", CircleCheck, false],
    ["success", CircleCheck, false],
    ["failed", CircleAlert, false],
    ["error", CircleAlert, false],
    ["running", Loader2, true],
  ])("maps %s -> icon", (status, expectedIcon, expectedSpin) => {
    const visuals = statusVisuals(status);
    expect(visuals.Icon).toBe(expectedIcon);
    expect(visuals.spin).toBe(expectedSpin);
  });

  it.each(["pending", "cancelled", "unknown", ""])(
    "falls back to muted dashed circle for %s",
    (status) => {
      const visuals = statusVisuals(status);
      expect(visuals.Icon).toBe(CircleDashed);
      expect(visuals.spin).toBe(false);
      expect(visuals.className).toContain("text-muted-foreground");
    },
  );

  it("only marks running as spinning", () => {
    expect(statusVisuals("running").spin).toBe(true);
    expect(statusVisuals("completed").spin).toBe(false);
    expect(statusVisuals("failed").spin).toBe(false);
    expect(statusVisuals("pending").spin).toBe(false);
  });
});
