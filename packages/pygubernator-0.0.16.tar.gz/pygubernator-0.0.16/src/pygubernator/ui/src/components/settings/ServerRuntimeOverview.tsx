"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  ApiError,
  getRuntimeOverview,
  getServerConfigBundle,
  patchServerConfig,
  type RuntimeOverviewResponse,
  type ServerConfigBundleResponse,
  type ServerConfigRow
} from "@/lib/api";
import { cn } from "@/lib/utils";
import { selectIsAdmin, selectLoading, useAuthStore } from "@/stores/auth";
import { Loader2 } from "lucide-react";

function getApiErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof ApiError) return error.message || fallback;
  if (error instanceof Error) return error.message || fallback;
  return fallback;
}

function buildRows(d: RuntimeOverviewResponse): { env: string; section: string; value: string }[] {
  const authLabel =
    d.auth_mode === "open_no_login"
      ? "Open (no login)"
      : d.auth_mode === "external_oidc"
        ? "External OAuth/OIDC"
        : "Built-in JWT users";
  const cp = d.control_plane;
  return [
    { env: "PYGUBERNATOR_UI_APP_NAME", section: "[ui]", value: d.app_name },
    { env: "PYGUBERNATOR_UI_THEME", section: "[ui]", value: d.ui_theme },
    { env: "—", section: "release", value: d.version || "—" },
    { env: "PYGUBERNATOR_API_URL", section: "[control_plane]", value: d.api_url },
    { env: "PYGUBERNATOR_API_HOST", section: "[control_plane]", value: cp.api_host },
    { env: "PYGUBERNATOR_API_PORT", section: "[control_plane]", value: String(cp.api_port) },
    { env: "PYGUBERNATOR_UI_HOST", section: "[control_plane]", value: cp.ui_host },
    { env: "PYGUBERNATOR_UI_PORT", section: "[control_plane]", value: String(cp.ui_port) },
    { env: "PYGUBERNATOR_ALLOW_ORIGINS", section: "[control_plane]", value: cp.allow_origins },
    {
      env: "PYGUBERNATOR_EVENT_RETENTION_DAYS",
      section: "[control_plane]",
      value: String(cp.event_retention_days)
    },
    { env: "PYGUBERNATOR_AUTH_*", section: "[auth]", value: authLabel },
    {
      env: "PYGUBERNATOR_DATABASE_URL",
      section: "[database]",
      value: d.database.configured_url_masked ?? "(default sqlite)"
    },
    { env: "—", section: "[database]", value: `Driver: ${d.database.driver_kind}` }
  ];
}

function sectionLabel(section: string): string {
  if (section.startsWith("[")) return section;
  if (section === "release") return "release";
  return `[${section}]`;
}

function parseBoolDraft(cfg: string | null, effective: string): boolean {
  if (cfg != null && cfg.trim() !== "") {
    const s = cfg.trim().toLowerCase();
    if (s === "0" || s === "false" || s === "no" || s === "off") return false;
    if (s === "1" || s === "true" || s === "yes" || s === "on") return true;
  }
  const e = effective.trim().toLowerCase();
  if (e.startsWith("off") || e.startsWith("false") || e.startsWith("no")) return false;
  return e.startsWith("on") || e.startsWith("true") || e.startsWith("yes") || e.startsWith("1");
}

function initialDraftValue(row: ServerConfigRow): string | boolean {
  if (row.kind === "bool") {
    return parseBoolDraft(row.cfg_value, row.effective_display);
  }
  if (row.cfg_value != null && row.cfg_value !== "") {
    return row.cfg_value;
  }
  if (row.kind === "number") {
    const m = row.effective_display.match(/^-?[\d.]+/);
    return m ? m[0] : "";
  }
  return row.effective_display;
}

function buildDraftMap(rows: ServerConfigRow[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (const row of rows) {
    if (!row.env_key || !row.editable) continue;
    out[row.env_key] = initialDraftValue(row);
  }
  return out;
}

function draftsEqual(a: string | boolean, b: string | boolean): boolean {
  return a === b;
}

interface ServerRuntimeOverviewProps {
  compact?: boolean;
  className?: string;
}

export function ServerRuntimeOverview({ compact, className }: ServerRuntimeOverviewProps) {
  const authLoading = useAuthStore(selectLoading);
  const isAdmin = useAuthStore(selectIsAdmin);

  const [bundle, setBundle] = useState<ServerConfigBundleResponse | null>(null);
  const [overview, setOverview] = useState<RuntimeOverviewResponse | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string | boolean>>({});
  const [initialDrafts, setInitialDrafts] = useState<Record<string, string | boolean>>({});
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const editableMode = Boolean(bundle && isAdmin);

  const dirty = useMemo(() => {
    if (!editableMode) return false;
    for (const k of Object.keys(drafts)) {
      if (!draftsEqual(drafts[k], initialDrafts[k])) return true;
    }
    return false;
  }, [drafts, initialDrafts, editableMode]);

  const reload = useCallback(
    async (preserveSaveMessage = false) => {
      setLoading(true);
      setError(null);
      if (!preserveSaveMessage) setSaveMessage(null);
      try {
        if (isAdmin) {
          try {
            const b = await getServerConfigBundle();
            setBundle(b);
            setOverview(null);
            const dm = buildDraftMap(b.rows);
            setDrafts(dm);
            setInitialDrafts({ ...dm });
            return;
          } catch (e) {
            if (e instanceof ApiError && (e.status === 401 || e.status === 403)) {
              const r = await getRuntimeOverview();
              setOverview(r);
              setBundle(null);
              setDrafts({});
              setInitialDrafts({});
              return;
            }
            throw e;
          }
        }
        const r = await getRuntimeOverview();
        setOverview(r);
        setBundle(null);
        setDrafts({});
        setInitialDrafts({});
      } catch (e) {
        setError(getApiErrorMessage(e, "Could not load server overview"));
        setBundle(null);
        setOverview(null);
      } finally {
        setLoading(false);
      }
    },
    [isAdmin]
  );

  useEffect(() => {
    if (authLoading) return;
    void reload();
  }, [authLoading, isAdmin, reload]);

  const updateDraft = (key: string, value: string | boolean) => {
    setDrafts((d) => ({ ...d, [key]: value }));
  };

  const handleSave = async () => {
    if (!bundle) return;
    const updates: Record<string, unknown> = {};
    for (const row of bundle.rows) {
      if (!row.env_key || !row.editable) continue;
      const k = row.env_key;
      if (!(k in drafts) || !(k in initialDrafts)) continue;
      if (draftsEqual(drafts[k], initialDrafts[k])) continue;
      const cur = drafts[k];
      if (row.kind === "number") {
        updates[k] = typeof cur === "string" ? Number(cur) : cur;
      } else if (row.kind === "bool") {
        updates[k] = cur === true;
      } else {
        updates[k] = cur;
      }
    }
    if (Object.keys(updates).length === 0) return;
    setSaving(true);
    setError(null);
    try {
      const res = await patchServerConfig(updates);
      await reload(true);
      setSaveMessage(res.detail);
    } catch (e) {
      setError(getApiErrorMessage(e, "Could not save server config"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card className={cn("scroll-mt-28", className)} id="overview">
      <CardHeader className={cn(compact && "space-y-1 p-4 pb-2")}>
        <CardTitle className={cn(compact && "text-base")}>
          {editableMode ? "Server runtime (edit cfg)" : "Server runtime"}
        </CardTitle>
        <CardDescription className={cn(compact && "text-xs leading-snug")}>
          {editableMode ? (
            <>
              Admin: values are written to{" "}
              <code className="rounded bg-muted px-0.5 text-[11px]">pygubernator.cfg</code>.
              Environment overrides the running process; restart{" "}
              <code className="rounded bg-muted px-0.5 text-[11px]">pygubernator api</code> when
              needed.
            </>
          ) : (
            <>
              Effective values from the API. Passwords masked. Log in as Admin to edit{" "}
              <code className="rounded bg-muted px-0.5 text-[11px]">pygubernator.cfg</code>.
            </>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className={cn("pt-0", compact && "p-4 pt-0")}>
        {loading && (
          <div className="flex items-center gap-2 py-4 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 shrink-0 animate-spin" />
            Loading server overview…
          </div>
        )}
        {error && (
          <p className="py-2 text-sm text-destructive" role="alert">
            {error}
          </p>
        )}
        {saveMessage && (
          <p className="py-2 text-sm text-green-800 dark:text-green-200" role="status">
            {saveMessage}
          </p>
        )}
        {editableMode && bundle && !loading && (
          <div className="flex flex-wrap items-center gap-2 pb-3">
            <Button type="button" size="sm" onClick={() => void reload()} variant="outline">
              Reload
            </Button>
            <Button type="button" size="sm" onClick={() => void handleSave()} disabled={saving || !dirty}>
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving…
                </>
              ) : (
                "Save to pygubernator.cfg"
              )}
            </Button>
            <span className="break-all text-[11px] text-muted-foreground">
              File: {bundle.config_write_target}
            </span>
          </div>
        )}
        {bundle && !loading && editableMode && (
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-2 py-1.5 font-medium">Variable</th>
                  <th className="w-16 px-2 py-1.5 font-medium">Section</th>
                  <th className="px-2 py-1.5 font-medium">Effective</th>
                  <th className="min-w-[140px] px-2 py-1.5 font-medium">File / edit</th>
                </tr>
              </thead>
              <tbody>
                {bundle.rows.map((row) => (
                  <ConfigRowView key={row.id} row={row} drafts={drafts} onDraftChange={updateDraft} />
                ))}
              </tbody>
            </table>
          </div>
        )}
        {overview && !loading && !editableMode && (
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="whitespace-nowrap px-2 py-1.5 font-medium">Variable</th>
                  <th className="w-16 px-2 py-1.5 font-medium">Section</th>
                  <th className="px-2 py-1.5 font-medium">Effective value</th>
                </tr>
              </thead>
              <tbody>
                {buildRows(overview).map((row, idx) => (
                  <tr key={idx} className="border-b border-border/60 last:border-0">
                    <td className="whitespace-nowrap px-2 py-1 align-top font-mono text-[11px] text-muted-foreground">
                      {row.env}
                    </td>
                    <td className="px-2 py-1 align-top text-muted-foreground">{row.section}</td>
                    <td className="break-all px-2 py-1 align-top">{row.value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ConfigRowView({
  row,
  drafts,
  onDraftChange
}: {
  row: ServerConfigRow;
  drafts: Record<string, string | boolean>;
  onDraftChange: (key: string, value: string | boolean) => void;
}) {
  const k = row.env_key ?? "";
  const locked = row.env_locked;
  const canEdit = row.editable && !locked && k;

  const control = (() => {
    if (!canEdit) {
      if (row.kind === "readonly" || !k) {
        return <span className="text-muted-foreground">—</span>;
      }
      return (
        <span className="text-muted-foreground">
          {locked ? "Set in environment" : "Not editable"}
        </span>
      );
    }
    const val = drafts[k];
    if (row.kind === "bool") {
      return (
        <Switch
          checked={val === true}
          onCheckedChange={(c: boolean) => onDraftChange(k, c)}
          aria-label={k}
        />
      );
    }
    const strVal = typeof val === "string" ? val : String(val);
    if (row.kind === "password") {
      return (
        <input
          type="password"
          className="w-full min-w-[8rem] rounded border border-input bg-background px-1.5 py-1 font-mono text-[11px]"
          value={strVal}
          onChange={(e) => onDraftChange(k, e.target.value)}
          autoComplete="off"
          aria-label={k}
        />
      );
    }
    if (row.kind === "number") {
      return (
        <input
          type="text"
          inputMode="decimal"
          className="w-full max-w-[10rem] rounded border border-input bg-background px-1.5 py-1 font-mono text-[11px]"
          value={strVal}
          onChange={(e) => onDraftChange(k, e.target.value)}
          aria-label={k}
        />
      );
    }
    return (
      <input
        type="text"
        className="w-full min-w-[8rem] rounded border border-input bg-background px-1.5 py-1 font-mono text-[11px]"
        value={strVal}
        onChange={(e) => onDraftChange(k, e.target.value)}
        aria-label={k}
      />
    );
  })();

  return (
    <tr className="border-b border-border/60 last:border-0">
      <td className="whitespace-nowrap px-2 py-1 align-top font-mono text-[11px] text-muted-foreground">
        {k || "—"}
      </td>
      <td className="px-2 py-1 align-top text-muted-foreground">{sectionLabel(row.section)}</td>
      <td className="break-all px-2 py-1 align-top">{row.effective_display}</td>
      <td className="px-2 py-1 align-top">
        {row.source_hint ? (
          <div className="mb-1 text-[10px] leading-tight text-muted-foreground">{row.source_hint}</div>
        ) : null}
        {control}
      </td>
    </tr>
  );
}
