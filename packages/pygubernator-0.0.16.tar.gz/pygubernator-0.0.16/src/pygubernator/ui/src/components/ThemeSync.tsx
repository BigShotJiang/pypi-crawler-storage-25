"use client";

import { useEffect, useLayoutEffect, useMemo, useState } from "react";

import { NAMED_THEME_IDS } from "@/lib/constants";
import type { NamedThemeId } from "@/lib/constants";
import { useAppConfigStore, selectTheme } from "@/stores/app-config";

function resolveTheme(raw: string): string {
  if (raw !== "system" || typeof window === "undefined") return raw;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function useResolvedThemeAttrs(): {
  className: string;
  "data-theme": string | undefined;
} {
  const theme = useAppConfigStore(selectTheme);
  const [systemResolved, setSystemResolved] = useState<"light" | "dark">(() =>
    typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light"
  );

  useEffect(() => {
    if (theme !== "system") return;
    const m = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => setSystemResolved(m.matches ? "dark" : "light");
    m.addEventListener("change", handler);
    return () => m.removeEventListener("change", handler);
  }, [theme]);

  return useMemo(() => {
    const resolved = resolveTheme(theme);
    const actual = theme === "system" ? systemResolved : resolved;
    const isDark = actual === "dark";
    const dataTheme = NAMED_THEME_IDS.includes(actual as NamedThemeId) ? actual : undefined;
    return { className: isDark ? "dark" : "", "data-theme": dataTheme };
  }, [theme, systemResolved]);
}

export default function ThemeSync() {
  const attrs = useResolvedThemeAttrs();
  const className = attrs.className;
  const dataTheme = attrs["data-theme"];

  useLayoutEffect(() => {
    const el = document.documentElement;
    el.classList.toggle("dark", className === "dark");
    if (dataTheme) {
      el.setAttribute("data-theme", dataTheme);
    } else {
      el.removeAttribute("data-theme");
    }
  }, [className, dataTheme]);
  return null;
}
