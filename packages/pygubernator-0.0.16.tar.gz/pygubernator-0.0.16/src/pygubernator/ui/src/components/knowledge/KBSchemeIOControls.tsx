"use client";

import { useRef, useState } from "react";
import { Download, FileUp, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toaster";
import { ApiError } from "@/lib/api";
import { kbApi, type RdfFormat } from "@/lib/api/kb";

/**
 * Export / import concept-scheme RDF from the ``/knowledge`` page.
 *
 * - **Export**: user enters a scheme key, picks a format, clicks
 *   "Download". The TTL / JSON-LD body is retrieved via the proxy
 *   and streamed to the browser as a file download — no server-side
 *   file artefacts.
 * - **Import**: user picks a local ``.ttl`` / ``.jsonld`` file; the
 *   text is uploaded to the proxy which forwards to pycharter.
 *
 * Layout uses document flow + flex only. The two actions share a
 * single labelled row on wide viewports and stack on narrow ones.
 */
export default function KBSchemeIOControls() {
  const { toast } = useToast();
  const [schemeKey, setSchemeKey] = useState("");
  const [format, setFormat] = useState<RdfFormat>("turtle");
  const [busy, setBusy] = useState<"export" | "import" | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  async function handleExport() {
    const key = schemeKey.trim();
    if (!key) {
      toast("Enter a scheme key first.", "error");
      return;
    }
    setBusy("export");
    try {
      const res = await kbApi.exportScheme(key, format);
      downloadText(
        res.text,
        `${res.scheme_key}.${format === "turtle" ? "ttl" : "jsonld"}`,
        format === "turtle" ? "text/turtle" : "application/ld+json"
      );
      toast(`Exported ${res.scheme_key}`, "success");
    } catch (exc) {
      const message =
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Export failed";
      toast(`Export failed: ${message}`, "error");
    } finally {
      setBusy(null);
    }
  }

  async function handleImport(file: File) {
    setBusy("import");
    try {
      const text = await file.text();
      const inferredFormat: RdfFormat = file.name.endsWith(".jsonld")
        ? "jsonld"
        : "turtle";
      const res = await kbApi.importScheme({
        text,
        format: inferredFormat,
        scheme_key: schemeKey.trim() || undefined
      });
      toast(
        `Imported ${res.concepts_upserted} concept(s) into ${res.scheme_key}`,
        "success"
      );
    } catch (exc) {
      const message =
        exc instanceof ApiError
          ? exc.message
          : exc instanceof Error
            ? exc.message
            : "Import failed";
      toast(`Import failed: ${message}`, "error");
    } finally {
      setBusy(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-md border bg-muted/10 px-3 py-2">
      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        Scheme key
        <Input
          type="text"
          value={schemeKey}
          onChange={(event) => setSchemeKey(event.target.value)}
          placeholder="e.g. biology"
          className="h-8 w-40 text-xs"
          aria-label="Scheme key"
        />
      </label>

      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        Format
        <select
          value={format}
          onChange={(event) => setFormat(event.target.value as RdfFormat)}
          className="h-8 rounded-md border bg-background px-2 text-xs"
          aria-label="RDF format"
        >
          <option value="turtle">Turtle</option>
          <option value="jsonld">JSON-LD</option>
        </select>
      </label>

      <Button
        type="button"
        size="sm"
        variant="outline"
        onClick={() => void handleExport()}
        disabled={busy !== null || schemeKey.trim() === ""}
        className="gap-1.5"
      >
        {busy === "export" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
        ) : (
          <Download className="h-3.5 w-3.5" aria-hidden="true" />
        )}
        Export
      </Button>

      <Button
        type="button"
        size="sm"
        variant="outline"
        onClick={() => fileInputRef.current?.click()}
        disabled={busy !== null}
        className="gap-1.5"
      >
        {busy === "import" ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
        ) : (
          <FileUp className="h-3.5 w-3.5" aria-hidden="true" />
        )}
        Import…
      </Button>
      <input
        ref={fileInputRef}
        type="file"
        accept=".ttl,.turtle,.jsonld,.json"
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void handleImport(file);
        }}
      />
    </div>
  );
}

function downloadText(text: string, filename: string, mime: string): void {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
