"use client";

/**
 * Pretty-printed JSON artifact renderer.
 *
 * Accepts either canonical JSON or any string that happens to round-trip
 * through ``JSON.parse``; falls back to rendering the raw text when the
 * payload isn't valid JSON so malformed artifacts still show the user
 * something useful.
 */

export interface JsonRendererProps {
  content: string;
  className?: string;
}

/** Pretty-print a JSON string, or return the original on parse error. */
export function prettyPrintJson(content: string): string {
  try {
    const parsed = JSON.parse(content);
    return JSON.stringify(parsed, null, 2);
  } catch {
    return content;
  }
}

export function JsonRenderer({ content, className }: JsonRendererProps) {
  const pretty = prettyPrintJson(content);
  return (
    <pre
      className={`overflow-auto rounded-md bg-muted p-2 font-mono text-xs leading-snug ${
        className ?? ""
      }`}
    >
      {pretty}
    </pre>
  );
}
