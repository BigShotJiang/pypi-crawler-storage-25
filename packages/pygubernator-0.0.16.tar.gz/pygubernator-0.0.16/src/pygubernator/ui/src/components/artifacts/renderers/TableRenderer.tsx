"use client";

/**
 * CSV/TSV artifact renderer.
 *
 * Parses RFC-4180 style CSV — including double-quoted fields with
 * embedded commas, newlines, and escaped double quotes — and renders the
 * result in the shared ``<Table />`` primitive. The first row is always
 * treated as the header.
 */

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface TableRendererProps {
  content: string;
  /** Field delimiter. Defaults to ``,`` (comma). */
  delimiter?: string;
  className?: string;
}

/** Split a CSV payload into a 2D array of strings, RFC-4180 aware. */
export function parseCsv(content: string, delimiter: string = ","): string[][] {
  const rows: string[][] = [];
  let current: string[] = [];
  let field = "";
  let inQuotes = false;

  for (let i = 0; i < content.length; i += 1) {
    const ch = content[i];
    if (inQuotes) {
      if (ch === '"') {
        if (content[i + 1] === '"') {
          // Escaped quote inside a quoted field.
          field += '"';
          i += 1;
        } else {
          inQuotes = false;
        }
      } else {
        field += ch;
      }
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      continue;
    }
    if (ch === delimiter) {
      current.push(field);
      field = "";
      continue;
    }
    if (ch === "\n" || ch === "\r") {
      // Handle CRLF by skipping the LF after a CR.
      if (ch === "\r" && content[i + 1] === "\n") {
        i += 1;
      }
      current.push(field);
      field = "";
      rows.push(current);
      current = [];
      continue;
    }
    field += ch;
  }
  if (field.length > 0 || current.length > 0) {
    current.push(field);
    rows.push(current);
  }
  // Trailing blank row from a terminating newline — drop it.
  if (rows.length > 0) {
    const last = rows[rows.length - 1];
    if (last.length === 1 && last[0] === "") {
      rows.pop();
    }
  }
  return rows;
}

export function TableRenderer({
  content,
  delimiter = ",",
  className,
}: TableRendererProps) {
  const rows = parseCsv(content, delimiter);
  if (rows.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">Empty table artifact.</p>
    );
  }
  const [header, ...body] = rows;
  return (
    <div className={className}>
      <div className="overflow-auto rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {header.map((cell, i) => (
                <TableHead key={i}>{cell}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {body.map((row, rIdx) => (
              <TableRow key={rIdx}>
                {row.map((cell, cIdx) => (
                  <TableCell key={cIdx} className="font-mono text-xs">
                    {cell}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {body.length.toLocaleString()} row{body.length === 1 ? "" : "s"} ·{" "}
        {header.length} column{header.length === 1 ? "" : "s"}
      </p>
    </div>
  );
}
