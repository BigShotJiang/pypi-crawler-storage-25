"use client";

import { useCallback, useEffect, useMemo, useReducer, useState } from "react";
import Link from "next/link";
import { MessageSquare, RefreshCw, Trash2 } from "lucide-react";

import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import ErrorDisplay from "@/components/ErrorDisplay";
import { PageLoading } from "@/components/LoadingSpinner";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/components/ui/toaster";
import { AgentHeartbeatIndicator } from "@/components/agents/AgentHeartbeatIndicator";
import { AgentSpecCatalogDialog } from "@/components/agents/AgentSpecCatalogDialog";
import { AgentVersionDetailCard } from "@/components/agents/AgentVersionDetailCard";
import { InlineVersionForm } from "@/components/agents/forms/InlineVersionForm";
import {
  INITIAL_INLINE_VERSION_FORM,
  inlineVersionFormReducer,
  type ProviderPreset,
} from "@/components/agents/forms/inline-version-form-state";
import { SpecVersionForm } from "@/components/agents/forms/SpecVersionForm";
import { VersionLifecycleActions } from "@/components/agents/forms/VersionLifecycleActions";
import {
  defaultVersionLabel,
  parseSpecText,
  validateSpec,
  type SpecValidation,
} from "@/lib/agent-spec";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/lib/api";
import { ROUTES } from "@/lib/constants";
import { cn, formatDateTimeShort } from "@/lib/utils";

interface AgentItem {
  id: string;
  name: string;
  owner: string;
  status: string;
  archived: boolean;
}

interface AgentDetail extends AgentItem {
  current_version_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface AgentRegistryVersionRow {
  id: string;
  agent_id: string;
  version: string;
  model: string | null;
  prompt: string | null;
  tools?: Record<string, unknown> | null;
  config?: Record<string, unknown> | null;
  spec_path?: string | null;
  spec_fingerprint?: string | null;
  spec_json?: Record<string, unknown> | null;
  active: boolean;
  created_at: string;
  deleted_at?: string | null;
}

interface AuditRow {
  id: string;
  actor: string;
  action: string;
  resource_type: string;
  resource_id: string | null;
  created_at: string;
}

export interface AgentRegistryDetailViewProps {
  agentId: string;
  onBack: () => void;
  /** Opens the visual agent builder with the active version loaded. */
  onOpenInBuilder?: () => void;
}

export default function AgentRegistryDetailView({
  agentId,
  onBack,
  onOpenInBuilder,
}: AgentRegistryDetailViewProps) {
  const { toast } = useToast();
  const [detail, setDetail] = useState<{
    agent: AgentDetail;
    versions: AgentRegistryVersionRow[];
    policies: { items: Array<{ id: string; policy_type: string; enabled: boolean }> };
    audit: { items: AuditRow[] };
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const [editStatus, setEditStatus] = useState("");
  const [editArchived, setEditArchived] = useState(false);
  const [editName, setEditName] = useState("");
  const [editOwner, setEditOwner] = useState("");
  const [editingIdentity, setEditingIdentity] = useState(false);
  const [expandedVersionId, setExpandedVersionId] = useState<string | null>(null);

  // Inline-version form state (R.3): one reducer instead of six
  // sibling ``useState`` calls so a provider-preset selection updates
  // ``api_base`` / ``model`` / ``api_key`` atomically.
  const [inlineForm, dispatchInlineForm] = useReducer(
    inlineVersionFormReducer,
    INITIAL_INLINE_VERSION_FORM,
  );
  const [versionMode, setVersionMode] = useState<"inline" | "spec">("inline");
  const [newSpecText, setNewSpecText] = useState("");
  const [newSpecVersion, setNewSpecVersion] = useState("");
  const [specValidation, setSpecValidation] = useState<SpecValidation | null>(
    null,
  );
  const [specValidating, setSpecValidating] = useState(false);
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [providerPresets, setProviderPresets] = useState<ProviderPreset[]>([]);

  const [runVersionId, setRunVersionId] = useState<string>("");
  const [runTrigger, setRunTrigger] = useState("ui");
  const [runCorrelation, setRunCorrelation] = useState("");

  const [confirmArchive, setConfirmArchive] = useState(false);
  const [confirmDeleteVersionId, setConfirmDeleteVersionId] = useState<string | null>(
    null,
  );

  useEffect(() => {
    apiGet<{ items: typeof providerPresets }>("/api/v1/llm/providers")
      .then((data) => setProviderPresets(data.items))
      .catch(() => {});
  }, []);

  const loadDetail = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      const [dash, policies, audit] = await Promise.all([
        apiGet<{ agent: AgentDetail; versions: AgentRegistryVersionRow[] }>(
          `/api/v1/agents/${id}/dashboard`,
        ),
        apiGet<{ items: Array<{ id: string; policy_type: string; enabled: boolean }> }>(
          `/api/v1/policies`,
          { agent_id: id },
        ),
        apiGet<{ items: AuditRow[] }>(`/api/v1/policies/audit`, {
          limit: 50,
          resource_id: id,
          resource_type: "agent",
        }),
      ]);
      setDetail({
        agent: dash.agent,
        versions: dash.versions,
        policies,
        audit,
      });
      setEditStatus(dash.agent.status);
      setEditArchived(dash.agent.archived);
      setEditName(dash.agent.name);
      setEditOwner(dash.agent.owner);
      setEditingIdentity(false);
      const active = dash.versions.find((v) => v.active);
      setRunVersionId(active?.id ?? dash.versions[0]?.id ?? "");
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDetail(agentId);
  }, [agentId, loadDetail]);

  const refresh = () => void loadDetail(agentId);

  const saveAgentMeta = async () => {
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPatch<
        { status: string; archived: boolean },
        AgentDetail
      >(`/api/v1/agents/${agentId}`, {
        status: editStatus,
        archived: editArchived,
      });
      setDetail((d) => (d ? { ...d, agent: updated } : null));
      toast("Agent updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const saveAgentIdentity = async () => {
    const nextName = editName.trim();
    const nextOwner = editOwner.trim();
    if (!nextName || !nextOwner) {
      toast("Name and owner cannot be empty.", "error");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPatch<{ name: string; owner: string }, AgentDetail>(
        `/api/v1/agents/${agentId}`,
        { name: nextName, owner: nextOwner },
      );
      setDetail((d) => (d ? { ...d, agent: updated } : null));
      setEditName(updated.name);
      setEditOwner(updated.owner);
      setEditingIdentity(false);
      toast("Agent renamed.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const archiveAgent = async () => {
    setConfirmArchive(false);
    setBusy(true);
    setError(null);
    try {
      await apiDelete<AgentDetail>(`/api/v1/agents/${agentId}`);
      toast("Agent archived.", "success");
      onBack();
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const activateVersion = async (versionId: string) => {
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPost<Record<string, never>, AgentDetail>(
        `/api/v1/agents/${agentId}/versions/${versionId}/activate`,
      );
      setDetail((d) =>
        d
          ? {
              ...d,
              agent: updated,
              versions: d.versions.map((v) => ({ ...v, active: v.id === versionId })),
            }
          : null,
      );
      setRunVersionId(versionId);
      toast("Active version updated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const deactivateVersion = async (versionId: string) => {
    setBusy(true);
    setError(null);
    try {
      const updated = await apiPost<Record<string, never>, AgentRegistryVersionRow>(
        `/api/v1/agents/${agentId}/versions/${versionId}/deactivate`,
      );
      setDetail((d) =>
        d
          ? {
              ...d,
              // The route clears agent.current_version_id when the deactivated
              // row was the current one — mirror that locally.
              agent:
                d.agent.current_version_id === versionId
                  ? { ...d.agent, current_version_id: null }
                  : d.agent,
              versions: d.versions.map((v) => (v.id === versionId ? updated : v)),
            }
          : null,
      );
      if (runVersionId === versionId) setRunVersionId("");
      toast("Version deactivated.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const deleteVersion = async (versionId: string) => {
    setBusy(true);
    setError(null);
    try {
      await apiDelete<AgentRegistryVersionRow>(
        `/api/v1/agents/${agentId}/versions/${versionId}`,
      );
      // Default list view hides deleted rows, so we drop it locally to match.
      setDetail((d) =>
        d
          ? { ...d, versions: d.versions.filter((v) => v.id !== versionId) }
          : null,
      );
      if (runVersionId === versionId) setRunVersionId("");
      if (expandedVersionId === versionId) setExpandedVersionId(null);
      setConfirmDeleteVersionId(null);
      toast("Version deleted.", "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const submitNewVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineForm.version.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const selectedPreset = providerPresets.find(
        (p) => p.name === inlineForm.provider_name,
      );
      const providerPayload = selectedPreset
        ? {
            provider_type: selectedPreset.provider_type,
            model: inlineForm.model.trim(),
            api_base:
              inlineForm.api_base.trim() ||
              selectedPreset.default_api_base ||
              undefined,
            api_key: inlineForm.api_key.trim() || undefined,
          }
        : undefined;
      const v = await apiPost<
        { version: string; model?: string; prompt?: string; provider?: unknown },
        AgentRegistryVersionRow
      >(`/api/v1/agents/${agentId}/versions`, {
        version: inlineForm.version.trim(),
        model: inlineForm.model.trim() || undefined,
        prompt: inlineForm.prompt.trim() || undefined,
        provider: providerPayload,
      });
      setDetail((d) => (d ? { ...d, versions: [v, ...d.versions] } : null));
      dispatchInlineForm({ type: "reset" });
      toast(`Version ${v.version} created.`, "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const parsedSpec = useMemo(() => {
    if (!newSpecText.trim()) return null;
    return parseSpecText(newSpecText);
  }, [newSpecText]);

  const specReadyForSubmit =
    parsedSpec?.ok === true &&
    specValidation?.valid === true &&
    newSpecVersion.trim().length > 0;

  const runSpecValidation = async () => {
    if (!parsedSpec?.ok) return;
    setSpecValidating(true);
    try {
      const result = await validateSpec(parsedSpec.value);
      setSpecValidation(result);
      if (result.valid && !newSpecVersion.trim()) {
        setNewSpecVersion(defaultVersionLabel(parsedSpec.value));
      }
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      toast(err.message, "error");
      setSpecValidation({
        valid: false,
        errors: [err.message],
      });
    } finally {
      setSpecValidating(false);
    }
  };

  const submitSpecVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!specReadyForSubmit || !parsedSpec?.ok) return;
    setBusy(true);
    setError(null);
    try {
      const v = await apiPost<
        { version: string; spec_json: Record<string, unknown> },
        AgentRegistryVersionRow
      >(`/api/v1/agents/${agentId}/versions`, {
        version: newSpecVersion.trim(),
        spec_json: parsedSpec.value,
      });
      setDetail((d) => (d ? { ...d, versions: [v, ...d.versions] } : null));
      setNewSpecText("");
      setNewSpecVersion("");
      setSpecValidation(null);
      toast(`Version ${v.version} published from spec.`, "success");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  const enqueueRun = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const run = await apiPost<
        { agent_version_id?: string; trigger?: string; correlation_id?: string },
        { id: string; status: string }
      >(`/api/v1/agents/${agentId}/runs`, {
        agent_version_id: runVersionId || undefined,
        trigger: runTrigger.trim() || "ui",
        correlation_id: runCorrelation.trim() || undefined,
      });
      toast(`Run ${run.id.slice(0, 8)}... queued (${run.status}).`, "success");
      setRunCorrelation("");
    } catch (e) {
      const err = e instanceof Error ? e : new Error(String(e));
      setError(err);
      toast(err.message, "error");
    } finally {
      setBusy(false);
    }
  };

  if (loading && !detail) {
    return (
      <div className="flex h-full min-h-0 items-center justify-center">
        <PageLoading message="Loading agent…" />
      </div>
    );
  }

  if (!detail) {
    return (
      <div className="flex h-full min-h-0 flex-col gap-3 p-4">
        {error ? <ErrorDisplay error={error} /> : <p className="text-sm text-muted-foreground">Agent not found.</p>}
        <Button variant="outline" size="sm" onClick={onBack}>
          Back
        </Button>
      </div>
    );
  }

  const { agent, versions, policies, audit } = detail;

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden">
      <div className="shrink-0 border-b border-border/60 bg-background/95 px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="truncate text-lg font-semibold">{agent.name}</h1>
              <AgentHeartbeatIndicator agentId={agent.id} />
            </div>
            <p className="text-xs text-muted-foreground">
              Owner {agent.owner} · {agent.status}
              {agent.archived ? " · archived" : ""}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={refresh} disabled={loading || busy}>
              <RefreshCw className={cn("mr-1 h-4 w-4", loading && "animate-spin")} /> Refresh
            </Button>
            {(() => {
              const activeVersion = versions.find((v) => v.active);
              const params = new URLSearchParams();
              if (activeVersion?.model) params.set("model", activeVersion.model);
              params.set("title", `Chat with ${agent.name}`);
              if (activeVersion?.prompt) {
                params.set("system_prompt", activeVersion.prompt);
              }
              const href = `${ROUTES.CHAT}?${params.toString()}`;
              return (
                <Link
                  href={href}
                  className={cn(buttonVariants({ variant: "default", size: "sm" }))}
                  aria-label={`Chat with ${agent.name}`}
                >
                  <MessageSquare className="mr-1 h-4 w-4" /> Chat now
                </Link>
              );
            })()}
            <Link
              href={`${ROUTES.OBS_RUNS}?agent_id=${encodeURIComponent(agent.id)}`}
              className={cn(buttonVariants({ variant: "secondary", size: "sm" }))}
            >
              View runs
            </Link>
            {onOpenInBuilder ? (
              <Button type="button" variant="secondary" size="sm" onClick={onOpenInBuilder}>
                Open in builder
              </Button>
            ) : null}
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setConfirmArchive(true)}
              disabled={busy || agent.archived}
            >
              <Trash2 className="mr-1 h-4 w-4" /> Archive
            </Button>
            <Button type="button" variant="secondary" size="sm" onClick={onBack}>
              Back to list
            </Button>
          </div>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {error ? <ErrorDisplay error={error} className="mb-4" /> : null}

        <ConfirmDialog
          open={confirmArchive}
          title="Archive agent"
          description={`Are you sure you want to archive "${agent.name}"? The agent will be soft-deleted.`}
          confirmLabel="Archive"
          variant="destructive"
          onConfirm={() => void archiveAgent()}
          onCancel={() => setConfirmArchive(false)}
        />

        <ConfirmDialog
          open={confirmDeleteVersionId !== null}
          title="Delete version"
          description={
            confirmDeleteVersionId
              ? `Version "${
                  detail?.versions.find((v) => v.id === confirmDeleteVersionId)
                    ?.version ?? confirmDeleteVersionId
                }" will be soft-deleted and hidden from the list. In-flight workflow runs pinned to this version keep resolving by id.`
              : ""
          }
          confirmLabel="Delete"
          variant="destructive"
          onConfirm={() => {
            if (confirmDeleteVersionId) {
              void deleteVersion(confirmDeleteVersionId);
            }
          }}
          onCancel={() => setConfirmDeleteVersionId(null)}
        />

        {catalogOpen && (
          <AgentSpecCatalogDialog
            onSelect={(yamlText) => {
              setNewSpecText(yamlText);
              setSpecValidation(null);
              setCatalogOpen(false);
            }}
            onClose={() => setCatalogOpen(false)}
          />
        )}

        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Identity</CardTitle>
              <CardDescription>
                Rename this agent or reassign ownership. Referenced by{" "}
                <code className="font-mono text-[11px]">agent_id</code> in workflows.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Name</label>
                <Input
                  value={editName}
                  onChange={(e) => {
                    setEditName(e.target.value);
                    setEditingIdentity(true);
                  }}
                  placeholder="agent-name"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Owner</label>
                <Input
                  value={editOwner}
                  onChange={(e) => {
                    setEditOwner(e.target.value);
                    setEditingIdentity(true);
                  }}
                  placeholder="team-name"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => void saveAgentIdentity()}
                  disabled={
                    busy || !editingIdentity || !editName.trim() || !editOwner.trim()
                  }
                >
                  Save identity
                </Button>
                {editingIdentity ? (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setEditName(agent.name);
                      setEditOwner(agent.owner);
                      setEditingIdentity(false);
                    }}
                    disabled={busy}
                  >
                    Discard
                  </Button>
                ) : null}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Agent settings</CardTitle>
              <CardDescription>Status and archive flag</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex flex-col gap-1">
                <label className="text-muted-foreground">Status</label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                >
                  <option value="active">active</option>
                  <option value="paused">paused</option>
                  <option value="deprecated">deprecated</option>
                </select>
              </div>
              <label className="flex cursor-pointer items-center gap-2">
                <input
                  type="checkbox"
                  checked={editArchived}
                  onChange={(e) => setEditArchived(e.target.checked)}
                  className="h-4 w-4 rounded border-input"
                />
                Archived
              </label>
              <Button size="sm" onClick={() => void saveAgentMeta()} disabled={busy}>
                Save changes
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Enqueue run</CardTitle>
              <CardDescription>Creates a queued run for this agent</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-3 text-sm" onSubmit={(e) => void enqueueRun(e)}>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Version</label>
                  <select
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    value={runVersionId}
                    onChange={(e) => setRunVersionId(e.target.value)}
                  >
                    {versions.length === 0 ? (
                      <option value="">No versions — create one first</option>
                    ) : (
                      versions.map((v) => (
                        <option key={v.id} value={v.id}>
                          {v.version}
                          {v.active ? " (active)" : ""}
                        </option>
                      ))
                    )}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Trigger</label>
                  <Input
                    value={runTrigger}
                    onChange={(e) => setRunTrigger(e.target.value)}
                    placeholder="ui"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-muted-foreground">Correlation ID (optional)</label>
                  <Input
                    value={runCorrelation}
                    onChange={(e) => setRunCorrelation(e.target.value)}
                    placeholder="trace key"
                  />
                </div>
                <Button type="submit" size="sm" disabled={busy || versions.length === 0}>
                  Enqueue run
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Versions</CardTitle>
            <CardDescription>Register, inspect, and set the active version</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Version</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {versions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-muted-foreground">
                      No versions yet. Add one below.
                    </TableCell>
                  </TableRow>
                ) : (
                  versions.flatMap((v) => {
                    const expanded = expandedVersionId === v.id;
                    const rows = [
                      <TableRow key={v.id}>
                        <TableCell className="font-medium">
                          <button
                            type="button"
                            className="flex items-center gap-1.5 hover:text-primary"
                            onClick={() => setExpandedVersionId(expanded ? null : v.id)}
                            aria-expanded={expanded}
                          >
                            <span className="inline-block w-3 text-muted-foreground">
                              {expanded ? "▾" : "▸"}
                            </span>
                            {v.version}
                            {v.active ? (
                              <span className="ml-2 text-xs font-normal text-primary">active</span>
                            ) : null}
                          </button>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">{v.model ?? "—"}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDateTimeShort(v.created_at)}
                        </TableCell>
                        <TableCell className="text-right">
                          <VersionLifecycleActions
                            versionId={v.id}
                            versionLabel={v.version}
                            isActive={v.active}
                            busy={busy}
                            onActivate={() => void activateVersion(v.id)}
                            onDeactivate={() => void deactivateVersion(v.id)}
                            onDelete={() => setConfirmDeleteVersionId(v.id)}
                          />
                        </TableCell>
                      </TableRow>,
                    ];
                    if (expanded) {
                      rows.push(
                        <TableRow key={`${v.id}-detail`} className="bg-muted/30 hover:bg-muted/30">
                          <TableCell colSpan={4} className="p-3">
                            <AgentVersionDetailCard version={v} />
                          </TableCell>
                        </TableRow>,
                      );
                    }
                    return rows;
                  })
                )}
              </TableBody>
            </Table>

            <div>
              <div className="mb-2 flex items-center justify-between gap-2">
                <h4 className="text-sm font-medium">New version</h4>
                <div
                  role="tablist"
                  className="inline-flex overflow-hidden rounded border"
                >
                  <button
                    type="button"
                    role="tab"
                    aria-selected={versionMode === "inline"}
                    className={cn(
                      "px-2 py-1 text-xs",
                      versionMode === "inline"
                        ? "bg-primary text-primary-foreground"
                        : "bg-background text-muted-foreground hover:bg-muted",
                    )}
                    onClick={() => setVersionMode("inline")}
                  >
                    Inline
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={versionMode === "spec"}
                    className={cn(
                      "px-2 py-1 text-xs border-l",
                      versionMode === "spec"
                        ? "bg-primary text-primary-foreground"
                        : "bg-background text-muted-foreground hover:bg-muted",
                    )}
                    onClick={() => setVersionMode("spec")}
                  >
                    From spec (YAML/JSON)
                  </button>
                </div>
              </div>
              {versionMode === "spec" ? (
                <SpecVersionForm
                  specText={newSpecText}
                  onSpecTextChange={(v) => {
                    setNewSpecText(v);
                    setSpecValidation(null);
                  }}
                  parsedSpec={parsedSpec}
                  validation={specValidation}
                  validating={specValidating}
                  onValidate={() => void runSpecValidation()}
                  specVersion={newSpecVersion}
                  onSpecVersionChange={setNewSpecVersion}
                  submitDisabled={busy || !specReadyForSubmit}
                  onSubmit={(e) => void submitSpecVersion(e)}
                  onBrowseCatalog={() => setCatalogOpen(true)}
                />
              ) : (
                <InlineVersionForm
                  state={inlineForm}
                  dispatch={dispatchInlineForm}
                  providerPresets={providerPresets}
                  busy={busy}
                  onSubmit={(e) => void submitNewVersion(e)}
                />
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Policies</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                {policies.items.length === 0 ? (
                  <p className="text-muted-foreground">No policies for this agent.</p>
                ) : (
                  policies.items.map((p) => (
                    <li key={p.id}>
                      {p.policy_type}{" "}
                      <span className="text-muted-foreground">({p.enabled ? "enabled" : "disabled"})</span>
                    </li>
                  ))
                )}
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Audit</CardTitle>
              <CardDescription>Actions on this agent (resource_type=agent)</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="max-h-64 space-y-2 overflow-y-auto text-sm">
                {audit.items.length === 0 ? (
                  <p className="text-muted-foreground">No audit entries for this agent.</p>
                ) : (
                  audit.items.map((a) => (
                    <li key={a.id} className="border-b border-border/40 pb-2 last:border-0">
                      <span className="font-medium">{a.action}</span>
                      <span className="text-muted-foreground">
                        {" "}
                        · {a.actor} · {formatDateTimeShort(a.created_at)}
                      </span>
                    </li>
                  ))
                )}
              </ul>
            </CardContent>
          </Card>
        </div>

        <p className="mt-4 text-xs text-muted-foreground">
          ID <span className="font-mono">{agent.id}</span> · Created {formatDateTimeShort(agent.created_at)} · Updated{" "}
          {formatDateTimeShort(agent.updated_at)}
          {agent.current_version_id ? (
            <>
              {" "}
              · Current version id{" "}
              <span className="font-mono">{agent.current_version_id.slice(0, 8)}...</span>
            </>
          ) : null}
        </p>
      </div>
    </div>
  );
}
