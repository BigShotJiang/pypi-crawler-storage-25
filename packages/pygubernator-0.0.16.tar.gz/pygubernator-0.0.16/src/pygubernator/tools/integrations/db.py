"""Database tools (SQLite/Postgres/MongoDB/Redis) for agent workflows.

Design goals:
  - Consistent tool naming across backends (db_<backend>_<operation>)
  - Env-driven configuration via create_tools_from_env()
  - Async tool functions that run blocking I/O in threads with timeouts
  - Optional dependencies for non-stdlib backends (psycopg/pymongo/redis)
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, Literal

from pygubernator.config._helpers import _cfg
from pygubernator.tools._decorator import tool

_DEFAULT_TOOL_TIMEOUT_S = float(os.getenv("PYGUBERNATOR_DB_TOOL_TIMEOUT", "30"))

Backend = Literal["sqlite", "postgres", "mongodb", "redis"]


def _timeout(timeout_s: float | None) -> float:
    return _DEFAULT_TOOL_TIMEOUT_S if timeout_s is None else float(timeout_s)


def _rows_to_dicts(
    columns: list[str], rows: Iterable[tuple[Any, ...]]
) -> list[dict[str, Any]]:
    return [dict(zip(columns, r, strict=False)) for r in rows]


# ======================================================================
# SQLite
# ======================================================================


@dataclass(frozen=True)
class _SQLiteCfg:
    db_path: str


def create_sqlite_tools(db_path: str) -> list[Any]:
    """Create SQLite tools bound to a database file path.

    Args:
        db_path: SQLite file path.
    """

    cfg = _SQLiteCfg(db_path=db_path)

    def _connect() -> sqlite3.Connection:
        con = sqlite3.connect(cfg.db_path, timeout=5.0)
        con.row_factory = sqlite3.Row
        return con

    def _execute(
        sql: str,
        params_json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        params_json = params_json or {}
        with _connect() as con:
            cur = con.execute(sql, params_json)
            return {"rows_affected": cur.rowcount}

    def _query(
        sql: str,
        params_json: dict[str, Any] | None = None,
        limit: int = 200,
    ) -> dict[str, Any]:
        params_json = params_json or {}
        with _connect() as con:
            cur = con.execute(sql, params_json)
            rows = cur.fetchmany(max(0, int(limit)))
            columns = [d[0] for d in cur.description] if cur.description else []
            return {
                "columns": columns,
                "rows": _rows_to_dicts(columns, [tuple(r) for r in rows]),
            }

    def _list_tables() -> dict[str, Any]:
        with _connect() as con:
            cur = con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            return {"tables": [r[0] for r in cur.fetchall()]}

    @tool(
        name="db_sqlite_execute",
        description=("Execute a SQLite statement (INSERT/UPDATE/DELETE/DDL)."),
    )
    async def db_sqlite_execute(
        sql: str,
        params_json: dict[str, Any] | None = None,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Execute a non-SELECT SQL statement.

        Args:
            sql: SQL statement to execute.
            params_json: Named parameters dict for SQLite
                (e.g. {"id": 1}).
            timeout_s: Tool timeout seconds.
        """
        return await asyncio.wait_for(
            asyncio.to_thread(_execute, sql, params_json),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_sqlite_query",
        description=("Run a SQLite SELECT query and return rows as JSON."),
    )
    async def db_sqlite_query(
        sql: str,
        params_json: dict[str, Any] | None = None,
        limit: int = 200,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Run a SELECT query.

        Args:
            sql: SELECT query.
            params_json: Named parameters dict for SQLite.
            limit: Maximum rows to return.
            timeout_s: Tool timeout seconds.
        """
        return await asyncio.wait_for(
            asyncio.to_thread(_query, sql, params_json, limit),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_sqlite_list_tables",
        description="List SQLite tables in the database.",
    )
    async def db_sqlite_list_tables(
        *, timeout_s: float | None = None
    ) -> dict[str, Any]:
        """List tables.

        Args:
            timeout_s: Tool timeout seconds.
        """
        return await asyncio.wait_for(
            asyncio.to_thread(_list_tables),
            timeout=_timeout(timeout_s),
        )

    return [
        db_sqlite_execute,
        db_sqlite_query,
        db_sqlite_list_tables,
    ]


# ======================================================================
# Postgres (optional dependency: psycopg)
# ======================================================================


def create_postgres_tools(dsn: str) -> list[Any]:
    """Create Postgres tools backed by psycopg (sync).

    Args:
        dsn: Postgres DSN string.
    """
    try:
        import psycopg  # type: ignore[import-untyped]
    except Exception as exc:  # pragma: no cover
        raise ImportError("Postgres tools require 'psycopg'") from exc

    def _execute(
        sql: str,
        params_json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        params_json = params_json or {}
        with psycopg.connect(dsn) as con, con.cursor() as cur:
            cur.execute(sql, params_json)
            return {"rows_affected": cur.rowcount}

    def _query(
        sql: str,
        params_json: dict[str, Any] | None = None,
        limit: int = 200,
    ) -> dict[str, Any]:
        params_json = params_json or {}
        with psycopg.connect(dsn) as con, con.cursor() as cur:
            cur.execute(sql, params_json)
            rows = cur.fetchmany(max(0, int(limit)))
            columns = [d.name for d in cur.description] if cur.description else []
            return {
                "columns": columns,
                "rows": _rows_to_dicts(columns, rows),
            }

    @tool(
        name="db_postgres_execute",
        description=("Execute a Postgres statement (INSERT/UPDATE/DELETE/DDL)."),
    )
    async def db_postgres_execute(
        sql: str,
        params_json: dict[str, Any] | None = None,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_execute, sql, params_json),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_postgres_query",
        description=("Run a Postgres SELECT query and return rows as JSON."),
    )
    async def db_postgres_query(
        sql: str,
        params_json: dict[str, Any] | None = None,
        limit: int = 200,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_query, sql, params_json, limit),
            timeout=_timeout(timeout_s),
        )

    return [db_postgres_execute, db_postgres_query]


# ======================================================================
# MongoDB (optional dependency: pymongo)
# ======================================================================


def create_mongodb_tools(uri: str, database: str) -> list[Any]:
    """Create MongoDB tools using pymongo (sync)."""
    try:
        from pymongo import MongoClient  # type: ignore[import-untyped]
    except Exception as exc:  # pragma: no cover
        raise ImportError("MongoDB tools require 'pymongo'") from exc

    client = MongoClient(uri)
    db = client[database]

    def _find(
        collection: str,
        filter_json: dict[str, Any] | None,
        limit: int,
    ) -> dict[str, Any]:
        filt = filter_json or {}
        cur = db[collection].find(filt).limit(max(0, int(limit)))
        docs = []
        for d in cur:
            # ObjectId is not JSON serializable; coerce to string.
            if "_id" in d:
                d["_id"] = str(d["_id"])
            docs.append(d)
        return {"documents": docs, "count": len(docs)}

    def _insert_one(
        collection: str,
        document: dict[str, Any],
    ) -> dict[str, Any]:
        res = db[collection].insert_one(document)
        return {"inserted_id": str(res.inserted_id)}

    @tool(
        name="db_mongodb_find",
        description=("Find documents in a MongoDB collection."),
    )
    async def db_mongodb_find(
        collection: str,
        filter_json: dict[str, Any] | None = None,
        limit: int = 50,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_find, collection, filter_json, limit),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_mongodb_insert_one",
        description=("Insert one document into a MongoDB collection."),
    )
    async def db_mongodb_insert_one(
        collection: str,
        document: dict[str, Any],
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_insert_one, collection, document),
            timeout=_timeout(timeout_s),
        )

    return [db_mongodb_find, db_mongodb_insert_one]


# ======================================================================
# Redis (optional dependency: redis)
# ======================================================================


def create_redis_tools(url: str) -> list[Any]:
    """Create Redis tools using redis-py (sync)."""
    try:
        import redis  # type: ignore[import-untyped]
    except Exception as exc:  # pragma: no cover
        raise ImportError("Redis tools require 'redis'") from exc

    r = redis.Redis.from_url(url, decode_responses=True)

    def _get(key: str) -> dict[str, Any]:
        return {"key": key, "value": r.get(key)}

    def _set(key: str, value: str, ex_seconds: int | None) -> dict[str, Any]:
        ok = r.set(key, value, ex=ex_seconds)
        return {"ok": bool(ok)}

    def _keys(pattern: str, limit: int) -> dict[str, Any]:
        ks = list(r.scan_iter(match=pattern, count=max(1, int(limit))))
        return {
            "keys": ks[: max(0, int(limit))],
            "count": min(len(ks), max(0, int(limit))),
        }

    @tool(
        name="db_redis_get",
        description="Get a key from Redis.",
    )
    async def db_redis_get(
        key: str, *, timeout_s: float | None = None
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_get, key),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_redis_set",
        description="Set a key in Redis.",
    )
    async def db_redis_set(
        key: str,
        value: str,
        ex_seconds: int | None = None,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_set, key, value, ex_seconds),
            timeout=_timeout(timeout_s),
        )

    @tool(
        name="db_redis_keys",
        description="List Redis keys (pattern match).",
    )
    async def db_redis_keys(
        pattern: str = "*",
        limit: int = 50,
        *,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        return await asyncio.wait_for(
            asyncio.to_thread(_keys, pattern, limit),
            timeout=_timeout(timeout_s),
        )

    return [db_redis_get, db_redis_set, db_redis_keys]


# ======================================================================
# Factory (env-based)
# ======================================================================


def _resolve_value(
    explicit: str | None,
    *,
    env_var: str,
) -> str:
    """Resolve a backend setting using standard precedence.

    Precedence (highest to lowest):
      1) explicit value passed in factory_args (workflow artifact)
      2) environment variable (includes DB-injected
         IntegrationCredential values)
      3) pygubernator.cfg [integrations]
    """
    if explicit is not None and str(explicit).strip():
        return str(explicit).strip()
    env_val = os.environ.get(env_var, "")
    if env_val.strip():
        return env_val.strip()
    cfg_val = _cfg("integrations", env_var) or ""
    return cfg_val.strip()


def create_tools_from_env(
    backend: Backend,
    *,
    # Explicit values (preferred when set; override env/cfg)
    sqlite_path: str | None = None,
    postgres_dsn: str | None = None,
    mongodb_uri: str | None = None,
    mongodb_database: str | None = None,
    redis_url: str | None = None,
    # Env var indirection (lets workflows refer to custom env names)
    sqlite_path_env: str = "PYGUBERNATOR_SQLITE_PATH",
    postgres_dsn_env: str = "PYGUBERNATOR_POSTGRES_DSN",
    mongodb_uri_env: str = "PYGUBERNATOR_MONGODB_URI",
    mongodb_db_env: str = "PYGUBERNATOR_MONGODB_DATABASE",
    redis_url_env: str = "PYGUBERNATOR_REDIS_URL",
) -> list[Any]:
    """Create database tools for a chosen backend using env/cfg or explicit args.

    Args:
        backend: One of sqlite/postgres/mongodb/redis.
        sqlite_path: Explicit sqlite db path (overrides env/cfg).
        postgres_dsn: Explicit Postgres DSN (overrides env/cfg).
        mongodb_uri: Explicit MongoDB URI (overrides env/cfg).
        mongodb_database: Explicit MongoDB DB name
            (overrides env/cfg).
        redis_url: Explicit Redis URL (overrides env/cfg).
        sqlite_path_env: Env var containing sqlite db path.
        postgres_dsn_env: Env var containing postgres DSN.
        mongodb_uri_env: Env var containing mongodb connection URI.
        mongodb_db_env: Env var containing mongodb database name.
        redis_url_env: Env var containing redis URL.
    """
    backend = str(backend).strip().lower()

    if backend == "sqlite":
        path = _resolve_value(sqlite_path, env_var=sqlite_path_env)
        if not path:
            raise ValueError(f"Missing SQLite path. Set {sqlite_path_env}.")
        return create_sqlite_tools(path)

    if backend == "postgres":
        dsn = _resolve_value(postgres_dsn, env_var=postgres_dsn_env)
        if not dsn:
            raise ValueError(f"Missing Postgres DSN. Set {postgres_dsn_env}.")
        return create_postgres_tools(dsn)

    if backend == "mongodb":
        uri = _resolve_value(mongodb_uri, env_var=mongodb_uri_env)
        db_name = _resolve_value(mongodb_database, env_var=mongodb_db_env)
        if not uri:
            raise ValueError(f"Missing MongoDB URI. Set {mongodb_uri_env}.")
        if not db_name:
            raise ValueError(f"Missing MongoDB database. Set {mongodb_db_env}.")
        return create_mongodb_tools(uri=uri, database=db_name)

    if backend == "redis":
        url = _resolve_value(redis_url, env_var=redis_url_env)
        if not url:
            raise ValueError(f"Missing Redis URL. Set {redis_url_env}.")
        return create_redis_tools(url)

    raise ValueError(f"Unknown backend: {backend}")
