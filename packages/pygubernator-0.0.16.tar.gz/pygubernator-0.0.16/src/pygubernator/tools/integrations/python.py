"""Python execution tools for running code and expressions."""

from __future__ import annotations

import asyncio
import builtins
import logging
import os
import subprocess
import sys
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

_ALLOWED_IMPORTS_ENV = "PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS"
_TIMEOUT_ENV = "PYGUBERNATOR_PYTHON_TIMEOUT"


class _PythonExecutor:
    """Executes Python code and expressions with optional import restrictions.

    Args:
        allowed_imports: If provided, only these module names may be
            imported.  ``None`` means unrestricted.
        timeout: Maximum seconds for code execution.
    """

    def __init__(
        self,
        allowed_imports: list[str] | None = None,
        timeout: int = 30,
    ) -> None:
        self._allowed_imports = allowed_imports
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Namespace helpers
    # ------------------------------------------------------------------

    def _build_namespace(
        self,
        variables: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Build an execution namespace with full builtins.

        Args:
            variables: Extra variables to inject into the namespace.

        Returns:
            Namespace dict ready for ``exec`` / ``eval``.
        """
        ns: dict[str, Any] = {"__builtins__": builtins.__dict__.copy()}

        if self._allowed_imports is not None:
            original_import = builtins.__import__
            allowed = set(self._allowed_imports)

            def _guarded_import(name: str, *args: Any, **kwargs: Any) -> Any:
                top_level = name.split(".")[0]
                if top_level not in allowed:
                    msg = (
                        f"Import of '{name}' is not allowed. "
                        f"Allowed imports: {sorted(allowed)}"
                    )
                    raise ImportError(msg)
                return original_import(name, *args, **kwargs)

            ns["__builtins__"]["__import__"] = _guarded_import

        if variables:
            ns.update(variables)

        return ns

    @staticmethod
    def _extract_user_vars(
        namespace: dict[str, Any],
    ) -> dict[str, Any]:
        """Return user-assigned variables from a namespace.

        Args:
            namespace: The execution namespace after code ran.

        Returns:
            Dict of user-assigned variables (excludes dunders
            and ``__builtins__``).
        """
        return {k: v for k, v in namespace.items() if not k.startswith("__")}

    # ------------------------------------------------------------------
    # Public execution methods
    # ------------------------------------------------------------------

    def exec_code(
        self,
        code: str,
        variables: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute Python code via ``exec``.

        The code should assign to a ``result`` variable in order to
        communicate its output.

        Args:
            code: Python source code to execute.
            variables: Variables to inject into the namespace.

        Returns:
            Dict with ``result`` and ``variables`` keys.
        """
        namespace = self._build_namespace(variables)
        compiled = compile(code, "<python_exec>", "exec")
        exec(compiled, namespace)  # noqa: S102
        user_vars = self._extract_user_vars(namespace)
        return {
            "result": namespace.get("result"),
            "variables": user_vars,
        }

    def eval_expression(
        self,
        expression: str,
        variables: dict[str, Any] | None = None,
    ) -> Any:
        """Evaluate a single Python expression via ``eval``.

        Args:
            expression: Python expression to evaluate.
            variables: Variables to inject into the namespace.

        Returns:
            The evaluated value.
        """
        namespace = self._build_namespace(variables)
        compiled = compile(expression, "<python_eval>", "eval")
        return eval(compiled, namespace)  # noqa: S307

    def install_package(self, package: str) -> dict[str, Any]:
        """Install a Python package using pip.

        Args:
            package: Package specifier (e.g. ``requests>=2.0``).

        Returns:
            Dict with ``success``, ``stdout``, and ``stderr``.
        """
        logger.info("Installing package %s", package)
        result = subprocess.run(  # noqa: S603
            [sys.executable, "-m", "pip", "install", package],
            capture_output=True,
            text=True,
            timeout=self._timeout,
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }


# ======================================================================
# Tool creation
# ======================================================================


def create_python_tools(
    allowed_imports: list[str] | None = None,
    timeout: int = 30,
) -> list[Any]:
    """Create Python execution tools.

    Args:
        allowed_imports: If provided, only these module names may be
            imported.  ``None`` means unrestricted (all installed
            packages available).
        timeout: Maximum seconds for code execution.

    Returns:
        List of tool objects ready for registration.
    """
    executor = _PythonExecutor(
        allowed_imports=allowed_imports,
        timeout=timeout,
    )

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="python_exec",
        description=(
            "Execute Python code. Assign results to a `result` "
            "variable. All installed packages are available."
        ),
    )
    async def python_exec(
        code: str,
        variables: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute Python code and return the result.

        Args:
            code: Python source code to execute.  Assign output to
                a ``result`` variable.
            variables: Optional dict of variables to inject into
                the execution namespace.

        Returns:
            Dict with ``result`` and ``variables`` keys.
        """
        logger.debug("Executing Python code (%d chars)", len(code))
        return await asyncio.wait_for(
            asyncio.to_thread(executor.exec_code, code, variables),
            timeout=timeout,
        )

    @tool(
        name="python_eval",
        description=("Evaluate a single Python expression and return its value."),
    )
    async def python_eval(
        expression: str,
        variables: dict[str, Any] | None = None,
    ) -> Any:
        """Evaluate a Python expression.

        Args:
            expression: Python expression to evaluate.
            variables: Optional dict of variables to inject into
                the evaluation namespace.

        Returns:
            The evaluated value.
        """
        logger.debug("Evaluating expression: %s", expression)
        return await asyncio.wait_for(
            asyncio.to_thread(
                executor.eval_expression,
                expression,
                variables,
            ),
            timeout=timeout,
        )

    @tool(
        name="python_install",
        description="Install a Python package using pip.",
    )
    async def python_install(
        package: str,
    ) -> dict[str, Any]:
        """Install a Python package.

        Args:
            package: Package specifier (e.g. ``requests>=2.0``).

        Returns:
            Dict with ``success``, ``stdout``, and ``stderr``.
        """
        logger.debug("Installing package: %s", package)
        return await asyncio.to_thread(executor.install_package, package)

    return [python_exec, python_eval, python_install]


# ======================================================================
# Factory (env-based)
# ======================================================================


def create_tools_from_env() -> list[Any]:
    """Create Python execution tools using configuration from env.

    Reads:
        ``PYGUBERNATOR_PYTHON_ALLOWED_IMPORTS``: Comma-separated list
            of allowed module names.  Empty or unset means unrestricted.
        ``PYGUBERNATOR_PYTHON_TIMEOUT``: Max seconds for execution
            (default ``30``).

    Returns:
        A list of tool objects ready for registration.
    """
    raw_imports = os.environ.get(_ALLOWED_IMPORTS_ENV, "").strip()
    allowed_imports: list[str] | None = None
    if raw_imports:
        allowed_imports = [m.strip() for m in raw_imports.split(",") if m.strip()]

    timeout = int(os.environ.get(_TIMEOUT_ENV, "30"))

    return create_python_tools(
        allowed_imports=allowed_imports,
        timeout=timeout,
    )
