"""Tool wrappers for pycharter data contract validation."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)
_CONTRACTS_ENV = "PYGUBERNATOR_CHARTER_CONTRACTS_PATH"


def create_charter_tools(validators: dict[str, Any]) -> list[Any]:
    """Create pycharter validation tools pre-loaded with validators.

    Args:
        validators: Mapping of contract name to Validator objects.

    Returns:
        List of tool objects ready for registration.
    """

    @tool(
        name="validate_record",
        description=(
            "Validate a single record against a named data contract. "
            "Returns a validation result dict."
        ),
    )
    async def validate_record(
        record: dict[str, Any],
        contract_name: str,
    ) -> dict[str, Any]:
        """Validate a record against a data contract.

        Args:
            record: The data record to validate.
            contract_name: Name of the contract to validate against.

        Returns:
            Dict with 'valid' bool and 'errors' list.
        """
        if contract_name not in validators:
            raise ValueError(
                f"Contract '{contract_name}' not found. "
                f"Available: {list(validators.keys())}"
            )

        validator = validators[contract_name]
        result = validator.validate(record)
        return {
            "valid": result.is_valid,
            "errors": [e.to_dict() for e in result.errors],
        }

    @tool(
        name="validate_batch",
        description=(
            "Validate a batch of records against a named data contract. "
            "Returns summary statistics."
        ),
    )
    async def validate_batch(
        records: list[dict[str, Any]],
        contract_name: str,
    ) -> dict[str, Any]:
        """Validate a batch of records against a data contract.

        Args:
            records: List of data records to validate.
            contract_name: Name of the contract to validate against.

        Returns:
            Dict with total, valid_count, invalid_count, and errors.
        """
        if contract_name not in validators:
            raise ValueError(
                f"Contract '{contract_name}' not found. "
                f"Available: {list(validators.keys())}"
            )

        validator = validators[contract_name]
        total = len(records)
        valid_count = 0
        all_errors: list[dict[str, Any]] = []

        for i, record in enumerate(records):
            result = validator.validate(record)
            if result.is_valid:
                valid_count += 1
            else:
                for err in result.errors:
                    err_dict = err.to_dict()
                    err_dict["record_index"] = i
                    all_errors.append(err_dict)

        return {
            "total": total,
            "valid_count": valid_count,
            "invalid_count": total - valid_count,
            "errors": all_errors,
        }

    return [validate_record, validate_batch]


def _is_contract_dir(path: Path) -> bool:
    return (path / "schema.yaml").exists() or (path / "schema.yml").exists()


def _load_validators_from_path(path: str | Path) -> dict[str, Any]:
    """Load one or more pycharter validators from a file or directory path."""

    try:
        from pycharter.runtime_validator import Validator
    except ImportError as exc:
        raise ImportError(
            "pycharter is required for charter tools. Install with: pip install pycharter"
        ) from exc

    root = Path(path).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"PyCharter contracts path not found: {root}")

    validators: dict[str, Any] = {}
    if root.is_file():
        validators[root.stem] = Validator(contract_file=str(root))
        return validators

    if _is_contract_dir(root):
        validators[root.name] = Validator(contract_dir=str(root))
        return validators

    # Directory of contracts: accept sub-directories with schema.yaml/schema.yml
    # and standalone contract files.
    for entry in sorted(root.iterdir()):
        if entry.is_dir() and _is_contract_dir(entry):
            validators[entry.name] = Validator(contract_dir=str(entry))
            continue
        if entry.is_file() and entry.suffix.lower() in {".yaml", ".yml", ".json"}:
            validators[entry.stem] = Validator(contract_file=str(entry))

    if not validators:
        raise ValueError(
            f"No loadable pycharter contracts found under: {root}. "
            "Expected a contract directory, a contract file, or a directory "
            "containing contract files/subdirectories."
        )
    return validators


def create_tools_from_env(
    contracts_env_var: str = _CONTRACTS_ENV,
) -> list[Any]:
    """Create pycharter tools from a contract path in environment."""

    contracts_path = os.environ.get(contracts_env_var, "").strip()
    if not contracts_path:
        logger.info(
            "No %s configured. Charter tools will start with an empty contract set.",
            contracts_env_var,
        )
        return create_charter_tools({})

    logger.info("Loading pycharter contracts from %s", contracts_path)
    validators = _load_validators_from_path(contracts_path)
    return create_charter_tools(validators)
