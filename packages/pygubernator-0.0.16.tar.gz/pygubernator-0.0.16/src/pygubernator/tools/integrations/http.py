"""HTTP/REST tools for making API requests."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

_BASE_URL_ENV = "PYGUBERNATOR_HTTP_BASE_URL"
_HEADERS_ENV = "PYGUBERNATOR_HTTP_DEFAULT_HEADERS"
_TIMEOUT_ENV = "PYGUBERNATOR_HTTP_TIMEOUT"


def _check_deps() -> None:
    """Raise if httpx dependency is missing."""
    if not _HAS_HTTPX:
        msg = "httpx is required for HTTP tools. Install with: pip install httpx"
        raise ImportError(msg)


class _HttpClient:
    """Thin async wrapper around httpx for HTTP requests.

    Args:
        base_url: Base URL prepended to relative request URLs.
        default_headers: Headers merged into every request.
        timeout: Default request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = "",
        default_headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        _check_deps()
        self._base_url = base_url
        self._default_headers = default_headers or {}
        self._timeout = timeout
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=self._default_headers,
            timeout=timeout,
        )

    # ------------------------------------------------------------------
    # Request helpers
    # ------------------------------------------------------------------

    async def get(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        params: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send a GET request.

        Args:
            url: Request URL (absolute or relative to base_url).
            headers: Extra headers for this request.
            params: Query parameters.

        Returns:
            Dict with status_code, headers, and body.
        """
        response = await self._client.get(
            url,
            headers=headers,
            params=params,
        )
        return self._build_result(response)

    async def post(
        self,
        url: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send a POST request with a JSON body.

        Args:
            url: Request URL (absolute or relative to base_url).
            body: JSON-serialisable request body.
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        response = await self._client.post(
            url,
            json=body,
            headers=headers,
        )
        return self._build_result(response)

    async def put(
        self,
        url: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send a PUT request with a JSON body.

        Args:
            url: Request URL (absolute or relative to base_url).
            body: JSON-serialisable request body.
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        response = await self._client.put(
            url,
            json=body,
            headers=headers,
        )
        return self._build_result(response)

    async def delete(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Send a DELETE request.

        Args:
            url: Request URL (absolute or relative to base_url).
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        response = await self._client.delete(
            url,
            headers=headers,
        )
        return self._build_result(response)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _build_result(
        response: httpx.Response,
    ) -> dict[str, Any]:
        """Convert an httpx response to a standardised dict.

        Args:
            response: The httpx response object.

        Returns:
            Dict with status_code, headers, and body.
        """
        try:
            body: Any = response.json()
        except Exception:
            body = response.text
        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "body": body,
        }


# ======================================================================
# Tool creation
# ======================================================================


def create_http_tools(
    base_url: str = "",
    default_headers: dict[str, str] | None = None,
    timeout: float = 30.0,
) -> list[Any]:
    """Create HTTP tools backed by a shared async client.

    Args:
        base_url: Base URL prepended to relative request URLs.
        default_headers: Headers merged into every request.
        timeout: Default request timeout in seconds.

    Returns:
        List of tool objects ready for registration.
    """
    client = _HttpClient(
        base_url=base_url,
        default_headers=default_headers,
        timeout=timeout,
    )

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="http_get",
        description="Make an HTTP GET request.",
    )
    async def http_get(
        url: str,
        headers: dict[str, str] | None = None,
        params: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP GET request.

        Args:
            url: Request URL (absolute or relative to base_url).
            headers: Extra headers for this request.
            params: Query string parameters.

        Returns:
            Dict with status_code, headers, and body.
        """
        return await client.get(url, headers=headers, params=params)

    @tool(
        name="http_post",
        description=("Make an HTTP POST request with a JSON body."),
    )
    async def http_post(
        url: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP POST request with a JSON body.

        Args:
            url: Request URL (absolute or relative to base_url).
            body: JSON request body.
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        return await client.post(url, body=body, headers=headers)

    @tool(
        name="http_put",
        description=("Make an HTTP PUT request with a JSON body."),
    )
    async def http_put(
        url: str,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP PUT request with a JSON body.

        Args:
            url: Request URL (absolute or relative to base_url).
            body: JSON request body.
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        return await client.put(url, body=body, headers=headers)

    @tool(
        name="http_delete",
        description="Make an HTTP DELETE request.",
    )
    async def http_delete(
        url: str,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an HTTP DELETE request.

        Args:
            url: Request URL (absolute or relative to base_url).
            headers: Extra headers for this request.

        Returns:
            Dict with status_code, headers, and body.
        """
        return await client.delete(url, headers=headers)

    return [http_get, http_post, http_put, http_delete]


# ======================================================================
# Factory (env-based)
# ======================================================================


def create_tools_from_env() -> list[Any]:
    """Create HTTP tools using configuration from environment variables.

    Reads the following env vars:
        - ``PYGUBERNATOR_HTTP_BASE_URL`` (optional, default ``""``).
        - ``PYGUBERNATOR_HTTP_DEFAULT_HEADERS`` (optional JSON).
        - ``PYGUBERNATOR_HTTP_TIMEOUT`` (optional, default ``30.0``).

    Returns:
        A list of tool objects ready for registration.
    """
    base_url = os.environ.get(_BASE_URL_ENV, "").strip()

    raw_headers = os.environ.get(_HEADERS_ENV, "").strip()
    default_headers: dict[str, str] | None = None
    if raw_headers:
        default_headers = json.loads(raw_headers)

    raw_timeout = os.environ.get(_TIMEOUT_ENV, "").strip()
    timeout = float(raw_timeout) if raw_timeout else 30.0

    return create_http_tools(
        base_url=base_url,
        default_headers=default_headers,
        timeout=timeout,
    )
