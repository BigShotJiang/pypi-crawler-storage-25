"""Tool wrappers and factory for pycatalyst mock data generation."""

from __future__ import annotations

import logging
import os
from dataclasses import is_dataclass
from enum import Enum
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

_SCHEMAS_ENV = "PYGUBERNATOR_CATALYST_SCHEMAS_PATH"

# Built-in demo schema names (must match keys returned by ``_default_schemas``).
BUILTIN_CATALYST_SCHEMA_NAMES: tuple[str, ...] = (
    "users",
    "orders",
    "products",
    "risk_assessments",
)

# Field ``type`` values accepted by ``_add_builder_field`` (UI / API hints).
CATALYST_FIELD_TYPES_SUPPORTED: tuple[str, ...] = (
    "string",
    "str",
    "int",
    "integer",
    "float",
    "number",
    "bool",
    "boolean",
    "uuid",
    "date",
    "datetime",
    "timestamp",
    "enum",
)


# ======================================================================
# Schema helpers
# ======================================================================


def _schema_to_jsonable(obj: Any) -> Any:
    if isinstance(obj, Enum):
        return obj.value
    if is_dataclass(obj):
        # Avoid dataclasses.asdict to keep control over Enum/tuple conversion
        # and to omit None values (SchemaSpec.from_config expects constraints
        # to be absent, not present as null).
        out: dict[str, Any] = {}
        for k in obj.__dataclass_fields__:  # type: ignore[attr-defined]
            v = getattr(obj, k)
            if v is None:
                continue
            out[k] = _schema_to_jsonable(v)
        return out
    if isinstance(obj, dict):
        return {str(k): _schema_to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list | tuple):
        return [_schema_to_jsonable(v) for v in obj]
    return obj


def _add_builder_field(
    builder: Any,
    name: str,
    type_name: str,
    cfg: dict[str, Any],
) -> None:
    t = type_name.strip().lower()

    # Common constraints (tests use min/max; builder uses min_val/max_val)
    min_val = cfg.get("min", cfg.get("min_val"))
    max_val = cfg.get("max", cfg.get("max_val"))

    if t in {"string", "str"}:
        builder.add_string(
            name,
            nullable=bool(cfg.get("nullable", False)),
            min_len=cfg.get("min_len"),
            max_len=cfg.get("max_len"),
            pattern=cfg.get("pattern"),
            format=cfg.get("format"),
        )
        return

    if t in {"int", "integer"}:
        builder.add_int(
            name,
            nullable=bool(cfg.get("nullable", False)),
            min_val=min_val,
            max_val=max_val,
            distribution=cfg.get("distribution"),
            mean=cfg.get("mean"),
            std=cfg.get("std"),
        )
        return

    if t in {"float", "number"}:
        builder.add_float(
            name,
            nullable=bool(cfg.get("nullable", False)),
            min_val=min_val,
            max_val=max_val,
            precision=cfg.get("precision"),
            distribution=cfg.get("distribution"),
            mean=cfg.get("mean"),
            std=cfg.get("std"),
        )
        return

    if t in {"bool", "boolean"}:
        builder.add_bool(name, nullable=bool(cfg.get("nullable", False)))
        return

    if t in {"uuid"}:
        builder.add_uuid(name, nullable=bool(cfg.get("nullable", False)))
        return

    if t in {"date"}:
        builder.add_date(name, nullable=bool(cfg.get("nullable", False)))
        return

    if t in {"datetime", "timestamp"}:
        builder.add_datetime(name, nullable=bool(cfg.get("nullable", False)))
        return

    if t in {"enum"}:
        choices = cfg.get("choices")
        if not isinstance(choices, list) or not choices:
            raise ValueError(
                f"Field '{name}' type enum requires non-empty 'choices' list"
            )
        builder.add_enum(
            name, choices=choices, nullable=bool(cfg.get("nullable", False))
        )
        return

    raise ValueError(
        f"Unsupported field type '{type_name}' for '{name}'. "
        "Supported: string, int, float, bool, uuid, date, datetime, enum"
    )


def _build_schema_spec(fields: dict[str, dict[str, Any]]) -> Any:
    from pycatalyst import SchemaBuilder

    builder = SchemaBuilder("dynamic", description="Agent-built schema")
    for name, config in fields.items():
        field_config = dict(config)
        type_name = field_config.pop("type", None)
        if not isinstance(type_name, str) or not type_name.strip():
            raise ValueError(f"Field '{name}' is missing required key: type")
        _add_builder_field(builder, name, type_name, field_config)
    return builder.build()


# ======================================================================
# Tool creation
# ======================================================================


def create_catalyst_tools(schemas: dict[str, Any]) -> list[Any]:
    """Create pycatalyst tools pre-loaded with schema definitions.

    Args:
        schemas: Mapping of schema name to SchemaSpec objects.

    Returns:
        List of tool objects ready for registration.
    """

    @tool(
        name="generate_data",
        description=(
            "Generate mock data records using a named schema. "
            "Returns a list of dictionaries."
        ),
    )
    async def generate_data(
        schema_name: str,
        count: int = 10,
        seed: int | None = None,
    ) -> list[dict[str, Any]]:
        """Generate mock data from a registered schema.

        Args:
            schema_name: Name of the schema to use.
            count: Number of records to generate.
            seed: Optional random seed for reproducibility.

        Returns:
            List of generated records.
        """
        try:
            from pycatalyst import GenerationEngine
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        if schema_name not in schemas:
            raise ValueError(
                f"Schema '{schema_name}' not found. Available: {list(schemas.keys())}"
            )

        engine = GenerationEngine()
        result = engine.generate(schemas[schema_name], count, seed)
        return list(result.records)

    @tool(
        name="generate_from_fields",
        description=(
            "Generate mock data directly from field definitions without a "
            "pre-registered schema name. Returns a list of dictionaries."
        ),
    )
    async def generate_from_fields(
        fields: dict[str, dict[str, Any]],
        count: int = 10,
        seed: int | None = None,
    ) -> list[dict[str, Any]]:
        """Generate mock data from ad-hoc field definitions.

        Args:
            fields: Mapping of field name to field config dicts.
            count: Number of records to generate.
            seed: Optional random seed for reproducibility.

        Returns:
            List of generated records.
        """
        try:
            from pycatalyst import GenerationEngine
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc

        schema = _build_schema_spec(fields)
        engine = GenerationEngine()
        result = engine.generate(schema, count, seed)
        return list(result.records)

    @tool(
        name="build_schema",
        description=(
            "Build a pycatalyst SchemaSpec from field definitions. "
            "Returns a serializable schema dict."
        ),
    )
    async def build_schema(
        fields: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Build a schema from field definitions.

        Args:
            fields: Mapping of field name to field config dicts.
                Each dict must have a ``"type"`` key (e.g. ``"string"``,
                ``"int"``). Other keys are treated as constraints
                (``"min"``, ``"max"``, ``"precision"``, ``"choices"``,
                etc.).

        Returns:
            Serialized SchemaSpec dictionary.
        """
        try:
            import pycatalyst  # noqa: F401
        except ImportError as exc:
            raise RuntimeError(
                "pycatalyst is required: pip install pycatalyst"
            ) from exc
        schema = _build_schema_spec(fields)
        # Return a config dict compatible with SchemaSpec.from_config
        return _schema_to_jsonable(schema)

    return [generate_data, generate_from_fields, build_schema]


# ======================================================================
# Factory helpers (env-based)
# ======================================================================


def _default_schemas() -> dict[str, Any]:
    """Build a set of demo schemas for common use cases."""
    try:
        from pycatalyst.schema.spec import SchemaBuilder
    except ImportError as exc:
        msg = (
            "pycatalyst required for catalyst tools. "
            "Install with: pip install pygubernator[workflow]"
        )
        raise ImportError(msg) from exc

    users = (
        SchemaBuilder("users", description="Demo user accounts")
        .add_uuid("id")
        .add_string("name", format="name")
        .add_string("email", format="email")
        .add_datetime("created_at")
        .build()
    )
    orders = (
        SchemaBuilder("orders", description="Demo order records")
        .add_uuid("id")
        .add_uuid("user_id")
        .add_float("amount", min_val=1.0, max_val=9999.99, precision=2)
        .add_enum(
            "status",
            ["pending", "confirmed", "shipped", "delivered"],
        )
        .add_datetime("created_at")
        .build()
    )
    products = (
        SchemaBuilder("products", description="Demo product catalog")
        .add_uuid("id")
        .add_string("name", min_len=2, max_len=60)
        .add_float("price", min_val=0.99, max_val=999.99, precision=2)
        .add_enum(
            "category",
            ["electronics", "clothing", "food", "books"],
        )
        .build()
    )

    risk_assessments = (
        SchemaBuilder(
            "risk_assessments",
            description="Demo risk assessment records",
        )
        .add_uuid("id")
        .add_string("applicant_name", format="name")
        .add_int("risk_score", min_val=0, max_val=100)
        .add_float(
            "credit_amount",
            min_val=100.0,
            max_val=50000.0,
            precision=2,
        )
        .add_enum("category", ["personal", "business", "mortgage"])
        .build()
    )

    result = {
        "users": users,
        "orders": orders,
        "products": products,
        "risk_assessments": risk_assessments,
    }
    if set(result.keys()) != set(BUILTIN_CATALYST_SCHEMA_NAMES):
        raise RuntimeError(
            "_default_schemas keys must match BUILTIN_CATALYST_SCHEMA_NAMES"
        )
    return result


def _load_schemas_from_file(path: str) -> dict[str, Any]:
    """Load SchemaSpec objects from a YAML file.

    Args:
        path: Filesystem path to a YAML file containing schemas.

    Returns:
        Mapping of schema name to SchemaSpec objects.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML required to load custom schemas") from exc

    from pycatalyst._types import SchemaSpec

    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    schemas: dict[str, Any] = {}
    for entry in raw.get("schemas", []):
        spec = SchemaSpec.from_config(entry)
        schemas[spec.name] = spec
    return schemas


def create_tools_from_env(
    schemas_env_var: str = _SCHEMAS_ENV,
) -> list[Any]:
    """Create pycatalyst tools with demo or custom schemas.

    Args:
        schemas_env_var: Env var for custom schemas YAML path.

    Returns:
        List of tool objects.
    """
    schemas_path = os.environ.get(schemas_env_var, "").strip()
    if schemas_path:
        logger.info("Loading catalyst schemas from %s", schemas_path)
        schemas = _load_schemas_from_file(schemas_path)
    else:
        logger.info("Using built-in demo catalyst schemas")
        schemas = _default_schemas()

    return create_catalyst_tools(schemas)
