"""SQL database tools for querying and managing relational databases."""

from __future__ import annotations

import logging
import os
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    import sqlalchemy  # noqa: F401
    from sqlalchemy import create_engine, inspect, text

    _HAS_SQLALCHEMY = True
except ImportError:
    _HAS_SQLALCHEMY = False

_READONLY_PREFIXES = frozenset({"select", "with", "show", "describe", "explain"})

_CONN_ENV = "PYGUBERNATOR_SQL_CONNECTION_STRING"
_READONLY_ENV = "PYGUBERNATOR_SQL_READONLY"


def _check_deps() -> None:
    """Raise if SQLAlchemy is not installed."""
    if not _HAS_SQLALCHEMY:
        msg = "SQLAlchemy is not available. Install with: pip install sqlalchemy"
        raise ImportError(msg)


class _SqlClient:
    """Thin wrapper around a SQLAlchemy engine.

    Args:
        connection_string: Database URL accepted by SQLAlchemy.
        readonly: When ``True``, block write operations.
    """

    def __init__(
        self,
        connection_string: str,
        readonly: bool = True,
    ) -> None:
        _check_deps()
        self._engine = create_engine(connection_string)
        self._readonly = readonly

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def query(
        self,
        query_str: str,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a read-only SQL query.

        Args:
            query_str: SQL SELECT statement.
            params: Optional bind parameters.

        Returns:
            Rows as a list of dicts.

        Raises:
            ValueError: If the statement is not a read-only query.
        """
        self._validate_readonly(query_str)
        with self._engine.connect() as conn:
            result = conn.execute(text(query_str), params or {})
            columns = list(result.keys())
            return [dict(zip(columns, row, strict=True)) for row in result]

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def execute(
        self,
        query_str: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a write SQL statement.

        Args:
            query_str: INSERT, UPDATE, or DELETE statement.
            params: Optional bind parameters.

        Returns:
            Dict with ``affected_rows`` count.

        Raises:
            ValueError: If the client is in readonly mode.
        """
        if self._readonly:
            msg = (
                "Write operations are disabled in readonly mode. "
                "Set readonly=False to enable writes."
            )
            raise ValueError(msg)
        with self._engine.connect() as conn:
            result = conn.execute(text(query_str), params or {})
            conn.commit()
            return {"affected_rows": result.rowcount}

    # ------------------------------------------------------------------
    # Schema introspection
    # ------------------------------------------------------------------

    def list_tables(self, schema: str | None = None) -> list[str]:
        """List all tables in the database or a specific schema.

        Args:
            schema: Optional schema name to filter by.

        Returns:
            List of table names.
        """
        insp = inspect(self._engine)
        return insp.get_table_names(schema=schema)

    def describe_table(
        self,
        table_name: str,
        schema: str | None = None,
    ) -> list[dict[str, Any]]:
        """Describe a table's columns, types, and constraints.

        Args:
            table_name: Name of the table to describe.
            schema: Optional schema the table belongs to.

        Returns:
            List of column dicts with name, type, nullable,
            and primary_key fields.
        """
        insp = inspect(self._engine)
        columns = insp.get_columns(table_name, schema=schema)
        pk_constraint = insp.get_pk_constraint(table_name, schema=schema)
        pk_columns = set(pk_constraint.get("constrained_columns", []))
        return [
            {
                "name": col["name"],
                "type": str(col["type"]),
                "nullable": col.get("nullable", True),
                "primary_key": col["name"] in pk_columns,
            }
            for col in columns
        ]

    def list_schemas(self) -> list[str]:
        """List all schemas in the database.

        Returns:
            List of schema names.
        """
        insp = inspect(self._engine)
        return insp.get_schema_names()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_readonly(query_str: str) -> None:
        """Ensure the query starts with a read-only keyword.

        Args:
            query_str: SQL statement to validate.

        Raises:
            ValueError: If the first keyword is not read-only.
        """
        stripped = query_str.strip()
        if not stripped:
            msg = "Empty query string."
            raise ValueError(msg)
        first_keyword = stripped.split()[0].lower()
        if first_keyword not in _READONLY_PREFIXES:
            msg = f"Only read-only queries are allowed. Got keyword: {first_keyword!r}"
            raise ValueError(msg)


# ======================================================================
# Tool creation
# ======================================================================


def create_sql_tools(
    connection_string: str,
    readonly: bool = True,
) -> list[Any]:
    """Create SQL database tools backed by a SQLAlchemy engine.

    Args:
        connection_string: Database URL accepted by SQLAlchemy.
        readonly: When ``True``, block write operations.

    Returns:
        List of tool objects ready for registration.
    """
    client = _SqlClient(connection_string, readonly=readonly)

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="sql_query",
        description=(
            "Execute a read-only SQL query and return rows as a list of dicts."
        ),
    )
    async def sql_query(
        query: str,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a read-only SQL query.

        Args:
            query: SQL SELECT/WITH/SHOW/DESCRIBE/EXPLAIN
                statement.
            params: Optional bind parameters as a dict.

        Returns:
            Rows as a list of dicts.
        """
        return client.query(query, params)

    @tool(
        name="sql_execute",
        description=(
            "Execute a write SQL statement "
            "(INSERT/UPDATE/DELETE). "
            "Only available when readonly=False."
        ),
    )
    async def sql_execute(
        query: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a write SQL statement.

        Args:
            query: INSERT, UPDATE, or DELETE statement.
            params: Optional bind parameters as a dict.

        Returns:
            Dict with affected_rows count.
        """
        return client.execute(query, params)

    @tool(
        name="sql_list_tables",
        description=("List all tables in the database or a specific schema."),
    )
    async def sql_list_tables(
        schema: str | None = None,
    ) -> list[str]:
        """List all tables.

        Args:
            schema: Optional schema name to filter by.

        Returns:
            List of table names.
        """
        return client.list_tables(schema)

    @tool(
        name="sql_describe_table",
        description=("Describe a table's columns, types, and constraints."),
    )
    async def sql_describe_table(
        table_name: str,
        schema: str | None = None,
    ) -> list[dict[str, Any]]:
        """Describe a table's structure.

        Args:
            table_name: Name of the table to describe.
            schema: Optional schema the table belongs to.

        Returns:
            List of column dicts with name, type, nullable,
            and primary_key fields.
        """
        return client.describe_table(table_name, schema)

    @tool(
        name="sql_list_schemas",
        description="List all schemas in the database.",
    )
    async def sql_list_schemas() -> list[str]:
        """List all database schemas.

        Returns:
            List of schema names.
        """
        return client.list_schemas()

    return [
        sql_query,
        sql_execute,
        sql_list_tables,
        sql_describe_table,
        sql_list_schemas,
    ]


# ======================================================================
# Factory (env-based)
# ======================================================================


def create_tools_from_env(
    connection_env_var: str = _CONN_ENV,
    readonly_env_var: str = _READONLY_ENV,
) -> list[Any]:
    """Create SQL tools using a connection string from env.

    Args:
        connection_env_var: Env var storing the database URL.
        readonly_env_var: Env var controlling readonly mode.
            Defaults to ``"1"`` (truthy = readonly).

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the connection string env var is not set.
    """
    connection_string = os.environ.get(connection_env_var, "").strip()
    if not connection_string:
        msg = (
            f"Missing SQL connection string. "
            f"Set {connection_env_var} to a database URL."
        )
        raise ValueError(msg)
    readonly_raw = os.environ.get(readonly_env_var, "1").strip()
    readonly = readonly_raw in {"1", "true", "True", "yes"}
    return create_sql_tools(connection_string, readonly=readonly)
