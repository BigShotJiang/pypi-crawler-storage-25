"""Notion tools for searching, reading, and modifying pages and blocks."""

from __future__ import annotations

import logging
import os
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

_API_KEY_ENV = "PYGUBERNATOR_NOTION_API_KEY"


def _check_deps() -> None:
    """Raise if httpx dependency is missing."""
    if not _HAS_HTTPX:
        msg = "httpx dependency not available. Install with: pip install httpx"
        raise ImportError(msg)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _extract_title(properties: dict[str, Any]) -> str:
    """Extract the title string from Notion page properties.

    Args:
        properties: Raw Notion page properties dict.

    Returns:
        The page title, or empty string if not found.
    """
    for prop in properties.values():
        if prop.get("type") == "title":
            title_parts = prop.get("title", [])
            return "".join(part.get("plain_text", "") for part in title_parts)
    return ""


def _simplify_page(page: dict[str, Any]) -> dict[str, Any]:
    """Simplify a raw Notion page response to useful fields.

    Args:
        page: Raw Notion API page response.

    Returns:
        Dict with id, url, title, and properties.
    """
    properties = page.get("properties", {})
    return {
        "id": page.get("id", ""),
        "url": page.get("url", ""),
        "title": _extract_title(properties),
        "properties": properties,
    }


def _simplify_search_result(
    result: dict[str, Any],
) -> dict[str, Any]:
    """Simplify a single Notion search result.

    Args:
        result: A single result object from the search endpoint.

    Returns:
        Dict with id, title, and object type.
    """
    obj_type = result.get("object", "")
    properties = result.get("properties", {})
    # Databases store title differently.
    if obj_type == "database":
        title_parts = result.get("title", [])
        title = "".join(p.get("plain_text", "") for p in title_parts)
    else:
        title = _extract_title(properties)
    return {
        "id": result.get("id", ""),
        "title": title,
        "object": obj_type,
    }


# ------------------------------------------------------------------
# Client
# ------------------------------------------------------------------


class _NotionClient:
    """Thin async wrapper around the Notion REST API.

    Args:
        api_key: Notion integration token (Bearer token).
    """

    def __init__(self, api_key: str) -> None:
        _check_deps()
        self._client = httpx.AsyncClient(
            base_url="https://api.notion.com/v1",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Notion-Version": "2022-06-28",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    async def search(
        self,
        query: str,
        filter_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search Notion pages and databases by title.

        Args:
            query: Search query string.
            filter_type: Optional filter -- ``"page"`` or
                ``"database"``.

        Returns:
            List of simplified result objects.
        """
        body: dict[str, Any] = {"query": query}
        if filter_type:
            body["filter"] = {
                "value": filter_type,
                "property": "object",
            }
        resp = await self._client.post("/search", json=body)
        resp.raise_for_status()
        results = resp.json().get("results", [])
        return [_simplify_search_result(r) for r in results]

    # ------------------------------------------------------------------
    # Pages
    # ------------------------------------------------------------------

    async def get_page(
        self,
        page_id: str,
    ) -> dict[str, Any]:
        """Get a Notion page's properties and metadata.

        Args:
            page_id: The Notion page ID.

        Returns:
            Simplified page dict with id, url, title, properties.
        """
        resp = await self._client.get(f"/pages/{page_id}")
        resp.raise_for_status()
        return _simplify_page(resp.json())

    async def create_page(
        self,
        parent_id: str,
        title: str,
        content: str | None = None,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new page in a database or as child of a page.

        Args:
            parent_id: Parent database or page ID.
            title: Title for the new page.
            content: Optional plain-text paragraph content.
            properties: Optional extra properties dict.

        Returns:
            Dict with id and url of the created page.
        """
        body = self._build_create_body(
            parent_id,
            title,
            content,
            properties,
        )
        resp = await self._client.post("/pages", json=body)
        resp.raise_for_status()
        data = resp.json()
        return {
            "id": data.get("id", ""),
            "url": data.get("url", ""),
        }

    async def update_page(
        self,
        page_id: str,
        properties: dict[str, Any],
    ) -> dict[str, Any]:
        """Update a Notion page's properties.

        Args:
            page_id: The Notion page ID.
            properties: Properties to update.

        Returns:
            Dict with id of the updated page.
        """
        body: dict[str, Any] = {"properties": properties}
        resp = await self._client.patch(
            f"/pages/{page_id}",
            json=body,
        )
        resp.raise_for_status()
        return {"id": resp.json().get("id", "")}

    # ------------------------------------------------------------------
    # Blocks
    # ------------------------------------------------------------------

    async def get_blocks(
        self,
        block_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get content blocks of a page or block.

        Args:
            block_id: The page or block ID.
            limit: Maximum number of blocks to return.

        Returns:
            List of block objects.
        """
        resp = await self._client.get(
            f"/blocks/{block_id}/children",
            params={"page_size": limit},
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    async def append_blocks(
        self,
        block_id: str,
        children: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Append content blocks to a page or block.

        Args:
            block_id: The page or block ID.
            children: List of block objects to append.

        Returns:
            List of created block objects.
        """
        body: dict[str, Any] = {"children": children}
        resp = await self._client.patch(
            f"/blocks/{block_id}/children",
            json=body,
        )
        resp.raise_for_status()
        return resp.json().get("results", [])

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _build_create_body(
        parent_id: str,
        title: str,
        content: str | None,
        properties: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Build the JSON body for a create-page request.

        Determines whether ``parent_id`` refers to a database
        or a page by checking for hyphens (UUIDv4 format).
        """
        if properties:
            parent = {"database_id": parent_id}
            props = dict(properties)
            props.setdefault(
                "title",
                {
                    "title": [
                        {"text": {"content": title}},
                    ],
                },
            )
        else:
            parent = {"page_id": parent_id}
            props = {
                "title": {
                    "title": [
                        {"text": {"content": title}},
                    ],
                },
            }

        body: dict[str, Any] = {
            "parent": parent,
            "properties": props,
        }

        if content:
            body["children"] = [
                {
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [
                            {"text": {"content": content}},
                        ],
                    },
                },
            ]
        return body


# ======================================================================
# Tool creation
# ======================================================================


def create_notion_tools(api_key: str) -> list[Any]:
    """Create Notion tools backed by an API integration token.

    Args:
        api_key: Notion integration token (Bearer token).

    Returns:
        List of tool objects ready for registration.
    """
    client = _NotionClient(api_key)

    # ------------------------------------------------------------------
    # Tool definitions
    # ------------------------------------------------------------------

    @tool(
        name="notion_search",
        description=(
            "Search Notion pages and databases by title. "
            "filter_type can be 'page' or 'database'."
        ),
    )
    async def notion_search(
        query: str,
        filter_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search Notion pages and databases by title.

        Args:
            query: Search query string.
            filter_type: Optional filter -- 'page' or 'database'.

        Returns:
            List of matching result objects.
        """
        return await client.search(query, filter_type)

    @tool(
        name="notion_get_page",
        description=("Get a Notion page's properties and metadata."),
    )
    async def notion_get_page(
        page_id: str,
    ) -> dict[str, Any]:
        """Get a Notion page's properties and metadata.

        Args:
            page_id: The Notion page ID.

        Returns:
            Dict with id, url, title, and properties.
        """
        return await client.get_page(page_id)

    @tool(
        name="notion_create_page",
        description=("Create a new page in a database or as child of a page."),
    )
    async def notion_create_page(
        parent_id: str,
        title: str,
        content: str | None = None,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new Notion page.

        Args:
            parent_id: Parent database or page ID.
            title: Title for the new page.
            content: Optional plain-text paragraph content.
            properties: Optional extra properties dict.

        Returns:
            Dict with id and url of the created page.
        """
        return await client.create_page(
            parent_id,
            title,
            content,
            properties,
        )

    @tool(
        name="notion_update_page",
        description="Update a Notion page's properties.",
    )
    async def notion_update_page(
        page_id: str,
        properties: dict[str, Any],
    ) -> dict[str, Any]:
        """Update a Notion page's properties.

        Args:
            page_id: The Notion page ID.
            properties: Properties to update.

        Returns:
            Dict with id of the updated page.
        """
        return await client.update_page(page_id, properties)

    @tool(
        name="notion_get_blocks",
        description=("Get the content blocks of a Notion page or block."),
    )
    async def notion_get_blocks(
        block_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get content blocks of a page or block.

        Args:
            block_id: The page or block ID.
            limit: Maximum number of blocks to return.

        Returns:
            List of block objects.
        """
        return await client.get_blocks(block_id, limit)

    @tool(
        name="notion_append_blocks",
        description="Append content blocks to a Notion page.",
    )
    async def notion_append_blocks(
        block_id: str,
        children: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Append content blocks to a page.

        Args:
            block_id: The page or block ID.
            children: List of block objects to append.

        Returns:
            List of created block objects.
        """
        return await client.append_blocks(block_id, children)

    return [
        notion_search,
        notion_get_page,
        notion_create_page,
        notion_update_page,
        notion_get_blocks,
        notion_append_blocks,
    ]


# ======================================================================
# Factory (env-based)
# ======================================================================


def create_tools_from_env(
    api_key_env_var: str = _API_KEY_ENV,
) -> list[Any]:
    """Create Notion tools using an API key from the environment.

    Args:
        api_key_env_var: Environment variable name storing the
            Notion integration token.

    Returns:
        A list of tool objects ready for registration.

    Raises:
        ValueError: If the env var is not set.
    """
    api_key = os.environ.get(api_key_env_var, "").strip()
    if not api_key:
        raise ValueError(
            f"Missing Notion API key. Set {api_key_env_var} "
            "to a Notion integration token.",
        )
    return create_notion_tools(api_key)
