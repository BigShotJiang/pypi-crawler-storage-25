"""Tool wrappers and factory for pystator state machine interactions."""

from __future__ import annotations

import logging
import os
from typing import Any

from pygubernator.tools._decorator import tool

logger = logging.getLogger(__name__)

_MACHINES_ENV = "PYGUBERNATOR_STATOR_MACHINES_PATH"


# ======================================================================
# Tool creation
# ======================================================================


def create_stator_tools(
    machines: dict[str, Any],
) -> list[Any]:
    """Create pystator tools with access to registered state machines.

    The factory captures a session registry via closure so that
    tools can create and interact with entity sessions.

    Args:
        machines: Mapping of machine name to StateMachine objects.

    Returns:
        List of tool objects ready for registration.
    """
    # Session registry: entity_id -> EntitySession
    sessions: dict[str, Any] = {}

    @tool(
        name="create_session",
        description=(
            "Create a new pystator entity session for a state machine. "
            "Returns the initial state."
        ),
    )
    async def create_session(
        entity_id: str,
        machine_name: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new entity session.

        Args:
            entity_id: Unique identifier for the entity.
            machine_name: Name of the state machine to use.
            context: Optional initial context dict.

        Returns:
            Dict with entity_id and initial state.
        """
        if machine_name not in machines:
            raise ValueError(
                f"Machine '{machine_name}' not found. "
                f"Available: {list(machines.keys())}"
            )

        machine = machines[machine_name]
        session = machine.create(context=context or {})
        sessions[entity_id] = session
        return {
            "entity_id": entity_id,
            "state": session.current_state,
        }

    @tool(
        name="send_event",
        description=(
            "Send an event/trigger to a pystator entity session. "
            "Returns the transition result."
        ),
    )
    async def send_event(
        entity_id: str,
        trigger: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send an event to an entity session.

        Args:
            entity_id: The entity to send the event to.
            trigger: The event/trigger name.
            payload: Optional payload kwargs for the transition.

        Returns:
            Dict with success, previous_state, and current_state.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        prev_state = session.current_state
        result = session.send(trigger, **(payload or {}))
        return {
            "success": result.success,
            "previous_state": prev_state,
            "current_state": session.current_state,
            "error": result.error if not result.success else None,
        }

    @tool(
        name="get_state",
        description=("Get the current state and context of a pystator entity."),
    )
    async def get_state(entity_id: str) -> dict[str, Any]:
        """Get current state of an entity.

        Args:
            entity_id: The entity to query.

        Returns:
            Dict with state and context.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        return {
            "entity_id": entity_id,
            "state": session.current_state,
            "context": dict(session.context),
        }

    @tool(
        name="list_triggers",
        description=("List available triggers for an entity in its current state."),
    )
    async def list_triggers(entity_id: str) -> dict[str, Any]:
        """List available triggers for the entity's current state.

        Args:
            entity_id: The entity to query.

        Returns:
            Dict with state and available trigger names.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        triggers = session.allowed_triggers
        return {
            "entity_id": entity_id,
            "state": session.current_state,
            "triggers": triggers,
        }

    @tool(
        name="apply_data",
        description=(
            "Apply data to a pystator entity and evaluate when-route "
            "transitions. Routes automatically based on state "
            "when-clauses."
        ),
    )
    async def apply_data(
        entity_id: str,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply data and trigger when-route evaluation.

        Merges *data* into the entity context, then evaluates
        destination ``when`` clauses to route automatically.

        Args:
            entity_id: The entity to apply data to.
            data: Dict of context fields to merge and evaluate.

        Returns:
            Dict with previous/current state and transitions fired.
        """
        if entity_id not in sessions:
            raise ValueError(f"No session found for entity '{entity_id}'")

        session = sessions[entity_id]
        prev_state = session.current_state
        results = session.apply_data(**data)
        return {
            "entity_id": entity_id,
            "previous_state": prev_state,
            "current_state": session.current_state,
            "transitions_fired": len(results),
        }

    return [
        create_session,
        send_event,
        get_state,
        list_triggers,
        apply_data,
    ]


# ======================================================================
# Factory helpers (env-based)
# ======================================================================


def _default_machines() -> dict[str, Any]:
    """Build demo state machines for common use cases."""
    try:
        from pystator import StateMachine
    except ImportError as exc:
        msg = "pystator required for stator tools. Install with: pip install pystator"
        raise ImportError(msg) from exc

    order_lifecycle = StateMachine.from_dict(
        {
            "states": [
                {"name": "pending", "type": "initial"},
                {"name": "confirmed", "type": "stable"},
                {"name": "shipped", "type": "stable"},
                {"name": "delivered", "type": "terminal"},
                {"name": "cancelled", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "confirm",
                    "source": "pending",
                    "dest": "confirmed",
                },
                {
                    "trigger": "ship",
                    "source": "confirmed",
                    "dest": "shipped",
                },
                {
                    "trigger": "deliver",
                    "source": "shipped",
                    "dest": "delivered",
                },
                {
                    "trigger": "cancel",
                    "source": "pending",
                    "dest": "cancelled",
                },
                {
                    "trigger": "cancel",
                    "source": "confirmed",
                    "dest": "cancelled",
                },
            ],
        }
    )

    risk_classifier = StateMachine.from_dict(
        {
            "meta": {
                "machine_name": "risk_classifier",
                "classification": {"auto_route": True},
            },
            "states": [
                {"name": "intake", "type": "initial"},
                {
                    "name": "approved",
                    "type": "terminal",
                    "when": [
                        {
                            "field": "risk_score",
                            "op": "gte",
                            "value": 70,
                        }
                    ],
                },
                {
                    "name": "review_required",
                    "type": "stable",
                    "when": [
                        {
                            "all_of": [
                                {
                                    "field": "risk_score",
                                    "op": "gte",
                                    "value": 40,
                                },
                                {
                                    "field": "risk_score",
                                    "op": "lt",
                                    "value": 70,
                                },
                            ]
                        }
                    ],
                },
                {
                    "name": "rejected",
                    "type": "terminal",
                    "when": [
                        {
                            "field": "risk_score",
                            "op": "lt",
                            "value": 40,
                        }
                    ],
                },
            ],
            "transitions": [
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "approved",
                },
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "review_required",
                },
                {
                    "trigger": "classify",
                    "source": "intake",
                    "dest": "rejected",
                },
            ],
        }
    )

    return {
        "order_lifecycle": order_lifecycle,
        "risk_classifier": risk_classifier,
    }


def _load_machines_from_file(path: str) -> dict[str, Any]:
    """Load StateMachine objects from a YAML file.

    Args:
        path: Filesystem path to a YAML file with machine configs.

    Returns:
        Mapping of machine name to StateMachine objects.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ImportError("PyYAML required to load custom machines") from exc

    from pystator import StateMachine

    with open(path, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    machines: dict[str, Any] = {}
    for name, cfg in raw.get("machines", {}).items():
        machines[name] = StateMachine.from_dict(cfg)
    return machines


def create_tools_from_env(
    machines_env_var: str = _MACHINES_ENV,
) -> list[Any]:
    """Create pystator tools with demo or custom machines.

    Args:
        machines_env_var: Env var for custom machines YAML path.

    Returns:
        List of tool objects.
    """
    machines_path = os.environ.get(machines_env_var, "").strip()
    if machines_path:
        logger.info("Loading stator machines from %s", machines_path)
        machines = _load_machines_from_file(machines_path)
    else:
        logger.info("Using built-in demo stator machines")
        machines = _default_machines()

    return create_stator_tools(machines)
