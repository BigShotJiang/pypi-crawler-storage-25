"""REST API backend for Obsidian vault operations."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False


class ObsidianApiClient:
    """Thin async client for the Obsidian Local REST API plugin.

    Args:
        api_url: Base URL for the REST API (e.g. ``http://localhost:27124``).
        api_key: Optional Bearer token for authentication.
    """

    def __init__(self, api_url: str, api_key: str | None = None) -> None:
        if not _HAS_HTTPX:
            msg = (
                "httpx is required for Obsidian REST API mode. "
                "Install with: pip install httpx"
            )
            raise ImportError(msg)
        self._api_url = api_url
        self._headers: dict[str, str] = {}
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

    async def read_note(self, path: str) -> dict[str, Any]:
        """Read a note via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            resp = await client.get(f"/vault/{path}")
            resp.raise_for_status()
            text = resp.text
        return {"path": path, "content": text, "size": len(text)}

    async def write_note(
        self,
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Write a note via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            resp = await client.put(
                f"/vault/{path}",
                content=content,
            )
            resp.raise_for_status()
        return {"path": path, "size": len(content), "created": True}

    async def append_note(
        self,
        path: str,
        content: str,
    ) -> dict[str, Any]:
        """Append to a note via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            resp = await client.post(
                f"/vault/{path}",
                content=content,
            )
            resp.raise_for_status()
        return {"path": path, "appended_size": len(content)}

    async def search(
        self,
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Search notes via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            resp = await client.post(
                "/search/simple/",
                params={"query": query},
            )
            resp.raise_for_status()
            results: list[dict[str, Any]] = resp.json()
            return results[:limit]

    async def list_notes(
        self,
        folder: str | None = None,
        recursive: bool = True,
    ) -> list[dict[str, Any]]:
        """List notes via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            path = f"/vault/{folder}/" if folder else "/vault/"
            resp = await client.get(
                path,
                params={"recursive": recursive},
            )
            resp.raise_for_status()
            return resp.json()

    async def delete_note(self, path: str) -> dict[str, Any]:
        """Delete a note via the Obsidian REST API."""
        async with httpx.AsyncClient(
            base_url=self._api_url,
            headers=self._headers,
        ) as client:
            resp = await client.delete(f"/vault/{path}")
            resp.raise_for_status()
        return {"path": path, "deleted": True}
