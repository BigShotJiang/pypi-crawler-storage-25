"""Tool registry for managing agent tools.

Beyond simple registration/lookup, the registry integrates with:

- ``PolicyEnforcer`` (``pygubernator.policy``): every call is checked
  before the tool runs.
- ``ToolCallAuditWriter`` (``pygubernator.safety``): every call is
  recorded with parameters, output, and policy decision.
- ``BudgetTracker`` (``pygubernator.safety``): tool calls are counted
  toward per-run caps.

Policy, audit, and budget are all optional; when unset the registry
falls back to plain execute.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any

from pygubernator._types import ToolResult
from pygubernator.errors import ToolError
from pygubernator.policy import CallerContext, Decision, DecisionKind
from pygubernator.safety import ToolCallAuditRecord

if TYPE_CHECKING:
    from pygubernator.policy import PolicyEnforcer
    from pygubernator.safety import BudgetTracker, ToolCallAuditWriter

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry for tools that agents can use.

    Manages tool registration, lookup, and execution. Tools must
    implement the Tool protocol (name, description, parameters_schema,
    execute). When a policy enforcer / audit writer / budget tracker
    is attached, every ``execute`` call flows through them.

    Example:
        >>> registry = ToolRegistry()
        >>> registry.register(my_tool)
        >>> result = await registry.execute("my_tool", {"param": "value"})
    """

    def __init__(
        self,
        *,
        policy_enforcer: PolicyEnforcer | None = None,
        audit_writer: ToolCallAuditWriter | None = None,
        budget_tracker: BudgetTracker | None = None,
        caller_context: CallerContext | None = None,
    ) -> None:
        """Initialize the registry.

        Args:
            policy_enforcer: Enforces policy rules per call.
            audit_writer: Persists tool-call audit records.
            budget_tracker: Tracks per-run tool-call count.
            caller_context: Default context attached to audit records
                and passed to the enforcer when a per-call context is
                not supplied.
        """
        self._tools: dict[str, Any] = {}
        self._policy_enforcer = policy_enforcer
        self._audit_writer = audit_writer
        self._budget_tracker = budget_tracker
        self._caller_context = caller_context or CallerContext()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register(self, tool: Any) -> None:
        """Register a tool.

        Args:
            tool: Tool implementing the Tool protocol.

        Raises:
            ToolError: If a tool with the same name is already registered.
        """
        name = tool.name
        if name in self._tools:
            raise ToolError(
                f"Tool '{name}' is already registered",
                tool_name=name,
            )
        self._tools[name] = tool
        logger.debug("Registered tool: %s", name)

    def unregister(self, name: str) -> None:
        """Unregister a tool by name.

        Args:
            name: Name of the tool to remove.

        Raises:
            ToolError: If the tool is not registered.
        """
        if name not in self._tools:
            raise ToolError(
                f"Tool '{name}' not found",
                tool_name=name,
            )
        del self._tools[name]

    def get(self, name: str) -> Any:
        """Get a tool by name.

        Args:
            name: Tool name.

        Returns:
            The registered tool.

        Raises:
            ToolError: If the tool is not registered.
        """
        if name not in self._tools:
            raise ToolError(
                f"Tool '{name}' not found",
                tool_name=name,
            )
        return self._tools[name]

    def has(self, name: str) -> bool:
        """Check if a tool is registered."""
        return name in self._tools

    # ------------------------------------------------------------------
    # Safety surface
    # ------------------------------------------------------------------

    def set_policy_enforcer(self, enforcer: PolicyEnforcer | None) -> None:
        """Install or clear the policy enforcer."""
        self._policy_enforcer = enforcer

    def set_audit_writer(self, writer: ToolCallAuditWriter | None) -> None:
        """Install or clear the audit writer."""
        self._audit_writer = writer

    def set_budget_tracker(self, tracker: BudgetTracker | None) -> None:
        """Install or clear the budget tracker."""
        self._budget_tracker = tracker

    def set_caller_context(self, context: CallerContext) -> None:
        """Install the default caller context used for policy + audit."""
        self._caller_context = context

    @property
    def caller_context(self) -> CallerContext:
        """Return the default caller context."""
        return self._caller_context

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def execute(
        self,
        name: str,
        params: dict[str, Any],
        *,
        context: CallerContext | None = None,
    ) -> ToolResult:
        """Execute a tool by name.

        Applies, in order:

        1. Policy enforcement (if configured).
        2. Budget increment (if configured).
        3. Tool execution.
        4. Audit write (always, regardless of outcome).

        Args:
            name: Tool name.
            params: Parameters to pass to the tool.
            context: Per-call caller context; falls back to the default.

        Returns:
            Tool result. On deny, a failed ``ToolResult`` with
            ``error`` set to the policy reason.
        """
        effective_context = context or self._caller_context
        tool = self.get(name)
        decision = self._check_policy(name, params, effective_context)
        started = time.monotonic()

        if decision.kind is DecisionKind.DENY:
            reason = decision.reason or "policy denied"
            result = ToolResult(
                tool_name=name, success=False, output=None, error=reason
            )
            self._emit_audit(
                record_for(
                    tool_name=name,
                    params=params,
                    result=result,
                    decision=decision,
                    duration_ms=_ms_since(started),
                    context=effective_context,
                )
            )
            return result

        if decision.kind is DecisionKind.REQUIRE_APPROVAL:
            reason = decision.reason or "approval required"
            result = ToolResult(
                tool_name=name,
                success=False,
                output=None,
                error=f"approval required: {reason}",
            )
            self._emit_audit(
                record_for(
                    tool_name=name,
                    params=params,
                    result=result,
                    decision=decision,
                    duration_ms=_ms_since(started),
                    context=effective_context,
                )
            )
            return result

        self._consume_budget()

        try:
            result = await tool.execute(params)
        except Exception as exc:
            logger.error("Tool '%s' failed: %s", name, exc)
            result = ToolResult(
                tool_name=name,
                success=False,
                output=None,
                error=str(exc),
            )

        self._emit_audit(
            record_for(
                tool_name=name,
                params=params,
                result=result,
                decision=decision,
                duration_ms=_ms_since(started),
                context=effective_context,
            )
        )
        return result

    # ------------------------------------------------------------------
    # Enumeration
    # ------------------------------------------------------------------

    def list_tools(self) -> list[str]:
        """List all registered tool names."""
        return list(self._tools.keys())

    def get_schemas(self) -> list[dict[str, Any]]:
        """Get parameter schemas for all registered tools.

        Returns:
            List of tool schema dicts with name, description,
            and parameters.
        """
        schemas: list[dict[str, Any]] = []
        for tool in self._tools.values():
            schemas.append(
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters_schema,
                }
            )
        return schemas

    def register_all(self, tools: list[Any]) -> None:
        """Register multiple tools at once.

        Args:
            tools: List of tools implementing the Tool protocol.

        Raises:
            ToolError: If any tool's name is already registered.
        """
        for t in tools:
            self.register(t)

    def register_module(self, module: Any) -> int:
        """Register all ``@tool``-decorated functions from a module.

        Scans ``dir(module)`` for ``_DecoratedTool`` instances and
        registers each one.

        Args:
            module: A Python module containing decorated tools.

        Returns:
            Number of tools registered from the module.
        """
        from pygubernator.tools._decorator import _DecoratedTool

        count = 0
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, _DecoratedTool):
                self.register(attr)
                count += 1
        return count

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _check_policy(
        self,
        name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        if self._policy_enforcer is None:
            return Decision.allow(rule_name="no_enforcer")
        try:
            return self._policy_enforcer.check(name, params, context)
        except Exception:
            logger.exception("policy enforcer errored; treating as allow")
            return Decision.allow(rule_name="enforcer_error")

    def _consume_budget(self) -> None:
        if self._budget_tracker is None:
            return
        self._budget_tracker.add_tool_call(1)

    def _emit_audit(self, record: ToolCallAuditRecord) -> None:
        if self._audit_writer is None:
            return
        self._audit_writer.write(record)


def record_for(
    *,
    tool_name: str,
    params: dict[str, Any],
    result: ToolResult,
    decision: Decision,
    duration_ms: int,
    context: CallerContext,
) -> ToolCallAuditRecord:
    """Build a ``ToolCallAuditRecord`` from a completed tool call.

    Exposed as a module-level helper so callers outside the registry
    (e.g. custom tool invokers in workflow nodes) can emit records with
    the same shape.
    """
    output_payload: dict[str, Any]
    if result.success:
        status = "ok"
        output_payload = {"output": result.output}
    elif decision.kind is DecisionKind.DENY:
        status = "denied"
        output_payload = {"error": result.error}
    elif decision.kind is DecisionKind.REQUIRE_APPROVAL:
        status = "pending_approval"
        output_payload = {"error": result.error}
    else:
        status = "error"
        output_payload = {"error": result.error}

    return ToolCallAuditRecord(
        tool_name=tool_name,
        params=dict(params),
        output=output_payload,
        status=status,
        policy_decision=decision.kind.value,
        policy_reason=decision.reason,
        duration_ms=duration_ms,
        agent_id=context.agent_id,
        run_id=context.run_id,
        workflow_id=context.workflow_id,
    )


def _ms_since(start: float) -> int:
    return int((time.monotonic() - start) * 1000)


__all__ = ["ToolRegistry", "record_for"]
