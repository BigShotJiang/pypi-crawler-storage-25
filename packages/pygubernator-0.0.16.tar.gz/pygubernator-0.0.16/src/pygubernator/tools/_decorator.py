"""Decorator for creating tools from functions."""

from __future__ import annotations

import functools
import inspect
import re
import types
import typing
from typing import Any

from pygubernator._types import ToolResult


class _DecoratedTool:
    """Tool created from a decorated async function.

    Attributes:
        name: Tool name.
        description: Tool description.
        parameters_schema: JSON schema for tool parameters.
    """

    def __init__(
        self,
        func: Any,
        name: str,
        description: str,
        parameters_schema: dict[str, Any],
    ) -> None:
        self._func = func
        self._name = name
        self._description = description
        self._parameters_schema = parameters_schema
        functools.update_wrapper(self, func)

    @property
    def name(self) -> str:
        """Tool name."""
        return self._name

    @property
    def description(self) -> str:
        """Tool description."""
        return self._description

    @property
    def parameters_schema(self) -> dict[str, Any]:
        """JSON schema for tool parameters."""
        return self._parameters_schema

    async def execute(self, params: dict[str, Any]) -> ToolResult:
        """Execute the tool with given parameters.

        Args:
            params: Parameters matching the tool's schema.

        Returns:
            Result of the tool execution.
        """
        try:
            if inspect.iscoroutinefunction(self._func):
                output = await self._func(**params)
            else:
                output = self._func(**params)
            return ToolResult(
                tool_name=self._name,
                success=True,
                output=output,
                error=None,
            )
        except Exception as exc:
            return ToolResult(
                tool_name=self._name,
                success=False,
                output=None,
                error=str(exc),
            )


def tool(
    name: str | None = None,
    description: str = "",
    parameters_schema: dict[str, Any] | None = None,
) -> Any:
    """Decorator to create a Tool from a function.

    Args:
        name: Tool name (defaults to function name).
        description: Tool description (defaults to function docstring).
        parameters_schema: JSON schema for parameters.

    Returns:
        Decorated function wrapped as a Tool.

    Example:
        >>> @tool(description="Search the web")
        ... async def web_search(query: str) -> str:
        ...     return f"Results for {query}"
    """

    def decorator(func: Any) -> _DecoratedTool:
        tool_name = name or func.__name__
        tool_desc = description or (func.__doc__ or "").strip()
        schema = parameters_schema or _infer_schema(func)
        return _DecoratedTool(func, tool_name, tool_desc, schema)

    return decorator


def _resolve_json_type(annotation: Any) -> dict[str, Any]:
    """Resolve a Python type annotation to a JSON Schema type descriptor.

    Handles primitives, ``list``, ``list[T]``, ``dict``, ``dict[str, V]``,
    and ``X | None`` (optional unwrapping). Falls back to ``{"type": "string"}``
    for unknown types.
    """
    simple_map: dict[type, str] = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
    }

    # Unwrap Optional / X | None unions.
    origin = typing.get_origin(annotation)
    if origin is types.UnionType or origin is typing.Union:
        args = [a for a in typing.get_args(annotation) if a is not type(None)]
        if len(args) == 1:
            return _resolve_json_type(args[0])

    # Simple primitives.
    if annotation in simple_map:
        return {"type": simple_map[annotation]}

    # list / list[T]
    if annotation is list:
        return {"type": "array"}
    if origin is list:
        inner_args = typing.get_args(annotation)
        if inner_args:
            return {"type": "array", "items": _resolve_json_type(inner_args[0])}
        return {"type": "array"}

    # dict / dict[str, V]
    if annotation is dict:
        return {"type": "object"}
    if origin is dict:
        inner_args = typing.get_args(annotation)
        if len(inner_args) == 2:
            return {
                "type": "object",
                "additionalProperties": _resolve_json_type(inner_args[1]),
            }
        return {"type": "object"}

    return {"type": "string"}


def _parse_arg_descriptions(func: Any) -> dict[str, str]:
    """Extract parameter descriptions from a Google-style docstring.

    Parses the ``Args:`` section and returns a mapping of parameter
    name to its description text.
    """
    doc = inspect.getdoc(func)
    if not doc:
        return {}

    descriptions: dict[str, str] = {}
    in_args = False
    current_param: str | None = None
    current_desc_lines: list[str] = []
    # Match "  param_name: description" or "  param_name (type): description"
    param_re = re.compile(r"^\s{2,}(\w+)(?:\s*\([^)]*\))?\s*:\s*(.*)$")

    for line in doc.splitlines():
        stripped = line.strip()
        if stripped == "Args:":
            in_args = True
            continue
        if in_args:
            # End of Args section on next top-level section header.
            if stripped and not stripped.startswith(" ") and stripped.endswith(":"):
                # But we need to check the raw line for indentation.
                pass
            if (
                re.match(r"^\S", line)
                and stripped.endswith(":")
                and stripped != "Args:"
            ):
                break

            match = param_re.match(line)
            if match:
                # Save previous param.
                if current_param is not None:
                    descriptions[current_param] = " ".join(current_desc_lines)
                current_param = match.group(1)
                first_line = match.group(2).strip()
                current_desc_lines = [first_line] if first_line else []
            elif current_param is not None and stripped:
                current_desc_lines.append(stripped)

    if current_param is not None:
        descriptions[current_param] = " ".join(current_desc_lines)

    return descriptions


def _infer_schema(func: Any) -> dict[str, Any]:
    """Infer a JSON schema from function signature and docstring."""
    sig = inspect.signature(func)
    properties: dict[str, Any] = {}
    required: list[str] = []

    try:
        hints = typing.get_type_hints(func)
    except (NameError, AttributeError):
        hints = {}

    for param_name, param in sig.parameters.items():
        annotation = hints.get(param_name, param.annotation)
        if annotation is inspect.Parameter.empty:
            properties[param_name] = {"type": "string"}
        else:
            properties[param_name] = _resolve_json_type(annotation)
        if param.default is inspect.Parameter.empty:
            required.append(param_name)

    descriptions = _parse_arg_descriptions(func)
    for param_name, prop in properties.items():
        if param_name in descriptions:
            prop["description"] = descriptions[param_name]

    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }
