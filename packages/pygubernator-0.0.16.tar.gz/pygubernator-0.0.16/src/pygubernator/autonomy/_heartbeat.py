"""Heartbeats: agents announce they are alive.

Writes to ``agent_heartbeats`` via a SQLAlchemy session factory when
available, otherwise to a generic ``RecordStore`` under kind
``agent_heartbeat``. A stale-agent detector compares the most recent
heartbeat per agent against a configurable threshold.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

from pygubernator.records import Record, RecordStore, default_record_store

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

HEARTBEAT_KIND = "agent_heartbeat"


@dataclass(frozen=True, slots=True)
class HeartbeatRecord:
    """Metadata for a single heartbeat.

    Args:
        agent_id: Agent emitting the beat.
        run_id: Current run identifier, if any.
        workflow_id: Containing workflow identifier, if any.
        status: ``live``, ``idle``, ``stuck``, or operator-defined.
        details: Extra structured data (iteration, queue depth, etc.).
        created_at: UTC timestamp.
    """

    agent_id: str
    run_id: str | None = None
    workflow_id: str | None = None
    status: str = "live"
    details: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class HeartbeatWriter:
    """Persists heartbeats.

    Uses the ``agent_heartbeats`` SQL table when a session factory is
    provided; otherwise writes to a ``RecordStore`` under kind
    ``agent_heartbeat``.
    """

    def __init__(
        self,
        *,
        session_factory: Callable[[], Session] | None = None,
        record_store: RecordStore | None = None,
    ) -> None:
        """Initialize.

        Args:
            session_factory: Optional SQLAlchemy session factory.
            record_store: RecordStore fallback. Defaults to the
                process-wide store.
        """
        self._session_factory = session_factory
        self._record_store = record_store or default_record_store()

    def write(self, record: HeartbeatRecord) -> None:
        """Best-effort persist. Logs on failure, never raises."""
        try:
            if self._session_factory is not None:
                self._write_sql(record)
            else:
                self._write_record_store(record)
        except Exception as exc:
            logger.warning(
                "heartbeat write failed: agent=%s err=%s", record.agent_id, exc
            )

    def latest_for(self, agent_id: str) -> HeartbeatRecord | None:
        """Return the most recent heartbeat for ``agent_id``.

        Queries the SQL table when a session factory is configured,
        otherwise the RecordStore.
        """
        if self._session_factory is not None:
            return self._latest_sql(agent_id)
        return self._latest_record_store(agent_id)

    def _write_sql(self, record: HeartbeatRecord) -> None:
        from pygubernator.db.models.agent_heartbeat import AgentHeartbeat

        if self._session_factory is None:
            return
        session = self._session_factory()
        try:
            row = AgentHeartbeat(
                agent_id=record.agent_id,
                run_id=record.run_id,
                workflow_id=record.workflow_id,
                status=record.status,
                details=record.details,
                created_at=record.created_at,
            )
            session.add(row)
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _write_record_store(self, record: HeartbeatRecord) -> None:
        self._record_store.put(
            Record(
                kind=HEARTBEAT_KIND,
                scope=record.agent_id,
                payload={
                    "status": record.status,
                    "run_id": record.run_id,
                    "workflow_id": record.workflow_id,
                    "details": record.details,
                },
                created_at=record.created_at,
            )
        )

    def _latest_sql(self, agent_id: str) -> HeartbeatRecord | None:
        from pygubernator.db.models.agent_heartbeat import AgentHeartbeat

        if self._session_factory is None:
            return None
        session = self._session_factory()
        try:
            row = (
                session.query(AgentHeartbeat)
                .filter(AgentHeartbeat.agent_id == agent_id)
                .order_by(AgentHeartbeat.created_at.desc())
                .first()
            )
            if row is None:
                return None
            return HeartbeatRecord(
                agent_id=row.agent_id,
                run_id=row.run_id,
                workflow_id=row.workflow_id,
                status=row.status,
                details=dict(row.details or {}),
                created_at=row.created_at,
            )
        finally:
            session.close()

    def _latest_record_store(self, agent_id: str) -> HeartbeatRecord | None:
        rows = self._record_store.query(HEARTBEAT_KIND, scope=agent_id, limit=1)
        if not rows:
            return None
        row = rows[0]
        return HeartbeatRecord(
            agent_id=agent_id,
            run_id=row.payload.get("run_id"),
            workflow_id=row.payload.get("workflow_id"),
            status=row.payload.get("status", "live"),
            details=dict(row.payload.get("details") or {}),
            created_at=row.created_at,
        )


class HeartbeatEmitter:
    """Periodic heartbeat beacon for a single agent.

    Construct, ``start()`` to begin a background thread, ``beat()`` to
    force an immediate emission, ``stop()`` on teardown. Safe to call
    ``stop`` multiple times.
    """

    def __init__(
        self,
        *,
        agent_id: str,
        writer: HeartbeatWriter,
        interval_s: float = 30.0,
        run_id: str | None = None,
        workflow_id: str | None = None,
        status_provider: Callable[[], tuple[str, dict[str, Any]]] | None = None,
    ) -> None:
        """Initialize.

        Args:
            agent_id: Agent identifier on each beat.
            writer: Heartbeat persistence.
            interval_s: Seconds between automatic beats.
            run_id: Current run id, included in each beat.
            workflow_id: Workflow id, included in each beat.
            status_provider: Optional callable returning ``(status, details)``
                for each beat. Defaults to ``("live", {})``.
        """
        self._agent_id = agent_id
        self._writer = writer
        self._interval_s = max(1.0, float(interval_s))
        self._run_id = run_id
        self._workflow_id = workflow_id
        self._status_provider = status_provider or (lambda: ("live", {}))
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def beat(self) -> None:
        """Emit a single heartbeat immediately."""
        status, details = self._status_provider()
        self._writer.write(
            HeartbeatRecord(
                agent_id=self._agent_id,
                run_id=self._run_id,
                workflow_id=self._workflow_id,
                status=status,
                details=details,
            )
        )

    def start(self) -> None:
        """Start the background beat loop.

        Does nothing if already running.
        """
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run, name=f"heartbeat-{self._agent_id}", daemon=True
        )
        self._thread.start()

    def stop(self, timeout_s: float = 5.0) -> None:
        """Signal the loop to exit and wait up to ``timeout_s`` seconds."""
        self._stop_event.set()
        thread = self._thread
        if thread is not None:
            thread.join(timeout=timeout_s)
            self._thread = None

    def _run(self) -> None:
        # Fire once immediately so staleness detectors see a beat
        # quickly after startup.
        try:
            self.beat()
        except Exception:
            logger.exception("initial heartbeat failed for %s", self._agent_id)
        while not self._stop_event.wait(self._interval_s):
            try:
                self.beat()
            except Exception:
                logger.exception("heartbeat loop error for %s", self._agent_id)


class StaleAgentDetector:
    """Flags agents whose last heartbeat is older than a threshold."""

    def __init__(
        self,
        writer: HeartbeatWriter,
        *,
        threshold_s: float = 120.0,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        """Initialize.

        Args:
            writer: Heartbeat writer used to read latest beats.
            threshold_s: Seconds an agent may be silent before being
                considered stale.
            clock: Injected time source for testing.
        """
        self._writer = writer
        self._threshold = timedelta(seconds=threshold_s)
        self._clock = clock or (lambda: datetime.now(UTC))

    def is_stale(self, agent_id: str) -> bool:
        """True if the agent has no recent heartbeat."""
        last = self._writer.latest_for(agent_id)
        if last is None:
            return True
        return (self._clock() - last.created_at) > self._threshold

    def classify(self, agent_ids: list[str]) -> dict[str, bool]:
        """Bulk staleness check."""
        return {agent_id: self.is_stale(agent_id) for agent_id in agent_ids}


# Ensure pytest doesn't collect ``time`` as a fixture.
_ = time
