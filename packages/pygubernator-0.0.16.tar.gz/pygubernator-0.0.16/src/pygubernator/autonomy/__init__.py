"""Long-running autonomy: heartbeats, monitoring, daemon helpers.

Exposes:

- ``HeartbeatEmitter``: periodic or on-demand liveness beacons.
- ``HeartbeatWriter``: persists heartbeats (SQL or RecordStore).
- ``StaleAgentDetector``: finds agents whose last beat is older than
  a threshold.
- ``WatchLoop``: drive-helper for ``watch_and_act`` node.

See ``pygubernator.workflow.nodes._watch`` and ``_inbox`` for the
workflow-level integrations.
"""

from __future__ import annotations

from pygubernator.autonomy._heartbeat import (
    HEARTBEAT_KIND,
    HeartbeatEmitter,
    HeartbeatRecord,
    HeartbeatWriter,
    StaleAgentDetector,
)

__all__ = [
    "HEARTBEAT_KIND",
    "HeartbeatEmitter",
    "HeartbeatRecord",
    "HeartbeatWriter",
    "StaleAgentDetector",
]
