"""HTTP client for PyGubernator control plane API."""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

__all__ = ["ControlPlaneClient"]


class ControlPlaneClient:
    """HTTP client for interacting with the PyGubernator control plane API.

    Args:
        api_url: Base URL of the control plane API (e.g., "http://localhost:8010").
        token: Optional API token for authentication. If None, uses X-API-Token header.
        actor: Optional actor identifier for audit logs.
        role: Optional role for authorization (defaults to "admin").
    """

    def __init__(
        self,
        api_url: str,
        token: str | None = None,
        actor: str | None = None,
        role: str = "admin",
    ) -> None:
        self._api_url = api_url.rstrip("/")
        self._token = token
        self._actor = actor or "client"
        self._role = role
        self._client = httpx.AsyncClient(timeout=30.0)

    def _headers(self) -> dict[str, str]:
        """Build request headers with authentication."""
        headers: dict[str, str] = {}
        if self._token:
            headers["X-API-Token"] = self._token
        headers["X-Actor"] = self._actor
        headers["X-Role"] = self._role
        return headers

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> ControlPlaneClient:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()

    # Agent operations

    async def create_agent(
        self, name: str, owner: str = "system", status: str = "active"
    ) -> dict[str, Any]:
        """Create a new agent.

        Args:
            name: Agent name (must be unique).
            owner: Agent owner.
            status: Agent status.

        Returns:
            Created agent record.
        """
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents",
            headers=self._headers(),
            json={"name": name, "owner": owner, "status": status},
        )
        resp.raise_for_status()
        return resp.json()

    async def get_agent(self, agent_id: str) -> dict[str, Any]:
        """Get an agent by ID.

        Args:
            agent_id: Agent identifier.

        Returns:
            Agent record.
        """
        resp = await self._client.get(
            f"{self._api_url}/api/v1/agents/{agent_id}",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def get_agent_dashboard(self, agent_id: str) -> dict[str, Any]:
        """Get agent plus all versions in one request.

        Returns:
            ``{"agent": {...}, "versions": [...]}``.
        """
        resp = await self._client.get(
            f"{self._api_url}/api/v1/agents/{agent_id}/dashboard",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def list_agents(
        self, page: int = 1, page_size: int = 25, q: str | None = None
    ) -> dict[str, Any]:
        """List agents.

        Args:
            page: Page number.
            page_size: Page size.
            q: Optional search query.

        Returns:
            Paginated list of agents.
        """
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if q:
            params["q"] = q
        resp = await self._client.get(
            f"{self._api_url}/api/v1/agents",
            headers=self._headers(),
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    # Agent version operations

    async def create_agent_version(
        self,
        agent_id: str,
        version: str,
        model: str | None = None,
        prompt: str | None = None,
        tools: dict[str, Any] | None = None,
        config: dict[str, Any] | None = None,
        spec_path: str | None = None,
        spec_json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new agent version.

        Args:
            agent_id: Agent identifier.
            version: Version string.
            model: Optional LLM model identifier.
            prompt: Optional system prompt.
            tools: Optional tools configuration dict.
            config: Optional agent configuration dict.

        Returns:
            Created agent version record.
        """
        payload: dict[str, Any] = {"version": version}
        if model is not None:
            payload["model"] = model
        if prompt is not None:
            payload["prompt"] = prompt
        if tools is not None:
            payload["tools"] = tools
        if config is not None:
            payload["config"] = config
        if spec_path is not None:
            payload["spec_path"] = spec_path
        if spec_json is not None:
            payload["spec_json"] = spec_json
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents/{agent_id}/versions",
            headers=self._headers(),
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()

    async def list_agent_specs(self, q: str | None = None) -> dict[str, Any]:
        """List discoverable file-based agent specs."""
        params: dict[str, Any] = {}
        if q:
            params["q"] = q
        resp = await self._client.get(
            f"{self._api_url}/api/v1/agents/specs",
            headers=self._headers(),
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    async def get_agent_spec_detail(self, path: str) -> dict[str, Any]:
        """Fetch canonical spec payload by file path."""
        resp = await self._client.get(
            f"{self._api_url}/api/v1/agents/specs/detail",
            headers=self._headers(),
            params={"path": path},
        )
        resp.raise_for_status()
        return resp.json()

    async def validate_agent_spec(
        self, spec_json: dict[str, Any], source_path: str | None = None
    ) -> dict[str, Any]:
        """Validate/compile raw agent spec JSON."""
        payload: dict[str, Any] = {"spec_json": spec_json}
        if source_path is not None:
            payload["source_path"] = source_path
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents/specs/validate",
            headers=self._headers(),
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()

    async def publish_agent_spec(
        self,
        agent_id: str,
        *,
        version: str,
        spec_path: str,
        activate: bool = False,
    ) -> dict[str, Any]:
        """Publish file spec into an agent version snapshot."""
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents/{agent_id}/specs/publish",
            headers=self._headers(),
            json={
                "version": version,
                "spec_path": spec_path,
                "activate": activate,
            },
        )
        resp.raise_for_status()
        return resp.json()

    async def activate_version(self, agent_id: str, version_id: str) -> dict[str, Any]:
        """Activate an agent version.

        Args:
            agent_id: Agent identifier.
            version_id: Version identifier.

        Returns:
            Updated agent record.
        """
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents/{agent_id}/versions/{version_id}/activate",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()

    # Run operations

    async def create_run(
        self,
        agent_id: str,
        agent_version_id: str | None = None,
        correlation_id: str | None = None,
        trigger: str | None = None,
        metadata_json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new run (uses ``POST /api/v1/runs``).

        Prefer :meth:`enqueue_run` when the agent is already known — it avoids
        repeating ``agent_id`` in the JSON body.
        """
        payload: dict[str, Any] = {"agent_id": agent_id}
        if agent_version_id is not None:
            payload["agent_version_id"] = agent_version_id
        if correlation_id is not None:
            payload["correlation_id"] = correlation_id
        if trigger is not None:
            payload["trigger"] = trigger
        if metadata_json is not None:
            payload["metadata_json"] = metadata_json
        resp = await self._client.post(
            f"{self._api_url}/api/v1/runs",
            headers=self._headers(),
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()

    async def enqueue_run(
        self,
        agent_id: str,
        agent_version_id: str | None = None,
        correlation_id: str | None = None,
        trigger: str | None = None,
        metadata_json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Enqueue a run for an agent (``POST /api/v1/agents/{id}/runs``)."""
        payload: dict[str, Any] = {}
        if agent_version_id is not None:
            payload["agent_version_id"] = agent_version_id
        if correlation_id is not None:
            payload["correlation_id"] = correlation_id
        if trigger is not None:
            payload["trigger"] = trigger
        if metadata_json is not None:
            payload["metadata_json"] = metadata_json
        resp = await self._client.post(
            f"{self._api_url}/api/v1/agents/{agent_id}/runs",
            headers=self._headers(),
            json=payload or {},
        )
        resp.raise_for_status()
        return resp.json()

    async def get_run(self, run_id: str) -> dict[str, Any]:
        """Get a run by ID.

        Args:
            run_id: Run identifier.

        Returns:
            Run record.
        """
        resp = await self._client.get(
            f"{self._api_url}/api/v1/runs/{run_id}",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def list_runs(
        self,
        page: int = 1,
        page_size: int = 25,
        agent_id: str | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """List runs.

        Args:
            page: Page number.
            page_size: Page size.
            agent_id: Optional agent ID filter.
            status: Optional status filter.

        Returns:
            Paginated list of runs.
        """
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if agent_id:
            params["agent_id"] = agent_id
        if status:
            params["status"] = status
        resp = await self._client.get(
            f"{self._api_url}/api/v1/runs",
            headers=self._headers(),
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    # Observability operations

    async def post_event(
        self,
        run_id: str,
        event_type: str,
        level: str = "info",
        message: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Post an observability event.

        Args:
            run_id: Run identifier.
            event_type: Event type.
            level: Event level (info, warning, error).
            message: Optional event message.
            payload: Optional event payload.

        Returns:
            Created event record.
        """
        event_payload: dict[str, Any] = {
            "run_id": run_id,
            "event_type": event_type,
            "level": level,
        }
        if message is not None:
            event_payload["message"] = message
        if payload is not None:
            event_payload["payload"] = payload
        resp = await self._client.post(
            f"{self._api_url}/api/v1/observability/events",
            headers=self._headers(),
            json=event_payload,
        )
        resp.raise_for_status()
        return resp.json()
