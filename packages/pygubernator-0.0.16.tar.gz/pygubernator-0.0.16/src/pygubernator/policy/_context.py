"""Caller context passed to the policy enforcer."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class CallerContext:
    """Identity + request metadata for a tool call.

    Args:
        agent_id: Invoking agent (if any).
        workflow_id: Workflow the call belongs to.
        run_id: Current run.
        user_id: End user on whose behalf the call runs.
        tags: Set of tags attached to the calling agent/workflow.
        extra: Arbitrary extra metadata evaluated by custom rules.
    """

    agent_id: str | None = None
    workflow_id: str | None = None
    run_id: str | None = None
    user_id: str | None = None
    tags: frozenset[str] = field(default_factory=frozenset)
    extra: dict[str, Any] = field(default_factory=dict)
