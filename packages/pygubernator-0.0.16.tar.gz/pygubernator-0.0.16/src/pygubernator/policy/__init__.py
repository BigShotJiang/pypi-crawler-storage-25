"""Policy enforcement for tool calls.

Exposes:

- ``Decision``: the outcome of a policy check.
- ``PolicyEnforcer``: evaluates rules against a ``CallerContext``.
- ``PolicyRule`` / ``rule_registry``: pluggable rule evaluators.
- ``PolicyLoader``: hydrates rules from the ``PolicyAssignment`` table
  or an in-memory list.

See ``pygubernator.safety`` for audit, redaction, and budgeting.
"""

from __future__ import annotations

from pygubernator.policy._context import CallerContext
from pygubernator.policy._decision import Decision, DecisionKind
from pygubernator.policy._enforcer import PolicyEnforcer
from pygubernator.policy._loader import InMemoryPolicyLoader, PolicyLoader
from pygubernator.policy._rules import (
    AllowlistRule,
    DenylistRule,
    PolicyRule,
    RateLimitRule,
    TagRule,
    rule_registry,
)

__all__ = [
    "AllowlistRule",
    "CallerContext",
    "Decision",
    "DecisionKind",
    "DenylistRule",
    "InMemoryPolicyLoader",
    "PolicyEnforcer",
    "PolicyLoader",
    "PolicyRule",
    "RateLimitRule",
    "TagRule",
    "rule_registry",
]
