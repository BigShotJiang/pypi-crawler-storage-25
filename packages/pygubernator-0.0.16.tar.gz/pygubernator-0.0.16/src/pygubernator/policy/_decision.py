"""Policy decision value objects."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class DecisionKind(StrEnum):
    """Outcome of a policy evaluation."""

    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


@dataclass(frozen=True, slots=True)
class Decision:
    """Outcome of a policy evaluation.

    Args:
        kind: ``allow`` / ``deny`` / ``require_approval``.
        reason: Human-readable rationale. Required for non-allow kinds.
        rule_name: Which rule produced the decision, if any.
        metadata: Extra context for audit.
    """

    kind: DecisionKind
    reason: str | None = None
    rule_name: str | None = None
    metadata: dict | None = None

    @classmethod
    def allow(
        cls, rule_name: str | None = None, metadata: dict | None = None
    ) -> Decision:
        """Short-circuit helper for an ``allow`` decision."""
        return cls(DecisionKind.ALLOW, rule_name=rule_name, metadata=metadata)

    @classmethod
    def deny(
        cls,
        reason: str,
        rule_name: str | None = None,
        metadata: dict | None = None,
    ) -> Decision:
        """Short-circuit helper for a ``deny`` decision."""
        return cls(
            DecisionKind.DENY,
            reason=reason,
            rule_name=rule_name,
            metadata=metadata,
        )

    @classmethod
    def require_approval(
        cls,
        reason: str,
        rule_name: str | None = None,
        metadata: dict | None = None,
    ) -> Decision:
        """Short-circuit helper for a ``require_approval`` decision."""
        return cls(
            DecisionKind.REQUIRE_APPROVAL,
            reason=reason,
            rule_name=rule_name,
            metadata=metadata,
        )

    @property
    def is_allowed(self) -> bool:
        """True if the call should proceed."""
        return self.kind is DecisionKind.ALLOW
