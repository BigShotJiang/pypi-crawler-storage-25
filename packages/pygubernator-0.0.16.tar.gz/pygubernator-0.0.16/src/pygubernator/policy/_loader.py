"""Load policy rules from a source (in-memory list or DB rows)."""

from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from pygubernator.policy._context import CallerContext
from pygubernator.policy._rules import PolicyRule, rule_registry

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class PolicyAssignmentSpec:
    """In-memory representation of a stored ``PolicyAssignment`` row.

    Args:
        policy_type: Rule family (``allowlist``, ``denylist``, …).
        policy_value: Config dict for the rule builder.
        scope: ``agent`` / ``workflow`` / ``global``.
        agent_id: Bound agent id (when scope is ``agent``).
        workflow_id: Bound workflow id (when scope is ``workflow``).
        priority: Higher values evaluated first.
        enabled: Whether this policy is active.
    """

    policy_type: str
    policy_value: dict[str, Any] = field(default_factory=dict)
    scope: str = "agent"
    agent_id: str | None = None
    workflow_id: str | None = None
    priority: int = 0
    enabled: bool = True

    def matches(self, context: CallerContext) -> bool:
        """True if this policy applies to the given caller."""
        if not self.enabled:
            return False
        if self.scope == "global":
            return True
        if self.scope == "workflow":
            return (
                self.workflow_id is not None and self.workflow_id == context.workflow_id
            )
        if self.scope == "agent":
            return self.agent_id is not None and self.agent_id == context.agent_id
        return False


@runtime_checkable
class PolicyLoader(Protocol):
    """Source of ``PolicyAssignmentSpec`` rows."""

    def load(self, context: CallerContext) -> list[PolicyRule]:
        """Return rules applicable to ``context``.

        Rules are returned ordered by descending priority.
        """
        ...


class InMemoryPolicyLoader:
    """Loader backed by a fixed list of specs.

    Useful for tests and for simple configurations. Production should
    use ``SqlAlchemyPolicyLoader``.
    """

    def __init__(self, specs: Iterable[PolicyAssignmentSpec]) -> None:
        """Initialize with an iterable of specs."""
        self._specs = list(specs)

    def add(self, spec: PolicyAssignmentSpec) -> None:
        """Append a spec to the loader."""
        self._specs.append(spec)

    def load(self, context: CallerContext) -> list[PolicyRule]:
        """Return rules applicable to the context, priority-descending."""
        return _specs_to_rules(
            (s for s in self._specs if s.matches(context)),
        )


class SqlAlchemyPolicyLoader:
    """Loader backed by the ``PolicyAssignment`` table.

    Queries the DB each time ``load`` is called. For high-QPS
    deployments, wrap with a cache.
    """

    def __init__(self, session_factory: Any) -> None:
        """Initialize.

        Args:
            session_factory: Callable returning a fresh SQLAlchemy session.
        """
        self._session_factory = session_factory

    def load(self, context: CallerContext) -> list[PolicyRule]:
        """Load rules matching the caller from the DB."""
        from pygubernator.db.models.policy import PolicyAssignment

        session = self._session_factory()
        try:
            q = session.query(PolicyAssignment).filter(
                PolicyAssignment.enabled.is_(True),
            )
            specs = [_row_to_spec(r) for r in q.all()]
        finally:
            session.close()

        matching = (s for s in specs if s.matches(context))
        return _specs_to_rules(matching)


def _row_to_spec(row: Any) -> PolicyAssignmentSpec:
    return PolicyAssignmentSpec(
        policy_type=row.policy_type,
        policy_value=dict(row.policy_value or {}),
        scope=getattr(row, "scope", "agent") or "agent",
        agent_id=getattr(row, "agent_id", None),
        workflow_id=getattr(row, "workflow_id", None),
        priority=int(getattr(row, "priority", 0) or 0),
        enabled=bool(getattr(row, "enabled", True)),
    )


def _specs_to_rules(specs: Iterable[PolicyAssignmentSpec]) -> list[PolicyRule]:
    rules: list[tuple[int, PolicyRule]] = []
    for spec in specs:
        rule = rule_registry.build(spec.policy_type, spec.policy_value)
        if rule is None:
            continue
        rules.append((spec.priority, rule))
    rules.sort(key=lambda item: item[0], reverse=True)
    return [r for _, r in rules]
