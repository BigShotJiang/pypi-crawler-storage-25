"""Pluggable policy rules.

Rules are plain callables wrapped in small classes for identification.
Each rule evaluates a (tool_name, params, context) tuple and returns a
``Decision``. A ``rule_registry`` maps ``policy_type`` values from the
``PolicyAssignment`` table to rule constructors.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from pygubernator.policy._context import CallerContext
from pygubernator.policy._decision import Decision

logger = logging.getLogger(__name__)


@runtime_checkable
class PolicyRule(Protocol):
    """Evaluates a single tool call against one rule."""

    name: str
    priority: int

    def evaluate(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Return a decision for this tool call."""
        ...


@dataclass
class AllowlistRule:
    """Allow only tools appearing in ``tools``.

    If ``tools`` is empty, allows everything (no-op).
    """

    tools: frozenset[str]
    name: str = "allowlist"
    priority: int = 10

    def evaluate(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Return allow/deny based on allowlist membership."""
        del params, context
        if not self.tools:
            return Decision.allow(rule_name=self.name)
        if tool_name in self.tools:
            return Decision.allow(rule_name=self.name)
        return Decision.deny(
            f"tool '{tool_name}' not in allowlist",
            rule_name=self.name,
        )


@dataclass
class DenylistRule:
    """Deny any tool in ``tools``."""

    tools: frozenset[str]
    name: str = "denylist"
    priority: int = 20

    def evaluate(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Return deny if the tool is in the denylist, else allow."""
        del params, context
        if tool_name in self.tools:
            return Decision.deny(
                f"tool '{tool_name}' is denied",
                rule_name=self.name,
            )
        return Decision.allow(rule_name=self.name)


@dataclass
class TagRule:
    """Require the caller to carry at least one of ``required_tags``."""

    required_tags: frozenset[str]
    name: str = "tag"
    priority: int = 30

    def evaluate(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Return allow if tags overlap, else deny."""
        del params
        if not self.required_tags:
            return Decision.allow(rule_name=self.name)
        if context.tags & self.required_tags:
            return Decision.allow(rule_name=self.name)
        return Decision.deny(
            f"tool '{tool_name}' requires one of tags {sorted(self.required_tags)}",
            rule_name=self.name,
        )


@dataclass
class RateLimitRule:
    """Per-tool sliding-window rate limit.

    Evaluates per (agent_id, tool_name). The first call after creation
    is always admitted; subsequent calls are counted against a sliding
    window of width ``window_s``.
    """

    max_calls: int
    window_s: float
    name: str = "rate_limit"
    priority: int = 40
    _history: dict[tuple[str, str], deque[float]] = field(
        default_factory=lambda: defaultdict(deque), repr=False
    )
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def evaluate(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Admit if under the per-window cap, else deny."""
        del params
        key = (context.agent_id or "__global__", tool_name)
        now = time.monotonic()
        cutoff = now - self.window_s
        with self._lock:
            window = self._history[key]
            while window and window[0] < cutoff:
                window.popleft()
            if len(window) >= self.max_calls:
                return Decision.deny(
                    f"rate limit: {self.max_calls} calls per "
                    f"{self.window_s}s for '{tool_name}'",
                    rule_name=self.name,
                )
            window.append(now)
        return Decision.allow(rule_name=self.name)


RuleBuilder = Callable[[dict[str, Any]], PolicyRule]


class _RuleRegistry:
    """Maps ``policy_type`` names to rule constructors."""

    def __init__(self) -> None:
        self._builders: dict[str, RuleBuilder] = {}

    def register(self, policy_type: str, builder: RuleBuilder) -> None:
        """Register a builder for ``policy_type``.

        Args:
            policy_type: Key matching ``PolicyAssignment.policy_type``.
            builder: Callable that constructs a ``PolicyRule`` from the
                assignment's ``policy_value`` dict.
        """
        if policy_type in self._builders:
            logger.debug("overwriting policy builder for %s", policy_type)
        self._builders[policy_type] = builder

    def build(self, policy_type: str, value: dict[str, Any]) -> PolicyRule | None:
        """Construct a rule from a stored assignment.

        Returns ``None`` if ``policy_type`` is unknown.
        """
        builder = self._builders.get(policy_type)
        if builder is None:
            logger.warning("unknown policy_type: %s", policy_type)
            return None
        return builder(value)

    def known_types(self) -> list[str]:
        """List all registered policy_type keys."""
        return sorted(self._builders)


rule_registry = _RuleRegistry()


def _build_allowlist(value: dict[str, Any]) -> PolicyRule:
    return AllowlistRule(tools=frozenset(value.get("tools", [])))


def _build_denylist(value: dict[str, Any]) -> PolicyRule:
    return DenylistRule(tools=frozenset(value.get("tools", [])))


def _build_tag(value: dict[str, Any]) -> PolicyRule:
    return TagRule(required_tags=frozenset(value.get("required_tags", [])))


def _build_rate_limit(value: dict[str, Any]) -> PolicyRule:
    return RateLimitRule(
        max_calls=int(value.get("max_calls", 100)),
        window_s=float(value.get("window_s", 60.0)),
    )


rule_registry.register("allowlist", _build_allowlist)
rule_registry.register("denylist", _build_denylist)
rule_registry.register("tag", _build_tag)
rule_registry.register("rate_limit", _build_rate_limit)
