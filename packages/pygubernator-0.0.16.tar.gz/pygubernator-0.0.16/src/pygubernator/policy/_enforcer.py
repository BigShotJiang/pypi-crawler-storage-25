"""Policy enforcer: evaluates rules and returns a decision."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.policy._context import CallerContext
from pygubernator.policy._decision import Decision
from pygubernator.policy._loader import PolicyLoader
from pygubernator.policy._rules import PolicyRule

logger = logging.getLogger(__name__)


class PolicyEnforcer:
    """Evaluate a tool call against applicable policy rules.

    Default behavior: when no loader is supplied or no rules match,
    the call is allowed. Rules are evaluated in priority order; the
    first non-allow decision short-circuits.

    The enforcer is intentionally stateless apart from the loader,
    so a single instance can be shared across threads / tasks.
    """

    def __init__(
        self,
        loader: PolicyLoader | None = None,
        *,
        default_decision: Decision | None = None,
        extra_rules: list[PolicyRule] | None = None,
    ) -> None:
        """Initialize.

        Args:
            loader: Supplies rules for a given caller context.
            default_decision: Returned when no rule denies.
                Defaults to ``Decision.allow``.
            extra_rules: Rules evaluated after the loader's rules.
                Useful for agent-level allowlist/denylist that lives
                alongside, not in, the DB.
        """
        self._loader = loader
        self._default = default_decision or Decision.allow(rule_name="default")
        self._extra_rules = list(extra_rules or [])

    def with_extra_rules(self, rules: list[PolicyRule]) -> PolicyEnforcer:
        """Return a new enforcer with additional rules appended.

        The original enforcer is left unchanged, so this is safe to
        use when building per-call enforcers on top of a shared one.
        """
        return PolicyEnforcer(
            loader=self._loader,
            default_decision=self._default,
            extra_rules=[*self._extra_rules, *rules],
        )

    def check(
        self,
        tool_name: str,
        params: dict[str, Any],
        context: CallerContext,
    ) -> Decision:
        """Evaluate all rules; return the first non-allow decision.

        Args:
            tool_name: Name of the tool being called.
            params: Parameters the agent wants to pass.
            context: Identity + request metadata.

        Returns:
            A ``Decision``.
        """
        rules: list[PolicyRule] = []
        if self._loader is not None:
            try:
                rules.extend(self._loader.load(context))
            except Exception:
                logger.exception("policy loader failed; defaulting to allow")
        rules.extend(self._extra_rules)

        for rule in rules:
            try:
                decision = rule.evaluate(tool_name, params, context)
            except Exception:
                logger.exception(
                    "policy rule %s errored; treating as allow",
                    getattr(rule, "name", type(rule).__name__),
                )
                continue
            if not decision.is_allowed:
                return decision
        return self._default
