"""PyGubernator -- Composable multi-agent workflow framework.

Quick start::

    from pygubernator import Agent, tool

    @tool(description="Search the web")
    async def search(query: str) -> str: ...

    agent = (
        Agent.builder()
        .model("gpt-4o", api_key="sk-...")
        .tools([search])
        .build()
    )
    response = await agent.run("What is Python?")

Subpackage organization:
    pygubernator.agents         Agents, builder, spec, supervisor
    pygubernator.tools          Tool registry + integrations
    pygubernator.workflow       DAG engine + 30 node types
    pygubernator.llm            LLM provider abstraction
    pygubernator.api            FastAPI routes + services + SSE
    pygubernator.db             Persistence, models, store
    pygubernator.events         Event bus + handlers + change bus
    pygubernator.scheduler      Cron-based workflow triggers
    pygubernator.notifications  Webhook/Slack/email dispatch
    pygubernator.chat           Interactive chat sessions
"""

from __future__ import annotations

import importlib
from typing import Any

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pygubernator")
except Exception:
    __version__ = "0.0.1.dev0"

_LAZY: dict[str, tuple[str, str]] = {
    "AgentEvent": ("pygubernator.events._bus", "AgentEvent"),
    "AgentEventType": ("pygubernator.events._bus", "AgentEventType"),
    "EventBus": ("pygubernator.events._bus", "EventBus"),
    "EventHandler": ("pygubernator.events._bus", "EventHandler"),
    "DatabaseEventHandler": ("pygubernator.events._handlers", "DatabaseEventHandler"),
    "LoggingEventHandler": ("pygubernator.events._handlers", "LoggingEventHandler"),
    "MetricsEventHandler": ("pygubernator.events._handlers", "MetricsEventHandler"),
    "Middleware": ("pygubernator._middleware", "Middleware"),
    "MiddlewareChain": ("pygubernator._middleware", "MiddlewareChain"),
    "LLMProvider": ("pygubernator._protocols", "LLMProvider"),
    "StreamingLLMProvider": ("pygubernator._protocols", "StreamingLLMProvider"),
    "Tool": ("pygubernator._protocols", "Tool"),
    "Transport": ("pygubernator._protocols", "Transport"),
    "AgentPipeline": ("pygubernator.agents._supervisor", "AgentPipeline"),
    "AgentSupervisor": ("pygubernator.agents._supervisor", "AgentSupervisor"),
    "RestartPolicy": ("pygubernator.agents._supervisor", "RestartPolicy"),
    "AgentResult": ("pygubernator._types", "AgentResult"),
    "Message": ("pygubernator._types", "Message"),
    "StepResult": ("pygubernator._types", "StepResult"),
    "ToolResult": ("pygubernator._types", "ToolResult"),
    "BaseAgent": ("pygubernator.agents", "BaseAgent"),
    "LLMAgent": ("pygubernator.agents", "LLMAgent"),
    "PipelineAgent": ("pygubernator.agents", "PipelineAgent"),
    "PipelineStep": ("pygubernator.agents", "PipelineStep"),
    "StateMachineAgent": ("pygubernator.agents", "StateMachineAgent"),
    "AgentSettings": ("pygubernator.config", "AgentSettings"),
    "AgentError": ("pygubernator.errors", "AgentError"),
    "ConfigError": ("pygubernator.errors", "ConfigError"),
    "ErrorCode": ("pygubernator.errors", "ErrorCode"),
    "ExecutionError": ("pygubernator.errors", "ExecutionError"),
    "ExpressionError": ("pygubernator.errors", "ExpressionError"),
    "GubernatorError": ("pygubernator.errors", "GubernatorError"),
    "LLMError": ("pygubernator.errors", "LLMError"),
    "NodeError": ("pygubernator.errors", "NodeError"),
    "PipelineStepError": ("pygubernator.errors", "PipelineStepError"),
    "ToolError": ("pygubernator.errors", "ToolError"),
    "TransportError": ("pygubernator.errors", "TransportError"),
    "WorkflowError": ("pygubernator.errors", "WorkflowError"),
    "ChatMessage": ("pygubernator.llm", "ChatMessage"),
    "ChatRole": ("pygubernator.llm", "ChatRole"),
    "LLMResponse": ("pygubernator.llm", "LLMResponse"),
    "OpenAICompatibleProvider": ("pygubernator.llm", "OpenAICompatibleProvider"),
    "ProviderConfig": ("pygubernator.llm", "ProviderConfig"),
    "ProviderType": ("pygubernator.llm", "ProviderType"),
    "StreamChunk": ("pygubernator.llm", "StreamChunk"),
    "ToolCall": ("pygubernator.llm", "ToolCall"),
    "ToolCallDelta": ("pygubernator.llm", "ToolCallDelta"),
    "create_provider": ("pygubernator.llm", "create_provider"),
    "LoggingMiddleware": ("pygubernator.middleware", "LoggingMiddleware"),
    "RetryMiddleware": ("pygubernator.middleware", "RetryMiddleware"),
    "TimeoutMiddleware": ("pygubernator.middleware", "TimeoutMiddleware"),
    "ValidationMiddleware": ("pygubernator.middleware", "ValidationMiddleware"),
    "run_batch": ("pygubernator.runners", "run_batch"),
    "run_stream": ("pygubernator.runners", "run_stream"),
    "ToolRegistry": ("pygubernator.tools", "ToolRegistry"),
    "tool": ("pygubernator.tools", "tool"),
    "InMemoryTransport": ("pygubernator.transport", "InMemoryTransport"),
    "AgentStoreClient": ("pygubernator.db.store.client", "AgentStoreClient"),
    "SQLAlchemyAgentStore": (
        "pygubernator.db.store.sqlalchemy",
        "SQLAlchemyAgentStore",
    ),
    "InMemoryAgentStore": ("pygubernator.db.store.memory", "InMemoryAgentStore"),
    "Agent": ("pygubernator.agents._builder", "Agent"),
    "AgentResponse": ("pygubernator.agents._builder_types", "AgentResponse"),
}

_OPTIONAL_WORKFLOW: dict[str, tuple[str, str]] = {
    "ExecutionMode": ("pygubernator.workflow", "ExecutionMode"),
    "NodeTypeRegistry": ("pygubernator.workflow", "NodeTypeRegistry"),
    "Workflow": ("pygubernator.workflow", "Workflow"),
    "WorkflowEngine": ("pygubernator.workflow", "WorkflowEngine"),
    "WorkflowLoader": ("pygubernator.workflow", "WorkflowLoader"),
    "WorkflowResult": ("pygubernator.workflow", "WorkflowResult"),
    "WorkflowSpec": ("pygubernator.workflow", "WorkflowSpec"),
    "build_default_registry": ("pygubernator.workflow", "build_default_registry"),
}

__all__ = [
    "__version__",
    *sorted(_LAZY.keys()),
    *_OPTIONAL_WORKFLOW.keys(),
    "ControlPlaneClient",
]


def __getattr__(name: str) -> Any:
    if name == "ControlPlaneClient":
        try:
            from pygubernator.client import ControlPlaneClient

            return ControlPlaneClient
        except ImportError:
            return None  # type: ignore[unreachable]
    if name in _LAZY:
        mod_path, attr = _LAZY[name]
        mod = importlib.import_module(mod_path)
        return getattr(mod, attr)
    if name in _OPTIONAL_WORKFLOW:
        mod_path, attr = _OPTIONAL_WORKFLOW[name]
        try:
            mod = importlib.import_module(mod_path)
            return getattr(mod, attr)
        except ImportError:
            return None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(__all__))
