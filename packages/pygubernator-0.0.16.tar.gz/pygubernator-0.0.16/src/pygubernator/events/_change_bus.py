"""In-memory pub/sub bus for config-change events."""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

ChangeCallback = Callable[["ChangeEvent"], None]


@dataclass(frozen=True, slots=True)
class ChangeEvent:
    """Immutable record of a configuration change.

    Attributes:
        topic: Resource type (e.g. ``"workflow"``).
        action: What happened (e.g. ``"saved"``, ``"deleted"``).
        resource_id: ID of the affected resource.
        revision: Monotonic revision counter for the resource.
        actor: Who made the change.
        timestamp: Unix epoch seconds when the change occurred.
        metadata: Arbitrary extra data about the change.
    """

    topic: str
    action: str
    resource_id: str
    revision: int = 0
    actor: str = "system"
    timestamp: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


class ChangeBus:
    """Thread-safe publish/subscribe bus for configuration changes.

    Subscribers register a callback for a specific topic string.
    The wildcard topic ``"*"`` receives events for every topic.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subs: dict[str, list[ChangeCallback]] = {}

    def subscribe(
        self,
        topic: str,
        callback: ChangeCallback,
    ) -> None:
        """Register *callback* for events on *topic*.

        Args:
            topic: Topic string, or ``"*"`` for all topics.
            callback: Callable invoked with each matching
                :class:`ChangeEvent`.
        """
        with self._lock:
            self._subs.setdefault(topic, []).append(callback)

    def unsubscribe(
        self,
        topic: str,
        callback: ChangeCallback,
    ) -> None:
        """Remove a previously registered callback.

        Args:
            topic: The topic the callback was registered under.
            callback: The callback to remove.
        """
        import contextlib

        with self._lock:
            cbs = self._subs.get(topic, [])
            with contextlib.suppress(ValueError):
                cbs.remove(callback)
            if not cbs:
                self._subs.pop(topic, None)

    def publish(self, event: ChangeEvent) -> None:
        """Broadcast *event* to matching subscribers.

        Callbacks registered for the event's topic **and** the
        wildcard topic ``"*"`` are invoked. Exceptions in
        individual callbacks are logged but do not prevent
        delivery to remaining subscribers.

        Args:
            event: The change event to broadcast.
        """
        with self._lock:
            targets = list(self._subs.get(event.topic, []))
            targets += list(self._subs.get("*", []))

        for cb in targets:
            try:
                cb(event)
            except Exception:
                logger.exception(
                    "ChangeBus callback %s failed for %s/%s",
                    cb,
                    event.topic,
                    event.action,
                )

    @property
    def subscriber_count(self) -> int:
        """Total number of registered callbacks across all topics."""
        with self._lock:
            return sum(len(cbs) for cbs in self._subs.values())
