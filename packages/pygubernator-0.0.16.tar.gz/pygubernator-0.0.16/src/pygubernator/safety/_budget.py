"""Run budget: token, tool-call, cost, and duration caps.

``RunBudget`` is the immutable specification. ``BudgetTracker`` is
the mutable running counter that agent and engine loops consult
before advancing. Exceeding any cap raises ``BudgetExceeded``.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from threading import RLock

from pygubernator.errors import GubernatorError


class BudgetExceeded(GubernatorError):
    """Raised when a run exceeds a configured budget cap."""

    def __init__(self, message: str, kind: str, limit: float, consumed: float) -> None:
        """Initialize.

        Args:
            message: Human-readable description.
            kind: Which limit was breached (``tokens``, ``tool_calls``,
                ``cost_usd``, ``duration_s``).
            limit: Configured cap.
            consumed: Amount consumed when breached.
        """
        super().__init__(
            message,
            context={"kind": kind, "limit": limit, "consumed": consumed},
        )
        self.kind = kind
        self.limit = limit
        self.consumed = consumed


@dataclass(frozen=True, slots=True)
class RunBudget:
    """Immutable budget specification for a run.

    Any field left ``None`` is unbounded.

    Args:
        max_tokens: Combined prompt + completion tokens.
        max_tool_calls: Total tool invocations.
        max_cost_usd: Total estimated cost in USD.
        max_duration_s: Wall-clock cap in seconds.
    """

    max_tokens: int | None = None
    max_tool_calls: int | None = None
    max_cost_usd: float | None = None
    max_duration_s: float | None = None

    @classmethod
    def unlimited(cls) -> RunBudget:
        """Return a budget with no caps (all fields None)."""
        return cls()

    @classmethod
    def from_dict(cls, data: dict | None) -> RunBudget:
        """Build a budget from a YAML/JSON dict.

        Unknown keys are ignored; missing keys stay unbounded.
        """
        if not data:
            return cls.unlimited()
        return cls(
            max_tokens=_as_int(data.get("max_tokens")),
            max_tool_calls=_as_int(data.get("max_tool_calls")),
            max_cost_usd=_as_float(data.get("max_cost_usd")),
            max_duration_s=_as_float(data.get("max_duration_s")),
        )

    def to_dict(self) -> dict:
        """Serialize to a dict (for logging / metadata)."""
        return {
            "max_tokens": self.max_tokens,
            "max_tool_calls": self.max_tool_calls,
            "max_cost_usd": self.max_cost_usd,
            "max_duration_s": self.max_duration_s,
        }


@dataclass
class BudgetTracker:
    """Mutable counter enforcing a ``RunBudget``.

    Thread-safe. Counters are monotonic; ``reset()`` is intentionally
    absent to avoid accidentally resetting mid-run.
    """

    budget: RunBudget = field(default_factory=RunBudget.unlimited)
    tokens: int = 0
    tool_calls: int = 0
    cost_usd: float = 0.0
    started_at: float = field(default_factory=time.monotonic)
    _lock: RLock = field(default_factory=RLock, repr=False)

    def elapsed_s(self) -> float:
        """Return wall-clock seconds since the tracker was created."""
        return time.monotonic() - self.started_at

    def add_tokens(self, n: int) -> None:
        """Add to the token counter and raise if the cap is breached."""
        if n <= 0:
            return
        with self._lock:
            self.tokens += n
            self._check_duration()
            if (
                self.budget.max_tokens is not None
                and self.tokens > self.budget.max_tokens
            ):
                raise BudgetExceeded(
                    "token budget exceeded",
                    kind="tokens",
                    limit=self.budget.max_tokens,
                    consumed=self.tokens,
                )

    def add_tool_call(self, n: int = 1) -> None:
        """Add to the tool-call counter and raise if the cap is breached."""
        if n <= 0:
            return
        with self._lock:
            self.tool_calls += n
            self._check_duration()
            if (
                self.budget.max_tool_calls is not None
                and self.tool_calls > self.budget.max_tool_calls
            ):
                raise BudgetExceeded(
                    "tool call budget exceeded",
                    kind="tool_calls",
                    limit=self.budget.max_tool_calls,
                    consumed=self.tool_calls,
                )

    def add_cost(self, usd: float) -> None:
        """Add to the cost counter and raise if the cap is breached."""
        if usd <= 0:
            return
        with self._lock:
            self.cost_usd += usd
            self._check_duration()
            if (
                self.budget.max_cost_usd is not None
                and self.cost_usd > self.budget.max_cost_usd
            ):
                raise BudgetExceeded(
                    "cost budget exceeded",
                    kind="cost_usd",
                    limit=self.budget.max_cost_usd,
                    consumed=self.cost_usd,
                )

    def check_duration(self) -> None:
        """Raise if the wall-clock cap is breached."""
        with self._lock:
            self._check_duration()

    def snapshot(self) -> dict:
        """Return a dict describing current consumption vs caps."""
        with self._lock:
            return {
                "tokens": self.tokens,
                "tool_calls": self.tool_calls,
                "cost_usd": self.cost_usd,
                "elapsed_s": self.elapsed_s(),
                "budget": self.budget.to_dict(),
            }

    def _check_duration(self) -> None:
        if self.budget.max_duration_s is None:
            return
        elapsed = self.elapsed_s()
        if elapsed > self.budget.max_duration_s:
            raise BudgetExceeded(
                "duration budget exceeded",
                kind="duration_s",
                limit=self.budget.max_duration_s,
                consumed=elapsed,
            )


def _as_int(value: object) -> int | None:
    if value is None:
        return None
    return int(value)  # type: ignore[arg-type]


def _as_float(value: object) -> float | None:
    if value is None:
        return None
    return float(value)  # type: ignore[arg-type]
