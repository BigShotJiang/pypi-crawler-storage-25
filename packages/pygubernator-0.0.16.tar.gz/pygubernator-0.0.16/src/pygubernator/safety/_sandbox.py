"""Subprocess sandbox for running untrusted Python snippets.

The sandbox spawns a fresh ``python`` interpreter with POSIX
``rlimit`` caps on CPU, memory, and file descriptors, a private
working directory, and a wall-clock timeout. Stdin delivers the
source; stdout/stderr are captured. Docker-based isolation lives
in Phase 4 (``_sandbox_docker.py``).
"""

from __future__ import annotations

import json
import logging
import os
import resource
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SandboxResult:
    """Outcome of a sandboxed execution.

    Args:
        success: True if the process exited 0 within the timeout.
        stdout: Captured stdout.
        stderr: Captured stderr.
        returncode: Process exit code (``-1`` on timeout).
        result: Parsed JSON value emitted by the snippet via the
            ``pygubernator_emit`` helper, if any.
        duration_s: Wall-clock seconds consumed.
        timed_out: True if the sandbox killed the process for elapsed time.
    """

    success: bool
    stdout: str
    stderr: str
    returncode: int
    result: object | None = None
    duration_s: float = 0.0
    timed_out: bool = False


class SubprocessSandbox:
    """Run Python source in a locked-down subprocess.

    The snippet is wrapped with a small harness that exposes an
    ``emit(value)`` function; calling it writes a JSON line to an
    out-of-band fd so the driver can recover structured data without
    parsing stdout.

    Available resource caps (POSIX):

    - ``max_cpu_seconds``: ``RLIMIT_CPU``
    - ``max_memory_mb``: ``RLIMIT_AS``
    - ``max_output_bytes``: truncation of stdout/stderr capture
    - ``timeout_s``: wall-clock kill via ``Popen.wait(timeout=...)``
    """

    def __init__(
        self,
        *,
        timeout_s: float = 30.0,
        max_cpu_seconds: int = 20,
        max_memory_mb: int = 512,
        max_output_bytes: int = 1_000_000,
        python_executable: str | None = None,
    ) -> None:
        """Initialize.

        Args:
            timeout_s: Wall-clock cap.
            max_cpu_seconds: CPU time cap (``RLIMIT_CPU``).
            max_memory_mb: Virtual memory cap (``RLIMIT_AS``).
            max_output_bytes: Truncate captured stdout/stderr at this size.
            python_executable: Which Python to invoke. Defaults to the
                running interpreter.
        """
        self.timeout_s = timeout_s
        self.max_cpu_seconds = max_cpu_seconds
        self.max_memory_mb = max_memory_mb
        self.max_output_bytes = max_output_bytes
        self.python_executable = python_executable or sys.executable

    def run(
        self,
        source: str,
        *,
        context: dict | None = None,
        env: dict[str, str] | None = None,
    ) -> SandboxResult:
        """Execute ``source`` in a sandboxed subprocess.

        Args:
            source: Python source to run.
            context: Optional mapping exposed to the snippet as the
                global variable ``ctx``.
            env: Optional environment overrides. By default only
                ``PATH``, ``HOME``, and ``LANG`` are passed through.

        Returns:
            A ``SandboxResult``.
        """
        import time

        workdir = Path(tempfile.mkdtemp(prefix="pyg_sandbox_"))
        try:
            harness = workdir / "_runner.py"
            harness.write_text(_HARNESS)
            user_code = workdir / "user.py"
            user_code.write_text(source)
            ctx_file = workdir / "ctx.json"
            ctx_file.write_text(json.dumps(context or {}))
            emit_file = workdir / "emit.jsonl"
            emit_file.write_text("")

            base_env = {
                "PATH": os.environ.get("PATH", ""),
                "HOME": str(workdir),
                "LANG": os.environ.get("LANG", "C.UTF-8"),
                "PYGUBERNATOR_SANDBOX_CTX": str(ctx_file),
                "PYGUBERNATOR_SANDBOX_EMIT": str(emit_file),
            }
            if env:
                base_env.update(env)

            started = time.monotonic()
            try:
                proc = subprocess.Popen(  # noqa: S603
                    [self.python_executable, "-I", str(harness), str(user_code)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    cwd=workdir,
                    env=base_env,
                    preexec_fn=self._apply_rlimits,
                )
            except FileNotFoundError as exc:
                return SandboxResult(
                    success=False,
                    stdout="",
                    stderr=f"sandbox launch failed: {exc}",
                    returncode=-2,
                )

            timed_out = False
            try:
                stdout_b, stderr_b = proc.communicate(timeout=self.timeout_s)
            except subprocess.TimeoutExpired:
                timed_out = True
                proc.kill()
                stdout_b, stderr_b = proc.communicate()
            duration = time.monotonic() - started

            stdout = _truncate(
                stdout_b.decode("utf-8", errors="replace"), self.max_output_bytes
            )
            stderr = _truncate(
                stderr_b.decode("utf-8", errors="replace"), self.max_output_bytes
            )

            result_value: object | None = None
            try:
                emitted = emit_file.read_text().strip().splitlines()
                if emitted:
                    result_value = json.loads(emitted[-1])
            except (OSError, json.JSONDecodeError):
                result_value = None

            return SandboxResult(
                success=(not timed_out) and proc.returncode == 0,
                stdout=stdout,
                stderr=stderr,
                returncode=-1 if timed_out else (proc.returncode or 0),
                result=result_value,
                duration_s=duration,
                timed_out=timed_out,
            )
        finally:
            shutil.rmtree(workdir, ignore_errors=True)

    def _apply_rlimits(self) -> None:
        """Child-process preexec hook applying POSIX rlimits."""
        try:
            resource.setrlimit(
                resource.RLIMIT_CPU,
                (self.max_cpu_seconds, self.max_cpu_seconds),
            )
            mem_bytes = self.max_memory_mb * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
            # Disable core dumps from the sandboxed child.
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        except Exception:
            # If rlimits can't be applied (e.g. platform quirks), we
            # still fall through to the timeout-based kill. Log and
            # continue rather than breaking the run.
            logger.debug("sandbox rlimit setup failed", exc_info=True)


def _truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n...[truncated]"


_HARNESS = """\
import json
import os
import runpy
import sys


def _load_ctx():
    path = os.environ.get("PYGUBERNATOR_SANDBOX_CTX")
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def _emit(value):
    path = os.environ.get("PYGUBERNATOR_SANDBOX_EMIT")
    if not path:
        return
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(value, default=str))
        fh.write("\\n")


if len(sys.argv) < 2:
    print("sandbox: missing user script path", file=sys.stderr)
    sys.exit(2)

user_script = sys.argv[1]

init_globals = {
    "ctx": _load_ctx(),
    "emit": _emit,
}

try:
    runpy.run_path(user_script, init_globals=init_globals, run_name="__sandbox__")
except SystemExit:
    raise
except BaseException as exc:
    import traceback
    traceback.print_exc()
    sys.exit(1)
"""
