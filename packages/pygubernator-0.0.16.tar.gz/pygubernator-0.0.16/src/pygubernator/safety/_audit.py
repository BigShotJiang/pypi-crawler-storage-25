"""Tool-call audit writer.

Turns a ``ToolCallAuditRecord`` into one of:

- a row in the ``tool_call_audit`` table (if a SQLAlchemy session
  factory is configured), or
- a ``Record`` in the default ``RecordStore`` (fallback).

All payloads are passed through the configured ``SecretRedactor``
before persistence.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from pygubernator.records import Record, RecordStore, default_record_store
from pygubernator.safety._redactor import SecretRedactor, default_redactor

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

AUDIT_KIND = "tool_call_audit"


@dataclass(frozen=True, slots=True)
class ToolCallAuditRecord:
    """A single tool-call audit entry.

    Args:
        tool_name: Tool invoked.
        params: Parameters supplied (pre-redaction).
        output: Output produced (pre-redaction).
        status: One of ``ok``, ``error``, ``denied``.
        policy_decision: ``allow``, ``deny``, ``require_approval``.
        policy_reason: Human-readable reason when denied.
        duration_ms: Execution duration in milliseconds.
        agent_id: Agent issuing the call.
        run_id: Run in which the call occurred.
        workflow_id: Workflow containing the run.
        created_at: UTC timestamp.
    """

    tool_name: str
    params: dict[str, Any]
    output: dict[str, Any]
    status: str
    policy_decision: str
    policy_reason: str | None = None
    duration_ms: int = 0
    agent_id: str | None = None
    run_id: str | None = None
    workflow_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        """Serialize for storage or logging."""
        data = asdict(self)
        data["created_at"] = self.created_at.isoformat()
        return data


class ToolCallAuditWriter:
    """Persists ``ToolCallAuditRecord`` instances.

    Uses the SQLAlchemy ``tool_call_audit`` table when a session
    factory is provided; otherwise falls back to the injected
    ``RecordStore`` (in-memory by default).
    """

    def __init__(
        self,
        *,
        session_factory: Callable[[], Session] | None = None,
        record_store: RecordStore | None = None,
        redactor: SecretRedactor | None = None,
    ) -> None:
        """Initialize.

        Args:
            session_factory: Optional SQLAlchemy session factory.
            record_store: RecordStore fallback. Defaults to the
                process-wide store from ``records.default_record_store``.
            redactor: Redactor applied to params/output.
        """
        self._session_factory = session_factory
        self._record_store = record_store or default_record_store()
        self._redactor = redactor or default_redactor()

    def write(self, record: ToolCallAuditRecord) -> None:
        """Persist an audit record. Never raises.

        Logged-and-swallowed failures: we prefer losing an audit row
        to breaking the tool call.
        """
        try:
            redacted_params = self._redactor.redact(record.params)
            redacted_output = self._redactor.redact(record.output)
            if self._session_factory is not None:
                self._write_sql(record, redacted_params, redacted_output)
            else:
                self._write_record_store(record, redacted_params, redacted_output)
        except Exception as exc:
            logger.warning(
                "tool-call audit write failed: tool=%s err=%s",
                record.tool_name,
                exc,
            )

    def _write_sql(
        self,
        record: ToolCallAuditRecord,
        params: dict[str, Any],
        output: dict[str, Any],
    ) -> None:
        from pygubernator.db.models.tool_call_audit import ToolCallAudit

        if self._session_factory is None:
            return
        session = self._session_factory()
        try:
            row = ToolCallAudit(
                run_id=record.run_id,
                agent_id=record.agent_id,
                workflow_id=record.workflow_id,
                tool_name=record.tool_name,
                params=params,
                output=output,
                status=record.status,
                policy_decision=record.policy_decision,
                policy_reason=record.policy_reason,
                duration_ms=record.duration_ms,
                created_at=record.created_at,
            )
            session.add(row)
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _write_record_store(
        self,
        record: ToolCallAuditRecord,
        params: dict[str, Any],
        output: dict[str, Any],
    ) -> None:
        payload = dict(record.to_dict())
        payload["params"] = params
        payload["output"] = output
        self._record_store.put(
            Record(
                kind=AUDIT_KIND,
                scope=record.agent_id,
                payload=payload,
                created_at=record.created_at,
            )
        )
