"""Secret redaction for audit payloads.

The redactor walks arbitrary JSON-like structures and replaces any
value whose key matches a secret pattern, or whose string form
matches a regex, with a fixed placeholder. Applied to tool-call
parameters and outputs before persistence.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

REDACTED = "***REDACTED***"

_DEFAULT_KEY_PATTERNS = [
    r"(?i).*api[_-]?key.*",
    r"(?i).*secret.*",
    r"(?i).*token.*",
    r"(?i).*password.*",
    r"(?i).*passwd.*",
    r"(?i).*credential.*",
    r"(?i).*private[_-]?key.*",
    r"(?i)authorization",
    r"(?i)cookie",
    r"(?i)set-cookie",
]

_DEFAULT_VALUE_PATTERNS = [
    # OpenAI-style keys
    r"sk-[A-Za-z0-9]{20,}",
    # AWS access keys
    r"AKIA[0-9A-Z]{16}",
    # Bearer tokens
    r"(?i)bearer\s+[A-Za-z0-9._~+/=-]{20,}",
    # GitHub PAT
    r"ghp_[A-Za-z0-9]{30,}",
    r"github_pat_[A-Za-z0-9_]{30,}",
    # Slack tokens
    r"xox[baprs]-[A-Za-z0-9-]{20,}",
    # Generic long hex/b64 secret-looking strings
    r"[A-Fa-f0-9]{40,}",
]


class SecretRedactor:
    """Redacts secret-looking values from structured payloads.

    Strategy:

    1. Any dict key matching ``key_patterns`` has its value replaced
       with ``REDACTED``.
    2. Any string value matching ``value_patterns`` is replaced.
    3. Recursion: descends into lists, tuples, and dicts.

    Redaction is conservative: it prefers false positives over
    leaking a real secret.
    """

    def __init__(
        self,
        key_patterns: Iterable[str] | None = None,
        value_patterns: Iterable[str] | None = None,
        extra_env_keys: Iterable[str] | None = None,
    ) -> None:
        """Initialize the redactor.

        Args:
            key_patterns: Regex strings matched against dict keys.
                Defaults to a common set (``api_key``, ``token``, …).
            value_patterns: Regex strings matched against string values.
                Defaults to a common set (OpenAI keys, AWS keys, …).
            extra_env_keys: Environment variable names whose values
                should be redacted on sight (any matching string value
                becomes ``REDACTED``).
        """
        self._key_regex = [
            re.compile(p) for p in (key_patterns or _DEFAULT_KEY_PATTERNS)
        ]
        self._value_regex = [
            re.compile(p) for p in (value_patterns or _DEFAULT_VALUE_PATTERNS)
        ]
        self._literal_values: set[str] = set()
        if extra_env_keys:
            import os

            for env_key in extra_env_keys:
                val = os.environ.get(env_key)
                if val:
                    self._literal_values.add(val)

    def redact(self, value: Any) -> Any:
        """Return a redacted copy of the given value.

        Args:
            value: Arbitrary JSON-like value.

        Returns:
            Deep copy with matching secrets replaced.
        """
        return self._walk(value)

    def redact_string(self, text: str) -> str:
        """Redact secret substrings inside a string.

        Args:
            text: Input text.

        Returns:
            Text with secret-looking substrings replaced.
        """
        if not isinstance(text, str):
            return text
        redacted = text
        if redacted in self._literal_values:
            return REDACTED
        for pattern in self._value_regex:
            redacted = pattern.sub(REDACTED, redacted)
        return redacted

    def _walk(self, value: Any) -> Any:
        if isinstance(value, dict):
            return {k: self._handle_mapping(k, v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._walk(v) for v in value]
        if isinstance(value, tuple):
            return tuple(self._walk(v) for v in value)
        if isinstance(value, str):
            return self.redact_string(value)
        return value

    def _handle_mapping(self, key: Any, value: Any) -> Any:
        if isinstance(key, str) and any(r.match(key) for r in self._key_regex):
            return REDACTED
        return self._walk(value)


_default = SecretRedactor()


def default_redactor() -> SecretRedactor:
    """Return a process-wide default redactor."""
    return _default
