"""Docker-backed sandbox for untrusted Python snippets.

Uses the ``docker`` SDK when installed. Writes the snippet to a
bind-mounted tmp directory, runs a small harness inside a container
image, enforces memory and CPU limits, and by default disables
network access.

This implementation targets *availability* and *isolation guarantees
stronger than subprocess rlimits*. For maximum isolation, pair with
host-level seccomp / AppArmor profiles.
"""

from __future__ import annotations

import json
import logging
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pygubernator.safety._sandbox import SandboxResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DockerNotAvailable(Exception):
    """Raised when the docker extra is not installed."""

    message: str = "pygubernator[packaging] required for docker sandbox"


class DockerSandbox:
    """Run Python source in a short-lived container.

    Args:
        image: Container image to run (must have ``python`` on PATH).
        timeout_s: Wall-clock cap enforced via container wait timeout.
        max_memory_mb: Hard memory cap (container limit).
        cpus: CPU quota (e.g. ``1.0`` for one core).
        network: Enable container network (default False).
        pull: If True, pull the image before running.
    """

    def __init__(
        self,
        *,
        image: str = "python:3.12-slim",
        timeout_s: float = 30.0,
        max_memory_mb: int = 512,
        cpus: float = 1.0,
        network: bool = False,
        pull: bool = False,
    ) -> None:
        self.image = image
        self.timeout_s = timeout_s
        self.max_memory_mb = max_memory_mb
        self.cpus = cpus
        self.network = network
        self.pull = pull

    def run(
        self,
        source: str,
        *,
        context: dict | None = None,
        env: dict[str, str] | None = None,
    ) -> SandboxResult:
        """Execute ``source`` inside a Docker container."""
        try:
            import docker  # type: ignore[import-not-found]
            from docker.errors import ContainerError, DockerException
        except ImportError as exc:
            return SandboxResult(
                success=False,
                stdout="",
                stderr=f"docker SDK not installed: {exc}",
                returncode=-2,
            )

        workdir = Path(tempfile.mkdtemp(prefix="pyg_docker_"))
        try:
            (workdir / "user.py").write_text(source)
            (workdir / "_runner.py").write_text(_HARNESS)
            (workdir / "ctx.json").write_text(json.dumps(context or {}))
            (workdir / "emit.jsonl").write_text("")

            client = docker.from_env()
            if self.pull:
                try:
                    client.images.pull(self.image)
                except DockerException as exc:
                    return SandboxResult(
                        success=False,
                        stdout="",
                        stderr=f"pull failed: {exc}",
                        returncode=-2,
                    )

            run_env = {
                "PYGUBERNATOR_SANDBOX_CTX": "/sandbox/ctx.json",
                "PYGUBERNATOR_SANDBOX_EMIT": "/sandbox/emit.jsonl",
            }
            if env:
                run_env.update(env)

            started = time.monotonic()
            try:
                stdout = client.containers.run(
                    self.image,
                    command=["python", "-I", "/sandbox/_runner.py", "/sandbox/user.py"],
                    volumes={str(workdir): {"bind": "/sandbox", "mode": "rw"}},
                    working_dir="/sandbox",
                    network_disabled=not self.network,
                    mem_limit=f"{self.max_memory_mb}m",
                    nano_cpus=int(self.cpus * 1e9),
                    stderr=True,
                    stdout=True,
                    remove=True,
                    detach=False,
                    environment=run_env,
                )
                stdout_text = _decode(stdout)
                returncode = 0
                stderr_text = ""
            except ContainerError as exc:
                stdout_text = _decode(exc.stdout)
                stderr_text = _decode(exc.stderr)
                returncode = exc.exit_status
            except DockerException as exc:
                return SandboxResult(
                    success=False,
                    stdout="",
                    stderr=f"docker error: {exc}",
                    returncode=-2,
                )

            duration = time.monotonic() - started
            timed_out = duration >= self.timeout_s

            result_value: Any = None
            try:
                emitted = (workdir / "emit.jsonl").read_text().strip().splitlines()
                if emitted:
                    result_value = json.loads(emitted[-1])
            except (OSError, json.JSONDecodeError):
                result_value = None

            return SandboxResult(
                success=returncode == 0 and not timed_out,
                stdout=stdout_text,
                stderr=stderr_text,
                returncode=-1 if timed_out else returncode,
                result=result_value,
                duration_s=duration,
                timed_out=timed_out,
            )
        finally:
            shutil.rmtree(workdir, ignore_errors=True)


def _decode(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value or "")


_HARNESS = """\
import json
import os
import runpy
import sys


def _load_ctx():
    path = os.environ.get("PYGUBERNATOR_SANDBOX_CTX")
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def _emit(value):
    path = os.environ.get("PYGUBERNATOR_SANDBOX_EMIT")
    if not path:
        return
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(value, default=str))
        fh.write("\\n")


if len(sys.argv) < 2:
    print("sandbox: missing user script path", file=sys.stderr)
    sys.exit(2)

init_globals = {
    "ctx": _load_ctx(),
    "emit": _emit,
}

try:
    runpy.run_path(sys.argv[1], init_globals=init_globals, run_name="__sandbox__")
except SystemExit:
    raise
except BaseException:
    import traceback
    traceback.print_exc()
    sys.exit(1)
"""
