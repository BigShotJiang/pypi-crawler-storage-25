"""Safety rails: audit, redaction, budget, sandbox.

This package contains the infrastructure that turns every tool call
into a policy-checked, audited, budgeted operation:

- ``SecretRedactor``: scrubs secrets from audit payloads.
- ``ToolCallAuditWriter``: persists audit rows (DB or RecordStore).
- ``RunBudget`` + ``BudgetTracker``: token/call/cost/duration caps.
- ``SubprocessSandbox``: isolated Python execution.

The policy enforcer lives in ``pygubernator.policy``.
"""

from __future__ import annotations

from pygubernator.safety._audit import (
    ToolCallAuditRecord,
    ToolCallAuditWriter,
)
from pygubernator.safety._budget import (
    BudgetExceeded,
    BudgetTracker,
    RunBudget,
)
from pygubernator.safety._redactor import SecretRedactor, default_redactor
from pygubernator.safety._sandbox import SandboxResult, SubprocessSandbox

__all__ = [
    "BudgetExceeded",
    "BudgetTracker",
    "RunBudget",
    "SandboxResult",
    "SecretRedactor",
    "SubprocessSandbox",
    "ToolCallAuditRecord",
    "ToolCallAuditWriter",
    "default_redactor",
]
