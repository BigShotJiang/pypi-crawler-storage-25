"""Repository helpers for Agent and AgentVersion entities."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import Agent, AgentVersion

__all__ = [
    "activate_agent_version",
    "create_agent",
    "create_agent_version",
    "deactivate_agent_version",
    "get_agent",
    "get_agent_version",
    "list_agent_versions",
    "list_agents",
    "soft_delete_agent_version",
    "update_agent",
]


def list_agents(
    db: Session,
    *,
    workspace_id: str = "default",
    page: int = 1,
    page_size: int = 25,
) -> tuple[list[Agent], int]:
    """List agents with pagination.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.

    Returns:
        Tuple of (agents, total_count).
    """
    total = (
        db.scalar(
            select(func.count(Agent.id)).where(Agent.workspace_id == workspace_id)
        )
        or 0
    )
    items = db.scalars(
        paginate(
            select(Agent)
            .where(Agent.workspace_id == workspace_id)
            .order_by(Agent.created_at.desc()),
            page,
            page_size,
        )
    ).all()
    return items, total


def get_agent(
    db: Session, agent_id: str, *, workspace_id: str = "default"
) -> Agent | None:
    """Get an agent by ID."""
    return db.scalar(
        select(Agent).where(Agent.id == agent_id, Agent.workspace_id == workspace_id)
    )


def get_agent_version(db: Session, version_id: str) -> AgentVersion | None:
    """Get an agent version by ID."""
    return db.get(AgentVersion, version_id)


def list_agent_versions(
    db: Session,
    agent_id: str,
    *,
    include_deleted: bool = False,
) -> list[AgentVersion]:
    """List versions for an agent, newest first.

    Args:
        db: SQLAlchemy session.
        agent_id: Parent agent id.
        include_deleted: When ``False`` (the default), soft-deleted versions
            (``deleted_at IS NOT NULL``) are filtered out. The UI default is
            a clean list; audit / admin views can pass ``True`` to see them.

    Returns:
        Matching :class:`AgentVersion` rows, newest first.
    """
    stmt = select(AgentVersion).where(AgentVersion.agent_id == agent_id)
    if not include_deleted:
        stmt = stmt.where(AgentVersion.deleted_at.is_(None))
    stmt = stmt.order_by(AgentVersion.created_at.desc())
    return list(db.scalars(stmt).all())


def create_agent(
    db: Session,
    *,
    workspace_id: str = "default",
    name: str,
    owner: str = "system",
    status: str = "active",
) -> Agent:
    """Create a new Agent record.

    Args:
        db: SQLAlchemy session.
        name: Unique agent name.
        owner: Owner identifier.
        status: Initial status.

    Returns:
        The created Agent.
    """
    agent = Agent(name=name, owner=owner, status=status, workspace_id=workspace_id)
    db.add(agent)
    return agent


def update_agent(
    db: Session,
    agent: Agent,
    **kwargs: Any,
) -> Agent:
    """Update fields on an existing Agent.

    Args:
        db: SQLAlchemy session.
        agent: The Agent to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated Agent.
    """
    for key, value in kwargs.items():
        if hasattr(agent, key):
            setattr(agent, key, value)
    return agent


def create_agent_version(
    db: Session,
    *,
    agent_id: str,
    version: str,
    model: str | None = None,
    prompt: str | None = None,
    tools: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
    spec_path: str | None = None,
    spec_fingerprint: str | None = None,
    spec_json: dict[str, Any] | None = None,
    active: bool = False,
) -> AgentVersion:
    """Create a new AgentVersion record.

    Args:
        db: SQLAlchemy session.
        agent_id: Parent agent ID.
        version: Version string.
        model: LLM model name.
        prompt: System prompt.
        tools: Tool configuration.
        config: Additional config.
        active: Whether this version is active.

    Returns:
        The created AgentVersion.
    """
    av = AgentVersion(
        agent_id=agent_id,
        version=version,
        model=model,
        prompt=prompt,
        tools=tools or {},
        config=config or {},
        spec_path=spec_path,
        spec_fingerprint=spec_fingerprint,
        spec_json=spec_json or {},
        active=active,
    )
    db.add(av)
    return av


def activate_agent_version(db: Session, agent: Agent, version_id: str) -> None:
    """Activate a specific agent version, deactivating all others.

    Args:
        db: SQLAlchemy session.
        agent: The agent whose version to activate.
        version_id: The version ID to activate.
    """
    for version in agent.versions:
        version.active = version.id == version_id
    agent.current_version_id = version_id


def deactivate_agent_version(db: Session, agent: Agent, version_id: str) -> bool:
    """Clear the ``active`` flag on a single version.

    When the version is the agent's current active version, the agent's
    ``current_version_id`` is nulled out as well so ``resolve_agent_config``
    surfaces "agent has no active version" instead of silently falling back
    to a deactivated row.

    Args:
        db: SQLAlchemy session.
        agent: Parent agent (mutated in place).
        version_id: Version id to deactivate.

    Returns:
        ``True`` if a matching active row was flipped, ``False`` if the
        version wasn't found on this agent or was already inactive.
    """
    del db  # unused; mutations are on the in-session ORM objects
    changed = False
    for version in agent.versions:
        if version.id == version_id and version.active:
            version.active = False
            changed = True
    if agent.current_version_id == version_id:
        agent.current_version_id = None
        changed = True
    return changed


def soft_delete_agent_version(
    db: Session, agent: Agent, version_id: str
) -> AgentVersion | None:
    """Soft-delete a version by stamping ``deleted_at``.

    Idempotent — calling twice leaves the original ``deleted_at`` untouched.
    Callers must guard against deleting the currently active version; this
    helper only does the write.

    Args:
        db: SQLAlchemy session.
        agent: Parent agent (scopes the lookup).
        version_id: Version id to soft-delete.

    Returns:
        The updated row, or ``None`` if the version wasn't found on this
        agent.
    """
    del db  # unused; mutations are on the in-session ORM objects
    for version in agent.versions:
        if version.id == version_id:
            if version.deleted_at is None:
                version.deleted_at = datetime.now(UTC)
            return version
    return None
