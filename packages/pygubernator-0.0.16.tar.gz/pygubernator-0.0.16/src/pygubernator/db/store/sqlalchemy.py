"""SQLAlchemy-backed :class:`AgentStoreClient` (SQLite / PostgreSQL)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from pygubernator.db import repositories as repos
from pygubernator.db.store.client import AgentStoreClient


class SQLAlchemyAgentStore(AgentStoreClient):
    """Persist control-plane entities via SQLAlchemy sessions."""

    def __init__(
        self,
        session: Session,
        *,
        workspace_id: str = "default",
        owns_session: bool = False,
    ) -> None:
        self._session = session
        self._workspace_id = workspace_id
        self._owns_session = owns_session
        self._connected = True

    @property
    def session(self) -> Session:
        """Underlying ORM session (for advanced routes that need ``session.get()``)."""
        return self._session

    @property
    def workspace_id(self) -> str:
        """Workspace scope for all workspace-aware CRUD operations."""
        return self._workspace_id

    def connect(self) -> None:
        self._connected = True

    def disconnect(self) -> None:
        if self._owns_session:
            self._session.close()
        self._connected = False

    def commit(self) -> None:
        self._session.commit()

    def rollback(self) -> None:
        self._session.rollback()

    def refresh(self, instance: object) -> None:
        self._session.refresh(instance)

    def add(self, instance: object) -> None:
        self._session.add(instance)

    def delete(self, instance: object) -> None:
        self._session.delete(instance)

    # --- agents --------------------------------------------------------------

    def list_agents(
        self, *, page: int = 1, page_size: int = 25
    ) -> tuple[list[Any], int]:
        return repos.list_agents(
            self._session,
            workspace_id=self._workspace_id,
            page=page,
            page_size=page_size,
        )

    def get_agent(self, agent_id: str) -> Any | None:
        return repos.get_agent(self._session, agent_id, workspace_id=self._workspace_id)

    def get_agent_version(self, version_id: str) -> Any | None:
        return repos.get_agent_version(self._session, version_id)

    def list_agent_versions(
        self, agent_id: str, *, include_deleted: bool = False
    ) -> list[Any]:
        return repos.list_agent_versions(
            self._session, agent_id, include_deleted=include_deleted
        )

    def create_agent(
        self,
        *,
        name: str,
        owner: str = "system",
        status: str = "active",
    ) -> Any:
        return repos.create_agent(
            self._session,
            workspace_id=self._workspace_id,
            name=name,
            owner=owner,
            status=status,
        )

    def update_agent(self, agent: Any, **kwargs: Any) -> Any:
        return repos.update_agent(self._session, agent, **kwargs)

    def create_agent_version(
        self,
        *,
        agent_id: str,
        version: str,
        model: str | None = None,
        prompt: str | None = None,
        tools: dict[str, Any] | None = None,
        config: dict[str, Any] | None = None,
        spec_path: str | None = None,
        spec_fingerprint: str | None = None,
        spec_json: dict[str, Any] | None = None,
        active: bool = False,
    ) -> Any:
        return repos.create_agent_version(
            self._session,
            agent_id=agent_id,
            version=version,
            model=model,
            prompt=prompt,
            tools=tools,
            config=config,
            spec_path=spec_path,
            spec_fingerprint=spec_fingerprint,
            spec_json=spec_json,
            active=active,
        )

    def activate_agent_version(self, agent: Any, version_id: str) -> None:
        repos.activate_agent_version(self._session, agent, version_id)

    def deactivate_agent_version(self, agent: Any, version_id: str) -> bool:
        return repos.deactivate_agent_version(self._session, agent, version_id)

    def soft_delete_agent_version(self, agent: Any, version_id: str) -> Any | None:
        return repos.soft_delete_agent_version(self._session, agent, version_id)

    # --- audit ---------------------------------------------------------------

    def create_audit(
        self,
        *,
        actor: str,
        action: str,
        resource_type: str,
        resource_id: str | None,
        details: dict[str, Any],
    ) -> Any:
        return repos.create_audit(
            self._session,
            actor=actor,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details,
        )

    def list_audit_logs(
        self,
        *,
        limit: int = 100,
        resource_id: str | None = None,
        resource_type: str | None = None,
    ) -> list[Any]:
        return repos.list_audit_logs(
            self._session,
            limit=limit,
            resource_id=resource_id,
            resource_type=resource_type,
        )

    # --- incidents -----------------------------------------------------------

    def get_incident(self, incident_id: str) -> Any | None:
        return repos.get_incident(self._session, incident_id)

    def list_incidents(
        self,
        *,
        status: str | None = None,
        severity: str | None = None,
        owner: str | None = None,
        limit: int = 100,
    ) -> list[Any]:
        return repos.list_incidents(
            self._session,
            status=status,
            severity=severity,
            owner=owner,
            limit=limit,
        )

    # --- policies ------------------------------------------------------------

    def list_policies(self, agent_id: str | None = None) -> list[Any]:
        return repos.list_policies(self._session, agent_id)

    # --- runs ----------------------------------------------------------------

    def get_run(self, run_id: str) -> Any | None:
        return repos.get_run(self._session, run_id)

    def create_run(
        self,
        *,
        agent_id: str,
        agent_version_id: str | None = None,
        status: str = "queued",
        correlation_id: str | None = None,
        trigger: str | None = None,
        metadata_json: dict[str, Any] | None = None,
    ) -> Any:
        return repos.create_run(
            self._session,
            agent_id=agent_id,
            agent_version_id=agent_version_id,
            status=status,
            correlation_id=correlation_id,
            trigger=trigger,
            metadata_json=metadata_json,
        )

    def update_run(self, run: Any, **kwargs: Any) -> Any:
        return repos.update_run(self._session, run, **kwargs)

    def list_runs_filtered(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        status: str | None = None,
        agent_id: str | None = None,
        correlation_id: str | None = None,
        has_error: bool | None = None,
        created_from: datetime | None = None,
        created_to: datetime | None = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
    ) -> tuple[list[Any], int]:
        return repos.list_runs_filtered(
            self._session,
            page=page,
            page_size=page_size,
            status=status,
            agent_id=agent_id,
            correlation_id=correlation_id,
            has_error=has_error,
            created_from=created_from,
            created_to=created_to,
            sort_by=sort_by,
            sort_order=sort_order,
        )

    def get_run_status_facets(self) -> list[dict[str, int | str]]:
        return repos.get_run_status_facets(self._session)

    def create_run_event(
        self,
        *,
        run_id: str,
        event_type: str,
        level: str = "info",
        message: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        return repos.create_run_event(
            self._session,
            run_id=run_id,
            event_type=event_type,
            level=level,
            message=message,
            payload=payload,
        )

    def list_run_events(
        self,
        run_id: str,
        *,
        page: int = 1,
        page_size: int = 100,
    ) -> tuple[list[Any], int]:
        return repos.list_run_events(
            self._session, run_id, page=page, page_size=page_size
        )

    def create_tool_call(
        self,
        *,
        run_id: str,
        tool_name: str,
        status: str = "completed",
        latency_ms: int | None = None,
        input_payload: dict[str, Any] | None = None,
        output_payload: dict[str, Any] | None = None,
        error_message: str | None = None,
    ) -> Any:
        return repos.create_tool_call(
            self._session,
            run_id=run_id,
            tool_name=tool_name,
            status=status,
            latency_ms=latency_ms,
            input_payload=input_payload,
            output_payload=output_payload,
            error_message=error_message,
        )

    def list_tool_calls(
        self,
        run_id: str,
        *,
        page: int = 1,
        page_size: int = 100,
    ) -> tuple[list[Any], int]:
        return repos.list_tool_calls(
            self._session, run_id, page=page, page_size=page_size
        )

    # --- tools ---------------------------------------------------------------

    def create_tool(
        self,
        *,
        name: str,
        description: str = "",
        owner: str = "system",
        status: str = "active",
    ) -> Any:
        return repos.create_tool(
            self._session,
            workspace_id=self._workspace_id,
            name=name,
            description=description,
            owner=owner,
            status=status,
        )

    def get_tool(self, tool_id: str) -> Any | None:
        return repos.get_tool(self._session, tool_id, workspace_id=self._workspace_id)

    def list_tools(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        status: str | None = None,
    ) -> tuple[list[Any], int]:
        return repos.list_tools(
            self._session,
            workspace_id=self._workspace_id,
            page=page,
            page_size=page_size,
            status=status,
        )

    def update_tool(self, tool: Any, **kwargs: Any) -> Any:
        return repos.update_tool(self._session, tool, **kwargs)

    def create_tool_version(
        self,
        *,
        tool_id: str,
        version: str,
        spec_json: dict[str, Any] | None = None,
        active: bool = False,
        published: bool = False,
        created_by: str = "system",
    ) -> Any:
        return repos.create_tool_version(
            self._session,
            tool_id=tool_id,
            version=version,
            spec_json=spec_json,
            active=active,
            published=published,
            created_by=created_by,
        )

    def get_tool_version(self, version_id: str) -> Any | None:
        return repos.get_tool_version(self._session, version_id)

    def list_tool_versions(self, tool_id: str) -> list[Any]:
        return repos.list_tool_versions(self._session, tool_id)

    def activate_tool_version(self, tool: Any, version_id: str) -> None:
        repos.activate_tool_version(self._session, tool, version_id)

    # --- workflows -----------------------------------------------------------

    def create_workflow(
        self,
        *,
        name: str,
        description: str = "",
        owner: str = "system",
        status: str = "active",
    ) -> Any:
        return repos.create_workflow(
            self._session,
            workspace_id=self._workspace_id,
            name=name,
            description=description,
            owner=owner,
            status=status,
        )

    def get_workflow(self, workflow_id: str) -> Any | None:
        return repos.get_workflow(
            self._session, workflow_id, workspace_id=self._workspace_id
        )

    def list_workflows(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        status: str | None = None,
    ) -> tuple[list[Any], int]:
        return repos.list_workflows(
            self._session,
            workspace_id=self._workspace_id,
            page=page,
            page_size=page_size,
            status=status,
        )

    def update_workflow(self, workflow: Any, **kwargs: Any) -> Any:
        return repos.update_workflow(self._session, workflow, **kwargs)

    def create_workflow_version(
        self,
        *,
        workflow_id: str,
        version: str,
        spec_json: dict[str, Any] | None = None,
        active: bool = False,
        created_by: str = "system",
    ) -> Any:
        return repos.create_workflow_version(
            self._session,
            workflow_id=workflow_id,
            version=version,
            spec_json=spec_json,
            active=active,
            created_by=created_by,
        )

    def list_workflow_versions(self, workflow_id: str) -> list[Any]:
        return repos.list_workflow_versions(self._session, workflow_id)

    def activate_workflow_version(self, workflow: Any, version_id: str) -> None:
        repos.activate_workflow_version(self._session, workflow, version_id)

    def create_workflow_run(
        self,
        *,
        workflow_id: str,
        workflow_version_id: str | None = None,
        status: str = "pending",
        input_json: dict[str, Any] | None = None,
        created_by: str = "system",
        session_id: str | None = None,
        trigger: str | None = None,
        correlation_id: str | None = None,
    ) -> Any:
        return repos.create_workflow_run(
            self._session,
            workflow_id=workflow_id,
            workflow_version_id=workflow_version_id,
            status=status,
            input_json=input_json,
            created_by=created_by,
            session_id=session_id,
            trigger=trigger,
            correlation_id=correlation_id,
        )

    def get_workflow_run(self, run_id: str) -> Any | None:
        return repos.get_workflow_run(self._session, run_id)

    def list_workflow_runs(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        workflow_id: str | None = None,
        status: str | None = None,
        search: str | None = None,
        created_after: Any | None = None,
        created_before: Any | None = None,
        session_id: str | None = None,
        trigger: str | None = None,
        correlation_id: str | None = None,
    ) -> tuple[list[Any], int]:
        return repos.list_workflow_runs(
            self._session,
            page=page,
            page_size=page_size,
            workflow_id=workflow_id,
            status=status,
            search=search,
            created_after=created_after,
            created_before=created_before,
            session_id=session_id,
            trigger=trigger,
            correlation_id=correlation_id,
        )

    def update_workflow_run(self, run: Any, **kwargs: Any) -> Any:
        return repos.update_workflow_run(self._session, run, **kwargs)

    def delete_workflow_run(self, run_id: str) -> bool:
        return repos.delete_workflow_run(self._session, run_id)

    def list_workflow_sessions(self, workflow_id: str) -> list[dict[str, Any]]:
        return repos.list_workflow_sessions(self._session, workflow_id)

    def list_all_workflow_sessions(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        workflow_id: str | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        return repos.list_all_workflow_sessions(
            self._session,
            page=page,
            page_size=page_size,
            workflow_id=workflow_id,
        )

    def create_workflow_step_run(
        self,
        *,
        workflow_run_id: str,
        node_id: str,
        node_type: str,
        status: str = "pending",
        input_json: dict[str, Any] | None = None,
    ) -> Any:
        return repos.create_workflow_step_run(
            self._session,
            workflow_run_id=workflow_run_id,
            node_id=node_id,
            node_type=node_type,
            status=status,
            input_json=input_json,
        )

    def list_step_runs(self, workflow_run_id: str) -> list[Any]:
        return repos.list_step_runs(self._session, workflow_run_id)

    def update_workflow_step_run(self, step: Any, **kwargs: Any) -> Any:
        return repos.update_workflow_step_run(self._session, step, **kwargs)

    def create_workflow_step_events(
        self,
        *,
        step_run_id: str,
        workflow_run_id: str,
        events: list[dict[str, Any]],
    ) -> list[Any]:
        return repos.create_workflow_step_events(
            self._session,
            step_run_id=step_run_id,
            workflow_run_id=workflow_run_id,
            events=events,
        )

    def list_workflow_step_events(self, step_run_id: str) -> list[Any]:
        return repos.list_workflow_step_events(self._session, step_run_id)

    def create_workflow_artifact(
        self,
        *,
        workflow_run_id: str,
        step_run_id: str | None = None,
        artifact_type: str,
        title: str | None = None,
        mime: str | None = None,
        content_text: str | None = None,
        source_path: str | None = None,
        size_bytes: int | None = None,
    ) -> Any:
        return repos.create_workflow_artifact(
            self._session,
            workflow_run_id=workflow_run_id,
            step_run_id=step_run_id,
            artifact_type=artifact_type,
            title=title,
            mime=mime,
            content_text=content_text,
            source_path=source_path,
            size_bytes=size_bytes,
        )

    def list_workflow_artifacts(
        self,
        *,
        workflow_run_id: str,
        step_run_id: str | None = None,
    ) -> list[Any]:
        return repos.list_workflow_artifacts(
            self._session,
            workflow_run_id=workflow_run_id,
            step_run_id=step_run_id,
        )

    def get_workflow_artifact(self, artifact_id: str) -> Any | None:
        return repos.get_workflow_artifact(self._session, artifact_id)

    def update_workflow_artifact(self, artifact: Any, **kwargs: Any) -> Any:
        return repos.update_workflow_artifact(self._session, artifact, **kwargs)

    def get_workflow_session(self, session_id: str) -> Any | None:
        return repos.get_workflow_session(self._session, session_id)

    def upsert_workflow_session(
        self,
        *,
        session_id: str,
        name: str | None = None,
        notes: str | None = None,
    ) -> Any:
        return repos.upsert_workflow_session(
            self._session,
            session_id=session_id,
            name=name,
            notes=notes,
        )

    def create_workflow_session_summary(
        self,
        *,
        session_id: str,
        content: str,
        generated_by: str | None = None,
        model: str | None = None,
    ) -> Any:
        return repos.create_workflow_session_summary(
            self._session,
            session_id=session_id,
            content=content,
            generated_by=generated_by,
            model=model,
        )

    def list_workflow_session_summaries(
        self,
        session_id: str,
        *,
        limit: int = 50,
    ) -> list[Any]:
        return repos.list_workflow_session_summaries(
            self._session,
            session_id,
            limit=limit,
        )


__all__ = ["SQLAlchemyAgentStore"]
