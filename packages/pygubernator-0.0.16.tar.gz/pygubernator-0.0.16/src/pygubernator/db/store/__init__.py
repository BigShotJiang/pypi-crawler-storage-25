"""Pluggable persistence for PyGubernator (mirrors ContractStore / StateStore)."""

from __future__ import annotations

from pygubernator.db.store.client import AgentStoreClient
from pygubernator.db.store.protocols import (
    AgentStore,
    AuditStore,
    RunStore,
    WorkflowStore,
)

try:
    from pygubernator.db.store.memory import InMemoryAgentStore
except ImportError:
    InMemoryAgentStore = None  # type: ignore[misc, assignment]

try:
    from pygubernator.db.store.sqlalchemy import SQLAlchemyAgentStore
except ImportError:
    SQLAlchemyAgentStore = None  # type: ignore[misc, assignment]

__all__ = [
    "AgentStore",
    "AgentStoreClient",
    "AuditStore",
    "InMemoryAgentStore",
    "RunStore",
    "SQLAlchemyAgentStore",
    "WorkflowStore",
]
