"""Protocol definitions for pluggable agent store backends."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class AgentStore(Protocol):
    """Protocol for agent CRUD operations."""

    def get_agent(self, agent_id: str) -> Any | None: ...

    def create_agent(
        self,
        *,
        name: str,
        owner: str = "system",
        status: str = "active",
    ) -> Any: ...

    def update_agent(self, agent: Any, **kwargs: Any) -> None: ...

    def list_agents(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
    ) -> tuple[list[Any], int]: ...


@runtime_checkable
class WorkflowStore(Protocol):
    """Protocol for workflow CRUD operations."""

    def get_workflow(self, workflow_id: str) -> Any | None: ...

    def create_workflow(
        self,
        *,
        name: str,
        owner: str,
        description: str = "",
    ) -> Any: ...

    def list_workflows(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
    ) -> tuple[list[Any], int]: ...

    def create_workflow_version(
        self,
        *,
        workflow_id: str,
        version: str,
        spec_json: dict[str, Any] | None = None,
        created_by: str = "system",
    ) -> Any: ...

    def list_workflow_versions(self, workflow_id: str) -> list[Any]: ...


@runtime_checkable
class RunStore(Protocol):
    """Protocol for execution run operations."""

    def get_run(self, run_id: str) -> Any | None: ...

    def create_run(
        self,
        *,
        agent_id: str,
        status: str = "pending",
        trigger: str = "manual",
        **kwargs: Any,
    ) -> Any: ...

    def update_run(self, run: Any, **kwargs: Any) -> None: ...

    def list_runs(
        self,
        *,
        page: int = 1,
        page_size: int = 25,
        **filters: Any,
    ) -> tuple[list[Any], int]: ...


@runtime_checkable
class AuditStore(Protocol):
    """Protocol for audit logging."""

    def create_audit(
        self,
        *,
        actor: str,
        action: str,
        resource_type: str,
        resource_id: str,
        details: dict[str, Any] | None = None,
    ) -> Any: ...

    def list_audit_logs(
        self,
        *,
        resource_type: str | None = None,
        resource_id: str | None = None,
        limit: int = 50,
    ) -> list[Any]: ...


__all__ = [
    "AgentStore",
    "AuditStore",
    "RunStore",
    "WorkflowStore",
]
