"""Database seeding helpers.

This module keeps seeding logic out of ``db/cli.py`` so we can grow seed
phases in a maintainable, testable way. The seeding pipeline is intentionally
ordered:

1. Workflow seed YAML files from ``data/seed/workflows`` (or caller-provided dir)
2. Curated workflow templates from ``workflow/templates``
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from pygubernator.db.base import get_session
from pygubernator.db.models import Workflow, WorkflowVersion
from pygubernator.workflow.config._loader import WorkflowLoader
from pygubernator.workflow.templates import (
    get_default_template_dir,
    iter_templates_from,
)


@dataclass(slots=True)
class SeedStats:
    """Counts emitted by a single seed phase."""

    created: int = 0
    skipped: int = 0
    invalid: int = 0

    def add(self, other: SeedStats) -> None:
        self.created += other.created
        self.skipped += other.skipped
        self.invalid += other.invalid


def get_default_seed_workflows_dir() -> Path:
    """Resolve packaged workflow seed directory."""
    try:
        import pygubernator as _pkg

        root = Path(_pkg.__file__).resolve().parent
    except (ImportError, AttributeError):
        root = Path(__file__).resolve().parent.parent

    # New default path for curated, self-sufficient workflow examples.
    candidate = root / "data" / "seed" / "workflows"
    if candidate.exists():
        return candidate

    # Backwards-compatible fallback for older layouts.
    return root / "data" / "seed"


def _yaml_files(seed_dir: Path) -> list[Path]:
    return sorted(
        [
            path
            for path in seed_dir.rglob("*")
            if path.is_file() and path.suffix.lower() in {".yaml", ".yml"}
        ]
    )


def _upsert_workflow_version(
    *,
    session: Any,
    spec: dict[str, Any],
    created_by: str,
) -> str:
    """Insert a workflow version unless ``name@version`` already exists.

    Returns:
        ``"created"``, ``"skipped"``, or ``"invalid"``.
    """
    meta = spec.get("meta") or {}
    name = meta.get("name")
    version = meta.get("version", "1.0.0")
    if not isinstance(name, str) or not name.strip():
        return "invalid"
    if not isinstance(version, str) or not version.strip():
        version = "1.0.0"

    existing_wf = session.query(Workflow).filter(Workflow.name == name).first()
    if existing_wf:
        existing_ver = (
            session.query(WorkflowVersion)
            .filter(
                WorkflowVersion.workflow_id == existing_wf.id,
                WorkflowVersion.version == version,
            )
            .first()
        )
        if existing_ver:
            return "skipped"

        session.add(
            WorkflowVersion(
                workflow_id=existing_wf.id,
                version=version,
                revision=1,
                spec_json=spec,
                active=True,
                created_by=created_by,
            )
        )
        return "created"

    workflow = Workflow(
        name=name,
        description=meta.get("description", ""),
        owner=spec.get("owner", "system"),
    )
    session.add(workflow)
    session.flush()
    session.add(
        WorkflowVersion(
            workflow_id=workflow.id,
            version=version,
            revision=1,
            spec_json=spec,
            active=True,
            created_by=created_by,
        )
    )
    return "created"


def seed_workflows_from_directory(seed_dir: Path, db_url: str) -> SeedStats:
    """Seed workflow specs from YAML files under ``seed_dir`` recursively."""
    loader = WorkflowLoader()
    files = _yaml_files(seed_dir)
    if not files:
        print(f"No workflow seed YAML files found in {seed_dir}")
        return SeedStats()

    specs: list[dict[str, Any]] = []
    invalid_messages: list[str] = []
    for path in files:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        if data is None:
            continue
        items = data if isinstance(data, list) else [data]
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                invalid_messages.append(f"{path.name}[{idx}]: not a mapping")
                continue
            try:
                loader.load_dict(item)
                specs.append(item)
            except Exception as exc:  # noqa: BLE001
                invalid_messages.append(f"{path.name}[{idx}]: {exc}")

    stats = SeedStats(invalid=len(invalid_messages))
    if not specs:
        if invalid_messages:
            print("No valid workflow seed definitions found.")
            for msg in invalid_messages[:10]:
                print(f"  ⚠ {msg}")
            if len(invalid_messages) > 10:
                print(f"  … and {len(invalid_messages) - 10} more")
        return stats

    print(f"Seeding workflow YAML definitions from: {seed_dir}")
    session = get_session(db_url)
    try:
        for spec in specs:
            status = _upsert_workflow_version(
                session=session,
                spec=spec,
                created_by="seed",
            )
            if status == "created":
                stats.created += 1
            elif status == "skipped":
                stats.skipped += 1
            else:
                stats.invalid += 1
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

    print(
        f"  workflow YAML results -> created={stats.created}, "
        f"skipped={stats.skipped}, invalid={stats.invalid}"
    )
    return stats


def seed_templates(db_url: str) -> SeedStats:
    """Seed bundled template specs into workflow/version rows."""
    template_dir = get_default_template_dir()
    templates = list(iter_templates_from(template_dir))
    if not templates:
        print(f"No templates found in {template_dir}")
        return SeedStats()

    print(f"Seeding workflow templates from: {template_dir}")
    stats = SeedStats()
    session = get_session(db_url)
    try:
        for template in templates:
            status = _upsert_workflow_version(
                session=session,
                spec=template.spec,
                created_by="seed:template",
            )
            if status == "created":
                stats.created += 1
            elif status == "skipped":
                stats.skipped += 1
            else:
                stats.invalid += 1
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

    print(
        f"  template results -> created={stats.created}, "
        f"skipped={stats.skipped}, invalid={stats.invalid}"
    )
    return stats


def seed_all(*, db_url: str, seed_dir: Path | None = None) -> SeedStats:
    """Run full seed pipeline."""
    stats = SeedStats()
    workflow_seed_dir = (
        seed_dir if seed_dir is not None else get_default_seed_workflows_dir()
    )
    stats.add(seed_workflows_from_directory(workflow_seed_dir, db_url))
    stats.add(seed_templates(db_url))
    return stats
