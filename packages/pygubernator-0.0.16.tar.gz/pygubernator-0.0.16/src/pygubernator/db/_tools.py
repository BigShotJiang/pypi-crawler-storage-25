"""Repository helpers for tool entities."""

from __future__ import annotations

from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import Tool, ToolVersion

__all__ = [
    "activate_tool_version",
    "create_tool",
    "create_tool_version",
    "get_tool",
    "get_tool_version",
    "list_tool_versions",
    "list_tools",
    "update_tool",
]


def create_tool(
    db: Session,
    *,
    workspace_id: str = "default",
    name: str,
    description: str = "",
    owner: str = "system",
    status: str = "active",
) -> Tool:
    """Create a new Tool record."""
    rec = Tool(
        name=name,
        description=description,
        owner=owner,
        status=status,
        workspace_id=workspace_id,
    )
    db.add(rec)
    return rec


def get_tool(
    db: Session, tool_id: str, *, workspace_id: str = "default"
) -> Tool | None:
    """Get a tool by ID in the current workspace."""
    return db.scalar(
        select(Tool).where(Tool.id == tool_id, Tool.workspace_id == workspace_id)
    )


def list_tools(
    db: Session,
    *,
    workspace_id: str = "default",
    page: int = 1,
    page_size: int = 25,
    status: str | None = None,
) -> tuple[list[Tool], int]:
    """List tools with pagination and optional status filter."""
    query = select(Tool).where(
        Tool.workspace_id == workspace_id, Tool.archived.is_(False)
    )
    count_query = select(func.count(Tool.id)).where(
        Tool.workspace_id == workspace_id, Tool.archived.is_(False)
    )
    if status:
        query = query.where(Tool.status == status)
        count_query = count_query.where(Tool.status == status)
    items = db.scalars(
        paginate(query.order_by(Tool.created_at.desc()), page, page_size)
    ).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def update_tool(db: Session, tool: Tool, **kwargs: Any) -> Tool:
    """Update fields on an existing Tool."""
    for key, value in kwargs.items():
        if hasattr(tool, key):
            setattr(tool, key, value)
    return tool


def create_tool_version(
    db: Session,
    *,
    tool_id: str,
    version: str,
    spec_json: dict[str, Any] | None = None,
    active: bool = False,
    published: bool = False,
    created_by: str = "system",
) -> ToolVersion:
    """Create a ToolVersion, or update spec if this version already exists."""
    existing = db.scalar(
        select(ToolVersion).where(
            ToolVersion.tool_id == tool_id,
            ToolVersion.version == version,
        )
    )
    if existing is not None:
        existing.spec_json = spec_json or {}
        existing.revision = int(existing.revision or 1) + 1
        if published:
            existing.published = True
        return existing
    rec = ToolVersion(
        tool_id=tool_id,
        version=version,
        spec_json=spec_json or {},
        active=active,
        published=published,
        created_by=created_by,
    )
    db.add(rec)
    db.flush()
    return rec


def get_tool_version(db: Session, version_id: str) -> ToolVersion | None:
    """Get a tool version by ID."""
    return db.get(ToolVersion, version_id)


def list_tool_versions(db: Session, tool_id: str) -> list[ToolVersion]:
    """List versions for a tool, newest first."""
    return list(
        db.scalars(
            select(ToolVersion)
            .where(ToolVersion.tool_id == tool_id)
            .order_by(ToolVersion.created_at.desc())
        ).all()
    )


def activate_tool_version(db: Session, tool: Tool, version_id: str) -> None:
    """Activate one tool version and mark others inactive."""
    selected: str | None = None
    for version in tool.versions:
        is_selected = version.id == version_id
        version.active = is_selected
        if is_selected:
            version.published = True
            selected = version.id
    tool.current_version_id = selected
