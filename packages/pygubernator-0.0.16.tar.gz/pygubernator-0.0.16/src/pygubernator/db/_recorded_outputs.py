"""Repository helpers for deterministic replay recorded outputs."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from pygubernator.db.models import RecordedOutput

__all__ = ["upsert_recorded_output", "list_recorded_outputs"]


def upsert_recorded_output(
    db: Session,
    *,
    workspace_id: str,
    workflow_run_id: str,
    node_id: str,
    payload_json: dict,
) -> RecordedOutput:
    existing = db.scalar(
        select(RecordedOutput).where(
            RecordedOutput.workspace_id == workspace_id,
            RecordedOutput.workflow_run_id == workflow_run_id,
            RecordedOutput.node_id == node_id,
        )
    )
    if existing is not None:
        existing.payload_json = payload_json
        return existing
    rec = RecordedOutput(
        workspace_id=workspace_id,
        workflow_run_id=workflow_run_id,
        node_id=node_id,
        payload_json=payload_json,
    )
    db.add(rec)
    return rec


def list_recorded_outputs(
    db: Session,
    *,
    workspace_id: str,
    workflow_run_id: str,
) -> list[RecordedOutput]:
    return list(
        db.scalars(
            select(RecordedOutput)
            .where(
                RecordedOutput.workspace_id == workspace_id,
                RecordedOutput.workflow_run_id == workflow_run_id,
            )
            .order_by(RecordedOutput.created_at.asc())
        ).all()
    )
