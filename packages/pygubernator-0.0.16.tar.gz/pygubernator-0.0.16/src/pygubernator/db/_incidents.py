"""Repository helpers for Incident entities."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from pygubernator.db.models import Incident

__all__ = ["get_incident", "list_incidents"]


def get_incident(db: Session, incident_id: str) -> Incident | None:
    """Get an incident by ID."""
    return db.get(Incident, incident_id)


def list_incidents(
    db: Session,
    *,
    status: str | None = None,
    severity: str | None = None,
    owner: str | None = None,
    limit: int = 100,
) -> list[Incident]:
    """List incidents with optional filters.

    Args:
        db: SQLAlchemy session.
        status: Optional status filter.
        severity: Optional severity filter.
        owner: Optional owner filter.
        limit: Maximum results to return.

    Returns:
        List of matching incidents.
    """
    query = select(Incident).order_by(Incident.created_at.desc()).limit(limit)
    if status:
        query = query.where(Incident.status == status)
    if severity:
        query = query.where(Incident.severity == severity)
    if owner:
        query = query.where(Incident.owner == owner)
    return db.scalars(query).all()
