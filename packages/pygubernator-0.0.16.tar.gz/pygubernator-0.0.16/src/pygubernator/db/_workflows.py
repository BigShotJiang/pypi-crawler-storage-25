"""Repository helpers for workflow entities."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import (
    Workflow,
    WorkflowArtifact,
    WorkflowRun,
    WorkflowSession,
    WorkflowSessionSummary,
    WorkflowStepEvent,
    WorkflowStepRun,
    WorkflowVersion,
)

__all__ = [
    "activate_workflow_version",
    "create_workflow",
    "create_workflow_artifact",
    "create_workflow_run",
    "create_workflow_session_summary",
    "create_workflow_step_events",
    "create_workflow_step_run",
    "create_workflow_version",
    "get_workflow",
    "delete_workflow_run",
    "get_workflow_artifact",
    "get_workflow_run",
    "get_workflow_session",
    "list_all_workflow_sessions",
    "list_step_runs",
    "list_workflow_artifacts",
    "list_workflow_runs",
    "list_workflow_session_summaries",
    "list_workflow_sessions",
    "list_workflow_step_events",
    "list_workflow_versions",
    "list_workflows",
    "update_workflow",
    "update_workflow_artifact",
    "update_workflow_run",
    "update_workflow_step_run",
    "upsert_workflow_session",
]


def create_workflow(
    db: Session,
    *,
    workspace_id: str = "default",
    name: str,
    description: str = "",
    owner: str = "system",
    status: str = "active",
) -> Workflow:
    """Create a new Workflow record.

    Args:
        db: SQLAlchemy session.
        name: Unique workflow name.
        description: Brief description.
        owner: Owner identifier.
        status: Initial status.

    Returns:
        The created Workflow.
    """
    wf = Workflow(
        name=name,
        description=description,
        owner=owner,
        status=status,
        workspace_id=workspace_id,
    )
    db.add(wf)
    return wf


def get_workflow(
    db: Session, workflow_id: str, *, workspace_id: str = "default"
) -> Workflow | None:
    """Get a workflow by ID."""
    return db.scalar(
        select(Workflow).where(
            Workflow.id == workflow_id, Workflow.workspace_id == workspace_id
        )
    )


def list_workflows(
    db: Session,
    *,
    workspace_id: str = "default",
    page: int = 1,
    page_size: int = 25,
    status: str | None = None,
) -> tuple[list[Workflow], int]:
    """List workflows with pagination and optional status filter.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.
        status: Optional status filter.

    Returns:
        Tuple of (workflows, total_count).
    """
    query = select(Workflow).where(Workflow.workspace_id == workspace_id)
    count_query = select(func.count(Workflow.id)).where(
        Workflow.workspace_id == workspace_id
    )
    if status:
        query = query.where(Workflow.status == status)
        count_query = count_query.where(Workflow.status == status)
    items = db.scalars(
        paginate(query.order_by(Workflow.created_at.desc()), page, page_size)
    ).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def update_workflow(
    db: Session,
    workflow: Workflow,
    **kwargs: Any,
) -> Workflow:
    """Update fields on an existing Workflow.

    Args:
        db: SQLAlchemy session.
        workflow: The Workflow to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated Workflow.
    """
    for key, value in kwargs.items():
        if hasattr(workflow, key):
            setattr(workflow, key, value)
    return workflow


def create_workflow_version(
    db: Session,
    *,
    workflow_id: str,
    version: str,
    spec_json: dict[str, Any] | None = None,
    active: bool = False,
    created_by: str = "system",
) -> WorkflowVersion:
    """Create a WorkflowVersion, or update *spec_json* if the version already exists.

    The database enforces a unique (workflow_id, version) pair. Re-saving from the
    editor with the same version string updates the existing row in place instead of
    inserting a duplicate.

    Args:
        db: SQLAlchemy session.
        workflow_id: Parent workflow ID.
        version: Version string.
        spec_json: Workflow specification as JSON dict.
        active: Whether this version is active (only applied on insert).
        created_by: Actor who created this version (only applied on insert).

    Returns:
        The created or updated WorkflowVersion.
    """
    existing = db.scalar(
        select(WorkflowVersion).where(
            WorkflowVersion.workflow_id == workflow_id,
            WorkflowVersion.version == version,
        )
    )
    if existing is not None:
        existing.spec_json = spec_json or {}
        return existing
    wv = WorkflowVersion(
        workflow_id=workflow_id,
        version=version,
        spec_json=spec_json or {},
        active=active,
        created_by=created_by,
    )
    db.add(wv)
    # So a second save with the same version in one transaction sees this row
    # (scalar(select(...)) does not match unflushed pending objects).
    db.flush()
    return wv


def list_workflow_versions(
    db: Session,
    workflow_id: str,
) -> list[WorkflowVersion]:
    """List all versions for a workflow, newest first."""
    return list(
        db.scalars(
            select(WorkflowVersion)
            .where(WorkflowVersion.workflow_id == workflow_id)
            .order_by(WorkflowVersion.created_at.desc())
        ).all()
    )


def activate_workflow_version(
    db: Session,
    workflow: Workflow,
    version_id: str,
) -> None:
    """Activate a specific workflow version, deactivating all others.

    Args:
        db: SQLAlchemy session.
        workflow: The workflow whose version to activate.
        version_id: The version ID to activate.
    """
    for version in workflow.versions:
        version.active = version.id == version_id


def create_workflow_run(
    db: Session,
    *,
    workflow_id: str,
    workflow_version_id: str | None = None,
    status: str = "pending",
    input_json: dict[str, Any] | None = None,
    created_by: str = "system",
    session_id: str | None = None,
    trigger: str | None = None,
    correlation_id: str | None = None,
) -> WorkflowRun:
    """Create a new WorkflowRun record.

    Args:
        db: SQLAlchemy session.
        workflow_id: Parent workflow ID.
        workflow_version_id: Optional version ID.
        status: Initial run status.
        input_json: Input data for the run.
        created_by: Actor who created this run.
        session_id: Optional session ID for multi-turn conversations.
        trigger: How the run was started (``"manual"``, ``"schedule"``,
            ``"webhook"``, ``"guide"``, …). Short free-text so new
            trigger kinds can be added without a migration. Defaults
            to ``None`` so existing callers stay untouched.
        correlation_id: Opaque id tying the run back to the caller's
            originating session / message (e.g. chat session id for
            Guide-dispatched runs). Indexed for cheap lookups.

    Returns:
        The created WorkflowRun.
    """
    wr = WorkflowRun(
        workflow_id=workflow_id,
        workflow_version_id=workflow_version_id,
        status=status,
        input_json=input_json or {},
        created_by=created_by,
        session_id=session_id,
        trigger=trigger,
        correlation_id=correlation_id,
    )
    db.add(wr)
    return wr


def get_workflow_run(db: Session, run_id: str) -> WorkflowRun | None:
    """Get a workflow run by ID."""
    return db.get(WorkflowRun, run_id)


def delete_workflow_run(db: Session, run_id: str) -> bool:
    """Delete a workflow run and all its step rows.

    Args:
        db: SQLAlchemy session.
        run_id: Workflow run ID.

    Returns:
        True if a run was deleted, False if not found.
    """
    run = get_workflow_run(db, run_id)
    if not run:
        return False
    db.execute(delete(WorkflowStepRun).where(WorkflowStepRun.workflow_run_id == run_id))
    db.delete(run)
    return True


def list_workflow_runs(
    db: Session,
    *,
    page: int = 1,
    page_size: int = 25,
    workflow_id: str | None = None,
    status: str | None = None,
    search: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    session_id: str | None = None,
    trigger: str | None = None,
    correlation_id: str | None = None,
) -> tuple[list[WorkflowRun], int]:
    """List workflow runs with pagination and optional filters.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.
        workflow_id: Optional workflow filter.
        status: Optional status filter.
        search: Free-text search on run ID, workflow name, created_by,
            or error_message.
        created_after: Only runs started at or after this timestamp.
        created_before: Only runs started at or before this timestamp.
        session_id: Optional session filter so the UI can drill from
            the cross-workflow Sessions sidebar into the runs inside a
            single multi-turn session.
        trigger: Optional trigger filter (e.g. ``"guide"``) so the UI
            can list "only the runs started by the Guide".
        correlation_id: Optional correlation filter so the Guide can
            list "all runs spawned by this chat thread".

    Returns:
        Tuple of (workflow_runs, total_count).
    """
    query = select(WorkflowRun)
    count_query = select(func.count(WorkflowRun.id))
    if workflow_id:
        query = query.where(WorkflowRun.workflow_id == workflow_id)
        count_query = count_query.where(WorkflowRun.workflow_id == workflow_id)
    if status:
        query = query.where(WorkflowRun.status == status)
        count_query = count_query.where(WorkflowRun.status == status)
    if session_id:
        query = query.where(WorkflowRun.session_id == session_id)
        count_query = count_query.where(WorkflowRun.session_id == session_id)
    if trigger:
        query = query.where(WorkflowRun.trigger == trigger)
        count_query = count_query.where(WorkflowRun.trigger == trigger)
    if correlation_id:
        query = query.where(WorkflowRun.correlation_id == correlation_id)
        count_query = count_query.where(WorkflowRun.correlation_id == correlation_id)
    if search:
        pattern = f"%{search}%"
        # Join Workflow for name search
        search_filter = or_(
            WorkflowRun.id.ilike(pattern),
            WorkflowRun.created_by.ilike(pattern),
            WorkflowRun.error_message.ilike(pattern),
            Workflow.name.ilike(pattern),
        )
        query = query.join(Workflow, WorkflowRun.workflow_id == Workflow.id)
        query = query.where(search_filter)
        count_query = count_query.join(Workflow, WorkflowRun.workflow_id == Workflow.id)
        count_query = count_query.where(search_filter)
    if created_after:
        query = query.where(WorkflowRun.started_at >= created_after)
        count_query = count_query.where(WorkflowRun.started_at >= created_after)
    if created_before:
        query = query.where(WorkflowRun.started_at <= created_before)
        count_query = count_query.where(WorkflowRun.started_at <= created_before)
    items = db.scalars(
        paginate(
            query.order_by(WorkflowRun.started_at.desc().nulls_last()),
            page,
            page_size,
        )
    ).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def list_workflow_sessions(
    db: Session,
    workflow_id: str,
) -> list[dict[str, Any]]:
    """List distinct sessions for a workflow with latest run info.

    Args:
        db: SQLAlchemy session.
        workflow_id: Workflow to query.

    Returns:
        List of dicts with session_id, run_count, latest_status,
        and last_run_at.
    """
    query = (
        select(
            WorkflowRun.session_id,
            func.count(WorkflowRun.id).label("run_count"),
            func.max(WorkflowRun.started_at).label("last_run_at"),
        )
        .where(WorkflowRun.workflow_id == workflow_id)
        .where(WorkflowRun.session_id.isnot(None))
        .group_by(WorkflowRun.session_id)
        .order_by(func.max(WorkflowRun.started_at).desc())
    )
    rows = db.execute(query).all()
    return [
        {
            "session_id": r.session_id,
            "run_count": r.run_count,
            "last_run_at": r.last_run_at.isoformat() if r.last_run_at else None,
        }
        for r in rows
    ]


def list_all_workflow_sessions(
    db: Session,
    *,
    page: int = 1,
    page_size: int = 25,
    workflow_id: str | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """List sessions across every workflow (or one workflow if pinned).

    Unlike :func:`list_workflow_sessions`, which is scoped to a single
    workflow and returns raw grouped rows, this helper powers the
    top-level Runs-page sidebar: it joins the ``workflows`` table so the
    UI can display a friendly workflow name next to each session row and
    is paginated with a total count so very long histories don't freeze
    the UI. Ordered by most recent run first.

    Args:
        db: SQLAlchemy session.
        page: 1-indexed page number.
        page_size: Items per page.
        workflow_id: Optional pin so the caller can re-use this helper
            for a single workflow view while keeping one query path.

    Returns:
        Tuple of ``(items, total)`` where each item is a dict with
        ``session_id``, ``workflow_id``, ``workflow_name``,
        ``run_count``, ``last_run_at``, and ``last_status``.
    """
    base = (
        select(
            WorkflowRun.session_id,
            WorkflowRun.workflow_id,
            Workflow.name.label("workflow_name"),
            func.count(WorkflowRun.id).label("run_count"),
            func.max(WorkflowRun.started_at).label("last_run_at"),
        )
        .join(Workflow, Workflow.id == WorkflowRun.workflow_id)
        .where(WorkflowRun.session_id.isnot(None))
    )
    if workflow_id is not None:
        base = base.where(WorkflowRun.workflow_id == workflow_id)
    base = base.group_by(
        WorkflowRun.session_id,
        WorkflowRun.workflow_id,
        Workflow.name,
    )
    count_query = select(func.count()).select_from(base.subquery())
    total = int(db.scalar(count_query) or 0)

    items_query = base.order_by(func.max(WorkflowRun.started_at).desc())
    items_query = items_query.limit(page_size).offset((page - 1) * page_size)
    rows = db.execute(items_query).all()

    # Look up each session's latest status in a second query so we don't
    # have to coerce the status into a GROUP BY aggregate (which behaves
    # differently across SQLite / Postgres / MySQL).
    session_ids = [r.session_id for r in rows]
    latest_status_by_session: dict[str, str | None] = {}
    if session_ids:
        status_rows = db.execute(
            select(
                WorkflowRun.session_id,
                WorkflowRun.status,
                WorkflowRun.started_at,
            )
            .where(WorkflowRun.session_id.in_(session_ids))
            .order_by(WorkflowRun.session_id, WorkflowRun.started_at.desc())
        ).all()
        seen: set[str] = set()
        for row in status_rows:
            if row.session_id in seen:
                continue
            latest_status_by_session[row.session_id] = row.status
            seen.add(row.session_id)

    # Join the metadata rows for any session that has a user-supplied
    # name. Done in a second query rather than as a LEFT JOIN above to
    # keep the GROUP BY portable across SQLite / Postgres / MySQL when
    # the metadata table is empty.
    name_by_session: dict[str, str] = {}
    if session_ids:
        meta_rows = db.execute(
            select(WorkflowSession.session_id, WorkflowSession.name).where(
                WorkflowSession.session_id.in_(session_ids)
            )
        ).all()
        for row in meta_rows:
            if row.name:
                name_by_session[row.session_id] = row.name

    return [
        {
            "session_id": r.session_id,
            "workflow_id": r.workflow_id,
            "workflow_name": r.workflow_name,
            "run_count": r.run_count,
            "last_run_at": r.last_run_at.isoformat() if r.last_run_at else None,
            "last_status": latest_status_by_session.get(r.session_id),
            "name": name_by_session.get(r.session_id),
        }
        for r in rows
    ], total


def update_workflow_run(
    db: Session,
    run: WorkflowRun,
    **kwargs: Any,
) -> WorkflowRun:
    """Update fields on an existing WorkflowRun.

    Args:
        db: SQLAlchemy session.
        run: The WorkflowRun to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated WorkflowRun.
    """
    for key, value in kwargs.items():
        if hasattr(run, key):
            setattr(run, key, value)
    return run


def create_workflow_step_run(
    db: Session,
    *,
    workflow_run_id: str,
    node_id: str,
    node_type: str,
    status: str = "pending",
    input_json: dict[str, Any] | None = None,
) -> WorkflowStepRun:
    """Create a WorkflowStepRun record.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: Parent workflow run ID.
        node_id: Workflow node ID.
        node_type: Node type string.
        status: Initial step status.
        input_json: Node input data.

    Returns:
        The created WorkflowStepRun.
    """
    step = WorkflowStepRun(
        workflow_run_id=workflow_run_id,
        node_id=node_id,
        node_type=node_type,
        status=status,
        input_json=input_json or {},
    )
    db.add(step)
    return step


def list_step_runs(
    db: Session,
    workflow_run_id: str,
) -> list[WorkflowStepRun]:
    """List all step runs for a workflow run, ordered by start time.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: The workflow run to list steps for.

    Returns:
        List of WorkflowStepRun records.
    """
    return list(
        db.scalars(
            select(WorkflowStepRun)
            .where(WorkflowStepRun.workflow_run_id == workflow_run_id)
            .order_by(WorkflowStepRun.started_at.asc().nulls_last())
        ).all()
    )


def update_workflow_step_run(
    db: Session,
    step: WorkflowStepRun,
    **kwargs: Any,
) -> WorkflowStepRun:
    """Update fields on an existing WorkflowStepRun.

    Args:
        db: SQLAlchemy session.
        step: The WorkflowStepRun to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated WorkflowStepRun.
    """
    for key, value in kwargs.items():
        if hasattr(step, key):
            setattr(step, key, value)
    return step


def create_workflow_step_events(
    db: Session,
    *,
    step_run_id: str,
    workflow_run_id: str,
    events: list[dict[str, Any]],
) -> list[WorkflowStepEvent]:
    """Bulk-insert buffered child events for a workflow step.

    ``events`` is the list produced by ``_StepEventBuffer.flush`` — each
    entry is ``{"type": str, "timestamp": float, "data": dict}``. Rows are
    assigned a monotonic ``sequence_num`` (0-based) in the order they
    appear so readers can reconstruct the original sequence without
    relying on float-timestamp ties.

    Args:
        db: SQLAlchemy session.
        step_run_id: Parent :class:`WorkflowStepRun` id.
        workflow_run_id: Parent workflow run id (denormalized for
            cross-run queries without an extra join).
        events: Buffered event dicts as produced by the step buffer.
            Empty / missing-shape entries are skipped defensively.

    Returns:
        The inserted :class:`WorkflowStepEvent` rows (not committed).
    """
    rows: list[WorkflowStepEvent] = []
    for seq, event in enumerate(events):
        if not isinstance(event, dict):
            continue
        event_type = event.get("type")
        if not isinstance(event_type, str):
            continue
        timestamp_raw = event.get("timestamp", 0.0)
        try:
            timestamp = float(timestamp_raw)
        except (TypeError, ValueError):
            timestamp = 0.0
        payload = event.get("data")
        if not isinstance(payload, dict):
            payload = {}
        row = WorkflowStepEvent(
            step_run_id=step_run_id,
            workflow_run_id=workflow_run_id,
            event_type=event_type,
            sequence_num=seq,
            event_timestamp=timestamp,
            payload_json=payload,
        )
        db.add(row)
        rows.append(row)
    return rows


def list_workflow_step_events(
    db: Session,
    step_run_id: str,
) -> list[WorkflowStepEvent]:
    """Return the events for a step in original sequence order.

    Args:
        db: SQLAlchemy session.
        step_run_id: Step run whose events to fetch.

    Returns:
        Events sorted by ``sequence_num`` ascending. Empty list if none.
    """
    return list(
        db.scalars(
            select(WorkflowStepEvent)
            .where(WorkflowStepEvent.step_run_id == step_run_id)
            .order_by(WorkflowStepEvent.sequence_num.asc())
        ).all()
    )


def _next_artifact_sequence_num(db: Session, workflow_run_id: str) -> int:
    """Return the next monotonic sequence number for a run's artifacts.

    Flushes first so rows added in the same session — but not yet
    committed — are counted, preventing duplicate sequence numbers when
    a caller emits several artifacts in quick succession.
    """
    db.flush()
    current = db.scalar(
        select(func.max(WorkflowArtifact.sequence_num)).where(
            WorkflowArtifact.workflow_run_id == workflow_run_id
        )
    )
    if current is None:
        return 0
    return int(current) + 1


def create_workflow_artifact(
    db: Session,
    *,
    workflow_run_id: str,
    step_run_id: str | None = None,
    artifact_type: str,
    title: str | None = None,
    mime: str | None = None,
    content_text: str | None = None,
    source_path: str | None = None,
    size_bytes: int | None = None,
) -> WorkflowArtifact:
    """Insert a new artifact row for a workflow run.

    Either ``content_text`` or ``source_path`` must be provided — the
    route that serves artifact content streams from whichever is set.
    ``sequence_num`` is assigned automatically as the next value within
    the run so the UI can render artifacts in emission order.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: Parent run id.
        step_run_id: Optional step run id when the artifact belongs to a
            specific node execution. ``None`` for run-level artifacts.
        artifact_type: Renderer discriminator (``markdown``, ``table``,
            ``html``, ``image``, ``notebook``, ``json``, ``text``).
        title: Optional human-readable title.
        mime: Optional MIME type (e.g. ``text/markdown``, ``text/csv``).
        content_text: Inline text content. Mutually exclusive with
            ``source_path``, but callers may supply both during staged
            emission (content first, path later) and the route prefers
            ``content_text`` when both exist.
        source_path: Filesystem or object-storage reference for content
            too large to inline.
        size_bytes: Optional content size for the list summary.

    Returns:
        The inserted :class:`WorkflowArtifact` (not committed).

    Raises:
        ValueError: If neither ``content_text`` nor ``source_path`` is
            provided — an artifact row with no content is not useful.
    """
    if content_text is None and source_path is None:
        raise ValueError(
            "create_workflow_artifact requires content_text or source_path"
        )
    sequence_num = _next_artifact_sequence_num(db, workflow_run_id)
    row = WorkflowArtifact(
        workflow_run_id=workflow_run_id,
        step_run_id=step_run_id,
        artifact_type=artifact_type,
        title=title,
        mime=mime,
        content_text=content_text,
        source_path=source_path,
        size_bytes=size_bytes,
        sequence_num=sequence_num,
    )
    db.add(row)
    return row


def list_workflow_artifacts(
    db: Session,
    *,
    workflow_run_id: str,
    step_run_id: str | None = None,
) -> list[WorkflowArtifact]:
    """Return artifacts for a run, optionally filtered to one step.

    Args:
        db: SQLAlchemy session.
        workflow_run_id: Run whose artifacts to fetch.
        step_run_id: Optional filter restricting results to one step.

    Returns:
        Artifacts sorted by ``sequence_num`` ascending. Empty list if
        none match.
    """
    stmt = select(WorkflowArtifact).where(
        WorkflowArtifact.workflow_run_id == workflow_run_id
    )
    if step_run_id is not None:
        stmt = stmt.where(WorkflowArtifact.step_run_id == step_run_id)
    stmt = stmt.order_by(WorkflowArtifact.sequence_num.asc())
    return list(db.scalars(stmt).all())


def get_workflow_artifact(
    db: Session,
    artifact_id: str,
) -> WorkflowArtifact | None:
    """Fetch one artifact by id, or ``None`` if it does not exist."""
    return db.get(WorkflowArtifact, artifact_id)


def update_workflow_artifact(
    db: Session,
    artifact: WorkflowArtifact,
    **kwargs: Any,
) -> WorkflowArtifact:
    """Apply partial updates to an artifact and return it.

    Supports live-reload flows where a long-running node streams
    incremental content updates into an already-emitted artifact.
    Unknown keys are ignored.
    """
    allowed = {
        "title",
        "mime",
        "content_text",
        "source_path",
        "size_bytes",
        "artifact_type",
    }
    for key, value in kwargs.items():
        if key in allowed:
            setattr(artifact, key, value)
    return artifact


def get_workflow_session(
    db: Session,
    session_id: str,
) -> WorkflowSession | None:
    """Fetch the metadata row for a session, or ``None`` if absent.

    Sessions exist as soon as a workflow run carries a ``session_id``;
    metadata only exists once a user has named or annotated the
    session. ``None`` here means "no friendly name yet" — callers fall
    back to displaying the raw id.
    """
    return db.get(WorkflowSession, session_id)


def upsert_workflow_session(
    db: Session,
    *,
    session_id: str,
    name: str | None = None,
    notes: str | None = None,
) -> WorkflowSession:
    """Create or update the metadata row for a session.

    Designed for "rename" flows from the UI: pass the new ``name`` (and
    optionally ``notes``) and the helper inserts a row if none exists,
    or overwrites the matching fields. Fields left as ``None`` are
    *preserved* on existing rows rather than blanked, so the caller
    doesn't need to fetch-then-merge for partial updates.

    Args:
        db: SQLAlchemy session.
        session_id: Session id to store metadata against.
        name: New display name. ``None`` leaves the existing value.
        notes: New free-form notes. ``None`` leaves the existing value.

    Returns:
        The persisted (or just-updated) :class:`WorkflowSession`.
    """
    row = db.get(WorkflowSession, session_id)
    if row is None:
        row = WorkflowSession(
            session_id=session_id,
            name=name,
            notes=notes,
        )
        db.add(row)
        return row
    if name is not None:
        row.name = name or None
    if notes is not None:
        row.notes = notes or None
    return row


def create_workflow_session_summary(
    db: Session,
    *,
    session_id: str,
    content: str,
    generated_by: str | None = None,
    model: str | None = None,
) -> WorkflowSessionSummary:
    """Insert a new summary row for a session.

    Many summaries can exist per session — typically one per schedule
    tick — so this is an unconditional insert. Callers fetch the
    history via :func:`list_workflow_session_summaries`.

    Args:
        db: SQLAlchemy session.
        session_id: Session this summary describes.
        content: The narrative summary text.
        generated_by: Identifier of the actor that produced the
            summary (agent name, ``"manual"``, etc.).
        model: Optional LLM model id when an agent generated the text.

    Returns:
        The new :class:`WorkflowSessionSummary` (not committed).
    """
    if not content.strip():
        raise ValueError("Summary content must not be empty")
    row = WorkflowSessionSummary(
        session_id=session_id,
        content=content,
        generated_by=generated_by,
        model=model,
    )
    db.add(row)
    return row


def list_workflow_session_summaries(
    db: Session,
    session_id: str,
    *,
    limit: int = 50,
) -> list[WorkflowSessionSummary]:
    """Return summaries for a session, newest first.

    Args:
        db: SQLAlchemy session.
        session_id: Session to query.
        limit: Maximum rows to return; older summaries are not
            paginated in v1 — long histories should issue periodic
            consolidation summaries that supersede the noise.

    Returns:
        Summaries sorted by ``generated_at`` descending.
    """
    return list(
        db.scalars(
            select(WorkflowSessionSummary)
            .where(WorkflowSessionSummary.session_id == session_id)
            .order_by(WorkflowSessionSummary.generated_at.desc())
            .limit(limit)
        ).all()
    )
