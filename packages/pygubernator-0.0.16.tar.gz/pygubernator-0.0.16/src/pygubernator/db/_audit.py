"""Repository helpers for AuditLog entities."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from pygubernator.db.models import AuditLog

__all__ = ["create_audit", "list_audit_logs"]


def create_audit(
    db: Session,
    *,
    actor: str,
    action: str,
    resource_type: str,
    resource_id: str | None,
    details: dict,
) -> AuditLog:
    """Create an audit log entry.

    Args:
        db: SQLAlchemy session.
        actor: Who performed the action.
        action: What action was performed.
        resource_type: Type of resource affected.
        resource_id: Optional ID of the affected resource.
        details: Additional details dict.

    Returns:
        The created AuditLog.
    """
    rec = AuditLog(
        actor=actor,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details,
    )
    db.add(rec)
    return rec


def list_audit_logs(
    db: Session,
    *,
    limit: int = 100,
    resource_id: str | None = None,
    resource_type: str | None = None,
) -> list[AuditLog]:
    """Return recent audit rows, optionally filtered by resource."""
    q = select(AuditLog).order_by(AuditLog.created_at.desc())
    if resource_id is not None:
        q = q.where(AuditLog.resource_id == resource_id)
    if resource_type is not None:
        q = q.where(AuditLog.resource_type == resource_type)
    return list(db.scalars(q.limit(limit)).all())
