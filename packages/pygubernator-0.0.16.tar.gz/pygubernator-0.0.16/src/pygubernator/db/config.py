"""Database URL resolution, migrations path, and Alembic configuration.

Mirrors pystator's db/config.py: used by db/cli.py, API, and session
when a database URL is needed (with optional default to SQLite).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from pygubernator.config.database import (
    default_sqlite_path,
    get_database_url,
    get_default_sqlite_url,
    set_database_url,
)
from pygubernator.db.paths import get_migrations_dir

# If a user runs `pygubernator db init upgrade`, argparse passes "upgrade" as the
# optional database URL for `init`. SQLAlchemy then fails to parse it.
_DB_CLI_SUBCOMMAND_NAMES = frozenset(
    {"init", "upgrade", "downgrade", "seed", "current", "history", "stamp", "truncate"}
)

if TYPE_CHECKING:
    from alembic.config import Config

try:
    from alembic.config import Config as _Config

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False
    _Config = None  # type: ignore[misc, assignment]


def _default_db_url() -> str:
    """Return the default SQLite database URL."""
    return get_default_sqlite_url()


def validate_database_url_string(url: str, *, cli_tool: str = "pygubernator db") -> str:
    """Ensure *url* parses as a SQLAlchemy URL; exit with a clear hint on failure.

    Catches mistaken invocations such as ``db init upgrade`` where the second word
    is parsed as the optional URL for ``db init``.
    """
    s = (url or "").strip()
    if not s:
        raise SystemExit(
            "Empty database URL. Set PYGUBERNATOR_DATABASE_URL or use the "
            "default SQLite file.\n"
            f"If you meant to apply migrations, run `{cli_tool} upgrade` "
            f"(not `{cli_tool} init upgrade`)."
        )
    try:
        from sqlalchemy.engine.url import make_url

        make_url(s)
        return s
    except Exception as exc:
        low = s.lower()
        if low in _DB_CLI_SUBCOMMAND_NAMES:
            raise SystemExit(
                f"Invalid database URL {s!r}: it matches a `db` subcommand name.\n"
                f"You may have run `{cli_tool} init {s}` by mistake. "
                f"Use `{cli_tool} {low}` as a separate command, not as "
                f"the URL argument to `init`.\n"
                f"  • Fresh schema: `{cli_tool} init`\n"
                f"  • Apply migrations: `{cli_tool} upgrade`\n"
            ) from None
        raise SystemExit(
            f"Invalid database URL {s!r}: {exc}\n"
            "Expected a SQLAlchemy URL, e.g. sqlite:///./pygubernator.db or "
            "postgresql://user:pass@host/dbname\n"
        ) from None


def require_alembic() -> None:
    """Raise ImportError if Alembic is not available."""
    if not ALEMBIC_AVAILABLE:
        raise ImportError(
            "alembic and sqlalchemy are required. "
            "Install with: pip install alembic sqlalchemy"
        )


def get_db_url(
    database_url: str | None = None,
    required: bool = True,
) -> str:
    """Resolve database URL from argument, config, or env.

    Defaults to ``sqlite:///<cwd>/pygubernator.db`` if unset.

    Args:
        database_url: Optional explicit URL (e.g. from CLI arg).
        required: If True and no URL was configured, print an info
            message about using the default SQLite database.

    Returns:
        Resolved database URL.
    """
    db_url = database_url or get_database_url()
    if not db_url:
        db_url = _default_db_url()
        if required:
            print(f"Using default SQLite database: {db_url}")
    return validate_database_url_string(db_url, cli_tool="pygubernator db")


def is_default_db_url(url: str) -> bool:
    """Return True if *url* is the current default SQLite database URL.

    Used by the API to log a warning only when the default is in use.
    """
    if not url or not url.startswith("sqlite://"):
        return False
    path_part = url[10:] if url.startswith("sqlite:///") else url
    try:
        return Path(path_part).resolve() == default_sqlite_path().resolve()
    except (OSError, RuntimeError):
        return False


def get_alembic_config(database_url: str | None = None) -> Config:
    """Build Alembic Config with script_location and sqlalchemy.url set.

    Uses :func:`get_db_url` (``required=False``) so the default path is
    defined in one place.
    """
    require_alembic()
    config = _Config()
    config.set_main_option("script_location", str(get_migrations_dir()))
    config.set_main_option("prepend_sys_path", ".")
    config.set_main_option("version_path_separator", "os")
    config.set_main_option(
        "file_template",
        "%%(year)d%%(month).2d%%(day).2d%%(hour).2d"
        "%%(minute).2d%%(second).2d_%%(rev)s_%%(slug)s",
    )
    db_url = get_db_url(database_url, required=False)
    config.set_main_option("sqlalchemy.url", db_url)
    set_database_url(db_url)
    return config  # type: ignore[return-value]


def detect_db_type(database_url: str) -> str:
    """Return database type from connection string.

    Returns:
        One of ``"postgresql"``, ``"sqlite"``, ``"mongodb"``, ``"redis"``.
        Defaults to ``"sqlite"`` for unrecognised schemes.
    """
    if database_url.startswith(("postgresql://", "postgres://")):
        return "postgresql"
    if database_url.startswith(("mongodb://", "mongodb+srv://")):
        return "mongodb"
    if database_url.startswith(("redis://", "rediss://")):
        return "redis"
    if database_url.startswith("sqlite://"):
        return "sqlite"
    return "sqlite"


__all__ = [
    "get_db_url",
    "get_alembic_config",
    "get_migrations_dir",
    "detect_db_type",
    "require_alembic",
    "is_default_db_url",
    "validate_database_url_string",
]
