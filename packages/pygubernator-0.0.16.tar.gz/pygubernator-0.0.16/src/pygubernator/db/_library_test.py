"""Repository helpers for LibraryTestJob entities."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import LibraryTestJob, LibraryTestJobEvent

__all__ = [
    "create_library_test_job",
    "get_library_test_job",
    "list_library_test_jobs",
    "create_library_test_job_event",
    "list_library_test_job_events",
]


def create_library_test_job(
    db: Session,
    *,
    workspace_id: str,
    name: str,
    spec_json: dict[str, Any],
    created_by: str,
    machine_name: str = "library_test_job",
    machine_version: str = "1.0.0",
    current_state: str = "queued",
) -> LibraryTestJob:
    rec = LibraryTestJob(
        workspace_id=workspace_id,
        name=name,
        spec_json=spec_json,
        created_by=created_by,
        machine_name=machine_name,
        machine_version=machine_version,
        current_state=current_state,
    )
    db.add(rec)
    return rec


def get_library_test_job(
    db: Session, job_id: str, *, workspace_id: str
) -> LibraryTestJob | None:
    return db.scalar(
        select(LibraryTestJob).where(
            LibraryTestJob.id == job_id,
            LibraryTestJob.workspace_id == workspace_id,
        )
    )


def list_library_test_jobs(
    db: Session,
    *,
    workspace_id: str,
    page: int = 1,
    page_size: int = 25,
    state: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
) -> tuple[list[LibraryTestJob], int]:
    q = select(LibraryTestJob).where(LibraryTestJob.workspace_id == workspace_id)
    cq = select(func.count(LibraryTestJob.id)).where(
        LibraryTestJob.workspace_id == workspace_id
    )
    if state:
        q = q.where(LibraryTestJob.current_state == state)
        cq = cq.where(LibraryTestJob.current_state == state)
    if created_from:
        q = q.where(LibraryTestJob.created_at >= created_from)
        cq = cq.where(LibraryTestJob.created_at >= created_from)
    if created_to:
        q = q.where(LibraryTestJob.created_at <= created_to)
        cq = cq.where(LibraryTestJob.created_at <= created_to)
    items = db.scalars(
        paginate(q.order_by(LibraryTestJob.created_at.desc()), page, page_size)
    ).all()
    total = int(db.scalar(cq) or 0)
    return items, total


def create_library_test_job_event(
    db: Session,
    *,
    workspace_id: str,
    job_id: str,
    trigger: str,
    actor: str,
    idempotency_key: str,
    payload_json: dict[str, Any] | None = None,
    workflow_run_id: str | None = None,
    from_state: str = "",
    to_state: str = "",
    success: bool = True,
    error_message: str | None = None,
) -> LibraryTestJobEvent:
    rec = LibraryTestJobEvent(
        workspace_id=workspace_id,
        job_id=job_id,
        trigger=trigger,
        actor=actor,
        idempotency_key=idempotency_key,
        workflow_run_id=workflow_run_id,
        payload_json=payload_json or {},
        from_state=from_state,
        to_state=to_state,
        success=1 if success else 0,
        error_message=error_message,
    )
    db.add(rec)
    return rec


def list_library_test_job_events(
    db: Session,
    job_id: str,
    *,
    workspace_id: str,
    page: int = 1,
    page_size: int = 200,
) -> tuple[list[LibraryTestJobEvent], int]:
    q = (
        select(LibraryTestJobEvent)
        .where(
            LibraryTestJobEvent.workspace_id == workspace_id,
            LibraryTestJobEvent.job_id == job_id,
        )
        .order_by(LibraryTestJobEvent.created_at.asc())
    )
    cq = select(func.count(LibraryTestJobEvent.id)).where(
        LibraryTestJobEvent.workspace_id == workspace_id,
        LibraryTestJobEvent.job_id == job_id,
    )
    items = db.scalars(paginate(q, page, page_size)).all()
    total = int(db.scalar(cq) or 0)
    return items, total
