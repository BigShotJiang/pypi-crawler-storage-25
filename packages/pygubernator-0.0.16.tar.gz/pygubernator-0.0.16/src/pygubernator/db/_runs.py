"""Repository helpers for Run, RunEvent, and ToolCall entities."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db._pagination import paginate
from pygubernator.db.models import Run, RunEvent, ToolCall

__all__ = [
    "create_run",
    "create_run_event",
    "create_tool_call",
    "get_run",
    "get_run_status_facets",
    "list_run_events",
    "list_runs_filtered",
    "list_tool_calls",
    "update_run",
]


def get_run(db: Session, run_id: str) -> Run | None:
    """Get a run by ID."""
    return db.get(Run, run_id)


def create_run(
    db: Session,
    *,
    agent_id: str,
    agent_version_id: str | None = None,
    status: str = "queued",
    correlation_id: str | None = None,
    trigger: str | None = None,
    metadata_json: dict[str, Any] | None = None,
) -> Run:
    """Create a new Run record.

    Args:
        db: SQLAlchemy session.
        agent_id: Agent that owns this run.
        agent_version_id: Optional agent version.
        status: Initial run status.
        correlation_id: Optional correlation ID.
        trigger: Optional trigger source.
        metadata_json: Optional metadata dict.

    Returns:
        The created Run.
    """
    run = Run(
        agent_id=agent_id,
        agent_version_id=agent_version_id,
        status=status,
        correlation_id=correlation_id,
        trigger=trigger,
        metadata_json=metadata_json or {},
    )
    db.add(run)
    return run


def update_run(
    db: Session,
    run: Run,
    **kwargs: Any,
) -> Run:
    """Update fields on an existing Run.

    Args:
        db: SQLAlchemy session.
        run: The Run to update.
        **kwargs: Field names and values to set.

    Returns:
        The updated Run.
    """
    for key, value in kwargs.items():
        if hasattr(run, key):
            setattr(run, key, value)
    return run


def list_runs_filtered(
    db: Session,
    *,
    page: int = 1,
    page_size: int = 25,
    status: str | None = None,
    agent_id: str | None = None,
    correlation_id: str | None = None,
    has_error: bool | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
    sort_by: str = "created_at",
    sort_order: str = "desc",
) -> tuple[list[Run], int]:
    """List runs with filtering, sorting, and pagination.

    Args:
        db: SQLAlchemy session.
        page: Page number (1-indexed).
        page_size: Results per page.
        status: Optional status filter.
        agent_id: Optional agent filter.
        correlation_id: Optional correlation ID filter.
        has_error: Optional error presence filter.
        created_from: Optional start date filter.
        created_to: Optional end date filter.
        sort_by: Column to sort by.
        sort_order: Sort direction ("asc" or "desc").

    Returns:
        Tuple of (runs, total_count).
    """
    query = select(Run)
    count_query = select(func.count(Run.id))

    if status:
        query = query.where(Run.status == status)
        count_query = count_query.where(Run.status == status)
    if agent_id:
        query = query.where(Run.agent_id == agent_id)
        count_query = count_query.where(Run.agent_id == agent_id)
    if correlation_id:
        query = query.where(Run.correlation_id == correlation_id)
        count_query = count_query.where(Run.correlation_id == correlation_id)
    if has_error is not None:
        if has_error:
            query = query.where(Run.error_message.is_not(None))
            count_query = count_query.where(Run.error_message.is_not(None))
        else:
            query = query.where(Run.error_message.is_(None))
            count_query = count_query.where(Run.error_message.is_(None))
    if created_from:
        query = query.where(Run.created_at >= created_from)
        count_query = count_query.where(Run.created_at >= created_from)
    if created_to:
        query = query.where(Run.created_at <= created_to)
        count_query = count_query.where(Run.created_at <= created_to)

    sort_column = {
        "created_at": Run.created_at,
        "duration_ms": Run.duration_ms,
        "cost_usd_micros": Run.cost_usd_micros,
    }.get(sort_by, Run.created_at)
    order_clause = sort_column.asc() if sort_order == "asc" else sort_column.desc()
    items = db.scalars(paginate(query.order_by(order_clause), page, page_size)).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def get_run_status_facets(db: Session) -> list[dict[str, int | str]]:
    """Get run counts grouped by status.

    Args:
        db: SQLAlchemy session.

    Returns:
        List of dicts with status and count keys.
    """
    rows = db.execute(select(Run.status, func.count(Run.id)).group_by(Run.status)).all()
    return [{"status": status, "count": int(count)} for status, count in rows]


def create_run_event(
    db: Session,
    *,
    run_id: str,
    event_type: str,
    level: str = "info",
    message: str | None = None,
    payload: dict[str, Any] | None = None,
) -> RunEvent:
    """Create a RunEvent record.

    Args:
        db: SQLAlchemy session.
        run_id: Parent run ID.
        event_type: Event type string.
        level: Severity level.
        message: Optional human-readable message.
        payload: Optional structured payload.

    Returns:
        The created RunEvent.
    """
    event = RunEvent(
        run_id=run_id,
        event_type=event_type,
        level=level,
        message=message,
        payload=payload or {},
    )
    db.add(event)
    return event


def list_run_events(
    db: Session,
    run_id: str,
    *,
    page: int = 1,
    page_size: int = 100,
) -> tuple[list[RunEvent], int]:
    """List events for a run.

    Args:
        db: SQLAlchemy session.
        run_id: The run to list events for.
        page: Page number.
        page_size: Results per page.

    Returns:
        Tuple of (events, total_count).
    """
    query = (
        select(RunEvent)
        .where(RunEvent.run_id == run_id)
        .order_by(RunEvent.created_at.asc())
    )
    count_query = select(func.count(RunEvent.id)).where(RunEvent.run_id == run_id)
    items = db.scalars(paginate(query, page, page_size)).all()
    total = int(db.scalar(count_query) or 0)
    return items, total


def create_tool_call(
    db: Session,
    *,
    run_id: str,
    tool_name: str,
    status: str = "completed",
    latency_ms: int | None = None,
    input_payload: dict[str, Any] | None = None,
    output_payload: dict[str, Any] | None = None,
    error_message: str | None = None,
) -> ToolCall:
    """Create a ToolCall record.

    Args:
        db: SQLAlchemy session.
        run_id: Parent run ID.
        tool_name: Name of the tool.
        status: Call status.
        latency_ms: Execution duration.
        input_payload: Tool input.
        output_payload: Tool output.
        error_message: Error if failed.

    Returns:
        The created ToolCall.
    """
    tc = ToolCall(
        run_id=run_id,
        tool_name=tool_name,
        status=status,
        latency_ms=latency_ms,
        input_payload=input_payload or {},
        output_payload=output_payload or {},
        error_message=error_message,
    )
    db.add(tc)
    return tc


def list_tool_calls(
    db: Session,
    run_id: str,
    *,
    page: int = 1,
    page_size: int = 100,
) -> tuple[list[ToolCall], int]:
    """List tool calls for a run.

    Args:
        db: SQLAlchemy session.
        run_id: The run to list tool calls for.
        page: Page number.
        page_size: Results per page.

    Returns:
        Tuple of (tool_calls, total_count).
    """
    query = (
        select(ToolCall)
        .where(ToolCall.run_id == run_id)
        .order_by(ToolCall.created_at.asc())
    )
    count_query = select(func.count(ToolCall.id)).where(ToolCall.run_id == run_id)
    items = db.scalars(paginate(query, page, page_size)).all()
    total = int(db.scalar(count_query) or 0)
    return items, total
