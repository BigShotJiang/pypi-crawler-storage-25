"""CLI commands for database management (pygubernator db init/upgrade/...).

Mirrors pystator's db/cli.py pattern.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

try:
    from alembic import command
    from sqlalchemy import create_engine, inspect, text

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False

from pygubernator.config.database import set_database_url
from pygubernator.db.base import get_engine
from pygubernator.db.config import (
    detect_db_type,
    get_alembic_config,
    get_db_url,
    get_migrations_dir,
    require_alembic,
)


# -------------------------------------------------------------------
# Command functions
# -------------------------------------------------------------------
def cmd_init(
    database_url: str | None = None,
    db_type: str | None = None,
    force: bool = False,
) -> int:
    """Initialize the database schema from scratch."""
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        db_type = db_type or detect_db_type(db_url)
        if db_type == "sqlite":
            return _init_sqlite(db_url, force)
        return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_sqlite(database_url: str, force: bool = False) -> int:
    """Initialize SQLite database."""
    require_alembic()

    try:
        db_path = (
            database_url[10:] if database_url.startswith("sqlite:///") else database_url
        )
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        engine = get_engine(database_url)
        existing_tables = inspect(engine).get_table_names()

        if existing_tables and not force:
            print(f"Warning: Database already contains {len(existing_tables)} tables.")
            print(
                "   Use --force to reinitialize, or run "
                "'pygubernator db upgrade' to apply migrations."
            )
            return 1

        if existing_tables and force:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for name in existing_tables:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
                conn.execute(text("PRAGMA foreign_keys=ON"))
                conn.commit()
            print("Dropped existing tables")

        versions_dir = get_migrations_dir() / "versions"
        if not versions_dir.exists() or not any(versions_dir.iterdir()):
            print(
                "No migrations found. Add Alembic migration files "
                "under db/migrations/versions/ and run again."
            )
            return 1

        set_database_url(database_url)
        config = get_alembic_config(database_url)
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("Migrations complete")
        print("SQLite initialization complete!")
        return 0
    except Exception as e:
        print(f"Error initializing SQLite: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """Initialize PostgreSQL database."""
    require_alembic()

    try:
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        engine = create_engine(database_url)

        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pygubernator"'))
            conn.commit()
        print("Created 'pygubernator' schema (if it didn't exist)")

        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("Database initialized successfully!")
        return 0
    except Exception as e:
        print(f"Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_upgrade(
    database_url: str | None = None,
    revision: str = "head",
) -> int:
    """Upgrade database to the latest revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)
        print("Database upgraded successfully!")
        return 0
    except Exception as e:
        print(f"Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(
    database_url: str | None = None,
    revision: str = "-1",
) -> int:
    """Downgrade database to a previous revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)
        print("Database downgraded successfully!")
        return 0
    except Exception as e:
        print(f"Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: str | None = None) -> int:
    """Show current database revision."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        with engine.connect() as connection:
            try:
                if is_postgres:
                    result = connection.execute(
                        text(
                            "SELECT version_num "
                            'FROM "pygubernator".alembic_version '
                            "LIMIT 1"
                        )
                    )
                else:
                    result = connection.execute(
                        text("SELECT version_num FROM alembic_version LIMIT 1")
                    )
                version = result.fetchone()
                if version:
                    print(f"Current database revision: {version[0]}")
                    return 0
            except Exception:
                pass

            from alembic.runtime.migration import MigrationContext

            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            if current_rev:
                print(f"Current database revision: {current_rev}")
                return 0

        print("Database is not initialized. Run 'pygubernator db init' first.")
        return 1
    except Exception as e:
        print(f"Error getting current revision: {e}")
        return 1


def cmd_history(database_url: str | None = None) -> int:
    """Show migration history."""
    require_alembic()

    try:
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config()
        command.history(config)
        return 0
    except Exception as e:
        print(f"Error showing history: {e}")
        return 1


def cmd_stamp(
    database_url: str | None = None,
    revision: str = "head",
) -> int:
    """Stamp database with a revision without running migrations."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)
        print(f"Database stamped at {revision}")
        return 0
    except Exception as e:
        print(f"Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_seed(
    seed_dir: str | None = None,
    database_url: str | None = None,
) -> int:
    """Seed the database with example workflow definitions."""
    try:
        # Handle swapped arguments
        if seed_dir and any(
            seed_dir.startswith(prefix)
            for prefix in (
                "postgresql://",
                "postgres://",
                "sqlite://",
            )
        ):
            database_url, seed_dir = seed_dir, None

        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        upgrade_rc = cmd_upgrade(database_url)
        if upgrade_rc != 0:
            return upgrade_rc

        from pygubernator.db.seed import seed_all

        seed_path = Path(seed_dir) if seed_dir else None

        if seed_path is not None and not seed_path.exists():
            print(f"Error: Seed directory not found: {seed_path}")
            return 1

        stats = seed_all(db_url=db_url, seed_dir=seed_path)
        total = stats.created + stats.skipped
        print(f"Loaded {total} workflow version seed item(s)")
        print(f"  created: {stats.created}")
        print(f"  skipped: {stats.skipped}")
        print(f"  invalid: {stats.invalid}")
        print("\nSeed data loaded successfully!")
        return 0
    except Exception as e:
        print(f"Error seeding database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _seed_workflows(seed_path: Path, db_url: str) -> int:
    """Back-compat wrapper for tests and external imports."""
    from pygubernator.db.seed import seed_workflows_from_directory

    seed_workflows_from_directory(seed_path, db_url)
    return 0


def cmd_truncate(
    database_url: str | None = None,
    force: bool = False,
) -> int:
    """Truncate all pygubernator database tables."""
    require_alembic()

    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        if is_postgres:
            inspector = inspect(engine)
            existing_tables = set(inspector.get_table_names(schema="pygubernator"))
        else:
            existing_tables = set(inspect(engine).get_table_names())

        # Tables in FK-safe drop order
        tables = [
            "workflow_step_runs",
            "workflow_runs",
            "workflow_versions",
            "workflows",
            "incidents",
            "audit_logs",
            "alerts",
            "policy_assignments",
            "tool_calls",
            "run_events",
            "runs",
            "agent_versions",
            "agents",
        ]
        to_truncate = [t for t in tables if t in existing_tables]

        if not to_truncate:
            print("No pygubernator tables found to truncate.")
            return 0

        print(f"\nWARNING: This will truncate {len(to_truncate)} table(s):")
        print(f"   {', '.join(to_truncate)}")
        print("\nALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")

        if not force:
            try:
                confirmation = input("\nType 'yes' to confirm: ").strip().lower()
                if confirmation not in ["yes", "y"]:
                    print("Truncate cancelled.")
                    return 1
            except (EOFError, KeyboardInterrupt):
                print("\nTruncate cancelled.")
                return 1

        with engine.begin() as conn:
            if is_postgres:
                conn.execute(text("SET session_replication_role = 'replica'"))
                for table in to_truncate:
                    conn.execute(text(f'TRUNCATE TABLE pygubernator."{table}" CASCADE'))
                    print(f"  Truncated {table}")
                conn.execute(text("SET session_replication_role = 'origin'"))
            else:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for table in to_truncate:
                    conn.execute(text(f'DELETE FROM "{table}"'))
                    print(f"  Truncated {table}")
                conn.execute(text("PRAGMA foreign_keys=ON"))

        print("\nSuccessfully truncated all pygubernator tables!")
        return 0
    except Exception as e:
        print(f"Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def main() -> int:
    """Main CLI entry point for pygubernator db commands."""
    parser = argparse.ArgumentParser(
        description="PyGubernator database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # init
    init_p = subparsers.add_parser(
        "init",
        help="Initialize database schema from scratch",
        epilog=(
            "`db init` and `db upgrade` are separate commands. "
            "Do not run `db init upgrade`; use `db upgrade` to apply migrations."
        ),
    )
    init_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (defaults to sqlite:///pygubernator.db)",
    )
    init_p.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "sqlite"],
        default=None,
        help="Database type (auto-detected from URL if omitted)",
    )
    init_p.add_argument(
        "--force",
        action="store_true",
        help="Proceed even if already initialized",
    )

    # upgrade
    upgrade_p = subparsers.add_parser(
        "upgrade", help="Upgrade database to latest revision"
    )
    upgrade_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )
    upgrade_p.add_argument("--revision", default="head", help="Target revision")

    # downgrade
    downgrade_p = subparsers.add_parser("downgrade", help="Downgrade database")
    downgrade_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )
    downgrade_p.add_argument("--revision", default="-1", help="Target revision")

    # current
    current_p = subparsers.add_parser("current", help="Show current database revision")
    current_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )

    # history
    history_p = subparsers.add_parser("history", help="Show migration history")
    history_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )

    # stamp
    stamp_p = subparsers.add_parser(
        "stamp",
        help="Stamp database with revision without running migrations",
    )
    stamp_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )
    stamp_p.add_argument("--revision", default="head", help="Revision to stamp")

    # seed
    seed_p = subparsers.add_parser("seed", help="Seed database with example workflows")
    seed_p.add_argument(
        "seed_dir",
        nargs="?",
        help="Directory with seed YAML files",
    )
    seed_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )

    # truncate
    truncate_p = subparsers.add_parser("truncate", help="Truncate all tables")
    truncate_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string",
    )
    truncate_p.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands: dict[str, Any] = {
        "init": lambda: cmd_init(
            args.database_url,
            db_type=args.db_type,
            force=args.force,
        ),
        "upgrade": lambda: cmd_upgrade(args.database_url, args.revision),
        "downgrade": lambda: cmd_downgrade(args.database_url, args.revision),
        "current": lambda: cmd_current(args.database_url),
        "history": lambda: cmd_history(args.database_url),
        "stamp": lambda: cmd_stamp(args.database_url, args.revision),
        "seed": lambda: cmd_seed(args.seed_dir, args.database_url),
        "truncate": lambda: cmd_truncate(args.database_url, force=args.force),
    }

    handler = commands.get(args.command, lambda: (parser.print_help(), 1)[1])
    return handler()


if __name__ == "__main__":
    sys.exit(main())
