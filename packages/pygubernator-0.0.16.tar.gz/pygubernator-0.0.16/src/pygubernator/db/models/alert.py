"""Alert rule and incident models."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    ForeignKey,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class AlertRule(Base):
    """Alert rule definition."""

    __tablename__ = "alerts"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    name: Mapped[str] = mapped_column(String(120), unique=True)
    severity: Mapped[str] = mapped_column(String(16), default="warning")
    condition: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


class Incident(Base):
    """Alert incident."""

    __tablename__ = "incidents"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    run_id: Mapped[str | None] = mapped_column(
        ForeignKey(f"{_SCHEMA}.runs.id"),
        nullable=True,
        index=True,
    )
    alert_id: Mapped[str | None] = mapped_column(
        ForeignKey(f"{_SCHEMA}.alerts.id"),
        nullable=True,
        index=True,
    )
    title: Mapped[str] = mapped_column(String(240))
    severity: Mapped[str] = mapped_column(String(16), default="warning", index=True)
    status: Mapped[str] = mapped_column(String(24), default="open", index=True)
    owner: Mapped[str | None] = mapped_column(String(120), nullable=True, index=True)
    acknowledged_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    silenced_until: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        index=True,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["AlertRule", "Incident"]
