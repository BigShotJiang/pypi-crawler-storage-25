"""Knowledge-base chunk model.

One row per embedded text chunk. The ``embedding`` column stores the
raw float32 bytes of the vector so workspace-local SQLite deployments
can do a vectorised cosine scan in numpy without any extension or
external dependency. Postgres deployments use the same bytes column
(BYTEA) and can add a ``pgvector`` index later without a data
migration.

See :class:`pygubernator.memory._vector_store.SqliteVectorStore` for
the reader/writer that operates on this table.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import LargeBinary

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class KBChunk(Base):
    """Persisted knowledge-base chunk with its embedding + bindings.

    Attributes:
        id: UUID primary key.
        scope: Pipe-delimited :class:`MemoryScope.to_key()` output.
        agent_id / workflow_id / run_id: Scope parts indexed for
            filtering without parsing the ``scope`` string.
        source_uri: Optional origin URL / file path for provenance.
        contract_id: Optional pycharter contract id this chunk conforms
            to (for ontology binding).
        concept_refs: List[str] of pycharter concept ids this chunk
            binds to. Stored as JSON so operators can search by concept.
        binding_state: One of ``unmapped``, ``suggested``, ``mapped``,
            ``approved`` — mirrors pycharter's ``MappingManager``
            lifecycle.
        embedding_dim: Dimensionality of the stored vector (e.g. 1536).
        embedding: Raw float32 bytes (little-endian).
        text: The chunk text.
        metadata_: Free-form metadata (ordinal, char offsets, etc.).
        created_at: UTC insert timestamp.
    """

    __tablename__ = "kb_chunks"
    __table_args__ = (
        Index("ix_kb_chunks_scope_created", "scope", "created_at"),
        Index("ix_kb_chunks_contract", "contract_id"),
        Index("ix_kb_chunks_agent_id", "agent_id"),
        Index("ix_kb_chunks_workflow_id", "workflow_id"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    scope: Mapped[str] = mapped_column(String(256))
    agent_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    workflow_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    run_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    source_uri: Mapped[str | None] = mapped_column(Text, nullable=True)
    contract_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    concept_refs: Mapped[list[str]] = mapped_column(JSON, default=list)
    binding_state: Mapped[str] = mapped_column(String(16), default="unmapped")
    embedding_dim: Mapped[int] = mapped_column(Integer)
    embedding: Mapped[bytes] = mapped_column(LargeBinary)
    text: Mapped[str] = mapped_column(Text)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
    )


__all__ = ["KBChunk"]
