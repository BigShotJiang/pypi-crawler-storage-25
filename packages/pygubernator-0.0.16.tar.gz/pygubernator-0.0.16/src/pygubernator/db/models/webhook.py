"""Webhook trigger model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    Base,
    Boolean,
    DateTime,
    Integer,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class WebhookTrigger(Base):
    """Inbound webhook that triggers a workflow."""

    __tablename__ = "webhook_triggers"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_id: Mapped[str] = mapped_column(String(36), index=True)
    name: Mapped[str] = mapped_column(String(120), default="")
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_triggered_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    trigger_count: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["WebhookTrigger"]
