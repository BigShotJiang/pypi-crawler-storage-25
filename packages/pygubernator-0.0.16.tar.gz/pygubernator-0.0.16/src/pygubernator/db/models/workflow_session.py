"""Workflow session metadata model (Phase 6 §6.8b).

Sessions are an existing concept — ``workflow_runs.session_id`` ties
multi-turn conversations together — but they had no metadata of their
own, so the UI could only display the raw id. This module adds a
sibling table to store user-supplied display data (name, notes…) keyed
by ``session_id``. Run rows are unchanged; this is pure additive
metadata that the sessions sidebar joins against to surface a friendly
name next to each session.
"""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    Base,
    DateTime,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
)


class WorkflowSession(Base):
    """User-supplied metadata for a multi-turn workflow session.

    The primary key is ``session_id`` itself — sessions are identified
    by the same opaque id workflow runs already carry, so a JOIN in
    the sessions list route is enough to surface the friendly name.
    Inserts are upsert-safe: callers always look up by session_id and
    overwrite the row when the user renames.
    """

    __tablename__ = "workflow_sessions"
    __table_args__ = ({"schema": _SCHEMA},)

    session_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str | None] = mapped_column(String(240), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


__all__ = ["WorkflowSession"]
