"""Workflow session summary model (Phase 6 §6.10).

Closes the narrator-pattern gap: long-running multi-turn sessions
accumulate too many runs to read at a glance. A summary is a
narrative paragraph (or bullet list) generated *about* a session —
"yesterday's overnight session ran 8 ETL pipelines, 1 failed". The
summary doesn't replace the runs themselves; it sits next to them so
operators can scan a long history without opening every run.

Summaries are content-only by design: any caller (a scheduled
narrator agent, a manual ``POST``, a UI "Summarise" button) can write
one. The table records who or what produced it (``generated_by``),
how (``model``), and when. The narrator agent that auto-creates
summaries on a schedule is a v1.1 follow-up — this PR ships the
storage + read surface so the agent (when it lands) has somewhere
to write.
"""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    Base,
    DateTime,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class WorkflowSessionSummary(Base):
    """A narrative summary of a session's activity.

    Many summaries can exist per ``session_id`` — typically one per
    schedule tick, or one per manual user request — so the primary key
    is a fresh UUID. Sorting by ``generated_at`` gives the natural
    "most recent summary first" feed.
    """

    __tablename__ = "workflow_session_summaries"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    session_id: Mapped[str] = mapped_column(String(36), index=True)
    content: Mapped[str] = mapped_column(Text)
    generated_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    model: Mapped[str | None] = mapped_column(String(120), nullable=True)
    generated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, index=True
    )


__all__ = ["WorkflowSessionSummary"]
