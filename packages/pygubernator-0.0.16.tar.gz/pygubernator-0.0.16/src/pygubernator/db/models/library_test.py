"""Library testing (LibraryTestJob) models.

Phase 1: single-tenant via workspace_id='default', but tenant-ready by design.
"""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    relationship,
    uuid,
)


class LibraryTestJob(Base):
    """A lifecycle-native entity for library/module testing workflows."""

    __tablename__ = "library_test_jobs"
    __table_args__ = (
        Index("ix_library_test_jobs_workspace_state", "workspace_id", "current_state"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )

    # Lifecycle
    machine_name: Mapped[str] = mapped_column(String(120), default="library_test_job")
    machine_version: Mapped[str] = mapped_column(String(64), default="1.0.0")
    current_state: Mapped[str] = mapped_column(String(64), default="queued", index=True)

    # User input / spec
    name: Mapped[str] = mapped_column(String(255), default="")
    spec_json: Mapped[dict] = mapped_column(JSON, default=dict)

    # Execution pointers (best-effort convenience)
    last_workflow_run_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True, index=True
    )
    last_error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Audit
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, index=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )

    events: Mapped[list[LibraryTestJobEvent]] = relationship(
        back_populates="job", cascade="all, delete-orphan"
    )


class LibraryTestJobEvent(Base):
    """Append-only event stream for LibraryTestJob lifecycle transitions."""

    __tablename__ = "library_test_job_events"
    __table_args__ = (
        Index(
            "ix_library_test_job_events_ws_job_time",
            "workspace_id",
            "job_id",
            "created_at",
        ),
        Index(
            "ix_library_test_job_events_idempotency",
            "workspace_id",
            "job_id",
            "idempotency_key",
            unique=True,
        ),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )
    job_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.library_test_jobs.id"),
        index=True,
    )

    trigger: Mapped[str] = mapped_column(String(64), index=True)
    actor: Mapped[str] = mapped_column(String(120), default="system")
    idempotency_key: Mapped[str] = mapped_column(String(120), default="")

    # Optional linkage for tracing
    workflow_run_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True, index=True
    )

    payload_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, index=True
    )

    # Lightweight derived info for UI/debug (denormalized)
    from_state: Mapped[str] = mapped_column(String(64), default="")
    to_state: Mapped[str] = mapped_column(String(64), default="")
    success: Mapped[int] = mapped_column(Integer, default=1)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    job: Mapped[LibraryTestJob] = relationship(back_populates="events")


__all__ = ["LibraryTestJob", "LibraryTestJobEvent"]
