"""Shared utilities for database models."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pygubernator.db.base import Base

_SCHEMA = "pygubernator"


def _utcnow() -> datetime:
    """Return the current UTC time."""
    return datetime.now(UTC)


__all__ = [
    "JSON",
    "Base",
    "Boolean",
    "DateTime",
    "Float",
    "ForeignKey",
    "Index",
    "Integer",
    "Mapped",
    "String",
    "Text",
    "_SCHEMA",
    "_utcnow",
    "mapped_column",
    "relationship",
    "uuid",
]
