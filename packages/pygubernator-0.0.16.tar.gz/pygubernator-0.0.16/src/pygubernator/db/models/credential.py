"""Integration credential model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    Base,
    Boolean,
    DateTime,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class IntegrationCredential(Base):
    """Stored integration credential for tool factories."""

    __tablename__ = "integration_credentials"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    provider: Mapped[str] = mapped_column(String(64), index=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    env_var: Mapped[str] = mapped_column(String(120))
    encrypted_value: Mapped[str] = mapped_column(Text)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["IntegrationCredential"]
