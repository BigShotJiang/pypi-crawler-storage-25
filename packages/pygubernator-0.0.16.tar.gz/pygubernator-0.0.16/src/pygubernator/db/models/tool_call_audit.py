"""Tool-call audit record model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Integer,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class ToolCallAudit(Base):
    """Per-tool-call audit entry.

    Captures every ``ToolRegistry.execute`` invocation: parameters,
    output, duration, and the policy decision. Parameters and output
    are passed through the ``SecretRedactor`` before persistence.
    """

    __tablename__ = "tool_call_audit"
    __table_args__ = (
        Index("ix_tool_call_audit_run_id", "run_id"),
        Index("ix_tool_call_audit_agent_id", "agent_id"),
        Index("ix_tool_call_audit_tool_created", "tool_name", "created_at"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    run_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    agent_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    workflow_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tool_name: Mapped[str] = mapped_column(String(120))
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    output: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(32), index=True)
    policy_decision: Mapped[str] = mapped_column(String(32))
    policy_reason: Mapped[str | None] = mapped_column(String(512), nullable=True)
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
    )


__all__ = ["ToolCallAudit"]
