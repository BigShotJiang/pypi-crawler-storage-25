"""Policy assignment model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class PolicyAssignment(Base):
    """Policy enforcement assignment.

    Scope indicates what the policy binds to:

    - ``agent``: applies to a single agent (``agent_id`` set).
    - ``workflow``: applies to all agents within a workflow
      (``workflow_id`` set).
    - ``global``: applies to every execution; both scope ids may be null.

    Higher ``priority`` values override lower ones when multiple
    assignments match. See ``pygubernator.policy`` for the enforcer.
    """

    __tablename__ = "policy_assignments"
    __table_args__ = (
        Index("ix_policy_assignments_scope_priority", "scope", "priority"),
        Index("ix_policy_assignments_workflow_id", "workflow_id"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    agent_id: Mapped[str | None] = mapped_column(
        ForeignKey(f"{_SCHEMA}.agents.id"),
        index=True,
        nullable=True,
    )
    workflow_id: Mapped[str | None] = mapped_column(
        String(64), index=True, nullable=True
    )
    scope: Mapped[str] = mapped_column(String(32), default="agent", index=True)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    policy_type: Mapped[str] = mapped_column(String(64), index=True)
    policy_value: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["PolicyAssignment"]
