"""Workflow run and workflow step run models."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class WorkflowRun(Base):
    """Execution record for a workflow run."""

    __tablename__ = "workflow_runs"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflows.id"), index=True
    )
    workflow_version_id: Mapped[str | None] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_versions.id"),
        nullable=True,
    )
    status: Mapped[str] = mapped_column(String(32), default="pending", index=True)
    input_json: Mapped[dict] = mapped_column(JSON, default=dict)
    output_json: Mapped[dict] = mapped_column(JSON, default=dict)
    variables_json: Mapped[dict] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    session_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True, index=True
    )
    claimed_by: Mapped[str | None] = mapped_column(
        String(120), nullable=True, index=True
    )
    heartbeat_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    checkpoint_json: Mapped[dict] = mapped_column(JSON, default=dict)
    trigger: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    correlation_id: Mapped[str | None] = mapped_column(
        String(120), nullable=True, index=True
    )


class WorkflowStepRun(Base):
    """Per-node execution record within a workflow run."""

    __tablename__ = "workflow_step_runs"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_run_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_runs.id"),
        index=True,
    )
    node_id: Mapped[str] = mapped_column(String(120))
    node_type: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32), default="pending")
    input_json: Mapped[dict] = mapped_column(JSON, default=dict)
    output_json: Mapped[dict] = mapped_column(JSON, default=dict)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    output_handle: Mapped[str] = mapped_column(String(64), default="default")
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)


class WorkflowStepEvent(Base):
    """Tool-call / LLM event emitted inside a workflow step.

    Scale-gated split of ``WorkflowStepRun.output_json["_child_events"]``:
    the same data the UI reads today from the blob is *also* persisted
    here as structured rows, so downstream code can filter or aggregate
    without parsing JSON. Writes are kept in parity during the cut-over;
    once every reader uses this table the blob entry will be removed.
    """

    __tablename__ = "workflow_step_events"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    step_run_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_step_runs.id"),
        index=True,
    )
    workflow_run_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_runs.id"),
        index=True,
    )
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    sequence_num: Mapped[int] = mapped_column(Integer)
    event_timestamp: Mapped[float] = mapped_column(Float)
    payload_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )


__all__ = ["WorkflowRun", "WorkflowStepEvent", "WorkflowStepRun"]
