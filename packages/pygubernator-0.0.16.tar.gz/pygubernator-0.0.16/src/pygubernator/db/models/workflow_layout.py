"""Workflow diagram layout positions (stored separately from spec).

Positions are visual/presentation data and do not belong in the
workflow spec.  This mirrors pystator's WorkspaceLayoutModel pattern.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, Float, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pygubernator.db.base import Base


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class WorkflowLayoutModel(Base):
    """Per-node diagram position for the workflow editor.

    Positions are visual/presentation data and are stored
    separately from the workflow spec (which is a pure DAG).
    """

    __tablename__ = "workflow_layouts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    workflow_id = Column(String(255), nullable=False, index=True)
    workflow_version = Column(String(50), nullable=False, index=True)
    node_id = Column(String(255), nullable=False, index=True)

    position_x = Column(Float, nullable=False, default=0.0)
    position_y = Column(Float, nullable=False, default=0.0)

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "workflow_id",
            "workflow_version",
            "node_id",
            name="uq_workflow_layouts_wf_version_node",
        ),
        {"schema": "pygubernator"},
    )
