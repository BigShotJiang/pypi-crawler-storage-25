"""Generic append-only record table backing SqlAlchemyRecordStore."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class GenericRecord(Base):
    """Catch-all append-only record row.

    Stores entries from any ``RecordStore`` kind. Strongly-typed
    subsystems (tool-call audit, memory audit, heartbeats) use their
    own tables; this one is the fallback.
    """

    __tablename__ = "generic_records"
    __table_args__ = (
        Index("ix_generic_records_kind_created_at", "kind", "created_at"),
        Index("ix_generic_records_kind_scope", "kind", "scope"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    kind: Mapped[str] = mapped_column(String(64))
    scope: Mapped[str | None] = mapped_column(String(128), nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
    )


__all__ = ["GenericRecord"]
