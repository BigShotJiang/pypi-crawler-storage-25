"""Memory-access audit record model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class MemoryAccessAudit(Base):
    """Per-memory-access audit entry.

    One row per read/write/delete against a scoped memory store.
    Used to trace which agent touched which memory scope and when.
    """

    __tablename__ = "memory_access_audit"
    __table_args__ = (
        Index("ix_memory_access_scope_created", "scope", "created_at"),
        Index("ix_memory_access_agent_id", "agent_id"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    scope: Mapped[str] = mapped_column(String(256))
    agent_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    run_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    operation: Mapped[str] = mapped_column(String(32), index=True)
    key: Mapped[str | None] = mapped_column(String(256), nullable=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
    )


__all__ = ["MemoryAccessAudit"]
