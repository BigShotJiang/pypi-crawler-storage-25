"""Notification rule model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class NotificationRule(Base):
    """Rule for automatic notifications on workflow events."""

    __tablename__ = "notification_rules"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    name: Mapped[str] = mapped_column(String(120))
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )
    event_type: Mapped[str] = mapped_column(String(64))
    channel_type: Mapped[str] = mapped_column(String(32))
    channel_config: Mapped[dict] = mapped_column(JSON, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )


__all__ = ["NotificationRule"]
