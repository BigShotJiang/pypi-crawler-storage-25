"""Workflow approval model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class WorkflowApproval(Base):
    """Pending or resolved workflow approval request."""

    __tablename__ = "workflow_approvals"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_run_id: Mapped[str] = mapped_column(String(36), index=True)
    node_id: Mapped[str] = mapped_column(String(120))
    prompt: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="pending")
    checkpoint_json: Mapped[dict] = mapped_column(JSON, default=dict)
    response_json: Mapped[dict] = mapped_column(JSON, default=dict)
    responded_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=86400)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    responded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


__all__ = ["WorkflowApproval"]
