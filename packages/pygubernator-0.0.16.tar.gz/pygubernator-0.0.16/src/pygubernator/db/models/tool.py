"""Tool and tool version models."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    relationship,
    uuid,
)


class Tool(Base):
    """First-class tool definition."""

    __tablename__ = "tools"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    name: Mapped[str] = mapped_column(String(120), index=True, unique=True)
    description: Mapped[str] = mapped_column(Text, default="")
    owner: Mapped[str] = mapped_column(String(120), default="system")
    status: Mapped[str] = mapped_column(String(32), default="active")
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    workspace_id: Mapped[str] = mapped_column(
        String(36),
        index=True,
        default="default",
    )
    current_version_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
        onupdate=_utcnow,
    )
    versions: Mapped[list[ToolVersion]] = relationship(back_populates="tool")


class ToolVersion(Base):
    """Versioned tool specification."""

    __tablename__ = "tool_versions"
    __table_args__ = (
        Index(
            "ix_tool_version_unique",
            "tool_id",
            "version",
            unique=True,
        ),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    tool_id: Mapped[str] = mapped_column(ForeignKey(f"{_SCHEMA}.tools.id"), index=True)
    version: Mapped[str] = mapped_column(String(64))
    revision: Mapped[int] = mapped_column(Integer, default=1)
    spec_json: Mapped[dict] = mapped_column(JSON, default=dict)
    active: Mapped[bool] = mapped_column(Boolean, default=False)
    published: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    tool: Mapped[Tool] = relationship(back_populates="versions")


__all__ = ["Tool", "ToolVersion"]
