"""Agent heartbeat record model."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class AgentHeartbeat(Base):
    """Heartbeat emitted by a long-running agent or workflow run.

    Stored in an append-only table; stale detection is performed by
    comparing the most recent row for each (agent_id, run_id) pair
    against a configurable threshold.
    """

    __tablename__ = "agent_heartbeats"
    __table_args__ = (
        Index("ix_agent_heartbeats_agent_id", "agent_id"),
        Index("ix_agent_heartbeats_run_id", "run_id"),
        Index("ix_agent_heartbeats_created", "created_at"),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    agent_id: Mapped[str] = mapped_column(String(64))
    run_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    workflow_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="live", index=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=_utcnow,
    )


__all__ = ["AgentHeartbeat"]
