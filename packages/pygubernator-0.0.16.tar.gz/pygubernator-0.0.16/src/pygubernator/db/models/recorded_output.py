"""Recorded outputs for deterministic replay."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    JSON,
    Base,
    DateTime,
    Index,
    Mapped,
    String,
    _utcnow,
    mapped_column,
    uuid,
)


class RecordedOutput(Base):
    """Recorded node output for deterministic replay."""

    __tablename__ = "recorded_outputs"
    __table_args__ = (
        Index(
            "ix_recorded_outputs_unique",
            "workspace_id",
            "workflow_run_id",
            "node_id",
            unique=True,
        ),
        {"schema": _SCHEMA},
    )

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workspace_id: Mapped[str] = mapped_column(String(36), index=True, default="default")
    workflow_run_id: Mapped[str] = mapped_column(String(36), index=True)
    node_id: Mapped[str] = mapped_column(String(120), index=True)
    payload_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, index=True
    )


__all__ = ["RecordedOutput"]
