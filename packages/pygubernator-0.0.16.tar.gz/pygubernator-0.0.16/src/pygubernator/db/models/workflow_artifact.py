"""Workflow artifact model (run-level or step-level output surface)."""

from __future__ import annotations

from datetime import datetime

from pygubernator.db.models._common import (
    _SCHEMA,
    Base,
    DateTime,
    ForeignKey,
    Integer,
    Mapped,
    String,
    Text,
    _utcnow,
    mapped_column,
    uuid,
)


class WorkflowArtifact(Base):
    """A named output surface produced during (or after) a workflow run.

    Artifacts are the first-class way for node handlers and tools to
    publish structured results — a rendered Markdown report, a CSV table,
    a sandboxed HTML preview, an image, a Jupyter notebook, a JSON blob —
    so the UI can mount a dedicated viewer instead of shoehorning the
    payload into the free-form ``output_json`` blob.

    Inline content lives in ``content_text`` when it fits (Markdown, CSV,
    JSON, text). Larger or binary content lives on disk / object storage
    and is referenced via ``source_path``; the content route streams from
    whichever field is populated. ``sequence_num`` orders artifacts within
    a run so the UI can render them in emission order without relying on
    float timestamps. ``step_run_id`` is nullable so callers can emit
    run-level artifacts (e.g. a final summary) that aren't tied to a
    single node execution.
    """

    __tablename__ = "workflow_artifacts"
    __table_args__ = ({"schema": _SCHEMA},)

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )
    workflow_run_id: Mapped[str] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_runs.id"),
        index=True,
    )
    step_run_id: Mapped[str | None] = mapped_column(
        ForeignKey(f"{_SCHEMA}.workflow_step_runs.id"),
        nullable=True,
        index=True,
    )
    artifact_type: Mapped[str] = mapped_column(String(32), index=True)
    title: Mapped[str | None] = mapped_column(String(240), nullable=True)
    mime: Mapped[str | None] = mapped_column(String(120), nullable=True)
    content_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    sequence_num: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


__all__ = ["WorkflowArtifact"]
