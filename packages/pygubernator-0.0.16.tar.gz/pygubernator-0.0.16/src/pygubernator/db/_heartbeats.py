"""Repository helpers for :class:`AgentHeartbeat` queries.

The append-only ``agent_heartbeats`` table stores one row per emitted
beat. For fleet-health views the useful question is "what's the latest
beat for each agent?" — that's what :func:`list_latest_heartbeats`
answers with a single portable SQL query (SQLite + PostgreSQL).
"""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from pygubernator.db.models import AgentHeartbeat

__all__ = ["list_latest_heartbeats"]


def list_latest_heartbeats(
    db: Session,
    *,
    agent_id: str | None = None,
) -> list[AgentHeartbeat]:
    """Return the most recent heartbeat row per distinct ``agent_id``.

    The query uses a ``GROUP BY agent_id, MAX(created_at)`` self-join
    which runs identically on SQLite and PostgreSQL (no window functions
    required). When two rows share the same ``created_at`` we keep the
    first observed in the result set so callers never see duplicates.

    Args:
        db: SQLAlchemy session.
        agent_id: When provided, restrict to just this agent (at most
            one row returned).

    Returns:
        Rows sorted by ``created_at`` descending — newest beat first.
    """
    latest_ts = select(
        AgentHeartbeat.agent_id,
        func.max(AgentHeartbeat.created_at).label("max_ts"),
    ).group_by(AgentHeartbeat.agent_id)
    if agent_id is not None:
        latest_ts = latest_ts.where(AgentHeartbeat.agent_id == agent_id)
    latest_ts_sq = latest_ts.subquery()

    rows = list(
        db.scalars(
            select(AgentHeartbeat).join(
                latest_ts_sq,
                (AgentHeartbeat.agent_id == latest_ts_sq.c.agent_id)
                & (AgentHeartbeat.created_at == latest_ts_sq.c.max_ts),
            )
        ).all()
    )

    # De-dup in case two rows for the same agent share the MAX timestamp
    # (rare but the table permits it). Keep the first row observed.
    seen: dict[str, AgentHeartbeat] = {}
    for row in rows:
        seen.setdefault(row.agent_id, row)
    return sorted(seen.values(), key=lambda r: r.created_at, reverse=True)
