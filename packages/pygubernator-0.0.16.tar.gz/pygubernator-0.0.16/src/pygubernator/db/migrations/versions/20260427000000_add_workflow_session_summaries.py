"""Workflow session summaries table (Phase 6 §6.10).

Backs the narrator-pattern feature: long sessions accumulate too many
runs to read at a glance, so summaries (paragraphs about a session)
sit alongside them. Many summaries can exist per session — typically
one per schedule tick — so this is a fresh-id table indexed on
``session_id`` + ``generated_at`` for the natural "latest summary
first" feed.

Revision ID: 20260427000000
Revises: 20260426000000
Create Date: 2026-04-27 00:00:00.000000
"""

from __future__ import annotations

import contextlib

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260427000000"
down_revision = "20260426000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    return inspector.has_table(table, schema=schema)


def _index_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    try:
        return {idx["name"] for idx in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str,
    table: str,
    columns: list[str],
    schema: str | None,
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, schema=schema)


def upgrade() -> None:
    """Create ``workflow_session_summaries`` + its lookup indexes."""
    schema = _schema()
    if not _has_table("workflow_session_summaries", schema):
        op.create_table(
            "workflow_session_summaries",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("session_id", sa.String(36), nullable=False),
            sa.Column("content", sa.Text(), nullable=False),
            sa.Column("generated_by", sa.String(120), nullable=True),
            sa.Column("model", sa.String(120), nullable=True),
            sa.Column(
                "generated_at",
                sa.DateTime(timezone=True),
                nullable=False,
            ),
            schema=schema,
        )
    _create_index(
        "ix_wss_session_id",
        "workflow_session_summaries",
        ["session_id"],
        schema,
    )
    _create_index(
        "ix_wss_generated_at",
        "workflow_session_summaries",
        ["generated_at"],
        schema,
    )


def downgrade() -> None:
    """Drop the table + indexes."""
    schema = _schema()
    with contextlib.suppress(Exception):
        if _has_table("workflow_session_summaries", schema):
            op.drop_table("workflow_session_summaries", schema=schema)
