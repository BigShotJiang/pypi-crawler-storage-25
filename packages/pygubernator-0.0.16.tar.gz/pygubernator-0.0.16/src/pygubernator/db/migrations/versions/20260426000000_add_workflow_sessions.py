"""Workflow sessions metadata table (Phase 6 §6.8b).

Adds a sibling table to ``workflow_runs`` keyed by ``session_id`` so
the Sessions sidebar can display a user-supplied display name + notes
next to the raw session id. The runs table itself is unchanged — the
relationship is a JOIN against ``session_id``, not a foreign key,
because sessions are an emergent grouping (any run can claim any
session_id; the metadata is just decoration).

Revision ID: 20260426000000
Revises: 20260425000000
Create Date: 2026-04-26 00:00:00.000000
"""

from __future__ import annotations

import contextlib

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260426000000"
down_revision = "20260425000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    return inspector.has_table(table, schema=schema)


def upgrade() -> None:
    """Create ``workflow_sessions``."""
    schema = _schema()
    if not _has_table("workflow_sessions", schema):
        op.create_table(
            "workflow_sessions",
            sa.Column("session_id", sa.String(36), primary_key=True),
            sa.Column("name", sa.String(240), nullable=True),
            sa.Column("notes", sa.Text(), nullable=True),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )


def downgrade() -> None:
    """Drop ``workflow_sessions``."""
    schema = _schema()
    with contextlib.suppress(Exception):
        if _has_table("workflow_sessions", schema):
            op.drop_table("workflow_sessions", schema=schema)
