"""Initial control plane schema.

Revision ID: 20260322000000
Revises: None
Create Date: 2026-03-22

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260322000000"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pygubernator schema for PostgreSQL; None for SQLite."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pygubernator"


def upgrade() -> None:
    """Create control-plane tables.

    If the database was created outside Alembic but ``alembic_version`` was never
    stamped, ``upgrade`` would try to recreate tables and fail. Skip DDL when the schema
    already
    exists so this revision can be recorded and later migrations can run.
    """
    connection = op.get_bind()
    schema = _schema()
    inspector = sa.inspect(connection)
    if inspector.has_table("agents", schema=schema):
        return

    # -- agents -------------------------------------------------------
    op.create_table(
        "agents",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("owner", sa.String(120), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("archived", sa.Boolean(), nullable=False),
        sa.Column("current_version_id", sa.String(36), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        schema=schema,
    )
    op.create_index("ix_agents_name", "agents", ["name"], unique=True, schema=schema)

    # -- agent_versions -----------------------------------------------
    op.create_table(
        "agent_versions",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("agent_id", sa.String(36), nullable=False),
        sa.Column("version", sa.String(64), nullable=False),
        sa.Column("model", sa.String(120), nullable=True),
        sa.Column("prompt", sa.Text(), nullable=True),
        sa.Column("tools", sa.JSON(), nullable=False),
        sa.Column("config", sa.JSON(), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["agent_id"],
            [f"{schema}.agents.id" if schema else "agents.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_agent_versions_agent_id",
        "agent_versions",
        ["agent_id"],
        schema=schema,
    )
    op.create_index(
        "ix_agent_version_unique",
        "agent_versions",
        ["agent_id", "version"],
        unique=True,
        schema=schema,
    )

    # -- runs ---------------------------------------------------------
    op.create_table(
        "runs",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("agent_id", sa.String(36), nullable=False),
        sa.Column("agent_version_id", sa.String(36), nullable=True),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("correlation_id", sa.String(120), nullable=True),
        sa.Column("trigger", sa.String(64), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("ended_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column("token_input", sa.Integer(), nullable=False),
        sa.Column("token_output", sa.Integer(), nullable=False),
        sa.Column("cost_usd_micros", sa.Integer(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["agent_id"],
            [f"{schema}.agents.id" if schema else "agents.id"],
        ),
        sa.ForeignKeyConstraint(
            ["agent_version_id"],
            [f"{schema}.agent_versions.id" if schema else "agent_versions.id"],
        ),
        schema=schema,
    )
    op.create_index("ix_runs_agent_id", "runs", ["agent_id"], schema=schema)
    op.create_index("ix_runs_status", "runs", ["status"], schema=schema)
    op.create_index(
        "ix_runs_correlation_id",
        "runs",
        ["correlation_id"],
        schema=schema,
    )

    # -- run_events ---------------------------------------------------
    op.create_table(
        "run_events",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("run_id", sa.String(36), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("level", sa.String(16), nullable=False),
        sa.Column("message", sa.Text(), nullable=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["run_id"],
            [f"{schema}.runs.id" if schema else "runs.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_run_events_run_id",
        "run_events",
        ["run_id"],
        schema=schema,
    )
    op.create_index(
        "ix_run_events_event_type",
        "run_events",
        ["event_type"],
        schema=schema,
    )
    op.create_index(
        "ix_run_events_created_at",
        "run_events",
        ["created_at"],
        schema=schema,
    )

    # -- tool_calls ---------------------------------------------------
    op.create_table(
        "tool_calls",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("run_id", sa.String(36), nullable=False),
        sa.Column("tool_name", sa.String(120), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("latency_ms", sa.Integer(), nullable=True),
        sa.Column("input_payload", sa.JSON(), nullable=False),
        sa.Column("output_payload", sa.JSON(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["run_id"],
            [f"{schema}.runs.id" if schema else "runs.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_tool_calls_run_id",
        "tool_calls",
        ["run_id"],
        schema=schema,
    )
    op.create_index(
        "ix_tool_calls_tool_name",
        "tool_calls",
        ["tool_name"],
        schema=schema,
    )
    op.create_index(
        "ix_tool_calls_created_at",
        "tool_calls",
        ["created_at"],
        schema=schema,
    )

    # -- policy_assignments -------------------------------------------
    op.create_table(
        "policy_assignments",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("agent_id", sa.String(36), nullable=False),
        sa.Column("policy_type", sa.String(64), nullable=False),
        sa.Column("policy_value", sa.JSON(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["agent_id"],
            [f"{schema}.agents.id" if schema else "agents.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_policy_assignments_agent_id",
        "policy_assignments",
        ["agent_id"],
        schema=schema,
    )
    op.create_index(
        "ix_policy_assignments_policy_type",
        "policy_assignments",
        ["policy_type"],
        schema=schema,
    )

    # -- alerts -------------------------------------------------------
    op.create_table(
        "alerts",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("severity", sa.String(16), nullable=False),
        sa.Column("condition", sa.JSON(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        schema=schema,
    )
    op.create_index("ix_alerts_name", "alerts", ["name"], unique=True, schema=schema)

    # -- audit_logs ---------------------------------------------------
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("actor", sa.String(120), nullable=False),
        sa.Column("action", sa.String(120), nullable=False),
        sa.Column("resource_type", sa.String(64), nullable=False),
        sa.Column("resource_id", sa.String(36), nullable=True),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        schema=schema,
    )
    op.create_index(
        "ix_audit_logs_actor",
        "audit_logs",
        ["actor"],
        schema=schema,
    )
    op.create_index(
        "ix_audit_logs_action",
        "audit_logs",
        ["action"],
        schema=schema,
    )
    op.create_index(
        "ix_audit_logs_resource_type",
        "audit_logs",
        ["resource_type"],
        schema=schema,
    )
    op.create_index(
        "ix_audit_logs_created_at",
        "audit_logs",
        ["created_at"],
        schema=schema,
    )

    # -- incidents ----------------------------------------------------
    op.create_table(
        "incidents",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("run_id", sa.String(36), nullable=True),
        sa.Column("alert_id", sa.String(36), nullable=True),
        sa.Column("title", sa.String(240), nullable=False),
        sa.Column("severity", sa.String(16), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("owner", sa.String(120), nullable=True),
        sa.Column(
            "acknowledged_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "silenced_until",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["run_id"],
            [f"{schema}.runs.id" if schema else "runs.id"],
        ),
        sa.ForeignKeyConstraint(
            ["alert_id"],
            [f"{schema}.alerts.id" if schema else "alerts.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_incidents_run_id",
        "incidents",
        ["run_id"],
        schema=schema,
    )
    op.create_index(
        "ix_incidents_alert_id",
        "incidents",
        ["alert_id"],
        schema=schema,
    )
    op.create_index(
        "ix_incidents_severity",
        "incidents",
        ["severity"],
        schema=schema,
    )
    op.create_index(
        "ix_incidents_status",
        "incidents",
        ["status"],
        schema=schema,
    )
    op.create_index(
        "ix_incidents_owner",
        "incidents",
        ["owner"],
        schema=schema,
    )
    op.create_index(
        "ix_incidents_created_at",
        "incidents",
        ["created_at"],
        schema=schema,
    )

    # -- workflows ----------------------------------------------------
    op.create_table(
        "workflows",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("owner", sa.String(120), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        schema=schema,
    )
    op.create_index(
        "ix_workflows_name",
        "workflows",
        ["name"],
        unique=True,
        schema=schema,
    )

    # -- workflow_versions --------------------------------------------
    op.create_table(
        "workflow_versions",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("workflow_id", sa.String(36), nullable=False),
        sa.Column("version", sa.String(64), nullable=False),
        sa.Column("spec_json", sa.JSON(), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_by", sa.String(120), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["workflow_id"],
            [f"{schema}.workflows.id" if schema else "workflows.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_workflow_versions_workflow_id",
        "workflow_versions",
        ["workflow_id"],
        schema=schema,
    )
    op.create_index(
        "ix_workflow_version_unique",
        "workflow_versions",
        ["workflow_id", "version"],
        unique=True,
        schema=schema,
    )

    # -- workflow_runs ------------------------------------------------
    op.create_table(
        "workflow_runs",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("workflow_id", sa.String(36), nullable=False),
        sa.Column("workflow_version_id", sa.String(36), nullable=True),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("input_json", sa.JSON(), nullable=False),
        sa.Column("output_json", sa.JSON(), nullable=False),
        sa.Column("variables_json", sa.JSON(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column("created_by", sa.String(120), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["workflow_id"],
            [f"{schema}.workflows.id" if schema else "workflows.id"],
        ),
        sa.ForeignKeyConstraint(
            ["workflow_version_id"],
            [f"{schema}.workflow_versions.id" if schema else "workflow_versions.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_workflow_runs_workflow_id",
        "workflow_runs",
        ["workflow_id"],
        schema=schema,
    )
    op.create_index(
        "ix_workflow_runs_status",
        "workflow_runs",
        ["status"],
        schema=schema,
    )

    # -- workflow_step_runs -------------------------------------------
    op.create_table(
        "workflow_step_runs",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("workflow_run_id", sa.String(36), nullable=False),
        sa.Column("node_id", sa.String(120), nullable=False),
        sa.Column("node_type", sa.String(64), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("input_json", sa.JSON(), nullable=False),
        sa.Column("output_json", sa.JSON(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("output_handle", sa.String(64), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["workflow_run_id"],
            [f"{schema}.workflow_runs.id" if schema else "workflow_runs.id"],
        ),
        schema=schema,
    )
    op.create_index(
        "ix_workflow_step_runs_workflow_run_id",
        "workflow_step_runs",
        ["workflow_run_id"],
        schema=schema,
    )


def downgrade() -> None:
    schema = _schema()
    tables = [
        "workflow_step_runs",
        "workflow_runs",
        "workflow_versions",
        "workflows",
        "incidents",
        "audit_logs",
        "alerts",
        "policy_assignments",
        "tool_calls",
        "run_events",
        "runs",
        "agent_versions",
        "agents",
    ]
    for table in tables:
        op.drop_table(table, schema=schema)
