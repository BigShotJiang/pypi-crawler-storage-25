"""Add timezone and policy fields to scheduled_jobs.

Revision ID: 20260415000000
Revises: 20260405000000
Create Date: 2026-04-15 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260415000000"
down_revision = "20260405000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _column_names(table: str, schema: str | None) -> set[str]:
    bind = op.get_bind()
    inspector = inspect(bind)
    return {col["name"] for col in inspector.get_columns(table, schema=schema)}


def upgrade() -> None:
    schema = _schema()
    columns = _column_names("scheduled_jobs", schema)

    if "timezone" not in columns:
        op.add_column(
            "scheduled_jobs",
            sa.Column("timezone", sa.String(64), nullable=False, server_default="UTC"),
            schema=schema,
        )
    if "concurrency_policy" not in columns:
        op.add_column(
            "scheduled_jobs",
            sa.Column(
                "concurrency_policy",
                sa.String(32),
                nullable=False,
                server_default="allow",
            ),
            schema=schema,
        )
    if "misfire_policy" not in columns:
        op.add_column(
            "scheduled_jobs",
            sa.Column(
                "misfire_policy",
                sa.String(32),
                nullable=False,
                server_default="fire_now",
            ),
            schema=schema,
        )
    if "misfire_grace_seconds" not in columns:
        op.add_column(
            "scheduled_jobs",
            sa.Column(
                "misfire_grace_seconds",
                sa.Integer(),
                nullable=False,
                server_default="60",
            ),
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    columns = _column_names("scheduled_jobs", schema)
    if "misfire_grace_seconds" in columns:
        op.drop_column("scheduled_jobs", "misfire_grace_seconds", schema=schema)
    if "misfire_policy" in columns:
        op.drop_column("scheduled_jobs", "misfire_policy", schema=schema)
    if "concurrency_policy" in columns:
        op.drop_column("scheduled_jobs", "concurrency_policy", schema=schema)
    if "timezone" in columns:
        op.drop_column("scheduled_jobs", "timezone", schema=schema)
