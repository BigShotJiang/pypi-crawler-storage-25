"""Add session_id column to workflow_runs.

Revision ID: 20260326000000
Revises: 20260322000000
Create Date: 2026-03-26

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260326000000"
down_revision: str = "20260322000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pygubernator schema for PostgreSQL; None for SQLite."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pygubernator"


def upgrade() -> None:
    schema = _schema()
    connection = op.get_bind()
    inspector = sa.inspect(connection)
    cols = {c["name"] for c in inspector.get_columns("workflow_runs", schema=schema)}
    if "session_id" in cols:
        return

    op.add_column(
        "workflow_runs",
        sa.Column("session_id", sa.String(36), nullable=True),
        schema=schema,
    )
    op.create_index(
        "ix_workflow_runs_session_id",
        "workflow_runs",
        ["session_id"],
        schema=schema,
    )


def downgrade() -> None:
    schema = _schema()
    op.drop_index(
        "ix_workflow_runs_session_id",
        table_name="workflow_runs",
        schema=schema,
    )
    op.drop_column("workflow_runs", "session_id", schema=schema)
