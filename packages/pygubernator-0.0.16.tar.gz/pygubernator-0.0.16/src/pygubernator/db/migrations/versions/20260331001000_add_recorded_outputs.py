"""Add recorded_outputs table for deterministic replay.

Revision ID: 20260331001000
Revises: 20260331000000
Create Date: 2026-03-31 00:10:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260331001000"
down_revision = "20260331000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("recorded_outputs", schema=schema):
        op.create_table(
            "recorded_outputs",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("workflow_run_id", sa.String(36), nullable=False),
            sa.Column("node_id", sa.String(120), nullable=False),
            sa.Column("payload_json", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_recorded_outputs_workspace_id",
            "recorded_outputs",
            ["workspace_id"],
            schema=schema,
        )
        op.create_index(
            "ix_recorded_outputs_workflow_run_id",
            "recorded_outputs",
            ["workflow_run_id"],
            schema=schema,
        )
        op.create_index(
            "ix_recorded_outputs_node_id",
            "recorded_outputs",
            ["node_id"],
            schema=schema,
        )
        op.create_index(
            "ix_recorded_outputs_created_at",
            "recorded_outputs",
            ["created_at"],
            schema=schema,
        )
        op.create_index(
            "ix_recorded_outputs_unique",
            "recorded_outputs",
            ["workspace_id", "workflow_run_id", "node_id"],
            unique=True,
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)
    if inspector.has_table("recorded_outputs", schema=schema):
        op.drop_table("recorded_outputs", schema=schema)
