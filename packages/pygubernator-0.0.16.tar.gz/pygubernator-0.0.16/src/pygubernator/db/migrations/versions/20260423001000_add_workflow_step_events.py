"""Workflow step events table (scale-gated extraction of ``_child_events``).

Nested tool-call / LLM events currently live inside
``workflow_step_runs.output_json["_child_events"]``. That JSON blob is
fine at low volume but isn't indexable, which blocks server-side
filtering ("show me every failed tool call in run X"), aggregation
queries, and size-bounded retention policies.

This migration introduces a dedicated ``workflow_step_events`` table.
The write path dual-writes for now so the UI keeps reading events out of
``output_json`` while downstream code migrates to the indexed table;
future migrations can drop the blob once the cut-over is complete.

Revision ID: 20260423001000
Revises: 20260423000000
Create Date: 2026-04-23 00:10:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260423001000"
down_revision = "20260423000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    return inspector.has_table(table, schema=schema)


def _index_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    try:
        return {idx["name"] for idx in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str,
    table: str,
    columns: list[str],
    schema: str | None,
    *,
    unique: bool = False,
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, unique=unique, schema=schema)


def upgrade() -> None:
    """Create ``workflow_step_events`` plus its lookup indexes."""
    schema = _schema()

    if not _has_table("workflow_step_events", schema):
        op.create_table(
            "workflow_step_events",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("step_run_id", sa.String(36), nullable=False),
            sa.Column("workflow_run_id", sa.String(36), nullable=False),
            sa.Column("event_type", sa.String(64), nullable=False),
            sa.Column("sequence_num", sa.Integer(), nullable=False),
            sa.Column("event_timestamp", sa.Float(), nullable=False),
            sa.Column("payload_json", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.ForeignKeyConstraint(["step_run_id"], ["workflow_step_runs.id"]),
            sa.ForeignKeyConstraint(["workflow_run_id"], ["workflow_runs.id"]),
            schema=schema,
        )
    _create_index(
        "ix_wse_step_run_id",
        "workflow_step_events",
        ["step_run_id"],
        schema,
    )
    _create_index(
        "ix_wse_workflow_run_id",
        "workflow_step_events",
        ["workflow_run_id"],
        schema,
    )
    _create_index(
        "ix_wse_event_type",
        "workflow_step_events",
        ["event_type"],
        schema,
    )
    _create_index(
        "ix_wse_step_sequence",
        "workflow_step_events",
        ["step_run_id", "sequence_num"],
        schema,
        unique=True,
    )


def downgrade() -> None:
    """Drop ``workflow_step_events`` and any associated indexes."""
    schema = _schema()
    if _has_table("workflow_step_events", schema):
        op.drop_table("workflow_step_events", schema=schema)
