"""Safety + autonomy tables.

Adds: generic_records, tool_call_audit, memory_access_audit,
agent_heartbeats. Extends policy_assignments with scope, priority,
workflow_id.

Revision ID: 20260416000000
Revises: 20260415000000
Create Date: 2026-04-16 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260416000000"
down_revision = "20260415000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    bind = op.get_bind()
    inspector = inspect(bind)
    return inspector.has_table(table, schema=schema)


def _column_names(table: str, schema: str | None) -> set[str]:
    bind = op.get_bind()
    inspector = inspect(bind)
    return {col["name"] for col in inspector.get_columns(table, schema=schema)}


def _index_names(table: str, schema: str | None) -> set[str]:
    bind = op.get_bind()
    inspector = inspect(bind)
    try:
        return {i["name"] for i in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str, table: str, columns: list[str], schema: str | None
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, schema=schema)


def upgrade() -> None:
    schema = _schema()

    if not _has_table("generic_records", schema):
        op.create_table(
            "generic_records",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("kind", sa.String(64), nullable=False),
            sa.Column("scope", sa.String(128), nullable=True),
            sa.Column("payload", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index(
        "ix_generic_records_kind_created_at",
        "generic_records",
        ["kind", "created_at"],
        schema,
    )
    _create_index(
        "ix_generic_records_kind_scope",
        "generic_records",
        ["kind", "scope"],
        schema,
    )

    if not _has_table("tool_call_audit", schema):
        op.create_table(
            "tool_call_audit",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("run_id", sa.String(36), nullable=True),
            sa.Column("agent_id", sa.String(64), nullable=True),
            sa.Column("workflow_id", sa.String(64), nullable=True),
            sa.Column("tool_name", sa.String(120), nullable=False),
            sa.Column("params", sa.JSON(), nullable=False),
            sa.Column("output", sa.JSON(), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("policy_decision", sa.String(32), nullable=False),
            sa.Column("policy_reason", sa.String(512), nullable=True),
            sa.Column("duration_ms", sa.Integer(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index("ix_tool_call_audit_run_id", "tool_call_audit", ["run_id"], schema)
    _create_index(
        "ix_tool_call_audit_agent_id", "tool_call_audit", ["agent_id"], schema
    )
    _create_index(
        "ix_tool_call_audit_tool_created",
        "tool_call_audit",
        ["tool_name", "created_at"],
        schema,
    )
    _create_index("ix_tool_call_audit_status", "tool_call_audit", ["status"], schema)

    if not _has_table("memory_access_audit", schema):
        op.create_table(
            "memory_access_audit",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("scope", sa.String(256), nullable=False),
            sa.Column("agent_id", sa.String(64), nullable=True),
            sa.Column("run_id", sa.String(36), nullable=True),
            sa.Column("operation", sa.String(32), nullable=False),
            sa.Column("key", sa.String(256), nullable=True),
            sa.Column("details", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index(
        "ix_memory_access_scope_created",
        "memory_access_audit",
        ["scope", "created_at"],
        schema,
    )
    _create_index(
        "ix_memory_access_agent_id",
        "memory_access_audit",
        ["agent_id"],
        schema,
    )
    _create_index(
        "ix_memory_access_operation",
        "memory_access_audit",
        ["operation"],
        schema,
    )

    if not _has_table("agent_heartbeats", schema):
        op.create_table(
            "agent_heartbeats",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("agent_id", sa.String(64), nullable=False),
            sa.Column("run_id", sa.String(36), nullable=True),
            sa.Column("workflow_id", sa.String(64), nullable=True),
            sa.Column("status", sa.String(32), nullable=False, server_default="live"),
            sa.Column("details", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index(
        "ix_agent_heartbeats_agent_id",
        "agent_heartbeats",
        ["agent_id"],
        schema,
    )
    _create_index("ix_agent_heartbeats_run_id", "agent_heartbeats", ["run_id"], schema)
    _create_index(
        "ix_agent_heartbeats_created",
        "agent_heartbeats",
        ["created_at"],
        schema,
    )
    _create_index("ix_agent_heartbeats_status", "agent_heartbeats", ["status"], schema)

    # Extend policy_assignments with scope + priority + workflow_id.
    if _has_table("policy_assignments", schema):
        cols = _column_names("policy_assignments", schema)
        if "scope" not in cols:
            op.add_column(
                "policy_assignments",
                sa.Column(
                    "scope", sa.String(32), nullable=False, server_default="agent"
                ),
                schema=schema,
            )
        if "priority" not in cols:
            op.add_column(
                "policy_assignments",
                sa.Column("priority", sa.Integer(), nullable=False, server_default="0"),
                schema=schema,
            )
        if "workflow_id" not in cols:
            op.add_column(
                "policy_assignments",
                sa.Column("workflow_id", sa.String(64), nullable=True),
                schema=schema,
            )
        _create_index(
            "ix_policy_assignments_scope_priority",
            "policy_assignments",
            ["scope", "priority"],
            schema,
        )
        _create_index(
            "ix_policy_assignments_workflow_id",
            "policy_assignments",
            ["workflow_id"],
            schema,
        )


def downgrade() -> None:
    schema = _schema()
    for table in (
        "agent_heartbeats",
        "memory_access_audit",
        "tool_call_audit",
        "generic_records",
    ):
        if _has_table(table, schema):
            op.drop_table(table, schema=schema)
    if _has_table("policy_assignments", schema):
        cols = _column_names("policy_assignments", schema)
        for idx in (
            "ix_policy_assignments_scope_priority",
            "ix_policy_assignments_workflow_id",
        ):
            if idx in _index_names("policy_assignments", schema):
                op.drop_index(idx, table_name="policy_assignments", schema=schema)
        if "workflow_id" in cols:
            op.drop_column("policy_assignments", "workflow_id", schema=schema)
        if "priority" in cols:
            op.drop_column("policy_assignments", "priority", schema=schema)
        if "scope" in cols:
            op.drop_column("policy_assignments", "scope", schema=schema)
