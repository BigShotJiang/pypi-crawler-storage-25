"""Workflow run ``trigger`` + ``correlation_id`` columns (Phase 6 §6.7b).

Runs dispatched by the Guide conversational orchestrator need to carry
enough metadata for the UI to reconcile them against the chat thread
that started them:

- ``trigger`` identifies *how* the run began. Values in use:
  ``"manual"`` (explicit Execute button — default), ``"schedule"``
  (scheduler tick), ``"webhook"`` (inbound HTTP trigger), ``"guide"``
  (chat → planner → dispatch). Stays a short free-text string so new
  trigger kinds can be added without a migration.
- ``correlation_id`` ties the run to the originating session / message
  on the caller's side (for Guide: the chat session id, so listing
  "runs spawned by this conversation" is a cheap indexed lookup).

Both are nullable and indexed — historical rows stay unchanged and
readers can filter efficiently.

Revision ID: 20260425000000
Revises: 20260424000000
Create Date: 2026-04-25 00:00:00.000000
"""

from __future__ import annotations

import contextlib

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260425000000"
down_revision = "20260424000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_column(table: str, column: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    try:
        return any(
            col["name"] == column for col in inspector.get_columns(table, schema=schema)
        )
    except Exception:
        return False


def _index_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    try:
        return {idx["name"] for idx in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str,
    table: str,
    columns: list[str],
    schema: str | None,
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, schema=schema)


def upgrade() -> None:
    """Add the ``trigger`` and ``correlation_id`` columns + their indexes."""
    schema = _schema()
    if not _has_column("workflow_runs", "trigger", schema):
        op.add_column(
            "workflow_runs",
            sa.Column("trigger", sa.String(32), nullable=True),
            schema=schema,
        )
    if not _has_column("workflow_runs", "correlation_id", schema):
        op.add_column(
            "workflow_runs",
            sa.Column("correlation_id", sa.String(120), nullable=True),
            schema=schema,
        )
    _create_index(
        "ix_wr_trigger",
        "workflow_runs",
        ["trigger"],
        schema,
    )
    _create_index(
        "ix_wr_correlation_id",
        "workflow_runs",
        ["correlation_id"],
        schema,
    )


def downgrade() -> None:
    """Drop the ``trigger`` and ``correlation_id`` columns."""
    schema = _schema()
    for idx in ("ix_wr_correlation_id", "ix_wr_trigger"):
        # Idempotent — tolerate a missing index from a partial upgrade.
        with contextlib.suppress(Exception):
            op.drop_index(idx, table_name="workflow_runs", schema=schema)
    if _has_column("workflow_runs", "correlation_id", schema):
        op.drop_column("workflow_runs", "correlation_id", schema=schema)
    if _has_column("workflow_runs", "trigger", schema):
        op.drop_column("workflow_runs", "trigger", schema=schema)
