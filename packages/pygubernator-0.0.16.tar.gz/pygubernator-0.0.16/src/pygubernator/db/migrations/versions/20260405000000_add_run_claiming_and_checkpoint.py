"""Add run claiming and checkpoint columns to workflow_runs.

Adds ``claimed_by``, ``heartbeat_at``, and ``checkpoint_json`` columns
to enable distributed run claiming, heartbeat-based stale detection,
and per-level checkpointing for crash recovery.

Revision ID: 20260405000000
Revises: 20260331003000
Create Date: 2026-04-05
"""

from __future__ import annotations

import contextlib

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260405000000"
down_revision = "20260331003000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _table_columns(
    inspector: sa.Inspector,
    table: str,
    schema: str | None,
) -> set[str]:
    return {c["name"] for c in inspector.get_columns(table, schema=schema)}


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("workflow_runs", schema=schema):
        return

    cols = _table_columns(inspector, "workflow_runs", schema)

    if "claimed_by" not in cols:
        op.add_column(
            "workflow_runs",
            sa.Column("claimed_by", sa.String(120), nullable=True),
            schema=schema,
        )
        op.create_index(
            "ix_workflow_runs_claimed_by",
            "workflow_runs",
            ["claimed_by"],
            schema=schema,
        )

    if "heartbeat_at" not in cols:
        op.add_column(
            "workflow_runs",
            sa.Column(
                "heartbeat_at",
                sa.DateTime(timezone=True),
                nullable=True,
            ),
            schema=schema,
        )

    if "checkpoint_json" not in cols:
        op.add_column(
            "workflow_runs",
            sa.Column(
                "checkpoint_json",
                sa.JSON(),
                nullable=True,
                server_default=sa.text("'{}'"),
            ),
            schema=schema,
        )

    # Composite index for stale-run detection queries.
    with contextlib.suppress(Exception):
        op.create_index(
            "ix_workflow_runs_status_heartbeat",
            "workflow_runs",
            ["status", "heartbeat_at"],
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("workflow_runs", schema=schema):
        return

    cols = _table_columns(inspector, "workflow_runs", schema)

    with contextlib.suppress(Exception):
        op.drop_index(
            "ix_workflow_runs_status_heartbeat",
            table_name="workflow_runs",
            schema=schema,
        )

    for col_name in ("checkpoint_json", "heartbeat_at", "claimed_by"):
        if col_name in cols:
            if col_name == "claimed_by":
                with contextlib.suppress(Exception):
                    op.drop_index(
                        "ix_workflow_runs_claimed_by",
                        table_name="workflow_runs",
                        schema=schema,
                    )
            op.drop_column("workflow_runs", col_name, schema=schema)
