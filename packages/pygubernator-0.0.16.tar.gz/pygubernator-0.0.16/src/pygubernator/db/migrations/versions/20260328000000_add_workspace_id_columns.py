"""Add workspace_id to agents, workflows, and related tables.

Revision ID: 20260328000000
Revises: 20260327000000
Create Date: 2026-03-28 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260328000000"
down_revision = "20260327000000"
branch_labels = None
depends_on = None

# Matches ORM defaults in db/models.py (string "default").
_DEFAULT_WORKSPACE = sa.text("'default'")


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _table_columns(inspector: sa.Inspector, table: str, schema: str | None) -> set[str]:
    return {c["name"] for c in inspector.get_columns(table, schema=schema)}


def upgrade() -> None:
    """Backfill workspace_id for databases created before the column existed."""
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    tables_indexes: tuple[tuple[str, str], ...] = (
        ("agents", "ix_agents_workspace_id"),
        ("workflows", "ix_workflows_workspace_id"),
        ("chat_sessions", "ix_chat_sessions_workspace_id"),
        ("notification_rules", "ix_notification_rules_workspace_id"),
        ("webhook_triggers", "ix_webhook_triggers_workspace_id"),
        ("scheduled_jobs", "ix_scheduled_jobs_workspace_id"),
    )

    for table, index_name in tables_indexes:
        if not inspector.has_table(table, schema=schema):
            continue
        cols = _table_columns(inspector, table, schema)
        if "workspace_id" in cols:
            continue
        op.add_column(
            table,
            sa.Column(
                "workspace_id",
                sa.String(36),
                nullable=False,
                server_default=_DEFAULT_WORKSPACE,
            ),
            schema=schema,
        )
        op.create_index(
            index_name,
            table,
            ["workspace_id"],
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    tables_indexes: tuple[tuple[str, str], ...] = (
        ("scheduled_jobs", "ix_scheduled_jobs_workspace_id"),
        ("webhook_triggers", "ix_webhook_triggers_workspace_id"),
        ("notification_rules", "ix_notification_rules_workspace_id"),
        ("chat_sessions", "ix_chat_sessions_workspace_id"),
        ("workflows", "ix_workflows_workspace_id"),
        ("agents", "ix_agents_workspace_id"),
    )

    for table, index_name in tables_indexes:
        if not inspector.has_table(table, schema=schema):
            continue
        cols = _table_columns(inspector, table, schema)
        if "workspace_id" not in cols:
            continue
        op.drop_index(index_name, table_name=table, schema=schema)
        op.drop_column(table, "workspace_id", schema=schema)
