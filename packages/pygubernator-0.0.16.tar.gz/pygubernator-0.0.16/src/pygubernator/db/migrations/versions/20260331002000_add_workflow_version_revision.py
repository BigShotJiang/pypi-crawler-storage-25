"""Add workflow_versions.revision column.

The ORM model `WorkflowVersion` includes a `revision` integer column, but older
databases (especially local SQLite files created before this column existed)
may be missing it. This migration adds the column with a default of 1 so the
API can query workflow versions without schema errors.

Revision ID: 20260331002000
Revises: 20260331001000
Create Date: 2026-03-31
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260331002000"
down_revision = "20260331001000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _table_columns(
    inspector: sa.Inspector,
    table: str,
    schema: str | None,
) -> set[str]:
    return {c["name"] for c in inspector.get_columns(table, schema=schema)}


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("workflow_versions", schema=schema):
        return

    cols = _table_columns(inspector, "workflow_versions", schema)
    if "revision" in cols:
        return

    op.add_column(
        "workflow_versions",
        sa.Column(
            "revision",
            sa.Integer(),
            nullable=False,
            server_default=sa.text("1"),
        ),
        schema=schema,
    )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("workflow_versions", schema=schema):
        return

    cols = _table_columns(inspector, "workflow_versions", schema)
    if "revision" not in cols:
        return

    op.drop_column("workflow_versions", "revision", schema=schema)
