"""Add ``deleted_at`` soft-delete column to agent_versions.

Soft-delete lets the UI retire individual agent versions without removing
the row — workflow runs pinned to that version via ``__pinned_agents__``
keep resolving by id. The list endpoint filters by ``deleted_at IS NULL``
by default so the default version table stays clean.

Revision ID: 20260423000000
Revises: 20260418000000
Create Date: 2026-04-23 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260423000000"
down_revision = "20260418000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _column_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    return {col["name"] for col in inspector.get_columns(table, schema=schema)}


def upgrade() -> None:
    """Add ``agent_versions.deleted_at`` if it isn't already present."""
    schema = _schema()
    columns = _column_names("agent_versions", schema)
    if "deleted_at" not in columns:
        op.add_column(
            "agent_versions",
            sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
            schema=schema,
        )


def downgrade() -> None:
    """Drop the ``agent_versions.deleted_at`` column."""
    schema = _schema()
    columns = _column_names("agent_versions", schema)
    if "deleted_at" in columns:
        op.drop_column("agent_versions", "deleted_at", schema=schema)
