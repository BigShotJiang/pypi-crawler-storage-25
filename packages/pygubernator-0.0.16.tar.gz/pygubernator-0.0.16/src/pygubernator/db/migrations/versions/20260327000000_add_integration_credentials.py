"""Add integration_credentials table.

Revision ID: 20260327000000
Revises: 20260326000000
Create Date: 2026-03-27 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260327000000"
down_revision = "20260326000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)
    table_names = set(inspector.get_table_names(schema=schema))
    if "integration_credentials" in table_names:
        return

    op.create_table(
        "integration_credentials",
        sa.Column("id", sa.String(36), nullable=False),
        sa.Column("provider", sa.String(64), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("env_var", sa.String(120), nullable=False),
        sa.Column("encrypted_value", sa.Text(), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
        schema=schema,
    )
    op.create_index(
        "ix_integration_credentials_provider",
        "integration_credentials",
        ["provider"],
        schema=schema,
    )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)
    table_names = set(inspector.get_table_names(schema=schema))
    if "integration_credentials" not in table_names:
        return
    op.drop_index(
        "ix_integration_credentials_provider",
        table_name="integration_credentials",
        schema=schema,
    )
    op.drop_table("integration_credentials", schema=schema)
