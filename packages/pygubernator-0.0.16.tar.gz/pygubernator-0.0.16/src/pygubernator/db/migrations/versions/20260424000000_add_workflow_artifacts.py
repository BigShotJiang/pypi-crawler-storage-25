"""Workflow artifacts table (first-class run output surface).

Node handlers and tools need a way to publish structured outputs —
Markdown reports, CSV tables, sandboxed HTML previews, Jupyter notebooks,
images — without shoehorning the payload into ``output_json``. This
migration adds the ``workflow_artifacts`` table that backs the new
artifact surface: one row per emitted artifact, with either inline text
content or a ``source_path`` reference to disk / object storage.

Revision ID: 20260424000000
Revises: 20260423001000
Create Date: 2026-04-24 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260424000000"
down_revision = "20260423001000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    return inspector.has_table(table, schema=schema)


def _index_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    try:
        return {idx["name"] for idx in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str,
    table: str,
    columns: list[str],
    schema: str | None,
    *,
    unique: bool = False,
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, unique=unique, schema=schema)


def upgrade() -> None:
    """Create ``workflow_artifacts`` plus its lookup indexes."""
    schema = _schema()

    if not _has_table("workflow_artifacts", schema):
        op.create_table(
            "workflow_artifacts",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("workflow_run_id", sa.String(36), nullable=False),
            sa.Column("step_run_id", sa.String(36), nullable=True),
            sa.Column("artifact_type", sa.String(32), nullable=False),
            sa.Column("title", sa.String(240), nullable=True),
            sa.Column("mime", sa.String(120), nullable=True),
            sa.Column("content_text", sa.Text(), nullable=True),
            sa.Column("source_path", sa.String(1024), nullable=True),
            sa.Column("size_bytes", sa.Integer(), nullable=True),
            sa.Column("sequence_num", sa.Integer(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.ForeignKeyConstraint(["workflow_run_id"], ["workflow_runs.id"]),
            sa.ForeignKeyConstraint(["step_run_id"], ["workflow_step_runs.id"]),
            schema=schema,
        )
    _create_index(
        "ix_wa_workflow_run_id",
        "workflow_artifacts",
        ["workflow_run_id"],
        schema,
    )
    _create_index(
        "ix_wa_step_run_id",
        "workflow_artifacts",
        ["step_run_id"],
        schema,
    )
    _create_index(
        "ix_wa_artifact_type",
        "workflow_artifacts",
        ["artifact_type"],
        schema,
    )
    _create_index(
        "ix_wa_run_sequence",
        "workflow_artifacts",
        ["workflow_run_id", "sequence_num"],
        schema,
    )


def downgrade() -> None:
    """Drop ``workflow_artifacts`` and its associated indexes."""
    schema = _schema()
    if _has_table("workflow_artifacts", schema):
        op.drop_table("workflow_artifacts", schema=schema)
