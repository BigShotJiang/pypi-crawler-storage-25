"""Add library_test_jobs and library_test_job_events tables.

Revision ID: 20260331000000
Revises: 20260329000000
Create Date: 2026-03-31 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260331000000"
down_revision = "20260329000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("library_test_jobs", schema=schema):
        op.create_table(
            "library_test_jobs",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("machine_name", sa.String(120), nullable=False),
            sa.Column("machine_version", sa.String(64), nullable=False),
            sa.Column("current_state", sa.String(64), nullable=False),
            sa.Column("name", sa.String(255), nullable=False),
            sa.Column("spec_json", sa.JSON(), nullable=False),
            sa.Column("last_workflow_run_id", sa.String(36), nullable=True),
            sa.Column("last_error_message", sa.Text(), nullable=True),
            sa.Column("created_by", sa.String(120), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_library_test_jobs_workspace_id",
            "library_test_jobs",
            ["workspace_id"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_jobs_current_state",
            "library_test_jobs",
            ["current_state"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_jobs_last_workflow_run_id",
            "library_test_jobs",
            ["last_workflow_run_id"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_jobs_workspace_state",
            "library_test_jobs",
            ["workspace_id", "current_state"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_jobs_created_at",
            "library_test_jobs",
            ["created_at"],
            schema=schema,
        )

    if not inspector.has_table("library_test_job_events", schema=schema):
        op.create_table(
            "library_test_job_events",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("job_id", sa.String(36), nullable=False),
            sa.Column("trigger", sa.String(64), nullable=False),
            sa.Column("actor", sa.String(120), nullable=False),
            sa.Column("idempotency_key", sa.String(120), nullable=False),
            sa.Column("workflow_run_id", sa.String(36), nullable=True),
            sa.Column("payload_json", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("from_state", sa.String(64), nullable=False),
            sa.Column("to_state", sa.String(64), nullable=False),
            sa.Column("success", sa.Integer(), nullable=False),
            sa.Column("error_message", sa.Text(), nullable=True),
            sa.ForeignKeyConstraint(
                ["job_id"],
                [f"{(schema + '.') if schema else ''}library_test_jobs.id"],
            ),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_workspace_id",
            "library_test_job_events",
            ["workspace_id"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_job_id",
            "library_test_job_events",
            ["job_id"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_trigger",
            "library_test_job_events",
            ["trigger"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_workflow_run_id",
            "library_test_job_events",
            ["workflow_run_id"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_created_at",
            "library_test_job_events",
            ["created_at"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_ws_job_time",
            "library_test_job_events",
            ["workspace_id", "job_id", "created_at"],
            schema=schema,
        )
        op.create_index(
            "ix_library_test_job_events_idempotency",
            "library_test_job_events",
            ["workspace_id", "job_id", "idempotency_key"],
            unique=True,
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if inspector.has_table("library_test_job_events", schema=schema):
        op.drop_table("library_test_job_events", schema=schema)
    if inspector.has_table("library_test_jobs", schema=schema):
        op.drop_table("library_test_jobs", schema=schema)
