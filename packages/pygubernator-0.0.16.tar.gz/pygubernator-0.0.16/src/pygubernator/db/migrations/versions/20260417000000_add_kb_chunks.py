"""Knowledge-base chunks table.

Adds the ``kb_chunks`` table used by the SQLite/numpy vector store
backing the ``kb_ingest`` / ``kb_retrieve`` workflow nodes.

Revision ID: 20260417000000
Revises: 20260416000000
Create Date: 2026-04-17 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260417000000"
down_revision = "20260416000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    bind = op.get_bind()
    inspector = inspect(bind)
    return inspector.has_table(table, schema=schema)


def _index_names(table: str, schema: str | None) -> set[str]:
    bind = op.get_bind()
    inspector = inspect(bind)
    try:
        return {i["name"] for i in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str, table: str, columns: list[str], schema: str | None
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, schema=schema)


def upgrade() -> None:
    """Create the ``kb_chunks`` table + supporting indexes."""
    schema = _schema()

    if not _has_table("kb_chunks", schema):
        op.create_table(
            "kb_chunks",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("scope", sa.String(256), nullable=False),
            sa.Column("agent_id", sa.String(64), nullable=True),
            sa.Column("workflow_id", sa.String(64), nullable=True),
            sa.Column("run_id", sa.String(36), nullable=True),
            sa.Column("source_uri", sa.Text(), nullable=True),
            sa.Column("contract_id", sa.String(128), nullable=True),
            sa.Column("concept_refs", sa.JSON(), nullable=False),
            sa.Column("binding_state", sa.String(16), nullable=False),
            sa.Column("embedding_dim", sa.Integer(), nullable=False),
            sa.Column("embedding", sa.LargeBinary(), nullable=False),
            sa.Column("text", sa.Text(), nullable=False),
            sa.Column("metadata", sa.JSON(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index(
        "ix_kb_chunks_scope_created",
        "kb_chunks",
        ["scope", "created_at"],
        schema,
    )
    _create_index(
        "ix_kb_chunks_contract",
        "kb_chunks",
        ["contract_id"],
        schema,
    )
    _create_index(
        "ix_kb_chunks_agent_id",
        "kb_chunks",
        ["agent_id"],
        schema,
    )
    _create_index(
        "ix_kb_chunks_workflow_id",
        "kb_chunks",
        ["workflow_id"],
        schema,
    )


def downgrade() -> None:
    """Drop the ``kb_chunks`` table."""
    schema = _schema()
    if _has_table("kb_chunks", schema):
        op.drop_table("kb_chunks", schema=schema)
