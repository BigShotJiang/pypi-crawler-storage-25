"""Tools catalog tables.

Adds first-class ``tools`` and ``tool_versions`` tables for Tool editor v1.

Revision ID: 20260418000000
Revises: 20260417000000
Create Date: 2026-04-18 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260418000000"
down_revision = "20260417000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def _has_table(table: str, schema: str | None) -> bool:
    inspector = inspect(op.get_bind())
    return inspector.has_table(table, schema=schema)


def _index_names(table: str, schema: str | None) -> set[str]:
    inspector = inspect(op.get_bind())
    try:
        return {i["name"] for i in inspector.get_indexes(table, schema=schema)}
    except Exception:
        return set()


def _create_index(
    name: str,
    table: str,
    columns: list[str],
    schema: str | None,
    *,
    unique: bool = False,
) -> None:
    if name not in _index_names(table, schema):
        op.create_index(name, table, columns, unique=unique, schema=schema)


def upgrade() -> None:
    """Create tool catalog tables and indexes."""
    schema = _schema()

    if not _has_table("tools", schema):
        op.create_table(
            "tools",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("description", sa.Text(), nullable=False, server_default=""),
            sa.Column("owner", sa.String(120), nullable=False, server_default="system"),
            sa.Column("status", sa.String(32), nullable=False, server_default="active"),
            sa.Column(
                "archived", sa.Boolean(), nullable=False, server_default=sa.false()
            ),
            sa.Column(
                "workspace_id", sa.String(36), nullable=False, server_default="default"
            ),
            sa.Column("current_version_id", sa.String(36), nullable=True),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            schema=schema,
        )
    _create_index("ix_tools_name", "tools", ["name"], schema)
    _create_index("ix_tools_workspace_id", "tools", ["workspace_id"], schema)
    _create_index("ix_tools_name_unique", "tools", ["name"], schema, unique=True)

    if not _has_table("tool_versions", schema):
        op.create_table(
            "tool_versions",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("tool_id", sa.String(36), nullable=False),
            sa.Column("version", sa.String(64), nullable=False),
            sa.Column("revision", sa.Integer(), nullable=False, server_default="1"),
            sa.Column("spec_json", sa.JSON(), nullable=False),
            sa.Column(
                "active", sa.Boolean(), nullable=False, server_default=sa.false()
            ),
            sa.Column(
                "published", sa.Boolean(), nullable=False, server_default=sa.false()
            ),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column(
                "created_by", sa.String(120), nullable=False, server_default="system"
            ),
            sa.ForeignKeyConstraint(["tool_id"], ["tools.id"]),
            schema=schema,
        )
    _create_index("ix_tool_versions_tool_id", "tool_versions", ["tool_id"], schema)
    _create_index(
        "ix_tool_version_unique",
        "tool_versions",
        ["tool_id", "version"],
        schema,
        unique=True,
    )


def downgrade() -> None:
    """Drop tool catalog tables."""
    schema = _schema()
    if _has_table("tool_versions", schema):
        op.drop_table("tool_versions", schema=schema)
    if _has_table("tools", schema):
        op.drop_table("tools", schema=schema)
