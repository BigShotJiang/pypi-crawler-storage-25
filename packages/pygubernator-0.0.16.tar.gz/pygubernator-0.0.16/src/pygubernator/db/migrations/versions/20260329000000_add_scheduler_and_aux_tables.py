"""Add workflow_approvals, chat_sessions, notification_rules, webhooks, scheduled_jobs.

These tables exist in ORM models but were not part of the initial control-plane
revision. Create them when missing so existing SQLite/Postgres DBs match models.

Revision ID: 20260329000000
Revises: 20260328000000
Create Date: 2026-03-29 00:00:00.000000
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "20260329000000"
down_revision = "20260328000000"
branch_labels = None
depends_on = None


def _schema() -> str | None:
    bind = op.get_bind()
    if bind.dialect.name.startswith("postgres"):
        return "pygubernator"
    return None


def upgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    if not inspector.has_table("workflow_approvals", schema=schema):
        op.create_table(
            "workflow_approvals",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workflow_run_id", sa.String(36), nullable=False),
            sa.Column("node_id", sa.String(120), nullable=False),
            sa.Column("prompt", sa.Text(), nullable=False),
            sa.Column("status", sa.String(32), nullable=False),
            sa.Column("checkpoint_json", sa.JSON(), nullable=False),
            sa.Column("response_json", sa.JSON(), nullable=False),
            sa.Column("responded_by", sa.String(120), nullable=True),
            sa.Column("timeout_seconds", sa.Integer(), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("responded_at", sa.DateTime(timezone=True), nullable=True),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_workflow_approvals_workflow_run_id",
            "workflow_approvals",
            ["workflow_run_id"],
            schema=schema,
        )

    if not inspector.has_table("chat_sessions", schema=schema):
        op.create_table(
            "chat_sessions",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("agent_id", sa.String(36), nullable=True),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("title", sa.String(255), nullable=False),
            sa.Column("model", sa.String(120), nullable=False),
            sa.Column("system_prompt", sa.Text(), nullable=False),
            sa.Column("messages_json", sa.JSON(), nullable=False),
            sa.Column("created_by", sa.String(120), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_chat_sessions_workspace_id",
            "chat_sessions",
            ["workspace_id"],
            schema=schema,
        )

    if not inspector.has_table("notification_rules", schema=schema):
        op.create_table(
            "notification_rules",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("event_type", sa.String(64), nullable=False),
            sa.Column("channel_type", sa.String(32), nullable=False),
            sa.Column("channel_config", sa.JSON(), nullable=False),
            sa.Column("enabled", sa.Boolean(), nullable=False),
            sa.Column("created_by", sa.String(120), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_notification_rules_workspace_id",
            "notification_rules",
            ["workspace_id"],
            schema=schema,
        )

    if not inspector.has_table("webhook_triggers", schema=schema):
        op.create_table(
            "webhook_triggers",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workflow_id", sa.String(36), nullable=False),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("token", sa.String(64), nullable=False),
            sa.Column("enabled", sa.Boolean(), nullable=False),
            sa.Column("last_triggered_at", sa.DateTime(timezone=True), nullable=True),
            sa.Column("trigger_count", sa.Integer(), nullable=False),
            sa.Column("created_by", sa.String(120), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_webhook_triggers_workflow_id",
            "webhook_triggers",
            ["workflow_id"],
            schema=schema,
        )
        op.create_index(
            "ix_webhook_triggers_workspace_id",
            "webhook_triggers",
            ["workspace_id"],
            schema=schema,
        )
        op.create_index(
            "ix_webhook_triggers_token",
            "webhook_triggers",
            ["token"],
            unique=True,
            schema=schema,
        )

    if not inspector.has_table("scheduled_jobs", schema=schema):
        op.create_table(
            "scheduled_jobs",
            sa.Column("id", sa.String(36), nullable=False),
            sa.Column("workflow_id", sa.String(36), nullable=False),
            sa.Column("name", sa.String(120), nullable=False),
            sa.Column("workspace_id", sa.String(36), nullable=False),
            sa.Column("description", sa.Text(), nullable=False),
            sa.Column("cron_expression", sa.String(64), nullable=False),
            sa.Column("input_json", sa.JSON(), nullable=False),
            sa.Column("enabled", sa.Boolean(), nullable=False),
            sa.Column("last_run_at", sa.DateTime(timezone=True), nullable=True),
            sa.Column("next_run_at", sa.DateTime(timezone=True), nullable=True),
            sa.Column("last_status", sa.String(32), nullable=False),
            sa.Column("created_by", sa.String(120), nullable=False),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.PrimaryKeyConstraint("id"),
            schema=schema,
        )
        op.create_index(
            "ix_scheduled_jobs_workflow_id",
            "scheduled_jobs",
            ["workflow_id"],
            schema=schema,
        )
        op.create_index(
            "ix_scheduled_jobs_workspace_id",
            "scheduled_jobs",
            ["workspace_id"],
            schema=schema,
        )


def downgrade() -> None:
    schema = _schema()
    bind = op.get_bind()
    inspector = inspect(bind)

    tables = (
        "scheduled_jobs",
        "webhook_triggers",
        "notification_rules",
        "chat_sessions",
        "workflow_approvals",
    )
    for table in tables:
        if inspector.has_table(table, schema=schema):
            op.drop_table(table, schema=schema)
