"""SQLAlchemy session helpers for the control plane.

Provides lazy engine/session creation and the ``get_db()`` FastAPI dependency.
``Base`` is re-exported from :mod:`pygubernator.db.base` for backward
compatibility with existing imports.
"""

from __future__ import annotations

import logging
from collections.abc import Generator

from sqlalchemy.orm import Session, sessionmaker

from pygubernator.db.base import Base, get_engine
from pygubernator.db.config import get_db_url

logger = logging.getLogger(__name__)

# Re-export for backward compatibility
__all__ = ["Base", "get_db", "init_db", "set_engine"]

# Lazy singletons
_engine = None
_session_factory = None


def _get_engine():
    """Return the module-level engine, creating it lazily."""
    global _engine  # noqa: PLW0603
    if _engine is None:
        url = get_db_url(required=False)
        _engine = get_engine(url)
    return _engine


def _get_session_factory():
    """Return the module-level session factory, creating it lazily."""
    global _session_factory  # noqa: PLW0603
    if _session_factory is None:
        _session_factory = sessionmaker(
            bind=_get_engine(),
            autoflush=False,
            autocommit=False,
        )
    return _session_factory


def set_engine(engine) -> None:
    """Override the module-level engine and session factory.

    Primarily used in tests to inject an in-memory SQLite engine.

    Args:
        engine: SQLAlchemy engine to use for all sessions.
    """
    global _engine, _session_factory  # noqa: PLW0603
    _engine = engine
    _session_factory = sessionmaker(
        bind=engine,
        autoflush=False,
        autocommit=False,
    )


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a database session.

    Yields:
        SQLAlchemy session, closed after the request.
    """
    factory = _get_session_factory()
    db = factory()
    try:
        yield db
    finally:
        db.close()


def init_db(database_url: str | None = None) -> None:
    """Create all tables via ``Base.metadata.create_all``.

    Args:
        database_url: Optional explicit URL. If None, resolves via
            :func:`~pygubernator.db.config.get_db_url`.
    """
    from pygubernator.db import models  # noqa: F401

    url = get_db_url(database_url, required=False)
    engine = get_engine(url)
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created via metadata.create_all")


# ---------------------------------------------------------------------------
# Backward-compatible module-level attributes
# ---------------------------------------------------------------------------
def __getattr__(name: str):
    """Lazy module-level access for ``engine`` and ``SessionLocal``."""
    if name == "engine":
        return _get_engine()
    if name == "SessionLocal":
        return _get_session_factory()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
