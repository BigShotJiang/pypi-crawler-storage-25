"""Batch runner: consume N messages, process, exit."""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC, datetime

from sqlalchemy.orm import Session

from pygubernator._protocols import Transport
from pygubernator._types import AgentResult
from pygubernator.agents._base import BaseAgent
from pygubernator.db.store.sqlalchemy import SQLAlchemyAgentStore
from pygubernator.events._bus import AgentEvent, AgentEventType, EventBus
from pygubernator.events._handlers import DatabaseEventHandler

logger = logging.getLogger(__name__)


async def run_batch(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    max_messages: int = 100,
    event_bus: EventBus | None = None,
    run_id: str | None = None,
) -> AgentResult:
    """Run an agent in batch mode.

    Consumes up to max_messages from the topic, processes each
    through the agent, then stops. Suitable for Airflow tasks.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        max_messages: Maximum messages to process.
        event_bus: Optional event bus for emitting run events.
        run_id: Optional run identifier for correlating events.

    Returns:
        Aggregate result of all processed messages.
    """
    if run_id is not None:
        agent.set_run_id(run_id)

    agent.start()
    if event_bus:
        await event_bus.emit(
            AgentEvent(
                event_type=AgentEventType.RUN_STARTED,
                agent_id=agent.agent_id,
                data={"mode": "batch", "topic": topic},
                run_id=run_id,
            )
        )
    total_processed = 0
    all_errors: list[str] = []

    try:
        messages = await transport.consume(topic, max_messages)
        logger.info(
            "Batch run: consuming %d messages from %s",
            len(messages),
            topic,
        )

        for msg in messages:
            result = await agent.process(msg)
            total_processed += result.messages_processed
            all_errors.extend(result.errors)

        await transport.commit()

    except Exception as exc:
        logger.error("Batch run failed: %s", exc)
        all_errors.append(str(exc))
    finally:
        agent.stop()
        await transport.close()

    success = len(all_errors) == 0
    if event_bus:
        await event_bus.emit(
            AgentEvent(
                event_type=AgentEventType.RUN_COMPLETED,
                agent_id=agent.agent_id,
                data={
                    "mode": "batch",
                    "topic": topic,
                    "success": success,
                    "messages_processed": total_processed,
                },
                run_id=run_id,
            )
        )
    return AgentResult(
        agent_id=agent.agent_id,
        success=success,
        messages_processed=total_processed,
        errors=all_errors,
        metadata={"mode": "batch", "topic": topic},
    )


async def run_batch_with_db(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    db_session_factory: Callable[[], Session],
    agent_id: str,
    agent_version_id: str | None = None,
    max_messages: int = 100,
    correlation_id: str | None = None,
    trigger: str | None = None,
    metadata_json: dict | None = None,
) -> AgentResult:
    """Run an agent in batch mode with database integration.

    Creates a Run record, sets up DatabaseEventHandler, and updates run status.
    Suitable for workers that share database access with the control plane.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        db_session_factory: Callable that returns a SQLAlchemy Session.
        agent_id: Agent ID for the run record.
        agent_version_id: Optional agent version ID.
        max_messages: Maximum messages to process.
        correlation_id: Optional correlation ID for the run.
        trigger: Optional trigger source for the run.
        metadata_json: Optional metadata dict for the run.

    Returns:
        Aggregate result of all processed messages.
    """
    # Create Run record
    db = db_session_factory()
    store = SQLAlchemyAgentStore(session=db)
    try:
        run = store.create_run(
            agent_id=agent_id,
            agent_version_id=agent_version_id,
            status="queued",
            correlation_id=correlation_id,
            trigger=trigger,
            metadata_json=metadata_json or {},
        )
        store.commit()
        store.refresh(run)
        run_id = run.id
    finally:
        db.close()

    event_bus = agent.ensure_event_bus()
    db_handler = DatabaseEventHandler(db_session_factory)
    event_bus.add_handler(db_handler)

    # Update run status to running
    db = db_session_factory()
    store = SQLAlchemyAgentStore(session=db)
    try:
        run = store.get_run(run_id)
        if run:
            store.update_run(run, status="running", started_at=datetime.now(UTC))
            store.commit()
    finally:
        db.close()

    # Run the agent
    try:
        result = await run_batch(
            agent=agent,
            transport=transport,
            topic=topic,
            max_messages=max_messages,
            event_bus=event_bus,
            run_id=run_id,
        )

        # Update run status on completion
        db = db_session_factory()
        store = SQLAlchemyAgentStore(session=db)
        try:
            run = store.get_run(run_id)
            if run:
                ended_at = datetime.now(UTC)
                duration_ms = None
                if run.started_at:
                    delta = ended_at - run.started_at
                    duration_ms = int(delta.total_seconds() * 1000)
                store.update_run(
                    run,
                    status="succeeded" if result.success else "failed",
                    ended_at=ended_at,
                    duration_ms=duration_ms,
                    error_message="; ".join(result.errors) if result.errors else None,
                )
                store.commit()
        finally:
            db.close()

        return result
    except Exception as exc:
        # Update run status on error
        db = db_session_factory()
        store = SQLAlchemyAgentStore(session=db)
        try:
            run = store.get_run(run_id)
            if run:
                store.update_run(
                    run,
                    status="failed",
                    ended_at=datetime.now(UTC),
                    error_message=str(exc),
                )
                store.commit()
        finally:
            db.close()
        raise
