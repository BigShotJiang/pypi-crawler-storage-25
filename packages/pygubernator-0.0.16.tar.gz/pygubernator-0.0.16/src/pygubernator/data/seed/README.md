# Pygubernator Seed Data

This directory contains packaged seed artifacts used by `pygubernator db seed`.

## Layout

- `workflows/`
  Default database seed workflows. These are intentionally self-sufficient and
  runnable without external services or credentials.
- `machines/`
  Supporting machine YAML used by integration metadata and editor guidance.

## Seeding Behavior

- `pygubernator db seed` seeds:
  1. workflow YAML files from `data/seed/workflows/`
  2. curated workflow templates from `workflow/templates/`
- Seeding is idempotent by workflow natural key: `meta.name` + `meta.version`.
- Existing versions are skipped, new versions are inserted.

## Custom Seed Directory

You can provide a custom directory:

`pygubernator db seed /path/to/my/seeds`

The directory is scanned recursively for `.yaml`/`.yml` workflow specs.
