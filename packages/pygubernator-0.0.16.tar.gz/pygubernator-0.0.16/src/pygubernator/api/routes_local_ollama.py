"""Proxy routes to a local Ollama daemon (Settings UI — model list / pull / delete)."""

from __future__ import annotations

import json
import logging
from typing import Any
from urllib.parse import urlparse, urlunparse

import httpx
from fastapi import APIRouter, HTTPException, Query, status

from pygubernator.api.deps import AdminUser, CurrentUser
from pygubernator.api.models import (
    LocalOllamaDeleteRequest,
    LocalOllamaDeleteResponse,
    LocalOllamaModelRow,
    LocalOllamaPullRequest,
    LocalOllamaPullResponse,
    LocalOllamaStatusResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/settings/local-ollama", tags=["settings"])

DEFAULT_OLLAMA_BASE = "http://127.0.0.1:11434"

_ALLOWED_HOSTS = frozenset({"localhost", "127.0.0.1", "host.docker.internal", "::1"})


def normalize_and_validate_ollama_base(raw: str | None) -> str:
    """Return Ollama native API root (``scheme://host:port``), no path.

    Strips a trailing ``/v1`` so users can paste an OpenAI-compat base URL.

    Raises:
        ValueError: Invalid scheme, host, or disallowed hostname (SSRF guard).
    """
    s = (raw or "").strip()
    if not s:
        s = DEFAULT_OLLAMA_BASE
    s = s.rstrip("/")
    if s.endswith("/v1"):
        s = s[:-3].rstrip("/")
    parsed = urlparse(s)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Ollama base URL must use http or https")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Userinfo is not allowed in Ollama base URL")
    host = parsed.hostname
    if not host:
        raise ValueError("Ollama base URL must include a host")
    if host.lower() not in _ALLOWED_HOSTS:
        raise ValueError(
            "Ollama host must be localhost, 127.0.0.1, host.docker.internal, or ::1"
        )
    port = parsed.port
    if port is None:
        port = 11434
    netloc = _format_netloc(host, port)
    return urlunparse((parsed.scheme, netloc, "", "", "", "")).rstrip("/")


def _format_netloc(host: str, port: int) -> str:
    if ":" in host and "." not in host:
        return f"[{host}]:{port}"
    return f"{host}:{port}"


def _bad_base(exc: ValueError) -> HTTPException:
    logger.info("Invalid Ollama base URL: %s", exc)
    return HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=(
            "Invalid Ollama base URL. Allowed hosts: localhost, 127.0.0.1, "
            "host.docker.internal, ::1; use http or https without credentials."
        ),
    )


def _parse_tags_models(payload: dict[str, Any]) -> list[LocalOllamaModelRow]:
    rows: list[LocalOllamaModelRow] = []
    for item in payload.get("models") or []:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if not name:
            continue
        rows.append(
            LocalOllamaModelRow(
                name=str(name),
                size=item.get("size") if isinstance(item.get("size"), int) else None,
                digest=str(item["digest"]) if item.get("digest") else None,
                modified_at=(
                    str(item["modified_at"]) if item.get("modified_at") else None
                ),
            )
        )
    return rows


@router.get(
    "/status",
    response_model=LocalOllamaStatusResponse,
    summary="List local Ollama models (GET /api/tags proxy)",
)
async def local_ollama_status(
    _: CurrentUser,
    base_url: str | None = Query(
        None,
        description="Ollama daemon root URL (optional; default 127.0.0.1:11434)",
    ),
) -> LocalOllamaStatusResponse:
    try:
        base = normalize_and_validate_ollama_base(base_url)
    except ValueError as exc:
        raise _bad_base(exc) from exc

    try:
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{base}/api/tags", timeout=15.0)
            if r.status_code >= 400:
                return LocalOllamaStatusResponse(
                    reachable=False,
                    base_url=base,
                    models=[],
                    error=f"Ollama returned HTTP {r.status_code}: {r.text[:500]}",
                )
            data = r.json()
            if not isinstance(data, dict):
                return LocalOllamaStatusResponse(
                    reachable=True,
                    base_url=base,
                    models=[],
                    error="Unexpected response shape from Ollama",
                )
            return LocalOllamaStatusResponse(
                reachable=True,
                base_url=base,
                models=_parse_tags_models(data),
                error=None,
            )
    except httpx.RequestError as exc:
        logger.info("Ollama status unreachable: %s", exc)
        return LocalOllamaStatusResponse(
            reachable=False,
            base_url=base,
            models=[],
            error=f"Cannot reach Ollama at {base}: {exc}",
        )


@router.post(
    "/pull",
    response_model=LocalOllamaPullResponse,
    summary="Pull a model (POST /api/pull proxy, admin)",
)
async def local_ollama_pull(
    _: AdminUser, body: LocalOllamaPullRequest
) -> LocalOllamaPullResponse:
    try:
        base = normalize_and_validate_ollama_base(body.base_url)
    except ValueError as exc:
        raise _bad_base(exc) from exc

    timeout = httpx.Timeout(30.0, read=900.0)
    last_line = ""
    try:
        async with (
            httpx.AsyncClient() as client,
            client.stream(
                "POST",
                f"{base}/api/pull",
                json={"name": body.name},
                timeout=timeout,
            ) as stream,
        ):
            if stream.status_code >= 400:
                body_bytes = await stream.aread()
                msg = body_bytes.decode("utf-8", errors="replace")[:800]
                return LocalOllamaPullResponse(
                    ok=False,
                    detail=f"Ollama pull failed (HTTP {stream.status_code}): {msg}",
                )
            async for line in stream.aiter_lines():
                if line:
                    last_line = line
        detail = None
        if last_line:
            try:
                j = json.loads(last_line)
                if isinstance(j, dict) and j.get("status"):
                    detail = str(j["status"])
            except json.JSONDecodeError:
                detail = last_line[:500]
        return LocalOllamaPullResponse(ok=True, detail=detail)
    except httpx.RequestError as exc:
        logger.warning("Ollama pull request error: %s", exc)
        return LocalOllamaPullResponse(
            ok=False,
            detail=f"Cannot reach Ollama at {base}: {exc}",
        )


@router.post(
    "/delete",
    response_model=LocalOllamaDeleteResponse,
    summary="Delete a model (DELETE /api/delete proxy, admin)",
)
async def local_ollama_delete(
    _: AdminUser, body: LocalOllamaDeleteRequest
) -> LocalOllamaDeleteResponse:
    try:
        base = normalize_and_validate_ollama_base(body.base_url)
    except ValueError as exc:
        raise _bad_base(exc) from exc

    try:
        async with httpx.AsyncClient() as client:
            r = await client.request(
                "DELETE",
                f"{base}/api/delete",
                json={"name": body.name},
                timeout=60.0,
            )
            if r.status_code >= 400:
                return LocalOllamaDeleteResponse(
                    ok=False,
                    detail=f"Ollama delete failed (HTTP {r.status_code}): {r.text[:800]}",
                )
            return LocalOllamaDeleteResponse(ok=True, detail=None)
    except httpx.RequestError as exc:
        logger.warning("Ollama delete request error: %s", exc)
        return LocalOllamaDeleteResponse(
            ok=False,
            detail=f"Cannot reach Ollama at {base}: {exc}",
        )
