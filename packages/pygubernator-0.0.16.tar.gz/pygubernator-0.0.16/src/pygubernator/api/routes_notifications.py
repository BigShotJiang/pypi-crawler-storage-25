"""Notification rule management API routes (admin-only)."""

from __future__ import annotations

import logging
from datetime import datetime

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_not_found,
)
from pygubernator.api.deps import AdminUser, DbSession
from pygubernator.db.models import NotificationRule
from pygubernator.notifications import (
    LogChannel,
    NotificationDispatcher,
    SlackChannel,
    WebhookChannel,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin/notifications",
    tags=["notifications"],
)


# --------------- Request / Response models ---------------


class RuleCreate(BaseModel):
    """Request body to create a notification rule."""

    name: str = Field(..., description="Rule name")
    event_type: str = Field(..., description="Event type to match")
    channel_type: str = Field(..., description="Channel: webhook, slack, or log")
    channel_config: dict = Field(
        default_factory=dict,
        description="Channel-specific config (url, etc.)",
    )
    enabled: bool = Field(default=True)


class RuleUpdate(BaseModel):
    """Request body for partial rule update."""

    name: str | None = Field(default=None)
    event_type: str | None = Field(default=None)
    channel_type: str | None = Field(default=None)
    channel_config: dict | None = Field(default=None)
    enabled: bool | None = Field(default=None)


class RuleResponse(BaseModel):
    """Response model for a notification rule."""

    id: str
    name: str
    event_type: str
    channel_type: str
    channel_config: dict
    enabled: bool
    created_by: str
    created_at: datetime
    updated_at: datetime


# --------------- Helpers ---------------


def _to_response(row: NotificationRule) -> RuleResponse:
    """Convert a DB row to a response model."""
    return RuleResponse(
        id=row.id,
        name=row.name,
        event_type=row.event_type,
        channel_type=row.channel_type,
        channel_config=row.channel_config,
        enabled=row.enabled,
        created_by=row.created_by,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


# --------------- Endpoints ---------------


@router.get("")
def list_rules(
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """List all notification rules."""
    rows = db.query(NotificationRule).all()
    items = [_to_response(r).model_dump(mode="json") for r in rows]
    return {"items": items}


@router.post("", response_model=RuleResponse)
def create_rule(
    payload: RuleCreate,
    _admin: AdminUser,
    db: DbSession,
) -> RuleResponse:
    """Create a new notification rule."""
    row = NotificationRule(
        name=payload.name,
        event_type=payload.event_type,
        channel_type=payload.channel_type,
        channel_config=payload.channel_config,
        enabled=payload.enabled,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info("Created notification rule %s", row.name)
    return _to_response(row)


@router.patch("/{rule_id}", response_model=RuleResponse)
def update_rule(
    rule_id: str,
    payload: RuleUpdate,
    _admin: AdminUser,
    db: DbSession,
) -> RuleResponse:
    """Update an existing notification rule."""
    row = db.get(NotificationRule, rule_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"rule_id={rule_id}"),
            public_detail="Rule not found",
            log_event="notification_rule_not_found",
        )
    if payload.name is not None:
        row.name = payload.name
    if payload.event_type is not None:
        row.event_type = payload.event_type
    if payload.channel_type is not None:
        row.channel_type = payload.channel_type
    if payload.channel_config is not None:
        row.channel_config = payload.channel_config
    if payload.enabled is not None:
        row.enabled = payload.enabled
    db.commit()
    db.refresh(row)
    logger.info("Updated notification rule %s", row.name)
    return _to_response(row)


@router.delete("/{rule_id}")
def delete_rule(
    rule_id: str,
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """Delete a notification rule."""
    row = db.get(NotificationRule, rule_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"rule_id={rule_id}"),
            public_detail="Rule not found",
            log_event="notification_rule_not_found",
        )
    name = row.name
    db.delete(row)
    db.commit()
    logger.info("Deleted notification rule %s", name)
    return {"ok": True, "deleted": rule_id}


@router.post("/{rule_id}/test")
async def test_rule(
    rule_id: str,
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """Send a test notification for a rule."""
    row = db.get(NotificationRule, rule_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"rule_id={rule_id}"),
            public_detail="Rule not found",
            log_event="notification_rule_not_found",
        )

    channel = _build_channel(row.channel_type, row.channel_config)
    dispatcher = NotificationDispatcher()
    dispatcher.add_channel(channel)
    await dispatcher.notify(
        subject="Test notification",
        body=f"Test from rule '{row.name}'.",
        metadata={"rule_id": row.id, "test": True},
    )
    return {"ok": True, "rule_id": rule_id}


def _build_channel(
    channel_type: str,
    config: dict,
) -> WebhookChannel | SlackChannel | LogChannel:
    """Instantiate a channel from type string and config.

    Args:
        channel_type: One of ``webhook``, ``slack``, ``log``.
        config: Channel-specific configuration dict.

    Returns:
        A concrete notification channel instance.

    Raises:
        HTTPException: If the channel_type is unknown.
    """
    if channel_type == "webhook":
        url = config.get("url", "")
        headers = config.get("headers")
        return WebhookChannel(url=url, headers=headers)
    if channel_type == "slack":
        url = config.get("webhook_url", "")
        return SlackChannel(webhook_url=url)
    if channel_type == "log":
        return LogChannel()
    raise_logged_bad_request(
        logger,
        ValueError(f"unknown channel type: {channel_type}"),
        public_detail=f"Unknown channel type: {channel_type}",
        log_event="notification_channel_unknown_type",
    )
