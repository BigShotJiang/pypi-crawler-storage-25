"""Template gallery routes — list, inspect, and import workflow templates.

Backed by :mod:`pygubernator.workflow.templates`. The routes are
intentionally thin: they delegate metadata parsing to the template
loader and workflow creation to the agent store, keeping the HTTP layer
a pure adapter.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter

from pygubernator.api._http_errors import (
    raise_logged_not_found,
    raise_logged_unprocessable,
)
from pygubernator.api._routes_common import emit_audit
from pygubernator.api.deps import AgentStore, CurrentUser
from pygubernator.api.models import (
    TemplateDetailOut,
    TemplateImportOut,
    TemplateImportRequest,
    TemplateSummaryOut,
)
from pygubernator.workflow.templates import (
    TemplateError,
    WorkflowTemplate,
    list_templates,
    load_template,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/templates", tags=["templates"])


def _summary_model(template: WorkflowTemplate) -> TemplateSummaryOut:
    """Convert a template to its summary Pydantic model."""
    return TemplateSummaryOut(**template.to_summary_dict())


def _detail_model(template: WorkflowTemplate) -> TemplateDetailOut:
    """Convert a template to its detail (with spec) Pydantic model."""
    return TemplateDetailOut(**template.to_detail_dict())


@router.get("")
def list_templates_route(_: CurrentUser) -> dict:
    """List every bundled + plugin-contributed template.

    The response is sorted by primary tag, then title. Callers use
    ``GET /api/v1/templates/{slug}`` to fetch the full spec.
    """
    items = [_summary_model(t).model_dump() for t in list_templates()]
    return {"items": items, "meta": {"total": len(items)}}


@router.get("/{slug}", response_model=TemplateDetailOut)
def get_template_route(slug: str, _: CurrentUser) -> TemplateDetailOut:
    """Return the full template including its workflow spec."""
    try:
        template = load_template(slug)
    except TemplateError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail="Template not found",
            log_event="template get failed",
        )
    return _detail_model(template)


@router.post("/{slug}/import", response_model=TemplateImportOut)
def import_template_route(
    slug: str,
    payload: TemplateImportRequest | None,
    store: AgentStore,
    actor: CurrentUser,
) -> TemplateImportOut:
    """Clone a template into the caller's workspace.

    Creates a new workflow (with a human-friendly name derived from the
    template) plus its first version containing the template spec.
    Returns identifiers the UI uses to deep-link the editor straight to
    the imported workflow.
    """
    try:
        template = load_template(slug)
    except TemplateError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail="Template not found",
            log_event="template import load failed",
        )

    # Validate the embedded spec before we touch the database — fail fast
    # with a 422 rather than leaving a half-created workflow behind.
    try:
        template.to_workflow_spec()
    except TemplateError as exc:
        raise_logged_unprocessable(
            logger,
            exc,
            public_detail="Invalid template workflow spec",
            log_event="template to_workflow_spec failed",
        )

    overrides = payload or TemplateImportRequest()
    username = actor["username"]
    default_name = f"{template.title} (from template)"
    workflow_name = (overrides.name or default_name).strip() or default_name
    workflow_description = (overrides.description or template.summary).strip()
    workflow_owner = (overrides.owner or username).strip() or username

    # Commit the workflow first so the ORM-generated id is available
    # for the version insert. Mirrors the two-step pattern used by
    # ``routes_workflows.create_workflow_route`` /
    # ``routes_workflows.create_version_route``.
    wf = store.create_workflow(
        name=workflow_name,
        description=workflow_description,
        owner=workflow_owner,
    )
    emit_audit(
        store,
        actor,
        "workflow.template.import",
        resource_type="workflow",
        resource_id=wf.id,
        details={
            "slug": slug,
            "template_title": template.title,
            "name": workflow_name,
        },
    )
    store.commit()
    store.refresh(wf)

    version = template.version or "1.0.0"
    wv = store.create_workflow_version(
        workflow_id=wf.id,
        version=version,
        spec_json=template.spec,
        created_by=username,
    )
    # Mirror the bump-on-save behaviour in routes_workflows.
    wv.revision = (wv.revision or 0) + 1
    store.commit()
    store.refresh(wv)

    logger.info(
        "imported template '%s' as workflow %s (version %s) for %s",
        slug,
        wf.id,
        wv.id,
        username,
    )

    return TemplateImportOut(
        workflow_id=wf.id,
        version_id=wv.id,
        version=version,
        slug=slug,
    )
