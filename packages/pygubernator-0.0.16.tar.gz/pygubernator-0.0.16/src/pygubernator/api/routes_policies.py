"""Policy assignment and alert routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from pygubernator.api._http_errors import raise_logged_not_found
from pygubernator.api._routes_common import emit_audit
from pygubernator.api.deps import AdminUser, AgentStore, CurrentUser
from pygubernator.api.models import (
    AlertRuleRequest,
    AlertRuleToggleRequest,
    PolicyAssignmentRequest,
)
from pygubernator.db.models import AlertRule, Incident, PolicyAssignment

router = APIRouter(prefix="/api/v1/policies", tags=["policies"])
logger = logging.getLogger(__name__)


@router.get("")
def get_policies(
    store: AgentStore, _: CurrentUser, agent_id: str | None = None
) -> dict:
    items = store.list_policies(agent_id)
    return {
        "items": [
            {
                "id": i.id,
                "agent_id": i.agent_id,
                "policy_type": i.policy_type,
                "policy_value": i.policy_value,
                "enabled": i.enabled,
                "created_at": i.created_at,
            }
            for i in items
        ]
    }


@router.post("")
def upsert_policy(
    payload: PolicyAssignmentRequest, store: AgentStore, actor: AdminUser
) -> dict:
    rec = PolicyAssignment(
        agent_id=payload.agent_id,
        policy_type=payload.policy_type,
        policy_value=payload.policy_value,
        enabled=payload.enabled,
    )
    store.add(rec)
    emit_audit(
        store,
        actor,
        "policy.create",
        resource_type="policy_assignment",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"id": rec.id}


@router.get("/alerts")
def get_alerts(store: AgentStore, _: CurrentUser) -> dict:
    sess = store.session
    incident_counts = {
        alert_id: count
        for alert_id, count in sess.execute(
            select(Incident.alert_id, func.count(Incident.id))
            .where(Incident.alert_id.is_not(None), Incident.status != "resolved")
            .group_by(Incident.alert_id)
        ).all()
    }
    items = sess.scalars(select(AlertRule).order_by(AlertRule.created_at.desc())).all()
    return {
        "items": [
            {
                "id": i.id,
                "name": i.name,
                "severity": i.severity,
                "condition": i.condition,
                "enabled": i.enabled,
                "open_incidents": int(incident_counts.get(i.id, 0)),
                "firing": int(incident_counts.get(i.id, 0)) > 0,
            }
            for i in items
        ]
    }


@router.post("/alerts")
def create_alert(
    payload: AlertRuleRequest, store: AgentStore, actor: AdminUser
) -> dict:
    rec = AlertRule(
        name=payload.name,
        severity=payload.severity,
        condition=payload.condition,
        enabled=payload.enabled,
    )
    store.add(rec)
    emit_audit(
        store,
        actor,
        "alert.create",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"id": rec.id}


@router.post("/alerts/{alert_id}/toggle")
def toggle_alert(
    alert_id: str,
    payload: AlertRuleToggleRequest,
    store: AgentStore,
    actor: AdminUser,
) -> dict:
    rec = store.session.get(AlertRule, alert_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"alert_id={alert_id}"),
            public_detail="Alert not found",
            log_event="policy_alert_not_found",
        )
    rec.enabled = payload.enabled
    emit_audit(
        store,
        actor,
        "alert.toggle",
        resource_type="alert",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return {"ok": True, "id": rec.id, "enabled": rec.enabled}


@router.get("/audit")
def get_audit_logs(
    store: AgentStore,
    _: CurrentUser,
    limit: int = Query(100, ge=1, le=500),
    resource_id: str | None = None,
    resource_type: str | None = None,
) -> dict:
    rows = store.list_audit_logs(
        limit=limit,
        resource_id=resource_id,
        resource_type=resource_type,
    )
    return {
        "items": [
            {
                "id": r.id,
                "actor": r.actor,
                "action": r.action,
                "resource_type": r.resource_type,
                "resource_id": r.resource_id,
                "details": r.details,
                "created_at": r.created_at,
            }
            for r in rows
        ]
    }


@router.get("/alerts/history")
def get_alert_history(
    store: AgentStore,
    _: CurrentUser,
    alert_id: str | None = None,
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    query = (
        select(Incident)
        .where(Incident.alert_id.is_not(None))
        .order_by(Incident.created_at.desc())
    )
    if alert_id:
        query = query.where(Incident.alert_id == alert_id)
    rows = store.session.scalars(query.limit(limit)).all()
    return {
        "items": [
            {
                "id": row.id,
                "alert_id": row.alert_id,
                "title": row.title,
                "severity": row.severity,
                "status": row.status,
                "owner": row.owner,
                "created_at": row.created_at,
                "resolved_at": row.resolved_at,
            }
            for row in rows
        ]
    }
