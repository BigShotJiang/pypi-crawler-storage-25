"""Memory / context-surface routes (Phase 6 §6.9).

Surfaces the agent-notebook backed by ``ContextSurface``: a structured
Markdown document (facts / questions / next_actions / log) the
operator can read and edit. Agents that already use ``AgentContextStore``
in workflows write to the same store under the conventional
``"context_surface"`` key, so the UI is editing exactly what agents
see — no shadow notebook.

Three routes:

- ``GET /api/v1/memory/scopes`` — list every distinct scope that has
  a saved ``context_surface`` row.
- ``GET /api/v1/memory/surface`` — read the surface for the scope
  encoded by query params (``agent_id``, ``workflow_id``, ``user_id``,
  ``run_id`` — at least one required). Returns the structured dict
  + a Markdown rendering ready for the editor.
- ``PUT /api/v1/memory/surface`` — replace the surface from posted
  Markdown.

Scopes use the same composite-key model the rest of the package uses
(``MemoryScope.to_key()``) so notebooks isolate cleanly between
agents, workflows, users, and runs.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Query
from pydantic import BaseModel
from sqlalchemy import select

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_not_found,
)
from pygubernator.api.deps import AgentStore, CurrentUser
from pygubernator.db.models import GenericRecord
from pygubernator.memory._backends import CONTEXT_KIND, SqlAlchemyContextStore
from pygubernator.memory._scope import MemoryScope
from pygubernator.memory._surface import ContextSurface

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/memory", tags=["memory"])

# Conventional key under which agents store their notebook in
# ``AgentContextStore``. Mirrors ``LLMAgent.context_key`` default.
_SURFACE_KEY = "context_surface"

# Agents write context-store records with this ``kind``; the actual key
# (``context_surface``) lives inside ``payload.key``. We hit the
# ``GenericRecord`` table directly to discover scopes because the
# protocol doesn't expose a list-scopes operation.
_RECORD_KIND = CONTEXT_KIND


class _MemoryScopeOut(BaseModel):
    """A scope known to the memory store, with its component fields."""

    key: str
    agent_id: str | None = None
    workflow_id: str | None = None
    user_id: str | None = None
    run_id: str | None = None


class _MemoryScopesOut(BaseModel):
    """Envelope for the list-scopes response."""

    items: list[_MemoryScopeOut]


class _ContextSurfaceOut(BaseModel):
    """Read response for one ContextSurface, in both shapes the UI needs."""

    scope: _MemoryScopeOut
    surface: dict[str, list[str]]
    markdown: str


class _ContextSurfaceUpdateRequest(BaseModel):
    """Body for the surface PUT route."""

    markdown: str


def _scope_from_query(
    agent_id: str | None,
    workflow_id: str | None,
    user_id: str | None,
    run_id: str | None,
) -> MemoryScope:
    """Build a non-empty :class:`MemoryScope` from query params or 400."""
    scope = MemoryScope(
        agent_id=agent_id,
        workflow_id=workflow_id,
        user_id=user_id,
        run_id=run_id,
    )
    if scope.to_key() == "__global__":
        raise_logged_bad_request(
            logger,
            ValueError("scope query missing all id fields"),
            public_detail=(
                "At least one of agent_id, workflow_id, user_id, run_id "
                "must be provided to identify the memory scope"
            ),
            log_event="memory_scope_missing",
        )
    return scope


def _parse_scope_key(raw: str) -> _MemoryScopeOut:
    """Reverse :meth:`MemoryScope.to_key` — best-effort decode for the UI."""
    fields: dict[str, str | None] = {
        "agent_id": None,
        "workflow_id": None,
        "user_id": None,
        "run_id": None,
    }
    if raw and raw != "__global__":
        for part in raw.split("|"):
            name, _, value = part.partition("=")
            field_name = f"{name.strip()}_id" if name.strip() else ""
            if field_name in fields:
                fields[field_name] = value.strip() or None
    return _MemoryScopeOut(key=raw, **fields)


@router.get("/scopes", response_model=_MemoryScopesOut)
def list_memory_scopes_route(
    store: AgentStore,
    _: CurrentUser,
) -> _MemoryScopesOut:
    """List every scope that has a saved context surface.

    Powers the left-hand list on the Knowledge → Notebooks UI: one
    entry per scope, decoded into its component ids so the UI can
    show "agent X · workflow Y" without re-parsing. Two-step query
    so the filter on ``payload.key="context_surface"`` stays portable
    across SQLite / Postgres / MySQL: first the distinct scope list,
    then a per-scope ``keys()`` check.
    """
    rows = store.session.execute(
        select(GenericRecord.scope)
        .where(GenericRecord.kind == _RECORD_KIND)
        .where(GenericRecord.scope.isnot(None))
        .distinct()
    ).all()
    candidate_keys = sorted({str(row[0]) for row in rows if row[0]})
    if not candidate_keys:
        return _MemoryScopesOut(items=[])

    backend = SqlAlchemyContextStore(session_factory=lambda: store.session)
    items: list[_MemoryScopeOut] = []
    for raw_key in candidate_keys:
        scope = _scope_from_string_key(raw_key)
        if scope is None:
            continue
        live_keys = backend.keys(scope)
        if _SURFACE_KEY in live_keys:
            items.append(_parse_scope_key(raw_key))
    return _MemoryScopesOut(items=items)


def _scope_from_string_key(raw: str) -> MemoryScope | None:
    """Reverse :meth:`MemoryScope.to_key` into a fresh :class:`MemoryScope`.

    Returns ``None`` for the global scope key — the route layer never
    surfaces global scopes (the editor requires at least one id).
    """
    if not raw or raw == "__global__":
        return None
    fields: dict[str, str | None] = {
        "agent_id": None,
        "workflow_id": None,
        "user_id": None,
        "run_id": None,
    }
    for part in raw.split("|"):
        name, _, value = part.partition("=")
        attr = f"{name.strip()}_id" if name.strip() else ""
        if attr in fields and value.strip():
            fields[attr] = value.strip()
    return MemoryScope(**fields)


@router.get("/surface", response_model=_ContextSurfaceOut)
def get_context_surface_route(
    store: AgentStore,
    _: CurrentUser,
    agent_id: str | None = Query(default=None),
    workflow_id: str | None = Query(default=None),
    user_id: str | None = Query(default=None),
    run_id: str | None = Query(default=None),
) -> _ContextSurfaceOut:
    """Read the ``ContextSurface`` for the scope identified by query params.

    Returns 404 only if the scope is unknown to the store. Empty
    surfaces (newly-minted scopes) come back with empty section lists
    + an empty Markdown skeleton — callers don't need to special-case.
    """
    scope = _scope_from_query(agent_id, workflow_id, user_id, run_id)
    backend = SqlAlchemyContextStore(session_factory=lambda: store.session)
    raw = backend.get(scope, _SURFACE_KEY, default=None)
    if raw is None:
        raise_logged_not_found(
            logger,
            LookupError(f"scope={scope.to_key()}"),
            public_detail="No context surface found for this scope",
            log_event="memory_surface_not_found",
        )
    surface = ContextSurface.from_dict(
        raw if isinstance(raw, dict) else {},
    )
    return _ContextSurfaceOut(
        scope=_parse_scope_key(scope.to_key()),
        surface=surface.to_dict(),
        markdown=surface.to_markdown(),
    )


@router.put("/surface", response_model=_ContextSurfaceOut)
def put_context_surface_route(
    payload: _ContextSurfaceUpdateRequest,
    store: AgentStore,
    _: CurrentUser,
    agent_id: str | None = Query(default=None),
    workflow_id: str | None = Query(default=None),
    user_id: str | None = Query(default=None),
    run_id: str | None = Query(default=None),
) -> _ContextSurfaceOut:
    """Replace the ``ContextSurface`` for one scope from posted Markdown.

    The body's ``markdown`` is parsed via
    :meth:`ContextSurface.from_markdown` so the editor's round-trip
    matches what an agent would write programmatically. Sections not
    represented in the Markdown are emptied — the editor is the
    canonical source for what the surface contains after a save.
    """
    scope = _scope_from_query(agent_id, workflow_id, user_id, run_id)
    surface = ContextSurface.from_markdown(payload.markdown or "")
    backend = SqlAlchemyContextStore(session_factory=lambda: store.session)
    backend.set(scope, _SURFACE_KEY, surface.to_dict())
    store.commit()
    return _ContextSurfaceOut(
        scope=_parse_scope_key(scope.to_key()),
        surface=surface.to_dict(),
        markdown=surface.to_markdown(),
    )


# Re-export the private helpers under stable names for tests that
# want to verify the scope key parser without reaching into the route
# module's underscored API.
parse_scope_key = _parse_scope_key
SURFACE_RECORD_KIND = _RECORD_KIND


__all__ = [
    "SURFACE_RECORD_KIND",
    "parse_scope_key",
    "router",
]


# --- Helpers used elsewhere ---------------------------------------------------


def _build_scope_filter(
    agent_id: str | None,
    workflow_id: str | None,
    user_id: str | None,
    run_id: str | None,
) -> dict[str, Any]:
    """Pure helper exported for tests; non-route callers can rebuild a scope."""
    return {
        "agent_id": agent_id,
        "workflow_id": workflow_id,
        "user_id": user_id,
        "run_id": run_id,
    }
