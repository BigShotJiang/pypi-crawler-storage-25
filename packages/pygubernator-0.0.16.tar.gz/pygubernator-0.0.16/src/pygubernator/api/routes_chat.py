"""Chat session HTTP API routes."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import raise_logged_not_found
from pygubernator.api.deps import CurrentUser, DbSession
from pygubernator.db.models import ChatSessionRecord
from pygubernator.llm._factory import create_provider

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/chat", tags=["chat"])


# --------------- Request / Response models ---------------


class ChatSessionCreate(BaseModel):
    """Request body to create a chat session."""

    model: str = Field(..., description="LLM model identifier")
    system_prompt: str = Field(default="", description="System prompt")
    title: str = Field(
        default="New conversation",
        description="Session title",
    )


class ChatMessageRequest(BaseModel):
    """Request body to send a message."""

    message: str = Field(..., description="The user's text message")


class ChatSessionResponse(BaseModel):
    """Response model for a chat session."""

    id: str
    title: str
    model: str
    message_count: int
    created_at: datetime
    updated_at: datetime


class ChatMessageResponse(BaseModel):
    """Response model after sending a message."""

    response: str
    session_id: str
    message_count: int


# --------------- Helpers ---------------


def _session_to_response(
    row: ChatSessionRecord,
) -> ChatSessionResponse:
    """Convert a DB row to a response model."""
    msgs: list[Any] = row.messages_json or []
    return ChatSessionResponse(
        id=row.id,
        title=row.title,
        model=row.model,
        message_count=len(msgs),
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


# --------------- Endpoints ---------------


@router.get("/sessions")
def list_sessions(
    actor: CurrentUser,
    db: DbSession,
) -> dict:
    """List chat sessions for the current user."""
    username = str(actor.get("username", "anonymous"))
    rows = (
        db.query(ChatSessionRecord)
        .filter(ChatSessionRecord.created_by == username)
        .order_by(ChatSessionRecord.updated_at.desc())
        .all()
    )
    items = [_session_to_response(r).model_dump(mode="json") for r in rows]
    return {"items": items}


@router.post("/sessions", response_model=ChatSessionResponse)
def create_session(
    payload: ChatSessionCreate,
    actor: CurrentUser,
    db: DbSession,
) -> ChatSessionResponse:
    """Create a new chat session."""
    username = str(actor.get("username", "anonymous"))
    row = ChatSessionRecord(
        model=payload.model,
        system_prompt=payload.system_prompt,
        title=payload.title,
        created_by=username,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info(
        "Created chat session %s for %s",
        row.id,
        username,
    )
    return _session_to_response(row)


@router.get(
    "/sessions/{session_id}",
    response_model=ChatSessionResponse,
)
def get_session(
    session_id: str,
    actor: CurrentUser,
    db: DbSession,
) -> ChatSessionResponse:
    """Get a chat session with message count."""
    row = db.get(ChatSessionRecord, session_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"chat_session_id={session_id}"),
            public_detail="Session not found",
            log_event="chat_session_not_found",
        )
    return _session_to_response(row)


@router.get("/sessions/{session_id}/messages")
def get_session_messages(
    session_id: str,
    actor: CurrentUser,
    db: DbSession,
) -> dict:
    """Return the full message history for a session."""
    row = db.get(ChatSessionRecord, session_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"chat_session_id={session_id}"),
            public_detail="Session not found",
            log_event="chat_session_not_found",
        )
    msgs: list[Any] = row.messages_json or []
    return {"messages": msgs}


@router.delete("/sessions/{session_id}")
def delete_session(
    session_id: str,
    actor: CurrentUser,
    db: DbSession,
) -> dict:
    """Delete a chat session."""
    row = db.get(ChatSessionRecord, session_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"chat_session_id={session_id}"),
            public_detail="Session not found",
            log_event="chat_session_not_found",
        )
    db.delete(row)
    db.commit()
    logger.info("Deleted chat session %s", session_id)
    return {"ok": True, "deleted": session_id}


@router.post(
    "/sessions/{session_id}/messages",
    response_model=ChatMessageResponse,
)
async def send_message(
    session_id: str,
    payload: ChatMessageRequest,
    actor: CurrentUser,
    db: DbSession,
) -> ChatMessageResponse:
    """Send a message and get an LLM response.

    Loads session history, calls the LLM provider, and
    persists both the user and assistant messages.
    """
    row = db.get(ChatSessionRecord, session_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"chat_session_id={session_id}"),
            public_detail="Session not found",
            log_event="chat_session_not_found",
        )

    provider = create_provider(row.model)

    messages: list[dict[str, str]] = []
    if row.system_prompt:
        messages.append({"role": "system", "content": row.system_prompt})

    history: list[Any] = row.messages_json or []
    messages.extend(history)
    messages.append({"role": "user", "content": payload.message})

    llm_response = await provider.chat(messages)
    assistant_text = llm_response.content

    history.append({"role": "user", "content": payload.message})
    history.append({"role": "assistant", "content": assistant_text})
    row.messages_json = history

    db.commit()
    db.refresh(row)

    return ChatMessageResponse(
        response=assistant_text,
        session_id=row.id,
        message_count=len(history),
    )
