"""Guide / planner routes (Phase 6 §6.7d).

Wraps the :mod:`pygubernator.workflow.nodes._llm_planner` parser in an
HTTP endpoint so the Guide UI can ask the configured LLM "which
workflow should I run for this user message?" without authoring a
full workflow first.

One route:

- ``POST /api/v1/guide/plan`` — body carries the user message and an
  optional workflow catalog override; response carries a
  ``decision`` discriminator (``"dispatch"`` / ``"reply"`` /
  ``"unresolved"``) plus the structured fields the planner produced.

Provider resolution mirrors the ``llm_planner`` node factory: an
explicit ``model`` (with optional ``api_base`` / ``api_key``) on the
request takes precedence; otherwise the route falls back to the
``PYGUBERNATOR_GUIDE_PLANNER_MODEL`` env var. If neither is set we
return 503 — the operator hasn't picked a default yet, and rejecting
loudly is better than silently calling a free-tier cloud model.

The catalog can be supplied explicitly (the UI can pass exactly what
it shows in its picker), or omitted — in which case the route builds
one from the workspace's workflows. Catalog entries match the shape
the node already understands: ``{workflow_id, name, description}``.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_service_unavailable,
)
from pygubernator.api.deps import AgentStore, CurrentUser
from pygubernator.workflow.nodes._llm_planner import (
    HANDLE_DISPATCH,
    HANDLE_REPLY,
    HANDLE_UNRESOLVED,
    parse_planner_response,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/guide", tags=["guide"])

# Env var that names the default planner model when the request body
# omits ``model``. Mirrors how the rest of the package layers config
# (request → env → fail loudly).
_DEFAULT_MODEL_ENV = "PYGUBERNATOR_GUIDE_PLANNER_MODEL"
_DEFAULT_API_BASE_ENV = "PYGUBERNATOR_GUIDE_PLANNER_API_BASE"
_DEFAULT_API_KEY_ENV = "PYGUBERNATOR_GUIDE_PLANNER_API_KEY"

# Same default the node uses, replicated here so the route is
# self-contained for the very-common "no catalog hint" case.
_DEFAULT_SYSTEM_PROMPT = (
    "You are a routing assistant. Pick the best workflow to run from "
    "the catalog below for the user's message, or reply directly if "
    "no workflow fits.\n\n"
    "Respond with a single JSON object and nothing else:\n"
    '- To run a workflow: {"workflow_id": "<id>", "args": {...}, '
    '"reason": "short rationale"}\n'
    '- To reply without running: {"reply": "<message>"}\n'
    '- If unsure: {"reply": "Could you clarify what you\'d like me '
    'to do?"}'
)


class _CatalogEntryIn(BaseModel):
    """One workflow the planner is allowed to pick.

    Optional fields keep the payload terse for the common case where
    the caller passes only ``workflow_id`` + ``name``.
    """

    workflow_id: str
    name: str | None = None
    description: str | None = None
    input_schema: dict[str, Any] | None = None


class _PlanRequest(BaseModel):
    """Body for the planner route.

    All LLM-config fields are optional — when omitted the route falls
    back to ``PYGUBERNATOR_GUIDE_PLANNER_*`` env vars.
    """

    user_message: str = Field(..., min_length=1)
    catalog: list[_CatalogEntryIn] | None = None
    model: str | None = None
    api_base: str | None = None
    api_key: str | None = None
    temperature: float = 0.0
    max_tokens: int = 1024
    system_prompt: str | None = None


class _PlanResponse(BaseModel):
    """Structured planner decision returned to the UI."""

    decision: str
    workflow_id: str | None = None
    args: dict[str, Any] | None = None
    reply: str | None = None
    reason: str | None = None
    allowed_workflow_ids: list[str]
    raw: str


def _allowed_ids_from_catalog(catalog: list[_CatalogEntryIn]) -> set[str]:
    """Collect the workflow ids the planner may pick."""
    return {
        entry.workflow_id.strip()
        for entry in catalog
        if entry.workflow_id and entry.workflow_id.strip()
    }


def _format_catalog_markdown(catalog: list[_CatalogEntryIn]) -> str:
    """Render the catalog as a numbered Markdown list for the prompt.

    Mirrors :func:`format_catalog` from the planner node; duplicating
    here keeps the route from depending on the node module's shape
    beyond what the parser exposes (and lets the route's catalog
    schema stay a Pydantic type, not a dict).
    """
    import json

    lines: list[str] = []
    for entry in catalog:
        wf_id = entry.workflow_id.strip()
        if not wf_id:
            continue
        name = entry.name or wf_id
        part = f"- id=`{wf_id}` · **{name}**"
        if entry.description:
            part += f" — {entry.description}"
        if entry.input_schema:
            part += f"\n  args: `{json.dumps(entry.input_schema, sort_keys=True)}`"
        lines.append(part)
    return "\n".join(lines) if lines else "(catalog is empty)"


def _build_catalog_from_store(store: AgentStore) -> list[_CatalogEntryIn]:
    """Fall back to the workspace's workflows when the request omits a catalog."""
    items, _total = store.list_workflows(page=1, page_size=100)
    catalog: list[_CatalogEntryIn] = []
    for wf in items:
        catalog.append(
            _CatalogEntryIn(
                workflow_id=wf.id,
                name=wf.name,
                description=wf.description or None,
            )
        )
    return catalog


def _resolve_provider(payload: _PlanRequest) -> Any:
    """Build an LLM provider from the request, falling back to env vars.

    Returns the constructed provider; raises 503 (via the standard
    helper) when no model is configured and 502 when the underlying
    provider factory blows up.
    """
    model = payload.model or os.getenv(_DEFAULT_MODEL_ENV)
    if not model or not model.strip():
        raise_logged_service_unavailable(
            logger,
            RuntimeError(f"no model on request and {_DEFAULT_MODEL_ENV} unset"),
            public_detail=(
                "No planner model is configured. Set "
                f"{_DEFAULT_MODEL_ENV} on the server or pass "
                "'model' in the request body."
            ),
            log_event="guide_planner_no_model",
        )
    api_base = payload.api_base or os.getenv(_DEFAULT_API_BASE_ENV)
    api_key = payload.api_key or os.getenv(_DEFAULT_API_KEY_ENV)
    # Lazy import: keeps route module importable in environments that
    # don't have llm extras installed (the route itself will 503 below
    # on the first attempt to use it).
    from pygubernator.llm._factory import create_provider

    try:
        return create_provider(
            model=model.strip(),
            api_base=api_base,
            api_key=api_key,
            max_tokens=payload.max_tokens,
            temperature=payload.temperature,
        )
    except Exception as exc:
        # Provider construction failures are nearly always config
        # issues (bad URL, missing extras) — surface them as 503 so
        # the UI can prompt the operator without leaking driver text.
        raise_logged_service_unavailable(
            logger,
            exc,
            public_detail="Could not initialise the planner LLM provider.",
            log_event="guide_planner_provider_init_failed",
        )


def _decision_handle(
    workflow_id: str | None,
    reply: str | None,
) -> str:
    """Map a parsed decision to its DAG-equivalent output handle."""
    if workflow_id:
        return HANDLE_DISPATCH
    if reply:
        return HANDLE_REPLY
    return HANDLE_UNRESOLVED


@router.post("/plan", response_model=_PlanResponse)
async def plan_route(
    payload: _PlanRequest,
    store: AgentStore,
    _: CurrentUser,
) -> _PlanResponse:
    """Ask the configured LLM which workflow fits a user message.

    The route is **stateless** — it does not dispatch a run, write to
    memory, or store the decision. It exists purely to drive the
    Guide chat UI's auto-route mode; the caller decides whether to
    follow the dispatch suggestion or to ignore it.
    """
    if not payload.user_message.strip():
        raise_logged_bad_request(
            logger,
            ValueError("empty user_message"),
            public_detail="`user_message` must not be empty",
            log_event="guide_plan_empty_message",
        )

    catalog = (
        list(payload.catalog)
        if payload.catalog is not None
        else _build_catalog_from_store(store)
    )
    allowed_ids = _allowed_ids_from_catalog(catalog)

    provider = _resolve_provider(payload)
    system_prompt = (payload.system_prompt or _DEFAULT_SYSTEM_PROMPT).strip()
    user_prompt = (
        f"Available workflows:\n{_format_catalog_markdown(catalog)}\n\n"
        f"User message:\n{payload.user_message.strip()}"
    )
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]

    try:
        response = await provider.chat(messages, tools=None)
    except Exception as exc:
        raise_logged_service_unavailable(
            logger,
            exc,
            public_detail="Planner LLM call failed; please retry.",
            log_event="guide_planner_chat_failed",
        )

    raw_content = getattr(response, "content", "") or ""
    decision = parse_planner_response(raw_content, allowed_ids=allowed_ids)
    handle = _decision_handle(decision.workflow_id, decision.reply)
    return _PlanResponse(
        decision=handle,
        workflow_id=decision.workflow_id,
        args=decision.args,
        reply=decision.reply,
        reason=decision.reason,
        allowed_workflow_ids=sorted(allowed_ids),
        raw=decision.raw,
    )


__all__ = ["router"]
