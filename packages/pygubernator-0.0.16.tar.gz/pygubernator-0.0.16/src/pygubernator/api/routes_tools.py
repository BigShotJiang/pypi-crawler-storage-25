"""First-class tools API routes."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Query

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_not_found,
)
from pygubernator.api._routes_common import emit_audit, paginated_response
from pygubernator.api.deps import AdminUser, AgentStore, CurrentUser
from pygubernator.api.models import (
    ToolCreateRequest,
    ToolOut,
    ToolTestRequest,
    ToolTestResponse,
    ToolUpdateRequest,
    ToolVersionCreateRequest,
    ToolVersionOut,
)
from pygubernator.api.services._tool_tests import execute_tool_test

router = APIRouter(prefix="/api/v1/tools", tags=["tools"])
logger = logging.getLogger(__name__)


def _extract_tool_workflow_spec(spec_json: dict[str, Any]) -> dict[str, Any]:
    """Return the executable workflow spec from a tool version payload."""
    raw = spec_json.get("workflow_spec")
    if isinstance(raw, dict):
        return raw
    if isinstance(spec_json.get("nodes"), dict) and isinstance(
        spec_json.get("edges"), list
    ):
        return spec_json
    raise ValueError(
        "Tool version spec_json must include workflow_spec with nodes/edges"
    )


@router.get("")
def list_tools(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    status: str | None = None,
    q: str | None = None,
) -> dict[str, Any]:
    items, total = store.list_tools(page=page, page_size=page_size, status=status)
    if q:
        query = q.lower()
        items = [
            i for i in items if query in i.name.lower() or query in i.owner.lower()
        ]
    return paginated_response(
        items, total, page=page, page_size=page_size, model=ToolOut
    )


@router.post("", response_model=ToolOut)
def create_tool(
    payload: ToolCreateRequest, store: AgentStore, actor: AdminUser
) -> ToolOut:
    rec = store.create_tool(
        name=payload.name,
        description=payload.description,
        owner=payload.owner,
    )
    emit_audit(
        store,
        actor,
        "tool.create",
        resource_type="tool",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return ToolOut.model_validate(rec)


@router.get("/{tool_id}", response_model=ToolOut)
def get_tool(tool_id: str, store: AgentStore, _: CurrentUser) -> ToolOut:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    return ToolOut.model_validate(rec)


@router.patch("/{tool_id}", response_model=ToolOut)
def update_tool(
    tool_id: str, payload: ToolUpdateRequest, store: AgentStore, actor: AdminUser
) -> ToolOut:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    patch = payload.model_dump(exclude_none=True)
    if patch:
        store.update_tool(rec, **patch)
        emit_audit(
            store,
            actor,
            "tool.update",
            resource_type="tool",
            resource_id=tool_id,
            details=patch,
        )
        store.commit()
        store.refresh(rec)
    return ToolOut.model_validate(rec)


@router.get("/{tool_id}/versions")
def get_tool_versions(
    tool_id: str, store: AgentStore, _: CurrentUser
) -> dict[str, Any]:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    versions = store.list_tool_versions(tool_id)
    return {"items": [ToolVersionOut.model_validate(v).model_dump() for v in versions]}


@router.post("/{tool_id}/versions", response_model=ToolVersionOut)
def create_tool_version(
    tool_id: str,
    payload: ToolVersionCreateRequest,
    store: AgentStore,
    actor: AdminUser,
) -> ToolVersionOut:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    version = store.create_tool_version(
        tool_id=tool_id,
        version=payload.version,
        spec_json=payload.spec_json,
        created_by=actor["username"],
    )
    emit_audit(
        store,
        actor,
        "tool.version.save",
        resource_type="tool_version",
        resource_id=version.id,
        details={"tool_id": tool_id, "version": payload.version},
    )
    store.commit()
    store.refresh(version)
    return ToolVersionOut.model_validate(version)


@router.post("/{tool_id}/versions/{version_id}/publish", response_model=ToolVersionOut)
def publish_tool_version(
    tool_id: str,
    version_id: str,
    store: AgentStore,
    actor: AdminUser,
) -> ToolVersionOut:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    version = store.get_tool_version(version_id)
    if not version or version.tool_id != tool_id:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id} version_id={version_id}"),
            public_detail="Tool version not found",
            log_event="tool_version_not_found",
        )
    store.activate_tool_version(rec, version_id)
    emit_audit(
        store,
        actor,
        "tool.version.publish",
        resource_type="tool_version",
        resource_id=version_id,
        details={"tool_id": tool_id, "version": version.version},
    )
    store.commit()
    store.refresh(version)
    return ToolVersionOut.model_validate(version)


@router.post("/{tool_id}/versions/{version_id}/test", response_model=ToolTestResponse)
def test_tool_version(
    tool_id: str,
    version_id: str,
    payload: ToolTestRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> ToolTestResponse:
    rec = store.get_tool(tool_id)
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id}"),
            public_detail="Tool not found",
            log_event="tool_not_found",
        )
    version = store.get_tool_version(version_id)
    if not version or version.tool_id != tool_id:
        raise_logged_not_found(
            logger,
            LookupError(f"tool_id={tool_id} version_id={version_id}"),
            public_detail="Tool version not found",
            log_event="tool_version_not_found",
        )
    try:
        workflow_spec = _extract_tool_workflow_spec(version.spec_json or {})
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Tool version spec is missing a workflow_spec payload",
            log_event="tool_test_missing_workflow_spec",
        )
    result = execute_tool_test(
        workflow_spec_json=workflow_spec,
        input_json=payload.input_json,
        timeout_s=payload.timeout_s,
        max_steps=payload.max_steps,
        max_output_chars=payload.max_output_chars,
    )
    logger.info(
        "tool.version.test actor=%s tool_id=%s version=%s success=%s duration_ms=%s",
        actor.get("username", "unknown"),
        tool_id,
        version.version,
        bool(result.get("success")),
        int(result.get("duration_ms", 0)),
    )
    emit_audit(
        store,
        actor,
        "tool.version.test",
        resource_type="tool_version",
        resource_id=version_id,
        details={
            "tool_id": tool_id,
            "version": version.version,
            "success": bool(result.get("success")),
            "duration_ms": int(result.get("duration_ms", 0)),
        },
    )
    store.commit()
    return ToolTestResponse.model_validate(result)
