"""Settings and connection-test routes (mirrors pycharter / pystator patterns)."""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, status
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from pygubernator import __version__ as pygubernator_version
from pygubernator.api._http_errors import raise_logged_bad_request
from pygubernator.api.deps import AdminUser, CurrentUser
from pygubernator.api.models import (
    ControlPlaneInfoResponse,
    DatabaseConfigResponse,
    DatabaseTestRequest,
    DatabaseTestResponse,
    ServerConfigPatchRequest,
)
from pygubernator.api.services.server_config_editor import (
    apply_server_config_patch,
    get_server_config_bundle,
)
from pygubernator.config import ControlPlaneSettings, get_api_url
from pygubernator.config.auth import get_auth_service_url, is_auth_disabled
from pygubernator.config.database import get_database_url
from pygubernator.config.ui import get_ui_app_name, get_ui_theme
from pygubernator.db.models import Workflow
from pygubernator.db.session import get_db

public_router = APIRouter(prefix="/api/v1/settings", tags=["settings"])
router = APIRouter(prefix="/api/v1/settings", tags=["settings"])

logger = logging.getLogger(__name__)


def _build_connection_string(
    connection_string: str | None = None,
    host: str | None = None,
    port: int | None = None,
    database: str | None = None,
    username: str | None = None,
    password: str | None = None,
) -> str:
    """Build database connection string from components."""
    if connection_string:
        return connection_string
    if not all([host, database]):
        raise ValueError(
            "Either connection_string or (host and database) must be provided"
        )
    if port is None:
        port = 5432
    if username and password:
        return f"postgresql://{username}:{password}@{host}:{port}/{database}"
    if username:
        return f"postgresql://{username}@{host}:{port}/{database}"
    return f"postgresql://{host}:{port}/{database}"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


def _database_driver_kind(url: str | None) -> str:
    if not url or not str(url).strip():
        return "sqlite_default"
    u = str(url).strip().lower()
    if u.startswith("sqlite"):
        return "sqlite"
    if u.startswith(("postgresql", "postgres")):
        return "postgresql"
    if u.startswith("mysql"):
        return "mysql"
    return "other"


@public_router.get(
    "/runtime-overview",
    status_code=status.HTTP_200_OK,
    summary="Server runtime (masked, public)",
)
def get_runtime_overview() -> dict[str, Any]:
    """Effective config snapshot for the settings UI overview (no auth)."""
    raw_db = get_database_url()
    cp = ControlPlaneSettings.from_env()
    return {
        "version": pygubernator_version or "",
        "app_name": get_ui_app_name(),
        "ui_theme": get_ui_theme(),
        "api_url": get_api_url(),
        "auth_disabled": is_auth_disabled(),
        "auth_mode": _auth_mode_summary(),
        "control_plane": {
            "api_host": cp.api_host,
            "api_port": cp.api_port,
            "ui_host": cp.ui_host,
            "ui_port": cp.ui_port,
            "allow_origins": cp.allow_origins,
            "event_retention_days": cp.event_retention_days,
        },
        "database": {
            "configured_url_masked": _mask_database_url(raw_db) or "(default sqlite)",
            "driver_kind": _database_driver_kind(raw_db),
        },
    }


@router.get(
    "/control-plane",
    response_model=ControlPlaneInfoResponse,
    summary="Listen address and public API URL from server config",
)
def get_control_plane_info(_: CurrentUser) -> ControlPlaneInfoResponse:
    """Expose bind host/port and public API URL (``pygubernator api`` config)."""
    s = ControlPlaneSettings.from_env()
    return ControlPlaneInfoResponse(
        api_host=s.api_host,
        api_port=s.api_port,
        api_url=s.api_url,
        ui_host=s.ui_host,
        ui_port=s.ui_port,
    )


@router.get(
    "/database-config",
    response_model=DatabaseConfigResponse,
    summary="Current database configuration",
)
def get_database_config_route(
    _: CurrentUser,
    db: Annotated[Session, Depends(get_db)],
) -> DatabaseConfigResponse:
    """Return which database the API is using (SQLite vs PostgreSQL, masked URL)."""
    configured_url = get_database_url()
    actual_url = (
        str(db.get_bind().url)
        if hasattr(db, "get_bind") and db.get_bind()
        else "unknown"
    )
    if actual_url.startswith("sqlite"):
        database_type = "SQLite"
        is_default = configured_url is None
    elif actual_url.startswith(("postgresql", "postgres")):
        database_type = "PostgreSQL"
        is_default = False
    else:
        database_type = "Unknown"
        is_default = False
    try:
        workflow_count = db.query(Workflow).count()
    except Exception:
        workflow_count = -1
    if is_default:
        message = (
            "No database URL configured. Using default SQLite. "
            "To use PostgreSQL, set PYGUBERNATOR_DATABASE_URL."
        )
        display_url = None
    else:
        display_url = configured_url
        if configured_url and "@" in configured_url:
            display_url = _mask_database_url(configured_url)
        message = f"Using {database_type} database"
    actual_display = actual_url.split("@")[-1] if "@" in actual_url else actual_url
    return DatabaseConfigResponse(
        configured_url=display_url,
        actual_url=actual_display,
        database_type=database_type,
        is_default=is_default,
        workflow_count=workflow_count,
        message=message,
    )


@router.post(
    "/test-database",
    response_model=DatabaseTestResponse,
    summary="Test an arbitrary database connection",
)
def test_database_route(
    request: DatabaseTestRequest,
    _: CurrentUser,
) -> DatabaseTestResponse:
    """Test a database connection (for Postgres or other URL built from fields)."""
    try:
        connection_string = _build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return DatabaseTestResponse(
            success=True, message="Database connection successful"
        )
    except ValueError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Invalid database connection parameters",
            log_event="database test build connection string failed",
        )
    except SQLAlchemyError:
        logger.exception("database connection test failed")
        return DatabaseTestResponse(
            success=False,
            message="Database connection failed",
        )
    except Exception:
        logger.exception("database connection test unexpected error")
        return DatabaseTestResponse(success=False, message="Database connection failed")


@router.get(
    "/server-config",
    status_code=status.HTTP_200_OK,
    summary="Server config table (admin)",
)
def get_server_config(_: AdminUser) -> dict[str, Any]:
    return get_server_config_bundle()


@router.patch(
    "/server-config",
    status_code=status.HTTP_200_OK,
    summary="Update pygubernator.cfg (admin)",
)
def patch_server_config(
    body: ServerConfigPatchRequest,
    _: AdminUser,
) -> dict[str, Any]:
    try:
        path, keys = apply_server_config_patch(body.values)
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Invalid server configuration patch",
            log_event="server config patch failed",
        )
    return {
        "written_path": str(path),
        "keys_written": keys,
        "detail": f"Updated {len(keys)} key(s) in {path}",
    }
