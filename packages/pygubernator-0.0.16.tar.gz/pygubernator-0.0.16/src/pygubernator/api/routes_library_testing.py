"""Library testing (LibraryTestJob) routes."""

from __future__ import annotations

import logging
from datetime import datetime

from fastapi import APIRouter, Query

from pygubernator.api._http_errors import raise_logged_not_found
from pygubernator.api._routes_common import emit_audit, paginated_response
from pygubernator.api.deps import AgentStore, CurrentUser
from pygubernator.api.models import (
    LibraryTestJobCreateRequest,
    LibraryTestJobEventOut,
    LibraryTestJobEventSubmitRequest,
    LibraryTestJobOut,
    PageMeta,
)
from pygubernator.api.services.library_testing import (
    create_job,
    get_job_transitions,
    submit_event,
)
from pygubernator.api.services.library_testing.bootstrap import (
    ensure_library_test_workflow,
)
from pygubernator.api.services.library_testing.service import sync_job_from_workflow_run
from pygubernator.db import repositories as repos

router = APIRouter(prefix="/api/v1/library-testing", tags=["library-testing"])
logger = logging.getLogger(__name__)


@router.post("/jobs", response_model=LibraryTestJobOut)
def create_job_route(
    payload: LibraryTestJobCreateRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> LibraryTestJobOut:
    rec = create_job(
        store.session,
        workspace_id=store.workspace_id,
        name=payload.name,
        spec_json=payload.spec_json,
        created_by=str(actor.get("username", "system")),
    )
    emit_audit(
        store,
        actor,
        "library_test_job.create",
        resource_type="library_test_job",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return LibraryTestJobOut.model_validate(rec)


@router.get("/jobs")
def list_jobs_route(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    state: str | None = None,
    created_from: datetime | None = None,
    created_to: datetime | None = None,
) -> dict:
    items, total = repos.list_library_test_jobs(
        store.session,
        workspace_id=store.workspace_id,
        page=page,
        page_size=page_size,
        state=state,
        created_from=created_from,
        created_to=created_to,
    )
    return {
        "items": [LibraryTestJobOut.model_validate(i).model_dump() for i in items],
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
        "facets": {"states": sorted({i.current_state for i in items})},
    }


@router.get("/jobs/{job_id}", response_model=LibraryTestJobOut)
def get_job_route(job_id: str, store: AgentStore, _: CurrentUser) -> LibraryTestJobOut:
    rec = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"library_test_job_id={job_id}"),
            public_detail="Job not found",
            log_event="library_test_job_not_found",
        )
    return LibraryTestJobOut.model_validate(rec)


@router.get("/jobs/{job_id}/transitions")
def get_job_transitions_route(job_id: str, store: AgentStore, _: CurrentUser) -> dict:
    rec = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not rec:
        raise_logged_not_found(
            logger,
            LookupError(f"library_test_job_id={job_id}"),
            public_detail="Job not found",
            log_event="library_test_job_not_found",
        )
    return get_job_transitions(rec)


@router.post("/jobs/{job_id}/events")
def submit_event_route(
    job_id: str,
    payload: LibraryTestJobEventSubmitRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> dict:
    try:
        job, ev = submit_event(
            store.session,
            workspace_id=store.workspace_id,
            job_id=job_id,
            trigger=payload.trigger,
            actor=str(actor.get("username", "system")),
            idempotency_key=payload.idempotency_key,
            payload_json=payload.payload_json,
            workflow_run_id=payload.workflow_run_id,
        )
    except ValueError:
        raise_logged_not_found(
            logger,
            LookupError(f"library_test_job_id={job_id}"),
            public_detail="Job not found",
            log_event="library_test_job_not_found",
        )

    emit_audit(
        store,
        actor,
        "library_test_job.event",
        resource_type="library_test_job",
        resource_id=job_id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(job)
    store.refresh(ev)
    return {
        "job": LibraryTestJobOut.model_validate(job).model_dump(),
        "event": LibraryTestJobEventOut.model_validate(ev).model_dump(),
    }


@router.get("/jobs/{job_id}/events")
def list_events_route(
    job_id: str,
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(200, ge=1, le=500),
) -> dict:
    job = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not job:
        raise_logged_not_found(
            logger,
            LookupError(f"library_test_job_id={job_id}"),
            public_detail="Job not found",
            log_event="library_test_job_not_found",
        )
    items, total = repos.list_library_test_job_events(
        store.session,
        job_id,
        workspace_id=store.workspace_id,
        page=page,
        page_size=page_size,
    )
    return paginated_response(
        items, total, page=page, page_size=page_size, model=LibraryTestJobEventOut
    )


@router.post("/jobs/{job_id}/run")
def run_job_route(job_id: str, store: AgentStore, actor: CurrentUser) -> dict:
    """Execute the LibraryTestWorkflow for a job (Phase 1: local runner)."""
    job = repos.get_library_test_job(
        store.session, job_id, workspace_id=store.workspace_id
    )
    if not job:
        raise_logged_not_found(
            logger,
            LookupError(f"library_test_job_id={job_id}"),
            public_detail="Job not found",
            log_event="library_test_job_not_found",
        )

    wf, version = ensure_library_test_workflow(
        store,
        workspace_id=store.workspace_id,
        actor=str(actor.get("username", "system")),
    )

    # Create a workflow run pointing at the template workflow/version.
    run = store.create_workflow_run(
        workflow_id=wf.id,
        workflow_version_id=version.id,
        status="pending",
        input_json={
            "job_id": job.id,
            **(job.spec_json or {}),
        },
        created_by=str(actor.get("username", "system")),
        session_id=None,
    )
    emit_audit(
        store,
        actor,
        "library_test_job.run",
        resource_type="library_test_job",
        resource_id=job.id,
        details={"workflow_id": wf.id, "workflow_version_id": version.id},
    )
    store.commit()
    store.refresh(run)

    # Best-effort pointer for UI convenience.
    job.last_workflow_run_id = run.id
    store.commit()

    # Auto-progress the job lifecycle for ops usability.
    sync_job_from_workflow_run(
        store.session,
        workspace_id=store.workspace_id,
        job_id=job.id,
        workflow_run_id=run.id,
        workflow_status="pending",
        actor=str(actor.get("username", "system")),
    )
    store.commit()

    # Execute in background thread using the same approach as workflows route.
    import threading

    from pygubernator.api.routes_workflows import _run_workflow_background

    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, run.input_json, run.id, None),
        daemon=True,
        name=f"libtest-{run.id[:8]}",
    )
    thread.start()

    return {"ok": True, "workflow_run_id": run.id}
