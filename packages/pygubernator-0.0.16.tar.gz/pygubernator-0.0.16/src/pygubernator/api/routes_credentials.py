"""Credential management API routes (admin-only)."""

from __future__ import annotations

import logging
from datetime import datetime

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_conflict,
    raise_logged_internal,
    raise_logged_not_found,
)
from pygubernator.api.deps import AdminUser, DbSession
from pygubernator.config.auth import get_auth_jwt_secret
from pygubernator.config.integrations import (
    KNOWN_PROVIDERS,
    decrypt_value,
    encrypt_value,
    mask_value,
)
from pygubernator.db.models import IntegrationCredential

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin/credentials",
    tags=["credentials"],
)


# --------------- Request / Response models ---------------


class CredentialCreate(BaseModel):
    """Request body for creating a new credential."""

    provider: str = Field(..., description="Provider key")
    name: str = Field(..., description="Human-readable name")
    env_var: str = Field(..., description="Target env variable")
    value: str = Field(..., description="Plaintext secret value")
    enabled: bool = Field(default=True)


class CredentialUpdate(BaseModel):
    """Request body for updating an existing credential."""

    name: str | None = Field(default=None)
    value: str | None = Field(default=None)
    enabled: bool | None = Field(default=None)


class CredentialResponse(BaseModel):
    """Response model for a credential (value masked)."""

    id: str
    provider: str
    name: str
    env_var: str
    value_preview: str
    enabled: bool
    created_at: datetime
    updated_at: datetime


# --------------- Helpers ---------------


def _secret() -> str:
    """Return the JWT secret or raise 500 if not configured."""
    secret = get_auth_jwt_secret()
    if not secret:
        raise_logged_internal(
            logger,
            RuntimeError("JWT secret not configured"),
            public_detail="JWT secret not configured",
            log_event="credentials_jwt_secret_missing",
        )
    return secret


def _to_response(
    row: IntegrationCredential,
    secret: str,
) -> CredentialResponse:
    """Convert a DB row to a masked response model."""
    try:
        plaintext = decrypt_value(row.encrypted_value, secret)
        preview = mask_value(plaintext)
    except Exception:
        preview = "****"
    return CredentialResponse(
        id=row.id,
        provider=row.provider,
        name=row.name,
        env_var=row.env_var,
        value_preview=preview,
        enabled=row.enabled,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


# --------------- Endpoints ---------------


@router.get("")
def list_credentials(
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """List all stored credentials with masked values."""
    secret = _secret()
    rows = db.query(IntegrationCredential).all()
    items = [_to_response(r, secret) for r in rows]
    return {
        "items": [i.model_dump(mode="json") for i in items],
    }


@router.post("", response_model=CredentialResponse)
def create_credential(
    payload: CredentialCreate,
    _admin: AdminUser,
    db: DbSession,
) -> CredentialResponse:
    """Create a new integration credential."""
    existing = (
        db.query(IntegrationCredential)
        .filter(IntegrationCredential.name == payload.name)
        .first()
    )
    if existing:
        raise_logged_conflict(
            logger,
            ValueError(f"duplicate credential name: {payload.name}"),
            public_detail=f"A credential named '{payload.name}' already exists.",
            log_event="credentials_duplicate_name",
        )
    secret = _secret()
    encrypted = encrypt_value(payload.value, secret)
    row = IntegrationCredential(
        provider=payload.provider,
        name=payload.name,
        env_var=payload.env_var,
        encrypted_value=encrypted,
        enabled=payload.enabled,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info("Created credential %s for provider %s", row.name, row.provider)
    return _to_response(row, secret)


@router.patch(
    "/{credential_id}",
    response_model=CredentialResponse,
)
def update_credential(
    credential_id: str,
    payload: CredentialUpdate,
    _admin: AdminUser,
    db: DbSession,
) -> CredentialResponse:
    """Update an existing credential's fields."""
    secret = _secret()
    row = db.get(IntegrationCredential, credential_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"credential_id={credential_id}"),
            public_detail="Credential not found",
            log_event="credential_not_found",
        )
    if payload.name is not None:
        row.name = payload.name
    if payload.value is not None:
        row.encrypted_value = encrypt_value(payload.value, secret)
    if payload.enabled is not None:
        row.enabled = payload.enabled
    db.commit()
    db.refresh(row)
    logger.info("Updated credential %s", row.name)
    return _to_response(row, secret)


@router.delete("/{credential_id}")
def delete_credential(
    credential_id: str,
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """Delete an integration credential."""
    row = db.get(IntegrationCredential, credential_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"credential_id={credential_id}"),
            public_detail="Credential not found",
            log_event="credential_not_found",
        )
    name = row.name
    db.delete(row)
    db.commit()
    logger.info("Deleted credential %s", name)
    return {"ok": True, "deleted": credential_id}


@router.get("/providers")
def list_providers(
    _admin: AdminUser,
) -> dict:
    """Return known provider definitions for UI dropdowns."""
    return {"providers": KNOWN_PROVIDERS}


class ValidateCredentialRequest(BaseModel):
    """Request body for credential validation."""

    provider: str = Field(..., description="Provider key")
    value: str = Field(..., description="Credential value to validate")


@router.post("/validate")
def validate_credential_route(
    body: ValidateCredentialRequest,
    _admin: AdminUser,
) -> dict:
    """Test if a credential value is valid for a given provider.

    Performs basic format validation (file exists, URL scheme, token
    length) without making network calls.
    """
    from pygubernator.config._credentials import validate_credential

    valid = validate_credential(body.provider, body.value)
    info = KNOWN_PROVIDERS.get(body.provider, {})
    cred_type = info.get("type", "text")

    if valid:
        message = "Credential format looks valid"
    elif cred_type == "file_path":
        message = "File not found at the specified path"
    elif cred_type == "connection_string":
        message = "Expected a connection string with :// scheme"
    elif cred_type == "url":
        message = "Expected an http:// or https:// URL"
    elif cred_type == "token":
        message = "Token is too short (minimum 8 characters)"
    else:
        message = "Value appears to be empty or invalid"

    return {"valid": valid, "message": message}
