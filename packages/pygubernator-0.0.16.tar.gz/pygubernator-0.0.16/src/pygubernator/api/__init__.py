"""Optional FastAPI control-plane layer."""

from __future__ import annotations

from pygubernator.api.main import app, create_app

__all__ = ["app", "create_app"]
