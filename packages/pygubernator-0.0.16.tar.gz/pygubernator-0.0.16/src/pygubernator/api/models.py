"""Pydantic API models for control plane."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class PageMeta(BaseModel):
    total: int
    page: int
    page_size: int


class AgentCreateRequest(BaseModel):
    name: str
    owner: str = "system"
    status: str = "active"


class AgentUpdateRequest(BaseModel):
    """Patch fields on an existing :class:`Agent`.

    All fields are optional; only those supplied are updated. ``name`` and
    ``owner`` make simple mistakes (typos at create time, changing
    ownership) recoverable without CLI or DB access.
    """

    name: str | None = None
    owner: str | None = None
    status: str | None = None
    archived: bool | None = None


class LLMProviderConfigRequest(BaseModel):
    """Structured LLM provider configuration."""

    provider_type: str = Field(
        ..., description="Provider backend: litellm, openai_compatible, local"
    )
    model: str = Field(..., description="Model identifier")
    api_base: str | None = Field(None, description="Server URL")
    api_key: str | None = Field(None, description="API key")
    max_tokens: int = Field(4096, ge=1)
    temperature: float = Field(0.0, ge=0.0, le=2.0)
    top_p: float | None = Field(None, ge=0.0, le=1.0)
    top_k: int | None = Field(None, ge=1)
    request_timeout: float | None = Field(
        None,
        ge=1.0,
        description="HTTP read timeout (s) for openai_compatible providers",
    )


class LLMProviderPresetOut(BaseModel):
    """Known provider preset for the UI."""

    name: str
    provider_type: str
    default_api_base: str | None
    requires_api_key: bool
    models: list[str]
    description: str


class LLMHealthCheckRequest(BaseModel):
    """Request to health-check an LLM provider endpoint."""

    api_base: str = Field(..., description="Server URL to check")
    api_key: str | None = Field(None, description="Optional API key")


class LLMHealthCheckResponse(BaseModel):
    """Response from provider health check."""

    reachable: bool
    models: list[str] = Field(default_factory=list)
    error: str | None = None


class LocalOllamaBaseBody(BaseModel):
    """Optional Ollama daemon root URL (native API, not ``.../v1``)."""

    base_url: str | None = Field(
        None,
        description="Ollama server root, e.g. http://127.0.0.1:11434",
    )


class LocalOllamaModelRow(BaseModel):
    """One installed model from ``GET /api/tags``."""

    name: str
    size: int | None = None
    digest: str | None = None
    modified_at: str | None = None


class LocalOllamaStatusResponse(BaseModel):
    """Reachability and model list for the Settings local-Ollama card."""

    reachable: bool
    base_url: str
    models: list[LocalOllamaModelRow] = Field(default_factory=list)
    error: str | None = None


class LocalOllamaPullRequest(LocalOllamaBaseBody):
    """Pull a model into the local Ollama library."""

    name: str = Field(
        ..., min_length=1, description="Model name, e.g. llama3.2 or mistral:7b"
    )


class LocalOllamaPullResponse(BaseModel):
    ok: bool
    detail: str | None = None


class LocalOllamaDeleteRequest(LocalOllamaBaseBody):
    """Remove a model from the local Ollama library."""

    name: str = Field(
        ..., min_length=1, description="Model name as shown in ollama list"
    )


class LocalOllamaDeleteResponse(BaseModel):
    ok: bool
    detail: str | None = None


class AgentVersionCreateRequest(BaseModel):
    version: str
    model: str | None = None
    prompt: str | None = None
    tools: dict[str, Any] = Field(default_factory=dict)
    config: dict[str, Any] = Field(default_factory=dict)
    provider: LLMProviderConfigRequest | None = None
    spec_path: str | None = None
    spec_json: dict[str, Any] | None = None


class AgentSpecSummaryOut(BaseModel):
    """Compact file-based AgentSpec listing row."""

    path: str
    name: str
    owner: str = "system"
    spec_version: str = "v1"
    fingerprint: str


class AgentSpecDetailOut(BaseModel):
    """Detailed AgentSpec payload with normalized shape."""

    path: str
    spec_json: dict[str, Any] = Field(default_factory=dict)
    fingerprint: str


class AgentSpecValidateRequest(BaseModel):
    """Validate a raw AgentSpec payload without publishing."""

    spec_json: dict[str, Any]
    source_path: str | None = None


class AgentSpecValidationOut(BaseModel):
    """Validation/compile summary for a spec payload."""

    valid: bool
    fingerprint: str | None = None
    errors: list[str] = Field(default_factory=list)
    normalized: dict[str, Any] = Field(default_factory=dict)


class AgentSpecPublishRequest(BaseModel):
    """Publish a file-based AgentSpec into an AgentVersion snapshot."""

    version: str
    spec_path: str
    activate: bool = False


class AgentCreateFromSpecRequest(BaseModel):
    """Create a new Agent *and* its first AgentVersion from one spec file.

    Server-side atomic so a failing version publish (invalid tool ref,
    unreadable file, duplicate name) never leaves an orphaned empty agent
    behind. When ``name`` / ``owner`` are omitted we fall back to the
    spec's ``meta`` block, which the catalog dialog already exposes.
    """

    spec_path: str
    version: str
    name: str | None = None
    owner: str | None = None
    status: str = "active"
    activate: bool = True


class RunCreateRequest(BaseModel):
    agent_id: str
    agent_version_id: str | None = None
    correlation_id: str | None = None
    trigger: str | None = None
    metadata_json: dict[str, Any] = Field(default_factory=dict)


class RunEnqueueRequest(BaseModel):
    """Enqueue a run for an agent (``agent_id`` comes from the URL path)."""

    agent_version_id: str | None = None
    correlation_id: str | None = None
    trigger: str | None = None
    metadata_json: dict[str, Any] = Field(default_factory=dict)


class RunControlRequest(BaseModel):
    action: str
    reason: str | None = None


class IncidentCreateRequest(BaseModel):
    title: str
    severity: str = "warning"
    run_id: str | None = None
    alert_id: str | None = None
    owner: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class IncidentAssignRequest(BaseModel):
    owner: str


class IncidentSilenceRequest(BaseModel):
    until: datetime


class PolicyAssignmentRequest(BaseModel):
    agent_id: str
    policy_type: str
    policy_value: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class AlertRuleRequest(BaseModel):
    name: str
    severity: str = "warning"
    condition: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class AlertRuleToggleRequest(BaseModel):
    enabled: bool


class RunEventIngestRequest(BaseModel):
    run_id: str
    event_type: str
    level: str = "info"
    message: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class AgentOut(BaseModel):
    id: str
    name: str
    owner: str
    status: str
    archived: bool
    current_version_id: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AgentVersionOut(BaseModel):
    id: str
    agent_id: str
    version: str
    model: str | None
    prompt: str | None
    tools: dict[str, Any]
    config: dict[str, Any]
    spec_path: str | None = None
    spec_fingerprint: str | None = None
    spec_json: dict[str, Any] = Field(default_factory=dict)
    active: bool
    created_at: datetime
    deleted_at: datetime | None = None

    model_config = {"from_attributes": True}


class AgentDashboardOut(BaseModel):
    """Agent plus versions in one response (UI / client convenience)."""

    agent: AgentOut
    versions: list[AgentVersionOut]


class AgentHeartbeatOut(BaseModel):
    """Latest heartbeat for a single agent, enriched with liveness.

    ``agent_name`` is populated via a join on the ``agents`` table when
    ``agent_id`` matches a registered agent. Ad-hoc / test agents that
    never got a registry row come through with ``agent_name=None`` —
    UI clients should fall back to the id as a display label.

    ``current_node_id`` and ``context_used_tokens`` are convention
    fields the server pulls out of ``details`` so the fleet-view panel
    doesn't need to parse the dict. Emitters populate them via
    :func:`HeartbeatEmitter.status_provider`; unset = ``None``.
    """

    agent_id: str
    agent_name: str | None = None
    run_id: str | None = None
    workflow_id: str | None = None
    current_node_id: str | None = None
    context_used_tokens: int | None = None
    status: str
    details: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    seconds_since_beat: float
    is_stale: bool


class AgentHeartbeatsOut(BaseModel):
    """Fleet-health response: latest heartbeat per agent.

    ``threshold_s`` echoes whichever staleness threshold was used by the
    server so the UI can label "stale for >N s" without re-deriving it.
    """

    items: list[AgentHeartbeatOut]
    threshold_s: float


class ToolCreateRequest(BaseModel):
    """Request to create a new tool."""

    name: str
    description: str = ""
    owner: str = "system"


class ToolUpdateRequest(BaseModel):
    """Request to update a tool."""

    name: str | None = None
    description: str | None = None
    status: str | None = None
    archived: bool | None = None


class ToolVersionCreateRequest(BaseModel):
    """Request to create or update a tool version draft."""

    version: str
    spec_json: dict[str, Any] = Field(default_factory=dict)


class ToolTestRequest(BaseModel):
    """Request to execute a tool version in tool_test mode."""

    input_json: dict[str, Any] = Field(default_factory=dict)
    timeout_s: float = Field(default=120.0, ge=1.0, le=900.0)
    max_steps: int = Field(default=100, ge=1, le=2000)
    max_output_chars: int = Field(default=40000, ge=1000, le=200000)


class ToolOut(BaseModel):
    """Tool response model."""

    id: str
    name: str
    description: str
    owner: str
    status: str
    archived: bool
    workspace_id: str
    current_version_id: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ToolVersionOut(BaseModel):
    """Tool version response model."""

    id: str
    tool_id: str
    version: str
    revision: int = 1
    spec_json: dict[str, Any] = Field(default_factory=dict)
    active: bool
    published: bool
    created_at: datetime
    created_by: str

    model_config = {"from_attributes": True}


class ToolTestStepOut(BaseModel):
    """One executed step from a tool test run."""

    node_id: str
    node_type: str
    status: str
    output_json: dict[str, Any] = Field(default_factory=dict)
    output_handle: str = "default"
    error_message: str | None = None


class ToolTestResponse(BaseModel):
    """Result payload for tool test execution."""

    success: bool
    output: dict[str, Any] = Field(default_factory=dict)
    errors: list[str] = Field(default_factory=list)
    duration_ms: int = 0
    execution_profile: str = "tool_test"
    steps: list[ToolTestStepOut] = Field(default_factory=list)


class WorkflowCreateRequest(BaseModel):
    """Request to create a new workflow."""

    name: str
    description: str = ""
    owner: str = "system"


class TemplateSummaryOut(BaseModel):
    """Compact template shape used by list endpoints."""

    slug: str
    title: str
    summary: str
    tags: list[str] = Field(default_factory=list)
    icon: str | None = None
    setup_minutes: int | None = None
    required_credentials: list[str] = Field(default_factory=list)
    name: str
    version: str


class TemplateDetailOut(TemplateSummaryOut):
    """Template detail shape including the raw workflow spec."""

    spec: dict[str, Any] = Field(default_factory=dict)


class TemplateImportRequest(BaseModel):
    """Optional overrides when importing a template into a workspace."""

    name: str | None = Field(
        default=None,
        description=(
            "Override the workflow name. Defaults to the template's "
            "meta.name with a ' (copy)' suffix."
        ),
    )
    description: str | None = Field(
        default=None,
        description=(
            "Override the workflow description. Defaults to the template summary."
        ),
    )
    owner: str | None = Field(
        default=None,
        description="Override the workflow owner. Defaults to the calling user.",
    )


class TemplateImportOut(BaseModel):
    """Response from the template-import endpoint."""

    workflow_id: str
    version_id: str
    version: str
    slug: str


class WorkflowUpdateRequest(BaseModel):
    """Request to update a workflow."""

    name: str | None = None
    description: str | None = None
    status: str | None = None


class WorkflowVersionCreateRequest(BaseModel):
    """Request to create a workflow version."""

    version: str
    spec_json: dict[str, Any] = Field(default_factory=dict)
    expected_revision: int | None = Field(
        default=None,
        description=(
            "If set, the save is rejected with 409 when the"
            " current revision does not match."
        ),
    )


class WorkflowExecuteRequest(BaseModel):
    """Request to execute a workflow."""

    input_json: dict[str, Any] = Field(default_factory=dict)
    version_id: str | None = None
    session_id: str | None = None
    trigger: str | None = Field(
        default=None,
        description=(
            "How the run was started. Known values: `manual` (default "
            "when omitted), `schedule`, `webhook`, `guide`. Short free "
            "text so new kinds can be added without a migration."
        ),
    )
    correlation_id: str | None = Field(
        default=None,
        description=(
            "Opaque id tying the run back to the caller's session / "
            "message (e.g. chat session id for Guide-dispatched runs). "
            "Indexed for cheap lookups."
        ),
    )


class WorkflowNodePreviewRequest(BaseModel):
    """Request body for single-node preview execution."""

    node_type: str = Field(..., description="Registered node type, e.g. 'template'.")
    config: dict[str, Any] = Field(
        default_factory=dict,
        description="Node config as it would appear in a workflow spec.",
    )
    input_json: dict[str, Any] = Field(
        default_factory=dict,
        description="Mock input data the node would receive from upstream.",
    )
    variables: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional shared variables to merge into the node context.",
    )
    session_id: str | None = Field(
        default=None,
        description=(
            "Opaque session marker. When set, a scratch session is used and "
            "torn down afterwards so memory nodes do not pollute live sessions."
        ),
    )
    cheap_llm: bool = Field(
        default=True,
        description=(
            "When True (default), substitutes known expensive LLM models "
            "with cheaper equivalents for the preview call."
        ),
    )
    timeout_s: float = Field(
        default=30.0,
        ge=1.0,
        le=120.0,
        description="Hard wall-clock cap in seconds.",
    )


class WorkflowNodePreviewResponse(BaseModel):
    """Structured outcome of a single-node preview execution."""

    status: str = Field(
        ...,
        description="One of: success, failed, skipped, awaiting_approval, timeout.",
    )
    node_type: str
    output_json: dict[str, Any] = Field(default_factory=dict)
    output_handle: str = "default"
    error: str | None = None
    duration_ms: int
    safety: str = Field(
        ..., description="Preview safety classification for this node + config."
    )
    warnings: list[str] = Field(default_factory=list)


class WorkflowApprovalDecisionRequest(BaseModel):
    """Explicit reviewer decision for a paused workflow run."""

    decision: Literal["approved", "rejected", "changes_requested"] = Field(
        ...,
        description="One of approved, rejected, or changes_requested",
    )
    comment: str | None = Field(
        default=None,
        description="Reviewer comment or rationale",
    )
    payload: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional structured reviewer data",
    )


class WorkflowApprovalOut(BaseModel):
    """Reviewer-facing approval request metadata."""

    id: str
    node_id: str
    prompt: str
    status: str
    responded_by: str | None
    timeout_seconds: int
    created_at: str | None
    responded_at: str | None
    allowed_decisions: list[str] = Field(default_factory=list)
    require_comment: bool = False
    reviewer_label: str = ""
    details_markdown: str = ""


class WorkflowOut(BaseModel):
    """Workflow response model."""

    id: str
    name: str
    description: str
    owner: str
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowVersionOut(BaseModel):
    """Workflow version response model."""

    id: str
    workflow_id: str
    version: str
    revision: int = 1
    spec_json: dict[str, Any]
    active: bool
    created_at: datetime
    created_by: str

    model_config = {"from_attributes": True}


class PortSchemaFieldOut(BaseModel):
    """A single key in a port's data shape."""

    name: str
    field_type: str
    required: bool = True
    description: str = ""


class PortSchemaOut(BaseModel):
    """Describes the data shape flowing through a port."""

    fields: list[PortSchemaFieldOut] = Field(default_factory=list)
    mode: str = "static"
    config_keys: list[str] = Field(default_factory=list)


class WorkflowNodePortOut(BaseModel):
    """Port metadata for workflow node types."""

    name: str
    direction: str
    kind: str
    label: str | None = None
    multiple: bool = False
    schema_: PortSchemaOut | None = Field(default=None, alias="schema")


class WorkflowNodeFieldOut(BaseModel):
    """Configuration field metadata for workflow node types."""

    name: str
    field_type: str
    label: str
    required: bool = False
    default: Any = None
    help_text: str = ""
    options: list[str] = Field(default_factory=list)
    placeholder: str | None = None
    visible_if: dict[str, Any] = Field(default_factory=dict)


class WorkflowToolPresetOut(BaseModel):
    """Built-in tool factory preset for Agent tool subgraph nodes."""

    id: str
    label: str
    name: str
    factory_module: str
    factory_function: str
    env_hint: str


class WorkflowNodeTypeOut(BaseModel):
    """Metadata model for editor-driven workflow node types."""

    type_name: str
    display_name: str
    category: str
    description: str
    color: str | None = None
    icon: str | None = None
    inputs: list[WorkflowNodePortOut] = Field(default_factory=list)
    outputs: list[WorkflowNodePortOut] = Field(default_factory=list)
    fields: list[WorkflowNodeFieldOut] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    supports_streaming: bool = False
    supports_checkpointing: bool = False
    supports_subgraph: bool = False
    runtime_kind: str = "node"
    output_schema: PortSchemaOut | None = None
    required_credentials: list[str] = Field(
        default_factory=list,
        description=(
            "Provider names whose credentials should typically be configured "
            "before the node can run end-to-end (advisory)."
        ),
    )
    preview_safety: str = Field(
        default="effectful",
        description=(
            "Default preview safety class for this node type, ignoring live "
            "config. Frontend uses this to enable/disable the Preview action. "
            "The backend re-classifies with config at request time."
        ),
    )


class WorkflowRunOut(BaseModel):
    """Workflow run response model."""

    id: str
    workflow_id: str
    workflow_version_id: str | None
    status: str
    input_json: dict[str, Any]
    output_json: dict[str, Any]
    variables_json: dict[str, Any]
    error_message: str | None
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None
    created_by: str
    session_id: str | None = None
    trigger: str | None = None
    correlation_id: str | None = None

    model_config = {"from_attributes": True}


class WorkflowStepRunOut(BaseModel):
    """Workflow step run response model."""

    id: str
    workflow_run_id: str
    node_id: str
    node_type: str
    status: str
    input_json: dict[str, Any]
    output_json: dict[str, Any]
    error_message: str | None
    dlq_meta: dict[str, Any] | None = None
    replay_meta: dict[str, Any] | None = None
    output_handle: str
    started_at: datetime | None
    completed_at: datetime | None
    duration_ms: int | None

    @model_validator(mode="after")
    def _derive_dlq_replay_meta(self) -> WorkflowStepRunOut:
        if self.dlq_meta is None:
            raw = self.output_json.get("__dlq__")
            if isinstance(raw, dict):
                self.dlq_meta = raw
        if self.replay_meta is None:
            raw = self.output_json.get("__replay__")
            if isinstance(raw, dict):
                self.replay_meta = raw
        return self

    model_config = {"from_attributes": True}


class WorkflowStepEventOut(BaseModel):
    """One ``workflow_step_events`` row with its full payload.

    Returned by ``GET /workflows/runs/{run_id}/steps/{step_id}/events``
    — the UI's agent-trace disclosure blocks render the ``payload_json``
    dict verbatim so users can inspect the exact tool / LLM call inputs
    and outputs.
    """

    id: str | None = None
    step_run_id: str
    workflow_run_id: str
    event_type: str
    sequence_num: int
    event_timestamp: float
    payload_json: dict[str, Any]
    created_at: datetime | None = None

    model_config = {"from_attributes": True}


class WorkflowStepEventsOut(BaseModel):
    """Envelope for a step's event list plus a provenance flag.

    ``source="table"`` means the events came from the indexed
    ``workflow_step_events`` table (post-P2a); ``source="blob"`` means
    they were reconstituted from the legacy
    ``output_json["_child_events"]`` payload on older rows.
    """

    items: list[WorkflowStepEventOut]
    source: str


class WorkflowArtifactOut(BaseModel):
    """Metadata for one ``workflow_artifacts`` row.

    The actual content is served by the content route — the list API
    intentionally omits ``content_text`` to keep payloads small when a
    run has dozens of Markdown reports or CSV tables. ``has_content``
    lets the UI decide whether to render a "View" affordance before
    making the content fetch.
    """

    id: str
    workflow_run_id: str
    step_run_id: str | None = None
    artifact_type: str
    title: str | None = None
    mime: str | None = None
    source_path: str | None = None
    size_bytes: int | None = None
    sequence_num: int
    has_content: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowArtifactsOut(BaseModel):
    """Envelope for a run's (or step's) artifact list.

    ``run_id`` echoes the path parameter so clients caching by URL don't
    need to parse it back out; ``step_run_id`` is present when the list
    was filtered to a single step.
    """

    items: list[WorkflowArtifactOut]
    run_id: str
    step_run_id: str | None = None


class WorkflowArtifactContentOut(BaseModel):
    """Inline artifact content as returned by the content route.

    ``content`` is always a string — binary artifacts are base64-encoded
    and flagged via ``encoding="base64"`` so the UI renderer can choose
    to decode back into a blob URL for ``<img>`` / ``<iframe>`` sources.
    """

    id: str
    artifact_type: str
    mime: str | None = None
    content: str
    encoding: str = "utf-8"
    size_bytes: int | None = None


class ArtifactQueryRequest(BaseModel):
    """Body for the artifact SQL sandbox route.

    The sandbox is SELECT-only — see
    :mod:`pygubernator.api.services._artifact_query` for the safety
    model. Queries run against a virtual table named ``artifact``.
    """

    sql: str


class ArtifactQueryResponse(BaseModel):
    """Envelope returned by a successful artifact query.

    ``truncated=True`` signals that more rows were available but the
    row cap kicked in; clients should narrow the query (``LIMIT``,
    ``WHERE``) rather than expect the full result set.
    """

    columns: list[str]
    rows: list[list[Any]]
    row_count: int
    truncated: bool
    elapsed_ms: int


class WorkflowSessionSummaryOut(BaseModel):
    """One row in the cross-workflow "Sessions" sidebar on the Runs page.

    Aggregates ``workflow_runs`` on ``session_id`` and joins back to
    ``workflows`` so the UI can show a friendly workflow name next to
    each session without a second fetch. ``last_status`` reflects the
    most recent run in the session — useful for an at-a-glance summary
    ("did my overnight session finish clean?").

    ``name`` is the user-supplied label from the ``workflow_sessions``
    metadata table (Phase 6 §6.8b); ``None`` means the user hasn't
    renamed the session yet, so the UI falls back to the raw
    ``session_id``.
    """

    session_id: str
    workflow_id: str
    workflow_name: str
    run_count: int
    last_run_at: str | None = None
    last_status: str | None = None
    name: str | None = None


class WorkflowSessionsOut(BaseModel):
    """Paginated envelope for the cross-workflow sessions list route."""

    items: list[WorkflowSessionSummaryOut]
    meta: PageMeta


class WorkflowSessionDetailOut(BaseModel):
    """Detail response for the ``GET / PATCH .../sessions/{id}/meta`` routes.

    Wraps the user-supplied metadata for a single session — name and
    free-form notes — keyed by the same ``session_id`` workflow runs
    already carry. Fields are ``None`` when the user has not yet
    annotated the session.
    """

    session_id: str
    name: str | None = None
    notes: str | None = None


class WorkflowSessionUpdateRequest(BaseModel):
    """Body for the rename / annotate route on a workflow session.

    Both fields are optional — passing only ``name`` renames without
    touching notes, and vice versa. An empty string is treated as
    "clear this field".
    """

    name: str | None = None
    notes: str | None = None


class WorkflowSessionSummaryEntryOut(BaseModel):
    """One summary row returned by ``GET .../sessions/{id}/summaries``.

    Many summaries can exist per session — typically one per scheduled
    narrator tick — so the response is a list ordered by
    ``generated_at`` descending.
    """

    id: str
    session_id: str
    content: str
    generated_by: str | None = None
    model: str | None = None
    generated_at: datetime

    model_config = {"from_attributes": True}


class WorkflowSessionSummariesOut(BaseModel):
    """Envelope for the summaries list response."""

    items: list[WorkflowSessionSummaryEntryOut]


class WorkflowSessionSummaryCreateRequest(BaseModel):
    """Body for ``POST .../sessions/{id}/summaries`` — append a summary.

    Designed for both manual user submissions and a future narrator
    agent: ``generated_by`` records the actor identity, ``model``
    optionally records which LLM produced the text. The narrator
    agent itself is a v1.1 follow-up; v1 ships the storage so any
    workflow-driven approach (a manual ``agent`` node + scheduler) can
    write summaries without further plumbing.
    """

    content: str
    generated_by: str | None = None
    model: str | None = None


# ---------------------------------------------------------------------------
# Settings (pycharter / pystator parity)
# ---------------------------------------------------------------------------


class DatabaseTestRequest(BaseModel):
    """Body for testing a database connection from the UI."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None


class DatabaseConfigResponse(BaseModel):
    """Server-side database configuration (masked credentials)."""

    configured_url: str | None = Field(
        None, description="Configured DB URL from env/cfg (masked if credentials)"
    )
    actual_url: str = Field(
        ...,
        description="Effective URL tail or path (passwords stripped from host part)",
    )
    database_type: str = Field(..., description="SQLite, PostgreSQL, or Unknown")
    is_default: bool = Field(
        ...,
        description="True when no PYGUBERNATOR_DATABASE_URL in env/cfg file",
    )
    workflow_count: int = Field(
        ...,
        description="Workflow rows in DB, or -1 if unavailable",
    )
    message: str = Field(..., description="Human-readable status")


class DatabaseTestResponse(BaseModel):
    success: bool
    message: str


class ControlPlaneInfoResponse(BaseModel):
    """API/UI listen settings from the running server (pygubernator.cfg / env)."""

    api_host: str
    api_port: int
    api_url: str
    ui_host: str
    ui_port: int


class RunOut(BaseModel):
    id: str
    agent_id: str
    agent_version_id: str | None
    status: str
    trigger: str | None
    correlation_id: str | None
    created_at: datetime
    started_at: datetime | None
    ended_at: datetime | None
    duration_ms: int | None
    token_input: int
    token_output: int
    cost_usd_micros: int
    metadata_json: dict[str, Any]
    error_message: str | None

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Library testing
# ---------------------------------------------------------------------------


class LibraryTestJobCreateRequest(BaseModel):
    name: str = ""
    spec_json: dict[str, Any] = Field(default_factory=dict)


class LibraryTestJobEventSubmitRequest(BaseModel):
    trigger: str
    idempotency_key: str | None = None
    payload_json: dict[str, Any] = Field(default_factory=dict)
    workflow_run_id: str | None = None


class LibraryTestJobOut(BaseModel):
    id: str
    machine_name: str
    machine_version: str
    current_state: str
    name: str
    spec_json: dict[str, Any]
    last_workflow_run_id: str | None
    last_error_message: str | None
    created_by: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class LibraryTestJobEventOut(BaseModel):
    id: str
    job_id: str
    trigger: str
    actor: str
    idempotency_key: str
    workflow_run_id: str | None
    payload_json: dict[str, Any]
    created_at: datetime
    from_state: str
    to_state: str
    success: int
    error_message: str | None

    model_config = {"from_attributes": True}


class ServerConfigPatchRequest(BaseModel):
    """PATCH ``/settings/server-config``: allow-listed ``PYGUBERNATOR_*`` keys."""

    values: dict[str, Any] = Field(
        ...,
        description="Map of env-style key to new value written to pygubernator.cfg",
    )


# ---------------------------------------------------------------------------
# Knowledge-base routes
# ---------------------------------------------------------------------------


class KBChunkOut(BaseModel):
    """A single chunk row exposed over the API."""

    chunk_id: str
    text: str
    score: float
    concept_refs: list[str] = Field(default_factory=list)
    contract_id: str | None = None
    source_uri: str | None = None
    binding_state: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class KBChunkListOut(BaseModel):
    """Paginated list of chunks + total count."""

    items: list[KBChunkOut]
    meta: PageMeta


class KBSearchRequest(BaseModel):
    """POST ``/kb/search`` payload."""

    query: str = Field(..., min_length=1)
    limit: int = Field(default=5, ge=1, le=100)
    min_score: float = Field(default=0.0, ge=0.0, le=1.0)
    scope_filter: dict[str, str] | None = None
    concept_filter: list[str] | None = None
    contract_filter: list[str] | None = None
    embedding_model: str = Field(default="text-embedding-3-small")


class KBSearchResponse(BaseModel):
    """Ranked search hits."""

    query: str
    items: list[KBChunkOut]
    count: int


class KBBindingPromoteRequest(BaseModel):
    """POST ``/kb/chunks/{id}/binding`` payload."""

    state: Literal["unmapped", "suggested", "mapped", "approved"]


class KBBindingPromoteResponse(BaseModel):
    """Response after a state transition."""

    chunk_id: str
    state: str


class KBBulkDeleteResponse(BaseModel):
    """Response after a bulk delete by scope."""

    removed: int
