"""Knowledge-base routes — list, inspect, search, promote bindings, delete.

All endpoints are thin adapters over
:class:`pygubernator.memory.SqliteVectorStore`; they don't perform any
business logic themselves. An optional ``embedding_provider`` can be
injected in tests to avoid hitting an external service during search.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_internal,
    raise_logged_not_found,
    raise_logged_service_unavailable,
    raise_logged_unprocessable,
    raise_logged_unprocessable_from_exception,
)
from pygubernator.api.deps import CurrentUser
from pygubernator.api.models import (
    KBBindingPromoteRequest,
    KBBindingPromoteResponse,
    KBBulkDeleteResponse,
    KBChunkListOut,
    KBChunkOut,
    KBSearchRequest,
    KBSearchResponse,
    PageMeta,
)
from pygubernator.llm._embeddings import create_embedding_provider
from pygubernator.memory import SearchHit, SqliteVectorStore
from pygubernator.semantic import SemanticClient, resolve_default_client

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/kb", tags=["knowledge-base"])


def _hit_to_model(hit: SearchHit) -> KBChunkOut:
    """Convert a :class:`SearchHit` to its API model."""
    # The vector store packs the chunk id + concept refs + contract id
    # into the metadata dict at ``to_dict`` time. When the hit is
    # returned directly from ``list_chunks``/``get`` those fields are
    # already on the dataclass too, so we prefer the typed accessor.
    raw_metadata = dict(hit.metadata or {})
    # Drop duplicated keys that live at the top level of the response.
    _duplicated_keys = (
        "chunk_id",
        "concept_refs",
        "contract_id",
        "source_uri",
        "binding_state",
    )
    for key in _duplicated_keys:
        raw_metadata.pop(key, None)
    return KBChunkOut(
        chunk_id=hit.chunk_id,
        text=hit.text,
        score=float(hit.score),
        concept_refs=list(hit.concept_refs),
        contract_id=hit.contract_id,
        source_uri=hit.source_uri,
        binding_state=hit.binding_state,
        metadata=raw_metadata,
    )


def _scope_filter_from_query(
    agent_id: str | None,
    workflow_id: str | None,
    run_id: str | None,
) -> dict[str, str]:
    """Build a scope-filter dict from query parameters."""
    out: dict[str, str] = {}
    for key, value in (
        ("agent_id", agent_id),
        ("workflow_id", workflow_id),
        ("run_id", run_id),
    ):
        if isinstance(value, str) and value.strip():
            out[key] = value.strip()
    return out


def _get_store() -> SqliteVectorStore:
    """Return the default vector store for route handlers.

    Module-level factory so tests can monkey-patch it to inject a fake.
    """
    return SqliteVectorStore()


def _get_semantic_client() -> SemanticClient:
    """Return the default :class:`SemanticClient` for route handlers.

    Separate factory so tests can patch it to inject a fake client that
    asserts on lifecycle events without standing up pycharter.
    """
    return resolve_default_client()


@router.get("/chunks", response_model=KBChunkListOut)
def list_chunks_route(
    _: CurrentUser,
    agent_id: str | None = Query(default=None),
    workflow_id: str | None = Query(default=None),
    run_id: str | None = Query(default=None),
    contract_id: str | None = Query(default=None),
    concept: str | None = Query(default=None),
    binding_state: str | None = Query(
        default=None, pattern="^(unmapped|suggested|mapped|approved)$"
    ),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=25, ge=1, le=200),
) -> KBChunkListOut:
    """Paginated chunk browse with scope + concept + contract filters."""
    store = _get_store()
    scope_filter = _scope_filter_from_query(agent_id, workflow_id, run_id)
    hits, total = store.list_chunks(
        scope_filter=scope_filter or None,
        concept_filter=[concept] if concept else None,
        contract_filter=[contract_id] if contract_id else None,
        binding_state_filter=[binding_state] if binding_state else None,
        limit=page_size,
        offset=(page - 1) * page_size,
    )
    return KBChunkListOut(
        items=[_hit_to_model(h) for h in hits],
        meta=PageMeta(total=total, page=page, page_size=page_size),
    )


@router.get("/chunks/{chunk_id}", response_model=KBChunkOut)
def get_chunk_route(chunk_id: str, _: CurrentUser) -> KBChunkOut:
    """Return a single chunk by id."""
    store = _get_store()
    hit = store.get(chunk_id)
    if hit is None:
        raise_logged_not_found(
            logger,
            LookupError(f"chunk_id={chunk_id}"),
            public_detail=f"chunk '{chunk_id}' not found",
            log_event="kb_chunk_not_found",
        )
    return _hit_to_model(hit)


@router.post("/search", response_model=KBSearchResponse)
async def search_chunks_route(
    payload: KBSearchRequest,
    _: CurrentUser,
) -> KBSearchResponse:
    """Embed a query and return the nearest chunks."""
    store = _get_store()
    embedding_provider = create_embedding_provider(payload.embedding_model)
    try:
        vectors = await embedding_provider.embed([payload.query])
    except Exception as exc:  # noqa: BLE001 — user-configurable provider
        raise_logged_service_unavailable(
            logger,
            exc,
            public_detail="embedding provider failed",
            log_event="kb_search_embed_failed",
        )
    if not vectors:
        return KBSearchResponse(query=payload.query, items=[], count=0)

    hits = store.search(
        list(vectors[0]),
        limit=payload.limit,
        scope_filter=payload.scope_filter or None,
        concept_filter=payload.concept_filter or None,
        contract_filter=payload.contract_filter or None,
        min_score=payload.min_score,
    )
    items = [_hit_to_model(h) for h in hits]
    return KBSearchResponse(query=payload.query, items=items, count=len(items))


@router.post(
    "/chunks/{chunk_id}/binding",
    response_model=KBBindingPromoteResponse,
)
def promote_binding_route(
    chunk_id: str,
    payload: KBBindingPromoteRequest,
    user: CurrentUser,
) -> KBBindingPromoteResponse:
    """Move a chunk's ``binding_state`` along the lifecycle.

    After the vector store is updated we fan the transition out to
    pycharter via :meth:`SemanticClient.record_binding_transition` so the
    ``concept_binding_events`` audit log stays in sync. The semantic
    call is best-effort — a pycharter outage must not break the KB UI.
    """
    store = _get_store()
    try:
        updated = store.set_binding_state(chunk_id, payload.state)
    except ValueError as exc:
        # The ValueError comes from our own vector store validator
        # (``_vector_store.set_binding_state``) with an authored,
        # user-actionable message (e.g. ``invalid binding_state=...``).
        # Surface it as a structured public-facing detail so the UI can
        # show the actual rule rather than a generic fallback.
        raise_logged_unprocessable_from_exception(
            logger,
            exc,
            log_event="kb set_binding_state failed",
            fallback_detail="Invalid binding state transition",
            extra_safe_types=(ValueError,),
        )
    if not updated:
        raise_logged_not_found(
            logger,
            LookupError(f"chunk_id={chunk_id}"),
            public_detail=f"chunk '{chunk_id}' not found",
            log_event="kb_chunk_not_found",
        )

    chunk = store.get(chunk_id)
    if chunk is not None:
        _record_chunk_binding_events(chunk, payload.state, actor=_actor_from_user(user))

    return KBBindingPromoteResponse(chunk_id=chunk_id, state=payload.state)


def _record_chunk_binding_events(
    chunk: SearchHit,
    to_state: str,
    *,
    actor: str,
) -> None:
    """Emit one lifecycle event per (contract_id, chunk_id, concept_id).

    Chunks model the "field_path" side of the lifecycle as
    ``chunk:{chunk_id}`` so every concept the chunk claims can carry
    independent lineage.
    """
    contract_id = chunk.contract_id or ""
    if not contract_id or not chunk.concept_refs:
        return
    field_path = f"chunk:{chunk.chunk_id}"
    client = _get_semantic_client()
    for concept_id in chunk.concept_refs:
        try:
            client.record_binding_transition(
                contract_id=contract_id,
                field_path=field_path,
                concept_id=concept_id,
                to_state=to_state,  # type: ignore[arg-type]
                actor=actor,
                reason="kb_review",
            )
        except Exception:  # noqa: BLE001 — lifecycle emit is best-effort
            logger.debug(
                "failed to emit binding event for chunk %s",
                chunk.chunk_id,
                exc_info=True,
            )


def _actor_from_user(user: CurrentUser) -> str:
    """Best-effort extract of the acting user's identity for audit."""
    for attr in ("username", "email", "id"):
        value = getattr(user, attr, None)
        if value:
            return str(value)
    return "kb_reviewer"


@router.get("/concepts/{concept_id}/inferred")
def inferred_relationships_route(
    concept_id: str,
    _: CurrentUser,
    direction: str = Query(default="both", pattern="^(outgoing|incoming|both)$"),
    types: str | None = Query(default=None),
    only_inferred: bool = Query(default=False),
) -> dict[str, list[dict[str, object]]]:
    """Proxy the pycharter reasoner for a single concept.

    Returns an ``items`` list of ``{source_id, target_id, relationship_type,
    inferred}`` rows so UI components can distinguish stated facts from
    reasoner-derived facts. Empty list when pycharter is unreachable.
    """
    client = _get_semantic_client()
    type_tuple: tuple[str, ...] | None = (
        tuple(t.strip() for t in types.split(",") if t.strip()) if types else None
    )
    try:
        rels = client.inferred_relationships(
            concept_id,
            direction=direction,
            types=type_tuple,
            only_inferred=only_inferred,
        )
    except Exception:  # noqa: BLE001 — degrade to empty rather than 500
        logger.debug(
            "inferred_relationships proxy failed for %s",
            concept_id,
            exc_info=True,
        )
        rels = []
    return {
        "items": [
            {
                "source_id": rel.source_id,
                "target_id": rel.target_id,
                "relationship_type": rel.relationship_type,
                "inferred": rel.inferred,
            }
            for rel in rels
        ]
    }


@router.get("/bindings/events")
def binding_events_route(
    _: CurrentUser,
    contract_id: str | None = Query(default=None),
    field_path: str | None = Query(default=None),
    concept_id: str | None = Query(default=None),
) -> dict[str, list[dict[str, object]]]:
    """Proxy pycharter's binding-lifecycle event log.

    The UI calls this with ``field_path=chunk:{chunk_id}`` to render a
    timeline for a single KB chunk. Returns ``{"items": [...]}`` so the
    shape matches the other proxies and the UI can dedupe typings.
    """
    client = _get_semantic_client()
    try:
        rows = client.list_binding_events(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
        )
    except Exception:  # noqa: BLE001 — degrade to empty rather than 500
        logger.debug(
            "binding events proxy failed for %s / %s / %s",
            contract_id,
            field_path,
            concept_id,
            exc_info=True,
        )
        rows = []
    return {
        "items": [
            {
                "contract_id": row.contract_id,
                "field_path": row.field_path,
                "concept_id": row.concept_id,
                "from_state": row.from_state,
                "to_state": row.to_state,
                "actor": row.actor,
                "reason": row.reason,
                "timestamp": row.timestamp,
            }
            for row in rows
        ]
    }


@router.get("/schemes/{scheme_key}/rdf")
def export_scheme_rdf_route(
    scheme_key: str,
    _: CurrentUser,
    format: str = Query(default="turtle", pattern="^(turtle|jsonld)$"),
) -> dict[str, str]:
    """Proxy pycharter's scheme RDF export.

    Returns ``{"text": <serialised scheme>}`` so the browser can
    download it or render it inline without a dedicated text route.
    Returns 404 when the scheme is unknown.
    """
    client = _get_semantic_client()
    try:
        body = client.export_scheme_rdf(scheme_key, format=format)
    except Exception as exc:  # noqa: BLE001 — pycharter proxy
        raise_logged_internal(
            logger,
            exc,
            public_detail="Scheme RDF export failed",
            log_event="kb scheme RDF export proxy failed",
        )
    if body is None:
        raise_logged_not_found(
            logger,
            LookupError(f"scheme_key={scheme_key}"),
            public_detail=(
                f"scheme '{scheme_key}' not found or RDF backend unavailable"
            ),
            log_event="kb_scheme_rdf_export_missing",
        )
    return {"text": body, "format": format, "scheme_key": scheme_key}


@router.post("/schemes/rdf")
def import_scheme_rdf_route(
    payload: dict[str, object],
    _: CurrentUser,
) -> dict[str, object]:
    """Proxy pycharter's scheme RDF import.

    Request body: ``{text, format, scheme_key?}``. Response reports the
    scheme key resolved on the server side + number of concepts upserted.
    """
    text = str(payload.get("text", ""))
    if not text.strip():
        raise_logged_bad_request(
            logger,
            ValueError("empty scheme RDF text"),
            public_detail="'text' is required and must be non-empty",
            log_event="kb_scheme_rdf_import_empty",
        )
    fmt = str(payload.get("format", "turtle"))
    if fmt not in {"turtle", "jsonld"}:
        raise_logged_bad_request(
            logger,
            ValueError(f"unsupported scheme RDF format: {fmt}"),
            public_detail="'format' must be 'turtle' or 'jsonld'",
            log_event="kb_scheme_rdf_import_bad_format",
        )
    scheme_key = payload.get("scheme_key")
    scheme_key_str = str(scheme_key) if isinstance(scheme_key, str) else None
    client = _get_semantic_client()
    try:
        upserted = client.import_scheme_rdf(
            text,
            format=fmt,
            scheme_key=scheme_key_str,
        )
    except Exception as exc:  # noqa: BLE001 — pycharter proxy
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Scheme RDF import failed",
            log_event="kb scheme RDF import proxy failed",
        )
    return {
        "scheme_key": scheme_key_str or "imported",
        "concepts_upserted": upserted,
    }


@router.post("/governance/validate")
def governance_validate_route(
    _: CurrentUser,
    payload: dict[str, object] | None = None,
) -> dict[str, object]:
    """Proxy the pycharter SHACL governance validator.

    Request body mirrors pycharter's ``GovernanceValidateRequest`` —
    optional ``scheme_key`` and ``extra_shapes_ttl`` fields. Response is
    the structured report so UIs can render violations inline.
    """
    client = _get_semantic_client()
    body = payload or {}
    scheme = body.get("scheme_key")
    extra = body.get("extra_shapes_ttl")
    try:
        report = client.validate_governance(
            scheme=scheme if isinstance(scheme, str) else None,
            extra_shapes_ttl=extra if isinstance(extra, str) else None,
        )
    except Exception as exc:  # noqa: BLE001 — pycharter proxy
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Governance validation failed",
            log_event="kb governance validate proxy failed",
        )
    return {
        "conforms": report.conforms,
        "error_count": report.error_count,
        "warning_count": report.warning_count,
        "info_count": report.info_count,
        "violations": [
            {
                "focus_node": v.focus_node,
                "path": v.path,
                "value": v.value,
                "shape": v.shape,
                "severity": v.severity,
                "message": v.message,
            }
            for v in report.violations
        ],
    }


@router.delete("/chunks", response_model=KBBulkDeleteResponse)
def bulk_delete_chunks_route(
    _: CurrentUser,
    agent_id: str | None = Query(default=None),
    workflow_id: str | None = Query(default=None),
    run_id: str | None = Query(default=None),
) -> KBBulkDeleteResponse:
    """Bulk-delete chunks by scope.

    At least one of ``agent_id`` / ``workflow_id`` / ``run_id`` is
    required — the underlying store refuses an empty filter to prevent
    accidentally clearing the whole knowledge base.
    """
    scope_filter = _scope_filter_from_query(agent_id, workflow_id, run_id)
    if not scope_filter:
        raise_logged_unprocessable(
            logger,
            ValueError("kb bulk delete missing scope filter"),
            public_detail=(
                "at least one of agent_id / workflow_id / run_id must be "
                "provided when deleting"
            ),
            log_event="kb_bulk_delete_no_scope",
        )
    store = _get_store()
    try:
        removed = store.delete(scope_filter=scope_filter)
    except ValueError as exc:
        raise_logged_unprocessable(
            logger,
            exc,
            public_detail="Invalid bulk delete scope",
            log_event="kb bulk delete failed",
        )
    return KBBulkDeleteResponse(removed=removed)
