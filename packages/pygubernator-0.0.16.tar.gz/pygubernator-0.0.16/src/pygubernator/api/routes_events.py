"""SSE endpoint for real-time config-change events."""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Query, Request
from starlette.responses import StreamingResponse

from pygubernator.events import ChangeBus, ChangeEvent

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/events",
    tags=["events"],
)


def _get_bus(request: Request) -> ChangeBus:
    """Retrieve the ChangeBus from app state."""
    return request.app.state.change_bus


@router.get("/stream")
async def stream_config_events(
    request: Request,
    topic: str | None = Query(
        None,
        description="Filter events by topic (omit for all)",
    ),
) -> StreamingResponse:
    """SSE stream of config-change events.

    Browsers connect via ``EventSource``; auth is **not**
    required because ``EventSource`` cannot send custom headers.

    An optional *topic* query parameter narrows the stream to
    a single resource type (e.g. ``?topic=workflow``).
    """
    bus = _get_bus(request)

    queue: asyncio.Queue[ChangeEvent] = asyncio.Queue()

    def _on_event(event: ChangeEvent) -> None:
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning(
                "SSE config-events queue full, dropping %s/%s",
                event.topic,
                event.action,
            )

    subscribe_topic = topic or "*"
    bus.subscribe(subscribe_topic, _on_event)

    async def _generate():
        try:
            while True:
                try:
                    event = await asyncio.wait_for(
                        queue.get(),
                        timeout=30,
                    )
                except TimeoutError:
                    yield ": keepalive\n\n"
                    continue

                payload = {
                    "topic": event.topic,
                    "action": event.action,
                    "resource_id": event.resource_id,
                    "revision": event.revision,
                    "actor": event.actor,
                    "timestamp": event.timestamp,
                    "metadata": event.metadata,
                }
                yield f"data: {json.dumps(payload)}\n\n"
        finally:
            bus.unsubscribe(subscribe_topic, _on_event)

    return StreamingResponse(
        _generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
