"""In-memory SSE event broadcaster for workflow run streaming."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)

_SENTINEL: dict[str, Any] = {"type": "done"}
_CLEANUP_DELAY_S = 30


class SSEBroadcaster:
    """Thread-safe broadcaster that fans out events to async SSE subscribers.

    Each ``run_id`` can have multiple subscriber queues. Background threads
    call :meth:`publish` (sync) to push events; async SSE generators call
    :meth:`subscribe` / :meth:`unsubscribe` to consume them.

    Events are buffered per run so that late subscribers receive the full
    history (up to ``_MAX_BUFFER`` events), preventing race conditions
    where the workflow finishes before the frontend connects.
    """

    _MAX_BUFFER = 200

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._queues: dict[str, list[asyncio.Queue[dict[str, Any]]]] = {}
        self._buffers: dict[str, list[dict[str, Any]]] = {}

    def subscribe(self, run_id: str) -> asyncio.Queue[dict[str, Any]]:
        """Create and return a subscription queue for a run.

        Late subscribers receive all buffered events so they can
        reconstruct the full execution state.

        Args:
            run_id: Workflow run identifier.

        Returns:
            Queue that will receive events published for this run.
        """
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        with self._lock:
            # Replay buffered events so late subscribers catch up
            for event in self._buffers.get(run_id, []):
                queue.put_nowait(event)
            self._queues.setdefault(run_id, []).append(queue)
        logger.debug("SSE subscriber added for run %s", run_id[:12])
        return queue

    def unsubscribe(self, run_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        """Remove a subscription queue.

        Args:
            run_id: Workflow run identifier.
            queue: The queue to remove.
        """
        import contextlib

        with self._lock:
            queues = self._queues.get(run_id, [])
            with contextlib.suppress(ValueError):
                queues.remove(queue)
            if not queues:
                self._queues.pop(run_id, None)

    def publish(self, run_id: str, event: dict[str, Any]) -> None:
        """Push an event to all subscribers for a run.

        Events are also buffered so late subscribers can replay them.
        Safe to call from any thread.

        Args:
            run_id: Workflow run identifier.
            event: Event data dict to broadcast.
        """
        with self._lock:
            buf = self._buffers.setdefault(run_id, [])
            if len(buf) < self._MAX_BUFFER:
                buf.append(event)
            queues = list(self._queues.get(run_id, []))

        for queue in queues:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("SSE queue full for run %s, dropping event", run_id[:12])

    def close(self, run_id: str) -> None:
        """Signal completion by sending a sentinel and schedule cleanup.

        Args:
            run_id: Workflow run identifier.
        """
        self.publish(run_id, _SENTINEL)

        # Delayed cleanup so late subscribers can still read the sentinel
        def _cleanup() -> None:
            time.sleep(_CLEANUP_DELAY_S)
            with self._lock:
                self._queues.pop(run_id, None)
                self._buffers.pop(run_id, None)

        thread = threading.Thread(target=_cleanup, daemon=True)
        thread.start()


# Module-level singleton — imported by routes and services
broadcaster = SSEBroadcaster()
