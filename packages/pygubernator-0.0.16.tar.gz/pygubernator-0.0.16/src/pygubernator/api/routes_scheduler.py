"""Scheduler CRUD routes (admin-only)."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_not_found,
    raise_logged_service_unavailable,
    raise_logged_unprocessable,
)
from pygubernator.api.deps import AdminUser, DbSession
from pygubernator.db.models import ScheduledJob

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin/schedules",
    tags=["scheduler"],
)


# --------------- Request / Response models ---------------


class JobCreate(BaseModel):
    """Request body for creating a scheduled job."""

    workflow_id: str = Field(..., description="Workflow to trigger")
    cron: str = Field(..., description="Cron expression")
    timezone: str = Field("UTC", description="IANA timezone name")
    input_json: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    name: str = ""
    description: str = ""
    concurrency_policy: str = "allow"
    misfire_policy: str = "fire_now"
    misfire_grace_seconds: int = 60


class JobUpdate(BaseModel):
    """Request body for updating a scheduled job."""

    cron: str | None = None
    timezone: str | None = None
    input_json: dict[str, Any] | None = None
    enabled: bool | None = None
    name: str | None = None
    description: str | None = None
    concurrency_policy: str | None = None
    misfire_policy: str | None = None
    misfire_grace_seconds: int | None = None


class JobResponse(BaseModel):
    """Response model for a scheduled job."""

    id: str
    workflow_id: str
    name: str
    description: str
    cron_expression: str
    timezone: str
    input_json: dict[str, Any]
    enabled: bool
    concurrency_policy: str
    misfire_policy: str
    misfire_grace_seconds: int
    last_run_at: datetime | None
    next_run_at: datetime | None
    last_status: str
    created_by: str
    created_at: datetime
    updated_at: datetime


# --------------- Helpers ---------------


def _to_response(row: ScheduledJob) -> JobResponse:
    """Convert a DB row to a response model."""
    return JobResponse(
        id=row.id,
        workflow_id=row.workflow_id,
        name=row.name,
        description=row.description,
        cron_expression=row.cron_expression,
        timezone=row.timezone,
        input_json=row.input_json,
        enabled=row.enabled,
        concurrency_policy=row.concurrency_policy,
        misfire_policy=row.misfire_policy,
        misfire_grace_seconds=row.misfire_grace_seconds,
        last_run_at=row.last_run_at,
        next_run_at=row.next_run_at,
        last_status=row.last_status,
        created_by=row.created_by,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _validate_cron(expr: str) -> None:
    """Validate a cron expression or raise 422."""
    from pygubernator.scheduler._engine import (
        validate_cron,
    )

    if not validate_cron(expr):
        raise_logged_unprocessable(
            logger,
            ValueError(f"invalid cron expression: {expr}"),
            public_detail=f"Invalid cron expression: {expr}",
            log_event="scheduler_invalid_cron",
        )


def _validate_timezone(name: str) -> None:
    try:
        ZoneInfo(name)
    except Exception as exc:
        raise_logged_unprocessable(
            logger,
            exc,
            public_detail=f"Invalid timezone: {name}",
            log_event="scheduler_invalid_timezone",
        )


def _validate_job_policies(
    *,
    concurrency_policy: str,
    misfire_policy: str,
    misfire_grace_seconds: int,
) -> None:
    if concurrency_policy not in {"allow", "skip"}:
        raise_logged_unprocessable(
            logger,
            ValueError(f"unsupported concurrency_policy: {concurrency_policy}"),
            public_detail="concurrency_policy must be 'allow' or 'skip'",
            log_event="scheduler_bad_concurrency_policy",
        )
    if misfire_policy not in {"fire_now", "skip"}:
        raise_logged_unprocessable(
            logger,
            ValueError(f"unsupported misfire_policy: {misfire_policy}"),
            public_detail="misfire_policy must be 'fire_now' or 'skip'",
            log_event="scheduler_bad_misfire_policy",
        )
    if misfire_grace_seconds < 0:
        raise_logged_unprocessable(
            logger,
            ValueError(f"negative misfire_grace_seconds: {misfire_grace_seconds}"),
            public_detail="misfire_grace_seconds must be >= 0",
            log_event="scheduler_bad_misfire_grace",
        )


# --------------- Endpoints ---------------


@router.get("")
def list_jobs(
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """List all scheduled jobs."""
    rows = db.query(ScheduledJob).all()
    items = [_to_response(r) for r in rows]
    return {
        "items": [i.model_dump(mode="json") for i in items],
    }


@router.post("", response_model=JobResponse)
def create_job(
    payload: JobCreate,
    _admin: AdminUser,
    db: DbSession,
) -> JobResponse:
    """Create a new scheduled job."""
    _validate_cron(payload.cron)
    _validate_timezone(payload.timezone)
    _validate_job_policies(
        concurrency_policy=payload.concurrency_policy,
        misfire_policy=payload.misfire_policy,
        misfire_grace_seconds=payload.misfire_grace_seconds,
    )

    from pygubernator.scheduler._engine import (
        compute_next_run,
    )

    row = ScheduledJob(
        workflow_id=payload.workflow_id,
        name=payload.name,
        description=payload.description,
        cron_expression=payload.cron,
        timezone=payload.timezone,
        input_json=payload.input_json,
        enabled=payload.enabled,
        concurrency_policy=payload.concurrency_policy,
        misfire_policy=payload.misfire_policy,
        misfire_grace_seconds=payload.misfire_grace_seconds,
        next_run_at=compute_next_run(payload.cron, timezone=payload.timezone),
        created_by=str(_admin.get("username", "system")),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info(
        "Created scheduled job %s for workflow %s",
        row.id,
        row.workflow_id,
    )
    return _to_response(row)


@router.patch(
    "/{job_id}",
    response_model=JobResponse,
)
def update_job(
    job_id: str,
    payload: JobUpdate,
    _admin: AdminUser,
    db: DbSession,
) -> JobResponse:
    """Update an existing scheduled job."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"scheduled_job_id={job_id}"),
            public_detail="Job not found",
            log_event="scheduler_job_not_found",
        )

    from pygubernator.scheduler._engine import (
        compute_next_run,
    )

    if payload.cron is not None:
        _validate_cron(payload.cron)
        row.cron_expression = payload.cron
    if payload.timezone is not None:
        _validate_timezone(payload.timezone)
        row.timezone = payload.timezone
    if payload.cron is not None or payload.timezone is not None:
        row.next_run_at = compute_next_run(
            row.cron_expression,
            timezone=row.timezone,
        )
    if payload.input_json is not None:
        row.input_json = payload.input_json
    if payload.enabled is not None:
        row.enabled = payload.enabled
    if payload.name is not None:
        row.name = payload.name
    if payload.description is not None:
        row.description = payload.description
    if payload.concurrency_policy is not None:
        _validate_job_policies(
            concurrency_policy=payload.concurrency_policy,
            misfire_policy=payload.misfire_policy or row.misfire_policy,
            misfire_grace_seconds=(
                payload.misfire_grace_seconds
                if payload.misfire_grace_seconds is not None
                else row.misfire_grace_seconds
            ),
        )
        row.concurrency_policy = payload.concurrency_policy
    if payload.misfire_policy is not None:
        _validate_job_policies(
            concurrency_policy=payload.concurrency_policy or row.concurrency_policy,
            misfire_policy=payload.misfire_policy,
            misfire_grace_seconds=(
                payload.misfire_grace_seconds
                if payload.misfire_grace_seconds is not None
                else row.misfire_grace_seconds
            ),
        )
        row.misfire_policy = payload.misfire_policy
    if payload.misfire_grace_seconds is not None:
        _validate_job_policies(
            concurrency_policy=payload.concurrency_policy or row.concurrency_policy,
            misfire_policy=payload.misfire_policy or row.misfire_policy,
            misfire_grace_seconds=payload.misfire_grace_seconds,
        )
        row.misfire_grace_seconds = payload.misfire_grace_seconds
    db.commit()
    db.refresh(row)
    logger.info("Updated scheduled job %s", row.id)
    return _to_response(row)


@router.delete("/{job_id}")
def delete_job(
    job_id: str,
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """Delete a scheduled job."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"scheduled_job_id={job_id}"),
            public_detail="Job not found",
            log_event="scheduler_job_not_found",
        )
    db.delete(row)
    db.commit()
    logger.info("Deleted scheduled job %s", job_id)
    return {"ok": True, "deleted": job_id}


@router.post("/{job_id}/trigger")
def trigger_job(
    job_id: str,
    _admin: AdminUser,
    db: DbSession,
) -> dict:
    """Manually trigger a scheduled job now."""
    row = db.get(ScheduledJob, job_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"scheduled_job_id={job_id}"),
            public_detail="Job not found",
            log_event="scheduler_job_not_found",
        )

    from pygubernator.db.store.sqlalchemy import (
        SQLAlchemyAgentStore,
    )
    from pygubernator.scheduler._engine import (
        _execute_in_thread,
        build_schedule_input,
    )

    store = SQLAlchemyAgentStore(session=db)
    workflow = store.get_workflow(row.workflow_id)
    if workflow is None:
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_id={row.workflow_id}"),
            public_detail="Workflow not found",
            log_event="scheduler_trigger_workflow_not_found",
        )

    versions = store.list_workflow_versions(row.workflow_id)
    active = next((v for v in versions if v.active), None)
    if active is None:
        raise_logged_bad_request(
            logger,
            ValueError(f"no active workflow version for workflow_id={row.workflow_id}"),
            public_detail="No active workflow version",
            log_event="scheduler_trigger_no_active_version",
        )

    scheduled_input = build_schedule_input(
        row,
        triggered_at=datetime.now(UTC),
        trigger_source="manual",
    )
    run = store.create_workflow_run(
        workflow_id=row.workflow_id,
        workflow_version_id=active.id,
        input_json=scheduled_input,
        created_by=f"scheduler:{row.id}",
    )
    db.commit()
    db.refresh(run)

    row.last_run_at = datetime.now(UTC)
    row.last_status = "triggered"
    db.commit()

    from pygubernator.db.session import (
        _get_session_factory,
    )

    _execute_in_thread(
        active.spec_json,
        scheduled_input,
        run.id,
        _get_session_factory(),
    )

    logger.info(
        "Manually triggered job %s -> run %s",
        job_id,
        run.id[:12],
    )
    return {"ok": True, "run_id": run.id}


# --------------- Cron preview (read-only) ---------------


class CronPreviewRequest(BaseModel):
    """Request body for previewing the next fire times of a cron expression."""

    cron: str = Field(..., description="5-field cron expression")
    timezone: str = Field(
        "UTC",
        description="IANA timezone name used to localise the preview",
    )
    count: int = Field(
        3,
        ge=1,
        le=20,
        description="Number of future fire times to return (1..20)",
    )


class CronPreviewResponse(BaseModel):
    """Response with parsed cron metadata + upcoming fire times."""

    ok: bool
    cron: str
    timezone: str
    next_fires_iso: list[str] = Field(
        default_factory=list,
        description="Upcoming fire times, ISO-8601 in the requested timezone.",
    )
    error: str | None = None


@router.post("/cron-preview", response_model=CronPreviewResponse)
def cron_preview(payload: CronPreviewRequest, _admin: AdminUser) -> CronPreviewResponse:
    """Compute the next ``count`` fire times for a cron + timezone pair.

    Used by the schedule builder UI to give users immediate feedback on
    what their human-friendly choices ("every weekday at 9 am") will
    actually produce. Pure read-only — no DB side effects.
    """
    try:
        from croniter import croniter
    except ImportError as exc:
        raise_logged_service_unavailable(
            logger,
            exc,
            public_detail="croniter is not installed; cron preview unavailable",
            log_event="scheduler_cron_preview_no_croniter",
        )

    try:
        tz = ZoneInfo(payload.timezone)
    except Exception:
        return CronPreviewResponse(
            ok=False,
            cron=payload.cron,
            timezone=payload.timezone,
            error=f"Unknown timezone: {payload.timezone!r}",
        )

    try:
        base = datetime.now(tz)
        iterator = croniter(payload.cron, base)
    except (ValueError, KeyError) as exc:
        return CronPreviewResponse(
            ok=False,
            cron=payload.cron,
            timezone=payload.timezone,
            error=f"Invalid cron expression: {exc}",
        )

    fires: list[str] = []
    for _ in range(payload.count):
        try:
            ts = iterator.get_next(datetime)
        except Exception as exc:  # noqa: BLE001
            return CronPreviewResponse(
                ok=False,
                cron=payload.cron,
                timezone=payload.timezone,
                next_fires_iso=fires,
                error=f"Failed to compute next fire: {exc}",
            )
        fires.append(ts.isoformat())

    return CronPreviewResponse(
        ok=True,
        cron=payload.cron,
        timezone=payload.timezone,
        next_fires_iso=fires,
    )
