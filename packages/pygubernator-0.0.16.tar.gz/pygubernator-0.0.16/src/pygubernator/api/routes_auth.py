"""Authentication routes backed by cfg/env users."""

from __future__ import annotations

import logging

from fastapi import APIRouter, status
from pydantic import BaseModel

from pygubernator.api._http_errors import (
    raise_logged_http_exception,
    raise_logged_service_unavailable,
)
from pygubernator.api.deps import (
    ACCESS_TOKEN_EXPIRE_SECONDS,
    CurrentUser,
    create_access_token,
    verify_credentials,
)
from pygubernator.config import get_auth_jwt_secret, get_auth_users, is_auth_disabled

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])
logger = logging.getLogger(__name__)


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = ACCESS_TOKEN_EXPIRE_SECONDS
    role: str = "User"


class UserResponse(BaseModel):
    username: str
    role: str = "User"
    auth_disabled: bool = False


@router.post("/login")
def login(payload: LoginRequest) -> LoginResponse:
    if is_auth_disabled():
        raise_logged_service_unavailable(
            logger,
            RuntimeError("auth disabled"),
            public_detail="Authentication is disabled",
            log_event="auth_login_disabled",
        )
    if not get_auth_users():
        raise_logged_service_unavailable(
            logger,
            RuntimeError("no auth users configured"),
            public_detail=(
                "Authentication not configured (set credentials or auth service)"
            ),
            log_event="auth_login_no_users",
        )
    if not get_auth_jwt_secret():
        raise_logged_service_unavailable(
            logger,
            RuntimeError("no JWT secret configured"),
            public_detail=(
                "JWT secret not configured "
                "(set PYGUBERNATOR_AUTH_JWT_SECRET in env or "
                "pygubernator.cfg [auth])"
            ),
            log_event="auth_login_no_jwt_secret",
        )

    matched = verify_credentials(payload.username, payload.password)
    if not matched:
        raise_logged_http_exception(
            logger,
            ValueError(f"bad credentials for username={payload.username}"),
            status_code=status.HTTP_401_UNAUTHORIZED,
            public_detail="Invalid username or password",
            log_event="auth_login_bad_credentials",
        )

    token = create_access_token(matched["username"], role=matched["role"])
    return LoginResponse(
        access_token=token,
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_SECONDS,
        role=matched["role"],
    )


@router.post("/logout")
def logout() -> dict[str, str]:
    return {"message": "OK"}


@router.get("/me")
def me(current_user: CurrentUser) -> UserResponse:
    return UserResponse(
        username=str(current_user["username"]),
        role=str(current_user.get("role", "User")),
        auth_disabled=bool(current_user.get("auth_disabled", False)),
    )
