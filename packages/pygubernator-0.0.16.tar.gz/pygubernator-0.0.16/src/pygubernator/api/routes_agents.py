"""Agent management routes."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Query
from sqlalchemy import select

from pygubernator.agents._spec import (
    compile_agent_spec,
    load_agent_spec_file,
    parse_agent_spec_payload,
)
from pygubernator.agents._spec_types import CompiledAgentVersionSpec
from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_conflict,
    raise_logged_not_found,
)
from pygubernator.api._routes_common import emit_audit, paginated_response
from pygubernator.api.deps import AdminUser, AgentStore, CurrentUser
from pygubernator.api.models import (
    AgentCreateFromSpecRequest,
    AgentCreateRequest,
    AgentDashboardOut,
    AgentHeartbeatOut,
    AgentHeartbeatsOut,
    AgentOut,
    AgentSpecDetailOut,
    AgentSpecPublishRequest,
    AgentSpecSummaryOut,
    AgentSpecValidateRequest,
    AgentSpecValidationOut,
    AgentUpdateRequest,
    AgentVersionCreateRequest,
    AgentVersionOut,
    RunEnqueueRequest,
    RunOut,
)
from pygubernator.api.services._tool_refs import validate_tool_refs_in_agent_tools
from pygubernator.db.models import Agent, AgentVersion
from pygubernator.errors import ConfigError

router = APIRouter(prefix="/api/v1/agents", tags=["agents"])
logger = logging.getLogger(__name__)


def _specs_root() -> Path:
    """Default local spec catalog root (file-first source of truth)."""
    return (Path.cwd() / "agents" / "specs").resolve()


def _resolve_spec_path(raw_path: str) -> Path:
    p = Path(raw_path).expanduser()
    if not p.is_absolute():
        p = (_specs_root() / p).resolve()
    return p.resolve()


def _compile_spec_from_path(path: str) -> CompiledAgentVersionSpec:
    """Compile an agent spec from a filesystem path (resolved against specs root)."""
    spec = load_agent_spec_file(str(_resolve_spec_path(path)))
    return compile_agent_spec(spec)


def _compile_agent_spec_or_400(
    *,
    spec_path: str | None,
    spec_json: dict[str, Any] | None,
    log_event: str,
    public_detail: str = "Invalid or unreadable agent spec",
) -> CompiledAgentVersionSpec:
    """Compile a spec from one of (spec_path, spec_json) or raise 400.

    Centralises the "load file or parse payload, then compile, then turn
    :class:`ConfigError` into a logged 400" pattern that previously lived
    inline in three different routes (R.1). Caller passes the
    ``log_event`` so each call site keeps its own audit-log breadcrumb.

    Args:
        spec_path: Path to a YAML/JSON spec on disk. Resolved relative
            to ``_specs_root()`` for non-absolute values.
        spec_json: Inline spec dict; used when ``spec_path`` is empty.
        log_event: Stable identifier written to the structured log on
            failure so an SRE can grep for the exact failure path.
        public_detail: Safe-to-surface message returned to the caller.

    Returns:
        A :class:`CompiledAgentVersionSpec` ready to drive an agent
        version create / publish.

    Raises:
        HTTPException: 400 (via :func:`raise_logged_bad_request`) when
            the spec fails to load or compile.
    """
    try:
        if spec_path:
            return _compile_spec_from_path(spec_path)
        if spec_json:
            spec = parse_agent_spec_payload(spec_json, source_path=spec_path)
            return compile_agent_spec(spec)
    except ConfigError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail=public_detail,
            log_event=log_event,
        )
    # Neither path nor json supplied → caller programming error; surface
    # explicitly so a future caller doesn't get a silent ``None``. The
    # ``raise_logged_*`` helpers return ``Never`` so mypy understands
    # control never falls past this point.
    raise_logged_bad_request(
        logger,
        ValueError("neither spec_path nor spec_json supplied"),
        public_detail="Provide either spec_path or spec_json to compile a spec.",
        log_event=log_event,
    )


def _require_agent(store: AgentStore, agent_id: str) -> Agent:
    """Fetch an agent or raise a logged 404 via the standard helper.

    Collapses the ``rec = store.get_agent(agent_id); if not rec: raise 404``
    pattern that appears in most routes in this file.
    """
    rec = store.get_agent(agent_id)
    if rec is None:
        raise_logged_not_found(
            logger,
            LookupError(f"agent_id={agent_id}"),
            public_detail="Agent not found",
            log_event="agent_not_found",
        )
    return rec


def _require_version(store: AgentStore, agent_id: str, version_id: str) -> AgentVersion:
    """Fetch an agent version (scoped to its agent) or raise a logged 404.

    The caller must already have validated that the agent exists — routes
    that need both an agent *and* a specific version typically call
    :func:`_require_agent` first and pass the known-good ``agent_id`` here.
    """
    version = store.get_agent_version(version_id)
    if version is None or version.agent_id != agent_id:
        raise_logged_not_found(
            logger,
            LookupError(f"agent_id={agent_id} version_id={version_id}"),
            public_detail="Agent/version not found",
            log_event="agent_version_not_found",
        )
    return version


@router.get("")
def get_agents(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    q: str | None = None,
) -> dict:
    items, total = store.list_agents(page=page, page_size=page_size)
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i.name.lower() or ql in i.owner.lower()]
    return paginated_response(
        items, total, page=page, page_size=page_size, model=AgentOut
    )


@router.get("/specs")
def list_agent_specs(_: CurrentUser, q: str | None = None) -> dict:
    root = _specs_root()
    if not root.exists():
        return {"items": []}
    items: list[dict] = []
    for pattern in ("*.yaml", "*.yml", "*.json"):
        for path in root.rglob(pattern):
            try:
                spec = load_agent_spec_file(str(path))
            except Exception:
                continue
            row = AgentSpecSummaryOut(
                path=str(path),
                name=spec.name or path.stem,
                owner=spec.owner,
                spec_version=spec.spec_version,
                fingerprint=spec.source_fingerprint or "",
            )
            if q:
                query = q.lower()
                if query not in row.name.lower() and query not in row.path.lower():
                    continue
            items.append(row.model_dump())
    items.sort(key=lambda entry: str(entry.get("name", "")).lower())
    return {"items": items}


@router.get("/specs/detail", response_model=AgentSpecDetailOut)
def get_agent_spec_detail(path: str, _: CurrentUser) -> AgentSpecDetailOut:
    compiled = _compile_agent_spec_or_400(
        spec_path=path,
        spec_json=None,
        log_event="agent_spec_detail_load_failed",
    )
    return AgentSpecDetailOut(
        path=compiled.spec_path or str(_resolve_spec_path(path)),
        spec_json=compiled.spec_json,
        fingerprint=compiled.spec_fingerprint or "",
    )


@router.get("/heartbeats", response_model=AgentHeartbeatsOut)
def list_agent_heartbeats(
    store: AgentStore,
    _: CurrentUser,
    agent_id: str | None = None,
    threshold_s: float = Query(120.0, gt=0, description="Stale-beat cutoff in seconds"),
    only_stale: bool = Query(
        False, description="Return only agents whose latest beat is stale"
    ),
) -> AgentHeartbeatsOut:
    """Return the latest heartbeat per agent with liveness enrichment.

    Autonomous agents (``watch_and_act``, ``inbox_consumer`` nodes, and
    ``LLMAgent``s with a ``HeartbeatEmitter``) append rows to
    ``agent_heartbeats`` on a cadence. This route flattens that table
    into "one row per agent, newest beat first" and decorates each with
    ``seconds_since_beat`` + ``is_stale`` so the UI can render a
    fleet-health indicator without doing the arithmetic itself.

    Agents that have never emitted a heartbeat simply don't appear. The
    ``is_stale`` decision uses ``threshold_s`` (default 120 s, matching
    :class:`StaleAgentDetector`).
    """
    # Lazy import: avoid routes-import-time circular risk against db.repositories.
    from pygubernator.db._heartbeats import list_latest_heartbeats

    rows = list_latest_heartbeats(store.session, agent_id=agent_id)
    now = datetime.now(UTC)

    # Resolve agent display names in one query so the fleet panel doesn't
    # have to cross-fetch ``/api/v1/agents`` for every row. Ad-hoc agents
    # that never got a registry row come back as ``agent_name=None``.
    agent_ids = {row.agent_id for row in rows}
    name_by_id: dict[str, str] = {}
    if agent_ids:
        name_by_id = {
            a.id: a.name
            for a in store.session.scalars(
                select(Agent).where(Agent.id.in_(agent_ids))
            ).all()
        }

    items: list[AgentHeartbeatOut] = []
    for row in rows:
        # ``created_at`` is stored with tz; the model defaults via _utcnow.
        # Fall back to UTC for any legacy naive datetimes rather than raising.
        created_at = row.created_at
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)
        age = max(0.0, (now - created_at).total_seconds())
        is_stale = age > threshold_s
        if only_stale and not is_stale:
            continue
        details = dict(row.details or {})
        current_node_id = details.get("current_node_id")
        tokens_raw = details.get("context_used_tokens")
        context_used_tokens: int | None = None
        if isinstance(tokens_raw, int):
            context_used_tokens = tokens_raw
        elif isinstance(tokens_raw, str) and tokens_raw.isdigit():
            context_used_tokens = int(tokens_raw)
        items.append(
            AgentHeartbeatOut(
                agent_id=row.agent_id,
                agent_name=name_by_id.get(row.agent_id),
                run_id=row.run_id,
                workflow_id=row.workflow_id,
                current_node_id=(
                    current_node_id if isinstance(current_node_id, str) else None
                ),
                context_used_tokens=context_used_tokens,
                status=row.status,
                details=details,
                created_at=created_at,
                seconds_since_beat=age,
                is_stale=is_stale,
            )
        )
    return AgentHeartbeatsOut(items=items, threshold_s=threshold_s)


@router.post("/specs/validate", response_model=AgentSpecValidationOut)
def validate_agent_spec(
    payload: AgentSpecValidateRequest,
    _: CurrentUser,
) -> AgentSpecValidationOut:
    try:
        spec = parse_agent_spec_payload(
            payload.spec_json, source_path=payload.source_path
        )
        compiled = compile_agent_spec(spec)
    except ConfigError as exc:
        return AgentSpecValidationOut(valid=False, errors=[str(exc)])
    return AgentSpecValidationOut(
        valid=True,
        fingerprint=compiled.spec_fingerprint,
        normalized=compiled.spec_json,
    )


@router.post("", response_model=AgentOut)
def create_agent(
    payload: AgentCreateRequest, store: AgentStore, actor: AdminUser
) -> AgentOut:
    rec = store.create_agent(
        name=payload.name, owner=payload.owner, status=payload.status
    )
    emit_audit(
        store,
        actor,
        "agent.create",
        resource_type="agent",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.post("/from-spec", response_model=AgentDashboardOut)
def create_agent_from_spec(
    payload: AgentCreateFromSpecRequest,
    store: AgentStore,
    actor: AdminUser,
) -> AgentDashboardOut:
    """Create an agent *and* its first version from one spec file.

    Single atomic operation: a failing version publish (bad tool ref,
    unreadable file, duplicate agent name) rolls back the whole thing
    rather than leaving an orphaned empty agent behind. ``name`` and
    ``owner`` default to the spec's ``meta`` block when omitted.
    """
    compiled = _compile_agent_spec_or_400(
        spec_path=payload.spec_path,
        spec_json=None,
        log_event="agent_create_from_spec_load_failed",
    )
    spec_meta = compiled.spec_json.get("meta") or {}
    spec_name = str(spec_meta.get("name") or "")
    spec_owner = str(spec_meta.get("owner") or "")

    agent_name = (payload.name or spec_name or "").strip()
    if not agent_name:
        raise_logged_bad_request(
            logger,
            ValueError("meta.name missing and no explicit name provided"),
            public_detail=(
                "Agent name is required. Either supply ``name`` in the request "
                "or set ``meta.name`` in the spec file."
            ),
            log_event="agent_create_from_spec_missing_name",
        )
    agent_owner = (payload.owner or spec_owner or "system").strip() or "system"

    existing = store.session.scalar(select(Agent).where(Agent.name == agent_name))
    if existing is not None:
        raise_logged_conflict(
            logger,
            ValueError(f"duplicate agent name: {agent_name}"),
            public_detail=f"Agent '{agent_name}' already exists",
            log_event="agent_create_from_spec_duplicate_name",
        )

    tool_ref_errors = validate_tool_refs_in_agent_tools(compiled.tools, store)
    if tool_ref_errors:
        raise_logged_bad_request(
            logger,
            ValueError("; ".join(tool_ref_errors)),
            public_detail="Invalid tool references in agent spec: "
            + "; ".join(tool_ref_errors),
            log_event="agent_create_from_spec_bad_tool_refs",
        )

    agent_rec = store.create_agent(
        name=agent_name, owner=agent_owner, status=payload.status
    )
    # Flush so agent_rec.id is populated before we insert the version row.
    store.session.flush()

    version_rec = store.create_agent_version(
        agent_id=agent_rec.id,
        version=payload.version,
        model=compiled.model,
        prompt=compiled.prompt,
        tools=compiled.tools,
        config=compiled.config,
        spec_path=compiled.spec_path,
        spec_fingerprint=compiled.spec_fingerprint,
        spec_json=compiled.spec_json,
    )
    store.session.flush()

    if payload.activate:
        store.activate_agent_version(agent_rec, version_rec.id)

    emit_audit(
        store,
        actor,
        "agent.create_from_spec",
        resource_type="agent",
        resource_id=agent_rec.id,
        details={
            "name": agent_name,
            "owner": agent_owner,
            "spec_path": payload.spec_path,
            "version": payload.version,
            "activate": payload.activate,
            "agent_version_id": version_rec.id,
        },
    )
    store.commit()
    store.refresh(agent_rec)
    store.refresh(version_rec)

    return AgentDashboardOut(
        agent=AgentOut.model_validate(agent_rec),
        versions=[AgentVersionOut.model_validate(version_rec)],
    )


@router.get("/{agent_id}/dashboard", response_model=AgentDashboardOut)
def get_agent_dashboard(
    agent_id: str,
    store: AgentStore,
    _: CurrentUser,
    include_deleted: bool = Query(False),
) -> AgentDashboardOut:
    """Return agent metadata and all versions in one round-trip.

    By default, soft-deleted versions are omitted. Pass
    ``include_deleted=true`` to surface retired rows (admin / audit views).
    """
    rec = _require_agent(store, agent_id)
    versions = store.list_agent_versions(agent_id, include_deleted=include_deleted)
    return AgentDashboardOut(
        agent=AgentOut.model_validate(rec),
        versions=[AgentVersionOut.model_validate(v) for v in versions],
    )


@router.post("/{agent_id}/runs", response_model=RunOut)
def enqueue_run_for_agent(
    agent_id: str,
    payload: RunEnqueueRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> RunOut:
    """Create a queued run for this agent (``agent_id`` is implicit from the path)."""
    _require_agent(store, agent_id)
    if payload.agent_version_id:
        version = store.session.get(AgentVersion, payload.agent_version_id)
        if not version or version.agent_id != agent_id:
            raise_logged_not_found(
                logger,
                LookupError(
                    f"agent_version_id={payload.agent_version_id} agent_id={agent_id}"
                ),
                public_detail="Agent version not found or does not belong to agent",
                log_event="enqueue_run_agent_version_not_found",
            )
    run = store.create_run(
        agent_id=agent_id,
        agent_version_id=payload.agent_version_id,
        status="queued",
        correlation_id=payload.correlation_id,
        trigger=payload.trigger,
        metadata_json=payload.metadata_json,
    )
    emit_audit(
        store,
        actor,
        "run.create",
        resource_type="run",
        resource_id=run.id,
        details={**payload.model_dump(), "agent_id": agent_id},
    )
    store.commit()
    store.refresh(run)
    return RunOut.model_validate(run)


@router.delete("/{agent_id}", response_model=AgentOut)
def delete_agent_route(
    agent_id: str,
    store: AgentStore,
    actor: AdminUser,
) -> AgentOut:
    """Soft-delete an agent by setting archived to True."""
    rec = _require_agent(store, agent_id)
    rec.archived = True
    emit_audit(
        store,
        actor,
        "agent.delete",
        resource_type="agent",
        resource_id=agent_id,
        details={"archived": True},
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.get("/{agent_id}", response_model=AgentOut)
def get_agent_detail(agent_id: str, store: AgentStore, _: CurrentUser) -> AgentOut:
    rec = _require_agent(store, agent_id)
    return AgentOut.model_validate(rec)


@router.patch("/{agent_id}", response_model=AgentOut)
def update_agent(
    agent_id: str,
    payload: AgentUpdateRequest,
    store: AgentStore,
    actor: AdminUser,
) -> AgentOut:
    rec = _require_agent(store, agent_id)
    if payload.name is not None:
        stripped_name = payload.name.strip()
        if not stripped_name:
            raise_logged_bad_request(
                logger,
                ValueError("empty agent name"),
                public_detail="Agent name cannot be empty",
                log_event="agent_update_empty_name",
            )
        rec.name = stripped_name
    if payload.owner is not None:
        stripped_owner = payload.owner.strip()
        if not stripped_owner:
            raise_logged_bad_request(
                logger,
                ValueError("empty agent owner"),
                public_detail="Agent owner cannot be empty",
                log_event="agent_update_empty_owner",
            )
        rec.owner = stripped_owner
    if payload.status is not None:
        rec.status = payload.status
    if payload.archived is not None:
        rec.archived = payload.archived
    emit_audit(
        store,
        actor,
        "agent.update",
        resource_type="agent",
        resource_id=agent_id,
        details=payload.model_dump(exclude_none=True),
    )
    store.commit()
    store.refresh(rec)
    return AgentOut.model_validate(rec)


@router.get("/{agent_id}/versions")
def get_agent_versions(
    agent_id: str,
    store: AgentStore,
    _: CurrentUser,
    include_deleted: bool = Query(False),
) -> dict:
    """List versions for an agent (soft-deleted rows hidden by default)."""
    versions = store.list_agent_versions(agent_id, include_deleted=include_deleted)
    return {"items": [AgentVersionOut.model_validate(v).model_dump() for v in versions]}


@router.post("/{agent_id}/versions", response_model=AgentVersionOut)
def create_agent_version(
    agent_id: str,
    payload: AgentVersionCreateRequest,
    store: AgentStore,
    actor: AdminUser,
) -> AgentVersionOut:
    _require_agent(store, agent_id)
    model = payload.model
    prompt = payload.prompt
    tools = dict(payload.tools)
    config = dict(payload.config)
    spec_path: str | None = None
    spec_fingerprint: str | None = None
    spec_json: dict | None = None
    if payload.spec_path or payload.spec_json:
        compiled = _compile_agent_spec_or_400(
            spec_path=payload.spec_path,
            spec_json=payload.spec_json,
            log_event="agent_version_create_invalid_spec",
            public_detail="Invalid agent spec payload",
        )
        model = compiled.model
        prompt = compiled.prompt
        tools = compiled.tools
        config = dict(compiled.config)
        spec_path = compiled.spec_path
        spec_fingerprint = compiled.spec_fingerprint
        spec_json = compiled.spec_json
    if payload.provider:
        config = {**config, "provider": payload.provider.model_dump()}
    tool_ref_errors = validate_tool_refs_in_agent_tools(tools, store)
    if tool_ref_errors:
        raise_logged_bad_request(
            logger,
            ValueError("; ".join(tool_ref_errors)),
            public_detail="Invalid tool references in agent version: "
            + "; ".join(tool_ref_errors),
            log_event="agent_version_create_bad_tool_refs",
        )
    rec = store.create_agent_version(
        agent_id=agent_id,
        version=payload.version,
        model=model,
        prompt=prompt,
        tools=tools,
        config=config,
        spec_path=spec_path,
        spec_fingerprint=spec_fingerprint,
        spec_json=spec_json,
    )
    emit_audit(
        store,
        actor,
        "agent.version.create",
        resource_type="agent_version",
        resource_id=rec.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(rec)
    return AgentVersionOut.model_validate(rec)


@router.post("/{agent_id}/specs/publish", response_model=AgentVersionOut)
def publish_agent_spec(
    agent_id: str,
    payload: AgentSpecPublishRequest,
    store: AgentStore,
    actor: AdminUser,
) -> AgentVersionOut:
    agent = _require_agent(store, agent_id)
    compiled = _compile_agent_spec_or_400(
        spec_path=payload.spec_path,
        spec_json=None,
        log_event="agent_spec_publish_load_failed",
    )
    tool_ref_errors = validate_tool_refs_in_agent_tools(compiled.tools, store)
    if tool_ref_errors:
        raise_logged_bad_request(
            logger,
            ValueError("; ".join(tool_ref_errors)),
            public_detail="Invalid tool references in agent spec: "
            + "; ".join(tool_ref_errors),
            log_event="agent_spec_publish_bad_tool_refs",
        )
    rec = store.create_agent_version(
        agent_id=agent_id,
        version=payload.version,
        model=compiled.model,
        prompt=compiled.prompt,
        tools=compiled.tools,
        config=compiled.config,
        spec_path=compiled.spec_path,
        spec_fingerprint=compiled.spec_fingerprint,
        spec_json=compiled.spec_json,
    )
    if payload.activate:
        store.activate_agent_version(agent, rec.id)
    emit_audit(
        store,
        actor,
        "agent.spec.publish",
        resource_type="agent_version",
        resource_id=rec.id,
        details={
            "agent_id": agent_id,
            "version": payload.version,
            "spec_path": payload.spec_path,
            "activate": payload.activate,
        },
    )
    store.commit()
    store.refresh(rec)
    return AgentVersionOut.model_validate(rec)


@router.post("/{agent_id}/versions/{version_id}/activate", response_model=AgentOut)
def activate_version(
    agent_id: str, version_id: str, store: AgentStore, actor: AdminUser
) -> AgentOut:
    agent = _require_agent(store, agent_id)
    version = _require_version(store, agent_id, version_id)
    if version.deleted_at is not None:
        raise_logged_bad_request(
            logger,
            ValueError(f"version {version_id} is soft-deleted"),
            public_detail="Cannot activate a deleted version",
            log_event="agent_version_activate_deleted",
        )
    store.activate_agent_version(agent, version_id)
    emit_audit(
        store,
        actor,
        "agent.version.activate",
        resource_type="agent",
        resource_id=agent_id,
        details={"version_id": version_id},
    )
    store.commit()
    store.refresh(agent)
    return AgentOut.model_validate(agent)


@router.post(
    "/{agent_id}/versions/{version_id}/deactivate", response_model=AgentVersionOut
)
def deactivate_version(
    agent_id: str, version_id: str, store: AgentStore, actor: AdminUser
) -> AgentVersionOut:
    """Clear the ``active`` flag on a version.

    Separate from "delete" — the version stays in the catalog and can be
    activated again later. If it was the agent's current active version,
    the agent ends up with no active version (explicit, visible state).
    """
    agent = _require_agent(store, agent_id)
    version = _require_version(store, agent_id, version_id)
    if version.deleted_at is not None:
        raise_logged_bad_request(
            logger,
            ValueError(f"version {version_id} is already soft-deleted"),
            public_detail="Version is already deleted",
            log_event="agent_version_deactivate_already_deleted",
        )
    store.deactivate_agent_version(agent, version_id)
    emit_audit(
        store,
        actor,
        "agent.version.deactivate",
        resource_type="agent_version",
        resource_id=version_id,
        details={"agent_id": agent_id},
    )
    store.commit()
    store.refresh(version)
    return AgentVersionOut.model_validate(version)


@router.delete("/{agent_id}/versions/{version_id}", response_model=AgentVersionOut)
def delete_version(
    agent_id: str, version_id: str, store: AgentStore, actor: AdminUser
) -> AgentVersionOut:
    """Soft-delete a version.

    Guards:
    * The version must belong to the agent (404 otherwise).
    * The version must not be currently active (400 — deactivate first or
      activate another version). Preserves the invariant that the agent's
      ``current_version_id`` never points at a soft-deleted row.

    Idempotent: deleting an already-deleted row returns the existing record
    unchanged.
    """
    agent = _require_agent(store, agent_id)
    version = _require_version(store, agent_id, version_id)
    if version.active or agent.current_version_id == version_id:
        raise_logged_bad_request(
            logger,
            ValueError(f"version {version_id} is currently active"),
            public_detail=(
                "Cannot delete the active version; deactivate it or activate "
                "another version first."
            ),
            log_event="agent_version_delete_active",
        )
    store.soft_delete_agent_version(agent, version_id)
    emit_audit(
        store,
        actor,
        "agent.version.delete",
        resource_type="agent_version",
        resource_id=version_id,
        details={"agent_id": agent_id},
    )
    store.commit()
    store.refresh(version)
    return AgentVersionOut.model_validate(version)
