"""Workflow management and execution routes."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from datetime import UTC, datetime
from typing import cast

from fastapi import APIRouter, Query, Request
from sqlalchemy.orm import Session
from starlette.responses import StreamingResponse

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_bad_request_from_exception,
    raise_logged_conflict,
    raise_logged_conflict_from_exception,
    raise_logged_http_exception,
    raise_logged_not_found,
)
from pygubernator.api._routes_common import (
    emit_audit,
    paginated_response,
    workspace_id_of,
)
from pygubernator.api.deps import AgentStore, CurrentUser
from pygubernator.api.models import (
    ArtifactQueryRequest,
    ArtifactQueryResponse,
    PageMeta,
    PortSchemaFieldOut,
    PortSchemaOut,
    WorkflowApprovalDecisionRequest,
    WorkflowApprovalOut,
    WorkflowArtifactContentOut,
    WorkflowArtifactOut,
    WorkflowArtifactsOut,
    WorkflowCreateRequest,
    WorkflowExecuteRequest,
    WorkflowNodeFieldOut,
    WorkflowNodePortOut,
    WorkflowNodePreviewRequest,
    WorkflowNodePreviewResponse,
    WorkflowNodeTypeOut,
    WorkflowOut,
    WorkflowRunOut,
    WorkflowSessionDetailOut,
    WorkflowSessionsOut,
    WorkflowSessionSummariesOut,
    WorkflowSessionSummaryCreateRequest,
    WorkflowSessionSummaryEntryOut,
    WorkflowSessionSummaryOut,
    WorkflowSessionUpdateRequest,
    WorkflowStepEventOut,
    WorkflowStepEventsOut,
    WorkflowStepRunOut,
    WorkflowToolPresetOut,
    WorkflowUpdateRequest,
    WorkflowVersionCreateRequest,
    WorkflowVersionOut,
)
from pygubernator.api.services._artifact_query import (
    ArtifactQueryError,
    run_artifact_query,
)
from pygubernator.api.services._preview import (
    PreviewRefusedError,
    preview_node,
)
from pygubernator.api.services._tool_refs import validate_tool_refs_in_workflow_spec
from pygubernator.api.services._workflows import execute_workflow
from pygubernator.db import repositories as repos
from pygubernator.db.store.sqlalchemy import SQLAlchemyAgentStore
from pygubernator.errors import NodeError
from pygubernator.workflow._fsm import (
    IllegalTransitionError,
    RunStatus,
    checked_status_update,
)
from pygubernator.workflow._preview_safety import classify as classify_preview_safety

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])
_CONTRACT_GATE_MODES = ["strict", "warn", "coerce"]
_ORCHESTRATION_MODES = ["standard", "entity_orchestration"]


def _require_workflow(store: AgentStore, workflow_id: str) -> object:
    """Fetch a workflow or raise a logged 404 via the standard helper."""
    wf = store.get_workflow(workflow_id)
    if wf is None:
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_id={workflow_id}"),
            public_detail="Workflow not found",
            log_event="workflow_not_found",
        )
    return wf


def _require_workflow_run(store: AgentStore, run_id: str) -> object:
    """Fetch a workflow run or raise a logged 404 via the standard helper."""
    run = store.get_workflow_run(run_id)
    if run is None:
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_run_id={run_id}"),
            public_detail="Workflow run not found",
            log_event="workflow_run_not_found",
        )
    return run


def _port_schema_out(schema: object) -> PortSchemaOut | None:
    """Convert a PortSchema dataclass to its API model, or None."""
    if schema is None:
        return None
    return PortSchemaOut(
        fields=[
            PortSchemaFieldOut(
                name=f.name,
                field_type=f.field_type,
                required=f.required,
                description=f.description,
            )
            for f in schema.fields  # type: ignore[attr-defined]
        ],
        mode=schema.mode,  # type: ignore[attr-defined]
        config_keys=list(schema.config_keys),  # type: ignore[attr-defined]
    )


@router.get("/node-types")
def list_workflow_node_types_route(_: CurrentUser) -> dict:
    """List workflow node metadata for editor-driven palettes and inspectors."""
    from pygubernator.api.services._workflows import build_node_registry

    registry = build_node_registry()
    items = [
        WorkflowNodeTypeOut(
            type_name=desc.type_name,
            display_name=desc.display_name,
            category=desc.category,
            description=desc.description,
            color=desc.color,
            icon=desc.icon,
            inputs=[
                WorkflowNodePortOut(
                    name=port.name,
                    direction=port.direction,
                    kind=port.kind,
                    label=port.label,
                    multiple=port.multiple,
                    schema=_port_schema_out(port.schema),
                )
                for port in desc.inputs
            ],
            outputs=[
                WorkflowNodePortOut(
                    name=port.name,
                    direction=port.direction,
                    kind=port.kind,
                    label=port.label,
                    multiple=port.multiple,
                    schema=_port_schema_out(port.schema),
                )
                for port in desc.outputs
            ],
            fields=[
                WorkflowNodeFieldOut(
                    name=field.name,
                    field_type=field.field_type,
                    label=field.label,
                    required=field.required,
                    default=field.default,
                    help_text=field.help_text,
                    options=list(field.options),
                    placeholder=field.placeholder,
                    visible_if=field.visible_if,
                )
                for field in desc.fields
            ],
            tags=list(desc.tags),
            supports_streaming=desc.supports_streaming,
            supports_checkpointing=desc.supports_checkpointing,
            supports_subgraph=desc.supports_subgraph,
            runtime_kind=desc.runtime_kind,
            output_schema=_port_schema_out(desc.output_schema),
            required_credentials=list(desc.required_credentials),
            preview_safety=classify_preview_safety(desc.type_name, {}).value,
        )
        for desc in registry.list_descriptions()
    ]
    return {
        "items": [item.model_dump(by_alias=True) for item in items],
        "contract_gate_modes": list(_CONTRACT_GATE_MODES),
        "orchestration_modes": list(_ORCHESTRATION_MODES),
    }


@router.get("/integrations/catalyst")
def catalyst_integration_metadata(_: CurrentUser) -> dict:
    """Built-in schema names and supported field types for Mock Data (pycatalyst)."""
    from pygubernator.tools.integrations.catalyst import (
        BUILTIN_CATALYST_SCHEMA_NAMES,
        CATALYST_FIELD_TYPES_SUPPORTED,
    )

    return {
        "builtin_schema_names": list(BUILTIN_CATALYST_SCHEMA_NAMES),
        "field_types_supported": list(CATALYST_FIELD_TYPES_SUPPORTED),
    }


@router.get("/integrations/pystator")
def pystator_integration_metadata(_: CurrentUser) -> dict:
    """Machine template paths for PyStator workflow nodes (local and API process)."""
    from pygubernator.workflow.integrations_meta import stator_machine_templates_public

    return {"machine_templates": stator_machine_templates_public()}


_CATALYST_PREVIEW_CAP = 5


@router.post("/integrations/catalyst/preview")
def catalyst_preview_route(payload: dict, _: CurrentUser) -> dict:
    """Return a small sample of generated records (capped) for editor checks."""
    from pygubernator.workflow.config.node_config import validate_catalyst_config

    cfg = {
        "operation": payload.get("operation", "generate_data"),
        "schema_name": payload.get("schema_name"),
        "fields": payload.get("fields"),
        "count": payload.get("count", 3),
        "seed": payload.get("seed"),
        "schemas_path": payload.get("schemas_path"),
    }
    errs = validate_catalyst_config(cfg)
    if errs:
        return {"ok": False, "errors": errs}

    try:
        count = int(cfg.get("count", 3))
    except (TypeError, ValueError):
        count = 3
    count = min(max(1, count), _CATALYST_PREVIEW_CAP)

    seed_raw = cfg.get("seed")
    seed = int(seed_raw) if seed_raw not in (None, "") else None

    try:
        from pycatalyst import GenerationEngine

        from pygubernator.tools.integrations.catalyst import (
            _build_schema_spec,
            _default_schemas,
            _load_schemas_from_file,
        )
    except ImportError as exc:
        return {"ok": False, "errors": [f"pycatalyst is required: {exc}"]}

    operation = str(cfg.get("operation", "generate_data"))
    engine = GenerationEngine()
    try:
        if operation == "generate_data":
            schema_name = str(cfg.get("schema_name", "")).strip()
            schemas_path = str(cfg.get("schemas_path", "") or "").strip()
            schemas = (
                _load_schemas_from_file(schemas_path)
                if schemas_path
                else _default_schemas()
            )
            if schema_name not in schemas:
                return {
                    "ok": False,
                    "errors": [
                        f"Schema '{schema_name}' not found. "
                        f"Available: {sorted(schemas.keys())}",
                    ],
                }
            result = engine.generate(schemas[schema_name], count, seed)
        else:
            fields_raw = cfg.get("fields")
            if isinstance(fields_raw, str) and fields_raw.strip():
                import json

                fields_raw = json.loads(fields_raw)
            if not isinstance(fields_raw, dict):
                return {"ok": False, "errors": ["fields must be an object"]}
            schema = _build_schema_spec(fields_raw)
            result = engine.generate(schema, count, seed)
    except Exception:
        logger.exception("catalyst preview failed")
        return {"ok": False, "errors": ["Catalyst preview failed"]}

    records: list[dict[str, object]] = []
    for r in result.records:
        if isinstance(r, dict):
            records.append(r)
        else:
            try:
                records.append(dict(r))
            except (TypeError, ValueError):
                records.append({"_repr": repr(r)})

    return {"ok": True, "records": records, "count": len(records)}


@router.post("/integrations/pystator/validate-machine")
def pystator_validate_machine_route(payload: dict, _: CurrentUser) -> dict:
    """Load and validate a machine definition without running transitions."""
    from pygubernator.workflow.config.node_config import (
        validate_pystator_local_machine_source,
    )
    from pygubernator.workflow.nodes._pystator_machine import load_fsm_config_dict

    cfg = {
        "machine_file": payload.get("machine_file"),
        "machine_config": payload.get("machine_config"),
        "variables": payload.get("variables"),
    }
    errs = validate_pystator_local_machine_source(cfg)
    if errs:
        return {"ok": False, "errors": errs}

    try:
        loaded = load_fsm_config_dict(cfg)
    except Exception:
        logger.exception("pystator validate-machine failed")
        return {"ok": False, "errors": ["Machine validation failed"]}

    meta = loaded.get("meta") if isinstance(loaded, dict) else {}
    machine_name = None
    if isinstance(meta, dict):
        machine_name = meta.get("machine_name")

    return {
        "ok": True,
        "machine_name": machine_name,
        "meta": meta if isinstance(meta, dict) else {},
    }


@router.post("/resolve-schemas")
def resolve_workflow_schemas_route(
    payload: dict,
    _: CurrentUser,
) -> dict:
    """Resolve input/output schemas for all nodes in a workflow spec.

    Accepts a raw spec_json and returns per-node resolved schemas,
    accounting for node configs and DAG topology.
    """
    from pygubernator.workflow._schema_resolution import (
        compute_all_schemas,
    )
    from pygubernator.workflow.config._loader import WorkflowLoader

    spec_json = payload.get("spec_json", {})
    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(spec_json)
    except Exception as exc:
        logger.exception("Schema resolution spec parse error: %s", exc)
        return {"schemas": {}, "error": "Could not parse workflow spec"}

    all_schemas = compute_all_schemas(spec)
    schemas: dict[str, dict[str, object]] = {}
    for node_id, (inp, out) in all_schemas.items():
        schemas[node_id] = {
            "input": _port_schema_out(inp).model_dump() if inp else None,
            "output": _port_schema_out(out).model_dump() if out else None,
        }
    return {"schemas": schemas}


@router.get("/tool-presets")
def list_workflow_tool_presets_route(_: CurrentUser) -> dict:
    """List built-in tool integration presets for the Tool node inspector."""
    from pygubernator.workflow.tool_presets import TOOL_INTEGRATION_PRESETS

    items = [
        WorkflowToolPresetOut(
            id=p.id,
            label=p.label,
            name=p.name,
            factory_module=p.factory_module,
            factory_function=p.factory_function,
            env_hint=p.env_hint,
        ).model_dump()
        for p in TOOL_INTEGRATION_PRESETS
    ]
    return {"items": items}


@router.post("", response_model=WorkflowOut)
def create_workflow_route(
    payload: WorkflowCreateRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> WorkflowOut:
    """Create a new workflow."""
    wf = store.create_workflow(
        name=payload.name,
        description=payload.description,
        owner=payload.owner,
    )
    emit_audit(
        store,
        actor,
        "workflow.create",
        resource_type="workflow",
        resource_id=wf.id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.get("")
def list_workflows_route(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    status: str | None = None,
    q: str | None = None,
) -> dict:
    """List workflows with pagination."""
    items, total = store.list_workflows(page=page, page_size=page_size, status=status)
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i.name.lower() or ql in i.owner.lower()]
    return paginated_response(
        items, total, page=page, page_size=page_size, model=WorkflowOut
    )


@router.get("/{workflow_id}", response_model=WorkflowOut)
def get_workflow_route(
    workflow_id: str, store: AgentStore, _: CurrentUser
) -> WorkflowOut:
    """Get workflow detail."""
    wf = _require_workflow(store, workflow_id)
    return WorkflowOut.model_validate(wf)


@router.patch("/{workflow_id}", response_model=WorkflowOut)
def update_workflow_route(
    workflow_id: str,
    payload: WorkflowUpdateRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> WorkflowOut:
    """Update workflow metadata."""
    wf = _require_workflow(store, workflow_id)
    updates = payload.model_dump(exclude_none=True)
    store.update_workflow(wf, **updates)
    emit_audit(
        store,
        actor,
        "workflow.update",
        resource_type="workflow",
        resource_id=workflow_id,
        details=updates,
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.delete("/{workflow_id}", response_model=WorkflowOut)
def delete_workflow_route(
    workflow_id: str,
    store: AgentStore,
    actor: CurrentUser,
) -> WorkflowOut:
    """Soft-delete a workflow by setting status to 'deleted'."""
    wf = _require_workflow(store, workflow_id)
    store.update_workflow(wf, status="deleted")
    emit_audit(
        store,
        actor,
        "workflow.delete",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"status": "deleted"},
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


@router.post("/{workflow_id}/versions", response_model=WorkflowVersionOut)
def create_version_route(
    workflow_id: str,
    payload: WorkflowVersionCreateRequest,
    store: AgentStore,
    actor: CurrentUser,
    request: Request,
) -> WorkflowVersionOut:
    """Create a workflow version, or replace its spec if this version already exists."""
    _require_workflow(store, workflow_id)
    ref_errors = validate_tool_refs_in_workflow_spec(payload.spec_json, store)
    if ref_errors:
        raise_logged_bad_request(
            logger,
            ValueError("; ".join(ref_errors)),
            public_detail="Invalid tool references in workflow spec: "
            + "; ".join(ref_errors),
            log_event="workflow_version_create_bad_tool_refs",
        )
    wv = store.create_workflow_version(
        workflow_id=workflow_id,
        version=payload.version,
        spec_json=payload.spec_json,
        created_by=actor["username"],
    )

    # Optimistic-concurrency check
    if (
        payload.expected_revision is not None
        and wv.revision != payload.expected_revision
    ):
        raise_logged_conflict(
            logger,
            ValueError(
                f"revision conflict expected={payload.expected_revision} "
                f"current={wv.revision}"
            ),
            public_detail=(
                f"Revision conflict: expected {payload.expected_revision},"
                f" current {wv.revision}"
            ),
            log_event="workflow_version_revision_conflict",
        )

    # Bump revision on every save
    wv.revision = (wv.revision or 0) + 1

    emit_audit(
        store,
        actor,
        "workflow.version.create",
        resource_type="workflow_version",
        resource_id=wv.id,
        details={"version": payload.version},
    )
    store.commit()
    store.refresh(wv)

    # Publish config-change event for real-time collaboration
    _publish_change(request, wv, actor["username"])

    return WorkflowVersionOut.model_validate(wv)


def _publish_change(
    request: Request,
    wv: object,
    actor_name: str,
) -> None:
    """Publish a workflow-saved ChangeEvent if the bus exists."""
    from pygubernator.events import ChangeBus, ChangeEvent

    bus: ChangeBus | None = getattr(request.app.state, "change_bus", None)
    if bus is None:
        return
    bus.publish(
        ChangeEvent(
            topic="workflow",
            action="saved",
            resource_id=getattr(wv, "workflow_id", ""),
            revision=getattr(wv, "revision", 0),
            actor=actor_name,
            metadata={
                "version_id": getattr(wv, "id", ""),
                "version": getattr(wv, "version", ""),
            },
        )
    )


@router.get("/{workflow_id}/versions")
def list_versions_route(workflow_id: str, store: AgentStore, _: CurrentUser) -> dict:
    """List all versions for a workflow."""
    versions = store.list_workflow_versions(workflow_id)
    return {
        "items": [WorkflowVersionOut.model_validate(v).model_dump() for v in versions],
    }


@router.post(
    "/{workflow_id}/versions/{version_id}/activate",
    response_model=WorkflowOut,
)
def activate_version_route(
    workflow_id: str,
    version_id: str,
    store: AgentStore,
    actor: CurrentUser,
) -> WorkflowOut:
    """Activate a specific workflow version."""
    wf = _require_workflow(store, workflow_id)
    versions = store.list_workflow_versions(workflow_id)
    if not any(v.id == version_id for v in versions):
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_id={workflow_id} version_id={version_id}"),
            public_detail="Version not found",
            log_event="workflow_version_not_found",
        )
    store.activate_workflow_version(wf, version_id)
    emit_audit(
        store,
        actor,
        "workflow.version.activate",
        resource_type="workflow",
        resource_id=workflow_id,
        details={"version_id": version_id},
    )
    store.commit()
    store.refresh(wf)
    return WorkflowOut.model_validate(wf)


def _run_workflow_background(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_id: str | None = None,
) -> None:
    """Execute a workflow in a background thread with its own DB session.

    Implements the full claiming + heartbeat lifecycle:
    pending → claimed → running → completed/failed/cancelled.
    """
    from pygubernator.db.session import get_db
    from pygubernator.workflow._claiming import (
        WorkerIdentity,
        claim_run,
        release_claim,
        update_heartbeat,
    )

    worker = WorkerIdentity.generate()
    db = cast(Session, next(get_db()))
    store = SQLAlchemyAgentStore(session=db)

    try:
        # Step 1: Claim the run (pending → claimed).
        if not claim_run(db, run_id, worker):
            logger.info("[BG] Run %s already claimed, skipping", run_id[:12])
            return

        # Step 2: Transition claimed → running (persist via store; expunge ORM
        # identity map so we never reuse a stale WorkflowRun after raw SQL claim).
        db.expunge_all()
        run = store.get_workflow_run(run_id)
        if not run:
            logger.error("[BG] Run %s vanished from DB", run_id[:12])
            return
        checked_status_update(
            run,
            RunStatus.RUNNING.value,
            store=store,
            started_at=datetime.now(UTC),
        )
        store.commit()

        # Step 3: Execute with heartbeat updates.
        def _heartbeat() -> None:
            update_heartbeat(db, run_id, worker)

        result = execute_workflow(
            spec_json,
            input_json,
            store,
            run_id,
            session_id=session_id,
            heartbeat_fn=_heartbeat,
        )

        # Step 4: Finalize status (expire + re-fetch: execute_workflow commits often and
        # may leave a cached WorkflowRun with a stale status attribute).
        db.expire_all()
        run = store.get_workflow_run(run_id)
        if not run:
            logger.error("[BG] Run %s vanished from DB", run_id[:12])
            return
        if run.status == RunStatus.CLAIMED.value:
            checked_status_update(
                run,
                RunStatus.RUNNING.value,
                store=store,
            )
            store.commit()
            db.expire_all()
            run = store.get_workflow_run(run_id)
            if not run:
                logger.error("[BG] Run %s vanished from DB", run_id[:12])
                return

        if result.get("awaiting_approval"):
            logger.info("[BG] Run %s paused for approval", run_id[:12])
        elif result.get("cancelled"):
            checked_status_update(
                run,
                RunStatus.CANCELLED.value,
                store=store,
                error_message="Cancelled by user",
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        elif result["success"]:
            checked_status_update(
                run,
                RunStatus.COMPLETED.value,
                store=store,
                output_json=result.get("output", {}),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        else:
            checked_status_update(
                run,
                RunStatus.FAILED.value,
                store=store,
                error_message="; ".join(result.get("errors", [])),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        store.commit()

        # LibraryTestJob auto-sync.
        try:
            job_id = (input_json or {}).get("job_id")
            if isinstance(job_id, str) and job_id:
                from pygubernator.api.services.library_testing.service import (
                    sync_job_from_workflow_run,
                )

                sync_job_from_workflow_run(
                    store.session,
                    workspace_id=workspace_id_of(store),
                    job_id=job_id,
                    workflow_run_id=run_id,
                    workflow_status=str(getattr(run, "status", "")),
                    actor="system",
                )
                store.commit()
        except Exception:
            logger.debug("LibraryTestJob sync failed", exc_info=True)
        logger.info(
            "[BG] Run %s finished: success=%s duration=%sms",
            run_id[:12],
            result.get("success"),
            result.get("duration_ms"),
        )
    except Exception as exc:
        logger.error("[BG] Run %s crashed: %s", run_id[:12], exc, exc_info=True)
        try:
            with contextlib.suppress(Exception):
                db.rollback()
            run = store.get_workflow_run(run_id)
            if run:
                checked_status_update(
                    run,
                    RunStatus.FAILED.value,
                    store=store,
                    force=True,
                    error_message=f"Internal error: {type(exc).__name__}: {exc}",
                    completed_at=datetime.now(UTC),
                )
                store.commit()
        except Exception:
            logger.error("[BG] Failed to update run %s status", run_id[:12])
    finally:
        with contextlib.suppress(Exception):
            db.rollback()
        try:
            release_claim(db, run_id, worker)
        except Exception:
            logger.error(
                "[BG] Failed to release claim for run %s",
                run_id[:12],
                exc_info=True,
            )
        db.close()


@router.post("/{workflow_id}/execute")
def execute_workflow_route(
    workflow_id: str,
    payload: WorkflowExecuteRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> dict:
    """Start workflow execution and return immediately with run ID.

    The workflow runs in a background thread. Poll GET /runs/{run_id}
    to track progress.
    """
    import threading

    logger.info(
        "[EXEC] Start execute workflow_id=%s actor=%s input_keys=%s",
        workflow_id,
        actor.get("username"),
        list(payload.input_json.keys()),
    )
    _require_workflow(store, workflow_id)

    versions = store.list_workflow_versions(workflow_id)
    if payload.version_id:
        version = next((v for v in versions if v.id == payload.version_id), None)
    else:
        version = next((v for v in versions if v.active), None)
        if not version and versions:
            version = versions[0]

    if not version:
        raise_logged_bad_request(
            logger,
            ValueError(f"no workflow version available for workflow_id={workflow_id}"),
            public_detail="No workflow version available",
            log_event="workflow_execute_no_version",
        )

    run = store.create_workflow_run(
        workflow_id=workflow_id,
        workflow_version_id=version.id,
        status=RunStatus.PENDING.value,
        input_json=payload.input_json,
        created_by=actor["username"],
        session_id=payload.session_id,
        trigger=payload.trigger,
        correlation_id=payload.correlation_id,
    )
    store.commit()
    store.refresh(run)

    run_data = WorkflowRunOut.model_validate(run).model_dump()
    logger.info("[EXEC] Created run %s, launching background execution", run.id[:12])

    # Launch execution in background thread with its own DB session
    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, payload.input_json, run.id, payload.session_id),
        daemon=True,
        name=f"wf-run-{run.id[:8]}",
    )
    thread.start()

    # Return immediately — UI polls GET /runs/{run_id} for status
    return {
        "run": run_data,
        "result": {
            "success": True,
            "output": {},
            "errors": [],
            "duration_ms": 0,
        },
    }


@router.post("/node-preview", response_model=WorkflowNodePreviewResponse)
async def preview_node_route(
    payload: WorkflowNodePreviewRequest,
    actor: CurrentUser,
) -> WorkflowNodePreviewResponse:
    """Execute a single node in isolation with user-supplied mock input.

    Stateless — no ``workflow_runs`` or step rows are created. Effectful,
    container, trigger, and approval node types are refused with a 409.
    """
    from pygubernator.api.services._workflows import build_node_registry

    registry = build_node_registry()
    try:
        outcome = await preview_node(
            node_type=payload.node_type,
            config=payload.config,
            input_data=payload.input_json,
            variables=payload.variables,
            session_id=payload.session_id,
            cheap_llm=payload.cheap_llm,
            timeout_s=payload.timeout_s,
            registry=registry,
            actor=actor.get("username"),
        )
    except NodeError as exc:
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="preview_unknown_node_type",
            fallback_detail="Unknown node type.",
            extra_safe_types=(NodeError,),
        )
    except PreviewRefusedError as exc:
        raise_logged_conflict_from_exception(
            logger,
            exc,
            log_event="preview_refused",
            fallback_detail="Node type is not previewable.",
        )

    return WorkflowNodePreviewResponse(
        status=outcome.status,
        node_type=payload.node_type,
        output_json=outcome.output,
        output_handle=outcome.output_handle,
        error=outcome.error,
        duration_ms=outcome.duration_ms,
        safety=classify_preview_safety(payload.node_type, payload.config).value,
        warnings=list(outcome.warnings),
    )


@router.get("/runs/list")
def list_runs_route(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    workflow_id: str | None = None,
    status: str | None = None,
    search: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    session_id: str | None = Query(
        default=None,
        description="Optional session filter so the Sessions sidebar "
        "can drill into one multi-turn conversation's runs.",
    ),
    trigger: str | None = Query(
        default=None,
        description=(
            "Optional trigger filter — e.g. `guide` to list only the "
            "runs dispatched from the Guide conversational orchestrator."
        ),
    ),
    correlation_id: str | None = Query(
        default=None,
        description=(
            "Optional correlation id filter. Guide chat threads set "
            "this to the chat session id so the thread UI can list "
            "just the runs it spawned."
        ),
    ),
) -> dict:
    """List workflow runs."""
    items, total = store.list_workflow_runs(
        page=page,
        page_size=page_size,
        workflow_id=workflow_id,
        status=status,
        search=search,
        created_after=created_after,
        created_before=created_before,
        session_id=session_id,
        trigger=trigger,
        correlation_id=correlation_id,
    )
    # Enrich with workflow names for display
    wf_ids = {r.workflow_id for r in items}
    wf_names: dict[str, str] = {}
    for wid in wf_ids:
        wf = store.get_workflow(wid)
        if wf:
            wf_names[wid] = wf.name

    enriched = []
    for r in items:
        data = WorkflowRunOut.model_validate(r).model_dump()
        data["workflow_name"] = wf_names.get(r.workflow_id, "")
        enriched.append(data)

    return paginated_response(enriched, total, page=page, page_size=page_size)


@router.get("/runs/sessions", response_model=WorkflowSessionsOut)
def list_all_sessions_route(
    store: AgentStore,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    workflow_id: str | None = Query(
        default=None,
        description="Optional filter to pin the list to one workflow.",
    ),
) -> WorkflowSessionsOut:
    """List workflow sessions across every workflow.

    Powers the "Sessions" sidebar on the Runs page. Unlike the scoped
    ``/{workflow_id}/sessions`` route, this one returns rows joined
    with each session's workflow name and the status of the latest run
    in the session, so the sidebar can render a summary card per
    session without round-trips. Paginated so very long histories
    don't freeze the UI.
    """
    items, total = store.list_all_workflow_sessions(
        page=page,
        page_size=page_size,
        workflow_id=workflow_id,
    )
    return WorkflowSessionsOut(
        items=[WorkflowSessionSummaryOut(**row) for row in items],
        meta=PageMeta(total=total, page=page, page_size=page_size),
    )


@router.get(
    "/runs/sessions/{session_id}/meta",
    response_model=WorkflowSessionDetailOut,
)
def get_session_meta_route(
    session_id: str,
    store: AgentStore,
    _: CurrentUser,
) -> WorkflowSessionDetailOut:
    """Read a session's user-supplied metadata (name, notes).

    Returns an empty payload (``name=None`` / ``notes=None``) when the
    user has not yet annotated the session — sessions exist as soon as
    a run carries a ``session_id``, but the metadata row is created
    lazily on first rename.
    """
    row = store.get_workflow_session(session_id)
    return WorkflowSessionDetailOut(
        session_id=session_id,
        name=row.name if row else None,
        notes=row.notes if row else None,
    )


@router.patch(
    "/runs/sessions/{session_id}/meta",
    response_model=WorkflowSessionDetailOut,
)
def update_session_meta_route(
    session_id: str,
    payload: WorkflowSessionUpdateRequest,
    store: AgentStore,
    _: CurrentUser,
) -> WorkflowSessionDetailOut:
    """Upsert user-supplied metadata for a workflow session.

    Drives the inline "Rename" affordance on the Sessions sidebar.
    Either field may be omitted to leave it untouched; passing an
    empty string clears the field.
    """
    row = store.upsert_workflow_session(
        session_id=session_id,
        name=payload.name,
        notes=payload.notes,
    )
    store.commit()
    store.refresh(row)
    return WorkflowSessionDetailOut(
        session_id=row.session_id,
        name=row.name,
        notes=row.notes,
    )


@router.get(
    "/runs/sessions/{session_id}/summaries",
    response_model=WorkflowSessionSummariesOut,
)
def list_session_summaries_route(
    session_id: str,
    store: AgentStore,
    _: CurrentUser,
    limit: int = Query(50, ge=1, le=500),
) -> WorkflowSessionSummariesOut:
    """List narrative summaries for a session, newest first.

    Backs the "Summaries" surface on the run-detail breadcrumb /
    Sessions sidebar (Phase 6 §6.10). Empty list when nothing has
    written a summary yet.
    """
    rows = store.list_workflow_session_summaries(session_id, limit=limit)
    return WorkflowSessionSummariesOut(
        items=[WorkflowSessionSummaryEntryOut.model_validate(r) for r in rows],
    )


@router.post(
    "/runs/sessions/{session_id}/summaries",
    response_model=WorkflowSessionSummaryEntryOut,
    status_code=201,
)
def create_session_summary_route(
    session_id: str,
    payload: WorkflowSessionSummaryCreateRequest,
    store: AgentStore,
    actor: CurrentUser,
) -> WorkflowSessionSummaryEntryOut:
    """Append a narrative summary to a session's history.

    Accepts content from any source — manual user notes, an
    on-schedule narrator agent (v1.1), or a workflow that ends with
    an ``agent`` node calling this route. ``generated_by`` defaults to
    the calling actor's username when omitted so summaries are
    auditable even when the caller forgets to set it.
    """
    try:
        row = store.create_workflow_session_summary(
            session_id=session_id,
            content=payload.content,
            generated_by=payload.generated_by or actor.get("username"),
            model=payload.model,
        )
    except ValueError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Summary content must not be empty",
            log_event="session_summary_empty",
        )
    store.commit()
    store.refresh(row)
    return WorkflowSessionSummaryEntryOut.model_validate(row)


@router.get("/{workflow_id}/sessions")
def list_sessions_route(
    workflow_id: str,
    store: AgentStore,
    _: CurrentUser,
) -> dict:
    """List distinct sessions for a workflow with latest run info."""
    _require_workflow(store, workflow_id)
    sessions = store.list_workflow_sessions(workflow_id)
    return {"items": sessions}


@router.delete("/{workflow_id}/sessions/{session_id}")
def delete_session_route(
    workflow_id: str,
    session_id: str,
    store: AgentStore,
    _: CurrentUser,
) -> dict:
    """Clear in-memory cache for a session."""
    from pygubernator.workflow.nodes._memory import clear_session_stores

    clear_session_stores(session_id)
    return {"detail": f"Session {session_id} cache cleared"}


@router.post("/runs/{run_id}/cancel")
def cancel_workflow_run_route(
    run_id: str,
    store: AgentStore,
    actor: CurrentUser,
) -> dict:
    """Request cancellation of a running workflow (cooperative, between DAG levels)."""
    run = _require_workflow_run(store, run_id)
    try:
        checked_status_update(run, RunStatus.CANCELLED.value, store=store)
    except IllegalTransitionError as exc:
        raise_logged_conflict(
            logger,
            exc,
            public_detail=f"Run cannot be cancelled (status={run.status})",
            log_event="workflow_run_cancel_illegal_transition",
        )
    emit_audit(
        store,
        actor,
        "workflow.run.cancel",
        resource_type="workflow_run",
        resource_id=run_id,
        details={},
    )
    store.commit()
    store.refresh(run)
    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "message": "Cancellation requested; run stops after the current DAG level.",
    }


@router.post("/runs/{run_id}/recover")
def recover_workflow_run_route(
    run_id: str,
    store: AgentStore,
    actor: CurrentUser,
) -> dict:
    """Recover a stale workflow run from its checkpoint.

    Only works for runs in 'stale' status that have a checkpoint.
    """
    import threading

    from pygubernator.workflow._claiming import WorkerIdentity

    run = _require_workflow_run(store, run_id)
    if run.status != RunStatus.STALE.value:
        raise_logged_conflict(
            logger,
            ValueError(f"run {run_id} cannot be recovered (status={run.status})"),
            public_detail=f"Run cannot be recovered (status={run.status})",
            log_event="workflow_run_recover_wrong_state",
        )

    emit_audit(
        store,
        actor,
        "workflow.run.recover",
        resource_type="workflow_run",
        resource_id=run_id,
        details={},
    )
    store.commit()

    def _recover_background() -> None:
        from pygubernator.api.services._workflows_recovery import (
            recover_stale_run,
        )
        from pygubernator.db.session import get_db

        worker = WorkerIdentity.generate()
        db = cast(Session, next(get_db()))
        bg_store = SQLAlchemyAgentStore(session=db)
        try:
            recover_stale_run(run_id, bg_store, worker)
        except Exception:
            logger.error(
                "[RECOVER] Run %s recovery failed",
                run_id[:12],
                exc_info=True,
            )
        finally:
            db.close()

    thread = threading.Thread(
        target=_recover_background,
        daemon=True,
        name=f"wf-recover-{run_id[:8]}",
    )
    thread.start()

    return {"message": "Recovery started", "run_id": run_id}


@router.delete("/runs/{run_id}", status_code=204)
def delete_workflow_run_route(
    run_id: str,
    store: AgentStore,
    actor: CurrentUser,
) -> None:
    """Permanently delete a workflow run and its step records."""
    run = _require_workflow_run(store, run_id)
    if run.status == "running":
        raise_logged_conflict(
            logger,
            ValueError(f"cannot delete running workflow run {run_id}"),
            public_detail=(
                "Run cannot be deleted while running; "
                "cancel it first or wait until it finishes."
            ),
            log_event="workflow_run_delete_while_running",
        )
    if not store.delete_workflow_run(run_id):
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_run_id={run_id}"),
            public_detail="Workflow run not found",
            log_event="workflow_run_delete_race_not_found",
        )
    emit_audit(
        store,
        actor,
        "workflow.run.delete",
        resource_type="workflow_run",
        resource_id=run_id,
        details={},
    )
    store.commit()


@router.get("/runs/{run_id}")
def get_run_detail_route(run_id: str, store: AgentStore, _: CurrentUser) -> dict:
    """Get workflow run detail with step timeline."""
    run = _require_workflow_run(store, run_id)
    steps = store.list_step_runs(run_id)
    return {
        "run": WorkflowRunOut.model_validate(run).model_dump(),
        "steps": [WorkflowStepRunOut.model_validate(s).model_dump() for s in steps],
    }


@router.get("/runs/{run_id}/trace")
def get_run_trace_route(run_id: str, store: AgentStore, _: CurrentUser) -> dict:
    """Get full step-by-step trace with timing for a workflow run."""
    run = _require_workflow_run(store, run_id)
    steps = store.list_step_runs(run_id)
    from pygubernator.workflow._recovery import classify_error

    trace = []
    for step in steps:
        entry: dict = {
            "node_id": step.node_id,
            "node_type": step.node_type,
            "status": step.status,
            "input": step.input_json,
            "output": step.output_json,
            "error": step.error_message,
            "output_handle": step.output_handle,
            "started_at": (step.started_at.isoformat() if step.started_at else None),
            "completed_at": (
                step.completed_at.isoformat() if step.completed_at else None
            ),
            "duration_ms": step.duration_ms,
        }
        if step.status == "failed" and step.error_message:
            classified = classify_error(step.node_id, step.error_message)
            entry["error_category"] = classified.category.value
            entry["error_retryable"] = classified.retryable
        trace.append(entry)
    return {
        "run_id": run_id,
        "workflow_id": run.workflow_id,
        "status": run.status,
        "trace": trace,
    }


@router.get(
    "/runs/{run_id}/steps/{step_id}/events",
    response_model=WorkflowStepEventsOut,
)
def get_step_events_route(
    run_id: str,
    step_id: str,
    store: AgentStore,
    _: CurrentUser,
) -> WorkflowStepEventsOut:
    """Return all tool-call / LLM events emitted inside one workflow step.

    Prefers the indexed ``workflow_step_events`` table (post-P2a runs).
    For legacy runs whose events still live inside
    ``output_json["_child_events"]`` the route reconstitutes the same
    shape so the UI doesn't have to special-case historical data.

    Returned ``source`` reflects where the events came from so UI tooling
    can surface the provenance (e.g. badge "from legacy blob").
    """
    _require_workflow_run(store, run_id)

    table_rows = store.list_workflow_step_events(step_id)
    if table_rows:
        return WorkflowStepEventsOut(
            items=[WorkflowStepEventOut.model_validate(r) for r in table_rows],
            source="table",
        )

    # Legacy fallback: steps that ran before ``workflow_step_events``
    # existed still have their child events inside the blob. Reconstruct
    # the table shape so the UI surface is uniform.
    steps = [s for s in store.list_step_runs(run_id) if s.id == step_id]
    if not steps:
        return WorkflowStepEventsOut(items=[], source="table")
    blob_events = (steps[0].output_json or {}).get("_child_events") or []
    if not blob_events:
        # No table rows *and* no blob — report as the preferred source so
        # the UI doesn't render a "from legacy blob" affordance on what is
        # really a not-yet-started step.
        return WorkflowStepEventsOut(items=[], source="table")
    items: list[WorkflowStepEventOut] = []
    for seq, raw in enumerate(blob_events):
        if not isinstance(raw, dict):
            continue
        items.append(
            WorkflowStepEventOut(
                id=None,
                step_run_id=step_id,
                workflow_run_id=run_id,
                event_type=str(raw.get("type", "")),
                sequence_num=seq,
                event_timestamp=float(raw.get("timestamp", 0.0) or 0.0),
                payload_json=raw.get("data")
                if isinstance(raw.get("data"), dict)
                else {},
                created_at=None,
            )
        )
    return WorkflowStepEventsOut(items=items, source="blob")


def _artifact_has_content(artifact: object) -> bool:
    """Return True when an artifact row exposes any content for the UI."""
    return bool(
        getattr(artifact, "content_text", None) is not None
        or getattr(artifact, "source_path", None)
    )


def _artifact_to_summary(artifact: object) -> WorkflowArtifactOut:
    """Build the list-route summary for an artifact row."""
    return WorkflowArtifactOut(
        id=artifact.id,  # type: ignore[attr-defined]
        workflow_run_id=artifact.workflow_run_id,  # type: ignore[attr-defined]
        step_run_id=artifact.step_run_id,  # type: ignore[attr-defined]
        artifact_type=artifact.artifact_type,  # type: ignore[attr-defined]
        title=artifact.title,  # type: ignore[attr-defined]
        mime=artifact.mime,  # type: ignore[attr-defined]
        source_path=artifact.source_path,  # type: ignore[attr-defined]
        size_bytes=artifact.size_bytes,  # type: ignore[attr-defined]
        sequence_num=artifact.sequence_num,  # type: ignore[attr-defined]
        has_content=_artifact_has_content(artifact),
        created_at=artifact.created_at,  # type: ignore[attr-defined]
        updated_at=artifact.updated_at,  # type: ignore[attr-defined]
    )


@router.get(
    "/runs/{run_id}/artifacts",
    response_model=WorkflowArtifactsOut,
)
def list_run_artifacts_route(
    run_id: str,
    store: AgentStore,
    _: CurrentUser,
    step_id: str | None = Query(
        default=None,
        description="Optional step run id to narrow the list to artifacts "
        "emitted by a single node execution.",
    ),
) -> WorkflowArtifactsOut:
    """List artifacts emitted during a workflow run.

    Content bodies are intentionally omitted from the list payload so a
    run with many large artifacts stays cheap to load; the UI fetches
    individual content via the sibling content route on demand. Results
    are ordered by ``sequence_num`` ascending to match emission order.
    """
    _require_workflow_run(store, run_id)
    rows = store.list_workflow_artifacts(workflow_run_id=run_id, step_run_id=step_id)
    return WorkflowArtifactsOut(
        items=[_artifact_to_summary(row) for row in rows],
        run_id=run_id,
        step_run_id=step_id,
    )


@router.get(
    "/runs/{run_id}/artifacts/{artifact_id}/content",
    response_model=WorkflowArtifactContentOut,
)
def get_run_artifact_content_route(
    run_id: str,
    artifact_id: str,
    store: AgentStore,
    _: CurrentUser,
) -> WorkflowArtifactContentOut:
    """Fetch the inline content for one artifact.

    Returns ``content_text`` verbatim when it is populated. If only
    ``source_path`` is set the route reads the file and returns its
    contents; binary files are base64-encoded and flagged via
    ``encoding="base64"`` so a UI renderer can decode back into a blob
    URL. Files are read with a conservative size cap to protect the API
    process; oversized artifacts should be fetched directly from their
    source (e.g. via a signed URL) rather than through this route.
    """
    _require_workflow_run(store, run_id)
    artifact = store.get_workflow_artifact(artifact_id)
    if artifact is None or artifact.workflow_run_id != run_id:
        raise_logged_not_found(
            logger,
            LookupError(f"artifact_id={artifact_id}"),
            public_detail="Artifact not found",
            log_event="workflow_artifact_not_found",
        )
    # Narrow the type for the checker — the helper above raises.
    assert artifact is not None
    if artifact.content_text is not None:
        return WorkflowArtifactContentOut(
            id=artifact.id,
            artifact_type=artifact.artifact_type,
            mime=artifact.mime,
            content=artifact.content_text,
            encoding="utf-8",
            size_bytes=artifact.size_bytes
            if artifact.size_bytes is not None
            else len(artifact.content_text.encode("utf-8")),
        )
    if artifact.source_path:
        return _read_artifact_source(artifact)
    raise_logged_not_found(
        logger,
        LookupError(f"artifact_id={artifact_id}"),
        public_detail="Artifact content is not available",
        log_event="workflow_artifact_content_missing",
    )


_ARTIFACT_MAX_BYTES = 8 * 1024 * 1024  # 8 MiB cap for inline content fetches
_ARTIFACT_TEXT_MIME_PREFIXES = (
    "text/",
    "application/json",
    "application/xml",
    "application/yaml",
    "application/x-yaml",
    "image/svg+xml",
)


def _is_textual_mime(mime: str | None) -> bool:
    """Return True when a MIME type is safe to decode as UTF-8 text."""
    if not mime:
        return False
    return any(mime.startswith(p) for p in _ARTIFACT_TEXT_MIME_PREFIXES)


def _read_artifact_source(artifact: object) -> WorkflowArtifactContentOut:
    """Read an artifact's ``source_path`` file and wrap it for the content route."""
    import base64
    from pathlib import Path

    source_path = Path(str(artifact.source_path))  # type: ignore[attr-defined]
    if not source_path.is_file():
        raise_logged_not_found(
            logger,
            LookupError(f"source_path={source_path}"),
            public_detail="Artifact source file is not available",
            log_event="workflow_artifact_source_missing",
        )
    try:
        size = source_path.stat().st_size
    except OSError as exc:
        raise_logged_not_found(
            logger,
            exc,
            public_detail="Artifact source file is not available",
            log_event="workflow_artifact_source_stat_failed",
        )
    if size > _ARTIFACT_MAX_BYTES:
        raise_logged_bad_request(
            logger,
            ValueError(f"artifact_size={size}"),
            public_detail="Artifact exceeds inline content size cap",
            log_event="workflow_artifact_oversized",
        )
    mime = getattr(artifact, "mime", None)
    raw = source_path.read_bytes()
    if _is_textual_mime(mime):
        return WorkflowArtifactContentOut(
            id=artifact.id,  # type: ignore[attr-defined]
            artifact_type=artifact.artifact_type,  # type: ignore[attr-defined]
            mime=mime,
            content=raw.decode("utf-8", errors="replace"),
            encoding="utf-8",
            size_bytes=size,
        )
    return WorkflowArtifactContentOut(
        id=artifact.id,  # type: ignore[attr-defined]
        artifact_type=artifact.artifact_type,  # type: ignore[attr-defined]
        mime=mime,
        content=base64.b64encode(raw).decode("ascii"),
        encoding="base64",
        size_bytes=size,
    )


@router.post(
    "/runs/{run_id}/artifacts/{artifact_id}/query",
    response_model=ArtifactQueryResponse,
)
def query_run_artifact_route(
    run_id: str,
    artifact_id: str,
    payload: ArtifactQueryRequest,
    store: AgentStore,
    _: CurrentUser,
) -> ArtifactQueryResponse:
    """Run a sandboxed read-only SQL query against a table artifact.

    Only ``table`` / ``csv`` artifacts are queryable — other types
    return 400. The sandbox loads the artifact's CSV into an
    isolated in-memory SQLite DB and attaches an authorizer that
    denies every non-SELECT action at statement-planning time, so
    DDL / DML / PRAGMA / ATTACH attempts fail before execution.
    See :mod:`api.services._artifact_query` for the full safety
    model and resource limits (row cap, timeout).
    """
    _require_workflow_run(store, run_id)
    artifact = store.get_workflow_artifact(artifact_id)
    if artifact is None or artifact.workflow_run_id != run_id:
        raise_logged_not_found(
            logger,
            LookupError(f"artifact_id={artifact_id}"),
            public_detail="Artifact not found",
            log_event="workflow_artifact_not_found",
        )
    assert artifact is not None
    try:
        result = run_artifact_query(
            artifact_type=artifact.artifact_type,
            content_text=artifact.content_text,
            sql=payload.sql,
        )
    except ArtifactQueryError as exc:
        raise_logged_bad_request_from_exception(
            logger,
            exc,
            log_event="artifact_query_rejected",
            fallback_detail="Artifact query was rejected",
        )
    return ArtifactQueryResponse(
        columns=list(result.columns),
        rows=[list(row) for row in result.rows],
        row_count=result.row_count,
        truncated=result.truncated,
        elapsed_ms=result.elapsed_ms,
    )


@router.get("/runs/{run_id}/checkpoint")
def get_run_checkpoint_route(run_id: str, store: AgentStore, _: CurrentUser) -> dict:
    """Inspect the checkpoint for a workflow run without resuming.

    Returns a summary of completed/pending nodes, the failed node
    (if any), variables at checkpoint time, and recovery options.
    """
    from pygubernator.workflow._recovery import inspect_checkpoint

    run = _require_workflow_run(store, run_id)
    checkpoint = run.checkpoint_json or {}
    if not checkpoint:
        return {"run_id": run_id, "has_checkpoint": False, "summary": None}
    summary = inspect_checkpoint(checkpoint)
    return {
        "run_id": run_id,
        "has_checkpoint": True,
        "summary": summary.to_dict(),
    }


@router.post("/runs/{run_id}/replay")
def replay_workflow_run_route(
    run_id: str, store: AgentStore, actor: CurrentUser
) -> dict:
    """Create a deterministic recorded replay of a workflow run.

    Phase 1: supports recorded replay for nodes that write RecordedOutput rows.
    """
    source = _require_workflow_run(store, run_id)
    if not source.workflow_version_id:
        raise_logged_bad_request(
            logger,
            ValueError(f"run {run_id} has no workflow_version_id"),
            public_detail="Run has no workflow_version_id",
            log_event="workflow_run_replay_no_version",
        )

    # Load recorded outputs from DB and inject into replay input.
    recorded_rows = repos.list_recorded_outputs(
        store.session,
        workspace_id=store.workspace_id,
        workflow_run_id=run_id,
    )
    recorded_map = {r.node_id: r.payload_json for r in recorded_rows}

    # Fail-fast: if the source run contains library_test nodes, it must have
    # recorded outputs for them.
    steps = store.list_step_runs(run_id)
    required_nodes = [s.node_id for s in steps if s.node_type == "library_test"]
    missing = [nid for nid in required_nodes if nid not in recorded_map]
    if missing:
        raise_logged_conflict(
            logger,
            ValueError(f"replay missing recorded outputs for nodes: {missing}"),
            public_detail=(
                "Recorded replay unavailable: missing recorded outputs for "
                f"node(s): {missing}. Re-run the workflow to record outputs first."
            ),
            log_event="workflow_run_replay_missing_recordings",
        )

    replay = store.create_workflow_run(
        workflow_id=source.workflow_id,
        workflow_version_id=source.workflow_version_id,
        status=RunStatus.PENDING.value,
        input_json={
            **(source.input_json or {}),
            "__replay_of__": run_id,
            "__replay_mode__": "recorded",
            "__recorded_outputs__": recorded_map,
        },
        created_by=str(actor.get("username", "system")),
        session_id=source.session_id,
    )
    store.create_audit(
        actor=str(actor["username"]),
        action="workflow.run.replay",
        resource_type="workflow_run",
        resource_id=replay.id,
        details={"source_run_id": run_id, "mode": "recorded"},
    )
    store.commit()
    store.refresh(replay)

    # Find spec_json for the version and run in background (reuse helper).
    versions = store.list_workflow_versions(source.workflow_id)
    version = next((v for v in versions if v.id == source.workflow_version_id), None)
    if version is None:
        raise_logged_not_found(
            logger,
            LookupError(
                f"workflow_version_id={source.workflow_version_id} "
                f"workflow_id={source.workflow_id}"
            ),
            public_detail="Workflow version not found",
            log_event="workflow_run_replay_version_not_found",
        )

    import threading

    thread = threading.Thread(
        target=_run_workflow_background,
        args=(version.spec_json, replay.input_json, replay.id, replay.session_id),
        daemon=True,
        name=f"wf-replay-{replay.id[:8]}",
    )
    thread.start()

    return {"ok": True, "new_run_id": replay.id}


@router.get("/runs/{run_id}/stream")
async def stream_run(
    run_id: str,
    token: str = Query(..., description="Bearer token for SSE auth"),
) -> StreamingResponse:
    """SSE stream of workflow execution events.

    Connect after POST /execute returns a run_id. Events are pushed
    in real-time as each node starts/completes. The stream ends with
    a ``done`` event.

    Auth is via query param because EventSource cannot send headers.
    """
    from pygubernator.api._sse import broadcaster
    from pygubernator.api.deps import verify_jwt

    payload = verify_jwt(token)
    if not payload:
        raise_logged_http_exception(
            logger,
            ValueError("invalid or expired SSE token"),
            status_code=401,
            public_detail="Invalid or expired token",
            log_event="workflow_run_stream_auth_failed",
        )

    async def event_generator():
        queue = broadcaster.subscribe(run_id)
        try:
            while True:
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=600)
                except TimeoutError:
                    yield f"data: {json.dumps({'type': 'timeout'})}\n\n"
                    break
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") == "done":
                    break
        finally:
            broadcaster.unsubscribe(run_id, queue)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/runs/{run_id}/approve")
def approve_workflow_run(
    run_id: str,
    payload: WorkflowApprovalDecisionRequest,
    actor: CurrentUser,
    store: AgentStore,
) -> dict:
    """Approve a pending workflow approval, resuming execution."""
    from pygubernator.api._http_errors import raise_logged_unprocessable
    from pygubernator.api.services._workflows import resume_workflow
    from pygubernator.db.models import WorkflowApproval

    run = _require_workflow_run(store, run_id)
    if run.status != RunStatus.AWAITING_APPROVAL.value:
        raise_logged_conflict(
            logger,
            ValueError(f"run {run_id} not awaiting approval (status={run.status})"),
            public_detail=f"Run is not awaiting approval (status={run.status})",
            log_event="workflow_run_approve_wrong_state",
        )

    sess = store.session
    approval = (
        sess.query(WorkflowApproval)
        .filter_by(workflow_run_id=run_id, status="pending")
        .first()
    )
    if not approval:
        raise_logged_not_found(
            logger,
            LookupError(f"no pending approval for run_id={run_id}"),
            public_detail="No pending approval for this run",
            log_event="workflow_run_approve_no_pending",
        )

    request_meta = _approval_request_metadata(approval)
    if payload.decision not in request_meta["allowed_decisions"]:
        raise_logged_unprocessable(
            logger,
            ValueError(
                f"decision '{payload.decision}' not in allowed "
                f"{request_meta['allowed_decisions']}"
            ),
            public_detail=(
                f"Decision '{payload.decision}' is not allowed for this approval. "
                f"Allowed decisions: {request_meta['allowed_decisions']}"
            ),
            log_event="workflow_run_approve_bad_decision",
        )
    if request_meta["require_comment"] and not str(payload.comment or "").strip():
        raise_logged_unprocessable(
            logger,
            ValueError("reviewer comment required"),
            public_detail="A reviewer comment is required for this approval",
            log_event="workflow_run_approve_missing_comment",
        )

    response_data = dict(payload.payload)
    response_data["decision"] = payload.decision
    if payload.comment is not None:
        response_data["comment"] = payload.comment

    result = resume_workflow(
        approval_id=approval.id,
        response_data=response_data,
        store=store,
        actor=str(actor.get("username", "anonymous")),
    )
    store.create_audit(
        actor=str(actor["username"]),
        action="workflow.run.approve",
        resource_type="workflow_run",
        resource_id=run_id,
        details={"decision": payload.decision},
    )
    store.commit()
    return {"run_id": run_id, "result": result}


@router.get("/runs/{run_id}/approvals")
def list_workflow_approvals(
    run_id: str,
    _actor: CurrentUser,
    store: AgentStore,
) -> dict:
    """List approval requests for a workflow run."""
    from pygubernator.db.models import WorkflowApproval

    _require_workflow_run(store, run_id)

    sess = store.session
    approvals = (
        sess.query(WorkflowApproval)
        .filter_by(workflow_run_id=run_id)
        .order_by(WorkflowApproval.created_at)
        .all()
    )
    items = [
        WorkflowApprovalOut(
            id=a.id,
            node_id=a.node_id,
            prompt=a.prompt,
            status=a.status,
            responded_by=a.responded_by,
            timeout_seconds=a.timeout_seconds,
            created_at=(a.created_at.isoformat() if a.created_at else None),
            responded_at=(a.responded_at.isoformat() if a.responded_at else None),
            **_approval_request_metadata(a),
        ).model_dump()
        for a in approvals
    ]
    return {"items": items}


def _approval_request_metadata(approval: object) -> dict[str, object]:
    checkpoint_json = getattr(approval, "checkpoint_json", {}) or {}
    raw = checkpoint_json.get("__approval_request__", {})
    if not isinstance(raw, dict):
        raw = {}
    allowed = raw.get("allowed_decisions", ["approved", "rejected"])
    if not isinstance(allowed, list) or not allowed:
        allowed = ["approved", "rejected"]
    return {
        "allowed_decisions": [str(item) for item in allowed],
        "require_comment": bool(raw.get("require_comment", False)),
        "reviewer_label": str(raw.get("reviewer_label", "") or ""),
        "details_markdown": str(raw.get("details_markdown", "") or ""),
    }


@router.get("/{workflow_id}/export")
def export_workflow_route(
    workflow_id: str,
    _actor: CurrentUser,
    store: AgentStore,
) -> dict:
    """Export a workflow's active version as a JSON spec."""
    wf = _require_workflow(store, workflow_id)
    versions = store.list_workflow_versions(workflow_id)
    active = next((v for v in versions if v.active), None)
    if not active and versions:
        active = versions[0]
    if not active:
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_id={workflow_id} has no versions"),
            public_detail="No version available to export",
            log_event="workflow_export_no_version",
        )
    return {
        "workflow": {
            "name": wf.name,
            "description": wf.description,
            "owner": wf.owner,
            "spec": active.spec_json,
            "version": active.version,
        },
    }


@router.post("/import")
def import_workflow_route(
    payload: dict,
    actor: CurrentUser,
    store: AgentStore,
) -> dict:
    """Import a workflow from a JSON spec.

    Expects ``{"name": ..., "spec": {...}, ...}`` in the body.
    Creates the workflow and an initial version.
    """
    name = payload.get("name", "imported-workflow")
    description = payload.get("description", "")
    owner = payload.get("owner", str(actor.get("username", "")))
    spec_json = payload.get("spec", {})
    version_label = payload.get("version", "1.0.0")

    wf = store.create_workflow(
        name=name,
        description=description,
        owner=owner,
    )
    store.commit()
    store.refresh(wf)

    store.create_workflow_version(
        workflow_id=wf.id,
        version=version_label,
        spec_json=spec_json,
        active=True,
        created_by=str(actor.get("username", "system")),
    )
    store.create_audit(
        actor=str(actor["username"]),
        action="workflow.import",
        resource_type="workflow",
        resource_id=wf.id,
        details={"name": name},
    )
    store.commit()
    store.refresh(wf)
    return {
        "workflow": WorkflowOut.model_validate(wf).model_dump(),
    }
