"""FastAPI app for pygubernator control plane."""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pygubernator.api._http_errors import internal_error_response_body
from pygubernator.api._rate_limit import RateLimitMiddleware
from pygubernator.api.deps import AdminUser, get_current_user
from pygubernator.api.routes_agents import router as agents_router
from pygubernator.api.routes_auth import router as auth_router
from pygubernator.api.routes_chat import router as chat_router
from pygubernator.api.routes_credentials import router as credentials_router
from pygubernator.api.routes_events import router as events_router
from pygubernator.api.routes_guide import router as guide_router
from pygubernator.api.routes_kb import router as kb_router
from pygubernator.api.routes_layouts import router as layouts_router
from pygubernator.api.routes_library_testing import (
    router as library_testing_router,
)
from pygubernator.api.routes_llm import router as llm_router
from pygubernator.api.routes_local_ollama import router as local_ollama_router
from pygubernator.api.routes_memory import router as memory_router
from pygubernator.api.routes_notifications import (
    router as notifications_router,
)
from pygubernator.api.routes_observability import router as observability_router
from pygubernator.api.routes_policies import router as policies_router
from pygubernator.api.routes_run_diff import router as replay_router
from pygubernator.api.routes_runs import router as runs_router
from pygubernator.api.routes_scheduler import router as scheduler_router
from pygubernator.api.routes_settings import public_router as settings_public_router
from pygubernator.api.routes_settings import router as settings_router
from pygubernator.api.routes_templates import router as templates_router
from pygubernator.api.routes_tools import router as tools_router
from pygubernator.api.routes_webhooks import (
    admin_router as webhooks_admin_router,
)
from pygubernator.api.routes_webhooks import (
    trigger_router as webhooks_trigger_router,
)
from pygubernator.api.routes_workflows import router as workflows_router
from pygubernator.config import ControlPlaneSettings, get_ui_app_name, get_ui_theme
from pygubernator.connectors import discover_sink_plugins, discover_source_plugins
from pygubernator.db.config import get_db_url
from pygubernator.db.retention import purge_old_events
from pygubernator.db.session import get_db, init_db
from pygubernator.workflow.templates import (
    discover_plugins as discover_template_plugins,
)

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    settings = ControlPlaneSettings.from_env()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        from pygubernator.events import ChangeBus

        app.state.change_bus = ChangeBus()
        _startup_discover_plugins()
        _startup_init_sqlite()
        _startup_scheduler(app)
        _startup_stale_run_sweeper()
        try:
            yield
        finally:
            scheduler = getattr(app.state, "scheduler", None)
            if scheduler is not None:
                try:
                    scheduler.stop()
                except Exception:
                    logger.warning("Scheduler stop failed", exc_info=True)

    app = FastAPI(
        title="PyGubernator Control Plane API",
        version="0.1.0",
        lifespan=lifespan,
    )
    cors_origins = [o.strip() for o in settings.allow_origins.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(
        RateLimitMiddleware,
        max_requests=200,
        window_seconds=60.0,
    )
    app.include_router(auth_router)
    protected_dependencies = [Depends(get_current_user)]
    app.include_router(agents_router, dependencies=protected_dependencies)
    app.include_router(runs_router, dependencies=protected_dependencies)
    app.include_router(replay_router, dependencies=protected_dependencies)
    app.include_router(observability_router, dependencies=protected_dependencies)
    app.include_router(policies_router, dependencies=protected_dependencies)
    app.include_router(workflows_router, dependencies=protected_dependencies)
    app.include_router(memory_router, dependencies=protected_dependencies)
    app.include_router(guide_router, dependencies=protected_dependencies)
    app.include_router(llm_router, dependencies=protected_dependencies)
    app.include_router(library_testing_router, dependencies=protected_dependencies)
    app.include_router(credentials_router, dependencies=protected_dependencies)
    app.include_router(chat_router, dependencies=protected_dependencies)
    app.include_router(notifications_router, dependencies=protected_dependencies)
    app.include_router(webhooks_admin_router, dependencies=protected_dependencies)
    app.include_router(scheduler_router, dependencies=protected_dependencies)
    app.include_router(templates_router, dependencies=protected_dependencies)
    app.include_router(tools_router, dependencies=protected_dependencies)
    app.include_router(kb_router, dependencies=protected_dependencies)
    app.include_router(settings_public_router)
    app.include_router(settings_router, dependencies=protected_dependencies)
    app.include_router(local_ollama_router, dependencies=protected_dependencies)
    app.include_router(webhooks_trigger_router)  # No auth — token in URL
    app.include_router(layouts_router)  # No auth — lightweight CRUD
    app.include_router(events_router)  # No auth — SSE via EventSource

    # --- Exception handlers (matching pystator pattern) ---

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        errors = []
        for err in exc.errors():
            loc = " -> ".join(str(item) for item in err.get("loc", []))
            errors.append({"field": loc, "message": err.get("msg", "")})
        return JSONResponse(
            status_code=422,
            content={"error": "Validation error", "details": errors},
        )

    @app.exception_handler(Exception)
    async def global_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        logger.error(
            "[GLOBAL] Unhandled %s on %s %s: %s",
            type(exc).__name__,
            request.method,
            request.url.path,
            exc,
            exc_info=True,
        )
        return JSONResponse(
            status_code=500,
            content=internal_error_response_body(exc),
        )

    # Optional: mount collaboration relay if installed
    try:
        from pygubernator.collab import create_collab_app

        collab_app = create_collab_app()
        app.mount("/collab", collab_app)
        logger.info("Collaboration module mounted at /collab")
    except ImportError:
        logger.debug(
            "Collaboration module not installed (pip install pygubernator[collab])"
        )

    def _startup_init_sqlite() -> None:
        # Auto-init SQLite only if the file doesn't exist yet.
        db_url = get_db_url(required=False)
        if db_url and db_url.startswith("sqlite:///"):
            from pathlib import Path

            db_path = db_url[10:]
            if db_path != ":memory:" and not Path(db_path).exists():
                init_db(db_url)

    def _startup_discover_plugins() -> None:
        """Discover extension plugins with per-group failure isolation."""

        _run_discovery_step("source", discover_source_plugins)
        _run_discovery_step("sink", discover_sink_plugins)
        _run_discovery_step("template", discover_template_plugins)

    def _run_discovery_step(step_name: str, discover_fn: Callable[[], int]) -> None:
        try:
            count = int(discover_fn())
            if count:
                logger.info(
                    "startup plugin discovery registered %d %s plugin(s)",
                    count,
                    step_name,
                )
        except Exception:
            logger.warning(
                "startup plugin discovery failed for %s plugins",
                step_name,
                exc_info=True,
            )

    def _startup_scheduler(app: FastAPI) -> None:
        try:
            from pygubernator.db.session import SessionLocal
            from pygubernator.scheduler._engine import Scheduler

            scheduler = Scheduler(db_session_factory=SessionLocal)
            scheduler.start()
            app.state.scheduler = scheduler
        except Exception:
            logger.warning("Scheduler start failed", exc_info=True)

    def _startup_stale_run_sweeper() -> None:
        """Detect and mark stuck workflow runs as stale or failed."""
        import threading

        def _sweep_loop() -> None:
            import time as _time

            while True:
                _time.sleep(60)
                try:
                    _sweep_stale_runs()
                except Exception:
                    logger.debug("Stale run sweeper error", exc_info=True)

        def _sweep_stale_runs() -> None:
            from pygubernator.workflow._claiming import find_stale_runs
            from pygubernator.workflow._fsm import RunStatus

            threshold = float(os.getenv("PYGUBERNATOR_STALE_THRESHOLD", "60"))
            db = next(get_db())
            try:
                stale_ids = find_stale_runs(db, threshold)
                # FSM transitions running→stale, claimed→stale
                # validated by SQL WHERE clause (status IN running, claimed).
                for rid in stale_ids:
                    db.execute(
                        __import__("sqlalchemy").text(
                            "UPDATE workflow_runs "
                            "SET status = :stale "
                            "WHERE id = :run_id "
                            "AND status IN (:running, :claimed)"
                        ),
                        {
                            "run_id": rid,
                            "stale": RunStatus.STALE.value,
                            "running": RunStatus.RUNNING.value,
                            "claimed": RunStatus.CLAIMED.value,
                        },
                    )
                db.commit()
                if stale_ids:
                    logger.info("Marked %d stale workflow run(s)", len(stale_ids))
            finally:
                db.close()

        thread = threading.Thread(
            target=_sweep_loop,
            daemon=True,
            name="stale-run-sweeper",
        )
        thread.start()

    @app.post("/api/v1/admin/retention")
    def run_retention(_admin: AdminUser) -> dict:
        db = next(get_db())
        try:
            result = purge_old_events(db, settings.event_retention_days)
        finally:
            db.close()
        return {"ok": True, **result}

    @app.get("/healthz")
    def healthz() -> dict:
        return {"status": "ok"}

    @app.get("/health")
    def health() -> dict:
        """Alias for ``/healthz`` (matches pycharter / pystator clients)."""
        return {"status": "ok"}

    @app.get("/api/v1/ui/config")
    def ui_config() -> dict:
        # Theme/name from cfg/env each request (not the import-time settings snapshot).
        return {
            "theme": get_ui_theme(),
            "app_name": get_ui_app_name(),
        }

    return app


app = create_app()


def _package_root() -> Path:
    """Return the pygubernator package directory (installed or editable)."""
    try:
        import pygubernator as _pkg

        return Path(_pkg.__file__).resolve().parent
    except ImportError:
        return Path(__file__).resolve().parent.parent


def _reload_dirs_excluding_ui() -> list[str]:
    """Dirs for uvicorn reload (exclude ui/ to avoid node_modules inotify limits)."""
    pkg_root = _package_root()
    return [
        str(d)
        for d in sorted(pkg_root.iterdir())
        if d.is_dir()
        and d.name != "ui"
        and not d.name.startswith("__")
        and not d.name.startswith(".")
    ]


def run_api(
    *,
    host: str | None = None,
    port: int | None = None,
    reload: bool = False,
) -> None:
    """Run the control-plane API with uvicorn (CLI / ``python -m`` entry)."""
    settings = ControlPlaneSettings.from_env()
    h = host if host is not None else settings.api_host
    p = port if port is not None else settings.api_port

    run_kw: dict[str, object] = {
        "host": h,
        "port": p,
        "reload": reload,
        "log_level": "info",
    }
    if reload:
        run_kw["reload_dirs"] = _reload_dirs_excluding_ui()

    uvicorn.run("pygubernator.api.main:app", **run_kw)


def serve_api() -> None:
    """Default production-style serve (config from env / .cfg only, no reload)."""
    settings = ControlPlaneSettings.from_env()
    run_api(host=settings.api_host, port=settings.api_port, reload=False)


if __name__ == "__main__":
    serve_api()
