"""Shared route helpers for FastAPI handlers (Phase R §R.5).

Three thin helpers that collapse boilerplate appearing across most of
``api/routes_*.py``:

- :func:`paginated_response` — builds the standard
  ``{"items": [...], "meta": {...}}`` envelope with a ``PageMeta``
  block. Optional ``model`` kwarg runs each row through a Pydantic
  ``model_validate(...).model_dump()`` so callers can stop spelling
  out the comprehension.
- :func:`emit_audit` — wraps the ``store.create_audit(actor=actor["username"], …)``
  pattern. Most routes copy the same six-line block per mutation;
  this turns it into one self-documenting call.
- :func:`workspace_id_of` — single source of truth for the
  ``getattr(store, "workspace_id", "default")`` fallback that
  routes_workflows uses; keeps the magic string in one place so a
  future "workspaces are no longer optional" change has a single
  call site to update.

The helpers are intentionally **thin**. The point is to make every
route's intent obvious at a glance, not to introduce a new
abstraction layer with policy of its own.
"""

from __future__ import annotations

from typing import Any, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel

from pygubernator.api.models import PageMeta

T = TypeVar("T")
ModelT = TypeVar("ModelT", bound=BaseModel)


@runtime_checkable
class _AuditCapableStore(Protocol):
    """Protocol for stores that implement the ``create_audit`` mutation.

    Carved out so the helper is testable against any implementation
    (real ``SQLAlchemyAgentStore`` or a test double) without importing
    the concrete store class.
    """

    def create_audit(
        self,
        *,
        actor: str,
        action: str,
        resource_type: str,
        resource_id: str,
        details: dict[str, Any] | None = None,
    ) -> Any: ...


def paginated_response(
    items: list[T],
    total: int,
    *,
    page: int,
    page_size: int,
    model: type[BaseModel] | None = None,
) -> dict[str, Any]:
    """Build the canonical paginated route envelope.

    Args:
        items: One page of rows from the underlying store.
        total: Total row count across all pages.
        page: 1-based page index this response covers.
        page_size: Page size used to compute ``total / page_size``.
        model: Optional Pydantic model to ``model_validate`` each row
            through before serialising. When omitted the rows are
            forwarded as-is (callers that already pre-serialised
            their items pass ``None``).

    Returns:
        A ``{"items": [...], "meta": {total, page, page_size}}`` dict
        ready for return from a FastAPI handler.
    """
    if model is not None:
        serialised: list[Any] = [
            model.model_validate(item).model_dump() for item in items
        ]
    else:
        serialised = list(items)
    return {
        "items": serialised,
        "meta": PageMeta(total=total, page=page, page_size=page_size).model_dump(),
    }


def emit_audit(
    store: _AuditCapableStore,
    actor: dict[str, Any],
    action: str,
    *,
    resource_type: str,
    resource_id: str,
    details: dict[str, Any] | None = None,
) -> None:
    """Emit an audit row using the actor dict's ``"username"`` key.

    Wraps the boilerplate every mutation route was repeating::

        store.create_audit(
            actor=actor["username"],
            action="...",
            resource_type="...",
            resource_id=...,
            details=...,
        )

    Args:
        store: Any store that implements :class:`_AuditCapableStore`.
        actor: The :func:`get_current_user` dict; ``actor["username"]``
            is the audit principal.
        action: Domain-specific event name (e.g. ``"agent.create"``).
        resource_type: Logical resource type (``"agent"``, ``"workflow"``).
        resource_id: Stable id of the row being mutated.
        details: Optional structured payload to attach to the row.
            Typically the inbound ``payload.model_dump()`` so the
            audit trail captures the request body verbatim.
    """
    store.create_audit(
        actor=actor["username"],
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details,
    )


def workspace_id_of(store: object, *, default: str = "default") -> str:
    """Return ``store.workspace_id`` or a documented default fallback.

    Mirrors the ``getattr(store, "workspace_id", "default")`` pattern
    that some routes use when they need a workspace id even from a
    pre-multitenant store. Centralising the fallback string keeps a
    future "workspaces are mandatory" change to one site.
    """
    value = getattr(store, "workspace_id", default)
    if isinstance(value, str) and value:
        return value
    return default


__all__ = [
    "emit_audit",
    "paginated_response",
    "workspace_id_of",
]
