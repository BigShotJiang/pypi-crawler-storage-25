"""Observability routes: events, metrics, traces, incidents."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_conflict,
    raise_logged_not_found,
)
from pygubernator.api._routes_common import emit_audit
from pygubernator.api.deps import AdminUser, AgentStore, CurrentUser
from pygubernator.api.models import (
    IncidentAssignRequest,
    IncidentCreateRequest,
    IncidentSilenceRequest,
    RunEventIngestRequest,
)
from pygubernator.db.models import Incident, Run, RunEvent, ToolCall

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/observability", tags=["observability"])


def _window_params(window: str) -> tuple[timedelta, timedelta]:
    mapping = {
        "15m": (timedelta(minutes=15), timedelta(minutes=1)),
        "1h": (timedelta(hours=1), timedelta(minutes=5)),
        "24h": (timedelta(hours=24), timedelta(hours=1)),
        "7d": (timedelta(days=7), timedelta(hours=6)),
    }
    if window not in mapping:
        raise_logged_bad_request(
            logger,
            ValueError(f"unsupported metrics window: {window}"),
            public_detail="Unsupported metrics window",
            log_event="obs_metrics_bad_window",
        )
    return mapping[window]


def _bucket_start(ts: datetime, step: timedelta) -> datetime:
    seconds = int(step.total_seconds())
    epoch = int(ts.timestamp())
    return datetime.fromtimestamp(epoch - (epoch % seconds), tz=UTC)


def _serialize_incident(rec: Incident) -> dict:
    return {
        "id": rec.id,
        "run_id": rec.run_id,
        "alert_id": rec.alert_id,
        "title": rec.title,
        "severity": rec.severity,
        "status": rec.status,
        "owner": rec.owner,
        "acknowledged_at": rec.acknowledged_at,
        "silenced_until": rec.silenced_until,
        "resolved_at": rec.resolved_at,
        "details": rec.details,
        "created_at": rec.created_at,
        "updated_at": rec.updated_at,
    }


@router.post("/events")
def ingest_event(
    payload: RunEventIngestRequest, store: AgentStore, _: CurrentUser
) -> dict:
    run = store.session.get(Run, payload.run_id)
    if not run:
        raise_logged_not_found(
            logger,
            LookupError(f"run_id={payload.run_id}"),
            public_detail="Run not found",
            log_event="obs_run_not_found",
        )
    evt = RunEvent(
        run_id=payload.run_id,
        event_type=payload.event_type,
        level=payload.level,
        message=payload.message,
        payload=payload.payload,
    )
    store.add(evt)
    store.commit()
    store.refresh(evt)
    return {"id": evt.id}


@router.get("/events")
def list_events(
    store: AgentStore, _: CurrentUser, run_id: str | None = None, limit: int = 200
) -> dict:
    q = select(RunEvent).order_by(RunEvent.created_at.desc()).limit(limit)
    if run_id:
        q = q.where(RunEvent.run_id == run_id)
    rows = store.session.scalars(q).all()
    return {
        "items": [
            {
                "id": r.id,
                "run_id": r.run_id,
                "event_type": r.event_type,
                "level": r.level,
                "message": r.message,
                "payload": r.payload,
                "created_at": r.created_at,
            }
            for r in rows
        ]
    }


@router.get("/metrics")
def get_metrics(
    store: AgentStore,
    _: CurrentUser,
    window: str = Query("24h", pattern="^(15m|1h|24h|7d)$"),
) -> dict:
    lookback, bucket_size = _window_params(window)
    now = datetime.now(UTC)
    window_start = now - lookback

    sess = store.session
    total_runs = int(sess.scalar(select(func.count(Run.id))) or 0)
    succeeded = int(
        sess.scalar(select(func.count(Run.id)).where(Run.status == "succeeded")) or 0
    )
    failed = int(
        sess.scalar(select(func.count(Run.id)).where(Run.status == "failed")) or 0
    )
    avg_latency = sess.scalar(
        select(func.avg(Run.duration_ms)).where(Run.duration_ms.is_not(None))
    )
    total_input = int(
        sess.scalar(select(func.coalesce(func.sum(Run.token_input), 0))) or 0
    )
    total_output = int(
        sess.scalar(select(func.coalesce(func.sum(Run.token_output), 0))) or 0
    )
    total_cost = int(
        sess.scalar(select(func.coalesce(func.sum(Run.cost_usd_micros), 0))) or 0
    )

    rows = sess.scalars(
        select(Run).where(Run.created_at >= window_start).order_by(Run.created_at.asc())
    ).all()
    buckets: dict[datetime, dict[str, int]] = {}
    current = _bucket_start(window_start, bucket_size)
    while current <= now:
        buckets[current] = {
            "runs": 0,
            "failed": 0,
            "succeeded": 0,
            "latency_sum_ms": 0,
            "latency_count": 0,
            "cost_usd_micros": 0,
        }
        current += bucket_size

    for run in rows:
        slot = _bucket_start(run.created_at, bucket_size)
        if slot not in buckets:
            continue
        bucket = buckets[slot]
        bucket["runs"] += 1
        if run.status == "failed":
            bucket["failed"] += 1
        if run.status == "succeeded":
            bucket["succeeded"] += 1
        if run.duration_ms is not None:
            bucket["latency_sum_ms"] += run.duration_ms
            bucket["latency_count"] += 1
        bucket["cost_usd_micros"] += run.cost_usd_micros

    return {
        "totals": {
            "runs": total_runs,
            "succeeded": succeeded,
            "failed": failed,
            "avg_latency_ms": int(avg_latency or 0),
            "token_input": total_input,
            "token_output": total_output,
            "cost_usd_micros": total_cost,
        },
        "window": {
            "label": window,
            "from": window_start,
            "to": now,
        },
        "series": [
            {
                "ts": ts,
                "runs": metrics["runs"],
                "failed": metrics["failed"],
                "succeeded": metrics["succeeded"],
                "avg_latency_ms": (
                    int(metrics["latency_sum_ms"] / metrics["latency_count"])
                    if metrics["latency_count"] > 0
                    else 0
                ),
                "cost_usd_micros": metrics["cost_usd_micros"],
            }
            for ts, metrics in sorted(buckets.items())
        ],
    }


@router.get("/traces/{run_id}")
def get_trace(run_id: str, store: AgentStore, _: CurrentUser) -> dict:
    run = store.session.get(Run, run_id)
    if not run:
        raise_logged_not_found(
            logger,
            LookupError(f"run_id={run_id}"),
            public_detail="Run not found",
            log_event="obs_run_not_found",
        )
    tool_calls = store.session.scalars(
        select(ToolCall)
        .where(ToolCall.run_id == run_id)
        .order_by(ToolCall.created_at.asc())
    ).all()
    events = store.session.scalars(
        select(RunEvent)
        .where(RunEvent.run_id == run_id)
        .order_by(RunEvent.created_at.asc())
    ).all()
    return {
        "run": {
            "id": run.id,
            "status": run.status,
            "correlation_id": run.correlation_id,
            "started_at": run.started_at,
            "ended_at": run.ended_at,
            "duration_ms": run.duration_ms,
        },
        "tool_calls": [
            {
                "id": t.id,
                "tool_name": t.tool_name,
                "status": t.status,
                "latency_ms": t.latency_ms,
                "error_message": t.error_message,
                "created_at": t.created_at,
            }
            for t in tool_calls
        ],
        "events": [
            {
                "id": e.id,
                "event_type": e.event_type,
                "level": e.level,
                "message": e.message,
                "payload": e.payload,
                "created_at": e.created_at,
            }
            for e in events
        ],
    }


@router.get("/incidents")
def get_incidents(
    store: AgentStore,
    _: CurrentUser,
    status: str | None = None,
    severity: str | None = None,
    owner: str | None = None,
    limit: int = Query(100, ge=1, le=500),
) -> dict:
    rows = store.list_incidents(
        status=status, severity=severity, owner=owner, limit=limit
    )
    return {"items": [_serialize_incident(row) for row in rows]}


@router.get("/incidents/{incident_id}")
def get_incident_detail(incident_id: str, store: AgentStore, _: CurrentUser) -> dict:
    row = store.get_incident(incident_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"incident_id={incident_id}"),
            public_detail="Incident not found",
            log_event="obs_incident_not_found",
        )
    return _serialize_incident(row)


@router.post("/incidents")
def create_incident(
    payload: IncidentCreateRequest, store: AgentStore, actor: AdminUser
) -> dict:
    if payload.run_id and not store.session.get(Run, payload.run_id):
        raise_logged_not_found(
            logger,
            LookupError(f"run_id={payload.run_id}"),
            public_detail="Run not found",
            log_event="obs_run_not_found",
        )
    incident = Incident(
        run_id=payload.run_id,
        alert_id=payload.alert_id,
        title=payload.title,
        severity=payload.severity,
        owner=payload.owner,
        details=payload.details,
    )
    store.add(incident)
    emit_audit(
        store,
        actor,
        "incident.create",
        resource_type="incident",
        resource_id=incident.id,
        details=payload.model_dump(mode="json"),
    )
    store.commit()
    store.refresh(incident)
    return _serialize_incident(incident)


@router.post("/incidents/{incident_id}/ack")
def ack_incident(incident_id: str, store: AgentStore, actor: AdminUser) -> dict:
    incident = store.get_incident(incident_id)
    if not incident:
        raise_logged_not_found(
            logger,
            LookupError(f"incident_id={incident_id}"),
            public_detail="Incident not found",
            log_event="obs_incident_not_found",
        )
    if incident.status == "resolved":
        raise_logged_conflict(
            logger,
            ValueError(f"incident {incident_id} is resolved; cannot acknowledge"),
            public_detail="Resolved incident cannot be acknowledged",
            log_event="obs_incident_ack_resolved",
        )
    incident.status = "acknowledged"
    incident.acknowledged_at = datetime.now(UTC)
    emit_audit(
        store,
        actor,
        "incident.ack",
        resource_type="incident",
        resource_id=incident_id,
        details={},
    )
    store.commit()
    store.refresh(incident)
    return _serialize_incident(incident)


@router.post("/incidents/{incident_id}/silence")
def silence_incident(
    incident_id: str,
    payload: IncidentSilenceRequest,
    store: AgentStore,
    actor: AdminUser,
) -> dict:
    incident = store.get_incident(incident_id)
    if not incident:
        raise_logged_not_found(
            logger,
            LookupError(f"incident_id={incident_id}"),
            public_detail="Incident not found",
            log_event="obs_incident_not_found",
        )
    if incident.status == "resolved":
        raise_logged_conflict(
            logger,
            ValueError(f"incident {incident_id} is resolved; cannot silence"),
            public_detail="Resolved incident cannot be silenced",
            log_event="obs_incident_silence_resolved",
        )
    incident.status = "silenced"
    incident.silenced_until = payload.until
    emit_audit(
        store,
        actor,
        "incident.silence",
        resource_type="incident",
        resource_id=incident_id,
        details=payload.model_dump(mode="json"),
    )
    store.commit()
    store.refresh(incident)
    return _serialize_incident(incident)


@router.post("/incidents/{incident_id}/resolve")
def resolve_incident(incident_id: str, store: AgentStore, actor: AdminUser) -> dict:
    incident = store.get_incident(incident_id)
    if not incident:
        raise_logged_not_found(
            logger,
            LookupError(f"incident_id={incident_id}"),
            public_detail="Incident not found",
            log_event="obs_incident_not_found",
        )
    if incident.status == "resolved":
        raise_logged_conflict(
            logger,
            ValueError(f"incident {incident_id} already resolved"),
            public_detail="Incident already resolved",
            log_event="obs_incident_already_resolved",
        )
    incident.status = "resolved"
    incident.resolved_at = datetime.now(UTC)
    emit_audit(
        store,
        actor,
        "incident.resolve",
        resource_type="incident",
        resource_id=incident_id,
        details={},
    )
    store.commit()
    store.refresh(incident)
    return _serialize_incident(incident)


@router.post("/incidents/{incident_id}/assign")
def assign_incident(
    incident_id: str,
    payload: IncidentAssignRequest,
    store: AgentStore,
    actor: AdminUser,
) -> dict:
    incident = store.get_incident(incident_id)
    if not incident:
        raise_logged_not_found(
            logger,
            LookupError(f"incident_id={incident_id}"),
            public_detail="Incident not found",
            log_event="obs_incident_not_found",
        )
    incident.owner = payload.owner
    emit_audit(
        store,
        actor,
        "incident.assign",
        resource_type="incident",
        resource_id=incident_id,
        details=payload.model_dump(),
    )
    store.commit()
    store.refresh(incident)
    return _serialize_incident(incident)
