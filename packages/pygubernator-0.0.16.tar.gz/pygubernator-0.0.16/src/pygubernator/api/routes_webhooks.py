"""Webhook trigger management and inbound trigger routes."""

from __future__ import annotations

import logging
import secrets
import threading
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_http_exception,
    raise_logged_not_found,
)
from pygubernator.api.deps import CurrentUser, DbSession
from pygubernator.db.models import WebhookTrigger

logger = logging.getLogger(__name__)

# --------------- Admin management routes ---------------

admin_router = APIRouter(
    prefix="/api/v1/admin/webhooks",
    tags=["webhooks"],
)


# --------------- Request / Response models ---------------


class WebhookCreate(BaseModel):
    """Request body for creating a webhook trigger."""

    workflow_id: str = Field(..., description="Workflow to trigger")
    name: str = Field(default="", description="Human-readable name")
    enabled: bool = Field(default=True)


class WebhookUpdate(BaseModel):
    """Request body for updating a webhook trigger."""

    name: str | None = Field(default=None)
    enabled: bool | None = Field(default=None)
    workflow_id: str | None = Field(default=None)


class WebhookResponse(BaseModel):
    """Response model for a webhook trigger."""

    id: str
    workflow_id: str
    name: str
    token: str
    webhook_url: str
    enabled: bool
    trigger_count: int
    last_triggered_at: datetime | None
    created_at: datetime


# --------------- Helpers ---------------


def _to_response(row: WebhookTrigger) -> WebhookResponse:
    """Convert a DB row to a response model."""
    return WebhookResponse(
        id=row.id,
        workflow_id=row.workflow_id,
        name=row.name,
        token=row.token,
        webhook_url=f"/api/v1/webhooks/trigger/{row.token}",
        enabled=row.enabled,
        trigger_count=row.trigger_count,
        last_triggered_at=row.last_triggered_at,
        created_at=row.created_at,
    )


# --------------- Admin endpoints ---------------


@admin_router.get("")
def list_webhooks(
    _actor: CurrentUser,
    db: DbSession,
) -> dict:
    """List all webhook triggers."""
    rows = db.query(WebhookTrigger).all()
    items = [_to_response(r).model_dump(mode="json") for r in rows]
    return {"items": items}


@admin_router.post("", response_model=WebhookResponse)
def create_webhook(
    payload: WebhookCreate,
    _actor: CurrentUser,
    db: DbSession,
) -> WebhookResponse:
    """Create a new webhook trigger with a unique token."""
    token = secrets.token_urlsafe(32)
    row = WebhookTrigger(
        workflow_id=payload.workflow_id,
        name=payload.name,
        token=token,
        enabled=payload.enabled,
        created_by=str(_actor.get("username", "system")),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info(
        "Created webhook %s for workflow %s",
        row.id,
        row.workflow_id,
    )
    return _to_response(row)


@admin_router.patch(
    "/{webhook_id}",
    response_model=WebhookResponse,
)
def update_webhook(
    webhook_id: str,
    payload: WebhookUpdate,
    _actor: CurrentUser,
    db: DbSession,
) -> WebhookResponse:
    """Update a webhook trigger's fields."""
    row = db.get(WebhookTrigger, webhook_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"webhook_id={webhook_id}"),
            public_detail="Webhook not found",
            log_event="webhook_not_found",
        )
    if payload.name is not None:
        row.name = payload.name
    if payload.enabled is not None:
        row.enabled = payload.enabled
    if payload.workflow_id is not None:
        row.workflow_id = payload.workflow_id
    db.commit()
    db.refresh(row)
    logger.info("Updated webhook %s", row.id)
    return _to_response(row)


@admin_router.delete("/{webhook_id}")
def delete_webhook(
    webhook_id: str,
    _actor: CurrentUser,
    db: DbSession,
) -> dict:
    """Delete a webhook trigger."""
    row = db.get(WebhookTrigger, webhook_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"webhook_id={webhook_id}"),
            public_detail="Webhook not found",
            log_event="webhook_not_found",
        )
    wh_id = row.id
    db.delete(row)
    db.commit()
    logger.info("Deleted webhook %s", wh_id)
    return {"ok": True, "deleted": wh_id}


@admin_router.post(
    "/{webhook_id}/regenerate",
    response_model=WebhookResponse,
)
def regenerate_webhook_token(
    webhook_id: str,
    _actor: CurrentUser,
    db: DbSession,
) -> WebhookResponse:
    """Regenerate the token for a webhook trigger."""
    row = db.get(WebhookTrigger, webhook_id)
    if not row:
        raise_logged_not_found(
            logger,
            LookupError(f"webhook_id={webhook_id}"),
            public_detail="Webhook not found",
            log_event="webhook_not_found",
        )
    row.token = secrets.token_urlsafe(32)
    db.commit()
    db.refresh(row)
    logger.info("Regenerated token for webhook %s", row.id)
    return _to_response(row)


# --------------- Inbound trigger route (NO auth) ---------------

trigger_router = APIRouter(
    prefix="/api/v1/webhooks",
    tags=["webhook-trigger"],
)


def _run_webhook_workflow(
    spec_json: dict[str, Any],
    input_json: dict[str, Any],
    run_id: str,
) -> None:
    """Execute a webhook-triggered workflow in a background thread.

    Reuses the main _run_workflow_background from routes_workflows,
    which handles claiming, heartbeat, and lifecycle transitions.
    """
    from pygubernator.api.routes_workflows import _run_workflow_background

    _run_workflow_background(spec_json, input_json, run_id)


@trigger_router.post("/trigger/{token}")
def trigger_webhook(
    token: str,
    body: dict[str, Any] | None = None,
    db: DbSession = ...,  # type: ignore[assignment]
) -> dict:
    """Receive an inbound webhook and trigger the workflow.

    No auth required; the token in the URL authenticates
    the request.
    """
    row = db.query(WebhookTrigger).filter(WebhookTrigger.token == token).first()
    if not row:
        raise_logged_not_found(
            logger,
            LookupError("unknown webhook token"),
            public_detail="Unknown webhook token",
            log_event="webhook_unknown_token",
        )
    if not row.enabled:
        raise_logged_http_exception(
            logger,
            ValueError(f"webhook disabled: id={row.id}"),
            status_code=410,
            public_detail="Webhook is disabled",
            log_event="webhook_trigger_disabled",
        )

    input_json = body or {}

    # Look up workflow and active version
    from pygubernator.db.models import Workflow, WorkflowVersion

    wf = db.get(Workflow, row.workflow_id)
    if not wf:
        raise_logged_not_found(
            logger,
            LookupError(f"workflow_id={row.workflow_id}"),
            public_detail="Workflow not found",
            log_event="webhook_trigger_workflow_not_found",
        )

    version = (
        db.query(WorkflowVersion)
        .filter(
            WorkflowVersion.workflow_id == row.workflow_id,
            WorkflowVersion.active.is_(True),
        )
        .first()
    )
    if not version:
        version = (
            db.query(WorkflowVersion)
            .filter(
                WorkflowVersion.workflow_id == row.workflow_id,
            )
            .first()
        )
    if not version:
        raise_logged_bad_request(
            logger,
            ValueError(f"no workflow version for workflow_id={row.workflow_id}"),
            public_detail="No workflow version available",
            log_event="webhook_trigger_no_version",
        )

    # Create a workflow run
    from pygubernator.db.models import WorkflowRun

    run = WorkflowRun(
        workflow_id=row.workflow_id,
        workflow_version_id=version.id,
        status="pending",
        input_json=input_json,
        created_by="webhook",
    )
    db.add(run)

    # Update trigger stats
    row.trigger_count += 1
    row.last_triggered_at = datetime.now(UTC)
    db.commit()
    db.refresh(run)

    run_id = run.id

    thread = threading.Thread(
        target=_run_webhook_workflow,
        args=(version.spec_json, input_json, run_id),
        daemon=True,
        name=f"wh-run-{run_id[:8]}",
    )
    thread.start()

    logger.info(
        "Webhook %s triggered workflow %s, run=%s",
        row.id,
        row.workflow_id,
        run_id[:12],
    )
    return {"ok": True, "run_id": run_id}
