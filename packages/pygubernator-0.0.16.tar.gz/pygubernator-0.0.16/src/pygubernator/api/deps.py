"""FastAPI dependencies for auth and db.

Auth mirrors pycharter/pystator: ``get_current_user``, JWT + optional introspect,
``require_admin`` (strict ``Admin`` role), lazy PyJWT import.
"""

from __future__ import annotations

import hmac
import time
from typing import Annotated, Any

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from pygubernator.config import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_service_introspect_path,
    get_auth_service_url,
    get_auth_users,
    is_auth_disabled,
)
from pygubernator.db.session import get_db
from pygubernator.db.store.sqlalchemy import SQLAlchemyAgentStore

security = HTTPBearer(auto_error=False)

BearerCredentials = Annotated[HTTPAuthorizationCredentials | None, Depends(security)]

ACCESS_TOKEN_EXPIRE_SECONDS = 3600  # 1 hour


def _constant_time_compare(a: str, b: str) -> bool:
    """Constant-time string comparison to avoid timing attacks."""
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def verify_credentials(username: str, password: str) -> dict[str, str] | None:
    """Check username/password against all configured users.

    Returns:
        ``{"username": ..., "role": ...}`` or ``None`` if no match.
    """
    for user in get_auth_users():
        if _constant_time_compare(
            username, user["username"]
        ) and _constant_time_compare(password, user["password"]):
            return {"username": user["username"], "role": user.get("role", "User")}
    return None


def _import_jwt():
    """Lazy import jwt so auth module can be imported without PyJWT (e.g. in tests)."""
    try:
        import jwt as _jwt

        return _jwt
    except ImportError:
        raise ImportError(
            "PyJWT is required for JWT auth. Install with: "
            "pip install pygubernator[api] or pip install PyJWT"
        ) from None


def create_access_token(
    username: str,
    role: str = "User",
    expires_delta_seconds: int = ACCESS_TOKEN_EXPIRE_SECONDS,
) -> str:
    """Create a JWT access token for the given username and role."""
    jwt = _import_jwt()
    secret = get_auth_jwt_secret()
    if not secret:
        raise ValueError(
            "JWT secret not configured "
            "(set PYGUBERNATOR_AUTH_JWT_SECRET in env or pygubernator.cfg [auth])"
        )
    payload = {
        "sub": username,
        "role": role,
        "exp": int(time.time()) + expires_delta_seconds,
        "iat": int(time.time()),
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def verify_jwt(token: str) -> dict[str, Any] | None:
    """Verify JWT and return payload (with 'sub' = username) or None if invalid."""
    try:
        jwt = _import_jwt()
    except ImportError:
        return None
    secret = get_auth_jwt_secret()
    if not secret:
        return None
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
        return payload
    except jwt.PyJWTError:
        return None


def _as_str_set(value: Any) -> set[str]:
    """Coerce a value to a lowercase set of strings."""
    if isinstance(value, str):
        return {value.lower()}
    if isinstance(value, list):
        return {str(v).lower() for v in value}
    return set()


def _payload_roles(payload: dict[str, Any]) -> set[str]:
    """Extract roles from token payload."""
    roles = payload.get("roles") or payload.get("role")
    return _as_str_set(roles) if roles else set()


def _payload_groups(payload: dict[str, Any]) -> set[str]:
    """Extract groups from token payload."""
    groups = payload.get("groups") or payload.get("group")
    return _as_str_set(groups) if groups else set()


def _resolve_role_from_claims(payload: dict[str, Any]) -> str:
    """Map external token claims to Admin/User using configured admin claim names."""
    roles = _payload_roles(payload)
    if roles & get_auth_admin_role_claims():
        return "Admin"
    groups = _payload_groups(payload)
    if groups & get_auth_admin_group_claims():
        return "Admin"
    return "User"


async def introspect_token(token: str) -> dict[str, Any] | None:
    """Call auth service introspect endpoint. Return payload if active, else None."""
    base = get_auth_service_url()
    path = get_auth_service_introspect_path()
    if not base or not path:
        return None
    url = f"{base.rstrip('/')}{path}"
    try:
        import httpx

        async with httpx.AsyncClient() as client:
            r = await client.post(
                url,
                data={"token": token},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=5.0,
            )
            if r.status_code != 200:
                return None
            data = r.json()
            if not data.get("active", False):
                return None
            return data
    except Exception:
        return None


async def get_current_user(
    credentials: BearerCredentials,
) -> dict[str, Any]:
    """Resolve current user from Bearer token.

    Returns:
        ``{"username": ..., "role": ..., "auth_disabled": bool}``.
        Auth disabled -> role = "Admin". Local JWT -> role from token claim.
        External introspect -> role derived from admin claim mapping.
    """
    if is_auth_disabled():
        return {"username": "anonymous", "role": "Admin", "auth_disabled": True}

    token = None
    if credentials and credentials.credentials:
        token = credentials.credentials

    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = verify_jwt(token)
    if payload is None and (
        get_auth_service_url() and get_auth_service_introspect_path()
    ):
        payload = await introspect_token(token)

    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    username = payload.get("sub") or payload.get("username")
    if not username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )

    role = payload.get("role") or _resolve_role_from_claims(payload)
    return {"username": str(username), "role": str(role), "auth_disabled": False}


CurrentUser = Annotated[dict[str, Any], Depends(get_current_user)]


async def require_admin(
    current_user: CurrentUser,
) -> dict[str, Any]:
    """Dependency that raises 403 if user is not Admin."""
    if current_user.get("auth_disabled"):
        return current_user
    if current_user.get("role") != "Admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user


AdminUser = Annotated[dict[str, Any], Depends(require_admin)]

DbSession = Annotated[Session, Depends(get_db)]


def get_workspace_id(current_user: CurrentUser) -> str:
    """Extract workspace_id from user claims.

    Falls back to ``"default"`` when the JWT does not carry a workspace claim.

    Args:
        current_user: Decoded user dict from the auth dependency.

    Returns:
        The workspace identifier string.
    """
    return str(current_user.get("workspace_id", "default"))


WorkspaceId = Annotated[str, Depends(get_workspace_id)]


def get_agent_store(db: DbSession, workspace_id: WorkspaceId) -> SQLAlchemyAgentStore:
    """Request-scoped persistence client for control-plane routes."""
    return SQLAlchemyAgentStore(session=db, workspace_id=workspace_id)


AgentStore = Annotated[SQLAlchemyAgentStore, Depends(get_agent_store)]
