"""Service helpers for emitting and broadcasting workflow artifacts.

Node handlers and tools call :func:`emit_artifact` to publish a
structured output (Markdown report, CSV table, HTML preview, notebook,
image) as a first-class ``workflow_artifacts`` row. The helper performs
the DB insert, flushes so the ORM-assigned id is available, and fans an
``artifact_created`` event out over the SSE run channel so the UI can
live-mount the new artifact without polling.

:func:`update_artifact_content` mirrors the insert path for long-running
nodes that stream incremental content into an already-emitted artifact —
the same row is updated and an ``artifact_updated`` SSE event fires.
"""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.api._sse import broadcaster
from pygubernator.db.models import WorkflowArtifact
from pygubernator.db.store.sqlalchemy import SQLAlchemyAgentStore

logger = logging.getLogger(__name__)

# SSE event type constants. Kept alongside ``_BroadcastHandler._EVENT_MAP``
# in spirit so the UI has a stable vocabulary for artifact-aware
# subscribers.
SSE_TYPE_ARTIFACT_CREATED = "artifact_created"
SSE_TYPE_ARTIFACT_UPDATED = "artifact_updated"


def _artifact_summary(artifact: WorkflowArtifact) -> dict[str, Any]:
    """Return the SSE-friendly summary dict for an artifact row.

    Intentionally excludes ``content_text`` — the list route omits
    content for the same reason (payload size), and streaming it on SSE
    would multiply that cost per subscriber. Subscribers that want the
    body fetch ``GET .../artifacts/{id}/content`` on demand.
    """
    return {
        "id": artifact.id,
        "workflow_run_id": artifact.workflow_run_id,
        "step_run_id": artifact.step_run_id,
        "artifact_type": artifact.artifact_type,
        "title": artifact.title,
        "mime": artifact.mime,
        "source_path": artifact.source_path,
        "size_bytes": artifact.size_bytes,
        "sequence_num": artifact.sequence_num,
        "has_content": artifact.content_text is not None
        or artifact.source_path is not None,
    }


def _publish(run_id: str, event_type: str, artifact: WorkflowArtifact) -> None:
    """Publish an ``artifact_*`` SSE event for a run. Errors are swallowed."""
    try:
        broadcaster.publish(
            run_id,
            {
                "type": event_type,
                "artifact": _artifact_summary(artifact),
            },
        )
    except Exception:
        # SSE publishing must never block or crash the emitting node.
        logger.exception("artifact_sse_publish_failed")


def emit_artifact(
    store: SQLAlchemyAgentStore,
    *,
    workflow_run_id: str,
    artifact_type: str,
    step_run_id: str | None = None,
    title: str | None = None,
    mime: str | None = None,
    content_text: str | None = None,
    source_path: str | None = None,
    size_bytes: int | None = None,
) -> WorkflowArtifact:
    """Persist a new artifact and broadcast ``artifact_created`` to SSE.

    This is the canonical entry point for node handlers and tools that
    want to publish a structured output. Either ``content_text`` or
    ``source_path`` must be provided so the content route has something
    to serve.

    Args:
        store: Request- or engine-scoped agent store.
        workflow_run_id: Parent run id.
        artifact_type: Renderer discriminator (``markdown``, ``table``,
            ``html``, ``image``, ``notebook``, ``json``, ``text``).
        step_run_id: Optional step run id when the artifact belongs to
            one node execution. ``None`` for run-level artifacts.
        title: Optional human-readable title.
        mime: Optional MIME type.
        content_text: Inline text content.
        source_path: Filesystem or object-storage reference for content
            too large or too binary to inline.
        size_bytes: Optional content size for the list summary.

    Returns:
        The persisted :class:`WorkflowArtifact`.

    Raises:
        ValueError: If neither ``content_text`` nor ``source_path`` is
            provided — propagated from the repository layer.
    """
    artifact = store.create_workflow_artifact(
        workflow_run_id=workflow_run_id,
        step_run_id=step_run_id,
        artifact_type=artifact_type,
        title=title,
        mime=mime,
        content_text=content_text,
        source_path=source_path,
        size_bytes=size_bytes,
    )
    # Flush so sequence_num, id, and timestamps materialise before we
    # build the SSE payload. Callers manage the outer commit.
    store.session.flush()
    logger.info(
        "artifact_created run=%s step=%s type=%s id=%s",
        workflow_run_id,
        step_run_id or "-",
        artifact_type,
        artifact.id,
    )
    _publish(workflow_run_id, SSE_TYPE_ARTIFACT_CREATED, artifact)
    return artifact


def update_artifact_content(
    store: SQLAlchemyAgentStore,
    *,
    artifact: WorkflowArtifact,
    content_text: str | None = None,
    source_path: str | None = None,
    size_bytes: int | None = None,
    title: str | None = None,
    mime: str | None = None,
) -> WorkflowArtifact:
    """Mutate an artifact's content and broadcast ``artifact_updated``.

    Designed for streaming updates: a long-running node emits a skeleton
    artifact early (so the UI mounts the viewer) and later replaces the
    content with the finished payload. Fields left as ``None`` are left
    unchanged; non-None values overwrite.

    Args:
        store: Store used to flush the update.
        artifact: Existing artifact to mutate.
        content_text: Replacement inline content, or ``None`` to leave
            as-is.
        source_path: Replacement source path, or ``None`` to leave as-is.
        size_bytes: Replacement size metadata.
        title: Replacement title.
        mime: Replacement MIME type.

    Returns:
        The same artifact instance after mutation and flush.
    """
    updates: dict[str, Any] = {}
    if content_text is not None:
        updates["content_text"] = content_text
    if source_path is not None:
        updates["source_path"] = source_path
    if size_bytes is not None:
        updates["size_bytes"] = size_bytes
    if title is not None:
        updates["title"] = title
    if mime is not None:
        updates["mime"] = mime
    if updates:
        store.update_workflow_artifact(artifact, **updates)
        store.session.flush()
    _publish(artifact.workflow_run_id, SSE_TYPE_ARTIFACT_UPDATED, artifact)
    return artifact


__all__ = [
    "SSE_TYPE_ARTIFACT_CREATED",
    "SSE_TYPE_ARTIFACT_UPDATED",
    "emit_artifact",
    "update_artifact_content",
]
