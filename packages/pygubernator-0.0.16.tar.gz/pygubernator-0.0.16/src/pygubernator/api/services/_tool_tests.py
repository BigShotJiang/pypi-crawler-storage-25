"""Tool-test execution service for first-class tool versions."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from pygubernator.api.services._workflows import build_node_registry

logger = logging.getLogger(__name__)

# Conservative v1 allowlist; expand over time behind policy review.
TOOL_TEST_NODE_ALLOWLIST = frozenset(
    {
        "input",
        "output",
        "template",
        "condition",
        "transform",
        "contract_validate",
        "http",
        "llm",
        "llm_chain",
        "tool",
        "subworkflow",
    }
)


def _truncate_output(value: Any, max_output_chars: int) -> Any:
    if isinstance(value, str):
        if len(value) <= max_output_chars:
            return value
        return value[:max_output_chars] + "...[truncated]"
    if isinstance(value, dict):
        return {k: _truncate_output(v, max_output_chars) for k, v in value.items()}
    if isinstance(value, list):
        return [_truncate_output(v, max_output_chars) for v in value]
    return value


def execute_tool_test(
    workflow_spec_json: dict[str, Any],
    input_json: dict[str, Any],
    *,
    timeout_s: float = 120.0,
    max_steps: int = 100,
    max_output_chars: int = 40000,
    allowed_node_types: set[str] | None = None,
    execution_profile: str = "tool_test",
) -> dict[str, Any]:
    """Execute a tool workflow-spec in isolated tool_test mode."""
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow._types import NodeResult
    from pygubernator.workflow.config._loader import WorkflowLoader

    allowed = allowed_node_types or set(TOOL_TEST_NODE_ALLOWLIST)
    loader = WorkflowLoader()
    spec = loader.load_dict(workflow_spec_json)

    disallowed = sorted(
        {
            node.node_type
            for node in spec.nodes.values()
            if node.node_type not in allowed
        }
    )
    if disallowed:
        return {
            "success": False,
            "output": {},
            "errors": [
                "Tool test blocked by node policy: "
                + ", ".join(disallowed)
                + ". Allowed node types: "
                + ", ".join(sorted(allowed))
            ],
            "duration_ms": 0,
            "execution_profile": execution_profile,
            "steps": [],
        }

    steps: list[dict[str, Any]] = []
    step_count = 0

    def should_cancel() -> bool:
        return step_count >= max_steps

    def persist_step(node_id: str, result: NodeResult) -> None:
        nonlocal step_count
        step_count += 1
        steps.append(
            {
                "node_id": node_id,
                "node_type": spec.nodes.get(node_id).node_type
                if node_id in spec.nodes
                else "unknown",
                "status": result.status.value,
                "output_json": _truncate_output(result.output or {}, max_output_chars),
                "output_handle": result.output_handle,
                "error_message": result.error,
            }
        )

    registry = build_node_registry()
    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        persist_callback=persist_step,
        should_cancel=should_cancel,
    )
    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            asyncio.wait_for(engine.run(input_json), timeout=timeout_s)
        )
    except TimeoutError:
        return {
            "success": False,
            "output": {},
            "errors": [f"Tool test timed out after {timeout_s:.1f}s"],
            "duration_ms": int((time.monotonic() - start) * 1000),
            "execution_profile": execution_profile,
            "steps": steps,
        }
    except Exception as exc:
        logger.error("Tool test execution failed: %s", exc, exc_info=True)
        return {
            "success": False,
            "output": {},
            "errors": [f"Tool test failed: {exc}"],
            "duration_ms": int((time.monotonic() - start) * 1000),
            "execution_profile": execution_profile,
            "steps": steps,
        }
    duration_ms = int((time.monotonic() - start) * 1000)
    logger.info(
        "tool_test completed success=%s steps=%d duration_ms=%d",
        bool(wf_result.success),
        len(steps),
        duration_ms,
    )
    return {
        "success": bool(wf_result.success),
        "output": _truncate_output(wf_result.output or {}, max_output_chars),
        "errors": list(wf_result.errors or []),
        "duration_ms": duration_ms,
        "execution_profile": execution_profile,
        "steps": steps,
    }
