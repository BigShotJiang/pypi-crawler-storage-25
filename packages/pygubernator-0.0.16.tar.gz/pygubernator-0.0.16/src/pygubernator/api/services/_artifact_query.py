"""Read-only SQL sandbox for ``table`` artifacts (Phase 6 §6.1a-query).

Users routinely emit CSV artifacts — daily report outputs, pipeline
summaries, QA dashboards — and then want to ask quick follow-up
questions of that data without opening a notebook: "how many rows where
x=y?", "what's the distribution of z?". This module backs the
``POST .../artifacts/{id}/query`` route that lets them type a SELECT
straight into the Artifact Viewer.

Safety model
------------

The sandbox is two locks deep:

1. **Isolated in-memory database.** Each query spins up a fresh
   ``sqlite3.connect(":memory:")`` and loads *only* the one artifact's
   CSV into it. There is no way to reach the application's real DB or
   any filesystem through the sandbox — the DB literally doesn't know
   any other tables exist.

2. **SQLite authorizer.** We attach a ``Connection.set_authorizer``
   callback that rejects every action code *except* the read-only ones
   (``SQLITE_SELECT``, ``SQLITE_READ``, ``SQLITE_FUNCTION``, etc.).
   Attempts to run ``INSERT``, ``UPDATE``, ``DELETE``, ``DROP``,
   ``CREATE``, ``ALTER``, ``ATTACH``, ``PRAGMA``, or any other mutating
   / side-effecting statement fail at statement-planning time with a
   clear ``ArtifactQueryError`` — even if the tokeniser would otherwise
   accept the SQL. This is stronger than keyword filtering: an adversary
   can't hide a mutation behind comments, unicode, or aliasing, because
   the SQLite planner itself refuses to compile the statement.

Additional resource limits:

- Per-query row cap (``_MAX_ROWS``) so a ``SELECT *`` against a million-
  row artifact doesn't OOM the API process.
- Per-query timeout (``_MAX_EXEC_SECONDS``) via
  ``Connection.set_progress_handler`` — coarse but enough to stop
  runaway cartesian joins.

Public surface
--------------

- :class:`ArtifactQueryError` — caller-safe, its ``str(exc)`` goes to
  the HTTP response body via ``_http_errors.raise_logged_bad_request``.
- :func:`run_artifact_query` — the sandboxed executor.
"""

from __future__ import annotations

import csv
import io
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Any

from pygubernator.api._http_errors import PublicFacingError
from pygubernator.errors import GubernatorError

logger = logging.getLogger(__name__)

# --- Resource limits ---------------------------------------------------------

_MAX_ROWS = 1_000
_MAX_EXEC_SECONDS = 5.0
# Progress handler fires every N VM opcodes — small enough to interrupt
# long queries but not so small we burn CPU on the handler itself.
_PROGRESS_INSTRUCTIONS = 1_000

# --- Authorizer --------------------------------------------------------------

# Action codes that a pure read-only query needs. Anything else is
# denied. Pulled from https://www.sqlite.org/c3ref/c_alter_table.html
# and filtered to the read-only set.
_ALLOWED_ACTIONS: frozenset[int] = frozenset(
    {
        sqlite3.SQLITE_SELECT,
        sqlite3.SQLITE_READ,
        sqlite3.SQLITE_FUNCTION,
        sqlite3.SQLITE_RECURSIVE,
    },
)


class ArtifactQueryError(GubernatorError, PublicFacingError):
    """Caller-facing error from the artifact SQL sandbox.

    Dual-inherits from ``GubernatorError`` (keeps the package
    exception hierarchy) and ``PublicFacingError`` (marks ``str(exc)``
    as safe to forward to HTTP clients). Messages are hand-written in
    this module and never contain driver, ORM, or server-side state —
    the only exception text that slips in is the SQLite library's own
    syntax-error output, which exposes only user-provided SQL.
    """


@dataclass(frozen=True, slots=True)
class ArtifactQueryResult:
    """Result envelope for a successful artifact query."""

    columns: tuple[str, ...]
    rows: tuple[tuple[Any, ...], ...]
    row_count: int
    truncated: bool = False
    elapsed_ms: int = 0


@dataclass(slots=True)
class _AuthorizerState:
    """Tracks whether a statement attempted a denied action."""

    denied_reason: str | None = None
    extra: tuple[str, ...] = field(default_factory=tuple)


def _build_deny_reason_map() -> dict[int, str]:
    """Map SQLite action codes to user-facing labels.

    Built at import time using ``getattr`` so we tolerate the handful
    of codes that are missing from some Python / SQLite builds (e.g.
    ``SQLITE_COPY`` was dropped in recent Python releases).
    """
    pairs: list[tuple[str, str]] = [
        ("SQLITE_INSERT", "INSERT"),
        ("SQLITE_UPDATE", "UPDATE"),
        ("SQLITE_DELETE", "DELETE"),
        ("SQLITE_DROP_TABLE", "DROP TABLE"),
        ("SQLITE_DROP_INDEX", "DROP INDEX"),
        ("SQLITE_DROP_VIEW", "DROP VIEW"),
        ("SQLITE_DROP_TRIGGER", "DROP TRIGGER"),
        ("SQLITE_CREATE_TABLE", "CREATE TABLE"),
        ("SQLITE_CREATE_INDEX", "CREATE INDEX"),
        ("SQLITE_CREATE_VIEW", "CREATE VIEW"),
        ("SQLITE_CREATE_TRIGGER", "CREATE TRIGGER"),
        ("SQLITE_CREATE_TEMP_TABLE", "CREATE TEMP TABLE"),
        ("SQLITE_ALTER_TABLE", "ALTER TABLE"),
        ("SQLITE_ATTACH", "ATTACH DATABASE"),
        ("SQLITE_DETACH", "DETACH DATABASE"),
        ("SQLITE_PRAGMA", "PRAGMA"),
        ("SQLITE_TRANSACTION", "transaction control"),
        ("SQLITE_REINDEX", "REINDEX"),
        ("SQLITE_ANALYZE", "ANALYZE"),
    ]
    result: dict[int, str] = {}
    for name, label in pairs:
        code = getattr(sqlite3, name, None)
        if isinstance(code, int):
            result[code] = label
    return result


_DENY_LABELS: dict[int, str] = _build_deny_reason_map()


def _deny_reason(action: int) -> str:
    """Return a caller-friendly label for a denied authorizer action."""
    return _DENY_LABELS.get(action, f"action {action}")


def _build_authorizer(state: _AuthorizerState):
    """Factory for the authorizer callback so each query gets fresh state.

    The authorizer tracks denied actions in ``state.denied_reason``
    using a preference rule: more specific DDL codes (DROP TABLE,
    CREATE TABLE, ATTACH DATABASE, PRAGMA, …) win over the generic
    DML codes (INSERT / UPDATE / DELETE) that SQLite emits as a
    side-effect of some DDL operations (e.g. DROP TABLE emits a
    DELETE on ``sqlite_master`` before the DROP_TABLE code itself).
    Without this rule a user who typed ``DROP TABLE artifact`` would
    see ``DELETE is not allowed``, which is confusing.
    """

    def authorizer(
        action: int,
        arg1: str | None,
        _a2: str | None,
        _a3: str | None,
        _a4: str | None,
    ) -> int:
        if action in _ALLOWED_ACTIONS:
            return sqlite3.SQLITE_OK
        # SQLite's DDL planner emits DELETE / INSERT / UPDATE actions
        # on ``sqlite_master`` and friends as a prelude to the actual
        # DROP / CREATE / ALTER. If we deny those prelude actions the
        # planner never reaches the DDL code we'd prefer to name in
        # the error, so the user sees "DELETE is not allowed" when
        # they typed "DROP TABLE". Letting them through is safe — our
        # outer deny on the real DDL action still blocks the statement
        # — and it gives us the accurate label.
        is_internal_prelude = (
            arg1 is not None
            and arg1.startswith("sqlite_")
            and action
            in {
                sqlite3.SQLITE_DELETE,
                sqlite3.SQLITE_INSERT,
                sqlite3.SQLITE_UPDATE,
                sqlite3.SQLITE_READ,
            }
        )
        if is_internal_prelude:
            return sqlite3.SQLITE_OK
        # Prefer the first specific DDL-style deny over any generic
        # DML label captured earlier for the same statement.
        current = state.denied_reason
        incoming = _deny_reason(action)
        if current is None or (
            current in _GENERIC_DENY_LABELS and incoming not in _GENERIC_DENY_LABELS
        ):
            state.denied_reason = incoming
        return sqlite3.SQLITE_DENY

    return authorizer


# Labels that SQLite emits as part of a larger DDL operation (e.g.
# ``DROP TABLE`` performs a ``DELETE`` on ``sqlite_master`` first).
# When we see one of these alongside a more specific DDL label we
# surface the specific one so the error message matches what the
# user actually typed.
_GENERIC_DENY_LABELS: frozenset[str] = frozenset(
    {"INSERT", "UPDATE", "DELETE"},
)


# --- CSV loader --------------------------------------------------------------


_TABLE_NAME = "artifact"


def _safe_column_name(raw: str, idx: int) -> str:
    """Coerce a CSV header into a SQLite-safe column name.

    SQLite accepts arbitrary quoted identifiers but we want queries the
    user can type unquoted, so strip characters that wouldn't parse as
    a bare identifier. Falls back to ``col_N`` for empty or all-invalid
    headers.
    """
    cleaned = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in raw)
    cleaned = cleaned.strip("_")
    if not cleaned or cleaned[0].isdigit():
        return f"col_{idx}"
    return cleaned


def _load_csv_into_sqlite(
    conn: sqlite3.Connection,
    content: str,
) -> tuple[str, ...]:
    """Parse CSV text and load into an ``artifact`` table in ``conn``.

    The first row is treated as the header. Columns are mapped to
    SQLite-safe names via :func:`_safe_column_name` to keep user queries
    readable. All values are stored as TEXT — SQLite's type affinity is
    loose enough that comparisons still work for numeric predicates,
    and avoiding inference keeps the loader deterministic.

    Returns:
        The resolved column names (post-safe-naming).
    """
    reader = csv.reader(io.StringIO(content))
    try:
        header = next(reader)
    except StopIteration:
        raise ArtifactQueryError("Artifact is empty — nothing to query") from None
    columns = tuple(_safe_column_name(str(h), i) for i, h in enumerate(header))
    if not columns:
        raise ArtifactQueryError("Artifact has no columns — nothing to query")
    column_sql = ", ".join(f'"{c}" TEXT' for c in columns)
    conn.execute(f'CREATE TABLE "{_TABLE_NAME}" ({column_sql})')
    placeholders = ", ".join(["?"] * len(columns))
    insert_sql = f'INSERT INTO "{_TABLE_NAME}" VALUES ({placeholders})'
    # Pad / truncate rows to the header length so ragged CSVs don't
    # raise a mid-load exception.
    rows = (tuple((row + [None] * len(columns))[: len(columns)]) for row in reader)
    conn.executemany(insert_sql, rows)
    return columns


# --- Public entry point ------------------------------------------------------


def run_artifact_query(
    *,
    artifact_type: str,
    content_text: str | None,
    sql: str,
) -> ArtifactQueryResult:
    """Run a read-only SQL query against one artifact's inline content.

    Only ``table`` artifacts are supported in v1 — those carry their
    content as CSV in ``content_text``. Other artifact types (markdown,
    html, image, …) raise immediately. Queries must be SELECT-only;
    mutations are rejected at statement-planning time by the SQLite
    authorizer, not by keyword matching.

    Args:
        artifact_type: The artifact's ``artifact_type`` field. Must be
            ``"table"`` or ``"csv"``.
        content_text: The CSV payload. ``None`` means the artifact
            hasn't been populated yet.
        sql: The user-provided SQL. One statement, no trailing
            semicolon required. The table to query is named
            ``artifact``.

    Returns:
        ArtifactQueryResult with columns, rows (capped at
        :data:`_MAX_ROWS`), row_count, truncated flag, and elapsed_ms.

    Raises:
        ArtifactQueryError: If the artifact type is wrong, the SQL is
            malformed, the query tries a denied action, runs past the
            timeout, or no SQL is provided.
    """
    if artifact_type not in ("table", "csv"):
        raise ArtifactQueryError(
            f"Query is only supported for table / CSV artifacts (got {artifact_type!r})"
        )
    if not content_text:
        raise ArtifactQueryError("Artifact has no inline content to query")
    sql_text = sql.strip()
    if sql_text.endswith(";"):
        sql_text = sql_text[:-1].rstrip()
    if not sql_text:
        raise ArtifactQueryError("SQL query is empty")
    if ";" in sql_text:
        raise ArtifactQueryError("Only a single SQL statement is allowed per query")

    state = _AuthorizerState()
    deadline = time.monotonic() + _MAX_EXEC_SECONDS

    def progress_handler() -> int:
        # Returning non-zero aborts the query; we use time-based
        # interruption so long cartesian joins don't wedge the request
        # thread.
        if time.monotonic() > deadline:
            return 1
        return 0

    conn: sqlite3.Connection | None = None
    start = time.monotonic()
    try:
        conn = sqlite3.connect(":memory:", isolation_level=None)
        _load_csv_into_sqlite(conn, content_text)
        conn.set_authorizer(_build_authorizer(state))
        conn.set_progress_handler(progress_handler, _PROGRESS_INSTRUCTIONS)
        try:
            cursor = conn.execute(sql_text)
        except sqlite3.Error as exc:
            # Covers authorizer denial (``DatabaseError``), progress-
            # handler abort (``OperationalError``), and pure syntax
            # errors. ``str(exc)`` from sqlite3 is safe to surface —
            # it's the SQLite library's own error text, not user data —
            # but we prefer the authorizer state when set because it
            # names the specific denied action more cleanly.
            if state.denied_reason is not None:
                raise ArtifactQueryError(
                    f"Query rejected: {state.denied_reason} is not allowed "
                    "in the artifact SQL sandbox"
                ) from None
            if "interrupted" in str(exc).lower():
                raise ArtifactQueryError(
                    f"Query exceeded the {_MAX_EXEC_SECONDS:.0f}s timeout"
                ) from None
            raise ArtifactQueryError(f"Invalid SQL: {exc}") from None

        columns = tuple(d[0] for d in (cursor.description or ()))
        rows: list[tuple[Any, ...]] = []
        truncated = False
        for row in cursor:
            if len(rows) >= _MAX_ROWS:
                truncated = True
                break
            rows.append(tuple(row))
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return ArtifactQueryResult(
            columns=columns,
            rows=tuple(rows),
            row_count=len(rows),
            truncated=truncated,
            elapsed_ms=elapsed_ms,
        )
    finally:
        if conn is not None:
            conn.close()


__all__ = [
    "ArtifactQueryError",
    "ArtifactQueryResult",
    "run_artifact_query",
]
