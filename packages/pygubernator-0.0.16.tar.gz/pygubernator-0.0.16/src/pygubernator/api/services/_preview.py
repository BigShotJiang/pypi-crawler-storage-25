"""Single-node preview service — executes one node in isolation, no persistence.

Preview reuses :meth:`AbstractNode.execute` directly but skips everything the
full workflow engine layers on top: no DB writes, no event bus, no retries,
no contract validation, no scheduling. The caller supplies input data and
optional variables; the node runs once, wrapped by :func:`asyncio.wait_for`,
and we return the :class:`NodeResult` or a structured failure.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass
from typing import Any

from pygubernator.api._http_errors import PublicFacingError
from pygubernator.errors import NodeError
from pygubernator.workflow._preview_safety import (
    PreviewSafety,
    classify,
    is_runnable_phase1,
)
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import NodeContext, NodeResult, NodeStatus

logger = logging.getLogger(__name__)

_PREVIEW_NODE_ID = "preview"
_CHEAP_MODEL_MAP: dict[str, str] = {
    "gpt-4o": "gpt-4o-mini",
    "gpt-4-turbo": "gpt-4o-mini",
    "gpt-4": "gpt-4o-mini",
    "claude-opus-4-7": "claude-haiku-4-5-20251001",
    "claude-sonnet-4-6": "claude-haiku-4-5-20251001",
    "claude-3-5-sonnet-latest": "claude-3-5-haiku-latest",
    "claude-3-opus-latest": "claude-3-5-haiku-latest",
    "gemini-2.0-pro": "gemini-2.0-flash",
    "gemini-1.5-pro": "gemini-1.5-flash",
}


class PreviewRefusedError(PublicFacingError):
    """Raised when a node's safety class is not runnable in preview.

    Routes translate this into an HTTP 409 response; the message is
    authored in this module and :class:`PublicFacingError` ancestry
    marks it safe to surface to the user.
    """

    def __init__(self, safety: PreviewSafety, node_type: str) -> None:
        self.safety = safety
        self.node_type = node_type
        super().__init__(self._render_message(safety, node_type))

    @staticmethod
    def _render_message(safety: PreviewSafety, node_type: str) -> str:
        """One-line explanation of why the preview was refused."""
        reasons = {
            PreviewSafety.CONTAINER: (
                "Container nodes execute their children; preview them inside "
                "a full workflow run instead."
            ),
            # Trigger nodes are runnable via synthetic-event preview; kept
            # here only as a defensive fallback if the classifier taxonomy
            # changes again.
            PreviewSafety.TRIGGER: (
                "Trigger nodes can normally be previewed with a synthetic "
                "event payload; this instance was refused."
            ),
            PreviewSafety.APPROVAL: (
                "Approval nodes pause for human input — nothing to preview "
                "in isolation."
            ),
            PreviewSafety.EFFECTFUL: (
                "This node has real-world side effects. Effectful preview "
                "requires dry-run support (Phase 2)."
            ),
        }
        detail = reasons.get(safety, "This node type is not previewable.")
        return f"Cannot preview '{node_type}': {detail}"


@dataclass(frozen=True, slots=True)
class PreviewOutcome:
    """Structured result of a single-node preview execution."""

    status: str
    output: dict[str, Any]
    output_handle: str
    error: str | None
    duration_ms: int
    warnings: tuple[str, ...] = ()

    @classmethod
    def success(cls, result: NodeResult, duration_ms: int) -> PreviewOutcome:
        """Build a success outcome from a node result."""
        return cls(
            status=result.status.value,
            output=dict(result.output),
            output_handle=result.output_handle,
            error=result.error,
            duration_ms=duration_ms,
        )

    @classmethod
    def failed(cls, error: str, duration_ms: int) -> PreviewOutcome:
        """Build a failure outcome with a user-safe error message."""
        return cls(
            status=NodeStatus.FAILED.value,
            output={},
            output_handle="default",
            error=error,
            duration_ms=duration_ms,
        )

    @classmethod
    def timed_out(cls, timeout_s: float, duration_ms: int) -> PreviewOutcome:
        """Build a timeout outcome (status distinct from failed)."""
        return cls(
            status="timeout",
            output={},
            output_handle="default",
            error=f"Preview exceeded {timeout_s:.0f}s timeout.",
            duration_ms=duration_ms,
        )

    def with_warnings(self, warnings: list[str]) -> PreviewOutcome:
        """Return a copy with the supplied warnings attached.

        Outcomes are frozen dataclasses; callers collect warnings as a
        mutable list during the preview and attach them at return time.
        """
        if not warnings:
            return self
        return PreviewOutcome(
            status=self.status,
            output=self.output,
            output_handle=self.output_handle,
            error=self.error,
            duration_ms=self.duration_ms,
            warnings=tuple(warnings),
        )


async def preview_node(
    *,
    node_type: str,
    config: dict[str, Any] | None,
    input_data: dict[str, Any] | None,
    variables: dict[str, Any] | None = None,
    session_id: str | None = None,
    cheap_llm: bool = True,
    timeout_s: float = 30.0,
    registry: NodeTypeRegistry,
    actor: str | None = None,
) -> PreviewOutcome:
    """Execute a single workflow node against ad-hoc input.

    Args:
        node_type: Registered node type (e.g. ``"template"``).
        config: Node config dict, as it would appear in a workflow spec.
        input_data: Mock input the node would have received from upstream.
        variables: Optional shared variables for the run.
        session_id: When set, a scratch session id is used (and cleared
            on exit) so memory nodes don't pollute live sessions.
        cheap_llm: If True, rewrites common expensive model names to
            cheaper equivalents for LLM nodes.
        timeout_s: Hard wall-clock cap on node execution.
        registry: Node factory registry (caller-built, for DI and testing).
        actor: Actor username (for audit log only).

    Returns:
        Structured :class:`PreviewOutcome`. Timeouts return status
        ``"timeout"``, not a raised exception.

    Raises:
        NodeError: Unknown ``node_type``.
        PreviewRefusedError: Node type is not runnable in Phase 1.
    """
    raw_config = dict(config or {})
    expanded_config, expansion_warnings = _expand_agent_reference(node_type, raw_config)
    # Cheap-model override applies AFTER expansion so agent_id-referenced
    # agents also benefit from the preview cost saver.
    effective_config = _rewrite_config_for_preview(
        node_type, expanded_config, cheap_llm=cheap_llm
    )
    safety = classify(node_type, effective_config)
    if not is_runnable_phase1(safety):
        raise PreviewRefusedError(safety, node_type)

    warnings: list[str] = list(expansion_warnings)
    if safety is PreviewSafety.TRIGGER:
        warnings.append(
            "Trigger preview: the supplied input is treated as a synthetic "
            "event payload. The real trigger will inject its own fields at "
            "runtime."
        )
    if cheap_llm and node_type in {"llm", "agent", "dispatch_agent"}:
        _maybe_note_cheap_llm(expanded_config, effective_config, warnings)

    scratch_session = _maybe_scratch_session(session_id)
    merged_variables: dict[str, Any] = dict(variables or {})
    if scratch_session is not None:
        merged_variables["__session_id__"] = scratch_session

    node = registry.create(_PREVIEW_NODE_ID, node_type, effective_config)
    context = NodeContext(
        node_id=_PREVIEW_NODE_ID,
        input_data=dict(input_data or {}),
        variables=merged_variables,
        config=effective_config,
    )

    logger.info(
        "[PREVIEW] actor=%s node_type=%s safety=%s timeout=%.0fs",
        actor or "anonymous",
        node_type,
        safety.value,
        timeout_s,
    )

    started = time.perf_counter()
    try:
        result = await asyncio.wait_for(node.execute(context), timeout=timeout_s)
    except TimeoutError:
        elapsed_ms = _elapsed_ms(started)
        return PreviewOutcome.timed_out(timeout_s, elapsed_ms).with_warnings(warnings)
    except NodeError as exc:
        elapsed_ms = _elapsed_ms(started)
        return PreviewOutcome.failed(str(exc), elapsed_ms).with_warnings(warnings)
    except Exception:
        elapsed_ms = _elapsed_ms(started)
        logger.exception("[PREVIEW] node raised unexpected exception")
        return PreviewOutcome.failed(
            "Node execution failed.", elapsed_ms
        ).with_warnings(warnings)
    finally:
        if scratch_session is not None:
            _clear_scratch_session(scratch_session)

    return PreviewOutcome.success(result, _elapsed_ms(started)).with_warnings(warnings)


def _elapsed_ms(started: float) -> int:
    """Milliseconds elapsed since ``started`` (from ``time.perf_counter``)."""
    return int((time.perf_counter() - started) * 1000)


def _maybe_scratch_session(session_id: str | None) -> str | None:
    """Return a scratch session id, or None if the caller did not need one."""
    if session_id is None:
        return None
    stripped = session_id.strip()
    if not stripped:
        return None
    # Always use a unique scratch id — we never want preview runs to write
    # into a real session's memory store.
    return f"preview-{uuid.uuid4().hex[:12]}"


def _clear_scratch_session(session_id: str) -> None:
    """Tear down any memory store entries for the scratch session."""
    try:
        from pygubernator.workflow.nodes._memory import clear_session_stores

        clear_session_stores(session_id)
    except Exception:
        logger.warning(
            "[PREVIEW] failed to clear scratch session %s",
            session_id,
            exc_info=True,
        )


def _expand_agent_reference(
    node_type: str, config: dict[str, Any]
) -> tuple[dict[str, Any], list[str]]:
    """Resolve ``agent_id`` / ``agent_version_id`` before safety classification.

    For ``dispatch_agent`` nodes, ``target_agent_id`` is treated as the
    reference — but only when it's a literal string (not a Jinja template);
    templated targets can't be resolved at preview time.

    If resolution fails (archived agent, missing version, templated id), we
    leave the config as-is — ``classify`` handles the fallback and the
    actual execution path surfaces the error through the resolver.

    Returns:
        Tuple of ``(effective_config, warnings)``. Warnings bubble up to
        the preview response so users can see why a pinned version was
        honoured, etc.
    """
    if node_type not in {"agent", "dispatch_agent"}:
        return config, []
    reference = dict(config)
    if node_type == "dispatch_agent":
        target = reference.get("target_agent_id")
        if isinstance(target, str) and "{{" not in target and target.strip():
            reference.setdefault("agent_id", target.strip())
        target_version = reference.get("target_version_id")
        if (
            isinstance(target_version, str)
            and "{{" not in target_version
            and target_version.strip()
        ):
            reference.setdefault("agent_version_id", target_version.strip())
    if not (reference.get("agent_id") or reference.get("agent_version_id")):
        return config, []
    try:
        from pygubernator.workflow.nodes._agent_resolver import (
            AgentResolutionError,
            resolve_agent_config,
        )

        expanded, warnings = resolve_agent_config(reference)
        return expanded, list(warnings)
    except AgentResolutionError:
        return config, []
    except Exception:
        logger.warning(
            "[PREVIEW] failed to pre-resolve agent reference for classification",
            exc_info=True,
        )
        return config, []


def _maybe_note_cheap_llm(
    original_config: dict[str, Any],
    effective_config: dict[str, Any],
    warnings: list[str],
) -> None:
    """Note when a cheap-model override was applied so the user can see it."""
    for key in ("model", "model_name"):
        before = original_config.get(key)
        after = effective_config.get(key)
        if isinstance(before, str) and isinstance(after, str) and before != after:
            warnings.append(
                f"Preview cost saver: swapped '{before}' → '{after}'. "
                "Disable with cheap_llm=false for full-fidelity output."
            )
            return


def _rewrite_config_for_preview(
    node_type: str,
    config: dict[str, Any],
    *,
    cheap_llm: bool,
) -> dict[str, Any]:
    """Apply preview-time config overrides (currently: cheap LLM models)."""
    if not cheap_llm:
        return config
    if node_type not in {"llm", "agent"}:
        return config
    return _swap_llm_model(config)


def _swap_llm_model(config: dict[str, Any]) -> dict[str, Any]:
    """Replace an expensive LLM model name with a cheaper equivalent if known."""
    for key in ("model", "model_name"):
        current = config.get(key)
        if not isinstance(current, str):
            continue
        cheap = _CHEAP_MODEL_MAP.get(current.strip())
        if cheap is not None and cheap != current:
            rewritten = dict(config)
            rewritten[key] = cheap
            return rewritten
    return config
