"""LibraryTestWorkflow v1 template spec.

Stored in the workflow registry as JSON and executed via the existing workflow engine.
"""

from __future__ import annotations

from typing import Any


def library_test_workflow_spec_v1() -> dict[str, Any]:
    """Return a workflow spec JSON for the library testing hero flow.

    Inputs expected:
      - job_id: LibraryTestJob id
      - repo_path: local path to repository to test (Phase 1)
      - python: python executable (optional)
      - requirements: list[str] or str (pip requirement specs)
      - pytest_args: list[str] (optional)
    """

    # The workflow engine is node-typed; we keep this template minimal and lean by
    # delegating most work to a single node type that can evolve internally.
    return {
        "name": "LibraryTestWorkflow",
        "version": "1.0.0",
        "nodes": {
            "input": {"type": "input", "config": {}},
            "run_tests": {
                "type": "library_test",
                "config": {
                    "timeout_seconds": 1800,
                },
            },
            "output": {"type": "output", "config": {"keys": ["result"]}},
        },
        "edges": [
            {
                "id": "e1",
                "source": "input",
                "target": "run_tests",
                "source_handle": "default",
            },
            {
                "id": "e2",
                "source": "run_tests",
                "target": "output",
                "source_handle": "default",
            },
        ],
    }


__all__ = ["library_test_workflow_spec_v1"]
