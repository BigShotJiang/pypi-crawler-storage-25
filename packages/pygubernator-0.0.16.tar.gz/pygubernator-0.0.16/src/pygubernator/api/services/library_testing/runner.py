"""Local execution backend for LibraryTestWorkflow (Phase 1).

This runner is intentionally simple:
- Creates an isolated venv under a run directory
- Installs requirements
- Runs pytest and captures logs
- Produces a structured result dict suitable for audit/replay
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


def _run(cmd: list[str], *, cwd: Path, timeout: int) -> dict[str, Any]:
    p = subprocess.run(
        cmd,
        cwd=str(cwd),
        capture_output=True,
        text=True,
        timeout=timeout,
        env=dict(os.environ),
    )
    return {
        "cmd": cmd,
        "returncode": p.returncode,
        "stdout": p.stdout[-200_000:],  # cap to keep DB rows reasonable
        "stderr": p.stderr[-200_000:],
    }


def run_library_test(
    *,
    repo_path: str,
    requirements: list[str] | str | None,
    pytest_args: list[str] | None,
    timeout_seconds: int = 1800,
    python: str | None = None,
) -> dict[str, Any]:
    repo = Path(repo_path).resolve()
    if not repo.exists():
        raise FileNotFoundError(f"repo_path not found: {repo}")

    py = python or sys.executable
    pytest_args = list(pytest_args or ["-q"])
    reqs = [requirements] if isinstance(requirements, str) else list(requirements or [])

    with tempfile.TemporaryDirectory(prefix="pygub-libtest-") as td:
        workdir = Path(td)
        venv_dir = workdir / ".venv"
        logs: dict[str, Any] = {}

        logs["venv_create"] = _run(
            [py, "-m", "venv", str(venv_dir)],
            cwd=repo,
            timeout=min(300, timeout_seconds),
        )

        vpy = str(venv_dir / "bin" / "python")
        pip = [vpy, "-m", "pip"]
        logs["pip_upgrade"] = _run(
            pip + ["install", "-U", "pip", "setuptools", "wheel"],
            cwd=repo,
            timeout=min(600, timeout_seconds),
        )

        if reqs:
            logs["pip_install"] = _run(
                pip + ["install", *reqs],
                cwd=repo,
                timeout=min(1200, timeout_seconds),
            )
        else:
            logs["pip_install"] = {
                "cmd": [],
                "returncode": 0,
                "stdout": "",
                "stderr": "",
            }

        logs["pip_freeze"] = _run(
            pip + ["freeze"],
            cwd=repo,
            timeout=min(300, timeout_seconds),
        )

        # Run pytest
        logs["pytest"] = _run(
            [vpy, "-m", "pytest", *pytest_args],
            cwd=repo,
            timeout=timeout_seconds,
        )

        success = logs["pytest"]["returncode"] == 0
        result = {
            "success": success,
            "repo_path": str(repo),
            "requirements": reqs,
            "pytest_args": pytest_args,
            "logs": logs,
        }

        # Include a canonical JSON string for hashing/replay.
        result["result_json"] = json.dumps(result, sort_keys=True)
        return result


__all__ = ["run_library_test"]
