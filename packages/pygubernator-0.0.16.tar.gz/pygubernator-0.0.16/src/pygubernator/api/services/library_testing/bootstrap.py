"""Bootstrap helpers for LibraryTestWorkflow registry rows."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select

from pygubernator.api.services.library_testing.workflow_template import (
    library_test_workflow_spec_v1,
)
from pygubernator.db.models import Workflow, WorkflowVersion


def ensure_library_test_workflow(
    store: Any,
    *,
    workspace_id: str,
    actor: str = "system",
) -> tuple[Workflow, WorkflowVersion]:
    """Ensure a LibraryTestWorkflow exists in the DB for this workspace."""
    sess = store.session
    wf = sess.scalar(
        select(Workflow).where(
            Workflow.workspace_id == workspace_id,
            Workflow.name == "LibraryTestWorkflow",
        )
    )
    if wf is None:
        wf = store.create_workflow(
            name="LibraryTestWorkflow",
            description="Library/module test runner (Phase 1 hero)",
            owner="system",
        )
        store.commit()
        store.refresh(wf)

    versions = store.list_workflow_versions(wf.id)
    active = next((v for v in versions if v.active), None)
    if active is None:
        v = store.create_workflow_version(
            workflow_id=wf.id,
            version="1.0.0",
            spec_json=library_test_workflow_spec_v1(),
            active=True,
            created_by=actor,
        )
        store.commit()
        store.refresh(v)
        return wf, v

    return wf, active


__all__ = ["ensure_library_test_workflow"]
