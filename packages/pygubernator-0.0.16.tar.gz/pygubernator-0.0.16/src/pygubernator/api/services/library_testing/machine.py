"""Library testing lifecycle machine definition (pystator config dict)."""

from __future__ import annotations

from typing import Any


def library_test_job_machine_config() -> dict[str, Any]:
    """Return the LibraryTestJob pystator machine config.

    The lifecycle is intentionally ops-centric: it emphasizes clear states and
    debuggability over clever branching.
    """

    return {
        "meta": {
            "machine_name": "library_test_job",
            "version": "1.0.0",
        },
        "states": [
            {"name": "queued", "type": "initial"},
            {"name": "env_preparing", "type": "stable"},
            {"name": "deps_installing", "type": "stable"},
            {"name": "tests_running", "type": "stable"},
            {"name": "summarizing", "type": "stable"},
            {"name": "awaiting_approval", "type": "stable"},
            {"name": "publishing", "type": "stable"},
            {"name": "succeeded", "type": "terminal"},
            {"name": "failed", "type": "terminal"},
            {"name": "cancelled", "type": "terminal"},
            {"name": "quarantined", "type": "stable"},
        ],
        "transitions": [
            {"trigger": "enqueue", "source": "queued", "dest": "env_preparing"},
            {
                "trigger": "prepare_env_ok",
                "source": "env_preparing",
                "dest": "deps_installing",
            },
            {
                "trigger": "prepare_env_failed",
                "source": "env_preparing",
                "dest": "failed",
            },
            {
                "trigger": "install_ok",
                "source": "deps_installing",
                "dest": "tests_running",
            },
            {
                "trigger": "install_failed",
                "source": "deps_installing",
                "dest": "failed",
            },
            {
                "trigger": "tests_ok",
                "source": "tests_running",
                "dest": "summarizing",
            },
            {
                "trigger": "tests_failed",
                "source": "tests_running",
                "dest": "summarizing",
            },
            {
                "trigger": "summary_ok",
                "source": "summarizing",
                "dest": "publishing",
            },
            {
                "trigger": "summary_needs_approval",
                "source": "summarizing",
                "dest": "awaiting_approval",
            },
            {
                "trigger": "summary_failed",
                "source": "summarizing",
                "dest": "failed",
            },
            {
                "trigger": "approve_publish",
                "source": "awaiting_approval",
                "dest": "publishing",
            },
            {
                "trigger": "reject_publish",
                "source": "awaiting_approval",
                "dest": "failed",
            },
            {"trigger": "publish_ok", "source": "publishing", "dest": "succeeded"},
            {"trigger": "publish_failed", "source": "publishing", "dest": "failed"},
            {
                "trigger": "cancel",
                "source": [
                    "queued",
                    "env_preparing",
                    "deps_installing",
                    "tests_running",
                    "summarizing",
                    "awaiting_approval",
                    "publishing",
                    "quarantined",
                ],
                "dest": "cancelled",
            },
            {
                "trigger": "quarantine",
                "source": [
                    "env_preparing",
                    "deps_installing",
                    "tests_running",
                    "summarizing",
                    "awaiting_approval",
                    "publishing",
                ],
                "dest": "quarantined",
            },
            {"trigger": "requeue", "source": "quarantined", "dest": "queued"},
        ],
    }


__all__ = ["library_test_job_machine_config"]
