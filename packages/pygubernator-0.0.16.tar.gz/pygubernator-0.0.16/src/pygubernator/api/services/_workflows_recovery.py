"""Crash recovery for stale workflow runs."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from pygubernator.api._sse import broadcaster
from pygubernator.workflow._claiming import (
    WorkerIdentity,
    claim_run,
    release_claim,
    update_heartbeat,
)
from pygubernator.workflow._fsm import RunStatus, checked_status_update

logger = logging.getLogger(__name__)

_NODE_TIMEOUT = float(os.getenv("PYGUBERNATOR_NODE_TIMEOUT", "300"))
_WORKFLOW_TIMEOUT = float(os.getenv("PYGUBERNATOR_WORKFLOW_TIMEOUT", "600"))


def recover_stale_run(
    run_id: str,
    store: Any,
    worker: WorkerIdentity,
) -> dict[str, Any]:
    """Recover a stale workflow run from its checkpoint.

    Claims the run, loads the checkpoint, rebuilds the engine,
    and resumes execution.

    Args:
        run_id: ID of the stale run to recover.
        store: SQLAlchemy agent store.
        worker: Identity of the recovery worker.

    Returns:
        Result dict with success, output, errors, duration_ms.
    """
    from pygubernator.api.services._workflows import (
        build_node_registry,
    )
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow.config._loader import WorkflowLoader

    session: Session = store.session

    # Step 1: Claim the stale run.
    if not claim_run(session, run_id, worker):
        return {
            "success": False,
            "output": {},
            "errors": ["Run already claimed by another worker"],
            "duration_ms": 0,
        }

    run = store.get_workflow_run(run_id)
    if not run:
        return {
            "success": False,
            "output": {},
            "errors": ["Run not found"],
            "duration_ms": 0,
        }

    checkpoint = getattr(run, "checkpoint_json", None) or {}
    if not checkpoint or not checkpoint.get("node_results"):
        # No checkpoint — mark as failed, nothing to recover.
        # FSM: claimed → failed (force: may still be stale in edge cases)
        checked_status_update(
            run,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message="No checkpoint available for recovery",
            completed_at=datetime.now(UTC),
        )
        store.commit()
        release_claim(session, run_id, worker)
        return {
            "success": False,
            "output": {},
            "errors": ["No checkpoint available for recovery"],
            "duration_ms": 0,
        }

    # Step 2: Load the workflow spec from the version.
    version_id = getattr(run, "workflow_version_id", None)
    if not version_id:
        checked_status_update(
            run,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message="No workflow version for recovery",
            completed_at=datetime.now(UTC),
        )
        store.commit()
        release_claim(session, run_id, worker)
        return {
            "success": False,
            "output": {},
            "errors": ["No workflow version for recovery"],
            "duration_ms": 0,
        }

    version = store.get_workflow_version(version_id)
    if not version:
        checked_status_update(
            run,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message="Workflow version not found",
            completed_at=datetime.now(UTC),
        )
        store.commit()
        release_claim(session, run_id, worker)
        return {
            "success": False,
            "output": {},
            "errors": ["Workflow version not found"],
            "duration_ms": 0,
        }

    # Step 3: FSM transition claimed → running, then resume.
    checked_status_update(run, RunStatus.RUNNING.value)
    store.commit()

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(version.spec_json)
    except Exception as exc:
        checked_status_update(
            run,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message=f"Spec load failed: {exc}",
            completed_at=datetime.now(UTC),
        )
        store.commit()
        release_claim(session, run_id, worker)
        return {
            "success": False,
            "output": {},
            "errors": [f"Spec load failed: {exc}"],
            "duration_ms": 0,
        }

    registry = build_node_registry()

    from pygubernator.api.services._workflows import _BroadcastHandler
    from pygubernator.events._bus import EventBus

    event_bus = EventBus()
    event_bus.add_handler(_BroadcastHandler(run_id))

    def persist_step(node_id: str, result: Any) -> None:
        """Persist step result during recovery."""
        node_spec = spec.nodes.get(node_id)
        node_type = node_spec.node_type if node_spec else "unknown"
        step = store.create_workflow_step_run(
            workflow_run_id=run_id,
            node_id=node_id,
            node_type=node_type,
            status=result.status.value,
            input_json={},
        )
        store.update_workflow_step_run(
            step,
            output_json=result.output,
            output_handle=result.output_handle,
            error_message=result.error,
        )
        store.commit()

    def persist_checkpoint(ckpt: dict[str, Any]) -> None:
        """Persist checkpoint during recovery."""
        r = store.get_workflow_run(run_id)
        if r is not None:
            store.update_workflow_run(r, checkpoint_json=ckpt)
            store.commit()
        update_heartbeat(session, run_id, worker)

    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        persist_callback=persist_step,
        level_checkpoint_callback=persist_checkpoint,
        event_bus=event_bus,
        node_timeout=_NODE_TIMEOUT,
    )

    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            asyncio.wait_for(
                engine.run_from_checkpoint(checkpoint),
                timeout=_WORKFLOW_TIMEOUT,
            )
        )
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        checked_status_update(
            run,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message=f"Recovery failed: {exc}",
            completed_at=datetime.now(UTC),
            duration_ms=elapsed,
        )
        store.commit()
        release_claim(session, run_id, worker)
        return {
            "success": False,
            "output": {},
            "errors": [f"Recovery failed: {exc}"],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)
    final_status = (
        RunStatus.COMPLETED.value if wf_result.success else RunStatus.FAILED.value
    )
    checked_status_update(
        run,
        final_status,
        store=store,
        output_json=wf_result.output,
        error_message=("; ".join(wf_result.errors) if wf_result.errors else None),
        completed_at=datetime.now(UTC),
        duration_ms=elapsed,
    )
    store.commit()
    release_claim(session, run_id, worker)

    broadcaster.publish(
        run_id,
        {
            "type": "workflow_completed",
            "success": wf_result.success,
            "duration_ms": elapsed,
            "recovered": True,
        },
    )
    broadcaster.close(run_id)

    logger.info(
        "[RECOVERY] Run %s recovered: success=%s duration=%sms",
        run_id[:12],
        wf_result.success,
        elapsed,
    )
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
        "recovered": True,
    }
