"""Build the ``input_json`` summary we persist per workflow step.

Historically ``persist_step`` wrote ``input_json={}`` — the runtime config
never made it to the step row, so the UI had to decide what to show from
``node_type`` alone. This module produces a lightweight summary so
downstream renderers (today: the live-DAG agent badge from §6.6b) can
label each node with the agent / model / tool that actually ran without
a second fetch of the full spec.

The helper is intentionally narrow: it copies *only* a short allow-list
of identifying fields for the node types that benefit. Secrets, full
prompts, and large tool-config dicts stay out of the row on purpose so
the runs table doesn't balloon for long-running workflows.
"""

from __future__ import annotations

from typing import Any

# Node types we summarise into ``input_json["agent"]``. Adding more here
# should stay cheap — the goal is to surface a human-readable badge, not
# to mirror the full config.
_AGENT_NODE_TYPES: frozenset[str] = frozenset(
    {
        "agent",
        "dispatch_agent",
        "llm",
        "llm_planner",
    },
)


def _first_non_empty(config: dict[str, Any], keys: tuple[str, ...]) -> str | None:
    """Return the first ``str(config[key])`` that's non-empty, or None."""
    for key in keys:
        raw = config.get(key)
        if isinstance(raw, str):
            trimmed = raw.strip()
            if trimmed:
                return trimmed
        elif raw not in (None, "", [], {}):
            text = str(raw).strip()
            if text:
                return text
    return None


def build_step_input_summary(
    *,
    node_type: str,
    config: dict[str, Any] | None,
) -> dict[str, Any]:
    """Build the ``input_json`` summary for one workflow step row.

    Keeps the row small: agent-style nodes get an ``agent`` sub-dict
    with ``name`` / ``version`` / ``model`` / ``target_agent_id`` (only
    those that are set); everything else returns ``{}``.

    Args:
        node_type: The node's type name (``agent``, ``dispatch_agent``,
            ``llm``, ``llm_planner`` are summarised).
        config: The resolved node config dict from the workflow spec.
            ``None`` is tolerated and treated as empty.

    Returns:
        A JSON-serialisable dict. Empty when there's nothing useful to
        surface — callers can merge unconditionally.
    """
    cfg = config or {}
    if node_type not in _AGENT_NODE_TYPES:
        return {}

    agent: dict[str, Any] = {}
    name = _first_non_empty(cfg, ("agent_name", "agent_id", "agent"))
    if name is not None:
        agent["name"] = name
    version = _first_non_empty(cfg, ("agent_version", "version"))
    if version is not None:
        agent["version"] = version
    model = _first_non_empty(cfg, ("model", "model_name"))
    if model is not None:
        agent["model"] = model
    target = _first_non_empty(
        cfg,
        ("target_agent_id", "target_agent", "dispatch_target"),
    )
    if target is not None:
        agent["target_agent_id"] = target

    if not agent:
        return {}
    return {"agent": agent}


__all__ = ["build_step_input_summary"]
