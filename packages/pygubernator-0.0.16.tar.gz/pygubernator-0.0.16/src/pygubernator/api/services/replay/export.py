"""Audit bundle export helpers (Phase 1)."""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Any


def _canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def chain_hash(events: list[dict[str, Any]], *, seed: str = "") -> list[dict[str, Any]]:
    """Add tamper-evident chain hashes to an ordered event list."""
    prev = seed
    out: list[dict[str, Any]] = []
    for e in events:
        payload = {"prev": prev, "event": e}
        h = sha256(_canon(payload).encode("utf-8")).hexdigest()
        out.append({**e, "_chain_prev": prev, "_chain_hash": h})
        prev = h
    return out


__all__ = ["chain_hash"]
