"""Run diff helpers (Phase 1).

Phase 1 focuses on workflow runs (workflow_step_runs + recorded outputs).
"""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Any


def _canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def hash_json(obj: Any) -> str:
    return sha256(_canon(obj).encode("utf-8")).hexdigest()


def diff_step_outputs(
    *,
    left_steps: list[dict[str, Any]],
    right_steps: list[dict[str, Any]],
) -> dict[str, Any]:
    """Diff two step timelines (by node_id)."""
    left_by = {s.get("node_id"): s for s in left_steps}
    right_by = {s.get("node_id"): s for s in right_steps}
    all_nodes = sorted({*left_by.keys(), *right_by.keys()})

    diffs: list[dict[str, Any]] = []
    for nid in all_nodes:
        left_row = left_by.get(nid)
        right_row = right_by.get(nid)
        if left_row is None or right_row is None:
            diffs.append(
                {
                    "node_id": nid,
                    "kind": "missing",
                    "left": bool(left_row),
                    "right": bool(right_row),
                }
            )
            continue
        if left_row.get("status") != right_row.get("status"):
            diffs.append(
                {
                    "node_id": nid,
                    "kind": "status_changed",
                    "node_type": (
                        left_row.get("node_type") or right_row.get("node_type")
                    ),
                    "left_status": left_row.get("status"),
                    "right_status": right_row.get("status"),
                }
            )
        lh = hash_json(left_row.get("output_json", {}))
        rh = hash_json(right_row.get("output_json", {}))
        if lh != rh:
            left_keys = sorted(list((left_row.get("output_json") or {}).keys()))
            right_keys = sorted(list((right_row.get("output_json") or {}).keys()))
            diffs.append(
                {
                    "node_id": nid,
                    "kind": "output_changed",
                    "node_type": (
                        left_row.get("node_type") or right_row.get("node_type")
                    ),
                    "left_status": left_row.get("status"),
                    "right_status": right_row.get("status"),
                    "left_keys": left_keys[:40],
                    "right_keys": right_keys[:40],
                    "left_hash": lh,
                    "right_hash": rh,
                }
            )

    first = diffs[0] if diffs else None
    return {"same": first is None, "first_divergence": first, "diffs": diffs}


__all__ = ["diff_step_outputs", "hash_json"]
