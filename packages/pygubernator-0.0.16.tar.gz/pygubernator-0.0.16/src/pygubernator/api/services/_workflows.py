"""Workflow execution service — business logic extracted from routes."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from pygubernator.api._sse import broadcaster
from pygubernator.api.services._step_input_summary import build_step_input_summary
from pygubernator.events._bus import AgentEvent, AgentEventType, EventBus
from pygubernator.workflow._fsm import RunStatus, checked_status_update
from pygubernator.workflow._registry import NodeTypeRegistry
from pygubernator.workflow._types import WorkflowResult

logger = logging.getLogger(__name__)

_WORKFLOW_TIMEOUT = float(os.getenv("PYGUBERNATOR_WORKFLOW_TIMEOUT", "600"))
_NODE_TIMEOUT = float(os.getenv("PYGUBERNATOR_NODE_TIMEOUT", "300"))


def _rollback_store_session(store: Any, *, reason: str) -> None:
    """Rollback the store session after a persistence failure."""
    session = getattr(store, "session", None)
    rollback = getattr(session, "rollback", None)
    if callable(rollback):
        try:
            rollback()
        except Exception as exc:
            logger.warning("[SVC] rollback after %s failed: %s", reason, exc)


async def _run_with_timeout(
    engine: Any,
    input_json: dict[str, Any],
    timeout: float,
    variables: dict[str, Any] | None = None,
) -> WorkflowResult:
    """Execute engine.run() with an overall timeout guard."""
    return await asyncio.wait_for(
        engine.run(input_json, variables=variables),
        timeout=timeout,
    )


def _snapshot_agent_versions(spec_json: dict[str, Any]) -> dict[str, str]:
    """Resolve each ``agent_id``-referencing node to a specific version now.

    Walks the spec, finds agent nodes that reference a registered Agent by
    id (without an explicit ``agent_version_id`` pin), looks up the Agent's
    current active version, and returns a ``{agent_id: version_id}`` map.
    This snapshot is stashed on the run's variables as ``__pinned_agents__``
    so the resolver can honour the run-start decision even if someone
    activates a newer version mid-run.
    """
    nodes = spec_json.get("nodes") or {}
    if not isinstance(nodes, dict):
        return {}
    references: set[str] = set()
    for node in nodes.values():
        if not isinstance(node, dict):
            continue
        if node.get("type") not in ("agent", "dispatch_agent"):
            continue
        config = node.get("config") or {}
        if not isinstance(config, dict):
            continue
        if config.get("agent_version_id"):
            continue  # explicit pin overrides snapshot; no action needed.
        agent_id = config.get("agent_id")
        if isinstance(agent_id, str) and agent_id.strip():
            references.add(agent_id.strip())

    if not references:
        return {}

    from pygubernator.db._agents import get_agent
    from pygubernator.db.session import _get_session_factory

    factory = _get_session_factory()
    session = factory()
    try:
        pinned: dict[str, str] = {}
        for agent_id in references:
            agent = get_agent(session, agent_id)
            if agent is None or agent.archived:
                # Skip — the resolver will emit a clear error at execute time.
                continue
            if agent.current_version_id:
                pinned[agent_id] = agent.current_version_id
        return pinned
    finally:
        session.close()


def build_node_registry() -> NodeTypeRegistry:
    """Build a NodeTypeRegistry with all built-in node factories.

    Delegates to :func:`~pygubernator.workflow.build_default_registry`
    in the stateless core.  This thin wrapper preserves the existing
    API surface used by route handlers.

    Returns:
        Configured NodeTypeRegistry instance with all standard node types.
    """
    from pygubernator.workflow._default_registry import build_default_registry

    return build_default_registry()


def execute_workflow(
    spec_json: dict[str, Any],
    input_json: dict[str, Any],
    store: Any,
    run_id: str,
    *,
    session_id: str | None = None,
    cancellation_check: Callable[[], bool] | None = None,
    heartbeat_fn: Callable[[], None] | None = None,
) -> dict[str, Any]:
    """Build and execute a workflow spec, persisting step results.

    Args:
        spec_json: Workflow spec as a JSON dict.
        input_json: Input data for the workflow.
        store: :class:`~pygubernator.agent_store.SQLAlchemyAgentStore` for persistence.
        run_id: Workflow run ID for step association.
        session_id: Optional session ID for multi-turn memory persistence.
        cancellation_check: If set, called before each DAG level; return True to stop.
        heartbeat_fn: If set, called periodically to update the heartbeat.

    Returns:
        Result dict with success, output, errors, duration_ms, and optional cancelled.
    """
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow._types import NodeResult
    from pygubernator.workflow.config._loader import WorkflowLoader

    logger.info(
        "[SVC] execute_workflow called: run_id=%s, nodes=%d, input_keys=%s",
        run_id[:12] if run_id else "?",
        len(spec_json.get("nodes", {})),
        list(input_json.keys()),
    )

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(spec_json)
    except Exception as exc:
        logger.error("[SVC] Spec load failed: %s", exc, exc_info=True)
        return {
            "success": False,
            "output": {},
            "errors": [f"Invalid spec: {exc}"],
            "duration_ms": 0,
        }

    logger.info(
        "[SVC] Spec loaded: %d nodes, node_timeout=%ss, workflow_timeout=%ss",
        len(spec.nodes),
        _NODE_TIMEOUT,
        _WORKFLOW_TIMEOUT,
    )
    for nid, ns in spec.nodes.items():
        logger.info(
            "[SVC]   node %s: type=%s config_keys=%s",
            nid,
            ns.node_type,
            list(ns.config.keys())[:6],
        )

    # Guardrail: the overall workflow timeout should never be shorter than the
    # longest node timeout, otherwise long-running nodes can perform side effects
    # (e.g. tool calls) and then still be cut off by the workflow-level timeout.
    #
    # We treat missing/invalid per-node overrides as the global node timeout.
    max_node_timeout_s = float(_NODE_TIMEOUT)
    for _nid, _ns in spec.nodes.items():
        timeout_s = _ns.failure_policy.timeout_seconds
        if timeout_s is None:
            continue
        max_node_timeout_s = max(max_node_timeout_s, float(timeout_s))

    effective_workflow_timeout_s = max(
        float(_WORKFLOW_TIMEOUT), max_node_timeout_s + 30.0
    )
    if effective_workflow_timeout_s != float(_WORKFLOW_TIMEOUT):
        logger.info(
            "[SVC] Adjusted workflow timeout to %ss (max node timeout=%ss)",
            effective_workflow_timeout_s,
            max_node_timeout_s,
        )

    # Always persist a bootstrap trace row and commit so GET .../trace is never
    # empty while the run is in progress (execute API returns before the worker
    # finishes; without an early commit, step rows are invisible to other sessions).
    _run_started_at = datetime.now(UTC)
    _marker = store.create_workflow_step_run(
        workflow_run_id=run_id,
        node_id="__run__",
        node_type="workflow_run",
        status="completed",
        input_json={},
    )
    store.update_workflow_step_run(
        _marker,
        output_json={
            "event": "run_started",
            "message": "Workflow execution started",
            "workflow": spec.name,
        },
        started_at=_run_started_at,
        completed_at=_run_started_at,
        duration_ms=0,
    )
    store.commit()

    registry = build_node_registry()

    # Inject stored credentials as env vars for tool factories
    try:
        from pygubernator.config.integrations import inject_credentials

        inject_credentials(store.session)
    except Exception as exc:
        logger.warning("Credential injection failed: %s", exc)

    def persist_step(node_id: str, result: NodeResult) -> None:
        """Persist a single step execution result."""
        node_spec = spec.nodes.get(node_id)
        node_type = node_spec.node_type if node_spec else "unknown"
        # Capture a lightweight summary of the node's resolved config so
        # the UI can render identifying metadata (agent badge, model
        # name, dispatch target) without a second fetch of the spec.
        # The helper returns an empty dict for nodes that don't have a
        # useful summary, so this stays cheap for non-agent steps.
        input_summary = build_step_input_summary(
            node_type=node_type,
            config=node_spec.config if node_spec else None,
        )
        step = store.create_workflow_step_run(
            workflow_run_id=run_id,
            node_id=node_id,
            node_type=node_type,
            status=result.status.value,
            input_json=input_summary,
        )
        child_events = step_event_buffer.flush(node_id)
        merged_output: dict[str, Any] = dict(result.output or {})
        if child_events:
            merged_output["_child_events"] = child_events
        store.update_workflow_step_run(
            step,
            output_json=merged_output,
            output_handle=result.output_handle,
            error_message=result.error,
        )
        # Dual-write the events into the dedicated ``workflow_step_events``
        # table so future readers can filter/aggregate without parsing the
        # JSON blob. The blob is kept in sync above for UI backward-compat
        # while the cut-over is in progress. A best-effort guard keeps the
        # dual-write from breaking runs on stores that don't implement it.
        if child_events:
            try:
                store.create_workflow_step_events(
                    step_run_id=step.id,
                    workflow_run_id=run_id,
                    events=child_events,
                )
            except (AttributeError, NotImplementedError) as exc:
                logger.debug(
                    "Skipped workflow_step_events dual-write for %s: %s",
                    node_id,
                    exc,
                )

        # Record deterministic outputs for replay (Phase 1: node-scoped).
        try:
            if node_type == "library_test" and result.status.value != "failed":
                payload = result.output.get("result")
                if isinstance(payload, dict):
                    from pygubernator.db import repositories as _repos

                    _repos.upsert_recorded_output(
                        store.session,
                        workspace_id=getattr(store, "workspace_id", "default"),
                        workflow_run_id=run_id,
                        node_id=node_id,
                        payload_json=payload,
                    )
        except Exception as exc:
            logger.debug("recorded output store failed: %s", exc)

        # Commit each step so (a) the trace is visible while the run is in progress
        # and (b) we release the SQLite write transaction before nodes open other
        # connections to the same file (e.g. agent memory with db_path=pygubernator.db).
        commit_fn = getattr(store, "commit", None)
        if callable(commit_fn):
            try:
                commit_fn()
            except Exception as exc:
                logger.warning(
                    "[SVC] commit after step %s failed: %s",
                    node_id,
                    exc,
                )
                _rollback_store_session(
                    store,
                    reason=f"step commit failure for {node_id}",
                )

    def _check_cancelled() -> bool:
        sess = getattr(store, "session", None)
        if sess is not None:
            sess.expire_all()
        run_row = store.get_workflow_run(run_id)
        if run_row is None:
            return False
        status = getattr(run_row, "status", None)
        return status == "cancelled"

    should_cancel = (
        cancellation_check if cancellation_check is not None else _check_cancelled
    )

    def persist_level_checkpoint(checkpoint: dict[str, Any]) -> None:
        """Persist checkpoint after each topological level for recovery."""
        run_row = store.get_workflow_run(run_id)
        if run_row is not None:
            store.update_workflow_run(run_row, checkpoint_json=checkpoint)
            commit_fn = getattr(store, "commit", None)
            if callable(commit_fn):
                try:
                    commit_fn()
                except Exception as exc:
                    logger.warning("[SVC] checkpoint commit failed: %s", exc)
                    _rollback_store_session(
                        store,
                        reason="checkpoint commit failure",
                    )
        if heartbeat_fn is not None:
            with contextlib.suppress(Exception):
                heartbeat_fn()

    # Set up event bus for SSE broadcasting
    event_bus = EventBus()
    event_bus.add_handler(_BroadcastHandler(run_id))
    step_event_buffer = _StepEventBuffer()
    event_bus.add_handler(step_event_buffer)

    # Derive workflow_id from the store so nodes (and the event stream) can
    # correlate across runs. This matches how LLMAgent tags its events.
    wf_run_row = store.get_workflow_run(run_id) if run_id else None
    workflow_id = getattr(wf_run_row, "workflow_id", None)

    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        persist_callback=persist_step,
        level_checkpoint_callback=persist_level_checkpoint,
        event_bus=event_bus,
        node_timeout=_NODE_TIMEOUT,
        should_cancel=should_cancel,
        run_id=run_id,
        workflow_id=workflow_id,
    )

    variables: dict[str, Any] = {}
    if session_id:
        variables["__session_id__"] = session_id

    pinned_agents = _snapshot_agent_versions(spec_json)
    if pinned_agents:
        variables["__pinned_agents__"] = pinned_agents
        logger.info(
            "[SVC] pinned %d agent version(s) for run %s",
            len(pinned_agents),
            run_id,
        )

    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            _run_with_timeout(
                engine, input_json, effective_workflow_timeout_s, variables
            )
        )
    except TimeoutError:
        elapsed = int((time.monotonic() - start) * 1000)
        logger.error(
            "Workflow execution timed out after %ss",
            effective_workflow_timeout_s,
        )
        broadcaster.publish(
            run_id,
            {"type": "workflow_completed", "success": False, "duration_ms": elapsed},
        )
        broadcaster.close(run_id)
        return {
            "success": False,
            "output": {},
            "errors": [
                f"Workflow execution timed out after {effective_workflow_timeout_s}s"
            ],
            "duration_ms": elapsed,
        }
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        parts = [f"{type(exc).__name__}: {exc}"]
        cause = exc.__cause__
        while cause:
            parts.append(f"  caused by {type(cause).__name__}: {cause}")
            cause = cause.__cause__
        error_msg = "\n".join(parts)
        logger.error("Workflow execution failed: %s", error_msg, exc_info=True)
        broadcaster.publish(
            run_id,
            {"type": "workflow_completed", "success": False, "duration_ms": elapsed},
        )
        broadcaster.close(run_id)
        return {
            "success": False,
            "output": {},
            "errors": [error_msg],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)

    if wf_result.awaiting_approval:
        return _handle_approval_pause(
            wf_result,
            store,
            run_id,
            elapsed,
        )

    payload: dict[str, Any] = {
        "type": "workflow_completed",
        "success": wf_result.success,
        "duration_ms": elapsed,
    }
    if wf_result.cancelled:
        payload["cancelled"] = True
    broadcaster.publish(run_id, payload)
    broadcaster.close(run_id)
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
        "cancelled": wf_result.cancelled,
    }


def _handle_approval_pause(
    wf_result: WorkflowResult,
    store: Any,
    run_id: str,
    elapsed: int,
) -> dict[str, Any]:
    """Persist an approval record and pause the workflow run.

    Args:
        wf_result: The workflow result with approval data.
        store: Agent store for DB persistence.
        run_id: Current workflow run ID.
        elapsed: Elapsed time in milliseconds.

    Returns:
        Result dict with awaiting_approval flag.
    """
    from pygubernator.db.models import WorkflowApproval

    output = wf_result.output
    checkpoint = output.get("__checkpoint__", {})
    node_id = output.get("approval_node_id", "")
    prompt = output.get("approval_prompt", "")
    timeout = output.get("timeout_seconds", 86400)
    approval_request = {
        "allowed_decisions": list(
            output.get("allowed_decisions", ["approved", "rejected"])
        ),
        "require_comment": bool(output.get("require_comment", False)),
        "reviewer_label": str(output.get("reviewer_label", "") or ""),
        "details_markdown": str(output.get("details_markdown", "") or ""),
    }
    checkpoint = dict(checkpoint)
    checkpoint["__approval_request__"] = approval_request

    approval = WorkflowApproval(
        workflow_run_id=run_id,
        node_id=node_id,
        prompt=prompt,
        status="pending",
        checkpoint_json=checkpoint,
        timeout_seconds=timeout,
    )
    sess = getattr(store, "session", None)
    if sess is not None:
        sess.add(approval)

    run_row = store.get_workflow_run(run_id)
    if run_row is not None:
        checked_status_update(
            run_row,
            RunStatus.AWAITING_APPROVAL.value,
            store=store,
        )
    store.commit()

    broadcaster.publish(
        run_id,
        {
            "type": "workflow_awaiting_approval",
            "node_id": node_id,
            "prompt": prompt,
            "duration_ms": elapsed,
        },
    )
    return {
        "success": False,
        "output": {
            "approval_node_id": node_id,
            "approval_prompt": prompt,
            **approval_request,
        },
        "errors": [],
        "duration_ms": elapsed,
        "awaiting_approval": True,
        "approval_id": approval.id,
    }


def resume_workflow(
    approval_id: str,
    response_data: dict[str, Any],
    store: Any,
    actor: str,
) -> dict[str, Any]:
    """Resume a paused workflow after human approval.

    Args:
        approval_id: The approval record ID.
        response_data: Human response (approved, comment, etc.).
        store: Agent store for DB persistence.
        actor: Username of the responder.

    Returns:
        Result dict from the resumed workflow execution.
    """
    from pygubernator.db.models import WorkflowApproval
    from pygubernator.workflow._engine import WorkflowEngine
    from pygubernator.workflow.config._loader import WorkflowLoader

    sess = getattr(store, "session", None)
    if sess is None:
        return _error_result("No DB session available")

    approval = sess.get(WorkflowApproval, approval_id)
    if approval is None:
        return _error_result("Approval not found")
    if approval.status != "pending":
        return _error_result(f"Approval already resolved: {approval.status}")

    decision = str(response_data.get("decision", "") or "").strip()
    if not decision:
        return _error_result("Approval decision is required")
    approval.status = decision
    approval.response_json = response_data
    approval.responded_by = actor
    approval.responded_at = datetime.now(UTC)

    run_id = approval.workflow_run_id
    run_row = store.get_workflow_run(run_id)
    if run_row is None:
        return _error_result("Workflow run not found")

    if decision in {"rejected", "changes_requested"}:
        message = (
            "Approval rejected"
            if decision == "rejected"
            else "Changes requested during approval"
        )
        checked_status_update(
            run_row,
            RunStatus.FAILED.value,
            store=store,
            error_message=message,
            completed_at=datetime.now(UTC),
        )
        store.commit()
        return {
            "success": False,
            "output": {},
            "errors": [message],
            "duration_ms": 0,
        }

    checked_status_update(run_row, RunStatus.RUNNING.value, store=store)
    store.commit()

    checkpoint = dict(approval.checkpoint_json or {})
    node_id = approval.node_id

    # Rebuild workflow spec from the version
    wf_version_id = run_row.workflow_version_id
    if not wf_version_id:
        return _error_result("No workflow version on run")

    versions = store.list_workflow_versions(run_row.workflow_id)
    version = next(
        (v for v in versions if v.id == wf_version_id),
        None,
    )
    if version is None:
        return _error_result("Workflow version not found")

    loader = WorkflowLoader()
    try:
        spec = loader.load_dict(version.spec_json)
    except Exception as exc:
        return _error_result(f"Invalid spec: {exc}")

    registry = build_node_registry()
    engine = WorkflowEngine(
        spec=spec,
        registry=registry,
        node_timeout=_NODE_TIMEOUT,
    )

    start = time.monotonic()
    try:
        wf_result = asyncio.run(
            asyncio.wait_for(
                engine.run_from_checkpoint(
                    checkpoint,
                    approval_node_id=node_id,
                    approval_output=response_data,
                ),
                timeout=_WORKFLOW_TIMEOUT,
            )
        )
    except Exception as exc:
        elapsed = int((time.monotonic() - start) * 1000)
        logger.error(
            "Resume workflow failed: %s",
            exc,
            exc_info=True,
        )
        checked_status_update(
            run_row,
            RunStatus.FAILED.value,
            store=store,
            force=True,
            error_message=str(exc),
            completed_at=datetime.now(UTC),
            duration_ms=elapsed,
        )
        store.commit()
        return {
            "success": False,
            "output": {},
            "errors": ["Workflow resume failed"],
            "duration_ms": elapsed,
        }

    elapsed = int((time.monotonic() - start) * 1000)

    if wf_result.awaiting_approval:
        return _handle_approval_pause(
            wf_result,
            store,
            run_id,
            elapsed,
        )

    final_status = (
        RunStatus.COMPLETED.value if wf_result.success else RunStatus.FAILED.value
    )
    checked_status_update(
        run_row,
        final_status,
        store=store,
        output_json=wf_result.output,
        completed_at=datetime.now(UTC),
        duration_ms=elapsed,
        error_message=("; ".join(wf_result.errors) if wf_result.errors else None),
    )
    store.commit()
    return {
        "success": wf_result.success,
        "output": wf_result.output,
        "errors": wf_result.errors,
        "duration_ms": elapsed,
    }


def _error_result(msg: str) -> dict[str, Any]:
    """Build a failure result dict with a single error message."""
    return {
        "success": False,
        "output": {},
        "errors": [msg],
        "duration_ms": 0,
    }


_TRACED_AGENT_EVENT_TYPES: frozenset[AgentEventType] = frozenset(
    {
        AgentEventType.TOOL_CALL_STARTED,
        AgentEventType.TOOL_CALL_COMPLETED,
        AgentEventType.TOOL_CALL_FAILED,
        AgentEventType.LLM_REQUEST_STARTED,
        AgentEventType.LLM_RESPONSE_RECEIVED,
    }
)

_AGENT_NODE_ID_PREFIX = "agent_node_"


def _workflow_node_id_from_agent_id(agent_id: str | None) -> str | None:
    """Recover the workflow node id from an LLMAgent's ``agent_id`` tag.

    ``AgentNode`` tags its internal ``LLMAgent`` as ``agent_node_<node_id>``
    so events can be grouped back to the originating DAG node. Events from
    agents that don't follow that convention (standalone ``LLMAgent`` runs)
    return ``None``.
    """
    if not isinstance(agent_id, str):
        return None
    if agent_id.startswith(_AGENT_NODE_ID_PREFIX):
        return agent_id[len(_AGENT_NODE_ID_PREFIX) :] or None
    return None


class _StepEventBuffer:
    """Buffer tool-call + LLM events per workflow node for later persistence.

    Events arrive as ``AgentEvent``s through the run's :class:`EventBus`.
    We keep them in memory keyed by workflow node id, then flush into the
    step row's ``output_json["_child_events"]`` when the node finishes
    (triggered by :func:`persist_step`). The result is a nested trace the
    UI can render without a schema migration.
    """

    def __init__(self) -> None:
        self._events: dict[str, list[dict[str, Any]]] = {}

    async def handle(self, event: AgentEvent) -> None:
        """Record tool/LLM events keyed by their originating workflow node."""
        if event.event_type not in _TRACED_AGENT_EVENT_TYPES:
            return
        node_id = _workflow_node_id_from_agent_id(event.agent_id)
        if node_id is None:
            return
        self._events.setdefault(node_id, []).append(
            {
                "type": event.event_type.value,
                "timestamp": event.timestamp,
                "data": dict(event.data),
            }
        )

    def flush(self, node_id: str) -> list[dict[str, Any]]:
        """Return and discard buffered events for the given workflow node."""
        return self._events.pop(node_id, [])


class _BroadcastHandler:
    """EventHandler that publishes workflow events to SSEBroadcaster."""

    _EVENT_MAP = {
        AgentEventType.WORKFLOW_STARTED: "workflow_started",
        AgentEventType.WORKFLOW_COMPLETED: "workflow_completed",
        AgentEventType.WORKFLOW_NODE_STARTED: "node_started",
        AgentEventType.WORKFLOW_NODE_COMPLETED: "node_completed",
        AgentEventType.WORKFLOW_NODE_FAILED: "node_failed",
        AgentEventType.TOOL_CALL_STARTED: "tool_call_started",
        AgentEventType.TOOL_CALL_COMPLETED: "tool_call_completed",
        AgentEventType.TOOL_CALL_FAILED: "tool_call_failed",
        AgentEventType.LLM_REQUEST_STARTED: "llm_request_started",
        AgentEventType.LLM_RESPONSE_RECEIVED: "llm_response_received",
        AgentEventType.LLM_THINKING_DELTA: "llm_thinking_delta",
    }

    def __init__(self, run_id: str) -> None:
        self._run_id = run_id

    async def handle(self, event: AgentEvent) -> None:
        """Forward relevant workflow events to the SSE broadcaster."""
        sse_type = self._EVENT_MAP.get(event.event_type)
        if sse_type is None:
            return  # Ignore non-workflow events

        payload: dict[str, Any] = {
            "type": sse_type,
            "timestamp": event.timestamp,
            **event.data,
        }
        # Attach the workflow node id for child events so the client can
        # group them under the parent step without parsing agent_id.
        node_id = _workflow_node_id_from_agent_id(event.agent_id)
        if node_id is not None:
            payload.setdefault("node_id", node_id)
        broadcaster.publish(self._run_id, payload)
