"""Server config table and PATCH for ``pygubernator.cfg`` (admin settings UI)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pygubernator import __version__ as pygubernator_version
from pygubernator.config import ControlPlaneSettings, get_api_url
from pygubernator.config.auth import get_auth_service_url, is_auth_disabled
from pygubernator.config.cfg_file_update import (
    MIRROR_TO_USER_SCOPED_SECTIONS,
    config_file_path_display,
    env_overrides,
    merge_and_write,
    normalize_bool_for_cfg,
    normalize_float_for_cfg,
    normalize_int_for_cfg,
    read_cfg_option,
    resolve_config_path_for_write,
    resolve_user_scoped_cfg_path_for_write,
)
from pygubernator.config.database import get_database_url
from pygubernator.config.ui import get_ui_app_name, get_ui_theme

_MAX_PATCH_KEYS = 64

PATCHABLE: dict[str, tuple[str, str]] = {
    "PYGUBERNATOR_UI_APP_NAME": ("ui", "string"),
    "PYGUBERNATOR_UI_THEME": ("ui", "string"),
    "PYGUBERNATOR_DATABASE_URL": ("database", "string"),
    "PYGUBERNATOR_API_URL": ("control_plane", "string"),
    "PYGUBERNATOR_API_HOST": ("control_plane", "string"),
    "PYGUBERNATOR_API_PORT": ("control_plane", "int_min_1"),
    "PYGUBERNATOR_UI_HOST": ("control_plane", "string"),
    "PYGUBERNATOR_UI_PORT": ("control_plane", "int_min_1"),
    "PYGUBERNATOR_ALLOW_ORIGINS": ("control_plane", "string"),
    "PYGUBERNATOR_EVENT_RETENTION_DAYS": ("control_plane", "int_min_1"),
}


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


def _auth_label() -> str:
    mode = _auth_mode_summary()
    if mode == "open_no_login":
        return "Open (no login)"
    if mode == "external_oidc":
        return "External OAuth/OIDC"
    return "Built-in JWT users"


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _database_driver_kind(url: str | None) -> str:
    if not url or not str(url).strip():
        return "sqlite_default"
    u = str(url).strip().lower()
    if u.startswith("sqlite"):
        return "sqlite"
    if u.startswith(("postgresql", "postgres")):
        return "postgresql"
    if u.startswith("mysql"):
        return "mysql"
    return "other"


def _row(
    *,
    row_id: str,
    env_key: str,
    section: str,
    kind: str,
    effective_display: str,
    source_hint: str = "",
    editable: bool = True,
) -> dict[str, Any]:
    locked = bool(env_key) and env_overrides(env_key)
    cfg_v = read_cfg_option(section, env_key) if env_key and section else None
    patch_ok = bool(env_key and env_key in PATCHABLE and editable)
    return {
        "id": row_id,
        "env_key": env_key or None,
        "section": section,
        "kind": kind,
        "effective_display": effective_display,
        "source_hint": source_hint,
        "env_locked": locked,
        "cfg_value": cfg_v,
        "editable": patch_ok and not locked,
    }


def build_server_config_rows() -> list[dict[str, Any]]:
    s = ControlPlaneSettings.from_env()
    raw_db = get_database_url()
    rows: list[dict[str, Any]] = []

    rows.append(
        _row(
            row_id="ui_app_name",
            env_key="PYGUBERNATOR_UI_APP_NAME",
            section="ui",
            kind="string",
            effective_display=get_ui_app_name(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="ui_theme",
            env_key="PYGUBERNATOR_UI_THEME",
            section="ui",
            kind="string",
            effective_display=get_ui_theme(),
            source_hint="env overrides [ui]",
        )
    )
    rows.append(
        _row(
            row_id="release_version",
            env_key="",
            section="release",
            kind="readonly",
            effective_display=pygubernator_version or "—",
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="api_url",
            env_key="PYGUBERNATOR_API_URL",
            section="control_plane",
            kind="string",
            effective_display=get_api_url(),
            source_hint="env overrides [control_plane]",
        )
    )
    rows.append(
        _row(
            row_id="api_host",
            env_key="PYGUBERNATOR_API_HOST",
            section="control_plane",
            kind="string",
            effective_display=s.api_host,
        )
    )
    rows.append(
        _row(
            row_id="api_port",
            env_key="PYGUBERNATOR_API_PORT",
            section="control_plane",
            kind="number",
            effective_display=str(s.api_port),
        )
    )
    rows.append(
        _row(
            row_id="ui_host",
            env_key="PYGUBERNATOR_UI_HOST",
            section="control_plane",
            kind="string",
            effective_display=s.ui_host,
        )
    )
    rows.append(
        _row(
            row_id="ui_port",
            env_key="PYGUBERNATOR_UI_PORT",
            section="control_plane",
            kind="number",
            effective_display=str(s.ui_port),
        )
    )
    rows.append(
        _row(
            row_id="allow_origins",
            env_key="PYGUBERNATOR_ALLOW_ORIGINS",
            section="control_plane",
            kind="string",
            effective_display=s.allow_origins,
        )
    )
    rows.append(
        _row(
            row_id="event_retention",
            env_key="PYGUBERNATOR_EVENT_RETENTION_DAYS",
            section="control_plane",
            kind="number",
            effective_display=str(s.event_retention_days),
        )
    )
    rows.append(
        _row(
            row_id="auth_mode",
            env_key="",
            section="[auth]",
            kind="readonly",
            effective_display=_auth_label(),
            editable=False,
        )
    )
    rows.append(
        _row(
            row_id="database_url",
            env_key="PYGUBERNATOR_DATABASE_URL",
            section="database",
            kind="password",
            effective_display=_mask_database_url(raw_db) or "(default sqlite)",
            source_hint="env overrides [database]",
        )
    )
    rows.append(
        _row(
            row_id="database_driver",
            env_key="",
            section="[database]",
            kind="readonly",
            effective_display=f"Driver: {_database_driver_kind(raw_db)}",
            editable=False,
        )
    )
    return rows


def get_server_config_bundle() -> dict[str, Any]:
    write_target = str(resolve_config_path_for_write())
    user_target = str(resolve_user_scoped_cfg_path_for_write())
    return {
        "config_file_resolved": config_file_path_display(),
        "config_write_target": write_target,
        "features_config_write_target": user_target,
        "rows": build_server_config_rows(),
    }


def apply_server_config_patch(updates: dict[str, Any]) -> tuple[Path, list[str]]:
    if not updates:
        raise ValueError("no updates provided")
    if len(updates) > _MAX_PATCH_KEYS:
        raise ValueError(f"too many keys (max {_MAX_PATCH_KEYS})")

    section_blobs: dict[str, dict[str, str]] = {}
    written: list[str] = []

    for env_key, raw in updates.items():
        if env_key not in PATCHABLE:
            raise ValueError(f"unknown or non-editable key: {env_key!r}")
        if env_overrides(env_key):
            raise ValueError(
                f"{env_key} is set in the process environment; "
                "unset it to manage via file"
            )
        section, kind = PATCHABLE[env_key]
        if kind == "bool":
            val = normalize_bool_for_cfg(raw)
        elif kind == "int_min_1":
            val = normalize_int_for_cfg(raw, min_val=1)
        elif kind == "float_0_1":
            val = normalize_float_for_cfg(raw, min_val=0.0, max_val=1.0)
        elif kind == "string":
            val = str(raw).strip()
        else:
            raise ValueError(f"internal: unknown kind {kind!r}")

        section_blobs.setdefault(section, {})[env_key] = val
        written.append(env_key)

    path = merge_and_write(section_blobs)
    mirror_sections = {
        s: section_blobs[s]
        for s in MIRROR_TO_USER_SCOPED_SECTIONS
        if s in section_blobs
    }
    if mirror_sections:
        alt = resolve_user_scoped_cfg_path_for_write()
        if alt.resolve() != path.resolve():
            merge_and_write(mirror_sections, target_path=alt)
    return path, written
