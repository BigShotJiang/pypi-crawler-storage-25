"""Validation helpers for tool catalog references in specs."""

from __future__ import annotations

from typing import Any


def _validate_tool_ref(
    *,
    tool_id: str,
    tool_version_id: str,
    store: Any,
    location: str,
) -> list[str]:
    errors: list[str] = []
    tool = store.get_tool(tool_id)
    if not tool:
        errors.append(f"{location}: tool_id '{tool_id}' not found")
        return errors
    version = store.get_tool_version(tool_version_id)
    if not version:
        errors.append(f"{location}: tool_version_id '{tool_version_id}' not found")
        return errors
    if version.tool_id != tool_id:
        errors.append(
            f"{location}: tool_version_id '{tool_version_id}' does not belong to tool_id '{tool_id}'"
        )
    return errors


def validate_tool_refs_in_workflow_spec(
    spec_json: dict[str, Any], store: Any
) -> list[str]:
    """Return validation errors for unresolved tool catalog refs in workflow spec."""
    errors: list[str] = []
    nodes = spec_json.get("nodes")
    if not isinstance(nodes, dict):
        return errors
    for node_id, node in nodes.items():
        if not isinstance(node, dict):
            continue
        if str(node.get("type") or "") != "tool":
            continue
        config = node.get("config")
        if not isinstance(config, dict):
            continue
        tool_id = str(config.get("tool_id") or "").strip()
        tool_version_id = str(config.get("tool_version_id") or "").strip()
        if not tool_id and not tool_version_id:
            continue
        if not tool_id or not tool_version_id:
            errors.append(
                f"nodes.{node_id}.config: both tool_id and tool_version_id are required"
            )
            continue
        errors.extend(
            _validate_tool_ref(
                tool_id=tool_id,
                tool_version_id=tool_version_id,
                store=store,
                location=f"nodes.{node_id}.config",
            )
        )
    return errors


def validate_tool_refs_in_agent_tools(
    tools: dict[str, Any] | None, store: Any
) -> list[str]:
    """Return validation errors for unresolved tool refs in agent version tools mapping."""
    errors: list[str] = []
    mapping = tools or {}
    if not isinstance(mapping, dict):
        return ["tools must be an object keyed by tool name"]
    for tool_name, spec in mapping.items():
        if not isinstance(spec, dict):
            continue
        tool_id = str(spec.get("tool_id") or "").strip()
        tool_version_id = str(spec.get("tool_version_id") or "").strip()
        if not tool_id and not tool_version_id:
            continue
        if not tool_id or not tool_version_id:
            errors.append(
                f"tools.{tool_name}: both tool_id and tool_version_id are required"
            )
            continue
        errors.extend(
            _validate_tool_ref(
                tool_id=tool_id,
                tool_version_id=tool_version_id,
                store=store,
                location=f"tools.{tool_name}",
            )
        )
    return errors
