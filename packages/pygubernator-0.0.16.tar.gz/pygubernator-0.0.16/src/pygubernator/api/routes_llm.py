"""LLM provider discovery and health-check routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter

from pygubernator.api._http_errors import raise_logged_not_found
from pygubernator.api.models import (
    LLMHealthCheckRequest,
    LLMHealthCheckResponse,
    LLMProviderPresetOut,
)
from pygubernator.llm._config import KNOWN_PROVIDERS

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/llm", tags=["llm"])


@router.get("/providers")
def list_providers() -> dict:
    """List known LLM provider presets.

    Returns:
        Dict with ``items`` list of provider presets.
    """
    items = [
        LLMProviderPresetOut(
            name=name,
            **preset.to_dict(),
        ).model_dump()
        for name, preset in KNOWN_PROVIDERS.items()
    ]
    return {"items": items}


@router.get("/providers/{provider_name}/models")
def list_provider_models(provider_name: str) -> dict:
    """List known models for a provider preset.

    Args:
        provider_name: Name of the provider preset.

    Returns:
        Dict with ``models`` list of model identifiers.
    """
    preset = KNOWN_PROVIDERS.get(provider_name)
    if not preset:
        raise_logged_not_found(
            logger,
            LookupError(f"provider_name={provider_name}"),
            public_detail=f"Unknown provider: {provider_name}",
            log_event="llm_unknown_provider",
        )
    return {"provider": provider_name, "models": list(preset.models)}


@router.post(
    "/health-check",
    response_model=LLMHealthCheckResponse,
)
async def health_check_provider(
    payload: LLMHealthCheckRequest,
) -> LLMHealthCheckResponse:
    """Health-check an OpenAI-compatible LLM provider endpoint.

    Pings ``/v1/models`` on the target server and returns
    reachability status and available model list.
    """
    try:
        from pygubernator.llm._openai_compat import (
            OpenAICompatibleProvider,
        )
    except ImportError:
        return LLMHealthCheckResponse(
            reachable=False,
            error=(
                "httpx not installed (pip install pygubernator[workflow] "
                "or pygubernator[api])"
            ),
        )

    provider = OpenAICompatibleProvider(
        api_base=payload.api_base.rstrip("/"),
        model="health-check",
        api_key=payload.api_key,
        timeout=10.0,
    )

    reachable = await provider.health_check()
    if not reachable:
        return LLMHealthCheckResponse(
            reachable=False,
            error=f"Cannot reach {payload.api_base}",
        )

    try:
        models = await provider.list_models()
    except Exception as exc:
        logger.warning("Health check models listing failed: %s", exc)
        models = []

    return LLMHealthCheckResponse(reachable=True, models=models)
