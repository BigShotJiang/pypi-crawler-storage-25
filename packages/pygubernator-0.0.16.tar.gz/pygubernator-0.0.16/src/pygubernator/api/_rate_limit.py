"""API rate limiting middleware."""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from typing import Any

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import (
    BaseHTTPMiddleware,
    RequestResponseEndpoint,
)

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding-window rate limiter per client IP.

    Tracks request timestamps per IP address and rejects
    requests that exceed the configured threshold within
    the sliding window.

    Args:
        app: The ASGI application.
        max_requests: Maximum requests per window.
        window_seconds: Window duration in seconds.
    """

    def __init__(
        self,
        app: Any,
        max_requests: int = 100,
        window_seconds: float = 60.0,
    ) -> None:
        super().__init__(app)
        self._max = max_requests
        self._window = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(
            list,
        )

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Check rate limit and forward or reject.

        Args:
            request: Incoming HTTP request.
            call_next: Next handler in the chain.

        Returns:
            The response from downstream or a 429 rejection.
        """
        client = request.client.host if request.client else "unknown"
        now = time.monotonic()

        # Prune entries outside the window
        cutoff = now - self._window
        entries = self._requests[client]
        self._requests[client] = [t for t in entries if t > cutoff]

        if len(self._requests[client]) >= self._max:
            logger.warning(
                "Rate limit exceeded for %s",
                client,
            )
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Rate limit exceeded",
                    "retry_after": self._window,
                },
            )

        self._requests[client].append(now)
        return await call_next(request)
