"""Workflow diagram layout positions API.

The workflow editor UI persists node coordinates inside ``spec_json``
(``nodes[id].position``). These routes are available for tooling or future split
storage; the Next.js app does not call them today.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query, status
from pydantic import BaseModel, Field

from pygubernator.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_not_found,
)
from pygubernator.api.deps import DbSession
from pygubernator.db.models.workflow_layout import WorkflowLayoutModel

router = APIRouter(prefix="/api/v1/layouts", tags=["Workflow Layouts"])
logger = logging.getLogger(__name__)


class LayoutPosition(BaseModel):
    """Single node position."""

    x: float = Field(..., description="X coordinate")
    y: float = Field(..., description="Y coordinate")


class WorkflowLayoutsListResponse(BaseModel):
    """All positions for a given workflow version."""

    workflow_id: str = Field(..., description="Workflow ID")
    workflow_version: str = Field(..., description="Workflow version")
    positions: dict[str, LayoutPosition] = Field(
        default_factory=dict,
        description="Positions keyed by node ID",
    )


@router.get(
    "",
    response_model=WorkflowLayoutsListResponse,
    status_code=status.HTTP_200_OK,
    summary="List layout positions for a workflow version",
)
def list_layouts(
    db: DbSession,
    workflow_id: str = Query(..., description="Workflow ID"),
    workflow_version: str = Query(..., description="Workflow version"),
) -> WorkflowLayoutsListResponse:
    """Return all saved positions as a dict keyed by node ID."""
    rows = (
        db.query(WorkflowLayoutModel)
        .filter(
            WorkflowLayoutModel.workflow_id == workflow_id,
            WorkflowLayoutModel.workflow_version == workflow_version,
        )
        .order_by(WorkflowLayoutModel.node_id.asc())
        .all()
    )
    positions = {
        r.node_id: LayoutPosition(x=r.position_x, y=r.position_y) for r in rows
    }
    return WorkflowLayoutsListResponse(
        workflow_id=workflow_id,
        workflow_version=workflow_version,
        positions=positions,
    )


@router.put(
    "/{workflow_id}/{workflow_version}",
    status_code=status.HTTP_200_OK,
    summary="Batch upsert diagram positions",
)
def batch_upsert_layouts(
    workflow_id: str,
    workflow_version: str,
    body: dict,
    db: DbSession,
) -> dict:
    """Upsert positions for multiple nodes at once.

    Args:
        workflow_id: Workflow ID from path.
        workflow_version: Workflow version from path.
        body: ``{"positions": {"node_id": {"x": ..., "y": ...}}}``
        db: DB session dependency.

    Returns:
        ``{"ok": True, "upserted": <count>}``
    """
    positions = body.get("positions")
    if not isinstance(positions, dict):
        raise_logged_bad_request(
            logger,
            ValueError("positions must be a dict"),
            public_detail="body.positions must be a dict",
            log_event="layouts_upsert_bad_positions",
        )

    count = 0
    for node_id, pos in positions.items():
        if not isinstance(pos, dict):
            continue
        x = float(pos.get("x", 0))
        y = float(pos.get("y", 0))

        row = (
            db.query(WorkflowLayoutModel)
            .filter(
                WorkflowLayoutModel.workflow_id == workflow_id,
                WorkflowLayoutModel.workflow_version == workflow_version,
                WorkflowLayoutModel.node_id == node_id,
            )
            .first()
        )
        if row is None:
            row = WorkflowLayoutModel(
                workflow_id=workflow_id,
                workflow_version=workflow_version,
                node_id=node_id,
                position_x=x,
                position_y=y,
            )
            db.add(row)
        else:
            row.position_x = x
            row.position_y = y
        count += 1

    db.commit()
    return {"ok": True, "upserted": count}


@router.delete(
    "/{workflow_id}/{workflow_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete ALL positions for a workflow version",
)
def delete_all_layouts(
    workflow_id: str,
    workflow_version: str,
    db: DbSession,
) -> None:
    """Delete every saved position for a workflow version.

    Used by the Reset Layout button to revert to auto-layout.
    """
    db.query(WorkflowLayoutModel).filter(
        WorkflowLayoutModel.workflow_id == workflow_id,
        WorkflowLayoutModel.workflow_version == workflow_version,
    ).delete(synchronize_session="fetch")
    db.commit()


@router.delete(
    "/{workflow_id}/{workflow_version}/{node_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete position for a single node",
)
def delete_single_layout(
    workflow_id: str,
    workflow_version: str,
    node_id: str,
    db: DbSession,
) -> None:
    """Delete the saved position for one node."""
    deleted = (
        db.query(WorkflowLayoutModel)
        .filter(
            WorkflowLayoutModel.workflow_id == workflow_id,
            WorkflowLayoutModel.workflow_version == workflow_version,
            WorkflowLayoutModel.node_id == node_id,
        )
        .delete(synchronize_session="fetch")
    )
    db.commit()
    if deleted == 0:
        raise_logged_not_found(
            logger,
            LookupError(
                f"workflow_id={workflow_id} version={workflow_version} "
                f"node_id={node_id}"
            ),
            public_detail="layout position not found",
            log_event="layouts_delete_single_missing",
        )
