"""``pygubernator new`` CLI: scaffold tool bundles, workflow packs, and plug-ins.

The ``tool`` and ``pack`` subcommands create simple bundle directories
(legacy manifest-driven packaging — see
:mod:`pygubernator.packaging`).

The ``node``, ``sink``, ``source``, ``connector``, and ``tool-plugin`` subcommands
create complete installable Python packages with ``pyproject.toml``,
the right entry-point group, a typed implementation skeleton, and a
test using the appropriate harness from ``pygubernator.testing``.
The generated package is ready to ``pip install -e .`` and ``pytest``
out of the box.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

_NAME_RE = re.compile(r"^[a-z][a-z0-9_\-]{1,63}$")


# ---------------------------------------------------------------------------
# Legacy bundle templates (preserved unchanged for backward compatibility)
# ---------------------------------------------------------------------------


_TOOL_MODULE = '''"""{name}: tool bundle scaffold."""

from __future__ import annotations

from pygubernator.tools import tool


@tool(description="Echo the payload back.")
async def echo(message: str) -> dict:
    """Return the supplied ``message`` inside a dict.

    Args:
        message: Text to echo back.
    """
    return {{"echo": message}}


def register(registry) -> int:
    """Register every @tool in this module with the given registry."""
    from pygubernator.tools import ToolRegistry

    assert isinstance(registry, ToolRegistry)
    return registry.register_module(__import__(__name__, fromlist=["register"]))
'''

_MANIFEST_TEMPLATE = """name: {name}
version: 0.1.0
description: {description}
kind: {kind}
tools: {tools}
workflows: {workflows}
permissions: []
env_vars: []
cost_estimate_usd: null
pygubernator: ">=0.0.1,<1.0.0"
extras: {{}}
"""

_WORKFLOW_TEMPLATE = """meta:
  name: {name}-demo
  version: 0.1.0
nodes:
  hello:
    type: template
    config:
      template: "Hello from {name}"
  out:
    type: output

edges:
  - {{ source: hello, target: out }}
"""


# ---------------------------------------------------------------------------
# Plug-in package templates (the modern, installable shape)
# ---------------------------------------------------------------------------


_PLUGIN_PYPROJECT = """\
[build-system]
requires = ["setuptools>=77.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{dist_name}"
version = "0.1.0"
description = "{description}"
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
dependencies = [
    "pygubernator>=0.1,<1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    "ruff>=0.9",
]

[tool.setuptools.packages.find]
where = ["src"]

[project.entry-points."{entry_group}"]
{entry_name} = "{module}:{entry_target}"
"""


_PLUGIN_README = """\
# {dist_name}

A pygubernator {kind_label} plug-in.

## Local development

```bash
pip install -e .[dev]
pytest
```

## Installing into a host

```bash
pip install {dist_name}
```

The plug-in is auto-discovered through the
``{entry_group}`` setuptools entry point.

See [the pygubernator extension guides](https://github.com/optophi/pygubernator/tree/main/docs/guides)
for the full plug-in development workflow.
"""


# --- Tool plugin -----------------------------------------------------------

_TOOL_PLUGIN_MODULE = '''"""{module}: pygubernator tool plug-in scaffold."""

from __future__ import annotations

from pygubernator.tools import tool


@tool(description="Echo the supplied message back as a dict.")
async def echo(message: str) -> dict[str, str]:
    """Return the input ``message`` wrapped in a dict.

    Args:
        message: Text to echo back.
    """
    return {{"echo": message}}


def register(registry) -> int:
    """Register every ``@tool``-decorated function in this module."""
    from pygubernator.tools import ToolRegistry

    assert isinstance(registry, ToolRegistry)
    return registry.register_module(__import__(__name__, fromlist=["register"]))
'''


_TOOL_PLUGIN_TEST = '''"""Tests for the {module} tool plug-in."""

from __future__ import annotations

import pytest

from pygubernator.testing import ToolTestHarness

from {module} import echo


@pytest.mark.asyncio
async def test_echo_returns_payload() -> None:
    harness = ToolTestHarness(echo)
    result = await harness.call({{"message": "hi"}})
    assert result.success is True
    assert result.output == {{"echo": "hi"}}
'''


# --- Node plugin -----------------------------------------------------------

_NODE_PLUGIN_MODULE = '''"""{module}: pygubernator node plug-in scaffold."""

from __future__ import annotations

from typing import Any

from pygubernator.workflow._types import (
    NodeContext,
    NodeResult,
    NodeStatus,
)


class {class_prefix}Node:
    """Uppercases a string from upstream input."""

    node_type = "{type_name}"

    def __init__(self, node_id: str, config: dict[str, Any]) -> None:
        self._node_id = node_id
        self._key = str(config.get("key", "text"))

    async def execute(self, context: NodeContext) -> NodeResult:
        value = context.input_data.get(self._key, "")
        if not isinstance(value, str):
            return NodeResult(
                node_id=self._node_id,
                status=NodeStatus.FAILED,
                error=(
                    f"Expected str at '{{self._key}}', "
                    f"got {{type(value).__name__}}"
                ),
            )
        return NodeResult(
            node_id=self._node_id,
            status=NodeStatus.SUCCESS,
            output={{self._key: value.upper()}},
        )


class {class_prefix}NodeFactory:
    """Factory pygubernator uses to construct {class_prefix}Node instances."""

    def create(self, node_id: str, config: dict[str, Any]) -> {class_prefix}Node:
        return {class_prefix}Node(node_id, config)
'''


_NODE_PLUGIN_TEST = '''"""Tests for the {module} node plug-in."""

from __future__ import annotations

import pytest

from pygubernator.testing import NodeTestHarness
from pygubernator.workflow._types import NodeStatus

from {module} import {class_prefix}NodeFactory


@pytest.mark.asyncio
async def test_uppercases_value() -> None:
    harness = NodeTestHarness({class_prefix}NodeFactory())
    result = await harness.execute(
        config={{"key": "name"}},
        input_data={{"name": "alice"}},
    )
    assert result.status is NodeStatus.SUCCESS
    assert result.output == {{"name": "ALICE"}}


@pytest.mark.asyncio
async def test_failed_on_non_string() -> None:
    harness = NodeTestHarness({class_prefix}NodeFactory())
    result = await harness.execute(input_data={{"text": 42}})
    assert result.status is NodeStatus.FAILED
'''


# --- Sink plugin -----------------------------------------------------------

_SINK_PLUGIN_MODULE = '''"""{module}: pygubernator sink plug-in scaffold."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors import SinkFactory
from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError


class {class_prefix}Sink:
    """In-memory sink scaffold — replace with the real implementation."""

    def __init__(self, *, target: str) -> None:
        self._target = target
        self.records: list[dict[str, Any]] = []

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        self.records.extend(records)
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="{type_name}",
            metadata={{"target": self._target}},
        )

    def close(self) -> None:
        return None


def _validate(config: dict[str, Any]) -> None:
    if not config.get("target"):
        raise SinkError(
            "{type_name} sink requires 'target' in config",
            sink_type="{type_name}",
        )


def _build(config: dict[str, Any]) -> {class_prefix}Sink:
    return {class_prefix}Sink(target=str(config["target"]))


FACTORY = SinkFactory(
    type_name="{type_name}",
    build=_build,
    validate=_validate,
    description="Replace this scaffold with your real sink description.",
)
'''


_SINK_PLUGIN_TEST = '''"""Tests for the {module} sink plug-in."""

from __future__ import annotations

import pytest

from pygubernator.connectors import SinkFactoryRegistry
from pygubernator.connectors.errors import SinkError

from {module} import FACTORY, {class_prefix}Sink


def test_factory_registers_under_type_name() -> None:
    registry = SinkFactoryRegistry()
    registry.register(FACTORY)
    assert "{type_name}" in registry


def test_validate_requires_target() -> None:
    registry = SinkFactoryRegistry()
    registry.register(FACTORY)
    with pytest.raises(SinkError):
        registry.create("{type_name}", {{}})


def test_build_returns_sink_and_records_batch() -> None:
    registry = SinkFactoryRegistry()
    registry.register(FACTORY)
    sink = registry.create("{type_name}", {{"target": "demo"}})
    assert isinstance(sink, {class_prefix}Sink)
    result = sink.send([{{"id": 1}}, {{"id": 2}}], {{}})
    assert result.success is True
    assert result.records_sent == 2
    assert sink.records == [{{"id": 1}}, {{"id": 2}}]
'''


# --- Source plugin ---------------------------------------------------------

_SOURCE_PLUGIN_MODULE = '''"""{module}: pygubernator source plug-in scaffold."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors import SourceFactory
from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError


class {class_prefix}Source:
    """In-memory source scaffold — replace with the real implementation."""

    def __init__(self, *, payload: list[dict[str, Any]]) -> None:
        self._payload = list(payload)
        self.read_count = 0

    def read(self) -> SourceResult:
        self.read_count += 1
        return SourceResult(
            success=True,
            records=list(self._payload),
            records_read=len(self._payload),
            source_type="{type_name}",
            metadata={{"read_count": self.read_count}},
        )

    def close(self) -> None:
        return None


def _validate(config: dict[str, Any]) -> None:
    payload = config.get("payload")
    if not isinstance(payload, list):
        raise SourceError(
            "{type_name} source requires 'payload' to be a list of records",
            source_type="{type_name}",
        )


def _build(config: dict[str, Any]) -> {class_prefix}Source:
    return {class_prefix}Source(payload=list(config["payload"]))


FACTORY = SourceFactory(
    type_name="{type_name}",
    build=_build,
    validate=_validate,
    description="Replace this scaffold with your real source description.",
)
'''


_SOURCE_PLUGIN_TEST = '''"""Tests for the {module} source plug-in."""

from __future__ import annotations

import pytest

from pygubernator.connectors import SourceFactoryRegistry
from pygubernator.connectors.errors import SourceError

from {module} import FACTORY, {class_prefix}Source


def test_factory_registers_under_type_name() -> None:
    registry = SourceFactoryRegistry()
    registry.register(FACTORY)
    assert "{type_name}" in registry


def test_validate_requires_payload_list() -> None:
    registry = SourceFactoryRegistry()
    registry.register(FACTORY)
    with pytest.raises(SourceError):
        registry.create("{type_name}", {{}})


def test_build_returns_source_and_reads_payload() -> None:
    registry = SourceFactoryRegistry()
    registry.register(FACTORY)
    payload = [{{"id": 1}}, {{"id": 2}}]
    source = registry.create("{type_name}", {{"payload": payload}})
    assert isinstance(source, {class_prefix}Source)
    result = source.read()
    assert result.success is True
    assert result.records_read == 2
    assert result.records == payload
'''


# --- Connector extension plugin --------------------------------------------

_CONNECTOR_PLUGIN_PYPROJECT = """\
[build-system]
requires = ["setuptools>=77.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{dist_name}"
version = "0.1.0"
description = "{description}"
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
dependencies = [
    "pygubernator>=0.1,<1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
    "ruff>=0.9",
]

[tool.setuptools.packages.find]
where = ["src"]

[project.entry-points."pygubernator.sources"]
{type_name} = "{module}.source:FACTORY"

[project.entry-points."pygubernator.sinks"]
{type_name} = "{module}.sink:FACTORY"
"""

_CONNECTOR_PLUGIN_INIT = '''"""Connector extension package scaffold."""\n\nfrom .sink import FACTORY as SINK_FACTORY\nfrom .source import FACTORY as SOURCE_FACTORY\n\n__all__ = ["SOURCE_FACTORY", "SINK_FACTORY"]\n'''

_CONNECTOR_SOURCE_MODULE = '''"""{module}.source: source connector scaffold."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors import SourceFactory
from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    ConnectorFieldSpec,
    ConnectorSpec,
)


class {class_prefix}Source:
    """Sample source that returns configured inline records."""

    def __init__(self, *, endpoint: str, records: list[dict[str, Any]] | None = None) -> None:
        self._endpoint = endpoint
        self._records = list(records or [])

    def read(self) -> SourceResult:
        return SourceResult(
            success=True,
            records=list(self._records),
            records_read=len(self._records),
            source_type="{type_name}",
            metadata={{"endpoint": self._endpoint}},
        )

    def close(self) -> None:
        return None


def _validate(config: dict[str, Any]) -> None:
    if not str(config.get("endpoint", "")).strip():
        raise SourceError(
            "{type_name} source requires 'endpoint' in config",
            source_type="{type_name}",
        )
    records = config.get("records", [])
    if not isinstance(records, list):
        raise SourceError(
            "{type_name} source requires 'records' to be a list when provided",
            source_type="{type_name}",
        )


def _build(config: dict[str, Any]) -> {class_prefix}Source:
    return {class_prefix}Source(
        endpoint=str(config["endpoint"]),
        records=list(config.get("records", [])),
    )


FACTORY = SourceFactory(
    type_name="{type_name}",
    build=_build,
    validate=_validate,
    description="Replace this scaffold with your real source description.",
    spec=ConnectorSpec(
        version=CONNECTOR_SPEC_V1,
        kind="source",
        type_name="{type_name}",
        display_name="{display_name}",
        description="Read records from {display_name}.",
        fields=(
            ConnectorFieldSpec(
                key="endpoint",
                label="Endpoint",
                required=True,
                description="API endpoint, queue name, or source identifier.",
                placeholder="https://api.example.com/resources",
            ),
            ConnectorFieldSpec(
                key="records",
                field_type="array",
                label="Records",
                default=[],
                description="Optional static records for local testing.",
            ),
        ),
    ),
)
'''

_CONNECTOR_SINK_MODULE = '''"""{module}.sink: sink connector scaffold."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors import SinkFactory
from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    ConnectorFieldSpec,
    ConnectorSpec,
)


class {class_prefix}Sink:
    """Sample sink that stores records in memory."""

    def __init__(self, *, target: str, mode: str = "append") -> None:
        self._target = target
        self._mode = mode
        self.records: list[dict[str, Any]] = []

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        if self._mode == "replace":
            self.records = list(records)
        else:
            self.records.extend(records)
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="{type_name}",
            metadata={{"target": self._target, "mode": self._mode}},
        )

    def close(self) -> None:
        return None


def _validate(config: dict[str, Any]) -> None:
    if not str(config.get("target", "")).strip():
        raise SinkError(
            "{type_name} sink requires 'target' in config",
            sink_type="{type_name}",
        )

    mode = str(config.get("mode", "append")).strip().lower()
    if mode not in {{"append", "replace"}}:
        raise SinkError(
            "{type_name} sink mode must be 'append' or 'replace'",
            sink_type="{type_name}",
        )


def _build(config: dict[str, Any]) -> {class_prefix}Sink:
    return {class_prefix}Sink(
        target=str(config["target"]),
        mode=str(config.get("mode", "append")),
    )


FACTORY = SinkFactory(
    type_name="{type_name}",
    build=_build,
    validate=_validate,
    description="Replace this scaffold with your real sink description.",
    spec=ConnectorSpec(
        version=CONNECTOR_SPEC_V1,
        kind="sink",
        type_name="{type_name}",
        display_name="{display_name}",
        description="Write records to {display_name}.",
        fields=(
            ConnectorFieldSpec(
                key="target",
                label="Target",
                required=True,
                description="Destination identifier for outbound records.",
                placeholder="orders-sync",
            ),
            ConnectorFieldSpec(
                key="mode",
                label="Mode",
                choices=("append", "replace"),
                default="append",
                description="append keeps previous records; replace overwrites.",
            ),
        ),
    ),
)
'''

_CONNECTOR_PLUGIN_TEST = '''"""Tests for the {module} connector extension scaffold."""

from __future__ import annotations

from pygubernator.connectors import (
    SinkFactoryRegistry,
    SourceFactoryRegistry,
)

from {module}.sink import FACTORY as SINK_FACTORY
from {module}.source import FACTORY as SOURCE_FACTORY


def test_source_factory_registers_with_spec() -> None:
    registry = SourceFactoryRegistry()
    registry.register(SOURCE_FACTORY)
    assert "{type_name}" in registry
    spec = registry.get_spec("{type_name}")
    assert spec.kind == "source"
    assert spec.type_name == "{type_name}"
    assert len(spec.fields) >= 1


def test_sink_factory_registers_with_spec() -> None:
    registry = SinkFactoryRegistry()
    registry.register(SINK_FACTORY)
    assert "{type_name}" in registry
    spec = registry.get_spec("{type_name}")
    assert spec.kind == "sink"
    assert spec.type_name == "{type_name}"
    assert len(spec.fields) >= 1
'''


# ---------------------------------------------------------------------------
# CLI wiring
# ---------------------------------------------------------------------------


_PLUGIN_KINDS = {"tool-plugin", "node", "sink", "source"}


def build_parser(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Add the ``new`` subcommands to ``parser``."""
    sub = parser.add_subparsers(dest="new_command", required=True)

    for kind, helptext in (
        ("tool", "Scaffold a legacy tool bundle (manifest-driven)"),
        ("pack", "Scaffold a legacy workflow pack (manifest-driven)"),
        ("tool-plugin", "Scaffold an installable tool plug-in package"),
        ("node", "Scaffold an installable node plug-in package"),
        ("sink", "Scaffold an installable sink plug-in package"),
        ("source", "Scaffold an installable source plug-in package"),
        (
            "connector",
            "Scaffold a paired source/sink connector extension package",
        ),
    ):
        sub_p = sub.add_parser(kind, help=helptext)
        sub_p.add_argument("name", help=f"{kind} name (slug)")
        sub_p.add_argument(
            "--path",
            default=None,
            help="Destination directory (default: ./<name>)",
        )

    return parser


def run(args: argparse.Namespace) -> int:
    """Dispatch to the selected scaffolder."""
    name = args.name
    if not _NAME_RE.match(name):
        print(f"name must match {_NAME_RE.pattern} — got '{name}'", file=sys.stderr)
        return 1

    dest = Path(args.path) if args.path else Path.cwd() / name
    if dest.exists() and any(dest.iterdir()):
        print(f"destination not empty: {dest}", file=sys.stderr)
        return 1
    dest.mkdir(parents=True, exist_ok=True)

    if args.new_command == "tool":
        return _scaffold_tool_bundle(name, dest)
    if args.new_command == "pack":
        return _scaffold_workflow_pack(name, dest)
    if args.new_command == "connector":
        return _scaffold_connector_package(name, dest)
    if args.new_command in _PLUGIN_KINDS:
        return _scaffold_plugin_package(args.new_command, name, dest)

    print("unknown new command", file=sys.stderr)
    return 1


def _scaffold_tool_bundle(name: str, dest: Path) -> int:
    (dest / "tools").mkdir()
    (dest / "tools" / "__init__.py").write_text("")
    (dest / "tools" / "bundle.py").write_text(_TOOL_MODULE.format(name=name))
    (dest / "pygubernator_manifest.yaml").write_text(
        _MANIFEST_TEMPLATE.format(
            name=name,
            description=f"{name} tool bundle",
            kind="tool_bundle",
            tools=f'["{name}.tools.bundle:echo"]',
            workflows="[]",
        )
    )
    (dest / "README.md").write_text(
        f"# {name}\n\nScaffolded by pygubernator new tool.\n"
    )
    print(f"scaffolded tool bundle at {dest}")
    return 0


def _scaffold_workflow_pack(name: str, dest: Path) -> int:
    (dest / "workflows").mkdir()
    (dest / "workflows" / f"{name}-demo.yaml").write_text(
        _WORKFLOW_TEMPLATE.format(name=name)
    )
    (dest / "pygubernator_manifest.yaml").write_text(
        _MANIFEST_TEMPLATE.format(
            name=name,
            description=f"{name} workflow pack",
            kind="workflow_pack",
            tools="[]",
            workflows=f'["workflows/{name}-demo.yaml"]',
        )
    )
    (dest / "README.md").write_text(
        f"# {name}\n\nScaffolded by pygubernator new pack.\n"
    )
    print(f"scaffolded workflow pack at {dest}")
    return 0


# ---------------------------------------------------------------------------
# Plug-in package scaffolders
# ---------------------------------------------------------------------------


def _module_name(name: str) -> str:
    """Return a valid Python identifier derived from a slug."""
    return name.replace("-", "_")


def _class_prefix(name: str, *, strip_suffix: str | None = None) -> str:
    """Return a PascalCase prefix derived from a slug.

    Args:
        name: Slug like ``demo-sink`` or ``uppercase-node``.
        strip_suffix: If the resulting PascalCase ends with this suffix
            (case-insensitive), drop it so the templates can reattach
            the kind suffix without producing names like ``DemoSinkSink``.
    """
    pascal = "".join(part.capitalize() for part in re.split(r"[-_]", name) if part)
    if strip_suffix and pascal.lower().endswith(strip_suffix.lower()):
        trimmed = pascal[: -len(strip_suffix)]
        if trimmed:
            return trimmed
    return pascal


_SUFFIX_FOR_KIND: dict[str, str | None] = {
    "tool-plugin": None,
    "node": "Node",
    "sink": "Sink",
    "source": "Source",
}


def _scaffold_plugin_package(kind: str, name: str, dest: Path) -> int:
    """Generate a complete installable plug-in package skeleton."""
    module = _module_name(name)
    class_prefix = _class_prefix(name, strip_suffix=_SUFFIX_FOR_KIND.get(kind))
    src_pkg = dest / "src" / module
    tests = dest / "tests"
    src_pkg.mkdir(parents=True)
    tests.mkdir()

    layout = _layout_for(kind, name=name, module=module, class_prefix=class_prefix)

    (src_pkg / "__init__.py").write_text(layout["module_source"])
    (tests / "__init__.py").write_text("")
    (tests / f"test_{module}.py").write_text(layout["test_source"])
    (dest / "pyproject.toml").write_text(
        _PLUGIN_PYPROJECT.format(
            dist_name=name,
            description=layout["description"],
            entry_group=layout["entry_group"],
            entry_name=layout["entry_name"],
            module=module,
            entry_target=layout["entry_target"],
        )
    )
    (dest / "README.md").write_text(
        _PLUGIN_README.format(
            dist_name=name,
            kind_label=layout["kind_label"],
            entry_group=layout["entry_group"],
        )
    )
    print(f"scaffolded {kind} plug-in at {dest}")
    print("next steps:")
    print(f"  cd {dest}")
    print("  pip install -e .[dev]")
    print("  pytest")
    return 0


def _scaffold_connector_package(name: str, dest: Path) -> int:
    """Generate a paired source/sink connector extension package."""
    module = _module_name(name)
    type_name = module
    class_prefix = _class_prefix(name)
    display_name = class_prefix.replace("_", " ")
    src_pkg = dest / "src" / module
    tests = dest / "tests"
    src_pkg.mkdir(parents=True)
    tests.mkdir()

    (src_pkg / "__init__.py").write_text(_CONNECTOR_PLUGIN_INIT)
    (src_pkg / "source.py").write_text(
        _CONNECTOR_SOURCE_MODULE.format(
            module=module,
            class_prefix=class_prefix,
            type_name=type_name,
            display_name=display_name,
        )
    )
    (src_pkg / "sink.py").write_text(
        _CONNECTOR_SINK_MODULE.format(
            module=module,
            class_prefix=class_prefix,
            type_name=type_name,
            display_name=display_name,
        )
    )
    (tests / "__init__.py").write_text("")
    (tests / f"test_{module}.py").write_text(
        _CONNECTOR_PLUGIN_TEST.format(
            module=module,
            type_name=type_name,
        )
    )
    (dest / "pyproject.toml").write_text(
        _CONNECTOR_PLUGIN_PYPROJECT.format(
            dist_name=name,
            description=f"{name} connector extension for pygubernator",
            module=module,
            type_name=type_name,
        )
    )
    (dest / "README.md").write_text(
        _PLUGIN_README.format(
            dist_name=name,
            kind_label="connector",
            entry_group="pygubernator.sources / pygubernator.sinks",
        )
    )
    print(f"scaffolded connector plug-in at {dest}")
    print("next steps:")
    print(f"  cd {dest}")
    print("  pip install -e .[dev]")
    print("  pytest")
    return 0


def _layout_for(
    kind: str,
    *,
    name: str,
    module: str,
    class_prefix: str,
) -> dict[str, str]:
    """Return per-kind template values."""
    type_name = module
    if kind == "tool-plugin":
        return {
            "module_source": _TOOL_PLUGIN_MODULE.format(module=module),
            "test_source": _TOOL_PLUGIN_TEST.format(module=module),
            "entry_group": "pygubernator.tools",
            "entry_name": name,
            "entry_target": "register",
            "description": f"{name} tool plug-in for pygubernator",
            "kind_label": "tool",
        }
    if kind == "node":
        return {
            "module_source": _NODE_PLUGIN_MODULE.format(
                module=module,
                class_prefix=class_prefix,
                type_name=type_name,
            ),
            "test_source": _NODE_PLUGIN_TEST.format(
                module=module,
                class_prefix=class_prefix,
            ),
            "entry_group": "pygubernator.nodes",
            "entry_name": type_name,
            "entry_target": f"{class_prefix}NodeFactory",
            "description": f"{name} node plug-in for pygubernator",
            "kind_label": "node",
        }
    if kind == "sink":
        return {
            "module_source": _SINK_PLUGIN_MODULE.format(
                module=module,
                class_prefix=class_prefix,
                type_name=type_name,
            ),
            "test_source": _SINK_PLUGIN_TEST.format(
                module=module,
                class_prefix=class_prefix,
                type_name=type_name,
            ),
            "entry_group": "pygubernator.sinks",
            "entry_name": type_name,
            "entry_target": "FACTORY",
            "description": f"{name} sink plug-in for pygubernator",
            "kind_label": "sink",
        }
    if kind == "source":
        return {
            "module_source": _SOURCE_PLUGIN_MODULE.format(
                module=module,
                class_prefix=class_prefix,
                type_name=type_name,
            ),
            "test_source": _SOURCE_PLUGIN_TEST.format(
                module=module,
                class_prefix=class_prefix,
                type_name=type_name,
            ),
            "entry_group": "pygubernator.sources",
            "entry_name": type_name,
            "entry_target": "FACTORY",
            "description": f"{name} source plug-in for pygubernator",
            "kind_label": "source",
        }
    raise ValueError(f"unknown plug-in kind: {kind}")
