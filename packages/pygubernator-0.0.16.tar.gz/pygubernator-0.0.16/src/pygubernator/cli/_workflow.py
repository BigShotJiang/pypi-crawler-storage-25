"""CLI handler for workflow orchestration commands."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys


def run_workflow(args: argparse.Namespace) -> int:
    """Load and run a workflow from a YAML file.

    Args:
        args: Parsed CLI arguments (path, input, dry_run).

    Returns:
        Exit code.
    """
    from pygubernator.api.services._workflows import build_node_registry
    from pygubernator.workflow._engine import ExecutionMode, WorkflowEngine
    from pygubernator.workflow.config._loader import WorkflowLoader

    try:
        input_data = json.loads(args.input)
    except json.JSONDecodeError as exc:
        print(f"Error: invalid JSON input: {exc}", file=sys.stderr)
        return 1

    loader = WorkflowLoader()
    try:
        spec = loader.load(args.path)
    except Exception as exc:
        print(f"Error loading workflow: {exc}", file=sys.stderr)
        return 1

    print(f"Workflow: {spec.name}")
    print(f"Version: {spec.version}")
    print(f"Nodes: {len(spec.nodes)}")
    print(f"Edges: {len(spec.edges)}")

    registry = build_node_registry()
    mode = ExecutionMode.DRY_RUN if args.dry_run else ExecutionMode.FULL

    engine = WorkflowEngine(spec=spec, registry=registry, mode=mode)

    try:
        result = asyncio.run(engine.run(input_data))
    except Exception as exc:
        print(f"Error executing workflow: {exc}", file=sys.stderr)
        return 1

    print(json.dumps(result.to_dict(), indent=2, default=str))
    return 0 if result.success else 1
