"""``pygubernator pack`` CLI: install / list / remove / build."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pygubernator.packaging import (
    PackInstallError,
    PackManifestError,
    default_pack_home,
    install_pack,
    list_packs,
    uninstall_pack,
)
from pygubernator.packaging._pack import pack_directory


def build_parser(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """Add the pack subcommands to an argparse parser."""
    sub = parser.add_subparsers(dest="pack_command", required=True)

    install_p = sub.add_parser("install", help="Install a .pgpack archive")
    install_p.add_argument("path", help="Path to the .pgpack archive")
    install_p.add_argument("--home", help="Override pack install root")
    install_p.add_argument("--force", action="store_true", default=False)
    install_p.add_argument(
        "--verify",
        action="store_true",
        default=False,
        help="Enable optional signature envelope checks before install",
    )
    install_p.add_argument(
        "--verify-strict",
        action="store_true",
        default=False,
        help="Require signature envelope checks to pass",
    )
    install_p.add_argument(
        "--trusted-key",
        action="append",
        default=[],
        help="Allowed signature key_id (repeatable)",
    )

    sub.add_parser("list", help="List installed packs")

    remove_p = sub.add_parser("remove", help="Uninstall a pack by name")
    remove_p.add_argument("name", help="Pack name to remove")

    build_p = sub.add_parser(
        "build",
        help="Build a .pgpack archive from a directory with a manifest",
    )
    build_p.add_argument("source", help="Directory containing the manifest")
    build_p.add_argument(
        "--output",
        help="Output .pgpack path (default: <name>-<version>.pgpack)",
    )

    return parser


def run(args: argparse.Namespace) -> int:
    """Dispatch to the selected pack subcommand."""
    try:
        if args.pack_command == "install":
            home = Path(args.home) if args.home else None
            pack = install_pack(
                args.path,
                home=home,
                force=args.force,
                verify=args.verify,
                verify_strict=args.verify_strict,
                trusted_key_ids=tuple(args.trusted_key),
            )
            print(
                f"installed {pack.manifest.name}@{pack.manifest.version} → {pack.path}"
            )
            if pack.verification is not None:
                print(json.dumps({"verification": pack.verification}))
            return 0

        if args.pack_command == "list":
            packs = list_packs()
            if not packs:
                print(f"no packs installed in {default_pack_home()}")
                return 0
            for pack in packs:
                print(
                    json.dumps(
                        {
                            "name": pack.manifest.name,
                            "version": pack.manifest.version,
                            "kind": pack.manifest.kind,
                            "path": str(pack.path),
                        }
                    )
                )
            return 0

        if args.pack_command == "remove":
            removed = uninstall_pack(args.name)
            if removed:
                print(f"removed {args.name}")
                return 0
            print(f"pack not installed: {args.name}", file=sys.stderr)
            return 1

        if args.pack_command == "build":
            out = pack_directory(args.source, args.output)
            print(f"built {out}")
            return 0

    except (PackInstallError, PackManifestError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print("unknown pack command", file=sys.stderr)
    return 1
