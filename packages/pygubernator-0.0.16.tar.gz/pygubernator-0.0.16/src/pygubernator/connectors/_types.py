"""Connector type definitions and protocols.

Core types for the connector layer: result dataclasses and
protocol definitions for sinks (write) and sources (read).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class SinkResult:
    """Result of sending data to a sink.

    Attributes:
        success: Whether all records were sent successfully.
        records_sent: Number of records successfully sent.
        sink_type: The type of sink that received the data.
        errors: Error messages for any failures.
        metadata: Additional sink-specific metadata.
    """

    success: bool
    records_sent: int
    sink_type: str = ""
    errors: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class Sink(Protocol):
    """Receives data batches (synchronous).

    Sinks are the output targets for data. Implementations
    handle writing to files, HTTP endpoints, databases, queues, etc.
    """

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send a batch of records to the target.

        Args:
            records: List of records to send.
            metadata: Metadata (schema name, timestamp, etc.).

        Returns:
            Result indicating success/failure and records sent.
        """
        ...

    def close(self) -> None:
        """Release any resources held by the sink."""
        ...


@runtime_checkable
class AsyncSink(Protocol):
    """Receives data batches (asynchronous).

    Async variant for I/O-bound sinks (HTTP, databases, queues).
    """

    async def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send a batch of records to the target asynchronously.

        Args:
            records: List of records to send.
            metadata: Metadata (schema name, timestamp, etc.).

        Returns:
            Result indicating success/failure and records sent.
        """
        ...

    async def close(self) -> None:
        """Release any resources held by the sink."""
        ...


# ---------------------------------------------------------------------------
# Source types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SourceResult:
    """Result of reading data from a source.

    Attributes:
        success: Whether records were read successfully.
        records: The records that were read.
        records_read: Number of records in the batch.
        source_type: The type of source that provided the data.
        errors: Error messages for any failures.
        metadata: Additional source-specific metadata.
    """

    success: bool
    records: list[dict[str, Any]] = field(default_factory=list)
    records_read: int = 0
    source_type: str = ""
    errors: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class Source(Protocol):
    """Reads data batches from an external system (synchronous)."""

    def read(self) -> SourceResult:
        """Read a batch of records from the source.

        Returns:
            Result containing the records and read metadata.
        """
        ...

    def close(self) -> None:
        """Release any resources held by the source."""
        ...


@runtime_checkable
class AsyncSource(Protocol):
    """Reads data batches from an external system (asynchronous)."""

    async def read(self) -> SourceResult:
        """Read a batch of records from the source asynchronously.

        Returns:
            Result containing the records and read metadata.
        """
        ...

    async def close(self) -> None:
        """Release any resources held by the source."""
        ...
