"""Exception hierarchy for the connectors layer."""

from __future__ import annotations

from typing import Any

from pygubernator.errors import ErrorCode, GubernatorError


class ConnectorError(GubernatorError):
    """Base exception for all connector errors.

    Args:
        message: Human-readable error description.
        connector_type: Identifier for the connector that failed.
        context: Additional structured context.
    """

    def __init__(
        self,
        message: str,
        connector_type: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if connector_type:
            ctx["connector_type"] = connector_type
        super().__init__(message, ctx, code=ErrorCode.CONNECTOR_FAILED)
        self.connector_type = connector_type


class SinkError(ConnectorError):
    """Error sending data to a sink target.

    Attributes:
        sink_type: The type of sink that failed.
        records_sent: Number of records successfully sent before failure.
    """

    def __init__(
        self,
        message: str,
        sink_type: str | None = None,
        records_sent: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if sink_type:
            ctx["sink_type"] = sink_type
        ctx["records_sent"] = records_sent
        super().__init__(message, connector_type=sink_type, context=ctx)
        self.sink_type = sink_type
        self.records_sent = records_sent
        self.code = ErrorCode.SINK_FAILED


class SourceError(ConnectorError):
    """Error reading data from a source.

    Attributes:
        source_type: The type of source that failed.
        records_read: Number of records read before failure.
    """

    def __init__(
        self,
        message: str,
        source_type: str | None = None,
        records_read: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if source_type:
            ctx["source_type"] = source_type
        ctx["records_read"] = records_read
        super().__init__(message, connector_type=source_type, context=ctx)
        self.source_type = source_type
        self.records_read = records_read
        self.code = ErrorCode.SOURCE_FAILED
