"""Register built-in source factories into a :class:`SourceFactoryRegistry`.

Each built-in source module under :mod:`pygubernator.connectors.sources`
exposes a module-level ``FACTORY`` constant. This module imports those
``FACTORY`` objects and registers them into a supplied registry.

Imports are performed lazily inside :func:`register_builtin_sources` so
merely importing the connectors package does not pull in every source
implementation at package-load time.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pygubernator.connectors._source_registry import SourceFactoryRegistry


def register_builtin_sources(registry: SourceFactoryRegistry) -> None:
    """Register every first-party source factory into ``registry``.

    Args:
        registry: Target registry (typically the module-level
            :data:`pygubernator.connectors.DEFAULT_SOURCE_REGISTRY`).
    """
    from pygubernator.connectors.sources import (
        database as _database,
    )
    from pygubernator.connectors.sources import (
        file as _file,
    )
    from pygubernator.connectors.sources import (
        http as _http,
    )
    from pygubernator.connectors.sources import (
        memory as _memory,
    )

    for module in (_memory, _file, _http, _database):
        factory = getattr(module, "FACTORY", None)
        if factory is None:
            continue
        if factory.type_name in registry:
            continue
        registry.register(factory)


__all__ = ["register_builtin_sources"]
