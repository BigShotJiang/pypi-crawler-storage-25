"""Versioned connector specification models and validation helpers."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import Any, Literal

CONNECTOR_SPEC_V1 = "v1"
SUPPORTED_CONNECTOR_SPEC_VERSIONS = (CONNECTOR_SPEC_V1,)
ConnectorKind = Literal["source", "sink"]

_SUPPORTED_FIELD_TYPES = {
    "string",
    "integer",
    "number",
    "boolean",
    "object",
    "array",
}


class ConnectorSpecError(ValueError):
    """Raised when connector spec payloads fail validation."""


def _normalize_kind(kind: str) -> ConnectorKind:
    normalized = kind.strip().lower()
    if normalized not in {"source", "sink"}:
        raise ConnectorSpecError(
            f"Connector spec kind must be 'source' or 'sink' (got '{kind}')"
        )
    return normalized  # type: ignore[return-value]


def _display_name_for_type_name(type_name: str) -> str:
    title = type_name.replace("-", " ").replace("_", " ").strip()
    return " ".join(part.capitalize() for part in title.split()) or type_name


@dataclass(frozen=True, slots=True)
class ConnectorFieldSpec:
    """Describes one configurable connector field for a form/runtime."""

    key: str
    field_type: str = "string"
    label: str = ""
    description: str = ""
    required: bool = False
    secret: bool = False
    default: Any = None
    placeholder: str = ""
    choices: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        key = self.key.strip()
        if not key:
            raise ConnectorSpecError("Connector field key must be a non-empty string")

        field_type = self.field_type.strip().lower() or "string"
        if field_type not in _SUPPORTED_FIELD_TYPES:
            raise ConnectorSpecError(
                f"Unsupported connector field type '{self.field_type}' for key '{key}'"
            )

        object.__setattr__(self, "key", key)
        object.__setattr__(self, "field_type", field_type)
        object.__setattr__(
            self, "choices", tuple(str(choice) for choice in self.choices)
        )

        if (
            self.choices
            and self.default is not None
            and str(self.default) not in self.choices
        ):
            raise ConnectorSpecError(
                f"Default '{self.default}' is not present in choices for field '{key}'"
            )

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> ConnectorFieldSpec:
        """Build a field spec from a plain mapping payload."""
        choices_raw = raw.get("choices", ())
        if isinstance(choices_raw, str):
            choices = (choices_raw,)
        elif isinstance(choices_raw, list | tuple | set):
            choices = tuple(str(choice) for choice in choices_raw)
        else:
            raise ConnectorSpecError(
                f"Field 'choices' must be a sequence for key '{raw.get('key', '')}'"
            )

        return cls(
            key=str(raw.get("key", "")),
            field_type=str(raw.get("field_type", "string")),
            label=str(raw.get("label", "")),
            description=str(raw.get("description", "")),
            required=bool(raw.get("required", False)),
            secret=bool(raw.get("secret", False)),
            default=raw.get("default"),
            placeholder=str(raw.get("placeholder", "")),
            choices=choices,
        )


@dataclass(frozen=True, slots=True)
class ConnectorSpec:
    """Versioned connector metadata used by registries and the API/UI."""

    version: str
    kind: ConnectorKind
    type_name: str
    display_name: str = ""
    description: str = ""
    fields: tuple[ConnectorFieldSpec, ...] = ()

    def __post_init__(self) -> None:
        version = self.version.strip().lower()
        if version not in SUPPORTED_CONNECTOR_SPEC_VERSIONS:
            raise ConnectorSpecError(
                f"Unsupported connector spec version '{self.version}'"
            )

        kind = _normalize_kind(str(self.kind))
        type_name = self.type_name.strip().lower()
        if not type_name:
            raise ConnectorSpecError("Connector spec type_name must be non-empty")

        fields = tuple(self.fields)
        keys = [field.key for field in fields]
        duplicates = sorted({key for key in keys if keys.count(key) > 1})
        if duplicates:
            raise ConnectorSpecError(
                f"Connector spec has duplicate field keys: {', '.join(duplicates)}"
            )

        display_name = self.display_name.strip() or _display_name_for_type_name(
            type_name
        )
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "type_name", type_name)
        object.__setattr__(self, "display_name", display_name)
        object.__setattr__(self, "fields", fields)

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> ConnectorSpec:
        """Build a connector spec from a plain mapping payload."""
        fields_raw = raw.get("fields", ())
        if not isinstance(fields_raw, list | tuple):
            raise ConnectorSpecError("Connector spec 'fields' must be a list or tuple")

        fields: list[ConnectorFieldSpec] = []
        for item in fields_raw:
            if isinstance(item, ConnectorFieldSpec):
                fields.append(item)
                continue
            if not isinstance(item, Mapping):
                raise ConnectorSpecError(
                    "Connector spec field entries must be mappings"
                )
            fields.append(ConnectorFieldSpec.from_mapping(item))

        return cls(
            version=str(raw.get("version", CONNECTOR_SPEC_V1)),
            kind=_normalize_kind(str(raw.get("kind", ""))),
            type_name=str(raw.get("type_name", "")),
            display_name=str(raw.get("display_name", "")),
            description=str(raw.get("description", "")),
            fields=tuple(fields),
        )


def coerce_connector_spec(
    spec: ConnectorSpec | Mapping[str, Any] | None,
    *,
    expected_kind: ConnectorKind,
    type_name: str,
    description: str = "",
) -> ConnectorSpec:
    """Normalize user/plugin-provided connector specs to validated v1 specs.

    Legacy factories without metadata are converted to a minimal spec v1
    object so callers can safely consume registry metadata without requiring
    every connector plugin to migrate at once.
    """

    normalized_type = type_name.strip().lower()
    if not normalized_type:
        raise ConnectorSpecError("Connector type_name must be non-empty")

    if spec is None:
        return ConnectorSpec(
            version=CONNECTOR_SPEC_V1,
            kind=expected_kind,
            type_name=normalized_type,
            description=description.strip(),
        )

    if isinstance(spec, Mapping):
        candidate = ConnectorSpec.from_mapping(spec)
    elif isinstance(spec, ConnectorSpec):
        candidate = spec
    else:
        raise ConnectorSpecError(
            f"Connector spec must be a ConnectorSpec, mapping, or None (got {type(spec).__name__})"
        )

    if candidate.kind != expected_kind:
        raise ConnectorSpecError(
            f"Connector spec kind mismatch for '{normalized_type}': expected "
            f"'{expected_kind}', got '{candidate.kind}'"
        )
    if candidate.type_name != normalized_type:
        raise ConnectorSpecError(
            f"Connector spec type_name mismatch: expected '{normalized_type}', "
            f"got '{candidate.type_name}'"
        )
    if not candidate.description and description.strip():
        return replace(candidate, description=description.strip())
    return candidate


__all__ = [
    "CONNECTOR_SPEC_V1",
    "SUPPORTED_CONNECTOR_SPEC_VERSIONS",
    "ConnectorFieldSpec",
    "ConnectorKind",
    "ConnectorSpec",
    "ConnectorSpecError",
    "coerce_connector_spec",
]
