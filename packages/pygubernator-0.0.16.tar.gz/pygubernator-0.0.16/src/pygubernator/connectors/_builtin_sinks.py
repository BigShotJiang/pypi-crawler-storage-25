"""Register built-in sink factories into a :class:`SinkFactoryRegistry`.

Each built-in sink module under :mod:`pygubernator.connectors.sinks`
exposes a module-level ``FACTORY`` constant. This module imports those
``FACTORY`` objects and registers them into a supplied registry.

Imports are performed lazily inside :func:`register_builtin_sinks` so
merely importing the connectors package does not pull in every sink
implementation at package-load time.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pygubernator.connectors._sink_registry import SinkFactoryRegistry


def register_builtin_sinks(registry: SinkFactoryRegistry) -> None:
    """Register every first-party sink factory into ``registry``.

    Args:
        registry: Target registry (typically the module-level
            :data:`pygubernator.connectors.DEFAULT_SINK_REGISTRY`).
    """
    # Local imports keep the module graph small and avoid loading
    # optional-dep-heavy modules until they are actually needed.
    from pygubernator.connectors.sinks import (
        console as _console,
    )
    from pygubernator.connectors.sinks import (
        database as _database,
    )
    from pygubernator.connectors.sinks import (
        file as _file,
    )
    from pygubernator.connectors.sinks import (
        http as _http,
    )
    from pygubernator.connectors.sinks import (
        kafka as _kafka,
    )
    from pygubernator.connectors.sinks import (
        memory as _memory,
    )
    from pygubernator.connectors.sinks import (
        rabbitmq as _rabbitmq,
    )
    from pygubernator.connectors.sinks import (
        s3 as _s3,
    )

    for module in (
        _memory,
        _file,
        _http,
        _database,
        _kafka,
        _rabbitmq,
        _s3,
        _console,
    ):
        factory = getattr(module, "FACTORY", None)
        if factory is None:
            continue
        if factory.type_name in registry:
            continue
        registry.register(factory)


__all__ = ["register_builtin_sinks"]
