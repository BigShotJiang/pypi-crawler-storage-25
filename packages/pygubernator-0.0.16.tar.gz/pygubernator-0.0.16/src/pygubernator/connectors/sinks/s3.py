"""S3 sink for writing generated data to Amazon S3 or compatible storage.

Supports JSON, NDJSON, and CSV output formats. Requires the ``[s3]``
optional extra (``boto3``).
"""

from __future__ import annotations

import csv
import io
import json
import logging
from typing import Any

from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError

try:
    import boto3
    from botocore.exceptions import ClientError

    _S3_AVAILABLE = True
except ImportError:
    _S3_AVAILABLE = False
    boto3 = None  # type: ignore[assignment]
    ClientError = None  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)

_SUPPORTED_FORMATS = {"json", "ndjson", "csv"}


class S3Sink:
    """Writes generated records to an S3 object.

    Uses ``put_object`` for atomic writes. For very large datasets,
    consider splitting into multiple keys or using multipart upload
    externally.

    Args:
        bucket: S3 bucket name.
        key: S3 object key (e.g. ``"data/orders.json"``).
        format: Output format — ``"json"`` (default), ``"ndjson"``,
            or ``"csv"``.
        region: AWS region. Falls back to ``AWS_DEFAULT_REGION``
            or boto3 defaults.
        credentials: Optional dict with ``aws_access_key_id`` and
            ``aws_secret_access_key``.
        endpoint_url: Custom endpoint for S3-compatible stores
            (e.g. MinIO).
    """

    def __init__(
        self,
        bucket: str,
        key: str,
        *,
        format: str = "json",
        region: str | None = None,
        credentials: dict[str, str] | None = None,
        endpoint_url: str | None = None,
    ) -> None:
        if not _S3_AVAILABLE:
            raise SinkError(
                "boto3 is required for S3Sink. "
                "Install with: pip install pygubernator[s3]",
                sink_type="s3",
            )
        if not bucket:
            raise SinkError("S3Sink requires a bucket name", sink_type="s3")
        if not key:
            raise SinkError("S3Sink requires an object key", sink_type="s3")

        fmt = format.lower()
        if fmt not in _SUPPORTED_FORMATS:
            raise SinkError(
                f"Unsupported S3 format: '{fmt}'. "
                f"Supported: {', '.join(sorted(_SUPPORTED_FORMATS))}",
                sink_type="s3",
            )

        self._bucket = bucket
        self._key = key
        self._format = fmt

        session_kwargs: dict[str, Any] = {}
        if region:
            session_kwargs["region_name"] = region
        if credentials:
            session_kwargs["aws_access_key_id"] = credentials.get(
                "aws_access_key_id", ""
            )
            session_kwargs["aws_secret_access_key"] = credentials.get(
                "aws_secret_access_key", ""
            )

        session = boto3.Session(**session_kwargs)
        client_kwargs: dict[str, Any] = {}
        if endpoint_url:
            client_kwargs["endpoint_url"] = endpoint_url
        self._client = session.client("s3", **client_kwargs)

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Write records to S3.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        try:
            body = self._serialize(records)
            content_type = _content_type(self._format)
            self._client.put_object(
                Bucket=self._bucket,
                Key=self._key,
                Body=body,
                ContentType=content_type,
            )
            logger.info(
                "wrote %d records to s3://%s/%s (%s)",
                len(records),
                self._bucket,
                self._key,
                self._format,
            )
            return SinkResult(
                success=True,
                records_sent=len(records),
                sink_type="s3",
                metadata={
                    "bucket": self._bucket,
                    "key": self._key,
                    "format": self._format,
                },
            )
        except ClientError as exc:
            raise SinkError(
                f"S3 put_object failed: {exc}",
                sink_type="s3",
            ) from exc

    def close(self) -> None:
        """No-op for S3 sink."""

    def _serialize(self, records: list[dict[str, Any]]) -> bytes:
        """Serialize records to bytes in the configured format."""
        if self._format == "json":
            return json.dumps(records, indent=2, default=str).encode("utf-8")
        if self._format == "ndjson":
            lines = [json.dumps(r, default=str) for r in records]
            return ("\n".join(lines) + "\n").encode("utf-8")
        # csv
        return _records_to_csv_bytes(records)


def _content_type(fmt: str) -> str:
    """Map format to MIME content type."""
    if fmt == "json":
        return "application/json"
    if fmt == "ndjson":
        return "application/x-ndjson"
    return "text/csv"


def _records_to_csv_bytes(records: list[dict[str, Any]]) -> bytes:
    """Serialize records to CSV bytes."""
    if not records:
        return b""
    fieldnames: list[str] = []
    seen: set[str] = set()
    for record in records:
        for key in record:
            if key not in seen:
                fieldnames.append(key)
                seen.add(key)
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(records)
    return buf.getvalue().encode("utf-8")


# ---------------------------------------------------------------------------
# Sink factory registration
# ---------------------------------------------------------------------------


def _validate(config: dict[str, Any]) -> None:
    """Require the ``bucket`` and ``key`` keys."""
    if not config.get("bucket"):
        raise SinkError("S3 sink requires 'bucket'", sink_type="s3")
    if not config.get("key"):
        raise SinkError("S3 sink requires 'key'", sink_type="s3")


def _build(config: dict[str, Any]) -> S3Sink:
    """Build an :class:`S3Sink` from a config dict."""
    return S3Sink(
        config["bucket"],
        config["key"],
        format=config.get("format", "json"),
        region=config.get("region"),
        credentials=config.get("credentials"),
        endpoint_url=config.get("endpoint_url"),
    )


def _factory() -> Any:
    """Return the :class:`SinkFactory` for this sink."""
    from pygubernator.connectors._sink_registry import SinkFactory

    return SinkFactory(
        type_name="s3",
        build=_build,
        validate=_validate,
        description="Writes records to an S3 (or S3-compatible) object.",
    )


FACTORY = _factory()
