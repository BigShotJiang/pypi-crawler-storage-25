"""In-memory sink for testing and programmatic use.

Captures generated records in a list for inspection,
assertion, and downstream processing.
"""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SinkResult


class InMemorySink:
    """Stores generated records in memory.

    Useful for testing, assertions, and programmatic pipelines
    where data doesn't need to leave the process.

    Attributes:
        records: All records received across send() calls.
        batches: List of individual batches received.
    """

    def __init__(self) -> None:
        self.records: list[dict[str, Any]] = []
        self.batches: list[list[dict[str, Any]]] = []
        self._metadata: list[dict[str, Any]] = []

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Store records in memory.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            Successful SinkResult.
        """
        self.records.extend(records)
        self.batches.append(list(records))
        self._metadata.append(dict(metadata))
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type="memory",
        )

    def close(self) -> None:
        """No-op for in-memory sink."""

    def clear(self) -> None:
        """Clear all stored records and batches."""
        self.records.clear()
        self.batches.clear()
        self._metadata.clear()

    @property
    def record_count(self) -> int:
        """Total number of records stored."""
        return len(self.records)

    @property
    def batch_count(self) -> int:
        """Number of batches received."""
        return len(self.batches)


# ---------------------------------------------------------------------------
# Sink factory registration
# ---------------------------------------------------------------------------


def _build(_config: dict[str, Any]) -> InMemorySink:
    """Build an :class:`InMemorySink` from a config dict (config unused)."""
    return InMemorySink()


def _factory() -> Any:
    """Return the :class:`SinkFactory` for this sink.

    Lazy construction avoids a circular import with
    :mod:`pygubernator.connectors._sink_registry`.
    """
    from pygubernator.connectors._sink_registry import SinkFactory

    return SinkFactory(
        type_name="memory",
        build=_build,
        description="In-process sink that stores records in a Python list.",
    )


FACTORY = _factory()
