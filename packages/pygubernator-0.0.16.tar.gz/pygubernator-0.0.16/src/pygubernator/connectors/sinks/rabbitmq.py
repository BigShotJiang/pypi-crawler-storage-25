"""RabbitMQ sink for publishing generated data to RabbitMQ exchanges.

Publishes generated records as JSON messages to a RabbitMQ exchange.
Requires the [rabbitmq] optional extra (pika).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError

logger = logging.getLogger(__name__)


class RabbitMQSink:
    """Publishes generated records to a RabbitMQ exchange.

    Each record is serialized as JSON and published as a message.

    Attributes:
        url: AMQP connection URL.
        exchange: Target exchange name.
        routing_key: Message routing key.
    """

    def __init__(
        self,
        url: str,
        *,
        exchange: str = "",
        routing_key: str = "",
        queue: str | None = None,
        declare_queue: bool = True,
        delivery_mode: int = 2,
    ) -> None:
        """Initialize the RabbitMQ sink.

        Args:
            url: AMQP connection URL
                (e.g. amqp://guest:guest@localhost/).
            exchange: Target exchange (empty string = default exchange).
            routing_key: Message routing key (defaults to queue name).
            queue: Queue name. If provided and declare_queue is True,
                the queue will be declared before publishing.
            declare_queue: Whether to declare the queue on first send.
            delivery_mode: Message delivery mode
                (1=transient, 2=persistent).

        Raises:
            SinkError: If pika is not installed.
        """
        try:
            import pika  # noqa: F401
        except ImportError:
            raise SinkError(
                "pika is required for RabbitMQSink. "
                "Install with: pip install pygubernator[rabbitmq]",
                sink_type="rabbitmq",
            ) from None

        self._url = url
        self._exchange = exchange
        self._routing_key = routing_key or (queue or "")
        self._queue = queue
        self._declare_queue = declare_queue
        self._delivery_mode = delivery_mode
        self._connection: Any = None
        self._channel: Any = None

    def _connect(self) -> Any:
        """Lazily create connection and channel."""
        if self._connection is None or self._connection.is_closed:
            import pika

            params = pika.URLParameters(self._url)
            self._connection = pika.BlockingConnection(params)
            self._channel = self._connection.channel()

            if self._queue and self._declare_queue:
                self._channel.queue_declare(queue=self._queue, durable=True)
                logger.debug("declared queue %s", self._queue)

        return self._channel

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Publish records to RabbitMQ.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        if not records:
            return SinkResult(
                success=True,
                records_sent=0,
                sink_type="rabbitmq",
            )

        import pika

        total_sent = 0
        errors: list[str] = []

        try:
            channel = self._connect()

            properties = pika.BasicProperties(
                delivery_mode=self._delivery_mode,
                content_type="application/json",
            )

            for record in records:
                body = json.dumps(record).encode("utf-8")
                channel.basic_publish(
                    exchange=self._exchange,
                    routing_key=self._routing_key,
                    body=body,
                    properties=properties,
                )
                total_sent += 1

        except Exception as exc:
            msg = f"RabbitMQ publish failed: {exc}"
            errors.append(msg)
            logger.warning("rabbitmq sink error: %s", msg)

        success = len(errors) == 0

        if success:
            logger.info(
                "published %d records to %s/%s",
                total_sent,
                self._exchange or "(default)",
                self._routing_key,
            )

        return SinkResult(
            success=success,
            records_sent=total_sent,
            sink_type="rabbitmq",
            errors=tuple(errors),
            metadata={
                "exchange": self._exchange,
                "routing_key": self._routing_key,
                "url": _mask_amqp_url(self._url),
            },
        )

    def close(self) -> None:
        """Close the RabbitMQ connection."""
        if self._connection is not None and not self._connection.is_closed:
            self._connection.close()
        self._connection = None
        self._channel = None


def _mask_amqp_url(url: str) -> str:
    """Mask password in an AMQP URL for safe logging."""
    if "@" in url and ":" in url.split("@")[0]:
        prefix, rest = url.split("@", 1)
        scheme_user = prefix.rsplit(":", 1)[0]
        return f"{scheme_user}:***@{rest}"
    return url


# ---------------------------------------------------------------------------
# Sink factory registration
# ---------------------------------------------------------------------------


def _validate(config: dict[str, Any]) -> None:
    """Require the ``url`` key."""
    if not config.get("url"):
        raise SinkError("RabbitMQ sink requires 'url'", sink_type="rabbitmq")


def _build(config: dict[str, Any]) -> RabbitMQSink:
    """Build a :class:`RabbitMQSink` from a config dict."""
    return RabbitMQSink(
        config["url"],
        exchange=config.get("exchange", ""),
        routing_key=config.get("routing_key", ""),
        queue=config.get("queue"),
        declare_queue=config.get("declare_queue", True),
    )


def _factory() -> Any:
    """Return the :class:`SinkFactory` for this sink."""
    from pygubernator.connectors._sink_registry import SinkFactory

    return SinkFactory(
        type_name="rabbitmq",
        build=_build,
        validate=_validate,
        description="Publishes JSON-encoded records to a RabbitMQ exchange.",
    )


FACTORY = _factory()
