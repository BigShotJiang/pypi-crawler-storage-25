"""Multi-sink that fans out records to multiple sinks.

Sends the same batch of records to every configured sink and
aggregates results. Useful for writing to both a file and Kafka,
or any combination of sink targets.
"""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.connectors._types import SinkResult
from pygubernator.connectors.errors import SinkError

logger = logging.getLogger(__name__)


class MultiSink:
    """Fan-out sink: sends records to multiple sinks and aggregates results.

    Args:
        sinks: List of sink instances (each must implement ``send``
            and ``close``).

    Raises:
        SinkError: If the sinks list is empty.
    """

    def __init__(self, sinks: list[Any]) -> None:
        if not sinks:
            raise SinkError(
                "MultiSink requires at least one sink",
                sink_type="multi",
            )
        self._sinks = list(sinks)

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send records to all sinks and aggregate results.

        Calls ``send`` on every sink even if one fails, so that
        partial delivery is maximised. Returns ``success=True``
        only when *all* sinks succeed.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            Aggregated SinkResult across all sinks.
        """
        all_errors: list[str] = []
        total_sent = 0
        all_success = True
        per_sink_meta: list[dict[str, Any]] = []

        for idx, sink in enumerate(self._sinks):
            try:
                result = sink.send(records, metadata)
                total_sent += result.records_sent
                if not result.success:
                    all_success = False
                    all_errors.extend(result.errors)
                per_sink_meta.append(
                    {
                        "index": idx,
                        "sink_type": result.sink_type,
                        "success": result.success,
                        "records_sent": result.records_sent,
                    }
                )
            except Exception as exc:
                all_success = False
                all_errors.append(f"Sink {idx} failed: {exc}")
                per_sink_meta.append(
                    {
                        "index": idx,
                        "sink_type": getattr(sink, "sink_type", "unknown"),
                        "success": False,
                        "error": str(exc),
                    }
                )

        logger.info(
            "multi-sink sent to %d sinks, %d total records delivered",
            len(self._sinks),
            total_sent,
        )

        return SinkResult(
            success=all_success,
            records_sent=total_sent,
            sink_type="multi",
            errors=tuple(all_errors),
            metadata={"sinks": per_sink_meta},
        )

    def close(self) -> None:
        """Close all wrapped sinks."""
        for sink in self._sinks:
            try:
                sink.close()
            except Exception:
                logger.warning("error closing sink in MultiSink", exc_info=True)
