"""Sink connector implementations."""

from __future__ import annotations

from pygubernator.connectors.sinks.console import ConsoleSink
from pygubernator.connectors.sinks.file import FileSink
from pygubernator.connectors.sinks.http import AsyncHttpSink, HttpSink
from pygubernator.connectors.sinks.memory import InMemorySink
from pygubernator.connectors.sinks.multi import MultiSink

# Optional sinks — guarded imports for heavy dependencies.

__all__ = [
    "AsyncHttpSink",
    "ConsoleSink",
    "FileSink",
    "HttpSink",
    "InMemorySink",
    "MultiSink",
]

try:
    from pygubernator.connectors.sinks.database import DatabaseSink

    __all__.append("DatabaseSink")
except ImportError:
    pass

try:
    from pygubernator.connectors.sinks.kafka import KafkaSink

    __all__.append("KafkaSink")
except ImportError:
    pass

try:
    from pygubernator.connectors.sinks.rabbitmq import RabbitMQSink

    __all__.append("RabbitMQSink")
except ImportError:
    pass

try:
    from pygubernator.connectors.sinks.s3 import S3Sink

    __all__.append("S3Sink")
except ImportError:
    pass
