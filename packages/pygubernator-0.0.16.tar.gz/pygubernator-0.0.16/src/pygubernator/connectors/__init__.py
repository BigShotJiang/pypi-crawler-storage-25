"""Connector layer for pygubernator — sinks, sources, and transport.

The :data:`DEFAULT_SINK_REGISTRY` and :data:`DEFAULT_SOURCE_REGISTRY`
are pre-populated with every first-party sink and source type. Third
parties contribute new types via the ``pygubernator.sinks`` and
``pygubernator.sources`` setuptools entry-point groups; call
:func:`discover_sink_plugins` / :func:`discover_source_plugins` (or the
matching ``discover_*_bundles`` helpers in :mod:`pygubernator.packaging`)
to register them.

Extension points at a glance:

=========  =====================================  =======================
Kind       Registry                               Entry-point group
=========  =====================================  =======================
Sink       :data:`DEFAULT_SINK_REGISTRY`          ``pygubernator.sinks``
Source     :data:`DEFAULT_SOURCE_REGISTRY`        ``pygubernator.sources``
Node       :class:`pygubernator.workflow.NodeTypeRegistry`  ``pygubernator.nodes``
Tool       :class:`pygubernator.tools.ToolRegistry`         ``pygubernator.tools``
=========  =====================================  =======================
"""

from __future__ import annotations

from pygubernator.connectors._sink_registry import (
    SinkFactory,
    SinkFactoryRegistry,
)
from pygubernator.connectors._source_registry import (
    SourceFactory,
    SourceFactoryRegistry,
)
from pygubernator.connectors._types import (
    AsyncSink,
    AsyncSource,
    Sink,
    SinkResult,
    Source,
    SourceResult,
)
from pygubernator.connectors.errors import ConnectorError, SinkError, SourceError
from pygubernator.connectors.spec import (
    CONNECTOR_SPEC_V1,
    SUPPORTED_CONNECTOR_SPEC_VERSIONS,
    ConnectorFieldSpec,
    ConnectorKind,
    ConnectorSpec,
    ConnectorSpecError,
    coerce_connector_spec,
)

# Module-level default registries pre-populated with every built-in type.
DEFAULT_SINK_REGISTRY: SinkFactoryRegistry = SinkFactoryRegistry()
DEFAULT_SOURCE_REGISTRY: SourceFactoryRegistry = SourceFactoryRegistry()


def _populate_default_registries() -> None:
    """Register every first-party sink and source into the defaults."""
    from pygubernator.connectors._builtin_sinks import register_builtin_sinks
    from pygubernator.connectors._builtin_sources import register_builtin_sources

    register_builtin_sinks(DEFAULT_SINK_REGISTRY)
    register_builtin_sources(DEFAULT_SOURCE_REGISTRY)


_populate_default_registries()


def discover_sink_plugins(
    *,
    registry: SinkFactoryRegistry | None = None,
    group: str = "pygubernator.sinks",
) -> int:
    """Register sink plugins from installed entry points.

    Thin wrapper over :meth:`SinkFactoryRegistry.discover_plugins` that
    defaults to :data:`DEFAULT_SINK_REGISTRY`. Call it once at
    application startup if your deployment depends on third-party
    sinks.

    Args:
        registry: Target registry. Defaults to
            :data:`DEFAULT_SINK_REGISTRY`.
        group: Entry-point group to scan.

    Returns:
        Number of newly registered sink types.
    """
    target = registry if registry is not None else DEFAULT_SINK_REGISTRY
    return target.discover_plugins(group=group)


def discover_source_plugins(
    *,
    registry: SourceFactoryRegistry | None = None,
    group: str = "pygubernator.sources",
) -> int:
    """Register source plugins from installed entry points.

    Thin wrapper over :meth:`SourceFactoryRegistry.discover_plugins`
    that defaults to :data:`DEFAULT_SOURCE_REGISTRY`.

    Args:
        registry: Target registry. Defaults to
            :data:`DEFAULT_SOURCE_REGISTRY`.
        group: Entry-point group to scan.

    Returns:
        Number of newly registered source types.
    """
    target = registry if registry is not None else DEFAULT_SOURCE_REGISTRY
    return target.discover_plugins(group=group)


__all__ = [
    "DEFAULT_SINK_REGISTRY",
    "DEFAULT_SOURCE_REGISTRY",
    "AsyncSink",
    "AsyncSource",
    "ConnectorError",
    "CONNECTOR_SPEC_V1",
    "SUPPORTED_CONNECTOR_SPEC_VERSIONS",
    "ConnectorFieldSpec",
    "ConnectorKind",
    "ConnectorSpec",
    "ConnectorSpecError",
    "Sink",
    "SinkError",
    "SinkFactory",
    "SinkFactoryRegistry",
    "SinkResult",
    "Source",
    "SourceError",
    "SourceFactory",
    "SourceFactoryRegistry",
    "SourceResult",
    "discover_sink_plugins",
    "discover_source_plugins",
    "coerce_connector_spec",
]
