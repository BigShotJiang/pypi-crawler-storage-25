"""Source factory entry points for PyGubernator connector nodes.

Backed by the
:class:`~pygubernator.connectors._source_registry.SourceFactoryRegistry`.
New source types are added by registering a :class:`SourceFactory` into
:data:`~pygubernator.connectors.DEFAULT_SOURCE_REGISTRY` (in-process) or
by publishing a ``pygubernator.sources`` entry point (from a plugin
package).

The public ``create_source`` / ``validate_source_config`` signatures
are intentionally positional-compatible with previous releases so
existing callers continue to work unchanged.
"""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._source_registry import SourceFactoryRegistry
from pygubernator.connectors._types import AsyncSource, Source


def _registry(registry: SourceFactoryRegistry | None) -> SourceFactoryRegistry:
    """Resolve a registry, defaulting to :data:`DEFAULT_SOURCE_REGISTRY`."""
    if registry is not None:
        return registry
    from pygubernator.connectors import DEFAULT_SOURCE_REGISTRY

    return DEFAULT_SOURCE_REGISTRY


def validate_source_config(
    source_type: str,
    config: dict[str, Any],
    *,
    registry: SourceFactoryRegistry | None = None,
) -> None:
    """Validate a config dict for a given source type.

    Args:
        source_type: Source type identifier (e.g. ``"http"``).
        config: Source-specific configuration.
        registry: Optional override registry (testing / bespoke hosts).
            Defaults to
            :data:`pygubernator.connectors.DEFAULT_SOURCE_REGISTRY`.

    Raises:
        SourceError: If the source type is unknown or required config
            is missing.
    """
    _registry(registry).validate(source_type, config)


def create_source(
    source_type: str,
    config: dict[str, Any],
    *,
    registry: SourceFactoryRegistry | None = None,
) -> Source | AsyncSource:
    """Create a source instance from a type name and config dict.

    Args:
        source_type: Source type identifier (e.g. ``"file"``, ``"http"``).
        config: Source-specific configuration dictionary.
        registry: Optional override registry. Defaults to
            :data:`pygubernator.connectors.DEFAULT_SOURCE_REGISTRY`.

    Returns:
        A configured source implementing :class:`Source` or
        :class:`AsyncSource`.

    Raises:
        SourceError: If the source type is unknown or required config
            is missing.
    """
    return _registry(registry).create(source_type, config)
