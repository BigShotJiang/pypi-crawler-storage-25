"""Registry of sink factories for the connectors layer.

Mirrors the ``NodeTypeRegistry`` / ``ToolRegistry`` pattern used elsewhere
in the package so contributors can add a new sink without modifying the
core if/elif factory.

A :class:`SinkFactory` captures the three pieces of information needed to
make a sink pluggable:

1. the stable ``type_name`` used in YAML specs,
2. a ``build`` callable that turns a config dict into a live
   :class:`~pygubernator.connectors._types.Sink` (or async variant), and
3. a ``validate`` callable that raises
   :class:`~pygubernator.connectors.errors.SinkError` when required keys
   are missing.

Third-party packages register new factories via the
``pygubernator.sinks`` entry-point group — see
:mod:`pygubernator.packaging._bundles`.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from typing import Any

from pygubernator.connectors._types import AsyncSink, Sink
from pygubernator.connectors.errors import SinkError
from pygubernator.connectors.spec import (
    ConnectorSpec,
    coerce_connector_spec,
)

logger = logging.getLogger(__name__)


SinkBuild = Callable[[dict[str, Any]], Sink | AsyncSink]
SinkValidate = Callable[[dict[str, Any]], None]


def _noop_validate(_config: dict[str, Any]) -> None:
    """Default validator — accepts any config."""


@dataclass(frozen=True, slots=True)
class SinkFactory:
    """Build + validate contract for one sink type.

    Attributes:
        type_name: Stable identifier used in YAML specs (e.g. ``"kafka"``).
        build: Callable that turns a config dict into a sink instance.
        validate: Callable that raises :class:`SinkError` when required
            config keys are missing. Defaults to a no-op validator.
        description: Short human-readable summary for docs / UI.
    """

    type_name: str
    build: SinkBuild
    validate: SinkValidate = field(default=_noop_validate)
    description: str = ""
    spec: ConnectorSpec | dict[str, Any] | None = None


class SinkFactoryRegistry:
    """Registry of sink factories keyed by case-insensitive type name.

    Example:
        >>> registry = SinkFactoryRegistry()
        >>> registry.register(SinkFactory("memory", build=_build_memory))
        >>> sink = registry.create("memory", {})
    """

    def __init__(self) -> None:
        self._factories: dict[str, SinkFactory] = {}

    # -- Registration ------------------------------------------------------

    def register(
        self,
        factory: SinkFactory,
        *,
        overwrite: bool = False,
    ) -> None:
        """Register a sink factory.

        Args:
            factory: Factory describing a sink type.
            overwrite: If False (default), re-registering an existing
                type raises :class:`SinkError`. Pass True to replace.

        Raises:
            SinkError: If ``factory.type_name`` is already registered
                and ``overwrite`` is False.
        """
        key = factory.type_name.lower().strip()
        if not key:
            raise SinkError(
                "Sink factory type_name must be a non-empty string",
                sink_type=factory.type_name,
            )
        if key in self._factories and not overwrite:
            raise SinkError(
                f"Sink type '{factory.type_name}' is already registered",
                sink_type=factory.type_name,
            )
        try:
            normalized_spec = coerce_connector_spec(
                factory.spec,
                expected_kind="sink",
                type_name=key,
                description=factory.description,
            )
        except ValueError as exc:
            raise SinkError(
                f"Invalid connector spec for sink type '{factory.type_name}': {exc}",
                sink_type=factory.type_name,
            ) from exc

        self._factories[key] = replace(factory, type_name=key, spec=normalized_spec)
        logger.debug("registered sink type: %s", key)

    def unregister(self, type_name: str) -> None:
        """Remove a registered sink type.

        Args:
            type_name: Sink type to remove.

        Raises:
            SinkError: If the type is not registered.
        """
        key = type_name.lower().strip()
        if key not in self._factories:
            raise SinkError(
                f"Sink type '{type_name}' not found",
                sink_type=type_name,
            )
        del self._factories[key]

    # -- Lookup ------------------------------------------------------------

    def get(self, type_name: str) -> SinkFactory:
        """Resolve a factory by type name.

        Args:
            type_name: Sink type identifier.

        Returns:
            The registered factory.

        Raises:
            SinkError: If the type is not registered.
        """
        key = type_name.lower().strip()
        try:
            return self._factories[key]
        except KeyError as exc:
            raise SinkError(
                f"Unknown sink type: '{type_name}'",
                sink_type=type_name,
            ) from exc

    def has(self, type_name: str) -> bool:
        """Return True if ``type_name`` is registered."""
        return type_name.lower().strip() in self._factories

    def list_types(self) -> list[str]:
        """List all registered sink type names in sorted order."""
        return sorted(self._factories.keys())

    def get_spec(self, type_name: str) -> ConnectorSpec:
        """Return normalized connector spec metadata for ``type_name``."""
        factory = self.get(type_name)
        assert isinstance(factory.spec, ConnectorSpec)
        return factory.spec

    # -- Convenience: validate + build in one call -------------------------

    def validate(self, type_name: str, config: dict[str, Any]) -> None:
        """Validate a config dict against the factory for ``type_name``."""
        factory = self.get(type_name)
        factory.validate(config)

    def create(self, type_name: str, config: dict[str, Any]) -> Sink | AsyncSink:
        """Validate config and build a sink instance.

        Args:
            type_name: Sink type identifier.
            config: Sink-specific configuration.

        Returns:
            A configured sink implementing :class:`Sink` or
            :class:`AsyncSink`.

        Raises:
            SinkError: If the type is unknown or required config is
                missing.
        """
        factory = self.get(type_name)
        factory.validate(config)
        return factory.build(config)

    # -- Plugin discovery --------------------------------------------------

    def discover_plugins(
        self,
        *,
        group: str = "pygubernator.sinks",
    ) -> int:
        """Register sink factories from installed entry points.

        Each entry point must resolve to one of:

        - a :class:`SinkFactory` instance, or
        - a callable ``register(registry)`` that registers one or more
          factories into the supplied registry.

        Args:
            group: Entry-point group to scan.

        Returns:
            Number of newly registered sink types.
        """
        from importlib.metadata import entry_points

        registered = 0
        for ep in entry_points(group=group):
            try:
                target = ep.load()
            except Exception:
                logger.warning(
                    "failed to load sink plugin entry point: %s (%s)",
                    ep.name,
                    ep.value,
                    exc_info=True,
                )
                continue

            before = len(self)
            try:
                if isinstance(target, SinkFactory):
                    if not self.has(target.type_name):
                        self.register(target)
                elif callable(target):
                    target(self)
                else:
                    logger.warning(
                        "sink plugin entry point %s did not resolve to "
                        "a SinkFactory or callable (got %r)",
                        ep.name,
                        type(target).__name__,
                    )
                    continue
            except Exception:
                logger.warning(
                    "sink plugin entry point raised: %s (%s)",
                    ep.name,
                    ep.value,
                    exc_info=True,
                )
                continue

            added = len(self) - before
            if added:
                logger.info("registered %d sink type(s) from %s", added, ep.name)
            registered += added
        return registered

    # -- Dunder methods ----------------------------------------------------

    def __len__(self) -> int:
        return len(self._factories)

    def __contains__(self, type_name: object) -> bool:
        if not isinstance(type_name, str):
            return False
        return type_name.lower().strip() in self._factories


__all__ = [
    "SinkBuild",
    "SinkFactory",
    "SinkFactoryRegistry",
    "SinkValidate",
]
