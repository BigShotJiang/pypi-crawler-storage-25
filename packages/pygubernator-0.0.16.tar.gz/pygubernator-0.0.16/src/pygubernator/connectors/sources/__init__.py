"""Source connectors (read from external systems).

Provides implementations for reading data from files, databases,
HTTP endpoints, and in-memory stores. Sources complement sinks
by pulling data into workflows from external systems.
"""

from __future__ import annotations

import logging

from pygubernator.connectors._types import AsyncSource, Source, SourceResult
from pygubernator.connectors.sources.file import FileSource
from pygubernator.connectors.sources.memory import InMemorySource

_logger = logging.getLogger(__name__)

__all__ = [
    "AsyncSource",
    "FileSource",
    "InMemorySource",
    "Source",
    "SourceResult",
]

try:
    from pygubernator.connectors.sources.http import HttpSource

    __all__ += ["HttpSource"]
except ImportError:
    _logger.debug("optional source unavailable: http (missing httpx)")

try:
    from pygubernator.connectors.sources.database import DatabaseSource

    __all__ += ["DatabaseSource"]
except ImportError:
    _logger.debug("optional source unavailable: database (missing sqlalchemy)")
