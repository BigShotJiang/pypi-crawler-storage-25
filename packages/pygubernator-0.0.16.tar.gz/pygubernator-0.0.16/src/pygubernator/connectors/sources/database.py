"""Database source — reads records via SQL query."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError

logger = logging.getLogger(__name__)

try:
    import sqlalchemy

    _HAS_SQLALCHEMY = True
except ImportError:  # pragma: no cover
    _HAS_SQLALCHEMY = False


class DatabaseSource:
    """Reads records from a database using a SQL query.

    Executes the configured query and returns all rows as dicts.
    Supports any database backend supported by SQLAlchemy.

    Args:
        connection_url: SQLAlchemy connection string.
        query: SQL SELECT query to execute.
        params: Optional query parameters for bind variables.
        batch_size: Maximum rows to return (0 = unlimited).

    Raises:
        SourceError: If sqlalchemy is not installed.
    """

    def __init__(
        self,
        connection_url: str,
        query: str,
        *,
        params: dict[str, Any] | None = None,
        batch_size: int = 0,
    ) -> None:
        if not _HAS_SQLALCHEMY:
            raise SourceError(
                "sqlalchemy is required for DatabaseSource: "
                "pip install pygubernator[db]",
                source_type="database",
            )
        self._connection_url = connection_url
        self._query = query
        self._params = params or {}
        self._batch_size = batch_size
        self._engine: Any = None

    def _get_engine(self) -> Any:
        """Lazily create the SQLAlchemy engine."""
        if self._engine is None:
            self._engine = sqlalchemy.create_engine(self._connection_url)
        return self._engine

    def read(self) -> SourceResult:
        """Execute the query and return records.

        Returns:
            SourceResult with the queried records.

        Raises:
            SourceError: If the query fails.
        """
        engine = self._get_engine()
        try:
            with engine.connect() as conn:
                result = conn.execute(
                    sqlalchemy.text(self._query),
                    self._params,
                )
                columns = list(result.keys())
                rows = result.fetchall()

            if self._batch_size > 0:
                rows = rows[: self._batch_size]

            records = [dict(zip(columns, row, strict=True)) for row in rows]
        except Exception as exc:
            raise SourceError(
                f"Database query failed: {exc}",
                source_type="database",
            ) from exc

        logger.debug(
            "read %d records from database query",
            len(records),
        )
        return SourceResult(
            success=True,
            records=records,
            records_read=len(records),
            source_type="database",
            metadata={
                "query": self._query,
                "connection_url": _mask_url(self._connection_url),
            },
        )

    def close(self) -> None:
        """Dispose the SQLAlchemy engine if created."""
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None


def _mask_url(url: str) -> str:
    """Mask password in connection URLs for safe logging."""
    if "@" in url and ":" in url.split("@")[0]:
        parts = url.split("@")
        creds = parts[0]
        colon_idx = creds.rfind(":")
        masked = creds[:colon_idx] + ":***"
        return masked + "@" + "@".join(parts[1:])
    return url


# ---------------------------------------------------------------------------
# Source factory registration
# ---------------------------------------------------------------------------


def _validate(config: dict[str, Any]) -> None:
    """Require the ``connection_url`` and ``query`` keys."""
    if not config.get("connection_url"):
        raise SourceError(
            "Database source requires 'connection_url'",
            source_type="database",
        )
    if not config.get("query"):
        raise SourceError(
            "Database source requires 'query'",
            source_type="database",
        )


def _build(config: dict[str, Any]) -> DatabaseSource:
    """Build a :class:`DatabaseSource` from a config dict."""
    return DatabaseSource(
        config["connection_url"],
        config["query"],
        params=config.get("params"),
        batch_size=config.get("batch_size", 0),
    )


def _factory() -> Any:
    """Return the :class:`SourceFactory` for this source."""
    from pygubernator.connectors._source_registry import SourceFactory

    return SourceFactory(
        type_name="database",
        build=_build,
        validate=_validate,
        description="Reads records from a SQL query via SQLAlchemy.",
    )


FACTORY = _factory()
