"""Source protocol and base types for read connectors.

Re-exports the canonical :class:`Source`, :class:`AsyncSource`, and
:class:`SourceResult` from :mod:`pygubernator.connectors._types` so
source implementations can import from this module directly.
"""

from __future__ import annotations

from pygubernator.connectors._types import AsyncSource, Source, SourceResult

__all__ = [
    "AsyncSource",
    "Source",
    "SourceResult",
]
