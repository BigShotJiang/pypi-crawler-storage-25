"""File source — reads records from JSON, CSV, or JSONL files."""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any

from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError

logger = logging.getLogger(__name__)

_SUPPORTED_FORMATS = {"json", "jsonl", "csv"}


class FileSource:
    """Reads records from a local file.

    Supports JSON (array of objects), JSONL (one JSON object per line),
    and CSV (header row + data rows).

    Args:
        path: Path to the data file.
        format: File format (``json``, ``jsonl``, ``csv``).
            Auto-detected from extension if not specified.

    Raises:
        SourceError: If the format is unsupported or the file is missing.
    """

    def __init__(
        self,
        path: str | Path,
        format: str | None = None,
    ) -> None:
        self._path = Path(path)
        self._format = (format or self._detect_format()).lower()
        if self._format not in _SUPPORTED_FORMATS:
            raise SourceError(
                f"Unsupported file format: '{self._format}' "
                f"(supported: {sorted(_SUPPORTED_FORMATS)})",
                source_type="file",
            )

    def _detect_format(self) -> str:
        """Infer format from file extension."""
        suffix = self._path.suffix.lower().lstrip(".")
        if suffix in _SUPPORTED_FORMATS:
            return suffix
        return "json"

    def read(self) -> SourceResult:
        """Read all records from the file.

        Returns:
            SourceResult with the parsed records.

        Raises:
            SourceError: If the file cannot be read or parsed.
        """
        try:
            text = self._path.read_text(encoding="utf-8")
        except FileNotFoundError:
            raise SourceError(
                f"File not found: {self._path}",
                source_type="file",
            ) from None
        except OSError as exc:
            raise SourceError(
                f"Cannot read file {self._path}: {exc}",
                source_type="file",
            ) from exc

        try:
            records = self._parse(text)
        except (json.JSONDecodeError, ValueError) as exc:
            raise SourceError(
                f"Failed to parse {self._path}: {exc}",
                source_type="file",
            ) from exc

        logger.debug(
            "read %d records from %s (%s)",
            len(records),
            self._path,
            self._format,
        )
        return SourceResult(
            success=True,
            records=records,
            records_read=len(records),
            source_type="file",
            metadata={
                "path": str(self._path),
                "format": self._format,
            },
        )

    def _parse(self, text: str) -> list[dict[str, Any]]:
        """Parse file content into records."""
        if self._format == "json":
            data = json.loads(text)
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                return [data]
            raise ValueError(
                f"Expected JSON array or object, got {type(data).__name__}"
            )

        if self._format == "jsonl":
            records: list[dict[str, Any]] = []
            for line in text.splitlines():
                stripped = line.strip()
                if stripped:
                    records.append(json.loads(stripped))
            return records

        # CSV — filter out rows where DictReader assigned None keys
        # (happens when data rows have more columns than the header).
        reader = csv.DictReader(text.splitlines())
        return [{k: v for k, v in row.items() if k is not None} for row in reader]

    def close(self) -> None:
        """No-op — file handles are not held open."""


# ---------------------------------------------------------------------------
# Source factory registration
# ---------------------------------------------------------------------------


def _validate(config: dict[str, Any]) -> None:
    """Require the ``path`` key."""
    if not config.get("path"):
        raise SourceError(
            "File source requires 'path' in config",
            source_type="file",
        )


def _build(config: dict[str, Any]) -> FileSource:
    """Build a :class:`FileSource` from a config dict."""
    return FileSource(
        config["path"],
        format=config.get("format"),
    )


def _factory() -> Any:
    """Return the :class:`SourceFactory` for this source."""
    from pygubernator.connectors._source_registry import SourceFactory

    return SourceFactory(
        type_name="file",
        build=_build,
        validate=_validate,
        description="Reads records from a local JSON/JSONL/CSV file.",
    )


FACTORY = _factory()
