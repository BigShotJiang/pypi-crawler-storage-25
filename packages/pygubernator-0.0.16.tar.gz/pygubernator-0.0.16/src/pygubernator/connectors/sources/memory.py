"""In-memory source for testing and prototyping."""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SourceResult


class InMemorySource:
    """Source that yields pre-loaded records from memory.

    Useful for testing, prototyping, and injecting static data
    into workflows.

    Args:
        records: List of records to return on read.

    Example:
        >>> source = InMemorySource([{"name": "Alice"}, {"name": "Bob"}])
        >>> result = source.read()
        >>> result.records_read
        2
    """

    def __init__(self, records: list[dict[str, Any]] | None = None) -> None:
        self._records = list(records or [])
        self._read_count = 0

    def read(self) -> SourceResult:
        """Return all stored records.

        Returns:
            SourceResult with the pre-loaded records.
        """
        self._read_count += 1
        return SourceResult(
            success=True,
            records=list(self._records),
            records_read=len(self._records),
            source_type="memory",
            metadata={"read_count": self._read_count},
        )

    def close(self) -> None:
        """No-op for in-memory source."""

    # -- Test helpers -------------------------------------------------------

    def load(self, records: list[dict[str, Any]]) -> None:
        """Replace the stored records.

        Args:
            records: New records to serve on next read.
        """
        self._records = list(records)

    def append(self, record: dict[str, Any]) -> None:
        """Add a single record to the store.

        Args:
            record: Record to append.
        """
        self._records.append(record)

    @property
    def record_count(self) -> int:
        """Number of records currently stored."""
        return len(self._records)


# ---------------------------------------------------------------------------
# Source factory registration
# ---------------------------------------------------------------------------


def _build(config: dict[str, Any]) -> InMemorySource:
    """Build an :class:`InMemorySource` from a config dict."""
    return InMemorySource(records=config.get("records"))


def _factory() -> Any:
    """Return the :class:`SourceFactory` for this source.

    Lazy construction avoids a circular import with
    :mod:`pygubernator.connectors._source_registry`.
    """
    from pygubernator.connectors._source_registry import SourceFactory

    return SourceFactory(
        type_name="memory",
        build=_build,
        description="In-process source that yields pre-loaded records.",
    )


FACTORY = _factory()
