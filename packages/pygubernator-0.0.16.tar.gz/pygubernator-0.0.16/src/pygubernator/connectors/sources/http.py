"""HTTP source — reads records from a REST API endpoint."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.connectors._types import SourceResult
from pygubernator.connectors.errors import SourceError

logger = logging.getLogger(__name__)

try:
    import httpx

    _HAS_HTTPX = True
except ImportError:  # pragma: no cover
    _HAS_HTTPX = False


class HttpSource:
    """Reads records from an HTTP GET endpoint.

    Expects the response body to be a JSON array of objects, or a JSON
    object with a configurable ``records_key`` field containing the array.

    Args:
        url: The endpoint URL.
        headers: Optional request headers.
        params: Optional query parameters.
        records_key: JSON key containing the records array.
            If ``None``, the top-level response is treated as the array.
        timeout: Request timeout in seconds.
        auth_token: Bearer token for Authorization header.

    Raises:
        SourceError: If httpx is not installed.
    """

    def __init__(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        params: dict[str, str] | None = None,
        records_key: str | None = None,
        timeout: float = 30.0,
        auth_token: str | None = None,
    ) -> None:
        if not _HAS_HTTPX:
            raise SourceError(
                "httpx is required for HttpSource: "
                "pip install pygubernator[integrations]",
                source_type="http",
            )
        self._url = url
        self._headers = dict(headers or {})
        self._params = dict(params or {})
        self._records_key = records_key
        self._timeout = timeout
        if auth_token:
            self._headers["Authorization"] = f"Bearer {auth_token}"

    def read(self) -> SourceResult:
        """Fetch records from the HTTP endpoint.

        Returns:
            SourceResult with the fetched records.

        Raises:
            SourceError: If the request fails or response is malformed.
        """
        try:
            resp = httpx.get(
                self._url,
                headers=self._headers,
                params=self._params,
                timeout=self._timeout,
            )
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise SourceError(
                f"HTTP request failed: {exc}",
                source_type="http",
            ) from exc

        try:
            body = resp.json()
        except ValueError as exc:
            raise SourceError(
                f"Response is not valid JSON: {exc}",
                source_type="http",
            ) from exc

        records = self._extract_records(body)
        logger.debug("read %d records from %s", len(records), self._url)
        return SourceResult(
            success=True,
            records=records,
            records_read=len(records),
            source_type="http",
            metadata={
                "url": self._url,
                "status_code": resp.status_code,
            },
        )

    def _extract_records(self, body: Any) -> list[dict[str, Any]]:
        """Extract the records array from the response body."""
        if self._records_key is not None:
            if not isinstance(body, dict):
                raise SourceError(
                    f"Expected JSON object with key '{self._records_key}'",
                    source_type="http",
                )
            data = body.get(self._records_key)
            if data is None:
                raise SourceError(
                    f"Key '{self._records_key}' not found in response",
                    source_type="http",
                )
        else:
            data = body

        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return [data]
        raise SourceError(
            f"Expected JSON array, got {type(data).__name__}",
            source_type="http",
        )

    def close(self) -> None:
        """No-op — HTTP connections are not held open."""


# ---------------------------------------------------------------------------
# Source factory registration
# ---------------------------------------------------------------------------


def _validate(config: dict[str, Any]) -> None:
    """Require the ``url`` key."""
    if not config.get("url"):
        raise SourceError(
            "HTTP source requires 'url' in config",
            source_type="http",
        )


def _build(config: dict[str, Any]) -> HttpSource:
    """Build an :class:`HttpSource` from a config dict."""
    return HttpSource(
        config["url"],
        headers=config.get("headers"),
        params=config.get("params"),
        records_key=config.get("records_key"),
        timeout=config.get("timeout", 30.0),
        auth_token=config.get("auth_token"),
    )


def _factory() -> Any:
    """Return the :class:`SourceFactory` for this source."""
    from pygubernator.connectors._source_registry import SourceFactory

    return SourceFactory(
        type_name="http",
        build=_build,
        validate=_validate,
        description="Fetches records from an HTTP JSON endpoint.",
    )


FACTORY = _factory()
