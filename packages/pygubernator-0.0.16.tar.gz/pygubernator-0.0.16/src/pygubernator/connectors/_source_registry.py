"""Registry of source factories for the connectors layer.

Mirrors :mod:`pygubernator.connectors._sink_registry` so sources share
the same pluggability story as sinks, nodes, and tools — register a
:class:`SourceFactory` in-process or advertise one via the
``pygubernator.sources`` setuptools entry-point group.

A :class:`SourceFactory` captures:

1. the ``type_name`` used in YAML specs,
2. a ``build`` callable that turns a config dict into a live
   :class:`~pygubernator.connectors._types.Source` (or async variant), and
3. a ``validate`` callable that raises
   :class:`~pygubernator.connectors.errors.SourceError` when required
   keys are missing.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from typing import Any

from pygubernator.connectors._types import AsyncSource, Source
from pygubernator.connectors.errors import SourceError
from pygubernator.connectors.spec import (
    ConnectorSpec,
    coerce_connector_spec,
)

logger = logging.getLogger(__name__)


SourceBuild = Callable[[dict[str, Any]], Source | AsyncSource]
SourceValidate = Callable[[dict[str, Any]], None]


def _noop_validate(_config: dict[str, Any]) -> None:
    """Default validator — accepts any config."""


@dataclass(frozen=True, slots=True)
class SourceFactory:
    """Build + validate contract for one source type.

    Attributes:
        type_name: Stable identifier used in YAML specs (e.g. ``"http"``).
        build: Callable that turns a config dict into a source instance.
        validate: Callable that raises :class:`SourceError` when required
            config keys are missing. Defaults to a no-op validator.
        description: Short human-readable summary for docs / UI.
    """

    type_name: str
    build: SourceBuild
    validate: SourceValidate = field(default=_noop_validate)
    description: str = ""
    spec: ConnectorSpec | dict[str, Any] | None = None


class SourceFactoryRegistry:
    """Registry of source factories keyed by case-insensitive type name.

    Example:
        >>> registry = SourceFactoryRegistry()
        >>> registry.register(SourceFactory("memory", build=_build_memory))
        >>> source = registry.create("memory", {})
    """

    def __init__(self) -> None:
        self._factories: dict[str, SourceFactory] = {}

    # -- Registration ------------------------------------------------------

    def register(
        self,
        factory: SourceFactory,
        *,
        overwrite: bool = False,
    ) -> None:
        """Register a source factory.

        Args:
            factory: Factory describing a source type.
            overwrite: If False (default), re-registering an existing
                type raises :class:`SourceError`. Pass True to replace.

        Raises:
            SourceError: If ``factory.type_name`` is already registered
                and ``overwrite`` is False.
        """
        key = factory.type_name.lower().strip()
        if not key:
            raise SourceError(
                "Source factory type_name must be a non-empty string",
                source_type=factory.type_name,
            )
        if key in self._factories and not overwrite:
            raise SourceError(
                f"Source type '{factory.type_name}' is already registered",
                source_type=factory.type_name,
            )
        try:
            normalized_spec = coerce_connector_spec(
                factory.spec,
                expected_kind="source",
                type_name=key,
                description=factory.description,
            )
        except ValueError as exc:
            raise SourceError(
                f"Invalid connector spec for source type '{factory.type_name}': {exc}",
                source_type=factory.type_name,
            ) from exc

        self._factories[key] = replace(factory, type_name=key, spec=normalized_spec)
        logger.debug("registered source type: %s", key)

    def unregister(self, type_name: str) -> None:
        """Remove a registered source type.

        Args:
            type_name: Source type to remove.

        Raises:
            SourceError: If the type is not registered.
        """
        key = type_name.lower().strip()
        if key not in self._factories:
            raise SourceError(
                f"Source type '{type_name}' not found",
                source_type=type_name,
            )
        del self._factories[key]

    # -- Lookup ------------------------------------------------------------

    def get(self, type_name: str) -> SourceFactory:
        """Resolve a factory by type name.

        Args:
            type_name: Source type identifier.

        Returns:
            The registered factory.

        Raises:
            SourceError: If the type is not registered.
        """
        key = type_name.lower().strip()
        try:
            return self._factories[key]
        except KeyError as exc:
            raise SourceError(
                f"Unknown source type: '{type_name}'",
                source_type=type_name,
            ) from exc

    def has(self, type_name: str) -> bool:
        """Return True if ``type_name`` is registered."""
        return type_name.lower().strip() in self._factories

    def list_types(self) -> list[str]:
        """List all registered source type names in sorted order."""
        return sorted(self._factories.keys())

    def get_spec(self, type_name: str) -> ConnectorSpec:
        """Return normalized connector spec metadata for ``type_name``."""
        factory = self.get(type_name)
        assert isinstance(factory.spec, ConnectorSpec)
        return factory.spec

    # -- Convenience: validate + build in one call -------------------------

    def validate(self, type_name: str, config: dict[str, Any]) -> None:
        """Validate a config dict against the factory for ``type_name``."""
        factory = self.get(type_name)
        factory.validate(config)

    def create(self, type_name: str, config: dict[str, Any]) -> Source | AsyncSource:
        """Validate config and build a source instance.

        Args:
            type_name: Source type identifier.
            config: Source-specific configuration.

        Returns:
            A configured source implementing :class:`Source` or
            :class:`AsyncSource`.

        Raises:
            SourceError: If the type is unknown or required config is
                missing.
        """
        factory = self.get(type_name)
        factory.validate(config)
        return factory.build(config)

    # -- Plugin discovery --------------------------------------------------

    def discover_plugins(
        self,
        *,
        group: str = "pygubernator.sources",
    ) -> int:
        """Register source factories from installed entry points.

        Each entry point must resolve to one of:

        - a :class:`SourceFactory` instance, or
        - a callable ``register(registry)`` that registers one or more
          factories into the supplied registry.

        Args:
            group: Entry-point group to scan.

        Returns:
            Number of newly registered source types.
        """
        from importlib.metadata import entry_points

        registered = 0
        for ep in entry_points(group=group):
            try:
                target = ep.load()
            except Exception:
                logger.warning(
                    "failed to load source plugin entry point: %s (%s)",
                    ep.name,
                    ep.value,
                    exc_info=True,
                )
                continue

            before = len(self)
            try:
                if isinstance(target, SourceFactory):
                    if not self.has(target.type_name):
                        self.register(target)
                elif callable(target):
                    target(self)
                else:
                    logger.warning(
                        "source plugin entry point %s did not resolve to "
                        "a SourceFactory or callable (got %r)",
                        ep.name,
                        type(target).__name__,
                    )
                    continue
            except Exception:
                logger.warning(
                    "source plugin entry point raised: %s (%s)",
                    ep.name,
                    ep.value,
                    exc_info=True,
                )
                continue

            added = len(self) - before
            if added:
                logger.info("registered %d source type(s) from %s", added, ep.name)
            registered += added
        return registered

    # -- Dunder methods ----------------------------------------------------

    def __len__(self) -> int:
        return len(self._factories)

    def __contains__(self, type_name: object) -> bool:
        if not isinstance(type_name, str):
            return False
        return type_name.lower().strip() in self._factories


__all__ = [
    "SourceBuild",
    "SourceFactory",
    "SourceFactoryRegistry",
    "SourceValidate",
]
