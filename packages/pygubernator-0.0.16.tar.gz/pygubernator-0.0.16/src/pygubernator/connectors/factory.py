"""Sink factory entry points for PyGubernator connector nodes.

Backed by the :class:`~pygubernator.connectors._sink_registry.SinkFactoryRegistry`.
New sink types are added by registering a :class:`SinkFactory` into
:data:`~pygubernator.connectors.DEFAULT_SINK_REGISTRY` (in-process) or by
publishing a ``pygubernator.sinks`` entry point (from a plugin package).

The public ``create_sink`` / ``validate_sink_config`` signatures are
intentionally positional-compatible with previous releases so existing
callers — notably :class:`pygubernator.workflow.nodes._sink.SinkNode` —
continue to work unchanged.

PyCatalyst's recipe runner keeps its own factory
(:mod:`pycatalyst.sinks.factory`) and :class:`pycatalyst.sinks.errors.SinkError`
so that library stays decoupled from pygubernator.
"""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._sink_registry import SinkFactoryRegistry
from pygubernator.connectors._types import AsyncSink, Sink


def _registry(registry: SinkFactoryRegistry | None) -> SinkFactoryRegistry:
    """Resolve a registry, defaulting to :data:`DEFAULT_SINK_REGISTRY`."""
    if registry is not None:
        return registry
    # Local import avoids a circular import at module load.
    from pygubernator.connectors import DEFAULT_SINK_REGISTRY

    return DEFAULT_SINK_REGISTRY


def validate_sink_config(
    sink_type: str,
    config: dict[str, Any],
    *,
    registry: SinkFactoryRegistry | None = None,
) -> None:
    """Validate a config dict for a given sink type.

    Args:
        sink_type: Sink type identifier (e.g. ``"file"``).
        config: Sink-specific configuration.
        registry: Optional override registry (testing / bespoke hosts).
            Defaults to
            :data:`pygubernator.connectors.DEFAULT_SINK_REGISTRY`.

    Raises:
        SinkError: If the sink type is unknown or required config is
            missing.
    """
    _registry(registry).validate(sink_type, config)


def create_sink(
    sink_type: str,
    config: dict[str, Any],
    *,
    registry: SinkFactoryRegistry | None = None,
) -> Sink | AsyncSink:
    """Create a sink instance from a type name and config dict.

    Args:
        sink_type: Sink type identifier (e.g. ``"kafka"``, ``"s3"``).
        config: Sink-specific configuration dictionary.
        registry: Optional override registry. Defaults to
            :data:`pygubernator.connectors.DEFAULT_SINK_REGISTRY`.

    Returns:
        A configured sink implementing :class:`Sink` or
        :class:`AsyncSink`.

    Raises:
        SinkError: If the sink type is unknown or required config is
            missing.
    """
    return _registry(registry).create(sink_type, config)
