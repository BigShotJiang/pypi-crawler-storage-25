"""OpenTelemetry tracing event handler."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.events._bus import AgentEvent, AgentEventType

logger = logging.getLogger(__name__)

# Event types that start a new child span.
_SPAN_START_EVENTS = frozenset(
    {
        AgentEventType.STEP_STARTED,
        AgentEventType.TOOL_CALL_STARTED,
        AgentEventType.LLM_REQUEST_STARTED,
    }
)

# Event types that end a child span.
_SPAN_END_MAP: dict[AgentEventType, AgentEventType] = {
    AgentEventType.STEP_COMPLETED: AgentEventType.STEP_STARTED,
    AgentEventType.STEP_FAILED: AgentEventType.STEP_STARTED,
    AgentEventType.TOOL_CALL_COMPLETED: AgentEventType.TOOL_CALL_STARTED,
    AgentEventType.TOOL_CALL_FAILED: AgentEventType.TOOL_CALL_STARTED,
    AgentEventType.LLM_RESPONSE_RECEIVED: AgentEventType.LLM_REQUEST_STARTED,
}


def configure_tracing(
    service_name: str = "pygubernator",
    exporter: Any | None = None,
) -> Any:
    """Configure OpenTelemetry tracing with an optional exporter.

    Args:
        service_name: Name of the service for trace metadata.
        exporter: Optional span exporter. Defaults to console exporter.

    Returns:
        The configured TracerProvider.
    """
    from opentelemetry import trace
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        ConsoleSpanExporter,
    )

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    if exporter is None:
        exporter = ConsoleSpanExporter()
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    return provider


class OTelEventHandler:
    """Translates agent events into OpenTelemetry spans.

    Creates a root span on ``RUN_STARTED`` and child spans for
    steps, tool calls, and LLM requests. Ends spans on
    corresponding completion/failure events.

    Args:
        tracer_name: Name for the OTel tracer.
        tracer_provider: Optional TracerProvider. Uses the global
            provider if not supplied.
    """

    def __init__(
        self,
        tracer_name: str = "pygubernator",
        tracer_provider: Any | None = None,
    ) -> None:
        from opentelemetry import trace

        self._tracer = trace.get_tracer(
            tracer_name,
            tracer_provider=tracer_provider,
        )
        # Active spans keyed by (agent_id, event_type_value, label).
        self._spans: dict[str, Any] = {}

    async def handle(self, event: AgentEvent) -> None:
        """Handle an agent event by managing OTel spans.

        Args:
            event: The agent event.
        """
        from opentelemetry.trace import StatusCode

        if event.event_type == AgentEventType.RUN_STARTED:
            span = self._tracer.start_span(
                name=f"run:{event.agent_id}",
                attributes={
                    "agent.id": event.agent_id,
                    "run.mode": event.data.get("mode", ""),
                },
            )
            self._spans[self._run_key(event)] = span
            return

        if event.event_type == AgentEventType.RUN_COMPLETED:
            key = self._run_key(event)
            span = self._spans.pop(key, None)
            if span is not None:
                success = event.data.get("success", True)
                if not success:
                    span.set_status(StatusCode.ERROR)
                span.end()
            return

        if event.event_type in _SPAN_START_EVENTS:
            label = self._child_label(event)
            span = self._tracer.start_span(
                name=f"{event.event_type.value}:{label}",
                attributes={"agent.id": event.agent_id},
            )
            self._spans[self._child_key(event)] = span
            return

        start_type = _SPAN_END_MAP.get(event.event_type)
        if start_type is not None:
            key = self._child_key(event, start_type)
            span = self._spans.pop(key, None)
            if span is not None:
                if "failed" in event.event_type.value:
                    span.set_status(
                        StatusCode.ERROR,
                        event.data.get("error", ""),
                    )
                span.end()

    @staticmethod
    def _run_key(event: AgentEvent) -> str:
        """Key for root run spans."""
        return f"run:{event.agent_id}"

    @staticmethod
    def _child_label(event: AgentEvent) -> str:
        """Extract a human-readable label from event data."""
        return (
            event.data.get("step_name")
            or event.data.get("tool_name")
            or str(event.data.get("iteration", ""))
        )

    @staticmethod
    def _child_key(
        event: AgentEvent,
        override_type: AgentEventType | None = None,
    ) -> str:
        """Key for child spans."""
        etype = override_type or event.event_type
        label = (
            event.data.get("step_name")
            or event.data.get("tool_name")
            or str(event.data.get("iteration", ""))
        )
        return f"{event.agent_id}:{etype.value}:{label}"
