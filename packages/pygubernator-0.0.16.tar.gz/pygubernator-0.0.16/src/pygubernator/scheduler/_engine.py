"""Background scheduler engine for cron-based workflow triggers."""

from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from datetime import UTC, datetime
from zoneinfo import ZoneInfo

from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

try:
    from croniter import croniter
except ImportError:  # pragma: no cover
    croniter = None  # type: ignore[assignment,misc]


def _parse_5field(expr: str) -> list[str] | None:
    parts = [p for p in expr.strip().split() if p]
    return parts if len(parts) == 5 else None


def _is_simple_field_ok(field: str, *, min_v: int, max_v: int) -> bool:
    if field == "*":
        return True
    if field.startswith("*/"):
        try:
            n = int(field[2:])
            return 1 <= n <= max_v
        except Exception:
            return False
    # Support MON-FRI style tokens for day-of-week only (validated separately).
    try:
        v = int(field)
        return min_v <= v <= max_v
    except Exception:
        return False


_DOW_NAMES = {"SUN": 0, "MON": 1, "TUE": 2, "WED": 3, "THU": 4, "FRI": 5, "SAT": 6}


def _is_dow_ok(field: str) -> bool:
    if field == "*":
        return True
    if field.isdigit():
        return _is_simple_field_ok(field, min_v=0, max_v=7)
    up = field.upper()
    if "-" in up:
        a, b = up.split("-", 1)
        return a in _DOW_NAMES and b in _DOW_NAMES
    return up in _DOW_NAMES


def _utcnow() -> datetime:
    """Return the current UTC datetime."""
    return datetime.now(UTC)


def compute_next_run(
    cron_expr: str,
    base_time: datetime | None = None,
    timezone: str = "UTC",
) -> datetime:
    """Compute the next run time for a cron expression.

    Args:
        cron_expr: Standard cron expression string.
        base_time: Reference time; defaults to now (UTC).

    Returns:
        Next occurrence as a timezone-aware UTC datetime.

    Raises:
        RuntimeError: If croniter is not installed.
        ValueError: If the cron expression is invalid.
    """
    zone = ZoneInfo(timezone)
    if base_time is None:
        base = datetime.now(zone)
    else:
        if base_time.tzinfo is None:
            base_time = base_time.replace(tzinfo=UTC)
        base = base_time.astimezone(zone)
    if croniter is not None:
        cron = croniter(cron_expr, base)
        next_local = cron.get_next(datetime)
        if next_local.tzinfo is None:
            next_local = next_local.replace(tzinfo=zone)
        return next_local.astimezone(UTC)

    # Fallback: support a minimal subset used in tests and common ops use.
    parts = _parse_5field(cron_expr)
    if parts is None:
        raise ValueError("Invalid cron expression")
    minute, hour, dom, month, dow = parts

    # Every minute: * * * * *
    if minute == hour == dom == month == dow == "*":
        from datetime import timedelta

        cur = base.replace(second=0, microsecond=0)
        return (cur + timedelta(minutes=1)).astimezone(UTC)

    # Support */n minute step with other fields as '*'
    if minute.startswith("*/") and hour == dom == month == dow == "*":
        from datetime import timedelta

        step = int(minute[2:])
        cur = base.replace(second=0, microsecond=0)
        # Move forward at least 1 minute, then advance until divisible.
        nxt = cur + timedelta(minutes=1)
        for _ in range(60):
            if nxt.minute % step == 0:
                return nxt.astimezone(UTC)
            nxt = nxt + timedelta(minutes=1)
        return nxt.astimezone(UTC)

    # Support daily midnight: 0 0 * * *
    if minute == "0" and hour == "0" and dom == month == dow == "*":
        cur = base.replace(second=0, microsecond=0)
        nxt = cur.replace(hour=0, minute=0)
        if nxt <= base:
            from datetime import timedelta

            nxt = nxt + timedelta(days=1)
        return nxt.astimezone(UTC)

    raise RuntimeError(
        "croniter is required for advanced scheduling. "
        "Install with: pip install croniter>=2.0.0"
    )


def validate_cron(cron_expr: str) -> bool:
    """Check whether a cron expression is syntactically valid.

    Args:
        cron_expr: Cron expression to validate.

    Returns:
        True if valid, False otherwise.
    """
    if croniter is not None:
        return croniter.is_valid(cron_expr)
    parts = _parse_5field(cron_expr)
    if parts is None:
        return False
    minute, hour, dom, month, dow = parts
    return (
        _is_simple_field_ok(minute, min_v=0, max_v=59)
        and _is_simple_field_ok(hour, min_v=0, max_v=23)
        and _is_simple_field_ok(dom, min_v=1, max_v=31)
        and _is_simple_field_ok(month, min_v=1, max_v=12)
        and _is_dow_ok(dow)
    )


class Scheduler:
    """Background scheduler that evaluates cron jobs.

    Runs in a daemon thread, polling the DB every
    ``poll_interval`` seconds for due jobs. Uses croniter
    to compute next-run times.
    """

    def __init__(
        self,
        db_session_factory: Callable[[], Session],
        poll_interval: float = 30.0,
    ) -> None:
        self._db_session_factory = db_session_factory
        self._poll_interval = poll_interval
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    # -- public API --------------------------------------------------

    def start(self) -> None:
        """Start the scheduler daemon thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="pygubernator-scheduler",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "Scheduler started (poll every %ss)",
            self._poll_interval,
        )

    def stop(self) -> None:
        """Signal the scheduler to stop."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self._poll_interval + 5)
            self._thread = None
        logger.info("Scheduler stopped")

    @property
    def running(self) -> bool:
        """Whether the scheduler thread is alive."""
        return self._thread is not None and self._thread.is_alive()

    # -- internal ----------------------------------------------------

    def _loop(self) -> None:
        """Main polling loop (runs in daemon thread)."""
        logger.info("Scheduler loop entered")
        while not self._stop_event.is_set():
            try:
                self._poll_once()
            except Exception:
                logger.error("Scheduler poll error", exc_info=True)
            self._stop_event.wait(self._poll_interval)

    def _poll_once(self) -> None:
        """Execute a single poll cycle."""
        session: Session = self._db_session_factory()
        try:
            self._evaluate_jobs(session)
        finally:
            session.close()

    def _evaluate_jobs(self, session: Session) -> None:
        """Check which jobs are due and trigger them.

        Args:
            session: Active SQLAlchemy session.
        """
        from pygubernator.db.models import ScheduledJob

        now = _utcnow()
        jobs = (
            session.query(ScheduledJob)
            .filter(
                ScheduledJob.enabled.is_(True),
                ScheduledJob.next_run_at.isnot(None),
                ScheduledJob.next_run_at <= now,
            )
            .all()
        )
        processed = 0
        for job in jobs:
            expected_next_run_at = job.next_run_at
            next_run_at = compute_next_run(
                job.cron_expression,
                now,
                timezone=job.timezone,
            )
            try:
                if self._should_skip_misfire(job, now):
                    if self._claim_due_job(
                        session,
                        job=job,
                        now=now,
                        expected_next_run_at=expected_next_run_at,
                        next_run_at=next_run_at,
                        status="skipped_misfire",
                    ):
                        processed += 1
                else:
                    if not self._claim_due_job(
                        session,
                        job=job,
                        now=now,
                        expected_next_run_at=expected_next_run_at,
                        next_run_at=next_run_at,
                        status="dispatching",
                    ):
                        continue
                    self._trigger_workflow(job, session)
                    processed += 1
            except Exception:
                logger.error(
                    "Failed to trigger job %s",
                    job.id,
                    exc_info=True,
                )
                self._update_job_status(session, job.id, "error")
        if processed:
            logger.info("Processed %d scheduled job(s)", processed)

    def _claim_due_job(
        self,
        session: Session,
        *,
        job: object,
        now: datetime,
        expected_next_run_at: datetime | None,
        next_run_at: datetime,
        status: str,
    ) -> bool:
        from pygubernator.db.models import ScheduledJob

        result = (
            session.query(ScheduledJob)
            .filter(
                ScheduledJob.id == job.id,
                ScheduledJob.enabled.is_(True),
                ScheduledJob.next_run_at == expected_next_run_at,
            )
            .update(
                {
                    ScheduledJob.last_run_at: now,
                    ScheduledJob.next_run_at: next_run_at,
                    ScheduledJob.last_status: status,
                },
                synchronize_session=False,
            )
        )
        session.commit()
        return result > 0

    def _update_job_status(
        self,
        session: Session,
        job_id: str,
        status: str,
    ) -> None:
        from pygubernator.db.models import ScheduledJob

        (
            session.query(ScheduledJob)
            .filter(ScheduledJob.id == job_id)
            .update({ScheduledJob.last_status: status}, synchronize_session=False)
        )
        session.commit()

    def _should_skip_misfire(self, job: object, now: datetime) -> bool:
        next_run_at = getattr(job, "next_run_at", None)
        if next_run_at is None:
            return False
        if getattr(next_run_at, "tzinfo", None) is None:
            next_run_at = next_run_at.replace(tzinfo=UTC)
        misfire_policy = str(getattr(job, "misfire_policy", "fire_now") or "fire_now")
        if misfire_policy != "skip":
            return False
        grace_seconds = int(getattr(job, "misfire_grace_seconds", 60) or 0)
        return (now - next_run_at).total_seconds() > grace_seconds

    def _has_active_run_for_job(
        self,
        session: Session,
        job_id: str,
    ) -> bool:
        from pygubernator.db.models.workflow_run import WorkflowRun

        active_statuses = ("pending", "claimed", "running", "awaiting_approval")
        return (
            session.query(WorkflowRun)
            .filter(
                WorkflowRun.created_by == f"scheduler:{job_id}",
                WorkflowRun.status.in_(active_statuses),
            )
            .count()
            > 0
        )

    def _trigger_workflow(
        self,
        job: object,
        session: Session,
    ) -> None:
        """Execute a workflow for a due scheduled job.

        Args:
            job: ScheduledJob row with workflow_id and input_json.
            session: Active SQLAlchemy session.
        """
        from pygubernator.db.models import ScheduledJob
        from pygubernator.db.store.sqlalchemy import (
            SQLAlchemyAgentStore,
        )

        assert isinstance(job, ScheduledJob)

        if str(
            job.concurrency_policy or "allow"
        ) == "skip" and self._has_active_run_for_job(session, job.id):
            job.last_status = "skipped_overlap"
            logger.info("Skipping overlapping scheduled job %s", job.id)
            return

        store = SQLAlchemyAgentStore(session=session)
        workflow = store.get_workflow(job.workflow_id)
        if workflow is None:
            logger.warning(
                "Workflow %s not found for job %s",
                job.workflow_id,
                job.id,
            )
            job.last_status = "error"
            return

        versions = store.list_workflow_versions(job.workflow_id)
        active = next((v for v in versions if v.active), None)
        if active is None:
            logger.warning(
                "No active version for workflow %s",
                job.workflow_id,
            )
            job.last_status = "error"
            return

        scheduled_input = build_schedule_input(
            job,
            triggered_at=_utcnow(),
            trigger_source="scheduler",
        )
        run = store.create_workflow_run(
            workflow_id=job.workflow_id,
            workflow_version_id=active.id,
            input_json=scheduled_input,
            created_by=f"scheduler:{job.id}",
        )
        session.commit()
        run_id = run.id

        logger.info(
            "Scheduler triggering workflow %s run %s",
            job.workflow_id,
            run_id[:12],
        )

        _execute_in_thread(
            active.spec_json,
            scheduled_input,
            run_id,
            self._db_session_factory,
        )
        self._update_job_status(session, job.id, "triggered")


def build_schedule_input(
    job: object,
    *,
    triggered_at: datetime,
    trigger_source: str,
) -> dict:
    """Inject schedule lineage into workflow input."""
    payload = dict(getattr(job, "input_json", {}) or {})
    payload["_schedule"] = {
        "job_id": str(getattr(job, "id", "")),
        "cron": str(getattr(job, "cron_expression", "") or ""),
        "timezone": str(getattr(job, "timezone", "UTC") or "UTC"),
        "trigger_source": trigger_source,
        "triggered_at": triggered_at.isoformat(),
        "concurrency_policy": str(
            getattr(job, "concurrency_policy", "allow") or "allow"
        ),
        "misfire_policy": str(getattr(job, "misfire_policy", "fire_now") or "fire_now"),
    }
    return payload


def _execute_in_thread(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_factory: Callable,
) -> None:
    """Fire-and-forget workflow execution in a thread.

    Args:
        spec_json: Workflow spec as JSON dict.
        input_json: Workflow input data.
        run_id: The workflow run ID.
        session_factory: Callable that returns a new session.
    """
    t = threading.Thread(
        target=_run_workflow,
        args=(spec_json, input_json, run_id, session_factory),
        daemon=True,
        name=f"sched-wf-{run_id[:8]}",
    )
    t.start()


def _run_workflow(
    spec_json: dict,
    input_json: dict,
    run_id: str,
    session_factory: Callable,
) -> None:
    """Execute a workflow with its own DB session."""
    from pygubernator.api.services._workflows import (
        execute_workflow,
    )
    from pygubernator.db.store.sqlalchemy import (
        SQLAlchemyAgentStore,
    )

    session = session_factory()
    store = SQLAlchemyAgentStore(session=session)
    try:
        result = execute_workflow(spec_json, input_json, store, run_id)
        run = store.get_workflow_run(run_id)
        if run is None:
            return
        if result["success"]:
            store.update_workflow_run(
                run,
                status="completed",
                output_json=result.get("output", {}),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        else:
            store.update_workflow_run(
                run,
                status="failed",
                error_message="; ".join(result.get("errors", [])),
                completed_at=datetime.now(UTC),
                duration_ms=result.get("duration_ms"),
            )
        store.commit()
    except Exception:
        logger.error(
            "Scheduled run %s crashed",
            run_id[:12],
            exc_info=True,
        )
    finally:
        session.close()
