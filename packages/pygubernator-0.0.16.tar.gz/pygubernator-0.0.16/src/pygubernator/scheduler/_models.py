"""Pydantic models for scheduler configuration."""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class CronExpression(BaseModel):
    """Validated cron expression string."""

    expression: str = Field(
        ...,
        description="Cron expression, e.g. '*/5 * * * *'",
    )


class ScheduledJobConfig(BaseModel):
    """Configuration for a scheduled workflow trigger.

    Captures everything needed to register a cron-based
    workflow execution.
    """

    workflow_id: str = Field(
        ...,
        description="ID of the workflow to trigger",
    )
    cron: str = Field(
        ...,
        description="Cron expression string",
    )
    timezone: str = "UTC"
    input_json: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True
    name: str = ""
    description: str = ""
    concurrency_policy: str = "allow"
    misfire_policy: str = "fire_now"
    misfire_grace_seconds: int = 60
