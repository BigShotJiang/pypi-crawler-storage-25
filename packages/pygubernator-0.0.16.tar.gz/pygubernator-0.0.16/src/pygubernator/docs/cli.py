"""CLI for documentation: ``pygubernator docs serve`` and ``pygubernator docs build``.

Delegates to MkDocs. Documentation sources are copied into
``pygubernator/_bundled_docs/`` during ``python -m build`` so
``pygubernator docs serve`` can work after ``pip install pygubernator[docs]``
without a full checkout. You can also run from the project root or set
``DOCS_ROOT`` to the directory that contains ``mkdocs.yml``.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from pygubernator.config.ports import DOCS_PORT


def _get_docs_root() -> Path | None:
    """Return the directory containing mkdocs.yml, or None if not found."""
    env_root = os.environ.get("DOCS_ROOT")
    if env_root:
        p = Path(env_root).resolve()
        if (p / "mkdocs.yml").exists():
            return p
        return None

    cwd = Path.cwd()
    if (cwd / "mkdocs.yml").exists():
        return cwd

    try:
        import pygubernator

        pkg_dir = Path(pygubernator.__file__).resolve().parent
        bundled = pkg_dir / "_bundled_docs"
        if (bundled / "mkdocs.yml").exists():
            return bundled
    except (ImportError, AttributeError):
        pass

    try:
        import pygubernator

        start = Path(pygubernator.__file__).resolve().parent
    except (ImportError, AttributeError):
        return None

    current = start
    for _ in range(12):
        if (current / "mkdocs.yml").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent

    return None


def cmd_docs_serve(host: str = "127.0.0.1", port: int = DOCS_PORT) -> int:
    """Run ``mkdocs serve`` for local preview."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root "
            "(where mkdocs.yml lives), or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "serve", "-a", f"{host}:{port}"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pygubernator[docs]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0


def cmd_docs_build() -> int:
    """Run ``mkdocs build`` to produce the static site."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root "
            "(where mkdocs.yml lives), or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "build"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pygubernator[docs]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0
