"""Validation middleware for message payload contract checking."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

from pygubernator._middleware import NextFn
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError

logger = logging.getLogger(__name__)


@runtime_checkable
class PayloadValidator(Protocol):
    """Protocol for payload validators (e.g. pycharter contracts)."""

    def validate(self, data: dict[str, Any]) -> Any:
        """Validate a payload dict.

        Args:
            data: The payload to validate.

        Returns:
            Validation result. Should be truthy on success.

        Raises:
            Exception: On validation failure.
        """
        ...


class ValidationMiddleware:
    """Validates message payloads before agent processing.

    Args:
        validator: Object implementing the PayloadValidator protocol.
    """

    def __init__(self, validator: PayloadValidator) -> None:
        self._validator = validator

    async def __call__(
        self,
        message: Message,
        agent: BaseAgent,
        next_fn: NextFn,
    ) -> AgentResult:
        """Validate the message payload, then proceed.

        Args:
            message: The incoming message.
            agent: The processing agent.
            next_fn: Next middleware or agent call.

        Returns:
            The agent result.

        Raises:
            AgentError: If payload validation fails.
        """
        try:
            self._validator.validate(message.payload)
        except Exception as exc:
            logger.error(
                "Payload validation failed for agent %s: %s",
                agent.agent_id,
                exc,
            )
            raise AgentError(
                f"Payload validation failed: {exc}",
                agent_id=agent.agent_id,
            ) from exc

        return await next_fn(message, agent)
