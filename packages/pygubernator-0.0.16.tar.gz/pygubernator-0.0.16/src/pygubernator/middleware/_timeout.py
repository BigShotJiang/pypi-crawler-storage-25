"""Timeout middleware using asyncio.wait_for."""

from __future__ import annotations

import asyncio
import logging

from pygubernator._middleware import NextFn
from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError

logger = logging.getLogger(__name__)


class TimeoutMiddleware:
    """Enforces a time limit on agent message processing.

    Args:
        timeout_seconds: Maximum allowed processing time in seconds.
    """

    def __init__(self, timeout_seconds: float = 30.0) -> None:
        self._timeout = timeout_seconds

    async def __call__(
        self,
        message: Message,
        agent: BaseAgent,
        next_fn: NextFn,
    ) -> AgentResult:
        """Execute with a timeout.

        Args:
            message: The incoming message.
            agent: The processing agent.
            next_fn: Next middleware or agent call.

        Returns:
            The agent result.

        Raises:
            AgentError: If processing exceeds the timeout.
        """
        try:
            return await asyncio.wait_for(
                next_fn(message, agent),
                timeout=self._timeout,
            )
        except TimeoutError:
            logger.error(
                "Agent %s timed out after %.1fs",
                agent.agent_id,
                self._timeout,
            )
            raise AgentError(
                f"Processing timed out after {self._timeout}s",
                agent_id=agent.agent_id,
            ) from None
