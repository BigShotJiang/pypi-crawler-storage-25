"""Agent configuration settings."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pygubernator.errors import ConfigError


def _parse_int(env_var: str, raw: str) -> int:
    """Parse an integer from an environment variable value."""
    try:
        return int(raw)
    except ValueError as exc:
        raise ConfigError(
            f"Invalid integer for PYGUBERNATOR_{env_var}: {raw!r}",
            context={"env_var": f"PYGUBERNATOR_{env_var}", "value": raw},
        ) from exc


def _parse_float(env_var: str, raw: str) -> float:
    """Parse a float from an environment variable value."""
    try:
        return float(raw)
    except ValueError as exc:
        raise ConfigError(
            f"Invalid float for PYGUBERNATOR_{env_var}: {raw!r}",
            context={"env_var": f"PYGUBERNATOR_{env_var}", "value": raw},
        ) from exc


@dataclass
class AgentSettings:
    """Configuration settings for pygubernator agents.

    Loaded from environment variables or config files. Provides
    sensible defaults for all settings.

    Attributes:
        agent_id: Unique identifier for this agent instance.
        agent_type: Type of agent (pipeline, llm, state_machine).
        kafka_bootstrap_servers: Kafka connection string.
        kafka_group_id: Kafka consumer group.
        llm_model: LLM model identifier (e.g. "gpt-4", "claude-3-opus").
        llm_max_tokens: Maximum tokens per LLM response.
        llm_temperature: LLM temperature setting.
        llm_api_key: API key for LLM provider.
        llm_api_base: Base URL for OpenAI-compatible providers.
        llm_provider_type: Provider type override (auto-detected if empty).
        max_iterations: Maximum iterations for LLM agent loops.
        system_prompt: System prompt for LLM agents.
        input_topic: Topic to consume messages from.
        output_topic: Topic to produce results to.
        max_messages: Max messages per batch run.
        log_level: Logging level.
        metadata: Additional custom settings.
    """

    agent_id: str = "agent-1"
    agent_type: str = "pipeline"
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_group_id: str = "pygubernator"
    llm_model: str = "gpt-4"
    llm_max_tokens: int = 4096
    llm_temperature: float = 0.0
    llm_api_key: str = ""
    llm_api_base: str = ""
    llm_provider_type: str = ""
    max_iterations: int = 10
    system_prompt: str = ""
    input_topic: str = "input"
    output_topic: str = "output"
    max_messages: int = 100
    log_level: str = "INFO"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> AgentSettings:
        """Create settings from environment variables.

        Environment variables are prefixed with ``PYGUBERNATOR_``.
        For example, ``PYGUBERNATOR_AGENT_ID`` sets ``agent_id``.

        Returns:
            Settings populated from environment.
        """
        import os

        def _get(key: str, default: str) -> str:
            return os.environ.get(f"PYGUBERNATOR_{key}", default)

        return cls(
            agent_id=_get("AGENT_ID", cls.agent_id),
            agent_type=_get("AGENT_TYPE", cls.agent_type),
            kafka_bootstrap_servers=_get(
                "KAFKA_BOOTSTRAP_SERVERS",
                cls.kafka_bootstrap_servers,
            ),
            kafka_group_id=_get("KAFKA_GROUP_ID", cls.kafka_group_id),
            llm_model=_get("LLM_MODEL", cls.llm_model),
            llm_max_tokens=_parse_int(
                "LLM_MAX_TOKENS", _get("LLM_MAX_TOKENS", str(cls.llm_max_tokens))
            ),
            llm_temperature=_parse_float(
                "LLM_TEMPERATURE",
                _get("LLM_TEMPERATURE", str(cls.llm_temperature)),
            ),
            llm_api_key=_get("LLM_API_KEY", cls.llm_api_key),
            llm_api_base=_get("LLM_API_BASE", cls.llm_api_base),
            llm_provider_type=_get("LLM_PROVIDER_TYPE", cls.llm_provider_type),
            max_iterations=_parse_int(
                "MAX_ITERATIONS",
                _get("MAX_ITERATIONS", str(cls.max_iterations)),
            ),
            system_prompt=_get("SYSTEM_PROMPT", cls.system_prompt),
            input_topic=_get("INPUT_TOPIC", cls.input_topic),
            output_topic=_get("OUTPUT_TOPIC", cls.output_topic),
            max_messages=_parse_int(
                "MAX_MESSAGES", _get("MAX_MESSAGES", str(cls.max_messages))
            ),
            log_level=_get("LOG_LEVEL", cls.log_level),
        )
