"""Database URL resolution for pygubernator.

Mirrors pycharter/pystator: env ``PYGUBERNATOR_DATABASE_URL``, then
``pygubernator.cfg`` ``[database]``, then ``alembic.ini`` ``sqlalchemy.url``.
"""

from __future__ import annotations

import os
from configparser import ConfigParser
from pathlib import Path

from pygubernator.config._helpers import _cfg
from pygubernator.config.paths import find_config_file

_ENV_KEY = "PYGUBERNATOR_DATABASE_URL"
_DEFAULT_DB_FILENAME = "pygubernator.db"


def default_sqlite_path() -> Path:
    """Default SQLite file path when no URL is configured (cwd / pygubernator.db)."""
    return Path.cwd() / _DEFAULT_DB_FILENAME


def get_default_sqlite_url() -> str:
    """Default SQLite URL when no database URL is configured."""
    return f"sqlite:///{default_sqlite_path()}"


def get_database_url() -> str | None:
    """Return database URL from env, pygubernator.cfg, or alembic.ini.

    Resolution order: env ``PYGUBERNATOR_DATABASE_URL`` (overrides file), then
    ``pygubernator.cfg`` ``[database]`` ``PYGUBERNATOR_DATABASE_URL``, then
    ``alembic.ini``. If you set Postgres in ``pygubernator.cfg`` but the app
    uses SQLite, check that the env var is not set (or set it to your URL).
    """
    url = os.getenv(_ENV_KEY)
    if url:
        return url.strip()
    url = _cfg("database", _ENV_KEY)
    if url:
        return url.strip()
    alembic_ini = find_config_file("alembic.ini")
    if alembic_ini:
        cfg = ConfigParser()
        cfg.read(alembic_ini)
        db_url = cfg.get("alembic", "sqlalchemy.url", fallback=None)
        if db_url and db_url != "driver://user:pass@localhost/dbname":
            return db_url
    return None


def set_database_url(database_url: str) -> None:
    """Set database URL as environment variable."""
    os.environ[_ENV_KEY] = database_url
