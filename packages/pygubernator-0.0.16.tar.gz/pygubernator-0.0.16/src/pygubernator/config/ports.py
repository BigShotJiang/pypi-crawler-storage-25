"""Default local development ports (aligned with workspace PORTS.md)."""

from __future__ import annotations

UI_PORT = 3010
API_PORT = 8010
DOCS_PORT = 5010
