"""Shared config helpers for pygubernator.cfg."""

from __future__ import annotations

from configparser import ConfigParser

from pygubernator.config.paths import find_config_file


def _cfg(section: str, key: str) -> str | None:
    cfg_path = find_config_file("pygubernator.cfg")
    if not cfg_path:
        return None
    try:
        # interpolation=None: values may contain `%` (e.g. URLs) or JSON with `%`
        cfg = ConfigParser(interpolation=None)
        cfg.read(cfg_path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        return None
    return None
