"""Auth config from env or pygubernator.cfg."""

from __future__ import annotations

import json
import logging
import os

from pygubernator.config._helpers import _cfg

logger = logging.getLogger(__name__)


def get_auth_users() -> list[dict[str, str]]:
    raw = os.getenv("PYGUBERNATOR_AUTH_USERS") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_USERS"
    )
    if not raw or not raw.strip():
        return []
    try:
        users = json.loads(raw)
        if isinstance(users, list):
            return [
                {
                    "username": u["username"],
                    "password": u["password"],
                    "role": u.get("role", "User"),
                }
                for u in users
                if isinstance(u, dict) and "username" in u and "password" in u
            ]
    except (json.JSONDecodeError, KeyError):
        logger.warning("Failed to parse PYGUBERNATOR_AUTH_USERS, returning empty list")
        return []
    return []


def get_auth_jwt_secret() -> str | None:
    return os.getenv("PYGUBERNATOR_AUTH_JWT_SECRET") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_JWT_SECRET"
    )


def get_auth_service_url() -> str | None:
    """Return external auth service base URL."""
    url = os.getenv("PYGUBERNATOR_AUTH_SERVICE_URL") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_SERVICE_URL"
    )
    return url.rstrip("/") if url else None


def get_auth_service_introspect_path() -> str | None:
    """Return auth service introspect endpoint path."""
    return os.getenv("PYGUBERNATOR_AUTH_SERVICE_INTROSPECT_PATH") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_SERVICE_INTROSPECT_PATH"
    )


def get_auth_admin_role_claims() -> set[str]:
    raw = os.getenv("PYGUBERNATOR_AUTH_ADMIN_ROLE_CLAIMS") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_ADMIN_ROLE_CLAIMS"
    )
    if raw and raw.strip():
        return {c.strip().lower() for c in raw.split(",") if c.strip()}
    return {"admin"}


def get_auth_admin_group_claims() -> set[str]:
    """Comma-separated external token group names that grant Admin."""
    raw = os.getenv("PYGUBERNATOR_AUTH_ADMIN_GROUP_CLAIMS") or _cfg(
        "auth", "PYGUBERNATOR_AUTH_ADMIN_GROUP_CLAIMS"
    )
    if raw and raw.strip():
        return {c.strip().lower() for c in raw.split(",") if c.strip()}
    return set()


def is_auth_disabled() -> bool:
    """Return True when auth is explicitly disabled or not configured.

    Same rules as pycharter/pystator: enabled only when external auth URL is set,
    or when both local users and JWT secret are configured.
    """
    raw = (
        os.getenv("PYGUBERNATOR_AUTH_DISABLED")
        or _cfg("auth", "PYGUBERNATOR_AUTH_DISABLED")
        or ""
    )
    if raw.strip().lower() in ("1", "true", "yes"):
        return True
    if get_auth_service_url():
        return False
    return not (get_auth_users() and get_auth_jwt_secret())
