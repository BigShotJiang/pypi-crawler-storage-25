"""Credential resolution for workflow and tool integrations.

Provides a protocol-based credential resolver that tools and workflows
use to obtain integration credentials at runtime.  The default
implementation reads from environment variables (populated by
:func:`~pygubernator.config.integrations.inject_credentials` at API
startup).  Custom resolvers can chain DB lookups, vault services, etc.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Protocol, runtime_checkable

from pygubernator.config.integrations import KNOWN_PROVIDERS

logger = logging.getLogger(__name__)


@runtime_checkable
class CredentialResolver(Protocol):
    """Resolves credential values for integration providers.

    Implementations may read from environment variables, databases,
    secret vaults, or any combination thereof.
    """

    def resolve(self, provider: str) -> str | None:
        """Resolve a single credential by provider name.

        Args:
            provider: Provider identifier (e.g. ``"google_sheets"``).

        Returns:
            The credential value, or ``None`` if not found.
        """
        ...

    def resolve_all(self, providers: list[str]) -> dict[str, str]:
        """Resolve multiple credentials at once.

        Args:
            providers: List of provider names to resolve.

        Returns:
            Dict mapping provider name → credential value.
            Missing credentials are omitted from the dict.
        """
        ...


class EnvCredentialResolver:
    """Resolves credentials from environment variables.

    Uses the ``KNOWN_PROVIDERS`` registry to map provider names
    to their corresponding environment variable names.

    This is the default resolver — credentials injected at API
    startup via ``inject_credentials()`` are available here.
    """

    def resolve(self, provider: str) -> str | None:
        """Look up the env var for a provider.

        Args:
            provider: Provider identifier.

        Returns:
            The env var value, or ``None`` if unset.
        """
        info = KNOWN_PROVIDERS.get(provider)
        if info is None:
            return None
        return os.environ.get(info["env_var"])

    def resolve_all(self, providers: list[str]) -> dict[str, str]:
        """Resolve all requested providers from env vars.

        Args:
            providers: Provider names to look up.

        Returns:
            Dict of resolved provider → value pairs.
        """
        result: dict[str, str] = {}
        for provider in providers:
            value = self.resolve(provider)
            if value is not None:
                result[provider] = value
        return result


class CompositeCredentialResolver:
    """Chains multiple resolvers, returning the first non-None value.

    Useful for layering: env vars → database → vault.

    Args:
        resolvers: Ordered list of resolvers to try.

    Example::

        resolver = CompositeCredentialResolver([
            EnvCredentialResolver(),
            db_resolver,
            vault_resolver,
        ])
        value = resolver.resolve("google_sheets")
    """

    def __init__(self, resolvers: list[Any]) -> None:
        self._resolvers = list(resolvers)

    def resolve(self, provider: str) -> str | None:
        """Try each resolver in order, return first match.

        Args:
            provider: Provider identifier.

        Returns:
            The first non-None value, or ``None`` if no resolver matched.
        """
        for resolver in self._resolvers:
            value = resolver.resolve(provider)
            if value is not None:
                return value
        return None

    def resolve_all(self, providers: list[str]) -> dict[str, str]:
        """Resolve all providers, merging results from all resolvers.

        Earlier resolvers take precedence for the same provider.

        Args:
            providers: Provider names to look up.

        Returns:
            Dict of resolved provider → value pairs.
        """
        result: dict[str, str] = {}
        for provider in providers:
            if provider not in result:
                value = self.resolve(provider)
                if value is not None:
                    result[provider] = value
        return result


def validate_credential(provider: str, value: str) -> bool:
    """Test if a credential value is superficially valid for a provider.

    Performs basic format validation based on the provider's type
    (file path exists, connection string has scheme, token is non-empty).
    Does NOT make network calls.

    Args:
        provider: Provider identifier.
        value: Credential value to validate.

    Returns:
        True if the value passes basic format checks.
    """
    info = KNOWN_PROVIDERS.get(provider)
    if info is None:
        logger.debug("Unknown provider: %s", provider)
        return bool(value.strip())

    cred_type = info.get("type", "text")

    if cred_type == "file_path":
        from pathlib import Path

        return Path(value).exists()

    if cred_type == "connection_string":
        return "://" in value or value.startswith("sqlite:")

    if cred_type == "url":
        return value.startswith("http://") or value.startswith("https://")

    if cred_type == "token":
        return len(value.strip()) >= 8

    # text — any non-empty value
    return bool(value.strip())


def check_workflow_credentials(
    providers: tuple[str, ...],
    resolver: CredentialResolver | None = None,
) -> list[str]:
    """Check that all required credentials are resolvable.

    Args:
        providers: Required provider names.
        resolver: Credential resolver (defaults to :class:`EnvCredentialResolver`).

    Returns:
        List of provider names that could NOT be resolved (empty = all OK).
    """
    if not providers:
        return []
    actual_resolver = resolver or EnvCredentialResolver()
    missing: list[str] = []
    for provider in providers:
        if actual_resolver.resolve(provider) is None:
            missing.append(provider)
    return missing
