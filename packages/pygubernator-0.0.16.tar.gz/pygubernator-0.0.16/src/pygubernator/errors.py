"""Exception hierarchy for the pygubernator agent framework."""

from __future__ import annotations

from enum import Enum
from typing import Any


class ErrorCode(Enum):
    """Machine-readable error codes for pygubernator exceptions."""

    AGENT_FAILED = "AGENT_FAILED"
    TOOL_FAILED = "TOOL_FAILED"
    TRANSPORT_FAILED = "TRANSPORT_FAILED"
    LLM_FAILED = "LLM_FAILED"
    PIPELINE_STEP_FAILED = "PIPELINE_STEP_FAILED"
    CONFIG_INVALID = "CONFIG_INVALID"
    WORKFLOW_FAILED = "WORKFLOW_FAILED"
    NODE_FAILED = "NODE_FAILED"
    EXPRESSION_FAILED = "EXPRESSION_FAILED"
    EXECUTION_FAILED = "EXECUTION_FAILED"
    CONNECTOR_FAILED = "CONNECTOR_FAILED"
    SINK_FAILED = "SINK_FAILED"
    SOURCE_FAILED = "SOURCE_FAILED"
    ILLEGAL_TRANSITION = "ILLEGAL_TRANSITION"


class GubernatorError(Exception):
    """Base exception for all pygubernator errors.

    Args:
        message: Human-readable error description.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.context: dict[str, Any] = context or {}
        self.code = code

    def to_dict(self) -> dict[str, Any]:
        """Serialize the error to a dictionary.

        Returns:
            Dictionary containing error details.
        """
        return {
            "error_type": type(self).__name__,
            "message": self.message,
            "code": self.code.value if self.code else None,
            "context": self.context,
        }


class AgentError(GubernatorError):
    """Raised when an agent encounters an error during execution.

    Args:
        message: Human-readable error description.
        agent_id: Identifier of the agent that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        agent_id: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.AGENT_FAILED,
    ) -> None:
        ctx = {**(context or {}), "agent_id": agent_id}
        super().__init__(message, context=ctx, code=code)
        self.agent_id = agent_id


class ToolError(GubernatorError):
    """Raised when a tool fails during execution.

    Args:
        message: Human-readable error description.
        tool_name: Name of the tool that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        tool_name: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.TOOL_FAILED,
    ) -> None:
        ctx = {**(context or {}), "tool_name": tool_name}
        super().__init__(message, context=ctx, code=code)
        self.tool_name = tool_name


class TransportError(GubernatorError):
    """Raised when a transport layer operation fails.

    Args:
        message: Human-readable error description.
        transport_type: Type of transport that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        transport_type: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.TRANSPORT_FAILED,
    ) -> None:
        ctx = {
            **(context or {}),
            "transport_type": transport_type,
        }
        super().__init__(message, context=ctx, code=code)
        self.transport_type = transport_type


class LLMError(GubernatorError):
    """Raised when an LLM provider call fails.

    Args:
        message: Human-readable error description.
        provider: Name of the LLM provider that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        provider: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.LLM_FAILED,
    ) -> None:
        ctx = {**(context or {}), "provider": provider}
        super().__init__(message, context=ctx, code=code)
        self.provider = provider


class PipelineStepError(GubernatorError):
    """Raised when a pipeline step fails during execution.

    Args:
        message: Human-readable error description.
        step_name: Name of the pipeline step that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        step_name: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.PIPELINE_STEP_FAILED,
    ) -> None:
        ctx = {**(context or {}), "step_name": step_name}
        super().__init__(message, context=ctx, code=code)
        self.step_name = step_name


class ConfigError(GubernatorError):
    """Raised when configuration is invalid or missing.

    Args:
        message: Human-readable error description.
        path: Configuration file path, if applicable.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        path: str | None = None,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.CONFIG_INVALID,
    ) -> None:
        ctx = {**(context or {}), "path": path}
        super().__init__(message, context=ctx, code=code)
        self.path = path


class WorkflowError(GubernatorError):
    """Raised when a workflow encounters an error during execution.

    Args:
        message: Human-readable error description.
        workflow_name: Name of the workflow that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        workflow_name: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.WORKFLOW_FAILED,
    ) -> None:
        ctx = {**(context or {}), "workflow_name": workflow_name}
        super().__init__(message, context=ctx, code=code)
        self.workflow_name = workflow_name


class NodeError(GubernatorError):
    """Raised when a workflow node fails during execution.

    Args:
        message: Human-readable error description.
        node_id: Identifier of the node that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        node_id: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.NODE_FAILED,
    ) -> None:
        ctx = {**(context or {}), "node_id": node_id}
        super().__init__(message, context=ctx, code=code)
        self.node_id = node_id


class ExecutionError(GubernatorError):
    """Raised for engine-level structural errors (cycles, unreachable nodes).

    Args:
        message: Human-readable error description.
        workflow_name: Name of the workflow that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        workflow_name: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.EXECUTION_FAILED,
    ) -> None:
        ctx = {**(context or {}), "workflow_name": workflow_name}
        super().__init__(message, context=ctx, code=code)
        self.workflow_name = workflow_name


class ExpressionError(GubernatorError):
    """Raised when a safe expression evaluation fails.

    Args:
        message: Human-readable error description.
        expression: The expression that failed.
        context: Additional structured context for debugging.
        code: Machine-readable error code.
    """

    def __init__(
        self,
        message: str,
        expression: str,
        context: dict[str, Any] | None = None,
        code: ErrorCode = ErrorCode.EXPRESSION_FAILED,
    ) -> None:
        ctx = {**(context or {}), "expression": expression}
        super().__init__(message, context=ctx, code=code)
        self.expression = expression
