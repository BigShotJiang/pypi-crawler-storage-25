"""Core value objects for the pygubernator agent framework."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class Message:
    """A message exchanged via a transport layer.

    Args:
        topic: The topic or channel the message belongs to.
        key: Optional partitioning key.
        payload: The message body as a dictionary.
        headers: Metadata headers attached to the message.
        timestamp: Unix timestamp of the message, if available.
    """

    topic: str
    key: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    timestamp: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize the message to a dictionary.

        Returns:
            Dictionary representation of the message.
        """
        return {
            "topic": self.topic,
            "key": self.key,
            "payload": self.payload,
            "headers": self.headers,
            "timestamp": self.timestamp,
        }


@dataclass(frozen=True, slots=True)
class ToolResult:
    """Result of a tool execution.

    Args:
        tool_name: Name of the tool that produced the result.
        success: Whether the tool executed successfully.
        output: The tool's output value.
        error: Error description if the tool failed.
    """

    tool_name: str
    success: bool
    output: Any = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize the tool result to a dictionary.

        Returns:
            Dictionary representation of the tool result.
        """
        return {
            "tool_name": self.tool_name,
            "success": self.success,
            "output": self.output,
            "error": self.error,
        }


@dataclass(frozen=True, slots=True)
class AgentResult:
    """Result of an agent execution cycle.

    Args:
        agent_id: Identifier of the agent.
        success: Whether the agent completed successfully.
        messages_processed: Number of messages handled.
        errors: List of error descriptions encountered.
        metadata: Additional result metadata.
    """

    agent_id: str
    success: bool
    messages_processed: int = 0
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the agent result to a dictionary.

        Returns:
            Dictionary representation of the agent result.
        """
        return {
            "agent_id": self.agent_id,
            "success": self.success,
            "messages_processed": self.messages_processed,
            "errors": self.errors,
            "metadata": self.metadata,
        }


@dataclass(frozen=True, slots=True)
class StepResult:
    """Result of a pipeline step execution.

    Args:
        step_name: Name of the pipeline step.
        success: Whether the step completed successfully.
        data: Output data from the step.
        error: Error description if the step failed.
        duration_ms: Execution time in milliseconds.
    """

    step_name: str
    success: bool
    data: Any = None
    error: str | None = None
    duration_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Serialize the step result to a dictionary.

        Returns:
            Dictionary representation of the step result.
        """
        return {
            "step_name": self.step_name,
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "duration_ms": self.duration_ms,
        }
