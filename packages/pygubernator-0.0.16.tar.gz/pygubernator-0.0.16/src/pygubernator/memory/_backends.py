"""Default ``AgentContextStore`` backends.

- ``InMemoryContextStore``: thread-safe, process-local. Test/dev use.
- ``FileContextStore``: JSON file per scope, human-readable, useful
  for single-user setups.
- ``SqlAlchemyContextStore``: persists into ``generic_records`` via
  the kind ``agent_context`` so context is inspectable alongside
  other audit records.
"""

from __future__ import annotations

import json
import logging
import threading
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pygubernator.memory._scope import MemoryScope
from pygubernator.records import Record, RecordStore, default_record_store

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

CONTEXT_KIND = "agent_context"


class InMemoryContextStore:
    """Thread-safe dict-backed context store."""

    def __init__(self) -> None:
        self._data: dict[str, dict[str, Any]] = {}
        self._lock = threading.RLock()

    def get(self, scope: MemoryScope, key: str, default: Any = None) -> Any:
        """Return ``default`` when the key is absent."""
        with self._lock:
            return self._data.get(scope.to_key(), {}).get(key, default)

    def set(self, scope: MemoryScope, key: str, value: Any) -> None:
        """Idempotent replacement."""
        with self._lock:
            self._data.setdefault(scope.to_key(), {})[key] = value

    def delete(self, scope: MemoryScope, key: str) -> None:
        """Best-effort removal."""
        with self._lock:
            bucket = self._data.get(scope.to_key())
            if bucket and key in bucket:
                del bucket[key]

    def keys(self, scope: MemoryScope) -> list[str]:
        """List keys in the scope."""
        with self._lock:
            return list(self._data.get(scope.to_key(), {}).keys())

    def clear(self, scope: MemoryScope) -> None:
        """Drop all entries for the scope."""
        with self._lock:
            self._data.pop(scope.to_key(), None)


class FileContextStore:
    """One JSON file per scope, inside ``root``.

    Simple, durable, and human-readable. Concurrent writers on the
    same scope should be avoided; a single-writer pattern (one agent
    per scope per time) is assumed.
    """

    def __init__(self, root: Path | str) -> None:
        """Initialize.

        Args:
            root: Directory used to store per-scope JSON files. Created
                if absent.
        """
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def _path(self, scope: MemoryScope) -> Path:
        safe = scope.to_key().replace("|", "_").replace("/", "_")
        return self._root / f"{safe}.json"

    def _load(self, scope: MemoryScope) -> dict[str, Any]:
        path = self._path(scope)
        if not path.exists():
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            logger.warning("context file unreadable: %s", path)
            return {}

    def _save(self, scope: MemoryScope, data: dict[str, Any]) -> None:
        tmp = self._path(scope).with_suffix(".tmp")
        tmp.write_text(json.dumps(data, default=str), encoding="utf-8")
        tmp.replace(self._path(scope))

    def get(self, scope: MemoryScope, key: str, default: Any = None) -> Any:
        """Return ``default`` when the key is absent."""
        with self._lock:
            return self._load(scope).get(key, default)

    def set(self, scope: MemoryScope, key: str, value: Any) -> None:
        """Idempotent replacement."""
        with self._lock:
            data = self._load(scope)
            data[key] = value
            self._save(scope, data)

    def delete(self, scope: MemoryScope, key: str) -> None:
        """Best-effort removal."""
        with self._lock:
            data = self._load(scope)
            if key in data:
                del data[key]
                self._save(scope, data)

    def keys(self, scope: MemoryScope) -> list[str]:
        """List keys in the scope."""
        with self._lock:
            return list(self._load(scope).keys())

    def clear(self, scope: MemoryScope) -> None:
        """Drop all entries (delete the JSON file)."""
        with self._lock:
            path = self._path(scope)
            if path.exists():
                path.unlink()


class RecordStoreContextStore:
    """``AgentContextStore`` backed by a generic ``RecordStore``.

    Each (scope, key) pair is stored as a record of kind
    ``agent_context`` with ``scope`` set to the serialized scope key.
    The most recent record for a given key is considered authoritative,
    so writes never overwrite — they append. ``delete`` emits a
    tombstone record with a null payload.
    """

    def __init__(self, store: RecordStore | None = None) -> None:
        """Initialize.

        Args:
            store: Underlying record store. Defaults to the process-wide
                default.
        """
        self._store = store or default_record_store()

    def _latest(self, scope: MemoryScope, key: str) -> Record | None:
        records = self._store.query(CONTEXT_KIND, scope=scope.to_key(), limit=500)
        for record in records:
            if record.payload.get("key") == key:
                return record
        return None

    def get(self, scope: MemoryScope, key: str, default: Any = None) -> Any:
        """Latest non-tombstone value for the key."""
        record = self._latest(scope, key)
        if record is None:
            return default
        payload = record.payload
        if payload.get("tombstone"):
            return default
        return payload.get("value", default)

    def set(self, scope: MemoryScope, key: str, value: Any) -> None:
        """Append a new record; older records stay around for audit."""
        self._store.put(
            Record(
                kind=CONTEXT_KIND,
                scope=scope.to_key(),
                payload={"key": key, "value": value},
                created_at=datetime.now(UTC),
            )
        )

    def delete(self, scope: MemoryScope, key: str) -> None:
        """Emit a tombstone record."""
        self._store.put(
            Record(
                kind=CONTEXT_KIND,
                scope=scope.to_key(),
                payload={"key": key, "tombstone": True},
                created_at=datetime.now(UTC),
            )
        )

    def keys(self, scope: MemoryScope) -> list[str]:
        """Distinct non-tombstone keys in the scope."""
        records = self._store.query(CONTEXT_KIND, scope=scope.to_key(), limit=10_000)
        keys: list[str] = []
        seen: set[str] = set()
        tombstoned: set[str] = set()
        for record in records:  # newest first
            key = record.payload.get("key")
            if not isinstance(key, str) or key in seen:
                continue
            seen.add(key)
            if record.payload.get("tombstone"):
                tombstoned.add(key)
                continue
            keys.append(key)
        return [k for k in keys if k not in tombstoned]

    def clear(self, scope: MemoryScope) -> None:
        """Tombstone every live key.

        The underlying ``RecordStore`` is append-only, so ``clear`` is
        implemented by emitting tombstones for every live key.
        """
        for key in self.keys(scope):
            self.delete(scope, key)


class SqlAlchemyContextStore:
    """``AgentContextStore`` persisting to ``generic_records`` via SQL.

    Thin wrapper over ``RecordStoreContextStore`` with a
    SQLAlchemy-backed ``RecordStore`` constructed from the supplied
    session factory.
    """

    def __init__(self, session_factory: Callable[[], Session]) -> None:
        """Initialize.

        Args:
            session_factory: Callable returning a fresh SQLAlchemy session.
        """
        from pygubernator.records._sqlalchemy import SqlAlchemyRecordStore

        self._inner = RecordStoreContextStore(
            store=SqlAlchemyRecordStore(session_factory)
        )

    def get(self, scope: MemoryScope, key: str, default: Any = None) -> Any:
        """Proxy to the underlying RecordStore-backed store."""
        return self._inner.get(scope, key, default)

    def set(self, scope: MemoryScope, key: str, value: Any) -> None:
        """Proxy to the underlying RecordStore-backed store."""
        self._inner.set(scope, key, value)

    def delete(self, scope: MemoryScope, key: str) -> None:
        """Proxy to the underlying RecordStore-backed store."""
        self._inner.delete(scope, key)

    def keys(self, scope: MemoryScope) -> list[str]:
        """Proxy to the underlying RecordStore-backed store."""
        return self._inner.keys(scope)

    def clear(self, scope: MemoryScope) -> None:
        """Proxy to the underlying RecordStore-backed store."""
        self._inner.clear(scope)
