"""Structured context surface: an agent's long-lived notebook.

Stores four named sections — ``facts``, ``questions``, ``next_actions``,
``log`` — each a list of string bullets. Renders to and parses from a
Markdown document so operators can read it without tools.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_SECTION_ORDER = ("facts", "questions", "next_actions", "log")
_HEADING_PATTERN = re.compile(r"^##\s+(.+?)\s*$")
_BULLET_PATTERN = re.compile(r"^-\s+(.*)$")


@dataclass
class ContextSurface:
    """Structured notebook shared by an agent across runs.

    Sections:

    - ``facts``: stable knowledge the agent has established.
    - ``questions``: open questions to pursue on a future run.
    - ``next_actions``: things the agent has decided to do next.
    - ``log``: run-by-run free-form notes (oldest first).

    Instances are mutable in place; render/parse are round-trippable.
    """

    facts: list[str] = field(default_factory=list)
    questions: list[str] = field(default_factory=list)
    next_actions: list[str] = field(default_factory=list)
    log: list[str] = field(default_factory=list)

    def append(self, section: str, item: str) -> None:
        """Append ``item`` to the named section.

        Args:
            section: One of ``facts``, ``questions``, ``next_actions``, ``log``.
            item: Bullet text to append.
        """
        self._bucket(section).append(item)

    def replace(self, section: str, items: list[str]) -> None:
        """Replace the contents of the named section."""
        bucket = self._bucket(section)
        bucket.clear()
        bucket.extend(items)

    def clear(self, section: str | None = None) -> None:
        """Clear a single section or all sections when ``section`` is None."""
        if section is None:
            self.facts.clear()
            self.questions.clear()
            self.next_actions.clear()
            self.log.clear()
            return
        self._bucket(section).clear()

    def to_dict(self) -> dict[str, list[str]]:
        """Serialize as a plain dict (for JSON storage)."""
        return {
            "facts": list(self.facts),
            "questions": list(self.questions),
            "next_actions": list(self.next_actions),
            "log": list(self.log),
        }

    @classmethod
    def from_dict(cls, data: dict | None) -> ContextSurface:
        """Build from a previously-serialized dict.

        Unknown / missing sections default to empty lists.
        """
        data = data or {}
        return cls(
            facts=[str(x) for x in data.get("facts", [])],
            questions=[str(x) for x in data.get("questions", [])],
            next_actions=[str(x) for x in data.get("next_actions", [])],
            log=[str(x) for x in data.get("log", [])],
        )

    def to_markdown(self) -> str:
        """Render as a Markdown document."""
        lines: list[str] = []
        for name in _SECTION_ORDER:
            lines.append(f"## {name}")
            bucket = self._bucket(name)
            if not bucket:
                lines.append("")
                continue
            for item in bucket:
                lines.append(f"- {item}")
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    @classmethod
    def from_markdown(cls, text: str) -> ContextSurface:
        """Parse a Markdown document back into a surface.

        Unknown headings are ignored; formatting outside bullets is
        discarded.
        """
        surface = cls()
        current: str | None = None
        for line in text.splitlines():
            heading = _HEADING_PATTERN.match(line)
            if heading:
                name = heading.group(1).strip().lower()
                current = name if name in _SECTION_ORDER else None
                continue
            if current is None:
                continue
            bullet = _BULLET_PATTERN.match(line)
            if bullet:
                surface.append(current, bullet.group(1).strip())
        return surface

    def _bucket(self, section: str) -> list[str]:
        if section not in _SECTION_ORDER:
            raise KeyError(
                f"unknown section '{section}'; expected one of {_SECTION_ORDER}"
            )
        return getattr(self, section)
