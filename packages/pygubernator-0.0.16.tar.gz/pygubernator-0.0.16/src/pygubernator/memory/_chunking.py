"""Text chunker for the knowledge-base subsystem.

Splits a body of text into overlapping chunks suitable for embedding.
Three strategies are supported:

- ``paragraph`` (default) — split on blank lines, then merge adjacent
  paragraphs until the token budget is reached.
- ``sentence`` — split on sentence-ending punctuation, then merge.
- ``fixed`` — pure character-count splitter, useful for code or
  tabular text without natural breakpoints.

The token estimator defaults to ``len(text.split()) / 0.75`` (roughly
0.75 words-per-token for English). Callers can substitute a precise
tokeniser (tiktoken, sentencepiece, …) by passing a custom
``token_estimator`` callable.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

Splitter = Literal["paragraph", "sentence", "fixed"]

TokenEstimator = Callable[[str], int]


def _default_token_estimator(text: str) -> int:
    """Rough word-based token count (1 token ≈ 0.75 words)."""
    words = len(text.split())
    if words == 0:
        return 0
    return max(1, int(round(words / 0.75)))


@dataclass(frozen=True, slots=True)
class Chunk:
    """A single chunk produced by :func:`chunk_text`.

    Attributes:
        text: The chunk body (already trimmed).
        ordinal: Zero-based index of this chunk within the source.
        char_start: Offset (in source characters) where the chunk
            starts.
        char_end: Exclusive offset where the chunk ends.
        estimated_tokens: Rough token count via the configured
            estimator.
    """

    text: str
    ordinal: int
    char_start: int
    char_end: int
    estimated_tokens: int


_PARAGRAPH_RE = re.compile(r"\n\s*\n+")
# Sentence splitter — conservative so "Mr.", "e.g." etc. don't split mid-sentence.
_SENTENCE_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])")


def chunk_text(
    text: str,
    *,
    max_tokens: int = 512,
    overlap: int = 64,
    splitter: Splitter = "paragraph",
    token_estimator: TokenEstimator | None = None,
) -> list[Chunk]:
    """Split ``text`` into chunks, respecting a token budget.

    Args:
        text: Source text.
        max_tokens: Soft upper bound per chunk.
        overlap: Approximate number of tokens of overlap between
            adjacent chunks. Set to 0 for no overlap.
        splitter: Strategy — ``paragraph`` / ``sentence`` / ``fixed``.
        token_estimator: Callable that estimates token count from a
            string; defaults to a word-based heuristic.

    Returns:
        Ordered list of :class:`Chunk` objects. Empty when ``text`` is
        empty or whitespace-only.
    """
    if not text or not text.strip():
        return []
    if max_tokens <= 0:
        raise ValueError(f"max_tokens must be > 0, got {max_tokens}")
    if overlap < 0:
        raise ValueError(f"overlap must be >= 0, got {overlap}")
    if overlap >= max_tokens:
        raise ValueError(
            f"overlap ({overlap}) must be strictly less than max_tokens ({max_tokens})"
        )

    estimator = token_estimator or _default_token_estimator

    if splitter == "fixed":
        return _chunk_fixed(
            text, max_tokens=max_tokens, overlap=overlap, estimator=estimator
        )
    if splitter == "sentence":
        pieces = _split_sentences(text)
    else:  # paragraph default
        pieces = _split_paragraphs(text)

    return _merge_pieces(
        pieces,
        source=text,
        max_tokens=max_tokens,
        overlap=overlap,
        estimator=estimator,
    )


# ---------------------------------------------------------------------------
# Splitters
# ---------------------------------------------------------------------------


def _split_paragraphs(text: str) -> list[tuple[str, int, int]]:
    """Return (piece, char_start, char_end) triples by blank-line split."""
    return _split_by_regex(_PARAGRAPH_RE, text)


def _split_sentences(text: str) -> list[tuple[str, int, int]]:
    """Return (piece, char_start, char_end) triples by sentence boundaries."""
    # First pass splits paragraphs (preserves cross-paragraph boundaries),
    # second pass splits each paragraph into sentences.
    pieces: list[tuple[str, int, int]] = []
    for para, start, _end in _split_by_regex(_PARAGRAPH_RE, text):
        offset = start
        for match in _SENTENCE_RE.split(para):
            if not match.strip():
                continue
            idx = text.find(match, offset)
            if idx < 0:
                continue
            pieces.append((match, idx, idx + len(match)))
            offset = idx + len(match)
    return pieces


def _split_by_regex(
    pattern: re.Pattern[str],
    text: str,
) -> list[tuple[str, int, int]]:
    """Generic splitter that preserves char offsets."""
    pieces: list[tuple[str, int, int]] = []
    cursor = 0
    for match in pattern.finditer(text):
        end = match.start()
        if end > cursor:
            piece = text[cursor:end]
            if piece.strip():
                pieces.append((piece, cursor, end))
        cursor = match.end()
    if cursor < len(text):
        piece = text[cursor:]
        if piece.strip():
            pieces.append((piece, cursor, len(text)))
    if not pieces and text.strip():
        pieces.append((text, 0, len(text)))
    return pieces


# ---------------------------------------------------------------------------
# Merging + fixed-width
# ---------------------------------------------------------------------------


def _merge_pieces(
    pieces: list[tuple[str, int, int]],
    *,
    source: str,
    max_tokens: int,
    overlap: int,
    estimator: TokenEstimator,
) -> list[Chunk]:
    """Merge adjacent pieces into chunks that stay under the token budget."""
    chunks: list[Chunk] = []
    buffer: list[tuple[str, int, int]] = []
    buffer_tokens = 0
    ordinal = 0

    for piece_text, start, end in pieces:
        piece_tokens = estimator(piece_text)

        # Single piece exceeds the budget on its own — fall back to
        # fixed-width splitting for just that piece so the caller still
        # gets chunks bounded by max_tokens.
        if piece_tokens > max_tokens:
            chunks.extend(
                _fixed_within(
                    piece_text,
                    offset=start,
                    ordinal_start=ordinal,
                    max_tokens=max_tokens,
                    overlap=overlap,
                    estimator=estimator,
                )
            )
            ordinal = len(chunks)
            buffer.clear()
            buffer_tokens = 0
            continue

        if buffer_tokens + piece_tokens > max_tokens and buffer:
            chunks.append(_flush_buffer(buffer, ordinal=ordinal, estimator=estimator))
            ordinal += 1
            buffer = _carry_overlap(buffer, overlap=overlap, estimator=estimator)
            buffer_tokens = sum(estimator(p[0]) for p in buffer)

        buffer.append((piece_text, start, end))
        buffer_tokens += piece_tokens

    if buffer:
        chunks.append(_flush_buffer(buffer, ordinal=ordinal, estimator=estimator))

    return chunks


def _flush_buffer(
    buffer: list[tuple[str, int, int]],
    *,
    ordinal: int,
    estimator: TokenEstimator,
) -> Chunk:
    """Collapse a buffer of pieces into a single :class:`Chunk`."""
    text = "\n\n".join(piece.strip() for piece, _s, _e in buffer).strip()
    start = buffer[0][1]
    end = buffer[-1][2]
    return Chunk(
        text=text,
        ordinal=ordinal,
        char_start=start,
        char_end=end,
        estimated_tokens=estimator(text),
    )


def _carry_overlap(
    buffer: list[tuple[str, int, int]],
    *,
    overlap: int,
    estimator: TokenEstimator,
) -> list[tuple[str, int, int]]:
    """Keep a trailing slice of the buffer (by token count) as overlap."""
    if overlap <= 0 or not buffer:
        return []
    carried: list[tuple[str, int, int]] = []
    token_sum = 0
    for piece in reversed(buffer):
        token_sum += estimator(piece[0])
        carried.insert(0, piece)
        if token_sum >= overlap:
            break
    return carried


def _chunk_fixed(
    text: str,
    *,
    max_tokens: int,
    overlap: int,
    estimator: TokenEstimator,
) -> list[Chunk]:
    """Fixed-width splitter — approximate chars from tokens."""
    return _fixed_within(
        text,
        offset=0,
        ordinal_start=0,
        max_tokens=max_tokens,
        overlap=overlap,
        estimator=estimator,
    )


def _fixed_within(
    text: str,
    *,
    offset: int,
    ordinal_start: int,
    max_tokens: int,
    overlap: int,
    estimator: TokenEstimator,
) -> list[Chunk]:
    """Fixed-width cut applied to a single piece of text."""
    # Approximate the char budget from the estimator by sampling a slice.
    sample = text[: min(len(text), 2000)]
    sample_tokens = max(1, estimator(sample))
    chars_per_token = max(1, int(round(len(sample) / sample_tokens)))
    window = max(1, max_tokens * chars_per_token)
    step = max(1, (max_tokens - overlap) * chars_per_token)

    chunks: list[Chunk] = []
    cursor = 0
    ordinal = ordinal_start
    while cursor < len(text):
        end = min(len(text), cursor + window)
        piece = text[cursor:end].strip()
        if piece:
            chunks.append(
                Chunk(
                    text=piece,
                    ordinal=ordinal,
                    char_start=offset + cursor,
                    char_end=offset + end,
                    estimated_tokens=estimator(piece),
                )
            )
            ordinal += 1
        if end >= len(text):
            break
        cursor += step
    return chunks


__all__ = ["Chunk", "Splitter", "TokenEstimator", "chunk_text"]
