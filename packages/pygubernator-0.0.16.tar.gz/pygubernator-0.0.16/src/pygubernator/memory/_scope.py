"""Memory scope: composite key for isolating memory between callers."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class MemoryScope:
    """Composite key identifying a memory compartment.

    Any combination of ``agent_id``, ``workflow_id``, ``user_id``,
    ``run_id`` may be set. Unset fields are excluded from the key.
    ``to_key()`` returns a canonical string form used by store
    backends for filtering.

    Args:
        agent_id: Agent owning the compartment.
        workflow_id: Workflow containing the run.
        user_id: End user on whose behalf the compartment exists.
        run_id: Specific run (used for ephemeral scope).
    """

    agent_id: str | None = None
    workflow_id: str | None = None
    user_id: str | None = None
    run_id: str | None = None

    def to_key(self) -> str:
        """Serialize to a deterministic string key.

        Returns:
            Pipe-delimited ``part=value`` tokens in fixed order. An
            empty scope returns ``__global__`` so callers can always
            index by a string.
        """
        parts: list[str] = []
        if self.agent_id:
            parts.append(f"agent={self.agent_id}")
        if self.workflow_id:
            parts.append(f"workflow={self.workflow_id}")
        if self.user_id:
            parts.append(f"user={self.user_id}")
        if self.run_id:
            parts.append(f"run={self.run_id}")
        if not parts:
            return "__global__"
        return "|".join(parts)

    def narrower_than(self, other: MemoryScope) -> bool:
        """True if ``self`` is a strictly narrower scope than ``other``."""
        self_fields = _non_none_fields(self)
        other_fields = _non_none_fields(other)
        if self_fields == other_fields:
            return False
        return other_fields.issubset(self_fields)

    @classmethod
    def from_context(cls, context: object) -> MemoryScope:
        """Build a scope from any object exposing the same attribute names.

        Designed to accept a ``CallerContext`` from
        ``pygubernator.policy`` without creating a hard dependency.
        """
        return cls(
            agent_id=getattr(context, "agent_id", None),
            workflow_id=getattr(context, "workflow_id", None),
            user_id=getattr(context, "user_id", None),
            run_id=getattr(context, "run_id", None),
        )


def _non_none_fields(scope: MemoryScope) -> frozenset[str]:
    return frozenset(
        name
        for name in ("agent_id", "workflow_id", "user_id", "run_id")
        if getattr(scope, name) is not None
    )
