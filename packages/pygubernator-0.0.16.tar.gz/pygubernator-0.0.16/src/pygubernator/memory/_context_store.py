"""Protocol for scoped context persistence."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pygubernator.memory._scope import MemoryScope


@runtime_checkable
class AgentContextStore(Protocol):
    """Scoped key/value store for agent context surviving across runs.

    Implementations persist JSON-serializable values keyed by
    ``(MemoryScope, str)`` pairs. Writes are idempotent replacements;
    ``delete`` is a best-effort no-op when the key is absent.
    """

    def get(self, scope: MemoryScope, key: str, default: Any = None) -> Any:
        """Fetch the value stored at ``(scope, key)``.

        Args:
            scope: Compartment.
            key: Logical key within the compartment.
            default: Returned when the key is absent.

        Returns:
            Stored value or ``default``.
        """
        ...

    def set(self, scope: MemoryScope, key: str, value: Any) -> None:
        """Persist ``value`` at ``(scope, key)``, replacing any prior value."""
        ...

    def delete(self, scope: MemoryScope, key: str) -> None:
        """Remove ``(scope, key)`` if present."""
        ...

    def keys(self, scope: MemoryScope) -> list[str]:
        """List logical keys stored in the scope."""
        ...

    def clear(self, scope: MemoryScope) -> None:
        """Remove all entries in the scope."""
        ...
