"""Vector store for the knowledge-base subsystem.

Defines the :class:`VectorStore` protocol plus a default
:class:`SqliteVectorStore` that backs to the existing SQLAlchemy
engine. The default store uses numpy cosine similarity over a
scope-filtered ``SELECT`` — performant to roughly 50k chunks on a
single machine, no external vector DB required.

Third-party packages (Chroma, Qdrant, Pinecone, pgvector) implement
the same protocol and plug in via the
:class:`VectorStoreRegistry` exposed from
:mod:`pygubernator.connectors`-style entry points in a future phase;
for now the default store covers the daily-research use case cleanly.
"""

from __future__ import annotations

import heapq
import logging
import uuid
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal, Protocol, runtime_checkable

import numpy as np
from sqlalchemy import and_, delete, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from pygubernator.db.models.kb_chunk import KBChunk
from pygubernator.db.session import _get_engine
from pygubernator.memory._scope import MemoryScope

logger = logging.getLogger(__name__)

BindingState = Literal["unmapped", "suggested", "mapped", "approved"]

_VALID_BINDING_STATES: frozenset[str] = frozenset(
    {"unmapped", "suggested", "mapped", "approved"}
)


# ---------------------------------------------------------------------------
# Value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class VectorChunk:
    """A single chunk of text with its embedding and semantic bindings.

    Attributes:
        text: The chunk body.
        embedding: Vector representation; any iterable of floats. The
            store serialises to float32 bytes.
        scope: Memory scope identifying which compartment the chunk
            belongs to.
        chunk_id: Stable identifier. Defaults to a new UUID4.
        metadata: Arbitrary JSON-serialisable metadata (ordinal,
            char_start/end, source headings).
        concept_refs: Pycharter concept ids bound to this chunk.
        contract_id: Pycharter contract id this chunk conforms to.
        source_uri: Provenance URL / file path.
        binding_state: Lifecycle state of the concept bindings.
        created_at: UTC timestamp; defaults to now.
    """

    text: str
    embedding: tuple[float, ...]
    scope: MemoryScope
    chunk_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    metadata: Mapping[str, Any] = field(default_factory=dict)
    concept_refs: tuple[str, ...] = ()
    contract_id: str | None = None
    source_uri: str | None = None
    binding_state: BindingState = "unmapped"
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass(frozen=True, slots=True)
class SearchHit:
    """Result of a vector-store search.

    Attributes:
        text: The matching chunk text.
        score: Cosine similarity score (higher = more relevant).
        metadata: The chunk's stored metadata.
        chunk_id: Chunk identifier (use for delete / promote / reject).
        concept_refs: Concept ids bound to the chunk.
        contract_id: Contract id the chunk conforms to, if any.
        source_uri: Provenance URL / file path, if any.
        binding_state: Current lifecycle state.
    """

    text: str
    score: float
    metadata: dict[str, Any]
    chunk_id: str
    concept_refs: tuple[str, ...] = ()
    contract_id: str | None = None
    source_uri: str | None = None
    binding_state: BindingState = "unmapped"

    def to_dict(self) -> dict[str, Any]:
        """Dict shape compatible with :func:`pygubernator.llm._rag.retrieve`."""
        return {
            "text": self.text,
            "score": self.score,
            "metadata": {
                **self.metadata,
                "chunk_id": self.chunk_id,
                "concept_refs": list(self.concept_refs),
                "contract_id": self.contract_id,
                "source_uri": self.source_uri,
                "binding_state": self.binding_state,
            },
        }


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class VectorStore(Protocol):
    """Persistent vector store used by the knowledge-base subsystem."""

    def upsert(self, chunks: Iterable[VectorChunk]) -> int:
        """Insert (or replace by ``chunk_id``) the given chunks.

        Args:
            chunks: Chunks to persist.

        Returns:
            Number of chunks written.
        """
        ...

    def search(
        self,
        vector: list[float] | tuple[float, ...],
        limit: int,
        *,
        scope_filter: dict[str, str] | None = None,
        concept_filter: list[str] | None = None,
        contract_filter: list[str] | None = None,
        min_score: float = 0.0,
    ) -> list[SearchHit]:
        """Return up to ``limit`` nearest chunks.

        Args:
            vector: Query embedding.
            limit: Max results.
            scope_filter: Match chunks by the stored scope-part columns
                (``agent_id``, ``workflow_id``, ``run_id``, ``user_id``).
            concept_filter: If non-empty, only return chunks whose
                ``concept_refs`` list contains any of these ids.
            contract_filter: If non-empty, only return chunks whose
                ``contract_id`` is in this list.
            min_score: Drop hits below this cosine similarity.
        """
        ...

    def delete(self, *, scope_filter: dict[str, str]) -> int:
        """Delete every chunk matching the scope filter. Returns count."""
        ...

    def get(self, chunk_id: str) -> SearchHit | None:
        """Fetch a chunk by id, returning ``None`` when missing."""
        ...

    def list_chunks(
        self,
        *,
        scope_filter: dict[str, str] | None = None,
        concept_filter: list[str] | None = None,
        contract_filter: list[str] | None = None,
        binding_state_filter: list[str] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[SearchHit], int]:
        """Browse chunks without vector search. Returns ``(items, total)``.

        Useful for the KB browser UI and any admin tooling that needs
        to enumerate chunks by scope / concept / binding state without
        a query vector.
        """
        ...

    def set_binding_state(
        self,
        chunk_id: str,
        state: BindingState,
    ) -> bool:
        """Promote / demote a chunk's binding state. Returns True when found."""
        ...


# ---------------------------------------------------------------------------
# SQLite (+numpy) default implementation
# ---------------------------------------------------------------------------


def _encode_embedding(values: Iterable[float]) -> bytes:
    """Serialise a vector as little-endian float32 bytes."""
    arr = np.asarray(list(values), dtype=np.float32)
    return arr.tobytes(order="C")


def _decode_embedding(blob: bytes, dim: int) -> np.ndarray:
    """Decode stored bytes back to a (dim,) float32 numpy array."""
    arr = np.frombuffer(blob, dtype=np.float32)
    if arr.shape[0] != dim:
        # Defensive — if the row's dim disagrees with the blob length we
        # truncate/pad so the subsequent cosine math does not raise. The
        # row would be corrupt; log for operators.
        logger.warning(
            "kb_chunks row has dim=%d but blob carries %d floats", dim, arr.shape[0]
        )
        if arr.shape[0] > dim:
            arr = arr[:dim]
        else:
            arr = np.concatenate([arr, np.zeros(dim - arr.shape[0], dtype=np.float32)])
    return arr


def _cosine_scores(
    query: np.ndarray,
    matrix: np.ndarray,
) -> np.ndarray:
    """Return cosine similarity between ``query`` and each row of ``matrix``."""
    if matrix.size == 0:
        return np.zeros((0,), dtype=np.float32)
    q_norm = np.linalg.norm(query)
    if q_norm == 0:
        return np.zeros((matrix.shape[0],), dtype=np.float32)
    m_norms = np.linalg.norm(matrix, axis=1)
    m_norms = np.where(m_norms == 0, 1.0, m_norms)
    return (matrix @ query) / (m_norms * q_norm)


def _scope_clauses(scope_filter: dict[str, str] | None) -> list[Any]:
    """Translate a scope-filter dict into SQLAlchemy equality clauses."""
    clauses: list[Any] = []
    if not scope_filter:
        return clauses
    parts = {
        "agent_id": KBChunk.agent_id,
        "workflow_id": KBChunk.workflow_id,
        "run_id": KBChunk.run_id,
    }
    for key, column in parts.items():
        if scope_filter.get(key):
            clauses.append(column == scope_filter[key])
    return clauses


def _row_to_hit(row: KBChunk, score: float) -> SearchHit:
    return SearchHit(
        text=row.text,
        score=float(score),
        metadata=dict(row.metadata_ or {}),
        chunk_id=row.id,
        concept_refs=tuple(row.concept_refs or ()),
        contract_id=row.contract_id,
        source_uri=row.source_uri,
        binding_state=row.binding_state,  # type: ignore[arg-type]
    )


class SqliteVectorStore:
    """Default vector store — any SQLAlchemy engine with numpy-side scoring.

    The "Sqlite" in the name reflects the intended default deployment;
    the implementation works on Postgres (and any other SQLAlchemy
    backend) too. Callers override ``engine`` to target a non-default
    database; by default it resolves the process-wide engine via
    :func:`pygubernator.db.session.get_engine_or_default`.

    Args:
        engine: Target SQLAlchemy engine. Defaults to the shared
            pygubernator engine.
        scan_batch_size: Rows pulled per scan page. Kept small to cap
            peak memory during large scope scans.
    """

    def __init__(
        self,
        *,
        engine: Engine | None = None,
        scan_batch_size: int = 2048,
    ) -> None:
        self._engine = engine
        self._scan_batch_size = max(128, scan_batch_size)

    # -- Lifecycle ---------------------------------------------------------

    def _resolve_engine(self) -> Engine:
        if self._engine is not None:
            return self._engine
        return _get_engine()

    def _session(self) -> Session:
        return Session(self._resolve_engine(), expire_on_commit=False)

    # -- Upsert ------------------------------------------------------------

    def upsert(self, chunks: Iterable[VectorChunk]) -> int:
        """Insert-or-replace the given chunks by ``chunk_id``."""
        rows = list(chunks)
        if not rows:
            return 0
        with self._session() as session, session.begin():
            for chunk in rows:
                if chunk.binding_state not in _VALID_BINDING_STATES:
                    raise ValueError(f"invalid binding_state={chunk.binding_state!r}")
                existing = session.get(KBChunk, chunk.chunk_id)
                payload = dict(
                    scope=chunk.scope.to_key(),
                    agent_id=chunk.scope.agent_id,
                    workflow_id=chunk.scope.workflow_id,
                    run_id=chunk.scope.run_id,
                    source_uri=chunk.source_uri,
                    contract_id=chunk.contract_id,
                    concept_refs=list(chunk.concept_refs),
                    binding_state=chunk.binding_state,
                    embedding_dim=len(chunk.embedding),
                    embedding=_encode_embedding(chunk.embedding),
                    text=chunk.text,
                    metadata_=dict(chunk.metadata),
                    created_at=chunk.created_at,
                )
                if existing is None:
                    session.add(KBChunk(id=chunk.chunk_id, **payload))
                else:
                    for key, value in payload.items():
                        setattr(existing, key, value)
        return len(rows)

    # -- Search ------------------------------------------------------------

    def search(
        self,
        vector: list[float] | tuple[float, ...],
        limit: int,
        *,
        scope_filter: dict[str, str] | None = None,
        concept_filter: list[str] | None = None,
        contract_filter: list[str] | None = None,
        min_score: float = 0.0,
    ) -> list[SearchHit]:
        """See :meth:`VectorStore.search`."""
        if limit <= 0:
            return []
        query_vec = np.asarray(list(vector), dtype=np.float32)
        if query_vec.size == 0:
            return []

        clauses = _scope_clauses(scope_filter)
        if contract_filter:
            clauses.append(KBChunk.contract_id.in_(list(contract_filter)))
        base_select = select(KBChunk)
        if clauses:
            base_select = base_select.where(and_(*clauses))

        # Stream through the candidate rows, computing cosine per batch,
        # and keep a running top-k heap. This avoids loading every row's
        # embedding into memory for large scopes.
        top: list[tuple[float, int, KBChunk]] = []
        counter = 0

        with self._session() as session:
            # Iterate in deterministic order so repeat calls produce
            # stable tie-breaking.
            stream = session.execute(base_select.order_by(KBChunk.created_at)).scalars()
            batch: list[KBChunk] = []
            for row in stream:
                batch.append(row)
                if len(batch) >= self._scan_batch_size:
                    counter = _score_batch(
                        batch,
                        query_vec,
                        concept_filter,
                        min_score,
                        limit,
                        top,
                        counter,
                    )
                    batch.clear()
            if batch:
                counter = _score_batch(
                    batch,
                    query_vec,
                    concept_filter,
                    min_score,
                    limit,
                    top,
                    counter,
                )

        # Heap is a min-heap keyed by score; sort descending for output.
        hits = sorted(top, key=lambda item: item[0], reverse=True)
        return [_row_to_hit(row, score) for score, _idx, row in hits]

    # -- Delete + retrieve -------------------------------------------------

    def delete(self, *, scope_filter: dict[str, str]) -> int:
        """Delete every chunk matching the scope filter.

        Raises:
            ValueError: When ``scope_filter`` is empty OR when any
                value in it is an empty string / non-string — refusing
                the request prevents callers from accidentally widening
                the predicate (an empty value would silently collapse
                the clause and delete more than the caller intended).
        """
        if not scope_filter:
            raise ValueError(
                "delete() requires at least one scope_filter key — refusing "
                "to clear the entire knowledge base silently"
            )
        for key, value in scope_filter.items():
            if not isinstance(value, str) or not value.strip():
                raise ValueError(
                    f"delete() scope_filter[{key!r}] must be a non-empty "
                    f"string, got {value!r}"
                )
        clauses = _scope_clauses(scope_filter)
        if not clauses:
            raise ValueError(
                "delete() scope_filter matched no valid scope keys "
                "(agent_id / workflow_id / run_id)"
            )
        with self._session() as session, session.begin():
            result = session.execute(delete(KBChunk).where(and_(*clauses)))
        # ``Result.rowcount`` is present on the ``CursorResult`` returned
        # by DML statements, but mypy sees the generic ``Result`` type.
        return int(getattr(result, "rowcount", 0) or 0)

    def get(self, chunk_id: str) -> SearchHit | None:
        """Fetch a single chunk by id."""
        with self._session() as session:
            row = session.get(KBChunk, chunk_id)
            if row is None:
                return None
            return _row_to_hit(row, 1.0)

    def list_chunks(
        self,
        *,
        scope_filter: dict[str, str] | None = None,
        concept_filter: list[str] | None = None,
        contract_filter: list[str] | None = None,
        binding_state_filter: list[str] | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[SearchHit], int]:
        """Browse chunks without vector search. See :class:`VectorStore`."""
        from sqlalchemy import func

        limit = max(1, min(limit, 200))
        offset = max(0, offset)

        clauses = _scope_clauses(scope_filter)
        if contract_filter:
            clauses.append(KBChunk.contract_id.in_(list(contract_filter)))
        if binding_state_filter:
            clauses.append(KBChunk.binding_state.in_(list(binding_state_filter)))

        base_select = select(KBChunk)
        count_select = select(func.count(KBChunk.id))
        if clauses:
            base_select = base_select.where(and_(*clauses))
            count_select = count_select.where(and_(*clauses))

        with self._session() as session:
            total = int(session.execute(count_select).scalar() or 0)
            rows = list(
                session.execute(
                    base_select.order_by(KBChunk.created_at.desc())
                    .limit(limit)
                    .offset(offset)
                ).scalars()
            )

        if concept_filter:
            filter_set = frozenset(concept_filter)
            rows = [
                row for row in rows if filter_set.intersection(row.concept_refs or ())
            ]
            # The concept filter is applied post-scan, so the ``total``
            # count may overstate the filtered view. This matches the
            # behaviour of other list endpoints in the codebase, which
            # return counts before post-processing filters.

        hits = [_row_to_hit(row, 1.0) for row in rows]
        return hits, total

    def set_binding_state(
        self,
        chunk_id: str,
        state: BindingState,
    ) -> bool:
        """Promote / demote a chunk's binding state."""
        if state not in _VALID_BINDING_STATES:
            raise ValueError(f"invalid binding_state={state!r}")
        with self._session() as session, session.begin():
            row = session.get(KBChunk, chunk_id)
            if row is None:
                return False
            row.binding_state = state
        return True


def _score_batch(
    batch: list[KBChunk],
    query_vec: np.ndarray,
    concept_filter: list[str] | None,
    min_score: float,
    limit: int,
    top: list[tuple[float, int, KBChunk]],
    counter: int,
) -> int:
    """Score a batch of rows and merge the top-k into ``top``.

    Returns the updated insertion counter used as a deterministic
    tie-breaker inside the heap.
    """
    if not batch:
        return counter

    # concept filter is a Python-side filter — it's expected to prune a
    # small minority of rows, so we apply it post-scan rather than
    # trying to express a JSON-array-contains clause portably.
    if concept_filter:
        filter_set = frozenset(concept_filter)
        batch = [
            row for row in batch if filter_set.intersection(row.concept_refs or ())
        ]
        if not batch:
            return counter

    dims = {row.embedding_dim for row in batch}
    if query_vec.shape[0] not in dims and len(dims) == 1:
        # Query and stored embeddings disagree on dim. Skip the batch.
        logger.warning(
            "search query dim=%d disagrees with stored dim=%s; skipping batch",
            query_vec.shape[0],
            dims,
        )
        return counter

    vectors = np.stack(
        [_decode_embedding(row.embedding, row.embedding_dim) for row in batch]
    )
    scores = _cosine_scores(query_vec, vectors)

    for row, score in zip(batch, scores, strict=False):
        if score < min_score:
            continue
        counter += 1
        entry = (float(score), counter, row)
        if len(top) < limit:
            heapq.heappush(top, entry)
        else:
            heapq.heappushpop(top, entry)
    return counter


__all__ = [
    "BindingState",
    "SearchHit",
    "SqliteVectorStore",
    "VectorChunk",
    "VectorStore",
]
