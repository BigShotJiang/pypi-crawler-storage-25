"""Durable memory & context surfaces, plus the knowledge-base subsystem.

Provides:

- ``MemoryScope``: composite key (agent/workflow/user/run) that
  isolates memory between callers.
- ``AgentContextStore``: a protocol for key/value persistence scoped
  by ``MemoryScope``, with in-memory, SQLAlchemy, and file backends.
- ``AuditingMemoryStore``: a decorator that emits
  ``MemoryAccessAudit`` records around any ``MemoryStore`` interface.
- ``ContextSurface``: structured Markdown-ish notebook an agent can
  read/write across runs (facts / questions / next_actions / log).
- ``VectorStore`` + ``SqliteVectorStore``: persistent vector store
  powering ``kb_ingest`` / ``kb_retrieve`` workflow nodes.
- ``chunk_text``: shared text chunker used by the KB ingestion path.

See ``pygubernator.workflow.nodes._context_surface`` for the workflow
integration and ``pygubernator.workflow.nodes._memory_compacting`` for
cross-run compaction.
"""

from __future__ import annotations

from pygubernator.memory._audit import (
    MEMORY_AUDIT_KIND,
    AuditingMemoryStore,
    MemoryAccessAuditWriter,
)
from pygubernator.memory._backends import (
    FileContextStore,
    InMemoryContextStore,
    RecordStoreContextStore,
    SqlAlchemyContextStore,
)
from pygubernator.memory._chunking import Chunk, chunk_text
from pygubernator.memory._context_store import AgentContextStore
from pygubernator.memory._scope import MemoryScope
from pygubernator.memory._surface import ContextSurface
from pygubernator.memory._vector_store import (
    BindingState,
    SearchHit,
    SqliteVectorStore,
    VectorChunk,
    VectorStore,
)

__all__ = [
    "MEMORY_AUDIT_KIND",
    "AgentContextStore",
    "AuditingMemoryStore",
    "BindingState",
    "Chunk",
    "ContextSurface",
    "FileContextStore",
    "InMemoryContextStore",
    "MemoryAccessAuditWriter",
    "MemoryScope",
    "RecordStoreContextStore",
    "SearchHit",
    "SqlAlchemyContextStore",
    "SqliteVectorStore",
    "VectorChunk",
    "VectorStore",
    "chunk_text",
]
