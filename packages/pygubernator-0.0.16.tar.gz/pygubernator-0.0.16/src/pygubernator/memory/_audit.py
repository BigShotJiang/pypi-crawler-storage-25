"""Memory-access audit.

Wraps a ``MemoryStore`` (workflow-node protocol) or an
``AgentContextStore`` and emits a record for every read / write / delete
so operators can trace which agents touched which scopes and when.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from pygubernator.records import Record, RecordStore, default_record_store

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from pygubernator.memory._scope import MemoryScope

logger = logging.getLogger(__name__)

MEMORY_AUDIT_KIND = "memory_access_audit"


@dataclass(frozen=True, slots=True)
class MemoryAccessRecord:
    """An audit-worthy memory access.

    Args:
        scope: Scope accessed.
        operation: ``get``, ``set``, ``delete``, ``read_messages``,
            ``add_messages``, ``clear``, or a user-defined op name.
        key: Logical key, if applicable.
        agent_id: Calling agent.
        run_id: Current run.
        details: Extra structured data (e.g. message count).
    """

    scope: str
    operation: str
    key: str | None = None
    agent_id: str | None = None
    run_id: str | None = None
    details: dict[str, Any] | None = None


class MemoryAccessAuditWriter:
    """Persists ``MemoryAccessRecord`` instances.

    Uses the ``memory_access_audit`` SQL table when a session factory
    is provided; otherwise writes to the supplied ``RecordStore`` under
    kind ``memory_access_audit``.
    """

    def __init__(
        self,
        *,
        session_factory: Callable[[], Session] | None = None,
        record_store: RecordStore | None = None,
    ) -> None:
        """Initialize.

        Args:
            session_factory: Optional SQLAlchemy session factory.
            record_store: RecordStore fallback. Defaults to the
                process-wide store.
        """
        self._session_factory = session_factory
        self._record_store = record_store or default_record_store()

    def write(self, record: MemoryAccessRecord) -> None:
        """Best-effort persist. Never raises; logs on failure."""
        try:
            if self._session_factory is not None:
                self._write_sql(record)
            else:
                self._write_record_store(record)
        except Exception as exc:
            logger.warning(
                "memory-access audit write failed: scope=%s op=%s err=%s",
                record.scope,
                record.operation,
                exc,
            )

    def _write_sql(self, record: MemoryAccessRecord) -> None:
        from pygubernator.db.models.memory_access_audit import MemoryAccessAudit

        if self._session_factory is None:
            return
        session = self._session_factory()
        try:
            row = MemoryAccessAudit(
                scope=record.scope,
                agent_id=record.agent_id,
                run_id=record.run_id,
                operation=record.operation,
                key=record.key,
                details=record.details or {},
            )
            session.add(row)
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _write_record_store(self, record: MemoryAccessRecord) -> None:
        payload: dict[str, Any] = {
            "operation": record.operation,
            "key": record.key,
            "agent_id": record.agent_id,
            "run_id": record.run_id,
        }
        if record.details:
            payload["details"] = record.details
        self._record_store.put(
            Record(
                kind=MEMORY_AUDIT_KIND,
                scope=record.scope,
                payload=payload,
                created_at=datetime.now(UTC),
            )
        )


class AuditingMemoryStore:
    """Decorator that audits ``MemoryStore`` conversation-history access.

    Wraps any implementation of the ``MemoryStore`` protocol defined
    in ``pygubernator.workflow.nodes._memory``. Every ``get_messages``
    and ``add_messages`` call is recorded.
    """

    def __init__(
        self,
        inner: Any,
        *,
        scope: MemoryScope,
        writer: MemoryAccessAuditWriter | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
    ) -> None:
        """Initialize.

        Args:
            inner: The underlying memory store to wrap.
            scope: Scope recorded on each audit row.
            writer: Audit writer. Defaults to a new
                ``MemoryAccessAuditWriter``.
            agent_id: Calling agent, recorded in each audit row.
            run_id: Current run id, recorded in each audit row.
        """
        self._inner = inner
        self._scope_key = scope.to_key()
        self._writer = writer or MemoryAccessAuditWriter()
        self._agent_id = agent_id
        self._run_id = run_id

    def get_messages(self) -> list[dict[str, str]]:
        """Audited proxy to ``inner.get_messages``."""
        messages = self._inner.get_messages()
        self._emit("read_messages", details={"count": len(messages)})
        return messages

    def add_messages(self, messages: list[dict[str, str]]) -> None:
        """Audited proxy to ``inner.add_messages``."""
        self._inner.add_messages(messages)
        self._emit("add_messages", details={"count": len(messages)})

    def _emit(self, operation: str, *, details: dict[str, Any] | None = None) -> None:
        self._writer.write(
            MemoryAccessRecord(
                scope=self._scope_key,
                operation=operation,
                agent_id=self._agent_id,
                run_id=self._run_id,
                details=details,
            )
        )
