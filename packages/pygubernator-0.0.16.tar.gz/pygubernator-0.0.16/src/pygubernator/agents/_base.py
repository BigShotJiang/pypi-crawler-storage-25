"""Base agent class with pystator lifecycle management."""

from __future__ import annotations

import abc
import logging
from typing import Any

from pystator import EntitySession, StateMachine

from pygubernator._types import AgentResult, Message
from pygubernator.agents._machines import base_lifecycle_config
from pygubernator.errors import AgentError
from pygubernator.events._bus import AgentEvent, AgentEventType, EventBus

logger = logging.getLogger(__name__)


class BaseAgent(abc.ABC):
    """Base class for all pygubernator agents.

    Every agent owns a pystator EntitySession for lifecycle management.
    Lifecycle methods (start, stop, pause, resume) trigger pystator
    state transitions. Subclasses implement the ``process`` method.

    Args:
        agent_id: Unique identifier for this agent.
        machine: Optional custom lifecycle state machine.
        context: Optional initial context for the lifecycle session.
        event_bus: Optional event bus for emitting lifecycle events.
        run_id: Optional run identifier for correlating events.
    """

    def __init__(
        self,
        agent_id: str,
        machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
        event_bus: EventBus | None = None,
        run_id: str | None = None,
    ) -> None:
        self._agent_id = agent_id
        self._event_bus = event_bus
        self._run_id = run_id
        if machine is None:
            machine = StateMachine.from_dict(base_lifecycle_config())
        self._machine = machine
        self._session = machine.create(context=context or {})

    @property
    def agent_id(self) -> str:
        """Unique agent identifier."""
        return self._agent_id

    @property
    def state(self) -> str:
        """Current lifecycle state."""
        return self._session.current_state

    @property
    def session(self) -> EntitySession:
        """The underlying pystator session."""
        return self._session

    @property
    def event_bus(self) -> EventBus | None:
        """The event bus attached to this agent, if any."""
        return self._event_bus

    @property
    def run_id(self) -> str | None:
        """Current run identifier, if set."""
        return self._run_id

    def set_run_id(self, run_id: str | None) -> None:
        """Set the run identifier for this agent.

        Args:
            run_id: Run identifier to use for subsequent events.
        """
        self._run_id = run_id

    def ensure_event_bus(self) -> EventBus:
        """Return the agent's event bus, creating one if absent."""
        if self._event_bus is None:
            self._event_bus = EventBus()
        return self._event_bus

    async def _emit(
        self,
        event_type: AgentEventType,
        data: dict[str, Any] | None = None,
        run_id: str | None = None,
    ) -> None:
        """Emit an event if an event bus is attached.

        Args:
            event_type: The type of event.
            data: Optional event payload.
            run_id: Optional run identifier (overrides agent's default run_id).
        """
        if self._event_bus is None:
            return
        # Use explicit run_id if provided, otherwise fall back to agent's run_id
        effective_run_id = run_id if run_id is not None else self._run_id
        event = AgentEvent(
            event_type=event_type,
            agent_id=self._agent_id,
            data=data or {},
            run_id=effective_run_id,
        )
        await self._event_bus.emit(event)

    def start(self) -> None:
        """Start the agent.

        Raises:
            AgentError: If the lifecycle transition fails.
        """
        result = self._session.send("start")
        if not result.success:
            raise AgentError(
                f"Failed to start agent: {result.error}",
                agent_id=self._agent_id,
            )
        logger.info("Agent %s started", self._agent_id)

    def stop(self) -> None:
        """Stop the agent.

        Raises:
            AgentError: If the lifecycle transition fails.
        """
        result = self._session.send("stop")
        if not result.success:
            raise AgentError(
                f"Failed to stop agent: {result.error}",
                agent_id=self._agent_id,
            )
        logger.info("Agent %s stopped", self._agent_id)

    def pause(self) -> None:
        """Pause the agent.

        Raises:
            AgentError: If the lifecycle transition fails.
        """
        result = self._session.send("pause")
        if not result.success:
            raise AgentError(
                f"Failed to pause agent: {result.error}",
                agent_id=self._agent_id,
            )
        logger.info("Agent %s paused", self._agent_id)

    def resume(self) -> None:
        """Resume the agent from paused state.

        Raises:
            AgentError: If the lifecycle transition fails.
        """
        result = self._session.send("resume")
        if not result.success:
            raise AgentError(
                f"Failed to resume agent: {result.error}",
                agent_id=self._agent_id,
            )
        logger.info("Agent %s resumed", self._agent_id)

    @property
    def is_idle(self) -> bool:
        """Whether the agent is in the idle state."""
        return self.state == "idle"

    @property
    def is_running(self) -> bool:
        """Whether the agent is in the running state."""
        return self.state == "running"

    @property
    def is_paused(self) -> bool:
        """Whether the agent is in the paused state."""
        return self.state == "paused"

    @property
    def is_stopped(self) -> bool:
        """Whether the agent is in the stopped state."""
        return self.state == "stopped"

    @property
    def is_error(self) -> bool:
        """Whether the agent is in the error state."""
        return self.state == "error"

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}(agent_id={self._agent_id!r}, state={self.state!r})"
        )

    async def __aenter__(self) -> BaseAgent:
        """Start the agent and return it for use as an async context manager."""
        self.start()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Stop the agent if it is not already stopped or in error."""
        if self.state not in ("stopped", "error"):
            self.stop()

    @abc.abstractmethod
    async def process(self, message: Message) -> AgentResult:
        """Process a single message.

        Args:
            message: The message to process.

        Returns:
            Result of processing the message.
        """
