"""Tool argument validation against JSON Schema."""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def validate_tool_args(
    args: dict[str, Any],
    schema: dict[str, Any],
    tool_name: str,
) -> list[str]:
    """Validate tool arguments against a JSON Schema.

    Performs lightweight validation of required fields and types
    without pulling in a full JSON Schema library.

    Args:
        args: The arguments to validate.
        schema: The JSON Schema (parameters_schema from the tool).
        tool_name: Tool name for error messages.

    Returns:
        List of validation error strings (empty if valid).
    """
    errors: list[str] = []

    properties = schema.get("properties", {})
    required = set(schema.get("required", []))

    # Check required fields
    for field in required:
        if field not in args:
            errors.append(f"Missing required argument: '{field}'")

    # Check types
    for field, value in args.items():
        if field not in properties:
            continue  # Extra fields are OK
        expected_type = properties[field].get("type")
        if expected_type and not _type_matches(value, expected_type):
            errors.append(
                f"Argument '{field}' expected "
                f"{expected_type}, "
                f"got {type(value).__name__}"
            )

    return errors


def _type_matches(value: Any, json_type: str) -> bool:
    """Check if a Python value matches a JSON Schema type."""
    if json_type == "string":
        return isinstance(value, str)
    if json_type == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if json_type == "number":
        return isinstance(value, int | float) and not isinstance(value, bool)
    if json_type == "boolean":
        return isinstance(value, bool)
    if json_type == "array":
        return isinstance(value, list)
    if json_type == "object":
        return isinstance(value, dict)
    return True  # Unknown type -- allow
