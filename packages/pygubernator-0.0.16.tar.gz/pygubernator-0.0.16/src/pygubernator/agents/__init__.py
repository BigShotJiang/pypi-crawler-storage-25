"""Agent implementations and base classes."""

from __future__ import annotations

from pygubernator.agents._base import BaseAgent
from pygubernator.agents._builder import Agent, AgentBuilder, Session
from pygubernator.agents._builder_types import AgentResponse
from pygubernator.agents._hooks import (
    AfterLLMCallContext,
    AfterToolCallContext,
    BeforeLLMCallContext,
    BeforePromptBuildContext,
    BeforeToolCallContext,
    Hook,
    HookPoint,
    HookRegistry,
)
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._machines import (
    base_lifecycle_config,
    llm_lifecycle_config,
    pipeline_lifecycle_config,
)
from pygubernator.agents._pipeline import PipelineAgent, PipelineStep
from pygubernator.agents._spec import (
    create_llm_agent_from_version,
    load_tools_from_version,
)
from pygubernator.agents._spec_types import AgentVersionLike
from pygubernator.agents._state_machine import StateMachineAgent
from pygubernator.agents._supervisor import (
    AgentPipeline,
    AgentSupervisor,
    RestartPolicy,
)
from pygubernator.agents._team import (
    AgentDelegate,
    AgentFanOut,
    AgentRouter,
)

__all__ = [
    "AfterLLMCallContext",
    "AfterToolCallContext",
    "Agent",
    "AgentBuilder",
    "AgentDelegate",
    "AgentFanOut",
    "AgentPipeline",
    "AgentResponse",
    "AgentRouter",
    "AgentSupervisor",
    "AgentVersionLike",
    "BaseAgent",
    "BeforeLLMCallContext",
    "BeforePromptBuildContext",
    "BeforeToolCallContext",
    "Hook",
    "HookPoint",
    "HookRegistry",
    "LLMAgent",
    "PipelineAgent",
    "PipelineStep",
    "RestartPolicy",
    "Session",
    "StateMachineAgent",
    "base_lifecycle_config",
    "create_llm_agent_from_version",
    "llm_lifecycle_config",
    "load_tools_from_version",
    "pipeline_lifecycle_config",
]
