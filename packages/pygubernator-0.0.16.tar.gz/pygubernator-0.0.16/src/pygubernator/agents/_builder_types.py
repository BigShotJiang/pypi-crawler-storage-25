"""Response types for the builder API."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from pygubernator._types import AgentResult


@dataclass(frozen=True, slots=True)
class AgentResponse:
    """Result from an agent run.

    Attributes:
        text: The agent's final text response.
        tool_calls: List of tool call result dicts.
        iterations: Number of think-act-observe iterations.
        success: Whether the run completed successfully.
        raw: The underlying AgentResult for advanced access.
    """

    text: str
    tool_calls: list[dict[str, Any]]
    iterations: int
    success: bool
    raw: AgentResult

    @staticmethod
    def from_agent_result(result: AgentResult) -> AgentResponse:
        """Create an AgentResponse from an AgentResult.

        Args:
            result: The raw agent result to wrap.

        Returns:
            A user-friendly AgentResponse.
        """
        metadata = result.metadata
        text = metadata.get("response", "")
        tool_calls = metadata.get("tool_results", [])
        iterations = metadata.get("iterations", 0)
        return AgentResponse(
            text=text,
            tool_calls=tool_calls,
            iterations=iterations,
            success=result.success,
            raw=result,
        )
