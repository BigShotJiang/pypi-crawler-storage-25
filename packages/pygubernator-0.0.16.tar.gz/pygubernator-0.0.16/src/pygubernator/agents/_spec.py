"""Build runtime agents from version-like configuration and file AgentSpecs."""

from __future__ import annotations

import importlib
import json
import logging
from collections.abc import Callable
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
from typing import Any

import yaml

from pygubernator._protocols import LLMProvider
from pygubernator.agents._llm import LLMAgent
from pygubernator.agents._spec_types import (
    AGENT_SPEC_V1,
    AgentComponentSpec,
    AgentSpec,
    AgentVersionLike,
    CompiledAgentVersionSpec,
)
from pygubernator.errors import ConfigError
from pygubernator.events._bus import EventBus
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)

__all__ = [
    "compile_agent_spec",
    "create_llm_agent_from_version",
    "load_agent_spec_file",
    "load_tools_from_version",
    "parse_agent_spec_payload",
]


def _canonical_json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _fingerprint_payload(payload: dict[str, Any]) -> str:
    return sha256(_canonical_json(payload).encode("utf-8")).hexdigest()


def parse_agent_spec_payload(
    payload: dict[str, Any],
    *,
    source_path: str | None = None,
) -> AgentSpec:
    """Validate and coerce a raw payload into :class:`AgentSpec`."""
    if not isinstance(payload, dict):
        raise ConfigError("Agent spec must be an object")

    spec_version = (
        str(payload.get("spec_version", AGENT_SPEC_V1)).strip() or AGENT_SPEC_V1
    )
    if spec_version != AGENT_SPEC_V1:
        raise ConfigError(f"Unsupported agent spec version: {spec_version}")

    meta = payload.get("meta", {})
    if meta is None:
        meta = {}
    if not isinstance(meta, dict):
        raise ConfigError("Agent spec meta must be an object")

    name = str(meta.get("name", payload.get("name", ""))).strip()
    owner = str(meta.get("owner", payload.get("owner", "system"))).strip() or "system"
    model_raw = payload.get("model", meta.get("model"))
    model = (
        str(model_raw).strip()
        if isinstance(model_raw, str) and model_raw.strip()
        else None
    )
    prompt_raw = payload.get("prompt", meta.get("prompt"))
    prompt = str(prompt_raw) if isinstance(prompt_raw, str) else None

    tools = payload.get("tools", {})
    if tools is None:
        tools = {}
    if not isinstance(tools, dict):
        raise ConfigError("Agent spec tools must be an object")

    config = payload.get("config", {})
    if config is None:
        config = {}
    if not isinstance(config, dict):
        raise ConfigError("Agent spec config must be an object")

    raw_components = payload.get("components", [])
    if raw_components is None:
        raw_components = []
    if not isinstance(raw_components, list):
        raise ConfigError("Agent spec components must be a list")
    components: list[AgentComponentSpec] = []
    for idx, component in enumerate(raw_components):
        if not isinstance(component, dict):
            raise ConfigError(f"Agent component at index {idx} must be an object")
        component_type = str(
            component.get("component_type", component.get("type", ""))
        ).strip()
        if not component_type:
            raise ConfigError(f"Agent component at index {idx} requires component_type")
        label_raw = component.get("label")
        label = str(label_raw).strip() if isinstance(label_raw, str) else ""
        component_config = component.get("config", {})
        if component_config is None:
            component_config = {}
        if not isinstance(component_config, dict):
            raise ConfigError(
                f"Agent component config at index {idx} must be an object"
            )
        components.append(
            AgentComponentSpec(
                component_type=component_type,
                label=label,
                config=dict(component_config),
            )
        )

    spec_payload = {
        "spec_version": spec_version,
        "meta": {"name": name, "owner": owner},
        "model": model,
        "prompt": prompt,
        "tools": tools,
        "config": config,
        "components": [asdict(c) for c in components],
    }
    return AgentSpec(
        spec_version=spec_version,
        name=name,
        owner=owner,
        model=model,
        prompt=prompt,
        tools=dict(tools),
        config=dict(config),
        components=tuple(components),
        source_path=source_path,
        source_fingerprint=_fingerprint_payload(spec_payload),
    )


def load_agent_spec_file(path: str) -> AgentSpec:
    """Load an AgentSpec from YAML/JSON file path."""
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise ConfigError(f"Agent spec file not found: {p}")
    raw = p.read_text(encoding="utf-8")
    suffix = p.suffix.lower()
    payload = yaml.safe_load(raw) if suffix in {".yaml", ".yml"} else json.loads(raw)
    if not isinstance(payload, dict):
        raise ConfigError("Agent spec file must contain an object")
    return parse_agent_spec_payload(payload, source_path=str(p))


def compile_agent_spec(spec: AgentSpec) -> CompiledAgentVersionSpec:
    """Compile canonical spec into AgentVersion payload fields."""
    spec_json = {
        "spec_version": spec.spec_version,
        "meta": {"name": spec.name, "owner": spec.owner},
        "model": spec.model,
        "prompt": spec.prompt,
        "tools": spec.tools,
        "config": spec.config,
        "components": [asdict(c) for c in spec.components],
    }
    normalized_config = dict(spec.config)
    normalized_config["__agent_spec__"] = {
        "spec_version": spec.spec_version,
        "path": spec.source_path,
        "fingerprint": spec.source_fingerprint,
    }
    if spec.components:
        normalized_config.setdefault("components", [asdict(c) for c in spec.components])
    return CompiledAgentVersionSpec(
        model=spec.model,
        prompt=spec.prompt,
        tools=dict(spec.tools),
        config=normalized_config,
        spec_json=spec_json,
        spec_path=spec.source_path,
        spec_fingerprint=spec.source_fingerprint,
    )


def load_tools_from_version(
    version: AgentVersionLike,
    registry: ToolRegistry | None = None,
) -> ToolRegistry:
    """Load tools from a version's ``tools`` mapping into a :class:`ToolRegistry`."""
    if registry is None:
        registry = ToolRegistry()

    tools = version.tools or {}
    if not tools:
        return registry

    for tool_name, tool_spec in tools.items():
        if not isinstance(tool_spec, dict):
            logger.warning(
                "Tool '%s' has invalid spec (expected dict), skipping",
                tool_name,
            )
            continue

        if "module" in tool_spec and "function" in tool_spec:
            try:
                module_path = tool_spec["module"]
                func_name = tool_spec["function"]
                module = importlib.import_module(module_path)
                tool_func = getattr(module, func_name)
                registry.register(tool_func)
                logger.debug(
                    "Loaded tool '%s' from %s.%s", tool_name, module_path, func_name
                )
            except (ImportError, AttributeError) as exc:
                raise ConfigError(
                    f"Failed to load tool '{tool_name}': {exc}",
                ) from exc
        else:
            logger.warning(
                "Tool '%s' spec missing 'module'/'function', skipping",
                tool_name,
            )

    return registry


def _default_provider_factory(model: str | None) -> LLMProvider:
    from pygubernator.llm._factory import create_provider

    return create_provider(model or "gpt-4")


def create_llm_agent_from_version(
    version: AgentVersionLike,
    llm_provider_factory: Callable[[str | None], LLMProvider] | None = None,
    tool_loader: (
        Callable[[AgentVersionLike, ToolRegistry | None], ToolRegistry] | None
    ) = None,
    event_bus: EventBus | None = None,
    run_id: str | None = None,
) -> LLMAgent:
    """Build :class:`~pygubernator.agents.LLMAgent` from a version-like spec."""
    config = version.config or {}

    provider_dict = config.get("provider")
    if provider_dict and isinstance(provider_dict, dict):
        from pygubernator.llm._config import ProviderConfig, ProviderType
        from pygubernator.llm._factory import create_provider_from_config

        pc = ProviderConfig(
            provider_type=ProviderType(provider_dict["provider_type"]),
            model=provider_dict.get("model", version.model or ""),
            api_base=provider_dict.get("api_base"),
            api_key=provider_dict.get("api_key"),
            max_tokens=provider_dict.get("max_tokens", 4096),
            temperature=provider_dict.get("temperature", 0.0),
            top_p=provider_dict.get("top_p"),
            top_k=provider_dict.get("top_k"),
            model_path=provider_dict.get("model_path"),
            n_ctx=provider_dict.get("n_ctx", 4096),
            n_gpu_layers=provider_dict.get("n_gpu_layers", -1),
            request_timeout=provider_dict.get("request_timeout"),
        )
        llm_provider = create_provider_from_config(pc)
    else:
        factory = llm_provider_factory or _default_provider_factory
        llm_provider = factory(version.model)

    if tool_loader is None:
        tool_loader = load_tools_from_version
    tool_registry = tool_loader(version, None)
    max_iterations = config.get("max_iterations", 10)
    if not isinstance(max_iterations, int) or max_iterations < 1:
        logger.warning(
            "Invalid max_iterations in config, using default: 10",
        )
        max_iterations = 10

    final_registry = tool_registry if len(tool_registry) > 0 else None

    return LLMAgent(
        agent_id=version.agent_id,
        llm_provider=llm_provider,
        tool_registry=final_registry,
        system_prompt=version.prompt or "",
        max_iterations=max_iterations,
        event_bus=event_bus,
        run_id=run_id,
    )
