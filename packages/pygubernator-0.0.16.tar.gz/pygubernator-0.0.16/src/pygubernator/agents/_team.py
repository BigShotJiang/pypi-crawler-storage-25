"""Multi-agent orchestration primitives.

Composable patterns for running multiple agents together:

- :class:`AgentFanOut` — parallel execution with result aggregation
- :class:`AgentRouter` — content-based routing to specialist agents
- :class:`AgentDelegate` — supervisor-worker delegation via tool calling

All three implement ``process(message) → AgentResult`` so they
compose with each other and with :class:`AgentPipeline`.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Any

from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent
from pygubernator.errors import AgentError

logger = logging.getLogger(__name__)

_VALID_STRATEGIES = frozenset({"all", "first_success", "majority"})


class AgentFanOut:
    """Run multiple agents in parallel on the same input.

    Results are aggregated into a single :class:`AgentResult` with
    per-agent outcomes stored in ``metadata["agent_results"]``.

    Args:
        agents: Agents to run concurrently.
        strategy: Aggregation strategy:
            ``"all"`` — succeed only if every agent succeeds.
            ``"first_success"`` — return first success, cancel others.
            ``"majority"`` — succeed if more than half succeed.

    Example::

        fan = AgentFanOut([analyst, reviewer, editor], strategy="all")
        result = await fan.process(message)
    """

    def __init__(
        self,
        agents: list[BaseAgent],
        *,
        strategy: str = "all",
    ) -> None:
        if not agents:
            raise ValueError("AgentFanOut requires at least one agent")
        if strategy not in _VALID_STRATEGIES:
            raise ValueError(
                f"Unknown strategy '{strategy}', "
                f"expected one of {sorted(_VALID_STRATEGIES)}"
            )
        self._agents = list(agents)
        self._strategy = strategy

    async def process(self, message: Message) -> AgentResult:
        """Execute all agents and aggregate results.

        Args:
            message: Input message sent to every agent.

        Returns:
            Aggregated result with per-agent metadata.
        """
        if self._strategy == "first_success":
            return await self._first_success(message)
        return await self._gather(message)

    async def _gather(self, message: Message) -> AgentResult:
        """Run all agents, wait for all, aggregate."""
        tasks = [
            asyncio.create_task(
                agent.process(message),
                name=f"fanout-{agent.agent_id}",
            )
            for agent in self._agents
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        agent_results: dict[str, Any] = {}
        successes = 0
        errors: list[str] = []

        for agent, result in zip(self._agents, results, strict=True):
            if isinstance(result, Exception):
                agent_results[agent.agent_id] = {
                    "success": False,
                    "error": str(result),
                }
                errors.append(f"{agent.agent_id}: {result}")
            else:
                agent_results[agent.agent_id] = result.to_dict()
                if result.success:
                    successes += 1
                else:
                    errors.extend(result.errors)

        total = len(self._agents)
        if self._strategy == "all":
            success = successes == total
        else:  # majority
            success = successes > total / 2

        return AgentResult(
            agent_id="fan_out",
            success=success,
            messages_processed=1,
            errors=errors,
            metadata={"agent_results": agent_results, "strategy": self._strategy},
        )

    async def _first_success(self, message: Message) -> AgentResult:
        """Return the first successful result, cancel remaining."""
        tasks = {
            asyncio.create_task(
                agent.process(message),
                name=f"fanout-{agent.agent_id}",
            ): agent
            for agent in self._agents
        }
        errors: list[str] = []
        try:
            while tasks:
                done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                for task in done:
                    agent = tasks.pop(task)
                    exc = task.exception()
                    if exc is not None:
                        errors.append(f"{agent.agent_id}: {exc}")
                        continue
                    result = task.result()
                    if result.success:
                        for remaining in tasks:
                            remaining.cancel()
                        return result
                    errors.extend(result.errors)
        finally:
            for task in tasks:
                task.cancel()

        return AgentResult(
            agent_id="fan_out",
            success=False,
            messages_processed=1,
            errors=errors or ["No agent succeeded"],
            metadata={"strategy": "first_success"},
        )


class AgentRouter:
    """Route messages to different agents based on a routing function.

    The *router_fn* inspects the message and returns a route name.
    The agent registered under that name processes the message.

    Args:
        routes: Mapping of route names to agents.
        router_fn: Callable that returns a route name for a message.
        default: Optional fallback agent for unmatched routes.

    Example::

        router = AgentRouter(
            routes={"code": coder, "review": reviewer},
            router_fn=lambda msg: msg.payload.get("task_type", "code"),
        )
        result = await router.process(message)
    """

    def __init__(
        self,
        routes: dict[str, BaseAgent],
        router_fn: Callable[[Message], str],
        *,
        default: BaseAgent | None = None,
    ) -> None:
        if not routes:
            raise ValueError("AgentRouter requires at least one route")
        self._routes = dict(routes)
        self._router_fn = router_fn
        self._default = default

    async def process(self, message: Message) -> AgentResult:
        """Route the message and process with the selected agent.

        Args:
            message: Input message to route.

        Returns:
            Result from the selected agent.

        Raises:
            AgentError: If no route matches and no default is set.
        """
        route_name = self._router_fn(message)
        agent = self._routes.get(route_name, self._default)
        if agent is None:
            raise AgentError(
                f"No agent registered for route '{route_name}' "
                f"(available: {sorted(self._routes.keys())})",
                agent_id="router",
            )
        logger.debug("Routing to '%s' (agent=%s)", route_name, agent.agent_id)
        result = await agent.process(message)
        result.metadata["route"] = route_name
        return result


class AgentDelegate:
    """Supervisor agent that delegates sub-tasks to worker agents.

    Each worker is registered as a tool on the supervisor agent.
    The supervisor LLM decides which workers to invoke via tool
    calling, enabling dynamic task decomposition.

    Args:
        supervisor: The coordinating agent (must support tool calling).
        workers: Named worker agents to register as tools.

    Example::

        delegate = AgentDelegate(
            supervisor=coordinator,
            workers={"analyst": data_agent, "writer": prose_agent},
        )
        result = await delegate.process(message)
    """

    def __init__(
        self,
        supervisor: Any,
        workers: dict[str, BaseAgent],
    ) -> None:
        if not workers:
            raise ValueError("AgentDelegate requires at least one worker")
        self._supervisor = supervisor
        self._workers = dict(workers)
        self._setup_tools()

    def _setup_tools(self) -> None:
        """Register each worker as a tool on the supervisor."""
        from pygubernator.agents._builder import Agent

        if not isinstance(self._supervisor, Agent):
            logger.warning(
                "Supervisor is not an Agent instance; tool registration may not work"
            )
            return

        for name, worker in self._workers.items():
            if isinstance(worker, Agent):
                tool = worker.as_tool(
                    name=name,
                    description=f"Delegate to worker agent '{name}'",
                )
            else:
                tool = self._wrap_base_agent(name, worker)
            self._supervisor._llm_agent.tool_registry.register(tool)

    @staticmethod
    def _wrap_base_agent(name: str, agent: BaseAgent) -> Any:
        """Wrap a BaseAgent as a tool manually."""
        from pygubernator.tools._decorator import _DecoratedTool

        async def _delegate(input: str) -> str:
            msg = Message(topic=f"delegate.{name}", payload={"input": input})
            result = await agent.process(msg)
            return str(result.metadata) if result.success else str(result.errors)

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "input": {
                    "type": "string",
                    "description": f"Input text for the '{name}' worker.",
                },
            },
            "required": ["input"],
        }
        return _DecoratedTool(
            func=_delegate,
            name=name,
            description=f"Delegate to worker agent '{name}'",
            parameters_schema=schema,
        )

    async def process(self, message: Message) -> AgentResult:
        """Delegate processing to the supervisor.

        The supervisor decides which workers to invoke via tool calls.

        Args:
            message: Input message for the supervisor.

        Returns:
            Result from the supervisor (includes worker tool call results).
        """
        return await self._supervisor.process(message)
