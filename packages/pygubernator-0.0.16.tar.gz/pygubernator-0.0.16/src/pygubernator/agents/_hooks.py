"""Lifecycle hooks for intercepting and modifying agent behavior."""

from __future__ import annotations

import enum
import logging
from collections import defaultdict
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


class HookPoint(enum.Enum):
    """Points in the agent processing loop where hooks can intercept."""

    BEFORE_PROMPT_BUILD = "before_prompt_build"
    BEFORE_LLM_CALL = "before_llm_call"
    AFTER_LLM_CALL = "after_llm_call"
    BEFORE_TOOL_CALL = "before_tool_call"
    AFTER_TOOL_CALL = "after_tool_call"


# -- Context dataclasses for each hook point --


@dataclass(slots=True)
class BeforePromptBuildContext:
    """Context for BEFORE_PROMPT_BUILD hook.

    Attributes:
        system_prompt: The system prompt to send to the LLM.
        history: Optional conversation history.
        user_message: The user message content.
    """

    system_prompt: str
    history: list[dict[str, Any]] | None
    user_message: str


@dataclass(slots=True)
class BeforeLLMCallContext:
    """Context for BEFORE_LLM_CALL hook.

    Attributes:
        messages: The messages list to send to the LLM.
        tools: Tool schemas to send to the LLM.
        iteration: Current iteration number (1-based).
    """

    messages: list[dict[str, Any]]
    tools: list[dict[str, Any]] | None
    iteration: int


@dataclass(slots=True)
class AfterLLMCallContext:
    """Context for AFTER_LLM_CALL hook.

    Attributes:
        messages: The messages list sent to the LLM.
        response: The LLMResponse from the provider.
        iteration: Current iteration number (1-based).
    """

    messages: list[dict[str, Any]]
    response: Any  # LLMResponse (Any to avoid circular import)
    iteration: int


@dataclass(slots=True)
class BeforeToolCallContext:
    """Context for BEFORE_TOOL_CALL hook.

    Attributes:
        tool_name: Name of the tool to call.
        arguments: Arguments for the tool call.
        tool_call_id: Unique identifier for the tool call.
    """

    tool_name: str
    arguments: dict[str, Any]
    tool_call_id: str


@dataclass(slots=True)
class AfterToolCallContext:
    """Context for AFTER_TOOL_CALL hook.

    Attributes:
        tool_name: Name of the tool that was called.
        arguments: Arguments that were passed to the tool.
        result: The ToolResult from execution.
        tool_call_id: Unique identifier for the tool call.
    """

    tool_name: str
    arguments: dict[str, Any]
    result: Any  # ToolResult (Any to avoid circular import)
    tool_call_id: str


@dataclass(frozen=True, slots=True)
class Hook:
    """A registered lifecycle hook.

    Attributes:
        point: The hook point to intercept.
        handler: Async callable receiving a context object.
        priority: Lower values run first (default 100).
        name: Optional name for identification and removal.
    """

    point: HookPoint
    handler: Callable[..., Coroutine[Any, Any, Any]]
    priority: int = 100
    name: str = ""


class HookRegistry:
    """Registry of hooks for an agent instance.

    Hooks run in priority order (lower first). Each hook receives
    a mutable context object and can modify it in-place or return
    a replacement. Returning ``None`` means no modification.
    """

    def __init__(self) -> None:
        self._hooks: dict[HookPoint, list[Hook]] = defaultdict(
            list,
        )

    def add(self, hook: Hook) -> None:
        """Register a hook.

        Args:
            hook: The hook to register.
        """
        self._hooks[hook.point].append(hook)
        self._hooks[hook.point].sort(key=lambda h: h.priority)

    def remove(self, name: str) -> None:
        """Remove all hooks with the given name.

        Args:
            name: Name of the hooks to remove.
        """
        for point in self._hooks:
            self._hooks[point] = [h for h in self._hooks[point] if h.name != name]

    async def run(self, point: HookPoint, context: Any) -> Any:
        """Run all hooks for a point, threading context through.

        Each hook receives the context and may return a replacement.
        If a hook returns ``None``, the existing context is kept.
        Exceptions in hooks are logged but do not halt execution.

        Args:
            point: The hook point.
            context: The mutable context object.

        Returns:
            The (possibly modified) context.
        """
        for hook in self._hooks.get(point, []):
            try:
                result = await hook.handler(context)
                if result is not None:
                    context = result
            except Exception:
                logger.error(
                    "Hook '%s' at %s failed",
                    hook.name or "unnamed",
                    point.value,
                    exc_info=True,
                )
        return context

    def __len__(self) -> int:
        """Return total number of registered hooks."""
        return sum(len(hooks) for hooks in self._hooks.values())
