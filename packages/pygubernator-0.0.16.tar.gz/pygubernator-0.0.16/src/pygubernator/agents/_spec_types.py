"""Typed models for configuration-driven AgentSpec assembly."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

AGENT_SPEC_V1 = "v1"


@dataclass(frozen=True, slots=True)
class AgentComponentSpec:
    """Declarative component used by the editor/canvas toolchain."""

    component_type: str
    label: str = ""
    config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class AgentSpec:
    """Canonical, file-based agent specification."""

    spec_version: str = AGENT_SPEC_V1
    name: str = ""
    owner: str = "system"
    model: str | None = None
    prompt: str | None = None
    tools: dict[str, Any] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)
    components: tuple[AgentComponentSpec, ...] = ()
    source_path: str | None = None
    source_fingerprint: str | None = None


@dataclass(frozen=True, slots=True)
class CompiledAgentVersionSpec:
    """Normalized payload that can be stored in AgentVersion rows."""

    model: str | None
    prompt: str | None
    tools: dict[str, Any]
    config: dict[str, Any]
    spec_json: dict[str, Any]
    spec_path: str | None = None
    spec_fingerprint: str | None = None


@runtime_checkable
class AgentVersionLike(Protocol):
    """Minimal shape needed to build an :class:`~pygubernator.agents.LLMAgent`."""

    agent_id: str
    model: str | None
    prompt: str | None
    tools: dict[str, Any]
    config: dict[str, Any]


__all__ = [
    "AGENT_SPEC_V1",
    "AgentComponentSpec",
    "AgentSpec",
    "AgentVersionLike",
    "CompiledAgentVersionSpec",
]
