"""Fake sources for testing pluggable connectors.

These satisfy the :class:`pygubernator.connectors.Source` /
:class:`pygubernator.connectors.AsyncSource` protocols and let tests
control exactly what records each ``read`` call returns — no network,
no flakiness, no fixtures to clean up.

Example::

    from pygubernator.testing import FakeSource

    source = FakeSource(records=[{"id": 1}, {"id": 2}])
    result = source.read()
    assert result.records_read == 2
    assert source.read_count == 1
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from pygubernator.connectors._types import SourceResult


class FakeSource:
    """Synchronous in-process source returning a scripted batch each ``read``.

    Args:
        records: Default batch returned on every ``read``. Override per
            call by extending ``scripted_batches`` (oldest-first queue).
        source_type: Identifier used in :class:`SourceResult.source_type`.
        scripted_batches: Optional queue of distinct batches to return
            in order; once exhausted, ``records`` is used as the fallback.
        raise_on_read: If non-``None``, the next ``read`` raises this
            exception instead of returning data. Cleared after one use
            unless ``raise_persistent`` is True.
        raise_persistent: When True, ``raise_on_read`` keeps firing.
    """

    def __init__(
        self,
        records: Sequence[dict[str, Any]] | None = None,
        *,
        source_type: str = "fake",
        scripted_batches: Sequence[Sequence[dict[str, Any]]] | None = None,
        raise_on_read: BaseException | None = None,
        raise_persistent: bool = False,
    ) -> None:
        self.source_type = source_type
        self._default = [dict(r) for r in (records or [])]
        self._queue: list[list[dict[str, Any]]] = [
            [dict(r) for r in batch] for batch in (scripted_batches or [])
        ]
        self.read_count = 0
        self.closed = False
        self._raise_on_read = raise_on_read
        self._raise_persistent = raise_persistent

    def queue_batch(self, batch: Sequence[dict[str, Any]]) -> None:
        """Append a batch to the scripted-read queue."""
        self._queue.append([dict(r) for r in batch])

    def fail_next_read(
        self,
        exc: BaseException,
        *,
        persistent: bool = False,
    ) -> None:
        """Configure the next ``read`` to raise ``exc``.

        Args:
            exc: Exception to raise.
            persistent: If True, every subsequent ``read`` raises
                until :meth:`reset_failure` is called.
        """
        self._raise_on_read = exc
        self._raise_persistent = persistent

    def reset_failure(self) -> None:
        """Stop a persistent ``raise_on_read`` from firing further."""
        self._raise_on_read = None
        self._raise_persistent = False

    def read(self) -> SourceResult:
        """Return the next scripted batch (or the default batch)."""
        self.read_count += 1
        if self._raise_on_read is not None:
            exc = self._raise_on_read
            if not self._raise_persistent:
                self._raise_on_read = None
            raise exc
        batch = self._queue.pop(0) if self._queue else list(self._default)
        return SourceResult(
            success=True,
            records=batch,
            records_read=len(batch),
            source_type=self.source_type,
            metadata={"read_count": self.read_count},
        )

    def close(self) -> None:
        """Mark the source as closed (test code can assert on this flag)."""
        self.closed = True


class FakeAsyncSource(FakeSource):
    """Asynchronous variant of :class:`FakeSource`.

    Implements the :class:`pygubernator.connectors.AsyncSource` protocol
    so it can be used wherever an async source is expected.
    """

    async def read(self) -> SourceResult:  # type: ignore[override]
        """Async wrapper around :meth:`FakeSource.read`."""
        return super().read()

    async def close(self) -> None:  # type: ignore[override]
        """Async wrapper around :meth:`FakeSource.close`."""
        super().close()


__all__ = ["FakeAsyncSource", "FakeSource"]
