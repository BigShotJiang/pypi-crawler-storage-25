"""Workflow-level test helpers — builder, runner, and assertion utilities.

Originally part of the single-file ``pygubernator.testing`` module. Kept
re-exported from :mod:`pygubernator.testing` so existing tests keep
working unchanged.
"""

from __future__ import annotations

import re
from typing import Any

from pygubernator.workflow._types import (
    EdgeSpec,
    NodeSpec,
    WorkflowResult,
    WorkflowSpec,
)


class WorkflowSpecBuilder:
    """Fluent builder for constructing :class:`WorkflowSpec` in tests.

    Reduces the boilerplate of creating inline specs from ~15 lines
    to a short chain of method calls.

    Args:
        name: Workflow name.
        version: Workflow version string.

    Example::

        spec = (WorkflowSpecBuilder("test")
            .add_node("start", "input")
            .add_node("end", "output")
            .connect("start", "end")
            .build())
    """

    def __init__(self, name: str = "test", version: str = "1.0.0") -> None:
        self._name = name
        self._version = version
        self._description = ""
        self._nodes: dict[str, NodeSpec] = {}
        self._edges: list[EdgeSpec] = []
        self._edge_counter = 0

    def description(self, desc: str) -> WorkflowSpecBuilder:
        """Set the workflow description."""
        self._description = desc
        return self

    def add_node(
        self,
        node_id: str,
        node_type: str,
        *,
        config: dict[str, Any] | None = None,
    ) -> WorkflowSpecBuilder:
        """Add a node to the workflow.

        Args:
            node_id: Unique identifier for the node.
            node_type: Node type (e.g. ``"input"``, ``"template"``).
            config: Node-specific configuration.
        """
        self._nodes[node_id] = NodeSpec(
            node_id=node_id,
            node_type=node_type,
            config=config or {},
        )
        return self

    def connect(
        self,
        source: str,
        target: str,
        *,
        condition: str | None = None,
        source_handle: str | None = None,
        target_handle: str | None = None,
    ) -> WorkflowSpecBuilder:
        """Add a directed edge between two nodes."""
        self._edge_counter += 1
        self._edges.append(
            EdgeSpec(
                edge_id=f"e{self._edge_counter}",
                source_id=source,
                target_id=target,
                source_handle=source_handle or "default",
                target_handle=target_handle or "default",
                condition=condition,
            )
        )
        return self

    def build(self) -> WorkflowSpec:
        """Build the :class:`WorkflowSpec`."""
        return WorkflowSpec(
            name=self._name,
            version=self._version,
            description=self._description,
            nodes=dict(self._nodes),
            edges=tuple(self._edges),
        )


class MockLLMProvider:
    """Deterministic LLM provider for testing agent workflows.

    Yields canned responses in order. Wraps around when all responses
    have been consumed.

    Args:
        responses: List of :class:`LLMResponse` objects to return.
            If ``None``, a single default response is used.
    """

    def __init__(self, responses: list[Any] | None = None) -> None:
        from pygubernator.llm import LLMResponse

        self._responses = list(
            responses or [LLMResponse(content="mock response", finish_reason="stop")]
        )
        self._index = 0
        self._call_count = 0
        self._last_messages: list[Any] = []

    async def chat(
        self,
        messages: list[Any],
        tools: list[Any] | None = None,
    ) -> Any:
        """Return the next canned response."""
        self._call_count += 1
        self._last_messages = list(messages)
        response = self._responses[self._index % len(self._responses)]
        self._index += 1
        return response

    @property
    def call_count(self) -> int:
        """Number of times ``chat()`` has been called."""
        return self._call_count

    @property
    def last_messages(self) -> list[Any]:
        """Messages from the most recent ``chat()`` call."""
        return self._last_messages


def run_workflow(
    spec: WorkflowSpec | dict[str, Any],
    input_data: dict[str, Any] | None = None,
    *,
    variables: dict[str, Any] | None = None,
    registry: Any = None,
) -> WorkflowResult:
    """Execute a workflow synchronously for testing.

    Args:
        spec: Workflow specification or config dict.
        input_data: Input data for the workflow.
        variables: Shared variables for all nodes.
        registry: Optional custom :class:`NodeTypeRegistry`.

    Returns:
        The workflow execution result.
    """
    from pygubernator.workflow._facade import Workflow

    if isinstance(spec, dict):
        wf = Workflow.from_dict(spec, registry=registry)
    else:
        wf = Workflow(spec, registry=registry)
    return wf.run(input_data or {}, variables=variables)


def assert_workflow_success(result: WorkflowResult) -> None:
    """Assert the workflow completed successfully.

    Raises:
        AssertionError: If the workflow failed.
    """
    assert result.success, (
        f"Workflow '{result.name}' failed with errors: {result.errors}"
    )


def assert_workflow_failed(
    result: WorkflowResult,
    *,
    error_pattern: str | None = None,
) -> None:
    """Assert the workflow failed, optionally matching an error pattern.

    Raises:
        AssertionError: If the workflow succeeded or pattern doesn't
            match.
    """
    assert not result.success, (
        f"Expected workflow '{result.name}' to fail, but it succeeded"
    )
    if error_pattern is not None:
        joined = " ".join(result.errors)
        assert re.search(error_pattern, joined), (
            f"Error pattern '{error_pattern}' not found in: {result.errors}"
        )


def assert_node_executed(result: WorkflowResult, *node_ids: str) -> None:
    """Assert that specific nodes were executed.

    Raises:
        AssertionError: If any node was not executed.
    """
    executed = set(result.node_results.keys())
    for nid in node_ids:
        assert nid in executed, (
            f"Node '{nid}' was not executed. Executed: {sorted(executed)}"
        )


def assert_output_contains(result: WorkflowResult, **expected: Any) -> None:
    """Assert the workflow output contains expected key-value pairs.

    Raises:
        AssertionError: If any key is missing or value doesn't match.
    """
    for key, value in expected.items():
        assert key in result.output, (
            f"Key '{key}' not in output. Available keys: {sorted(result.output.keys())}"
        )
        assert result.output[key] == value, (
            f"output['{key}'] = {result.output[key]!r}, expected {value!r}"
        )


__all__ = [
    "MockLLMProvider",
    "WorkflowSpecBuilder",
    "assert_node_executed",
    "assert_output_contains",
    "assert_workflow_failed",
    "assert_workflow_success",
    "run_workflow",
]
