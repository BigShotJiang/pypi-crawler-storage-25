"""Testing utilities for pygubernator workflows, agents, tools, and connectors.

The package is organised by what you're testing:

- :mod:`pygubernator.testing._workflows` — fluent
  :class:`WorkflowSpecBuilder`, :func:`run_workflow` runner,
  ``assert_workflow_*`` helpers, and :class:`MockLLMProvider`.
- :mod:`pygubernator.testing._sinks` — :class:`FakeSink` and
  :class:`FakeAsyncSink` for connector / sink-plugin tests.
- :mod:`pygubernator.testing._sources` — :class:`FakeSource` and
  :class:`FakeAsyncSource` for source-plugin tests.
- :mod:`pygubernator.testing._tools` — :class:`ToolTestHarness` for
  ``@tool``-decorated functions and tool-plugin tests.
- :mod:`pygubernator.testing._nodes` — :class:`NodeTestHarness` for
  workflow-node / node-factory plugins.

Example::

    from pygubernator.testing import (
        WorkflowSpecBuilder,
        FakeSink,
        ToolTestHarness,
        NodeTestHarness,
        run_workflow,
        assert_workflow_success,
    )

    spec = (WorkflowSpecBuilder("greet")
        .add_node("in", "input")
        .add_node("greet", "template", config={"template": "Hi {{ name }}"})
        .add_node("out", "output")
        .connect("in", "greet")
        .connect("greet", "out")
        .build())

    result = run_workflow(spec, {"name": "Alice"})
    assert_workflow_success(result)
"""

from __future__ import annotations

from pygubernator.testing._nodes import NodeTestHarness
from pygubernator.testing._sinks import FakeAsyncSink, FakeSink
from pygubernator.testing._sources import FakeAsyncSource, FakeSource
from pygubernator.testing._tools import ToolTestHarness
from pygubernator.testing._workflows import (
    MockLLMProvider,
    WorkflowSpecBuilder,
    assert_node_executed,
    assert_output_contains,
    assert_workflow_failed,
    assert_workflow_success,
    run_workflow,
)

__all__ = [
    "FakeAsyncSink",
    "FakeAsyncSource",
    "FakeSink",
    "FakeSource",
    "MockLLMProvider",
    "NodeTestHarness",
    "ToolTestHarness",
    "WorkflowSpecBuilder",
    "assert_node_executed",
    "assert_output_contains",
    "assert_workflow_failed",
    "assert_workflow_success",
    "run_workflow",
]
