"""Test harness for ``@tool``-decorated functions and ToolRegistry plugins.

Wraps the boilerplate of registering a tool, calling it through a
fully-configured registry, and asserting on the resulting
:class:`ToolResult`. Mirrors the same execution path used by agents in
production so plugin authors test the *real* code path, not a stub.

Example::

    from pygubernator.testing import ToolTestHarness

    @tool(description="echo")
    async def echo(message: str) -> dict:
        return {"echo": message}

    harness = ToolTestHarness(echo)
    result = await harness.call({"message": "hi"})
    assert result.success
    assert result.output == {"echo": "hi"}
"""

from __future__ import annotations

from typing import Any

from pygubernator._types import ToolResult
from pygubernator.policy import CallerContext
from pygubernator.tools._registry import ToolRegistry


class ToolTestHarness:
    """Thin wrapper over :class:`ToolRegistry` for plugin / tool tests.

    Constructs a fresh registry, registers the tool(s), and exposes a
    typed ``call`` that runs the standard execute pipeline (policy +
    audit + budget hooks all default to no-op).

    Args:
        *tools: One or more tools (anything implementing the Tool
            protocol — typically ``@tool``-decorated functions).
        caller_context: Optional default caller context passed into
            every call. Use to assert on audit-record fields.
        registry: Inject a pre-configured :class:`ToolRegistry`
            instead of building a fresh one (e.g. when testing
            policy enforcers or audit writers).
    """

    def __init__(
        self,
        *tools: Any,
        caller_context: CallerContext | None = None,
        registry: ToolRegistry | None = None,
    ) -> None:
        self.registry: ToolRegistry = registry or ToolRegistry(
            caller_context=caller_context,
        )
        if caller_context and registry is not None:
            self.registry.set_caller_context(caller_context)
        for tool in tools:
            self.registry.register(tool)

    def register(self, tool: Any) -> None:
        """Register an additional tool after construction."""
        self.registry.register(tool)

    async def call(
        self,
        params_or_name: dict[str, Any] | str,
        params: dict[str, Any] | None = None,
        *,
        context: CallerContext | None = None,
    ) -> ToolResult:
        """Invoke a tool through the registry's standard execute path.

        Two call shapes are supported:

        - ``await harness.call({"x": 1})`` — only valid when exactly
          one tool is registered; resolves to that tool automatically.
        - ``await harness.call("tool_name", {"x": 1})`` — explicit
          tool selection, required when multiple tools are registered.

        Args:
            params_or_name: Either the params dict (single-tool case)
                or the tool name (multi-tool case).
            params: Tool params when the first arg is a name.
            context: Per-call caller context override.
        """
        if isinstance(params_or_name, str):
            tool_name = params_or_name
            payload = params or {}
        else:
            names = self.registry.list_tools()
            if len(names) != 1:
                raise ValueError(
                    "ToolTestHarness.call(params) is only valid for a "
                    "single registered tool; pass the name explicitly "
                    "when multiple tools are registered."
                )
            tool_name = names[0]
            payload = params_or_name
        return await self.registry.execute(tool_name, payload, context=context)


__all__ = ["ToolTestHarness"]
