"""Test harness for workflow ``Node`` and ``NodeFactory`` plugins.

Removes the boilerplate of constructing a node, building a NodeContext
with sensible defaults, and awaiting ``execute``. Mirrors the path the
:class:`pygubernator.workflow.WorkflowEngine` follows in production
without spinning up a full DAG run.

Example::

    from pygubernator.testing import NodeTestHarness

    harness = NodeTestHarness(MyNodeFactory())
    result = await harness.execute(
        node_id="echo-1",
        config={"prefix": "hi"},
        input_data={"name": "Alice"},
    )
    assert result.status is NodeStatus.SUCCESS
    assert result.output == {"greeting": "hi Alice"}
"""

from __future__ import annotations

from typing import Any

from pygubernator.workflow._protocols import Node, NodeFactory
from pygubernator.workflow._types import NodeContext, NodeResult


class NodeTestHarness:
    """Constructs and exercises a single node through its factory.

    Args:
        factory: A :class:`NodeFactory` that builds the node under test.
            Pass an instance, not a class.
    """

    def __init__(self, factory: NodeFactory) -> None:
        self.factory = factory
        self._last_node: Node | None = None
        self._last_context: NodeContext | None = None

    def build(
        self,
        node_id: str = "node-under-test",
        config: dict[str, Any] | None = None,
    ) -> Node:
        """Construct a node instance via the factory.

        Args:
            node_id: Unique node identifier (defaults to a stable
                string for tests).
            config: Node-specific configuration.
        """
        node = self.factory.create(node_id, dict(config or {}))
        self._last_node = node
        return node

    async def execute(
        self,
        *,
        node_id: str = "node-under-test",
        config: dict[str, Any] | None = None,
        input_data: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
    ) -> NodeResult:
        """Build the node, run it once, and return the result.

        Args:
            node_id: Unique node identifier.
            config: Node-specific configuration.
            input_data: Upstream input merged into the context.
            variables: Workflow-level shared variables.
        """
        node = self.build(node_id=node_id, config=config)
        context = NodeContext(
            node_id=node_id,
            input_data=dict(input_data or {}),
            variables=dict(variables or {}),
            config=dict(config or {}),
        )
        self._last_context = context
        return await node.execute(context)

    @property
    def last_node(self) -> Node | None:
        """Most recently built node (``None`` before first build/execute)."""
        return self._last_node

    @property
    def last_context(self) -> NodeContext | None:
        """The :class:`NodeContext` from the last ``execute`` call."""
        return self._last_context


__all__ = ["NodeTestHarness"]
