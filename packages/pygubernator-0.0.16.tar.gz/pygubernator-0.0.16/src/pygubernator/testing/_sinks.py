"""Fake sinks for testing pluggable connectors.

These satisfy the :class:`pygubernator.connectors.Sink` /
:class:`pygubernator.connectors.AsyncSink` protocols and record
everything they receive so tests can make assertions without spinning
up real services. Use them anywhere ``create_sink`` would normally
return a network-bound implementation.

Example::

    from pygubernator.testing import FakeSink

    sink = FakeSink()
    sink.send([{"id": 1}, {"id": 2}], {"schema": "user"})
    assert sink.record_count == 2
    assert sink.batches[0] == [{"id": 1}, {"id": 2}]
"""

from __future__ import annotations

from typing import Any

from pygubernator.connectors._types import SinkResult


class FakeSink:
    """Synchronous in-process sink that records every batch it receives.

    Mirrors :class:`pygubernator.connectors.sinks.memory.InMemorySink`
    but exposes a few extra introspection helpers (``calls``,
    ``last_metadata``) and an optional ``raise_on_send`` switch for
    error-path tests.

    Args:
        sink_type: Identifier used in :class:`SinkResult.sink_type`.
            Override when testing routing logic that expects a specific
            type name.
        raise_on_send: If non-``None``, the next ``send`` call raises
            this exception instead of recording the batch. The flag
            clears after one use unless ``raise_persistent`` is True.
        raise_persistent: When True, ``raise_on_send`` keeps firing on
            every ``send`` until cleared by ``reset_failure()``.
    """

    def __init__(
        self,
        sink_type: str = "fake",
        *,
        raise_on_send: BaseException | None = None,
        raise_persistent: bool = False,
    ) -> None:
        self.sink_type = sink_type
        self.records: list[dict[str, Any]] = []
        self.batches: list[list[dict[str, Any]]] = []
        self.metadata_log: list[dict[str, Any]] = []
        self.calls = 0
        self._raise_on_send = raise_on_send
        self._raise_persistent = raise_persistent
        self.closed = False

    @property
    def record_count(self) -> int:
        """Total records received across every ``send`` call."""
        return len(self.records)

    @property
    def batch_count(self) -> int:
        """Number of ``send`` calls that successfully recorded a batch."""
        return len(self.batches)

    @property
    def last_metadata(self) -> dict[str, Any] | None:
        """Metadata dict from the most recent ``send`` (``None`` if no send)."""
        return self.metadata_log[-1] if self.metadata_log else None

    def reset(self) -> None:
        """Clear every recorded batch / record / metadata entry."""
        self.records.clear()
        self.batches.clear()
        self.metadata_log.clear()
        self.calls = 0

    def reset_failure(self) -> None:
        """Stop a persistent ``raise_on_send`` from firing on future calls."""
        self._raise_on_send = None
        self._raise_persistent = False

    def fail_next_send(
        self,
        exc: BaseException,
        *,
        persistent: bool = False,
    ) -> None:
        """Configure the next ``send`` to raise ``exc`` instead of recording.

        Args:
            exc: Exception to raise.
            persistent: If True, every subsequent ``send`` raises
                until :meth:`reset_failure` is called.
        """
        self._raise_on_send = exc
        self._raise_persistent = persistent

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Record ``records`` and ``metadata``; honour any pending failure."""
        self.calls += 1
        if self._raise_on_send is not None:
            exc = self._raise_on_send
            if not self._raise_persistent:
                self._raise_on_send = None
            raise exc
        self.records.extend(records)
        self.batches.append([dict(r) for r in records])
        self.metadata_log.append(dict(metadata))
        return SinkResult(
            success=True,
            records_sent=len(records),
            sink_type=self.sink_type,
        )

    def close(self) -> None:
        """Mark the sink as closed (test code can assert on this flag)."""
        self.closed = True


class FakeAsyncSink(FakeSink):
    """Asynchronous variant of :class:`FakeSink`.

    Implements the :class:`pygubernator.connectors.AsyncSink` protocol
    so it can be used wherever an async sink is expected. The
    ``async`` methods just delegate to the sync recording machinery.
    """

    async def send(  # type: ignore[override]
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Async wrapper around :meth:`FakeSink.send`."""
        return super().send(records, metadata)

    async def close(self) -> None:  # type: ignore[override]
        """Async wrapper around :meth:`FakeSink.close`."""
        super().close()


__all__ = ["FakeAsyncSink", "FakeSink"]
