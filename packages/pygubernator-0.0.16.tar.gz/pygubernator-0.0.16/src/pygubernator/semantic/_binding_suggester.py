"""LLM-based concept binding suggester.

Given a piece of text and a slate of candidate concepts, ask an LLM
which concepts (if any) best describe the text. The result is used to
seed ``SUGGESTED``-state bindings on ingested KB chunks, which an
operator can then promote to ``MAPPED`` / ``APPROVED`` via the KB
browser (Phase K1-T8).

Deliberately narrow in scope:

- **Deterministic parsing** — the prompt asks for strict JSON so
  unparseable responses return an empty suggestion list rather than
  exploding the ingest job.
- **Token-budget aware** — only concept id + label + one-line
  definition go into the prompt; free-text examples are dropped.
- **Bounded output** — the caller supplies ``max`` (defaults to 3).
"""

from __future__ import annotations

import json
import logging
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from pygubernator._protocols import LLMProvider
from pygubernator.semantic._types import ConceptRef

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ConceptSuggestion:
    """A single concept the LLM proposed for a chunk.

    Attributes:
        concept_id: Stable id matching a :class:`ConceptRef.id`.
        confidence: Self-reported score in ``[0, 1]``.
        reason: One-line rationale from the LLM.
    """

    concept_id: str
    confidence: float
    reason: str = ""


_MAX_TEXT_CHARS = 2000
_MAX_CONCEPTS_IN_PROMPT = 40


_SYSTEM_PROMPT = (
    "You are a careful ontology mapper. Given a snippet of text and a "
    "catalog of candidate concepts, pick AT MOST {max} concepts whose "
    "definitions the snippet clearly exemplifies. If no concept cleanly "
    "applies, return an empty list. Always return valid JSON matching "
    'this schema: {{"suggestions": [{{"concept_id": str, '
    '"confidence": 0.0..1.0, "reason": str}}]}}. Never invent concept '
    "ids — only use ids from the catalog."
)


def _format_catalog(concepts: Sequence[ConceptRef]) -> str:
    """Render the catalog as a compact newline-separated list."""
    lines: list[str] = []
    for concept in concepts[:_MAX_CONCEPTS_IN_PROMPT]:
        defn = (concept.definition or "").strip().replace("\n", " ")
        if len(defn) > 200:
            defn = defn[:197] + "..."
        lines.append(f"- {concept.id} ({concept.label}): {defn}")
    return "\n".join(lines) if lines else "(no concepts registered)"


def _parse_response(text: str, valid_ids: set[str]) -> list[ConceptSuggestion]:
    """Extract suggestions from the LLM response.

    The LLM is instructed to emit JSON; when the raw response contains
    prose alongside JSON we try to isolate the JSON object by scanning
    for the outer ``{...}`` pair. Any id that isn't in ``valid_ids`` is
    dropped so the LLM can't invent concepts.
    """
    payload = _extract_json_object(text)
    if payload is None:
        logger.debug("binding suggester returned no parseable JSON: %s", text[:200])
        return []
    raw_suggestions = payload.get("suggestions")
    if not isinstance(raw_suggestions, list):
        return []

    out: list[ConceptSuggestion] = []
    for item in raw_suggestions:
        if not isinstance(item, dict):
            continue
        cid = str(item.get("concept_id", "")).strip()
        if not cid or cid not in valid_ids:
            continue
        try:
            confidence = float(item.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = max(0.0, min(1.0, confidence))
        reason = str(item.get("reason", "")).strip()
        out.append(
            ConceptSuggestion(
                concept_id=cid,
                confidence=confidence,
                reason=reason,
            )
        )
    return out


def _extract_json_object(text: str) -> dict[str, Any] | None:
    """Return the first balanced ``{...}`` object in ``text`` as a dict."""
    stripped = text.strip()
    if not stripped:
        return None
    # Fast path: entire response is JSON.
    try:
        value = json.loads(stripped)
    except ValueError:
        value = None
    if isinstance(value, dict):
        return value

    # Fallback: scan for the first balanced object.
    start = stripped.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    for idx in range(start, len(stripped)):
        char = stripped[idx]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                candidate = stripped[start : idx + 1]
                try:
                    parsed = json.loads(candidate)
                except ValueError:
                    return None
                return parsed if isinstance(parsed, dict) else None
    return None


async def suggest_concepts(
    text: str,
    concepts: Sequence[ConceptRef],
    llm: LLMProvider,
    *,
    max: int = 3,
) -> list[ConceptSuggestion]:
    """Ask ``llm`` which concepts best describe ``text``.

    Args:
        text: Chunk body to classify. Truncated to ~2 kB before it
            reaches the prompt.
        concepts: Candidate concepts from the registered ontology.
            Only the first 40 are shown to the LLM.
        llm: Any :class:`LLMProvider`.
        max: Upper bound on suggestions. The prompt enforces this; the
            parser also trims defensively.

    Returns:
        Ordered (highest-confidence-first) list of suggestions. Empty
        on any parse or provider error.
    """
    if max <= 0:
        return []
    if not concepts:
        return []
    snippet = text.strip()
    if not snippet:
        return []
    if len(snippet) > _MAX_TEXT_CHARS:
        snippet = snippet[:_MAX_TEXT_CHARS] + "..."

    valid_ids = {concept.id for concept in concepts}
    catalog = _format_catalog(concepts)
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT.format(max=max)},
        {
            "role": "user",
            "content": (f"Candidate concepts:\n{catalog}\n\nSnippet:\n{snippet}"),
        },
    ]

    try:
        response = await llm.chat(messages)
    except Exception:  # noqa: BLE001 — arbitrary LLM providers raise anything
        # We explicitly swallow every provider exception here because
        # concept binding is a best-effort enrichment. A provider outage
        # must not fail ingest; the caller sees an empty suggestion list
        # and can retry on the next ingest.
        logger.warning("binding suggester LLM call failed", exc_info=True)
        return []

    content = getattr(response, "content", None) or ""
    suggestions = _parse_response(str(content), valid_ids)
    suggestions.sort(key=lambda s: s.confidence, reverse=True)
    return suggestions[:max]


__all__ = ["ConceptSuggestion", "suggest_concepts"]
