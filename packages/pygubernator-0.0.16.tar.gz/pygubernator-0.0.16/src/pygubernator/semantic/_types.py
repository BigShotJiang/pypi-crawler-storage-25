"""Value objects + error types for the semantic facade."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from pygubernator.errors import ErrorCode, GubernatorError

BindingState = Literal["unmapped", "suggested", "mapped", "approved"]


class SemanticError(GubernatorError):
    """Raised when the semantic facade cannot fulfil a request.

    Attributes:
        concept_id: Concept id the operation targeted, if any.
        contract_id: Contract id the operation targeted, if any.
    """

    def __init__(
        self,
        message: str,
        *,
        concept_id: str | None = None,
        contract_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = dict(context or {})
        if concept_id:
            ctx["concept_id"] = concept_id
        if contract_id:
            ctx["contract_id"] = contract_id
        super().__init__(message, ctx, code=ErrorCode.CONFIG_INVALID)
        self.concept_id = concept_id
        self.contract_id = contract_id


@dataclass(frozen=True, slots=True)
class ConceptRef:
    """A lightweight reference to a pycharter concept.

    Attributes:
        id: Namespace-qualified concept id (e.g. ``pygubernator:Person``).
        label: Human-readable label.
        definition: Short definition, if supplied.
        scheme: Concept scheme the concept belongs to.
        concept_type: Pycharter concept type (``entity``, ``process``…).
        broader: Parent concept id (SKOS ``broader``).
    """

    id: str
    label: str
    definition: str | None = None
    scheme: str | None = None
    concept_type: str | None = None
    broader: str | None = None


@dataclass(frozen=True, slots=True)
class FieldBindingRef:
    """Binding between a contract field and a concept."""

    contract_id: str
    field_path: str
    concept_id: str
    state: BindingState = "unmapped"


@dataclass(frozen=True, slots=True)
class RelationshipRef:
    """A relationship edge from pycharter — stated or inferred.

    Attributes:
        source_id: Source concept id.
        target_id: Target concept id.
        relationship_type: Pycharter relationship type (e.g. ``is_a``,
            ``broader``, ``equivalent_to``).
        inferred: ``True`` when the edge only appears in the reasoner's
            closure; ``False`` when asserted directly in the store.
    """

    source_id: str
    target_id: str
    relationship_type: str
    inferred: bool = False


@dataclass(frozen=True, slots=True)
class GovernanceViolation:
    """A single SHACL violation returned by pycharter.

    Attributes:
        focus_node: IRI of the offending node.
        path: SHACL property path reported with the violation.
        value: Offending value, if any.
        shape: IRI / label of the violated shape.
        severity: ``"Violation"``, ``"Warning"``, or ``"Info"``.
        message: Human-readable description of the constraint failure.
    """

    focus_node: str
    path: str
    value: str | None
    shape: str
    severity: str
    message: str


@dataclass(frozen=True, slots=True)
class BindingEventRef:
    """One binding-lifecycle event as surfaced by the pycharter API.

    Attributes:
        contract_id: Contract the binding belongs to.
        field_path: Dotted path within the contract.
        concept_id: Target concept id.
        from_state: Lifecycle state before the transition.
        to_state: Lifecycle state after the transition.
        actor: Who initiated the transition.
        reason: Optional free-text audit reason.
        timestamp: ISO-8601 string of when the transition was recorded.
    """

    contract_id: str
    field_path: str
    concept_id: str
    from_state: BindingState
    to_state: BindingState
    actor: str
    reason: str
    timestamp: str


@dataclass(frozen=True, slots=True)
class GovernanceReport:
    """Summary of a SHACL validation run.

    Attributes:
        conforms: ``True`` when no violations were found.
        error_count: Number of Violation-severity findings.
        warning_count: Number of Warning-severity findings.
        info_count: Number of Info-severity findings.
        violations: All :class:`GovernanceViolation` rows.
    """

    conforms: bool
    error_count: int = 0
    warning_count: int = 0
    info_count: int = 0
    violations: tuple[GovernanceViolation, ...] = field(default_factory=tuple)


@dataclass(frozen=True, slots=True)
class ContractRef:
    """A lightweight reference to a pycharter contract.

    Attributes:
        id: Namespace-qualified contract id (e.g. ``trading/orders``).
        version: Semver string; defaults to ``"0.0.0"`` for unknown.
        title: Human-readable title.
        description: Short description.
        bindings: Known field bindings at the time of snapshot.
    """

    id: str
    version: str = "0.0.0"
    title: str | None = None
    description: str | None = None
    bindings: tuple[FieldBindingRef, ...] = field(default_factory=tuple)


__all__ = [
    "BindingEventRef",
    "BindingState",
    "ConceptRef",
    "ContractRef",
    "FieldBindingRef",
    "GovernanceReport",
    "GovernanceViolation",
    "RelationshipRef",
    "SemanticError",
]
