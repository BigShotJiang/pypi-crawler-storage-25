"""Pygubernator's thin facade over pycharter's ontology + contract stores.

Pygubernator treats pycharter as the canonical source of truth for
concepts, concept schemes, and contract definitions. To avoid a hard
runtime dependency (pycharter is an optional install) and to keep the
UI-driving surface small, pygubernator ships its own narrow
:class:`SemanticClient` protocol plus three implementations:

- :class:`NoopSemanticClient` — always available; returns empty /
  success responses. Used when pycharter is not installed or the
  feature is disabled.
- :class:`LocalSemanticClient` — direct in-process calls into pycharter
  (loader + in-memory `SemanticStoreClient`). Lightweight, no HTTP.
- :class:`RemoteSemanticClient` — HTTP client for deployments where
  pycharter runs as its own service.

All KB workflow nodes and API routes accept a :class:`SemanticClient`
by dependency injection so tests can substitute a fake.
"""

from __future__ import annotations

from pygubernator.semantic._binding_suggester import (
    ConceptSuggestion,
    suggest_concepts,
)
from pygubernator.semantic._client import (
    LocalSemanticClient,
    NoopSemanticClient,
    RemoteSemanticClient,
    SemanticClient,
    resolve_default_client,
)
from pygubernator.semantic._types import (
    BindingEventRef,
    ConceptRef,
    ContractRef,
    FieldBindingRef,
    GovernanceReport,
    GovernanceViolation,
    RelationshipRef,
    SemanticError,
)

__all__ = [
    "BindingEventRef",
    "ConceptRef",
    "ConceptSuggestion",
    "ContractRef",
    "FieldBindingRef",
    "GovernanceReport",
    "GovernanceViolation",
    "LocalSemanticClient",
    "NoopSemanticClient",
    "RelationshipRef",
    "RemoteSemanticClient",
    "SemanticClient",
    "SemanticError",
    "resolve_default_client",
    "suggest_concepts",
]
