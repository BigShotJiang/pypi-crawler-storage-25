"""Implementations of :class:`SemanticClient`.

See :mod:`pygubernator.semantic` for the package-level overview.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

from pygubernator.semantic._types import (
    BindingEventRef,
    BindingState,
    ConceptRef,
    ContractRef,
    FieldBindingRef,
    GovernanceReport,
    GovernanceViolation,
    RelationshipRef,
    SemanticError,
)

logger = logging.getLogger(__name__)


@runtime_checkable
class SemanticClient(Protocol):
    """Narrow interface over pycharter's semantic + contract stores.

    Every KB workflow node and API route depends on this protocol, not
    on pycharter directly. That keeps the surface testable and the
    hard dependency on pycharter optional.
    """

    def get_concept(self, concept_id: str) -> ConceptRef | None:
        """Return the concept with ``concept_id``, or ``None`` if missing."""
        ...

    def list_concepts(
        self,
        *,
        scheme: str | None = None,
        broader: str | None = None,
        concept_type: str | None = None,
    ) -> list[ConceptRef]:
        """List concepts, optionally narrowed by scheme / broader / type."""
        ...

    def get_contract(self, contract_id: str) -> ContractRef | None:
        """Return the contract with ``contract_id``, or ``None``."""
        ...

    def register_contract(self, contract: ContractRef) -> ContractRef:
        """Register or update a contract; returns the stored reference."""
        ...

    def set_field_binding(
        self,
        contract_id: str,
        field_path: str,
        concept_id: str,
        state: BindingState,
    ) -> FieldBindingRef:
        """Create / update a binding between a contract field and a concept."""
        ...

    @property
    def available(self) -> bool:
        """True when the underlying store is reachable and healthy."""
        ...

    # -- Phase K2 additions ------------------------------------------------

    def inferred_relationships(
        self,
        concept_id: str,
        *,
        direction: str = "both",
        types: tuple[str, ...] | None = None,
        only_inferred: bool = False,
    ) -> list[RelationshipRef]:
        """Return relationships touching ``concept_id`` via the reasoner."""
        ...

    def validate_governance(
        self,
        *,
        scheme: str | None = None,
        extra_shapes_ttl: str | None = None,
    ) -> GovernanceReport:
        """Run pycharter's SHACL governance validator."""
        ...

    def record_binding_transition(
        self,
        *,
        contract_id: str,
        field_path: str,
        concept_id: str,
        to_state: BindingState,
        actor: str,
        reason: str = "",
    ) -> FieldBindingRef:
        """Record a binding transition through pycharter's lifecycle.

        Implementations should be tolerant: when the underlying store is
        unavailable they return a :class:`FieldBindingRef` describing the
        requested transition so the caller can still render progress in
        the UI — the lifecycle event is simply not persisted.
        """
        ...

    def list_binding_events(
        self,
        *,
        contract_id: str | None = None,
        field_path: str | None = None,
        concept_id: str | None = None,
    ) -> list[BindingEventRef]:
        """Return binding lifecycle events filtered by the supplied dimensions."""
        ...

    def export_scheme_rdf(
        self,
        scheme_key: str,
        *,
        format: str = "turtle",
    ) -> str | None:
        """Serialise a concept scheme as Turtle or JSON-LD.

        Returns ``None`` when the scheme is unknown or the semantic
        store is unreachable — callers should surface that as an
        "unavailable" message in the UI.
        """
        ...

    def import_scheme_rdf(
        self,
        text: str,
        *,
        format: str = "turtle",
        scheme_key: str | None = None,
    ) -> int:
        """Parse a serialised scheme and upsert concepts. Returns insert count."""
        ...


# ---------------------------------------------------------------------------
# No-op fallback
# ---------------------------------------------------------------------------


class NoopSemanticClient:
    """Always-available client that returns empty results.

    Used when pycharter is not installed, the feature is disabled, or
    tests want to exercise the "no ontology" code path.
    """

    @property
    def available(self) -> bool:
        """Always ``False`` — nothing is backing this client."""
        return False

    def get_concept(self, concept_id: str) -> ConceptRef | None:  # noqa: ARG002
        return None

    def list_concepts(
        self,
        *,
        scheme: str | None = None,  # noqa: ARG002
        broader: str | None = None,  # noqa: ARG002
        concept_type: str | None = None,  # noqa: ARG002
    ) -> list[ConceptRef]:
        return []

    def get_contract(self, contract_id: str) -> ContractRef | None:  # noqa: ARG002
        return None

    def register_contract(self, contract: ContractRef) -> ContractRef:
        return contract

    def set_field_binding(
        self,
        contract_id: str,
        field_path: str,
        concept_id: str,
        state: BindingState,
    ) -> FieldBindingRef:
        return FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=state,
        )

    def inferred_relationships(
        self,
        concept_id: str,  # noqa: ARG002
        *,
        direction: str = "both",  # noqa: ARG002
        types: tuple[str, ...] | None = None,  # noqa: ARG002
        only_inferred: bool = False,  # noqa: ARG002
    ) -> list[RelationshipRef]:
        return []

    def validate_governance(
        self,
        *,
        scheme: str | None = None,  # noqa: ARG002
        extra_shapes_ttl: str | None = None,  # noqa: ARG002
    ) -> GovernanceReport:
        return GovernanceReport(conforms=True)

    def record_binding_transition(
        self,
        *,
        contract_id: str,
        field_path: str,
        concept_id: str,
        to_state: BindingState,
        actor: str,  # noqa: ARG002
        reason: str = "",  # noqa: ARG002
    ) -> FieldBindingRef:
        return FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=to_state,
        )

    def list_binding_events(
        self,
        *,
        contract_id: str | None = None,  # noqa: ARG002
        field_path: str | None = None,  # noqa: ARG002
        concept_id: str | None = None,  # noqa: ARG002
    ) -> list[BindingEventRef]:
        return []

    def export_scheme_rdf(
        self,
        scheme_key: str,  # noqa: ARG002
        *,
        format: str = "turtle",  # noqa: ARG002
    ) -> str | None:
        return None

    def import_scheme_rdf(
        self,
        text: str,  # noqa: ARG002
        *,
        format: str = "turtle",  # noqa: ARG002
        scheme_key: str | None = None,  # noqa: ARG002
    ) -> int:
        return 0


# ---------------------------------------------------------------------------
# Local (in-process pycharter)
# ---------------------------------------------------------------------------


class LocalSemanticClient:
    """Calls pycharter's semantic + contract stores in-process.

    Pycharter's installed stores key contracts by
    ``(contract_name, contract_version)`` tuples; this client accepts
    the combined ``"name:version"`` id shape used throughout
    pygubernator and splits on the last colon. When pycharter isn't
    installed, :attr:`available` returns ``False`` and every method
    gives the same empty-result behaviour as
    :class:`NoopSemanticClient` — the control plane still runs.

    Pycharter's installed in-memory contract store does not model
    field bindings as first-class rows yet, so this client maintains
    an in-memory side-table keyed by ``(contract_id, field_path)``.
    Phase K2 turns that into a thin shim over pycharter-native
    lifecycle tables.
    """

    def __init__(self) -> None:
        self._concepts: object | None = None
        self._contracts: object | None = None
        self._bindings: dict[tuple[str, str], FieldBindingRef] = {}
        self._ready = False

    @property
    def available(self) -> bool:
        try:
            self._ensure_ready()
        except SemanticError:
            return False
        return True

    def _ensure_ready(self) -> None:
        if self._ready:
            return
        try:
            from pycharter.contract_store import (  # type: ignore[import-not-found]
                InMemoryContractStore,
            )
            from pycharter.semantic_store import (  # type: ignore[import-not-found]
                InMemorySemanticStore,
            )
        except ImportError as exc:
            raise SemanticError(
                "pycharter is not installed; use NoopSemanticClient "
                "instead of LocalSemanticClient.",
            ) from exc
        concepts = InMemorySemanticStore()
        contracts = InMemoryContractStore()
        # Pycharter stores require an explicit connect() before use.
        if hasattr(concepts, "connect"):
            concepts.connect()
        if hasattr(contracts, "connect"):
            contracts.connect()
        self._concepts = concepts
        self._contracts = contracts
        self._ready = True

    @staticmethod
    def _split_id(contract_id: str) -> tuple[str, str]:
        """Split ``name:version`` into parts. Defaults version to ``1.0.0``."""
        if ":" in contract_id:
            name, _, version = contract_id.rpartition(":")
            return name, version or "1.0.0"
        return contract_id, "1.0.0"

    def get_concept(self, concept_id: str) -> ConceptRef | None:
        try:
            self._ensure_ready()
        except SemanticError:
            return None
        store = self._concepts
        assert store is not None
        try:
            raw = store.get_concept(concept_id)  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, TypeError, ValueError, KeyError):
            logger.debug("concept lookup failed: %s", concept_id, exc_info=True)
            return None
        if raw is None:
            return None
        return _coerce_concept(raw)

    def list_concepts(
        self,
        *,
        scheme: str | None = None,
        broader: str | None = None,
        concept_type: str | None = None,
    ) -> list[ConceptRef]:
        try:
            self._ensure_ready()
        except SemanticError:
            return []
        store = self._concepts
        assert store is not None
        try:
            raw_list = store.list_concepts(scheme_key=scheme)  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("concept list failed", exc_info=True)
            return []
        refs = [_coerce_concept(item) for item in raw_list]
        if broader:
            refs = [r for r in refs if r.broader == broader]
        if concept_type:
            refs = [r for r in refs if r.concept_type == concept_type]
        return refs

    def get_contract(self, contract_id: str) -> ContractRef | None:
        try:
            self._ensure_ready()
        except SemanticError:
            return None
        store = self._contracts
        assert store is not None
        name, version = self._split_id(contract_id)
        try:
            schema = store.get_schema(name, version)  # type: ignore[attr-defined]
            metadata = store.get_metadata(name, version) or {}  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, TypeError, ValueError, KeyError):
            logger.debug("contract lookup failed: %s", contract_id, exc_info=True)
            return None
        if schema is None and not metadata:
            return None
        bindings = tuple(
            ref for (cid, _field), ref in self._bindings.items() if cid == contract_id
        )
        return ContractRef(
            id=contract_id,
            version=version,
            title=(metadata or {}).get("title"),
            description=(metadata or {}).get("description"),
            bindings=bindings,
        )

    def register_contract(self, contract: ContractRef) -> ContractRef:
        try:
            self._ensure_ready()
        except SemanticError as exc:
            raise SemanticError(
                f"failed to register contract '{contract.id}': pycharter unavailable",
                contract_id=contract.id,
            ) from exc
        store = self._contracts
        assert store is not None
        name, version = self._split_id(contract.id)
        metadata = {
            "title": contract.title,
            "description": contract.description,
            "version": version,
        }
        try:
            store.store_metadata(name, version, metadata)  # type: ignore[attr-defined]
        except (AttributeError, RuntimeError, TypeError, ValueError, KeyError) as exc:
            raise SemanticError(
                f"failed to register contract '{contract.id}': {exc}",
                contract_id=contract.id,
            ) from exc
        return contract

    def set_field_binding(
        self,
        contract_id: str,
        field_path: str,
        concept_id: str,
        state: BindingState,
    ) -> FieldBindingRef:
        # Pycharter's installed in-memory contract store does not model
        # field bindings as first-class rows yet, so we maintain a
        # side-table keyed by ``(contract_id, field_path)``. This
        # becomes a shim once Phase K2 lands lifecycle tables in
        # pycharter itself.
        try:
            self._ensure_ready()
        except SemanticError as exc:
            raise SemanticError(
                f"failed to bind {contract_id}.{field_path} → {concept_id}: "
                "pycharter unavailable",
                contract_id=contract_id,
                concept_id=concept_id,
            ) from exc
        ref = FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=state,
        )
        self._bindings[(contract_id, field_path)] = ref
        return ref

    def inferred_relationships(
        self,
        concept_id: str,
        *,
        direction: str = "both",
        types: tuple[str, ...] | None = None,
        only_inferred: bool = False,
    ) -> list[RelationshipRef]:
        try:
            self._ensure_ready()
        except SemanticError:
            return []
        try:
            from pycharter.semantic.reasoning import (  # type: ignore[import-not-found]
                ConceptGraphReasoner,
            )
        except ImportError:
            logger.debug(
                "pycharter.semantic.reasoning unavailable; returning []",
                exc_info=True,
            )
            return []
        store = self._concepts
        assert store is not None
        reasoner = ConceptGraphReasoner(store)
        try:
            edges = reasoner.inferred_relationships(
                of=concept_id,
                direction=direction,
                types=types,
                only_inferred=only_inferred,
            )
        except Exception:  # noqa: BLE001 — degrade gracefully
            logger.debug("reasoner query failed", exc_info=True)
            return []
        return [
            RelationshipRef(
                source_id=edge.source_name,
                target_id=edge.target_name,
                relationship_type=edge.relationship_type,
                inferred=edge.inferred,
            )
            for edge in edges
        ]

    def validate_governance(
        self,
        *,
        scheme: str | None = None,
        extra_shapes_ttl: str | None = None,
    ) -> GovernanceReport:
        try:
            self._ensure_ready()
        except SemanticError:
            return GovernanceReport(conforms=True)
        try:
            from pycharter.semantic.governance import (  # type: ignore[import-not-found]
                GovernanceValidator,
            )
        except ImportError:
            logger.debug(
                "pycharter.semantic.governance unavailable; skipping",
                exc_info=True,
            )
            return GovernanceReport(conforms=True)
        store = self._concepts
        assert store is not None
        try:
            report = GovernanceValidator(
                extra_shapes_ttl=extra_shapes_ttl,
            ).validate(store, scheme_key=scheme)
        except Exception as exc:  # noqa: BLE001 — surface as SemanticError
            raise SemanticError(
                f"governance validation failed: {exc}",
            ) from exc
        return GovernanceReport(
            conforms=report.conforms,
            error_count=report.error_count,
            warning_count=report.warning_count,
            info_count=report.info_count,
            violations=tuple(
                GovernanceViolation(
                    focus_node=v.focus_node,
                    path=v.path,
                    value=v.value,
                    shape=v.shape,
                    severity=v.severity,
                    message=v.message,
                )
                for v in report.violations
            ),
        )

    def record_binding_transition(
        self,
        *,
        contract_id: str,
        field_path: str,
        concept_id: str,
        to_state: BindingState,
        actor: str,
        reason: str = "",
    ) -> FieldBindingRef:
        """See :meth:`SemanticClient.record_binding_transition`."""
        ref = FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=to_state,
        )
        lifecycle = _local_lifecycle()
        if lifecycle is None:
            return ref
        try:
            from pycharter.semantic.lifecycle import (  # type: ignore[import-not-found]
                BindingState as PyBindingState,
            )
        except ImportError:
            return ref
        try:
            lifecycle.transition(
                contract_id=contract_id,
                field_path=field_path,
                concept_id=concept_id,
                to_state=PyBindingState(to_state),
                actor=actor,
                reason=reason,
            )
        except Exception:  # noqa: BLE001 — log + return stub on failure
            logger.debug("failed to record binding transition", exc_info=True)
        return ref

    def list_binding_events(
        self,
        *,
        contract_id: str | None = None,
        field_path: str | None = None,
        concept_id: str | None = None,
    ) -> list[BindingEventRef]:
        """See :meth:`SemanticClient.list_binding_events`."""
        lifecycle = _local_lifecycle()
        if lifecycle is None:
            return []
        try:
            events = lifecycle.events(
                contract_id=contract_id,
                field_path=field_path,
                concept_id=concept_id,
            )
        except Exception:  # noqa: BLE001 — degrade silently
            logger.debug("failed to list binding events", exc_info=True)
            return []
        return [
            BindingEventRef(
                contract_id=event.contract_id,
                field_path=event.field_path,
                concept_id=event.concept_id,
                from_state=event.from_state.value,  # type: ignore[arg-type]
                to_state=event.to_state.value,  # type: ignore[arg-type]
                actor=event.actor,
                reason=event.reason,
                timestamp=event.timestamp.isoformat(),
            )
            for event in events
        ]

    def export_scheme_rdf(
        self,
        scheme_key: str,
        *,
        format: str = "turtle",
    ) -> str | None:
        """See :meth:`SemanticClient.export_scheme_rdf`."""
        try:
            self._ensure_ready()
        except SemanticError:
            return None
        store = self._concepts
        assert store is not None
        try:
            header = store.get_scheme(scheme_key)  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001 — unknown scheme → None
            logger.debug("get_scheme(%s) raised", scheme_key, exc_info=True)
            return None
        if header is None:
            return None
        try:
            from pycharter.semantic.ontology.models import (  # type: ignore[import-not-found]
                Concept,
                ConceptScheme,
            )
            from pycharter.semantic.rdf.roundtrip import (  # type: ignore[import-not-found]
                dump_scheme,
            )
        except ImportError:
            return None

        scheme = ConceptScheme(
            id=str(header.get("key") or header.get("scheme_key") or scheme_key),
            title=str(header.get("title") or scheme_key),
            version=str(header.get("version") or "1.0.0"),
            description=str(header.get("description") or ""),
            base_uri=str(header.get("base_uri") or ""),
        )
        for row in store.list_concepts(scheme_key=scheme_key):  # type: ignore[attr-defined]
            name = row.get("name")
            if not name:
                continue
            scheme.concepts.append(
                Concept(
                    id=str(name),
                    label=str(row.get("label") or name),
                    definition=row.get("definition"),
                    broader=row.get("broader"),
                    notation=row.get("notation"),
                    concept_type=row.get("concept_type"),
                )
            )
        try:
            return dump_scheme(scheme, format=format)  # type: ignore[arg-type]
        except Exception:  # noqa: BLE001 — surface as unavailable
            logger.debug("dump_scheme failed", exc_info=True)
            return None

    def import_scheme_rdf(
        self,
        text: str,
        *,
        format: str = "turtle",
        scheme_key: str | None = None,
    ) -> int:
        """See :meth:`SemanticClient.import_scheme_rdf`."""
        try:
            self._ensure_ready()
        except SemanticError:
            return 0
        store = self._concepts
        assert store is not None
        try:
            from pycharter.semantic.rdf.roundtrip import (  # type: ignore[import-not-found]
                load_scheme,
            )
        except ImportError:
            return 0
        try:
            scheme = load_scheme(text, format=format)  # type: ignore[arg-type]
        except Exception as exc:  # noqa: BLE001 — raise as SemanticError
            raise SemanticError(
                f"failed to parse {format} payload: {exc}",
            ) from exc

        resolved_key = scheme_key or scheme.id or "imported"
        try:
            existing = store.get_scheme(resolved_key)  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001 — let store_scheme raise on real issues
            existing = None
        if existing is None:
            store.store_scheme(  # type: ignore[attr-defined]
                resolved_key,
                title=scheme.title or resolved_key,
                version=scheme.version or "1.0.0",
                base_uri=scheme.base_uri
                or f"urn:pygubernator:imported:{resolved_key}:",
            )

        inserted = 0
        for concept in scheme.concepts:
            if concept.id and store.get_concept(concept.id) is not None:  # type: ignore[attr-defined]
                continue
            kw: dict[str, str] = {"broader": concept.broader} if concept.broader else {}
            store.store_concept(  # type: ignore[attr-defined]
                name=concept.id,
                label=concept.label or concept.id,
                scheme_key=resolved_key,
                concept_type=concept.concept_type or "entity",
                **kw,
            )
            inserted += 1
        return inserted


# Process-level singleton so :meth:`record_binding_transition` and
# :meth:`list_binding_events` share an event log inside a single
# pygubernator deployment using the local client. Cross-process
# deployments should use :class:`RemoteSemanticClient`.
_LOCAL_LIFECYCLE: object | None = None


def _local_lifecycle() -> object | None:
    """Lazy-import a shared :class:`BindingLifecycle` for local mode."""
    global _LOCAL_LIFECYCLE  # noqa: PLW0603 — module-level singleton by design
    if _LOCAL_LIFECYCLE is not None:
        return _LOCAL_LIFECYCLE
    try:
        from pycharter.semantic.lifecycle import (  # type: ignore[import-not-found]
            BindingLifecycle,
        )
    except ImportError:
        return None
    _LOCAL_LIFECYCLE = BindingLifecycle()
    return _LOCAL_LIFECYCLE


# ---------------------------------------------------------------------------
# Remote (pycharter as its own service)
# ---------------------------------------------------------------------------


class RemoteSemanticClient:
    """HTTP client targeting pycharter's FastAPI routes.

    Args:
        base_url: Pycharter API root (e.g. ``http://pycharter:8080``).
        token: Optional bearer token.
        timeout: Per-request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout

    @property
    def available(self) -> bool:
        try:
            import httpx
        except ImportError:
            logger.debug("httpx is not installed; RemoteSemanticClient is unavailable")
            return False
        try:
            resp = httpx.get(
                f"{self._base_url}/api/v1/health",
                headers=self._headers(),
                timeout=self._timeout,
            )
        except httpx.HTTPError:
            logger.debug("remote semantic healthcheck failed", exc_info=True)
            return False
        return resp.status_code < 500

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return headers

    def _get(self, path: str) -> dict | None:
        import httpx

        try:
            resp = httpx.get(
                f"{self._base_url}{path}",
                headers=self._headers(),
                timeout=self._timeout,
            )
        except httpx.HTTPError:
            logger.debug("remote GET failed: %s", path, exc_info=True)
            return None
        if resp.status_code == 404:
            return None
        if resp.status_code >= 400:
            raise SemanticError(f"pycharter GET {path} returned {resp.status_code}")
        return resp.json() if resp.content else None

    def _post(self, path: str, payload: dict) -> dict:
        import httpx

        try:
            resp = httpx.post(
                f"{self._base_url}{path}",
                json=payload,
                headers=self._headers(),
                timeout=self._timeout,
            )
        except httpx.HTTPError as exc:
            raise SemanticError(
                f"pycharter POST {path} failed: {exc}",
            ) from exc
        if resp.status_code >= 400:
            raise SemanticError(
                f"pycharter POST {path} returned {resp.status_code}",
            )
        return resp.json() if resp.content else {}

    def get_concept(self, concept_id: str) -> ConceptRef | None:
        payload = self._get(f"/api/v1/semantic/concepts/{concept_id}")
        return _coerce_concept(payload) if payload else None

    def list_concepts(
        self,
        *,
        scheme: str | None = None,
        broader: str | None = None,
        concept_type: str | None = None,
    ) -> list[ConceptRef]:
        from urllib.parse import urlencode

        query = {
            k: v
            for k, v in {
                "scheme": scheme,
                "broader": broader,
                "concept_type": concept_type,
            }.items()
            if v
        }
        path = "/api/v1/semantic/concepts"
        if query:
            path = f"{path}?{urlencode(query)}"
        payload = self._get(path) or {}
        items = payload.get("items", []) if isinstance(payload, dict) else []
        return [_coerce_concept(item) for item in items]

    def get_contract(self, contract_id: str) -> ContractRef | None:
        payload = self._get(f"/api/v1/contracts/{contract_id}")
        return _coerce_contract(payload) if payload else None

    def register_contract(self, contract: ContractRef) -> ContractRef:
        payload = self._post(
            "/api/v1/contracts",
            {
                "id": contract.id,
                "version": contract.version,
                "title": contract.title,
                "description": contract.description,
            },
        )
        return _coerce_contract(payload or {"id": contract.id})

    def set_field_binding(
        self,
        contract_id: str,
        field_path: str,
        concept_id: str,
        state: BindingState,
    ) -> FieldBindingRef:
        self._post(
            f"/api/v1/contracts/{contract_id}/bindings",
            {
                "field_path": field_path,
                "concept_id": concept_id,
                "state": state,
            },
        )
        return FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=state,
        )

    def inferred_relationships(
        self,
        concept_id: str,
        *,
        direction: str = "both",
        types: tuple[str, ...] | None = None,
        only_inferred: bool = False,
    ) -> list[RelationshipRef]:
        from urllib.parse import urlencode

        query: dict[str, str] = {"direction": direction}
        if only_inferred:
            query["only_inferred"] = "true"
        if types:
            query["types"] = ",".join(types)
        path = f"/api/v1/semantic/reasoning/{concept_id}?{urlencode(query)}"
        payload = self._get(path)
        if not payload:
            return []
        items = payload.get("items", []) if isinstance(payload, dict) else []
        return [
            RelationshipRef(
                source_id=str(item.get("source_id", "")),
                target_id=str(item.get("target_id", "")),
                relationship_type=str(item.get("relationship_type", "")),
                inferred=bool(item.get("inferred", False)),
            )
            for item in items
        ]

    def validate_governance(
        self,
        *,
        scheme: str | None = None,
        extra_shapes_ttl: str | None = None,
    ) -> GovernanceReport:
        payload: dict = {}
        if scheme:
            payload["scheme_key"] = scheme
        if extra_shapes_ttl:
            payload["extra_shapes_ttl"] = extra_shapes_ttl
        response = self._post(
            "/api/v1/semantic/governance/validate",
            payload,
        )
        violations = response.get("violations", []) or []
        return GovernanceReport(
            conforms=bool(response.get("conforms", True)),
            error_count=int(response.get("error_count", 0)),
            warning_count=int(response.get("warning_count", 0)),
            info_count=int(response.get("info_count", 0)),
            violations=tuple(
                GovernanceViolation(
                    focus_node=str(v.get("focus_node", "")),
                    path=str(v.get("path", "")),
                    value=v.get("value"),
                    shape=str(v.get("shape", "")),
                    severity=str(v.get("severity", "")),
                    message=str(v.get("message", "")),
                )
                for v in violations
            ),
        )

    def record_binding_transition(
        self,
        *,
        contract_id: str,
        field_path: str,
        concept_id: str,
        to_state: BindingState,
        actor: str,
        reason: str = "",
    ) -> FieldBindingRef:
        """See :meth:`SemanticClient.record_binding_transition`."""
        try:
            self._post(
                "/api/v1/semantic/bindings/transitions",
                {
                    "contract_id": contract_id,
                    "field_path": field_path,
                    "concept_id": concept_id,
                    "to_state": to_state,
                    "actor": actor,
                    "reason": reason,
                },
            )
        except SemanticError:
            # Lifecycle record is best-effort for remote deployments;
            # don't break the calling route if pycharter is down.
            logger.debug("remote lifecycle transition failed", exc_info=True)
        return FieldBindingRef(
            contract_id=contract_id,
            field_path=field_path,
            concept_id=concept_id,
            state=to_state,
        )

    def list_binding_events(
        self,
        *,
        contract_id: str | None = None,
        field_path: str | None = None,
        concept_id: str | None = None,
    ) -> list[BindingEventRef]:
        """See :meth:`SemanticClient.list_binding_events`."""
        from urllib.parse import urlencode

        query: dict[str, str] = {}
        if contract_id:
            query["contract_id"] = contract_id
        if field_path:
            query["field_path"] = field_path
        if concept_id:
            query["concept_id"] = concept_id
        suffix = f"?{urlencode(query)}" if query else ""
        payload = self._get(f"/api/v1/semantic/bindings/events{suffix}")
        if not payload:
            return []
        # FastAPI returns a bare list by default; tolerate either shape.
        rows = payload.get("items", []) or [] if isinstance(payload, dict) else payload
        return [
            BindingEventRef(
                contract_id=str(row.get("contract_id", "")),
                field_path=str(row.get("field_path", "")),
                concept_id=str(row.get("concept_id", "")),
                from_state=str(row.get("from_state", "unmapped")),  # type: ignore[arg-type]
                to_state=str(row.get("to_state", "unmapped")),  # type: ignore[arg-type]
                actor=str(row.get("actor", "")),
                reason=str(row.get("reason", "")),
                timestamp=str(row.get("timestamp", "")),
            )
            for row in rows
        ]

    def export_scheme_rdf(
        self,
        scheme_key: str,
        *,
        format: str = "turtle",
    ) -> str | None:
        """See :meth:`SemanticClient.export_scheme_rdf`."""
        import httpx

        try:
            resp = httpx.get(
                f"{self._base_url}/api/v1/semantic/schemes/"
                f"{scheme_key}/rdf?format={format}",
                headers=self._headers(),
                timeout=self._timeout,
            )
        except httpx.HTTPError:
            logger.debug("remote scheme export failed", exc_info=True)
            return None
        if resp.status_code == 404:
            return None
        if resp.status_code >= 400:
            return None
        return resp.text

    def import_scheme_rdf(
        self,
        text: str,
        *,
        format: str = "turtle",
        scheme_key: str | None = None,
    ) -> int:
        """See :meth:`SemanticClient.import_scheme_rdf`."""
        payload: dict[str, str] = {"text": text, "format": format}
        if scheme_key:
            payload["overwrite_scheme_key"] = scheme_key
        response = self._post("/api/v1/semantic/schemes/rdf", payload)
        return int(response.get("concepts_upserted", 0))


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def resolve_default_client() -> SemanticClient:
    """Return the best available :class:`SemanticClient`.

    Tries :class:`LocalSemanticClient` first and falls back to
    :class:`NoopSemanticClient` when pycharter isn't installed. This
    is what workflow nodes + API routes use when no explicit client is
    injected.
    """
    client = LocalSemanticClient()
    if client.available:
        return client
    return NoopSemanticClient()


# ---------------------------------------------------------------------------
# Shape coercion helpers
# ---------------------------------------------------------------------------


def _coerce_concept(raw: object) -> ConceptRef:
    """Accept either a dict or a pycharter ``Concept`` and return a ref."""
    if isinstance(raw, dict):
        return ConceptRef(
            id=str(raw.get("id", "")),
            label=str(raw.get("label") or raw.get("id") or ""),
            definition=raw.get("definition"),
            scheme=raw.get("scheme"),
            concept_type=raw.get("concept_type") or raw.get("type"),
            broader=raw.get("broader"),
        )
    return ConceptRef(
        id=str(getattr(raw, "id", "")),
        label=str(getattr(raw, "label", "") or getattr(raw, "id", "")),
        definition=getattr(raw, "definition", None),
        scheme=getattr(raw, "scheme", None),
        concept_type=getattr(raw, "concept_type", None),
        broader=getattr(raw, "broader", None),
    )


def _coerce_contract(raw: object) -> ContractRef:
    """Accept either a dict or a pycharter ``ContractConfig`` and return a ref."""
    if isinstance(raw, dict):
        bindings_raw = raw.get("bindings", [])
        bindings = tuple(_coerce_binding(item) for item in bindings_raw)
        return ContractRef(
            id=str(raw.get("id", "")),
            version=str(raw.get("version", "0.0.0")),
            title=raw.get("title") or (raw.get("metadata") or {}).get("title"),
            description=raw.get("description")
            or (raw.get("metadata") or {}).get("description"),
            bindings=bindings,
        )
    return ContractRef(
        id=str(getattr(raw, "id", "")),
        version=str(getattr(raw, "version", "0.0.0")),
        title=getattr(raw, "title", None),
        description=getattr(raw, "description", None),
        bindings=(),
    )


def _coerce_binding(raw: object) -> FieldBindingRef:
    if isinstance(raw, dict):
        return FieldBindingRef(
            contract_id=str(raw.get("contract_id", "")),
            field_path=str(raw.get("field_path", "")),
            concept_id=str(raw.get("concept_id", "")),
            state=str(raw.get("state", "unmapped")),  # type: ignore[arg-type]
        )
    return FieldBindingRef(
        contract_id=str(getattr(raw, "contract_id", "")),
        field_path=str(getattr(raw, "field_path", "")),
        concept_id=str(getattr(raw, "concept_id", "")),
        state=getattr(raw, "state", "unmapped"),
    )


__all__ = [
    "LocalSemanticClient",
    "NoopSemanticClient",
    "RemoteSemanticClient",
    "SemanticClient",
    "resolve_default_client",
]
