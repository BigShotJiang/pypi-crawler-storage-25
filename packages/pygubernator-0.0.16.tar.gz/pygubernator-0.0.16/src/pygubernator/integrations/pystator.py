"""Use PyStator's HTTP API from Python (same client as workflow nodes).

Example::

    from pygubernator.integrations.pystator import connect_pystator

    client = connect_pystator()  # uses PYSTATOR_API_BASE / PYSTATOR_API_TOKEN
    result = await client.entity_event(
        "my-entity-id",
        trigger="initiate",
        context={"leg_id": "…"},
        machine_name="aidx_flight_lifecycle",
        machine_version="1.0.0",
    )
"""

from __future__ import annotations

from pygubernator.workflow.integrations.pystator_client import (
    PyStatorApiError,
    PyStatorClient,
    json_safe_values,
)

__all__ = ("PyStatorApiError", "PyStatorClient", "connect_pystator", "json_safe_values")


def connect_pystator(
    *,
    base_url: str | None = None,
    bearer_token: str | None = None,
    timeout: float = 30.0,
) -> PyStatorClient:
    """Return a configured :class:`PyStatorClient`.

    When ``base_url`` or ``bearer_token`` are omitted, uses ``PYSTATOR_API_BASE``
    and ``PYSTATOR_API_TOKEN`` from the environment.
    """
    return PyStatorClient.from_env(
        base_url=base_url, bearer_token=bearer_token, timeout=timeout
    )
