"""Public integration entry points for scripts and applications."""

from pygubernator.integrations.pystator import connect_pystator

__all__ = ("connect_pystator",)
