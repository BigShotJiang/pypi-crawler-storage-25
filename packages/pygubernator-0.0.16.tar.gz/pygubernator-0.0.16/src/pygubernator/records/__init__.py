"""Generic append-only record persistence abstraction.

Provides a ``RecordStore`` protocol and in-memory / SQLAlchemy
backends used by safety audit, memory access audit, and agent
heartbeat subsystems. Chosen over directly coupling those subsystems
to the database so pygubernator can run without a DB configured.
"""

from __future__ import annotations

from pygubernator.records._memory import InMemoryRecordStore
from pygubernator.records._protocol import Record, RecordStore
from pygubernator.records._registry import (
    default_record_store,
    set_default_record_store,
)

__all__ = [
    "InMemoryRecordStore",
    "Record",
    "RecordStore",
    "default_record_store",
    "set_default_record_store",
]
