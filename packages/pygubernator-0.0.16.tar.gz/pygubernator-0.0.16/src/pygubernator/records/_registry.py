"""Process-wide default record store.

Subsystems (audit, heartbeat) write to ``default_record_store()`` unless
given an explicit store. Defaults to an in-memory store; applications
may swap in a SQL-backed store at startup.
"""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

from pygubernator.records._memory import InMemoryRecordStore

if TYPE_CHECKING:
    from pygubernator.records._protocol import RecordStore

_lock = threading.RLock()
_store: RecordStore | None = None


def default_record_store() -> RecordStore:
    """Return the process-wide default record store.

    Lazily initializes an ``InMemoryRecordStore`` on first call.
    """
    global _store
    with _lock:
        if _store is None:
            _store = InMemoryRecordStore()
        return _store


def set_default_record_store(store: RecordStore | None) -> None:
    """Replace the process-wide default record store.

    Args:
        store: New store, or ``None`` to reset to in-memory default
            on next access.
    """
    global _store
    with _lock:
        _store = store
