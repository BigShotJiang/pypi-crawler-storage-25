"""SQLAlchemy-backed RecordStore.

Persists records into the ``generic_records`` table. Separate from
typed audit tables (``tool_call_audit``, ``memory_access_audit``,
``agent_heartbeats``) so callers can choose between a generic
catch-all and strongly-typed models.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from pygubernator.records._protocol import Record

if TYPE_CHECKING:
    from collections.abc import Callable

    from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class SqlAlchemyRecordStore:
    """RecordStore persisting to a generic SQL table.

    Requires the ``generic_records`` model (see
    ``pygubernator.db.models.generic_record``). Callers inject a
    session factory; each operation opens a short-lived session.
    """

    def __init__(self, session_factory: Callable[[], Session]) -> None:
        """Initialize the store.

        Args:
            session_factory: Callable returning a fresh SQLAlchemy session.
        """
        self._session_factory = session_factory

    def put(self, record: Record) -> Record:
        """Persist a record to the generic_records table."""
        from pygubernator.db.models.generic_record import GenericRecord

        stored = replace(
            record,
            record_id=record.record_id or str(uuid.uuid4()),
            created_at=record.created_at or datetime.now(UTC),
        )
        session = self._session_factory()
        try:
            row = GenericRecord(
                id=stored.record_id,
                kind=stored.kind,
                scope=stored.scope,
                payload=stored.payload,
                created_at=stored.created_at,
            )
            session.add(row)
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
        return stored

    def query(
        self,
        kind: str,
        *,
        scope: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[Record]:
        """Query the generic_records table, newest first."""
        from pygubernator.db.models.generic_record import GenericRecord

        session = self._session_factory()
        try:
            q = session.query(GenericRecord).filter(GenericRecord.kind == kind)
            if scope is not None:
                q = q.filter(GenericRecord.scope == scope)
            if since is not None:
                q = q.filter(GenericRecord.created_at >= since)
            q = q.order_by(GenericRecord.created_at.desc()).limit(limit)
            rows = list(q.all())
        finally:
            session.close()

        return [_row_to_record(r) for r in rows]

    def count(self, kind: str, *, scope: str | None = None) -> int:
        """Count records of a kind."""
        from pygubernator.db.models.generic_record import GenericRecord

        session = self._session_factory()
        try:
            q = session.query(GenericRecord).filter(GenericRecord.kind == kind)
            if scope is not None:
                q = q.filter(GenericRecord.scope == scope)
            return q.count()
        finally:
            session.close()


def _row_to_record(row: Any) -> Record:
    """Convert a ``GenericRecord`` row to a ``Record`` value object."""
    return Record(
        kind=row.kind,
        payload=dict(row.payload or {}),
        record_id=row.id,
        created_at=row.created_at,
        scope=row.scope,
    )
