"""In-memory RecordStore for tests and DB-less deployments."""

from __future__ import annotations

import threading
import uuid
from dataclasses import replace
from datetime import UTC, datetime

from pygubernator.records._protocol import Record


class InMemoryRecordStore:
    """Thread-safe in-memory record store.

    Suitable for tests, single-process deployments, and DB-less mode.
    Records are retained in insertion order; ``query`` returns them
    newest-first. Optional per-kind capacity bound prevents unbounded
    growth in long-running processes.
    """

    def __init__(self, max_per_kind: int | None = 10_000) -> None:
        """Initialize the store.

        Args:
            max_per_kind: Cap per record kind. Oldest are evicted when
                exceeded. ``None`` means unbounded.
        """
        self._records: dict[str, list[Record]] = {}
        self._lock = threading.RLock()
        self._max_per_kind = max_per_kind

    def put(self, record: Record) -> Record:
        """Persist a record.

        Args:
            record: Record to persist.

        Returns:
            Stored record with identifier and timestamp populated.
        """
        stored = replace(
            record,
            record_id=record.record_id or str(uuid.uuid4()),
            created_at=record.created_at or datetime.now(UTC),
        )
        with self._lock:
            bucket = self._records.setdefault(stored.kind, [])
            bucket.append(stored)
            if self._max_per_kind and len(bucket) > self._max_per_kind:
                # Evict oldest: keep the most recent ``max_per_kind``.
                del bucket[: len(bucket) - self._max_per_kind]
        return stored

    def query(
        self,
        kind: str,
        *,
        scope: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[Record]:
        """Return records matching filters, newest first."""
        with self._lock:
            bucket = list(self._records.get(kind, []))

        if scope is not None:
            bucket = [r for r in bucket if r.scope == scope]
        if since is not None:
            bucket = [r for r in bucket if r.created_at >= since]

        bucket.sort(key=lambda r: r.created_at, reverse=True)
        return bucket[:limit]

    def count(self, kind: str, *, scope: str | None = None) -> int:
        """Count records of a kind."""
        with self._lock:
            bucket = list(self._records.get(kind, []))
        if scope is None:
            return len(bucket)
        return sum(1 for r in bucket if r.scope == scope)

    def clear(self) -> None:
        """Remove all records. Intended for test cleanup."""
        with self._lock:
            self._records.clear()
