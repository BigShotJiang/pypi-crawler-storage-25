"""Protocol for append-only record storage."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True, slots=True)
class Record:
    """An append-only record entry.

    Args:
        kind: Logical record family (e.g. ``tool_call_audit``).
        payload: Structured record body.
        record_id: Optional identifier; assigned by the store when absent.
        created_at: UTC timestamp when the record was minted.
        scope: Optional grouping key for cheap filtering (e.g. agent_id).
    """

    kind: str
    payload: dict[str, Any] = field(default_factory=dict)
    record_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    scope: str | None = None


@runtime_checkable
class RecordStore(Protocol):
    """Append-only record persistence.

    Implementations must be safe to call from both sync and async
    contexts. The interface is intentionally minimal: ``put`` for
    writes, ``query`` for reads. Retention and compaction are
    implementation concerns.
    """

    def put(self, record: Record) -> Record:
        """Persist a record and return a stored copy with ``record_id`` set.

        Args:
            record: Record to persist.

        Returns:
            Stored record with identifier and timestamp populated.
        """
        ...

    def query(
        self,
        kind: str,
        *,
        scope: str | None = None,
        since: datetime | None = None,
        limit: int = 100,
    ) -> list[Record]:
        """Return records matching filters, newest first.

        Args:
            kind: Record family to query.
            scope: If given, only records with matching scope.
            since: If given, only records with ``created_at >= since``.
            limit: Max records to return.

        Returns:
            List of records ordered newest-first.
        """
        ...

    def count(self, kind: str, *, scope: str | None = None) -> int:
        """Count records of a kind.

        Args:
            kind: Record family to count.
            scope: If given, only records with matching scope.

        Returns:
            Number of matching records.
        """
        ...
