"""Notification delivery channel implementations."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

import httpx

logger = logging.getLogger(__name__)


@runtime_checkable
class NotificationChannel(Protocol):
    """Protocol for notification delivery channels."""

    async def send(
        self,
        subject: str,
        body: str,
        metadata: dict[str, Any],
    ) -> bool:
        """Send a notification.

        Args:
            subject: Notification subject/title.
            body: Notification body text.
            metadata: Additional context for the notification.

        Returns:
            True if the notification was delivered successfully.
        """
        ...


class WebhookChannel:
    """Sends notifications via HTTP POST to a URL.

    Args:
        url: Target webhook URL.
        headers: Optional extra HTTP headers.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 10.0,
    ) -> None:
        self._url = url
        self._headers = headers or {}
        self._timeout = timeout

    async def send(
        self,
        subject: str,
        body: str,
        metadata: dict[str, Any],
    ) -> bool:
        """POST JSON payload to the webhook URL.

        Args:
            subject: Notification subject/title.
            body: Notification body text.
            metadata: Additional context for the notification.

        Returns:
            True if the server responded with a 2xx status.
        """
        payload = {
            "subject": subject,
            "body": body,
            "metadata": metadata,
        }
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self._url,
                    json=payload,
                    headers=self._headers,
                    timeout=self._timeout,
                )
            ok = 200 <= resp.status_code < 300
            if not ok:
                logger.warning(
                    "Webhook %s returned %d",
                    self._url,
                    resp.status_code,
                )
            return ok
        except httpx.HTTPError:
            logger.exception("Webhook POST to %s failed", self._url)
            return False


class SlackChannel:
    """Sends notifications to a Slack incoming webhook.

    Args:
        webhook_url: Slack incoming webhook URL.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        webhook_url: str,
        timeout: float = 10.0,
    ) -> None:
        self._webhook_url = webhook_url
        self._timeout = timeout

    async def send(
        self,
        subject: str,
        body: str,
        metadata: dict[str, Any],
    ) -> bool:
        """POST a Slack message via incoming webhook.

        Args:
            subject: Notification subject (used as bold header).
            body: Notification body text.
            metadata: Additional context (not sent to Slack).

        Returns:
            True if Slack responded with 200.
        """
        text = f"*{subject}*\n{body}"
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self._webhook_url,
                    json={"text": text},
                    timeout=self._timeout,
                )
            ok = resp.status_code == 200
            if not ok:
                logger.warning(
                    "Slack webhook returned %d",
                    resp.status_code,
                )
            return ok
        except httpx.HTTPError:
            logger.exception("Slack webhook POST failed")
            return False


class LogChannel:
    """Logs notifications using the standard logging module.

    Useful as a fallback or debug channel.
    """

    async def send(
        self,
        subject: str,
        body: str,
        metadata: dict[str, Any],
    ) -> bool:
        """Log the notification at INFO level.

        Args:
            subject: Notification subject/title.
            body: Notification body text.
            metadata: Additional context for the notification.

        Returns:
            Always True.
        """
        logger.info(
            "Notification: [%s] %s (metadata=%s)",
            subject,
            body,
            metadata,
        )
        return True
