"""Notification dispatcher with EventHandler integration."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.events._bus import AgentEvent, AgentEventType
from pygubernator.notifications._channels import NotificationChannel

logger = logging.getLogger(__name__)


class NotificationDispatcher:
    """Dispatches notifications to registered channels.

    Can be used as an ``EventHandler`` to auto-notify on
    workflow completion or failure events.

    Example::

        dispatcher = NotificationDispatcher()
        dispatcher.add_channel(WebhookChannel(url="https://..."))
        bus.add_handler(dispatcher)
    """

    def __init__(self) -> None:
        self._channels: list[NotificationChannel] = []

    def add_channel(self, channel: NotificationChannel) -> None:
        """Register a notification channel.

        Args:
            channel: Channel implementing NotificationChannel.
        """
        self._channels.append(channel)

    @property
    def channel_count(self) -> int:
        """Number of registered channels."""
        return len(self._channels)

    async def notify(
        self,
        subject: str,
        body: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Send a notification to all registered channels.

        Exceptions in individual channels are logged but do
        not prevent other channels from receiving the message.

        Args:
            subject: Notification subject/title.
            body: Notification body text.
            metadata: Optional additional context.
        """
        meta = metadata or {}
        for channel in self._channels:
            try:
                await channel.send(subject, body, meta)
            except Exception:
                logger.exception(
                    "Channel %s failed for subject '%s'",
                    type(channel).__name__,
                    subject,
                )

    async def handle(self, event: AgentEvent) -> None:
        """Handle an agent event (EventHandler protocol).

        Only processes ``WORKFLOW_COMPLETED`` events. Formats
        a success or failure notification based on the event
        data.

        Args:
            event: The agent event to handle.
        """
        if event.event_type != AgentEventType.WORKFLOW_COMPLETED:
            return

        name = event.data.get("workflow_name", "unknown")
        error = event.data.get("error")
        if error:
            subject = f"Workflow '{name}' failed"
            body = f"Workflow failed: {error}"
        else:
            subject = f"Workflow '{name}' completed"
            body = "Workflow completed successfully."

        metadata = {
            "agent_id": event.agent_id,
            "run_id": event.run_id,
            "event_type": event.event_type.value,
        }
        await self.notify(subject, body, metadata)
