"""MCP Core — orchestrates multi-agent cognitive processing."""

import os
import json
import time
import uuid
import threading
from pathlib import Path
from typing import Optional, Dict, Any, Iterator, List

from .minimax_client import MiniMaxClient, MiniMaxError
from .agents import CreatorAgent, CriticAgent, AnalystAgent
from .memory import WorkingMemory
from .tools import TOOL_REGISTRY


DEFAULT_CONFIG_PATH = Path("~/.mcp/config.json").expanduser()
DEFAULT_LOG_DIR = Path("~/.mcp/logs").expanduser()
DEFAULT_MEMORY_DIR = Path("~/.mcp/memory").expanduser()
DEFAULT_RESULTS_DIR = Path("~/.mcp/results").expanduser()


# ── Tool invocation parser ───────────────────────────────────────────────────────

import re


def _parse_local_tool(task: str) -> Optional[Dict[str, Any]]:
    """Detect if task is a local tool invocation and return the call spec.

    Matches patterns like:
      run "hermes update"         → terminal(command="hermes update")
      execute terminal "ls -la"  → terminal(command="ls -la")
      read file "/path/to/file"  → read_file(path="/path/to/file")
      search the web for "x"     → web_search(query="x")

    Returns None if no local tool call is detected.
    Returns {"type": "tool_call", "name": "...", "arguments": {...}} on match.
    """
    task_stripped = task.strip()

    # ── Pattern: terminal / shell command ──────────────────────────────────────
    # "run <command>", "execute <command>", "run the command <...>"
    terminal_patterns = [
        r"^(?:run|execute|do)\s+(?:the\s+)?(?:command\s+)?[\"\'](.+?)[\"\']",
        r"^(?:run|execute)\s+(?:the\s+)?terminal\s+[\"\'](.+?)[\"\']",
        r"^(?:run|execute)\s+hermes\s+update",
    ]
    for pattern in terminal_patterns:
        m = re.match(pattern, task_stripped, re.IGNORECASE)
        if m:
            cmd = m.group(1)
            if pattern.endswith("hermes update") if "hermes update" in pattern else False:
                cmd = "hermes update"
            return {"type": "tool_call", "name": "terminal", "arguments": {"command": cmd}}

    # Also handle bare "hermes update" or "hermes update --force"
    if re.match(r"^hermes\s+update", task_stripped, re.IGNORECASE):
        cmd = task_stripped
        return {"type": "tool_call", "name": "terminal", "arguments": {"command": cmd}}

    # ── Pattern: read a file ──────────────────────────────────────────────────
    # "read file /path", "cat /path"
    read_patterns = [
        r"^(?:read|cat|view)\s+(?:the\s+)?file\s+[\"\'](.+?)[\"\']",
        r"^(?:read|cat|view)\s+[\"\'](.+?)[\"\']",
    ]
    for pattern in read_patterns:
        m = re.match(pattern, task_stripped, re.IGNORECASE)
        if m:
            return {"type": "tool_call", "name": "read_file", "arguments": {"path": m.group(1)}}

    # ── Pattern: write a file ─────────────────────────────────────────────────
    # "write to /path: content" or "write file /path"
    write_match = re.match(r"^write\s+(?:to\s+)?(?:file\s+)?[\"\'](.+?)[\"\']\s*[:\n]\s*(.+)$", task_stripped, re.DOTALL | re.IGNORECASE)
    if write_match:
        return {"type": "tool_call", "name": "write_file", "arguments": {"path": write_match.group(1), "content": write_match.group(2)}}

    # ── Pattern: web search ───────────────────────────────────────────────────
    # "search for x", "google x", "look up x"
    search_match = re.match(r"^(?:search|google|look\s+up|find)\s+(?:the\s+)?(?:web\s+)?(?:for\s+)?[\"\'](.+?)[\"\']", task_stripped, re.IGNORECASE)
    if search_match:
        return {"type": "tool_call", "name": "web_search", "arguments": {"query": search_match.group(1)}}

    # ── Pattern: git commands ─────────────────────────────────────────────────
    # "git status", "git log -3"
    git_match = re.match(r"^git\s+(.+)$", task_stripped, re.IGNORECASE)
    if git_match:
        return {"type": "tool_call", "name": "git_run", "arguments": {"command": git_match.group(1)}}

    return None


def _parse_tool_invocation(
    task: str,
    functions: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Detect if task is invoking a function and return the call spec.

    Matches patterns like:
      /llm-wiki           → skill_view(skill_name="llm-wiki")
      read the /llm-wiki  → skill_view(skill_name="llm-wiki")
      use the skill "foo" → skill_view(skill_name="foo")

    Returns None if no function call is detected.
    Returns {"type": "function_call", "name": "...", "arguments": {...}} on match.
    """
    task_stripped = task.strip()

    # Build a map of available function names
    func_map: Dict[str, Dict[str, Any]] = {}
    for f in functions:
        name = f.get("name", "")
        if name:
            func_map[name] = f

    # ── Pattern 1: standalone slash command "/skill-name" ─────────────────────────
    # Match: /llm-wiki, /mcp-brain, /arxiv, etc.
    # Strategy: if the slash target looks like a skill name (lower-kebab-case),
    # look for a function named "skill_view" (or containing "skill" + "view").
    slash_match = re.match(r"^/([\w\-]+)$", task_stripped)
    if slash_match:
        target = slash_match.group(1)  # e.g. "llm-wiki"

        # Priority 1: exact function name match (e.g. function is literally "llm-wiki")
        if target in func_map:
            args = _infer_skill_args(target, func_map[target])
            if args:
                return {"type": "function_call", "name": target, "arguments": args}

        # Priority 2: function whose name contains "skill" + can take skill_name arg
        # This handles skill_view(skill_name="llm-wiki")
        for fname, fdef in func_map.items():
            fname_lower = fname.lower()
            if "skill" in fname_lower and "view" in fname_lower:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

        # Priority 3: function whose name matches the target with -/_ normalized
        target_norm = target.lower().replace("-", "").replace("_", "")
        for fname, fdef in func_map.items():
            fname_norm = fname.lower().replace("-", "").replace("_", "")
            if fname_norm == target_norm:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    # ── Pattern 2: "read/use/check the /name or skill 'name'" ────────────────────
    skill_phrase = re.search(
        r"(?:read|use|check|view|load|invoke|run)\s+(?:the\s+)?(?:skill\s+)?/?([\w\-]+)",
        task_stripped,
        re.IGNORECASE,
    )
    if skill_phrase:
        target = skill_phrase.group(1)
        # Same priority logic
        if target in func_map:
            args = _infer_skill_args(target, func_map[target])
            if args:
                return {"type": "function_call", "name": target, "arguments": args}
        for fname, fdef in func_map.items():
            fname_lower = fname.lower()
            if "skill" in fname_lower and "view" in fname_lower:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    # ── Pattern 3: quoted skill name "foo" or 'foo' ──────────────────────────────
    quoted = re.search(r"[\"\']([\w\-]+)[\"\']", task_stripped)
    if quoted:
        target = quoted.group(1)
        for fname, fdef in func_map.items():
            fname_lower = fname.lower()
            if "skill" in fname_lower and "view" in fname_lower:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    return None


def _infer_skill_args(
    skill_name: str,
    func_def: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """Infer the arguments to pass to a function based on its parameter schema."""
    params = func_def.get("parameters", {})
    props = params.get("properties", {})

    if not props:
        return {}

    # Find the most relevant parameter — prefer names like skill_name, name, path
    priority_params = ["skill_name", "name", "path", "identifier", "resource"]
    for pname in priority_params:
        if pname in props:
            return {pname: skill_name}

    # Fall back to first string parameter
    for pname, pschema in props.items():
        ptype = pschema.get("type", "string")
        if ptype == "string":
            return {pname: skill_name}

    return None


class MCP:
    """Multi-agent Cognitive Processing engine."""

    # Class-level store for background results (session_id -> result dict)
    _results: Dict[str, Optional[Dict[str, Any]]] = {}
    _results_lock = threading.Lock()

    def __init__(self, config_path: Optional[str] = None, skip_api_key_check: bool = False):
        self.config_path = Path(config_path or DEFAULT_CONFIG_PATH)
        self.log_dir = Path(DEFAULT_LOG_DIR)
        self.memory_dir = Path(DEFAULT_MEMORY_DIR)
        self.results_dir = Path(DEFAULT_RESULTS_DIR)

        self.config = self._load_config()
        self.session_id = str(uuid.uuid4())[:8]
        self.llm = None
        self.agents = {}

        # Ensure directories exist
        for d in (self.log_dir, self.memory_dir, self.results_dir):
            d.mkdir(parents=True, exist_ok=True)

        # Initialize LLM
        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not api_key and not skip_api_key_check:
            raise ValueError("No API key configured. Run: mcp setup")

        if api_key:
            self.llm = MiniMaxClient(api_key)
            model = self.config.get("model", "MiniMax-M2.7")
            self.agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }

        self.memory = WorkingMemory(storage_path=str(self.memory_dir))

    def _load_config(self) -> Dict[str, Any]:
        """Load or create default config."""
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)

        # Create default config
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        default = {
            "api_key": "",
            "model": "MiniMax-M2.7",
            "max_tokens": 2000,
            "temperature": 0.7,
        }
        with open(self.config_path, "w") as f:
            json.dump(default, f, indent=2)
        return default

    def is_setup(self) -> bool:
        """Check if API key is configured."""
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "MiniMax-M2.7") -> bool:
        """Configure API key and model, reinitialize components."""
        self.config["api_key"] = api_key
        self.config["model"] = model
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=2)

        # Reinitialize with new key
        self.llm = MiniMaxClient(api_key)
        self.agents = {
            "creator": CreatorAgent(api_key, model=model),
            "critic": CriticAgent(api_key, model=model),
            "analyst": AnalystAgent(api_key, model=model),
        }
        return True

    @classmethod
    def get_result(cls, session_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a completed background result by session ID."""
        with cls._results_lock:
            return cls._results.get(session_id)

    # ── Cognitive pipeline (streaming) ───────────────────────────────────────────

    def process_task_stream(
        self,
        task: str,
        functions: Optional[List[Dict[str, Any]]] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Run the cognitive pipeline with streaming token output.

        Yields step events:
            {"type": "start", "step": 1, "agent": "analyst", "task": "..."}
            {"type": "token", "agent": "analyst", "content": "..."}
            {"type": "step_done", "step": 1, "agent": "analyst", "response": "..."}
            ... (continues for each step)
            {"type": "done", "session_id": "...", "duration_seconds": ...}

        If functions are provided and the task is a tool invocation (e.g. /skill-name),
        yields a single {"type": "function_call", "name": "...", "arguments": {...}}
        and returns early without running the cognitive pipeline.
        """
        if not self.is_setup():
            yield {"type": "error", "message": "MCP not set up. Run: mcp setup"}
            return

        # ── Local tool execution ─────────────────────────────────────────────────
        # If the task looks like a direct tool invocation (e.g. "hermes update",
        # "run 'ls -la'", "git status"), execute it immediately and return the result.
        parsed = _parse_local_tool(task)
        if parsed:
            tool_name = parsed["name"]
            tool_args = parsed["arguments"]
            tool = TOOL_REGISTRY.get(tool_name)
            if tool:
                yield {"type": "tool_start", "name": tool_name, "arguments": tool_args}
                result = TOOL_REGISTRY.execute(tool_name, tool_args)
                yield {"type": "tool_result", "name": tool_name, "result": result}
                yield {"type": "done", "session_id": self.session_id, "duration_seconds": 0.0, "tool_executed": True}
                return

        # ── Tool/Function call detection ─────────────────────────────────────────
        # If functions are provided and the task looks like a tool invocation
        # (e.g. "/llm-wiki", "read the skill /llm-wiki"), emit a function_call
        # event and return early without running the cognitive pipeline.
        if functions:
            parsed = _parse_tool_invocation(task, functions)
            if parsed:
                yield parsed
                return

        start_time = time.time()
        step_num = 0

        yield {
            "type": "start",
            "task": task,
            "session_id": self.session_id,
        }

        # ── Adaptive pipeline ─────────────────────────────────────────────────────
        #
        # The Analyst's response is structured as:
        #
        #   [COMPLEXITY: SIMPLE]
        #   [REASON: brief one-liner]
        #   ---
        #   <detailed analysis>
        #
        # The header appears FIRST so we can read it as tokens stream in
        # and decide whether to continue to steps 2-5 or stop early.
        #
        # Tier routing:
        #   SIMPLE   → respond immediately (1 API call, ~5s)
        #   MODERATE → Analyst + Creator (2 API calls, ~15s)
        #   COMPLEX  → full 5-step pipeline (5 API calls, ~60-180s)

        # ── Step 1: Analyst (always runs, does complexity classification too) ───────
        step_num = 1
        agent_name = "analyst"
        agent = self.agents[agent_name]
        accumulated = ""
        complexity_detected = None

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, ""):
            if event["type"] == "start":
                pass
            elif event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
                # Try to detect complexity as tokens stream in
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        marker = f"[COMPLEXITY: {comp}]"
                        if marker in accumulated:
                            complexity_detected = comp
                            yield {"type": "complexity_detected", "complexity": comp}
                            break
            elif event["type"] == "done":
                analysis_response = event["response"]
                # Fallback: parse from full response if not caught mid-stream
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        if f"[COMPLEXITY: {comp}]" in analysis_response:
                            complexity_detected = comp
                            break
                if complexity_detected is None:
                    complexity_detected = "COMPLEX"  # safe default

                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": analysis_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": analysis_response}

        # ── Tier routing ───────────────────────────────────────────────────────────
        if complexity_detected == "SIMPLE":
            # Analyst's analysis IS the answer — no further steps needed
            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response,
                "solution": analysis_response,
                "evaluation": "SIMPLE task — answered directly by Analyst.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        elif complexity_detected == "MODERATE":
            # MODERATE: Analyst → Creator (skip both Critic rounds)
            # Steps 2
            step_num = 2
            agent_name = "creator"
            agent = self.agents[agent_name]
            accumulated = ""

            yield {"type": "step_start", "step": step_num, "agent": agent_name}
            for event in agent.process_stream(task, self.memory.get_context()):
                if event["type"] == "token":
                    accumulated += event["content"]
                    yield {"type": "token", "agent": agent_name, "content": event["content"]}
                elif event["type"] == "done":
                    creation_response = event["response"]
                    self.memory.add({
                        "agent_id": agent_name,
                        "role": agent.role,
                        "task": task,
                        "response": creation_response,
                        "timestamp": time.time(),
                    })
                    yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response,
                "solution": creation_response,
                "evaluation": "MODERATE task — resolved by Creator without critique rounds.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        # COMPLEX (or unknown): full 5-step pipeline
        # Step 2 — Creator generates a first draft
        step_num = 2
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                creation_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": creation_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

        # Step 3 — Critic evaluates
        step_num = 3
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        for event in agent.process_stream(task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                critique_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": critique_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": critique_response}

        # Step 4 — Creator improves based on critique
        step_num = 4
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        improve_task = f"Improve your previous solution based on this criticism: {critique_response}"
        for event in agent.process_stream(improve_task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                improvement_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": improvement_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": improvement_response}

        # Step 5 — Critic final evaluation
        step_num = 5
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        final_task = f"Provide a final evaluation of this improved solution. Rate it and note any remaining issues: {improvement_response}"
        for event in agent.process_stream(final_task, self.memory.get_context()):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                final_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": final_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": final_response}

        duration = time.time() - start_time

        result = {
            "task": task,
            "session_id": self.session_id,
            "duration_seconds": round(duration, 2),
            "complexity": complexity_detected,
            "analysis": analysis_response,
            "solution": improvement_response,
            "evaluation": final_response,
        }

        with self.__class__._results_lock:
            self.__class__._results[self.session_id] = result

        self._save_session_log(task, result)

        yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}

    def process_task(self, task: str, verbose: bool = True) -> Dict[str, Any]:
        """Run the adaptive cognitive pipeline (blocking, for CLI)."""
        result = None
        complexity = None
        for event in self.process_task_stream(task):
            if event["type"] == "complexity_detected" and verbose:
                print(f"[MCP] Complexity: {event['complexity']} — routing...", flush=True)
            elif event["type"] == "step_done" and verbose:
                role = event["agent"].capitalize()
                preview = event["response"][:80].replace("\n", " ")
                print(f"  [✓] {role}: {preview}...")
            elif event["type"] == "start" and verbose:
                print(f"[MCP] Task: {task}")
            elif event["type"] == "done" and verbose:
                comp = event.get("complexity", "")
                print(f"[MCP] Done in {event['duration_seconds']:.2f}s  complexity={comp}  session={event['session_id']}")

            if event["type"] == "done":
                result = self.get_result(event["session_id"])

        return result or {}

    # ── Background processing ────────────────────────────────────────────────────

    def process_task_background(self, task: str) -> str:
        """Start processing in a background thread. Returns session_id immediately."""
        session_id = self.session_id
        # Store a placeholder so get_result() returns None until done
        with self.__class__._results_lock:
            self.__class__._results[session_id] = None

        def run():
            # Create a fresh MCP instance in this thread (has its own agents/LLM)
            brain = MCP(skip_api_key_check=True)
            brain.session_id = session_id
            brain.config = self.config
            brain.agents = {
                "creator": CreatorAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "critic": CriticAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "analyst": AnalystAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
            }
            brain.memory = WorkingMemory(storage_path=str(brain.memory_dir))
            # Drain the stream to complete the pipeline
            for _ in brain.process_task_stream(task):
                pass

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return session_id

    # ── Legacy helpers ──────────────────────────────────────────────────────────

    def _run_step(self, agent_name: str, task: str, context: str) -> Dict[str, Any]:
        """Run one agent step and store result in memory (blocking)."""
        agent = self.agents[agent_name]
        result = agent.process(task, context)
        self.memory.add(result)
        return result

    def _save_session_log(self, task: str, result: Dict[str, Any]) -> str:
        """Persist session to disk."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        path = self.log_dir / f"session_{ts}_{self.session_id}.json"
        with open(path, "w") as f:
            json.dump({
                "task": task,
                "session_id": self.session_id,
                "timestamp": ts,
                "result": result,
            }, f, indent=2)
        return str(path)
