"""OpenAI-compatible HTTP server for MCP Brain.

Serves POST /v1/chat/completions — proxies requests through the adaptive
cognitive pipeline and streams SSE responses back in OpenAI format.

Usage:
    mcp-brain-http                    # default 0.0.0.0:8080
    mcp-brain-http --port 9000       # custom port
    mcp-brain-http --help            # see all options
"""

import os
import sys
import json
import time
import uuid
import asyncio
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional

import fastapi
from fastapi import Request, Response
from fastapi.responses import StreamingResponse
import uvicorn

# Add src to path for editable installs
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from mcpbrain.mcp_core import MCP
from mcpbrain.tools import TOOL_REGISTRY


APP = fastapi.FastAPI(
    title="MCP Brain",
    description="OpenAI-compatible API for the adaptive multi-agent cognitive pipeline",
    version="0.5.0",
)


def _build_token_chunk(delta_content: str, index: int = 0) -> dict:
    """Build an OpenAI-compatible chunk for SSE streaming."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion.chunk",
        "created": int(time.time()),
        "model": "mcp-brain",
        "choices": [{
            "index": index,
            "delta": {"content": delta_content},
            "finish_reason": None,
        }],
    }


def _build_done_chunk(usage: dict, index: int = 0) -> dict:
    """Build the final [DONE] chunk with usage stats."""
    return {
        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
        "object": "chat.completion",
        "created": int(time.time()),
        "model": "mcp-brain",
        "choices": [{
            "index": index,
            "message": {"role": "assistant", "content": ""},
            "finish_reason": "stop",
        }],
        "usage": usage,
    }


async def _stream_pipeline(mcp: MCP, task: str, model: Optional[str], functions: Optional[List[dict]]):
    """Drain the cognitive pipeline and yield OpenAI-compatible SSE tokens.

    The pipeline yields step events (start, token, step_done, done).
    We only forward `token` content as SSE deltas.
    If the pipeline emits a function_call event, format it as a function_call chunk.
    If the pipeline emits a tool_start/tool_result event, format as a content chunk.
    All other events are consumed but not sent to the client.
    """
    step_content = {}
    all_tokens = []  # full text for non-stream fallback

    async for event in _async_pipeline(mcp, task, functions):
        etype = event.get("type")

        if etype == "function_call":
            # Emit a function_call delta chunk, then done
            chunk = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model or "mcp-brain",
                "choices": [{
                    "index": 0,
                    "delta": {
                        "content": None,
                        "function_call": {
                            "name": event["name"],
                            "arguments": json.dumps(event["arguments"]),
                        },
                    },
                    "finish_reason": "function_call",
                }],
            }
            yield f"data: {json.dumps(chunk)}\n\n"
            yield "data: [DONE]\n\n"
            return

        elif etype == "tool_start":
            # Announce tool execution
            tool_name = event.get("name", "")
            args_str = json.dumps(event.get("arguments", {}))
            chunk = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model or "mcp-brain",
                "choices": [{
                    "index": 0,
                    "delta": {"content": f"[executing: {tool_name}({args_str})]"},
                    "finish_reason": None,
                }],
            }
            yield f"data: {json.dumps(chunk)}\n\n"

        elif etype == "tool_result":
            # Format tool result as content
            result = event.get("result", {})
            tool_name = event.get("name", "")
            if result.get("success"):
                if "stdout" in result:
                    output = result["stdout"] or "(no output)"
                elif "content" in result:
                    output = result["content"]
                else:
                    output = json.dumps(result)
            else:
                output = f"[error] {result.get('error', result.get('stderr', 'unknown error'))}"

            # Truncate very long output
            if len(output) > 5000:
                output = output[:5000] + f"\n... [truncated {len(output)-5000} chars]"

            chunk = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model or "mcp-brain",
                "choices": [{
                    "index": 0,
                    "delta": {"content": f"\n{output}\n"},
                    "finish_reason": None,
                }],
            }
            yield f"data: {json.dumps(chunk)}\n\n"
            all_tokens.append(f"\n{output}\n")

        elif etype == "token":
            content = event.get("content", "")
            all_tokens.append(content)
            chunk = _build_token_chunk(content)
            yield f"data: {json.dumps(chunk)}\n\n"

        elif etype == "done":
            usage = {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1}
            chunk = {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model or "mcp-brain",
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": "".join(all_tokens)},
                    "finish_reason": "stop",
                }],
                "usage": usage,
            }
            yield f"data: {json.dumps(chunk)}\n\n"
            yield "data: [DONE]\n\n"


async def _async_pipeline(mcp: MCP, task: str, functions: Optional[List[dict]]):
    """Run process_task_stream in a thread pool to avoid blocking the async loop."""
    loop = asyncio.get_event_loop()

    def sync_gen():
        yield from mcp.process_task_stream(task, functions=functions)

    for event in await loop.run_in_executor(None, sync_gen):
        yield event


def _extract_user_message(messages: List[dict]) -> str:
    """Pull the last user message from the OpenAI messages array."""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            return msg.get("content", "")
    return ""


def _build_system_message(messages: List[dict]) -> Optional[str]:
    """Extract the last system message, if any."""
    for msg in messages:
        if msg.get("role") == "system":
            return msg.get("content")
    return None


@APP.post("/v1/chat/completions")
async def chat_completions(request: Request):
    """OpenAI-compatible /v1/chat/completions endpoint.

    Supports:
        - streaming (stream: true) → SSE tokens
        - non-streaming (stream: false) → full JSON response
        - message history (messages array)
    """
    body = await request.json()
    messages = body.get("messages", [])
    stream = body.get("stream", False)
    model = body.get("model", "mcp-brain")
    # Support both OpenAI "functions" and "tools" (they're the same thing)
    functions = body.get("functions") or body.get("tools")

    # Extract the task (last user message)
    task = _extract_user_message(messages)
    if not task:
        return {"error": {"message": "No user message found", "type": "invalid_request_error"}}

    # Build MCP instance (loads config from ~/.mcp/config.json)
    try:
        mcp = MCP(skip_api_key_check=True)
        if not mcp.is_setup():
            return {"error": {"message": "MCP Brain not configured. Run: mcp setup", "type": "auth_error"}}
    except Exception as e:
        return {"error": {"message": f"MCP init failed: {e}", "type": "server_error"}}

    if stream:
        return StreamingResponse(
            _stream_pipeline(mcp, task, model, functions),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",  # disable nginx buffering
            },
        )
    else:
        # Non-streaming: collect all events
        function_call = None
        all_content = []
        done_result = None
        tool_executed = False
        async for event in _async_pipeline(mcp, task, functions):
            if event["type"] == "function_call":
                function_call = event
            elif event["type"] == "token":
                all_content.append(event.get("content", ""))
            elif event["type"] == "tool_result":
                # Append tool result to content
                result = event.get("result", {})
                if result.get("success"):
                    if "stdout" in result:
                        output = result["stdout"] or "(no output)"
                    elif "content" in result:
                        output = result["content"]
                    else:
                        output = json.dumps(result)
                else:
                    output = f"[error] {result.get('error', result.get('stderr', 'unknown error'))}"
                all_content.append(f"\n{output}\n")
                tool_executed = True
            elif event["type"] == "done":
                done_result = event

        if function_call:
            # Return as a function_call response
            return {
                "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "function_call": {
                            "name": function_call["name"],
                            "arguments": json.dumps(function_call["arguments"]),
                        },
                    },
                    "finish_reason": "function_call",
                }],
                "usage": {"prompt_tokens": -1, "completion_tokens": -1, "total_tokens": -1},
            }

        full_content = "".join(all_content)
        duration = done_result.get("duration_seconds", 0) if done_result else 0

        return {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": full_content},
                "finish_reason": "stop",
            }],
            "usage": {
                "prompt_tokens": -1,
                "completion_tokens": -1,
                "total_tokens": -1,
            },
        }


@APP.get("/v1/models")
async def list_models():
    """OpenAI-compatible models endpoint. MCP Brain is a single model."""
    return {
        "object": "list",
        "data": [{
            "id": "mcp-brain",
            "object": "model",
            "created": 1700000000,
            "owned_by": "mcp-brain",
            "permission": [],
        }],
    }


@APP.get("/health")
async def health():
    """Health check."""
    return {"status": "ok"}


@APP.get("/v1/tools")
async def list_tools():
    """Return the registry of locally-executable tools (OpenAI function schema format)."""
    return {
        "object": "list",
        "data": TOOL_REGISTRY.list(),
    }


def main():
    parser = argparse.ArgumentParser(description="MCP Brain HTTP Server (OpenAI-compatible)")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind (default: 8080)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (dev mode)")
    args = parser.parse_args()

    print(f"[MCP Brain HTTP] Starting server on {args.host}:{args.port}")
    print(f"[MCP Brain HTTP] Endpoint: POST http://{args.host}:{args.port}/v1/chat/completions")
    print(f"[MCP Brain HTTP] Models:  GET http://{args.host}:{args.port}/v1/models")

    uvicorn.run(
        "mcpbrain.http_server:APP",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info",
    )


if __name__ == "__main__":
    main()
