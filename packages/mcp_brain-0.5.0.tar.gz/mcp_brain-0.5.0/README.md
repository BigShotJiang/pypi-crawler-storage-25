# MCP-Brain: Multi-agent Cognitive Processing Framework

A lightweight AI framework that runs **locally** on your machine using **MiniMax API**. Three specialized agents — Analyst, Creator, and Critic — collaborate through a structured cognitive pipeline to solve complex problems.

```
User Task
   │
   ▼
┌──────────┐   Analyst breaks it down
│ Analyst ├─────────────────────────┐
└──────────┘                       │
   │                                │
   ▼                                │
┌──────────┐   Creator drafts   ┌──────────┐
│ Creator  │◄──────────────────┤ Analyst  │
└──────────┘                    │ Context  │
   │                            └──────────┘
   │                                │
   ▼                                │
┌──────────┐   Critic evaluates  ┌──────────┐
│ Critic   │◄────────────────────┤ Creator  │
└──────────┘                     │ Draft    │
   │                            └──────────┘
   │                                │
   ▼                                │
┌──────────┐   Creator improves   ┌──────────┐
│ Creator  │◄────────────────────┤ Critic   │
└──────────┘                     │ Feedback │
   │                            └──────────┘
   │
   ▼
┌──────────┐   Critic final     ┌──────────┐
│ Critic   │◄──────eval─────────│ Improved │
└──────────┘                    │ Solution │
   │                            └──────────┘
   ▼
Final Solution + Evaluation
```

## Features

- **Local-only** — API key and data never leave your machine
- **Multi-agent cognition** — mimics human collaborative problem-solving
- **Persistent memory** — sessions saved to `~/.mcp/` for review
- **Simple CLI** — `mcp setup`, `mcp process`, `mcp sessions`
- **Streaming support** — stream responses token-by-token

## Installation

```bash
# Download and run installer
curl -fsSL https://raw.githubusercontent.com/MC80s/mcp/main/install.sh | bash
```
# Or manually install from source
git clone https://github.com/MC80s/mcp.git
cd mcp
bash install.sh

# Or install with pip
pip install mcp-brain
```

## Quick Start

```bash
# 1. Configure your MiniMax API key
mcp setup

# 2. Process your first task
mcp process "Design a logo for a tech startup called Quantum Leap"

# 3. View previous sessions
mcp sessions

# 4. Check config status
mcp status
```

## How It Works

| Step | Agent | Role |
|------|-------|------|
| 1 | Analyst | Breaks down the problem into components |
| 2 | Creator | Generates an initial creative solution |
| 3 | Critic | Evaluates the draft, identifies flaws |
| 4 | Creator | Improves the solution based on critique |
| 5 | Critic | Final evaluation and rating |

## Cost Estimation

MiniMax API is pay-per-use. Each task runs 5 agent calls.

| Complexity | Est. Cost |
|------------|-----------|
| Simple task | ~$0.02–0.05 |
| Medium task | ~$0.05–0.15 |
| Complex task | ~$0.15–0.30 |

No subscription fees. You control your usage.

## Project Structure

```
mcp-brain/
├── src/mcp/
│   ├── minimax_client.py   # MiniMax API client
│   ├── agents.py            # Creator/Critic/Analyst agents
│   ├── memory.py            # Working memory
│   ├── mcp_core.py          # Orchestration engine
│   └── cli.py               # CLI commands
├── scripts/
├── tests/
├── setup.py
├── pyproject.toml
├── install.sh
└── README.md
```

## CLI Commands

```
mcp setup              Interactively configure API key
mcp process "task"    Run a task through the cognitive pipeline
mcp sessions          List recent sessions
mcp session <id>      View full session details
mcp status            Check configuration
```

## Hermes Integration

`mcp-brain` integrates with Hermes in two ways:

### Option A — MCP Tool Server (existing)

Connect `mcp-brain` as a native MCP tool server inside Hermes. Hermes can delegate complex reasoning tasks to the multi-agent pipeline by calling the `process_task` tool.

**Step 1:** Add to `~/.hermes/config.yaml`:

```yaml
mcp_servers:
  mcp-brain:
    command: "/home/YOUR_USERNAME/.local/bin/mcp-brain-server"
```

Find your username with `whoami` and substitute the path accordingly.

**Step 2:** Restart the Hermes gateway:
```bash
systemctl --user restart hermes-gateway
```

**Step 3:** Verify:
```bash
hermes status
```
You should see `mcp_mcp_brain_process_task` listed as an available tool.

**Usage:** Ask Hermes to use mcp-brain for complex tasks — it calls the pipeline as a tool.

### Option B — Full LLM Provider (HTTP, recommended)

Route **all** LLM conversations through the cognitive pipeline. Every message goes through the adaptive multi-agent architecture automatically.

**Step 1:** Start the HTTP server:

```bash
# Auto-start on boot (systemd user service)
systemctl --user enable mcp-brain-http
systemctl --user start mcp-brain-http

# Or run manually
mcp-brain-http --port 8080
```

**Step 2:** Add to `~/.hermes/config.yaml` under `custom_providers`:

```yaml
custom_providers:
  - name: "mcp-brain"
    base_url: "http://127.0.0.1:8080/v1"
    api_key: "local"   # any value — the server ignores it
    provider: "openai"  # OpenAI-compatible endpoint
```

**Step 3:** Restart Hermes:
```bash
systemctl --user restart hermes-gateway
```

**How it works:** The HTTP server exposes `POST /v1/chat/completions` in OpenAI format. Hermes routes all conversations through it. The adaptive pipeline classifies each task as SIMPLE (1 step), MODERATE (2 steps), or COMPLEX (5 steps) and routes accordingly — so simple questions are answered fast while complex problems get full multi-agent reasoning.

**Why Option B:** With Option A, you manually invoke mcp-brain tools. With Option B, every conversation automatically benefits from the cognitive pipeline — no explicit invocation needed.

## Privacy

- All API calls go directly from your machine to MiniMax
- No intermediary servers
- Session logs stored locally in `~/.mcp/logs/`
- Your API key stored in `~/.mcp/config.json` (keep this file private)
