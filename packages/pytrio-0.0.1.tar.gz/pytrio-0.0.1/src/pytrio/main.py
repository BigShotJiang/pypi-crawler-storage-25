def hello():
    print("Hello, World! This is pytrio.")

if __name__ == "__main__":
    hello()
