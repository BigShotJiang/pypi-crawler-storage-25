# pytrio

A simple hello world package.

## Installation

```bash
pip install pytrio
```

## Usage

```python
from pytrio import hello
hello()
```

Or from the command line:

```bash
pytrio
```
