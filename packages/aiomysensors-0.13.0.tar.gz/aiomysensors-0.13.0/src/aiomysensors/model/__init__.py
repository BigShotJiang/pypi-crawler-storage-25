"""Provide the aiomysensors model."""
