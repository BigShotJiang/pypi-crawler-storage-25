from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="rubplus",
    version="1.2.0",
    author="RubPlus Team",
    author_email="support@rubplus.com",
    description="Official Rubika Bot API wrapper - Simple, Modern, Powerful",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rubplus/rubplus",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=["httpx>=0.27.0"],
    license="MIT",
    keywords=["rubika", "bot", "api", "messenger", "rubplus"],
)