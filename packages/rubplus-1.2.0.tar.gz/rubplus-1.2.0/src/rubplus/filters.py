"""
Filters for RubPlus
===================

فیلترهای پیشرفته برای هندلرهای ربات
"""

from typing import Callable, Dict, Any
import re


class Filter:
    """کلاس پایه فیلترها - قابلیت ترکیب با & و | رو داره"""
    
    def __init__(self, func: Callable[[Dict], bool]):
        self.func = func
    
    def __call__(self, message: Dict) -> bool:
        return self.func(message)
    
    def __and__(self, other: 'Filter') -> 'Filter':
        """ترکیب AND - هر دو شرط باید درست باشن"""
        return Filter(lambda m: self(m) and other(m))
    
    def __or__(self, other: 'Filter') -> 'Filter':
        """ترکیب OR - یکی از شرط‌ها باید درست باشه"""
        return Filter(lambda m: self(m) or other(m))
    
    def __invert__(self) -> 'Filter':
        """NOT - شرط برعکس"""
        return Filter(lambda m: not self(m))


# ============================================================
# فیلترهای پایه
# ============================================================

def private() -> Filter:
    """فقط پیام‌های خصوصی (پیوی)"""
    return Filter(lambda m: m.get("chat_id", "").startswith("b0"))


def group() -> Filter:
    """فقط پیام‌های گروهی"""
    return Filter(lambda m: m.get("chat_id", "").startswith("g0"))


def text() -> Filter:
    """فقط پیام‌های متنی"""
    return Filter(lambda m: m.get("text") is not None)


def media() -> Filter:
    """فقط پیام‌های دارای رسانه"""
    return Filter(lambda m: m.get("file") is not None)


def command(cmd: str) -> Filter:
    """فقط دستورات خاص (مثل start, help)"""
    return Filter(lambda m: m.get("text", "").startswith(f"/{cmd}"))


def regex(pattern: str) -> Filter:
    """فقط پیام‌های مطابق با الگوی منظم (RegEx)"""
    compiled = re.compile(pattern)
    return Filter(lambda m: bool(compiled.search(m.get("text", ""))))


def contains(word: str) -> Filter:
    """فقط پیام‌های حاوی کلمه خاص"""
    return Filter(lambda m: word in m.get("text", ""))


def starts_with(prefix: str) -> Filter:
    """فقط پیام‌هایی که با پیشوند خاص شروع می‌شوند"""
    return Filter(lambda m: m.get("text", "").startswith(prefix))


def sender_id(user_id: str) -> Filter:
    """فقط پیام‌های یک کاربر خاص"""
    return Filter(lambda m: m.get("sender_id") == user_id)


def any_message() -> Filter:
    """همه پیام‌ها"""
    return Filter(lambda m: True)


# ============================================================
# فیلترهای ترکیبی آماده
# ============================================================

private_text = private() & text()
private_command = private() & command
group_text = group() & text()
start_command = private() & command("start")