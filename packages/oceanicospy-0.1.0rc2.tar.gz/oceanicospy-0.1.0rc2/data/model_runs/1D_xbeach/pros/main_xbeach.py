from oceanicospy.models import xbeachpy

from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ── path to the case root ─────────────────────────────────────────────────────
# Script lives at <case_root>/pros/main_xbeach.py  →  case root is one level up
path_case = '../'

# ── case-level flags written into params.txt ──────────────────────────────────
ini_case_data = dict(
    case_description='1D profile – Caribbean coast',
    act_morf=0,
    act_sedtrans=0,
    act_wavemodel=1,
    dims=1
)

# ── simulation period ─────────────────────────────────────────────────────────
ini_date = datetime(2008, 11, 20, 11)
end_date = datetime(2008, 11, 24, 21)

# =============================================================================
# Initialization
# =============================================================================

case = xbeachpy.Initializer(
    root_path=path_case,
    dict_ini_data=ini_case_data,
    ini_date=ini_date,
    end_date=end_date
)
case.create_folders()
case.replace_ini_data()

# =============================================================================
# Generating the grid
# =============================================================================

grid_params_case = dict(thetamin=-20, thetamax=160, dtheta=180, alfa=161)

case_grid = xbeachpy.preprocess.GridMaker(init=case, grid_params=grid_params_case)
profile_axis = case_grid.build_profile.from_coordinates(
    start=(4054866.827, 2962460.496),
    end=(4051803.311, 2963542.255),
    dx=5.0,
    auto_extend=True,
)
case_grid.fill_grid_section()

# =============================================================================
# Setting up the bathymetry
# =============================================================================

case_bathy = xbeachpy.preprocess.BathyMaker(init=case)
case_bathy.build_z_from_bathy(
    xyz_filepath='topobat_sai_mergedALM_lidar&10m_bothAC_MAGNA-ON.xyz',
    geometry_object=profile_axis
)
case_bathy.fill_bathy_section()

# =============================================================================
# Configuring wind forcing (ERA5)
# =============================================================================

wind_dict = dict(
    lon_ll_corner_wind=-82,
    lat_ll_corner_wind=12.567536,
    nx_wind=1,
    ny_wind=1,
    dx_wind=0.025,
    dy_wind=0.025
)

case_winds = xbeachpy.preprocess.WindForcing(
    init=case,
    wind_info=wind_dict,
    use_link=False
)
case_winds.get_winds_from_ERA5(utc_offset_hours=-5, format_localtime=True)
case_winds.write_ERA5_ascii(
    era5_filename='winds_era5_localtime.nc',
    ascii_filename='winds.wnd',
    lon_target=278.326063 - 360,
    lat_target=12.567536
)
case_winds.fill_wind_section()

# =============================================================================
# Setting up the water level forcing
# =============================================================================

case_wl = xbeachpy.preprocess.WaterLevelForcing(init=case, use_link=False)
df_wl = case_wl.get_waterlevel_from_UHSLC(station_id=737)

# Correct the known -2 m datum shift for station 737 (1997-2018)
correction_mask = (
    (df_wl.index >= datetime(1997, 1, 1, 0)) &
    (df_wl.index <= datetime(2018, 12, 31, 18))
)
df_wl.loc[correction_mask, 'depth[m]'] -= 2.0

case_wl.write_UHSLC_ascii(df_wl, 'water_levels.wl')
case_wl.fill_wl_section()

# =============================================================================
# Defining the wave boundary conditions
# =============================================================================

case_bounds = xbeachpy.preprocess.BoundaryConditions(init=case)
case_bounds.spectra_from_swan(
    input_filename='SpecSWAN.out',
    location_points=[(0, 0)],
    point_indexes=[18]
)
case_bounds.fill_boundaries_section()

# =============================================================================
# Output and compilation configuration
# =============================================================================

comp_data_nonstat = dict(
    tint_value=3600,    # output interval [s]
    tintg_value=3600,   # global output interval [s]
    tstart_value=3600.  # start time for outputs [s]
)

case_output = xbeachpy.execution.CaseRunner(
    init=case,
    dict_comp_data=comp_data_nonstat
)

case_output.write_output_file(filename='E1_profile1D_Nov2008.nc')
case_output.select_global_vars(list_vars=['zs', 'hh', 'zb0', 'H', 'u', 'urms'])
case_output.write_output_points(filename='points_output.txt')
case_output.select_point_vars(list_vars=['zs', 'H', 'urms', 'Sxx'])
case_output.fill_computation_section()
