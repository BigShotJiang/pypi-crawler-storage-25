from oceanicospy.models import xbeachpy

from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ── path to the case root ─────────────────────────────────────────────────────
# Script lives at <case_root>/pros/main_xbeach.py  →  case root is one level up
path_case = '../'

# ── case-level flags written into params.txt ──────────────────────────────────
ini_case_data = dict(
    case_description='2D Sound Bay - San Andres',
    act_morf=0,
    act_sedtrans=0,
    act_wavemodel=1,
    dims=2
)

# ── simulation period ─────────────────────────────────────────────────────────
ini_date = datetime(2025, 5, 9, 4)
end_date = datetime(2025, 5, 10, 4)

# =============================================================================
# Initialization
# =============================================================================

case = xbeachpy.Initializer(
    root_path=path_case,
    dict_ini_data=ini_case_data,
    ini_date=ini_date,
    end_date=end_date
)
case.create_folders()
case.replace_ini_data()

# =============================================================================
# Generating the grid
# =============================================================================

case_grid = xbeachpy.preprocess.GridMaker(init=case, coordinates_type='relative')
grid_object = case_grid.build_rectangular_grid.from_shapefile(
    source_file='XBeach_domain.shp',
    dx=10,
    dy=10
)
case_grid.fill_grid_section()

# =============================================================================
# Setting up the bathymetry
# =============================================================================

# case_bathy = xbeachpy.preprocess.BathyMaker(init=case, output_filename='bathymetry')
# case_bathy.convert_xyz2asc(xyz_filename='TopoBathy_XBeach_domain_Lidar&10m&50m')
# case_bathy.fill_bathy_section()

# =============================================================================
# Configuring wind forcing (ERA5)
# =============================================================================

wind_dict = dict(
    lon_ll_corner_wind=278,
    lat_ll_corner_wind=12.3,
    nx_wind=24,
    ny_wind=24,
    dx_wind=0.025,
    dy_wind=0.025
)

case_winds = xbeachpy.preprocess.WindForcing(
    init=case,
    wind_info=wind_dict,
    use_link=False
)
case_winds.get_winds_from_ERA5(utc_offset_hours=-5, format_localtime=True)
case_winds.write_ERA5_ascii(
    era5_filename='winds_era5_localtime.nc',
    ascii_filename='winds.wnd',
    lon_target=-81.706,
    lat_target=12.5204
)
case_winds.fill_wind_section()

# =============================================================================
# Setting up the water level forcing
# =============================================================================

case_wl = xbeachpy.preprocess.WaterLevelForcing(init=case, use_link=False)
df_wl = case_wl.get_waterlevel_from_UHSLC(station_id=737)

# Correct a known -2 m datum shift affecting station 737 between 1997 and 2018
correction_mask = (
    (df_wl.index >= datetime(1997, 1, 1, 0)) &
    (df_wl.index <= datetime(2018, 12, 31, 18))
)
df_wl.loc[correction_mask, 'depth[m]'] -= 2.0

case_wl.write_UHSLC_ascii(df_wl, 'water_levels.wl')
case_wl.fill_wl_section()

# =============================================================================
# Defining the wave boundary conditions
# =============================================================================

case_bounds = xbeachpy.preprocess.BoundaryConditions(init=case)
case_bounds.spectra_from_swan(input_filename='SpecSWAN.out', point_indexes=range(3, 15))
case_bounds.fill_boundaries_section()

# =============================================================================
# Output and compilation configuration
# =============================================================================

comp_data_nonstat = dict(
    tint_value=3600,   # output interval [s]
    tintg_value=3600,  # global output interval [s]
)

case_output = xbeachpy.execution.CaseRunner(
    init=case,
    dict_comp_data=comp_data_nonstat
)

case_output.write_output_file(filename='SoundBay2D.nc')
case_output.select_global_vars(list_vars=['zs', 'hh', 'zb0', 'H', 'u', 'v'])
case_output.write_output_points(filename='points_output.txt')
case_output.select_point_vars(list_vars=['zs', 'hh', 'zb0', 'H', 'u', 'v'])
case_output.fill_computation_section()