from oceanicospy.models.swanpy import Initializer
from oceanicospy.models.swanpy.preprocess import GridMaker, BathyMaker, WindForcing, \
                                                 BottomFrictionProcessor, BoundaryConditions
from oceanicospy.models.swanpy.execution import CaseRunner

# --- Case configuration ---
path_case = '../../stationary_swan/'

dict_ini_data = dict(
    name            = 'Stationary case',
    case_number     = 1,
    case_description= 'Example',
    stat_id         = 1,
    number_domains  = 1
)

DOMAIN_ID = 1

# --- Initialization ---
case = Initializer(
    root_path    = path_case,
    dict_ini_data= dict_ini_data,
)

case.create_folders()
case.replace_ini_data()

# --- Grid ---

case_grid = GridMaker(
    init         = case,
    domain_number= DOMAIN_ID,
    grid_info    = {'lon_ll_corner': 278.2265167,
                    'lat_ll_corner': 12.4413166,
                    'x_extent': 0.13185,
                    'y_extent': 0.1908,
                    'nx': 293,
                    'ny': 424},
)

# Option – derive grid parameters from the bathymetry file
# dict_grid = case_grid.params_from_bathy()

print(f'The grid info dictionary for domain {DOMAIN_ID} is: {case_grid.grid_info}')
case_grid.fill_grid_section()

# --- Bathymetry ---
case_bathy = BathyMaker(
    init         = case,
    domain_number= DOMAIN_ID,
    bathy_info   = {'lon_ll_corner_bot': 278.2265167, 'lat_ll_corner_bot': 12.4413166,
                    'nx_bot': 293, 'ny_bot': 424,
                    'dx_bot': 0.00045, 'dy_bot': 0.00045},
)

case_bathy.use_ascii_file_from_user()

print(f'The bathymetry info dictionary for domain {DOMAIN_ID} is: {case_bathy.bathy_info}')
case_bathy.fill_bathy_section()

# --- Bottom friction ---
case_bottom_friction = BottomFrictionProcessor(
    init             = case,
    domain_number    = DOMAIN_ID,
    bottom_fric_info = {'lon_ll_corner_fric': 278.2265167, 'lat_ll_corner_fric': 12.4413166,
                        'nx_fric': 293, 'ny_fric': 424,
                        'dx_fric': 0.00045, 'dy_fric': 0.00045}
)

case_bottom_friction.use_ascii_file_from_user()
print(f'The bottom friction info dictionary for domain {DOMAIN_ID} is: {case_bottom_friction.bottom_fric_info}')
case_bottom_friction.fill_friction_section()

# --- Wind forcing (constant) ---
case_winds = WindForcing(
    init         = case,
    domain_number= DOMAIN_ID,
)

case_winds.use_constant_wind(wind_speed=6.02, wind_dir=90)

print(f'The wind info dictionary for domain {DOMAIN_ID} is: {case_winds.dict_info}')
case_winds.fill_wind_section()

# --- Boundary conditions ---
case_boundary = BoundaryConditions(
    init         = case,
    domain_number= DOMAIN_ID,
    bound_info   = {"bound_type": "side", "variable_bound": False}
)

case_boundary.create_boundary_line(list_sides=["E"], wave_params={'hs': 1.7, 'tp': 9, 'dir': 90, 'spr': 2})
case_boundary.fill_boundaries_section()

# --- Computation and run configuration ---
comp_data_stat = dict(
    stat_comp = 1,  # 1 → stationary
)

case_run = CaseRunner(
    init          = case,
    domain_number = DOMAIN_ID,
    dict_comp_data= comp_data_stat
)

case_run.define_output_from_file(filename='output_points.csv')
case_run.fill_computation_section()