import sys
from importlib.machinery import SourceFileLoader, FileFinder
import ast
import typing
from pathlib import Path
from .source_transformer import Transformer

# FileFinder is a PathEntryFinder
# FileFinder.path_hook returns function for usage in sys.path_hooks

# SourceFileLoader is one of the loaders for FileFinder


class SourceFileLoaderHacked(SourceFileLoader):
    def source_to_code(self, data: bytes, path: str, *, _optimize: int = -1):
        tree = ast.parse(data)
        tree = Transformer().visit(tree)
        tree = ast.fix_missing_locations(tree)
        return super().source_to_code(tree, path)


def _should_hack_import(path: str) -> bool:
    """
    Whether we should use our hacked import machinery to transform the source
    code. Should only do this for files contained within the same root directory
    as the entrypoint script, excluding virtual environements.
    """
    main = sys.modules["__main__"]
    main_path = Path(main.__file__)
    main_root = main_path.parent
    if not Path(path).is_relative_to(main_root):
        return False
    if "site-packages" in Path(path).parts:
        return False
    return True


def _prepare_path_hook_hacked(previous_path_hook: typing.Callable):
    def path_hook_hacked(path: str):
        if not _should_hack_import(path):
            return previous_path_hook(path)

        # "path" is one of the elements of "sys.path". Usually the directory in
        # which the Python interpreter was started.
        ff: FileFinder = previous_path_hook(path)
        py_loader_factory = [loader for (ext, loader) in ff._loaders if ext == ".py"][0]
        ff._loaders.remove((".py", py_loader_factory))
        ff._loaders.append((".py", SourceFileLoaderHacked))
        return ff

    return path_hook_hacked


def hook_into_import_machinery():
    path_hook = [hook for hook in sys.path_hooks if "FileFinder" in hook.__name__][0]
    sys.path_hooks.remove(path_hook)
    sys.path_hooks.append(_prepare_path_hook_hacked(path_hook))
    sys.path_importer_cache = {}
