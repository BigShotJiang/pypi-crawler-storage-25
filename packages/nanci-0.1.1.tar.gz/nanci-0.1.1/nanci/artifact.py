from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar
from tempfile import TemporaryDirectory

class AsArtifact:
    """
    This is just a sentinel class/value to pass to Context.download to download
    an artifact.
    """

    def __str__(self) -> str:
        return "<AsArtifact>"


@dataclass
class Artifact:
    """
    A temporary directory with just one file/directory in it.
    """

    next_artifact_id: ClassVar[int] = 1

    temporay_dir: TemporaryDirectory
    id: int = -1

    @property
    def path_to_temporary_dir(self) -> Path:
        return Path(self.temporay_dir.name)
    
    @property
    def path_to_content(self) -> Path:
        return next(self.path_to_temporary_dir.iterdir())

    def __post_init__(self):
        self.id = Artifact.next_artifact_id
        Artifact.next_artifact_id += 1

    def __str__(self) -> str:
        return f"<Artifact #{self.id}>"
