import glob
import hashlib
from pathlib import Path
import pickle
from typing import TypeAlias
from .config import get_project_root
from threading import Lock
from collections.abc import Collection

FILES_HASH: TypeAlias = str


def calc_files_hash(paths: Collection[Path]) -> FILES_HASH:
    hasher = hashlib.blake2b()
    for path in paths:
        if path.is_file():
            hasher.update(path.absolute().as_posix().encode())
            hasher.update(path.read_bytes())
        elif path.is_dir():
            for file in glob.glob(str(path) + "/**", recursive=True):
                file = Path(file)
                if file.is_file():
                    hasher.update(file.absolute().as_posix().encode())
                    hasher.update(file.read_bytes())
        else:
            raise ValueError(f"Path {path} is neither a file nor a directory.")
    return hasher.hexdigest()


_mutex = Lock()


def get_manualcache_path() -> Path:
    return get_project_root() / ".nanci_manualcache"


def have_files_changed(paths: list[Path | str]) -> bool:
    paths_set = frozenset([Path(p) for p in paths])
    h = calc_files_hash(paths_set)

    with _mutex:
        manualcache: dict[frozenset[Path], FILES_HASH]
        if (manualcache_path := get_manualcache_path()).exists():
            manualcache = pickle.loads(manualcache_path.read_bytes())
        else:
            manualcache = {}

        if paths_set not in manualcache or manualcache[paths_set] != h:
            manualcache[paths_set] = h
            get_manualcache_path().write_bytes(pickle.dumps(manualcache))
            return True
        else:
            return False
