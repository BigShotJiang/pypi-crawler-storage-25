import traceback
from dataclasses import dataclass, asdict, field
import threading
from .job_id import JobId
from typing import Any, Union, TypeAlias, Literal, final
from queue import Queue
import json
import sys
from typing import TextIO
import base64
from datetime import datetime, timezone

@dataclass
class BaseNanciMessage:
    at: datetime = field(default_factory=lambda: datetime.now(timezone.utc), kw_only=True)

@dataclass
class JobStartMessage(BaseNanciMessage):
    job_id: JobId
    name: str

@dataclass
class JobEndMessage(BaseNanciMessage):
    job_id: JobId
    exception: Exception | str | None = None

@dataclass
class JobImagePullStartMessage(BaseNanciMessage):
    job_id: JobId
    image: str

@dataclass
class JobImagePullEndMessage(BaseNanciMessage):
    job_id: JobId

@dataclass
class JobStartMoveMessage(BaseNanciMessage):
    job_id: JobId
    direction: Literal["upload", "download"]
    src: str
    dst: str


@dataclass
class JobEndMoveMessage(BaseNanciMessage):
    job_id: JobId


@dataclass
class JobExecStartMessage(BaseNanciMessage):
    job_id: JobId
    cmd: str


@dataclass
class JobExecOutputMessage(BaseNanciMessage):
    job_id: JobId
    chunk: bytes


@dataclass
class JobExecEndMessage(BaseNanciMessage):
    job_id: JobId


@dataclass
class UncaughtExceptionMessage(BaseNanciMessage):
    exception: Exception | str


@dataclass
class JobAutocacheHitMessage(BaseNanciMessage):
    job_id: JobId


@dataclass
class StdStreamMessage(BaseNanciMessage):
    text: str


@dataclass
class MainThreadStartMessage(BaseNanciMessage):
    pass

@dataclass
class MainThreadTerminateMessage(BaseNanciMessage):
    pass


NanciMessage: TypeAlias = Union[
    JobStartMessage,
    JobEndMessage,
    JobImagePullStartMessage,
    JobImagePullEndMessage,
    JobExecStartMessage,
    JobExecOutputMessage,
    JobExecEndMessage,
    JobStartMoveMessage,
    JobEndMoveMessage,
    UncaughtExceptionMessage,
    JobAutocacheHitMessage,
    StdStreamMessage,
    MainThreadStartMessage,
    MainThreadTerminateMessage,
]

NANCI_EVENT_QUEUE = Queue[NanciMessage]()


class NanciMessageSerializor:
    @staticmethod
    def serialize(msg: NanciMessage) -> str:
        d = asdict(msg)
        d["type"] = msg.__class__.__name__
        d["at"] = d["at"].isoformat()
        match msg:
            case JobExecOutputMessage(chunk=chunk):
                d["chunk"] = base64.b64encode(chunk).decode()
            case (
                JobEndMessage(_, exception=exception)
                | UncaughtExceptionMessage(exception=exception)
            ) if exception is not None:
                d["exception"] = "\n".join(traceback.format_exception(None, exception, exception.__traceback__))
        return json.dumps(d)

    @staticmethod
    def deserialize(s: str) -> NanciMessage:
        d = json.loads(s)
        d["at"] = datetime.fromisoformat(d["at"])
        
        if d["type"] == "JobExecOutputMessage":
            d["chunk"] = base64.b64decode(d["chunk"].encode())

        match d.pop("type"):
            case "JobStartMessage":
                return JobStartMessage(**d)
            case "JobEndMessage":
                return JobEndMessage(**d)
            case "JobImagePullStartMessage":
                return JobImagePullStartMessage(**d)
            case "JobImagePullEndMessage":
                return JobImagePullEndMessage(**d)
            case "JobExecStartMessage":
                return JobExecStartMessage(**d)
            case "JobExecOutputMessage":
                return JobExecOutputMessage(**d)
            case "JobExecEndMessage":
                return JobExecEndMessage(**d)
            case "JobStartMoveMessage":
                return JobStartMoveMessage(**d)
            case "JobEndMoveMessage":
                return JobEndMoveMessage(**d)
            case "UncaughtExceptionMessage":
                return UncaughtExceptionMessage(**d)
            case "JobAutocacheHitMessage":
                return JobAutocacheHitMessage(**d)
            case "StdStreamMessage":
                return StdStreamMessage(**d)
            case "MainThreadStartMessage":
                return MainThreadStartMessage(**d)
            case "MainThreadTerminateMessage":
                return MainThreadTerminateMessage(**d)
            case _:
                raise ValueError(f"Unknown message type: {d['type']}")


class HeadlessConsumer:
    def __init__(self, true_stdout: TextIO):
        self.thread = threading.Thread(target=self.thread_main)
        self.true_stdout: TextIO = true_stdout

    def start(self):
        self.thread.start()

    def join(self):
        self.thread.join()

    def thread_main(self):
        while True:
            msg = NANCI_EVENT_QUEUE.get()
            print(NanciMessageSerializor.serialize(msg), file=self.true_stdout)
            if isinstance(msg, (MainThreadTerminateMessage, UncaughtExceptionMessage)):
                break


class HeadlessStdCapture:
    def write(self, text: str) -> None:
        """Called when writing to stdout or stderr.

        Args:
            text: Text that was "printed".
        """
        NANCI_EVENT_QUEUE.put(StdStreamMessage(text=text))

    def flush(self) -> None:
        """Called when stdout or stderr was flushed."""
        pass

    def isatty(self) -> bool:
        """Pretend we're a terminal."""
        return True

    def fileno(self) -> int:
        """Return invalid fileno."""
        return -1
