from collections.abc import Callable, Coroutine
from typing import Any, Optional, overload

from functools import wraps
import aiodocker
from .shell import bash, Shell
from contextvars import ContextVar, Context
from proxyvars import lookup_proxy
from uuid import uuid4
import asyncio
from .job import Job
from .events import NANCI_EVENT_QUEUE, JobStartMessage, JobEndMessage, JobImagePullStartMessage, JobImagePullEndMessage

ci_var = ContextVar("ci_var")
ci: Job = lookup_proxy(ci_var, Job)


def _normalize_image_name(image: str) -> str:
    if "@" in image:
        return image
    last_part = image.rsplit("/", maxsplit=1)[-1]
    if ":" in last_part:
        return image
    return f"{image}:latest"


@overload
def job[T](
    job_func: Callable[..., Coroutine[Any, Any, T]], /
) -> Callable[..., Coroutine[Any, Any, T | Exception]]: ...


@overload
def job[T](
    *,
    image: str = "ubuntu:latest",
    noop_cmd: list[str] = ["tail", "-f"],
    shell: Shell = bash,
) -> Callable[
    [Callable[..., Coroutine[Any, Any, T]]], Callable[..., Coroutine[Any, Any, T | Exception]]
]: ...


def job[T](
    job_func: Optional[Callable] = None,
    *,
    # Make sure the defaults match the spec above!
    image: str = "ubuntu:latest",
    noop_cmd: list[str] = ["tail", "-f"],
    shell: Shell = bash,
) -> Callable:
    def _decorate(f: Callable) -> Callable:
        @wraps(f)
        async def wrapper(*args, **kwargs):
            docker_client = aiodocker.Docker()

            job = Job(f.__name__, shell=shell)
            NANCI_EVENT_QUEUE.put(JobStartMessage(job_id=job.id, name=job.name))

            resolved_image = _normalize_image_name(image)
            images = sum(
                [
                    img["RepoTags"]
                    for img in await docker_client.images.list()
                    if img.get("RepoTags")
                ],
                start=[],
            )
            if resolved_image not in images:
                NANCI_EVENT_QUEUE.put(JobImagePullStartMessage(job_id=job.id, image=resolved_image))
                await docker_client.images.pull(resolved_image)
                NANCI_EVENT_QUEUE.put(JobImagePullEndMessage(job_id=job.id))

            container_name = f"nanci-{uuid4()}"
            container = await docker_client.containers.create(
                {
                    "Image": resolved_image,
                    "Cmd": noop_cmd,
                    "AttachStdout": False,
                    "AttachStderr": False,
                    "HostConfig": {"AutoRemove": True},
                },
                name=container_name,
            )

            job.set_container(container)

            await container.start()

            # Create an async context so that each job has its own nanci.Context
            ctx = Context()
            ctx.run(ci_var.set, job)
            co = f(*args, **kwargs)
            task = asyncio.create_task(co, context=ctx)

            try:
                res = await task
                NANCI_EVENT_QUEUE.put(JobEndMessage(job_id=job.id))
            except Exception as exception:
                res = exception
                NANCI_EVENT_QUEUE.put(JobEndMessage(job_id=job.id, exception=exception))
            finally:
                await container.delete(force=True)
                await docker_client.close()
            return res

        return wrapper

    if job_func is None:
        return _decorate
    else:
        return _decorate(job_func)
