from pathlib import Path
import sys


def get_project_root() -> Path:
    # Assumption: execution starts with a nanci_ci.py file in the root of the project.
    main_file = sys.modules["__main__"].__file__
    if main_file is None:
        raise ValueError("Cannot determine nanci project root.")
    return Path(main_file).parent
