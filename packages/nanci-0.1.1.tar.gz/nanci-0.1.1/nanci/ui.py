from collections.abc import Callable
import traceback
from typing import Literal, TypeAlias, Union
from textual.app import App, ComposeResult, RenderResult
from rich.spinner import Spinner
from textual.widget import Widget, Text
from textual.containers import Horizontal, Vertical
from textual.widgets import (
    Static,
    Rule,
    ContentSwitcher,
)
from textual.containers import VerticalScroll
from textual.reactive import reactive
from textual.css.query import NoMatches
from textual.message import Message
from textual.events import Print
from queue import Queue
from dataclasses import dataclass
import threading
from .term import Term
from .job_id import JobId
import nanci.events as nanci_ev
from nanci.events import NANCI_EVENT_QUEUE
import sys


# Otherwise the snapshots might not match, depending on how long pilot.pause()
# takes
SPINNER_SPEED = 0.0 if "pytest" in sys.modules else 1.0


class Job(Static):
    class Selected(Message):
        def __init__(self, job_id: JobId):
            super().__init__()
            self.job_id = job_id

    def __init__(self, id: JobId, name: str):
        super().__init__(id=id)
        self.job_name = name
        self.finished = False

    def on_click(self):
        self.post_message(self.Selected(self.id))

    def on_mount(self):
        self.spinner = Spinner("dots", text=self.job_name, speed=SPINNER_SPEED)
        self._update_renderable()
        self.timer = self.set_interval(1 / 30, self._update_renderable)

    def _update_renderable(self):
        if self.finished:
            self.update(Text(f"⣿ {self.job_name}"))
        else:
            self.update(self.spinner)

    async def on_nanci_message(self, msg: nanci_ev.NanciMessage):
        match msg:
            case nanci_ev.JobAutocacheHitMessage():
                if self.id != msg.job_id:
                    return
                self.add_class("completed-autocached")
            case nanci_ev.JobEndMessage():
                if self.id != msg.job_id:
                    return
                if not self.has_class("completed-autocached"):
                    if msg.exception:
                        self.add_class("completed-error")
                    else:
                        self.add_class("completed-success")
                self.finished = True
                self.timer.stop()
                self._update_renderable()


class Sidebar(Widget):
    BORDER_TITLE = "Jobs"

    async def on_nanci_message(self, msg: nanci_ev.NanciMessage):
        match msg:
            case nanci_ev.JobStartMessage(job_id, name):
                await self.query_one("#jobs").mount(Job(job_id, name))
            case _ if hasattr(msg, "job_id"):
                await self.query_one(f"#{msg.job_id}").on_nanci_message(msg)

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="jobs")


class RuleWithTitle(Widget):
    def __init__(self, title: str, *, border_char: str = "━"):
        super().__init__()
        self.title = title
        self.border_char = border_char

    def render(self) -> RenderResult:
        title = self.title
        max_len = self.size.width - 6
        ellipsis = "..."
        if len(title) > max_len:
            to_the_side = (max_len - len(ellipsis)) // 2
            title = title[: to_the_side + 1] + ellipsis + title[-to_the_side:]
        side_len = (self.size.width - len(title)) // 2
        side = self.border_char * side_len
        return Text(side + " " + title + " " + side, overflow="ignore")


class Exec(Static):
    def __init__(self):
        super().__init__()
        self.term = Term()

    def add_to_output(self, chunk: bytes):
        self.term.feed(chunk)
        self.update(self.term.display)


class ProgressBar(Static):
    def on_mount(self):
        self.spinner = Spinner("dots", speed=SPINNER_SPEED)
        self._update_renderable()
        self.timer = self.set_interval(1 / 30, self._update_renderable)

    def _update_renderable(self):
        self.update(self.spinner)


class Move(Widget):
    is_completed = reactive[bool](False)

    def __init__(
        self, direction: Literal["upload", "download"], src: str, dst: str | Literal["as_artifact"]
    ):
        super().__init__()
        self.direction = direction
        self.src = src
        self.dst = dst

    def compose(self):
        with Vertical():
            with Horizontal():
                yield Static(self.direction.title(), classes="title")
                yield ProgressBar()
            with Horizontal():
                yield Static("from: ", classes="src-or-dst")
                yield Static(self.src)
            with Horizontal():
                yield Static("to: ", classes="src-or-dst")
                yield Static(self.dst)

    def watch_is_completed(self, value: bool):
        if value:
            self.query_one("ProgressBar").remove()


class ImagePull(Widget):
    is_completed = reactive[bool](False)

    def __init__(
        self, image: str
    ):
        super().__init__()
        self.image = image

    def compose(self):
        with Vertical():
            with Horizontal():
                yield Static("Pull image", classes="title")
                yield ProgressBar()
            with Horizontal():
                yield Static("image: ", classes="image")
                yield Static(self.image)

    def watch_is_completed(self, value: bool):
        if value:
            self.query_one("ProgressBar").remove()


class AutocacheHit(Static):
    def __init__(self):
        super().__init__()
        self.update("Job skipped due to autocache hit.")


class JobException(Widget):
    def __init__(self, exc: Exception):
        super().__init__()
        self.exc = exc

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Uncaught exception in job:", classes="title")
            code = "\n".join(traceback.format_exception(None, self.exc, self.exc.__traceback__))
            yield Static(code.strip())


class JobConsole(Widget):
    def __init__(self, job_id: JobId, job_name: str):
        super().__init__(id=job_id)

    async def _ensure_rule_after_exec(self):
        if (last_child := self.query_one("VerticalScroll").children) and isinstance(
            last_child[-1], Exec
        ):
            await self.query_one("VerticalScroll").mount(Rule(line_style="heavy"))

    async def on_nanci_message(self, msg: nanci_ev.NanciMessage):
        match msg:
            case nanci_ev.JobStartMessage():
                job_started = RuleWithTitle("Job started", border_char="═")
                job_started.add_class("started")
                await self.query_one("#console-stream").mount(job_started)
            case nanci_ev.JobExecStartMessage():
                vs = self.query_one("#console-stream")
                exec_header = RuleWithTitle(msg.cmd)
                exec_header.tooltip = msg.cmd
                await vs.mount(exec_header)
                await vs.mount(Exec())
            case nanci_ev.JobExecOutputMessage():
                exec = self.query("#console-stream > *")[-1]
                exec.add_to_output(msg.chunk)
                exec.refresh(layout=True)
            case nanci_ev.JobEndMessage():
                if msg.exception:
                    await self._ensure_rule_after_exec()
                    job_exception = JobException(msg.exception)
                    await self.query_one("#console-stream").mount(job_exception)
                if not self.query("#console-stream AutocacheHit"):
                    job_completed = RuleWithTitle("Job completed", border_char="═")
                    if msg.exception:
                        job_completed.add_class("completed-error")
                    else:
                        job_completed.add_class("completed-success")
                    await self.query_one("#console-stream").mount(job_completed)
            case nanci_ev.JobStartMoveMessage():
                await self._ensure_rule_after_exec()
                move_start = Move(msg.direction, msg.src, msg.dst)
                await self.query_one("#console-stream").mount(move_start)
            case nanci_ev.JobEndMoveMessage():
                self.query("#console-stream > *")[-1].is_completed = True
            case nanci_ev.JobAutocacheHitMessage():
                await self.query_one("#console-stream").mount(AutocacheHit())
            case nanci_ev.JobImagePullStartMessage():
                await self._ensure_rule_after_exec()
                image_pull = ImagePull(msg.image)
                await self.query_one("#console-stream").mount(image_pull)
            case nanci_ev.JobImagePullEndMessage():
                self.query("#console-stream > *")[-1].is_completed = True
        try:
            self.query_one("#console-stream").scroll_end(animate=False)
        except NoMatches:
            pass

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="console-stream")


class ExceptionAlert(Widget):
    def __init__(self, exc: Exception):
        super().__init__()
        self.exc = exc
        self.border_title = "Uncaught global exception"

    def on_mount(self):
        self.query_one("VerticalScroll").scroll_end(animate=False)

    def compose(self) -> ComposeResult:
        code = "\n".join(traceback.format_exception(None, self.exc, self.exc.__traceback__))
        yield VerticalScroll(Static(code.strip()), classes="traceback")


class Capture(Widget):
    def __init__(self):
        super().__init__()
        self.display = False
        self.border_title = "Captured stdout & stderr"
        self.border_subtitle = "Press S again to go back."

    class CapturedText(Static):
        captured_text = reactive("")

        def watch_captured_text(self, v: str):
            self.update(Text(v))

    def compose(self) -> ComposeResult:
        yield VerticalScroll(Capture.CapturedText())

    def on_nanci_message(self, ev: nanci_ev.NanciMessage):
        if not isinstance(ev, nanci_ev.StdStreamMessage):
            return
        self.query_one("CapturedText").captured_text += ev.text


class UI(App):
    CSS_PATH = "style.tcss"

    BINDINGS = [
        ("s", "toggle_capture"),
    ]

    def __init__(self, run_main_module: Callable):
        super().__init__()
        self.run_main_module = run_main_module

    def action_toggle_capture(self):
        capture = self.query_one("Capture")
        capture.display = not capture.display

    def select_job(self, job_id: JobId):
        for job in self.query("Job"):
            job.set_class(job.id == job_id, "selected")
        self.query_one("ContentSwitcher").current = job_id

    def ensure_selected_job(self):
        if self.query_one("ContentSwitcher").current is not None:
            return
        jobs = list(self.query("Job"))
        if not jobs:
            return
        self.select_job(jobs[0].id)

    # Handle message from child
    def on_job_selected(self, msg: Job.Selected):
        self.select_job(msg.job_id)
        self.log.info(self.query_one("ContentSwitcher").children)

    def compose(self) -> ComposeResult:
        yield Capture()
        with Horizontal(id="main"):
            yield Sidebar()
            yield ContentSwitcher()

    async def on_nanci_message(self, msg: nanci_ev.NanciMessage):
        if self.query("ExceptionAlert"):
            return
        match msg:
            case nanci_ev.JobStartMessage():
                new_widget = JobConsole(msg.job_id, msg.name)
                new_widget.display = False
                await self.query_one("ContentSwitcher").mount(new_widget)
            case nanci_ev.StdStreamMessage():
                self.query_one("Capture").on_nanci_message(msg)
            case nanci_ev.UncaughtExceptionMessage():
                screen = self.query_one("Screen")
                screen.styles.align = "center", "middle"
                await screen.remove_children("#main")
                await screen.mount(ExceptionAlert(msg.exception))
                return
        if hasattr(msg, "job_id"):
            await self.query_one(f"ContentSwitcher > #{msg.job_id}").on_nanci_message(msg)
        await self.query_one("Sidebar").on_nanci_message(msg)
        self.ensure_selected_job()
        self.wait_for_message()

    def on_unmount(self):
        self.workers.cancel_all()

    def on_mount(self):
        self.begin_capture_print(self)
        self.run_main_module()
        self.wait_for_message()

    def on_print(self, ev: Print):
        NANCI_EVENT_QUEUE.put(nanci_ev.StdStreamMessage(ev.text))

    def wait_for_message(self):
        def _target():
            msg = NANCI_EVENT_QUEUE.get()
            self.call_from_thread(self.on_nanci_message, msg)

        t = threading.Thread(target=_target, daemon=True)
        t.start()
