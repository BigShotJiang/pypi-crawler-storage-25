import ast
import sys
import inspect
import hashlib
from pathlib import Path
import typing as t

from ..config import get_project_root


def is_user_function(f: t.Callable) -> bool:
    if inspect.ismethod(f):
        f = f.__func__
    if not inspect.isfunction(f):
        return False
    file_path_str = sys.modules[f.__module__].__file__
    if file_path_str is None:
        return False
    file_path = Path(file_path_str)
    # TODO Check which item in sys.path, to make sure we skip modules in a venv
    return file_path.is_relative_to(get_project_root())


class Visitor(ast.NodeVisitor):
    hasher: hashlib.blake2b
    globals: dict

    def __init__(self, hasher: hashlib.blake2b, scope: dict):
        self.hasher = hasher
        self.scope = scope

    def resolve_global_call(self, func: ast.expr) -> t.Callable:
        """ "
        A call is global if it's a sequence of Attribute nodes with a leading Name node.
        """
        names_stack = []
        # `index` keeps track of the current expression as we peel off its
        # layers.
        index = func
        while isinstance(index, ast.Attribute):
            names_stack.append(index.attr)
            index = index.value
        if not isinstance(index, ast.Name):
            raise Exception(
                "Autocache only supports calling other functions in the global scope by static name."
            )
        names_stack.append(index.id)

        scope = self.scope
        while len(names_stack) > 1:
            name = names_stack.pop()
            if name not in scope:
                raise Exception(
                    "Autocache only supports calling other functions in the global scope by static name."
                )
            scope = scope[name]
            if not isinstance(scope, dict):
                scope = {k: getattr(scope, k) for k in dir(scope)}
        return scope[names_stack.pop()]

    def visit_Call(self, node: ast.Call):
        f = self.resolve_global_call(node.func)
        assert callable(f)
        if not is_user_function(f):
            return
        update_func_hash(f, self.hasher)


def update_func_hash(f: t.Callable, hasher: hashlib.blake2b):
    source = inspect.getsource(f)
    hasher.update(source.encode())
    Visitor(hasher, f.__globals__ | __builtins__).visit(ast.parse(source))
