from functools import wraps
import hashlib
from pathlib import Path
from dataclasses import dataclass
import typing as t

from ..manualcaching import FILES_HASH, calc_files_hash
from ..config import get_project_root
import pickle
from ..events import NANCI_EVENT_QUEUE, JobAutocacheHitMessage
from ..job_decorator import ci
from threading import Lock
from .ctx import AutocacheContext, autocache_var
from .hashing import update_func_hash


@dataclass
class SavedRun:
    uploaded_paths: list[Path]
    files_hash: FILES_HASH

    @staticmethod
    def from_uploaded_paths(uploaded_paths: list[Path]) -> "SavedRun":
        return SavedRun(uploaded_paths, calc_files_hash(uploaded_paths))


_mutex = Lock()


def get_autocache_path() -> Path:
    return get_project_root() / ".nanci_autocache"


FUNC_HASH: t.TypeAlias = str


def _read_autocache_file() -> dict[FUNC_HASH, SavedRun]:
    autocache: dict[FUNC_HASH, SavedRun]
    if (autocache_path := get_autocache_path()).exists():
        autocache = pickle.load(autocache_path.open("rb"))
    else:
        autocache = {}
    return autocache


def autocache(f: t.Callable) -> t.Callable:
    """
    To be autocachable, a function must:
    - Not return anything.
    - If it calls another function, that function must:
        - Be defined in the global scope.
        - Be called by its constant name.
        - Not be decorated.
    """

    @wraps(f)
    async def wrapper(*args, **kwargs):
        # Compute hash of the source code for the function (including the
        # functions it calls) and its arguments.
        hasher = hashlib.blake2b()
        update_func_hash(f, hasher)
        for arg in args:
            hasher.update(str(arg).encode())
        for k, v in kwargs.items():
            hasher.update(str(k).encode())
            hasher.update(str(v).encode())
        func_hash = hasher.hexdigest()

        # Read the previous runs.
        with _mutex:
            autocache = _read_autocache_file()

        if func_hash in autocache:
            # Function's source code (including the source code of the
            # functions it calls) has not changed, and we know the files
            # that it uses. Check if those files have changed since.
            previous_run = autocache[func_hash]
            if previous_run.files_hash == calc_files_hash(previous_run.uploaded_paths):
                NANCI_EVENT_QUEUE.put(JobAutocacheHitMessage(job_id=ci.id))
                return Unusable()

        # Otherwise run the function, record what files it uses, and save the
        # run for next time.

        # This context var is picked up when calling ci.upload
        autocache_ctx = AutocacheContext(uploaded_paths=[])
        autocache_var.set(autocache_ctx)

        result = await f(*args, **kwargs)

        with _mutex:
            autocache = _read_autocache_file()
            autocache[func_hash] = SavedRun.from_uploaded_paths(autocache_ctx.uploaded_paths)
            pickle.dump(autocache, get_autocache_path().open("wb"))

        return result

    return wrapper


class Unusable:
    exception = Exception("Cannot use result of cached job.")

    def __str__(self):
        raise Unusable.exception

    def __repr__(self):
        raise Unusable.exception

    def __bool__(self):
        raise Unusable.exception
