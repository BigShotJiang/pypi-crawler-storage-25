from contextvars import ContextVar
from dataclasses import dataclass
from pathlib import Path


@dataclass
class AutocacheContext:
    uploaded_paths: list[Path]

autocache_var = ContextVar[AutocacheContext]("autocache_context_var")
