from typing import NewType
from uuid import UUID, uuid4

JobId = NewType("JobId", str)

def generate_job_id() -> JobId:
    return JobId("_" + str(uuid4()).replace("-", ""))
