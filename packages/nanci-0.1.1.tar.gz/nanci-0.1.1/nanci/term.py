from rich.console import RenderableType
from rich.text import Text
from collections import defaultdict


class Term:
    def __init__(self):
        self.lines: list[bytearray] = [bytearray()]
        self.line = 0
        self.column = 0

        self.saved_cursor: tuple[int, int] | None = None

        self.esc_seq = bytearray()

        self.format: bytes | None = None

        self.char_format = defaultdict(lambda: defaultdict(lambda: None))

    def ensure_line(self, line_no: int):
        while len(self.lines) <= line_no:
            self.lines.append(bytearray())

    def clamp_cursor(self):
        if self.line < 0:
            self.line = 0
        if self.column < 0:
            self.column = 0
        self.ensure_line(self.line)

    def write_char(self, char: int):
        self.ensure_line(self.line)
        line = self.lines[self.line]
        if self.column >= len(line):
            line.extend(b" " * (self.column - len(line) + 1))
        line[self.column] = char
        self.char_format[self.line][self.column] = self.format
        self.column += 1

    def feed(self, chunk: bytes):
        for char in chunk:
            if self.esc_seq:
                self.esc_seq.append(char)
                self.handle_escape()
                continue

            match char:
                case 7:
                    # Bell
                    pass
                case 8:
                    # Backspace
                    if self.column > 0:
                        self.column -= 1
                case 9:
                    # Tab
                    self.column += 8 - self.column % 8
                case 0x0A:
                    # Line feed
                    self.line += 1
                    self.ensure_line(self.line)
                    self.column = 0
                case 0x0C:
                    # Form feed (clear screen)
                    self.lines = [bytearray()]
                    self.char_format = defaultdict(lambda: defaultdict(lambda: None))
                    self.line = 0
                    self.column = 0
                case 0x0D:
                    # Carriage return
                    self.column = 0
                case 0x1B:
                    # Escape
                    self.esc_seq.append(char)
                case _:
                    # Printable characters
                    self.write_char(char)

    def handle_escape(self):
        seq = bytes(self.esc_seq)

        # Wait for one more byte after ESC.
        if seq == b"\x1B":
            return

        if seq == b"\x1B7":
            # Save cursor position
            self.saved_cursor = (self.line, self.column)
            self.esc_seq = bytearray()
            return
        if seq == b"\x1B8":
            # Restore cursor position
            if self.saved_cursor is not None:
                self.line, self.column = self.saved_cursor
                self.clamp_cursor()
            self.esc_seq = bytearray()
            return

        if not seq.startswith(b"\x1B["):
            # Unsupported ESC sequence (e.g. OSC); drop it.
            self.esc_seq = bytearray()
            return

        # Wait for at least one byte after CSI introducer.
        if len(seq) == 2:
            return

        command = seq[-1]
        # CSI commands end with bytes 0x40..0x7E.
        if not (0x40 <= command <= 0x7E):
            return

        params_raw = seq[2:-1]
        params = self.parse_csi_params(params_raw)
        command_ch = chr(command)

        if command_ch == "A":
            # Cursor up
            self.line -= self.csi_param(params, 0, default=1)
        elif command_ch == "B":
            # Cursor down
            self.line += self.csi_param(params, 0, default=1)
        elif command_ch == "C":
            # Cursor forward
            self.column += self.csi_param(params, 0, default=1)
        elif command_ch == "D":
            # Cursor back
            self.column -= self.csi_param(params, 0, default=1)
        elif command_ch == "G":
            # Cursor horizontal absolute
            self.column = self.csi_param(params, 0, default=1) - 1
        elif command_ch in {"H", "f"}:
            # Cursor position
            self.line = self.csi_param(params, 0, default=1) - 1
            self.column = self.csi_param(params, 1, default=1) - 1
        elif command_ch == "J":
            self.erase_in_display(self.csi_param(params, 0, default=0))
        elif command_ch == "K":
            self.erase_in_line(self.csi_param(params, 0, default=0))
        elif command_ch == "m":
            # Keep full SGR bytes; Rich will interpret these later.
            if params_raw in {b"", b"0"}:
                self.format = None
            else:
                self.format = b"\x1B[" + params_raw + b"m"
        elif command_ch == "s":
            self.saved_cursor = (self.line, self.column)
        elif command_ch == "u":
            if self.saved_cursor is not None:
                self.line, self.column = self.saved_cursor
        # Unknown CSI sequences are intentionally ignored.

        self.clamp_cursor()
        self.esc_seq = bytearray()

    @staticmethod
    def parse_csi_params(params_raw: bytes) -> list[int | None]:
        # Ignore private-mode prefixes (e.g. ?25l).
        while params_raw[:1] in [b"?", b">", b"<", b"="]:
            params_raw = params_raw[1:]

        if not params_raw:
            return []

        out: list[int | None] = []
        for part in params_raw.split(b";"):
            if part == b"":
                out.append(None)
                continue
            try:
                out.append(int(part))
            except ValueError:
                out.append(None)
        return out

    @staticmethod
    def csi_param(params: list[int | None], index: int, *, default: int) -> int:
        if index >= len(params) or params[index] is None:
            return default
        return params[index]

    def erase_in_display(self, mode: int):
        self.ensure_line(self.line)
        if mode == 0:
            # Clear from cursor to end of screen.
            self.lines[self.line] = self.lines[self.line][: self.column]
            self.lines = self.lines[: self.line + 1]
        elif mode == 1:
            # Clear from beginning of screen to cursor.
            for row in range(self.line):
                self.lines[row] = bytearray()
            row = self.lines[self.line]
            for col in range(min(self.column + 1, len(row))):
                row[col] = 0x20
                self.char_format[self.line][col] = None
        elif mode == 2:
            # Clear entire screen.
            self.lines = [bytearray()]
            self.char_format = defaultdict(lambda: defaultdict(lambda: None))
            self.line = 0
            self.column = 0

    def erase_in_line(self, mode: int):
        self.ensure_line(self.line)
        row = self.lines[self.line]
        if mode == 0:
            # Clear from cursor to end of line.
            self.lines[self.line] = row[: self.column]
        elif mode == 1:
            # Clear from beginning of line to cursor.
            for col in range(min(self.column + 1, len(row))):
                row[col] = 0x20
                self.char_format[self.line][col] = None
        elif mode == 2:
            # Clear entire line.
            self.lines[self.line] = bytearray()

    @property
    def display(self) -> RenderableType:
        styled_lines = []
        for line_n, line in enumerate(self.lines):
            if line_n == len(self.lines) - 1 and line == b"":
                break
            styled_line = bytearray(b"\x1B[m")
            for column_n, char in enumerate(line):
                if (
                    column_n > 0
                    and self.char_format[line_n][column_n] == self.char_format[line_n][column_n - 1]
                ):
                    # Format didn't change, just add the character
                    styled_line.append(char)
                    continue
                # First column or format changed
                if format := self.char_format[line_n][column_n]:
                    styled_line.extend(format)
                    styled_line.append(char)
                else:
                    styled_line.extend(b"\x1B[m")
                    styled_line.append(char)
            styled_lines.append(styled_line)

        return Text.from_ansi(
            "\n".join(styled_line.decode(errors="replace") for styled_line in styled_lines)
        )

    # Legacy alias for compatibility with older call sites.
    def _clamp_cursor(self):
        self.clamp_cursor()

    # Legacy alias for compatibility with older call sites.
    def _ensure_line(self, line_no: int):
        self.ensure_line(line_no)

    # Legacy alias for compatibility with older call sites.
    def _write_char(self, char: int):
        self.write_char(char)
