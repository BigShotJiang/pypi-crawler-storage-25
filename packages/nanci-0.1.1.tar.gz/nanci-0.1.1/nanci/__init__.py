# This file won't be execute twice because the "nanci" module has already been
# imported (actually, is in the process of being imported but the Python
# interpreter will have already assigned "sys.modules["nanci"]"").

from .importing import hook_into_import_machinery, SourceFileLoaderHacked
import sys
from .autocache.decorator import autocache as autocache
from .job_decorator import job as job, ci as ci
from .shell import bash as bash, sh as sh, no_shell as no_shell
from .artifact import Artifact as Artifact, AsArtifact as AsArtifact
from .manualcaching import have_files_changed as have_files_changed
from .ui import UI
from .events import (
    NANCI_EVENT_QUEUE,
    UncaughtExceptionMessage,
    HeadlessConsumer,
    HeadlessStdCapture,
)
from contextlib import redirect_stdout, redirect_stderr
import threading
import os
from .hijack_import import hijack_import
from .trigger import PullRequestTrigger as PullRequestTrigger, PushTrigger as PushTrigger, get_trigger_from_env

trigger = get_trigger_from_env()

match os.environ.get("NANCI_NO_HIJACK", None):
    case "true":
        IS_NO_HIJACK = True
    case "false" | None:
        IS_NO_HIJACK = False
    case _:
        raise ValueError("Invalid NANCI_NO_HIJACK, must be 'true' or 'false'")

if not IS_NO_HIJACK:
    hijack_import()
