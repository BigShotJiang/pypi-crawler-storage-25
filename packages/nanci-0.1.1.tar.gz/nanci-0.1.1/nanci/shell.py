from typing import Any, AsyncGenerator, TypeAlias, Callable
from aiodocker.containers import DockerContainer
import re
from dataclasses import dataclass


@dataclass
class ShellState:
    state: Any


Shell: TypeAlias = Callable[
    [str, DockerContainer, ShellState | None], AsyncGenerator[list[str] | ShellState, None]
]


async def no_shell(
    cmd: str, container: DockerContainer, state: ShellState | None = None
) -> AsyncGenerator[list[str] | ShellState, None]:
    yield cmd.split()
    yield ShellState(None)


async def sh(
    cmd: str, container: DockerContainer, state: ShellState | None = None
) -> AsyncGenerator[list[str] | ShellState, None]:
    yield ["sh", "-o", "errexit", "-c", cmd]
    yield ShellState(None)


async def bash(
    cmd: str, container: DockerContainer, state: ShellState | None = None
) -> AsyncGenerator[list[str] | ShellState, None]:
    cwd, declare = None, None
    if state:
        cwd = state.state.get("cwd")
        declare = state.state.get("declare")

    bash_script = f"""
    function on_exit() {{
        pwd > /tmp/_nanci_bash_cwd
        declare -p > /tmp/_nanci_bash_declare
        declare -pf >> /tmp/_nanci_bash_declare
    }}
    trap on_exit EXIT
    {cwd and "cd " + cwd or ""}
    {declare or ""}
    {cmd}
    """

    yield ["bash", "-o", "errexit", "-c", bash_script]

    cwd_tar = await container.get_archive("/tmp/_nanci_bash_cwd")
    cwd = cwd_tar.extractfile(cwd_tar.next()).read().decode().strip()

    declare_tar = await container.get_archive("/tmp/_nanci_bash_declare")
    declare = declare_tar.extractfile(declare_tar.next()).read().decode().strip()

    declare = "\n".join(
        [line for line in declare.splitlines() if not re.match(r"declare -[^ ]*r", line)]
    )

    yield ShellState(
        {
            "cwd": cwd,
            "declare": declare,
        }
    )
