import tempfile
from aiodocker.containers import DockerContainer
import tarfile
from pathlib import Path
import io

from nanci.config import get_project_root
from .autocache.ctx import autocache_var
from .utils import get_file_stat, FileStat
from .shell import Shell, ShellState
from .artifact import Artifact, AsArtifact
from .job_id import JobId, generate_job_id
from .events import (
    NANCI_EVENT_QUEUE,
    JobExecOutputMessage,
    JobExecStartMessage,
    JobExecEndMessage,
    JobStartMoveMessage,
    JobEndMoveMessage,
)


class Job:
    def __init__(self, name: str, *, shell: Shell):
        self.id: JobId = JobId(generate_job_id())

        self.name = name
        self.container: DockerContainer | None = None
        self.shell = shell

        self.shell_state: ShellState | None = None

    def set_container(self, container: DockerContainer) -> None:
        self.container = container

    async def exec(self, cmd: str, *, tty: bool = False) -> str:
        assert self.container is not None, "Container is not running"

        shell = self.shell(cmd, self.container, self.shell_state)
        prepared_cmd = await anext(shell)
        assert isinstance(prepared_cmd, list)
        exec = await self.container.exec(prepared_cmd, tty=tty)

        NANCI_EVENT_QUEUE.put(JobExecStartMessage(self.id, cmd))

        async with exec.start() as stream:
            buf = io.BytesIO()
            while (chunk := await stream.read_out()) is not None:
                chunk_data = chunk.data
                if tty:
                    # The default behavior of TTYs (in general, not a Docker specific
                    # thing) is to replace \n with \r\n. This is probably not what the
                    # user expects though so we undo that.
                    chunk_data = chunk_data.replace(b"\r\n", b"\n")
                buf.write(chunk_data)
                NANCI_EVENT_QUEUE.put(JobExecOutputMessage(self.id, chunk_data))

        NANCI_EVENT_QUEUE.put(JobExecEndMessage(self.id))

        code: int = (await exec.inspect())["ExitCode"]
        if code != 0:
            raise Exception(f"Command exited with non-zero exit code {code}")

        next_shell_state = await anext(shell)
        assert isinstance(next_shell_state, ShellState)
        self.shell_state = next_shell_state

        buf.seek(0)
        output = buf.read().decode()
        return output

    async def upload(self, src: Path | str | Artifact, dst: Path | str) -> None:
        assert self.container is not None, "Container is not running"

        if isinstance(src, str):
            src = Path(src)
        if not isinstance(src, Artifact):
            try:
                autocache_var.get().uploaded_paths.append(src)
            except LookupError:
                # Not using autocache
                pass

        if isinstance(dst, str):
            dst = Path(dst)

        NANCI_EVENT_QUEUE.put(JobStartMoveMessage(self.id, "upload", str(src), str(dst)))

        try:
            dst_stat = await get_file_stat(self.container, dst)

            if (nanciignore_path := get_project_root() / ".nanciignore").exists():
                ignore_patterns = [
                    line for line in nanciignore_path.read_text().splitlines() if line
                ]
            else:
                ignore_patterns = []

            def filter_fn(tarinfo: tarfile.TarInfo) -> tarfile.TarInfo | None:
                path = Path(tarinfo.path)
                if any(path.match(ignore_pattern) for ignore_pattern in ignore_patterns):
                    return None
                return tarinfo

            buffer = io.BytesIO()
            with tarfile.open(fileobj=buffer, mode="w") as tar:
                if isinstance(src, Artifact):
                    src = src.path_to_content
                match dst_stat:
                    case None | FileStat(is_dir=False):
                        tar.add(src, arcname=dst.name, filter=filter_fn)
                        dst = dst.parent
                    case FileStat(is_dir=True):
                        tar.add(src, arcname=src.name, filter=filter_fn)
            buffer.seek(0)
            await self.container.put_archive(path=str(dst), data=buffer)
        finally:
            NANCI_EVENT_QUEUE.put(JobEndMoveMessage(self.id))

    async def download(
        self, src: Path | str, dst: Path | str | AsArtifact = AsArtifact()
    ) -> None | Artifact:
        assert self.container is not None, "Container is not running"

        if isinstance(src, str):
            src = Path(src)

        artifact: Artifact | None = None
        if isinstance(dst, AsArtifact):
            artifact = Artifact(tempfile.TemporaryDirectory())
            dst = artifact.path_to_temporary_dir
        elif isinstance(dst, str):
            dst = Path(dst)

        NANCI_EVENT_QUEUE.put(
            JobStartMoveMessage(
                self.id, "download", str(src), str(artifact) if artifact else str(dst)
            )
        )

        try:
            tar = await self.container.get_archive(path=str(src))
            if dst.is_dir():
                tar.extractall(path=dst)
            else:
                for member in tar.getmembers():
                    member.name = str(
                        Path(dst.name) / member.name.removeprefix(Path(src).name).removeprefix("/")
                    )
                tar.extractall(path=dst.parent)
        finally:
            NANCI_EVENT_QUEUE.put(JobEndMoveMessage(self.id))

        if artifact:
            return artifact
