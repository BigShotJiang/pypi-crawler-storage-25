from time import sleep
from .importing import hook_into_import_machinery, SourceFileLoaderHacked
import sys
from .autocache.decorator import autocache as autocache
from .job_decorator import job as job, ci as ci
from .artifact import Artifact as Artifact
from .manualcaching import have_files_changed as have_files_changed
from .ui import UI
from .events import (
    NANCI_EVENT_QUEUE,
    MainThreadStartMessage,
    MainThreadTerminateMessage,
    UncaughtExceptionMessage,
    HeadlessConsumer,
    HeadlessStdCapture,
)
from contextlib import redirect_stdout, redirect_stderr
import threading
import os


def hijack_import():
    match os.environ.get("NANCI_HEADLESS", None):
        case "true":
            IS_HEADLESS = True
        case "false" | None:
            IS_HEADLESS = False
        case _:
            raise ValueError("Invalid NANCI_HEADLESS, must be 'true' or 'false'")

    # So that when the main module imports anything, the source code is
    # transformed.
    hook_into_import_machinery()

    def _rerun_main_module():
        # Execute the main module (which was already executing up-to the import of
        # this very module).
        main = sys.modules["__main__"]
        try:
            NANCI_EVENT_QUEUE.put(MainThreadStartMessage())
            if IS_HEADLESS:
                with redirect_stdout(HeadlessStdCapture()), redirect_stderr(HeadlessStdCapture()):
                    SourceFileLoaderHacked("__main__", main.__file__).exec_module(main)
            else:
                SourceFileLoaderHacked("__main__", main.__file__).exec_module(main)
        except Exception as e:
            NANCI_EVENT_QUEUE.put(UncaughtExceptionMessage(e))
        finally:
            NANCI_EVENT_QUEUE.put(MainThreadTerminateMessage())

    main_thread = threading.Thread(target=_rerun_main_module)

    # Make it look like this module is already completely loaded (even if we're
    # still executing __init_.py), otherwise the thread above will sleep forever
    # waiting for this file to terminate execution, which it never will as long as
    # the UI is shown.
    sys.modules["nanci"].__spec__ = {}

    headless_consumer: HeadlessConsumer | None = None

    if IS_HEADLESS:
        # Get a reference to the real stdout before we start capturing it. Otherwise
        # printing Nanci messages will be captured too an cause a loop.
        headless_consumer = HeadlessConsumer(true_stdout=sys.stdout)
        headless_consumer.start()
        main_thread.start()
    else:
        ui = UI(lambda: main_thread.start())
        ui.run()

    main_thread.join()

    if headless_consumer is not None:
        headless_consumer.join()

    # We executed the main module during the import of this "nanci" module, we don't
    # want main to resume normal execution so we quit.
    sys.exit(0)
