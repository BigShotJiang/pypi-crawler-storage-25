from aiodocker.containers import DockerContainer
from dataclasses import dataclass
from base64 import b64decode
import json
from pathlib import Path

@dataclass
class FileStat:
    is_dir: bool

MODE_DIR = 0b10000000000000000000000000000000

async def get_file_stat(container: DockerContainer, path: Path) -> FileStat | None:
    try:
        async with container.docker._query(
            f"containers/{container.id}/archive",
            method="HEAD",
            headers={"content-type": "application/json"},
            params={"path": str(path)}
        ) as response:
            header = response.headers["X-Docker-Container-Path-Stat"]
            file_mode = json.loads(b64decode(header))["mode"]
            return FileStat(is_dir=file_mode & MODE_DIR != 0)
    except json.decoder.JSONDecodeError as err:
        if not err.msg.startswith("Expecting value"):
            raise
        return None