from typing import Any
from ast import NodeTransformer, Module, AST, Expr, Constant, JoinedStr, parse, walk, iter_child_nodes

class Transformer(NodeTransformer):
    parent: AST = None

    def visit(self, node: AST) -> Any:
        for _node in walk(node):
            for child in iter_child_nodes(_node):
                child.parent = _node
        return super().visit(node)

    def visit_Module(self, node: Module) -> Any:
        node = self.generic_visit(node)
        node.body.insert(0, parse("import nanci").body[0])
        return node

    def visit_Expr(self, node: Expr) -> Any:
        node = self.generic_visit(node)
        if isinstance(node.parent, Module):
            return node
        match node.value:
            case Constant(value) if isinstance(value, str):
                # Go ahead
                pass
            case JoinedStr():
                # Go ahead
                pass
            case _:
                return node
            
        call_expr = parse("await nanci.ci.exec(None, tty=True)").body[0]
        call_expr.value.value.args = [node.value]
        return call_expr
