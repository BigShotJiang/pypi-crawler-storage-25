from dataclasses import dataclass
from typing import TypeAlias
import os


@dataclass
class PushTrigger:
    branch: str


@dataclass
class PullRequestTrigger:
    number: int


Trigger: TypeAlias = PushTrigger | PullRequestTrigger

def get_trigger_from_env() -> Trigger | None:
    match os.environ.get("NANCI_TRIGGER_KIND"):
        case "push":
            return PushTrigger(branch=os.environ["NANCI_TRIGGER_PUSH_BRANCH"])
        case "pull_request":
            return PullRequestTrigger(number=int(os.environ["NANCI_TRIGGER_PR_NUMBER"]))
        case _:
            return None
