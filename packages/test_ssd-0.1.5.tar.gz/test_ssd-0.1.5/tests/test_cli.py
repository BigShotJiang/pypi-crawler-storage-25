from __future__ import annotations

from pathlib import Path

import pytest

from ssdtest.cli import main
from ssdtest.models import DeviceInfo, HealthSnapshot, RunArtifacts, StageResult, VerdictResult


def _artifacts(tmp_path: Path) -> RunArtifacts:
    device = DeviceInfo(
        name="nvme0n1",
        path="/dev/nvme0n1",
        ctrl_path="/dev/nvme0",
        size_bytes=1000,
        model="Samsung SSD 990 PRO 1TB",
        serial="SER123",
    )
    return RunArtifacts(
        run_id="run-1",
        label="label-1",
        log_dir=tmp_path,
        started_at="2026-03-29T00:00:00+00:00",
        ended_at="2026-03-29T00:10:00+00:00",
        duration_seconds=600.0,
        device=device,
        stage_results={"precheck": StageResult(name="precheck", ok=True)},
        verdict=VerdictResult(verdict="PASS", reasons=[], notes=[], completed=True),
        health_before=HealthSnapshot(),
        health_after=HealthSnapshot(),
        health_deltas={},
        dmesg_issues=[],
    )


def test_run_command_notifies_on_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.cli.run_interactive", lambda **kwargs: _artifacts(tmp_path))
    called: list[tuple[str, bool]] = []
    monkeypatch.setattr("ssdtest.cli._notify_completion", lambda message, success: called.append((message, success)))
    exit_code = main(["run", "--device", "/dev/nvme0n1", "--label", "label", "--report-root", str(tmp_path)])
    assert exit_code == 0
    assert called and called[0][1] is True


def test_run_command_notifies_on_failure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]):
    monkeypatch.setattr("ssdtest.cli.run_interactive", lambda **kwargs: (_ for _ in ()).throw(RuntimeError("boom")))
    called: list[tuple[str, bool]] = []
    monkeypatch.setattr("ssdtest.cli._notify_completion", lambda message, success: called.append((message, success)))
    exit_code = main(["run", "--device", "/dev/nvme0n1", "--label", "label", "--report-root", str(tmp_path)])
    captured = capsys.readouterr()
    assert exit_code == 1
    assert "Error: boom" in captured.out
    assert called and called[0][1] is False


def test_notify_completion_writes_bell(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]):
    monkeypatch.setattr("ssdtest.cli.shutil.which", lambda name: None)
    monkeypatch.setattr("ssdtest.cli.time.sleep", lambda _: None)
    from ssdtest.cli import _notify_completion

    _notify_completion("done", success=True)
    captured = capsys.readouterr()
    assert captured.out.count("\a") == 16


def test_emit_terminal_notifications_prints_osc_sequences(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]):
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    from ssdtest.cli import _emit_terminal_notifications

    _emit_terminal_notifications("test-ssd complete", "SSD test finished")
    captured = capsys.readouterr()
    assert "\033]9;SSD test finished\007" in captured.out
    assert "\033]777;notify;test-ssd complete;SSD test finished\007" in captured.out


def test_ring_audible_alert_repeats_for_configured_duration(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]):
    sleeps: list[float] = []
    monkeypatch.setattr("ssdtest.cli.time.sleep", lambda seconds: sleeps.append(seconds))
    from ssdtest.cli import _ring_audible_alert

    _ring_audible_alert()
    captured = capsys.readouterr()
    assert captured.out.count("\a") == 16
    assert sleeps == [0.5] * 15
