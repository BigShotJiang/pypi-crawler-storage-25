from ssdtest.models import HealthSnapshot, StageResult
from ssdtest.verdicts import build_health_deltas, evaluate_run


def make_stage(name: str, ok: bool = True, allow_failure: bool = False, note: str = "") -> StageResult:
    return StageResult(name=name, ok=ok, allow_failure=allow_failure, note=note)


def test_evaluate_run_passes_clean_drive():
    stages = {
        "precheck": make_stage("precheck"),
        "short_self_test": make_stage("short_self_test"),
        "fio_full_verify": make_stage("fio_full_verify"),
        "fio_burnin": make_stage("fio_burnin"),
        "postcheck": make_stage("postcheck"),
    }
    before = HealthSnapshot(critical_warning=0, percentage_used=1, media_errors=0, num_err_log_entries=0)
    after = HealthSnapshot(critical_warning=0, percentage_used=1, media_errors=0, num_err_log_entries=0)
    verdict = evaluate_run(stages, before, after, [])
    assert verdict.verdict == "PASS"
    assert verdict.completed is True


def test_evaluate_run_fails_on_verify_error():
    stages = {
        "precheck": make_stage("precheck"),
        "short_self_test": make_stage("short_self_test", allow_failure=True),
        "fio_full_verify": make_stage("fio_full_verify", ok=False),
        "fio_burnin": make_stage("fio_burnin"),
        "postcheck": make_stage("postcheck"),
    }
    verdict = evaluate_run(stages, HealthSnapshot(critical_warning=0), HealthSnapshot(critical_warning=0), [])
    assert verdict.verdict == "FAIL"
    assert any("write+verify" in reason for reason in verdict.reasons)


def test_evaluate_run_fails_on_dmesg_issue():
    stages = {
        "precheck": make_stage("precheck"),
        "short_self_test": make_stage("short_self_test"),
        "fio_full_verify": make_stage("fio_full_verify"),
        "fio_burnin": make_stage("fio_burnin"),
        "postcheck": make_stage("postcheck"),
    }
    verdict = evaluate_run(
        stages,
        HealthSnapshot(critical_warning=0, media_errors=0, num_err_log_entries=0),
        HealthSnapshot(critical_warning=0, media_errors=0, num_err_log_entries=0),
        ["nvme0: I/O error"],
    )
    assert verdict.verdict == "FAIL"


def test_evaluate_run_warns_on_unsupported_self_test_and_prior_wear():
    stages = {
        "precheck": make_stage("precheck"),
        "short_self_test": make_stage("short_self_test", ok=False, allow_failure=True, note="short self-test unsupported"),
        "fio_full_verify": make_stage("fio_full_verify"),
        "fio_burnin": make_stage("fio_burnin"),
        "postcheck": make_stage("postcheck"),
    }
    verdict = evaluate_run(
        stages,
        HealthSnapshot(critical_warning=0, percentage_used=7, media_errors=0, num_err_log_entries=0),
        HealthSnapshot(critical_warning=0, percentage_used=7, media_errors=0, num_err_log_entries=0),
        [],
    )
    assert verdict.verdict == "CAUTION"
    assert any("unsupported" in note for note in verdict.notes)


def test_build_health_deltas_computes_host_writes():
    deltas = build_health_deltas(
        HealthSnapshot(data_units_written=100, percentage_used=1, critical_warning=0),
        HealthSnapshot(data_units_written=200, percentage_used=2, critical_warning=0),
    )
    assert deltas["data_units_written_delta"] == 100
    assert deltas["host_writes_tb"] == 0.0 or deltas["host_writes_tb"] == 0.051
