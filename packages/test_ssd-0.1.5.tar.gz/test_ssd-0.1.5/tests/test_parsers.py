from ssdtest.parsers import (
    detect_dmesg_issues,
    merge_health,
    parse_lsblk_pairs,
    parse_nvme_error_log,
    parse_nvme_list,
    parse_nvme_smart_log,
    parse_smartctl_x,
)


NVME_LIST = """Node                  Generic               SN                   Model                                    Namespace  Usage                      Format           FW Rev
--------------------- --------------------- -------------------- ---------------------------------------- ---------- -------------------------- ---------------- --------
/dev/nvme0n1          /dev/ng0n1            S7U8NJ0Y509531K      Samsung SSD 990 EVO Plus 4TB             0x1          4.00  TB /   4.00  TB    512   B +  0 B   2B2QKXG7
/dev/nvme1n1          /dev/ng1n1            511240409209004480   YSR128GHLCV-E3C-1                        0x1        128.04  GB / 128.04  GB    512   B +  0 B   EDFMM0.1
"""

LSBLK_PAIRS = """NAME="nvme0n1" PATH="/dev/nvme0n1" SIZE="4000787030016" MODEL="Samsung SSD 990 EVO Plus 4TB" SERIAL="S7U8NJ0Y509531K" TYPE="disk" MOUNTPOINTS="" PKNAME=""
NAME="nvme1n1" PATH="/dev/nvme1n1" SIZE="128035676160" MODEL="YSR128GHLCV-E3C-1" SERIAL="511240409209004480" TYPE="disk" MOUNTPOINTS="" PKNAME=""
NAME="nvme1n1p1" PATH="/dev/nvme1n1p1" SIZE="2147483648" MODEL="" SERIAL="" TYPE="part" MOUNTPOINTS="/" PKNAME="nvme1n1"
"""

NVME_SMART_LOG = """critical_warning                    : 0
temperature                         : 37 C
available_spare                     : 100%
percentage_used                     : 1%
data_units_written                  : 3,947,821
unsafe_shutdowns                    : 2
media_errors                        : 0
num_err_log_entries                 : 4
"""

SMARTCTL_X = """Critical Warning:                   0x00
Temperature:                        37 Celsius
Available Spare:                    100%
Percentage Used:                    1%
Data Units Written:                 3,947,821 [2.02 TB]
Unsafe Shutdowns:                   2
Media and Data Integrity Errors:    0
Error Information Log Entries:      4
"""

NVME_ERROR_LOG = """Error Log Entries for device:nvme0 entries:64
.................
Entry[ 0]
error_count      : 4
sqid             : 0
cmdid            : 0x0
"""


def test_parse_nvme_list_extracts_rows():
    rows = parse_nvme_list(NVME_LIST)
    assert len(rows) == 2
    assert rows[0]["node"] == "/dev/nvme0n1"
    assert rows[0]["model"] == "Samsung SSD 990 EVO Plus 4TB"
    assert rows[1]["serial"] == "511240409209004480"


def test_parse_lsblk_pairs_extracts_mounts():
    rows = parse_lsblk_pairs(LSBLK_PAIRS)
    assert rows[0]["PATH"] == "/dev/nvme0n1"
    assert rows[2]["TYPE"] == "part"
    assert rows[2]["MOUNTPOINTS"] == "/"


def test_parse_nvme_and_smartctl_health():
    nvme_health = parse_nvme_smart_log(NVME_SMART_LOG)
    smartctl_health = parse_smartctl_x(SMARTCTL_X)
    merged = merge_health(nvme_health, smartctl_health)
    assert merged.critical_warning == 0
    assert merged.temperature_c == 37
    assert merged.data_units_written == 3947821
    assert merged.num_err_log_entries == 4


def test_parse_nvme_error_log_counts_entries():
    summary = parse_nvme_error_log(NVME_ERROR_LOG)
    assert summary["entries_seen"] == 1
    assert summary["max_error_count"] == 4


def test_detect_dmesg_issues_only_returns_new_problem_lines():
    before = "[Sat] nvme0: ready\n"
    after = before + "[Sat] nvme0: I/O error, dev nvme0n1, sector 8\n"
    issues = detect_dmesg_issues(before, after)
    assert len(issues) == 1
    assert "I/O error" in issues[0]
