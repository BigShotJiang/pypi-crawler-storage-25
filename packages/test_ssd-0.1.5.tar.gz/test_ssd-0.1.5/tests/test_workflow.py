from __future__ import annotations

import json
from pathlib import Path

import pytest

from ssdtest.models import CommandResult
from ssdtest.system import inventory_devices
from ssdtest.workflow import run_interactive


def _result(args: list[str], stdout: str = "", stderr: str = "", exit_code: int = 0) -> CommandResult:
    return CommandResult(args=args, stdout=stdout, stderr=stderr, exit_code=exit_code, duration_seconds=0.01)


NVME_LIST = """Node                  Generic               SN                   Model                                    Namespace  Usage                      Format           FW Rev
--------------------- --------------------- -------------------- ---------------------------------------- ---------- -------------------------- ---------------- --------
/dev/nvme0n1          /dev/ng0n1            S7U8NJ0Y509531K      Samsung SSD 990 EVO Plus 4TB             0x1          4.00  TB /   4.00  TB    512   B +  0 B   2B2QKXG7
/dev/nvme1n1          /dev/ng1n1            511240409209004480   YSR128GHLCV-E3C-1                        0x1        128.04  GB / 128.04  GB    512   B +  0 B   EDFMM0.1
"""

LSBLK = """NAME="nvme0n1" PATH="/dev/nvme0n1" SIZE="4000787030016" MODEL="Samsung SSD 990 EVO Plus 4TB" SERIAL="S7U8NJ0Y509531K" TYPE="disk" MOUNTPOINTS="" PKNAME=""
NAME="nvme1n1" PATH="/dev/nvme1n1" SIZE="128035676160" MODEL="YSR128GHLCV-E3C-1" SERIAL="511240409209004480" TYPE="disk" MOUNTPOINTS="" PKNAME=""
NAME="nvme1n1p1" PATH="/dev/nvme1n1p1" SIZE="2147483648" MODEL="" SERIAL="" TYPE="part" MOUNTPOINTS="/" PKNAME="nvme1n1"
"""

NVME_SMART_BEFORE = """critical_warning                    : 0
temperature                         : 35 C
available_spare                     : 100%
percentage_used                     : 1%
data_units_written                  : 1000
unsafe_shutdowns                    : 1
media_errors                        : 0
num_err_log_entries                 : 0
"""

NVME_SMART_AFTER = """critical_warning                    : 0
temperature                         : 40 C
available_spare                     : 100%
percentage_used                     : 1%
data_units_written                  : 9000
unsafe_shutdowns                    : 1
media_errors                        : 0
num_err_log_entries                 : 0
"""

SMARTCTL = """Critical Warning:                   0x00
Temperature:                        35 Celsius
Available Spare:                    100%
Percentage Used:                    1%
Data Units Written:                 1000
Unsafe Shutdowns:                   1
Media and Data Integrity Errors:    0
Error Information Log Entries:      0
"""


class FakeRunner:
    def __init__(self) -> None:
        self.calls: list[list[str]] = []

    def __call__(self, args: list[str]) -> CommandResult:
        self.calls.append(args)
        command = tuple(args[:2])
        if args[:2] == ["which", "smartctl"] or args[:2] == ["which", "nvme"] or args[:2] == ["which", "fio"] or args[:2] == ["which", "lsblk"] or args[:2] == ["which", "dmesg"] or args[:2] == ["which", "mount"] or args[:2] == ["which", "uname"]:
            return _result(args, stdout=f"/usr/bin/{args[1]}\n")
        if args == ["nvme", "list"]:
            return _result(args, stdout=NVME_LIST)
        if args[:2] == ["lsblk", "-P"]:
            return _result(args, stdout=LSBLK)
        if args == ["mount"]:
            return _result(args, stdout="/dev/nvme1n1p1 on / type ext4 (rw)\n")
        if args[:2] == ["uname", "-a"]:
            return _result(args, stdout="Linux test-host\n")
        if args[:2] == ["lsblk", "-o"]:
            return _result(args, stdout="NAME PATH\n")
        if args[:2] == ["dmesg", "-T"]:
            return _result(args, stdout="[Sat] nvme0 ready\n")
        if args[:2] == ["smartctl", "-x"]:
            return _result(args, stdout=SMARTCTL)
        if args[:3] == ["smartctl", "-l", "selftest"]:
            return _result(args, stdout="No self-tests logged\n")
        if args[:2] == ["nvme", "id-ctrl"]:
            return _result(args, stdout="edstt : 12\n")
        if args[:2] == ["nvme", "smart-log"]:
            if len([call for call in self.calls if call[:2] == ["nvme", "smart-log"]]) == 1:
                return _result(args, stdout=NVME_SMART_BEFORE)
            return _result(args, stdout=NVME_SMART_AFTER)
        if args[:2] == ["nvme", "error-log"]:
            return _result(args, stdout="error_count      : 0\n")
        if args[:2] == ["nvme", "self-test-log"]:
            return _result(args, stdout="Current operation: 0\n")
        if args[:2] == ["nvme", "device-self-test"]:
            return _result(args, stdout="Self test completed\n")
        if args[0] == "fio":
            return _result(args, stdout="fio run complete\n")
        raise AssertionError(f"Unexpected command: {args}")


class SmartctlFallbackRunner(FakeRunner):
    def __call__(self, args: list[str]) -> CommandResult:
        if args == ["smartctl", "-x", "/dev/nvme0n1"]:
            self.calls.append(args)
            return _result(args, stderr="Read NVMe Identify Controller failed: bad namespace\n", exit_code=2)
        if args == ["smartctl", "-l", "selftest", "/dev/nvme0n1"]:
            self.calls.append(args)
            return _result(args, stderr="selftest log unavailable on namespace path\n", exit_code=2)
        return super().__call__(args)


def test_inventory_marks_small_system_disk():
    devices, _ = inventory_devices(FakeRunner())
    system_device = next(item for item in devices if item.path == "/dev/nvme1n1")
    target_device = next(item for item in devices if item.path == "/dev/nvme0n1")
    assert system_device.is_system is True
    assert target_device.is_eligible is True


def test_run_interactive_creates_reports(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.workflow.ensure_root", lambda: None)
    runner = FakeRunner()
    answers = iter(["S7U8NJ0Y509531K"])
    artifacts = run_interactive(
        report_root=tmp_path,
        label="bb-refurb-01",
        requested_device=None,
        command_runner=runner,
        input_fn=lambda prompt: next(answers),
    )
    report_json = artifacts.log_dir / "report.json"
    report_md = artifacts.log_dir / "report.md"
    assert report_json.exists()
    assert report_md.exists()
    payload = json.loads(report_json.read_text(encoding="utf-8"))
    assert payload["final"]["verdict"] == "PASS"
    assert payload["device"]["serial"] == "S7U8NJ0Y509531K"
    fio_calls = [call for call in runner.calls if call and call[0] == "fio"]
    assert len(fio_calls) == 2


def test_run_interactive_rejects_bad_serial(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.workflow.ensure_root", lambda: None)
    runner = FakeRunner()
    answers = iter(["", "WRONG", "STILL-WRONG"])
    with pytest.raises(RuntimeError, match="after 3 attempts"):
        run_interactive(
            report_root=tmp_path,
            label="bb-refurb-01",
            requested_device=None,
            command_runner=runner,
            input_fn=lambda prompt: next(answers),
        )


def test_run_interactive_accepts_blank_then_correct_serial(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.workflow.ensure_root", lambda: None)
    runner = FakeRunner()
    answers = iter(["", "S7U8NJ0Y509531K"])
    artifacts = run_interactive(
        report_root=tmp_path,
        label="bb-refurb-01",
        requested_device=None,
        command_runner=runner,
        input_fn=lambda prompt: next(answers),
    )
    assert artifacts.verdict.verdict == "PASS"


def test_run_interactive_falls_back_to_controller_smartctl(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.workflow.ensure_root", lambda: None)
    runner = SmartctlFallbackRunner()
    answers = iter(["S7U8NJ0Y509531K"])
    artifacts = run_interactive(
        report_root=tmp_path,
        label="bb-refurb-01",
        requested_device=None,
        command_runner=runner,
        input_fn=lambda prompt: next(answers),
    )
    assert artifacts.verdict.verdict == "PASS"
    assert ["smartctl", "-x", "/dev/nvme0"] in runner.calls
    assert ["smartctl", "-l", "selftest", "/dev/nvme0"] in runner.calls


def test_run_interactive_marks_unreached_stages_as_skipped(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr("ssdtest.workflow.ensure_root", lambda: None)

    class PrecheckFailRunner(FakeRunner):
        def __call__(self, args: list[str]) -> CommandResult:
            if args == ["smartctl", "-x", "/dev/nvme0n1"]:
                self.calls.append(args)
                return _result(args, stderr="namespace fail\n", exit_code=2)
            if args == ["smartctl", "-x", "/dev/nvme0"]:
                self.calls.append(args)
                return _result(args, stderr="controller fail\n", exit_code=2)
            return super().__call__(args)

    runner = PrecheckFailRunner()
    answers = iter(["S7U8NJ0Y509531K"])
    artifacts = run_interactive(
        report_root=tmp_path,
        label="bb-refurb-01",
        requested_device=None,
        command_runner=runner,
        input_fn=lambda prompt: next(answers),
    )
    assert artifacts.verdict.verdict == "FAIL"
    assert artifacts.stage_results["short_self_test"].skipped is True
    assert "Required stage failed: precheck" in artifacts.verdict.reasons
    assert "fio full-device write+verify did not complete cleanly" not in artifacts.verdict.reasons
