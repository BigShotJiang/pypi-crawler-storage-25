# SSD Test CLI

`test-ssd` is a Python 3 CLI for screening refurbished NVMe SSDs on a UGREEN NAS or another Linux host with `smartctl`, `nvme-cli`, `fio`, `lsblk`, and `dmesg` installed.

## Install

From PyPI:

```bash
pipx install test-ssd
```

or:

```bash
pip install test-ssd
```

From this project directory:

```bash
./install.sh
```

That installs the package into the current Python environment and exposes both `test-ssd` and `ssdtest` as shell commands.

If `~/.local/bin` is not already on your `PATH`, add it once:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

## Commands

```bash
test-ssd scan
test-ssd run --label bb-refurb-01
test-ssd history
test-ssd show <run_id>
```

Module entry point:

```bash
python3 -m ssdtest scan
```

## Notes

- `run` requires root.
- The destructive test writes the full target device.
- Reports default to `/root/nvme-tests` and include raw command outputs, `report.json`, and `report.md`.
