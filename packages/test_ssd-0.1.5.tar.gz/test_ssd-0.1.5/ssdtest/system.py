from __future__ import annotations

import os
import re
import subprocess
import time
from collections import defaultdict
from pathlib import Path

from ssdtest.models import CommandResult, DeviceInfo
from ssdtest.parsers import parse_lsblk_pairs, parse_nvme_list


REQUIRED_COMMANDS = ("smartctl", "nvme", "fio", "lsblk", "dmesg", "mount", "uname")


def run_command(args: list[str], timeout: int | None = None) -> CommandResult:
    started = time.monotonic()
    completed = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
    duration = time.monotonic() - started
    return CommandResult(
        args=list(args),
        stdout=completed.stdout,
        stderr=completed.stderr,
        exit_code=completed.returncode,
        duration_seconds=duration,
    )


def ensure_root() -> None:
    if os.geteuid() != 0:
        raise PermissionError("ssdtest run requires root privileges.")


def ensure_dependencies(command_runner=run_command) -> None:
    missing: list[str] = []
    for name in REQUIRED_COMMANDS:
        result = command_runner(["which", name])
        if not result.ok or not result.stdout.strip():
            missing.append(name)
    if missing:
        raise RuntimeError(f"Missing required commands: {', '.join(missing)}")


def _controller_from_namespace(path: str) -> str:
    name = Path(path).name
    match = re.match(r"^(nvme\d+)n\d+$", name)
    if not match:
        return path
    return f"/dev/{match.group(1)}"


def _split_mountpoints(value: str) -> list[str]:
    if not value:
        return []
    return [item for item in value.split("\n") if item and item != "[SWAP]"]


def inventory_devices(command_runner=run_command) -> tuple[list[DeviceInfo], dict[str, str]]:
    nvme_result = command_runner(["nvme", "list"])
    lsblk_result = command_runner(
        ["lsblk", "-P", "-b", "-o", "NAME,PATH,SIZE,MODEL,SERIAL,TYPE,MOUNTPOINTS,PKNAME"]
    )
    mount_result = command_runner(["mount"])
    if not nvme_result.ok:
        raise RuntimeError(f"nvme list failed: {nvme_result.stderr.strip() or nvme_result.stdout.strip()}")
    if not lsblk_result.ok:
        raise RuntimeError(f"lsblk failed: {lsblk_result.stderr.strip() or lsblk_result.stdout.strip()}")

    nvme_map = {entry["node"]: entry for entry in parse_nvme_list(nvme_result.stdout)}
    lsblk_rows = parse_lsblk_pairs(lsblk_result.stdout)

    child_mounts: dict[str, list[str]] = defaultdict(list)
    rows_by_path: dict[str, dict[str, str]] = {}
    for row in lsblk_rows:
        path = row.get("PATH", "")
        if path:
            rows_by_path[path] = row
        if row.get("TYPE") == "part":
            parent = row.get("PKNAME")
            if parent:
                child_mounts[f"/dev/{parent}"].extend(_split_mountpoints(row.get("MOUNTPOINTS", "")))

    root_mounts = mount_result.stdout if mount_result.ok else ""

    devices: list[DeviceInfo] = []
    for path, row in rows_by_path.items():
        if row.get("TYPE") != "disk" or not path.startswith("/dev/nvme"):
            continue
        merged = nvme_map.get(path, {})
        mountpoints = _split_mountpoints(row.get("MOUNTPOINTS", ""))
        child = child_mounts.get(path, [])
        system_reasons: list[str] = []
        danger_reasons: list[str] = []
        if mountpoints:
            system_reasons.append("device has mounted filesystems")
        if child:
            system_reasons.append("device has mounted child partitions")
        if _appears_in_mount_output(root_mounts, path):
            system_reasons.append("device appears in mount table")

        size_bytes = int(row.get("SIZE", "0") or 0)
        device = DeviceInfo(
            name=row.get("NAME", Path(path).name),
            path=path,
            ctrl_path=_controller_from_namespace(path),
            size_bytes=size_bytes,
            model=(row.get("MODEL") or merged.get("model") or "").strip(),
            serial=(row.get("SERIAL") or merged.get("serial") or "").strip(),
            generic_path=(merged.get("generic") or "").strip(),
            mountpoints=mountpoints,
            child_mountpoints=child,
            system_reasons=system_reasons,
            danger_reasons=danger_reasons,
        )
        devices.append(device)

    _mark_smallest_system_candidate(devices)
    return sorted(devices, key=lambda item: item.path), {
        "nvme_list": nvme_result.stdout,
        "lsblk": lsblk_result.stdout,
        "mount": mount_result.stdout,
    }


def _appears_in_mount_output(mount_output: str, path: str) -> bool:
    if not mount_output.strip():
        return False
    if re.search(rf"^{re.escape(path)}(\b|p\d+\b)", mount_output, re.MULTILINE):
        return True
    return path in mount_output


def _mark_smallest_system_candidate(devices: list[DeviceInfo]) -> None:
    if len(devices) < 2:
        return
    smallest = min(devices, key=lambda item: item.size_bytes or 0)
    second = sorted(devices, key=lambda item: item.size_bytes or 0)[1]
    if smallest.size_bytes and smallest.size_bytes <= 256 * 1024 ** 3 and second.size_bytes >= smallest.size_bytes * 2:
        if "small NVMe likely to be the NAS system disk" not in smallest.system_reasons:
            smallest.system_reasons.append("small NVMe likely to be the NAS system disk")


def select_device(devices: list[DeviceInfo], requested_path: str | None) -> DeviceInfo:
    if requested_path:
        for device in devices:
            if device.path == requested_path:
                return device
        raise ValueError(f"Requested device {requested_path} was not found.")
    eligible = [device for device in devices if device.is_eligible]
    if len(eligible) == 1:
        return eligible[0]
    raise ValueError("Multiple candidate NVMe devices found. Run interactively and pick one device.")
