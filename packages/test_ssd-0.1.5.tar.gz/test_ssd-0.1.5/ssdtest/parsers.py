from __future__ import annotations

import re
import shlex
from typing import Any

from ssdtest.models import HealthSnapshot


def _parse_int(value: str) -> int | None:
    cleaned = value.strip()
    if not cleaned:
        return None
    match = re.search(r"0x[0-9a-fA-F]+|[-+]?\d[\d,]*", cleaned)
    if not match:
        return None
    token = match.group(0).replace(",", "")
    return int(token, 0)


def _parse_percent(value: str) -> int | None:
    match = re.search(r"(\d+)\s*%?", value)
    return int(match.group(1)) if match else None


def _parse_temperature(value: str) -> int | None:
    match = re.search(r"(-?\d+)\s*C", value)
    if match:
        return int(match.group(1))
    return _parse_int(value)


def parse_nvme_list(text: str) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    for line in text.splitlines():
        if not line.strip() or line.startswith("Node") or line.startswith("---"):
            continue
        base = re.match(r"^(?P<node>\S+)\s+(?P<generic>\S+)\s+(?P<serial>\S+)\s+(?P<rest>.+)$", line)
        if not base:
            continue
        extra = re.split(r"\s{2,}", base.group("rest").strip())
        if len(extra) < 5:
            continue
        entries.append(
            {
                "node": base.group("node"),
                "generic": base.group("generic"),
                "serial": base.group("serial"),
                "model": extra[0],
                "namespace": extra[1],
                "usage": extra[2],
                "format": extra[3],
                "fw_rev": extra[4],
            }
        )
    return entries


def parse_lsblk_pairs(text: str) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        record: dict[str, str] = {}
        for token in shlex.split(line):
            if "=" not in token:
                continue
            key, value = token.split("=", 1)
            record[key] = value
        if record:
            records.append(record)
    return records


def parse_nvme_smart_log(text: str) -> HealthSnapshot:
    data: dict[str, Any] = {}
    key_map = {
        "critical_warning": ("critical_warning", _parse_int),
        "temperature": ("temperature_c", _parse_temperature),
        "available_spare": ("available_spare", _parse_percent),
        "percentage_used": ("percentage_used", _parse_percent),
        "data_units_written": ("data_units_written", _parse_int),
        "media_errors": ("media_errors", _parse_int),
        "num_err_log_entries": ("num_err_log_entries", _parse_int),
        "unsafe_shutdowns": ("unsafe_shutdowns", _parse_int),
    }
    for line in text.splitlines():
        if ":" not in line:
            continue
        raw_key, raw_value = line.split(":", 1)
        key = raw_key.strip().lower()
        if key in key_map:
            field_name, parser = key_map[key]
            data[field_name] = parser(raw_value)
    return HealthSnapshot(**data)


def parse_smartctl_x(text: str) -> HealthSnapshot:
    data: dict[str, Any] = {}
    patterns = {
        "critical_warning": (r"Critical Warning:\s*(.+)$", _parse_int),
        "temperature_c": (r"Temperature:\s*(.+)$", _parse_temperature),
        "available_spare": (r"Available Spare:\s*(.+)$", _parse_percent),
        "percentage_used": (r"Percentage Used:\s*(.+)$", _parse_percent),
        "data_units_written": (r"Data Units Written:\s*(.+)$", _parse_int),
        "media_errors": (r"Media and Data Integrity Errors:\s*(.+)$", _parse_int),
        "num_err_log_entries": (r"Error Information Log Entries:\s*(.+)$", _parse_int),
        "unsafe_shutdowns": (r"Unsafe Shutdowns:\s*(.+)$", _parse_int),
    }
    for field_name, (pattern, parser) in patterns.items():
        match = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
        if match:
            data[field_name] = parser(match.group(1))
    return HealthSnapshot(**data)


def merge_health(primary: HealthSnapshot, fallback: HealthSnapshot) -> HealthSnapshot:
    data: dict[str, int | None] = {}
    for field_name in HealthSnapshot.__dataclass_fields__:
        primary_value = getattr(primary, field_name)
        data[field_name] = primary_value if primary_value is not None else getattr(fallback, field_name)
    return HealthSnapshot(**data)


def parse_nvme_error_log(text: str) -> dict[str, int]:
    counts = [_parse_int(match.group(1)) for match in re.finditer(r"error_count\s*:\s*(.+)$", text, re.MULTILINE)]
    clean_counts = [count for count in counts if count is not None]
    return {
        "entries_seen": len(clean_counts),
        "max_error_count": max(clean_counts) if clean_counts else 0,
    }


def extract_new_dmesg_lines(before: str, after: str) -> list[str]:
    before_lines = before.splitlines()
    after_lines = after.splitlines()
    if len(after_lines) >= len(before_lines) and after_lines[: len(before_lines)] == before_lines:
        return after_lines[len(before_lines) :]

    index = 0
    while index < min(len(before_lines), len(after_lines)) and before_lines[index] == after_lines[index]:
        index += 1
    return after_lines[index:]


def detect_dmesg_issues(before: str, after: str) -> list[str]:
    issue_lines: list[str] = []
    patterns = [
        r"\bnvme\d+\b.*\b(reset|timeout|abort|failed|error)\b",
        r"\bI/O error\b",
        r"\bcritical medium error\b",
        r"\bcontroller is down\b",
        r"\bPCIe Bus Error\b",
    ]
    for line in extract_new_dmesg_lines(before, after):
        lowered = line.lower()
        if "nvme" not in lowered and "i/o error" not in lowered and "pcie" not in lowered:
            continue
        if any(re.search(pattern, line, re.IGNORECASE) for pattern in patterns):
            issue_lines.append(line)
    return issue_lines
