from __future__ import annotations

from ssdtest.models import HealthSnapshot, StageResult, VerdictResult


CAUTION_PERCENTAGE_USED = 5
CAUTION_UNSAFE_SHUTDOWNS = 10


def build_health_deltas(before: HealthSnapshot, after: HealthSnapshot) -> dict[str, int | float | None]:
    def delta(field_name: str) -> int | None:
        before_value = getattr(before, field_name)
        after_value = getattr(after, field_name)
        if before_value is None or after_value is None:
            return None
        return after_value - before_value

    data_units_delta = delta("data_units_written")
    host_writes_tb = None
    if data_units_delta is not None:
        host_writes_tb = round(data_units_delta * 512000 / 1e12, 3)

    return {
        "critical_warning_before": before.critical_warning,
        "critical_warning_after": after.critical_warning,
        "media_errors_delta": delta("media_errors"),
        "num_err_log_entries_delta": delta("num_err_log_entries"),
        "unsafe_shutdowns_delta": delta("unsafe_shutdowns"),
        "data_units_written_delta": data_units_delta,
        "host_writes_tb": host_writes_tb,
        "temperature_before": before.temperature_c,
        "temperature_after": after.temperature_c,
        "percentage_used_before": before.percentage_used,
        "percentage_used_after": after.percentage_used,
    }


def evaluate_run(
    stage_results: dict[str, StageResult],
    before: HealthSnapshot,
    after: HealthSnapshot,
    dmesg_issues: list[str],
) -> VerdictResult:
    reasons: list[str] = []
    notes: list[str] = []
    completed = True

    required_failures = [
        stage.name
        for stage in stage_results.values()
        if not stage.ok and not stage.allow_failure and not stage.skipped
    ]
    if required_failures:
        completed = False
        reasons.extend(f"Required stage failed: {name}" for name in required_failures)

    fio_stage = stage_results.get("fio_full_verify")
    if fio_stage and not fio_stage.ok and not fio_stage.skipped:
        reasons.append("fio full-device write+verify did not complete cleanly")
    burnin_stage = stage_results.get("fio_burnin")
    if burnin_stage and not burnin_stage.ok and not burnin_stage.skipped:
        reasons.append("fio random burn-in did not complete cleanly")

    if (after.critical_warning or 0) != 0:
        reasons.append("NVMe critical warning is nonzero after the run")
    if before.critical_warning not in (None, 0):
        reasons.append("NVMe critical warning was already nonzero before the run")

    if dmesg_issues:
        reasons.append("Kernel log shows new NVMe or I/O errors during testing")

    media_delta = _delta(before.media_errors, after.media_errors)
    if media_delta and media_delta > 0:
        reasons.append("media/data integrity errors increased during testing")
    err_delta = _delta(before.num_err_log_entries, after.num_err_log_entries)
    if err_delta and err_delta > 0:
        reasons.append("NVMe error log entry count increased during testing")

    if reasons:
        return VerdictResult(verdict="FAIL", reasons=_dedupe(reasons), notes=_dedupe(notes), completed=completed)

    short_stage = stage_results.get("short_self_test")
    if short_stage and not short_stage.ok:
        notes.append(short_stage.note or "Short self-test did not complete cleanly")
    if before.percentage_used is not None and before.percentage_used >= CAUTION_PERCENTAGE_USED:
        notes.append(
            f"Drive reports prior wear at {before.percentage_used}% used, which exceeds the caution threshold."
        )
    if before.media_errors not in (None, 0):
        notes.append("Drive already had media/data integrity errors before testing.")
    if before.num_err_log_entries not in (None, 0):
        notes.append("Drive already had NVMe error log entries before testing.")
    if before.unsafe_shutdowns is not None and before.unsafe_shutdowns >= CAUTION_UNSAFE_SHUTDOWNS:
        notes.append(
            f"Drive reports {before.unsafe_shutdowns} unsafe shutdowns before testing, which exceeds the caution threshold."
        )

    verdict = "CAUTION" if notes else "PASS"
    return VerdictResult(verdict=verdict, reasons=[], notes=_dedupe(notes), completed=completed)


def _delta(before: int | None, after: int | None) -> int | None:
    if before is None or after is None:
        return None
    return after - before


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result
