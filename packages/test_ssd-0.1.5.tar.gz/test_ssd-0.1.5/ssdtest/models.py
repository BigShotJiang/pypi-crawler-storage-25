from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class CommandResult:
    args: list[str]
    stdout: str
    stderr: str
    exit_code: int
    duration_seconds: float

    @property
    def ok(self) -> bool:
        return self.exit_code == 0


@dataclass(slots=True)
class DeviceInfo:
    name: str
    path: str
    ctrl_path: str
    size_bytes: int
    model: str
    serial: str
    generic_path: str = ""
    mountpoints: list[str] = field(default_factory=list)
    child_mountpoints: list[str] = field(default_factory=list)
    system_reasons: list[str] = field(default_factory=list)
    danger_reasons: list[str] = field(default_factory=list)

    @property
    def size_gib(self) -> float:
        return self.size_bytes / (1024 ** 3)

    @property
    def mounted(self) -> bool:
        return bool(self.mountpoints)

    @property
    def has_mounted_children(self) -> bool:
        return bool(self.child_mountpoints)

    @property
    def is_system(self) -> bool:
        return bool(self.system_reasons)

    @property
    def is_eligible(self) -> bool:
        return not self.danger_reasons and not self.is_system


@dataclass(slots=True)
class HealthSnapshot:
    critical_warning: int | None = None
    temperature_c: int | None = None
    available_spare: int | None = None
    percentage_used: int | None = None
    data_units_written: int | None = None
    media_errors: int | None = None
    num_err_log_entries: int | None = None
    unsafe_shutdowns: int | None = None

    def as_dict(self) -> dict[str, int | None]:
        return {
            "critical_warning": self.critical_warning,
            "temperature_c": self.temperature_c,
            "available_spare": self.available_spare,
            "percentage_used": self.percentage_used,
            "data_units_written": self.data_units_written,
            "media_errors": self.media_errors,
            "num_err_log_entries": self.num_err_log_entries,
            "unsafe_shutdowns": self.unsafe_shutdowns,
        }


@dataclass(slots=True)
class StageResult:
    name: str
    ok: bool
    skipped: bool = False
    allow_failure: bool = False
    exit_code: int | None = None
    duration_seconds: float = 0.0
    command: list[str] = field(default_factory=list)
    log_file: str = ""
    note: str = ""

    def as_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "ok": self.ok,
            "skipped": self.skipped,
            "allow_failure": self.allow_failure,
            "exit_code": self.exit_code,
            "duration_seconds": round(self.duration_seconds, 3),
            "command": self.command,
            "log_file": self.log_file,
            "note": self.note,
        }


@dataclass(slots=True)
class VerdictResult:
    verdict: str
    reasons: list[str]
    notes: list[str]
    completed: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "verdict": self.verdict,
            "reasons": self.reasons,
            "notes": self.notes,
            "completed": self.completed,
        }


@dataclass(slots=True)
class RunArtifacts:
    run_id: str
    label: str
    log_dir: Path
    started_at: str
    ended_at: str
    duration_seconds: float
    device: DeviceInfo
    stage_results: dict[str, StageResult]
    verdict: VerdictResult
    health_before: HealthSnapshot
    health_after: HealthSnapshot
    health_deltas: dict[str, int | float | None]
    dmesg_issues: list[str]
