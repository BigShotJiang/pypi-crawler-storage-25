from __future__ import annotations

import json
from pathlib import Path

from ssdtest.models import RunArtifacts


def write_report_files(artifacts: RunArtifacts) -> tuple[Path, Path]:
    json_path = artifacts.log_dir / "report.json"
    md_path = artifacts.log_dir / "report.md"
    json_path.write_text(json.dumps(build_report_payload(artifacts), indent=2) + "\n", encoding="utf-8")
    md_path.write_text(build_markdown_report(artifacts), encoding="utf-8")
    return json_path, md_path


def build_report_payload(artifacts: RunArtifacts) -> dict[str, object]:
    return {
        "run_id": artifacts.run_id,
        "label": artifacts.label,
        "started_at": artifacts.started_at,
        "ended_at": artifacts.ended_at,
        "duration_seconds": round(artifacts.duration_seconds, 3),
        "completed": artifacts.verdict.completed,
        "device": {
            "dev": artifacts.device.path,
            "ctrl": artifacts.device.ctrl_path,
            "model": artifacts.device.model,
            "serial": artifacts.device.serial,
            "size_bytes": artifacts.device.size_bytes,
        },
        "stage_results": {name: stage.as_dict() for name, stage in artifacts.stage_results.items()},
        "health_before": artifacts.health_before.as_dict(),
        "health_after": artifacts.health_after.as_dict(),
        "health_deltas": artifacts.health_deltas,
        "dmesg_issues": artifacts.dmesg_issues,
        "final": artifacts.verdict.as_dict(),
    }


def build_markdown_report(artifacts: RunArtifacts) -> str:
    verdict = artifacts.verdict
    stage_lines = [
        f"- `{name}`: {'OK' if stage.ok else 'FAILED'}"
        + (f" ({stage.note})" if stage.note else "")
        + (f" [{stage.log_file}]" if stage.log_file else "")
        for name, stage in artifacts.stage_results.items()
    ]
    reason_lines = verdict.reasons or ["- None"]
    note_lines = verdict.notes or ["- None"]
    if verdict.reasons:
        reason_lines = [f"- {item}" for item in verdict.reasons]
    if verdict.notes:
        note_lines = [f"- {item}" for item in verdict.notes]
    dmesg_lines = [f"- {line}" for line in artifacts.dmesg_issues] or ["- None"]
    health = artifacts.health_deltas
    return "\n".join(
        [
            f"# SSD Test Report: {artifacts.label}",
            "",
            f"- Verdict: **{verdict.verdict}**",
            f"- Completed: **{'yes' if verdict.completed else 'no'}**",
            f"- Run ID: `{artifacts.run_id}`",
            f"- Device: `{artifacts.device.path}`",
            f"- Controller: `{artifacts.device.ctrl_path}`",
            f"- Model: `{artifacts.device.model}`",
            f"- Serial: `{artifacts.device.serial}`",
            f"- Size: `{artifacts.device.size_bytes}` bytes",
            f"- Started: `{artifacts.started_at}`",
            f"- Ended: `{artifacts.ended_at}`",
            f"- Duration: `{round(artifacts.duration_seconds, 1)}` seconds",
            "",
            "## Reasons",
            *reason_lines,
            "",
            "## Notes",
            *note_lines,
            "",
            "## Stage Results",
            *stage_lines,
            "",
            "## Health Deltas",
            f"- critical warning: {health.get('critical_warning_before')} -> {health.get('critical_warning_after')}",
            f"- media errors delta: {health.get('media_errors_delta')}",
            f"- error log entries delta: {health.get('num_err_log_entries_delta')}",
            f"- unsafe shutdowns delta: {health.get('unsafe_shutdowns_delta')}",
            f"- data units written delta: {health.get('data_units_written_delta')}",
            f"- host writes added (TB): {health.get('host_writes_tb')}",
            f"- temperature (C): {health.get('temperature_before')} -> {health.get('temperature_after')}",
            f"- percentage used: {health.get('percentage_used_before')} -> {health.get('percentage_used_after')}",
            "",
            "## Kernel Issues",
            *dmesg_lines,
            "",
        ]
    )


def load_history(report_root: Path) -> list[dict[str, object]]:
    if not report_root.exists():
        return []
    records: list[dict[str, object]] = []
    for json_path in sorted(report_root.glob("*/report.json")):
        try:
            payload = json.loads(json_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        payload["_report_path"] = json_path
        records.append(payload)
    records.sort(key=lambda item: str(item.get("started_at", "")), reverse=True)
    return records


def find_report(report_root: Path, run_id: str) -> dict[str, object]:
    for record in load_history(report_root):
        if record.get("run_id") == run_id:
            return record
    raise FileNotFoundError(f"Run {run_id} not found under {report_root}")
