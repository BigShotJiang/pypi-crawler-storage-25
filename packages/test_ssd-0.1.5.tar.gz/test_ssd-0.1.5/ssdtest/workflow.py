from __future__ import annotations

import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from ssdtest.models import CommandResult, DeviceInfo, HealthSnapshot, RunArtifacts, StageResult
from ssdtest.parsers import (
    detect_dmesg_issues,
    merge_health,
    parse_nvme_error_log,
    parse_nvme_smart_log,
    parse_smartctl_x,
)
from ssdtest.reports import write_report_files
from ssdtest.system import ensure_dependencies, ensure_root, inventory_devices, run_command, select_device
from ssdtest.verdicts import build_health_deltas, evaluate_run


CommandRunner = Callable[[list[str]], CommandResult]
InputFn = Callable[[str], str]


def run_interactive(
    report_root: Path,
    label: str | None,
    requested_device: str | None,
    command_runner: CommandRunner = run_command,
    input_fn: InputFn = input,
) -> RunArtifacts:
    ensure_root()
    ensure_dependencies(command_runner)
    devices, raw_inventory = inventory_devices(command_runner)
    device = _pick_device(devices, requested_device, input_fn)
    if device.is_system:
        raise RuntimeError(f"Refusing to test {device.path}: {'; '.join(device.system_reasons)}")
    if device.danger_reasons:
        raise RuntimeError(f"Refusing to test {device.path}: {'; '.join(device.danger_reasons)}")

    chosen_label = sanitize_label(label or device.serial or device.name)
    started = datetime.now(timezone.utc)
    run_id = f"{chosen_label}-{started.strftime('%Y%m%d-%H%M%S')}"
    log_dir = report_root / run_id
    log_dir.mkdir(parents=True, exist_ok=True)

    _write_text(log_dir / "00-nvme-list.txt", raw_inventory["nvme_list"])
    _write_text(log_dir / "01-lsblk-disks.txt", raw_inventory["lsblk"])
    _write_text(log_dir / "02-mount.txt", raw_inventory["mount"])

    stage_results: dict[str, StageResult] = {}
    notes: list[str] = []
    health_before = HealthSnapshot()
    health_after = HealthSnapshot()
    dmesg_issues: list[str] = []

    print_device_banner(device)
    _confirm_destructive_run(device, input_fn)

    before_logs: dict[str, CommandResult] = {}
    after_logs: dict[str, CommandResult] = {}

    try:
        stage_results["precheck"], before_logs = _capture_pretest(log_dir, device, command_runner)
        if not stage_results["precheck"].ok:
            raise RuntimeError(stage_results["precheck"].note or "Precheck failed.")
        stage_results["short_self_test"] = _run_short_self_test(log_dir, device, command_runner)
        stage_results["fio_full_verify"] = _run_stage(
            name="fio_full_verify",
            command=[
                "fio",
                "--name=full_write_verify",
                f"--filename={device.path}",
                "--direct=1",
                "--ioengine=libaio",
                "--iodepth=32",
                "--rw=write",
                "--bs=4M",
                "--numjobs=1",
                "--end_fsync=1",
                "--verify=crc32c",
                "--do_verify=1",
                "--verify_fatal=1",
                "--group_reporting=1",
            ],
            log_dir=log_dir,
            filename="20-fio-full-write-verify.txt",
            command_runner=command_runner,
        )
        stage_results["fio_burnin"] = _run_stage(
            name="fio_burnin",
            command=[
                "fio",
                "--name=randrw_burnin",
                f"--filename={device.path}",
                "--direct=1",
                "--ioengine=libaio",
                "--iodepth=32",
                "--rw=randrw",
                "--rwmixread=70",
                "--bs=4k",
                "--size=20%",
                "--time_based=1",
                "--runtime=30m",
                "--group_reporting=1",
            ],
            log_dir=log_dir,
            filename="21-fio-randrw-burnin.txt",
            command_runner=command_runner,
        )
        stage_results["postcheck"], after_logs = _capture_posttest(log_dir, device, command_runner)
    except Exception as exc:
        notes.append(str(exc))
        missing = {"precheck", "short_self_test", "fio_full_verify", "fio_burnin", "postcheck"} - set(stage_results)
        for name in missing:
            stage_results[name] = StageResult(name=name, ok=False, skipped=True, note="not reached due to earlier failure")
    else:
        health_before = merge_health(
            parse_nvme_smart_log(before_logs["nvme_smart"].stdout),
            parse_smartctl_x(before_logs["smart"].stdout),
        )
        health_after = merge_health(
            parse_nvme_smart_log(after_logs["nvme_smart"].stdout),
            parse_smartctl_x(after_logs["smart"].stdout),
        )
        dmesg_issues = detect_dmesg_issues(before_logs["dmesg"].stdout, after_logs["dmesg"].stdout)
        error_before = parse_nvme_error_log(before_logs["error_log"].stdout)
        error_after = parse_nvme_error_log(after_logs["error_log"].stdout)
        if error_after["max_error_count"] > error_before["max_error_count"]:
            dmesg_issues.append("NVMe error log recorded a higher error_count after the run.")

    ended = datetime.now(timezone.utc)
    verdict = evaluate_run(stage_results, health_before, health_after, dmesg_issues)
    verdict.notes.extend(item for item in notes if item not in verdict.notes)
    artifacts = RunArtifacts(
        run_id=run_id,
        label=chosen_label,
        log_dir=log_dir,
        started_at=started.isoformat(),
        ended_at=ended.isoformat(),
        duration_seconds=(ended - started).total_seconds(),
        device=device,
        stage_results=stage_results,
        verdict=verdict,
        health_before=health_before,
        health_after=health_after,
        health_deltas=build_health_deltas(health_before, health_after),
        dmesg_issues=dmesg_issues,
    )
    write_report_files(artifacts)
    _maybe_run_extended_self_test(artifacts, command_runner, input_fn)
    return artifacts


def sanitize_label(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9._-]+", "-", value.strip()).strip("-")
    return cleaned or "ssd-test"


def print_device_banner(device: DeviceInfo) -> None:
    print("Selected device:")
    print(f"  path:   {device.path}")
    print(f"  ctrl:   {device.ctrl_path}")
    print(f"  model:  {device.model}")
    print(f"  serial: {device.serial}")
    print(f"  size:   {device.size_gib:.1f} GiB")


def _pick_device(devices: list[DeviceInfo], requested_device: str | None, input_fn: InputFn) -> DeviceInfo:
    if requested_device:
        return select_device(devices, requested_device)

    eligible = [device for device in devices if device.is_eligible]
    if len(eligible) == 1:
        return eligible[0]
    if not eligible:
        raise RuntimeError("No eligible NVMe devices were found to test.")

    print("Available NVMe devices:")
    for index, device in enumerate(devices, start=1):
        flags = []
        if device.is_system:
            flags.append("system")
        if device.danger_reasons:
            flags.append("danger")
        if not flags:
            flags.append("candidate")
        print(
            f"  [{index}] {device.path}  {device.size_gib:.1f} GiB  {device.model}  "
            f"{device.serial}  ({', '.join(flags)})"
        )
    choice = input_fn("Select a device by number: ").strip()
    if not choice.isdigit():
        raise RuntimeError("Selection must be a numeric index.")
    index = int(choice) - 1
    if index < 0 or index >= len(devices):
        raise RuntimeError("Selected index is out of range.")
    return devices[index]


def _confirm_destructive_run(device: DeviceInfo, input_fn: InputFn) -> None:
    print("")
    print("WARNING: This workflow performs a destructive full-device write and verify.")
    print("Type the exact SSD serial number shown below to continue.")
    print(f"Expected serial: {device.serial}")
    for attempt in range(1, 4):
        typed = input_fn("Serial confirmation: ").strip()
        if typed == device.serial:
            return
        if not typed:
            print(f"Confirmation was empty. {4 - attempt} attempt(s) remaining.")
        else:
            print(f"Confirmation did not match. {4 - attempt} attempt(s) remaining.")
    raise RuntimeError("Serial confirmation did not match the selected drive after 3 attempts.")


def _capture_pretest(log_dir: Path, device: DeviceInfo, command_runner: CommandRunner) -> tuple[StageResult, dict[str, CommandResult]]:
    results = {
        "uname": _run_stage("precheck", ["uname", "-a"], log_dir, "03-uname.txt", command_runner),
        "target_lsblk": _run_stage(
            "precheck",
            ["lsblk", "-o", "NAME,PATH,SIZE,FSTYPE,MOUNTPOINTS,MODEL,SERIAL", device.path],
            log_dir,
            "04-target-lsblk.txt",
            command_runner,
        ),
        "dmesg": _run_stage("precheck", ["dmesg", "-T"], log_dir, "05-dmesg-before.txt", command_runner),
        "smart": _run_smartctl_with_fallback(
            device=device,
            smart_args=["-x"],
            log_dir=log_dir,
            filename="06-smart-before.txt",
            command_runner=command_runner,
        ),
        "id_ctrl": _run_stage("precheck", ["nvme", "id-ctrl", device.ctrl_path], log_dir, "07-id-ctrl.txt", command_runner),
        "nvme_smart": _run_stage(
            "precheck", ["nvme", "smart-log", device.ctrl_path], log_dir, "08-nvme-smart-before.txt", command_runner
        ),
        "error_log": _run_stage(
            "precheck", ["nvme", "error-log", device.ctrl_path], log_dir, "09-error-before.txt", command_runner
        ),
        "self_test_log": _run_stage(
            "precheck",
            ["nvme", "self-test-log", device.ctrl_path],
            log_dir,
            "10-selftest-before.txt",
            command_runner,
            allow_failure=True,
        ),
    }
    failed = [name for name, result in results.items() if not result.ok and name != "self_test_log"]
    stage = StageResult(
        name="precheck",
        ok=not failed,
        exit_code=0 if not failed else 1,
        duration_seconds=sum(result.duration_seconds for result in results.values()),
        command=["precheck"],
        note="" if not failed else f"failed commands: {', '.join(failed)}",
    )
    return stage, results


def _capture_posttest(log_dir: Path, device: DeviceInfo, command_runner: CommandRunner) -> tuple[StageResult, dict[str, CommandResult]]:
    results = {
        "dmesg": _run_stage("postcheck", ["dmesg", "-T"], log_dir, "30-dmesg-after.txt", command_runner),
        "smart": _run_smartctl_with_fallback(
            device=device,
            smart_args=["-x"],
            log_dir=log_dir,
            filename="31-smart-after.txt",
            command_runner=command_runner,
        ),
        "nvme_smart": _run_stage(
            "postcheck", ["nvme", "smart-log", device.ctrl_path], log_dir, "32-nvme-smart-after.txt", command_runner
        ),
        "error_log": _run_stage(
            "postcheck", ["nvme", "error-log", device.ctrl_path], log_dir, "33-error-after.txt", command_runner
        ),
        "self_test_log": _run_stage(
            "postcheck",
            ["nvme", "self-test-log", device.ctrl_path],
            log_dir,
            "34-selftest-after.txt",
            command_runner,
            allow_failure=True,
        ),
    }
    failed = [name for name, result in results.items() if not result.ok and name != "self_test_log"]
    stage = StageResult(
        name="postcheck",
        ok=not failed,
        exit_code=0 if not failed else 1,
        duration_seconds=sum(result.duration_seconds for result in results.values()),
        command=["postcheck"],
        note="" if not failed else f"failed commands: {', '.join(failed)}",
    )
    return stage, results


def _run_short_self_test(log_dir: Path, device: DeviceInfo, command_runner: CommandRunner) -> StageResult:
    print(f"Running short_self_test: nvme device-self-test {device.ctrl_path} -s 1 -w", file=sys.stderr)
    result = command_runner(["nvme", "device-self-test", device.ctrl_path, "-s", "1", "-w"])
    _write_result(log_dir / "11-short-selftest-run.txt", result)
    followup = _run_smartctl_with_fallback(
        device=device,
        smart_args=["-l", "selftest"],
        log_dir=log_dir,
        filename="12-smart-selftest-log.txt",
        command_runner=command_runner,
    )
    unsupported_text = f"{result.stdout}\n{result.stderr}\n{followup.stdout}\n{followup.stderr}".lower()
    stage = StageResult(
        name="short_self_test",
        ok=result.ok,
        allow_failure=True,
        exit_code=result.exit_code,
        duration_seconds=result.duration_seconds + followup.duration_seconds,
        command=["nvme", "device-self-test", device.ctrl_path, "-s", "1", "-w"],
        log_file="11-short-selftest-run.txt",
    )
    if result.ok:
        stage.note = "short self-test completed"
        return stage
    if "unsupported" in unsupported_text or "invalid opcode" in unsupported_text:
        stage.note = "short self-test unsupported"
        return stage
    stage.note = "short self-test failed or returned an indeterminate result"
    return stage


def _run_stage(
    name: str,
    command: list[str],
    log_dir: Path,
    filename: str,
    command_runner: CommandRunner,
    allow_failure: bool = False,
) -> CommandResult | StageResult:
    print(f"Running {name}: {' '.join(command)}", file=sys.stderr)
    result = command_runner(command)
    _write_result(log_dir / filename, result)
    stage = StageResult(
        name=name,
        ok=result.ok,
        allow_failure=allow_failure,
        exit_code=result.exit_code,
        duration_seconds=result.duration_seconds,
        command=command,
        log_file=filename,
    )
    if name in {"precheck", "postcheck"}:
        return result
    return stage


def _run_smartctl_with_fallback(
    device: DeviceInfo,
    smart_args: list[str],
    log_dir: Path,
    filename: str,
    command_runner: CommandRunner,
) -> CommandResult:
    primary_command = ["smartctl", *smart_args, device.path]
    print(f"Running smartctl: {' '.join(primary_command)}", file=sys.stderr)
    primary_result = command_runner(primary_command)
    if primary_result.ok:
        _write_result(log_dir / filename, primary_result)
        return primary_result

    fallback_command = ["smartctl", *smart_args, device.ctrl_path]
    print(f"Running smartctl fallback: {' '.join(fallback_command)}", file=sys.stderr)
    fallback_result = command_runner(fallback_command)
    if fallback_result.ok:
        combined = CommandResult(
            args=fallback_command,
            stdout=fallback_result.stdout,
            stderr=(
                "Primary smartctl command failed and controller-path fallback succeeded.\n"
                f"Primary command: {' '.join(primary_command)}\n"
                f"Primary exit code: {primary_result.exit_code}\n"
                f"Primary stderr:\n{primary_result.stderr.rstrip()}\n\n"
                f"Fallback command: {' '.join(fallback_command)}\n"
                f"Fallback exit code: {fallback_result.exit_code}\n"
                f"Fallback stderr:\n{fallback_result.stderr.rstrip()}"
            ).rstrip()
            + "\n",
            exit_code=0,
            duration_seconds=primary_result.duration_seconds + fallback_result.duration_seconds,
        )
        _write_result(log_dir / filename, combined)
        return combined

    combined_failure = CommandResult(
        args=primary_command,
        stdout=primary_result.stdout,
        stderr=(
            "Both smartctl namespace and controller-path commands failed.\n"
            f"Primary command: {' '.join(primary_command)}\n"
            f"Primary exit code: {primary_result.exit_code}\n"
            f"Primary stderr:\n{primary_result.stderr.rstrip()}\n\n"
            f"Fallback command: {' '.join(fallback_command)}\n"
            f"Fallback exit code: {fallback_result.exit_code}\n"
            f"Fallback stderr:\n{fallback_result.stderr.rstrip()}"
        ).rstrip()
        + "\n",
        exit_code=primary_result.exit_code or fallback_result.exit_code or 1,
        duration_seconds=primary_result.duration_seconds + fallback_result.duration_seconds,
    )
    _write_result(log_dir / filename, combined_failure)
    return combined_failure


def _write_result(path: Path, result: CommandResult) -> None:
    body = [
        f"# command: {' '.join(result.args)}",
        f"# exit_code: {result.exit_code}",
        f"# duration_seconds: {result.duration_seconds:.3f}",
        "",
        "## stdout",
        result.stdout.rstrip(),
        "",
        "## stderr",
        result.stderr.rstrip(),
        "",
    ]
    _write_text(path, "\n".join(body))


def _write_text(path: Path, text: str) -> None:
    path.write_text(text if text.endswith("\n") else text + "\n", encoding="utf-8")


def _maybe_run_extended_self_test(
    artifacts: RunArtifacts,
    command_runner: CommandRunner,
    input_fn: InputFn,
) -> None:
    if artifacts.verdict.verdict != "CAUTION":
        return
    response = input_fn("Run extended self-test now? [y/N]: ").strip().lower()
    if response not in {"y", "yes"}:
        return
    _run_stage(
        name="extended_self_test",
        command=["nvme", "device-self-test", artifacts.device.ctrl_path, "-s", "2", "-w"],
        log_dir=artifacts.log_dir,
        filename="50-extended-selftest-run.txt",
        command_runner=command_runner,
        allow_failure=True,
    )
    _run_stage(
        name="extended_self_test",
        command=["nvme", "self-test-log", artifacts.device.ctrl_path],
        log_dir=artifacts.log_dir,
        filename="51-extended-selftest-log.txt",
        command_runner=command_runner,
        allow_failure=True,
    )
