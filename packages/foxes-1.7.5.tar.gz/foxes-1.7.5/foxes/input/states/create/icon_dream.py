import argparse
import numpy as np
from xarray import Dataset
from pandas import DataFrame
from pathlib import Path
from tqdm.autonotebook import tqdm
from shutil import rmtree

from foxes.core import get_engine, Engine
from foxes.config import config
from foxes.utils import write_nc, import_module, download_file
from foxes.data import StaticData, STATES
import foxes.variables as FV


def _rm_tmp_dir(cdo_tmp_dir, verbosity=1):
    """Remove the temporary directory for CDO intermediate files."""
    if cdo_tmp_dir.exists():
        if verbosity > 0:
            print("Removing tmp directory", cdo_tmp_dir)
        rmtree(cdo_tmp_dir)


def _get_file_var_str(var, for_fname=False):
    """Get the variable string for the filename based on the variable code."""
    var_str = {
        FV.U: "U",
        FV.V: "V",
        FV.TKE: "TKE",
        FV.p: "P",
        FV.T: "T",
        None: "",
    }[var]
    if for_fname and var is not None:
        var_str = f"_{var_str}"
    return var_str


def _get_fname(year, month, var=None, region=None, suffix="nc"):
    """Construct the filename for a given year, month, and variable."""
    ym_str = f"{year}{month:02d}"
    var_str = _get_file_var_str(var, for_fname=True)
    region_str = f"_{region}" if region is not None else ""
    return f"ICON-DREAM-EU_{ym_str}{region_str}{var_str}_hourly.{suffix}"


def _download_icon_dream(ymv, base_url, out_dir, verbosity=1):
    """Download a file from ICON-DREAM-EU for a given year, month, and variable."""
    year, month, var = ymv
    fname = _get_fname(year, month, var, region=None, suffix="grb")
    var_str = _get_file_var_str(var)
    url = f"{base_url}/{var_str}/{fname}"
    var_dir = out_dir / var_str
    var_dir.mkdir(parents=True, exist_ok=True)
    out_path = var_dir / fname
    return download_file(url, out_path, verbosity=verbosity)


def _prepare_grid(
    path_grid_select,
    path_icon_grid,
    path_weights_out,
    url_icon_grid,
    cdo_tmp_dir,
    verbosity=1,
):
    """Download and prepare grid files for remapping."""
    if path_weights_out.is_file():
        return 0  # Already present
    if download_file(url_icon_grid, path_icon_grid, verbosity=verbosity) < 0:
        return -1  # Indicate failure

    Cdo = import_module(
        "cdo",
        pip_hint="pip install cdo",
        conda_hint="conda install -c conda-forge cdo",
    ).Cdo
    cdo = Cdo(tempdir=str(cdo_tmp_dir))

    try:
        cdo.gencon(
            path_grid_select, input=f"{path_icon_grid}", output=str(path_weights_out)
        )
    except Exception as e:
        if verbosity > 3:
            _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
            raise e
        elif verbosity > 1:
            print(f"Generating grid weights failed with exception {e}")
        elif verbosity > 0:
            print("Generating grid weights failed.")
        return -1  # Indicate failure

    return 1  # Indicate success


def _check_grb(
    year,
    month,
    grb_dir,
    var2ncvar,
    cdo_tmp_dir,
    verbosity=1,
):
    """Check dimensions of the grb files for a given year and month."""
    Cdo = import_module(
        "cdo",
        pip_hint="pip install cdo",
        conda_hint="conda install -c conda-forge cdo",
    ).Cdo
    cdo = Cdo(tempdir=str(cdo_tmp_dir))

    dms = None
    valid = []
    fname = []
    reason = []
    details = []
    for var, vname in var2ncvar.items():
        grb_fname = _get_fname(year, month, var, region=None, suffix="grb")
        grb_path = grb_dir / _get_file_var_str(var) / grb_fname
        if verbosity > 2:
            print(f"{grb_fname}: Starting check")

        # check file exists:
        if not grb_path.exists():
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise FileNotFoundError(f"File {grb_path} not found.")
            elif verbosity > 1:
                print(f"{grb_fname}: Check FAILED, file not found.")
            valid.append(False)
            fname.append(grb_fname)
            reason.append("missing")
            details.append("File not found")
            continue

        # check dimensions:

        if verbosity > 2:
            print(f"{grb_fname}: Reading file")
        try:
            data = cdo.selvar(vname, input=str(grb_path), returnXArray=vname)
        except Exception as e:
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise e
            elif verbosity > 2:
                print(
                    f"{grb_fname}: Selecting variable '{vname}' failed with exception {e}"
                )
            elif verbosity > 1:
                print(f"{grb_fname}: Selecting variable '{vname}' failed.")
            valid.append(False)
            fname.append(grb_fname)
            reason.append("cdo")
            details.append(f"cdo.selvar failed for variable '{vname}'")
            continue

        hdms = list(data.sizes.keys())
        try:
            assert hdms == ["time", "height", "ncells"], (
                f"{grb_fname}: Unexpected dimensions {hdms}, expected ['time', 'height', 'ncells']."
            )
        except Exception as e:
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise e
            elif verbosity > 2:
                print(f"{grb_fname}: Check FAILED with exception {e}")
            elif verbosity > 1:
                print(f"{grb_fname}: Check FAILED.")
            valid.append(False)
            fname.append(grb_fname)
            reason.append("coords")
            details.append(f"Unexpected dimensions {hdms}")
            continue

        if dms is None:
            dms = {c: s for c, s in data.sizes.items()}
            if var == FV.TKE:
                dms["height"] += 1
            if verbosity > 2:
                print(f"{grb_fname}: Dimensions are {dms}")

        for dim, size in dms.items():
            try:
                if var == FV.TKE and dim == "height":
                    assert data.sizes["height"] == size + 1, (
                        f"{grb_fname}: Dimension mismatch for TKE, expected height to be {size + 1}, got {data.sizes['height']}."
                    )
                else:
                    assert data.sizes[dim] == size, (
                        f"{grb_fname}: Dimension mismatch for {dim}, expected {size}, got {data.sizes[dim]}."
                    )
            except Exception as e:
                if verbosity > 3:
                    _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                    raise e
                elif verbosity > 2:
                    print(f"{grb_fname}: Check FAILED with exception {e}")
                elif verbosity > 1:
                    print(f"{grb_fname}: Check FAILED.")
                valid.append(False)
                fname.append(grb_fname)
                reason.append("shape")
                details.append(f"Size mismatch for {dim}: {size} vs {data.sizes[dim]}")
                continue

        if verbosity > 3:
            print(f"{grb_fname}: Dimensions match {data.sizes}.")
            print(f"{grb_fname}: Checks OK")
        valid.append(True)
        fname.append(grb_fname)
        reason.append("ok")
        details.append("")

    return valid, fname, reason, details


def _process(
    region,
    year,
    month,
    grb_dir,
    nc_dir,
    var2ncvar,
    levels,
    path_grid_select,
    path_grid_weights,
    check_nans=True,
    pack=True,
    cdo_tmp_dir="cdo_tmp",
    verbosity=1,
):
    """Process grb files and convert to NetCDF."""
    nc_fname = _get_fname(year, month, var=None, region=region, suffix="nc")
    nc_path = nc_dir / nc_fname
    if nc_path.exists():
        return 0  # Indicate already processed

    Cdo = import_module(
        "cdo",
        pip_hint="pip install cdo",
        conda_hint="conda install -c conda-forge cdo",
    ).Cdo
    cdo = Cdo(tempdir=str(cdo_tmp_dir))

    data = {}
    for var, vname in var2ncvar.items():
        grb_fname = _get_fname(year, month, var, region=None, suffix="grb")
        grb_path = grb_dir / _get_file_var_str(var) / grb_fname
        if verbosity > 0:
            print(f"Processing {grb_fname}")

        if not grb_path.exists():
            if verbosity > 1:
                print(f"File {grb_path} not found, skipping.")
            return -1  # Indicate failure

        # select levels:
        if verbosity > 2:
            print(f"{grb_fname}: Selecting levels")
        lvls = levels if var != "TKE" else levels + [levels[-1] + 1]
        lvls = ",".join(str(lv) for lv in lvls)
        try:
            temp = cdo.sellevel(lvls, input=str(grb_path), returnXArray=vname)
        except Exception as e:
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise e
            elif verbosity > 2:
                print(f"{grb_fname}: Selecting levels failed with exception {e}")
            elif verbosity > 1:
                print(f"{grb_fname}: Selecting levels failed, skipping.")
            return -1  # Indicate failure

        # remap:
        if verbosity > 2:
            print(f"{grb_fname}: Remapping")
        try:
            data[var] = cdo.remap(
                str(path_grid_select), path_grid_weights, input=temp, returnXArray=vname
            )
        except Exception as e:
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise e
            elif verbosity > 2:
                print(f"{grb_fname}: Remapping failed with exception {e}")
            elif verbosity > 1:
                print(f"{grb_fname}: Remapping failed, skipping.")
            return -1  # Indicate failure
        if var == "TKE":
            data[var] = data[var].rename({"height": "height_2"})

        if check_nans and np.isnan(data[var].to_numpy()).any():
            if verbosity > 3:
                _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
                raise ValueError(
                    f"{grb_fname}: Found NaNs in data for variable '{var}'."
                )
            elif verbosity > 1:
                print(
                    f"{grb_fname}: Found NaNs in data for variable '{var}', skipping."
                )
            return -1  # Indicate failure

        if verbosity > 1:
            print(f"{grb_fname}: Processing done.")

    """
    # for debugging, complains if array sizes do not match:
    crds = {}
    dvrs = {}
    for v, d in data.items():
       crds.update(d.coords)
       dvrs[v] = (d.dims, d.to_numpy())
       grb_fname = _get_fname(year, month, v, region=None, suffix="grb")
       print("PROCESSED DATA", grb_fname, d.to_numpy().shape, "NaNs:", np.sum(np.isnan(d.to_numpy())))
    data = Dataset(coords=crds, data_vars=dvrs)
    """
    data = Dataset(data)
    write_nc(
        data,
        nc_path,
        nc_engine=config.nc_engine,
        pack=pack,
        verbosity=verbosity,
    )

    return 1  # Indicate success


def iconDream2foxes(
    out_dir,
    region,
    min_year,
    min_month,
    max_year,
    max_month,
    base_url="https://opendata.dwd.de/climate_environment/REA/ICON-DREAM-EU/hourly",
    url_icon_grid="http://icon-downloads.mpimet.mpg.de/grids/public/edzw/icon_grid_0027_R03B08_N02.nc",
    levels=None,
    skip_download=False,
    check_grb=False,
    check_nans=True,
    pack=True,
    cdo_tmp_dir="cdo_tmp",
    verbosity=1,
):
    """
    Download ICON-DREAM-EU hourly files for specified variables and time range,
    and convert them into foxes compatible NetCDF files.

    Parameters
    ----------
    out_dir: str or Path
        Directory to save downloaded files.
    region: str
        Region for which to download data ("northsea" or "baltic").
    min_year: int
        Minimal year (inclusive).
    min_month: int
        Minimal month (inclusive).
    max_year: int
        Maximal year (inclusive).
    max_month: int
        Maximal month (inclusive).
    base_url: str
        Base URL of the FTP server.
    url_icon_grid: str
        URL to download the ICON grid file if not present.
    levels: list of int, optional
        The ICON height levels, e.g. [69,70,71,72,73,74].
    skip_download: bool
        If True, skip the download step and assume all files are present.
    check_grb: bool
        If True, check the grb files for expected dimensions before processing
    check_nans: bool
        If True, check for NaNs in the data
    pack: bool
        Whether to pack data using scale_factor and add_offset
    cdo_tmp_dir: str
        Temporary directory for CDO intermediate files.
    verbosity: int
        The verbosity level, 0 = silent, 1 = progress bars and summary.

    :group: input.states.create

    """
    engine = get_engine()
    out_dir = Path(out_dir).expanduser()
    grb_dir = out_dir / "grb"
    nc0_dir = out_dir / "nc"
    nc_dir = nc0_dir / region
    grb_dir.mkdir(parents=True, exist_ok=True)
    nc_dir.mkdir(parents=True, exist_ok=True)
    levels = list(range(69, 75)) if levels is None else levels

    cdo_tmp_dir = Path(cdo_tmp_dir).expanduser()
    if cdo_tmp_dir.exists():
        raise FileExistsError(
            f"Temporary directory {cdo_tmp_dir} already exists. Please remove it or choose another one."
        )
    else:
        if verbosity > 0:
            print("Creating tmp directory for CDO intermediate files:", cdo_tmp_dir)
        cdo_tmp_dir.mkdir(parents=True)

    var2ncvar = {
        FV.U: "u",
        FV.V: "v",
        FV.TKE: "tke",
        FV.p: "pres",
        FV.T: "t",
    }

    static_data = StaticData()
    if region == "northsea":
        path_grid_select = static_data.get_file_path(
            STATES, "target_grid_icon_eu_R03B08_nordsee.txt"
        )
    elif region == "baltic":
        path_grid_select = static_data.get_file_path(
            STATES, "target_grid_icon_eu_R03B08_ostsee.txt"
        )
    else:
        _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
        raise ValueError(f"Unknown region: {region}, choose 'northsea' or 'baltic'.")
    path_grid_weights = nc0_dir / f"icon_weights_{region}.nc"
    path_icon_grid = nc0_dir / "icon_grid_0027_R03B08_N02.nc"

    def _ymv(vrs=None):
        """Helper to iterate over year/month/var"""
        y, m = min_year, min_month
        while (y < max_year) or (y == max_year and m <= max_month):
            if vrs is not None:
                for v in vrs:
                    yield y, m, v
            else:
                yield y, m
            if m == 12:
                y += 1
                m = 1
            else:
                m += 1

    ym = list(_ymv(vrs=None))
    ymv = list(_ymv(vrs=var2ncvar.keys()))

    # download grid file and prepare grid conversion:
    futures = [
        engine.submit(
            _prepare_grid,
            path_grid_select,
            path_icon_grid,
            path_grid_weights,
            url_icon_grid,
            cdo_tmp_dir=cdo_tmp_dir,
            verbosity=verbosity - 1,
        )
    ]

    # download files in parallel:
    if not skip_download:
        futures += [
            engine.submit(
                _download_icon_dream,
                ymv_i,
                base_url,
                grb_dir,
                verbosity=verbosity - 1,
            )
            for ymv_i in ymv
        ]
        if verbosity > 0:
            results = np.array(
                [
                    engine.await_result(f)
                    for f in tqdm(futures, desc="Downloading ICON-DREAM files")
                ]
            )
        else:
            results = np.array([engine.await_result(f) for f in futures])

        failed = np.sum(results == -1)
        if verbosity > 0:
            print(
                f"Downloaded {np.sum(results == 1)} files, "
                f"{failed} failed, "
                f"{np.sum(results == 0)} already present."
            )

        if failed > 0:
            if verbosity > 0:
                print("Some downloads failed. Please retry.")
            _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
            return
        elif verbosity > 0:
            print(f"All grb files present in {grb_dir}.")

    # check grb files in parallel:
    if check_grb:
        futures = [
            engine.submit(
                _check_grb,
                year,
                month,
                grb_dir,
                var2ncvar,
                cdo_tmp_dir=cdo_tmp_dir,
                verbosity=verbosity - 1,
            )
            for year, month in ym
        ]
        if verbosity > 0:
            valid, fname, reason, details = zip(
                *[
                    engine.await_result(f)
                    for f in tqdm(
                        futures, desc=f"Checking GRB files for {len(ym)} months"
                    )
                ]
            )
        else:
            valid, fname, reason, details = zip(
                *[engine.await_result(f) for f in futures]
            )
        valid = np.concatenate(valid, dtype=bool)
        fname = np.concatenate(fname)
        reason = np.concatenate(reason)
        details = np.concatenate(details)
        fpath = out_dir / "grb_check_results.csv"

        df = DataFrame(
            {
                "file": fname,
                "valid": valid.astype(np.int8),
                "reason": reason,
                "details": details,
            }
        )
        if verbosity > 1:
            print(df)
        if verbosity > 0:
            print(f"Writing GRB check results to {fpath}")
        df.to_csv(fpath, index=False)

        failed = np.sum(~valid)
        if failed > 0:
            if verbosity > 0:
                print(
                    f"Found {failed} GBR files that failed checks. Writing file {fpath}. Please investigate."
                )
            _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)
            return
        elif verbosity > 0:
            print("All GRB files passed the check.")

    # process files in parallel:
    futures = [
        engine.submit(
            _process,
            region,
            year,
            month,
            grb_dir,
            nc_dir,
            var2ncvar,
            levels,
            path_grid_select,
            path_grid_weights,
            check_nans=check_nans,
            pack=pack,
            cdo_tmp_dir=cdo_tmp_dir,
            verbosity=verbosity - 1,
        )
        for year, month in ym
    ]
    results = np.array(
        [
            engine.await_result(f)
            for f in tqdm(
                futures, desc=f"Processing {len(ymv)} GRB files for {len(ym)} months"
            )
        ]
    )
    failed = np.sum(results == -1)
    if verbosity > 0:
        print(
            f"Processed {np.sum(results == 1)} files, "
            f"{failed} failed, "
            f"{np.sum(results == 0)} already present."
        )

    _rm_tmp_dir(cdo_tmp_dir, verbosity=verbosity)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "out_dir",
        help="Output directory to save downloaded and processed files",
        type=str,
    )
    parser.add_argument(
        "region",
        help="The region, either 'northsea' or 'baltic'",
        type=str,
        choices=["northsea", "baltic"],
    )
    parser.add_argument(
        "min_year",
        help="Minimal year (inclusive)",
        type=int,
    )
    parser.add_argument(
        "min_month",
        help="Minimal month (inclusive)",
        type=int,
    )
    parser.add_argument(
        "max_year",
        help="Maximal year (inclusive)",
        type=int,
    )
    parser.add_argument(
        "max_month",
        help="Maximal month (inclusive)",
        type=int,
    )
    parser.add_argument(
        "-e",
        "--engine",
        help="The engine",
        default="process",
    )
    parser.add_argument(
        "-n",
        "--n_cpus",
        help="The number of cpus",
        default=None,
        type=int,
    )
    parser.add_argument(
        "-v",
        "--verbosity",
        help="The verbosity level, 0 = silent",
        type=int,
        default=1,
    )
    parser.add_argument(
        "-sd",
        "--skip_download",
        help="If given, skip the download step and assume all files are present",
        action="store_true",
    )
    parser.add_argument(
        "-sc",
        "--skip_check_nans",
        help="If given, skip the check for NaNs in the data",
        action="store_true",
    )
    parser.add_argument(
        "-sp",
        "--skip_pack",
        help="If given, skip packing the data using scale_factor and add_offset",
        action="store_true",
    )
    parser.add_argument(
        "-cg",
        "--check_grb",
        help="If given, check the grb files for expected dimensions before processing",
        action="store_true",
    )
    parser.add_argument(
        "--cdo_tmp_dir",
        help="Temporary directory for CDO intermediate files",
        default="cdo_tmp",
        type=str,
    )
    args = parser.parse_args()

    try:
        with Engine.new(args.engine, n_procs=args.n_cpus):
            return iconDream2foxes(
                out_dir=args.out_dir,
                region=args.region,
                min_year=args.min_year,
                min_month=args.min_month,
                max_year=args.max_year,
                max_month=args.max_month,
                skip_download=args.skip_download,
                check_grb=args.check_grb,
                check_nans=not args.skip_check_nans,
                pack=not args.skip_pack,
                cdo_tmp_dir=args.cdo_tmp_dir,
                verbosity=args.verbosity,
            )
    except Exception as e:
        _rm_tmp_dir(args.cdo_tmp_dir, verbosity=args.verbosity)
        raise e


if __name__ == "__main__":
    main()
