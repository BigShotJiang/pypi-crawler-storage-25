"""Pydantic v2 models for the verdict envelope.

A verdict envelope binds two structures together with a content hash:

* a :class:`Claim` — what an agent intended to do, plus a digest of its input
  parameters;
* a :class:`Verdict` — a deterministic post-flight evaluation of what actually
  happened, plus a digest of the observed output.

The envelope itself is signed (see :mod:`verdict_protocol.signing`); the
signature is *not* part of the envelope body so the same envelope can be
co-signed by multiple parties without rewriting the body.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Annotated, Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)

from verdict_protocol.canonical import canonicalize
from verdict_protocol.digest import DIGEST_HEX_LEN, content_hash

SCHEMA_VERSION: Literal["0.1.0"] = "0.1.0"
"""Semantic version of the verdict envelope schema."""

MAX_ENVELOPE_BYTES = 8192
"""Hard cap on canonicalized envelope size (RFC 8785 bytes)."""

_HEX_DIGEST_RE = re.compile(r"^0x[0-9a-f]{64}$")
_ETH_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
_ISO8601_UTC_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$")

HexDigest = Annotated[
    str,
    StringConstraints(min_length=DIGEST_HEX_LEN, max_length=DIGEST_HEX_LEN),
]
"""0x-prefixed lowercase keccak-256 digest, 66 chars."""

Outcome = Literal["match", "mismatch", "inconclusive"]
"""Result of a deterministic outcome evaluation."""


class _Strict(BaseModel):
    """Base model: forbid extras, freeze instances, validate on assignment."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        validate_assignment=True,
        str_strip_whitespace=False,
    )


def _validate_digest(value: str) -> str:
    if not _HEX_DIGEST_RE.match(value):
        raise ValueError("must be a 0x-prefixed lowercase keccak-256 digest (66 chars)")
    return value


def _validate_address(value: str) -> str:
    if not _ETH_ADDRESS_RE.match(value):
        raise ValueError("must be a 0x-prefixed 20-byte Ethereum address")
    return value


def _validate_iso8601_utc(value: str) -> str:
    if not _ISO8601_UTC_RE.match(value):
        raise ValueError("must be ISO 8601 UTC with trailing 'Z' (e.g. 2026-05-01T12:00:00Z)")
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"invalid timestamp: {exc}") from exc
    return value


def utcnow_iso() -> str:
    """Return the current UTC time as an ISO 8601 ``Z``-suffixed string (seconds precision)."""
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Claim(_Strict):
    """What an agent intended to do.

    The ``params_digest`` MUST equal ``keccak256(JCS(params))`` for the original
    input parameters; callers compute it via :func:`verdict_protocol.params_digest`.
    """

    schema_version: Literal["0.1.0"] = Field(default=SCHEMA_VERSION)
    agent_id: str = Field(min_length=1, max_length=256)
    intent: str = Field(min_length=1, max_length=128)
    params_digest: HexDigest
    created_at: str

    @field_validator("params_digest")
    @classmethod
    def _digest_format(cls, v: str) -> str:
        return _validate_digest(v)

    @field_validator("created_at")
    @classmethod
    def _ts_format(cls, v: str) -> str:
        return _validate_iso8601_utc(v)


class Verdict(_Strict):
    """Deterministic post-flight evaluation of a claim.

    ``claim_digest`` MUST be the digest of the matching :class:`Claim`'s
    canonical form. ``output_digest`` MUST be the keccak-256 of the
    canonicalized observed output.
    """

    schema_version: Literal["0.1.0"] = Field(default=SCHEMA_VERSION)
    evaluator_id: str = Field(min_length=1, max_length=256)
    claim_digest: HexDigest
    output_digest: HexDigest
    outcome: Outcome
    evaluated_at: str

    @field_validator("claim_digest", "output_digest")
    @classmethod
    def _digest_format(cls, v: str) -> str:
        return _validate_digest(v)

    @field_validator("evaluated_at")
    @classmethod
    def _ts_format(cls, v: str) -> str:
        return _validate_iso8601_utc(v)


class Envelope(_Strict):
    """A signed-shape verdict envelope binding claim + verdict via ``content_hash``.

    The signature is carried out-of-band (see :mod:`verdict_protocol.signing`); it
    is not part of the envelope body, so the canonical form is reproducible by
    anyone holding the body.
    """

    schema_version: Literal["0.1.0"] = Field(default=SCHEMA_VERSION)
    claim: Claim
    verdict: Verdict
    content_hash: HexDigest
    signer: str

    @field_validator("content_hash")
    @classmethod
    def _digest_format(cls, v: str) -> str:
        return _validate_digest(v)

    @field_validator("signer")
    @classmethod
    def _addr_format(cls, v: str) -> str:
        return _validate_address(v)

    @model_validator(mode="after")
    def _check_invariants(self) -> Envelope:
        body: dict[str, Any] = {
            "schema_version": self.schema_version,
            "claim": self.claim.model_dump(mode="json"),
            "verdict": self.verdict.model_dump(mode="json"),
        }
        expected = content_hash(body)
        if expected != self.content_hash:
            raise ValueError(
                "content_hash does not match keccak256(JCS({schema_version, claim, verdict}))"
            )
        if self.verdict.claim_digest != content_hash(self.claim.model_dump(mode="json")):
            raise ValueError("verdict.claim_digest does not match keccak256(JCS(claim))")
        size = len(canonicalize(self.model_dump(mode="json")))
        if size > MAX_ENVELOPE_BYTES:
            raise ValueError(f"canonicalized envelope is {size} bytes; max {MAX_ENVELOPE_BYTES}")
        return self

    @classmethod
    def build(cls, claim: Claim, verdict: Verdict, signer: str) -> Envelope:
        """Construct an envelope, computing ``content_hash`` from claim+verdict."""
        body = {
            "schema_version": SCHEMA_VERSION,
            "claim": claim.model_dump(mode="json"),
            "verdict": verdict.model_dump(mode="json"),
        }
        return cls(
            schema_version=SCHEMA_VERSION,
            claim=claim,
            verdict=verdict,
            content_hash=content_hash(body),
            signer=signer,
        )

    def canonical_bytes(self) -> bytes:
        """Return the JCS-canonicalized envelope as bytes."""
        return canonicalize(self.model_dump(mode="json"))
