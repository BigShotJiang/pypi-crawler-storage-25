"""EIP-191 (``personal_sign``) helpers for verdict envelopes.

The signing payload is the JCS-canonical bytes of the envelope. We use
``eth_account``'s ``encode_defunct`` to produce the EIP-191 prefixed message
(``"\\x19Ethereum Signed Message:\\n" + len + msg``), then sign / recover.

The library does not manage keys: callers pass a ``private_key`` (hex string or
bytes) for :func:`sign` and an ``expected_signer`` address for :func:`verify`.
"""

from __future__ import annotations

from typing import cast

from eth_account import Account
from eth_account.messages import encode_defunct
from eth_utils import to_checksum_address  # type: ignore[attr-defined]

from verdict_protocol.schema import Envelope

PrivateKey = str | bytes


class InvalidSignatureError(ValueError):
    """Raised when a signature is malformed or cannot be parsed."""


class SignerMismatchError(ValueError):
    """Raised when the recovered signer does not match the expected address."""


def _normalize_signature(signature: str) -> bytes:
    if not isinstance(signature, str):
        raise InvalidSignatureError("signature must be a hex string")
    sig = signature.lower()
    if sig.startswith("0x"):
        sig = sig[2:]
    if len(sig) != 130:
        raise InvalidSignatureError(f"signature must be 65 bytes (130 hex chars); got {len(sig)}")
    try:
        return bytes.fromhex(sig)
    except ValueError as exc:
        raise InvalidSignatureError(f"signature is not valid hex: {exc}") from exc


def sign(envelope: Envelope, private_key: PrivateKey) -> str:
    """Return the EIP-191 ``personal_sign`` signature over the envelope's canonical bytes.

    The returned value is a 0x-prefixed 65-byte hex string (``r || s || v``).
    The caller MUST persist the signature alongside the envelope; the envelope
    body itself is unchanged.
    """
    message = encode_defunct(primitive=envelope.canonical_bytes())
    signed = Account.sign_message(message, private_key=private_key)
    return cast(str, signed.signature.to_0x_hex())


def verify(envelope: Envelope, signature: str, expected_signer: str) -> bool:
    """Verify an EIP-191 signature over an envelope.

    Returns ``True`` iff the recovered signer matches ``expected_signer`` (case-
    insensitive checksum comparison). Raises :class:`InvalidSignatureError` for
    malformed signatures and :class:`SignerMismatchError` when the recovered
    address differs from ``expected_signer``.
    """
    sig_bytes = _normalize_signature(signature)
    message = encode_defunct(primitive=envelope.canonical_bytes())
    try:
        recovered = Account.recover_message(message, signature=sig_bytes)
    except Exception as exc:
        raise InvalidSignatureError(f"could not recover signer: {exc}") from exc
    expected = to_checksum_address(expected_signer)
    if to_checksum_address(recovered) != expected:
        raise SignerMismatchError(
            f"recovered signer {recovered} does not match expected {expected}"
        )
    return True
