"""verdict-protocol: schema, JCS canonicalization, and EIP-191 signing for verdict envelopes.

This package is a pure library with no networking, no persistence, and no key management.
Callers are responsible for transport, storage, and key custody.

See README.md for the I/O contract and POSITIONING.md (agentshield-mcp) for product context.
"""

from verdict_protocol.canonical import canonicalize
from verdict_protocol.digest import (
    content_hash,
    keccak256,
    output_digest,
    params_digest,
)
from verdict_protocol.schema import (
    SCHEMA_VERSION,
    Claim,
    Envelope,
    Outcome,
    Verdict,
)
from verdict_protocol.signing import (
    InvalidSignatureError,
    SignerMismatchError,
    sign,
    verify,
)

__all__ = [
    "SCHEMA_VERSION",
    "Claim",
    "Envelope",
    "InvalidSignatureError",
    "Outcome",
    "SignerMismatchError",
    "Verdict",
    "canonicalize",
    "content_hash",
    "keccak256",
    "output_digest",
    "params_digest",
    "sign",
    "verify",
]

__version__ = "0.1.0"
