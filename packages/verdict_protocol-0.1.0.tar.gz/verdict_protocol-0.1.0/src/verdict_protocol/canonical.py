"""JCS canonicalization (RFC 8785).

Wrapper around the `jcs` package (Anders Rundgren's reference implementation of RFC 8785).
The canonical form is deterministic: the same logical value produces the same byte string,
regardless of dict ordering, whitespace, or numeric formatting variations.

Use this whenever you need to hash, sign, or compare structured data byte-for-byte.
"""

from __future__ import annotations

from typing import Any

import jcs


def canonicalize(value: Any) -> bytes:
    """Return the RFC 8785 (JCS) canonical UTF-8 byte representation of ``value``.

    The function is idempotent on already-canonical bytes when re-parsed, and it
    raises ``TypeError`` for inputs that the underlying JSON canonicalizer cannot
    serialize (e.g. ``set``, ``bytes``, custom objects).

    Args:
        value: A JSON-compatible Python value (``dict``, ``list``, ``str``, ``int``,
            ``float``, ``bool``, ``None``).

    Returns:
        The canonical UTF-8 encoded bytes.
    """
    result = jcs.canonicalize(value)
    if not isinstance(result, bytes):  # pragma: no cover - defensive
        raise TypeError(f"jcs.canonicalize returned non-bytes: {type(result).__name__}")
    return result
