"""keccak-256 helpers for verdict-protocol digests.

The wire format expects 0x-prefixed lowercase hex strings of length 66 (``0x`` + 64 nibbles).
All digest helpers here produce that format and operate on JCS-canonicalized inputs.
"""

from __future__ import annotations

from typing import Any

from eth_utils import keccak  # type: ignore[attr-defined]

from verdict_protocol.canonical import canonicalize

DIGEST_HEX_LEN = 66
"""Length of a 0x-prefixed keccak-256 digest in hex characters."""


def keccak256(data: bytes) -> str:
    """Return the 0x-prefixed lowercase hex keccak-256 digest of ``data``."""
    return "0x" + keccak(data).hex()


def _digest_value(value: Any) -> str:
    return keccak256(canonicalize(value))


def params_digest(params: Any) -> str:
    """Digest of a claim's input parameters after JCS canonicalization."""
    return _digest_value(params)


def output_digest(output: Any) -> str:
    """Digest of an evaluator's observed output after JCS canonicalization."""
    return _digest_value(output)


def content_hash(envelope_body: Any) -> str:
    """Digest over the canonicalized envelope body (claim + verdict, no signature)."""
    return _digest_value(envelope_body)
