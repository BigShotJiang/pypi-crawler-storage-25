#!/usr/bin/env python3
"""
Adobe Terminator
Gracefully quit all Adobe applications and background processes on macOS.
No force kill — apps get a chance to save unsaved work.
"""

import subprocess
import sys
import time
import os
import signal
import termios
import tty
import re


# ── Auto-install dependencies ──────────────────────────────────────────────────

def _ensure_deps():
    missing = [pkg for pkg in ("psutil", "rich") if not _importable(pkg)]
    if not missing:
        return
    print(f"Installing required packages: {', '.join(missing)} ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--quiet"] + missing,
        capture_output=True,
    )
    if result.returncode != 0:
        # Homebrew / externally-managed Python — try with the override flag
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "--break-system-packages"] + missing,
            check=True,
        )

def _importable(pkg):
    try:
        __import__(pkg)
        return True
    except ImportError:
        return False

if sys.platform != "darwin":
    sys.exit("Adobe Terminator only runs on macOS.")

_ensure_deps()

import argparse
import psutil
from rich.console import Console, Group
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.text import Text
from rich.prompt import Confirm
from rich.progress import Progress, BarColumn, TextColumn, MofNCompleteColumn, SpinnerColumn
from rich import box

console = Console()


# ── Adobe Process Definitions ──────────────────────────────────────────────────

# Main creative applications — quit via AppleScript so save dialogs appear.
# Listed from heaviest to lightest (typical usage order).
MAIN_APPS = [
    "Adobe Premiere Pro",
    "Adobe After Effects",
    "Adobe Photoshop",
    "Adobe Illustrator",
    "Adobe InDesign",
    "Adobe Audition",
    "Adobe Animate",
    "Adobe XD",
    "Adobe Acrobat DC",
    "Adobe Acrobat",
    "Adobe Lightroom Classic",
    "Adobe Lightroom",
    "Adobe Bridge",
    "Adobe Media Encoder",
    "Adobe Dreamweaver",
    "Adobe Character Animator",
    "Adobe Dimension",
    "Adobe Fresco",
    "Adobe Substance 3D Painter",
    "Adobe Substance 3D Stager",
    "Adobe Substance 3D Designer",
]

# Background / helper processes — quit via SIGTERM (no force kill).
# These often relaunch each other, so we quit them all at once then retry.
SUB_PROCESSES = [
    "Adobe Creative Cloud",
    "Creative Cloud",
    "Adobe Desktop Service",
    "Adobe CEF Helper",
    "AdobeIPCBroker",
    "CoreSync",
    "Creative Cloud Helper",
    "CCLibrary",
    "CCXProcess",
    "Adobe Update",
    "Adobe Update Helper",
    "AdobeGCClient",
    "AGMService",
    "AGSService",
    "Creative Cloud Content Manager",
    "Adobe Crash Processor",
    "AdobeCRDaemon",
    "Adobe Genuine Monitor",
    "Adobe Installer",
]

# Status constants
_QUEUED  = "queued"
_WAITING = "waiting"   # quit sent, waiting for app to respond / user to save
_RETRY   = "retry"     # sending quit again
_DONE    = "done"
_FAILED  = "failed"    # still running after all retries (never force-killed)


# ── Process Detection ──────────────────────────────────────────────────────────

def _bundle_name(exe: str) -> str:
    """Extract the .app bundle display name from an exe path (used for AppleScript)."""
    m = re.search(r'/([^/]+)\.app/', exe, re.IGNORECASE)
    return m.group(1) if m else ""


def find_main_apps(target_names):
    """
    Find the primary process for each app in target_names.
    Only matches the main binary (exe path contains Contents/MacOS/) so that
    helper processes buried in the app bundle are not grouped in.
    Returns: {display_name: {"pid": int, "proc_name": str, "script_name": str}}
    """
    found = {}
    for target in target_names:
        t_lower = target.lower()
        for p in psutil.process_iter(["pid", "name", "exe"]):
            try:
                name = p.info["name"] or ""
                exe  = p.info["exe"]  or ""
                exe_l = exe.lower()
                if "contents/macos" in exe_l and t_lower in exe_l:
                    found[target] = {
                        "pid":         p.info["pid"],
                        "proc_name":   name,
                        "script_name": _bundle_name(exe) or name,
                    }
                    break
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
    return found


def find_background_processes(exclude_pids=None):
    """
    Sweep every running process and collect any Adobe-related one not in exclude_pids.
    Each PID becomes its own individual entry — nothing is grouped.
    Returns: list of {"pid": int, "display_name": str}
    """
    exclude   = set(exclude_pids or [])
    seen_pids = set(exclude)
    sub_lower = {n.lower() for n in SUB_PROCESSES}
    results   = []

    for p in psutil.process_iter(["pid", "name", "exe"]):
        try:
            pid  = p.info["pid"]
            if pid in seen_pids:
                continue
            name  = p.info["name"] or ""
            exe   = p.info["exe"]  or ""
            exe_l = exe.lower()
            name_l = name.lower()

            is_adobe = (
                any(pat in exe_l for pat in (
                    "/applications/adobe",
                    "/library/application support/adobe",
                    "/library/printers/adobe",
                ))
                or "creative cloud" in exe_l
                or any(sub in name_l for sub in sub_lower)
            )
            if is_adobe:
                results.append({"pid": pid, "display_name": name})
                seen_pids.add(pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    return results


def pid_alive(pid: int) -> bool:
    """Return True if the process with this PID is still running."""
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# ── Quit Helpers ───────────────────────────────────────────────────────────────

def applescript_quit(proc_name: str):
    """
    Ask an application to quit via AppleScript.
    This triggers the native save dialog — no data loss.
    proc_name should be the OS-level process name (e.g. 'Adobe Premiere Pro 2024').
    """
    script = f'tell application "{proc_name}" to quit'
    try:
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=6,
        )
    except Exception:
        pass  # App may already be gone or not scriptable — that's fine


def sigterm_pid(pid: int):
    """Send SIGTERM to a single process by PID."""
    try:
        os.kill(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError, OSError):
        pass


# ── UI Helpers ─────────────────────────────────────────────────────────────────

STATUS_STYLE = {
    _QUEUED:  ("[dim]– Queued[/dim]",          ""),
    _WAITING: ("[yellow]⏳ Waiting to save…[/yellow]", "yellow"),
    _RETRY:   ("[cyan]↺  Retrying quit…[/cyan]",       "cyan"),
    _DONE:    ("[green]✓  Quit[/green]",                "green"),
    _FAILED:  ("[red]✗  Could not quit[/red]",          "red"),
}


def _build_stage_table(title: str, statuses: dict) -> Table:
    table = Table(
        title=title,
        box=box.ROUNDED,
        border_style="dim",
        show_header=True,
        header_style="bold",
        expand=False,
        min_width=52,
    )
    table.add_column("Process / Application", style="white", no_wrap=True)
    table.add_column("Status", justify="left", no_wrap=True)

    for name, status in statuses.items():
        label, _ = STATUS_STYLE.get(status, ("?", ""))
        table.add_row(name, label)

    return table


def getch():
    """Block until the user presses any key."""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


# ── Stage Runners ──────────────────────────────────────────────────────────────

POLL_INTERVAL   = 3    # seconds between status checks
MAIN_RETRY_SEC  = 12   # resend quit every N seconds while app is still open
SUB_MAX_RETRIES = 6    # max SIGTERM attempts for background processes


def run_stage1(running_main: dict):
    """
    Stage 1 — Quit all main Adobe applications simultaneously.
    Waits (indefinitely, no force kill) for users to save their work.
    """
    statuses = {name: _QUEUED for name in running_main}
    total = len(running_main)

    # Send quit to ALL main apps at once using the bundle name for AppleScript
    for name, info in running_main.items():
        applescript_quit(info["script_name"])
        statuses[name] = _WAITING

    last_retry_time = time.time()

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}[/bold cyan]"),
        BarColumn(bar_width=28),
        MofNCompleteColumn(),
        TextColumn("quit"),
        console=console,
        auto_refresh=False,
    )
    prog_task = progress.add_task("Main apps", total=total)

    def render():
        done = sum(1 for s in statuses.values() if s == _DONE)
        progress.update(prog_task, completed=done)
        return Group(progress, _build_stage_table("Stage 1 — Main Applications", statuses))

    with Live(render(), refresh_per_second=2, console=console) as live:
        while True:
            time.sleep(POLL_INTERVAL)

            for name in list(running_main):
                if statuses[name] == _DONE:
                    continue
                if not pid_alive(running_main[name]["pid"]):
                    statuses[name] = _DONE
                else:
                    statuses[name] = _WAITING

            live.update(render())

            if all(s == _DONE for s in statuses.values()):
                break

            # Periodically resend quit (in case dialog was dismissed without quitting)
            if time.time() - last_retry_time >= MAIN_RETRY_SEC:
                for name, info in running_main.items():
                    if statuses[name] != _DONE:
                        statuses[name] = _RETRY
                        applescript_quit(info["script_name"])
                last_retry_time = time.time()
                live.update(render())

    console.print("[green]✓ All main applications have quit.[/green]")


def run_stage2(bg_processes: list):
    """
    Stage 2 — Stop all Adobe background processes via SIGTERM.
    Each process is tracked individually by PID.
    Retries up to SUB_MAX_RETRIES times. Never force-kills.
    """
    pid_to_name = {item["pid"]: item["display_name"] for item in bg_processes}
    statuses    = {pid: _QUEUED for pid in pid_to_name}
    total       = len(bg_processes)

    # SIGTERM all at once
    for pid in pid_to_name:
        sigterm_pid(pid)
        statuses[pid] = _WAITING

    attempts = 0

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold yellow]{task.description}[/bold yellow]"),
        BarColumn(bar_width=28),
        MofNCompleteColumn(),
        TextColumn("stopped"),
        console=console,
        auto_refresh=False,
    )
    prog_task = progress.add_task("Background processes", total=total)

    def build_table():
        table = Table(
            title="Stage 2 — Background Processes",
            box=box.ROUNDED,
            border_style="dim",
            show_header=True,
            header_style="bold",
            expand=False,
            min_width=58,
        )
        table.add_column("Process",  style="white", no_wrap=True)
        table.add_column("PID",      style="dim",   justify="right", no_wrap=True)
        table.add_column("Status",   justify="left", no_wrap=True)
        for pid, name in pid_to_name.items():
            label, _ = STATUS_STYLE.get(statuses[pid], ("?", ""))
            table.add_row(name, str(pid), label)
        return table

    def render():
        done = sum(1 for s in statuses.values() if s == _DONE)
        progress.update(prog_task, completed=done)
        return Group(progress, build_table())

    with Live(render(), refresh_per_second=2, console=console) as live:
        while attempts < SUB_MAX_RETRIES:
            time.sleep(POLL_INTERVAL)
            attempts += 1

            for pid in pid_to_name:
                if statuses[pid] == _DONE:
                    continue
                if not pid_alive(pid):
                    statuses[pid] = _DONE
                elif attempts < SUB_MAX_RETRIES:
                    sigterm_pid(pid)
                    statuses[pid] = _RETRY
                else:
                    statuses[pid] = _FAILED

            live.update(render())

            if all(s in (_DONE, _FAILED) for s in statuses.values()):
                break

    failed = [pid_to_name[p] for p, s in statuses.items() if s == _FAILED]
    if failed:
        console.print(
            f"[yellow]⚠ {len(failed)} process(es) could not be stopped "
            f"(no force quit used): {', '.join(failed)}[/yellow]"
        )
    else:
        console.print("[green]✓ All background processes stopped.[/green]")


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Gracefully terminate all Adobe processes.")
    parser.add_argument("-y", "--yes", action="store_true", help="Skip confirmation prompt and proceed automatically.")
    args = parser.parse_args()

    console.print()
    console.print(
        Panel.fit(
            Text.assemble(
                ("  ADOBE TERMINATOR  \n", "bold red"),
                ("Terminate all Adobe processes  ·  No force quit", "dim"),
            ),
            border_style="red",
            padding=(1, 3),
        )
    )
    console.print()

    # ── Detect running processes ───────────────────────────────────────────────
    console.print("[dim]Scanning for running Adobe processes…[/dim]")
    running_main = find_main_apps(MAIN_APPS)
    main_pids    = {info["pid"] for info in running_main.values()}
    running_bg   = find_background_processes(exclude_pids=main_pids)

    if not running_main and not running_bg:
        console.print("[green]\nNo Adobe processes are currently running. Nothing to do![/green]")
        if not args.yes:
            console.print("\nPress any key to exit…")
            getch()
        return

    # ── Step 1 — Show what will be terminated ─────────────────────────────────
    console.print()

    if running_main:
        t = Table(
            title="[bold]Main Applications[/bold]",
            box=box.ROUNDED,
            border_style="red",
            show_header=True,
            header_style="bold",
            expand=False,
            min_width=52,
        )
        t.add_column("Application", style="white")
        t.add_column("PID", style="dim", justify="right")
        for name, info in running_main.items():
            t.add_row(name, str(info["pid"]))
        console.print(t)
        console.print()

    if running_bg:
        t = Table(
            title="[bold]Background Processes[/bold]",
            box=box.ROUNDED,
            border_style="yellow",
            show_header=True,
            header_style="bold",
            expand=False,
            min_width=52,
        )
        t.add_column("Process", style="white")
        t.add_column("PID", style="dim", justify="right")
        for item in running_bg:
            t.add_row(item["display_name"], str(item["pid"]))
        console.print(t)
        console.print()

    # ── Step 1 confirmation ────────────────────────────────────────────────────
    console.print(
        "[dim]Main apps will be asked to quit — save dialogs will appear as normal.\n"
        "Background processes will receive a graceful stop signal (no force quit).[/dim]\n"
    )
    if args.yes:
        console.print("[dim]Skipping confirmation (-y passed).[/dim]")
    else:
        console.print("[dim]Tip: use [bold]adobe-terminator -y[/bold] to skip this prompt.[/dim]\n")
        proceed = Confirm.ask("[bold]Proceed with termination?[/bold]", default=False)
        if not proceed:
            console.print("\n[dim]Aborted. No changes made.[/dim]")
            return

    console.print()

    # ── Step 2 — Stage 1: Main apps ───────────────────────────────────────────
    if running_main:
        console.print(Panel("[bold cyan]Stage 1:[/bold cyan] Quitting main applications", border_style="cyan"))
        console.print(
            "[dim]Apps with unsaved work will show a save dialog — "
            "save your files and quit normally. This will wait for you.[/dim]\n"
        )
        run_stage1(running_main)
        console.print()

    # ── Step 3 — Rescan background processes after main apps quit ─────────────
    if running_main:
        console.print("[dim]Checking active background processes…[/dim]")
        running_bg = find_background_processes()
        console.print()

    # ── Step 4 — Stage 2: Background processes ────────────────────────────────
    if running_bg:
        console.print(Panel("[bold yellow]Stage 2:[/bold yellow] Stopping background processes", border_style="yellow"))
        console.print("[dim]Sending stop signals — some may relaunch briefly before quitting.[/dim]\n")
        run_stage2(running_bg)
        console.print()

    # ── Step 5 — Completion ───────────────────────────────────────────────────
    console.print(
        Panel.fit(
            Text.assemble(
                ("  ✓ Adobe Terminator Complete!  \n", "bold green"),
                ("All Adobe processes have been gracefully shut down.", "dim"),
            ),
            border_style="green",
            padding=(1, 3),
        )
    )
    if not args.yes:
        console.print("\nPress any key to exit…")
        getch()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n\n[dim]Interrupted. Exiting.[/dim]")
        sys.exit(0)
