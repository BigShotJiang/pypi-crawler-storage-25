# Adobe Terminator

Gracefully terminate all Adobe processes on macOS — no force quit.

Adobe Terminator finds every running Adobe application and background process, asks you to save your work through the normal save dialog, waits for you to quit, then cleans up all remaining background processes automatically.

## Features

- Detects all running Adobe main applications (Premiere Pro, After Effects, Photoshop, etc.)
- Detects all Adobe background processes (Creative Cloud, CoreSync, AdobeIPCBroker, etc.)
- Quits main apps via AppleScript — native save dialogs appear, no data loss
- Waits indefinitely for you to save and quit — never force kills
- Kills background processes by PID after main apps are closed
- Retries stubborn background processes automatically
- Progress bars for both stages
- Skip confirmation with `-y` for scripted use

## Install

**pipx (recommended)**
```bash
pipx install adobe-terminator
```

**pip**
```bash
pip install adobe-terminator
```

**Homebrew**
```bash
brew tap Endrite-tar/adobe-terminator
brew install adobe-terminator
```

## Usage

```bash
adobe-terminator          # interactive — lists processes and asks to confirm
adobe-terminator -y       # skip confirmation prompt
```

## How it works

**Stage 1 — Main applications**
Sends a quit signal via AppleScript to all running Adobe apps simultaneously. Each app shows its normal save dialog. Adobe Terminator waits until every app has fully closed before moving on — no timeout, no force quit.

**Stage 2 — Background processes**
After all main apps are closed, scans for any remaining Adobe-related processes (Creative Cloud, sync daemons, helpers, crash reporters, etc.) and sends each one a SIGTERM signal by PID. Retries automatically since some processes relaunch each other. Never force kills.

## Requirements

- macOS
- Python 3.9+

## License

MIT
