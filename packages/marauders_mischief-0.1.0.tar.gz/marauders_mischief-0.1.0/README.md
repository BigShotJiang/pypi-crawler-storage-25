# marauders-mischief

> An AI-native dev harness. Solemnly swear you're up to no good.

A versioned, harness-agnostic development framework for AI-native software engineering. Size-adaptive sessions, multi-agent quality gates, persistent context across sessions.

Built for Claude Code today; designed to support Codex CLI and Cursor in future releases.

**Status:** Pre-release. v0.1.0 in development.

---

## Install

```bash
pipx install marauders-mischief
# or
uv tool install marauders-mischief
```

## Quickstart

```bash
mkdir my-new-project && cd my-new-project
git init
mar init
```

This scaffolds the harness into your repo:

```
my-new-project/
├── CLAUDE.md                        Project-level context (you own)
├── .brain/                          Curated, distilled context (you own)
│   ├── CONTEXT.md
│   ├── STATE.md
│   ├── STACK.md
│   ├── DECISIONS.md
│   └── RISKS.md
├── .claude/
│   ├── agents/                      12 subagents (research, plan, execute, ...)
│   ├── commands/mar/                19 slash commands (/mar:*)
│   └── settings.json                Hooks + permissions (mar manages its keys)
├── ops/
│   ├── memory/                      Knowledge capture pipeline (uv-managed)
│   ├── workflow/                    Session/phase/stage spec + scripts
│   └── ideas/                       Idea lifecycle machinery
└── .mm/
    ├── version                      Installed mar version
    └── lockfile.json                SHA256 of every framework file
```

Then:

```bash
cd ops/memory && uv sync   # one-time: set up memory pipeline deps
```

Fill in `.brain/CONTEXT.md` and `.brain/STATE.md`, and you're ready to run `/mar:session-start` in Claude Code.

## Commands

| Command | Purpose |
|---|---|
| `mar init` | Scaffold the harness into the current directory |
| `mar update` | Pull latest framework version and apply updates *(v0.2)* |
| `mar status` | Show installed version and local drift *(v0.2)* |
| `mar doctor` | Verify install integrity *(v0.2)* |

Flags:

- `--target <adapter>` — currently `claude` (default). `codex` and `cursor` adapters land in future releases.
- `--force` — overwrite scaffolded files (`.brain/*`, `CLAUDE.md`) that already exist.
- `--project-name <name>` — substituted into Jinja-rendered templates. Defaults to the current directory name.

## How it works

### File classes

Every file shipped by mar belongs to one of three classes (see [docs/file-classes.md](docs/file-classes.md)):

| Class | Behavior |
|---|---|
| **framework** | Owned by mar. Overwritten on `mar update`. Conflict-detected if you edit locally. |
| **scaffolded** | Created once at init. You own thereafter; mar never touches. |
| **merged** | mar owns specific keys; you own everything else in the same file. Update reconciles only mar's keys. |

This split is what lets `mar update` upgrade the framework without clobbering your project's content.

### Adapter layer

The mar core is harness-agnostic in spirit. Each harness (Claude Code, Codex CLI, Cursor) gets a small adapter that:

- Validates which paths the framework can write to
- Provides merge strategies for files that mix framework wiring with user config (e.g., `.claude/settings.json` for Claude Code)

Today only the Claude Code adapter is implemented. Adding a new adapter means subclassing `Adapter` and `MergeStrategy`.

### The workflow framework

mar's centerpiece is a **size-adaptive session loop**:

- **XS** edits skip the framework entirely
- **S/M** sessions collapse to a single phase
- **L/XL** sessions get an explicit meta-plan with human approval gates between phases

Each phase runs through stages: research → plan → execute → test → refine → simplify → verify → review + tester → integrate. A PreToolUse scope hook prevents agents from editing outside their declared scope.

Full spec lives in your repo at `ops/workflow/README.md` after `mar init`.

## Slash commands

After `mar init`, these are available in Claude Code:

| Command | What it does |
|---|---|
| `/mar:session-start` | Start a new session (size/guidance/autonomy picker) |
| `/mar:plan` | Run research + planning for the current sub-stage |
| `/mar:ship` | Run execute → test → refine → simplify → verify → review + tester |
| `/mar:integrate` | Compose commit story, propose .brain/ writebacks |
| `/mar:approve <gate>` | Pass a gate |
| `/mar:iterate <gate> "<note>"` | Refine in place with new direction |
| `/mar:replan` | Discard current plan and re-plan from scratch |
| `/mar:status` | Current session status |
| `/mar:session-list` | All active and recently archived sessions |
| `/mar:idea-new` | Capture an incubating idea |

Full reference: see `.claude/commands/mar/*.md` after install.

## Development

Clone and set up:

```bash
git clone git@github.com:sindreespeland/marauders-mischief.git
cd marauders-mischief
uv sync --dev
```

Run tests:

```bash
uv run pytest
uv run ruff check src tests
```

Try `mar init` against a throwaway directory:

```bash
mkdir /tmp/test-install && cd /tmp/test-install
uv run --project ~/repos/marauders-mischief mar init
```

## Roadmap

- **v0.1** — `mar init`, Claude Code adapter, the workflow framework
- **v0.2** — `mar update` (with conflict resolution), `mar status`, `mar doctor`
- **v0.3** — Codex CLI adapter, Cursor adapter
- **v0.4** — `mar update --auto-check` (optional auto-notify on session start)

## License

MIT — see [LICENSE](LICENSE).
