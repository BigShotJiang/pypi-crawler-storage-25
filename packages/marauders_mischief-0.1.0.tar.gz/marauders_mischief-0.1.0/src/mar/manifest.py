"""Manifest schema for the marauders-mischief framework.

The manifest declares every file shipped by `mar init` — its source within
the framework/ directory, its target in the consumer repo, and which file
class governs how it's installed and updated. See docs/file-classes.md.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

import yaml

MANIFEST_VERSION = 1


class FileClass(StrEnum):
    """How a framework file is managed in the consumer repo."""

    FRAMEWORK = "framework"
    SCAFFOLDED = "scaffolded"
    MERGED = "merged"


class Renderer(StrEnum):
    """How the source is rendered into the target."""

    COPY = "copy"
    JINJA = "jinja"


@dataclass(frozen=True)
class FileEntry:
    """A single file declared in the manifest."""

    source: str
    target: str
    klass: FileClass
    renderer: Renderer = Renderer.COPY
    merge: str | None = None

    def __post_init__(self) -> None:
        if self.klass is FileClass.MERGED and self.merge is None:
            raise ValueError(
                f"merged file {self.source!r} requires a 'merge' strategy name"
            )
        if self.klass is not FileClass.MERGED and self.merge is not None:
            raise ValueError(
                f"file {self.source!r} declares 'merge' but is not class=merged"
            )


@dataclass(frozen=True)
class Manifest:
    """The full framework manifest."""

    manifest_version: int
    files: tuple[FileEntry, ...]

    def by_target(self) -> dict[str, FileEntry]:
        return {entry.target: entry for entry in self.files}

    def by_class(self, klass: FileClass) -> tuple[FileEntry, ...]:
        return tuple(e for e in self.files if e.klass is klass)

    @classmethod
    def load(cls, path: Path) -> Manifest:
        """Load and validate a manifest from a YAML file."""
        with path.open() as f:
            raw: dict[str, Any] = yaml.safe_load(f) or {}
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> Manifest:
        version = raw.get("manifest_version")
        if version != MANIFEST_VERSION:
            raise ValueError(
                f"unsupported manifest_version {version!r}; expected {MANIFEST_VERSION}"
            )

        files_raw = raw.get("files", [])
        if not isinstance(files_raw, list):
            raise ValueError("manifest 'files' must be a list")

        entries: list[FileEntry] = []
        seen_targets: set[str] = set()

        for i, entry_raw in enumerate(files_raw):
            if not isinstance(entry_raw, dict):
                raise ValueError(f"manifest files[{i}] must be a mapping")

            try:
                entry = FileEntry(
                    source=entry_raw["source"],
                    target=entry_raw["target"],
                    klass=FileClass(entry_raw["class"]),
                    renderer=Renderer(entry_raw.get("renderer", "copy")),
                    merge=entry_raw.get("merge"),
                )
            except KeyError as e:
                raise ValueError(f"manifest files[{i}] missing required key: {e}") from e
            except ValueError as e:
                raise ValueError(f"manifest files[{i}]: {e}") from e

            if entry.target in seen_targets:
                raise ValueError(f"duplicate target {entry.target!r} in manifest")
            seen_targets.add(entry.target)

            entries.append(entry)

        return cls(manifest_version=version, files=tuple(entries))
