"""Implementation of `mar init` — scaffold the framework into a target repo."""

from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jinja2 import Template

from mar import __version__, framework_root
from mar.adapters import Adapter, get_adapter, validate_manifest
from mar.manifest import FileClass, FileEntry, Manifest, Renderer

LOCKFILE_REL = Path(".mm/lockfile.json")
VERSION_FILE_REL = Path(".mm/version")


@dataclass
class InstallReport:
    """Summary of what `init_repo` did."""

    framework_installed: int = 0
    scaffolded_created: int = 0
    scaffolded_skipped: int = 0
    merged_files: int = 0
    skipped_paths: list[str] = field(default_factory=list)


def init_repo(
    target_dir: Path,
    adapter_name: str = "claude",
    force: bool = False,
    project_name: str | None = None,
) -> InstallReport:
    """Scaffold the framework into `target_dir`.

    Args:
        target_dir: Absolute path to the consumer repo root.
        adapter_name: Adapter identifier (currently only "claude").
        force: If True, overwrite scaffolded files even when present.
        project_name: Substituted into Jinja templates. Defaults to the
            target directory's basename.

    Returns:
        InstallReport summarizing the install.
    """
    target_dir = target_dir.resolve()
    if not target_dir.exists():
        raise FileNotFoundError(f"target dir does not exist: {target_dir}")
    if not target_dir.is_dir():
        raise NotADirectoryError(f"target is not a directory: {target_dir}")

    root = framework_root()
    manifest = Manifest.load(root / "manifest.yaml")
    adapter = get_adapter(adapter_name)
    validate_manifest(manifest, adapter)

    context: dict[str, Any] = {
        "project_name": project_name or target_dir.name,
        "target_adapter": adapter_name,
        "mar_version": __version__,
    }

    report = InstallReport()
    lockfile_entries: dict[str, dict[str, Any]] = {}

    for entry in manifest.files:
        source_path = root / entry.source
        target_path = target_dir / entry.target

        if entry.klass is FileClass.FRAMEWORK:
            _install_file(source_path, target_path, entry, context)
            lockfile_entries[entry.target] = {
                "source": entry.source,
                "sha256": _sha256_file(target_path),
            }
            report.framework_installed += 1

        elif entry.klass is FileClass.SCAFFOLDED:
            if target_path.exists() and not force:
                report.scaffolded_skipped += 1
                report.skipped_paths.append(entry.target)
                continue
            _install_file(source_path, target_path, entry, context)
            report.scaffolded_created += 1

        elif entry.klass is FileClass.MERGED:
            _install_merged_file(source_path, target_path, entry, adapter, context)
            owned_hash = _owned_sha256(target_path, entry, adapter)
            lockfile_entries[entry.target] = {
                "source": entry.source,
                "merge": entry.merge,
                "owned_sha256": owned_hash,
            }
            report.merged_files += 1

    _write_lockfile(target_dir, manifest, adapter_name, lockfile_entries)
    _write_version_pointer(target_dir)

    return report


def _install_file(
    source: Path,
    target: Path,
    entry: FileEntry,
    context: dict[str, Any],
) -> None:
    """Copy or render `source` into `target`."""
    target.parent.mkdir(parents=True, exist_ok=True)
    if entry.renderer is Renderer.JINJA:
        template_text = source.read_text(encoding="utf-8")
        rendered = Template(template_text).render(**context)
        target.write_text(rendered, encoding="utf-8")
    else:
        shutil.copy2(source, target)


def _install_merged_file(
    source: Path,
    target: Path,
    entry: FileEntry,
    adapter: Adapter,
    context: dict[str, Any],
) -> None:
    """Combine `source` content with existing target via the adapter's strategy."""
    assert entry.merge is not None  # invariant guaranteed by manifest validation
    strategy = adapter.merge_strategies()[entry.merge]

    existing = target.read_text(encoding="utf-8") if target.exists() else None
    framework_text = source.read_text(encoding="utf-8")
    merged = strategy.merge(existing, framework_text, context)

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(merged, encoding="utf-8")


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _owned_sha256(path: Path, entry: FileEntry, adapter: Adapter) -> str | None:
    """SHA256 of just the mar-owned portion of a merged file (or None)."""
    assert entry.merge is not None
    strategy = adapter.merge_strategies()[entry.merge]
    owned = strategy.extract_owned(path.read_text(encoding="utf-8"))
    if owned is None:
        return None
    return hashlib.sha256(owned.encode("utf-8")).hexdigest()


def _write_lockfile(
    target_dir: Path,
    manifest: Manifest,
    adapter_name: str,
    entries: dict[str, dict[str, Any]],
) -> None:
    lockfile_path = target_dir / LOCKFILE_REL
    lockfile_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "mar_version": __version__,
        "manifest_version": manifest.manifest_version,
        "adapter": adapter_name,
        "files": entries,
    }
    lockfile_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _write_version_pointer(target_dir: Path) -> None:
    version_path = target_dir / VERSION_FILE_REL
    version_path.parent.mkdir(parents=True, exist_ok=True)
    version_path.write_text(__version__ + "\n")
