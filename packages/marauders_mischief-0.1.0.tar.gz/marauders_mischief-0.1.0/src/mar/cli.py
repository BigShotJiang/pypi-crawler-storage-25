"""mar — Marauder's Mischief CLI."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

from mar import __version__
from mar.adapters import supported_adapters
from mar.install import init_repo

app = typer.Typer(
    name="mar",
    help="Marauder's Mischief — an AI-native dev harness. Solemnly swear you're up to no good.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"mar {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Marauder's Mischief — an AI-native dev harness."""


@app.command()
def init(
    target: str = typer.Option(
        "claude",
        "--target",
        help=f"Harness adapter target. Supported: {list(supported_adapters())}.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite scaffolded files (.brain/, CLAUDE.md) even when they exist.",
    ),
    project_name: str | None = typer.Option(
        None,
        "--project-name",
        help="Project name used in template substitution. Defaults to the current directory name.",
    ),
) -> None:
    """Scaffold the harness into the current directory."""
    cwd = Path.cwd()

    if target not in supported_adapters():
        console.print(
            f"[red]Unknown adapter:[/red] {target!r}. "
            f"Supported: {list(supported_adapters())}"
        )
        raise typer.Exit(code=2)

    console.print(
        f"[bold]Marauder's Mischief[/bold] v{__version__} → installing into [cyan]{cwd}[/cyan] "
        f"(adapter: [yellow]{target}[/yellow])"
    )

    try:
        report = init_repo(
            target_dir=cwd,
            adapter_name=target,
            force=force,
            project_name=project_name,
        )
    except Exception as e:
        console.print(f"[red]init failed:[/red] {e}")
        raise typer.Exit(code=1) from e

    console.print()
    console.print("[green]✓[/green] Install complete.")
    console.print(f"  framework files: {report.framework_installed}")
    console.print(
        f"  scaffolded:      {report.scaffolded_created} created, "
        f"{report.scaffolded_skipped} skipped (already present)"
    )
    console.print(f"  merged:          {report.merged_files}")

    if report.scaffolded_skipped:
        console.print()
        console.print(
            "[dim]Skipped scaffolded files (use --force to overwrite):[/dim]"
        )
        for path in report.skipped_paths[:5]:
            console.print(f"  [dim]{path}[/dim]")
        if len(report.skipped_paths) > 5:
            console.print(f"  [dim]... and {len(report.skipped_paths) - 5} more[/dim]")

    console.print()
    console.print("[bold]Next steps:[/bold]")
    console.print("  1. [yellow]cd ops/memory && uv sync[/yellow]  (set up the memory pipeline)")
    console.print(
        "  2. Fill in [yellow].brain/CONTEXT.md[/yellow] "
        "and [yellow].brain/STATE.md[/yellow]"
    )
    console.print("  3. Solemnly swear you're up to no good.")


@app.command()
def update(
    check: bool = typer.Option(
        False,
        "--check",
        help="Show what would change without applying.",
    ),
) -> None:
    """Pull the latest framework version and apply updates."""
    console.print("[yellow]mar update: not implemented yet[/yellow]")
    raise typer.Exit(code=1)


@app.command()
def status() -> None:
    """Show installed framework version and local drift."""
    console.print("[yellow]mar status: not implemented yet[/yellow]")
    raise typer.Exit(code=1)


@app.command()
def doctor() -> None:
    """Verify harness install integrity."""
    console.print("[yellow]mar doctor: not implemented yet[/yellow]")
    raise typer.Exit(code=1)
