#!/usr/bin/env bash
# Resolve the current session id for this Claude Code window.
#
# Resolution order:
#   1. $MAR_SESSION_ID env var (explicit override)
#   2. .claude/sessions/pointer-<CLAUDE_CODE_SSE_PORT> (per-window pointer)
#   3. .claude/.current-session (legacy single-window fallback)
#
# Exits 0 with session id on stdout; exits 1 with message on stderr if none found.
#
# Used by every workflow slash command (plan, ship, status, approve, reject,
# continue, integrate, stop, replan, session-resume, session-list, session-archive)
# to avoid stepping on a parallel window's session.

set -euo pipefail

repo_root() {
  git rev-parse --show-toplevel 2>/dev/null || pwd
}

ROOT="$(repo_root)"

# 1. explicit env override
if [[ -n "${MAR_SESSION_ID:-}" ]]; then
  echo "$MAR_SESSION_ID"
  exit 0
fi

# 2. per-window pointer keyed by CC SSE port (unique per CC instance)
if [[ -n "${CLAUDE_CODE_SSE_PORT:-}" ]]; then
  PTR="$ROOT/.claude/sessions/pointer-$CLAUDE_CODE_SSE_PORT"
  if [[ -f "$PTR" ]]; then
    cat "$PTR"
    exit 0
  fi
fi

# 3. legacy fallback — only safe when there's a single active session
FALLBACK="$ROOT/.claude/.current-session"
if [[ -f "$FALLBACK" ]]; then
  cat "$FALLBACK"
  exit 0
fi

echo "no current session — run /session-start or /session-resume" >&2
exit 1
