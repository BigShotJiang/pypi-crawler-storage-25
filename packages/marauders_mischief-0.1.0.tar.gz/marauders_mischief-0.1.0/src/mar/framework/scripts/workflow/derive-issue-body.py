#!/usr/bin/env python3
"""
Derive issue-body.md from a phase plan.

In v2, plan.md is the single source of truth for a phase. The GitHub issue
body, the PR body, and success-criteria evidence are all *derived views*.
This script generates one such view: phases/<id>/issue-body.md.

Step 1 (local mode, current): writes the file under the session's phase dir.
The user reviews it; iterate gates regenerate it after every plan revision.

Step 2 (gh mode, deferred): the same content gets posted via
`gh issue edit <num> --body-file -`. Same call sites in the orchestrator,
different backend. Add `--target gh --issue <num>` to enable.

plan.md is canonical. This script never edits plan.md.

Stdlib only.
"""

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SESSIONS = ROOT / "sessions" / "active"
TEMPLATE = ROOT / "ops" / "workflow" / "templates" / "issue-body.md.template"


def read_section(plan_text: str, heading: str) -> str:
    """Return the verbatim content of a `## <heading>` section. "" if absent."""
    lines = plan_text.splitlines()
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$")
    start = None
    for i, line in enumerate(lines):
        if pattern.match(line):
            start = i + 1
            break
    if start is None:
        return ""
    end = len(lines)
    for j in range(start, len(lines)):
        if re.match(r"^##\s+", lines[j]):
            end = j
            break
    return "\n".join(lines[start:end]).strip()


def extract_questions(approach_text: str) -> str:
    """Pull [QUESTION] entries from §Approach into a bulleted list."""
    questions: list[str] = []
    pattern = re.compile(
        r"\*\*\[QUESTION\]\*\*\s*(.+?)(?=\n\s*\n|\n\*\*\[|\Z)",
        re.DOTALL,
    )
    for m in pattern.finditer(approach_text):
        q = " ".join(m.group(1).strip().split())
        questions.append(f"- {q}")
    return (
        "\n".join(questions)
        if questions
        else "_None — all decisions resolved or assumed with fallback._"
    )


def extract_frontmatter(plan_text: str) -> dict[str, str]:
    m = re.match(r"^---\n(.*?)\n---", plan_text, re.DOTALL)
    if not m:
        return {}
    out: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip()] = v.strip()
    return out


def extract_size(plan_text: str) -> str:
    return read_section(plan_text, "Size").strip() or "—"


def derive(session_id: str, phase_id: str) -> Path:
    phase_dir = SESSIONS / session_id / "phases" / phase_id
    plan_path = phase_dir / "plan.md"
    if not plan_path.exists():
        sys.exit(f"plan.md not found at {plan_path}")
    if not TEMPLATE.exists():
        sys.exit(f"issue-body template not found at {TEMPLATE}")

    plan_text = plan_path.read_text()
    template_text = TEMPLATE.read_text()

    contract = read_section(plan_text, "Contract") or "_(missing in plan.md — fix plan)_"
    scope = read_section(plan_text, "Scope") or "_(missing)_"
    success = read_section(plan_text, "Success criteria") or "_(missing)_"
    dod = read_section(plan_text, "Definition of Done") or "_(missing)_"
    approach = read_section(plan_text, "Approach")
    questions = extract_questions(approach)
    size = extract_size(plan_text)
    depends_on = "—"

    rendered = (
        template_text
        .replace("{{SESSION_ID}}", session_id)
        .replace("{{PHASE_ID}}", phase_id)
        .replace("{{DEPENDS_ON}}", depends_on)
        .replace("{{SIZE}}", size)
        .replace("{{CONTRACT_SECTION}}", contract)
        .replace("{{SCOPE_SECTION}}", scope)
        .replace("{{SUCCESS_CRITERIA_SECTION}}", success)
        .replace("{{DOD_SECTION}}", dod)
        .replace("{{QUESTIONS_SECTION}}", questions)
    )

    out = phase_dir / "issue-body.md"
    out.write_text(rendered)
    return out


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Derive issue-body.md from plan.md (Step 1 local mode)."
    )
    ap.add_argument("--session", required=True, help="Session id")
    ap.add_argument("--phase", required=True, help="Phase id (e.g. 01-main)")
    ap.add_argument(
        "--target",
        default="local",
        choices=["local"],
        help="Output target. Step 2 will add 'gh' for `gh issue edit`.",
    )
    args = ap.parse_args()

    if args.target != "local":
        sys.exit(f"target '{args.target}' not implemented in Step 1")

    out = derive(args.session, args.phase)
    rel = out.relative_to(ROOT) if out.is_absolute() else out
    print(f"derived: {rel}")


if __name__ == "__main__":
    main()
