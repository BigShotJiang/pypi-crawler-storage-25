#!/usr/bin/env bash
# Set the current session id for this Claude Code window.
#
# Writes the per-window pointer file `.claude/sessions/pointer-<CLAUDE_CODE_SSE_PORT>`.
# Also updates legacy `.claude/.current-session` only if no other per-window
# pointer exists (keeps legacy consumers working while a single session is active).
#
# Usage: set-session.sh <session-id>
# Usage: set-session.sh --clear        (removes the per-window pointer only)

set -euo pipefail

repo_root() {
  git rev-parse --show-toplevel 2>/dev/null || pwd
}

ROOT="$(repo_root)"
SESSIONS_DIR="$ROOT/.claude/sessions"
mkdir -p "$SESSIONS_DIR"

if [[ "${1:-}" == "--clear" ]]; then
  if [[ -n "${CLAUDE_CODE_SSE_PORT:-}" ]]; then
    rm -f "$SESSIONS_DIR/pointer-$CLAUDE_CODE_SSE_PORT"
  fi
  # If no per-window pointers remain, also clear legacy
  if ! ls "$SESSIONS_DIR"/pointer-* >/dev/null 2>&1; then
    rm -f "$ROOT/.claude/.current-session"
  fi
  exit 0
fi

SESSION_ID="${1:?usage: set-session.sh <session-id> | --clear}"

if [[ -z "${CLAUDE_CODE_SSE_PORT:-}" ]]; then
  echo "warning: CLAUDE_CODE_SSE_PORT not set; falling back to legacy pointer only (no per-window isolation)" >&2
  printf "%s" "$SESSION_ID" > "$ROOT/.claude/.current-session"
  exit 0
fi

printf "%s" "$SESSION_ID" > "$SESSIONS_DIR/pointer-$CLAUDE_CODE_SSE_PORT"

# Mirror to legacy pointer only when there are no other per-window pointers
# (single active window — safe for legacy consumers).
OTHER=$(ls "$SESSIONS_DIR"/pointer-* 2>/dev/null | grep -v "pointer-$CLAUDE_CODE_SSE_PORT$" || true)
if [[ -z "$OTHER" ]]; then
  printf "%s" "$SESSION_ID" > "$ROOT/.claude/.current-session"
fi
