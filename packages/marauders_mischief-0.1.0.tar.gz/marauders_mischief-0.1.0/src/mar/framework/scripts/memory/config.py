"""Path constants and configuration for the knowledge capture pipeline."""

from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

# ── Paths ──────────────────────────────────────────────────────────────
ROOT_DIR = Path(__file__).resolve().parent.parent.parent.parent  # repo root
MEMORY_DIR = ROOT_DIR / "ops" / "memory"
DAILY_DIR = MEMORY_DIR / "daily"
KNOWLEDGE_DIR = ROOT_DIR / "knowledge"
CONCEPTS_DIR = KNOWLEDGE_DIR / "concepts"
CONNECTIONS_DIR = KNOWLEDGE_DIR / "connections"
QA_DIR = KNOWLEDGE_DIR / "qa"
REPORTS_DIR = MEMORY_DIR / "reports"
SCRIPTS_DIR = MEMORY_DIR / "scripts"
HOOKS_DIR = MEMORY_DIR / "hooks"
SCHEMA_FILE = MEMORY_DIR / "SCHEMA.md"

INDEX_FILE = KNOWLEDGE_DIR / "index.md"
LOG_FILE = KNOWLEDGE_DIR / "log.md"
STATE_FILE = MEMORY_DIR / "state.json"
LAST_FLUSH_FILE = MEMORY_DIR / "last-flush.json"
BRAIN_DIR = ROOT_DIR / ".brain"

# ── Timezone ───────────────────────────────────────────────────────────
TIMEZONE = "Europe/Oslo"


def now_local() -> datetime:
    """Current time in local timezone."""
    return datetime.now(ZoneInfo(TIMEZONE))


def now_iso() -> str:
    """Current time in ISO 8601 format."""
    return now_local().isoformat(timespec="seconds")


def today_iso() -> str:
    """Current date in ISO 8601 format."""
    return now_local().strftime("%Y-%m-%d")
