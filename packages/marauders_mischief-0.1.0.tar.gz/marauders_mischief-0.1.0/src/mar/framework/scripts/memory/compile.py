"""
Compile daily conversation logs into structured knowledge articles.

This is the "LLM compiler" — reads daily logs (source code) and produces
organized knowledge articles (the executable).

Usage:
    uv run --project ops/memory python ops/memory/scripts/compile.py
    uv run --project ops/memory python ops/memory/scripts/compile.py --all
    uv run --project ops/memory python ops/memory/scripts/compile.py --file 2026-04-15.md
    uv run --project ops/memory python ops/memory/scripts/compile.py --dry-run
"""

from __future__ import annotations

# Recursion prevention
import os
os.environ["CLAUDE_INVOKED_BY"] = "memory_compile"

import argparse
import asyncio
import logging
import sys
from pathlib import Path

# Add scripts dir to path for local imports
sys.path.insert(0, str(Path(__file__).resolve().parent))


def _patch_sdk_parser():
    """Monkey-patch SDK to skip unknown message types (e.g. rate_limit_event).

    The SDK raises MessageParseError for unrecognized types. We patch the
    reference in client.py so process_query() yields None instead of crashing,
    and skip None in our iteration loop.
    """
    try:
        import claude_agent_sdk._internal.client as _client
        from claude_agent_sdk._errors import MessageParseError

        _original = _client.parse_message

        def _safe_parse(data):
            try:
                return _original(data)
            except MessageParseError as e:
                if "Unknown message type" in str(e):
                    return None
                raise

        _client.parse_message = _safe_parse
    except Exception as e:
        logging.warning("Could not patch SDK parser: %s", e)


_patch_sdk_parser()

from config import (
    CONCEPTS_DIR,
    CONNECTIONS_DIR,
    DAILY_DIR,
    KNOWLEDGE_DIR,
    MEMORY_DIR,
    ROOT_DIR,
    SCHEMA_FILE,
    now_iso,
)
from utils import (
    file_hash,
    list_raw_files,
    list_wiki_articles,
    load_state,
    read_wiki_index,
    save_state,
)


async def compile_daily_log(log_path: Path, state: dict) -> float:
    """Compile a single daily log into knowledge articles.

    Returns the API cost of the compilation.
    """
    from claude_agent_sdk import ClaudeAgentOptions, ResultMessage, query

    log_content = log_path.read_text(encoding="utf-8")
    schema = SCHEMA_FILE.read_text(encoding="utf-8")
    wiki_index = read_wiki_index()

    # Read existing articles for context
    existing_articles_context = ""
    existing = {}
    for article_path in list_wiki_articles():
        rel = article_path.relative_to(KNOWLEDGE_DIR)
        existing[str(rel)] = article_path.read_text(encoding="utf-8")

    if existing:
        parts = []
        for rel_path, content in existing.items():
            parts.append(f"### {rel_path}\n```markdown\n{content}\n```")
        existing_articles_context = "\n\n".join(parts)

    # List .brain/ files so the compiler knows what's already curated
    brain_dir = ROOT_DIR / ".brain"
    brain_files = ""
    if brain_dir.exists():
        brain_list = sorted(f.name for f in brain_dir.glob("*.md") if f.name != ".gitkeep")
        brain_files = ", ".join(brain_list)

    timestamp = now_iso()

    prompt = f"""You are a knowledge compiler. Your job is to read a daily conversation log
from a software development project and extract knowledge into structured wiki articles.

The project's domain context lives in `.brain/` (see the files listed below) — refer
to it when classifying terminology or interpreting domain-specific references in the log.

## Schema

{schema}

## Current Wiki Index

{wiki_index}

## Existing Wiki Articles

{existing_articles_context if existing_articles_context else "(No existing articles yet)"}

## .brain/ Files (curated source of truth)

The following .brain/ files already contain curated knowledge: {brain_files}

**Important:** Before creating a concept article, check if the topic is already
covered in .brain/ files. If a .brain/ file covers the topic, create a brief article
that references the .brain/ file (e.g., "See also: `.brain/DOMAIN.md` § section")
rather than restating its content. Knowledge articles should capture what .brain/ doesn't:
session-specific decisions, debugging lessons, workflow discoveries, and negative knowledge.

If `.brain/GLOSSARY.md` exists, use the terminology defined there correctly.

## Daily Log to Compile

**File:** {log_path.name}

{log_content}

## Your Task

Read the daily log above and compile it into wiki articles following the schema exactly.

### Rules:

1. **Extract key concepts** — Identify distinct concepts worth their own article.
   Don't force it — some days have 1-2, some have 5-7.
2. **Create concept articles** in `knowledge/concepts/` — One .md file per concept
   - Use the exact article format from the schema (YAML frontmatter + sections)
   - Include `sources:` in frontmatter pointing to the daily log file
   - Use `[[concepts/slug]]` wikilinks to link to related concepts
   - Write in encyclopedia style — neutral, comprehensive
3. **Create connection articles** in `knowledge/connections/` if this log reveals
   non-obvious relationships between 2+ existing concepts
4. **Update existing articles** if this log adds new information
   - Read the existing article, add new information, add the source, update the date
5. **Update knowledge/index.md** — Add new entries to the table
   - Each entry: `| [[path/slug]] | One-line summary | source-file | {timestamp[:10]} |`
   - Update "Last compiled" date
6. **Append to knowledge/log.md** — Add a timestamped entry:
   ```
   ## [{timestamp}] compile | {log_path.name}
   - Source: daily/{log_path.name}
   - Articles created: [[concepts/x]], [[concepts/y]]
   - Articles updated: [[concepts/z]] (if any)
   ```

### File paths:
- Write concept articles to: {CONCEPTS_DIR}
- Write connection articles to: {CONNECTIONS_DIR}
- Update index at: {KNOWLEDGE_DIR / 'index.md'}
- Append log at: {KNOWLEDGE_DIR / 'log.md'}

### Quality standards:
- Every article must have complete YAML frontmatter
- Key Points section should have 3-5 bullet points
- Details section should have 2+ paragraphs
- Related section should reference other articles or .brain/ files
- Sources section should cite the daily log with specific claims
"""

    cost = 0.0

    try:
        async for message in query(
            prompt=prompt,
            options=ClaudeAgentOptions(
                cwd=str(ROOT_DIR),
                allowed_tools=["Read", "Write", "Edit", "Glob", "Grep"],
                permission_mode="acceptEdits",
                max_turns=30,
            ),
        ):
            if message is None:
                continue
            if isinstance(message, ResultMessage):
                cost = message.total_cost_usd or 0.0
                print(f"  Cost: ${cost:.4f}")
    except Exception as e:
        print(f"  Error: {e}")
        return 0.0

    # Update state
    rel_path = log_path.name
    state.setdefault("ingested", {})[rel_path] = {
        "hash": file_hash(log_path),
        "compiled_at": now_iso(),
        "cost_usd": cost,
    }
    state["total_cost"] = state.get("total_cost", 0.0) + cost
    save_state(state)

    return cost


def main():
    parser = argparse.ArgumentParser(description="Compile daily logs into knowledge articles")
    parser.add_argument("--all", action="store_true", help="Force recompile all logs")
    parser.add_argument("--file", type=str, help="Compile a specific daily log file")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be compiled")
    args = parser.parse_args()

    state = load_state()

    # Determine which files to compile
    if args.file:
        target = Path(args.file)
        if not target.is_absolute():
            target = DAILY_DIR / target.name
        if not target.exists():
            target = ROOT_DIR / args.file
        if not target.exists():
            print(f"Error: {args.file} not found")
            sys.exit(1)
        to_compile = [target]
    else:
        all_logs = list_raw_files()
        if args.all:
            to_compile = all_logs
        else:
            to_compile = []
            for log_path in all_logs:
                rel = log_path.name
                prev = state.get("ingested", {}).get(rel, {})
                if not prev or prev.get("hash") != file_hash(log_path):
                    to_compile.append(log_path)

    if not to_compile:
        print("Nothing to compile — all daily logs are up to date.")
        return

    print(f"{'[DRY RUN] ' if args.dry_run else ''}Files to compile ({len(to_compile)}):")
    for f in to_compile:
        print(f"  - {f.name}")

    if args.dry_run:
        return

    # Compile each file sequentially
    total_cost = 0.0
    for i, log_path in enumerate(to_compile, 1):
        print(f"\n[{i}/{len(to_compile)}] Compiling {log_path.name}...")
        cost = asyncio.run(compile_daily_log(log_path, state))
        total_cost += cost
        print(f"  Done.")

    articles = list_wiki_articles()
    print(f"\nCompilation complete. Total cost: ${total_cost:.2f}")
    print(f"Knowledge base: {len(articles)} articles")


if __name__ == "__main__":
    main()
