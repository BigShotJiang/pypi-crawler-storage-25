"""
Memory flush — extracts knowledge from conversation context.

Spawned by session-end.py or pre-compact.py as a background process. Reads
pre-extracted conversation context from a .md file, uses the Claude Code SDK
to decide what's worth saving, and appends the result to today's daily log.

Usage:
    uv run --project ops/memory python ops/memory/scripts/flush.py <context_file.md> <session_id>
"""

from __future__ import annotations

# Recursion prevention: set BEFORE any imports that might trigger Claude
import os
os.environ["CLAUDE_INVOKED_BY"] = "memory_flush"

import asyncio
import json
import logging
import subprocess
import sys
import time
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent.parent.parent  # repo root
MEMORY_DIR = ROOT / "ops" / "memory"
DAILY_DIR = MEMORY_DIR / "daily"
SCRIPTS_DIR = MEMORY_DIR / "scripts"
LAST_FLUSH_FILE = MEMORY_DIR / "last-flush.json"
COMPILE_STATE_FILE = MEMORY_DIR / "state.json"
TIMEZONE = "Europe/Oslo"

logging.basicConfig(
    filename=str(MEMORY_DIR / "flush.log"),
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def load_flush_state() -> dict:
    if LAST_FLUSH_FILE.exists():
        try:
            return json.loads(LAST_FLUSH_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save_flush_state(state: dict) -> None:
    LAST_FLUSH_FILE.write_text(json.dumps(state), encoding="utf-8")


def append_to_daily_log(content: str, section: str = "Session") -> None:
    """Append content to today's daily log."""
    now = datetime.now(ZoneInfo(TIMEZONE))
    log_path = DAILY_DIR / f"{now.strftime('%Y-%m-%d')}.md"

    if not log_path.exists():
        DAILY_DIR.mkdir(parents=True, exist_ok=True)
        log_path.write_text(
            f"# Daily Log: {now.strftime('%Y-%m-%d')}\n\n## Sessions\n\n## Memory Maintenance\n\n",
            encoding="utf-8",
        )

    time_str = now.strftime("%H:%M")
    entry = f"### {section} ({time_str})\n\n{content}\n\n"

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(entry)


def _patch_sdk_parser():
    """Monkey-patch SDK to skip unknown message types (e.g. rate_limit_event).

    The SDK raises MessageParseError for unrecognized types.
    We patch the reference in client.py so process_query() yields None
    instead of crashing, and skip None in our iteration loop.
    """
    try:
        import claude_agent_sdk._internal.client as _client
        from claude_agent_sdk._errors import MessageParseError

        _original = _client.parse_message

        def _safe_parse(data):
            try:
                return _original(data)
            except MessageParseError as e:
                if "Unknown message type" in str(e):
                    msg_type = data.get("type", "?") if isinstance(data, dict) else "?"
                    logging.debug("Skipping unknown SDK message type: %s", msg_type)
                    return None
                raise

        _client.parse_message = _safe_parse
        logging.debug("SDK parser patched for unknown message type handling")
    except Exception as e:
        logging.warning("Could not patch SDK parser: %s", e)


_patch_sdk_parser()


async def run_flush(context: str) -> str:
    """Use Claude Code SDK to extract knowledge from conversation context."""
    from claude_agent_sdk import ClaudeAgentOptions, query, AssistantMessage, TextBlock

    prompt = f"""Review the conversation context below and respond with a concise summary
of important items that should be preserved in the daily log.
Do NOT use any tools — just return plain text.

Format your response as a structured daily log entry with these sections:

**Context:** [One line about what the user was working on]

**Key Exchanges:**
- [Important Q&A or discussions]

**Decisions Made:**
- [Any decisions with rationale]

**Lessons Learned:**
- [Gotchas, patterns, or insights discovered]

**Negative Knowledge (what was tried and didn't work):**
- [Approaches that failed and why — this prevents repeating mistakes]

**Action Items:**
- [Follow-ups or TODOs mentioned]

**.brain/ Writeback Candidates:**
- [Insights that might belong in .brain/ files — note which file: DOMAIN.md, DECISIONS.md, STACK.md, RISKS.md, GLOSSARY.md, etc.]

Skip anything that is:
- Routine tool calls or file reads
- Content that's trivial or obvious
- Trivial back-and-forth or clarification exchanges

Only include sections that have actual content. If nothing is worth saving,
respond with exactly: FLUSH_OK

## Conversation Context

{context}"""

    response = ""

    try:
        async for message in query(
            prompt=prompt,
            options=ClaudeAgentOptions(
                cwd=str(ROOT),
                allowed_tools=[],
                max_turns=2,
            ),
        ):
            if message is None:
                continue  # skipped unknown message type
            if isinstance(message, AssistantMessage):
                for block in message.content:
                    if isinstance(block, TextBlock):
                        response += block.text
    except Exception as e:
        import traceback
        logging.error("Claude Code SDK error: %s\n%s", e, traceback.format_exc())
        response = f"FLUSH_ERROR: {type(e).__name__}: {e}"

    return response


COMPILE_AFTER_HOUR = 14  # 2 PM local time


def maybe_trigger_compilation() -> None:
    """If it's past the compile hour and any daily log is uncompiled, run compile.py."""
    now = datetime.now(ZoneInfo(TIMEZONE))
    if now.hour < COMPILE_AFTER_HOUR:
        return

    # Check if ANY daily log needs compilation, not just today's
    ingested = {}
    if COMPILE_STATE_FILE.exists():
        try:
            compile_state = json.loads(COMPILE_STATE_FILE.read_text(encoding="utf-8"))
            ingested = compile_state.get("ingested", {})
        except (json.JSONDecodeError, OSError):
            pass

    has_uncompiled = False
    for log_path in sorted(DAILY_DIR.glob("*.md")):
        prev = ingested.get(log_path.name, {})
        if not prev or prev.get("hash") != sha256(log_path.read_bytes()).hexdigest()[:16]:
            has_uncompiled = True
            break

    if not has_uncompiled:
        return

    compile_script = SCRIPTS_DIR / "compile.py"
    if not compile_script.exists():
        return

    logging.info("End-of-day compilation triggered (after %d:00)", COMPILE_AFTER_HOUR)

    cmd = [
        "uv",
        "run",
        "--project",
        str(MEMORY_DIR),
        "python",
        str(compile_script),
    ]

    try:
        log_handle = open(str(MEMORY_DIR / "compile.log"), "a")
        subprocess.Popen(
            cmd,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            cwd=str(ROOT),
            start_new_session=True,
        )
    except Exception as e:
        logging.error("Failed to spawn compile.py: %s", e)


def main():
    if len(sys.argv) < 3:
        logging.error("Usage: %s <context_file.md> <session_id>", sys.argv[0])
        sys.exit(1)

    context_file = Path(sys.argv[1])
    session_id = sys.argv[2]

    logging.info("flush.py started for session %s, context: %s", session_id, context_file)

    if not context_file.exists():
        logging.error("Context file not found: %s", context_file)
        return

    # Deduplication: skip if same session was flushed within 60 seconds
    state = load_flush_state()
    if (
        state.get("session_id") == session_id
        and time.time() - state.get("timestamp", 0) < 60
    ):
        logging.info("Skipping duplicate flush for session %s", session_id)
        context_file.unlink(missing_ok=True)
        return

    # Read pre-extracted context
    context = context_file.read_text(encoding="utf-8").strip()
    if not context:
        logging.info("Context file is empty, skipping")
        context_file.unlink(missing_ok=True)
        return

    logging.info("Flushing session %s: %d chars", session_id, len(context))

    # Run the LLM extraction
    response = asyncio.run(run_flush(context))

    # Append to daily log
    if "FLUSH_OK" in response:
        logging.info("Result: FLUSH_OK")
        append_to_daily_log(
            "FLUSH_OK - Nothing worth saving from this session", "Memory Flush"
        )
    elif "FLUSH_ERROR" in response:
        logging.error("Result: %s", response)
        append_to_daily_log(response, "Memory Flush")
    else:
        logging.info("Result: saved to daily log (%d chars)", len(response))
        append_to_daily_log(response, "Session")

    # Update dedup state
    save_flush_state({"session_id": session_id, "timestamp": time.time()})

    # Clean up context file
    context_file.unlink(missing_ok=True)

    # End-of-day auto-compilation
    maybe_trigger_compilation()

    logging.info("Flush complete for session %s", session_id)


if __name__ == "__main__":
    main()
