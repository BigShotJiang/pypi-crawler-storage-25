# Knowledge Compiler Schema

This file is the specification for the knowledge compilation pipeline.
The compiler (Claude via Agent SDK) follows these rules exactly.

```
daily/          = source code    (immutable conversation logs)
LLM             = compiler       (transforms logs into knowledge)
knowledge/      = executable     (compiled, indexed articles)
lint            = test suite     (validates knowledge integrity)
queries         = runtime        (answers questions from the KB)
```

---

## Three-Layer Architecture

1. **`ops/memory/daily/`** — Immutable daily conversation logs. One file per day (`YYYY-MM-DD.md`). Written by `flush.py`, never edited after creation.
2. **`knowledge/`** — LLM-compiled knowledge articles. Created and maintained by `compile.py`. Three subdirectories: `concepts/`, `connections/`, `qa/`.
3. **This file (`SCHEMA.md`)** — The specification. The compiler reads this to know what to produce.

---

## Relationship to .brain/

The `.brain/` directory is the **curated source of truth** — manually maintained, distilled, concise. The `knowledge/` directory is **auto-compiled conversation knowledge** — automated, incremental, growing.

**Rules for the compiler:**
- Before creating a concept article, check if the topic is already covered in `.brain/` files (DOMAIN.md, REGULATORY.md, STACK.md, DECISIONS.md, GLOSSARY.md, etc.)
- If a `.brain/` file covers the topic, create a brief article that **references** the .brain/ file rather than restating its content
- Knowledge articles capture what `.brain/` doesn't: session-specific decisions, debugging lessons, workflow discoveries, negative knowledge (what was tried and failed)
- If the project has domain-specific terminology, use it per `.brain/GLOSSARY.md`

---

## Article Formats

### Concept Articles (`knowledge/concepts/`)

Atomic knowledge units. One concept per file.

```markdown
---
title: "Concept Name"
aliases: [alternate-name, abbreviation]
tags: [domain, technical, business, regulatory, mvp, architecture]
sources:
  - "daily/2026-04-15.md"
created: 2026-04-15
updated: 2026-04-15
---

# Concept Name

[2-4 sentence core explanation]

## Key Points
- [3-5 bullet points capturing the essential knowledge]

## Details
[2+ paragraphs, encyclopedia-style, third person]

## Related
- [[concepts/related-concept]] — How it connects
- See also: `.brain/DOMAIN.md` § section name (if applicable)

## Sources
- [[daily/2026-04-15.md]] — What was learned and in what context
```

### Connection Articles (`knowledge/connections/`)

Cross-cutting insights that link two or more concepts.

```markdown
---
title: "Connection: X and Y"
connects:
  - "concepts/concept-x"
  - "concepts/concept-y"
sources:
  - "daily/2026-04-15.md"
created: 2026-04-15
updated: 2026-04-15
---

# Connection: X and Y

## The Connection
[What links these concepts]

## Key Insight
[The non-obvious takeaway]

## Evidence
[Where this connection was observed]

## Related
- [[concepts/concept-x]]
- [[concepts/concept-y]]
```

### Q&A Articles (`knowledge/qa/`)

Filed answers to questions asked via `query.py --file-back`.

```markdown
---
title: "Q: Original Question"
question: "The exact question asked"
consulted:
  - "concepts/article-1"
  - "concepts/article-2"
filed: 2026-04-15
---

# Q: Original Question

## Answer
[Synthesized answer with [[wikilink]] citations]

## Sources Consulted
- [[concepts/article-1]] — What it contributed
- [[concepts/article-2]] — What it contributed

## Follow-Up Questions
- [Questions this answer raises]
```

---

## Index Format (`knowledge/index.md`)

The master catalog. This is the **primary retrieval mechanism** — the LLM reads this first, picks relevant articles, then reads them in full.

```markdown
# Knowledge Base Index

Last compiled: YYYY-MM-DD

| Article | Summary | Sources | Updated |
|---------|---------|---------|---------|
| [[concepts/example-concept]] | One-line summary of what this article covers | daily/2026-04-15.md | 2026-04-15 |
| [[connections/example-connection]] | One-line summary of the cross-cutting insight | daily/2026-04-15.md, daily/2026-04-16.md | 2026-04-16 |
```

Rules:
- One row per article
- Summary must be a single line, under 100 characters
- Keep sorted: concepts first, then connections, then Q&A
- Update the "Last compiled" date on every compilation run

---

## Build Log Format (`knowledge/log.md`)

Append-only log of all compilation and query activity.

```markdown
# Build Log

## [2026-04-15T18:30:00] compile | Daily Log 2026-04-15
- Source: daily/2026-04-15.md
- Articles created: [[concepts/x]], [[concepts/y]]
- Articles updated: (none)
- Connections found: [[connections/x-and-y]]

## [2026-04-16T10:00:00] query (filed) | question summary
- Question: How does the auth flow work?
- Consulted: [[concepts/auth-workflow]], [[concepts/session-tokens]]
- Filed to: [[qa/auth-flow]]
```

---

## Compilation Workflow

When `compile.py` invokes the compiler with a daily log:

1. **Read** the daily log being compiled
2. **Read** the current `knowledge/index.md` to understand what exists
3. **Read** existing articles that might need updating
4. **Check** `.brain/` files for topic overlap before creating new concepts
5. **Create** new concept articles for genuinely new knowledge
6. **Update** existing articles if the daily log adds new information (update the `updated` date and add the new source)
7. **Create** connection articles when cross-cutting insights emerge
8. **Update** `knowledge/index.md` with new/changed entries
9. **Append** to `knowledge/log.md` documenting what was done

---

## Query Workflow

When `query.py` processes a question:

1. **Read** `knowledge/index.md`
2. **Select** 3-10 relevant articles based on the question
3. **Read** selected articles in full
4. **Synthesize** an answer with `[[wikilink]]` citations
5. If `--file-back`: create a Q&A article, update index, append to log

---

## Lint Checks

Seven validation checks for knowledge base health:

| # | Check | Type | Catches | Severity |
|---|-------|------|---------|----------|
| 1 | Broken links | Structural | `[[wikilinks]]` to non-existent articles | error |
| 2 | Orphan pages | Structural | Articles with zero inbound links | warning |
| 3 | Orphan sources | Structural | Daily logs not yet compiled | warning |
| 4 | Stale articles | Structural | Source logs changed since compilation | warning |
| 5 | Missing backlinks | Structural | A links to B but B doesn't link back | suggestion |
| 6 | Sparse articles | Structural | Articles under 200 words | suggestion |
| 7 | Contradictions | LLM | Conflicting claims across articles | warning |

Checks 1-6 are free (pure file analysis). Check 7 uses the Claude Agent SDK.

---

## Conventions

- **Wikilinks:** `[[path/to/article]]` — no `.md` extension
- **Dates:** ISO 8601 (`YYYY-MM-DD`, `YYYY-MM-DDTHH:MM:SS`)
- **Filenames:** lowercase, hyphens, no spaces (`my-concept-name.md`)
- **Writing style:** Encyclopedia-style, third person, concise
- **Frontmatter:** YAML, required on every article
- **Source attribution:** Every article must cite at least one daily log
- **Tags:** Use from this set: `domain`, `regulatory`, `technical`, `business`, `mvp`, `architecture`, `workflow`, `tooling`, `integration`
