# research/ideas/ — Incubating ideas

Home for ideas that aren't yet actionable work. One markdown file per idea. Grows with the project; pruned by the weekly groomer (see `ops/ideas/README.md`).

**When to put something here instead of a GitHub Issue:**
- It's a concept, spec sketch, or exploratory thinking — not a task with a clear done-state.
- It needs design discussion before it can be scoped.
- It might be rejected after thinking, not implemented.

If you can write a crisp one-line issue title and imagine closing it, it's a GitHub Issue, not an incubating idea.

---

## File naming

```
research/ideas/{slug}-{YYYY-MM-DD}.md
```

- `slug` — kebab-case, descriptive, 2–5 words (`solo-leveling-hud`, `cross-assistant-event-schema`)
- Date is **created** date, not last-touched. Files never get renamed.

---

## Required frontmatter

Every file must start with this YAML block:

```yaml
---
status: raw          # raw | shaping | promoted | rejected | archived
created: 2026-04-22  # YYYY-MM-DD, set once at creation
last_touched: 2026-04-22  # YYYY-MM-DD, bump every meaningful edit
promoted_to: null    # or GitHub issue URL / session id once promoted
tags: [ux, infra]    # free-form, lowercase, keep short
---
```

Files without frontmatter are flagged by the groomer and ignored by automation.

---

## Status lifecycle

| Status | Meaning | Transitions to |
|---|---|---|
| `raw` | Captured, not yet thought through. | `shaping`, `archived` |
| `shaping` | Actively being reasoned about; content is growing. | `promoted`, `rejected`, `archived` |
| `promoted` | Graduated to a GitHub Issue or `/mar:session-start`. File retained as historical record with `promoted_to` filled in. | terminal |
| `rejected` | Explicit no, with reason in file body so it isn't re-litigated. | terminal |
| `archived` | Silent no — untouched too long, not worth an explicit reject. | terminal |

Terminal statuses stay in the folder for reference. Don't delete.

---

## File body convention

Below the frontmatter, structure as you like — but the groomer and promotion flow look for these sections if present:

- **Problem** — one-paragraph statement of what's being addressed.
- **Sketch** — the idea itself; pseudocode, bullet lists, prose, whatever.
- **Open questions** — things you don't yet know.
- **Rejection reason** (if `status: rejected`) — one paragraph capturing *why*, so the idea isn't re-proposed six months later.

See `ops/ideas/README.md` §3 for the full lifecycle rationale.
