# mar-ideas — Idea Lifecycle System

Lightweight system for capturing, incubating, promoting, and retiring ideas across the this project. Built to stop the decay that every `notes.md`-style scratch pad eventually suffers.

Design philosophy: **two homes split by maturity, one weekly reviewer to keep both honest.** No custom tooling, no external trackers — reuses GitHub Issues, the existing `research/` convention, and the scanner cron pattern already in use elsewhere in `ops/`.

---

## 1. Why this exists

Every project accumulates a scratch file — `notes.md`, `TODO.md`, `ideas.txt` — and every one eventually rots. The failure mode is predictable:

- Mixed lifecycles: "fix a typo" sits next to "rewrite the architecture" with no distinction.
- No reviewer: items get added but never revisited, so the file grows monotonically.
- No graduation path: an idea that's ready to build has nowhere to go that isn't the same file.

This system addresses each failure directly:

| Failure mode | Fix |
|---|---|
| Mixed lifecycles | Split into **two homes** by maturity (tracker vs incubation) |
| No reviewer | **Weekly groomer** cron proposes promotions, archives, and staleness flags |
| No graduation path | Explicit **promotion flow**: incubation file → GitHub Issue or `/session-start` |

---

## 2. The three-home model

| Home | Contents | Lifecycle |
|---|---|---|
| **GitHub Issues** | Actionable work — features, bugs, concrete todos | open → closed |
| **`research/ideas/*.md`** | Incubating concepts, spec sketches, exploratory thinking | raw → shaping → promoted / rejected / archived |
| **Scratch (ephemeral)** | Fleeting one-liners captured mid-session | Triage within 7 days: promote or delete |

Why two structured homes and not one:

- Forcing a two-paragraph half-baked concept into a GitHub Issue makes the tracker noisy and the concept shallow.
- Forcing a one-line actionable task into a dated markdown file makes the folder bloated and the task invisible.
- The split lets each home specialise. Issues stay crisp and closeable. `research/ideas/` stays verbose and reflective.

### What goes where — examples

| Item | Home | Why |
|---|---|---|
| "Wire meta-level replan" | GitHub Issue | Clear scope, clear done-state, 1-line title fits |
| "Add Isak's competitor to COMPETITORS.md" | GitHub Issue | Actionable, short |
| Solo Leveling-style read-only HUD overlay | `research/ideas/` | Needs design thinking before it's shapeable |
| Cross-assistant event schema for OpenClaw / Hermes interop | `research/ideas/` | Spec-sketch, not yet a task |
| "Check if uv is on PATH after reboot" | Scratch → delete once verified | Fleeting |

---

## 3. Idea lifecycle (`research/ideas/`)

Each incubating idea is a single markdown file: `research/ideas/{slug}-{YYYY-MM-DD}.md`.

### Frontmatter schema

```yaml
---
status: raw | shaping | promoted | rejected | archived
created: 2026-04-22
last_touched: 2026-04-22
promoted_to: null           # or GH issue URL / session id
tags: [ux, infra, oss]
---
```

### Status meanings

- **raw** — captured, not yet thought through
- **shaping** — actively being reasoned about; content is growing
- **promoted** — graduated to a GitHub Issue or a `/session-start`. File retained as historical record with `promoted_to` filled in.
- **rejected** — decided against. Reason captured in the file body. File retained so the rejection rationale isn't re-litigated.
- **archived** — stale, neither promoted nor explicitly rejected. Kept for reference.

### Promotion paths

```
research/ideas/foo.md (shaping)
        │
        ├──► GitHub Issue           (for actionable work)
        │    status: promoted, promoted_to: <issue url>
        │
        ├──► /session-start         (for work big enough to warrant a phase-planned session)
        │    status: promoted, promoted_to: <session id>
        │
        ├──► rejected               (explicit no)
        │    status: rejected
        │
        └──► archived               (silent no — groomer suggests this after N days untouched)
             status: archived
```

---

## 4. The weekly groomer

Same pattern as `ops/cron/weekly-competitor-scan` and `weekly-state-update` — a scanner cron that reads the current state, proposes changes, and writes a human review doc. No auto-actions.

### Inputs

- All files in `research/ideas/` (read frontmatter + body)
- Open GitHub Issues labeled `idea` (via `gh issue list --label idea`)
- `ops/ideas/queue/pending/` (previous proposals still awaiting review)

### Outputs

1. **Human review doc** — `ops/cron/output/weekly-idea-groom-YYYY-MM-DD.md`
   - Summary of what moved this week
   - Staleness report (ideas untouched > 30 days)
   - Proposed promotions, archives, and tag cleanups

2. **Machine queue** — one YAML file per proposal under `ops/ideas/queue/pending/`:

```yaml
# ops/ideas/queue/pending/2026-04-22-hud-spec.yaml
id: 2026-04-22-hud-spec
source: research/ideas/solo-leveling-hud-2026-04-22.md
proposed_action: create_issue        # or archive, reject, split
title: "Read-only HUD overlay for session events"
body: |
  Ambient dashboard subscribing to ops/hud/events.ndjson.
  Read-only, event-driven, optional. See source for full spec.
labels: [idea, ux]
created: 2026-04-22
status: pending
```

### Groomer rules (v1)

- Idea with `status: raw` and `last_touched` > 14 days ago → propose move to `shaping` or `archived`
- Idea with `status: shaping` and `last_touched` > 30 days ago → propose `promoted` (with draft issue body) or `archived`
- Open Issue labeled `idea` with no activity > 60 days → propose close
- `research/ideas/` file with no frontmatter → flag, no auto-action

---

## 5. Human-in-the-loop via Telegram

The groomer is fire-and-forget. Interactivity happens through the **already-running Telegram-bound Claude Code session** (see `knowledge/concepts/telegram-channel-state-persistence`), not through the cron.

### Flow

```
┌─────────────────┐     writes YAML      ┌──────────────────────┐
│ weekly-idea-    │ ──────────────────►  │ ops/ideas/queue/     │
│ groomer (cron)  │                      │   pending/*.yaml     │
└─────────────────┘                      └──────────────────────┘
                                                   │
                                    drained by     │
                                                   ▼
                                         ┌──────────────────────┐
                                         │ Live Claude session  │
                                         │ (tmux, Telegram      │
                                         │  plugin active)      │
                                         └──────────────────────┘
                                                   │
                                  sends proposal   │   receives reply
                                                   ▼
                                         ┌──────────────────────┐
                                         │ Telegram (phone)     │
                                         │   approve / decline  │
                                         │   defer / chat       │
                                         └──────────────────────┘
```

### Reply grammar

The live Claude parses your Telegram replies. Recognised forms:

| Reply | Effect |
|---|---|
| `approve` | Runs `gh issue create` with the proposal. Moves queue file to `approved/`. Updates `research/ideas/` source's frontmatter to `promoted`. |
| `decline [reason]` | Moves to `declined/` with reason appended. Updates source to `rejected`. |
| `defer [Nd]` | Moves to `deferred/`. Groomer re-proposes after N days (default 14). |
| anything else | Normal conversation. Live Claude has the proposal + source file loaded as context. Discuss freely; eventually you say approve/decline/defer. |

### Why Telegram via the existing Claude session, not a standalone bot

- The Telegram plugin already binds to a live Claude. Reusing it means approval *and* free-form chat both work in one channel.
- A standalone Python Telegram bot could do inline approve/decline buttons but couldn't chat about the idea. Splitting into "bot for buttons, Claude for chat" fragments the UX.
- Bot-API tokens bind one webhook at a time — two bots means two pairings, two allowlists, two maintenance targets.

### Known failure mode: dead Claude session

If the live Claude / tmux session is down, Telegram goes dark. Proposals queue up silently. Mitigations, in order of effort:

- **tmux-resurrect + tmux-continuum** — survives reboots (already a tracked action item)
- **Watchdog cron** — pings the live session daily; if unresponsive for 24h, sends plain email/SMS: "Claude session down, N proposals waiting"
- **Proposal TTL** — groomer skips pending proposals > 30 days old so the queue self-limits

These are v2. v1 assumes the live session is up or the user tolerates silence.

---

## 6. Folder map

```
ops/ideas/
├── README.md                  # this file
├── queue/
│   ├── pending/               # <proposal-id>.yaml — awaiting Telegram review
│   ├── approved/              # promoted to GH issue, kept for audit
│   ├── declined/              # rejected, with reason
│   └── deferred/              # re-propose after N days
└── scripts/                   # (future) helpers — queue drainer, validator

research/ideas/                # NOT in ops/ — content lives here
├── README.md                  # frontmatter convention
└── {slug}-{YYYY-MM-DD}.md     # one file per incubating idea

ops/scheduled/
└── weekly-idea-groomer.md     # scanner spec, same shape as other scheduled scans
```

Mirrors the existing split: `ops/memory/` holds the pipeline machinery, `knowledge/` + `ops/memory/daily/` hold the content. Same pattern here — `ops/ideas/` is machinery, `research/ideas/` is content.

---

## 7. Commands

| Command | Purpose |
|---|---|
| `/mar:idea-new <slug>` | Scaffold a new `research/ideas/{slug}-{date}.md` with frontmatter; fills body conversationally |
| `/mar:idea-status` | Summary of `research/ideas/` by status + open `idea`-labeled issues + queue counts |
| `/mar:idea-promote <slug>` | Manual promotion — create GH issue from a `research/ideas/` file without waiting for the weekly groomer |
| `/mar:review-proposals` | In a Telegram-bound Claude session: drain `queue/pending/`, send each proposal to Telegram, execute the reply |

Command spec files live at `.claude/commands/mar/{name}.md`.

---

## 8. Open questions / not-yet-built

This document is the **spec**. Nothing in `ops/ideas/queue/` or `ops/cron/weekly-idea-groomer.md` is implemented yet. Landing them is a future session's work.

Outstanding decisions:

- **Push vs pull delivery.** Should proposals auto-push to Telegram (e.g., daily at 09:00) or wait for `/review-proposals`? Recommendation: start pull. Push is easier to add later than to calm down.
- **Labels / tag taxonomy.** Initial set: `idea`, `ux`, `infra`, `oss`, `research-needed`, `good-first-issue`. Grow from usage, not from upfront design.
- **Ownership when open-sourced.** External contributors filing ideas — do they go straight to Issues (normal OSS flow) or into `research/ideas/` first? Default: Issues for them, `research/ideas/` remains the maintainer incubation space.
- **Watchdog for dead sessions.** Defer to v2.
- **Proposal TTL.** 30 days is a guess. Tune from the first month of groomer output.

---

## 9. Conversation provenance

This system was designed in conversation on 2026-04-22. Key decisions, captured so future edits know what was load-bearing:

- **Two homes, not one.** Explicitly rejected the single-file approach (`IDEAS.md`) and the single-tracker approach (everything in GitHub Issues) because of lifecycle mismatch.
- **No external tools.** Rejected Obsidian/Linear/Notion because (a) lock-in, (b) hostile to agent automation, (c) bad signal for an OSS project intended for others to fork.
- **Reuse the scanner pattern.** The groomer is not a new primitive — it's `weekly-competitor-scan` with different inputs. Same cron infrastructure, same output convention, same approval flow.
- **Telegram HITL via the live Claude, not a dedicated bot.** Chat-about-the-idea is the feature that makes this nice; a buttons-only bot would remove it.
- **Paperclip-level ambition.** This system exists to prevent decay, not to become a product. If it grows features beyond "capture, review weekly, promote or retire," it's drifting.
