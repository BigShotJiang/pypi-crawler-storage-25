# mar-workflow — Development Session Framework (v2)

Custom AI-native development workflow for this project. Two-level decomposition (session → phases → stages), contract-shaped plans, fresh-context review + functional tester at Stage 5, 3-way iterate-able gates, plan.md as single source of truth.

**Design spec**: `ops/workflow/WORKFLOW-V2-DRAFT.md` (the full v2 design doc). This README is the operational guide.

**Rollout state**: Step 1 is implemented — agent-only execution against the local repo. Step 2 (issue/PR creation, worktree-per-phase, agents posting to PR, hard-block on `gh` failures during the run) remains deferred.

---

## 1. Quick start

```
/mar:session-start "<one-line goal>"     # interactive picker — service, size, guidance, autonomy
/mar:plan                                 # research + planning for current sub-stage; pauses at gate
/mar:approve plan | /mar:iterate plan "<note>" | /mar:reject plan
/mar:ship                                 # execute → test → refine → simplify → re-test → verify → review + tester
/mar:integrate                            # commit story + .brain/ writeback proposals
/mar:approve integrate                    # apply writebacks + commit
/mar:session-archive
```

The user touches the keyboard between gates. `autonomous` mode auto-passes every gate; only safeguards interrupt.

---

## 2. Core concepts

Three nouns:

- **Session** — one initiative end-to-end. E.g. "add voice transcription to MVP." Lives in `sessions/active/<id>/` until archived.
- **Phase** — a chunk of a session, with its own deep research → plan → execute → test → refine → simplify → verify → review/tester cycle. L/XL sessions have multiple phases; S/M sessions collapse to one implicit phase.
- **Stage** — a step within a phase (research, plan, execute, test, refine, simplify, verify, review, tester, integrate). Each stage runs as a fresh-context sub-agent dispatched via the Task tool.

**plan.md is canonical.** The phase plan is the single source of truth for the phase. Issue body and PR body are *derived views* — never hand-edited. Any plan revision triggers regeneration of derived views.

---

## 3. Size-adaptive flow

| Size | Typical scope | Meta layer | Phases | Stages per phase |
|---|---|---|---|---|
| **S**  | Bug fix or isolated refactor (~½ day) | — | 1 | plan → execute → test → verify → review + tester |
| **M**  | Feature in one service (1–2 days) | — | 1 | full cycle |
| **L**  | Cross-cutting feature or new subsystem (2–5 days) | yes | 2–4 | full cycle per phase |
| **XL** | New service or major rewrite (>1 week) | yes | 4+ | full cycle per phase + between-phase compaction |

For trivially small edits (typo, config tweak, <30 min), don't open a session — edit directly and commit. The framework would add more cost than value.

---

## 4. Stage 2 split (planning)

In v2, the planning stage is **split into three sub-stages**, each with its own gate:

- **2a — Meta-plan** (L/XL only). Decompose into phases. No issues created. Gate: 3-way.
- **2b — Issue scaffolding**. Generate proposed issue bodies from meta-plan. Step 1: written to `proposed-issue-bodies.md` for review. Step 2: `gh issue create` per phase, with hard-block on failure. Gate: 3-way.
- **2c — Phase plan** (per-phase, just-in-time). Phase-plan-agent writes `plan.md`; orchestrator runs `derive-issue-body.py` to regenerate `issue-body.md`. Hard-block if derivation fails. Gate: 3-way.

`/mar:plan` advances whichever sub-stage is current.

S/M sessions skip 2a and 2b; only 2c runs.

---

## 5. 3-way gates

Every gate accepts approve / reject; most also accept iterate:

- **approve** — advance to next stage.
- **iterate** — apply free-text direction *without* losing position. Re-runs the current stage's agent with the direction; for plan iterate, also re-derives `issue-body.md`. The plan and the issue must agree before iterate completes.
- **reject** — discard the artifact (renamed `<file>.rejected-<ts>`) and back up to the prior stage.

Gates: `research`, `meta-plan`, `issue-scaffolding`, `plan`, `integrate`.

`issue-scaffolding` is **not directly iterable** — issue bodies are derived views, so adjustments route through the source: phase-1's body comes from its plan (`/mar:iterate plan`), later phases' stub bodies come from the meta-plan (`/mar:iterate meta-plan`). Approve/reject still apply.

`/mar:iterate` is distinct from `/mar:continue` (re-runs a stage as-is) and `/mar:replan` (full reset).

---

## 6. Autonomy matrix

| Mode | Research review | Plan gate | Between-phase | Merge | Integrate |
|---|---|---|---|---|---|
| `interactive` | gate | gate | ack | user | gate |
| `normal` | — | gate | ack | user | gate |
| `streamlined` | — | gate | — auto | — auto | gate |
| `autonomous` | — | — auto | — auto | — auto | — auto (no writebacks) |

**Autonomous mode contract.** After `/mar:session-start`, the user provides no further input until the session completes. All approval gates auto-pass. The only thing that interrupts is a stuck-state safeguard firing.

**Always-on safeguards** (every mode, including autonomous):
- manual-step block
- scope violation
- secret-file write
- **review-wall hit** — review-agent ↔ refine-agent loop hit its 3-round cap
- **tester-fail after cap** — tester-agent ↔ refine-agent loop hit its 2-round cap
- `[QUESTION]` present on plan in autonomous mode
- **gh failure** (Step 2) — hard block on issue/PR create or edit failure
- `derive-issue-body.py` failure (Step 1)

---

## 7. Stage 5 — review + tester (the big v2 addition)

After pre-PR verify passes, the orchestrator dispatches **two agents in parallel**:

- **review-agent** (Opus 4.7 xhigh, fresh-context) — quality review. Reads diff + plan.md + deviations.md. Posts categorized comments. Every comment carries one of `[blocker]` / `[must-fix]` / `[nit]` / `[idea]`. Verdict: `approve` or `request-changes`.
- **tester-agent** (Opus 4.7 high, fresh-context) — functional / behavior validation. Runs the feature against realistic scenarios from plan §"Tester scenarios" (CLI invocations, library consumers, eval scripts, dev-server smoke). Verdict: `pass` or `fail`.

**Aggregation**:
- Both clear → integrate gate.
- Either flags issues → refine-agent reads new comments and patches; round counter increments after refine checkpoint; re-dispatch review + tester.

**Round caps** (hardcoded): 3 review rounds, 2 tester rounds. Beyond cap → review-wall / tester-fail-cap safeguard fires.

Refine-agent may mark a comment `won't fix — <reason>`; that comment is final unless the user re-flags it.

**Step 1 (current)**: review-agent and tester-agent run in **local-file mode** — output goes to `phases/<id>/review-comments.md` and `phases/<id>/tester-report.md`. No GitHub interaction.

**Step 2 (deferred)**: same agents post via `gh pr review` and `gh pr comment` against the draft PR. User can comment on the PR; refine-agent picks up user comments at next checkpoint.

---

## 8. Plan v2 schema

Sections (full template at `ops/workflow/templates/plan.md.template`):

- **Contract** — public API, inputs/outputs, invariants, idempotency, error semantics
- **Non-functional** — perf / reliability / security / observability
- **Definition of Done** — checklist (template defaults + service-CLAUDE.md inheritance)
- **Scope** — files in / files out (read by `check-scope.py` PreToolUse hook)
- **Approach** — design decisions only, no pseudo-code; uses `[DECIDED]` / `[ASSUMED]` / `[QUESTION]` marks
- **Test matrix** — every row has a command and a measurable acceptance
- **Tester scenarios** — concrete invocations for tester-agent at Stage 5
- **Success criteria** — each cites a Test matrix row
- **Risks** — with mitigations
- **Manual steps** — declared upfront
- **Size**, **Commit preview**

Approach explicitly forbids pseudo-code. Phase-plan-agent's prompt enforces this.

---

## 9. Agent roster

All agents are **Opus 4.7**. Thinking spectrum: `medium / high / xhigh / max`. No Sonnet, no `low`.

| Agent | Effort | Role |
|---|---|---|
| research-agent | high | scan + distill (`.brain/`, codebase, web) |
| meta-plan-agent | max | decompose phases (Stage 2a) |
| phase-plan-agent | xhigh | v2 plan.md (Stage 2c) |
| execute-agent | xhigh | implement the plan |
| test-agent | medium | run declared Test matrix |
| refine-agent | high | patch failures + PR comments |
| simplify-agent | medium | cleanup within scope |
| verify-agent | medium | pre-PR adherence (binary pass/fail) |
| **review-agent** | **xhigh** | quality review on PR (new) |
| **tester-agent** | **high** | functional / eval validation (new) |
| integrate-agent | medium | commit story + `.brain/` writebacks |
| retrospect-agent | xhigh | framework audit (post-archive) |

Every stage = fresh sub-agent invocation via Task tool. No agent inherits another's conversation. Only the orchestrator persists across stages, and it compacts at phase boundaries (mandatory for L/XL).

---

## 10. Multi-project parallelism

The framework supports multiple Claude Code instances in parallel:

- **Different repos, parallel CC instances** — each repo has its own `sessions/active/`, own `.claude/`, own scope hook, own `$CLAUDE_PROJECT_DIR`. No shared state.
- **Same repo, multiple CC windows** — per-window pointer at `.claude/sessions/pointer-<CLAUDE_CODE_SSE_PORT>` keys session state by CC instance. `current-session.sh` / `set-session.sh` / `check-scope.py` all resolve via the per-window key.

**Step 2** adds: per-repo `gh` auth handled via the user's normal credential setup.

---

## 11. Project organization

Sessions target the current repo. If the repo organizes work by service (`services/api/`, `services/web/`, etc.), `/mar:session-start` lets you pick one; otherwise the session runs repo-wide.

- **Service-organized repos** — sessions bind to a service, scope hook fences edits to the chosen service's tree.
- **Single-package repos** — sessions run repo-wide, scope hook fences edits to plan-declared paths only.
- **Internal ops/*** — direct edits, no session ceremony.

`/mar:session-start` does not create GitHub repos or git submodules. Repo-level setup is the user's responsibility.

---

## 12. Repo layout

```
ops/workflow/
  README.md                    # this file
  WORKFLOW-V2-DRAFT.md         # design spec
  test-findings.md             # retrospect-agent appends here
  templates/
    session.md.template
    meta-plan.md.template
    plan.md.template            # v2 schema
    issue-body.md.template      # derived from plan.md (Step 1 local; Step 2 = GitHub issue body)
    review-comments.md.template # review-agent output (local mode)
    tester-report.md.template   # tester-agent output (local mode)
    deviations.md.template      # execute-agent's structured deviation log
    verification.md.template    # narrowed: pass/fail adherence + DoD evidence
    phase-summary.md.template
    integration.md.template
  scripts/
    current-session.sh          # resolves the per-window session pointer
    set-session.sh              # writes the per-window session pointer
    check-scope.py              # PreToolUse hook for scope enforcement
    derive-issue-body.py        # plan.md → issue-body.md (canonical → derived view)

.claude/
  agents/                       # agent definitions
  commands/mar/                 # slash command definitions

sessions/
  active/<session-id>/          # current sessions
    session.md
    meta-research.md            # L/XL only
    meta-plan.md                # L/XL only
    proposed-issue-bodies.md    # L/XL only, after Stage 2b
    phases/<phase-id>/
      research.md
      plan.md                   # canonical
      issue-body.md             # derived from plan.md
      progress.md               # gitignored
      deviations.md             # tracked — execute-agent's deviation log
      test-report.md
      simplify-report.md
      verification.md
      review-comments.md        # Step 1 local mode
      tester-report.md          # Step 1 local mode
      summary.md
    INTEGRATION.md
    SUMMARY.md                  # written at archive time
  archive/<session-id>/         # archived sessions (immutable)
```

**Gitignore**: `sessions/active/*/phases/*/progress.md` (noisy), `.claude/sessions/pointer-*`, `.claude/.current-session`.

---

## 13. Plan marks — `[DECIDED] / [ASSUMED] / [QUESTION]`

Plan-agent tags every non-trivial decision in the Approach section:

- **`[DECIDED]`** — committed direction, defensible from research + `.brain/`.
- **`[ASSUMED]`** — reasonable default, flagged for user review.
- **`[QUESTION]`** — narrow, specific question only the user can answer.

Guidance modes set the `[QUESTION]` budget:
- `light` — 0–2 `[QUESTION]`s (bias `[ASSUMED]`)
- `normal` — 2–4
- `deep` — 4–8

In **autonomous** mode, every `[QUESTION]` must be resolved to `[ASSUMED]` with explicit fallback (or the feature dropped). The plan gate refuses to advance if any `[QUESTION]` remains.

---

## 14. Iterate semantics

`/mar:iterate <gate> "<direction>"` — apply free-text direction at an open gate without losing position.

Routing:
- "Research deeper on X" — research-agent runs again, **appends** to research.md (raw notes preserved). plan-agent then re-derives plan.md from updated research.
- "Adjust plan: <change>" — plan-agent regenerates plan.md applying direction.
- "Wrong scope" — equivalent to reject.

After plan regeneration: `derive-issue-body.py` runs automatically. **Hard-block on failure** — the plan and issue body must agree, or we don't move (Step 1 hard-block; Step 2 extends to `gh issue edit`).

---

## 15. What stays from v1

- Size-adaptive flow.
- Two-level decomposition: session → phases → stages.
- `[DECIDED]` / `[ASSUMED]` / `[QUESTION]` plan marks.
- Guidance modes (light / normal / deep).
- Autonomy modes (interactive / normal / streamlined / autonomous).
- Artifact-as-memory principle — compaction is lossless.
- Fresh-context verification (now split: pre-PR verify for adherence, review-agent for quality).
- PreToolUse scope hook (`ops/workflow/scripts/check-scope.py`, using `$CLAUDE_PROJECT_DIR`).
- Per-window session pointer keyed by `$CLAUDE_CODE_SSE_PORT`.
- Knowledge pipeline (`ops/memory/`) integration at integrate only.
- `retrospect-agent` writing to `ops/workflow/test-findings.md`.

---

## 16. Step 1 vs Step 2 — what's live now

**Step 1 (current)** — agent-only execution, local files only:
- Plan v2 schema, all agents in place.
- review-agent + tester-agent in local-file mode.
- 3-way gates and `/mar:iterate` with `derive-issue-body.py`.
- Stage 2 split (2a / 2b / 2c).
- `/mar:session-start` scaffolds service directories (no GitHub repo/submodule creation).

**Step 2 (deferred)**:
- Agent-implementable: `gh issue create` / `gh issue edit` (Stage 2b/2c), `gh pr create --draft` (Stage 4), review-agent/tester-agent posting to PR (Stage 5), worktree-per-phase, squash merge with plan's commit preview, hard-block on any `gh` failure during the run.

---

## 17. Command surface

### Session lifecycle
- `/mar:session-start` — interactive picker, scaffolds `sessions/active/<id>/`.
- `/mar:session-resume [id]` — load session.
- `/mar:session-list` — show active sessions.
- `/mar:session-archive [id]` — move to `sessions/archive/`.
- `/mar:stop` — hard halt.
- `/mar:status` — current state, compact.
- `/mar:retrospect <id> [focus]` — fresh-context framework audit of an archived session. Appends findings to `ops/workflow/test-findings.md`. Does not modify the archive.

### Stage / sub-stage drivers
- `/mar:plan` — advance the current planning sub-stage (2a / 2b / 2c). Pauses at the current gate.
- `/mar:ship` — build loop + Stage 5. Pauses at integrate gate.
- `/mar:integrate` — produce INTEGRATION.md. Pauses at integrate gate.

### Gate actions (3-way)
- `/mar:approve <gate>` — advance.
- `/mar:iterate <gate> "<direction>"` — refine without losing position.
- `/mar:reject <gate>` — discard and revert.

### Adjustments
- `/mar:continue <stage> "<note>"` — re-run a stage with an extra note (no gate change).
- `/mar:replan [meta]` — discard current plan + research, restart.

---

## 18. Artifacts as memory

State lives in files, not context:
- `session.md` — top-level state, timeline.
- `meta-plan.md`, `meta-research.md` — session-level (L/XL).
- `phases/<id>/{research, plan, deviations, test-report, simplify-report, verification, review-comments, tester-report, summary}.md` — phase-level.
- `INTEGRATION.md` — final commit story + `.brain/` writeback proposals.
- `SUMMARY.md` — written at archive.

Compaction is lossless because every state is reconstructible from disk. Between-phase compaction (mandatory for L/XL) summarizes the completed phase into a paragraph and drops the rest.

Per-stage compaction within a phase is unnecessary — every stage is already a fresh sub-agent.

---

## 19. Rollback

v2 (Step 1) rollback is fully contained in:
- `.claude/agents/`
- `.claude/commands/mar/`
- `ops/workflow/`
- `.github/ISSUE_TEMPLATE/mar-phase.md` (added per submodule in Step 2)

Reverting those four locations restores v1 (or removes Step 1 changes if v1 has been deleted in the meantime).
