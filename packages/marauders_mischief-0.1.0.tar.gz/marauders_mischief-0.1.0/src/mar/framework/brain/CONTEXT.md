# Context

What we're building, who for, and where we are in the journey. This file is the first thing agents read at the start of every session — keep it current and concise.

## What we're building

<!-- One paragraph: the product, the problem it solves. -->

## Who it's for

<!-- The target user, the pain point, the alternative they'd otherwise use. -->

## Current phase

<!-- e.g. "Research", "MVP build", "First customers", "Scaling". Update when the phase materially shifts (rarely — quarterly is normal). -->
