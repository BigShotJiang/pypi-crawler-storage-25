# Stack

The technical building blocks of this project — what tools are in use, what they're used for, and what's been deliberately chosen against.

## Languages and runtimes

<!-- e.g. Python 3.12, Node 20, etc. -->

## Frameworks and libraries

<!-- Major dependencies with one-line "why this one". -->

## Infrastructure

<!-- Hosting, databases, queues, observability. -->

## Decisions log

<!-- Append-only. Each: date, decision, rationale, alternatives considered. -->
