# State

What's happening *right now*. Active workstreams, current blockers, near-term milestones. This file reflects current state — overwrite freely; history lives in DECISIONS.md.

## Active workstreams

<!-- Bullet list. Each: short name, owner (if multiple people), what stage it's in. -->

## Blockers

<!-- Things that are stuck and why. -->

## Near-term milestones

<!-- The next 1–3 things expected to land, with rough dates. -->
