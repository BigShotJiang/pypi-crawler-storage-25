# Risks

Things that could derail the project. Append as identified; mark mitigated or accepted as they resolve.

Format per entry:

```
## <risk in one line>

**Likelihood**: low | medium | high
**Impact**: low | medium | high
**Mitigation**: what we're doing (or have planned).
**Status**: open | mitigated <date> | accepted <date>
```

---

<!-- Append below. -->
