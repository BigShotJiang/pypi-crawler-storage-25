# Decisions

Append-only log of meaningful decisions and their reasoning. Use this when a choice would otherwise be lost ("why did we pick X over Y?").

Format per entry:

```
## YYYY-MM-DD [tag] short title

**Decision**: one sentence.

**Rationale**: why this won.

**Alternatives considered**: what else we looked at, and why it lost.

**Status**: active | superseded by <date> | reversed
```

---

<!-- Append below. Newest at the top is fine; chronological order is also fine. Pick one and stick to it. -->
