---
description: Scaffold a new incubating idea at research/ideas/{slug}-{today}.md.
---

Create a new idea file and help the user fill it in conversationally.

## Step 1 — Parse arguments

`$ARGUMENTS` is either empty, a bare slug, or "slug description text follows".

- If empty: ask the user for a 2–5 word kebab-case slug and one or two sentences on the idea, then continue.
- If first token(s) look like a slug and rest is prose: split on first whitespace-bounded break where prose starts. Slug is first 1–5 kebab-case words; everything after is the body.
- Normalize the slug: lowercase, replace spaces and underscores with `-`, strip leading/trailing `-`, collapse runs of `-`. Reject or transform anything non-`[a-z0-9-]`.

## Step 2 — Collision check

Glob `research/ideas/{slug}-*.md`. If any match exists:

- Tell the user the existing file path and ask whether they want to edit it instead (recommend yes), pick a new slug, or add a suffix (`{slug}-2`).
- Stop here unless they pick a new slug or confirm a suffix.

## Step 3 — Create the file

Write `research/ideas/{slug}-{YYYY-MM-DD}.md` where the date is today. Use Write tool. Initial content:

```markdown
---
status: raw
created: YYYY-MM-DD
last_touched: YYYY-MM-DD
promoted_to: null
tags: []
---

# {Title — humanize the slug}

## Problem
_(fill in)_

## Sketch
_(fill in)_

## Open questions
_(fill in)_
```

Substitute the slug's title-case humanization for `{Title — humanize the slug}` (e.g., `hud-overlay` → `HUD overlay`, `cross-assistant-event-schema` → `Cross-assistant event schema`).

## Step 4 — Fill the body

If the user supplied prose in `$ARGUMENTS` (step 1): use it to populate the Sketch section. If it naturally splits into problem/sketch/open-questions, do that; otherwise put it all under Sketch.

If no prose was supplied: ask "What's the idea? One paragraph is fine." and wait for their reply. Then populate as above on the next turn.

Infer 1–3 tags from the content (pick from common buckets: `ux`, `infra`, `oss`, `ops`, `research-needed`, `domain`, `ai`). Update the `tags: []` line in frontmatter. Keep `last_touched` equal to `created` for now.

## Step 5 — Report

Keep it short:

```
Saved: research/ideas/{slug}-{date}.md
status: raw | tags: [..]
Groomer picks it up on the next Tuesday scan.
```

## Guardrails

- Don't create the file before the slug is clean and the collision check has passed.
- Don't commit the file — that's the user's call.
- If the user's description is a single fleeting line ("check X"), recommend GitHub Issue instead of `research/ideas/` (two paragraphs or more is the rough threshold).
- Never set `status` to anything other than `raw` on creation.
