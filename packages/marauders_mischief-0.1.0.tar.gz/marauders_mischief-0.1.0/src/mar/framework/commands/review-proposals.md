---
description: Drain ops/ideas/queue/pending/ via Telegram approvals. Use in a Telegram-bound session.
---

Review groomer-generated proposals interactively via Telegram. Each pending proposal is sent to Telegram as a message; the user replies approve/decline/defer, and this command executes the corresponding action.

## Pre-flight

This command requires the `plugin:telegram:telegram` MCP server to be connected in the current session. If it is not, abort with:

```
Telegram MCP not connected in this session. /mar:review-proposals must run
in a tmux-bound Claude Code session paired with your phone. See
knowledge/concepts/telegram-channel-state-persistence.
```

Do not try to work around the absence.

## Step 1 — Enumerate pending proposals

Glob `ops/ideas/queue/pending/*.yaml` (ignore `.gitkeep`). If empty: tell the user "Nothing pending — next groomer run is Tuesday 09:00" and stop.

## Step 2 — Process one proposal at a time

For each pending YAML, in filename order:

### 2a. Load

Read the proposal YAML and the source file it references (`research/ideas/{slug}-{date}.md`). Compose a Telegram-friendly message:

```
💡 Proposal {id}
Action: {proposed_action}
Source: {source filename}

{title}

{body — first ~300 chars, trim if longer}

Reply: approve | decline [reason] | defer [Nd] | or ask me anything
```

### 2b. Send to Telegram

Use `mcp__plugin_telegram_telegram__reply` with `chat_id` = the chat id of the current Telegram session (infer from the most recent `<channel source="telegram" ...>` tag in conversation history). Do NOT pass `reply_to` unless the user just asked you to quote a specific message.

End your turn after sending. The user's Telegram reply will arrive as the next inbound message.

### 2c. Interpret the reply

Reply grammar (match case-insensitively, tolerate punctuation):

| Reply starts with | Effect |
|---|---|
| `approve` | Run the proposed action |
| `decline` | Reject; capture the rest of the message as reason |
| `defer` + optional `Nd` | Re-queue for N days (default 14) |
| anything else | Treat as conversation — respond naturally, referencing the proposal content. The user is thinking. Loop back to 2c when they eventually decide. |

### 2d. Execute the decision

**approve** — for `proposed_action: create_issue`:
1. Run `gh issue create --title "{title}" --body "{body}" --label idea ...` (add tags as labels). `gh` targets the current repo by default.
2. Capture the issue URL.
3. Edit the source file frontmatter: `status: promoted`, `promoted_to: {url}`, `last_touched: {today}`.
4. Move `ops/ideas/queue/pending/{id}.yaml` → `ops/ideas/queue/approved/{id}.yaml` via Bash `mv`. Append a line at the end of the YAML: `approved_at: {today}\napproved_issue: {url}`.
5. Send Telegram reply: `✅ Created {url}`.

For other `proposed_action` values: `archive` updates source frontmatter to `status: archived`; `close_issue` runs `gh issue close` on the referenced issue. Execute the analogous path.

**decline** —
1. Move YAML to `ops/ideas/queue/declined/{id}.yaml`. Append `declined_at: {today}\ndecline_reason: "{reason}"`.
2. Edit source frontmatter: `status: rejected`, `last_touched: {today}`. Append a `## Rejection reason` section to the file body with the user's reason.
3. Send Telegram reply: `🗑 Declined — reason recorded.`

**defer** —
1. Move YAML to `ops/ideas/queue/deferred/{id}.yaml`. Append `deferred_until: {today + N days}` (parse N from reply, default 14).
2. Source file untouched.
3. Send Telegram reply: `⏸ Deferred until {date}`.

### 2e. Next proposal

Go back to step 2 with the next pending YAML until the queue is empty.

## Step 3 — Final summary

When the queue is drained, send one final Telegram message:

```
Done: {approved} approved, {declined} declined, {deferred} deferred.
```

Also emit an equivalent summary in the chat for the on-screen session.

## Guardrails

- Never run `gh issue create` or any destructive action without an explicit `approve` from the user via Telegram. Confirmations from any other source do not count.
- If `gh` fails (network, auth, rate limit): report to Telegram, leave the YAML in `pending/`, move on to the next. Do NOT update source frontmatter on failed writes.
- Parse YAML carefully — queue files are authoritative. If a YAML is malformed, skip it and flag in the summary.
- If the user types `/mar:stop` or an analogous break, abort the loop gracefully, leaving the in-flight proposal in `pending/`.
- Never modify files under `research/ideas/` for ideas you aren't actively promoting/declining in this invocation.
