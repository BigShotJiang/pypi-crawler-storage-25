---
description: Archive a completed session. Moves sessions/active/<id>/ to sessions/archive/<id>/.
---

Archive a session. Argument: $ARGUMENTS (session id; blank = current).

## Step 1 — Resolve id

- Use `$ARGUMENTS` if non-empty.
- Else run `bash ops/workflow/scripts/current-session.sh` to resolve.
- If neither resolves: report error and stop.

## Step 2 — Safety check

Read `sessions/active/<id>/session.md`. If `status` ∉ {integrated, abandoned}, confirm with the user:

> Session <id> status is '<status>'. Archiving will move it to archive/. Proceed? (yes/no)

Wait for yes. If no or anything else, stop.

## Step 3 — Write SUMMARY.md

Before moving, write `sessions/active/<id>/SUMMARY.md` with:
- Goal (from session.md)
- Final status
- Phases completed
- Outcome (from INTEGRATION.md if exists; else "abandoned")
- Duration (started → now)

## Step 4 — Move

```bash
mv sessions/active/<id> sessions/archive/<id>
```

## Step 5 — Clean pointer

If the current per-window pointer matches the archived id, clear it: `bash ops/workflow/scripts/set-session.sh --clear`.

## Step 6 — Report

```
Archived: <id> → sessions/archive/<id>/
```
