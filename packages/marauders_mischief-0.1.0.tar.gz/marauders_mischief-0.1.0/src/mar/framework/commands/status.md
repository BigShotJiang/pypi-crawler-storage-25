---
description: Show current session status — phase, stage, outstanding items.
---

Show the current session's state compactly.

## Step 1 — Resolve

Run `bash ops/workflow/scripts/current-session.sh` to resolve. If it exits non-zero, show output of `/mar:session-list` instead.

## Step 2 — Load

Read:
- `sessions/active/<id>/session.md` — top-level state
- `meta-plan.md` if exists — phase list with status
- Current phase's `plan.md` if exists — scope, manual steps, DoD progress
- Current phase's `progress.md` if exists — last 5 lines
- Current phase's `review-comments.md` if exists — round + verdict
- Current phase's `tester-report.md` if exists — round + verdict

## Step 3 — Report

```
Session: <id>
  service: <s> | size: <z> | guidance: <g> | autonomy: <a>
  status: <status>

Phases:
  [x] 01-<slug>  → integrated
  [>] 02-<slug>  → in-progress, stage=execute
  [ ] 03-<slug>  → pending

Current phase (02-<slug>):
  plan DoD: <ticked/total>
  scope: <N files>  |  open [QUESTION]s: <K>  |  manual steps: <pending/total>
  review: round <n>/3, verdict=<approve|request-changes|—>
  tester: round <n>/2, verdict=<pass|fail|—>

Awaiting:
  <gate name + 3-way options if status=awaiting-approval, else "—">

Last activity (progress.md):
  <line>
  <line>
  <line>

Next: <suggested action based on status>
```

If status is `awaiting-approval`, the "Awaiting" block lists the three options for the open gate:

```
Awaiting: plan gate
  /mar:approve plan                  → advance
  /mar:iterate plan "<direction>"    → refine in place
  /mar:reject plan                   → revert to prior stage
```

Keep output under 35 lines. Skim-friendly.

## Rules

- Do NOT show budget — v2 dropped budget tracking.
- If review/tester rounds haven't started for the current phase, show `—` rather than `0`. The dash is a clearer "not yet" than zero.
