---
description: Reject a gate. Reverts to the prior stage. Usage — /mar:reject <gate>
---

Reject a gate. Arguments: `$ARGUMENTS` (gate name — `research` | `meta-plan` | `issue-scaffolding` | `plan` | `integrate`).

Reject = discard the artifact and back up to the prior stage. Use `/mar:iterate <gate> "<direction>"` instead if you want to *adjust* without discarding.

## Step 1 — Resolve session

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md. Error if the script exits non-zero.

## Step 2 — Confirm intent

Ask user (free-text):

> Reject `<gate>`? This will:
> - `research`: move research artifact aside and re-run research from scratch (interactive prompts for new direction)
> - `meta-plan`: discard meta-plan.md and return to meta-research stage
> - `issue-scaffolding`: discard proposed-issue-bodies.md and return to meta-plan stage
> - `plan`: discard the current phase's plan.md (and its derived issue-body.md) and return to research stage for that phase
> - `integrate`: discard INTEGRATION.md and return to verify stage; allows /mar:replan or `/mar:continue` actions
>
> Confirm? (yes/no)

If user wants to refine without discarding, point them at `/mar:iterate <gate> "<direction>"` and stop.

## Step 3 — Act

### research

1. Rename research artifact (`meta-research.md` at meta level, or `phases/<id>/research.md` at phase level) to `<name>.rejected-<timestamp>`.
2. Update session.md: `current_stage: research`, `status: in-progress`.
3. Log timeline.
4. Tell user to run `/mar:plan` again to restart research.

### meta-plan

1. Move `meta-plan.md` → `meta-plan.md.rejected-<timestamp>`.
2. Update session.md: `current_stage: meta-research`, `status: in-progress`.
3. Log timeline.

### issue-scaffolding

1. Move `proposed-issue-bodies.md` → `proposed-issue-bodies.md.rejected-<timestamp>`.
2. Update session.md: `current_stage: meta-plan`, `status: awaiting-approval`. The meta-plan re-opens its gate so the user can iterate the meta-plan if the issue scaffolding revealed a problem.
3. Log timeline.

### plan (phase-plan, Stage 2c)

1. Move the phase's `plan.md` → `plan.md.rejected-<timestamp>`.
2. Move the phase's `issue-body.md` → `issue-body.md.rejected-<timestamp>` (it's a derived view; rejecting plan.md invalidates it).
3. Update session.md: `current_stage: research`, `status: in-progress`.
4. Log timeline.

### integrate

1. Rename `INTEGRATION.md` → `INTEGRATION.md.rejected-<timestamp>`.
2. Update session.md: `current_stage: verify`, `status: in-progress`.
3. Suggest `/mar:replan` or `/mar:continue verify "<note>"`.

## Step 4 — Report

State what happened and what to do next.

## Rules

- Never delete artifacts; always rename with `.rejected-<timestamp>` suffix.
- Rejecting a phase's plan also discards the derived issue-body.md — the two must always agree, so reject takes both.
- After reject, the orchestrator does not auto-advance — user decides the next step.
- If the user wanted to refine rather than discard, point them at `/mar:iterate`.
