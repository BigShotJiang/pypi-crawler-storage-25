---
description: Re-run a stage with added direction. Usage — /mar:continue <stage> "<note>"
---

Re-run a stage of the current session with an added directive. Arguments: $ARGUMENTS

Expected format: `<stage> "<note>"` — e.g. `plan "go deeper on error handling"` or `manual-step openai-key`.

## Step 1 — Parse

Extract `<stage>` (first token) and `<note>` (rest). If stage is missing, error and show usage.

Valid stages:
- `research` | `plan` | `execute` | `test` | `refine` | `simplify` | `verify` | `integrate`
- Special: `manual-step <step-id>` — marks a manual step as complete and resumes from the blocking stage.

## Step 2 — Resolve session

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md.

## Step 3 — Dispatch

### For regular stages
Dispatch the corresponding agent with an extra input: `additional_direction: <note>`. The agent incorporates the note into its work without starting from scratch — it refines rather than redoes.

### For `manual-step`
1. Locate the manual step in the current phase's plan.md.
2. Mark it `[x]` in place.
3. Update session.md: find the blocking stage, resume from there by dispatching that stage's agent.
4. Log the manual completion in progress.md.

## Step 4 — Report

Same reporting shape as the stage's original command. After re-run completes, surface the updated output.

## Rules

- `/mar:continue` never skips gates. After a plan re-run, user still `/mar:approve plan`.
- `/mar:continue` is the refinement tool; `/mar:replan` is the reset tool. Know the difference.
