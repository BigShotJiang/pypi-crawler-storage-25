---
description: Pass a gate (research | meta-plan | issue-scaffolding | plan | integrate). Usage — /mar:approve <gate>
---

Pass a gate. Arguments: `$ARGUMENTS` (gate name).

Valid gates: `research`, `meta-plan`, `issue-scaffolding`, `plan`, `integrate`.

Each gate is **3-way** in v2: approve (this command) / iterate (`/mar:iterate <gate> "<direction>"`) / reject (`/mar:reject <gate>`).

## Step 1 — Resolve session and validate

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md.

- `research` → status must be `awaiting-approval`, current_stage `research-review`.
- `meta-plan` → status `awaiting-approval`, current_stage `meta-plan` (a.k.a. Stage 2a).
- `issue-scaffolding` → status `awaiting-approval`, current_stage `issue-scaffolding` (a.k.a. Stage 2b). Only valid for L/XL sessions.
- `plan` → status `awaiting-approval`, current_stage `plan` (a.k.a. Stage 2c, phase plan).
- `integrate` → status `awaiting-approval`, current_stage `integrate`, INTEGRATION.md must exist.

If preconditions fail, error stating which condition was not met.

## Step 2 — Act by gate

### research

1. Update session.md: `status: in-progress`, advance `current_stage` to `plan` (the planning sub-stage that follows research at this level). Timeline: `<ts> research approved`.
2. Re-enter `/mar:plan`'s Step 6 (run plan-agent — meta-plan-agent for meta level, phase-plan-agent for phase level). Do NOT re-run research.
3. Report: "Research approved. Running plan-agent next."

### meta-plan (Stage 2a — L/XL only)

1. Update session.md: `status: in-progress`, advance `current_stage` to `issue-scaffolding`. Timeline: `<ts> meta-plan approved`.
2. The next `/mar:plan` invocation will run Stage 2b (orchestrator derives proposed issue bodies).
3. Report: "Meta-plan approved. Run /mar:plan to proceed to issue scaffolding (Stage 2b)."

### issue-scaffolding (Stage 2b — L/XL only)

1. Update session.md: `status: in-progress`, advance `current_stage` to `plan` (Stage 2c — phase plan for phase 1, or whichever current_phase is set to). Timeline: `<ts> issue-scaffolding approved (Step 1 local preview)`.
2. **Step 1 (current)**: this is a sanity-check approval; no real GitHub issues are created yet. The `proposed-issue-bodies.md` file is recorded as approved.
3. **Step 2 (deferred)**: this approve will trigger `gh issue create` per phase. **Hard-block on any gh failure** — do not advance until issues exist.
4. Set `current_phase: phase-1` (or first phase from meta-plan) if not already set.
5. The next `/mar:plan` runs Stage 2c for the current phase.
6. Report: "Issue scaffolding approved. Run /mar:plan to draft the phase plan."

### plan (Stage 2c — phase plan)

1. Mark plan's `## Definition of Done` as user-approved (any unticked items get a session-timeline note: "User force-approved plan with N unchecked DoD items").
2. Update session.md: `status: in-progress`, advance `current_stage` to `execute`. Timeline: `<ts> plan approved (phase=<id>)`.
3. Report: "Plan approved. Run /mar:ship to execute."

### integrate (non-autonomous only)

1. Read INTEGRATION.md.
2. For each proposed `.brain/` writeback, ask the user per-entry (via AskUserQuestion) — accept / reject / edit. Apply accepted entries per CLAUDE.md writeback protocol.
3. Run the commit:
   - Step 1 (current — local only): stage plan-scoped files + session artifacts, commit using the message from INTEGRATION.md.
   - Step 2 (deferred): for `real` services, commit, push to origin, open draft PR via `gh`.
   - Never stage `sessions/active/*/phases/*/progress.md` (gitignored — double-check).
4. If a PR body exists and user wants a PR: Step 1 → "PR creation deferred to Step 2." Step 2 → `gh pr create`.
5. Update session.md: `status: integrated`.
6. Offer to archive: "Session integrated. Archive now with /mar:session-archive?"

## Rules

- Never commit without the user having seen INTEGRATION.md. If `/mar:approve integrate` is run too fast, show INTEGRATION.md contents first and confirm.
- Never push to a remote without explicit user request (and Step 2 wiring).
- If a writeback entry targets `.brain/PEOPLE.md`, refuse — that file is gitignored.
- Approve never bypasses scope hooks or always-on safeguards.
