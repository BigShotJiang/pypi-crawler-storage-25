---
description: Start a new development session. Interactive — picks service (if any), size, guidance, autonomy via AskUserQuestion.
---

You are starting a new development session. The goal is: $ARGUMENTS

## Step 1 — Collect configuration via AskUserQuestion

Do NOT ask via free-text. Use the AskUserQuestion tool with the questions below (batched in parallel where the options are independent).

### Question 1 — Service (skip if the project has no `services/` directory)

Many repos organize work by service or subproject (e.g. `services/api/`, `services/web/`). If this repo doesn't, skip Question 1 entirely — the session will run without a service binding.

Detection:
1. Run `test -d services && ls -1d services/*/ 2>/dev/null | xargs -n1 basename` to enumerate existing services.
2. If no services exist, skip Question 1. Set `service: null` in the session and proceed.

If services exist:
1. Filter out any service currently bound to an active session (glob `sessions/active/*/session.md`, read `service:` field, exclude matches).
2. Sort alphabetically.
3. Build the option list:
   - First option: `new service` (creates a new `services/<name>/` directory with a stub CLAUDE.md).
   - Fill the remaining up-to-3 slots with existing services.
   - If more than 3 existing services remain after filtering, document in the question text: "Additional services: `<name1>, <name2>, …` — type via 'Other' to pick one."

Description: "Which service does this session target?"

Treat the implicit "Other" answer as either (a) an existing service name (matches `services/<name>/` → use it), or (b) a new service to scaffold (Step 1a).

### Step 1a — Resolve service

Branch on the Question 1 answer:

- Existing service → no scaffolding. Proceed to Question 2.
- `new service` → ask one follow-up (plain text, NOT via AskUserQuestion):

  **Name**
  > Name the new service (lowercase, kebab-case, alphanumeric + dashes only, ≤30 chars — e.g. `api`, `worker`, `sandbox`).

  Validate: `^[a-z][a-z0-9-]{0,29}$`, not already under `services/`, not reserved (`meta`). Re-ask on invalid input.

  Then scaffold (Step 1b).

- `Other` (free-text) → if the string matches an existing `services/<dir>/`, use it. Otherwise treat as a new-service name and run Step 1b.

### Step 1b — Scaffold new service (directory + stub CLAUDE.md)

For a framework-managed scaffold, do the minimum: create the directory and a stub CLAUDE.md so the service has its own context anchor. Repo-level concerns (GitHub repo creation, submodules, monorepo wiring) are out of scope for `/mar:session-start` — handle those manually if your project needs them.

1. `mkdir -p services/<name>`
2. If `ops/workflow/templates/service-CLAUDE.md.template` exists, read it, substitute `{{SERVICE_NAME}}` and `{{DATE}}`, and write to `services/<name>/CLAUDE.md`. Otherwise write a minimal stub:
   ```markdown
   # <name>

   Service-specific context. Append a `## Definition of Done` section here
   to extend the framework's DoD checklist for this service.
   ```
3. Do NOT commit. The user commits the scaffold when ready.

Proceed to Question 2.

### Question 2 — Size

- Options:
  - `S` — bug fix or isolated refactor (~½ day)
  - `M` — feature in one service (1–2 days)
  - `L` — cross-cutting or new subsystem (2–5 days)
  - `XL` — new service or major rewrite (>1 week)
- When in doubt, size down — upgrading via `/mar:replan` mid-session is cheaper than paying meta-plan overhead on work that turns out small.
- For trivially small edits (typo, config tweak, <30 min), don't open a session at all — edit directly and commit.

### Question 3 — Guidance mode

- Options:
  - `light` — few questions, more assumptions
  - `normal` — balanced
  - `deep` — more questions for uncertain terrain

### Question 4 — Autonomy

Controls which gates pause for human input across the whole loop. See `ops/workflow/README.md` for the full gate matrix.

- Options:
  - `interactive` — pauses at: research review, meta-plan, each phase-plan, between phases (L/XL), integrate. Maximum hand-holding.
  - `normal` — pauses at: meta-plan, each phase-plan, between phases (L/XL), integrate.
  - `streamlined` — pauses at: meta-plan, each phase-plan, integrate. No between-phase ack.
  - `autonomous` — fully hands-off after this command. Auto-passes meta-plan, every phase-plan, integrate. Only stops on always-on safeguards (manual step, scope violation, review-wall, tester-fail-cap, unresolved `[QUESTION]`, secret-file write).

## Step 2 — Collect session description (required, all modes)

Prompt the user with plain text (NOT AskUserQuestion):

> One paragraph: what is this session about? What are you trying to achieve, what constraints matter, what has already been tried? This feeds the research agent and is the **only** human input `autonomous` sessions get, so say enough for the agent to work without you.

Requirements:
- Non-empty. If empty or `skip`, re-prompt: "Required. A goal slug is not enough context for research-agent — add at least 2–3 sentences."
- No upper bound — multi-paragraph fine.

Store the reply verbatim for use in Step 4 (substituted as `{{DESCRIPTION}}`).

## Step 3 — Check for conflicts

Read `sessions/active/*/session.md` (via Glob + Read). If any active session has `service` matching the chosen service (or no-service collision in single-repo mode), refuse:

> Active session already exists for `<service or repo>`: `<existing-id>`. Archive or stop it first with `/mar:session-archive` or `/mar:stop`.

## Step 4 — Create session

1. Compute session id: `YYYY-MM-DD-<service-or-repo-slug>-<goal-slug>` where goal-slug is a 2–4-word kebab from the goal. If no service, use a short repo identifier or just the goal slug.
2. Create dir: `sessions/active/<session-id>/`
3. Read `ops/workflow/templates/session.md.template`. Substitute placeholders:
   - `{{SESSION_ID}}` — computed id
   - `{{SERVICE}}` — chosen service (or `null`)
   - `{{GOAL}}` — goal slug (≤80 chars summary of $ARGUMENTS)
   - `{{SIZE}}`, `{{GUIDANCE}}`, `{{AUTONOMY}}` — from questions 2/3/4
   - `{{STARTED}}` — current timestamp ISO8601
   - `{{DESCRIPTION}}` — the paragraph from Step 2

   Write to `sessions/active/<session-id>/session.md`.
4. Create `phases/` subdir.
5. Run `bash ops/workflow/scripts/set-session.sh <session-id>` to write the per-window pointer (keyed by `$CLAUDE_CODE_SSE_PORT`). Lets parallel CC windows each drive their own session.

## Step 5 — Report

Output:
```
Session created: <session-id>
  service: <service or none>
  size: <size>
  guidance: <mode>
  autonomy: <interactive|normal|streamlined|autonomous>

Next: /mar:plan
```

Do not proceed past `/mar:session-start`. The user runs `/mar:plan` next.

## Rules

- Do NOT prompt for budget — v2 dropped budget tracking.
- Do NOT require services. If the repo has no `services/` directory, sessions run repo-wide with `service: null`.
- Do NOT create GitHub repos or git submodules. Repo-level setup is the user's responsibility, not the framework's.
- Do NOT refuse `autonomous` mode based on service type — autonomous mode works against local files in v0.1.
