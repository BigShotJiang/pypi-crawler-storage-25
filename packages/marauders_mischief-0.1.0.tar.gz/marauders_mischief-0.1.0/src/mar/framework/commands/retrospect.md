---
description: Audit an archived session for workflow-framework improvements. Appends findings to ops/workflow/test-findings.md.
---

Run a fresh-context workflow-framework audit on an archived session. Arguments: $ARGUMENTS (session id, required; optional audit-focus paragraph after).

Usage:
- `/mar:retrospect 2026-04-22-note-indexer-initial-build`
- `/mar:retrospect 2026-04-22-note-indexer-initial-build "focus on between-phase handoffs and artifact consumption"`

## Step 1 — Parse and validate

1. Extract `<session_id>` (first whitespace-delimited token of `$ARGUMENTS`). Error if missing:
   > Usage: `/mar:retrospect <archived-session-id> [optional-focus-paragraph]`. Run `/mar:session-list` to see archived ids.

2. Extract `<audit_focus>` (rest of `$ARGUMENTS` after the first token). May be empty.

3. Verify `sessions/archive/<session_id>/session.md` exists. If not:
   - Check `sessions/active/<session_id>/session.md` — if there, refuse: "Session is still active. Archive it first with `/mar:session-archive <id>`, then retrospect."
   - Otherwise: "No archived session with id `<session_id>`. Run `/mar:session-list` to see archived sessions."

## Step 2 — Print breadcrumb

```
[retrospect: <session_id> | stage: → dispatch retrospect-agent]
```

## Step 3 — Dispatch retrospect-agent

Dispatch via Task:
- `subagent_type: retrospect-agent`
- inputs: `session_id` (the argument), `audit_focus` (may be empty).

Agent reads: full archive dir, `ops/workflow/README.md`, all `.claude/commands/mar/*.md`, all `.claude/agents/*.md`, git log/diff scoped to the session.

Agent writes: appended findings at `ops/workflow/test-findings.md` under `## Outstanding`, each tagged `[retrospect:<session_id>]` and severity `blocker|should-fix|nit|idea`.

## Step 4 — Show the return

Surface the agent's return verbatim plus the top 2–3 new findings in the test-findings file (grep for the session's tag). Summary:

```
[retrospect: <session_id> | complete]
Findings: <blocker-count> blocker / <should-fix-count> should-fix / <nit-count> nit / <idea-count> idea
Appended to: ops/workflow/test-findings.md

Top highlights:
  1. <one-line>
  2. <one-line>
  3. <one-line>

Review the full list in ops/workflow/test-findings.md (grep for `retrospect:<session_id>`).
```

## Rules

- Do not re-run on an already-audited session without explicit user request — retrospect is an expensive agent call. If `test-findings.md` already contains `[retrospect:<session_id>]` entries, warn:
  > Session `<session_id>` has already been retrospected (<N> prior entries). Re-run anyway? (yes/no)
  and wait for confirmation.
- Do not modify session archive — archives are immutable.
- Do not write to `.brain/` or `research/`.
- Retrospect does not gate, approve, or reject anything. It only produces findings.
