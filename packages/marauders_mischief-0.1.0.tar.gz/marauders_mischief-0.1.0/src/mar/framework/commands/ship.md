---
description: Run execute → test → refine → simplify → re-test → pre-PR verify → review-agent + tester-agent (Stage 5). Pauses at integrate gate.
---

Kick off the v2 build pipeline for the current phase. Sequential build loop, then parallel review + tester at Stage 5. Step 1 runs review-agent and tester-agent in **local-file mode** — they write to artifact files, not GitHub. Step 2 swaps the backend to PR comments.

## Step 1 — Preconditions

1. Run `bash ops/workflow/scripts/current-session.sh`. Error if it exits non-zero.
2. Read session.md. Error if `status` ≠ one of {`in-progress`, `awaiting-approval`}.
3. Read the current phase's plan.md. Error if plan gate not passed (timeline contains `<ts> plan approved` or equivalent).
4. Confirm `phases/<id>/issue-body.md` exists (derived at plan gate). If missing, error: "issue body not derived — run /mar:plan to regenerate".
5. **Credentials gate** (hard-blocking, session-level):
   ```bash
   python3 ops/workflow/scripts/check-credentials.py --session <id> --json
   ```
   - Exit 0: all declared credentials present. Continue to Step 2.
   - Exit 1: parse the JSON `missing` array. For each missing credential, surface via `AskUserQuestion`:
     ```
     Missing: <NAME> (scope=<global|project>)
       location: <path>
       setup:    <one-liner from meta-plan>

     Options:
       I've set it now — re-check
       Abort the session
     ```
     Loop until either all-present (continue) or user aborts (`status: paused`, `last_activity: now`, stop).
   - The script verifies presence-by-name only, never reads values. If the session has `## Credentials` set to `none`, the gate trivially passes.

If any precondition fails, state the reason and stop.

## Step 2 — Build loop (sequential, fresh sub-agents)

For sizes S / M / L / XL, the build loop is the same set of stages. Each stage = fresh sub-agent invocation via the Task tool.

| Stage | Agent | When |
|---|---|---|
| execute | execute-agent | always |
| test | test-agent | always |
| refine | refine-agent | only if test-agent reported failures (≤2 cycles) |
| simplify | simplify-agent | size ≥ M |
| re-test | test-agent | only if simplify made non-trivial changes |
| pre-PR verify | verify-agent | always |

For each stage:
1. Print breadcrumb:
   ```
   [session: <id> | phase: <phase-id> | stage: <prev> → <stage>]
   ```
2. Update `session.md`: `current_stage: <stage>`, `last_activity: now`.
3. Dispatch the agent with `session_id`, `phase_id`, `plan_path`, plus stage-specific paths.
4. Receive return:
   - `status: complete` → next stage
   - `status: paused` (manual step) → surface, stop
   - `status: replan-needed` → surface, stop
   - `status: test-fail` → if size ≥ M, dispatch refine-agent (max 2 cycles)
   - `status: fail` (verify) → bounce to refine-agent with verification.md as input

After verify reports `pass`, advance to Stage 5.

If verify reports `fail` after refine cycles exhausted, pause with `{reason: stuck, recommend: replan}`.

## Step 3 — Stage 5: review-agent + tester-agent (parallel, iterative)

Once pre-PR verify passes, dispatch review-agent and tester-agent **in parallel** (single message, two Task tool calls).

```
[session: <id> | phase: <phase-id> | stage: verify → review+tester (round 1)]
```

### Dispatch (round N)

- **review-agent**:
  - inputs: session_id, phase_id, plan_path, deviations_path, mode=`local`, round=N
  - output: `phases/<id>/review-comments.md` (new round overwrites prior — round N+1 references prior comments by reading the prior file before overwriting)
- **tester-agent**:
  - inputs: session_id, phase_id, plan_path, mode=`local`, round=N
  - output: `phases/<id>/tester-report.md`

### Aggregation

When both return:

- review verdict = `approve` AND tester verdict = `pass` → advance to Step 4 (integrate gate).
- review verdict = `request-changes` OR tester verdict = `fail` → dispatch refine-agent (Step 3a).

### Step 3a — Refine within Stage 5

Print breadcrumb:
```
[session: <id> | phase: <phase-id> | stage: review+tester → refine (round N)]
```

Dispatch `refine-agent`:
- inputs: session_id, phase_id, plan_path, round=N
- sources (whichever produced new comments this round):
  - review_comments_path (if review request-changes)
  - tester_report_path (if tester fail)
  - user_comments_path (optional — see "User intervention" below)

When refine returns `complete`:
- Increment round counter.
- **Re-dispatch review-agent and tester-agent** (round N+1, in parallel).

When refine returns `replan-needed` → surface, stop.

### Round caps (hardcoded)

- Review loop cap: **3 rounds**.
- Tester loop cap: **2 rounds**.

If caps exhausted with status still not clear → pause with summary:
```
[session: <id> | phase: <phase-id> | review-wall hit (round 3) | tester-wall hit (round N)]
Stage 5 did not converge. Outstanding:
  review: <K> [blocker]/[must-fix] open
  tester: <M> failures open
Surface to user. Recommended actions:
  - Inspect review-comments.md and tester-report.md.
  - /mar:iterate plan "<adjustment>" if the contract was wrong.
  - /mar:replan if scope/approach needs to change.
  - Manual edits + /mar:continue ship to re-enter at Step 3.
```

Update `session.md`: `status: stuck-review-wall` or `stuck-tester-wall`. Stop.

### User intervention (optional)

If a `phases/<id>/user-comments.md` file exists at start of a refine round, refine-agent reads it as an additional source. The user creates this file freely — no command needed. Refine treats user comments same as agent comments. After refine consumes them, archive the file: `mv user-comments.md user-comments.consumed-<ts>.md`.

## Step 4 — Integrate gate (branch by autonomy)

Once Stage 5 clears (review approve + tester pass), advance to integrate.

Update `session.md`: `current_stage: integrate`, `last_activity: now`.

### `interactive` / `normal` / `streamlined` — gate (pause)

Set `status: awaiting-approval`. Report:

```
[session: <id> | phase: <phase-id> | stage: review+tester → integrate (gate)]
Phase <phase-id> Stage 5 clear.
  verify: pass
  review: approve (round <n>, <comments_count_total> comments resolved)
  tester: pass (round <n>, <scenarios_count> scenarios)

Next:
  /mar:integrate                            → run integrate-agent (commit story + .brain/ writebacks)
  /mar:iterate plan "<note>"                → adjust plan and rebuild (regenerates issue-body too)
  /mar:replan                               → discard plan and start over
```

Stop.

### `autonomous` — skip gate, continue

Log timeline: `<ts> autonomous auto-dispatching integrate`. Inline-dispatch `/mar:integrate`'s pipeline.

In Step 1 (no GitHub), autonomous's integrate produces INTEGRATION.md and (if writebacks not skipped) writes them. **In Step 1, autonomous does NOT push or open a PR — Step 2 wires that in.** The phase artifact stays local.

Skip `.brain/` writebacks for autonomous (per v2 spec).

## Step 5 — Between-phase handling (L/XL only)

After integrate completes for a phase, if more phases remain, branch on `autonomy`:
- `interactive` / `normal`: stop and report: "Phase complete. Next phase: <id>. Run `/mar:plan` to proceed."
- `streamlined` / `autonomous`: between-phase compaction (orchestrator main thread compacts, retains meta-plan + last phase's summary), then auto-run `/mar:plan` for the next phase. No ack pause.

After the final phase integrates: stop. Report session summary.

## Always-on safeguards (every mode)

These pause regardless of autonomy:
- Manual step unmet
- Scope violation (PreToolUse hook fired)
- Test-fail after refine loop exhausted (build loop)
- Replan requested
- **Review-wall** (Stage 5 review cap exhausted)
- **Tester-fail-cap** (Stage 5 tester cap exhausted)
- Unresolved `[QUESTION]` on plan in autonomous mode
- Secret-file write attempt
- `derive-issue-body.py` failure (if iterate-plan happens mid-ship)

## Rules

- Stop conditions in every mode: see "Always-on safeguards" above.
- `interactive` / `normal` / `streamlined`: never commit from `/mar:ship` — commit happens via `/mar:integrate` → `/mar:approve integrate`.
- `autonomous`: `/mar:ship` auto-dispatches integrate at Step 4 — but Step 1 autonomous does NOT push or open a PR (Step 2 adds that).
- Keep the main session context lean — workers carry the heavy context.
- Compact between phases for L/XL (mandatory).
- Stage 5 round counters increment only after a refine checkpoint, not on each agent dispatch.
