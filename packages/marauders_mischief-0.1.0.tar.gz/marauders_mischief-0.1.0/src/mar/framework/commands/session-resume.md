---
description: Resume an existing development session. Optionally pass a session id; defaults to most-recent active.
---

Resume a session. Argument: $ARGUMENTS (session id, or blank to pick most-recent active).

## Step 1 — Resolve session

- If `$ARGUMENTS` is non-empty: use that as the session id.
- If blank: Glob `sessions/active/*/session.md`, read all, pick the one with most recent `last_activity` field.
- If none found: report "No active sessions. Use /mar:session-start." and stop.

## Step 2 — Load state

Read the session's `session.md`. Extract:
- `status` (planning | in-progress | paused | awaiting-approval)
- `current_phase`
- `current_stage`
- `service`, `size`, `guidance`

## Step 3 — Point to session

Run `bash ops/workflow/scripts/set-session.sh <session-id>` to set the per-window pointer.

## Step 4 — Report state and next action

Output a concise summary:

```
Resumed: <session-id>
  service: <service> | size: <size> | guidance: <mode>
  status: <status>
  current phase: <phase-id or "not yet">
  current stage: <stage>

Next: <suggested command based on status>
  e.g. status=planning → /mar:plan
       status=in-progress → /mar:ship or /mar:status for details
       status=paused → /mar:continue after addressing the pause reason
       status=awaiting-approval → review and /mar:approve
```

Do not auto-run the next command. Wait for the user.
