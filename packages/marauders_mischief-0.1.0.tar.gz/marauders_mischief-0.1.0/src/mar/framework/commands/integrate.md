---
description: Run integrate-agent to compose the commit story and propose .brain/ writebacks. Pauses for /mar:approve integrate.
---

Run the integration stage for the current session.

## Step 1 — Preconditions

1. Run `bash ops/workflow/scripts/current-session.sh`. Error if it exits non-zero.
2. Read session.md. Error if `current_stage` ≠ `integrate` OR if there's no verified phase.
3. Verify each phase has a `summary.md` and `verification.md`. Error if any missing — direct user to /mar:ship or /verify first.

## Step 2 — Dispatch

Dispatch `integrate-agent` via Task:
- inputs: session_id, service_type (`scratch` | `real`)
- agent reads: session.md, meta-plan.md (if exists), every phase summary + verification, current git diff
- agent writes: `INTEGRATION.md` (commit message, PR body for `real`, `.brain/` writeback proposals). For `autonomous` sessions the agent must NOT include `.brain/` writebacks — they are skipped entirely.

## Step 3 — Branch by autonomy

### `interactive` / `normal` / `streamlined` — review gate

Read and show the produced INTEGRATION.md inline (not just a path). User must review commit message, PR body, and writeback proposals before approving.

Report and pause:

```
Integration artifact: sessions/active/<id>/INTEGRATION.md

Commit message preview:
  <first line>

Writebacks proposed: <count>
  <target-file>: <short>
  <target-file>: <short>

Review the file, then:
  /mar:approve integrate  → commit (with per-entry writeback approval) and optionally create PR
  /mar:reject integrate   → discard and return to verify stage
  /mar:continue integrate "<note>"  → re-run with added direction
```

Update session.md: `status: awaiting-approval`, `last_activity: now`. Stop.

### `autonomous` — auto-commit, auto-push, draft PR

Preconditions (refuse if not met):
- `service_type == real` — `scratch` services never run autonomous (enforced earlier at session-start, but double-check here).
- Current branch is not the repo's default branch (refuse to auto-push to main/master).
- `gh` is authenticated for the current repo.

Steps:

1. **Stage and commit**:
   ```bash
   # Stage source changes. Session artifacts under sessions/ are typically gitignored or kept on a separate branch.
   git add -A
   # If nothing to commit, abort with {status: no-changes, action: stop}.
   git commit -m "<commit message from INTEGRATION.md>"
   ```

2. **Push to origin**:
   ```bash
   git push -u origin HEAD
   ```

3. **Open a draft PR**:
   ```bash
   gh pr create \
     --draft \
     --title "<PR title from INTEGRATION.md>" \
     --body-file <(cat <INTEGRATION.md PR-body section>) \
     --label autonomous-agent
   ```

4. **Skip `.brain/` writebacks.** Integrate-agent was already told to omit them for autonomous, but double-check the INTEGRATION.md has no writebacks section. If one exists, ignore it and log: `<ts> autonomous: skipped .brain/ writebacks`.

5. **Update session.md**: `status: integrated`, `last_activity: now`. Timeline: `<ts> autonomous: pushed + draft PR <PR-url>`.

6. **Report**:
   ```
   [session: <id> | stage: integrate (autonomous complete)]
   Pushed: <commit-sha> to origin/<branch>
   Draft PR: <PR-url>  (label: autonomous-agent)
   Next: /mar:session-archive to close.
   ```

## Rules

- **Non-autonomous**: never commit from /mar:integrate itself — commit happens via /mar:approve integrate. Never push to remote without explicit user request.
- **Autonomous**: commit + push + draft PR are part of the pipeline. Push always targets the current repo's `origin`; uses whatever `gh` authentication the user has configured.
- Never write to `.brain/` during autonomous integrate. Human-curated only.
- Never bundle multiple sessions into one commit. One session → one commit → one PR.
