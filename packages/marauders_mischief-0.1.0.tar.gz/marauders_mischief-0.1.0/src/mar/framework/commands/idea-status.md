---
description: Summary of research/ideas/ by status + open idea-labeled GitHub Issues.
---

Give a compact snapshot of the idea system.

## Step 1 — Load research/ideas/

Glob `research/ideas/*.md` (ignore `README.md`). For each file, read just enough to parse the YAML frontmatter at the top. Capture `status`, `last_touched`, `tags`, `promoted_to`, and the filename.

## Step 2 — Load GitHub Issues

Run `gh issue list --label idea --state all --limit 100 --json number,title,state,updatedAt`. Parse the JSON.

If `gh` is not authenticated or the call fails, note it and continue without GitHub data.

## Step 3 — Load pending proposals

Glob `ops/ideas/queue/pending/*.yaml`. Count them. Also count `approved/`, `declined/`, `deferred/` for historical context.

## Step 4 — Report

Compact, skim-friendly:

```
Incubating ideas (research/ideas/)
  raw:       N   {slug}, {slug}   (last-touched dates)
  shaping:   N   {slug}
  promoted:  N
  rejected:  N
  archived:  N

GitHub Issues (label=idea)
  open:    N   #12 {title}, #15 {title}
  closed:  N

Proposal queue (ops/ideas/queue/)
  pending:   N   (review with /mar:review-proposals)
  approved:  N
  declined:  N
  deferred:  N

Last groomer run: ops/cron/output/weekly-idea-groomer-{date}.md
Next scheduled: Tuesday 09:00
```

Only show detail (slug/title lists) for buckets with ≤ 5 items; otherwise just the count. Keep the whole output under ~20 lines.

## Guardrails

- Read-only command. Do not modify files, do not create issues.
- Don't run any gh write-mode commands.
- If `research/ideas/` is empty, say "No ideas incubating yet" and skip that section.
