---
description: Run research + plan for the current session's current sub-stage. v2 splits planning into 2a meta-plan, 2b issue scaffolding, 2c phase plan. Pauses at the current gate.
---

Run the planning pipeline for the current session. Optional free-text direction can be passed inline: `/mar:plan "<extra direction for research>"`.

In v2, planning is split into three sub-stages, each with its own 3-way gate (approve / iterate / reject). `/mar:plan` advances whichever sub-stage is current. The user typically runs `/mar:plan` multiple times across an L/XL session as they pass each gate.

## Step 1 — Resolve current session

Run `bash ops/workflow/scripts/current-session.sh` to resolve the session id. If it exits non-zero, error: "No current session. Use /mar:session-start or /mar:session-resume."

Read `sessions/active/<id>/session.md`.

## Step 2 — Decide which sub-stage is current

Based on `size` and the artifacts on disk:

| Size | meta-plan.md | proposed-issue-bodies.md | current phase plan.md | Sub-stage to run |
|---|---|---|---|---|
| S / M | n/a | n/a | absent | **2c** (phase plan, single phase `01-main`) |
| S / M | n/a | n/a | exists, gate not approved | hold at 2c gate |
| L / XL | absent | absent | — | **2a** (meta-plan) |
| L / XL | exists | absent | — | **2b** (issue scaffolding) |
| L / XL | exists | exists | absent for current phase | **2c** (phase plan) |
| L / XL | exists | exists | exists, gate approved, more phases pending | **2c** (next phase's plan) |

If a gate is currently `awaiting-approval`, `/mar:plan` reports the gate state and tells the user to approve / iterate / reject. It does not advance.

## Step 3 — Collect extra direction (pre-research input, if 2a or 2c)

This step only fires for sub-stages that run research first (2a, 2c). For 2b (which is a pure derivation), skip to Step 6.

Collect any user-supplied extra direction to feed into research-agent. Precedence:

1. **$ARGUMENTS** (if present) — use as-is.
2. **Interactive prompt** — fires only when `autonomy: interactive` AND no $ARGUMENTS:
   > Research is about to run for `<level>: <phase-id-or-"meta">`. Any direction beyond what's in `session.md`? Reply with a short paragraph, or `skip` to proceed with no extra direction.
3. **`normal` / `streamlined` / `autonomous`** — no prompt. Proceed with none unless $ARGUMENTS was passed.

Store as `pre_research_direction`.

## Step 4 — Run research (2a, 2c only)

Print breadcrumb:
```
[session: <id> | size: <size> | autonomy: <mode> | stage: → research (<level>)]
```

### For meta level (Stage 2a):
Dispatch `research-agent` via Task:
- level: `meta`
- inputs: session_id, goal, scope_hint (derived from service), pre_research_direction
- output: `sessions/active/<id>/meta-research.md`

### For phase level (Stage 2c):
Dispatch `research-agent`:
- level: `phase`
- inputs: session_id, phase_id (resolve current phase from meta-plan or default `01-main`), phase_goal, scope_hint, pre_research_direction
- output: `sessions/active/<id>/phases/<phase_id>/research.md`

## Step 5 — Research review gate (interactive mode only, 2a/2c)

After research-agent returns, fires only when `autonomy: interactive`. Otherwise skip to Step 6.

Show user a short summary (≤150 words) and pause:

```
[session: <id> | stage: research → plan (gate)]
Research ready: <path>

Summary: <agent-reported summary>
Unknowns / questions surfaced: <N>

Options:
  /mar:approve research                    → proceed to plan
  /mar:iterate research "<direction>"      → re-run research with added direction (appended)
  /mar:reject research                     → discard research and restart from scratch
```

Update session.md: `current_stage: research-review`, `status: awaiting-approval`. Hold here.

## Step 6 — Run the planning sub-stage

Print breadcrumb:
```
[session: <id> | size: <size> | autonomy: <mode> | stage: → <2a|2b|2c>]
```

### Stage 2a — Meta-plan

Dispatch `meta-plan-agent`:
- inputs: session_id, goal, size, guidance, meta_research_path
- output: `sessions/active/<id>/meta-plan.md`

**No issues are opened in 2a.** That's 2b's job. Just produces meta-plan.md with phase IDs as local labels (`phase-1`, `phase-2`, ...).

### Stage 2b — Issue scaffolding

This stage doesn't dispatch an agent. The orchestrator itself derives proposed issue bodies from the meta-plan, then creates real GitHub issues in the current repo via `gh`.

For each phase in meta-plan:
1. Generate a stub issue body using `ops/workflow/templates/issue-body.md.template`. Phase 1 may get fuller content if its phase-plan-agent has already run; stubs otherwise.
2. Concatenate all stub bodies into one preview file: `sessions/active/<id>/proposed-issue-bodies.md`. Each body separated by a `---` divider with its phase ID as section header.

**Issue creation — branch by autonomy:**

- `interactive` / `normal` / `streamlined`: write `proposed-issue-bodies.md`, pause at the 2b gate so the user can review. On `/mar:approve issue-scaffolding`, the orchestrator runs:
  ```bash
  bash ops/workflow/scripts/create-phase-issues.sh --session <id>
  ```
  Hard-block on non-zero exit. The script handles `gh auth status`, repo existence, fine-grained-PAT scope errors, and records issue numbers back into `session.md` (`issues:` field) and each `phases/<phase-id>/plan.md` frontmatter (`issue:` + `issue_url:`).

- `autonomous`: skip the preview gate. Write `proposed-issue-bodies.md` AND immediately run `create-phase-issues.sh`. Same hard-block on failure. Log the issue numbers in `session.md` timeline.

**No more "preview-only forever" mode.** The script always runs; the only difference is whether it runs immediately (autonomous) or on user approval (interactive).

### Stage 2c — Phase plan

Dispatch `phase-plan-agent`:
- inputs: session_id, phase_id, goal, size, guidance, service, research_path, meta_plan_path (if exists)
- output: `sessions/active/<id>/phases/<phase_id>/plan.md`

After phase-plan-agent returns successfully, **derive the issue body**:

```bash
python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
```

**Hard-block on non-zero exit.** Surface the script's stderr verbatim and stop. The plan and the derived view must agree, or we don't move.

Log derivation in session.md timeline: `<ts> derived issue-body for <phase_id>`.

## Step 7 — Sub-stage gate (branch by autonomy)

Read the artifact produced. Branch on `session.md` `autonomy`:

### `interactive` / `normal` / `streamlined` — gate (pause)

Show a concise summary with breadcrumb header:

```
[session: <id> | size: <size> | autonomy: <mode> | stage: <2a|2b|2c> → gate]
Artifact ready: <path>

<stage-specific summary lines>

Approve, iterate, or reject:
  /mar:approve <meta-plan|issue-scaffolding|plan>            → pass the gate
  /mar:iterate <meta-plan|issue-scaffolding|plan> "<note>"   → refine in place
  /mar:reject <meta-plan|issue-scaffolding|plan>             → revert to prior stage
  /mar:replan                                                → full re-plan
```

Stage-specific summary lines:
- 2a: `Phase count: <N>` | `Risks: <count>` | `Open [QUESTION]s: <K>`
- 2b: `Phases scaffolded: <N>` | `Issues will be created in <owner/repo> on /mar:approve issue-scaffolding`
- 2c: `Scope: <N files>` | `DoD items: <count>` | `[QUESTION]s: <K>` | `Test matrix rows: <count>`

Update `session.md`: `current_stage: <2a|2b|2c>`, `status: awaiting-approval`, `last_activity: now`. Stop.

### `autonomous` — skip gate, continue the pipeline

No pause. Log in session.md timeline: `<ts> autonomous auto-approved <stage>` and `last_activity: now`. Then continue inline:

- After 2a → next loop iteration runs 2b (still no pause).
- After 2b → next loop iteration runs 2c (still no pause).
- After 2c → dispatch `/mar:ship`'s pipeline for this phase (execute → test → refine → simplify → re-test → verify → review/tester → integrate).
- After integrate completes for a phase, if more phases remain: loop back to Step 4 for the next phase (2c only — 2a/2b are session-level, done once).
- After the final phase integrates: stop.

Always-on safeguards still fire even in autonomous (manual step, scope violation, review-wall, tester-fail-cap, unresolved `[QUESTION]`, derive-issue-body.py failure, secret write).

## Rules

- `interactive` / `normal` / `streamlined`: each sub-stage gate is hard. Do not run subsequent sub-stages or execute.
- `autonomous`: may chain through 2a → 2b → 2c → ship inline. Always-on safeguards still apply.
- Do not write to `.brain/` or `research/`.
- If any stage returns replan-needed or paused, surface to the user and stop regardless of autonomy.
- The 3-way gate (approve / iterate / reject) is the standard surface across all gates. Always show all three options to the user.
