---
description: Manually promote a research/ideas/ file to a GitHub Issue.
---

Promote an incubating idea to GitHub without waiting for the weekly groomer.

## Step 1 — Parse arguments

`$ARGUMENTS` is a slug (without the `-YYYY-MM-DD.md` suffix). If empty, list candidate slugs by globbing `research/ideas/*.md` and ask the user to pick.

## Step 2 — Locate the file

Glob `research/ideas/{slug}-*.md`.

- 0 matches: tell the user, suggest `/mar:idea-new {slug}` if they want to create one.
- 1 match: that's the file.
- multiple matches: list dates and ask the user to pick.

Read the file. Parse frontmatter.

## Step 3 — Guard against double-promotion

If `status` is already `promoted`, `rejected`, or `archived`: show the existing `promoted_to` (if any) and ask the user to confirm re-promotion. Default is to abort.

## Step 4 — Draft the issue

Compose a draft:

```
Title: {humanized slug — concise, imperative if actionable}
Body:
  {Problem section, if present}

  {Sketch section, if present}

  ---
  Source: research/ideas/{filename}
Labels: [idea] + {tags from frontmatter, filtered to existing repo labels}
```

Show the draft to the user and ask "Create this issue?" — allow free-form edits to title/body/labels in the reply. Iterate until they approve or abort.

## Step 5 — Create the issue

On approval, run:

```
gh issue create \
  --title "{title}" \
  --body "{body}" \
  --label "idea" --label "{tag1}" ...
```

`gh` targets the current repo by default. If your repo doesn't have a configured GitHub remote, `gh issue create` will fail — set up the remote first, or pass `--repo <owner/name>` explicitly.

Capture the issue URL from stdout.

## Step 6 — Update the source file

Edit `research/ideas/{slug}-{date}.md` frontmatter:
- `status: promoted`
- `promoted_to: {issue URL}`
- `last_touched: {today}`

Don't touch the body.

## Step 7 — Report

```
Promoted: research/ideas/{filename} → {issue URL}
status: raw → promoted
```

## Guardrails

- Do not create an issue without explicit user approval of the draft.
- Do not update frontmatter until `gh issue create` succeeds (capture exit code).
- If `gh` fails (rate limit, auth, network), report the error and do NOT update frontmatter — the idea stays in its original status.
- Do not commit the frontmatter update automatically; the user decides when to commit.
