---
description: Hard halt the current session. Preserves artifacts; resume with /mar:session-resume.
---

Hard-halt the current session. No arguments needed.

## Step 1 — Resolve

Run `bash ops/workflow/scripts/current-session.sh` to resolve the session id. If the script exits non-zero, report "No current session to stop." and end.

## Step 2 — Update state

Read session.md. Update:
- `status: paused`
- `last_activity: now`
- Append timeline: `<ts> /mar:stop invoked by user — session paused at stage=<current_stage>`

## Step 3 — Report

```
Session <id> paused.
  last stage: <stage>
  last phase: <phase_id or meta>

Resume with: /mar:session-resume <id>    (or just /mar:session-resume for most-recent)
```

## Rules

- Preserve all artifacts — do not delete anything.
- If any agent was mid-flight when /mar:stop was invoked, the next Claude Code invocation should treat its partial outputs as stale and be willing to re-run that stage via /mar:continue.
- Do not clear the per-window pointer — keep it so /mar:session-resume with no args resolves to this session.
