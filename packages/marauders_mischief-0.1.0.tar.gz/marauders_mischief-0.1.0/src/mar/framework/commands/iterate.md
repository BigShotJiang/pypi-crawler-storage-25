---
description: Apply free-text direction to a gate without losing position. Auto-regenerates plan + derived issue-body. Usage — /mar:iterate <gate> "<direction>"
---

Apply a directional adjustment at a gate. Distinct from `/mar:continue` (re-runs a stage as-is) and `/mar:replan` (discards and restarts). Iterate refines in place.

Arguments: `$ARGUMENTS` — expected format `<gate> "<direction>"`. Examples:

- `/mar:iterate research "go deeper on the OpenAI Whisper streaming API limits"`
- `/mar:iterate plan "tighten the error-handling story — surface to user, don't retry"`
- `/mar:iterate meta-plan "split phase 2 into separate ingestion + indexing phases"`

## Step 1 — Parse

Split into `<gate>` (first token) and `<direction>` (rest, trim quotes).

Valid gates: `research`, `meta-plan`, `plan`, `integrate`.

**Note**: `issue-scaffolding` (Stage 2b) is *not* directly iterable. To adjust proposed issue bodies, iterate the source: phase 1's body comes from phase 1's plan (use `/mar:iterate plan`); later phases' stub bodies come from the meta-plan (use `/mar:iterate meta-plan`). The body is always a view of something canonical.

If parsing fails or gate is invalid, error with usage and stop.

## Step 2 — Resolve session

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read `sessions/active/<id>/session.md`. Error if no session.

## Step 3 — Validate gate state

The session must be currently sitting at the named gate (status `awaiting-approval`, `current_stage` matches). Iterate is only valid at an open gate — it doesn't restart a closed one (use `/mar:replan` for that).

If the session isn't paused at this gate, refuse:
> Cannot iterate `<gate>` — session is at stage `<current_stage>`, status `<status>`. Use `/mar:continue <stage> "<note>"` to add direction to a running stage, or `/mar:replan` to discard the current artifact and restart.

## Step 4 — Route the direction

Each gate routes differently. The principle is the same: regenerate the canonical artifact (plan.md / meta-plan.md / INTEGRATION.md), then re-derive any downstream views.

### `research`

User wants more or different research before approving the plan.

1. Print breadcrumb: `[session: <id> | stage: research → iterate (round <n+1>)]`.
2. Dispatch `research-agent` with:
   - level: matches what was originally produced (`meta` or `phase`)
   - inputs: session_id, (phase_id if phase level), goal, scope_hint
   - **`additional_direction: <direction>`** — agent **appends** to existing research.md (does not overwrite raw findings).
3. After research-agent returns, re-dispatch `plan-agent` (`meta-plan-agent` or `phase-plan-agent` to match level) — it must regenerate plan.md from the updated research.
4. **Re-derive issue-body** if a phase plan was regenerated:
   ```bash
   python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
   ```
   On non-zero exit → **halt** with the script's stderr verbatim. Do not advance.
5. Update session.md timeline: `<ts> iterate research — <direction>`. Reset `status: awaiting-approval`, hold at plan gate.
6. Show the standard plan-gate message (see `/mar:plan` Step 7).

### `meta-plan`

User wants to adjust phase decomposition.

1. Print breadcrumb: `[session: <id> | stage: meta-plan → iterate]`.
2. Dispatch `meta-plan-agent` with:
   - inputs: session_id, goal, size, guidance, meta_research_path
   - **`additional_direction: <direction>`**
3. Agent regenerates `meta-plan.md`.
4. **Step 2 (deferred)**: if any phase issues already exist, regenerate their issue bodies via derive-issue-body.py per phase, and `gh issue edit` per phase. In Step 1 (no GitHub), if any phase plans already exist as files, re-derive their `issue-body.md`.
5. Update session.md timeline. Hold at meta-plan gate.
6. Show the standard meta-plan-gate message.

### `plan`

User wants to adjust the current phase plan.

1. Print breadcrumb: `[session: <id> | phase: <phase-id> | stage: plan → iterate]`.
2. Dispatch `phase-plan-agent` with:
   - inputs: session_id, phase_id, goal, size, guidance, research_path, meta_plan_path (if exists)
   - **`additional_direction: <direction>`**
3. Agent regenerates `plan.md` (single source of truth).
4. **Re-derive issue-body** — mandatory:
   ```bash
   python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
   ```
   On non-zero exit → **halt** with stderr verbatim. The plan and the issue must agree.
5. Update session.md timeline. Hold at plan gate.
6. Show the standard plan-gate message.

### `integrate`

User wants to adjust the integration story (commit message, writeback proposals).

1. Print breadcrumb: `[session: <id> | stage: integrate → iterate]`.
2. Dispatch `integrate-agent` with:
   - inputs: session_id (and the same context integrate normally gets)
   - **`additional_direction: <direction>`**
3. Agent regenerates `INTEGRATION.md`.
4. Hold at integrate gate.
5. Show the standard integrate-gate message.

## Step 5 — Hold and report

Across every gate, the iterate flow ends at the same gate it started at — never advances. The user sees the regenerated artifact and decides:

- `/mar:approve <gate>` — accept and advance.
- `/mar:iterate <gate> "<more direction>"` — refine again.
- `/mar:reject <gate>` — discard and revert to prior stage.
- `/mar:replan` — full restart of planning for the current scope.

## Hard rules

- Iterate **never** skips a gate. After iterate, the same gate is open again until the user approves.
- If `derive-issue-body.py` fails (Step 1) or `gh issue edit` fails (Step 2 future), the iterate command **hard-blocks**. The plan and the issue must agree, or we don't move. Surface the error verbatim and stop.
- Iterate **never hand-edits** issue-body.md, the GitHub issue body, or the PR body. Those are derived. Iterate regenerates plan.md (or meta-plan.md / INTEGRATION.md) and re-runs the derivation pipeline.
- Iterate respects the same scope hook as execute — the agent cannot drift outside plan scope.

## Rules

- `/mar:iterate` is the refinement tool with new direction. `/mar:continue` is the refinement tool *without* new direction (re-runs as-is). `/mar:replan` is the reset tool (discards artifacts).
- For research iterate: appended raw findings preserve the audit trail. Plan re-derivation guarantees the plan reflects current state, not stale notes.
- An iterate count > 3 on the same gate without approval is a smell — surface a hint: "This is iterate #4 on the plan gate. Consider `/mar:reject plan` to take a fresh path, or check whether the underlying goal needs revisiting."
