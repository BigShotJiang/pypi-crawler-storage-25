---
description: Re-plan the current phase or the session meta-plan. Discards the current plan and runs research + plan from scratch.
---

Re-run planning from scratch. Arguments: $ARGUMENTS (optional — `meta` to re-plan meta; blank defaults to current phase).

## Step 1 — Resolve scope

- `$ARGUMENTS == "meta"` → re-plan the session-level meta-plan (L/XL only).
- blank → re-plan the current phase.

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md.

## Step 2 — Confirm

Show the user what will change:

> Re-plan <meta | phase <id>>?
> This will:
> - Move current <meta-plan.md | phase/<id>/mar:plan.md> to <file>.superseded-<ts>
> - Re-run research stage (optionally — user choice via AskUserQuestion: "re-run research?" yes/no)
> - Re-run plan-agent with any existing session context
>
> Confirm? (yes/no)

## Step 3 — Archive current artifacts

Rename affected files with `.superseded-<timestamp>` suffix. Keep for reference.

## Step 4 — Run

Invoke the flow /mar:plan would take, for the specified scope. If user said no to re-run research, reuse the existing research.md / meta-research.md.

## Step 5 — Report

Same as /mar:plan's final gate report. User must /mar:approve the new plan before /mar:ship.

## Rules

- Never discard artifacts; rename with `.superseded-<timestamp>`.
- Replan counts — if 3 replans happen on the same phase without `/mar:ship` in between, surface: "Phase has replanned 3×. Consider: is this phase's goal itself wrong? /mar:reject plan and revisit meta-plan."
