"""
SessionEnd hook — captures conversation context when a session closes, and
auto-marks any active session as `status: paused` so the scope hook
honors the implicit "user left" signal.

For short sessions (hours), this is the primary capture point.
For long sessions (weeks), PreCompact does most of the capturing;
this is the final cleanup sweep.

session auto-pause:
  When Claude Code exits with a session pointer set and the session's
  status is `in-progress` or `awaiting-approval`, we set `status: paused`
  and append a timeline entry. This catches the "user closed the terminal
  without /mar:stop" failure mode that left stale locks for the scope hook.

No API calls in the hook itself. Runs in under 1 second.
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

# Recursion guard: if spawned by flush.py → Agent SDK → Claude Code → this hook
if os.environ.get("CLAUDE_INVOKED_BY"):
    sys.exit(0)

ROOT = Path(__file__).resolve().parent.parent.parent.parent
MEMORY_DIR = ROOT / "ops" / "memory"
SCRIPTS_DIR = MEMORY_DIR / "scripts"
LEGACY_POINTER = ROOT / ".claude" / ".current-session"
PER_WINDOW_DIR = ROOT / ".claude" / "sessions"
SESSIONS_DIR = ROOT / "sessions" / "active"

ACTIVE_STATUSES = {"in-progress", "awaiting-approval"}

logging.basicConfig(
    filename=str(MEMORY_DIR / "flush.log"),
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [session-end] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

MAX_TURNS = 30
MAX_CONTEXT_CHARS = 15_000
MIN_TURNS_TO_FLUSH = 1


def extract_conversation_context(transcript_path: Path) -> tuple[str, int]:
    """Read JSONL transcript and extract last ~N conversation turns as markdown."""
    turns: list[str] = []

    with open(transcript_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            msg = entry.get("message", {})
            if isinstance(msg, dict):
                role = msg.get("role", "")
                content = msg.get("content", "")
            else:
                role = entry.get("role", "")
                content = entry.get("content", "")

            if role not in ("user", "assistant"):
                continue

            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        text_parts.append(block)
                content = "\n".join(text_parts)

            if isinstance(content, str) and content.strip():
                label = "User" if role == "user" else "Assistant"
                turns.append(f"**{label}:** {content.strip()}\n")

    recent = turns[-MAX_TURNS:]
    context = "\n".join(recent)

    if len(context) > MAX_CONTEXT_CHARS:
        context = context[-MAX_CONTEXT_CHARS:]
        boundary = context.find("\n**")
        if boundary > 0:
            context = context[boundary + 1:]

    return context, len(recent)


def resolve_session_id() -> str | None:
    override = os.environ.get("MAR_SESSION_ID", "").strip()
    if override:
        return override
    sse_port = os.environ.get("CLAUDE_CODE_SSE_PORT", "").strip()
    if sse_port:
        per_window = PER_WINDOW_DIR / f"pointer-{sse_port}"
        if per_window.exists():
            try:
                return per_window.read_text().strip() or None
            except OSError:
                pass
    if LEGACY_POINTER.exists():
        try:
            return LEGACY_POINTER.read_text().strip() or None
        except OSError:
            pass
    return None


def auto_pause_session() -> None:
    """If a session pointer is set and the session is active, pause it.

    Catches the "user closed Claude Code without running /mar:stop" failure
    mode. The scope hook reads `status:` and falls open for `paused`.
    """
    sid = resolve_session_id()
    if not sid:
        return
    session_md = SESSIONS_DIR / sid / "session.md"
    if not session_md.exists():
        return

    try:
        text = session_md.read_text()
    except OSError as e:
        logging.error("auto_pause: read failed: %s", e)
        return

    m = re.search(r"^status:\s*(.+?)\s*$", text, re.MULTILINE)
    if not m:
        return
    status = m.group(1).strip().strip('"\'').lower()
    if status not in ACTIVE_STATUSES:
        return

    now_iso = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    new_text = re.sub(
        r"^status:\s*.+?$",
        "status: paused",
        text,
        count=1,
        flags=re.MULTILINE,
    )
    new_text = re.sub(
        r"^last_activity:\s*.+?$",
        f"last_activity: {now_iso}",
        new_text,
        count=1,
        flags=re.MULTILINE,
    )

    timeline_entry = (
        f"- {now_iso} — auto-paused by SessionEnd hook (Claude Code exited "
        f"with status=`{status}`); resume with /mar:session-resume {sid}"
    )
    if "## Timeline" in new_text:
        new_text = new_text.rstrip() + "\n" + timeline_entry + "\n"
    else:
        new_text = new_text.rstrip() + "\n\n## Timeline\n\n" + timeline_entry + "\n"

    try:
        session_md.write_text(new_text)
        logging.info("auto-paused session %s (was %s)", sid, status)
    except OSError as e:
        logging.error("auto_pause: write failed: %s", e)


def main() -> None:
    # session auto-pause runs first, independent of transcript flush.
    try:
        auto_pause_session()
    except Exception as e:
        logging.error("auto_pause crashed: %s", e)

    try:
        raw_input = sys.stdin.read()
        try:
            hook_input: dict = json.loads(raw_input)
        except json.JSONDecodeError:
            fixed_input = re.sub(r'(?<!\\)\\(?!["\\])', r'\\\\', raw_input)
            hook_input = json.loads(fixed_input)
    except (json.JSONDecodeError, ValueError, EOFError) as e:
        logging.error("Failed to parse stdin: %s", e)
        return

    session_id = hook_input.get("session_id", "unknown")
    transcript_path_str = hook_input.get("transcript_path", "")

    logging.info("SessionEnd fired: session=%s", session_id)

    if not transcript_path_str or not isinstance(transcript_path_str, str):
        logging.info("SKIP: no transcript path")
        return

    transcript_path = Path(transcript_path_str)
    if not transcript_path.exists():
        logging.info("SKIP: transcript missing: %s", transcript_path_str)
        return

    try:
        context, turn_count = extract_conversation_context(transcript_path)
    except Exception as e:
        logging.error("Context extraction failed: %s", e)
        return

    if not context.strip():
        logging.info("SKIP: empty context")
        return

    if turn_count < MIN_TURNS_TO_FLUSH:
        logging.info("SKIP: only %d turns (min %d)", turn_count, MIN_TURNS_TO_FLUSH)
        return

    # Write context to temp file for the background process
    timestamp = datetime.now(timezone.utc).astimezone().strftime("%Y%m%d-%H%M%S")
    context_file = SCRIPTS_DIR / f"session-flush-{session_id}-{timestamp}.md"
    context_file.write_text(context, encoding="utf-8")

    # Spawn flush.py as background process
    flush_script = SCRIPTS_DIR / "flush.py"

    cmd = [
        "uv",
        "run",
        "--project",
        str(MEMORY_DIR),
        "python",
        str(flush_script),
        str(context_file),
        session_id,
    ]

    try:
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        logging.info(
            "Spawned flush.py for session %s (%d turns, %d chars)",
            session_id, turn_count, len(context),
        )
    except Exception as e:
        logging.error("Failed to spawn flush.py: %s", e)


if __name__ == "__main__":
    main()
