"""
SessionStart hook — injects knowledge base context into every conversation.

Reads the knowledge index and recent daily log, then outputs JSON so Claude
always has access to compiled knowledge from past sessions.

Also surfaces stale session locks: if a session pointer points at a
session whose last_activity is older than STALE_HOURS_BANNER hours, prepend
a warning banner so Claude knows the session is orphaned and should ask the
user before resuming.

No API calls. Runs in under 1 second.
"""

import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

# Paths relative to repo root
ROOT = Path(__file__).resolve().parent.parent.parent.parent
KNOWLEDGE_DIR = ROOT / "knowledge"
DAILY_DIR = ROOT / "ops" / "memory" / "daily"
INDEX_FILE = KNOWLEDGE_DIR / "index.md"
BRAIN_DIR = ROOT / ".brain"
LEGACY_POINTER = ROOT / ".claude" / ".current-session"
PER_WINDOW_DIR = ROOT / ".claude" / "sessions"
SESSIONS_DIR = ROOT / "sessions" / "active"
TIMEZONE = "Europe/Oslo"

MAX_CONTEXT_CHARS = 20_000
MAX_LOG_LINES = 30

# Show the stale-session banner when last_activity is older than this many
# hours. Lower than check-scope's STALE_HOURS (2) — banner first, fall-open
# second.
STALE_HOURS_BANNER = 1


def get_recent_log() -> str:
    """Read the most recent daily log (today or yesterday)."""
    now = datetime.now(ZoneInfo(TIMEZONE))

    for offset in range(2):
        date = now - timedelta(days=offset)
        log_path = DAILY_DIR / f"{date.strftime('%Y-%m-%d')}.md"
        if log_path.exists():
            lines = log_path.read_text(encoding="utf-8").splitlines()
            recent = lines[-MAX_LOG_LINES:] if len(lines) > MAX_LOG_LINES else lines
            return "\n".join(recent)

    return "(no recent daily log)"


def resolve_session_id() -> str | None:
    """Mirror current-session.sh: env var > per-window pointer > legacy."""
    override = os.environ.get("MAR_SESSION_ID", "").strip()
    if override:
        return override
    sse_port = os.environ.get("CLAUDE_CODE_SSE_PORT", "").strip()
    if sse_port:
        per_window = PER_WINDOW_DIR / f"pointer-{sse_port}"
        if per_window.exists():
            try:
                return per_window.read_text().strip() or None
            except OSError:
                pass
    if LEGACY_POINTER.exists():
        try:
            return LEGACY_POINTER.read_text().strip() or None
        except OSError:
            pass
    return None


def stale_session_banner() -> str:
    """Return a one-paragraph banner if an in-progress session pointer is stale.

    Empty string when no pointer, no session, or session is fresh / paused /
    archived. The banner tells Claude (and the user) that the framework
    thinks they're inside a session but it hasn't seen activity in a while —
    a hint to /mar:session-resume or /mar:stop explicitly.
    """
    sid = resolve_session_id()
    if not sid:
        return ""
    session_md = SESSIONS_DIR / sid / "session.md"
    if not session_md.exists():
        return ""

    try:
        text = session_md.read_text()
    except OSError:
        return ""

    def fm(field: str) -> str | None:
        m = re.search(rf"^{re.escape(field)}:\s*(.+?)\s*$", text, re.MULTILINE)
        if not m:
            return None
        v = m.group(1).strip().strip('"\'')
        return v if v not in ("", "null", "none", "-", "~") else None

    status = (fm("status") or "").lower()
    if status in {"paused", "archived", "complete", "completed", "stopped"}:
        return ""

    last = fm("last_activity")
    if not last:
        return ""
    try:
        dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.astimezone()
    except (ValueError, TypeError):
        return ""

    now = datetime.now(timezone.utc).astimezone()
    age = now - dt
    if age <= timedelta(hours=STALE_HOURS_BANNER):
        return ""

    hours = int(age.total_seconds() // 3600)
    phase = fm("current_phase") or "—"
    stage = fm("current_stage") or "—"
    return (
        f"## ⚠️ Stale session detected\n\n"
        f"Pointer points at `{sid}` (status={status or 'unset'}, "
        f"phase={phase}, stage={stage}). Last activity was ~{hours}h ago.\n\n"
        f"Before doing session-related work: ask the user whether to **resume** "
        f"(`/mar:session-resume {sid}`) or **step out** (`/mar:stop`). The scope "
        f"hook falls open after 2h, so unrelated edits will work — but the user "
        f"may have meant to come back to this session and forgotten."
    )


def list_brain_files() -> str:
    """List .brain/ files available for context loading."""
    if not BRAIN_DIR.exists():
        return "(no .brain/ directory)"
    files = sorted(f.name for f in BRAIN_DIR.glob("*.md") if f.name != ".gitkeep")
    return ", ".join(files)


def build_context() -> str:
    """Assemble the context to inject into the conversation."""
    parts = []

    # Stale-session banner first — surface before any other context so the
    # model sees it before it starts working.
    banner = stale_session_banner()
    if banner:
        parts.append(banner)

    now = datetime.now(ZoneInfo(TIMEZONE))
    parts.append(f"## Today\n{now.strftime('%A, %B %d, %Y')}")

    # Knowledge base index
    if INDEX_FILE.exists():
        index_content = INDEX_FILE.read_text(encoding="utf-8")
        parts.append(f"## Knowledge Base Index\n\n{index_content}")
    else:
        parts.append("## Knowledge Base Index\n\n(empty — no articles compiled yet)")

    # Brain files available
    brain_list = list_brain_files()
    parts.append(f"## .brain/ files available\n{brain_list}")

    # Recent daily log
    recent_log = get_recent_log()
    parts.append(f"## Recent Daily Log\n\n{recent_log}")

    context = "\n\n---\n\n".join(parts)

    if len(context) > MAX_CONTEXT_CHARS:
        context = context[:MAX_CONTEXT_CHARS] + "\n\n...(truncated)"

    return context


def main():
    context = build_context()

    output = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": context,
        }
    }

    print(json.dumps(output))


if __name__ == "__main__":
    main()
