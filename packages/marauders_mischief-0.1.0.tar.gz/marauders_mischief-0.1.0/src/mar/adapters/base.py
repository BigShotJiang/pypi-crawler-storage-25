"""Adapter interface — translates framework files into harness-specific layouts.

Each adapter encapsulates the conventions of one AI harness (Claude Code,
Codex CLI, Cursor): which directories its config lives in, what format its
settings file uses, how its hooks are declared. The framework manifest is
adapter-agnostic in spirit; the adapter enforces what's actually valid for
its harness and provides the merge strategies that combine mar-owned
content with user-owned content in shared files.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class MergeStrategy(ABC):
    """A named strategy for combining mar-owned content with a user-owned file.

    Used for `merged` class manifest entries. Each strategy must be
    idempotent (re-running with the same framework content yields the same
    output) and reversible (the mar-owned portion can be extracted later for
    drift detection).
    """

    @abstractmethod
    def merge(
        self,
        existing: str | None,
        framework: str,
        context: dict[str, Any],
    ) -> str:
        """Produce the new file content.

        Args:
            existing: Current content of the target file, or None if absent.
            framework: The mar-owned content to merge in.
            context: Init-time context (project name, slug, etc.).

        Returns:
            The merged file content.
        """

    @abstractmethod
    def extract_owned(self, content: str) -> str | None:
        """Return the mar-owned portion of a merged file, or None if absent.

        Used by `mar update` to determine whether the user has edited mar's
        owned content. The return value should be comparable to the framework
        content that was passed to merge().
        """


class Adapter(ABC):
    """Abstract base for harness-specific install logic."""

    #: Adapter identifier used by `mar init --target=<name>`.
    name: str = ""

    @abstractmethod
    def validate_target(self, target: str) -> None:
        """Raise ValueError if `target` is not a valid path for this adapter.

        Used at manifest-load time to catch typos and cross-adapter mistakes
        (e.g., a `.cursor/` target in the Claude Code adapter).
        """

    @abstractmethod
    def merge_strategies(self) -> dict[str, MergeStrategy]:
        """Return the named merge strategies this adapter supports.

        Manifest entries with `class: merged` reference a strategy by name;
        the adapter must expose it here for the install to succeed.
        """
