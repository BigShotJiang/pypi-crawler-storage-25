"""Harness-specific adapters for installing the framework."""

from __future__ import annotations

from mar.adapters.base import Adapter, MergeStrategy
from mar.adapters.claude_code import ClaudeCodeAdapter
from mar.manifest import Manifest

__all__ = [
    "Adapter",
    "ClaudeCodeAdapter",
    "MergeStrategy",
    "get_adapter",
    "supported_adapters",
    "validate_manifest",
]


def supported_adapters() -> tuple[str, ...]:
    """Names of the adapters currently shipped with mar."""
    return ("claude",)


def get_adapter(name: str) -> Adapter:
    """Resolve an adapter by name (used by `mar init --target=<name>`).

    Raises ValueError if `name` is not a supported adapter.
    """
    if name == "claude":
        return ClaudeCodeAdapter()
    raise ValueError(
        f"unknown adapter {name!r}; supported: {list(supported_adapters())} "
        f"(codex and cursor adapters coming in a future release)"
    )


def validate_manifest(manifest: Manifest, adapter: Adapter) -> None:
    """Cross-check that every manifest entry is valid for the given adapter.

    Verifies:
    - Each target path is within the adapter's allowed paths.
    - Each `merge` strategy reference resolves to a strategy the adapter provides.
    """
    strategies = adapter.merge_strategies()
    for entry in manifest.files:
        adapter.validate_target(entry.target)
        if entry.merge is not None and entry.merge not in strategies:
            raise ValueError(
                f"manifest entry {entry.source!r} references unknown merge strategy "
                f"{entry.merge!r}; adapter {adapter.name!r} provides: "
                f"{sorted(strategies)}"
            )
