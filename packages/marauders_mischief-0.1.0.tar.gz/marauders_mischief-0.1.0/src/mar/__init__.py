"""marauders-mischief — an AI-native dev harness."""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path

__version__ = "0.1.0"


def framework_root() -> Path:
    """Return the path to the bundled framework/ directory.

    Works both from a source checkout and from an installed wheel.
    """
    return Path(str(files("mar") / "framework"))
