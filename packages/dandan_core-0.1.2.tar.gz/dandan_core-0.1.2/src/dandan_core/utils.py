def my_function(text: str) -> str:
    """A simple example utility."""
    return text.strip().lower()
