import socket

# Server

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('localhost', 65432))
server.listen(1)

print("Server is listening for Ciphertext...")
conn, addr = server.accept()
msg = conn.recv(1024).decode()
key_digits, ciphertext = msg.split('|')
print(f"Received Ciphertext: {ciphertext}")

plaintext = ""
key_len = len(key_digits)

for i, char in enumerate(ciphertext):
    if char.isalpha():
        shift = int(key_digits[i % key_len])
        base = ord('a') if char.islower() else ord('A')
        decrypted_char = chr((ord(char) - base - shift) % 26 + base)
        plaintext += decrypted_char
    else:
        plaintext += char

print(f"Decrypted Message: {plaintext}")
conn.close()

# Client

REG_NO = input("Enter registration number: ")
text = input("Enter Plaintext: ")

ciphertext = ""
key_len = len(REG_NO)

for i, char in enumerate(text):
    if char.isalpha():
        shift = int(REG_NO[i % key_len])
        base = ord('a') if char.islower() else ord('A')
        encrypted_char = chr((ord(char) - base + shift) % 26 + base)
        ciphertext += encrypted_char
    else:
        ciphertext += char


print(f"Generated Ciphertext: {ciphertext}")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('localhost', 65432))
client.send(f"{REG_NO}|{ciphertext}".encode())
client.close()
