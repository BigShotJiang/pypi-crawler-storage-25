"""Entry point — run with ``python -m faraway_realms``."""

from __future__ import annotations

import argparse
import asyncio
import logging
import random
import threading
import uuid
from pathlib import Path

from faraway_realms.character_type import CHARACTER_REGISTRY
from faraway_realms.content import ContentLoader
from faraway_realms.content_parsers.abilities import parse_abilities
from faraway_realms.content_parsers.character_types import parse_character_types
from faraway_realms.content_parsers.creatures import parse_creatures
from faraway_realms.content_parsers.damage_types import parse_damage_effectiveness
from faraway_realms.content_parsers.factions import parse_factions
from faraway_realms.content_parsers.stat_definitions import parse_stat_definitions
from faraway_realms.content_parsers.static_objects import parse_static_objects
from faraway_realms.content_parsers.status_effects import parse_status_effects
from faraway_realms.content_parsers.tiles import (
    parse_tile_overlays,
    parse_tile_type_patches,
    parse_tiles,
)
from faraway_realms.creature_type import CREATURE_REGISTRY
from faraway_realms.entity import Entity, Player
from faraway_realms.factions import FACTION_RELATIONS
from faraway_realms.game import Game
from faraway_realms.map import Map, make_blank_map, make_bordered_map
from faraway_realms.mapgen import (
    CaveGenerator,
    CreaturePopulationPass,
    NoiseTexturePass,
    StaticObjectPopulationPass,
)
from faraway_realms.panels import LiveStatsPanel
from faraway_realms.tile import Tile
from faraway_realms.ui import GameUI

_log = logging.getLogger(__name__)

_ASSETS = Path(__file__).parent / "assets"
_TILESET = _ASSETS / "unified_12x12.png"
_DATA_STATS = Path(__file__).parent / "data" / "stats"
_USER_STATS = Path.home() / ".faraway_realms" / "stats"
_DATA_ABILITIES = Path(__file__).parent / "data" / "abilities"
_USER_ABILITIES = Path.home() / ".faraway_realms" / "abilities"
_DATA_CREATURES = Path(__file__).parent / "data" / "creatures"
_USER_CREATURES = Path.home() / ".faraway_realms" / "creatures"
_DATA_CHARACTERS = Path(__file__).parent / "data" / "characters"
_USER_CHARACTERS = Path.home() / ".faraway_realms" / "characters"
_DATA_STATIC_OBJECTS = Path(__file__).parent / "data" / "static_objects"
_USER_STATIC_OBJECTS = Path.home() / ".faraway_realms" / "static_objects"
_DATA_DAMAGE_TYPES = Path(__file__).parent / "data" / "damage_types"
_USER_DAMAGE_TYPES = Path.home() / ".faraway_realms" / "damage_types"
_DATA_FACTIONS = Path(__file__).parent / "data" / "factions"
_USER_FACTIONS = Path.home() / ".faraway_realms" / "factions"
_DATA_TILES = Path(__file__).parent / "data" / "tiles"
_USER_TILES = Path.home() / ".faraway_realms" / "tiles"
_DATA_STATUS_EFFECTS = Path(__file__).parent / "data" / "status_effects"
_USER_STATUS_EFFECTS = Path.home() / ".faraway_realms" / "status_effects"
_UUID_FILE = Path.home() / ".faraway_realms" / "client.uuid"

_MAP_WIDTH = 100
_MAP_HEIGHT = 60
_MAP_SEED = 42


def _validate_damage_types() -> None:
    from faraway_realms.damage_types import EFFECTIVENESS

    known_damage = {dt for dt, _ in EFFECTIVENESS}
    known_armor = {at for _, at in EFFECTIVENESS}
    for ct in [*CREATURE_REGISTRY.values(), *CHARACTER_REGISTRY.values()]:
        cp = ct.combat_profile
        if cp.damage_type not in known_damage:
            _log.warning(
                "Content: %r has unknown damage_type %r (not in effectiveness matrix)",
                ct.name,
                cp.damage_type,
            )
        if cp.armor_type != "none" and cp.armor_type not in known_armor:
            _log.warning(
                "Content: %r has unknown armor_type %r (not in effectiveness matrix)",
                ct.name,
                cp.armor_type,
            )


def _load_content() -> None:
    loader = ContentLoader(
        dirs=[
            _DATA_STATS,
            _USER_STATS,
            _DATA_ABILITIES,
            _USER_ABILITIES,
            _DATA_CREATURES,
            _USER_CREATURES,
            _DATA_CHARACTERS,
            _USER_CHARACTERS,
            _DATA_STATIC_OBJECTS,
            _USER_STATIC_OBJECTS,
            _DATA_DAMAGE_TYPES,
            _USER_DAMAGE_TYPES,
            _DATA_FACTIONS,
            _USER_FACTIONS,
            _DATA_TILES,
            _USER_TILES,
            _DATA_STATUS_EFFECTS,
            _USER_STATUS_EFFECTS,
        ]
    )
    loader.register_parser("stat_definitions", parse_stat_definitions)
    loader.register_parser("abilities", parse_abilities)
    loader.register_parser("creatures", parse_creatures)
    loader.register_parser("character_types", parse_character_types)
    loader.register_parser("static_objects", parse_static_objects)
    loader.register_parser("damage_effectiveness", parse_damage_effectiveness)
    loader.register_parser("factions", parse_factions)
    loader.register_parser("tiles", parse_tiles)
    loader.register_parser("tile_overlays", parse_tile_overlays)
    loader.register_parser("tile_type_patches", parse_tile_type_patches)
    loader.register_parser("status_effects", parse_status_effects)
    loader.load()
    _validate_damage_types()


def _load_or_create_uuid() -> str:
    _UUID_FILE.parent.mkdir(parents=True, exist_ok=True)
    if _UUID_FILE.exists():
        return _UUID_FILE.read_text().strip()
    uid = str(uuid.uuid4())
    _UUID_FILE.write_text(uid)
    return uid


def _build_game(seed: int) -> tuple[Game, Player]:
    rng = random.Random(seed)  # noqa: S311 — game logic, not crypto
    gen_result = CaveGenerator().generate(_MAP_WIDTH, _MAP_HEIGHT, rng)
    NoiseTexturePass().apply(gen_result, rng)
    CreaturePopulationPass().apply(gen_result, rng)
    StaticObjectPopulationPass().apply(gen_result, rng)
    game_map = gen_result.map

    entity = CHARACTER_REGISTRY["hero"].to_entity(entity_id=1)
    player = Player(username="player1", entity=entity, is_game_master=True)

    game = Game(game_map=game_map, faction_relations=FACTION_RELATIONS)
    for ct in CREATURE_REGISTRY.values():
        game.register_creature(ct.name, ct.to_npc)
    game.add_player(player)
    px, py = gen_result.player_start
    game_map.place_entity(entity.entity_id, px, py)

    for i, (creature_type, cx, cy) in enumerate(
        gen_result.creature_placements, start=2
    ):
        npc = creature_type.to_npc(entity_id=i)
        game.add_npc(npc)
        game_map.place_entity(i, cx, cy)

    for sot, sx, sy in gen_result.static_object_placements:
        game.add_static_object(sot.to_static_object(sx, sy))

    return game, player


def _start_server_thread(server: object) -> None:
    def _run() -> None:
        asyncio.run(server.run())  # type: ignore[attr-defined]

    t = threading.Thread(target=_run, daemon=True, name="GameServer")
    t.start()


def _wait_for_server(server: object) -> int:
    import time

    for _ in range(50):  # up to 5 seconds
        try:
            return server.bound_port  # type: ignore[attr-defined]
        except RuntimeError:
            time.sleep(0.1)
    raise RuntimeError("Server did not start in time")


def _parse_addr(addr: str) -> tuple[str, int]:
    parts = addr.rsplit(":", 1)
    return parts[0], int(parts[1])


def _reconstruct_map(tiles_data: list, width: int, height: int) -> Map:
    """Build a Map from a sparse tile list received in the welcome message."""
    game_map = make_blank_map(width, height)
    for cell in tiles_data:
        game_map.set_tile(
            cell["x"],
            cell["y"],
            Tile(
                walkable=cell["walkable"],
                fg_color=tuple(cell["fg"]),  # type: ignore[arg-type]
                bg_color=tuple(cell["bg"]),  # type: ignore[arg-type]
                char=cell.get("char", ord(".")),
            ),
        )
    return game_map


def _map_from_welcome(welcome: dict) -> Map:
    map_tiles_data = welcome.get("map_tiles")
    width = welcome.get("map_width", _MAP_WIDTH)
    height = welcome.get("map_height", _MAP_HEIGHT)
    if map_tiles_data is not None:
        return _reconstruct_map(map_tiles_data, width, height)
    return make_bordered_map(width, height)


def _run_as_client(addr: str) -> None:
    import time

    from faraway_realms.client_game import ClientGame
    from faraway_realms.net.client import NetworkClient

    host, port = _parse_addr(addr)
    uid = _load_or_create_uuid()
    client = NetworkClient(host, port, uid, username="player1")
    client.start()

    for _ in range(100):
        if client.welcome_info() is not None:
            break
        time.sleep(0.05)

    welcome = client.welcome_info() or {}
    game_map = _map_from_welcome(welcome)
    entity_id = welcome.get("entity_id", 1)
    cg = ClientGame(
        client,
        game_map,
        initial_static_objects=welcome.get("static_objects", []),
        initial_blood_tiles=welcome.get("blood_tiles", {}),
    )

    stub_entity = Entity(
        entity_id=entity_id,
        char=ord("@"),
        fg_color=(255, 255, 0),
        name="Hero",
        faction="player",
    )
    viewing_player = Player(username="player1", entity=stub_entity)

    ui = GameUI(
        game=cg,
        tileset_path=_TILESET,
        viewing_player=viewing_player,
        panels=[LiveStatsPanel(cg, entity_id)],
    )
    ui.run()
    client.stop()


def _run_as_server(seed: int, serve_addr: str, headless: bool) -> None:
    from faraway_realms.net.server import GameServer

    _load_content()
    game, _player = _build_game(seed)
    host, port = _parse_addr(serve_addr)
    server = GameServer(game, host=host, port=port)

    if headless:
        asyncio.run(server.run())
    else:
        _start_server_thread(server)
        port = _wait_for_server(server)
        _run_as_client(f"{host}:{port}")


def _run_singleplayer(seed: int) -> None:
    from faraway_realms.net.server import GameServer

    _load_content()
    game, _player = _build_game(seed)
    server = GameServer(game, host="127.0.0.1", port=0)
    _start_server_thread(server)
    port = _wait_for_server(server)
    _run_as_client(f"127.0.0.1:{port}")


def _raise_windows_timer_resolution() -> None:
    """Set Windows multimedia timer resolution to 1 ms for the process lifetime.

    asyncio's ProactorEventLoop uses the system timer for scheduling; the default
    resolution is ~15 ms which causes tick-rate drift.  timeBeginPeriod(1) is a
    process-scoped request — Windows 10 2004+ restores it automatically on exit.
    """
    import ctypes  # noqa: PLC0415
    import sys  # noqa: PLC0415

    if sys.platform == "win32":
        ctypes.windll.winmm.timeBeginPeriod(1)


def main(
    seed: int = _MAP_SEED,
    serve: str | None = None,
    connect: str | None = None,
    headless: bool = False,
) -> None:
    """Bootstrap a default game and open the window."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    _raise_windows_timer_resolution()
    from faraway_realms import __version__  # noqa: PLC0415

    _log.info("faraway-realms %s", __version__)
    if connect:
        _load_content()
        _run_as_client(connect)
    elif serve:
        _run_as_server(seed, serve, headless)
    else:
        _run_singleplayer(seed)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="faraway_realms")
    parser.add_argument("seed", nargs="?", type=int, default=_MAP_SEED)
    parser.add_argument("--serve", default=None, metavar="HOST:PORT")
    parser.add_argument("--connect", default=None, metavar="HOST:PORT")
    parser.add_argument("--headless", action="store_true")
    args = parser.parse_args()
    main(
        seed=args.seed,
        serve=args.serve,
        connect=args.connect,
        headless=args.headless,
    )
