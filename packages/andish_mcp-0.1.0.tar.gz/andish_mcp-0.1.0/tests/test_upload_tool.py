"""Unit tests for andish_upload_document MCP tool — CEO-SELF-USE-BUNDLE Story 8.

Tests:
  - tool registration
  - happy path (file upload → document_id in response)
  - file-not-found → user-friendly error
  - empty content → user-friendly error
  - SDK AndishError (e.g. auth failure) → to_user_message mapping
  - title metadata propagated
  - document_date propagated
  - SDK roundtrip: httpx.MockTransport verifies POST /v1/documents path + response
    parsed to non-default document_id (per feedback_sdk_roundtrip_test_required)
"""

from __future__ import annotations

from __future__ import annotations

import importlib
import json
from pathlib import Path  # noqa: TC003 — pytest fixture parameter; cannot move to TYPE_CHECKING
from unittest.mock import MagicMock

import httpx
import pytest

from andish.errors import AuthError
from andish.types import Document

# ---------------------------------------------------------------------------
# mcp availability guard
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(not _mcp_available, reason="mcp not installed")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_upload_doc(document_id: str = "upload-uuid-0001", status: str = "pending") -> Document:
    return Document(
        document_id=document_id,
        status=status,
        created_at="",
        updated_at="",
        meta={"filename": "test.md"},
    )


# ---------------------------------------------------------------------------
# Business logic tests (_format_upload) — no mcp required
# ---------------------------------------------------------------------------


class TestUploadToolOutputFormat:
    """Test _format_upload() directly (no FastMCP)."""

    def test_happy_path_returns_document_id(self, tmp_path: Path) -> None:
        """A successful upload prints the document_id in the response."""
        from andish_mcp.tools.upload import _format_upload  # noqa: PLC0415

        md_file = tmp_path / "test.md"
        md_file.write_text("# ADR-999\nThis is a test document.", encoding="utf-8")

        mock_client = MagicMock()
        mock_client.documents.upload.return_value = _make_upload_doc("doc-abc-999")

        result = _format_upload(mock_client, str(md_file))

        assert "doc-abc-999" in result
        assert "pending" in result
        assert "andish_get_document" in result

    def test_file_not_found_returns_error(self) -> None:
        """Non-existent path returns a user-friendly error string (not an exception)."""
        from andish_mcp.tools.upload import _format_upload  # noqa: PLC0415

        mock_client = MagicMock()
        # SDK upload raises ValueError for missing file.
        mock_client.documents.upload.side_effect = ValueError("File not found: /no/such.md")

        result = _format_upload(mock_client, "/no/such.md")

        assert "Ошибка" in result
        assert "/no/such.md" in result

    def test_auth_error_returns_user_message(self, tmp_path: Path) -> None:
        """AuthError from SDK is mapped to user-friendly Russian message."""
        from andish_mcp.tools.upload import _format_upload  # noqa: PLC0415

        md_file = tmp_path / "auth_test.md"
        md_file.write_text("content", encoding="utf-8")

        mock_client = MagicMock()
        mock_client.documents.upload.side_effect = AuthError("Bad key", status_code=401)

        result = _format_upload(mock_client, str(md_file))

        assert "невалиден" in result or "API ключ" in result

    def test_title_propagated_to_sdk(self, tmp_path: Path) -> None:
        """title kwarg is passed as metadata['title'] to client.documents.upload."""
        from andish_mcp.tools.upload import _format_upload  # noqa: PLC0415

        md_file = tmp_path / "titled.md"
        md_file.write_text("content", encoding="utf-8")

        mock_client = MagicMock()
        mock_client.documents.upload.return_value = _make_upload_doc()

        _format_upload(mock_client, str(md_file), title="My Title")

        call_kwargs = mock_client.documents.upload.call_args
        assert call_kwargs is not None
        metadata_arg = call_kwargs[1].get("metadata") or {}
        assert metadata_arg.get("title") == "My Title"

    def test_document_date_propagated_to_sdk(self, tmp_path: Path) -> None:
        """document_date kwarg is forwarded to client.documents.upload."""
        from andish_mcp.tools.upload import _format_upload  # noqa: PLC0415

        md_file = tmp_path / "dated.md"
        md_file.write_text("content", encoding="utf-8")

        mock_client = MagicMock()
        mock_client.documents.upload.return_value = _make_upload_doc()

        _format_upload(mock_client, str(md_file), document_date="2025-Q4")

        call_kwargs = mock_client.documents.upload.call_args
        assert call_kwargs[1].get("document_date") == "2025-Q4"


# ---------------------------------------------------------------------------
# Registration test — requires mcp
# ---------------------------------------------------------------------------


@requires_mcp
class TestUploadToolRegistration:
    """Verify andish_upload_document is registered in FastMCP."""

    def test_tool_registered(self) -> None:
        """andish_upload_document must appear in the tool list after register()."""
        from mcp.server.fastmcp import FastMCP  # noqa: PLC0415

        from andish_mcp.tools.upload import register  # noqa: PLC0415

        mcp = FastMCP("test")
        mock_client = MagicMock()
        register(mcp, mock_client)

        tool_names = [t.name for t in mcp._tool_manager.list_tools()]
        assert "andish_upload_document" in tool_names


# ---------------------------------------------------------------------------
# SDK roundtrip test — httpx.MockTransport (per feedback_sdk_roundtrip_test_required)
# ---------------------------------------------------------------------------


class TestUploadSDKRoundtrip:
    """Verify SDK documents.upload() parses POST /v1/documents response correctly.

    Uses httpx.MockTransport to intercept the HTTP call and return a crafted
    JSON body.  Asserts that the returned Document has a non-default document_id.
    This guards against parser bypass (pattern identified in Sprint 2 incidents).
    """

    def test_roundtrip_document_id_parsed(self, tmp_path: Path) -> None:
        """SDK parses POST /v1/documents 202 response into Document with correct id."""
        from andish import Client  # noqa: PLC0415

        expected_id = "roundtrip-doc-9999"

        # Build a minimal 202 response matching DocumentCreateResponse wire format.
        response_body = json.dumps({
            "document_id": expected_id,
            "status": "pending",
            "status_url": f"/v1/documents/{expected_id}",
            "is_split": False,
        }).encode()

        def _handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/v1/documents"
            return httpx.Response(202, content=response_body)

        transport = httpx.MockTransport(_handler)
        # Bypass Client.__init__ which requires a real httpx.Client.
        # We construct the internal _http directly to inject mock transport.
        real_client = Client.__new__(Client)
        real_client._max_retries = 0
        real_client._http = httpx.Client(
            base_url="https://api.andish.ru/v1",
            transport=transport,
            headers={"Authorization": "Bearer adsh_test_roundtrip"},
        )
        # Import the namespace directly to attach to our manually constructed client.
        from andish.client import _DocumentsNamespace  # noqa: PLC0415

        docs_ns = _DocumentsNamespace(real_client._http, max_retries=0)

        # Write a temp file so upload() finds a real path.
        test_file = tmp_path / "roundtrip.md"
        test_file.write_text("# Roundtrip test", encoding="utf-8")

        doc = docs_ns.upload(str(test_file))

        # Non-default value assertion (per rule: not just Pydantic construction).
        assert doc.document_id == expected_id
        assert doc.status == "pending"
