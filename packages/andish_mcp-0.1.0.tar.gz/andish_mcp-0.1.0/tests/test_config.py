"""Unit tests for andish_mcp.config — SP1-02."""

from __future__ import annotations

import pytest

# config.py has NO mcp import — these tests run without mcp installed.
from andish_mcp.config import MCPConfig, load_config


def test_config_loads_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_config reads ANDISH_API_KEY from env and returns MCPConfig."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_abc123")
    monkeypatch.delenv("ANDISH_BASE_URL", raising=False)
    monkeypatch.delenv("ANDISH_TIMEOUT", raising=False)

    cfg = load_config()

    assert cfg.api_key == "adsh_test_abc123"
    assert cfg.base_url == "https://api.andish.ru/v1"
    assert cfg.timeout == 30.0


def test_config_fails_fast_when_api_key_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_config raises SystemExit with helpful message when key is absent."""
    monkeypatch.delenv("ANDISH_API_KEY", raising=False)

    with pytest.raises(SystemExit) as exc_info:
        load_config()

    assert "ANDISH_API_KEY" in str(exc_info.value)
    assert "andish.ru/dashboard" in str(exc_info.value)


def test_config_fails_fast_when_api_key_empty(monkeypatch: pytest.MonkeyPatch) -> None:
    """load_config raises SystemExit when ANDISH_API_KEY is set but empty."""
    monkeypatch.setenv("ANDISH_API_KEY", "   ")

    with pytest.raises(SystemExit) as exc_info:
        load_config()

    assert "ANDISH_API_KEY" in str(exc_info.value)


def test_config_strips_trailing_slash_from_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    """base_url trailing slash is stripped to allow clean path concatenation."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_BASE_URL", "https://staging.andish.ru/v1/")

    cfg = load_config()

    assert cfg.base_url == "https://staging.andish.ru/v1"
    assert not cfg.base_url.endswith("/")


def test_config_custom_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    """ANDISH_BASE_URL override is respected."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_BASE_URL", "http://localhost:8000/v1")

    cfg = load_config()

    assert cfg.base_url == "http://localhost:8000/v1"


def test_config_custom_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """ANDISH_TIMEOUT override is respected."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_TIMEOUT", "60.0")

    cfg = load_config()

    assert cfg.timeout == 60.0


def test_config_invalid_timeout_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-numeric ANDISH_TIMEOUT raises SystemExit."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_TIMEOUT", "not-a-float")

    with pytest.raises(SystemExit):
        load_config()


def test_config_rejects_base_url_without_scheme(monkeypatch: pytest.MonkeyPatch) -> None:
    """ANDISH_BASE_URL without http(s):// scheme is rejected (SSRF defence — security review M1)."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_BASE_URL", "file:///etc/passwd")

    with pytest.raises(SystemExit) as exc_info:
        load_config()

    assert "ANDISH_BASE_URL" in str(exc_info.value)
    assert "http" in str(exc_info.value)


def test_config_rejects_bare_host(monkeypatch: pytest.MonkeyPatch) -> None:
    """Bare host without scheme also rejected (e.g. someone pastes 'api.andish.ru')."""
    monkeypatch.setenv("ANDISH_API_KEY", "adsh_test_xyz")
    monkeypatch.setenv("ANDISH_BASE_URL", "api.andish.ru/v1")

    with pytest.raises(SystemExit):
        load_config()


def test_mcp_config_is_frozen() -> None:
    """MCPConfig is a frozen dataclass — no mutation allowed."""
    cfg = MCPConfig(api_key="adsh_test_immutable")

    with pytest.raises((AttributeError, TypeError)):
        cfg.api_key = "changed"  # type: ignore[misc]
