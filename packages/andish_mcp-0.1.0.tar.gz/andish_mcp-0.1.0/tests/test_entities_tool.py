"""Unit tests for andish_search_entities and andish_get_neighbors MCP tools.

Tests that do NOT require mcp test the output formatting logic independently.
Tests that DO require mcp check tool registration and call behaviour.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from andish.errors import AndishError, AuthError, NotFoundError
from andish.types import EdgeRef, EntityRef, EntitySearchResponse, NeighborResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_search_response(
    entities: list[EntityRef], query: str = "test"
) -> EntitySearchResponse:
    return EntitySearchResponse(entities=entities, query=query, total=len(entities))


def _make_neighbor_response(
    entity: EntityRef,
    neighbors: list[EntityRef],
    edges: list[EdgeRef] | None = None,
    hop: int = 1,
) -> NeighborResponse:
    return NeighborResponse(
        entity=entity,
        neighbors=neighbors,
        edges=edges or [],
        hop=hop,
    )


def _entity(id_: str, label: str, type_: str | None = None) -> EntityRef:
    return EntityRef(id=id_, label=label, type=type_)


def _edge(source: str, target: str, type_: str | None = None) -> EdgeRef:
    return EdgeRef(source=source, target=target, type=type_)


# ---------------------------------------------------------------------------
# Test 1: tool schema check (requires mcp)
# ---------------------------------------------------------------------------

try:
    import mcp  # noqa: F401

    _mcp_available = True
except ImportError:
    _mcp_available = False

requires_mcp = pytest.mark.skipif(not _mcp_available, reason="mcp not installed")


@requires_mcp
def test_search_entities_tool_schema_valid() -> None:
    """FastMCP-registered andish_search_entities must expose correct JSON schema.

    Expected: query is required string, limit is optional int with default 20.
    """
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    cfg = MCPConfig(api_key="adsh_test_unittest", base_url="http://localhost:8000/v1")
    mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert "andish_search_entities" in tools, f"Tool not registered; found: {list(tools)}"

    tool = tools["andish_search_entities"]
    schema = tool.parameters  # FastMCP exposes JSON schema via .parameters
    props = schema.get("properties", {})

    assert "query" in props, f"'query' param missing; got {list(props)}"
    assert "limit" in props, f"'limit' param missing; got {list(props)}"
    # limit should be integer type
    assert props["limit"].get("type") == "integer" or "integer" in str(props["limit"]), (
        f"limit must be integer, got: {props['limit']}"
    )


# ---------------------------------------------------------------------------
# Test 2: tool calls SDK correctly (requires mcp)
# ---------------------------------------------------------------------------


@requires_mcp
def test_search_entities_tool_calls_sdk_correctly(monkeypatch: pytest.MonkeyPatch) -> None:
    """andish_search_entities must call client.entities.search with correct args."""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.search.return_value = _make_search_response(
        [_entity("FastAPI", "FastAPI", "FRAMEWORK")],
        query="Fast",
    )

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    # Retrieve the tool callable from FastMCP and call it.
    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert "andish_search_entities" in tools

    # Simulate a tool call: call the underlying function directly.
    tool = tools["andish_search_entities"]
    result = tool.fn(query="Fast", limit=10)  # type: ignore[attr-defined]

    mock_client.entities.search.assert_called_once_with("Fast", limit=10)
    assert isinstance(result, str)
    assert "FastAPI" in result
    assert "Found 1 entities" in result


# ---------------------------------------------------------------------------
# Test 3: 404 from get_neighbors → user-friendly message (no raw HTTP)
# ---------------------------------------------------------------------------


@requires_mcp
def test_get_neighbors_tool_404_mapped_to_user_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """NotFoundError from entities.get_neighbors must return user-friendly string."""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.get_neighbors.side_effect = NotFoundError(
        "Entity not found.", status_code=404
    )

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert "andish_get_neighbors" in tools

    tool = tools["andish_get_neighbors"]
    result = tool.fn(entity_id="nonexistent", hop=1, limit=50)  # type: ignore[attr-defined]

    # Must be a string, not an exception.
    assert isinstance(result, str)
    # Must not contain raw HTTP codes — user-friendly message expected.
    assert "404" not in result
    # Must contain the word "найден" (from NotFoundError mapping in errors.py).
    assert "найден" in result.lower(), f"Expected 'найден' in result: {result!r}"


# ---------------------------------------------------------------------------
# Test 4: empty search result → "No entities matched." string
# ---------------------------------------------------------------------------


@requires_mcp
def test_search_entities_tool_empty_result_string(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty entity list → tool output contains 'No entities matched.'"""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.search.return_value = _make_search_response([], query="zzz")

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    tool = tools["andish_search_entities"]
    result = tool.fn(query="zzz", limit=20)  # type: ignore[attr-defined]

    assert result == "No entities matched.", f"Unexpected result: {result!r}"


# ---------------------------------------------------------------------------
# Additional: andish_get_neighbors happy path output format
# ---------------------------------------------------------------------------


@requires_mcp
def test_get_neighbors_tool_output_format(monkeypatch: pytest.MonkeyPatch) -> None:
    """andish_get_neighbors returns structured output with entity label and neighbors."""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.get_neighbors.return_value = _make_neighbor_response(
        entity=_entity("FastAPI", "FastAPI", "FRAMEWORK"),
        neighbors=[
            _entity("Python", "Python", "LANGUAGE"),
            _entity("PostgreSQL", "PostgreSQL", "DATABASE"),
        ],
        edges=[
            _edge("FastAPI", "Python", "uses"),
            _edge("FastAPI", "PostgreSQL", "stores_data_in"),
        ],
        hop=1,
    )

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    tool = tools["andish_get_neighbors"]
    result = tool.fn(entity_id="FastAPI", hop=1, limit=50)  # type: ignore[attr-defined]

    assert "Entity: FastAPI" in result
    assert "Neighbors (hop=1):" in result
    assert "Python" in result
    assert "PostgreSQL" in result


# ---------------------------------------------------------------------------
# Additional: auth error in search → user-friendly message
# ---------------------------------------------------------------------------


@requires_mcp
def test_search_entities_auth_error_mapped_to_user_message(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """AuthError from entities.search → user-friendly message (not exception)."""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.search.side_effect = AuthError("Bad key", status_code=401)

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    tool = tools["andish_search_entities"]
    result = tool.fn(query="test")  # type: ignore[attr-defined]

    assert isinstance(result, str)
    assert "401" not in result  # no raw HTTP codes
    assert "невалиден" in result or "истёк" in result  # human message


# ---------------------------------------------------------------------------
# No-mcp fallback: verify tool formatting logic without mcp dependency
# ---------------------------------------------------------------------------


def test_search_entities_output_format_no_mcp() -> None:
    """Replicates search output formatting logic — no mcp required."""
    entities = [
        _entity("FastAPI", "FastAPI", "FRAMEWORK"),
        _entity("Python", "Python", "LANGUAGE"),
    ]
    total = len(entities)

    lines = [f"Found {total} entities:"]
    for entity in entities:
        type_part = f" ({entity.type})" if entity.type else ""
        lines.append(f"  - {entity.id}: {entity.label}{type_part}")
    result = "\n".join(lines)

    assert "Found 2 entities" in result
    assert "FastAPI: FastAPI (FRAMEWORK)" in result
    assert "Python: Python (LANGUAGE)" in result


def test_search_entities_empty_output_no_mcp() -> None:
    """Empty entities → 'No entities matched.' — no mcp required."""
    entities: list[EntityRef] = []
    result = "No entities matched." if not entities else ""
    assert result == "No entities matched."


# ---------------------------------------------------------------------------
# Generic AndishError → user-friendly mapping (covers network errors,
# 5xx server errors, anything wrapped by SDK _retry_request as AndishError)
# ---------------------------------------------------------------------------


@requires_mcp
def test_search_entities_tool_generic_andish_error_mapped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Generic AndishError (e.g. from httpx.TimeoutException wrapped by
    _retry_request after retries exhausted) must NOT propagate as raw exception
    — to_user_message produces a human-readable string. Catches QA P1 gap:
    network errors leaking traceback to LLM context.
    """
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    # Simulate network exhaustion: SDK wraps httpx.ConnectError → AndishError
    mock_client.entities.search.side_effect = AndishError(
        "Connection refused after 3 retries"
    )

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    tool = tools["andish_search_entities"]

    # Must NOT raise — must return a string envelope.
    result = tool.fn(query="anything")  # type: ignore[attr-defined]

    assert isinstance(result, str), (
        f"Tool leaked raw exception instead of returning string: {result!r}"
    )
    # Must not leak raw httpx/Connection details verbatim.
    # to_user_message should produce a human-readable string instead.
    assert len(result) > 0


@requires_mcp
def test_get_neighbors_tool_generic_andish_error_mapped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Same as above for andish_get_neighbors — generic AndishError → string."""
    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.entities.get_neighbors.side_effect = AndishError(
        "Read timeout after 3 retries"
    )

    with monkeypatch.context() as m:
        m.setattr(server_module, "_get_client", lambda cfg: mock_client)
        cfg = MCPConfig(api_key="adsh_test_mock", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tools = {t.name: t for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    tool = tools["andish_get_neighbors"]
    result = tool.fn(entity_id="some_id", hop=1, limit=50)  # type: ignore[attr-defined]

    assert isinstance(result, str), (
        f"Tool leaked raw exception: {result!r}"
    )
    assert len(result) > 0
