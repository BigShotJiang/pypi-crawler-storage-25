"""Unit tests for andish_list_documents and andish_get_document MCP tools.

SP2-02 (andish_list_documents) — 6+ tests:
  - registration
  - output format (markdown table)
  - pagination note (AC8)
  - empty list (AC4)
  - 402 CostCapError mapping (AC9)
  - 422 limit validation (AC7)

SP2-03 (andish_get_document) — 4+ tests:
  - registration
  - output format (metadata markdown)
  - 404 NotFoundError mapping
  - 402 CostCapError mapping

Regression gate (pre-merge checklist item 4):
  - test_list_raises_if_sdk_not_implemented and test_get_raises_if_sdk_not_implemented
    verify tests fail when SDK methods raise NotImplementedError (stubs).
"""

from __future__ import annotations

import importlib
from decimal import Decimal
from unittest.mock import MagicMock, patch

import pytest

from andish.errors import (
    AuthError,
    CostCapError,
    NotFoundError,
)
from andish.types import Document, DocumentListResponse

# ---------------------------------------------------------------------------
# mcp availability guard — mirrors conftest.py pattern
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(not _mcp_available, reason="mcp not installed")


# ---------------------------------------------------------------------------
# Helpers — shared test factories
# ---------------------------------------------------------------------------


def _make_document(
    document_id: str = "doc-uuid-0001",
    status: str = "indexed",
    created_at: str = "2026-05-01T10:00:00Z",
    updated_at: str = "2026-05-01T10:05:00Z",
    meta: dict | None = None,
    progress_percent: int = 100,
    error_message: str | None = None,
    processed_at: str | None = "2026-05-01T10:05:00Z",
    content: str | None = None,
) -> Document:
    return Document(
        document_id=document_id,
        status=status,
        created_at=created_at,
        updated_at=updated_at,
        meta=meta or {},
        progress_percent=progress_percent,
        error_message=error_message,
        processed_at=processed_at,
        content=content,
    )


def _make_list_response(
    items: list[Document],
    total: int | None = None,
    limit: int = 50,
    offset: int = 0,
) -> DocumentListResponse:
    return DocumentListResponse(
        items=items,
        total=total if total is not None else len(items),
        limit=limit,
        offset=offset,
    )


# ===========================================================================
# SP2-02: andish_list_documents — business logic via _format_list
# ===========================================================================


class TestListDocumentsOutputFormat:
    """Test the _format_list() business logic directly (no mcp required)."""

    def test_table_has_header_and_separator(self) -> None:
        """Output must start with a markdown table header and separator row."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        doc = _make_document(document_id="abc-123", meta={"title": "API Spec"})
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([doc])

        result = _format_list(mock_client, limit=50)

        assert "| id | name | status | uploaded_at |" in result
        assert "| --- |" in result
        assert "abc-123" in result
        assert "API Spec" in result
        assert "indexed" in result

    def test_empty_workspace_returns_friendly_message(self) -> None:
        """AC4: empty items list → 'Нет документов в workspace.'"""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        result = _format_list(mock_client)

        assert result == "Нет документов в workspace."

    def test_pagination_note_shown_when_total_exceeds_items(self) -> None:
        """AC8: when total > len(items), must show pagination footer."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        items = [_make_document(document_id=f"doc-{i}") for i in range(3)]
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response(
            items, total=50, limit=3
        )

        result = _format_list(mock_client, limit=3)

        assert "showing first 3 of 50 documents" in result
        assert "increase limit parameter to see more" in result
        assert "max 100" in result

    def test_no_pagination_note_when_all_returned(self) -> None:
        """No pagination note when total == len(items)."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        items = [_make_document(document_id=f"doc-{i}") for i in range(2)]
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response(
            items, total=2, limit=50
        )

        result = _format_list(mock_client, limit=50)

        assert "showing first" not in result

    def test_limit_over_100_returns_validation_message(self) -> None:
        """AC7: limit > 100 → validation message, SDK is NOT called."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        mock_client = MagicMock()

        result = _format_list(mock_client, limit=200)

        assert "limit" in result.lower()
        assert "200" in result
        mock_client.documents.list.assert_not_called()

    def test_list_cost_cap_402_mapped(self) -> None:
        """AC9: HTTP 402 (CostCapError) → human message, NOT generic fallback."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.documents.list.side_effect = CostCapError(
            "Over cap",
            status_code=402,
            cap=Decimal("500.00"),
            current_spend=Decimal("501.00"),
        )

        result = _format_list(mock_client)

        assert "500" in result
        assert "лимит" in result.lower()
        # Must NOT be the generic AndishError fallback.
        assert "Ошибка Andish:" not in result

    def test_long_name_truncated_in_table(self) -> None:
        """Document names over 40 chars must be truncated with ellipsis."""
        from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

        long_title = "A" * 50
        doc = _make_document(meta={"title": long_title})
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([doc])

        result = _format_list(mock_client)

        assert "..." in result
        # The full 50-char title must not appear verbatim.
        assert long_title not in result


# ---------------------------------------------------------------------------
# Registration test (requires mcp)
# ---------------------------------------------------------------------------


@requires_mcp
def test_andish_list_documents_registered_in_server() -> None:
    """AC1: After build_server(), 'andish_list_documents' must be registered."""
    import andish_mcp.server as server_module  # noqa: PLC0415
    from andish_mcp.config import MCPConfig  # noqa: PLC0415
    from andish_mcp.server import build_server  # noqa: PLC0415

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_unittest", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tool_names = [t.name for t in mcp_server._tool_manager.list_tools()]  # type: ignore[attr-defined]
    assert "andish_list_documents" in tool_names


# ===========================================================================
# SP2-03: andish_get_document — business logic via _format_get
# ===========================================================================


class TestGetDocumentOutputFormat:
    """Test _format_get() business logic directly (no mcp required)."""

    def test_get_returns_metadata_markdown(self) -> None:
        """Output must include document ID, status, and timestamps."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        doc = _make_document(
            document_id="abc-xyz",
            status="indexed",
            created_at="2026-05-01T10:00:00Z",
            meta={"source": "confluence"},
        )
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="abc-xyz")

        assert "abc-xyz" in result
        assert "indexed" in result
        assert "2026-05-01T10:00:00Z" in result
        assert "source" in result
        assert "confluence" in result

    def test_get_shows_error_message_on_failed_doc(self) -> None:
        """error_message field must appear in output when status='failed'."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        doc = _make_document(
            status="failed",
            error_message="Extraction timeout after 60s",
            progress_percent=0,
            processed_at=None,
        )
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "failed" in result
        assert "Extraction timeout after 60s" in result

    def test_get_not_found_404_mapped(self) -> None:
        """NotFoundError (404) → user-friendly Russian message."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.documents.get.side_effect = NotFoundError(
            "not_found", status_code=404
        )

        result = _format_get(mock_client, document_id="no-such-doc")

        assert "не найден" in result.lower()
        # Must not leak raw HTTP status code.
        assert "404" not in result

    def test_get_cost_cap_402_mapped(self) -> None:
        """CostCapError (402) → human message mentioning лимит."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.documents.get.side_effect = CostCapError(
            "Over cap",
            status_code=402,
            cap=Decimal("100.00"),
        )

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "100" in result
        assert "лимит" in result.lower()

    def test_get_auth_error_mapped(self) -> None:
        """AuthError → user-friendly message about API key."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.documents.get.side_effect = AuthError("Bad key", status_code=401)

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "невалиден" in result or "истёк" in result

    def test_get_no_meta_still_renders(self) -> None:
        """Document with empty meta must still render without crash."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        doc = _make_document(meta={})
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "indexed" in result
        assert "Metadata" not in result  # No metadata section for empty dict

    # ------------------------------------------------------------------
    # GET-DOCUMENT-CONTENT-BLANK regression tests (ADR-036 §2.6)
    # ------------------------------------------------------------------

    def test_get_content_short_rendered_in_full(self) -> None:
        """Content shorter than 500 chars must appear verbatim in output."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        short_text = "Hello, Andish! This is the document content."
        doc = _make_document(content=short_text)
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "**Content:**" in result
        assert short_text in result
        # No truncation note for short content.
        assert "excerpt" not in result

    def test_get_content_long_truncated_with_excerpt_note(self) -> None:
        """Content longer than 500 chars must be truncated with an excerpt note."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        long_text = "X" * 1200
        doc = _make_document(content=long_text)
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "**Content:**" in result
        assert "X" * 500 in result          # excerpt starts with 500 Xs
        assert "X" * 501 not in result       # but NOT 501 (truncated)
        assert "excerpt" in result
        assert "1200" in result              # total char count shown

    def test_get_content_none_shows_placeholder(self) -> None:
        """None content (legacy/encrypted-only doc) must show placeholder, not blank."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        doc = _make_document(content=None)
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert "**Content:**" in result
        assert "no content available" in result

    def test_get_content_exactly_500_chars_not_truncated(self) -> None:
        """Content exactly 500 chars must appear without truncation note."""
        from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

        exact_text = "A" * 500
        doc = _make_document(content=exact_text)
        mock_client = MagicMock()
        mock_client.documents.get.return_value = doc

        result = _format_get(mock_client, document_id="doc-uuid-0001")

        assert exact_text in result
        assert "excerpt" not in result


# ---------------------------------------------------------------------------
# Registration test (requires mcp)
# ---------------------------------------------------------------------------


@requires_mcp
def test_andish_get_document_registered_in_server() -> None:
    """After build_server(), 'andish_get_document' must be registered."""
    import andish_mcp.server as server_module  # noqa: PLC0415
    from andish_mcp.config import MCPConfig  # noqa: PLC0415
    from andish_mcp.server import build_server  # noqa: PLC0415

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_unittest", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tool_names = [t.name for t in mcp_server._tool_manager.list_tools()]  # type: ignore[attr-defined]
    assert "andish_get_document" in tool_names


# ===========================================================================
# Regression gate: SDK stubs must cause test failures
# ===========================================================================


def test_list_raises_if_sdk_not_implemented() -> None:
    """Regression: if list() is stubbed, _format_list raises NotImplementedError.

    This test fails if the SDK stub is restored — confirming SP2-01 is required.
    """
    from andish_mcp.tools.documents import _format_list  # noqa: PLC0415

    mock_client = MagicMock()
    mock_client.documents.list.side_effect = NotImplementedError(
        "documents.list is not yet implemented in v0.1"
    )

    # _format_list does NOT catch NotImplementedError — it propagates.
    with pytest.raises(NotImplementedError):
        _format_list(mock_client)


def test_get_raises_if_sdk_not_implemented() -> None:
    """Regression: if get() is stubbed, _format_get raises NotImplementedError.

    This test fails if the SDK stub is restored — confirming SP2-01 is required.
    """
    from andish_mcp.tools.documents import _format_get  # noqa: PLC0415

    mock_client = MagicMock()
    mock_client.documents.get.side_effect = NotImplementedError(
        "documents.get is not yet implemented in v0.1"
    )

    with pytest.raises(NotImplementedError):
        _format_get(mock_client, document_id="some-id")
