"""Unit tests for andish_mcp.errors — SP1-03.

Tests that each SDK exception class maps to the correct Russian user message.
These tests do NOT require the mcp package.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from andish.errors import (
    AndishError,
    AuthError,
    CostCapError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from andish_mcp.errors import to_user_message


# ---------------------------------------------------------------------------
# Per-exception-class mapping
# ---------------------------------------------------------------------------


def test_auth_error_message() -> None:
    exc = AuthError("Invalid API key", status_code=401)
    msg = to_user_message(exc)

    assert "невалиден" in msg or "истёк" in msg
    assert "andish.ru/dashboard" in msg


def test_cost_cap_error_with_cap() -> None:
    exc = CostCapError("Over cap", status_code=402, cap=Decimal("200.00"))
    msg = to_user_message(exc)

    assert "200" in msg  # cap value surfaced
    assert "лимит" in msg.lower()


def test_cost_cap_error_without_cap() -> None:
    """When cap is None, message must not crash and must not contain parenthesis."""
    exc = CostCapError("Over cap", status_code=402, cap=None)
    msg = to_user_message(exc)

    assert "лимит" in msg.lower()
    # No '(лимит None₽)' or similar garbage.
    assert "None" not in msg


def test_rate_limit_error_with_retry_after() -> None:
    exc = RateLimitError("Too many requests", status_code=429, retry_after=15.0)
    msg = to_user_message(exc)

    assert "15" in msg
    assert "запросов" in msg.lower() or "лимит" in msg.lower()


def test_rate_limit_error_without_retry_after() -> None:
    exc = RateLimitError("Too many requests", status_code=429, retry_after=None)
    msg = to_user_message(exc)

    # Must still return a message — no crash.
    assert len(msg) > 0
    assert "запросов" in msg.lower() or "лимит" in msg.lower()


def test_not_found_error_message() -> None:
    exc = NotFoundError("Document not found", status_code=404)
    msg = to_user_message(exc)

    assert "не найден" in msg.lower()


def test_validation_error_message() -> None:
    exc = ValidationError("Bad payload", status_code=422)
    msg = to_user_message(exc)

    assert "отклонён" in msg.lower() or "запрос" in msg.lower()


def test_server_error_message() -> None:
    exc = ServerError("Internal server error", status_code=500)
    msg = to_user_message(exc)

    assert "5xx" in msg or "ошибка" in msg.lower()
    assert "Повторите" in msg


def test_base_andish_error_fallback() -> None:
    """Base AndishError (no subclass) must return a non-empty fallback message."""
    exc = AndishError("Unknown error", status_code=418)
    msg = to_user_message(exc)

    assert len(msg) > 0
    # Must not crash.


# ---------------------------------------------------------------------------
# All messages are strings (no accidental None / exception propagation)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "exc",
    [
        AuthError("x", status_code=401),
        CostCapError("x", status_code=402),
        RateLimitError("x", status_code=429),
        NotFoundError("x", status_code=404),
        ValidationError("x", status_code=422),
        ServerError("x", status_code=500),
        AndishError("x", status_code=418),
    ],
)
def test_all_errors_return_str(exc: AndishError) -> None:
    result = to_user_message(exc)
    assert isinstance(result, str)
    assert len(result) > 0
