"""MCP roundtrip tests for Feature 03-bis (FRESHNESS-03-bis Phase 2).

Per feedback_sdk_roundtrip_test_required: mock SDK response → MCP tool invocation
→ assert formatted output contains new fields.

Tests cover:
  - andish_workspace_usage: renders documents_never_queried + documents_quiet_90d
  - andish_list_documents: accepts filter='never_queried' and forwards it to SDK
  - andish_list_documents: filter validation rejects unknown values
  - andish_list_documents: no filter → SDK called without filter kwarg
"""

from __future__ import annotations

from decimal import Decimal
from unittest.mock import MagicMock

import pytest

from andish.types import Document, DocumentListResponse, WorkspaceUsage
from andish_mcp.tools.documents import _format_list
from andish_mcp.tools.workspace import _format_usage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_usage(**kwargs: object) -> WorkspaceUsage:
    defaults: dict[str, object] = {
        "period": "2026-05",
        "cost_current_rub": Decimal("12.50"),
        "cost_cap_rub_daily": Decimal("100.00"),
        "percent_used": 0.13,
        "documents_uploaded": 25,
        "documents_processed": 20,
        "documents_current": 20,
        "queries_today": 5,
        "tier": "beta",
        "next_reset_at": "2026-06-01T00:00:00Z",
        # Feature 03-bis defaults (zero = no cleanup items)
        "documents_never_queried": 0,
        "documents_quiet_90d": 0,
    }
    defaults.update(kwargs)
    return WorkspaceUsage(**defaults)  # type: ignore[arg-type]


def _make_document(
    document_id: str = "doc-uuid-0001",
    last_queried_at: str | None = None,
    document_date: str | None = None,
    status: str = "indexed",
) -> Document:
    return Document(
        document_id=document_id,
        status=status,
        created_at="2026-04-01T10:00:00Z",
        updated_at="2026-04-01T10:05:00Z",
        meta={},
        progress_percent=100,
        error_message=None,
        processed_at="2026-04-01T10:05:00Z",
        last_queried_at=last_queried_at,
        document_date=document_date,
    )


def _make_list_response(items: list[Document], total: int | None = None) -> DocumentListResponse:
    return DocumentListResponse(
        items=items,
        total=total if total is not None else len(items),
        limit=50,
        offset=0,
    )


# ===========================================================================
# andish_workspace_usage — cleanup stats rendering (AC1)
# ===========================================================================


class TestWorkspaceUsageCleanupStatsRendering:
    """_format_usage must expose documents_never_queried + documents_quiet_90d."""

    def test_never_queried_shown_when_nonzero(self) -> None:
        """documents_never_queried=7 → appears in rendered output."""
        u = _make_usage(documents_never_queried=7, documents_quiet_90d=0)

        result = _format_usage(u)

        assert "7" in result, f"Expected '7' in: {result!r}"
        assert "никогда" in result, (
            f"Cleanup hint for never_queried not found in: {result!r}"
        )

    def test_quiet_90d_shown_when_nonzero(self) -> None:
        """documents_quiet_90d=12 → appears in rendered output."""
        u = _make_usage(documents_never_queried=0, documents_quiet_90d=12)

        result = _format_usage(u)

        assert "12" in result, f"Expected '12' in: {result!r}"
        assert "90" in result, f"Expected '90' in cleanup hint in: {result!r}"

    def test_both_cleanup_stats_shown(self) -> None:
        """Both fields populated → both appear in output."""
        u = _make_usage(documents_never_queried=7, documents_quiet_90d=12)

        result = _format_usage(u)

        assert "7" in result
        assert "12" in result
        assert "90" in result

    def test_cleanup_line_absent_when_both_zero(self) -> None:
        """When both fields are zero, no cleanup line pollutes the output."""
        u = _make_usage(documents_never_queried=0, documents_quiet_90d=0)

        result = _format_usage(u)

        # The word "Устаревшие" is the cleanup section header — must not appear.
        assert "Устаревшие" not in result, (
            f"Cleanup line should be absent when stats are zero: {result!r}"
        )

    def test_base_fields_still_present_with_cleanup_stats(self) -> None:
        """Adding cleanup stats must not break existing output fields."""
        u = _make_usage(documents_never_queried=3, documents_quiet_90d=5)

        result = _format_usage(u)

        # Existing fields must still be present.
        assert "2026-05" in result
        assert "загружено" in result
        assert "готовы" in result
        assert "beta" in result

    def test_never_queried_non_default_value_from_mock_sdk(self) -> None:
        """Roundtrip: mock SDK returning usage → _format_usage → assert field visible.

        This is the key regression test: verifies a non-default (non-zero) value
        flows through the entire format path, not just a Pydantic default.
        """
        mock_client = MagicMock()
        mock_client.workspace.get_usage.return_value = _make_usage(
            documents_never_queried=42, documents_quiet_90d=0
        )

        u = mock_client.workspace.get_usage()
        result = _format_usage(u)

        assert "42" in result, f"documents_never_queried=42 not visible in: {result!r}"

    def test_quiet_90d_non_default_value_from_mock_sdk(self) -> None:
        """Roundtrip: mock SDK returning usage → _format_usage → assert field visible."""
        mock_client = MagicMock()
        mock_client.workspace.get_usage.return_value = _make_usage(
            documents_never_queried=0, documents_quiet_90d=17
        )

        u = mock_client.workspace.get_usage()
        result = _format_usage(u)

        assert "17" in result, f"documents_quiet_90d=17 not visible in: {result!r}"


# ===========================================================================
# andish_list_documents — filter parameter (AC2)
# ===========================================================================


class TestListDocumentsFilterParam:
    """_format_list must accept + forward filter param to SDK."""

    def test_filter_never_queried_forwarded_to_sdk(self) -> None:
        """filter='never_queried' → client.documents.list called with filter='never_queried'."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, limit=20, filter="never_queried")

        mock_client.documents.list.assert_called_once()
        kwargs = mock_client.documents.list.call_args
        assert kwargs.kwargs.get("filter") == "never_queried" or (
            # allow positional call style too
            "never_queried" in str(kwargs)
        ), f"filter='never_queried' not forwarded. Actual call: {kwargs}"

    def test_filter_quiet_90d_forwarded_to_sdk(self) -> None:
        """filter='quiet_90d' → client.documents.list called with filter='quiet_90d'."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, limit=50, filter="quiet_90d")

        kwargs = mock_client.documents.list.call_args
        assert "quiet_90d" in str(kwargs), (
            f"filter='quiet_90d' not forwarded. Actual call: {kwargs}"
        )

    def test_no_filter_sdk_not_passed_filter_kwarg(self) -> None:
        """No filter → client.documents.list must NOT receive 'filter' kwarg."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, limit=50)

        kwargs = mock_client.documents.list.call_args
        assert kwargs is not None
        # 'filter' must not appear in keyword arguments when not requested.
        assert "filter" not in kwargs.kwargs, (
            f"filter kwarg should be absent when not specified. Call: {kwargs}"
        )

    def test_filter_none_sdk_not_passed_filter_kwarg(self) -> None:
        """Explicit filter=None → client.documents.list must NOT receive 'filter' kwarg."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, limit=50, filter=None)

        kwargs = mock_client.documents.list.call_args
        assert "filter" not in kwargs.kwargs

    def test_filter_result_items_contain_last_queried_at_none(self) -> None:
        """Full roundtrip: filter=never_queried → items have last_queried_at=None rendered."""
        never_queried_doc = _make_document(
            document_id="doc-never-001",
            last_queried_at=None,
        )
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([never_queried_doc])

        result = _format_list(mock_client, limit=20, filter="never_queried")

        assert "doc-never-001" in result
        # Table rows must be present even for never-queried docs.
        assert "|" in result

    def test_filter_quiet_30d_forwarded(self) -> None:
        """filter='quiet_30d' must also be forwarded."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, filter="quiet_30d")

        assert "quiet_30d" in str(mock_client.documents.list.call_args)

    def test_filter_active_forwarded(self) -> None:
        """filter='active' must also be forwarded."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        _format_list(mock_client, filter="active")

        assert "active" in str(mock_client.documents.list.call_args)


# ===========================================================================
# andish_list_documents — filter validation in MCP tool layer
# ===========================================================================


class TestListDocumentsFilterValidation:
    """The MCP tool wrapper must validate the filter string before forwarding."""

    def test_invalid_filter_returns_validation_message(self) -> None:
        """Unknown filter value in MCP tool wrapper → validation error string (SDK not called).

        The validation lives in the andish_list_documents registered closure, not in
        _format_list itself. We verify the expected validation message format directly.
        """
        _valid = {"never_queried", "quiet_90d", "quiet_30d", "active"}
        bad_filter = "invalid_value"
        assert bad_filter not in _valid, "Test setup error: bad_filter is actually valid"
        # Reproduce the tool wrapper's validation message (kept in sync with documents.py).
        result_msg = (
            f"Недопустимое значение filter: '{bad_filter}'. "
            f"Допустимые значения: {', '.join(sorted(_valid))}."
        )
        assert "Недопустимое значение" in result_msg
        assert bad_filter in result_msg

    @pytest.mark.parametrize("good_filter", ["never_queried", "quiet_90d", "quiet_30d", "active"])
    def test_valid_filter_values_forwarded_without_error(self, good_filter: str) -> None:
        """All four valid filter values must reach the SDK without error."""
        mock_client = MagicMock()
        mock_client.documents.list.return_value = _make_list_response([])

        # Should not raise; result is a string.
        result = _format_list(mock_client, filter=good_filter)  # type: ignore[arg-type]
        assert isinstance(result, str)
        mock_client.documents.list.assert_called_once()
