"""Shared fixtures for andish-mcp tests."""

from __future__ import annotations

import importlib
import importlib.util  # Risk 1 mitigation: explicit import per TL peer-review
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

# Make andish_mcp and andish importable when tests are run from the project root
# without installing either package (editable install not required for test run).
_ROOT = Path(__file__).parent.parent.parent.parent  # project root
_MCP_SRC = Path(__file__).parent.parent / "src"
_SDK_SRC = _ROOT / "sdk"

for _path in (_MCP_SRC, _SDK_SRC):
    _path_str = str(_path)
    if _path_str not in sys.path:
        sys.path.insert(0, _path_str)

# Mark all tests in this package to skip if mcp is not installed.
# This allows the test suite to run in CI before mcp is in the lockfile.
mcp_installed = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(
    not mcp_installed,
    reason="mcp package not installed — run: pip install 'mcp>=1.6,<3'",
)


@pytest.fixture(autouse=True)
def _suppress_whoami_ping_in_unit_tests(request: pytest.FixtureRequest) -> None:  # type: ignore[return]
    """Autouse fixture: no-op whoami ping for unit tests.

    SP2-07 adds a real HTTP call (client.whoami()) inside build_server().
    Unit tests that call build_server() with a MagicMock client already get
    whoami() mocked for free (MagicMock returns MagicMock).  However, tests
    that call build_server() WITHOUT patching _get_client would try to make
    a real HTTP request.

    This fixture patches ``andish_mcp.server._whoami_ping`` to a no-op for
    ALL tests in this directory EXCEPT those in tests/integration/ (which
    manage whoami mocking explicitly via their own mock_client fixture data).

    NB: pytest DOES inherit autouse fixtures from parent conftest.py
    into subdirectory tests by default. The exclusion of integration/ +
    test_startup_whoami.py is enforced explicitly below via the fspath
    check, NOT by conftest scoping. Don't move the no-op logic into
    integration/conftest.py expecting parent isolation — it won't work.
    """
    # Do not suppress for:
    #   - integration tests (they manage whoami via mock_client.whoami.return_value)
    #   - test_startup_whoami.py (it specifically tests _whoami_ping behaviour)
    fspath_str = str(request.fspath)
    if "integration" in fspath_str or "test_startup_whoami" in fspath_str:
        yield
        return

    # For all other unit tests: patch _whoami_ping to a no-op.
    # This prevents real HTTP calls when build_server() is called without
    # patching _get_client (e.g. test_andish_query_tool_registered_in_server).
    # We import lazily to avoid AttributeError when andish_mcp.server is not
    # yet imported in the test process (e.g. test_config.py runs first).
    try:
        import andish_mcp.server  # noqa: F401, PLC0415 — ensure module is imported before patch
        with patch("andish_mcp.server._whoami_ping"):
            yield
    except (ModuleNotFoundError, ImportError):
        # mcp/andish not installed — tests will be skipped anyway via requires_mcp.
        yield
