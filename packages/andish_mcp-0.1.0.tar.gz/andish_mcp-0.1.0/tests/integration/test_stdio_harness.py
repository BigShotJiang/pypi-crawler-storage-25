"""Integration tests for andish-mcp stdio harness — SP2-06.

Tests verify MCP protocol-level behaviour of the built server:
  AC1 — 8 tools listed via tools/list
  AC2 — initialize returns server capabilities
  AC3 — tools/list returns correct tool names and schemas
  AC4 — tools/call for each of the 8 tools returns text content (mocked backend)
  AC5 — pytest passes on CI

Architecture
------------
Two test layers:

1. **In-process MCP protocol tests** (``TestInProcessMCPProtocol``):
   Uses ``mcp.shared.memory.create_client_server_memory_streams`` so the full
   MCP JSON-RPC handshake runs in the same process without subprocess spawn.
   The andish SDK HTTP layer is replaced by a ``MagicMock`` — real MCP protocol,
   mocked backend.  This is the primary layer; avoids Risk 2 (subprocess async
   complexity in pytest).

2. **Subprocess smoke test** (``test_subprocess_server_lists_eight_tools``):
   Spawns the MCP server as a real OS subprocess via ``sys.executable -c``.
   Communicates via raw JSON-RPC over stdin/stdout.  Needs a stdlib HTTP stub
   for the whoami startup ping.  Marked ``@pytest.mark.slow`` — can be skipped
   in fast CI with ``-m "not slow"``.

Risk mitigations (TL peer-review 2026-05-05)
--------------------------------------------
Risk 1: ``import importlib.util`` is explicit in this file and integration/conftest.py.
Risk 2: In-process layer is primary; subprocess layer is smoke only and marked slow.
Risk 2 (respx URL pattern): SDK uses inline query string (``/documents?limit=50&offset=0``),
        not httpx ``params=`` kwarg.  These tests use MagicMock instead of respx to
        avoid any URL-matching fragility — the unit tests in test_documents_tool.py
        already cover the SDK path; here we test MCP protocol framing.
"""

from __future__ import annotations

import importlib.util  # Risk 1 — explicit import
import sys
from decimal import Decimal
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Availability guard
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(
    not _mcp_available,
    reason="mcp package not installed — run: pip install 'mcp>=1.6,<3'",
)

# ---------------------------------------------------------------------------
# Path constants (used by subprocess smoke test)
# ---------------------------------------------------------------------------

_THIS_FILE = Path(__file__)
_MCP_SRC_PATH = _THIS_FILE.parent.parent.parent / "src"         # packages/andish-mcp/src
_SDK_SRC_PATH = _THIS_FILE.parent.parent.parent.parent.parent / "sdk"  # project root/sdk

# ---------------------------------------------------------------------------
# Expected tool names (6 P0 tools + andish_health AI-T4 + andish_upload_document W2 D5)
# ---------------------------------------------------------------------------

_EXPECTED_TOOL_NAMES = frozenset(
    {
        "andish_query",
        "andish_list_documents",
        "andish_get_document",
        "andish_workspace_usage",
        "andish_search_entities",
        "andish_get_neighbors",
        "andish_health",
        "andish_upload_document",
    }
)

_EXPECTED_TOOL_COUNT = 8  # 6 P0 tools + andish_health (AI-T4) + andish_upload_document (W2 D5)


# ---------------------------------------------------------------------------
# Helper: build a test FastMCP server with fully mocked SDK client
# ---------------------------------------------------------------------------


def _build_test_server() -> Any:
    """Return a FastMCP server with a MagicMock SDK client.

    Whoami ping is mocked to return a valid identity, so build_server()
    does not fail on startup.  Each tool namespace returns sensible fixture
    data so tools/call responses can be asserted on content shape.
    """
    from andish.types import (
        Document,
        DocumentListResponse,
        EntityRef,
        EntitySearchResponse,
        NeighborResponse,
        QueryResponse,
        SourceRef,
        WorkspaceUsage,
    )

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()

    # Startup ping — must succeed so build_server() completes
    mock_client.whoami.return_value = {
        "tenant_id": "test-tenant-uuid",
        "tenant_name": "Integration Test Corp",
        "scopes": ["read", "write"],
        "api_key_prefix": "adsh_test_",
    }

    # andish_query
    mock_client.query.ask.return_value = QueryResponse(
        answer="Test answer from graph.",
        sources=[SourceRef(document_id="doc-1"), SourceRef(document_id="doc-2")],
        cost_rub=Decimal("0.05"),
        mode="mix",
    )

    # andish_workspace_usage
    mock_client.workspace.get_usage.return_value = WorkspaceUsage(
        period="2026-05",
        cost_current_rub=Decimal("12.34"),
        cost_cap_rub=Decimal("500.00"),
        cost_cap_rub_daily=Decimal("50.00"),
        percent_used=2.468,
        documents_current=10,
        documents_cap=None,
        queries_today=5,
        queries_cap_daily=None,
        tier="beta",
        next_reset_at="2026-06-01T00:00:00Z",
    )

    # andish_search_entities
    mock_client.entities.search.return_value = EntitySearchResponse(
        entities=[
            EntityRef(id="e-1", label="FastAPI", type="Technology", weight=1.0),
        ],
        query="FastAPI",
        total=1,
    )

    # andish_get_neighbors
    mock_client.entities.get_neighbors.return_value = NeighborResponse(
        entity=EntityRef(id="e-1", label="FastAPI", type="Technology", weight=1.0),
        neighbors=[
            EntityRef(id="e-2", label="Python", type="Technology", weight=0.9),
        ],
        edges=[],
        hop=1,
    )

    # andish_list_documents
    doc = Document(
        document_id="doc-uuid-0001",
        status="indexed",
        created_at="2026-05-01T10:00:00Z",
        updated_at="2026-05-01T10:05:00Z",
        meta={"title": "API Spec"},
        progress_percent=100,
        error_message=None,
        processed_at="2026-05-01T10:05:00Z",
    )
    # andish_get_document — uses a separate fixture with content field
    # (list responses return None content per ADR-036 §2.6 bandwidth policy)
    doc_with_content = Document(
        document_id="doc-uuid-0001",
        status="indexed",
        created_at="2026-05-01T10:00:00Z",
        updated_at="2026-05-01T10:05:00Z",
        meta={"title": "API Spec"},
        progress_percent=100,
        error_message=None,
        processed_at="2026-05-01T10:05:00Z",
        content="This is the integration test document content for API Spec.",
    )
    mock_client.documents.list.return_value = DocumentListResponse(
        items=[doc], total=1, limit=50, offset=0
    )

    # andish_get_document
    mock_client.documents.get.return_value = doc_with_content

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_integration", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    return mcp_server


# ---------------------------------------------------------------------------
# Async session runner (anyio-based; works with pytest-asyncio backend too)
# ---------------------------------------------------------------------------


async def _run_mcp_session(
    mcp_server: Any,
    operation: Any,  # Callable[[ClientSession], Awaitable[T]]
) -> Any:
    """Utility: run a single MCP session operation against the test server.

    Uses in-memory streams so no subprocess or network is required.
    The server task is cancelled after the operation completes.
    """
    import anyio
    from mcp.client.session import ClientSession
    from mcp.shared.memory import create_client_server_memory_streams
    from mcp.types import Implementation

    result_holder: list[Any] = []

    async with create_client_server_memory_streams() as (
        (client_read, client_write),
        (server_read, server_write),
    ), anyio.create_task_group() as tg:
        tg.start_soon(
            mcp_server._mcp_server.run,  # type: ignore[attr-defined]
            server_read,
            server_write,
            mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
        )

        async with ClientSession(
            client_read,
            client_write,
            client_info=Implementation(name="test-client", version="0.0.1"),
        ) as session:
            await session.initialize()
            result_holder.append(await operation(session))
            tg.cancel_scope.cancel()

    return result_holder[0]


# ===========================================================================
# In-process MCP protocol tests
# ===========================================================================


@requires_mcp
class TestInProcessMCPProtocol:
    """AC1-AC4: Full MCP protocol via in-memory transport (no subprocess)."""

    def test_initialize_returns_server_info(self) -> None:
        """AC2: MCP initialize handshake returns server capabilities."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation

        mcp_server = _build_test_server()

        async def _run() -> dict[str, object]:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[Any] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        init_result = await session.initialize()
                        result_holder.append({
                            "server_name": init_result.serverInfo.name,
                            "has_capabilities": init_result.capabilities is not None,
                        })
                        tg.cancel_scope.cancel()

            return result_holder[0]

        info = anyio.run(_run)
        assert info["server_name"] == "andish-mcp"
        assert info["has_capabilities"] is True

    def test_tools_list_returns_eight_tools(self) -> None:
        """AC1 + AC3: tools/list returns exactly 8 tools with correct names."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation

        mcp_server = _build_test_server()

        async def _run() -> list[str]:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[list[str]] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        tools_result = await session.list_tools()
                        result_holder.append([t.name for t in tools_result.tools])
                        tg.cancel_scope.cancel()

            return result_holder[0]

        tool_names = anyio.run(_run)
        assert len(tool_names) == _EXPECTED_TOOL_COUNT, (
            f"Expected {_EXPECTED_TOOL_COUNT} tools, got {len(tool_names)}: {tool_names}"
        )
        assert set(tool_names) == _EXPECTED_TOOL_NAMES

    def test_tools_list_all_have_descriptions(self) -> None:
        """AC3: every tool must have a non-empty description."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation

        mcp_server = _build_test_server()

        async def _run() -> list[tuple[str, str]]:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[list[tuple[str, str]]] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        tools_result = await session.list_tools()
                        result_holder.append([
                            (t.name, t.description or "") for t in tools_result.tools
                        ])
                        tg.cancel_scope.cancel()

            return result_holder[0]

        pairs = anyio.run(_run)
        for name, desc in pairs:
            assert desc, f"Tool '{name}' has an empty description"

    def test_call_andish_query_returns_text_content(self) -> None:
        """AC4: tools/call andish_query returns answer + Sources section."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool(
                            "andish_query",
                            {"question": "What is our refund policy?", "mode": "mix"},
                        )
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert "Test answer from graph." in text
        assert "Sources:" in text
        assert "doc-1" in text

    def test_call_andish_list_documents_returns_markdown_table(self) -> None:
        """AC4: andish_list_documents returns markdown table with document row."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool(
                            "andish_list_documents", {"limit": 50}
                        )
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert "| id | name | status | uploaded_at |" in text
        assert "doc-uuid-0001" in text
        assert "API Spec" in text

    def test_call_andish_get_document_returns_metadata_block(self) -> None:
        """AC4: andish_get_document returns document metadata markdown."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool(
                            "andish_get_document", {"document_id": "doc-uuid-0001"}
                        )
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert "doc-uuid-0001" in text
        assert "indexed" in text

    def test_call_andish_workspace_usage_returns_russian_summary(self) -> None:
        """AC4: andish_workspace_usage returns Russian-language summary with cost."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool("andish_workspace_usage", {})
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert any(word in text for word in ("документ", "запрос", "стоимость", "12.34"))

    def test_call_andish_search_entities_returns_entity_list(self) -> None:
        """AC4: andish_search_entities returns found entity with ID and label."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool(
                            "andish_search_entities",
                            {"query": "FastAPI", "limit": 10},
                        )
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert "FastAPI" in text
        assert "e-1" in text

    def test_call_andish_get_neighbors_returns_neighbor_list(self) -> None:
        """AC4: andish_get_neighbors returns entity and its neighbors."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation, TextContent

        mcp_server = _build_test_server()

        async def _run() -> str:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[str] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool(
                            "andish_get_neighbors",
                            {"entity_id": "e-1", "hop": 1, "limit": 50},
                        )
                        text = "".join(
                            b.text for b in call_result.content if isinstance(b, TextContent)
                        )
                        result_holder.append(text)
                        tg.cancel_scope.cancel()

            return result_holder[0]

        text = anyio.run(_run)
        assert "Python" in text or "FastAPI" in text

    def test_unknown_tool_returns_error_flag(self) -> None:
        """Regression: calling a non-existent tool must return isError=True, not crash."""
        import anyio
        from mcp.client.session import ClientSession
        from mcp.shared.memory import create_client_server_memory_streams
        from mcp.types import Implementation

        mcp_server = _build_test_server()

        async def _run() -> bool:
            async with create_client_server_memory_streams() as (
                (cr, cw),
                (sr, sw),
            ):
                import anyio as _anyio
                result_holder: list[bool] = []

                async with _anyio.create_task_group() as tg:
                    tg.start_soon(
                        mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                        sr,
                        sw,
                        mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
                    )

                    async with ClientSession(
                        cr,
                        cw,
                        client_info=Implementation(name="test-client", version="0.0.1"),
                    ) as session:
                        await session.initialize()
                        call_result = await session.call_tool("nonexistent_tool", {})
                        result_holder.append(bool(call_result.isError))
                        tg.cancel_scope.cancel()

            return result_holder[0]

        is_error = anyio.run(_run)
        assert is_error, "Non-existent tool call must set isError=True"


# ===========================================================================
# Subprocess smoke test — raw JSON-RPC over stdio
# ===========================================================================


@requires_mcp
@pytest.mark.slow
def test_subprocess_server_lists_eight_tools() -> None:
    """Subprocess spawn: real stdio transport, 8 tools confirmed via raw JSON-RPC.

    Starts a stdlib HTTP stub in a background thread to serve the whoami
    startup ping (SP2-07).  Then spawns ``sys.executable -c <server_script>``
    and communicates via JSON-RPC newline-delimited messages on stdin/stdout.

    This is the real end-to-end smoke test for the stdio transport path.
    """
    import json
    import os
    import subprocess
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    # Stub HTTP server for whoami ping
    _whoami_body = {
        "tenant_id": "test-tenant-uuid",
        "tenant_name": "Subprocess Test Tenant",
        "scopes": ["read", "write"],
        "api_key_prefix": "adsh_test_",
    }

    class _StubHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/v1/whoami":
                body = json.dumps(_whoami_body).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args: object) -> None:
            pass  # silence test output

    stub_httpd = HTTPServer(("127.0.0.1", 0), _StubHandler)
    stub_port = stub_httpd.server_address[1]
    stub_thread = threading.Thread(target=stub_httpd.serve_forever, daemon=True)
    stub_thread.start()

    server_script = (
        f"import sys; "
        f"sys.path.insert(0, {str(_MCP_SRC_PATH)!r}); "
        f"sys.path.insert(0, {str(_SDK_SRC_PATH)!r}); "
        f"from andish_mcp.server import run; run()"
    )

    full_env = {
        **os.environ,
        "ANDISH_API_KEY": "adsh_test_subprocess_smoke",
        "ANDISH_BASE_URL": f"http://127.0.0.1:{stub_port}/v1",
    }

    proc = subprocess.Popen(  # noqa: S603 — trusted input: sys.executable + our own script
        [sys.executable, "-c", server_script],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=full_env,
    )

    def _send(msg: dict[str, object]) -> None:
        assert proc.stdin is not None
        proc.stdin.write((json.dumps(msg) + "\n").encode())
        proc.stdin.flush()

    def _recv() -> dict[str, object]:
        assert proc.stdout is not None
        line = proc.stdout.readline()
        if not line:
            stderr_out = proc.stderr.read().decode() if proc.stderr else ""
            raise RuntimeError(
                f"Subprocess stdout closed unexpectedly.\nstderr:\n{stderr_out}"
            )
        return json.loads(line.decode())  # type: ignore[no-any-return]

    try:
        # initialize handshake
        _send(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {"name": "pytest-smoke", "version": "0.0.1"},
                },
            }
        )
        init_resp = _recv()
        assert "result" in init_resp, f"initialize failed: {init_resp}"
        assert init_resp["result"]["serverInfo"]["name"] == "andish-mcp"

        # initialized notification (no response expected)
        _send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})

        # tools/list
        _send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        tools_resp = _recv()
        assert "result" in tools_resp, f"tools/list failed: {tools_resp}"
        tools = tools_resp["result"]["tools"]
        tool_names = {t["name"] for t in tools}

        assert len(tool_names) == _EXPECTED_TOOL_COUNT, (
            f"Expected {_EXPECTED_TOOL_COUNT} tools, got {len(tool_names)}: {tool_names}"
        )
        assert tool_names == _EXPECTED_TOOL_NAMES

    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        stub_httpd.shutdown()
