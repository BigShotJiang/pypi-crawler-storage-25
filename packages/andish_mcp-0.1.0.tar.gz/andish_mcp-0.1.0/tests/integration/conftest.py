"""Fixtures for andish-mcp integration tests.

Integration tests spawn the MCP server as a real subprocess via stdio transport
and communicate through the mcp.client.stdio_client async context manager.

The backend HTTP layer is intercepted by respx so tests run without a live
Andish API.  Real subprocess spawn is used — these are NOT mock-only tests.
"""

from __future__ import annotations

import importlib.util  # Risk 1 mitigation: explicit import required by TL peer-review
import sys
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Path setup — mirrors packages/andish-mcp/tests/conftest.py
# ---------------------------------------------------------------------------

_ROOT = Path(__file__).parent.parent.parent.parent.parent  # project root
_MCP_SRC = Path(__file__).parent.parent.parent / "src"
_SDK_SRC = _ROOT / "sdk"

for _path in (_MCP_SRC, _SDK_SRC):
    _path_str = str(_path)
    if _path_str not in sys.path:
        sys.path.insert(0, _path_str)

# ---------------------------------------------------------------------------
# mcp availability guard
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None  # explicit import — Risk 1
requires_mcp = pytest.mark.skipif(
    not _mcp_available,
    reason="mcp package not installed — run: pip install 'mcp>=1.6,<3'",
)
