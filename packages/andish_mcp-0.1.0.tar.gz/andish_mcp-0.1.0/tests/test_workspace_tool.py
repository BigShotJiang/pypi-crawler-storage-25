"""Unit tests for andish_workspace_usage MCP tool — SP1-04.

Tests that do NOT require mcp test the output formatting logic independently.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from andish.errors import AuthError
from andish.types import WorkspaceUsage
from andish_mcp.errors import to_user_message
from andish_mcp.tools.workspace import _format_usage  # canonical implementation


# ---------------------------------------------------------------------------
# Output formatting (no mcp required — test pure Python logic)
# ---------------------------------------------------------------------------


def _make_usage(**kwargs: object) -> WorkspaceUsage:
    defaults: dict[str, object] = {
        "period": "2026-04",
        "cost_current_rub": Decimal("23.40"),
        "cost_cap_rub_daily": Decimal("100.00"),
        "percent_used": 23.4,
        "documents_uploaded": 5,
        "documents_processed": 5,
        "documents_current": 5,
        "queries_today": 12,
        "tier": "beta",
        "next_reset_at": "2026-04-29T00:00:00Z",
        # Feature 03-bis defaults (zero = clean workspace)
        "documents_never_queried": 0,
        "documents_quiet_90d": 0,
    }
    defaults.update(kwargs)
    return WorkspaceUsage(**defaults)  # type: ignore[arg-type]


def test_workspace_usage_format_basic() -> None:
    u = _make_usage()
    result = _format_usage(u)

    assert "2026-04" in result
    assert "5 загружено" in result  # documents_uploaded
    assert "5 готовы" in result  # documents_processed
    assert "23.40" in result  # cost_current_rub (Decimal serialisation)
    assert "12" in result  # queries_today
    assert "beta" in result


def test_workspace_usage_format_with_caps() -> None:
    """documents_cap no longer shown inline (two-counter format replaces it).
    queries_cap_daily and cost_cap_rub still appear.
    """
    u = _make_usage(
        documents_cap=250,
        queries_cap_daily=1000,
        cost_cap_rub=Decimal("3000.00"),
    )
    result = _format_usage(u)

    # queries cap still shown
    assert "из 1000" in result
    # cost cap still shown
    assert "3000" in result
    # documents_cap is no longer rendered inline — two-counter line replaced it
    assert "из 250" not in result


def test_workspace_usage_format_no_caps() -> None:
    """When caps are None, no 'из' suffix and no monthly cap line."""
    u = _make_usage(documents_cap=None, queries_cap_daily=None, cost_cap_rub=None)
    result = _format_usage(u)

    # 'из' must not appear (no cap shown).
    assert "из" not in result


def test_workspace_usage_decimal_cost_in_output() -> None:
    """Cost value must appear as Decimal (not float — avoids 23.399999... artifacts)."""
    u = _make_usage(cost_current_rub=Decimal("23.40"))
    result = _format_usage(u)

    # Decimal("23.40") serialises to "23.40", not "23.4" or "23.400000000001".
    assert "23.40" in result


def test_auth_error_returned_as_string() -> None:
    """Tool must return a string (not raise) when API errors occur."""
    exc = AuthError("Invalid key", status_code=401)
    result = to_user_message(exc)

    assert isinstance(result, str)
    assert "невалиден" in result or "истёк" in result


# ---------------------------------------------------------------------------
# Variant (a) render tests: two-counter document line (CEO ack 2026-05-14)
# ---------------------------------------------------------------------------


def test_docs_render_all_processed() -> None:
    """Case 1: all 5 uploaded + 5 processed — compact, no parens."""
    u = _make_usage(documents_uploaded=5, documents_processed=5, documents_current=5)
    result = _format_usage(u)

    assert "5 загружено · 5 готовы" in result
    # No '(... индексируются)' suffix when processing == 0.
    assert "индексируются" not in result


def test_docs_render_some_processing() -> None:
    """Case 2: 5 uploaded, 3 processed → 2 still indexing."""
    u = _make_usage(documents_uploaded=5, documents_processed=3, documents_current=3)
    result = _format_usage(u)

    assert "5 загружено · 3 готовы (2 индексируются)" in result


def test_docs_render_zero() -> None:
    """Case 3: fresh workspace — zero uploaded, zero processed."""
    u = _make_usage(documents_uploaded=0, documents_processed=0, documents_current=0)
    result = _format_usage(u)

    assert "0 загружено · 0 готовы" in result
    assert "индексируются" not in result


def test_docs_render_no_legacy_field_shown() -> None:
    """The render must NOT output the old single-counter pattern 'Документы: N'."""
    u = _make_usage(documents_uploaded=3, documents_processed=3, documents_current=3)
    result = _format_usage(u)

    # Old pattern was "Документы: 3" (number alone); new pattern has '·' separator.
    assert "загружено" in result
    assert "готовы" in result


# ---------------------------------------------------------------------------
# Tool registration (requires mcp)
# ---------------------------------------------------------------------------

try:
    import mcp  # noqa: F401

    _mcp_available = True
except ImportError:
    _mcp_available = False

requires_mcp = pytest.mark.skipif(not _mcp_available, reason="mcp not installed")


@requires_mcp
def test_andish_workspace_usage_tool_registered_in_server() -> None:
    """After build_server(), the server must expose 'andish_workspace_usage' tool."""
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    cfg = MCPConfig(api_key="adsh_test_unittest", base_url="http://localhost:8000/v1")
    mcp_server = build_server(cfg)

    tool_names = [t.name for t in mcp_server._tool_manager.list_tools()]  # type: ignore[attr-defined]
    assert "andish_workspace_usage" in tool_names
