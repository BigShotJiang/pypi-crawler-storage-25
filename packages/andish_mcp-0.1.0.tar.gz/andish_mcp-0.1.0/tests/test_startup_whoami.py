"""Unit tests for SP2-07: startup whoami ping in build_server().

AC coverage:
  - test_startup_whoami_success:
      Server boots when client.whoami() returns a valid identity dict.

  - test_startup_whoami_invalid_key_raises:
      AuthError (401) → SystemExit(1) with user-friendly stderr message.
      Server must NOT start silently with a broken key.

  - test_startup_whoami_network_error_raises:
      Generic AndishError (network error, 5xx) → server starts anyway
      (warning logged, no SystemExit).  Backend may be temporarily down.

These tests verify the fail-fast behaviour added in SP2-07 without requiring
a live API.  All HTTP calls are intercepted via MagicMock on the SDK client.
"""

from __future__ import annotations

import importlib

import pytest

from andish.errors import AndishError, AuthError, ServerError

# ---------------------------------------------------------------------------
# mcp availability guard (mirrors conftest.py)
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(
    not _mcp_available,
    reason="mcp package not installed — run: pip install 'mcp>=1.6,<3'",
)


# ===========================================================================
# SP2-07 tests
# ===========================================================================


@requires_mcp
def test_startup_whoami_success() -> None:
    """Server builds successfully when whoami returns valid identity.

    Verifies that all 6 tools are registered after a successful startup ping.
    """
    from unittest.mock import MagicMock, patch

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.whoami.return_value = {
        "tenant_id": "test-tenant-uuid",
        "tenant_name": "Test Corp",
        "scopes": ["read", "write"],
        "api_key_prefix": "adsh_test_",
    }

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_whoami_ok", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    # whoami must have been called exactly once during build_server()
    mock_client.whoami.assert_called_once()

    # All 8 tools must be registered (6 P0 + andish_health AI-T4 + andish_upload_document W2 D5)
    tool_names = {t.name for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    expected = {
        "andish_query",
        "andish_list_documents",
        "andish_get_document",
        "andish_workspace_usage",
        "andish_search_entities",
        "andish_get_neighbors",
        "andish_health",
        "andish_upload_document",
    }
    assert tool_names == expected


@requires_mcp
def test_startup_whoami_invalid_key_raises(capsys: pytest.CaptureFixture[str]) -> None:
    """AuthError from whoami → SystemExit(1) with user-friendly message on stderr.

    Regression gate: a server with an invalid API key must NOT start silently.
    Claude Desktop surfaces SystemExit(1) as "MCP server failed to start".
    """
    from unittest.mock import MagicMock, patch

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.whoami.side_effect = AuthError("Invalid API key", status_code=401)

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_bad_key", base_url="http://localhost:8000/v1")
        with pytest.raises(SystemExit) as exc_info:
            build_server(cfg)

    # Must exit with code 1, not 0
    assert exc_info.value.code == 1

    # User-friendly message must appear on stderr
    captured = capsys.readouterr()
    assert "invalid" in captured.err.lower() or "API key" in captured.err
    assert "dashboard" in captured.err.lower() or "andish.ru" in captured.err

    # Must NOT surface raw HTTP status code to the user
    assert "401" not in captured.err


@requires_mcp
def test_startup_whoami_network_error_continues() -> None:
    """Generic AndishError from whoami → server continues, no SystemExit.

    When the backend is temporarily unavailable, the MCP server must still
    start so that Claude Desktop can connect.  Individual tool calls will
    handle errors via to_user_message() per-request.
    """
    from unittest.mock import MagicMock, patch

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.whoami.side_effect = ServerError(
        "Service unavailable", status_code=503
    )

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_net_err", base_url="http://localhost:8000/v1")
        # Must NOT raise — server starts despite backend being down
        mcp_server = build_server(cfg)

    # All 8 tools must still be registered (6 P0 + andish_health AI-T4 + andish_upload_document W2 D5)
    tool_names = {t.name for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert len(tool_names) == 8


@requires_mcp
def test_startup_whoami_connection_error_continues() -> None:
    """Connection-level AndishError from whoami → server continues.

    Handles the case where the backend URL is unreachable at startup
    (e.g. airgapped environment, backend not yet deployed in staging).
    """
    from unittest.mock import MagicMock, patch

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    # Simulate network-level failure (ConnectError → wrapped as AndishError)
    mock_client.whoami.side_effect = AndishError("Connection refused")

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(
            api_key="adsh_test_no_network", base_url="http://unreachable.local/v1"
        )
        mcp_server = build_server(cfg)

    tool_names = {t.name for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert len(tool_names) == 8  # 6 P0 tools + andish_health (AI-T4) + andish_upload_document (W2 D5)


@requires_mcp
def test_startup_whoami_called_before_tools_registered(capsys: pytest.CaptureFixture[str]) -> None:
    """Whoami ping is called before tool registration — AuthError skips all tools.

    If the ping fails, we must not register any tools (SystemExit(1) is raised
    before register calls).  This prevents a half-initialized server from
    running with an invalid key.
    """
    from unittest.mock import MagicMock, patch

    import andish_mcp.server as server_module
    from andish_mcp.config import MCPConfig
    from andish_mcp.server import build_server

    server_module._client = None  # type: ignore[attr-defined]

    call_order: list[str] = []

    mock_client = MagicMock()

    def _tracking_whoami() -> dict[str, object]:
        call_order.append("whoami")
        raise AuthError("Expired key", status_code=401)

    mock_client.whoami.side_effect = _tracking_whoami

    with (
        patch.object(server_module, "_get_client", return_value=mock_client),
        patch(
            "andish_mcp.server.register_query",
            side_effect=lambda *a: call_order.append("query"),
        ),
        patch(
            "andish_mcp.server.register_workspace",
            side_effect=lambda *a: call_order.append("workspace"),
        ),
        patch(
            "andish_mcp.server.register_entities",
            side_effect=lambda *a: call_order.append("entities"),
        ),
        patch(
            "andish_mcp.server.register_documents",
            side_effect=lambda *a: call_order.append("documents"),
        ),
    ):
        cfg = MCPConfig(api_key="adsh_test_order", base_url="http://localhost:8000/v1")
        with pytest.raises(SystemExit):
            build_server(cfg)

    # whoami called first, no tool registers should have happened
    assert call_order == ["whoami"], (
        f"Expected only whoami before SystemExit, got: {call_order}"
    )
