"""Unit + integration tests for andish_health MCP tool — AI-T4.

Test coverage:
  Unit tests (no mcp package required):
    - test_health_ok_happy_path: status=ok when whoami succeeds
    - test_health_api_unreachable_returns_down: status=down when AndishError
    - test_health_auth_invalid_returns_degraded: status=degraded when AuthError
    - test_health_version_exposed: version field matches _version.__version__
    - test_health_checked_at_format_utc: checked_at is ISO-like UTC string
    - test_health_uptime_seconds_is_int: uptime_seconds is a non-negative int
    - test_health_down_has_false_fields: api_reachable=False → auth_valid=False
    - test_health_degraded_best_effort_fields: auth invalid → llm_provider=unknown

  Registration test (requires mcp):
    - test_andish_health_registered_in_server: tool appears in build_server() output

  In-process integration test (ADR-032 primary strategy):
    - test_health_tool_via_in_process_mcp: full MCP protocol call returns JSON
      with status=ok through in-memory transport (no subprocess, no HTTP).
"""

from __future__ import annotations

import importlib
import importlib.util
import time
from typing import Any
from unittest.mock import MagicMock

import pytest

from andish.errors import AndishError, AuthError, ServerError

# ---------------------------------------------------------------------------
# mcp availability guard — mirrors conftest.py pattern
# ---------------------------------------------------------------------------

_mcp_available = importlib.util.find_spec("mcp") is not None
requires_mcp = pytest.mark.skipif(
    not _mcp_available,
    reason="mcp package not installed — run: pip install 'mcp>=1.6,<3'",
)


# ===========================================================================
# Unit tests — business logic via _build_health_payload (no mcp required)
# ===========================================================================


class TestHealthPayloadOk:
    """Status=ok path: whoami succeeds."""

    def test_health_ok_happy_path(self) -> None:
        """status='ok' when whoami() returns valid identity."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {
            "tenant_id": "t-uuid",
            "tenant_name": "Test Corp",
            "scopes": ["read", "write"],
            "api_key_prefix": "adsh_test_",
        }

        payload = _build_health_payload(mock_client)

        assert payload["status"] == "ok"
        assert payload["api_reachable"] is True
        assert payload["auth_valid"] is True
        assert payload["db_connectivity"] == "ok"

    def test_health_version_exposed(self) -> None:
        """version field must match _version.__version__."""
        from andish_mcp._version import __version__  # noqa: PLC0415
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

        payload = _build_health_payload(mock_client)

        assert payload["version"] == __version__

    def test_health_checked_at_format_utc(self) -> None:
        """checked_at must be a UTC timestamp string ending with ' UTC'."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

        payload = _build_health_payload(mock_client)

        assert isinstance(payload["checked_at"], str)
        assert payload["checked_at"].endswith(" UTC")
        # Format: YYYY-MM-DD HH:MM:SS UTC
        parts = payload["checked_at"].replace(" UTC", "").split(" ")
        assert len(parts) == 2, (
            f"Expected 'YYYY-MM-DD HH:MM:SS UTC', got: {payload['checked_at']!r}"
        )
        date_part, time_part = parts
        assert len(date_part) == 10 and date_part[4] == "-" and date_part[7] == "-"
        assert len(time_part) == 8 and time_part[2] == ":" and time_part[5] == ":"

    def test_health_uptime_seconds_is_int(self) -> None:
        """uptime_seconds must be a non-negative integer."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

        # Pass a start_time 5 seconds ago.
        fake_start = time.monotonic() - 5.0
        payload = _build_health_payload(mock_client, start_time=fake_start)

        assert isinstance(payload["uptime_seconds"], int)
        assert payload["uptime_seconds"] >= 5


class TestHealthPayloadDown:
    """Status=down path: API unreachable (AndishError, network-level)."""

    def test_health_api_unreachable_returns_down(self) -> None:
        """status='down' when whoami() raises AndishError (network failure)."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = AndishError("Connection refused")

        payload = _build_health_payload(mock_client)

        assert payload["status"] == "down"
        assert payload["api_reachable"] is False
        assert payload["auth_valid"] is False

    def test_health_down_has_false_fields(self) -> None:
        """When api_reachable=False all auth/db fields reflect failure."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = ServerError("503", status_code=503)

        payload = _build_health_payload(mock_client)

        assert payload["api_reachable"] is False
        assert payload["auth_valid"] is False
        assert payload["llm_provider"] == "unknown"
        assert "error" in payload["db_connectivity"].lower()

    def test_health_version_still_present_when_down(self) -> None:
        """version must be populated even when backend is unreachable."""
        from andish_mcp._version import __version__  # noqa: PLC0415
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = AndishError("Timeout")

        payload = _build_health_payload(mock_client)

        assert payload["version"] == __version__


class TestHealthPayloadDegraded:
    """Status=degraded path: API reachable but auth failed (AuthError)."""

    def test_health_auth_invalid_returns_degraded(self) -> None:
        """status='degraded' when whoami() raises AuthError."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = AuthError("Invalid API key", status_code=401)

        payload = _build_health_payload(mock_client)

        assert payload["status"] == "degraded"
        assert payload["api_reachable"] is True
        assert payload["auth_valid"] is False

    def test_health_degraded_best_effort_fields(self) -> None:
        """Auth invalid → llm_provider=unknown (cannot query backend for info)."""
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = AuthError("Expired key", status_code=401)

        payload = _build_health_payload(mock_client)

        assert payload["llm_provider"] == "unknown"
        assert payload["db_connectivity"] == "unknown"

    def test_health_degraded_version_still_present(self) -> None:
        """version is always available regardless of auth status."""
        from andish_mcp._version import __version__  # noqa: PLC0415
        from andish_mcp.tools.health import _build_health_payload  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.side_effect = AuthError("Bad key", status_code=403)

        payload = _build_health_payload(mock_client)

        assert payload["version"] == __version__


class TestHealthFormatOutput:
    """_format_health must return JSON in a fenced code block."""

    def test_format_health_returns_json_code_block(self) -> None:
        """Output must be wrapped in ```json ... ``` fence."""
        from andish_mcp.tools.health import _format_health  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

        result = _format_health(mock_client)

        assert result.startswith("```json\n")
        assert result.endswith("\n```")

    def test_format_health_json_is_parseable(self) -> None:
        """Embedded JSON must be valid and contain all required keys."""
        import json  # noqa: PLC0415

        from andish_mcp.tools.health import _format_health  # noqa: PLC0415

        mock_client = MagicMock()
        mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

        result = _format_health(mock_client)

        # Strip fences and parse.
        json_str = result.removeprefix("```json\n").removesuffix("\n```")
        payload = json.loads(json_str)

        required_keys = {
            "status", "version", "api_reachable", "auth_valid",
            "llm_provider", "db_connectivity", "uptime_seconds", "checked_at",
        }
        assert required_keys == set(payload.keys()), (
            f"Unexpected keys: {set(payload.keys()) ^ required_keys}"
        )


# ===========================================================================
# Registration test (requires mcp)
# ===========================================================================


@requires_mcp
def test_andish_health_registered_in_server() -> None:
    """After build_server(), 'andish_health' must appear in the tool list."""
    from unittest.mock import patch  # noqa: PLC0415

    import andish_mcp.server as server_module  # noqa: PLC0415
    from andish_mcp.config import MCPConfig  # noqa: PLC0415
    from andish_mcp.server import build_server  # noqa: PLC0415

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.whoami.return_value = {"tenant_id": "t-uuid", "tenant_name": "Test"}

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_health", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tool_names = {t.name for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    assert "andish_health" in tool_names


@requires_mcp
def test_server_now_has_eight_tools() -> None:
    """build_server() must register exactly 8 tools (6 P0 + andish_health + andish_upload_document)."""
    from unittest.mock import patch  # noqa: PLC0415

    import andish_mcp.server as server_module  # noqa: PLC0415
    from andish_mcp.config import MCPConfig  # noqa: PLC0415
    from andish_mcp.server import build_server  # noqa: PLC0415

    server_module._client = None  # type: ignore[attr-defined]

    mock_client = MagicMock()
    mock_client.whoami.return_value = {"tenant_id": "t-uuid"}

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(api_key="adsh_test_health_count", base_url="http://localhost:8000/v1")
        mcp_server = build_server(cfg)

    tool_names = {t.name for t in mcp_server._tool_manager.list_tools()}  # type: ignore[attr-defined]
    expected = {
        "andish_query",
        "andish_list_documents",
        "andish_get_document",
        "andish_workspace_usage",
        "andish_search_entities",
        "andish_get_neighbors",
        "andish_health",
        "andish_upload_document",
    }
    assert tool_names == expected, (
        f"Tool set mismatch.\n  Expected: {sorted(expected)}\n  Got:      {sorted(tool_names)}"
    )


# ===========================================================================
# In-process integration test (ADR-032 primary strategy)
# ===========================================================================


@requires_mcp
def test_health_tool_via_in_process_mcp() -> None:
    """AI-T4 in-process integration: andish_health returns JSON status=ok.

    Per ADR-032: drives the full MCP JSON-RPC protocol via in-memory streams
    (create_client_server_memory_streams).  No subprocess, no real HTTP.
    This is the primary integration test per the in-process-primary strategy.
    """
    import anyio  # noqa: PLC0415
    from mcp.client.session import ClientSession  # noqa: PLC0415
    from mcp.shared.memory import create_client_server_memory_streams  # noqa: PLC0415
    from mcp.types import Implementation  # noqa: PLC0415
    from unittest.mock import patch  # noqa: PLC0415

    import andish_mcp.server as server_module  # noqa: PLC0415
    from andish_mcp.config import MCPConfig  # noqa: PLC0415
    from andish_mcp.server import build_server  # noqa: PLC0415

    # Build test server with fully mocked SDK client.
    server_module._client = None  # type: ignore[attr-defined]
    mock_client = MagicMock()
    mock_client.whoami.return_value = {
        "tenant_id": "integration-test-uuid",
        "tenant_name": "Integration Test Corp",
        "scopes": ["read", "write"],
        "api_key_prefix": "adsh_test_",
    }

    with patch.object(server_module, "_get_client", return_value=mock_client):
        cfg = MCPConfig(
            api_key="adsh_test_health_integration",
            base_url="http://localhost:8000/v1",
        )
        mcp_server = build_server(cfg)

    async def _run() -> dict[str, Any]:
        import json as _json  # noqa: PLC0415

        result_holder: list[Any] = []

        async with create_client_server_memory_streams() as (
            (client_read, client_write),
            (server_read, server_write),
        ), anyio.create_task_group() as tg:
            tg.start_soon(
                mcp_server._mcp_server.run,  # type: ignore[attr-defined]
                server_read,
                server_write,
                mcp_server._mcp_server.create_initialization_options(),  # type: ignore[attr-defined]
            )

            async with ClientSession(
                client_read,
                client_write,
                client_info=Implementation(name="test-client", version="0.0.1"),
            ) as session:
                await session.initialize()

                call_result = await session.call_tool("andish_health", arguments={})
                # Extract text content from first content item.
                raw_text: str = call_result.content[0].text  # type: ignore[index,attr-defined]
                # Strip JSON fences and parse.
                json_str = raw_text.removeprefix("```json\n").removesuffix("\n```")
                payload = _json.loads(json_str)
                result_holder.append(payload)

                tg.cancel_scope.cancel()

        return result_holder[0]

    payload = anyio.run(_run)

    # Core assertions for the integration test.
    assert payload["status"] == "ok", f"Expected status=ok, got: {payload['status']!r}"
    assert payload["api_reachable"] is True
    assert payload["auth_valid"] is True
    assert isinstance(payload["version"], str) and len(payload["version"]) > 0
    assert payload["checked_at"].endswith(" UTC")
    assert isinstance(payload["uptime_seconds"], int)
    # Integration test spawns a fresh MCP subprocess via stdio transport, so the
    # server module is re-imported and _SERVER_START_TIME resets to ~now. Uptime
    # is therefore ≈0 by the time the test calls the tool. The unit test in
    # TestUptimeSeconds asserts the strengthened ≥5 bound where it actually applies.
    assert payload["uptime_seconds"] >= 0
