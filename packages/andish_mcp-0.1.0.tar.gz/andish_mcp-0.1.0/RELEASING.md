# andish-mcp Release Runbook

Release pipeline: `.github/workflows/andish-mcp-release.yml`

---

## Prerequisites

### PyPI accounts

1. Create account on [test.pypi.org](https://test.pypi.org) and [pypi.org](https://pypi.org).
2. Create a project named `andish-mcp` on each.
3. Generate an API token scoped to that project on each service.

### GitHub Secrets (Settings → Secrets → Actions)

| Secret | Value | Required |
|---|---|---|
| `TEST_PYPI_API_TOKEN` | test.pypi.org API token scoped to `andish-mcp` | Yes — PR dry-run fails without it |
| `PYPI_API_TOKEN` | pypi.org API token scoped to `andish-mcp` | Yes — prod-release fails without it |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token | No — notification skipped if absent |
| `TELEGRAM_CHAT_ID` | Chat or channel ID | No — notification skipped if absent |

`PYPI_API_TOKEN` is **required**. The prod-release job uses API token authentication
(`twine upload` with `TWINE_PASSWORD`). Without this secret the upload step fails with HTTP 403.

### Future: OIDC Trusted Publishing (planned for Sprint 3)

PyPI supports OIDC trusted publishing — no long-lived API tokens needed.
This approach is planned for Sprint 3 and is not implemented in the current workflow.
When implemented, `id-token: write` will be added to the prod-release job permissions
and `PYPI_API_TOKEN` can be removed.

---

## PR workflow (automatic dry-run)

Every non-draft PR that touches `packages/andish-mcp/**` triggers the `test-pypi-dry-run` job.

What happens automatically:
1. Package is built (`python -m build`).
2. Artifacts are validated (`twine check`).
3. Package is uploaded to test.pypi.org.
4. Import smoke check: installs from test.pypi and verifies `>= 4` tools register.
5. A comment is posted to the PR with the install command for manual validation.

To validate manually after the job passes:

```bash
VERSION=0.1.0  # replace with the version from the PR comment
pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  "andish-mcp==$VERSION"

python -c "
from andish_mcp.server import build_server
from andish_mcp.config import MCPConfig
cfg = MCPConfig(api_key='adsh_test_xxx', base_url='https://api.andish.ru/v1', timeout=30.0)
mcp = build_server(cfg=cfg)
print('Tools:', [t.name for t in mcp._tool_manager.list_tools()])
"
```

### Draft PRs

Draft PRs do not trigger test.pypi upload (`draft == false` condition in the workflow).
Convert to "Ready for review" to trigger the dry-run.

---

## Production release

### Step 1 — bump version in pyproject.toml

```toml
[project]
version = "0.1.0"   # was 0.1.0a1 or similar
```

Commit and merge to `develop` via normal PR flow.

### Step 2 — trigger release (two options)

**Option A: workflow_dispatch (recommended for first releases)**

1. GitHub → Actions → "andish-mcp Release" → Run workflow.
2. Enter version exactly as it appears in `pyproject.toml` (e.g. `0.1.0`).
3. The workflow verifies the match before uploading — mismatch causes a hard failure.

**Option B: push a tag**

```bash
git tag andish-mcp/v0.1.0
git push origin andish-mcp/v0.1.0
```

The tag push triggers the `prod-release` job automatically.
The version is extracted from the tag (`andish-mcp/v0.1.0` → `0.1.0`) and verified
against `pyproject.toml`.

### Step 3 — verify

After the workflow completes:
- Package appears at https://pypi.org/project/andish-mcp/
- GitHub Release created at https://github.com/MotoPes/Mnemo/releases

Install verification:

```bash
pip install andish-mcp==0.1.0
# or
uvx andish-mcp@0.1.0
```

---

## Rollback

### Yank a PyPI version (hide from search, block install without explicit pin)

1. pypi.org → project andish-mcp → Manage → Releases → select version → Yank.
2. Add yank reason (e.g. "Critical bug in andish_query tool").

Yanked versions are still installable with an explicit pin (`pip install andish-mcp==0.1.0`)
but `pip install andish-mcp` and `uvx andish-mcp@latest` will skip the yanked version.

### Revert the git tag

```bash
git push origin --delete andish-mcp/v0.1.0
```

This does not un-publish PyPI — yank separately.

### Delete a PyPI release (irreversible, use only for security incidents)

PyPI allows deletion only within a short window after upload or for security reasons.
Contact PyPI support via https://pypi.org/help/#project.
After deletion, the version number cannot be re-used (PyPI policy).

---

## Local build

To reproduce the CI build locally:

```bash
cd packages/andish-mcp

pip install build twine
python -m build
twine check dist/*

# Expected output:
#   Successfully built andish_mcp-0.1.0a0.tar.gz andish_mcp-0.1.0a0-py3-none-any.whl
#   Checking dist/andish_mcp-0.1.0a0.tar.gz: PASSED
#   Checking dist/andish_mcp-0.1.0a0-py3-none-any.whl: PASSED
```

---

## Common pitfalls

**Cached wheel installed instead of newly uploaded version**

`pip` caches wheels locally. If smoke install returns an old version:

```bash
pip install --no-cache-dir --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ andish-mcp==<version>
```

**test.pypi 400: File already exists**

Each version+filename combination can only be uploaded once to test.pypi.
If the workflow re-runs on the same commit and version, twine will fail with 400.
Bump `version` in `pyproject.toml` (e.g. `0.1.0a1` → `0.1.0a2`) or use a `.post0` suffix.

**Version mismatch error in prod-release**

The `prod-release` job hard-fails if the trigger version (input or tag) does not match
`pyproject.toml version`. Fix: update `pyproject.toml` first and merge before tagging.

**test.pypi rate limit (429)**

test.pypi has upload rate limits. If you hit them, wait ~10 minutes and re-run the job.
To reduce unnecessary uploads, keep PRs in draft until ready for review.

**PYPI_API_TOKEN not configured**

The `prod-release` job will fail at the upload step with a 403.
Set `PYPI_API_TOKEN` in GitHub Secrets, or configure OIDC Trusted Publishing (see above).

**Telegram notification skipped**

Expected when `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` secrets are not set.
The job does not fail — notification is best-effort.
