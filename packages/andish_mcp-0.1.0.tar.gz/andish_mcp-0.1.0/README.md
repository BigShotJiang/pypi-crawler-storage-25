# andish-mcp

MCP server for the [Andish](https://andish.ru) Knowledge Graph API.

Works with any MCP-compatible client: Claude Desktop, Claude Code, Cursor, Cline, Continue, and others.

## Install

```bash
uvx andish-mcp@latest
```

Or with pip:

```bash
pip install andish-mcp
```

## Configure (Claude Desktop)

```jsonc
// ~/Library/Application Support/Claude/claude_desktop_config.json
{
  "mcpServers": {
    "andish": {
      "command": "uvx",
      "args": ["andish-mcp@latest"],
      "env": {
        "ANDISH_API_KEY": "adsh_live_xxxxxxxxxxxx"
      }
    }
  }
}
```

## Available Tools

- `andish_query` — search the Andish knowledge graph, get a synthesised answer with sources.
- `andish_workspace_usage` — view current workspace usage: documents, cost, daily queries.

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `ANDISH_API_KEY` | Yes | — | API key from https://andish.ru/dashboard |
| `ANDISH_BASE_URL` | No | `https://api.andish.ru/v1` | Override for self-hosted or staging |
| `ANDISH_TIMEOUT` | No | `30.0` | Per-request timeout in seconds |
