"""Error mapping: andish SDK exceptions → human-friendly MCP responses.

MCP tools must never leak raw HTTP status codes or server stack traces to the
LLM / user. This module translates typed SDK exceptions into plain Russian
sentences that can be shown directly in the AI client interface.

Per design doc §2.6: all error handling happens here, not in tool implementations.
"""

from __future__ import annotations

from andish.errors import (
    AndishError,
    AuthError,
    CostCapError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def to_user_message(exc: AndishError) -> str:
    """Translate an SDK exception into a sentence the LLM can show the user.

    All messages are in Russian (ICP = RU CTO).  If locale support is needed
    later, add ANDISH_LOCALE env var handling here — not in tool code.
    """
    if isinstance(exc, AuthError):
        return (
            "Andish API ключ невалиден или истёк. "
            "Получите новый ключ на https://andish.ru/dashboard"
        )
    if isinstance(exc, CostCapError):
        cap_part = f" (лимит {exc.cap}₽)" if exc.cap is not None else ""
        return (
            f"Дневной лимит стоимости в Andish исчерпан{cap_part}. "
            "Обновите тариф или подождите до завтра."
        )
    if isinstance(exc, RateLimitError):
        retry_part = f" Повторите через {int(exc.retry_after)}с." if exc.retry_after else ""
        return f"Слишком много запросов к Andish API.{retry_part}"
    if isinstance(exc, NotFoundError):
        return "Запрошенный ресурс не найден в вашем workspace."
    if isinstance(exc, ValidationError):
        return f"Запрос отклонён: {exc!s}"
    if isinstance(exc, ServerError):
        return "Внутренняя ошибка Andish (5xx). Повторите через минуту."
    # Fallback for base AndishError and any future subclasses.
    return f"Ошибка Andish: {exc!s}"
