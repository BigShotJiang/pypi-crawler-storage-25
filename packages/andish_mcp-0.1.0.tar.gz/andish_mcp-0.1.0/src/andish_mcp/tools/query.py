"""andish_query MCP tool — SP1-03.

Wraps POST /v1/query via the andish SDK.  All HTTP error mapping is done via
:func:`andish_mcp.errors.to_user_message` — the tool never leaks raw HTTP codes.
"""

from __future__ import annotations

from andish import Client
from andish.errors import AndishError
from mcp.server.fastmcp import FastMCP

from andish_mcp.errors import to_user_message


def register(mcp: FastMCP, client: Client) -> None:
    """Register ``andish_query`` tool on the given FastMCP server instance."""

    @mcp.tool()
    def andish_query(question: str, mode: str = "mix") -> str:  # type: ignore[return]
        """Search the Andish workspace knowledge graph and synthesise an answer.

        Use this tool when you need to answer questions based on the user's
        workspace (documents previously uploaded to Andish). Returns a
        natural-language answer with source document references.

        Args:
            question: Natural-language question in Russian or English (3-2000 chars).
            mode: Retrieval mode. "mix" (default, recommended) combines knowledge
                  graph + vector search. "local", "global", "hybrid", "naive" are
                  experimental and may return empty answers for sparse graphs.

        Returns:
            Synthesised answer text plus a list of source document references.
            Returns "Недостаточно данных для ответа." when the graph is empty.
            Returns a user-friendly error message on API errors (not raw HTTP codes).
        """
        try:
            response = client.query.ask(question, mode=mode)
        except AndishError as exc:
            return to_user_message(exc)

        # Feature 04-bis (AC #5): include freshness metadata in structured output
        # so Claude / Cursor can cite the document age and staleness signal.
        def _format_source(s: object) -> str:
            # SourceRef carries richness; plain str is legacy fallback.
            from andish.types import SourceRef  # noqa: PLC0415

            if isinstance(s, SourceRef):
                parts = [s.document_id]
                if s.loaded_days_ago is not None:
                    parts.append(f"loaded_days_ago={s.loaded_days_ago}")
                if s.freshness is not None:
                    parts.append(f"freshness={s.freshness}")
                if s.document_date is not None:
                    parts.append(f"document_date={s.document_date}")
                return " | ".join(parts)
            return str(s)

        sources_lines = "\n".join(f"  - {_format_source(s)}" for s in response.sources)
        sources_section = sources_lines if sources_lines else "  (no sources)"
        return f"{response.answer}\n\nSources:\n{sources_section}"
