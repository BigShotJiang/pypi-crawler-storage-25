# Tool registration modules — each exports a single ``register(mcp, client)`` function.
