"""andish_list_documents and andish_get_document MCP tools — SP2-02, SP2-03.

Wraps GET /v1/documents (list) and GET /v1/documents/{id} (get) via the
andish SDK.  All HTTP error mapping is done via
:func:`andish_mcp.errors.to_user_message` — the tool never leaks raw HTTP
codes to the LLM caller.

Sprint 2 scope:
  - List: first-page only (offset=0), limit 1-100.  No status filter (backend
    does not expose a status query param; filter removed per TL AC revision).
  - Get: returns metadata + content excerpt (first 500 chars) from ADR-036 §2.6
    content field.  Full content is truncated to avoid flooding LLM context windows.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from andish import Client
from andish.errors import AndishError

from andish_mcp.errors import to_user_message

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

_MAX_LIMIT = 100
_CONTENT_EXCERPT_CHARS = 500  # ADR-036 §2.6: excerpt to avoid LLM context overflow

# Feature 03-bis: activity-based filter values exposed to the MCP caller.
_ActivityFilter = Literal["never_queried", "quiet_90d", "quiet_30d", "active"]


# ---------------------------------------------------------------------------
# Business logic — importable without mcp installed
# ---------------------------------------------------------------------------


def _format_list(
    client: Client,
    limit: int = 50,
    filter: _ActivityFilter | None = None,  # noqa: A002
) -> str:
    """Core list logic; testable without FastMCP.

    Feature 03-bis: when ``filter`` is provided it is forwarded to the SDK
    (which passes it as a query-string parameter to the API).  Valid values:
    ``"never_queried"``, ``"quiet_90d"``, ``"quiet_30d"``, ``"active"``.
    """
    if limit < 1 or limit > _MAX_LIMIT:
        return (
            f"Параметр limit должен быть от 1 до {_MAX_LIMIT}. "
            f"Получено: {limit}."
        )

    try:
        list_kwargs: dict[str, object] = {"limit": limit, "offset": 0}
        if filter is not None:
            list_kwargs["filter"] = filter
        result = client.documents.list(**list_kwargs)  # type: ignore[arg-type]
    except AndishError as exc:
        return to_user_message(exc)

    if not result.items:
        return "Нет документов в workspace."

    lines = ["| id | name | status | uploaded_at |", "| --- | --- | --- | --- |"]
    for doc in result.items:
        # Use meta.title or meta.filename as display name; fall back to doc_id.
        name = str(
            doc.meta.get("title") or doc.meta.get("filename") or doc.document_id
        )
        # Truncate long names for table readability.
        if len(name) > 40:
            name = name[:37] + "..."
        lines.append(
            f"| {doc.document_id} | {name} | {doc.status} | {doc.created_at} |"
        )

    table = "\n".join(lines)

    # AC8: pagination note when backend has more than returned.
    if result.total > len(result.items):
        pagination_note = (
            f"\n\n_(showing first {len(result.items)} of {result.total} documents"
            f" — increase limit parameter to see more, max {_MAX_LIMIT})_"
        )
        return table + pagination_note

    return table


def _format_get(client: Client, document_id: str) -> str:
    """Core get logic; testable without FastMCP."""
    try:
        doc = client.documents.get(document_id)
    except AndishError as exc:
        return to_user_message(exc)

    lines = [
        f"## Document `{doc.document_id}`",
        "",
        f"**Status:** {doc.status}",
        f"**Uploaded:** {doc.created_at}",
        f"**Updated:** {doc.updated_at}",
        f"**Progress:** {doc.progress_percent}%",
    ]

    if doc.processed_at:
        lines.append(f"**Processed:** {doc.processed_at}")

    if doc.error_message:
        lines.append(f"**Error:** {doc.error_message}")

    if doc.meta:
        lines.append("")
        lines.append("**Metadata:**")
        for key, value in doc.meta.items():
            lines.append(f"  - {key}: {value}")

    # ADR-036 §2.6: render content excerpt (first 500 chars) to avoid context overflow.
    # content is None for legacy docs without encryption or list-endpoint responses.
    lines.append("")
    lines.append("**Content:**")
    if doc.content:
        total_chars = len(doc.content)
        if total_chars <= _CONTENT_EXCERPT_CHARS:
            lines.append(doc.content)
        else:
            lines.append(doc.content[:_CONTENT_EXCERPT_CHARS] + "…")
            lines.append(
                f"_(excerpt: first {_CONTENT_EXCERPT_CHARS} of {total_chars} chars)_"
            )
    else:
        lines.append("_(no content available)_")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# FastMCP registration
# ---------------------------------------------------------------------------


def register(mcp: FastMCP, client: Client) -> None:
    """Register ``andish_list_documents`` and ``andish_get_document`` tools."""

    @mcp.tool()
    def andish_list_documents(  # type: ignore[return]
        limit: int = 50,
        filter: str | None = None,  # noqa: A002
    ) -> str:
        """List documents uploaded to the Andish workspace.

        Returns a markdown table of documents with their ID, name/title,
        status, and upload date. Only the first page is returned (Sprint 2).
        To see more documents increase the limit parameter (max 100).

        Feature 03-bis: use ``filter`` to focus on documents that may need
        review or cleanup.

        Args:
            limit: Maximum number of documents to return (1-100, default 50).
            filter: Optional activity filter. Allowed values:
                    - ``"never_queried"`` — documents never cited by any query.
                    - ``"quiet_90d"`` — not cited in 90+ days (includes never_queried).
                    - ``"quiet_30d"`` — not cited in 30+ days.
                    - ``"active"`` — cited within the last 30 days.
                    Omit (or pass None) to list all documents.

        Returns:
            Markdown table of documents. Empty workspace returns a friendly
            message. API errors return a user-friendly Russian-language message.
        """
        validated_filter: _ActivityFilter | None = None
        _valid = {"never_queried", "quiet_90d", "quiet_30d", "active"}
        if filter is not None:
            if filter not in _valid:
                return (
                    f"Недопустимое значение filter: '{filter}'. "
                    f"Допустимые значения: {', '.join(sorted(_valid))}."
                )
            validated_filter = filter  # type: ignore[assignment]
        return _format_list(client, limit=limit, filter=validated_filter)

    @mcp.tool()
    def andish_get_document(document_id: str) -> str:  # type: ignore[return]
        """Fetch metadata and a content excerpt for a specific Andish document.

        Use this tool when you need details about a particular document — its
        processing status, upload time, metadata, or a preview of its content.

        Args:
            document_id: UUID of the document (e.g. from andish_list_documents).

        Returns:
            Markdown-formatted document metadata and content excerpt.
            Returns a user-friendly error on 404 or API errors.
        """
        return _format_get(client, document_id=document_id)
