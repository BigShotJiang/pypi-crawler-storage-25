"""andish_health MCP tool — AI-T4.

Returns a structured health status of the Andish MCP server and its backend
connectivity.  Designed for the Phase 2 onboarding wizard success state — the
LLM client calls this tool to confirm the MCP connection is live and the API
key is valid before showing the wizard "connected" screen.

Status semantics:
  "ok"       — api_reachable=True AND auth_valid=True
  "degraded" — api_reachable=True AND auth_valid=False (key expired / revoked)
  "down"     — api_reachable=False (network error, backend unreachable)
"""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from andish import Client
from andish.errors import AndishError, AuthError

from andish_mcp._version import __version__

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

# Module-level: record server start time once per process.
_SERVER_START_TIME: float = time.monotonic()


# ---------------------------------------------------------------------------
# Business logic — importable and testable without mcp installed
# ---------------------------------------------------------------------------


def _build_health_payload(client: Client, start_time: float = _SERVER_START_TIME) -> dict[str, Any]:
    """Core health check logic; returns a structured dict.

    Separated from the FastMCP registration so it can be tested without the
    mcp package installed (mirrors the _format_list / _format_get pattern).

    Args:
        client: Andish SDK client to probe.
        start_time: monotonic reference timestamp for uptime_seconds calculation.
            Defaults to the module-level _SERVER_START_TIME (process start).

    Returns:
        Health payload dict matching the AI-T4 contract.
    """
    checked_at = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")
    uptime_seconds = int(time.monotonic() - start_time)

    # Step 1: probe API reachability + auth by calling whoami.
    api_reachable: bool
    auth_valid: bool
    llm_provider: str
    db_connectivity: str

    try:
        identity = client.whoami()
        api_reachable = True
        auth_valid = True
        # Infer LLM provider from identity if backend exposes it; otherwise mark unknown
        # for semantic consistency with degraded/down branches (TL P2 follow-up).
        llm_provider = str(identity.get("llm_provider", "unknown"))
        db_connectivity = "ok"
    except AuthError:
        # API is reachable but credentials are rejected.
        api_reachable = True
        auth_valid = False
        llm_provider = "unknown"
        db_connectivity = "unknown"
    except AndishError:
        # Network failure, DNS error, 5xx, timeout, etc.
        api_reachable = False
        auth_valid = False
        llm_provider = "unknown"
        db_connectivity = "error: backend unreachable"

    # Step 2: derive overall status.
    if not api_reachable:
        status = "down"
    elif not auth_valid:
        status = "degraded"
    else:
        status = "ok"

    return {
        "status": status,
        "version": __version__,
        "api_reachable": api_reachable,
        "auth_valid": auth_valid,
        "llm_provider": llm_provider,
        "db_connectivity": db_connectivity,
        "uptime_seconds": uptime_seconds,
        "checked_at": checked_at,
    }


def _format_health(client: Client, start_time: float = _SERVER_START_TIME) -> str:
    """Return health payload formatted as a markdown code block.

    The MCP tool returns a string; we embed the JSON payload inside a fenced
    code block so that LLM clients can parse it reliably without needing the
    raw dict.  Returning structured text (not raw JSON str) is consistent with
    other tools in this package.
    """
    payload = _build_health_payload(client, start_time=start_time)
    return "```json\n" + json.dumps(payload, indent=2) + "\n```"


# ---------------------------------------------------------------------------
# FastMCP registration
# ---------------------------------------------------------------------------


def register(mcp: FastMCP, client: Client) -> None:
    """Register ``andish_health`` tool on the given FastMCP server instance."""

    @mcp.tool()
    def andish_health() -> str:  # type: ignore[return]
        """Check the health of the Andish MCP server and API connectivity.

        Use this tool to verify the MCP connection is live, the API key is
        valid, and the Andish backend is reachable.  Designed for the Phase 2
        onboarding wizard success state — call this tool first to confirm
        everything is working before running any other Andish tools.

        No parameters required.

        Returns:
            JSON health report with status ("ok" | "degraded" | "down"),
            version, API reachability, auth validity, LLM provider, database
            connectivity, server uptime in seconds, and a UTC timestamp.
            Status "ok" means all systems are operational.
            Status "degraded" means the API is reachable but auth failed —
            check your ANDISH_API_KEY.
            Status "down" means the Andish backend is unreachable — check
            network connectivity and ANDISH_BASE_URL.
        """
        return _format_health(client)
