"""andish_workspace_usage MCP tool — SP1-04.

Wraps GET /v1/workspace/usage via the andish SDK.  Tenant is determined from
the API key — no parameters required from the LLM caller.
"""

from __future__ import annotations

from andish import Client
from andish.errors import AndishError
from andish.types import WorkspaceUsage

from andish_mcp.errors import to_user_message

# ---------------------------------------------------------------------------
# Business logic — importable without mcp installed
# ---------------------------------------------------------------------------


def _format_usage(u: WorkspaceUsage) -> str:
    """Format WorkspaceUsage into a human-readable string.

    Extracted from the tool closure so it can be unit-tested independently of
    the FastMCP runtime.  Keep in sync with test_workspace_tool._format_usage.
    """
    query_cap = f" из {u.queries_cap_daily}" if u.queries_cap_daily is not None else ""
    cap_str = (
        f"{u.cost_cap_rub_daily}₽ (дневной лимит)"
        if u.cost_cap_rub is None
        else f"{u.cost_cap_rub_daily}₽ (дневной) / {u.cost_cap_rub}₽ (месячный)"
    )

    # Two-counter document line: shows upload vs. indexed state clearly.
    # Helps users understand progress in the first 60 seconds after upload.
    processing = u.documents_uploaded - u.documents_processed
    docs_line = f"{u.documents_uploaded} загружено · {u.documents_processed} готовы"
    if processing > 0:
        docs_line += f" ({processing} индексируются)"

    # Feature 03-bis: cleanup stats line — shown only when there is something to review.
    cleanup_parts: list[str] = []
    if u.documents_never_queried > 0:
        cleanup_parts.append(f"{u.documents_never_queried} никогда не использовались")
    if u.documents_quiet_90d > 0:
        cleanup_parts.append(f"{u.documents_quiet_90d} не использовались 90+ дней")
    cleanup_line = "  Устаревшие: " + " · ".join(cleanup_parts) if cleanup_parts else ""

    lines = [
        f"Workspace '{u.period}':",
        f"  Документы: {docs_line}",
        f"  Расходы: {u.cost_current_rub}₽ | Лимит: {cap_str}",
        f"  Запросы сегодня: {u.queries_today}{query_cap}",
        f"  Тариф: {u.tier}",
    ]
    if cleanup_line:
        lines.append(cleanup_line)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# FastMCP registration
# ---------------------------------------------------------------------------


def register(mcp: object, client: Client) -> None:
    """Register ``andish_workspace_usage`` tool on the given FastMCP server instance."""
    from mcp.server.fastmcp import FastMCP  # noqa: PLC0415

    assert isinstance(mcp, FastMCP)

    @mcp.tool()
    def andish_workspace_usage() -> str:  # type: ignore[return]
        """Show current Andish workspace usage: documents, cost, and daily queries.

        No parameters needed — the workspace is determined from the API key.
        Use this tool to answer questions like "how many documents do I have?"
        or "how much have I spent today?".  Also shows workspace cleanup hints
        (documents never queried or quiet for 90+ days).

        Returns:
            Human-readable summary of workspace usage metrics.
            Returns a user-friendly error message on API errors (not raw HTTP codes).
        """
        try:
            u = client.workspace.get_usage()
        except AndishError as exc:
            return to_user_message(exc)

        return _format_usage(u)
