"""andish_search_entities and andish_get_neighbors MCP tools.

Wraps GET /v1/graph/entities/search and GET /v1/graph/entities/{id}/neighbors
via the andish SDK.  All HTTP error mapping goes through
:func:`andish_mcp.errors.to_user_message` — tools never leak raw HTTP codes.
"""

from __future__ import annotations

from andish import Client
from andish.errors import AndishError
from mcp.server.fastmcp import FastMCP

from andish_mcp.errors import to_user_message


def register(mcp: FastMCP, client: Client) -> None:
    """Register ``andish_search_entities`` and ``andish_get_neighbors`` tools."""

    @mcp.tool()
    def andish_search_entities(query: str, limit: int = 20) -> str:  # type: ignore[return]
        """Search entities (people, organizations, concepts) by label substring in workspace.

        Use this tool when you need to find specific entities in the knowledge
        graph by name fragment. Returns a list of matching entity identifiers
        and their types.

        Args:
            query: Substring to search in entity labels (case-insensitive, 1-200 chars).
            limit: Maximum number of results to return (1-100, default: 20).

        Returns:
            Formatted list of matching entities or "No entities matched." when empty.
            Returns a user-friendly error message on API errors (not raw HTTP codes).
        """
        try:
            response = client.entities.search(query, limit=limit)
        except AndishError as exc:
            return to_user_message(exc)

        if not response.entities:
            return "No entities matched."

        lines = [f"Found {response.total} entities:"]
        for entity in response.entities:
            type_part = f" ({entity.type})" if entity.type else ""
            lines.append(f"  - {entity.id}: {entity.label}{type_part}")
        return "\n".join(lines)

    @mcp.tool()
    def andish_get_neighbors(entity_id: str, hop: int = 1, limit: int = 50) -> str:  # type: ignore[return]
        """Return entities directly (hop=1) or transitively (hop=2) connected to entity_id.

        Use this tool to explore relationships of a known entity in the knowledge
        graph. hop=1 returns direct neighbors; hop=2 includes neighbors-of-neighbors.

        Args:
            entity_id: Stable entity identifier returned by andish_search_entities.
            hop:       Traversal depth: 1 (direct neighbors) or 2 (2-hop). Default: 1.
            limit:     Maximum number of neighbor entities to return (1-200). Default: 50.

        Returns:
            Entity label with a list of neighbors and edge types, or
            "Entity has no neighbors." when the entity exists but is isolated.
            Returns a user-friendly error message on API errors (not raw HTTP codes).
        """
        try:
            response = client.entities.get_neighbors(entity_id, hop=hop, limit=limit)
        except AndishError as exc:
            return to_user_message(exc)

        if not response.neighbors:
            return "Entity has no neighbors."

        lines = [f"Entity: {response.entity.label}", f"Neighbors (hop={response.hop}):"]
        # Build a lookup of edges for quick type retrieval.
        edge_types: dict[str, str | None] = {}
        for edge in response.edges:
            edge_types[edge.target] = edge.type
            edge_types[edge.source] = edge_types.get(edge.source)

        for neighbor in response.neighbors:
            type_part = f" ({neighbor.type})" if neighbor.type else ""
            edge_type = edge_types.get(neighbor.id)
            edge_part = f" [{edge_type}]" if edge_type else ""
            lines.append(f"  - {neighbor.id}: {neighbor.label}{type_part}{edge_part}")
        return "\n".join(lines)
