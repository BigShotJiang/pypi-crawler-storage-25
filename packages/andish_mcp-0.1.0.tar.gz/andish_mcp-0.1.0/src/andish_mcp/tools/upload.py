"""andish_upload_document MCP tool — CEO-SELF-USE-BUNDLE Story 8.

Thin wrapper around POST /v1/documents via the andish SDK.  Accepts a local
file path, reads content as UTF-8, and enqueues the document for extraction.

The returned ``document_id`` can be passed to ``andish_get_document`` to poll
processing status, or to ``andish_list_documents`` to verify it appears.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from andish import Client
from andish.errors import AndishError

from andish_mcp.errors import to_user_message

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


# ---------------------------------------------------------------------------
# Business logic — importable without mcp installed
# ---------------------------------------------------------------------------


def _format_upload(
    client: Client,
    file_path: str,
    *,
    title: str | None = None,
    document_date: str | None = None,
) -> str:
    """Core upload logic; testable without FastMCP."""
    metadata: dict[str, object] = {}
    if title:
        metadata["title"] = title

    try:
        doc = client.documents.upload(
            file_path,
            metadata=metadata if metadata else None,
            document_date=document_date,
        )
    except ValueError as exc:
        # File-not-found / empty-content errors from the SDK (pre-HTTP).
        return f"Ошибка: {exc}"
    except AndishError as exc:
        return to_user_message(exc)

    lines = [
        "Документ загружен и поставлен в очередь на индексацию.",
        "",
        f"**document_id:** `{doc.document_id}`",
        f"**status:** {doc.status}",
    ]
    if doc.meta.get("filename"):
        lines.append(f"**filename:** {doc.meta['filename']}")
    lines.append(
        f"\nПроверить статус: `andish_get_document(document_id=\"{doc.document_id}\")`"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# FastMCP registration
# ---------------------------------------------------------------------------


def register(mcp: FastMCP, client: Client) -> None:
    """Register ``andish_upload_document`` tool on the given FastMCP server instance."""

    @mcp.tool()
    def andish_upload_document(  # type: ignore[return]
        file_path: str,
        title: str = "",
        document_date: str = "",
    ) -> str:
        """Upload a local file to the Andish workspace for indexing.

        Reads the file at ``file_path`` as UTF-8 text and enqueues it for
        knowledge graph extraction.  Use ``andish_get_document`` to poll the
        returned ``document_id`` until status becomes "indexed".

        Typical file types: Markdown (.md), plain text (.txt), any UTF-8 file.
        Maximum size: 1 MB.  Content above 15 000 words is split automatically.

        Args:
            file_path:     Absolute or relative path to the local file.
            title:         Optional display title (overrides filename).
            document_date: Optional validity date label, e.g. "2024-Q3" or
                           "2025-12-15".  Stored as-is; not parsed.

        Returns:
            Confirmation with document_id and processing status, or a
            user-friendly Russian error message on failure.
        """
        return _format_upload(
            client,
            file_path,
            title=title or None,
            document_date=document_date or None,
        )
