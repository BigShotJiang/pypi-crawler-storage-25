"""Entry-point for ``python -m andish_mcp`` and the ``andish-mcp`` CLI script.

Usage:
    ANDISH_API_KEY=adsh_live_... python -m andish_mcp
    ANDISH_API_KEY=adsh_live_... uvx andish-mcp@latest
"""

from andish_mcp.server import run


def main() -> None:
    """CLI entry-point (also used by ``project.scripts`` in pyproject.toml)."""
    run()


if __name__ == "__main__":
    main()
