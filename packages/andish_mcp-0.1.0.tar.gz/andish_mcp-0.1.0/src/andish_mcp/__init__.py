"""andish-mcp — MCP server for the Andish Knowledge Graph API."""

from ._version import __version__

__all__ = ["__version__"]
