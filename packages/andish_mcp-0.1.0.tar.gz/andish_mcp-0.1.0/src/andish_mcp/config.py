"""Configuration for andish-mcp — reads env vars, fails fast if key is missing."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class MCPConfig:
    """Runtime configuration for the andish-mcp server.

    Constructed once at server startup via :func:`load_config`.
    Immutable (frozen dataclass) to prevent accidental mutation in tools.
    """

    api_key: str
    base_url: str = "https://api.andish.ru/v1"
    timeout: float = 30.0


def load_config() -> MCPConfig:
    """Read env vars and return a validated :class:`MCPConfig`.

    Fails fast with a human-readable :class:`SystemExit` if ``ANDISH_API_KEY``
    is missing or empty — callers (Claude Desktop, etc.) will surface the
    message to the user.
    """
    api_key = os.environ.get("ANDISH_API_KEY", "").strip()
    if not api_key:
        raise SystemExit(
            "ANDISH_API_KEY env variable is required. Get a key at https://andish.ru/dashboard"
        )

    # Strip trailing slash so we can always concatenate paths with a leading /.
    raw_url = os.environ.get("ANDISH_BASE_URL", "https://api.andish.ru/v1")
    if not raw_url.startswith(("https://", "http://")):
        raise SystemExit(f"ANDISH_BASE_URL must start with https:// or http://, got: {raw_url!r}")
    base_url = raw_url.rstrip("/")

    raw_timeout = os.environ.get("ANDISH_TIMEOUT", "30.0")
    try:
        timeout = float(raw_timeout)
    except ValueError:
        raise SystemExit(f"ANDISH_TIMEOUT must be a float, got: {raw_timeout!r}") from None

    return MCPConfig(api_key=api_key, base_url=base_url, timeout=timeout)
