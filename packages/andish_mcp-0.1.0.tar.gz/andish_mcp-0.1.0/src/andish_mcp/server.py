"""FastMCP server factory for andish-mcp — SP1-02 / SP2-07.

Builds the MCP server instance, registers all tools, and provides the ``run()``
entry-point for stdio transport (primary P0 transport per design doc §2.4).

SP2-07 addition: ``build_server()`` performs a ``client.whoami()`` startup ping
to verify the API key before accepting tool calls.  On ``AuthError`` the process
exits with code 1 and a user-friendly message on stderr so that Claude Desktop
can surface it immediately.  On network errors the warning is logged and startup
continues — the backend may be temporarily unavailable.
"""

from __future__ import annotations

import sys

import structlog
from andish import Client
from andish.errors import AndishError, AuthError
from mcp.server.fastmcp import FastMCP

from andish_mcp.config import MCPConfig, load_config
from andish_mcp.tools.documents import register as register_documents
from andish_mcp.tools.entities import register as register_entities
from andish_mcp.tools.health import register as register_health
from andish_mcp.tools.query import register as register_query
from andish_mcp.tools.upload import register as register_upload
from andish_mcp.tools.workspace import register as register_workspace

log = structlog.get_logger(__name__)

# Module-level singleton: one Client instance per MCP server process.
_client: Client | None = None


def _get_client(cfg: MCPConfig) -> Client:
    """Return (or lazily construct) the andish SDK client singleton.

    One HTTP connection pool per process — reused across tool calls.
    Multi-tenancy is handled server-side via the API key in the Authorization
    header; the MCP server does not need to track tenants.
    """
    global _client  # noqa: PLW0603 — intentional module-level singleton
    if _client is None:
        _client = Client(
            api_key=cfg.api_key,
            base_url=cfg.base_url,
            timeout=cfg.timeout,
        )
    return _client


def _whoami_ping(client: Client) -> None:
    """Verify the API key via GET /v1/whoami before accepting tool calls.

    SP2-07: fail-fast on invalid credentials rather than silently returning
    error messages for every tool call.

    Behaviour:
    - ``AuthError`` (401/403): write user-friendly message to stderr and exit
      with code 1.  Claude Desktop surfaces this as "MCP server failed to start".
    - Any other ``AndishError`` (network error, server error): log warning and
      continue — backend may be temporarily unavailable; tool calls will handle
      errors individually via ``to_user_message()``.
    """
    try:
        identity = client.whoami()
        log.info(
            "andish_mcp.startup_ping_ok",
            tenant_id=identity.get("tenant_id"),
            tenant_name=identity.get("tenant_name"),
        )
    except AuthError as exc:
        message = (
            f"MCP server failed to start: invalid Andish API key ({exc}).\n"
            "Set ANDISH_API_KEY to a valid key from https://andish.ru/dashboard"
        )
        print(message, file=sys.stderr, flush=True)  # noqa: T201 — user-facing startup error
        raise SystemExit(1) from exc
    except AndishError as exc:
        # Network error, 5xx, etc. — warn and continue.
        log.warning(
            "andish_mcp.startup_ping_failed",
            error=str(exc),
            note="Continuing startup — individual tool calls will handle errors.",
        )


def build_server(cfg: MCPConfig | None = None) -> FastMCP:
    """Build and return a configured :class:`FastMCP` server instance.

    Loads config from env vars when *cfg* is ``None`` (production path).
    Pass an explicit :class:`MCPConfig` in tests to avoid env coupling.

    Performs a ``client.whoami()`` startup ping (SP2-07):
    - Invalid API key → ``SystemExit(1)`` with user-friendly stderr message.
    - Network error → log warning, continue (backend may be temporarily down).

    Args:
        cfg: Optional pre-built config.  When ``None``, :func:`load_config` is called.

    Returns:
        FastMCP server with all P0 tools registered.
    """
    resolved_cfg = cfg or load_config()
    mcp = FastMCP("andish-mcp")

    client = _get_client(resolved_cfg)

    # SP2-07: verify credentials before serving any tool calls.
    _whoami_ping(client)

    register_query(mcp, client)
    register_workspace(mcp, client)
    register_entities(mcp, client)
    register_documents(mcp, client)
    register_upload(mcp, client)
    register_health(mcp, client)

    return mcp


def run() -> None:
    """Start the MCP server in stdio transport mode (P0 primary transport).

    Blocks until the MCP client disconnects or the process is killed.
    All config is read from env vars — see :mod:`andish_mcp.config`.

    MCP stdio transport requires stdout to carry only JSON-RPC frames.
    We redirect structlog output to stderr here so that any log statements
    in the startup path do not corrupt the JSON-RPC stream.
    """
    import structlog as _structlog  # noqa: PLC0415 — local import to avoid top-level side-effect

    _structlog.configure(
        processors=[
            _structlog.processors.TimeStamper(fmt="iso"),
            _structlog.dev.ConsoleRenderer(colors=False),
        ],
        wrapper_class=_structlog.BoundLogger,
        context_class=dict,
        logger_factory=_structlog.PrintLoggerFactory(file=sys.stderr),
    )

    build_server().run(transport="stdio")
