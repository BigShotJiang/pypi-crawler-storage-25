import os
from copy import deepcopy
from typing import Protocol, get_args

from hocon.constants import ANY_VALUE_TYPE, ROOT_TYPE, UNDEFINED, Undefined
from hocon.exceptions import (
    HOCONSubstitutionCycleError,
    HOCONSubstitutionUndefinedError,
)
from hocon.strings import QuotedString
from hocon.unresolved import ANY_UNRESOLVED, UnresolvedSubstitution

from ._self_reference import cut_self_reference_and_fields_that_override_it
from ._substitution import Substitution, SubstitutionStatus


class Resolver(Protocol):
    """SubstitutionResolver should receive an object with this method set."""

    def resolve(self, values: ANY_VALUE_TYPE | ANY_UNRESOLVED) -> ANY_VALUE_TYPE | Undefined: ...


class SubstitutionResolver:
    """The only resolver that needs the entire config tree to perform correctly.

    Example:
    parsed = parse("{value: 42, sub: ${value}}")
    resolve_sub = SubstitutionResolver(parsed, Resolver(parsed))
    resolve_sub(parsed["sub"][0]) ---> 42

    """

    def __init__(
        self,
        parsed: ROOT_TYPE,
        resolver: Resolver,
        substitutions: dict[int, Substitution] | None = None,
    ) -> None:
        self._parsed: ROOT_TYPE = parsed
        self.resolver = resolver
        self.subs: dict[int, Substitution] = substitutions or {}

    def __call__(self, substitution: UnresolvedSubstitution) -> ANY_VALUE_TYPE | Undefined:
        cached_sub = self.subs.get(substitution.id_, Substitution())
        if cached_sub.status.is_resolved:
            return cached_sub.value
        if cached_sub.status == SubstitutionStatus.RESOLVING:
            cached_sub.status = SubstitutionStatus.FALLBACK_UNRESOLVED
            result = self.resolve_substitution_fallback(substitution)
            self.subs[substitution.id_] = Substitution(value=result, status=SubstitutionStatus.RESOLVED)
            return result
        self._turn_to_resolving_state(substitution, cached_sub.status)
        subvalue = self._try_resolve(substitution)
        if self.subs[substitution.id_].status.is_resolved:
            return self.subs[substitution.id_].value

        self.subs[substitution.id_] = Substitution(value=subvalue, status=SubstitutionStatus.RESOLVED)
        return subvalue

    def _try_resolve(self, substitution: UnresolvedSubstitution) -> ANY_VALUE_TYPE | Undefined:
        value: ANY_VALUE_TYPE | ANY_UNRESOLVED | Undefined = self._parsed
        for key in substitution.keys:
            if isinstance(value, get_args(ANY_UNRESOLVED)):
                value = self.resolver.resolve(value)
            if isinstance(value, dict) and key in value:
                value = value[key]
            elif isinstance(value, list) and key.isdigit() and len(value) > int(key):
                value = value[int(key)]
            elif isinstance(value, (dict, list)):
                if substitution.including_root:
                    substitution.keys = substitution.including_root + substitution.keys
                    substitution.including_root = []
                    self.subs.pop(substitution.id_)
                    value = self(substitution)
                else:
                    value = self._resolve_sub_from_env(substitution)
        if isinstance(value, (dict, list)):
            value = self.resolver.resolve(value)
        if isinstance(value, UnresolvedSubstitution):
            value = self(value)
        return value

    def _turn_to_resolving_state(self, substitution: UnresolvedSubstitution, status: SubstitutionStatus) -> None:
        new_status = status.to_resolving()
        if new_status is None:
            msg = f"Could not resolve {substitution}"
            raise HOCONSubstitutionCycleError(msg)
        self.subs[substitution.id_] = Substitution(status=new_status)

    def _resolve_sub_from_env(self, substitution: UnresolvedSubstitution) -> ANY_VALUE_TYPE | Undefined:
        resolved_sub = get_from_env(substitution)
        if resolved_sub.status == SubstitutionStatus.UNDEFINED and substitution.optional is False:
            resolving_status = self.subs[substitution.id_].status
            if resolving_status == SubstitutionStatus.FALLBACK_RESOLVING and substitution.keys not in [
                substitution.location,
                substitution.relative_location,
            ]:
                msg = f"Cycle occurred when resolving {substitution}"
                raise HOCONSubstitutionCycleError(msg)
            msg = f"Could not resolve substitution {substitution}"
            raise HOCONSubstitutionUndefinedError(msg)
        self.subs[substitution.id_] = resolved_sub
        return resolved_sub.value

    def resolve_substitution_fallback(self, substitution: UnresolvedSubstitution) -> ANY_VALUE_TYPE | Undefined:
        """In case of self-referencial substitutions, try to resolve them by removing the self-reference.

        Then, resolve the nodes after the removed self-reference.
        For example for:

        a : { a : { c : 1 } }
        b : 1
        a : ${a.a}
        a : { a : 2 }
        b : 5

        the substitution ${a.a} will be attempted to resolve with the following object:
        a : { a : { c : 1 } }
        b : 1
        b : 5
        and ultimately will return {c:1}
        """
        orig_parsed = self._parsed
        carved_parsed = cut_self_reference_and_fields_that_override_it(substitution, deepcopy(self._parsed))
        self._parsed = carved_parsed
        result = self(substitution)
        self._parsed = orig_parsed
        return result


def get_from_env(substitution: UnresolvedSubstitution) -> Substitution:
    env_value: str | None = os.getenv(".".join(substitution.keys))
    if env_value is None:
        return Substitution(value=UNDEFINED, status=SubstitutionStatus.UNDEFINED)
    return Substitution(value=QuotedString(env_value), status=SubstitutionStatus.RESOLVED)
