"""ClaudeBoost MCP Server — Prompt enhancement for Claude Code."""

__version__ = "0.3.0"
