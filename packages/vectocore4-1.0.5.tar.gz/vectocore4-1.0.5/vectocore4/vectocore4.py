from __future__ import annotations

from typing import Any, Dict, List, Optional, Literal, Union, Iterator
import json
import requests
from typing import TypedDict


XFinderDocType = Literal["text", "image", "video"]
XFinderModeType = Literal["vector", "keyword", "hybrid"]
LensModelType = Literal["5.1chat", "5chat", "4o", "mini"]

DEFAULT_BASE_URL = "https://vectocore-prod-apim.azure-api.net/external/post"

from typing import Optional, List

def json_auto_complete(json_string: str) -> Optional[str]:
    """
    스트리밍 chunk가 덜 닫힌 JSON일 때 닫아주는 보정기.
    (TS의 jsonAutoComplete와 동일 컨셉)
    """
    if not json_string:
        return None

    stack: List[str] = []
    is_inside_string = False
    is_escaped = False

    for ch in json_string:
        if is_escaped:
            is_escaped = False
            continue

        if ch == "\\":
            is_escaped = True
            continue

        if ch == '"':
            is_inside_string = not is_inside_string
            continue

        if not is_inside_string:
            if ch == "{":
                stack.append("}")
            elif ch == "[":
                stack.append("]")
            elif ch in ("}", "]"):
                if stack and stack[-1] == ch:
                    stack.pop()

    result = json_string.strip()

    # 1) 문자열이 열린 채로 끝났다면 따옴표 닫기
    if is_inside_string:
        result += '"'

    # 2) trailing comma 제거 (줄 끝 콤마)
    result = result.rstrip()
    if result.endswith(","):
        result = result[:-1]

    # 3) key: 로 끝나면 null
    if result.endswith(":"):
        result += "null"

    # 4) 남은 괄호 닫기
    for closing in reversed(stack):
        if closing == "]" and result.endswith(","):
            result = result[:-1]
        result += closing

    return result

# -----------------------------
# Exception
# -----------------------------
class VectocoreError(RuntimeError):
    pass


# -----------------------------
# Base Client
# -----------------------------
class _BaseClient:
    def __init__(
        self,
        tenant_key: str,
        base_url: Optional[str] = None,
    ):
        if not tenant_key:
            raise ValueError("tenant_key는 필수입니다.")

        self.base_url = base_url or DEFAULT_BASE_URL

        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "x-tenant-key": tenant_key,
        })

    def _post_json(self, payload: Dict[str, Any]) -> Any:
        resp = self._session.post(
            self.base_url,
            data=json.dumps(payload, ensure_ascii=False),
        )

        if not resp.ok:
            try:
                err = resp.json()
            except Exception:
                err = {}
            raise VectocoreError(
                err.get("message") or f"API 요청 실패: {resp.status_code} ({resp.reason})"
            )

        return resp.json()

    def _post_stream(self, payload: Dict[str, Any]) -> requests.Response:
        resp = self._session.post(
            self.base_url,
            data=json.dumps(payload, ensure_ascii=False),
            stream=True,
        )

        if not resp.ok:
            try:
                err = resp.json()
            except Exception:
                err = {}
            raise VectocoreError(
                err.get("message") or f"API 요청 실패: {resp.status_code} ({resp.reason})"
            )

        return resp

class ExtremeDocBody(TypedDict, total=False):
    id: str
    keywords: str
    data: str
    doc_type: XFinderDocType
    image_url: str
    metadata: Any
    ref_only_text: bool
    tags: List[str]

# -----------------------------
# Vectocore (X-Finder)
# -----------------------------
class Vectocore(_BaseClient):

    # Index
    def put_index(self, index_name: str, description: str = "") -> Any:
        return self._post_json({
            "command": "put_index",
            "params": {
                "index_name": index_name,
                "description": description,
            }
        })

    def delete_index(self, index_name: str) -> Any:
        return self._post_json({
            "command": "delete_index",
            "params": {"index_name": index_name}
        })

    def list_index(self) -> Any:
        return self._post_json({"command": "list_index"})

    # Document
    def put_extreme_data(
        self,
        index_name: str,
        doc_body: ExtremeDocBody,
    ) -> Any:

        doc_body = {
            "doc_type": "text",
            "ref_only_text": False,
            "tags": [],
            **doc_body,   # 사용자가 준 값이 우선
        }

        return self._post_json({
            "command": "put_extreme_data",
            "params": {
                "index_name": index_name,
                "doc_body": doc_body
            }
        })
    
    def get_extreme_data(
        self,
        index_name: str,
        document_id: str,
    ) -> Any:

        return self._post_json({
            "command": "get_extreme_data",
            "params": {
                "index_name": index_name,
                "document_id": document_id
            }
        })
    
    def list_extreme_data(
        self,
        index_name: str,
        last_key: Optional[str] = None,
        with_vector_value: bool = False,
    ) -> Any:
        """
        인덱스에 저장된 지식 데이터를 페이징 단위로 조회합니다.

        :param index_name: 조회할 인덱스 이름 (필수)
        :param last_key: 이전 응답에서 받은 페이징 토큰
        :param with_vector_value: 벡터값 포함 여부 (기본값 False)
        """

        params: Dict[str, Any] = {
            "index_name": index_name,
            "with_vector_value": with_vector_value,
        }

        if last_key:
            params["last_key"] = last_key

        return self._post_json({
            "command": "list_extreme_data",
            "params": params
        })
    
    def list_all_extreme_data(
        self,
        index_name: str,
        with_vector_value: bool = False,
    ) -> Any:
        """
        인덱스에 저장된 모든 지식 데이터를 조회합니다.

        :param index_name: 조회할 인덱스 이름 (필수)
        :param with_vector_value: 벡터값 포함 여부 (기본값 False)
        """

        return self._post_json({
            "command": "list_all_extreme_data",
            "params": {
                "index_name": index_name,
                "with_vector_value": with_vector_value,
            }
        })
    
    def delete_extreme_data(
        self,
        index_name: str,
        document_id: str,
    ) -> Any:
        """
        문서를 삭제합니다.

        :param index_name: 삭제할 문서가 저장된 인덱스 이름
        :param document_id: 삭제할 문서 ID
        """

        return self._post_json({
            "command": "delete_extreme_data",
            "params": {
                "index_name": index_name,
                "document_id": document_id,
            }
        })

    def extreme_search(
        self,
        question: str,
        index_names: Optional[List[str]] = None,
        mode: XFinderModeType = "vector",
        top: int = 10,
        rerank: bool = False,
        tags: Optional[List[str]] = None,
    ) -> Any:

        return self._post_json({
            "command": "extreme_search",
            "params": {
                "mode": mode,
                "index_names": index_names or [],
                "question": question,
                "top": top,
                "rerank": rerank,
                "tags": tags or [],
            }
        })

    def web_search(self, question: str) -> Any:
        return self._post_json({
            "command": "web_search",
            "params": {"question": question}
        })


# -----------------------------
# Lens (Chat)
# -----------------------------
class Lens(_BaseClient):

    def chat(
        self,
        question: str,
        stream: bool = True,
        model: LensModelType = "4o",
        xfinder: Optional[Dict[str, Any]] = None,
        web_search: Optional[Dict[str, Any]] = None,
        agentic: Optional[Dict[str, Any]] = None,
        image_urls: Optional[List[str]] = None,
        file_urls: Optional[List[Dict[str, Any]]] = None,
        custom_context: Optional[Dict[str, Any]] = None,
        session_key: Optional[str] = None,
        max_his_count: Optional[int] = None,
        with_status: Optional[bool] = None,
        static_info: Any = None,
        custom_system_prompt: Optional[str] = None,
    ) -> Union[Any, requests.Response]:

        params: Dict[str, Any] = {
            "question": question,
            "stream": stream,
            "model": model,
        }

        if xfinder:
            params["xfinder"] = xfinder
        if web_search:
            params["web_search"] = web_search
        if agentic:
            params["agentic"] = agentic
        if image_urls:
            params["image_urls"] = image_urls
        if file_urls:
            params["file_urls"] = file_urls
        if custom_context:
            params["custom_context"] = custom_context
        if session_key:
            params["session_key"] = session_key
        if max_his_count is not None:
            params["max_his_count"] = max_his_count
        if with_status is not None:
            params["with_status"] = with_status
        if static_info is not None:
            params["static_info"] = static_info
        if custom_system_prompt:
            params["custom_system_prompt"] = custom_system_prompt

        payload = {
            "command": "lens_chat",
            "params": params
        }

        if stream:
            return self._post_stream(payload)
        return self._post_json(payload)

    @staticmethod
    def json_auto_complete(json_string: str) -> Optional[str]:
        return json_auto_complete(json_string)

# -----------------------------
# AIMS
# -----------------------------
class AIMS(_BaseClient):

    def keypoint(self, text: str, stream: bool = True):
        payload = {
            "command": "keywords",
            "params": {"text": text, "stream": stream}
        }
        return self._post_stream(payload) if stream else self._post_json(payload)

    def im_cap(self, image_url: str, stream: bool = True):
        payload = {
            "command": "im_cap",
            "params": {"image_url": image_url, "stream": stream}
        }
        return self._post_stream(payload) if stream else self._post_json(payload)

    def translate(self, language: str, text: str, stream: bool = True):
        payload = {
            "command": "translate",
            "params": {
                "language": language,
                "text": text,
                "stream": stream
            }
        }
        return self._post_stream(payload) if stream else self._post_json(payload)

    @staticmethod
    def json_auto_complete(json_string: str) -> Optional[str]:
        return json_auto_complete(json_string)

# -----------------------------
# Streaming helper
# -----------------------------
def iter_sse_lines(resp: requests.Response) -> Iterator[str]:
    for raw in resp.iter_lines(decode_unicode=True):
        if raw:
            yield raw
