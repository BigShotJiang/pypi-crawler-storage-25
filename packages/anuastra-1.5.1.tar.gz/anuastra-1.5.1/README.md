# 🌌 Aṇu Astra: Official Python SDK

The official Python SDK for the **Aṇu Astra Virtual Quantum Processor (VQP)**. This SDK provides a high-level interface for quantum circuit execution, post-quantum cryptography (PQC), quantum random number generation (QRNG), and quantum key distribution (QKD).

---

## 🚀 Quick Start

### **1. Installation**
```bash
pip install anuastra
```

### **2. Basic Usage**
```python
from anuastra import AnuAstra, QuantumCircuit

# 🔑 Initialize the Client
client = AnuAstra(api_key="your_astra_key")

# 🧬 Create a Quantum Circuit
qc = QuantumCircuit(2)
qc.h(0).cx(0, 1) # Create entanglement (Bell State)

# 🚀 Execute on the VQP
result = client.execute_quantum(qc, shots=1024)
print(f"Result: {result}")
```

---

## 🛠️ Features

### **Quantum Execution**
- **Native Circuit Builder**: Fluent API similar to Qiskit/Cirq.
- **OpenQASM 2.0**: Submit raw QASM strings for execution.
- **Audit Ledger**: Every execution is signed and verifiable.

### **Post-Quantum Cryptography (PQC)**
- **ML-KEM (Kyber)**: Integrated FIPS 203 support for key encapsulation.
- **ML-DSA (Dilithium)**: Hybrid-ready digital signatures.

### **Quantum Infrastructure**
- **QRNG**: High-entropy bits, bytes, and integers.
- **QKD**: BB84 and E91 physical protocol simulation.

---

## 🏛️ Enterprise Advantages
*   **Immutable Audit Ledger**: Every transaction is recorded on an Ed25519-signed ledger.
*   **Compliance Ready**: Includes transaction IDs and verification URLs for every request.
*   **Hybrid Execution**: Local PQC key generation with server-side encapsulation.

---
**© 2026 CryptoPIX Aṇu Astra. The Future of Decentralized Intelligence.**
