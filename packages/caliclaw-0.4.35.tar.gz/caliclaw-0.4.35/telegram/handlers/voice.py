"""Voice-mode toggle: /voice on | /voice off | /voice status.

Writes a flag file at `~/caliclaw/data/state/voice_mode` (contents `on`
or absent). The agent (Ares) reads this file at the start of every turn
and, if enabled, additionally renders the reply as a Telegram voice note
via skills/telegram-voice/send_voice.py.

The bot itself only manages the flag — actual voice synthesis is the
agent's responsibility (so the agent can condense / strip markdown for
TTS-friendly output instead of TTS-ing raw responses).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

if TYPE_CHECKING:
    from telegram.bot import CaliclawBot

logger = logging.getLogger(__name__)
router = Router()


def _state_file(bot: "CaliclawBot") -> Path:
    return bot.settings.data_dir / "state" / "voice_mode"


def _is_on(bot: "CaliclawBot") -> bool:
    f = _state_file(bot)
    if not f.exists():
        return False
    try:
        return f.read_text().strip().lower() == "on"
    except Exception:
        return False


def _set(bot: "CaliclawBot", on: bool) -> None:
    f = _state_file(bot)
    f.parent.mkdir(parents=True, exist_ok=True)
    if on:
        f.write_text("on\n")
    elif f.exists():
        f.unlink()


def register(bot: "CaliclawBot") -> None:
    bot.dp.include_router(router)

    @router.message(Command("voice"))
    async def cmd_voice(message: Message) -> None:
        if not bot._check_allowed(message):
            return

        text = (message.text or "").strip()
        parts = text.split(maxsplit=1)
        arg = parts[1].strip().lower() if len(parts) > 1 else "status"

        if arg in ("on", "1", "true", "yes", "y", "вкл"):
            _set(bot, True)
            await message.answer(
                "🔊 Voice-mode: ON\n"
                "Now Ares will also send a voice note alongside text replies.\n"
                "Use /voice off to disable."
            )
            logger.info("voice-mode ON by user %s", message.from_user.id if message.from_user else "?")
        elif arg in ("off", "0", "false", "no", "n", "выкл"):
            _set(bot, False)
            await message.answer("🔇 Voice-mode: OFF — text-only replies.")
            logger.info("voice-mode OFF by user %s", message.from_user.id if message.from_user else "?")
        elif arg == "status":
            on = _is_on(bot)
            await message.answer(f"voice-mode is {'🔊 ON' if on else '🔇 OFF'}\n\nUsage: /voice on | /voice off")
        else:
            await message.answer(
                "Unknown arg. Usage:\n"
                "  /voice on    — enable voice replies\n"
                "  /voice off   — disable\n"
                "  /voice       — show current status"
            )
