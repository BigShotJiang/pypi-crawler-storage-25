# Content Pipeline Skill

## When to Use
When generating content for the AI model persona (Mia). Handles:
- Daily content planning (reels, stories, posts)
- Image generation via ComfyUI on VPS
- Video reel composition (Ken Burns, text overlays, music)
- Wan2.1 I2V video generation (image-to-video animation)
- Story arc management
- Music library management

## Architecture

```
content_pipeline/
├── scenario_engine.py    # Generates daily plans, story arcs, scene prompts
├── video_composer.py     # FFmpeg-based video composition (text, music, transitions)
├── wan_video_gen.py      # Wan2.1 I2V/T2V via ComfyUI API on VPS
├── music_manager.py      # Background music generation & library
├── pipeline.py           # Full orchestrator (scenario → images → video → publish)
├── test_e2e.py           # End-to-end test
├── music/                # Generated music library (9 mood tracks)
├── scripts/              # Generated daily plans (JSON)
├── output/               # Generated content
│   ├── videos/           # Wan I2V outputs
│   ├── stories/          # Story images
│   └── test_reel/        # Test outputs
└── templates/            # Reusable templates
```

## Persona: Mia
- 24yo, Brazilian-European, Miami-based fitness model
- Full persona config: agents/scenario_writer/persona.json
- Content pillars: fitness(25%), lifestyle(30%), fashion(20%), travel(15%), personal(10%)
- Story arcs: fitness_challenge(30d), travel_adventure(7d), relationship_tease(14d)

## Usage

### Generate Daily Plan
```bash
python3 content_pipeline/scenario_engine.py          # Single day
python3 content_pipeline/scenario_engine.py week      # Full week
python3 content_pipeline/scenario_engine.py week travel_adventure  # With arc
```

### Generate Music Library
```bash
python3 content_pipeline/music_manager.py             # All moods, 15s each
python3 content_pipeline/music_manager.py generate-all 30  # 30s tracks
python3 content_pipeline/music_manager.py list        # Show library
```

### Full Pipeline
```bash
python3 content_pipeline/pipeline.py --day 1 --plan-only        # Plan only
python3 content_pipeline/pipeline.py --day 1 --arc fitness_challenge  # Full run
python3 content_pipeline/pipeline.py --week --plan-only          # Week of plans
```

### Video Composition
```python
from content_pipeline.video_composer import VideoComposer
composer = VideoComposer()
# Image → Video with Ken Burns
composer.image_to_video("photo.jpg", "clip.mp4", duration=3.0, zoom="in")
# Add text overlay
composer.add_text_overlay("clip.mp4", "out.mp4", text="Hello ✨", position="bottom")
# Add music
composer.add_music("video.mp4", "final.mp4", "music.mp3", volume=0.4)
```

### Wan2.1 I2V (Image-to-Video)
```bash
python3 content_pipeline/wan_video_gen.py test        # Test connection
python3 content_pipeline/wan_video_gen.py check       # Check downloads
python3 content_pipeline/wan_video_gen.py i2v photo.jpg "woman walking on beach"
```

## VPS Models
- **Wan2.1-I2V-14B-480P** (GGUF Q4_K_S, 9.8GB) — Image to video
- **Z-Image Turbo** — Fast image generation
- **CLIP Vision** (ViT-H/14) — For I2V conditioning
- **Qwen 3 4B** — Text encoder for Wan
- **VAE** (ae.safetensors) — Video/image decoding

## Reel Templates (9 types)
morning_routine, gym_workout, beach_day, getting_ready, cooking_healthy,
travel_arrival, night_out, self_care_day, bikini_try_on

## Music Moods (9 tracks)
upbeat_morning, energetic_workout, chill_tropical, glam_transformation,
feel_good, adventure, club_vibes, soft_ambient, fun_pop
