#!/usr/bin/env python3
"""Send a voice message to Tor via the caliclaw Telegram bot.

Pipeline:
    text → edge-tts (free Microsoft Neural voice, Russian)
         → opus-encoded OGG (Telegram's native voice-note format)
         → aiogram.Bot.send_voice(chat_id, voice=FSInputFile)

Usage:
    # text from arg
    python send_voice.py "Привет, я готов"
    # text from stdin (handy for piping)
    echo "Длинный текст" | python send_voice.py

Env (read from /home/atlant/caliclaw/.env):
    TELEGRAM_BOT_TOKEN     — bot token
    TELEGRAM_ALLOWED_USERS — comma-separated chat ids (uses the FIRST one)

Optional flags:
    --voice  ru-RU-DmitryNeural | ru-RU-SvetlanaNeural    (default Dmitry)
    --rate   "+0%" / "+10%" / "-15%" (speech rate)        (default +0%)
    --pitch  "+0Hz" / "+5Hz" / "-10Hz"                    (default +0Hz)
    --chat   <chat_id>   override
"""
from __future__ import annotations

import argparse
import asyncio
import os
import sys
import tempfile
from pathlib import Path

import edge_tts
from aiogram import Bot
from aiogram.types import FSInputFile


def _load_env(env_file: Path) -> dict[str, str]:
    """Tiny .env parser — avoids dotenv dependency for this small script."""
    out: dict[str, str] = {}
    if not env_file.exists():
        return out
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip("'").strip('"')
        out[k.strip()] = v
    return out


async def synthesize(text: str, *, voice: str, rate: str, pitch: str, out: Path) -> None:
    communicate = edge_tts.Communicate(text=text, voice=voice, rate=rate, pitch=pitch)
    await communicate.save(str(out))


async def send_voice(token: str, chat_id: int, audio_path: Path, *, caption: str | None = None) -> None:
    bot = Bot(token=token)
    try:
        await bot.send_voice(
            chat_id=chat_id,
            voice=FSInputFile(audio_path),
            caption=caption,
        )
    finally:
        await bot.session.close()


async def amain(args: argparse.Namespace) -> int:
    env = _load_env(Path("/home/atlant/caliclaw/.env"))
    token = os.environ.get("TELEGRAM_BOT_TOKEN") or env.get("TELEGRAM_BOT_TOKEN", "")
    if not token:
        print("[FATAL] TELEGRAM_BOT_TOKEN missing", file=sys.stderr)
        return 2

    chat_id = args.chat
    if chat_id is None:
        allowed = (env.get("TELEGRAM_ALLOWED_USERS") or os.environ.get("TELEGRAM_ALLOWED_USERS") or "").strip()
        if not allowed:
            print("[FATAL] TELEGRAM_ALLOWED_USERS missing and --chat not provided", file=sys.stderr)
            return 2
        chat_id = int(allowed.split(",")[0].strip())

    text = args.text
    if not text:
        text = sys.stdin.read().strip()
    if not text:
        print("[FATAL] no text provided (arg or stdin)", file=sys.stderr)
        return 2
    if len(text) > 4000:
        print(f"[WARN] text length {len(text)} truncated to 4000", file=sys.stderr)
        text = text[:4000]

    with tempfile.NamedTemporaryFile(suffix=".ogg", delete=False) as tmp:
        out_path = Path(tmp.name)

    try:
        await synthesize(text, voice=args.voice, rate=args.rate, pitch=args.pitch, out=out_path)
        size_kb = out_path.stat().st_size / 1024
        print(f"[ok] synthesized {size_kb:.1f} KB → {out_path}", file=sys.stderr)

        await send_voice(token, chat_id, out_path, caption=args.caption)
        print(f"[ok] sent to chat {chat_id}", file=sys.stderr)
        return 0
    finally:
        try:
            out_path.unlink()
        except OSError:
            pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("text", nargs="?", default="", help="Text to speak (omit to read from stdin)")
    ap.add_argument("--voice", default="ru-RU-DmitryNeural",
                    choices=["ru-RU-DmitryNeural", "ru-RU-SvetlanaNeural"])
    ap.add_argument("--rate", default="+0%", help="Speech rate, e.g. +10% or -15%")
    ap.add_argument("--pitch", default="+0Hz", help="Speech pitch, e.g. +5Hz or -10Hz")
    ap.add_argument("--caption", default=None, help="Optional text caption attached to the voice message")
    ap.add_argument("--chat", type=int, default=None, help="Override chat_id")
    args = ap.parse_args()
    return asyncio.run(amain(args))


if __name__ == "__main__":
    sys.exit(main())
