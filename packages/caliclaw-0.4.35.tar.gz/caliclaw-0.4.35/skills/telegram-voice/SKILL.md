---
name: telegram-voice
description: Send a voice message to Tor via Telegram. Use when Tor explicitly asks for a voice reply (driving, hands busy, can't read screen). Generates Russian Neural TTS via edge-tts (free, no API key) and posts as a native Telegram voice note (OGG/Opus).
version: "1.0.0"
---

# telegram-voice

Sends a voice message to Tor via the running caliclaw Telegram bot.

## When to use

There are TWO ways voice gets triggered:

### 1) Persistent voice-mode (most common — the `/voice` toggle)

**State file**: `~/caliclaw/data/state/voice_mode` (contents `on` or absent).

Tor toggles the bot command:
- `/voice on`  → state file written, all subsequent agent replies should also
                 be sent as voice
- `/voice off` → flag cleared, back to text-only
- `/voice`     → shows current status

**Channel guard — read FIRST, before checking voice_mode**:

The env var `$CALICLAW_CHANNEL` tells you which surface started this turn:
- `telegram` — message came from TG bot (default)
- `cli`      — message came from `caliclaw chat` TUI
- `scheduler` — autonomous task (no human waiting on a channel)

**If `$CALICLAW_CHANNEL` is anything other than `telegram`, IGNORE voice_mode
and reply with text in your stdout — do NOT run send_voice.py.** Sending a
TG voice when Tor is at the terminal is wrong: he's looking at the TUI, not
at his phone, and the TUI shows nothing.

```bash
# Combined check — only do TG voice if BOTH are true:
[ "$CALICLAW_CHANNEL" = "telegram" ] && \
  [ "$(cat /home/atlant/caliclaw/data/state/voice_mode 2>/dev/null)" = "on" ] && \
  echo "VOICE ON"
```

If `on`:
- Send the reply as a **voice message ONLY** via `send_voice.py`
- Do NOT also dump a full text reply in the chat — Tor explicitly asked for
  voice-only when this mode is on (he can't read at the wheel; text just
  clutters his screen)
- The agent's text response in the chat must be MINIMAL — at most one short
  acknowledgment line so the chat history stays scannable later. No markdown
  walls, no code blocks, no tables.
- Voice content: TTS-friendly (no markdown, no emoji, no code blocks). Speak
  the actual answer — don't summarize what you would have said in text. The
  voice IS the response.

If `off` (file missing or contents not `on`): text-only as before, no voice.

### 2) Ad-hoc voice request (one-shot)

Even with voice-mode OFF, send a voice if Tor explicitly asks in this turn:
- "ответь голосом"
- "голосом", "голосовухой", "voice"
- "за рулём — голосом"
- "не пиши, наговори"
- "дай голосовуху", "voice please"

This is a one-time override — does NOT change the state file.

## Output style for voice

Text-to-speech is read literally. Plan accordingly:
- **Conversational sentences**, not markdown. No code blocks. No bullet points.
  Convert lists to "первое… второе… третье…" form.
- **Numbers spelled out** when ambiguous (TTS handles `25` fine but pronounces
  `0.001` poorly — say "одна тысячная").
- **Latin technical terms** are acceptable; the Russian voice handles them OK.
  If a term is critical and might mispronounce, transliterate (e.g. "юдиэти"
  for "USDT" — but usually not necessary).
- **Skip verbose status reports**. Voice should be the *headline* (3–8 sentences).
  If detail matters, send the voice + a short text follow-up summary.
- **No emojis, no decorative chars** (`✓`, `→`, `═`) — TTS reads them aloud or
  garbles them.

## How to invoke

Single command. Pass the text as an argument or pipe via stdin.

```bash
# Short voice — text as argument (single quotes, escape inner quotes if any)
python3 /home/atlant/caliclaw/skills/telegram-voice/send_voice.py \
  "Депозит подтверждён, тысяча двести пятьдесят сом зачислены."

# Long voice — pipe via stdin (avoids shell-escape headaches)
echo "Свободный текст с переносами и любым контентом" | \
  python3 /home/atlant/caliclaw/skills/telegram-voice/send_voice.py
```

Defaults: voice `ru-RU-DmitryNeural` (male, neutral), rate `+0%`, pitch `+0Hz`.
Sends to the first id in `TELEGRAM_ALLOWED_USERS` from `~/caliclaw/.env`
(Tor's chat).

## Optional flags

| flag | values | when |
|---|---|---|
| `--voice` | `ru-RU-DmitryNeural` (M, default) / `ru-RU-SvetlanaNeural` (F) | gender preference |
| `--rate`  | `-50%` … `+50%` | speed up for routine status, slow down for technical detail |
| `--pitch` | `-20Hz` … `+20Hz` | rarely needed |
| `--caption` | any text | optional sub-caption shown under the voice in Telegram |
| `--chat`  | int | override chat_id (debug only) |

## After sending

The script prints `[ok] sent to chat <id>` to stderr.
Always include the same content as a text message in the chat too unless Tor
explicitly says "только голосом" — text message is your primary communication
medium and stays scrollable in history.

## Failure modes

- **No bot token / chat_id**: script prints `[FATAL]` and exits 2. Check
  `TELEGRAM_BOT_TOKEN` and `TELEGRAM_ALLOWED_USERS` in `~/caliclaw/.env`.
- **edge-tts upstream timeout**: rare, retry once. The script is sync so a
  hung HTTP call shows as a delay; abort with Ctrl-C if it stalls > 30s.
- **Telegram API limits**: bots can send ~30 voice msgs/min to a single chat.
  In practice you'll never hit this — voice is a one-off, not a stream.

## Notes for future sessions

- File: `send_voice.py` is self-contained (no internal imports).
- Output format is OGG/Opus, which is Telegram's native voice format — sends
  as a real voice note (not a music file), shows the typical waveform UI.
- TTS audio gets written to a tempfile under `/tmp/`, deleted on exit.
- Russian voices are limited to Dmitry (M) and Svetlana (F); Microsoft adds
  more sometimes — re-list with:
  `python3 -c "import asyncio,edge_tts; asyncio.run((lambda: print([v['Name'] for v in (await edge_tts.VoicesManager.create()).find(Locale='ru-RU')]))())"`
- For English / mixed messages, switch voice to `en-US-ChristopherNeural` or
  similar — Russian voices DO speak English words but with a thick accent.
