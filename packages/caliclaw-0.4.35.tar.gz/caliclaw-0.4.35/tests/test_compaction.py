"""Tests for /squeeze compaction.

The key invariant: after compaction, `claude_session_id` is None and
`summary` holds a verbatim replay of recent messages so the bot's
existing handoff path picks it up on the next turn.
"""
from __future__ import annotations

import pytest


# ── core.handoff ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_lossless_handoff_chronological(db):
    from core.handoff import build_lossless_handoff

    await db.create_session("s1", "main")
    await db.save_message(role="user", content="first user msg", session_id="s1")
    await db.save_message(role="assistant", content="first reply", session_id="s1")
    await db.save_message(role="user", content="second user msg", session_id="s1")
    await db.save_message(role="assistant", content="second reply", session_id="s1")

    handoff = await build_lossless_handoff(db, "s1")
    # Chronological order
    assert handoff.index("first user msg") < handoff.index("first reply")
    assert handoff.index("first reply") < handoff.index("second user msg")
    assert handoff.index("second user msg") < handoff.index("second reply")
    assert "User: first user msg" in handoff
    assert "Assistant: second reply" in handoff


@pytest.mark.asyncio
async def test_lossless_handoff_strips_image_paths(db):
    from core.handoff import build_lossless_handoff

    await db.create_session("s1", "main")
    await db.save_message(
        role="user",
        content="check /workspace/media/photo_123_abc.jpg please",
        session_id="s1",
    )

    handoff = await build_lossless_handoff(db, "s1")
    assert "photo_123_abc.jpg" not in handoff
    assert "[image previously shared]" in handoff


@pytest.mark.asyncio
async def test_lossless_handoff_respects_char_budget(db):
    from core.handoff import build_lossless_handoff

    await db.create_session("s1", "main")
    # 10 messages of ~200 chars each = 2KB total
    for i in range(10):
        await db.save_message(
            role="user", content=f"msg{i} " + "x" * 200, session_id="s1",
        )

    handoff = await build_lossless_handoff(db, "s1", char_budget=500)
    # Budget enforced, so handoff is small but contains the *most recent* msgs
    assert len(handoff) < 1500
    # Newest messages preserved (msg9 is the last one written)
    assert "msg9" in handoff


@pytest.mark.asyncio
async def test_lossless_handoff_empty_session(db):
    from core.handoff import build_lossless_handoff

    await db.create_session("s1", "main")
    handoff = await build_lossless_handoff(db, "s1")
    assert handoff == ""


# ── ConversationCompactor.check_and_compact ──────────────────────────


@pytest.mark.asyncio
async def test_compactor_force_runs_below_threshold(db, settings):
    """force=True must compact even with just a few messages.

    Without force, the threshold (100 msgs) skips small sessions —
    that path stays for auto-compact, but `/squeeze` always honors intent.
    """
    from intelligence.compaction import ConversationCompactor

    await db.create_session("s1", "main")
    await db.update_session("s1", claude_session_id="claude-abc")
    for i in range(5):
        await db.save_message(role="user", content=f"hello {i}", session_id="s1")

    compactor = ConversationCompactor(db)
    ran = await compactor.check_and_compact("s1", force=True)
    assert ran is True

    session = await db.get_session("s1")
    # Claude-side session was dropped — bloat goes with it
    assert session["claude_session_id"] is None
    # Verbatim handoff staged in summary for next-turn injection
    assert session["summary"]
    assert "hello 0" in session["summary"]
    assert "hello 4" in session["summary"]
    assert session["status"] == "compacted"


@pytest.mark.asyncio
async def test_compactor_skips_below_threshold_without_force(db, settings):
    from intelligence.compaction import ConversationCompactor

    await db.create_session("s1", "main")
    await db.update_session("s1", claude_session_id="claude-abc")
    for i in range(5):
        await db.save_message(role="user", content=f"hi {i}", session_id="s1")

    compactor = ConversationCompactor(db)
    ran = await compactor.check_and_compact("s1", force=False)
    assert ran is False

    # Untouched
    session = await db.get_session("s1")
    assert session["claude_session_id"] == "claude-abc"
    assert not session["summary"]


@pytest.mark.asyncio
async def test_compactor_archives_to_disk(db, settings):
    from intelligence.compaction import ConversationCompactor

    await db.create_session("s1", "main")
    await db.save_message(role="user", content="archive me", session_id="s1")

    compactor = ConversationCompactor(db)
    await compactor.check_and_compact("s1", force=True)

    archives = list((settings.workspace_dir / "conversations").glob("*.md"))
    assert any("archive me" in a.read_text() for a in archives)


# ── DreamingEngine ────────────────────────────────────────────────────


class _FakePool:
    """Captures pool.run() inputs and returns a canned response."""

    def __init__(self, response: str = "## Decisions\n- ship dreamer fix\n"):
        self.response = response
        self.last_config = None
        self.last_prompt = None

    async def run(self, config, prompt):
        from core.agent import AgentResult
        self.last_config = config
        self.last_prompt = prompt
        return AgentResult(
            text=self.response, session_id="fake", duration_ms=0,
            exit_code=0, error=None,
        )


@pytest.mark.asyncio
async def test_dreamer_skips_when_below_threshold(db, settings):
    """A quiet day shouldn't waste haiku tokens or write empty digests."""
    from intelligence.compaction import DreamingEngine
    import time

    await db.create_session("s1", "main")
    # 3 messages — below MIN_MESSAGES_TO_DREAM (5)
    for i in range(3):
        await db.save_message(role="user", content=f"q{i}", session_id="s1")

    pool = _FakePool()
    engine = DreamingEngine(db, pool)
    today = time.strftime("%Y-%m-%d")
    result = await engine.dream(target_date=today)

    assert "Skipped" in result or "below threshold" in result
    assert pool.last_prompt is None  # never called the LLM
    assert not list(settings.memory_dir.glob("dream_*.md"))


@pytest.mark.asyncio
async def test_dreamer_reads_sqlite_writes_memory(db, settings):
    """Above threshold: reads day's messages, writes memory/dream_<date>.md."""
    from intelligence.compaction import DreamingEngine
    import time

    await db.create_session("s1", "main")
    for i in range(7):
        role = "user" if i % 2 == 0 else "assistant"
        await db.save_message(role=role, content=f"msg{i}", session_id="s1")

    pool = _FakePool(response="## Decisions\n- learned X\n## User & Project notes\n- Y\n")
    engine = DreamingEngine(db, pool)
    today = time.strftime("%Y-%m-%d")
    result = await engine.dream(target_date=today)

    # LLM was called with a transcript that contains the messages
    assert pool.last_prompt is not None
    assert "msg0" in pool.last_prompt
    assert "msg6" in pool.last_prompt
    # User messages tagged U, assistant tagged A (token-saving prefixes)
    assert "U: msg0" in pool.last_prompt
    assert "A: msg1" in pool.last_prompt
    # Haiku — daily summary doesn't need sonnet
    assert pool.last_config.model == "haiku"

    # Memory file written + indexed
    dream_file = settings.memory_dir / f"dream_{today.replace('-', '_')}.md"
    assert dream_file.exists()
    assert "learned X" in dream_file.read_text()

    index = (settings.memory_dir / "MEMORY.md").read_text()
    assert f"Dream {today}" in index

    assert "learned X" in result


@pytest.mark.asyncio
async def test_dreamer_only_includes_target_date(db, settings):
    """Messages outside the target date must NOT leak into the digest."""
    from intelligence.compaction import DreamingEngine
    import time

    await db.create_session("s1", "main")

    # Stamp `timestamp` directly so we can place messages on a specific
    # day. db.save_message uses time.time(), which we can't time-travel.
    today_ts = time.time()
    yday_ts = today_ts - 86400 * 2  # 2 days ago, well outside target

    for i, ts in enumerate([today_ts] * 6 + [yday_ts] * 6):
        label = "today" if ts == today_ts else "old"
        await db.db.execute(
            "INSERT INTO messages (role, content, session_id, timestamp) "
            "VALUES (?, ?, ?, ?)",
            ("user", f"day-{label}-{i}", "s1", ts),
        )
    await db.db.commit()

    pool = _FakePool()
    engine = DreamingEngine(db, pool)
    today = time.strftime("%Y-%m-%d", time.localtime(today_ts))
    await engine.dream(target_date=today)

    transcript = pool.last_prompt
    assert "day-today" in transcript
    assert "day-old" not in transcript
