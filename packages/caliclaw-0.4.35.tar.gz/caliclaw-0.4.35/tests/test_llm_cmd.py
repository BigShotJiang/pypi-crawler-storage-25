"""Tests for `caliclaw llm` CLI command and AgentProcess env injection."""
from __future__ import annotations

import pytest


# ── _upsert_env / _get_env ────────────────────────────────────────────


def test_upsert_env_appends_when_missing(tmp_path):
    from cli.commands.llm import _upsert_env, _get_env

    (tmp_path / ".env").write_text("TELEGRAM_BOT_TOKEN=abc\n")
    _upsert_env(tmp_path, "ANTHROPIC_BASE_URL", "https://openrouter.ai/api/v1")

    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == "https://openrouter.ai/api/v1"
    assert "TELEGRAM_BOT_TOKEN=abc" in (tmp_path / ".env").read_text()


def test_upsert_env_replaces_existing(tmp_path):
    from cli.commands.llm import _upsert_env, _get_env

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://old.example.com\n"
        "TELEGRAM_BOT_TOKEN=abc\n"
    )
    _upsert_env(tmp_path, "ANTHROPIC_BASE_URL", "https://new.example.com")

    content = (tmp_path / ".env").read_text()
    assert "https://old.example.com" not in content
    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == "https://new.example.com"
    assert "TELEGRAM_BOT_TOKEN=abc" in content


def test_upsert_env_removes_when_value_none(tmp_path):
    """Passing None deletes the key — used by `caliclaw llm anthropic` reset."""
    from cli.commands.llm import _upsert_env, _get_env

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://openrouter.ai/api/v1\n"
        "ANTHROPIC_AUTH_TOKEN=sk-or-secret\n"
        "TELEGRAM_BOT_TOKEN=abc\n"
    )
    _upsert_env(tmp_path, "ANTHROPIC_BASE_URL", None)
    _upsert_env(tmp_path, "ANTHROPIC_AUTH_TOKEN", None)

    content = (tmp_path / ".env").read_text()
    assert "ANTHROPIC_BASE_URL" not in content
    assert "ANTHROPIC_AUTH_TOKEN" not in content
    assert "TELEGRAM_BOT_TOKEN=abc" in content
    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == ""


def test_get_env_no_file(tmp_path):
    from cli.commands.llm import _get_env
    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == ""


# ── _apply_anthropic ──────────────────────────────────────────────────


def test_apply_anthropic_clears_both_keys(tmp_path, monkeypatch):
    from cli.commands.llm import _apply_anthropic

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://openrouter.ai/api/v1\n"
        "ANTHROPIC_AUTH_TOKEN=sk-or-xxx\n"
        "TELEGRAM_BOT_TOKEN=abc\n"
    )
    _apply_anthropic(tmp_path)

    content = (tmp_path / ".env").read_text()
    assert "ANTHROPIC_BASE_URL" not in content
    assert "ANTHROPIC_AUTH_TOKEN" not in content
    assert "TELEGRAM_BOT_TOKEN=abc" in content


# ── AgentProcess._build_env ──────────────────────────────────────────


def test_build_env_no_override(settings, monkeypatch):
    """Without provider config, env passes through unchanged."""
    from core.agent import AgentProcess, AgentConfig

    # Ensure no inherited env from the host
    monkeypatch.delenv("ANTHROPIC_BASE_URL", raising=False)
    monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert "ANTHROPIC_BASE_URL" not in env
    assert "ANTHROPIC_AUTH_TOKEN" not in env


def test_build_env_overlays_settings(settings, monkeypatch):
    """When settings carry a base URL / token, they land in subprocess env."""
    from core.agent import AgentProcess, AgentConfig

    settings.anthropic_base_url = "https://openrouter.ai/api/v1"
    settings.anthropic_auth_token = "sk-or-test"

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert env["ANTHROPIC_BASE_URL"] == "https://openrouter.ai/api/v1"
    assert env["ANTHROPIC_AUTH_TOKEN"] == "sk-or-test"


def test_build_env_inherits_parent(settings, monkeypatch):
    """Parent env (PATH, HOME, etc.) is inherited so claude CLI keeps working."""
    from core.agent import AgentProcess, AgentConfig

    monkeypatch.setenv("CALICLAW_CANARY_TEST", "yes")

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert env.get("CALICLAW_CANARY_TEST") == "yes"
    assert "PATH" in env


# ── per-tier model override (native Claude Code env vars) ────────────


def test_build_env_forwards_tier_overrides(settings):
    """ANTHROPIC_DEFAULT_*_MODEL env vars are forwarded to the subprocess."""
    from core.agent import AgentProcess, AgentConfig

    settings.anthropic_base_url = "https://openrouter.ai/api/v1"
    settings.anthropic_default_haiku_model = "deepseek/deepseek-chat"
    settings.anthropic_default_sonnet_model = "anthropic/claude-sonnet-4.5"
    settings.anthropic_default_opus_model = "anthropic/claude-opus-4.5"

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert env["ANTHROPIC_DEFAULT_HAIKU_MODEL"] == "deepseek/deepseek-chat"
    assert env["ANTHROPIC_DEFAULT_SONNET_MODEL"] == "anthropic/claude-sonnet-4.5"
    assert env["ANTHROPIC_DEFAULT_OPUS_MODEL"] == "anthropic/claude-opus-4.5"


def test_build_env_omits_tier_overrides_when_unset(settings, monkeypatch):
    """Unset overrides do NOT appear in the subprocess env (so CC keeps its default)."""
    from core.agent import AgentProcess, AgentConfig

    monkeypatch.delenv("ANTHROPIC_DEFAULT_HAIKU_MODEL", raising=False)
    monkeypatch.delenv("ANTHROPIC_DEFAULT_SONNET_MODEL", raising=False)
    monkeypatch.delenv("ANTHROPIC_DEFAULT_OPUS_MODEL", raising=False)

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert "ANTHROPIC_DEFAULT_HAIKU_MODEL" not in env
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL" not in env
    assert "ANTHROPIC_DEFAULT_OPUS_MODEL" not in env


def test_build_command_passes_alias_through(settings):
    """`--model` carries the bare alias; CC remaps internally via env vars."""
    from core.agent import AgentProcess, AgentConfig

    settings.anthropic_base_url = "https://openrouter.ai/api/v1"
    settings.anthropic_default_sonnet_model = "anthropic/claude-sonnet-4.5"

    proc = AgentProcess(AgentConfig(name="t", model="sonnet"), settings=settings)
    cmd = proc._build_command("hello")
    idx = cmd.index("--model")
    assert cmd[idx + 1] == "sonnet"


def test_apply_anthropic_clears_tier_overrides(tmp_path):
    """Reset to anthropic-direct removes per-tier model env-var lines too."""
    from cli.commands.llm import _apply_anthropic

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://openrouter.ai/api/v1\n"
        "ANTHROPIC_AUTH_TOKEN=sk-or-xxx\n"
        "ANTHROPIC_DEFAULT_HAIKU_MODEL=deepseek/deepseek-chat\n"
        "ANTHROPIC_DEFAULT_SONNET_MODEL=anthropic/claude-sonnet-4.5\n"
        "ANTHROPIC_DEFAULT_OPUS_MODEL=anthropic/claude-opus-4.5\n"
        "TELEGRAM_BOT_TOKEN=abc\n"
    )
    _apply_anthropic(tmp_path)

    content = (tmp_path / ".env").read_text()
    assert "ANTHROPIC_BASE_URL" not in content
    assert "ANTHROPIC_AUTH_TOKEN" not in content
    assert "ANTHROPIC_DEFAULT_HAIKU_MODEL" not in content
    assert "ANTHROPIC_DEFAULT_SONNET_MODEL" not in content
    assert "ANTHROPIC_DEFAULT_OPUS_MODEL" not in content
    assert "TELEGRAM_BOT_TOKEN=abc" in content


def test_apply_openrouter_writes_api_key_empty_and_subagent(tmp_path):
    """OR docs: ANTHROPIC_API_KEY="" prevents shadowing; SUBAGENT_MODEL=opus."""
    from cli.commands.llm import _apply_openrouter, _get_env

    _apply_openrouter(tmp_path, "sk-or-test")

    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == "https://openrouter.ai/api"
    # Literal `""` characters land in .env (pydantic parses them away)
    assert _get_env(tmp_path, "ANTHROPIC_API_KEY") == '""'
    assert _get_env(tmp_path, "CLAUDE_CODE_SUBAGENT_MODEL") == "anthropic/claude-opus-4.7"


def test_build_env_forwards_empty_api_key(settings):
    """Empty-string API_KEY must propagate so it shadows an inherited key."""
    from core.agent import AgentProcess, AgentConfig

    # Simulate: parent shell has a leftover ANTHROPIC_API_KEY from `claude login`
    import os
    os.environ["ANTHROPIC_API_KEY"] = "sk-ant-leftover"
    try:
        settings.anthropic_base_url = "https://openrouter.ai/api"
        settings.anthropic_auth_token = "sk-or-test"
        settings.anthropic_api_key = ""  # explicit empty, not None

        proc = AgentProcess(AgentConfig(name="t"), settings=settings)
        env = proc._build_env()

        assert env["ANTHROPIC_API_KEY"] == ""  # overridden, not the leftover
        assert env["ANTHROPIC_AUTH_TOKEN"] == "sk-or-test"
    finally:
        os.environ.pop("ANTHROPIC_API_KEY", None)


def test_build_env_omits_api_key_when_none(settings, monkeypatch):
    """None means 'don't touch' — let the parent env's API_KEY through."""
    from core.agent import AgentProcess, AgentConfig

    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-from-parent")
    settings.anthropic_api_key = None

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert env["ANTHROPIC_API_KEY"] == "sk-ant-from-parent"


def test_apply_anthropic_clears_deepseek_extras(tmp_path):
    """Reset also strips DeepSeek-specific routing knobs (ANTHROPIC_MODEL etc.)."""
    from cli.commands.llm import _apply_anthropic

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic\n"
        "ANTHROPIC_AUTH_TOKEN=sk-deepseek-xxx\n"
        "ANTHROPIC_MODEL=deepseek-v4-pro[1m]\n"
        "CLAUDE_CODE_SUBAGENT_MODEL=deepseek-v4-flash\n"
        "CLAUDE_CODE_EFFORT_LEVEL=max\n"
        "TELEGRAM_BOT_TOKEN=abc\n"
    )
    _apply_anthropic(tmp_path)

    content = (tmp_path / ".env").read_text()
    assert "ANTHROPIC_MODEL" not in content
    assert "CLAUDE_CODE_SUBAGENT_MODEL" not in content
    assert "CLAUDE_CODE_EFFORT_LEVEL" not in content
    assert "TELEGRAM_BOT_TOKEN=abc" in content


# ── DeepSeek preset ───────────────────────────────────────────────────


def test_apply_deepseek_writes_full_env_block(tmp_path, monkeypatch):
    """`caliclaw llm deepseek <key>` writes BASE_URL + AUTH + 3 routing knobs.

    Tier defaults are written non-interactively via _prompt_tier_models when
    stdin isn't a TTY (the path tests run under).
    """
    from cli.commands.llm import _apply_deepseek, _get_env

    _apply_deepseek(tmp_path, "sk-deepseek-test")

    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == "https://api.deepseek.com/anthropic"
    assert _get_env(tmp_path, "ANTHROPIC_AUTH_TOKEN") == "sk-deepseek-test"
    assert _get_env(tmp_path, "ANTHROPIC_MODEL") == "deepseek-v4-pro[1m]"
    assert _get_env(tmp_path, "CLAUDE_CODE_SUBAGENT_MODEL") == "deepseek-v4-flash"
    assert _get_env(tmp_path, "CLAUDE_CODE_EFFORT_LEVEL") == "max"
    # Tier defaults written non-interactively
    assert _get_env(tmp_path, "ANTHROPIC_DEFAULT_HAIKU_MODEL") == "deepseek-v4-flash"
    assert _get_env(tmp_path, "ANTHROPIC_DEFAULT_SONNET_MODEL") == "deepseek-v4-pro[1m]"
    assert _get_env(tmp_path, "ANTHROPIC_DEFAULT_OPUS_MODEL") == "deepseek-v4-pro[1m]"


def test_apply_openrouter_clears_deepseek_extras(tmp_path):
    """Switching from DeepSeek → OpenRouter must drop the DeepSeek-only knobs.

    Otherwise ANTHROPIC_MODEL=deepseek-v4-pro would bleed into OR requests
    and OR would 4xx on an unknown model.
    """
    from cli.commands.llm import _apply_openrouter, _get_env

    (tmp_path / ".env").write_text(
        "ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic\n"
        "ANTHROPIC_AUTH_TOKEN=sk-deepseek-old\n"
        "ANTHROPIC_MODEL=deepseek-v4-pro[1m]\n"
        "CLAUDE_CODE_SUBAGENT_MODEL=deepseek-v4-flash\n"
        "CLAUDE_CODE_EFFORT_LEVEL=max\n"
    )
    _apply_openrouter(tmp_path, "sk-or-newtoken")

    assert _get_env(tmp_path, "ANTHROPIC_BASE_URL") == "https://openrouter.ai/api"
    assert _get_env(tmp_path, "ANTHROPIC_AUTH_TOKEN") == "sk-or-newtoken"
    # OR's docs require ANTHROPIC_API_KEY="" (explicit empty, not absent)
    assert _get_env(tmp_path, "ANTHROPIC_API_KEY") == '""'
    # OR preset overwrites SUBAGENT_MODEL with its own opus default rather
    # than nulling it — the var is shared across presets, not DS-specific.
    assert _get_env(tmp_path, "CLAUDE_CODE_SUBAGENT_MODEL") == "anthropic/claude-opus-4.7"
    assert _get_env(tmp_path, "ANTHROPIC_MODEL") == ""
    assert _get_env(tmp_path, "CLAUDE_CODE_EFFORT_LEVEL") == ""


def test_build_env_forwards_deepseek_extras(settings):
    """ANTHROPIC_MODEL, CLAUDE_CODE_SUBAGENT_MODEL, CLAUDE_CODE_EFFORT_LEVEL forward."""
    from core.agent import AgentProcess, AgentConfig

    settings.anthropic_base_url = "https://api.deepseek.com/anthropic"
    settings.anthropic_model = "deepseek-v4-pro[1m]"
    settings.claude_code_subagent_model = "deepseek-v4-flash"
    settings.claude_code_effort_level = "max"

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert env["ANTHROPIC_MODEL"] == "deepseek-v4-pro[1m]"
    assert env["CLAUDE_CODE_SUBAGENT_MODEL"] == "deepseek-v4-flash"
    assert env["CLAUDE_CODE_EFFORT_LEVEL"] == "max"


def test_build_env_omits_deepseek_extras_when_unset(settings, monkeypatch):
    """Unset extras don't appear in subprocess env (so CC's defaults stand)."""
    from core.agent import AgentProcess, AgentConfig

    monkeypatch.delenv("ANTHROPIC_MODEL", raising=False)
    monkeypatch.delenv("CLAUDE_CODE_SUBAGENT_MODEL", raising=False)
    monkeypatch.delenv("CLAUDE_CODE_EFFORT_LEVEL", raising=False)

    proc = AgentProcess(AgentConfig(name="t"), settings=settings)
    env = proc._build_env()

    assert "ANTHROPIC_MODEL" not in env
    assert "CLAUDE_CODE_SUBAGENT_MODEL" not in env
    assert "CLAUDE_CODE_EFFORT_LEVEL" not in env
