"""Credential vault — Fernet-encrypted storage for social media secrets.

The vault key lives at VAULT_KEY_PATH (0600 perms, atlant-only). Social-media
passwords and TOTP secrets are Fernet-encrypted before being persisted to
caliclaw.db.social_accounts.

Contract:
    >>> from core.vault import encrypt, decrypt, mask
    >>> blob = encrypt("hunter2")     # -> bytes (bytes-safe for BLOB column)
    >>> decrypt(blob)                 # -> "hunter2"
    >>> mask("hunter2")               # -> "hu***n2" (for UI, never leaks full)

Design notes:
- Fernet = AES-128-CBC + HMAC-SHA256, with key rotation hooks if we add
  MultiFernet later.
- The key NEVER appears in DB, logs, reports, or git. A missing key raises —
  we never auto-generate it on read; it must be explicitly initialised.
- For dev convenience, `ensure_key()` generates the key on first boot.
"""
from __future__ import annotations

import os
import stat
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

VAULT_DIR = Path("/home/atlant/caliclaw/vault")
VAULT_KEY_PATH = VAULT_DIR / ".vault_key"

_cached_fernet: Fernet | None = None


def ensure_key() -> Path:
    """Create the vault key on first use. No-op if it already exists."""
    VAULT_DIR.mkdir(parents=True, exist_ok=True)
    if not VAULT_KEY_PATH.exists():
        key = Fernet.generate_key()
        VAULT_KEY_PATH.write_bytes(key)
        os.chmod(VAULT_KEY_PATH, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    else:
        # Re-assert 0600 in case someone chmod'd it
        mode = VAULT_KEY_PATH.stat().st_mode & 0o777
        if mode != 0o600:
            os.chmod(VAULT_KEY_PATH, stat.S_IRUSR | stat.S_IWUSR)
    return VAULT_KEY_PATH


def _fernet() -> Fernet:
    global _cached_fernet
    if _cached_fernet is None:
        ensure_key()
        _cached_fernet = Fernet(VAULT_KEY_PATH.read_bytes())
    return _cached_fernet


def encrypt(plaintext: str | None) -> bytes | None:
    """Encrypt a string. None passes through."""
    if plaintext is None or plaintext == "":
        return None
    return _fernet().encrypt(plaintext.encode("utf-8"))


def decrypt(blob: bytes | None) -> str | None:
    """Decrypt a Fernet blob. None / empty passes through. Corrupt → None."""
    if not blob:
        return None
    try:
        return _fernet().decrypt(blob).decode("utf-8")
    except InvalidToken:
        return None


def mask(plaintext: str | None, show: int = 2) -> str:
    """Return a safe display form: first+last N chars, middle replaced with ***."""
    if not plaintext:
        return ""
    if len(plaintext) <= show * 2:
        return "*" * len(plaintext)
    return f"{plaintext[:show]}***{plaintext[-show:]}"


def is_configured() -> bool:
    return VAULT_KEY_PATH.exists()
