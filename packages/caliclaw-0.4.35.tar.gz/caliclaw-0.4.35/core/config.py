from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from pydantic_settings import BaseSettings
from pydantic import Field, field_validator


_ROOT_CACHE = Path.home() / ".caliclaw" / ".project_root"


def _project_root() -> Path:
    """Resolve project root: env var > saved path > cwd > source checkout > user home."""
    env = os.environ.get("CALICLAW_HOME") or os.environ.get("PROJECT_ROOT")
    if env:
        return Path(env).resolve()
    # Saved from previous init (survives pip upgrades and cwd changes)
    if _ROOT_CACHE.exists():
        saved = Path(_ROOT_CACHE.read_text().strip())
        if saved.exists() and (saved / ".env").exists():
            return saved
    # If cwd has .env or agents/, we're in a caliclaw project
    cwd = Path.cwd()
    if (cwd / ".env").exists() or (cwd / "agents").exists():
        return cwd
    # Source checkout: package sits next to .env or agents/
    pkg_parent = Path(__file__).resolve().parent.parent
    if (pkg_parent / ".env").exists():
        return pkg_parent
    if (pkg_parent / "agents").exists() and (pkg_parent / "skills").exists():
        return pkg_parent
    # Pip install — per-user config dir in ~/.caliclaw
    return Path.home() / ".caliclaw"


def save_project_root(root: Path) -> None:
    """Persist project root so future runs find it from any cwd."""
    _ROOT_CACHE.parent.mkdir(parents=True, exist_ok=True)
    _ROOT_CACHE.write_text(str(root.resolve()))


def bundled_skills_path() -> Path:
    """Return the path to the bundled default skills.

    Works both for source clones (./skills) and pip-installed wheels
    (site-packages/skills).
    """
    # Source checkout — skills are next to the package
    src = Path(__file__).resolve().parent.parent / "skills"
    if src.exists() and any(src.glob("*/SKILL.md")):
        return src
    # Pip install — skills is a subpackage
    try:
        import skills as _skills_pkg
        return Path(_skills_pkg.__file__).resolve().parent
    except ImportError:
        return src


def detect_system_tz() -> str:
    """Auto-detect the IANA timezone name from the host OS. Falls back to UTC."""
    # Debian/Ubuntu
    try:
        tz = Path("/etc/timezone").read_text().strip()
        if tz:
            return tz
    except OSError:
        pass
    # /etc/localtime symlink (most distros, macOS)
    try:
        link = os.readlink("/etc/localtime")
        if "zoneinfo/" in link:
            return link.split("zoneinfo/", 1)[1]
    except OSError:
        pass
    # TZ env var as last resort
    env_tz = os.environ.get("TZ", "").strip()
    if env_tz:
        return env_tz
    return "UTC"


class Settings(BaseSettings):
    model_config = {"env_file": str(_project_root() / ".env"), "extra": "ignore"}

    # Telegram
    telegram_bot_token: str = ""
    telegram_allowed_users: List[int] = Field(default_factory=list)

    @field_validator("telegram_allowed_users", mode="before")
    @classmethod
    def parse_allowed_users(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        if isinstance(v, int):
            return [v]
        return v

    # Engine
    claude_binary: str = "claude"  # legacy alias, kept for backward compat
    claude_default_model: str = "sonnet"
    freedom_mode: bool = False

    # LLM provider routing — when set, every agent subprocess
    # (main agent, haiku image-describer, child agents) runs against
    # this endpoint instead of the default Anthropic API.
    # Use cases:
    #   - OpenRouter: BASE_URL=https://openrouter.ai/api/v1, AUTH_TOKEN=<sk-or-...>
    #   - Custom Anthropic-compatible proxy (claude-code-router, LiteLLM): point at it
    #   - Self-hosted relay: same idea
    # Claude Code natively reads ANTHROPIC_BASE_URL / ANTHROPIC_AUTH_TOKEN
    # from its environment; we just forward them.
    anthropic_base_url: Optional[str] = None
    anthropic_auth_token: Optional[str] = None
    # ANTHROPIC_API_KEY is forwarded distinctly from AUTH_TOKEN: when
    # routing through OR/DS it must be EXPLICITLY EMPTY ("") to override
    # an inherited key from `claude login` or the parent shell. Distinguish
    # "unset" (None — don't forward) from "force empty" ("") with `is not None`.
    anthropic_api_key: Optional[str] = None

    # Per-tier model override — read natively by Claude Code. When set,
    # CC remaps `--model haiku/sonnet/opus` aliases to these concrete
    # model IDs before sending the request. Lets one OpenRouter / CCR
    # proxy serve different models per tier (e.g. haiku→deepseek-v3.1
    # for cheap image describes, sonnet→anthropic/claude-sonnet-4.5 for
    # the main agent). Variable names match Claude Code's native env
    # contract — no in-process remap needed; we just forward to the
    # subprocess.
    anthropic_default_haiku_model: Optional[str] = None
    anthropic_default_sonnet_model: Optional[str] = None
    anthropic_default_opus_model: Optional[str] = None

    # Coarse model-routing knobs that some providers (DeepSeek-direct,
    # certain proxies) want set alongside the per-tier overrides:
    #   ANTHROPIC_MODEL           — fallback model when CC doesn't pick a tier
    #   CLAUDE_CODE_SUBAGENT_MODEL — model used by built-in subagents
    #   CLAUDE_CODE_EFFORT_LEVEL  — provider-specific reasoning depth ("max", …)
    # All optional; only forwarded when set.
    anthropic_model: Optional[str] = None
    claude_code_subagent_model: Optional[str] = None
    claude_code_effort_level: Optional[str] = None

    # MCP — Model Context Protocol servers. Path to a JSON config with
    # `{"mcpServers": {...}}` shape. Forwarded to every agent subprocess
    # via `--mcp-config`. Lets Telegram agents reach Chrome DevTools,
    # Playwright, Filesystem, GitHub, etc.
    # Default: <project_root>/mcp.json. File doesn't have to exist — the
    # flag is only added when the file is present, so an empty install
    # silently skips MCP without breaking anything.
    mcp_config_path: Path = Field(
        default_factory=lambda: _project_root() / "mcp.json"
    )

    @property
    def engine_binary(self) -> str:
        """Path to the caliclaw engine wrapper."""
        wrapper = self.project_root / "bin" / "caliclaw-engine"
        if wrapper.exists():
            return str(wrapper)
        return self.claude_binary

    # Paths
    project_root: Path = Field(default_factory=_project_root)
    data_dir: Path = Field(default_factory=lambda: _project_root() / "data")
    workspace_dir: Path = Field(default_factory=lambda: _project_root() / "workspace")
    agents_dir: Path = Field(default_factory=lambda: _project_root() / "agents")
    skills_dir: Path = Field(default_factory=lambda: _project_root() / "skills")
    memory_dir: Path = Field(default_factory=lambda: _project_root() / "memory")

    # Limits
    max_concurrent_agents: int = 3

    # Heartbeat cron expressions
    heartbeat_quick_cron: str = "0 */2 * * *"
    heartbeat_review_cron: str = "0 */6 * * *"
    heartbeat_morning_cron: str = "0 9 * * *"
    heartbeat_dream_cron: str = "0 3 * * *"

    # Auto-backup
    backup_enabled: bool = False
    backup_interval_days: int = 7  # weekly by default

    # Whisper
    whisper_cpp_path: str = "/usr/local/bin/whisper-cpp"
    whisper_model_path: str = str(_project_root() / "models" / "ggml-base.bin")

    # Obsidian integration (optional). When set, caliclaw can read from /
    # write structured notes into the user's Obsidian vault.
    obsidian_vault_path: Optional[Path] = None
    obsidian_daily_notes_dir: str = "Daily"     # subdir inside vault
    obsidian_inbox_dir: str = "Inbox/caliclaw"  # where bot writes new notes

    # Dashboard
    dashboard_port: int = 8080
    dashboard_enabled: bool = True

    # Timezone
    tz: str = "Europe/Moscow"

    # Logging
    log_level: str = "INFO"

    def ensure_dirs(self) -> None:
        for d in (
            self.data_dir,
            self.workspace_dir,
            self.workspace_dir / "conversations",
            self.workspace_dir / "media",
            self.workspace_dir / "ipc",
            self.workspace_dir / "projects",
            self.agents_dir,
            self.skills_dir,
            self.memory_dir,
            self.project_root / "logs",
        ):
            d.mkdir(parents=True, exist_ok=True)


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reset_settings() -> None:
    global _settings
    _settings = None
