"""caliclaw search — full-text search across all conversation history.

Powered by SQLite FTS5 over the `messages` table. Returns matching messages
with FTS5 highlight snippets, grouped by session, ordered by relevance.

Usage:
    caliclaw search "MCP setup"                # everything
    caliclaw search "telegram" --days 7        # last week only
    caliclaw search "telegram OR slack" -n 50  # OR query, 50 results
    caliclaw search '"exact phrase"'           # phrase query (escape quotes)
    caliclaw search "auth*"                    # prefix match
"""
from __future__ import annotations

import argparse
from datetime import datetime
from typing import Optional

from cli.ui import ui
from core.db import Database


async def cmd_search(args: argparse.Namespace) -> None:
    query = (getattr(args, "query", "") or "").strip()
    if not query:
        ui.fail("Usage: caliclaw search <query> [--days N] [-n LIMIT]")
        return

    limit: int = getattr(args, "limit", 20) or 20
    days: Optional[int] = getattr(args, "days", None)

    db = Database()
    await db.connect()
    try:
        rows = await db.search_messages(query, limit=limit, days=days)
    except Exception as e:  # FTS5 syntax errors land here as OperationalError
        ui.fail(f"Search failed: {e}")
        ui.c.print(
            "[dim]Tip: FTS5 is picky about syntax. Try wrapping in quotes "
            "or simplifying the query.[/dim]"
        )
        await db.close()
        return
    await db.close()

    if not rows:
        ui.info(f"No matches for {query!r}.")
        return

    # Group by session so the user sees context
    by_session: dict[str, list[dict]] = {}
    for r in rows:
        by_session.setdefault(r["session_id"], []).append(r)

    ui.c.print(
        f"[bold]Found {len(rows)} match{'es' if len(rows) != 1 else ''} "
        f"across {len(by_session)} session{'s' if len(by_session) != 1 else ''}[/bold]\n"
    )
    for session_id, hits in by_session.items():
        first_ts = datetime.fromtimestamp(hits[0]["timestamp"]).strftime("%Y-%m-%d %H:%M")
        ui.c.print(f"[bold cyan]session[/bold cyan] [dim]{session_id[:12]}[/dim] [dim]({first_ts})[/dim]")
        for h in hits:
            role_color = "yellow" if h["role"] == "user" else "white"
            ts = datetime.fromtimestamp(h["timestamp"]).strftime("%m-%d %H:%M")
            snippet = h.get("snippet") or h["content"][:200]
            ui.c.print(f"  [{role_color}]{h['role'][0].upper()}[/{role_color}] [dim]{ts}[/dim] {snippet}")
        ui.c.print()
