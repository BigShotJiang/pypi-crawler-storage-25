"""caliclaw user — manage USER.md, the bounded user-identity file.

USER.md is the agent's stable model of who you are: name, role, communication
preferences, hard rules. Hard cap at MAX_USER_CHARS so it stays cache-stable
in the system prompt (caliclaw injects it once per session start).

For ephemeral facts ("user is debugging X today") use MEMORY.md / dream files
instead — those rotate. USER.md is for things that don't change much.

Subcommands:
    show              Print current USER.md
    set [text]        Replace USER.md (from stdin if no arg)
    edit              Open USER.md in $EDITOR
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from cli.ui import ui
from core.config import get_settings


# Cache-stable cap — keeps USER.md from bloating the system-prompt prefix.
# 1500 chars ≈ 400 tokens; a tight identity card, not a biography.
MAX_USER_CHARS = 1500


def _user_path() -> Path:
    return get_settings().memory_dir / "USER.md"


async def cmd_user(args: argparse.Namespace) -> None:
    sub = getattr(args, "user_command", None) or "show"
    path = _user_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    if sub == "show":
        if not path.exists():
            ui.info(f"USER.md not set yet. Path: {path}")
            ui.c.print("\nCreate it with: [bold]caliclaw user set <text>[/bold]")
            ui.c.print("Or edit interactively: [bold]caliclaw user edit[/bold]")
            return
        content = path.read_text(encoding="utf-8")
        ui.c.print(f"[dim]{path}  ({len(content)}/{MAX_USER_CHARS} chars)[/dim]\n")
        ui.c.print(content)
        return

    if sub == "set":
        text = args.text
        if text is None:
            if sys.stdin.isatty():
                ui.c.print("Paste USER.md content. Ctrl-D to finish:")
            text = sys.stdin.read()
        text = (text or "").strip()
        if not text:
            ui.fail("Empty content. Aborting.")
            return
        if len(text) > MAX_USER_CHARS:
            ui.fail(
                f"Too long: {len(text)} chars (max {MAX_USER_CHARS}). "
                f"Trim before saving — USER.md is bounded so it stays cache-stable."
            )
            return
        path.write_text(text + ("\n" if not text.endswith("\n") else ""), encoding="utf-8")
        ui.ok(f"Saved USER.md ({len(text)}/{MAX_USER_CHARS} chars).")
        return

    if sub == "edit":
        editor = os.environ.get("EDITOR", "nano")
        # Use a tempfile copy so a corrupted edit doesn't lose the original
        with tempfile.NamedTemporaryFile(
            mode="w+", suffix=".md", prefix="USER_", delete=False, encoding="utf-8"
        ) as tf:
            if path.exists():
                tf.write(path.read_text(encoding="utf-8"))
            tmp = Path(tf.name)
        try:
            result = subprocess.run([editor, str(tmp)], check=False)
            if result.returncode != 0:
                ui.fail(f"{editor} exited with {result.returncode}, no save.")
                return
            new_content = tmp.read_text(encoding="utf-8").strip()
            if not new_content:
                ui.fail("File empty after edit. Not overwriting USER.md.")
                return
            if len(new_content) > MAX_USER_CHARS:
                ui.fail(
                    f"Too long: {len(new_content)} chars (max {MAX_USER_CHARS}). "
                    f"Original USER.md kept. Re-edit to trim."
                )
                return
            path.write_text(new_content + "\n", encoding="utf-8")
            ui.ok(f"USER.md updated ({len(new_content)}/{MAX_USER_CHARS} chars).")
        finally:
            tmp.unlink(missing_ok=True)
        return

    ui.fail(f"Unknown subcommand: {sub}")
    sys.exit(1)
