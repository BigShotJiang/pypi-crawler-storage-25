#  260429
## nlanskov
- [ ] Bump version to 1.2.0 and publish updated version
- [ ] Verify 1.2.0 concomitants tool version
- [ ] Verify that extractor skill generates concomitants with proper structure format.