# mcp-server-pp

MCP server for PharmaPendium data extraction — converts extraction results to XLSX, expands drug/concomitant rows, and uploads to Azure Blob Storage.

## Tools

### `save_extraction`

Converts a JSON array of extraction results into an XLSX file, uploads it to Azure Blob Storage, and returns a download URL (valid 7 days).

If the user provided corrections or new rules during the extraction session, pass them in `notes` — they are saved as a separate **Notes** sheet inside the XLSX for traceability.

**Parameters:**
- `json_data` (required): JSON array string — extraction results, one object per row
- `file_name` (optional): Output filename (with or without `.xlsx`). Defaults to `extraction_results.xlsx`
- `notes` (optional): User corrections, comments, or new rules applied in this session

### `expand_concomitants`

Takes a JSON array of rows (from the built-in Excel tool) with `Drug Name` and `Concomitants` columns and rotates each drug into the title slot. The `Concomitants` cell is parsed as CT-style free text: drugs separated by `;`, each entry shaped as `Name (aliases), route, dose, dose_comment, duration`. For each input row, emits N+1 rows — the promoted drug's parsed metadata populates `Drug Name`, `Route`, `Dose/Concentration`, `Dose Comment`, and `Treatment Duration`; the displaced drugs are re-serialized back into `Concomitants`. All other columns are copied unchanged. Semicolons inside `(...)` and semicolons followed by non-drug continuations (digits, `or`/`and`, bare units) are preserved within a single drug's metadata; bare-name segments at the start of a chunk are merged as combination-drug components (e.g. `Elexacaftor; Tezacaftor; Ivacaftor (ELX; TEZ; IVA), orally, ...` stays one entry).

**Parameters:**
- `json_data` (required): JSON array string of row objects — read via the built-in Excel tool
- `file_name` (optional): Output filename (with or without `.xlsx`). Defaults to `expanded_results.xlsx`

**Example — one source row becomes three:**

| Drug Name | Route | Dose/Concentration | Concomitants                                              |
|-----------|-------|--------------------|-----------------------------------------------------------|
| DrugA     | oral  | 10 mg              | DrugB, i.v., 5 mg, daily; DrugC, oral, 20 mg, twice daily |

→

| Drug Name | Route | Dose/Concentration | Concomitants                                              |
|-----------|-------|--------------------|-----------------------------------------------------------|
| DrugA     | oral  | 10 mg              | DrugB, i.v., 5 mg, daily; DrugC, oral, 20 mg, twice daily |
| DrugB     | i.v.  | 5 mg               | DrugA, oral, 10 mg; DrugC, oral, 20 mg, twice daily       |
| DrugC     | oral  | 20 mg              | DrugA, oral, 10 mg; DrugB, i.v., 5 mg, daily              |

**Required environment variable:** `AZURE_STORAGE_CONNECTION_STRING`

## Usage

### With uvx (no installation needed)

```bash
uvx mcp-server-pp@1.2.0
```

### MCP client config (e.g. Codemie, Claude Desktop)

```json
{
  "mcpServers": {
    "pp-tools": {
      "command": "uvx",
      "args": ["mcp-server-pp@1.2.0"],
      "env": {
        "AZURE_STORAGE_CONNECTION_STRING": "${AZURE_STORAGE_CONNECTION_STRING}"
      }
    }
  }
}
```
