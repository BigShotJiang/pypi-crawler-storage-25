"""
MCP server providing tools for PharmaPendium data extraction workflows.

Tools:
  - save_extraction: Convert a JSON array into an XLSX file, upload to Azure
                     Blob Storage, and return a download link. Optionally
                     saves user corrections/notes as a separate sheet.
  - expand_concomitants: Expand an XLSX with Drug Name / Concomitants columns
                         so each drug in the combined list gets its own row.

Environment variables (required):
  - AZURE_STORAGE_CONNECTION_STRING: connection string for the storage account.
  - OUTPUT_CONTAINER: blob container name (default: "codemie-output").

Usage:
  uvx mcp-server-pp          # install from PyPI and run (stdio)
  mcp-server-pp              # run directly if installed
  python -m mcp_server_pp    # run as module
"""

import io
import json
import os
import re
from datetime import datetime, timezone
from urllib.parse import quote

import pandas as pd
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    TextContent,
    Tool,
)

server = Server("mcp-server-pp")

XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _json_to_dataframe(json_str: str) -> pd.DataFrame | str:
    """Parse JSON string into a DataFrame. Returns error string on failure."""
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"

    if not isinstance(data, list):
        return "json_data must be a JSON array"

    if len(data) == 0:
        return "JSON array is empty, nothing to convert"

    return pd.DataFrame(data)


def _dataframe_to_xlsx_bytes(df: pd.DataFrame, notes: str | None = None) -> bytes:
    """Convert DataFrame to XLSX bytes. Optionally adds a Notes sheet."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
        if notes:
            notes_ws = writer.book.create_sheet("Notes")
            notes_ws["A1"] = "Extraction Notes"
            for i, line in enumerate(notes.splitlines(), start=2):
                notes_ws.cell(row=i, column=1, value=line)
    buf.seek(0)
    return buf.read()


def _ensure_xlsx_ext(name: str) -> str:
    return name if name.endswith(".xlsx") else name + ".xlsx"


# Column mapping: structured drug field -> row column (CT/AE convention).
DRUG_COLUMNS = {
    "route": "Route",
    "dose": "Dose/Concentration",
    "dose_comment": "Dose Comment",
    "duration": "Treatment Duration",
}

ROUTE_KEYWORDS = (
    "orally", "intravenously", "subcutaneously", "intrathecally",
    "intramuscularly", "topically", "inhaled", "inhalation",
    "sublingually", "rectally", "ophthalmic", "intraperitoneally",
    "intranasally", "per os", "p.o.", "i.v.", "i.m.", "s.c.", "i.th.",
)

CONTINUATION_STOPWORDS = frozenset({
    "or", "and", "if", "during", "through", "throughout", "followed",
    "upon", "then", "as", "with", "before", "after", "plus",
})

UNIT_STOPWORDS = frozenset({"mg", "g", "ug", "µg", "ng", "kg", "ml", "mL", "L", "IU", "U"})

DOSE_RE = re.compile(
    r"""
    ^\s*
    [\d.]+                               # leading number
    (?:\s*-\s*[\d.]+)?                   # optional range
    \s*
    (?:mg|g|ug|µg|ng|kg|mL|ml|L|IU|U|mol|mmol)   # unit
    (?:\s*/\s*(?:m\^?2|m²|kg|day|week|dose))?    # optional rate/ratio
    (?:\s*/\s*[\d.]+\s*(?:mg|g|ug|µg|ng|kg|mL|ml|L|IU|U))*   # combination doses: 200 mg / 100 mg
    \s*$
    """,
    re.VERBOSE | re.IGNORECASE,
)

NAME_RE = re.compile(r"^\s*([^,()]+?)\s*(?:\(([^)]*)\))?\s*(?:,|$)")


def _cell_str(value) -> str:
    """Coerce a pandas cell to a clean string ('' for NaN/None)."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    return str(value).strip()


def _split_top_level(text: str, sep: str) -> list[str]:
    """Split on `sep` only at paren depth 0. Does not interpret content."""
    out, buf, depth = [], [], 0
    for ch in text:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if ch == sep and depth == 0:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        out.append(tail)
    return out


def _split_concomitants(text: str) -> list[str]:
    """
    Split a Concomitants cell into per-drug chunks.

    Splits on `;` at paren depth 0, but only when the following segment looks
    like a new drug entry (starts with a letter, not a stopword/unit). Segments
    that follow a `;` and start with a digit or a continuation word are merged
    back with the previous chunk (handles cases like Methotrexate's internal
    `(part of study group); 12 mg for >= 3 years`).

    Additionally, chunks with no top-level comma (bare drug names like the
    leading components of a combination "A; B; C (abbrev), orally, ...") are
    merged with the following chunk using `;` — the CT convention for
    combination drug names.
    """
    if not text:
        return []

    raw_segments = _split_top_level(text, ";")

    # First pass: merge continuation-style segments back (digit-leading or stopword-leading).
    merged: list[str] = []
    for seg in raw_segments:
        seg = seg.strip()
        if not seg:
            continue
        first_word = re.match(r"\s*([^\s,(]+)", seg)
        token = (first_word.group(1) if first_word else "").rstrip(",")
        looks_like_continuation = (
            seg[:1].isdigit()
            or token.lower() in CONTINUATION_STOPWORDS
            or token in UNIT_STOPWORDS
        )
        if looks_like_continuation and merged:
            merged[-1] = merged[-1] + "; " + seg
        else:
            merged.append(seg)

    # Second pass: merge bare-name segments (combination drug components) forward.
    chunks: list[str] = []
    pending: list[str] = []
    for seg in merged:
        if "," not in _strip_parens(seg):
            pending.append(seg)
        else:
            if pending:
                seg = "; ".join(pending + [seg])
                pending = []
            chunks.append(seg)
    if pending:
        # Trailing bare-name segments with no following metadata — keep as their own chunk.
        chunks.append("; ".join(pending))
    return chunks


def _strip_parens(text: str) -> str:
    """Remove top-level `(...)` groups (for comma detection on the outer skeleton)."""
    out, depth = [], 0
    for ch in text:
        if ch == "(":
            depth += 1
            continue
        if ch == ")":
            depth = max(0, depth - 1)
            continue
        if depth == 0:
            out.append(ch)
    return "".join(out)


def _parse_drug_chunk(chunk: str) -> dict:
    """Parse one drug free-text chunk into a structured dict."""
    chunk = chunk.strip().rstrip(";").strip()
    drug = {"name": "", "aliases": "", "route": "", "dose": "", "dose_comment": "", "duration": ""}
    if not chunk:
        return drug

    m = NAME_RE.match(chunk)
    if not m:
        drug["name"] = chunk
        return drug

    drug["name"] = m.group(1).strip()
    drug["aliases"] = (m.group(2) or "").strip()
    remainder = chunk[m.end():].strip()
    if not remainder:
        return drug

    tokens = [t for t in (s.strip() for s in _split_top_level(remainder, ",")) if t]

    route_idx = dose_idx = duration_idx = None
    for i, tok in enumerate(tokens):
        low = tok.lower()
        if route_idx is None and any(kw in low for kw in ROUTE_KEYWORDS):
            route_idx = i
            continue
        if dose_idx is None and DOSE_RE.match(tok):
            dose_idx = i
            continue
        if duration_idx is None and low.startswith("for "):
            duration_idx = i

    if route_idx is not None:
        drug["route"] = tokens[route_idx]
    if dose_idx is not None:
        drug["dose"] = tokens[dose_idx]
    if duration_idx is not None:
        drug["duration"] = tokens[duration_idx]

    used = {i for i in (route_idx, dose_idx, duration_idx) if i is not None}
    drug["dose_comment"] = ", ".join(t for i, t in enumerate(tokens) if i not in used)
    return drug


def _serialize_drug(drug: dict) -> str:
    """Serialize a drug dict back into CT-style free text."""
    name = drug.get("name", "").strip()
    aliases = drug.get("aliases", "").strip()
    head = f"{name} ({aliases})" if aliases else name
    tail = [drug.get("route", ""), drug.get("dose", ""), drug.get("dose_comment", ""), drug.get("duration", "")]
    parts = [head] + [p.strip() for p in tail if p and p.strip()]
    return ", ".join(parts)


def _structure_title_drug(row: dict) -> dict:
    """Build a drug dict from the row's title columns."""
    name_cell = _cell_str(row.get("Drug Name"))
    aliases = ""
    name = name_cell
    if name_cell:
        m = NAME_RE.match(name_cell + ",")  # force match by appending comma
        if m:
            name = m.group(1).strip()
            aliases = (m.group(2) or "").strip()
    return {
        "name": name,
        "aliases": aliases,
        "route": _cell_str(row.get(DRUG_COLUMNS["route"])),
        "dose": _cell_str(row.get(DRUG_COLUMNS["dose"])),
        "dose_comment": _cell_str(row.get(DRUG_COLUMNS["dose_comment"])),
        "duration": _cell_str(row.get(DRUG_COLUMNS["duration"])),
    }


def _promote_drug(row: dict, drug: dict) -> dict:
    """Write a structured drug into the row's title columns (only columns that exist)."""
    new = dict(row)
    name = drug.get("name", "").strip()
    aliases = drug.get("aliases", "").strip()
    new["Drug Name"] = f"{name} ({aliases})" if aliases else name
    for field, col in DRUG_COLUMNS.items():
        if col in new:
            new[col] = drug.get(field, "")
    return new


def _expand_drug_concomitants(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each row: parse Concomitants into structured drugs, then emit (N+1) rows
    where each output row promotes a different drug (title + N concomitants) into
    the title columns. The displaced drugs are re-serialized back into the
    Concomitants cell as CT-style free text.
    """
    expanded: list[dict] = []
    for _, row in df.iterrows():
        row_dict = row.to_dict()
        title = _structure_title_drug(row_dict)
        concos = [_parse_drug_chunk(c) for c in _split_concomitants(_cell_str(row_dict.get("Concomitants")))]

        if not concos:
            expanded.append(row_dict)
            continue

        all_drugs = [title] + concos
        for i in range(len(all_drugs)):
            promoted = _promote_drug(row_dict, all_drugs[i])
            others = [d for j, d in enumerate(all_drugs) if j != i]
            promoted["Concomitants"] = "; ".join(_serialize_drug(d) for d in others if d.get("name"))
            expanded.append(promoted)
    return pd.DataFrame(expanded)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="save_extraction",
            description=(
                "Convert extraction results (JSON array of objects) into an XLSX file, "
                "upload it to Azure Blob Storage, and return a download URL. "
                "Use this as the mandatory final step of every extraction. "
                "If the user provided corrections, comments, or new rules in this session, "
                "pass them in the notes parameter — they will be saved as a Notes sheet "
                "inside the XLSX for traceability. To apply a correction: update the "
                "json_data to reflect the fix, then call this tool again with the corrected "
                "data and the correction description in notes."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "json_data": {
                        "type": "string",
                        "description": (
                            "A JSON array of extraction result objects. "
                            "Example: '[{\"col1\": \"val1\", \"col2\": 2}, ...]'"
                        ),
                    },
                    "file_name": {
                        "type": "string",
                        "description": (
                            "Output filename (with or without .xlsx extension). "
                            "Defaults to 'extraction_results'."
                        ),
                        "default": "extraction_results",
                    },
                    "notes": {
                        "type": "string",
                        "description": (
                            "Optional. User corrections, comments, or new rules applied "
                            "to this extraction. Saved as a Notes sheet in the XLSX. "
                            "Example: 'User correction: row 3 dose changed from 10mg to 5mg. "
                            "New rule: always use mg/L for plasma concentration units.'"
                        ),
                    },
                },
                "required": ["json_data"],
            },
        ),
        Tool(
            name="expand_concomitants",
            description=(
                "Takes a JSON array of rows with 'Drug Name' and 'Concomitants' columns (read "
                "via the built-in Excel tool). The 'Concomitants' cell is parsed as CT-style "
                "free text: drugs separated by `;`, each entry shaped as "
                "'Name (aliases), route, dose, dose_comment, duration'. For each input row, "
                "emits N+1 output rows by rotating each drug (title + concomitants) into the "
                "title slot: the promoted drug's parsed metadata populates 'Drug Name', 'Route', "
                "'Dose/Concentration', 'Dose Comment', and 'Treatment Duration' columns, while "
                "the displaced drugs are re-serialized back into 'Concomitants' as CT free text. "
                "All other columns are copied unchanged. Semicolons inside `(...)` and semicolons "
                "followed by non-drug continuations (digits, 'or', 'and', units) are preserved "
                "within a single drug's metadata. Uploads the expanded XLSX to Azure Blob Storage "
                "and returns a 7-day SAS download URL."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "json_data": {
                        "type": "string",
                        "description": (
                            "A JSON array of row objects read from the Excel file. "
                            "Each object must have at least 'Drug Name' and 'Concomitants' keys. "
                            "Example: '[{\"Drug Name\": \"Aspirin\", \"Concomitants\": \"Ibuprofen, Warfarin\"}, ...]'"
                        ),
                    },
                    "file_name": {
                        "type": "string",
                        "description": (
                            "Output filename (with or without .xlsx extension). "
                            "Defaults to 'expanded_results'."
                        ),
                        "default": "expanded_results",
                    },
                },
                "required": ["json_data"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list:
    if name == "save_extraction":
        return _handle_save_extraction(arguments)
    elif name == "expand_concomitants":
        return _handle_expand_concomitants(arguments)
    else:
        raise ValueError(f"Unknown tool: {name}")


# ---------------------------------------------------------------------------
# Tool handler
# ---------------------------------------------------------------------------

def _handle_save_extraction(arguments: dict) -> list:
    from azure.storage.blob import BlobSasPermissions, ContentSettings, generate_blob_sas
    from azure.storage.blob import BlobServiceClient

    conn_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING", "")
    if not conn_str:
        return [TextContent(
            type="text",
            text="Error: AZURE_STORAGE_CONNECTION_STRING environment variable is not set.",
        )]

    container_name = os.environ.get("OUTPUT_CONTAINER", "codemie-output")
    json_str = arguments["json_data"]
    file_name = _ensure_xlsx_ext(arguments.get("file_name", "extraction_results"))
    notes = arguments.get("notes")

    result = _json_to_dataframe(json_str)
    if isinstance(result, str):
        return [TextContent(type="text", text=result)]

    df = result
    xlsx_bytes = _dataframe_to_xlsx_bytes(df, notes=notes)

    # Build blob path: YYMMDD-HHMMSS/filename.xlsx
    timestamp = datetime.now(timezone.utc).strftime("%y%m%d-%H%M%S")
    blob_path = f"{timestamp}/{file_name}"

    # Upload to Azure Blob Storage
    blob_service = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
    blob_client.upload_blob(
        xlsx_bytes,
        content_settings=ContentSettings(content_type=XLSX_MIME),
        overwrite=True,
    )

    # Generate SAS download URL (valid for 7 days)
    from datetime import timedelta
    account_name = blob_service.account_name
    account_key = blob_service.credential.account_key

    sas_token = generate_blob_sas(
        account_name=account_name,
        container_name=container_name,
        blob_name=blob_path,
        account_key=account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.now(timezone.utc) + timedelta(days=7),
    )

    download_url = f"https://{account_name}.blob.core.windows.net/{container_name}/{quote(blob_path, safe='/')}?{sas_token}"

    notes_line = "\n\nNotes recorded: yes (see Notes sheet in the file)." if notes else ""

    return [
        TextContent(
            type="text",
            text=(
                f"Created {file_name} with {len(df)} rows and {len(df.columns)} columns."
                f"{notes_line}\n\n"
                f"Uploaded to: `{container_name}/{blob_path}`\n\n"
                f"Download link (valid 7 days): {download_url}"
            ),
        ),
    ]


# ---------------------------------------------------------------------------
# Tool handler: expand_concomitants
# ---------------------------------------------------------------------------

def _handle_expand_concomitants(arguments: dict) -> list:
    from azure.storage.blob import BlobSasPermissions, BlobServiceClient, ContentSettings, generate_blob_sas
    from datetime import timedelta

    conn_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING", "")
    if not conn_str:
        return [TextContent(
            type="text",
            text="Error: AZURE_STORAGE_CONNECTION_STRING environment variable is not set.",
        )]

    result = _json_to_dataframe(arguments["json_data"])
    if isinstance(result, str):
        return [TextContent(type="text", text=result)]
    df = result

    missing = [c for c in ("Drug Name", "Concomitants") if c not in df.columns]
    if missing:
        return [TextContent(
            type="text",
            text=(
                f"Missing required columns: {missing}. "
                f"Found columns: {list(df.columns)}"
            ),
        )]

    expanded = _expand_drug_concomitants(df)
    file_name = _ensure_xlsx_ext(arguments.get("file_name", "expanded_results"))
    xlsx_out = _dataframe_to_xlsx_bytes(expanded)

    container_name = os.environ.get("OUTPUT_CONTAINER", "codemie-output")
    timestamp = datetime.now(timezone.utc).strftime("%y%m%d-%H%M%S")
    blob_path = f"{timestamp}/{file_name}"

    blob_service = BlobServiceClient.from_connection_string(conn_str)
    blob_client = blob_service.get_blob_client(container=container_name, blob=blob_path)
    blob_client.upload_blob(
        xlsx_out,
        content_settings=ContentSettings(content_type=XLSX_MIME),
        overwrite=True,
    )

    sas_token = generate_blob_sas(
        account_name=blob_service.account_name,
        container_name=container_name,
        blob_name=blob_path,
        account_key=blob_service.credential.account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.now(timezone.utc) + timedelta(days=7),
    )

    download_url = (
        f"https://{blob_service.account_name}.blob.core.windows.net"
        f"/{container_name}/{quote(blob_path, safe='/')}?{sas_token}"
    )

    return [TextContent(
        type="text",
        text=(
            f"Expanded {len(df)} source rows → {len(expanded)} rows.\n\n"
            f"Uploaded to: `{container_name}/{blob_path}`\n\n"
            f"Download link (valid 7 days): {download_url}"
        ),
    )]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    import asyncio

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())
