"""Allow running as: python -m mcp_server_pp"""

from mcp_server_pp.server import main

main()
