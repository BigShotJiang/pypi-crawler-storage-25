"""MCP server providing tools for PharmaPendium data extraction workflows."""

from mcp_server_pp.server import main

__all__ = ["main"]
