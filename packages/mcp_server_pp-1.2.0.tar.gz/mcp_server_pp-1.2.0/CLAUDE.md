# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

A minimal MCP (Model Context Protocol) server exposing two tools to AI clients (Codemie, Claude Desktop):
- **`save_extraction`** — converts AI-extracted pharmaceutical data (JSON) into a formatted XLSX and uploads to Azure Blob Storage, returning a 7-day SAS download URL.
- **`expand_concomitants`** — takes a JSON array of rows (read via the built-in Excel tool) with `Drug Name` and `Concomitants` columns. Parses the `Concomitants` cell as CT-style free text (drugs separated by `;`, shape `Name (aliases), route, dose, dose_comment, duration`) and rotates each drug into the title slot: the promoted drug's parsed metadata populates `Drug Name`, `Route`, `Dose/Concentration`, `Dose Comment`, and `Treatment Duration`; the displaced drugs are re-serialized back into `Concomitants`. Uploads the result and returns a download URL.

## Commands

```bash
# Run locally (from source)
uv run mcp-server-pp

# Run from PyPI (no install required)
uvx mcp-server-pp@1.2.0

# Smoke test (sends JSON-RPC messages over stdin, checks tool listing)
make test

# Build + publish to PyPI (requires PYPI_TOKEN in .env)
make publish
```

## Required Environment Variables

- `AZURE_STORAGE_CONNECTION_STRING` — Azure Storage connection string (required at runtime)
- `OUTPUT_CONTAINER` — blob container name (optional, defaults to `codemie-output`)
- `PYPI_TOKEN` — only needed for `make publish`

## Architecture

All logic is in `src/mcp_server_pp/server.py` (~480 lines). Transport is stdio JSON-RPC 2.0 using the `mcp` library's `stdio_server`.

**Tool flow for `save_extraction`:**
1. Receives `json_data` (JSON array string), optional `file_name`, and optional `notes`
2. `_json_to_dataframe()` — parses JSON to `pd.DataFrame`
3. `_dataframe_to_xlsx_bytes()` — writes DataFrame to XLSX in-memory; appends a "Notes" sheet if `notes` is provided
4. Uploads bytes to Azure Blob Storage via `BlobServiceClient`
5. Generates a SAS URL (7-day expiry) and returns it as `TextContent`

**Tool flow for `expand_concomitants`:**
1. Receives `json_data` (JSON array string from the built-in Excel tool) and optional `file_name`
2. `_json_to_dataframe()` — parses JSON to `pd.DataFrame`; validates `Drug Name` and `Concomitants` columns exist
3. `_expand_drug_concomitants()` — for each row:
   - `_structure_title_drug()` builds a drug dict from the title columns (`Drug Name`/`Route`/`Dose/Concentration`/`Dose Comment`/`Treatment Duration`)
   - `_split_concomitants()` smart-splits the Concomitants cell on `;` (paren-aware; skips `;` followed by digits / continuation stopwords / bare units; merges bare-name prefix segments as combination-drug components)
   - `_parse_drug_chunk()` extracts `name`, `aliases`, `route`, `dose`, `dose_comment`, `duration` from each chunk via `NAME_RE` + `ROUTE_KEYWORDS` + `DOSE_RE` heuristics
   - Emits N+1 output rows: each rotation uses `_promote_drug()` to overwrite the title columns with the promoted drug's metadata, and `_serialize_drug()` to re-serialize the remaining drugs back into `Concomitants` as CT free text
4. Converts expanded DataFrame to XLSX, uploads to Azure Blob Storage
5. Generates a SAS URL (7-day expiry) and returns it as `TextContent`

## No Tests Beyond Smoke Test

There is no pytest suite. `make test` pipes raw JSON-RPC through the server binary and checks it responds without error. No linting config exists.
