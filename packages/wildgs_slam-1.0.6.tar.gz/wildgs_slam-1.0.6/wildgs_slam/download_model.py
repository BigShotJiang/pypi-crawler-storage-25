"""Download pretrained model weights for WildGS-SLAM.

Usage:
    python -m wildgs_slam.download_model [--output-dir DIR]
    wildgs-download-model [--output-dir DIR]
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

# droid.pth is hosted on the same Google Drive as the original DROID-SLAM checkpoint.
# Mirror hosted by GradientSpaces for reliability.
_DROID_PTH_URL = "https://drive.google.com/uc?id=1PpqVt1H4maBa_GbPJp4NwxRsd9jk-elh"
_DROID_PTH_FILENAME = "droid.pth"

_DEFAULT_DIR = Path.home() / ".wildgs_slam" / "models"


def _download(url: str, dest: Path) -> None:
    try:
        import gdown
    except ImportError:
        print("Installing gdown for Google Drive download...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "gdown"])
        import gdown  # type: ignore

    print(f"Downloading {dest.name} → {dest}")
    gdown.download(url, str(dest), quiet=False)


def main() -> None:
    parser = argparse.ArgumentParser(description="Download WildGS-SLAM pretrained weights")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=_DEFAULT_DIR,
        help=f"Directory to save model weights (default: {_DEFAULT_DIR})",
    )
    args = parser.parse_args()

    out_dir: Path = args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    droid_dest = out_dir / _DROID_PTH_FILENAME
    if droid_dest.exists():
        print(f"[skip] {droid_dest} already exists.")
    else:
        _download(_DROID_PTH_URL, droid_dest)
        print(f"Saved to {droid_dest}")

    print(f"\nModel weights saved to: {out_dir}")
    print(f"Use --droid-pretrained {droid_dest} when starting the MCP server.")


if __name__ == "__main__":
    main()
