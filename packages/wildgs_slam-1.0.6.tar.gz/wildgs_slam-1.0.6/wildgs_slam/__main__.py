"""Entry point for `python -m wildgs_slam`."""
import os

# Avoid network requests during model loading (torch.hub, timm, huggingface_hub).
# All weights must be pre-cached locally.
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

import sys

import numpy as np
import torch
import argparse
import random

from wildgs_slam import config
from wildgs_slam.slam import SLAM
from wildgs_slam.utils.datasets import get_dataset
from time import gmtime, strftime
from colorama import Fore, Style
from wildgs_slam.utils.debug import dbg, get_debug_log_path


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def main():
    parser = argparse.ArgumentParser(description="WildGS-SLAM: SLAM in dynamic environments")
    parser.add_argument("config", type=str, help="Path to config file.")
    args = parser.parse_args()

    torch.multiprocessing.set_start_method("spawn")

    cfg = config.load_config(args.config)
    dbg(f"argv={sys.argv}", stage="MAIN")
    dbg(f"config_path={args.config}", stage="MAIN")
    dbg(f"debug_log={get_debug_log_path()}", stage="MAIN")
    setup_seed(cfg["setup_seed"])
    if cfg["fast_mode"] and "mapping" in cfg:
        cfg["mapping"]["final_refine_iters"] = 3000

    output_dir = cfg["data"]["output"]
    output_dir = output_dir + f"/{cfg['scene']}"

    start_time = strftime("%Y-%m-%d %H:%M:%S", gmtime())
    start_info = (
        "-" * 30
        + Fore.LIGHTRED_EX
        + f"\nStart WildGS-SLAM at {start_time},\n"
        + Style.RESET_ALL
        + f"   scene: {cfg['dataset']}-{cfg['scene']},\n"
        f"   output: {output_dir}\n"
        + "-" * 30
    )
    print(start_info)

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    config.save_config(cfg, f"{output_dir}/cfg.yaml")
    dbg(
        f"scene={cfg['scene']} dataset={cfg['dataset']} device={cfg['device']} output_dir={output_dir}",
        stage="MAIN",
    )

    dataset = get_dataset(cfg)
    dbg(
        f"dataset_len={len(dataset)} intrinsic={dataset.get_intrinsic().tolist() if hasattr(dataset.get_intrinsic(), 'tolist') else dataset.get_intrinsic()}",
        stage="MAIN",
    )
    slam = SLAM(cfg, dataset)
    slam.run()
    dbg("slam.run completed", stage="MAIN")

    end_time = strftime("%Y-%m-%d %H:%M:%S", gmtime())
    print("-" * 30 + Fore.LIGHTRED_EX + f"\nWildGS-SLAM finishes!\n" + Style.RESET_ALL + f"{end_time}\n" + "-" * 30)


if __name__ == "__main__":
    main()
