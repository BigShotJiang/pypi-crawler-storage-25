"""
Build script for WildGS-SLAM pip package.

Compiles five CUDA extensions:
  - droid_backends          (bundle-adjustment + correlation kernels)
  - lietorch_backends       (Lie-group operations)
  - lietorch_extras         (alt-correlation + SE3 kernels)
  - diff_gaussian_rasterization._C  (Gaussian rasterizer with pose)
  - simple_knn._C           (spatial k-NN)

All CUDA source lives under wildgs_slam/ (renamed from src/) and
wildgs_slam/thirdparty/ (moved from thirdparty/).

NOTE: sources use relative paths (relative to this file) to keep setuptools
happy during manifest/egg-info generation. include_dirs use absolute paths
which is fine for compilation.
"""

import glob
import os
import os.path as osp
import shutil
import sys
import sysconfig
from pathlib import Path

from setuptools import setup, find_namespace_packages

ROOT = osp.dirname(osp.abspath(__file__))

# Map top-level package names to physical source directories. This is also used
# by the prebuilt-extension reuse logic, so keep it near the top of the file.
_PACKAGE_DIR = {
    "lietorch": "wildgs_slam/thirdparty/lietorch/lietorch",
    "diff_gaussian_rasterization": "wildgs_slam/thirdparty/diff_gaussian_rasterization",
    "simple_knn": "simple_knn",
}

NVCC_ARCHES = [
    "-gencode=arch=compute_70,code=sm_70",
    "-gencode=arch=compute_75,code=sm_75",
    "-gencode=arch=compute_80,code=sm_80",
    "-gencode=arch=compute_86,code=sm_86",
    "-gencode=arch=compute_89,code=sm_89",
    "-gencode=arch=compute_90,code=sm_90",
]

ext_modules = []
cmdclass = {}
_BUILDING_SDIST = "sdist" in sys.argv


def _find_prebuilt_extension(fullname: str) -> str | None:
    """Return an existing compiled extension for *fullname* if present.

    This lets `pip install .` reuse already-built CUDA binaries instead of
    recompiling them every time in environments where the `.so` artifacts are
    preserved in the source tree.
    """
    parts = fullname.split(".")
    package_root = parts[0]
    base_dir = _PACKAGE_DIR.get(package_root, package_root)
    stem = parts[-1]

    search_roots: list[Path] = []
    build_roots: list[Path] = []

    if len(parts) == 1:
        # Top-level extensions like droid_backends live directly under ROOT.
        search_roots.append(Path(ROOT))
        build_roots.append(Path(ROOT) / "build" / "lib*")
    else:
        module_path = Path(ROOT) / base_dir
        if len(parts) > 2:
            module_path = module_path.joinpath(*parts[1:-1])
        search_roots.append(module_path)
        build_roots.append(Path(ROOT) / "build" / "lib*" / base_dir)

    install_roots: list[Path] = []
    for key in ("platlib", "purelib"):
        root = sysconfig.get_paths().get(key)
        if root:
            install_roots.append(Path(root))
    for root in sys.path:
        if root:
            install_roots.append(Path(root))

    seen_install_roots: list[Path] = []
    for root in install_roots:
        try:
            resolved = root.expanduser().resolve()
        except Exception:
            continue
        if resolved not in seen_install_roots and resolved.exists():
            seen_install_roots.append(resolved)

    patterns = []
    for root in search_roots + build_roots:
        patterns.extend(
            [
                str(root / f"{stem}*.so"),
                str(root / f"{stem}*.pyd"),
                str(root / f"{stem}*.dylib"),
            ]
        )
    for root in seen_install_roots:
        if len(parts) == 1:
            ext_root = root
        else:
            ext_root = root / base_dir
            if len(parts) > 2:
                ext_root = ext_root.joinpath(*parts[1:-1])
        patterns.extend(
            [
                str(ext_root / f"{stem}*.so"),
                str(ext_root / f"{stem}*.pyd"),
                str(ext_root / f"{stem}*.dylib"),
            ]
        )
    for pattern in patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            return matches[0]
    return None

try:
    from torch.utils.cpp_extension import BuildExtension, CUDAExtension

    # ------------------------------------------------------------------ #
    # 1. droid_backends                                                    #
    # ------------------------------------------------------------------ #
    droid_backends = CUDAExtension(
        name="droid_backends",
        include_dirs=[osp.join(ROOT, "wildgs_slam", "thirdparty", "lietorch", "eigen")],
        sources=[
            "wildgs_slam/lib/droid.cpp",
            "wildgs_slam/lib/droid_kernels.cu",
            "wildgs_slam/lib/correlation_kernels.cu",
            "wildgs_slam/lib/altcorr_kernel.cu",
        ],
        extra_compile_args={
            "cxx": ["-O3"],
            "nvcc": ["-O3"] + NVCC_ARCHES,
        },
    )

    # ------------------------------------------------------------------ #
    # 2. lietorch_backends + lietorch_extras                              #
    # ------------------------------------------------------------------ #
    _lt = "wildgs_slam/thirdparty/lietorch"
    lietorch_backends = CUDAExtension(
        name="lietorch_backends",
        include_dirs=[
            osp.join(ROOT, _lt, "lietorch", "include"),
            osp.join(ROOT, _lt, "eigen"),
        ],
        sources=[
            f"{_lt}/lietorch/src/lietorch.cpp",
            f"{_lt}/lietorch/src/lietorch_gpu.cu",
            f"{_lt}/lietorch/src/lietorch_cpu.cpp",
        ],
        extra_compile_args={
            "cxx": ["-O2"],
            "nvcc": ["-O2"] + NVCC_ARCHES,
        },
    )
    lietorch_extras = CUDAExtension(
        name="lietorch_extras",
        sources=[
            f"{_lt}/lietorch/extras/altcorr_kernel.cu",
            f"{_lt}/lietorch/extras/corr_index_kernel.cu",
            f"{_lt}/lietorch/extras/se3_builder.cu",
            f"{_lt}/lietorch/extras/se3_inplace_builder.cu",
            f"{_lt}/lietorch/extras/se3_solver.cu",
            f"{_lt}/lietorch/extras/extras.cpp",
        ],
        extra_compile_args={
            "cxx": ["-O2"],
            "nvcc": ["-O2"] + NVCC_ARCHES,
        },
    )

    # ------------------------------------------------------------------ #
    # 3. diff_gaussian_rasterization (with pose support)                  #
    # ------------------------------------------------------------------ #
    _dgr = "wildgs_slam/thirdparty/diff-gaussian-rasterization-w-pose"
    _glm_include = osp.join(ROOT, _dgr, "third_party", "glm")
    diff_gaussian = CUDAExtension(
        name="diff_gaussian_rasterization._C",
        include_dirs=[_glm_include],
        sources=[
            f"{_dgr}/cuda_rasterizer/rasterizer_impl.cu",
            f"{_dgr}/cuda_rasterizer/forward.cu",
            f"{_dgr}/cuda_rasterizer/backward.cu",
            f"{_dgr}/rasterize_points.cu",
            f"{_dgr}/ext.cpp",
        ],
        extra_compile_args={
            "nvcc": [f"-I{_glm_include}"],
        },
    )

    # ------------------------------------------------------------------ #
    # 4. simple_knn                                                        #
    # ------------------------------------------------------------------ #
    _sknn = "wildgs_slam/thirdparty/simple-knn"
    simple_knn = CUDAExtension(
        name="simple_knn._C",
        sources=[
            f"{_sknn}/spatial.cu",
            f"{_sknn}/simple_knn.cu",
            f"{_sknn}/ext.cpp",
        ],
        extra_compile_args={
            "cxx": [] if os.name != "nt" else ["/wd4624"],
            "nvcc": [],
        },
    )

    class ReusableBuildExtension(BuildExtension):
        """Reuse prebuilt binaries when present, otherwise compile normally."""

        def build_extension(self, ext):
            if not os.environ.get("WILDGS_FORCE_REBUILD"):
                existing = _find_prebuilt_extension(ext.name)
                if existing:
                    target = Path(self.get_ext_fullpath(ext.name))
                    target.parent.mkdir(parents=True, exist_ok=True)
                    existing_path = Path(existing).resolve()
                    target_path = target.resolve()
                    if existing_path == target_path:
                        self.announce(
                            f"prebuilt extension already present for {ext.name}: {existing}",
                            level=2,
                        )
                        return
                    shutil.copy2(existing, target)
                    self.announce(
                        f"reusing prebuilt extension for {ext.name}: {existing}",
                        level=2,
                    )
                    return
            super().build_extension(ext)

    ext_modules = [droid_backends, lietorch_backends, lietorch_extras, diff_gaussian, simple_knn]
    cmdclass = {"build_ext": ReusableBuildExtension}

except (ImportError, Exception) as e:
    import warnings
    if _BUILDING_SDIST or os.environ.get("WILDGS_NO_CUDA"):
        ext_modules = []
        cmdclass = {}
    else:
        warnings.warn(
            f"CUDA extensions could not be configured ({e}). "
            "Install PyTorch with CUDA support before running `pip install --no-build-isolation wildgs-slam`, "
            "or install with `WILDGS_NO_CUDA=1 pip install --no-build-isolation wildgs-slam` to skip compilation.",
            stacklevel=2,
        )
        raise


def _find_packages():
    """Find all Python packages to install.

    In addition to the main ``wildgs_slam`` namespace, we expose a few
    thirdparty packages at the top level so that upstream imports like
    ``from lietorch import SE3`` and ``from diff_gaussian_rasterization import …``
    continue to work without modifications.
    """
    pkgs = find_namespace_packages(
        include=["wildgs_slam", "wildgs_slam.*"],
        exclude=[
            "wildgs_slam.thirdparty.lietorch.examples",
            "wildgs_slam.thirdparty.lietorch.examples.*",
        ],
    )
    # Top-level thirdparty packages expected by the source code
    pkgs += ["diff_gaussian_rasterization", "lietorch", "simple_knn"]
    return pkgs


setup(
    ext_modules=ext_modules,
    cmdclass=cmdclass,
    packages=_find_packages(),
    package_dir=_PACKAGE_DIR,
)
