"""
monobit.storage.fontformats.softfonr - terminal softfonts

(c) 2022--2026 Rob Hagemans
licence: https://opensource.org/licenses/MIT
"""

from monobit.base import import_all
import_all(__name__)
