"""
monobit.storage.containerformats - container format converter plugins

(c) 2019--2026 Rob Hagemans
licence: https://opensource.org/licenses/MIT
"""

from monobit.base import import_all
import_all(__name__)
