"""
monobit.constants

(c) 2019--2026 Rob Hagemans
licence: https://opensource.org/licenses/MIT
"""


VERSION = '0.51'
MONOBIT = f'monobit v{VERSION}'
