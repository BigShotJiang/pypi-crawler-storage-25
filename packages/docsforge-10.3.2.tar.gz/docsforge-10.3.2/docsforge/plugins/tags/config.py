# Copyright (c) 2016-2025 Martin Donath <martin.donath@squidfunk.com>
# Copyright (c) 2026 QQ (Cyrus)
#
# This file is part of DocsForge.
#
# DocsForge is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DocsForge is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with DocsForge.  If not, see <https://www.gnu.org/licenses/>.



# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

from collections.abc import Callable
from docsforge.utilities.filter import FilterConfig
from docsforge.config.config_options import (
    DictOfItems, Deprecated, ListOfItems, SubConfig, Type
)
from docsforge.config.base import Config
from pymdownx.slugs import slugify

from . import item_title, tag_name
from .structure.listing import ListingConfig
from .structure.tag.options import TagSet

# -----------------------------------------------------------------------------
# Classes
# -----------------------------------------------------------------------------

# Tags plugin configuration
class TagsConfig(Config):
    enabled = Type(bool, default = True)

    # Settings for filtering
    filters = SubConfig(FilterConfig)

    # Settings for tags
    tags = Type(bool, default = True)
    tags_slugify = Type(Callable, default = slugify(case = "lower"))
    tags_slugify_separator = Type(str, default = "-")
    tags_slugify_format = Type(str, default = "tag:{slug}")
    tags_hierarchy = Type(bool, default = False)
    tags_hierarchy_separator = Type(str, default = "/")
    tags_sort_by = Type(Callable, default = tag_name)
    tags_sort_reverse = Type(bool, default = False)
    tags_name_property = Type(str, default = "tags")
    tags_name_variable = Type(str, default = "tags")
    tags_allowed = TagSet()

    # Settings for listings
    listings = Type(bool, default = True)
    listings_map = DictOfItems(SubConfig(ListingConfig), default = {})
    listings_sort_by = Type(Callable, default = item_title)
    listings_sort_reverse = Type(bool, default = False)
    listings_tags_sort_by = Type(Callable, default = tag_name)
    listings_tags_sort_reverse = Type(bool, default = False)
    listings_directive = Type(str, default = "docsforge/themes/material/tags")
    listings_layout = Type(str, default = "default")
    listings_toc = Type(bool, default = True)

    # Settings for shadow tags
    shadow = Type(bool, default = False)
    shadow_on_serve = Type(bool, default = True)
    shadow_tags = TagSet()
    shadow_tags_prefix = Type(str, default = "")
    shadow_tags_suffix = Type(str, default = "")

    # Settings for export
    export = Type(bool, default = True)
    export_file = Type(str, default = "tags.json")
    export_only = Type(bool, default = False)

    # Deprecated settings
    tags_compare = Deprecated(moved_to = "tags_sort_by")
    tags_compare_reverse = Deprecated(moved_to = "tags_sort_reverse")
    tags_pages_compare = Deprecated(moved_to = "listings_sort_by")
    tags_pages_compare_reverse = Deprecated(moved_to = "listings_sort_reverse")
    tags_file = Deprecated(option_type = Type(str))
    tags_extra_files = Deprecated(
        option_type = DictOfItems(ListOfItems(Type(str)), default = {})
    )
