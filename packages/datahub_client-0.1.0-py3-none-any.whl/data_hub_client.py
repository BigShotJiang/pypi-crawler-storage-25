from __future__ import annotations
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .Http.authentication import Authentication
from .Http.httpx_http_client import HttpxHttpClient
from .Http.ihttp_client import IHttpClient
from .Resources.files_api import FilesApi
from .Resources.issues_api import IssuesApi
from .Resources.merge_requests_api import MergeRequestsApi
from .Resources.packages_api import PackagesApi
from .Resources.projects_api import ProjectsApi
from .Resources.repository_api import RepositoryApi

def _expr511() -> TypeInfo:
    return class_type("DataHubClient.DataHubClient", None, DataHubClient)


class DataHubClient:
    def __init__(self, base_url: str, auth: Authentication) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = HttpxHttpClient()

    @property
    def Http(self, __unit: Unit=UNIT) -> IHttpClient:
        _: DataHubClient = self
        return _.http

    @Http.setter
    def Http(self, value: IHttpClient) -> None:
        _: DataHubClient = self
        _.http = value

    @property
    def Projects(self, __unit: Unit=UNIT) -> ProjectsApi:
        _: DataHubClient = self
        return ProjectsApi(base_url = _.base_url, auth = _.auth, http = _.http)

    @property
    def Repository(self, __unit: Unit=UNIT) -> RepositoryApi:
        _: DataHubClient = self
        return RepositoryApi(base_url = _.base_url, auth = _.auth, http = _.http)

    @property
    def Files(self, __unit: Unit=UNIT) -> FilesApi:
        _: DataHubClient = self
        return FilesApi(base_url = _.base_url, auth = _.auth, http = _.http)

    @property
    def Issues(self, __unit: Unit=UNIT) -> IssuesApi:
        _: DataHubClient = self
        return IssuesApi(base_url = _.base_url, auth = _.auth, http = _.http)

    @property
    def MergeRequests(self, __unit: Unit=UNIT) -> MergeRequestsApi:
        _: DataHubClient = self
        return MergeRequestsApi(base_url = _.base_url, auth = _.auth, http = _.http)

    @property
    def Packages(self, __unit: Unit=UNIT) -> PackagesApi:
        _: DataHubClient = self
        return PackagesApi(base_url = _.base_url, auth = _.auth, http = _.http)


DataHubClient_reflection = _expr511

def DataHubClient__ctor_Z748C2BDA(base_url: str, auth: Authentication) -> DataHubClient:
    return DataHubClient(base_url, auth)


__all__ = ["DataHubClient_reflection"]

