"""JSON encoder and decoder for <see cref="T:DataHubClient.Note"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, bool_1, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.note import Note
from ..Models.user import User
from .user import (decoder as decoder_1, encoder as encoder_1)

def _arrow190(get: IGetters) -> Note:
    def _arrow184(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow185(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("body", string)

    def _arrow186(__unit: Unit=UNIT) -> User:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("author", decoder_1)

    def _arrow187(__unit: Unit=UNIT) -> bool:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("system", bool_1)

    def _arrow188(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("created_at", string)

    def _arrow189(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("updated_at", string)

    return Note(id = _arrow184(), body = _arrow185(), author = _arrow186(), is_system = _arrow187(), created_at = _arrow188(), updated_at = _arrow189())


decoder: Decoder_1[Note] = object(_arrow190)

def encoder(note: Note) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.Note"/> to its GitLab JSON representation.
    """
    def _arrow192(note: Any=note) -> IEncodable:
        value: int32 = note.Id
        class ObjectExpr191(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr191()

    def _arrow194(note: Any=note) -> IEncodable:
        value_1: str = note.Body
        class ObjectExpr193(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr193()

    def _arrow196(note: Any=note) -> IEncodable:
        value_2: bool = note.System
        class ObjectExpr195(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_bool(value_2)

        return ObjectExpr195()

    def _arrow198(note: Any=note) -> IEncodable:
        value_3: str = note.CreatedAt
        class ObjectExpr197(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr197()

    def _arrow200(note: Any=note) -> IEncodable:
        value_4: str = note.UpdatedAt
        class ObjectExpr199(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr199()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow192()), ("body", _arrow194()), ("author", encoder_1(note.Author)), ("system", _arrow196()), ("created_at", _arrow198()), ("updated_at", _arrow200())])
    class ObjectExpr201(IEncodable):
        def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_5))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_5.encode_object(arg)

    return ObjectExpr201()


__all__ = ["decoder", "encoder"]

