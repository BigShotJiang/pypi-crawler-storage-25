"""JSON encoder and decoder for <see cref="T:DataHubClient.Project"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.project import Project
from .thoth_extensions import encode_option

def _arrow99(get: IGetters) -> Project:
    def _arrow91(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow92(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("name", string)

    def _arrow93(__unit: Unit=UNIT) -> str:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("path", string)

    def _arrow94(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("path_with_namespace", string)

    def _arrow95(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("visibility", string)

    def _arrow96(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("web_url", string)

    def _arrow97(__unit: Unit=UNIT) -> str | None:
        object_arg_6: IOptionalGetter = get.Optional
        return erase(object_arg_6.Field("description", string))

    def _arrow98(__unit: Unit=UNIT) -> str | None:
        object_arg_7: IOptionalGetter = get.Optional
        return erase(object_arg_7.Field("default_branch", string))

    return Project(id = _arrow91(), name = _arrow92(), path = _arrow93(), path_with_namespace = _arrow94(), visibility = _arrow95(), web_url = _arrow96(), description = _arrow97(), default_branch = _arrow98())


decoder: Decoder_1[Project] = object(_arrow99)

def encoder(project: Project) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.Project"/> to its GitLab JSON representation.
    """
    def _arrow101(project: Any=project) -> IEncodable:
        value: int32 = project.Id
        class ObjectExpr100(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr100()

    def _arrow103(project: Any=project) -> IEncodable:
        value_1: str = project.Name
        class ObjectExpr102(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr102()

    def _arrow105(project: Any=project) -> IEncodable:
        value_2: str = project.Path
        class ObjectExpr104(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_string(value_2)

        return ObjectExpr104()

    def _arrow107(project: Any=project) -> IEncodable:
        value_3: str = project.PathWithNamespace
        class ObjectExpr106(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr106()

    def _arrow109(project: Any=project) -> IEncodable:
        value_4: str = project.Visibility
        class ObjectExpr108(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr108()

    def _arrow111(project: Any=project) -> IEncodable:
        value_5: str = project.WebUrl
        class ObjectExpr110(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr110()

    def _arrow113(value_6: str) -> IEncodable:
        class ObjectExpr112(IEncodable):
            def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                return helpers_6.encode_string(value_6)

        return ObjectExpr112()

    def _arrow115(value_8: str) -> IEncodable:
        class ObjectExpr114(IEncodable):
            def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
                return helpers_7.encode_string(value_8)

        return ObjectExpr114()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow101()), ("name", _arrow103()), ("path", _arrow105()), ("path_with_namespace", _arrow107()), ("visibility", _arrow109()), ("web_url", _arrow111()), ("description", encode_option(_arrow113, project.Description)), ("default_branch", encode_option(_arrow115, project.DefaultBranch))])
    class ObjectExpr116(IEncodable):
        def Encode[_A](self, helpers_8: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_8))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_8.encode_object(arg)

    return ObjectExpr116()


__all__ = ["decoder", "encoder"]

