"""JSON encoder and decoder for <see cref="T:DataHubClient.User"/>. The JSON
modules live in the <c>DataHubClient.Json</c> namespace — separate from the
model classes in <c>DataHubClient</c> — mirroring ARCtrl's <c>ARCtrl.Json</c>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.user import User
from .thoth_extensions import encode_option

def _arrow77(get: IGetters) -> User:
    def _arrow71(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow72(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("username", string)

    def _arrow73(__unit: Unit=UNIT) -> str:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("name", string)

    def _arrow74(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("state", string)

    def _arrow75(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("web_url", string)

    def _arrow76(__unit: Unit=UNIT) -> str | None:
        object_arg_5: IOptionalGetter = get.Optional
        return erase(object_arg_5.Field("avatar_url", string))

    return User(id = _arrow71(), username = _arrow72(), name = _arrow73(), state = _arrow74(), web_url = _arrow75(), avatar_url = _arrow76())


decoder: Decoder_1[User] = object(_arrow77)

def encoder(user: User) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.User"/> to its GitLab JSON representation.
    """
    def _arrow79(user: Any=user) -> IEncodable:
        value: int32 = user.Id
        class ObjectExpr78(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr78()

    def _arrow81(user: Any=user) -> IEncodable:
        value_1: str = user.Username
        class ObjectExpr80(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr80()

    def _arrow83(user: Any=user) -> IEncodable:
        value_2: str = user.Name
        class ObjectExpr82(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_string(value_2)

        return ObjectExpr82()

    def _arrow85(user: Any=user) -> IEncodable:
        value_3: str = user.State
        class ObjectExpr84(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr84()

    def _arrow87(user: Any=user) -> IEncodable:
        value_4: str = user.WebUrl
        class ObjectExpr86(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr86()

    def _arrow89(value_5: str) -> IEncodable:
        class ObjectExpr88(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr88()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow79()), ("username", _arrow81()), ("name", _arrow83()), ("state", _arrow85()), ("web_url", _arrow87()), ("avatar_url", encode_option(_arrow89, user.AvatarUrl))])
    class ObjectExpr90(IEncodable):
        def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_6))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_6.encode_object(arg)

    return ObjectExpr90()


__all__ = ["decoder", "encoder"]

