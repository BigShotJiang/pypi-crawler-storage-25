"""Shared Thoth.Json encoder helpers used by the JSON modules. Internal: not
part of the public, transpiled API surface.
"""
from __future__ import annotations
from collections.abc import Callable
from typing import Any
from fable_library.list import (choose, FSharpList)
from fable_library.option import (map, erase, widen, value as value_1, Option)
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map as map_1
from fable_library.util import UNIT
from ..fable_modules.thoth_json_core.types import (IEncodable, IEncoderHelpers_1)

def object_skip_null(fields: FSharpList[tuple[str, IEncodable | None]]) -> IEncodable:
    """Builds a JSON object, dropping any field whose value is <c>None</c>.
    """
    def chooser(tupled_arg: tuple[str, IEncodable | None]) -> tuple[str, IEncodable] | None:
        def mapping(v: IEncodable, tupled_arg: Any=tupled_arg) -> tuple[str, IEncodable]:
            return (tupled_arg[0], v)

        return erase(map(mapping, tupled_arg[1]))

    values: FSharpList[tuple[str, IEncodable]] = choose(widen(chooser), fields)
    class ObjectExpr55(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping_1(tupled_arg_1: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg_1[0], tupled_arg_1[1].Encode(helpers))

            arg: IEnumerable_1[tuple[str, Any]] = map_1(mapping_1, values)
            return helpers.encode_object(arg)

    return ObjectExpr55()


def encode_option[T](encoder: Callable[[T], IEncodable], value: Option[T]=None) -> IEncodable:
    """Encodes an optional value, emitting JSON <c>null</c> when <c>None</c>.
    """
    if value is None:
        class ObjectExpr56(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_null()

        return ObjectExpr56()

    else:
        return encoder(value_1(value))



__all__ = ["encode_option", "object_skip_null"]

