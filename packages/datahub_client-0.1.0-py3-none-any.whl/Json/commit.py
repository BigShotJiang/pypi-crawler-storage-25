"""JSON encoder and decoder for <see cref="T:DataHubClient.Commit"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, string, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.commit import Commit
from .thoth_extensions import encode_option

def _arrow127(get: IGetters) -> Commit:
    def _arrow117(__unit: Unit=UNIT) -> str:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", string)

    def _arrow118(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("short_id", string)

    def _arrow119(__unit: Unit=UNIT) -> str:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("title", string)

    def _arrow120(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("message", string)

    def _arrow121(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("author_name", string)

    def _arrow122(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("author_email", string)

    def _arrow123(__unit: Unit=UNIT) -> str:
        object_arg_6: IRequiredGetter = get.Required
        return object_arg_6.Field("created_at", string)

    def _arrow125(__unit: Unit=UNIT) -> str | None:
        object_arg_7: IOptionalGetter = get.Optional
        return erase(object_arg_7.Field("web_url", string))

    return Commit(id = _arrow117(), short_id = _arrow118(), title = _arrow119(), message = _arrow120(), author_name = _arrow121(), author_email = _arrow122(), created_at = _arrow123(), web_url = _arrow125())


decoder: Decoder_1[Commit] = object(_arrow127)

def encoder(commit: Commit) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.Commit"/> to its GitLab JSON representation.
    """
    def _arrow133(commit: Any=commit) -> IEncodable:
        value: str = commit.Id
        class ObjectExpr132(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_string(value)

        return ObjectExpr132()

    def _arrow135(commit: Any=commit) -> IEncodable:
        value_1: str = commit.ShortId
        class ObjectExpr134(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr134()

    def _arrow139(commit: Any=commit) -> IEncodable:
        value_2: str = commit.Title
        class ObjectExpr138(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_string(value_2)

        return ObjectExpr138()

    def _arrow145(commit: Any=commit) -> IEncodable:
        value_3: str = commit.Message
        class ObjectExpr144(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr144()

    def _arrow149(commit: Any=commit) -> IEncodable:
        value_4: str = commit.AuthorName
        class ObjectExpr148(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr148()

    def _arrow151(commit: Any=commit) -> IEncodable:
        value_5: str = commit.AuthorEmail
        class ObjectExpr150(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr150()

    def _arrow153(commit: Any=commit) -> IEncodable:
        value_6: str = commit.CreatedAt
        class ObjectExpr152(IEncodable):
            def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                return helpers_6.encode_string(value_6)

        return ObjectExpr152()

    def _arrow156(value_7: str) -> IEncodable:
        class ObjectExpr155(IEncodable):
            def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
                return helpers_7.encode_string(value_7)

        return ObjectExpr155()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow133()), ("short_id", _arrow135()), ("title", _arrow139()), ("message", _arrow145()), ("author_name", _arrow149()), ("author_email", _arrow151()), ("created_at", _arrow153()), ("web_url", encode_option(_arrow156, commit.WebUrl))])
    class ObjectExpr157(IEncodable):
        def Encode[_A](self, helpers_8: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_8))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_8.encode_object(arg)

    return ObjectExpr157()


__all__ = ["decoder", "encoder"]

