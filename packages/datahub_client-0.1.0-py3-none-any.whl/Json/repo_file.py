"""JSON encoder and decoder for <see cref="T:DataHubClient.RepoFile"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, string, int_1, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.repo_file import RepoFile

def _arrow166(get: IGetters) -> RepoFile:
    def _arrow158(__unit: Unit=UNIT) -> str:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("file_name", string)

    def _arrow159(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("file_path", string)

    def _arrow160(__unit: Unit=UNIT) -> int32:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("size", int_1)

    def _arrow161(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("encoding", string)

    def _arrow162(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("content", string)

    def _arrow163(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("ref", string)

    def _arrow164(__unit: Unit=UNIT) -> str:
        object_arg_6: IRequiredGetter = get.Required
        return object_arg_6.Field("blob_id", string)

    def _arrow165(__unit: Unit=UNIT) -> str:
        object_arg_7: IRequiredGetter = get.Required
        return object_arg_7.Field("commit_id", string)

    return RepoFile(file_name = _arrow158(), file_path = _arrow159(), size = _arrow160(), encoding = _arrow161(), content = _arrow162(), ref_name = _arrow163(), blob_id = _arrow164(), commit_id = _arrow165())


decoder: Decoder_1[RepoFile] = object(_arrow166)

def encoder(file: RepoFile) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.RepoFile"/> to its GitLab JSON representation.
    """
    def _arrow168(file: Any=file) -> IEncodable:
        value: str = file.FileName
        class ObjectExpr167(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_string(value)

        return ObjectExpr167()

    def _arrow170(file: Any=file) -> IEncodable:
        value_1: str = file.FilePath
        class ObjectExpr169(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr169()

    def _arrow172(file: Any=file) -> IEncodable:
        value_2: int32 = file.Size
        class ObjectExpr171(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_signed_integral_number(value_2)

        return ObjectExpr171()

    def _arrow174(file: Any=file) -> IEncodable:
        value_3: str = file.Encoding
        class ObjectExpr173(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr173()

    def _arrow176(file: Any=file) -> IEncodable:
        value_4: str = file.Content
        class ObjectExpr175(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr175()

    def _arrow178(file: Any=file) -> IEncodable:
        value_5: str = file.Ref
        class ObjectExpr177(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr177()

    def _arrow180(file: Any=file) -> IEncodable:
        value_6: str = file.BlobId
        class ObjectExpr179(IEncodable):
            def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                return helpers_6.encode_string(value_6)

        return ObjectExpr179()

    def _arrow182(file: Any=file) -> IEncodable:
        value_7: str = file.CommitId
        class ObjectExpr181(IEncodable):
            def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
                return helpers_7.encode_string(value_7)

        return ObjectExpr181()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("file_name", _arrow168()), ("file_path", _arrow170()), ("size", _arrow172()), ("encoding", _arrow174()), ("content", _arrow176()), ("ref", _arrow178()), ("blob_id", _arrow180()), ("commit_id", _arrow182())])
    class ObjectExpr183(IEncodable):
        def Encode[_A](self, helpers_8: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_8))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_8.encode_object(arg)

    return ObjectExpr183()


__all__ = ["decoder", "encoder"]

