"""JSON encoder and decoder for <see cref="T:DataHubClient.Issue"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.array_ import map
from fable_library.array_ import Array
from fable_library.core import int32
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map as map_1
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, array as array_2, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.issue import Issue
from ..Models.user import User
from .thoth_extensions import encode_option
from .user import (decoder as decoder_1, encoder as encoder_1)

def _arrow271(get: IGetters) -> Issue:
    def _arrow257(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow258(__unit: Unit=UNIT) -> int32:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("iid", int_1)

    def _arrow260(__unit: Unit=UNIT) -> int32:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("project_id", int_1)

    def _arrow261(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("title", string)

    def _arrow262(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("state", string)

    def _arrow263(__unit: Unit=UNIT) -> User:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("author", decoder_1)

    def _arrow264(__unit: Unit=UNIT) -> Array[User]:
        arg_13: Decoder_1[Array[User]] = array_2(decoder_1)
        object_arg_6: IRequiredGetter = get.Required
        return object_arg_6.Field("assignees", arg_13)

    def _arrow266(__unit: Unit=UNIT) -> Array[str]:
        arg_15: Decoder_1[Array[str]] = array_2(string)
        object_arg_7: IRequiredGetter = get.Required
        return object_arg_7.Field("labels", arg_15)

    def _arrow267(__unit: Unit=UNIT) -> str:
        object_arg_8: IRequiredGetter = get.Required
        return object_arg_8.Field("web_url", string)

    def _arrow268(__unit: Unit=UNIT) -> str:
        object_arg_9: IRequiredGetter = get.Required
        return object_arg_9.Field("created_at", string)

    def _arrow269(__unit: Unit=UNIT) -> str:
        object_arg_10: IRequiredGetter = get.Required
        return object_arg_10.Field("updated_at", string)

    def _arrow270(__unit: Unit=UNIT) -> str | None:
        object_arg_11: IOptionalGetter = get.Optional
        return erase(object_arg_11.Field("description", string))

    return Issue(id = _arrow257(), iid = _arrow258(), project_id = _arrow260(), title = _arrow261(), state = _arrow262(), author = _arrow263(), assignees = _arrow264(), labels = _arrow266(), web_url = _arrow267(), created_at = _arrow268(), updated_at = _arrow269(), description = _arrow270())


decoder: Decoder_1[Issue] = object(_arrow271)

def encoder(issue: Issue) -> IEncodable:
    """Encodes an <see cref="T:DataHubClient.Issue"/> to its GitLab JSON representation.
    """
    def _arrow274(issue: Any=issue) -> IEncodable:
        value: int32 = issue.Id
        class ObjectExpr273(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr273()

    def _arrow276(issue: Any=issue) -> IEncodable:
        value_1: int32 = issue.Iid
        class ObjectExpr275(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_signed_integral_number(value_1)

        return ObjectExpr275()

    def _arrow278(issue: Any=issue) -> IEncodable:
        value_2: int32 = issue.ProjectId
        class ObjectExpr277(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_signed_integral_number(value_2)

        return ObjectExpr277()

    def _arrow281(issue: Any=issue) -> IEncodable:
        value_3: str = issue.Title
        class ObjectExpr280(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr280()

    def _arrow283(issue: Any=issue) -> IEncodable:
        value_4: str = issue.State
        class ObjectExpr282(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr282()

    def _arrow286(issue: Any=issue) -> IEncodable:
        values: Array[IEncodable] = map(encoder_1, issue.Assignees, None)
        class ObjectExpr285(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                def mapping(v: IEncodable) -> _A:
                    return v.Encode(helpers_5)

                arg: Array[Any] = map(mapping, values, None)
                return helpers_5.encode_array(arg)

        return ObjectExpr285()

    def _arrow290(issue: Any=issue) -> IEncodable:
        def _arrow288(value_5: str) -> IEncodable:
            class ObjectExpr287(IEncodable):
                def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                    return helpers_6.encode_string(value_5)

            return ObjectExpr287()

        values_1: Array[IEncodable] = map(_arrow288, issue.Labels, None)
        class ObjectExpr289(IEncodable):
            def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
                def mapping_1(v_1: IEncodable) -> _A:
                    return v_1.Encode(helpers_7)

                arg_1: Array[Any] = map(mapping_1, values_1, None)
                return helpers_7.encode_array(arg_1)

        return ObjectExpr289()

    def _arrow294(issue: Any=issue) -> IEncodable:
        value_7: str = issue.WebUrl
        class ObjectExpr293(IEncodable):
            def Encode[_A](self, helpers_8: IEncoderHelpers_1[_A]) -> _A:
                return helpers_8.encode_string(value_7)

        return ObjectExpr293()

    def _arrow296(issue: Any=issue) -> IEncodable:
        value_8: str = issue.CreatedAt
        class ObjectExpr295(IEncodable):
            def Encode[_A](self, helpers_9: IEncoderHelpers_1[_A]) -> _A:
                return helpers_9.encode_string(value_8)

        return ObjectExpr295()

    def _arrow298(issue: Any=issue) -> IEncodable:
        value_9: str = issue.UpdatedAt
        class ObjectExpr297(IEncodable):
            def Encode[_A](self, helpers_10: IEncoderHelpers_1[_A]) -> _A:
                return helpers_10.encode_string(value_9)

        return ObjectExpr297()

    def _arrow302(value_10: str) -> IEncodable:
        class ObjectExpr301(IEncodable):
            def Encode[_A](self, helpers_11: IEncoderHelpers_1[_A]) -> _A:
                return helpers_11.encode_string(value_10)

        return ObjectExpr301()

    values_2: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow274()), ("iid", _arrow276()), ("project_id", _arrow278()), ("title", _arrow281()), ("state", _arrow283()), ("author", encoder_1(issue.Author)), ("assignees", _arrow286()), ("labels", _arrow290()), ("web_url", _arrow294()), ("created_at", _arrow296()), ("updated_at", _arrow298()), ("description", encode_option(_arrow302, issue.Description))])
    class ObjectExpr303(IEncodable):
        def Encode[_A](self, helpers_12: IEncoderHelpers_1[_A]) -> _A:
            def mapping_2(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_12))

            arg_2: IEnumerable_1[tuple[str, Any]] = map_1(mapping_2, values_2)
            return helpers_12.encode_object(arg_2)

    return ObjectExpr303()


__all__ = ["decoder", "encoder"]

