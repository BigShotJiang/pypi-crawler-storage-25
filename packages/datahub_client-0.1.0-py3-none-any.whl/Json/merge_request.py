"""JSON encoder and decoder for <see cref="T:DataHubClient.MergeRequest"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.merge_request import MergeRequest
from ..Models.user import User
from .thoth_extensions import encode_option
from .user import (decoder as decoder_1, encoder as encoder_1)

def _arrow325(get: IGetters) -> MergeRequest:
    def _arrow312(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow313(__unit: Unit=UNIT) -> int32:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("iid", int_1)

    def _arrow314(__unit: Unit=UNIT) -> int32:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("project_id", int_1)

    def _arrow315(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("title", string)

    def _arrow316(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("state", string)

    def _arrow317(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("source_branch", string)

    def _arrow318(__unit: Unit=UNIT) -> str:
        object_arg_6: IRequiredGetter = get.Required
        return object_arg_6.Field("target_branch", string)

    def _arrow319(__unit: Unit=UNIT) -> User:
        object_arg_7: IRequiredGetter = get.Required
        return object_arg_7.Field("author", decoder_1)

    def _arrow320(__unit: Unit=UNIT) -> str:
        object_arg_8: IRequiredGetter = get.Required
        return object_arg_8.Field("web_url", string)

    def _arrow321(__unit: Unit=UNIT) -> str:
        object_arg_9: IRequiredGetter = get.Required
        return object_arg_9.Field("created_at", string)

    def _arrow322(__unit: Unit=UNIT) -> str:
        object_arg_10: IRequiredGetter = get.Required
        return object_arg_10.Field("updated_at", string)

    def _arrow323(__unit: Unit=UNIT) -> str | None:
        object_arg_11: IOptionalGetter = get.Optional
        return erase(object_arg_11.Field("description", string))

    def _arrow324(__unit: Unit=UNIT) -> str | None:
        object_arg_12: IOptionalGetter = get.Optional
        return erase(object_arg_12.Field("merge_status", string))

    return MergeRequest(id = _arrow312(), iid = _arrow313(), project_id = _arrow314(), title = _arrow315(), state = _arrow316(), source_branch = _arrow317(), target_branch = _arrow318(), author = _arrow319(), web_url = _arrow320(), created_at = _arrow321(), updated_at = _arrow322(), description = _arrow323(), merge_status = _arrow324())


decoder: Decoder_1[MergeRequest] = object(_arrow325)

def encoder(mr: MergeRequest) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.MergeRequest"/> to its GitLab JSON representation.
    """
    def _arrow327(mr: Any=mr) -> IEncodable:
        value: int32 = mr.Id
        class ObjectExpr326(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr326()

    def _arrow329(mr: Any=mr) -> IEncodable:
        value_1: int32 = mr.Iid
        class ObjectExpr328(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_signed_integral_number(value_1)

        return ObjectExpr328()

    def _arrow333(mr: Any=mr) -> IEncodable:
        value_2: int32 = mr.ProjectId
        class ObjectExpr331(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_signed_integral_number(value_2)

        return ObjectExpr331()

    def _arrow338(mr: Any=mr) -> IEncodable:
        value_3: str = mr.Title
        class ObjectExpr337(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr337()

    def _arrow343(mr: Any=mr) -> IEncodable:
        value_4: str = mr.State
        class ObjectExpr342(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr342()

    def _arrow347(mr: Any=mr) -> IEncodable:
        value_5: str = mr.SourceBranch
        class ObjectExpr346(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr346()

    def _arrow351(mr: Any=mr) -> IEncodable:
        value_6: str = mr.TargetBranch
        class ObjectExpr350(IEncodable):
            def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                return helpers_6.encode_string(value_6)

        return ObjectExpr350()

    def _arrow358(mr: Any=mr) -> IEncodable:
        value_7: str = mr.WebUrl
        class ObjectExpr357(IEncodable):
            def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
                return helpers_7.encode_string(value_7)

        return ObjectExpr357()

    def _arrow362(mr: Any=mr) -> IEncodable:
        value_8: str = mr.CreatedAt
        class ObjectExpr361(IEncodable):
            def Encode[_A](self, helpers_8: IEncoderHelpers_1[_A]) -> _A:
                return helpers_8.encode_string(value_8)

        return ObjectExpr361()

    def _arrow367(mr: Any=mr) -> IEncodable:
        value_9: str = mr.UpdatedAt
        class ObjectExpr366(IEncodable):
            def Encode[_A](self, helpers_9: IEncoderHelpers_1[_A]) -> _A:
                return helpers_9.encode_string(value_9)

        return ObjectExpr366()

    def _arrow372(value_10: str) -> IEncodable:
        class ObjectExpr371(IEncodable):
            def Encode[_A](self, helpers_10: IEncoderHelpers_1[_A]) -> _A:
                return helpers_10.encode_string(value_10)

        return ObjectExpr371()

    def _arrow377(value_12: str) -> IEncodable:
        class ObjectExpr376(IEncodable):
            def Encode[_A](self, helpers_11: IEncoderHelpers_1[_A]) -> _A:
                return helpers_11.encode_string(value_12)

        return ObjectExpr376()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow327()), ("iid", _arrow329()), ("project_id", _arrow333()), ("title", _arrow338()), ("state", _arrow343()), ("source_branch", _arrow347()), ("target_branch", _arrow351()), ("author", encoder_1(mr.Author)), ("web_url", _arrow358()), ("created_at", _arrow362()), ("updated_at", _arrow367()), ("description", encode_option(_arrow372, mr.Description)), ("merge_status", encode_option(_arrow377, mr.MergeStatus))])
    class ObjectExpr380(IEncodable):
        def Encode[_A](self, helpers_12: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_12))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_12.encode_object(arg)

    return ObjectExpr380()


__all__ = ["decoder", "encoder"]

