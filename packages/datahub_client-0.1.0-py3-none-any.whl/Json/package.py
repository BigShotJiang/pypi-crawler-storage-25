"""JSON encoder and decoder for <see cref="T:DataHubClient.Package"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.core import int32
from fable_library.option import erase
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, int_1, string, IOptionalGetter, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.package import Package
from .thoth_extensions import encode_option

def _arrow344(get: IGetters) -> Package:
    def _arrow332(__unit: Unit=UNIT) -> int32:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("id", int_1)

    def _arrow334(__unit: Unit=UNIT) -> str:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("name", string)

    def _arrow335(__unit: Unit=UNIT) -> str:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("version", string)

    def _arrow336(__unit: Unit=UNIT) -> str:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("package_type", string)

    def _arrow339(__unit: Unit=UNIT) -> str:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("status", string)

    def _arrow340(__unit: Unit=UNIT) -> str:
        object_arg_5: IRequiredGetter = get.Required
        return object_arg_5.Field("created_at", string)

    def _arrow341(__unit: Unit=UNIT) -> str | None:
        object_arg_6: IOptionalGetter = get.Optional
        return erase(object_arg_6.Field("web_url", string))

    return Package(id = _arrow332(), name = _arrow334(), version = _arrow335(), package_type = _arrow336(), status = _arrow339(), created_at = _arrow340(), web_url = _arrow341())


decoder: Decoder_1[Package] = object(_arrow344)

def encoder(package: Package) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.Package"/> to its GitLab JSON representation.
    """
    def _arrow349(package: Any=package) -> IEncodable:
        value: int32 = package.Id
        class ObjectExpr348(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_signed_integral_number(value)

        return ObjectExpr348()

    def _arrow353(package: Any=package) -> IEncodable:
        value_1: str = package.Name
        class ObjectExpr352(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(value_1)

        return ObjectExpr352()

    def _arrow356(package: Any=package) -> IEncodable:
        value_2: str = package.Version
        class ObjectExpr355(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_string(value_2)

        return ObjectExpr355()

    def _arrow360(package: Any=package) -> IEncodable:
        value_3: str = package.PackageType
        class ObjectExpr359(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string(value_3)

        return ObjectExpr359()

    def _arrow365(package: Any=package) -> IEncodable:
        value_4: str = package.Status
        class ObjectExpr364(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string(value_4)

        return ObjectExpr364()

    def _arrow370(package: Any=package) -> IEncodable:
        value_5: str = package.CreatedAt
        class ObjectExpr369(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                return helpers_5.encode_string(value_5)

        return ObjectExpr369()

    def _arrow374(value_6: str) -> IEncodable:
        class ObjectExpr373(IEncodable):
            def Encode[_A](self, helpers_6: IEncoderHelpers_1[_A]) -> _A:
                return helpers_6.encode_string(value_6)

        return ObjectExpr373()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("id", _arrow349()), ("name", _arrow353()), ("version", _arrow356()), ("package_type", _arrow360()), ("status", _arrow365()), ("created_at", _arrow370()), ("web_url", encode_option(_arrow374, package.WebUrl))])
    class ObjectExpr378(IEncodable):
        def Encode[_A](self, helpers_7: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_7))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_7.encode_object(arg)

    return ObjectExpr378()


__all__ = ["decoder", "encoder"]

