"""JSON encoder and decoder for <see cref="T:DataHubClient.Branch"/>.
"""
from __future__ import annotations
from typing import Any
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.decode import (object, IRequiredGetter, string, bool_1, IGetters)
from ..fable_modules.thoth_json_core.types import (Decoder_1, IEncodable, IEncoderHelpers_1)
from ..Models.branch import Branch
from ..Models.commit import Commit
from .commit import (decoder as decoder_1, encoder as encoder_1)

def _arrow131(get: IGetters) -> Branch:
    def _arrow124(__unit: Unit=UNIT) -> str:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("name", string)

    def _arrow126(__unit: Unit=UNIT) -> bool:
        object_arg_1: IRequiredGetter = get.Required
        return object_arg_1.Field("default", bool_1)

    def _arrow128(__unit: Unit=UNIT) -> bool:
        object_arg_2: IRequiredGetter = get.Required
        return object_arg_2.Field("protected", bool_1)

    def _arrow129(__unit: Unit=UNIT) -> bool:
        object_arg_3: IRequiredGetter = get.Required
        return object_arg_3.Field("merged", bool_1)

    def _arrow130(__unit: Unit=UNIT) -> Commit:
        object_arg_4: IRequiredGetter = get.Required
        return object_arg_4.Field("commit", decoder_1)

    return Branch(name = _arrow124(), is_default = _arrow126(), is_protected = _arrow128(), merged = _arrow129(), commit = _arrow130())


decoder: Decoder_1[Branch] = object(_arrow131)

def encoder(branch: Branch) -> IEncodable:
    """Encodes a <see cref="T:DataHubClient.Branch"/> to its GitLab JSON representation.
    """
    def _arrow137(branch: Any=branch) -> IEncodable:
        value: str = branch.Name
        class ObjectExpr136(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_string(value)

        return ObjectExpr136()

    def _arrow141(branch: Any=branch) -> IEncodable:
        value_1: bool = branch.Default
        class ObjectExpr140(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_bool(value_1)

        return ObjectExpr140()

    def _arrow143(branch: Any=branch) -> IEncodable:
        value_2: bool = branch.Protected
        class ObjectExpr142(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_bool(value_2)

        return ObjectExpr142()

    def _arrow147(branch: Any=branch) -> IEncodable:
        value_3: bool = branch.Merged
        class ObjectExpr146(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_bool(value_3)

        return ObjectExpr146()

    values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("name", _arrow137()), ("default", _arrow141()), ("protected", _arrow143()), ("merged", _arrow147()), ("commit", encoder_1(branch.Commit))])
    class ObjectExpr154(IEncodable):
        def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers_4))

            arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
            return helpers_4.encode_object(arg)

    return ObjectExpr154()


__all__ = ["decoder", "encoder"]

