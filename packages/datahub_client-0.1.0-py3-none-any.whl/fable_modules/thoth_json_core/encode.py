from __future__ import annotations
from collections.abc import Callable
from typing import Any
from fable_library.array_ import map as map_3
from fable_library.array_ import Array
from fable_library.core import (float64, float32 as float32_1, int32)
from fable_library.list import (map as map_1, FSharpList)
from fable_library.map import (to_seq, to_list)
from fable_library.option import (default_arg_with, map as map_4, Option, value as value_6)
from fable_library.protocols import IEnumerable_1
from fable_library.seq import map as map_2
from fable_library.util import (UNIT, get_enumerator, dispose, Unit, to_enumerable)
from .types import (IEncodable, IEncoderHelpers_1, Json)

def float32(value_1: float32_1) -> IEncodable:
    class ObjectExpr17(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_decimal_number(float64(value_1))

    return ObjectExpr17()


def list_1(values: FSharpList[IEncodable]) -> IEncodable:
    class ObjectExpr18(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], values: Any=values) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: FSharpList[Any] = map_1(mapping, values)
            return helpers.encode_list(arg)

    return ObjectExpr18()


def seq(values: IEnumerable_1[IEncodable]) -> IEncodable:
    class ObjectExpr19(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], values: Any=values) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: IEnumerable_1[Any] = map_2(mapping, values)
            return helpers.encode_seq(arg)

    return ObjectExpr19()


def resize_array(values: list[IEncodable]) -> IEncodable:
    class ObjectExpr20(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], values: Any=values) -> _A:
            result: list[Any] = []
            enumerator: Any = get_enumerator(values)
            try:
                while enumerator.System_Collections_IEnumerator_MoveNext():
                    v: IEncodable = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
                    (result.append(v.Encode(helpers)))

            finally:
                dispose(enumerator)

            return helpers.encode_resize_array(result)

    return ObjectExpr20()


def dict_1(values: Any) -> IEncodable:
    values_1: IEnumerable_1[tuple[str, IEncodable]] = to_seq(values)
    class ObjectExpr21(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                return (tupled_arg[0], tupled_arg[1].Encode(helpers))

            arg: IEnumerable_1[tuple[str, Any]] = map_2(mapping, values_1)
            return helpers.encode_object(arg)

    return ObjectExpr21()


def tuple2[T1, T2](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], v1: T1, v2: T2) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2)])
    class ObjectExpr22(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr22()


def tuple3[T1, T2, T3](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], v1: T1, v2: T2, v3: T3) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3)])
    class ObjectExpr23(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr23()


def tuple4[T1, T2, T3, T4](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], enc4: Callable[[T4], IEncodable], v1: T1, v2: T2, v3: T3, v4: T4) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3), enc4(v4)])
    class ObjectExpr24(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr24()


def tuple5[T1, T2, T3, T4, T5](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], enc4: Callable[[T4], IEncodable], enc5: Callable[[T5], IEncodable], v1: T1, v2: T2, v3: T3, v4: T4, v5: T5) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3), enc4(v4), enc5(v5)])
    class ObjectExpr25(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr25()


def tuple6[T1, T2, T3, T4, T5, T6](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], enc4: Callable[[T4], IEncodable], enc5: Callable[[T5], IEncodable], enc6: Callable[[T6], IEncodable], v1: T1, v2: T2, v3: T3, v4: T4, v5: T5, v6: T6) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3), enc4(v4), enc5(v5), enc6(v6)])
    class ObjectExpr26(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr26()


def tuple7[T1, T2, T3, T4, T5, T6, T7](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], enc4: Callable[[T4], IEncodable], enc5: Callable[[T5], IEncodable], enc6: Callable[[T6], IEncodable], enc7: Callable[[T7], IEncodable], v1: T1, v2: T2, v3: T3, v4: T4, v5: T5, v6: T6, v7: T7) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3), enc4(v4), enc5(v5), enc6(v6), enc7(v7)])
    class ObjectExpr27(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr27()


def tuple8[T1, T2, T3, T4, T5, T6, T7, T8](enc1: Callable[[T1], IEncodable], enc2: Callable[[T2], IEncodable], enc3: Callable[[T3], IEncodable], enc4: Callable[[T4], IEncodable], enc5: Callable[[T5], IEncodable], enc6: Callable[[T6], IEncodable], enc7: Callable[[T7], IEncodable], enc8: Callable[[T8], IEncodable], v1: T1, v2: T2, v3: T3, v4: T4, v5: T5, v6: T6, v7: T7, v8: T8) -> IEncodable:
    values: Array[IEncodable] = Array[Any]([enc1(v1), enc2(v2), enc3(v3), enc4(v4), enc5(v5), enc6(v6), enc7(v7), enc8(v8)])
    class ObjectExpr28(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
            def mapping(v: IEncodable) -> _A:
                return v.Encode(helpers)

            arg: Array[Any] = map_3(mapping, values, None)
            return helpers.encode_array(arg)

    return ObjectExpr28()


def map[KEY, VALUE](key_encoder: Callable[[KEY], IEncodable], value_encoder: Callable[[VALUE], IEncodable], values: Any) -> IEncodable:
    def mapping(tupled_arg: tuple[KEY, VALUE], key_encoder: Any=key_encoder, value_encoder: Any=value_encoder) -> IEncodable:
        return tuple2(key_encoder, value_encoder, tupled_arg[0], tupled_arg[1])

    return list_1(map_1(mapping, to_list(values)))


def lazily[T](enc: Any, x: T) -> IEncodable:
    return enc.Value(x)


def Enum_byte[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr29(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_unsigned_integral_number(value_1)

    return ObjectExpr29()


def Enum_sbyte[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr30(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_signed_integral_number(int32(value_1))

    return ObjectExpr30()


def Enum_int16[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr31(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_signed_integral_number(int32(value_1))

    return ObjectExpr31()


def Enum_uint16[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr32(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_unsigned_integral_number(value_1)

    return ObjectExpr32()


def Enum_int[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr33(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_signed_integral_number(int32(value_1))

    return ObjectExpr33()


def Enum_uint32[TENUM](value_1: TENUM=UNIT) -> IEncodable:
    class ObjectExpr34(IEncodable):
        def Encode[_A](self, helpers: IEncoderHelpers_1[_A], value_1: Any=value_1) -> _A:
            return helpers.encode_unsigned_integral_number(value_1)

    return ObjectExpr34()


def lossy_option[A](encoder: Callable[[A], IEncodable]) -> Callable[[Option[A]], IEncodable]:
    """Encodes an option value using the provided encoder.

    Attention, this encoder is lossy, it's result will not be able to distinguish between `'T option` and `'T option option`.

    If you need to distinguish between `'T option` and `'T option option`, use `losslessOption`.
    """
    def _arrow36(arg: Option[A]=None, encoder: Any=encoder) -> IEncodable:
        def def_thunk(__unit: Unit=UNIT) -> IEncodable:
            class ObjectExpr35(IEncodable):
                def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                    return helpers.encode_null()

            return ObjectExpr35()

        return default_arg_with(map_4(encoder, arg), def_thunk)

    return _arrow36


def lossless_option[A](encoder: Callable[[A], IEncodable], value_1: Option[A]=None) -> IEncodable:
    """Encodes an option value using the provided encoder.

    This encoder is lossless, it's result will be able to distinguish between `'T option` and `'T option option`.

    If you don't need to distinguish between `'T option` and `'T option option`, use `lossyOption`.
    """
    if value_1 is None:
        class ObjectExpr37(IEncodable):
            def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                return helpers_3.encode_string("option")

        class ObjectExpr38(IEncodable):
            def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                return helpers_4.encode_string("none")

        values_1: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("$type", ObjectExpr37()), ("$case", ObjectExpr38())])
        class ObjectExpr39(IEncodable):
            def Encode[_A](self, helpers_5: IEncoderHelpers_1[_A]) -> _A:
                def mapping_1(tupled_arg_1: tuple[str, IEncodable]) -> tuple[str, _A]:
                    return (tupled_arg_1[0], tupled_arg_1[1].Encode(helpers_5))

                arg_1: IEnumerable_1[tuple[str, Any]] = map_2(mapping_1, values_1)
                return helpers_5.encode_object(arg_1)

        return ObjectExpr39()

    else:
        v: Any = value_6(value_1)
        class ObjectExpr40(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_string("option")

        class ObjectExpr41(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string("some")

        values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("$type", ObjectExpr40()), ("$case", ObjectExpr41()), ("$value", encoder(v))])
        class ObjectExpr42(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                    return (tupled_arg[0], tupled_arg[1].Encode(helpers_2))

                arg: IEnumerable_1[tuple[str, Any]] = map_2(mapping, values)
                return helpers_2.encode_object(arg)

        return ObjectExpr42()



def value(json: Json) -> IEncodable:
    match json.tag:
        case 3:
            class ObjectExpr43(IEncodable):
                def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A], json: Any=json) -> _A:
                    return helpers_1.encode_bool(json.fields[0])

            return ObjectExpr43()

        case 0:
            class ObjectExpr44(IEncodable):
                def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A], json: Any=json) -> _A:
                    return helpers_2.encode_string(json.fields[0])

            return ObjectExpr44()

        case 1:
            class ObjectExpr45(IEncodable):
                def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A], json: Any=json) -> _A:
                    return helpers_3.encode_decimal_number(json.fields[0])

            return ObjectExpr45()

        case 5:
            return list_1(map_1(value, json.fields[0]))

        case 4:
            def mapping(tupled_arg: tuple[str, Json]) -> tuple[str, IEncodable]:
                return (tupled_arg[0], value(tupled_arg[1]))

            values: IEnumerable_1[tuple[str, IEncodable]] = map_2(mapping, json.fields[0])
            class ObjectExpr46(IEncodable):
                def Encode[_A](self, helpers_4: IEncoderHelpers_1[_A]) -> _A:
                    def mapping_1(tupled_arg_1: tuple[str, IEncodable]) -> tuple[str, _A]:
                        return (tupled_arg_1[0], tupled_arg_1[1].Encode(helpers_4))

                    arg: IEnumerable_1[tuple[str, Any]] = map_2(mapping_1, values)
                    return helpers_4.encode_object(arg)

            return ObjectExpr46()

        case _:
            class ObjectExpr47(IEncodable):
                def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                    return helpers.encode_null()

            return ObjectExpr47()



__all__ = ["Enum_byte", "Enum_int", "Enum_int16", "Enum_sbyte", "Enum_uint16", "Enum_uint32", "dict_1", "float32", "lazily", "list_1", "lossless_option", "lossy_option", "map", "resize_array", "seq", "tuple2", "tuple3", "tuple4", "tuple5", "tuple6", "tuple7", "tuple8", "value"]

