from __future__ import annotations
from abc import abstractmethod
from collections.abc import Callable
from decimal import Decimal
from typing import (Any, cast, Protocol)
from uuid import UUID
from fable_library.array_ import (fold as fold_1, zero_create)
from fable_library.array_ import Array
from fable_library.big_int import (from_int32, try_parse as try_parse_2)
from fable_library.core import (int32, FSharpRef, sbyte as sbyte_1, float64, int8, byte as byte_1, uint8, int16 as int16_1, uint16 as uint16_1, uint32 as uint32_1, int64 as int64_1, uint64 as uint64_1, float32 as float32_1)
from fable_library.date import (min_value, try_parse as try_parse_4)
from fable_library.decimal_ import try_parse as try_parse_3
from fable_library.decimal_ import create
from fable_library.guid import (parse, try_parse as try_parse_1)
from fable_library.list import (map as map_1, try_last, FSharpList, fold, empty, append, singleton, of_seq, reverse as reverse_1, cons, is_empty, head as head_1, tail as tail_1, length)
from fable_library.long import (to_number, from_number)
from fable_library.map import (of_list, of_seq as of_seq_1)
from fable_library.option import (some, Option, default_arg, default_arg as default_arg_1, value as value_7)
from fable_library.protocols import IEnumerable_1
from fable_library.record import Record
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.result import (FSharpResult_2, Error, Ok, Result_MapError, Result_Map)
from fable_library.seq import (reverse, append as append_1, to_list)
from fable_library.string_ import (join, get_length)
from fable_library.time_span import (create as create_1, try_parse as try_parse_5)
from fable_library.types import FSharpRef as FSharpRef_1
from fable_library.util import (UNIT, Unit, to_enumerable, nullable, compare_primitives, compare)
from .types import (ErrorReason_1, IDecoderHelpers_1, Decoder_1, ErrorReason_1_BadPrimitive, ErrorReason_1_BadPrimitiveExtra, ErrorReason_1_BadType, ErrorReason_1_BadPath, ErrorReason_1_BadField, ErrorReason_1_TooSmallArray, ErrorReason_1_BadOneOf, Json, Json_Boolean, Json_Null, Json_String, Json_Number, Json_Array, Json_Object, ErrorReason_1_FailMessage)

def Helpers_prependPath[JSONVALUE](path: str, err_: str, err__1: ErrorReason_1[JSONVALUE]) -> tuple[str, ErrorReason_1[JSONVALUE]]:
    err: tuple[str, ErrorReason_1[Any]] = (err_, err__1)
    return (path + err[0], err[1])


def generic_msg[JSONVALUE](helpers: IDecoderHelpers_1[JSONVALUE], msg: str, value_1: JSONVALUE, new_line: bool) -> str:
    try:
        return ((("Expecting " + msg) + " but instead got:") + ("\n" if new_line else " ")) + helpers.any_to_string(value_1)

    except Exception as match_value:
        return (("Expecting " + msg) + " but decoder failed. Couldn\'t report given value due to circular structure.") + ("\n" if new_line else " ")



def error_to_string[JSONVALUE](helpers: IDecoderHelpers_1[JSONVALUE], path: str, error: ErrorReason_1[JSONVALUE]) -> str:
    def mapping(error_1: tuple[str, ErrorReason_1[JSONVALUE]], helpers: Any=helpers, path: Any=path) -> str:
        tupled_arg: tuple[str, ErrorReason_1[Any]] = Helpers_prependPath(path, error_1[0], error_1[1])
        return error_to_string(helpers, tupled_arg[0], tupled_arg[1])

    reason_1: str = generic_msg(helpers, error.fields[0], error.fields[1], True) if (error.tag == int32(2)) else (((generic_msg(helpers, error.fields[0], error.fields[1], False) + "\nReason: ") + error.fields[2]) if (error.tag == int32(1)) else (generic_msg(helpers, error.fields[0], error.fields[1], True) if (error.tag == int32(3)) else ((generic_msg(helpers, error.fields[0], error.fields[1], True) + (("\nNode `" + error.fields[2]) + "` is unkown.")) if (error.tag == int32(4)) else (((("Expecting " + error.fields[0]) + ".\n") + helpers.any_to_string(error.fields[1])) if (error.tag == int32(5)) else (("The following errors were found:\n\n" + join("\n\n", map_1(mapping, error.fields[0]))) if (error.tag == int32(7)) else (("The following `failure` occurred with the decoder: " + error.fields[0]) if (error.tag == int32(6)) else generic_msg(helpers, error.fields[0], error.fields[1], False)))))))
    match error.tag:
        case 7:
            return reason_1

        case _:
            return (("Error at: `" + path) + "`\n") + reason_1



def Advanced_fromValue[JSONVALUE, T](helpers: IDecoderHelpers_1[JSONVALUE], decoder: Decoder_1[T], value_1: JSONVALUE) -> FSharpResult_2[T, str]:
    """Runs the decoder against the given JSON value.

    If the decoder fails, it reports the error prefixed with the given path.
    """
    match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_1)
    match match_value.tag:
        case 1:
            error: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
            return Error(error_to_string(helpers, error[0], error[1]))

        case _:
            return Ok(match_value.fields[0])



class ObjectExpr202(Decoder_1[str]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[str, tuple[str, ErrorReason_1[_A]]]:
        return Ok(helpers.as_string(value_1)) if helpers.is_string(value_1) else Error(("", ErrorReason_1_BadPrimitive("a string", value_1)))


string: Decoder_1[str] = ObjectExpr202()

class ObjectExpr203(Decoder_1[str]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[str, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_string(value_1):
            str_1: str = helpers.as_string(value_1)
            return Ok(str_1[int32.ZERO]) if (get_length(str_1) == int32.ONE) else Error(("", ErrorReason_1_BadPrimitive("a single character string", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a char", value_1)))



char: Decoder_1[str] = ObjectExpr203()

class ObjectExpr206(Decoder_1[UUID]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[UUID, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_string(value_1):
            match_value: tuple[bool, UUID]
            out_arg: UUID = parse("00000000-0000-0000-0000-000000000000")
            def _arrow204(__unit: Unit=UNIT) -> UUID:
                return out_arg

            def _arrow205(v: UUID) -> None:
                nonlocal out_arg
                out_arg = v

            match_value = (try_parse_1(helpers.as_string(value_1), FSharpRef(_arrow204, _arrow205)), out_arg)
            return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive("a guid", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a guid", value_1)))



guid: Decoder_1[UUID] = ObjectExpr206()

class ObjectExpr207(Decoder_1[None]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[None, tuple[str, ErrorReason_1[_A]]]:
        return Ok(None) if helpers.is_null_value(value_1) else Error(("", ErrorReason_1_BadPrimitive("null", value_1)))


unit: Decoder_1[None] = ObjectExpr207()

def _arrow211(__unit: Unit=UNIT) -> Decoder_1[sbyte_1]:
    name: str = "a sbyte"
    class ObjectExpr210(Decoder_1[sbyte_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[sbyte_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(sbyte_1(float_value)) if ((float_value <= float64(int8(127))) if (float64(int8(-128)) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, sbyte_1]
                arg: str = helpers.as_string(value_2)
                out_arg: sbyte_1 = int8.ZERO
                def _arrow208(__unit: Unit=UNIT) -> sbyte_1:
                    return out_arg

                def _arrow209(v: sbyte_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (int8.try_parse(arg, int32(511), FSharpRef(_arrow208, _arrow209)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr210()


sbyte: Decoder_1[sbyte_1] = _arrow211()

def _arrow215(__unit: Unit=UNIT) -> Decoder_1[byte_1]:
    name: str = "a byte"
    class ObjectExpr214(Decoder_1[byte_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[byte_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(byte_1(float_value)) if ((float_value <= float64(uint8(255))) if (float64(uint8.ZERO) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, byte_1]
                arg: str = helpers.as_string(value_2)
                out_arg: byte_1 = uint8.ZERO
                def _arrow212(__unit: Unit=UNIT) -> byte_1:
                    return out_arg

                def _arrow213(v: byte_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (uint8.try_parse(arg, int32(511), FSharpRef(_arrow212, _arrow213)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr214()


byte: Decoder_1[byte_1] = _arrow215()

def _arrow219(__unit: Unit=UNIT) -> Decoder_1[int16_1]:
    name: str = "an int16"
    class ObjectExpr218(Decoder_1[int16_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[int16_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(int16_1(float_value)) if ((float_value <= float64(int16_1(32767))) if (float64(int16_1(-32768)) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, int16_1]
                arg: str = helpers.as_string(value_2)
                out_arg: int16_1 = int16_1.ZERO
                def _arrow216(__unit: Unit=UNIT) -> int16_1:
                    return out_arg

                def _arrow217(v: int16_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (int16_1.try_parse(arg, int32(511), FSharpRef(_arrow216, _arrow217)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr218()


int16: Decoder_1[int16_1] = _arrow219()

def _arrow223(__unit: Unit=UNIT) -> Decoder_1[uint16_1]:
    name: str = "an uint16"
    class ObjectExpr222(Decoder_1[uint16_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[uint16_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(uint16_1(float_value)) if ((float_value <= float64(uint16_1(65535))) if (float64(uint16_1.ZERO) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, uint16_1]
                arg: str = helpers.as_string(value_2)
                out_arg: uint16_1 = uint16_1.ZERO
                def _arrow220(__unit: Unit=UNIT) -> uint16_1:
                    return out_arg

                def _arrow221(v: uint16_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (uint16_1.try_parse(arg, int32(511), FSharpRef(_arrow220, _arrow221)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr222()


uint16: Decoder_1[uint16_1] = _arrow223()

def _arrow227(__unit: Unit=UNIT) -> Decoder_1[int32]:
    name: str = "an int"
    class ObjectExpr226(Decoder_1[int32]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[int32, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(int32(float_value)) if ((float_value <= float64(int32(2147483647))) if (float64(int32(-2147483648)) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, int32]
                arg: str = helpers.as_string(value_2)
                out_arg: int32 = int32.ZERO
                def _arrow224(__unit: Unit=UNIT) -> int32:
                    return out_arg

                def _arrow225(v: int32) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (int32.try_parse(arg, int32(511), FSharpRef(_arrow224, _arrow225)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr226()


int_1: Decoder_1[int32] = _arrow227()

def _arrow231(__unit: Unit=UNIT) -> Decoder_1[uint32_1]:
    name: str = "an uint32"
    class ObjectExpr230(Decoder_1[uint32_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[uint32_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(uint32_1(float_value)) if ((float_value <= float64(uint32_1(4294967295))) if (float64(uint32_1.ZERO) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, uint32_1]
                arg: str = helpers.as_string(value_2)
                out_arg: uint32_1 = uint32_1.ZERO
                def _arrow228(__unit: Unit=UNIT) -> uint32_1:
                    return out_arg

                def _arrow229(v: uint32_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (uint32_1.try_parse(arg, int32(511), FSharpRef(_arrow228, _arrow229)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr230()


uint32: Decoder_1[uint32_1] = _arrow231()

def _arrow235(__unit: Unit=UNIT) -> Decoder_1[int64_1]:
    name: str = "an int64"
    class ObjectExpr234(Decoder_1[int64_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[int64_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(from_number(float_value, False)) if ((float_value <= to_number(int64_1(9223372036854775807))) if (to_number(int64_1(-9223372036854775808)) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, int64_1]
                arg: str = helpers.as_string(value_2)
                out_arg: int64_1 = int64_1.ZERO
                def _arrow232(__unit: Unit=UNIT) -> int64_1:
                    return out_arg

                def _arrow233(v: int64_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (int64_1.try_parse(arg, int32(511), FSharpRef(_arrow232, _arrow233)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr234()


int64: Decoder_1[int64_1] = _arrow235()

def _arrow239(__unit: Unit=UNIT) -> Decoder_1[uint64_1]:
    name: str = "an uint64"
    class ObjectExpr238(Decoder_1[uint64_1]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_2: _A) -> FSharpResult_2[uint64_1, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_number(value_2):
                if helpers.is_integral_value(value_2):
                    float_value: float64 = helpers.as_float(value_2)
                    return Ok(from_number(float_value, True)) if ((float_value <= to_number(uint64_1(18446744073709551615))) if (to_number(uint64_1.ZERO) <= float_value) else False) else Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value was either too large or too small for " + name)))

                else:
                    return Error(("", ErrorReason_1_BadPrimitiveExtra(name, value_2, "Value is not an integral value")))


            elif helpers.is_string(value_2):
                match_value: tuple[bool, uint64_1]
                arg: str = helpers.as_string(value_2)
                out_arg: uint64_1 = uint64_1.ZERO
                def _arrow236(__unit: Unit=UNIT) -> uint64_1:
                    return out_arg

                def _arrow237(v: uint64_1) -> None:
                    nonlocal out_arg
                    out_arg = v

                match_value = (uint64_1.try_parse(arg, int32(511), FSharpRef(_arrow236, _arrow237)), out_arg)
                return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive(name, value_2)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive(name, value_2)))


    return ObjectExpr238()


uint64: Decoder_1[uint64_1] = _arrow239()

class ObjectExpr242(Decoder_1[int]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[int, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_number(value_1):
            return Ok(from_int32(helpers.as_int(value_1)))

        elif helpers.is_string(value_1):
            parse_result: tuple[bool, int]
            out_arg: int = from_int32(int32.ZERO)
            def _arrow240(__unit: Unit=UNIT) -> int:
                return out_arg

            def _arrow241(v: int) -> None:
                nonlocal out_arg
                out_arg = v

            parse_result = (try_parse_2(helpers.as_string(value_1), FSharpRef(_arrow240, _arrow241)), out_arg)
            return Ok(parse_result[1]) if parse_result[0] else Error(("", ErrorReason_1_BadPrimitive("a bigint", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a bigint", value_1)))



bigint: Decoder_1[int] = ObjectExpr242()

class ObjectExpr243(Decoder_1[bool]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[bool, tuple[str, ErrorReason_1[_A]]]:
        return Ok(helpers.as_boolean(value_1)) if helpers.is_boolean(value_1) else Error(("", ErrorReason_1_BadPrimitive("a boolean", value_1)))


bool_1: Decoder_1[bool] = ObjectExpr243()

class ObjectExpr244(Decoder_1[float64]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[float64, tuple[str, ErrorReason_1[_A]]]:
        return Ok(helpers.as_float(value_1)) if helpers.is_number(value_1) else Error(("", ErrorReason_1_BadPrimitive("a float", value_1)))


float_1: Decoder_1[float64] = ObjectExpr244()

class ObjectExpr245(Decoder_1[float32_1]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[float32_1, tuple[str, ErrorReason_1[_A]]]:
        return Ok(helpers.as_float32(value_1)) if helpers.is_number(value_1) else Error(("", ErrorReason_1_BadPrimitive("a float32", value_1)))


float32: Decoder_1[float32_1] = ObjectExpr245()

class ObjectExpr248(Decoder_1[Decimal]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[Decimal, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_number(value_1):
            return Ok(create(helpers.as_float(value_1)))

        elif helpers.is_string(value_1):
            match_value: tuple[bool, Decimal]
            out_arg: Decimal = create(int32.ZERO)
            def _arrow246(__unit: Unit=UNIT) -> Decimal:
                return out_arg

            def _arrow247(v: Decimal) -> None:
                nonlocal out_arg
                out_arg = v

            match_value = (try_parse_3(helpers.as_string(value_1), FSharpRef(_arrow246, _arrow247)), out_arg)
            return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive("a decimal", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a decimal", value_1)))



decimal: Decoder_1[Decimal] = ObjectExpr248()

class ObjectExpr251(Decoder_1[Any]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[Any, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_string(value_1):
            match_value: tuple[bool, Any]
            out_arg: Any = min_value()
            def _arrow249(__unit: Unit=UNIT) -> Any:
                return out_arg

            def _arrow250(v: Any) -> None:
                nonlocal out_arg
                out_arg = v

            match_value = (try_parse_4(helpers.as_string(value_1), FSharpRef(_arrow249, _arrow250)), out_arg)
            return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive("a datetime", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a datetime", value_1)))



datetime_local: Decoder_1[Any] = ObjectExpr251()

class ObjectExpr254(Decoder_1[Any]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[Any, tuple[str, ErrorReason_1[_A]]]:
        if helpers.is_string(value_1):
            match_value: tuple[bool, Any]
            out_arg: Any = create_1(int32.ZERO)
            def _arrow252(__unit: Unit=UNIT) -> Any:
                return out_arg

            def _arrow253(v: Any) -> None:
                nonlocal out_arg
                out_arg = v

            match_value = (try_parse_5(helpers.as_string(value_1), FSharpRef(_arrow252, _arrow253)), out_arg)
            return Ok(match_value[1]) if match_value[0] else Error(("", ErrorReason_1_BadPrimitive("a timespan", value_1)))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("a timespan", value_1)))



timespan: Decoder_1[Any] = ObjectExpr254()

def decode_maybe_null[JSONVALUE, VALUE](helpers: IDecoderHelpers_1[JSONVALUE], path: str, decoder: Decoder_1[VALUE], value_1: JSONVALUE) -> FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[JSONVALUE]]]:
    if helpers.is_null_value(value_1):
        return Ok(None)

    else:
        match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_1)
        match match_value.tag:
            case 1:
                def _arrow255(path: Any=path) -> tuple[str, ErrorReason_1[JSONVALUE]]:
                    tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                    return Helpers_prependPath(path, tupled_arg[0], tupled_arg[1])

                return Error(_arrow255())

            case _:
                return Ok(some(match_value.fields[0]))




def optional[VALUE](field_name: str, decoder: Decoder_1[VALUE]) -> Decoder_1[Option[VALUE]]:
    class ObjectExpr256(Decoder_1[Option[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, field_name: Any=field_name, decoder: Any=decoder) -> FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[_A]]]:
            return (decode_maybe_null(helpers, "." + field_name, decoder, helpers.get_property(field_name, value_1)) if helpers.has_property(field_name, value_1) else Ok(None)) if helpers.is_object(value_1) else Error(("", ErrorReason_1_BadType("an object", value_1)))

    return ObjectExpr256()


def bad_path_error[_A, _B](field_names: FSharpList[str], current_path: str | None, value_1: _A) -> FSharpResult_2[_B, tuple[str, ErrorReason_1[_A]]]:
    return Error(("." + default_arg(current_path, join(".", field_names)), ErrorReason_1_BadPath(("an object with path `" + join(".", field_names)) + "`", value_1, default_arg_1(try_last(field_names), ""))))


def map2[A, B, OUTPUT](ctor: Callable[[A, B], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B]) -> Decoder_1[OUTPUT]:
    class ObjectExpr259(Decoder_1[Any]):
        def Decode[_C](self, helpers: IDecoderHelpers_1[_C], value_1: _C, ctor: Any=ctor, d1: Any=d1, d2: Any=d2) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_C]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0]))



    return ObjectExpr259()


def optional_at[VALUE](field_names: FSharpList[str], decoder: Decoder_1[VALUE]) -> Decoder_1[Option[VALUE]]:
    class ObjectExpr265(Decoder_1[Option[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], first_value: _A, field_names: Any=field_names, decoder: Any=decoder) -> FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[_A]]]:
            def folder(tupled_arg: tuple[str, _A, FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[_A]]] | None], field_1: str) -> tuple[str, _A, FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[_A]]] | None]:
                cur_path: str = tupled_arg[0]
                cur_value: Any = tupled_arg[1]
                res: FSharpResult_2[Option[Any], tuple[str, ErrorReason_1[Any]]] | None = tupled_arg[2]
                if res is None:
                    if helpers.is_null_value(cur_value):
                        return (cur_path, cur_value, Ok(None))

                    elif helpers.is_object(cur_value):
                        if helpers.has_property(field_1, cur_value):
                            return ((cur_path + ".") + field_1, helpers.get_property(field_1, cur_value), None)

                        else:
                            return (cur_path, cur_value, Ok(None))


                    else:
                        return (cur_path, cur_value, Error((cur_path, ErrorReason_1_BadType("an object", cur_value))))


                else:
                    return (cur_path, cur_value, res)


            _arg: tuple[str, Any, FSharpResult_2[Option[Any], tuple[str, ErrorReason_1[Any]]] | None] = fold(folder, ("", first_value, None), field_names)
            if _arg[2] is None:
                last_value: Any = _arg[1]
                return Ok(None) if helpers.is_null_value(last_value) else decode_maybe_null(helpers, _arg[0], decoder, last_value)

            else:
                return value_7(_arg[2])


    return ObjectExpr265()


def field[VALUE](field_name: str, decoder: Decoder_1[VALUE]) -> Decoder_1[VALUE]:
    class ObjectExpr272(Decoder_1[Any]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, field_name: Any=field_name, decoder: Any=decoder) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_object(value_1):
                if helpers.has_property(field_name, value_1):
                    field_value: Any = helpers.get_property(field_name, value_1)
                    path: str = "." + field_name
                    def mapping(tupled_arg: tuple[str, ErrorReason_1[_A]]) -> tuple[str, ErrorReason_1[_A]]:
                        return Helpers_prependPath(path, tupled_arg[0], tupled_arg[1])

                    return Result_MapError(mapping, decoder.Decode(helpers, field_value))

                else:
                    return Error(("", ErrorReason_1_BadField(("an object with a field named `" + field_name) + "`", value_1)))


            else:
                return Error(("", ErrorReason_1_BadType("an object", value_1)))


    return ObjectExpr272()


def at[VALUE](field_names: FSharpList[str], decoder: Decoder_1[VALUE]) -> Decoder_1[VALUE]:
    class ObjectExpr279(Decoder_1[Any]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], first_value: _A, field_names: Any=field_names, decoder: Any=decoder) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
            def folder(tupled_arg: tuple[str, _A, FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]] | None], field_1: str) -> tuple[str, _A, FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]] | None]:
                cur_path: str = tupled_arg[0]
                cur_value: Any = tupled_arg[1]
                res: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] | None = tupled_arg[2]
                if res is None:
                    if helpers.is_null_value(cur_value):
                        return (cur_path, cur_value, bad_path_error(field_names, cur_path, first_value))

                    elif helpers.is_object(cur_value):
                        if helpers.has_property(field_1, cur_value):
                            return ((cur_path + ".") + field_1, helpers.get_property(field_1, cur_value), None)

                        else:
                            return (cur_path, cur_value, bad_path_error(field_names, None, first_value))


                    else:
                        return (cur_path, cur_value, Error((cur_path, ErrorReason_1_BadType("an object", cur_value))))


                else:
                    return (cur_path, cur_value, res)


            _arg: tuple[str, Any, FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] | None] = fold(folder, ("", first_value, None), field_names)
            def mapping(tupled_arg_1: tuple[str, ErrorReason_1[_A]]) -> tuple[str, ErrorReason_1[_A]]:
                return Helpers_prependPath(_arg[0], tupled_arg_1[0], tupled_arg_1[1])

            return Result_MapError(mapping, decoder.Decode(helpers, _arg[1])) if (_arg[2] is None) else value_7(_arg[2])

    return ObjectExpr279()


def index[VALUE](requested_index: int32, decoder: Decoder_1[VALUE]) -> Decoder_1[VALUE]:
    class ObjectExpr284(Decoder_1[Any]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, requested_index: Any=requested_index, decoder: Any=decoder) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_array(value_1):
                v_array: Array[Any] = helpers.as_array(value_1)
                path: str = (".[" + int32(requested_index).to_string()) + "]"
                def mapping(tupled_arg: tuple[str, ErrorReason_1[_A]]) -> tuple[str, ErrorReason_1[_A]]:
                    return Helpers_prependPath(path, tupled_arg[0], tupled_arg[1])

                return Result_MapError(mapping, decoder.Decode(helpers, v_array[requested_index])) if (requested_index < int32(len(v_array))) else Error((path, ErrorReason_1_TooSmallArray(((("a longer array. Need index `" + int32(requested_index).to_string()) + "` but there are only `") + int32(int32(len(v_array))).to_string()) + "` entries", value_1)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive("an array", value_1)))


    return ObjectExpr284()


def list_1[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[FSharpList[VALUE]]:
    class ObjectExpr292(Decoder_1[FSharpList[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[FSharpList[VALUE], tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_array(value_1):
                tokens: Array[Any] = helpers.as_array(value_1)
                i: int32 = int32.ZERO
                result: FSharpList[Any] = empty()
                error: tuple[str, ErrorReason_1[Any]] | None = cast(tuple[str, ErrorReason_1[Any]] | None, None)
                while (error is None) if (i < int32(len(tokens))) else False:
                    value_2: Any = tokens[i]
                    match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_2)
                    match match_value.tag:
                        case 1:
                            def _arrow291(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_A]]:
                                tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                                return Helpers_prependPath((".[" + int32(i).to_string()) + "]", tupled_arg[0], tupled_arg[1])

                            x: tuple[str, ErrorReason_1[Any]] | None = _arrow291()
                            error = x

                        case _:
                            result = append(result, singleton(match_value.fields[0]))

                    i = i + int32.ONE
                return Ok(result) if (error is None) else Error(value_7(error))

            else:
                return Error(("", ErrorReason_1_BadPrimitive("a list", value_1)))


    return ObjectExpr292()


def resize_array[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[list[VALUE]]:
    class ObjectExpr300(Decoder_1[list[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[list[VALUE], tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_array(value_1):
                tokens: Array[Any] = helpers.as_array(value_1)
                i: int32 = int32.ZERO
                result: list[Any] = []
                error: tuple[str, ErrorReason_1[Any]] | None = cast(tuple[str, ErrorReason_1[Any]] | None, None)
                while (error is None) if (i < int32(len(tokens))) else False:
                    value_2: Any = tokens[i]
                    match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_2)
                    match match_value.tag:
                        case 1:
                            def _arrow299(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_A]]:
                                tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                                return Helpers_prependPath((".[" + int32(i).to_string()) + "]", tupled_arg[0], tupled_arg[1])

                            error = _arrow299()

                        case _:
                            (result.append(match_value.fields[0]))

                    i = i + int32.ONE
                return Ok(list(result)) if (error is None) else Error(value_7(error))

            else:
                return Error(("", ErrorReason_1_BadPrimitive("a ResizeArray", value_1)))


    return ObjectExpr300()


def seq[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[IEnumerable_1[VALUE]]:
    class ObjectExpr305(Decoder_1[IEnumerable_1[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[IEnumerable_1[VALUE], tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_array(value_1):
                i: int32 = int32.NEG_ONE
                def folder(acc: FSharpResult_2[IEnumerable_1[VALUE], tuple[str, ErrorReason_1[_A]]], value_2: _A) -> FSharpResult_2[IEnumerable_1[VALUE], tuple[str, ErrorReason_1[_A]]]:
                    nonlocal i
                    i = i + int32.ONE
                    match acc.tag:
                        case 0:
                            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_2)
                            match match_value.tag:
                                case 0:
                                    return Ok(append_1(to_enumerable([match_value.fields[0]]), acc.fields[0]))

                                case _:
                                    def _arrow304(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_A]]:
                                        tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                                        return Helpers_prependPath((".[" + int32(i).to_string()) + "]", tupled_arg[0], tupled_arg[1])

                                    return Error(_arrow304())


                        case _:
                            return acc


                return Result_Map(reverse, fold_1(folder, Ok(to_enumerable([])), helpers.as_array(value_1)))

            else:
                return Error(("", ErrorReason_1_BadPrimitive("a seq", value_1)))


    return ObjectExpr305()


def array[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[Array[VALUE]]:
    class ObjectExpr307(Decoder_1[Array[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[Array[VALUE], tuple[str, ErrorReason_1[_A]]]:
            if helpers.is_array(value_1):
                i: int32 = int32.NEG_ONE
                tokens: Array[Any] = helpers.as_array(value_1)
                def folder(acc: FSharpResult_2[Array[VALUE], tuple[str, ErrorReason_1[_A]]], value_2: _A) -> FSharpResult_2[Array[VALUE], tuple[str, ErrorReason_1[_A]]]:
                    nonlocal i
                    i = i + int32.ONE
                    match acc.tag:
                        case 0:
                            acc_1: Array[Any] = acc.fields[0]
                            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_2)
                            match match_value.tag:
                                case 0:
                                    acc_1[i] = match_value.fields[0]
                                    return Ok(acc_1)

                                case _:
                                    def _arrow306(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_A]]:
                                        tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                                        return Helpers_prependPath((".[" + int32(i).to_string()) + "]", tupled_arg[0], tupled_arg[1])

                                    return Error(_arrow306())


                        case _:
                            return acc


                return fold_1(folder, Ok(zero_create(int32(len(tokens)), cast(Any, None))), tokens)

            else:
                return Error(("", ErrorReason_1_BadPrimitive("an array", value_1)))


    return ObjectExpr307()


class ObjectExpr308(Decoder_1[FSharpList[str]]):
    def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A) -> FSharpResult_2[FSharpList[str], tuple[str, ErrorReason_1[_A]]]:
        return Ok(of_seq(helpers.get_properties(value_1))) if helpers.is_object(value_1) else Error(("", ErrorReason_1_BadPrimitive("an object", value_1)))


keys: Decoder_1[FSharpList[str]] = ObjectExpr308()

def key_value_pairs[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[FSharpList[tuple[str, VALUE]]]:
    class ObjectExpr309(Decoder_1[FSharpList[tuple[str, Any]]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[FSharpList[tuple[str, VALUE]], tuple[str, ErrorReason_1[_A]]]:
            match_value: FSharpResult_2[FSharpList[str], tuple[str, ErrorReason_1[Any]]] = keys.Decode(helpers, value_1)
            match match_value.tag:
                case 1:
                    return Error(match_value.fields[0])

                case _:
                    def folder(acc: FSharpResult_2[FSharpList[tuple[str, VALUE]], tuple[str, ErrorReason_1[_A]]], prop: str) -> FSharpResult_2[FSharpList[tuple[str, VALUE]], tuple[str, ErrorReason_1[_A]]]:
                        match acc.tag:
                            case 0:
                                field_value: Any = helpers.get_property(prop, value_1)
                                match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, field_value)
                                match match_value_1.tag:
                                    case 0:
                                        return Ok(cons((prop, match_value_1.fields[0]), acc.fields[0]))

                                    case _:
                                        return Error(match_value_1.fields[0])


                            case _:
                                return acc


                    return Result_Map(reverse_1, fold(folder, Ok(empty()), match_value.fields[0]))


    return ObjectExpr309()


def one_of[VALUE](decoders: FSharpList[Decoder_1[VALUE]]) -> Decoder_1[VALUE]:
    class ObjectExpr310(Decoder_1[Any]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoders: Any=decoders) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
            def runner(decoders_1_mut: FSharpList[Decoder_1[VALUE]], errors_mut: FSharpList[tuple[str, ErrorReason_1[_A]]]) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
                while True:
                    (decoders_1, errors) = (decoders_1_mut, errors_mut)
                    if is_empty(decoders_1):
                        return Error(("", ErrorReason_1_BadOneOf(errors)))

                    else:
                        match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = head_1(decoders_1).Decode(helpers, value_1)
                        match match_value.tag:
                            case 1:
                                decoders_1_mut = tail_1(decoders_1)
                                errors_mut = append(errors, singleton(match_value.fields[0]))
                                continue

                            case _:
                                return Ok(match_value.fields[0])


                    break

            return runner(decoders, empty())

    return ObjectExpr310()


def nil[A](output: A=UNIT) -> Decoder_1[A]:
    class ObjectExpr311(Decoder_1[Any]):
        def Decode[_B](self, helpers: IDecoderHelpers_1[_B], value_1: _B, output: Any=output) -> FSharpResult_2[A, tuple[str, ErrorReason_1[_B]]]:
            return Ok(output) if helpers.is_null_value(value_1) else Error(("", ErrorReason_1_BadPrimitive("null", value_1)))

    return ObjectExpr311()


def _expr354() -> TypeInfo:
    return class_type("Thoth.Json.Core.Decode.ValueDecoder", None, ValueDecoder)


class ValueDecoder:
    def __init__(self, __unit: Unit=UNIT) -> None:
        pass

    def Decode[JSONVALUE, _JSONVALUE](self, helpers: IDecoderHelpers_1[_JSONVALUE], value_1: _JSONVALUE) -> FSharpResult_2[Json, tuple[str, ErrorReason_1[_JSONVALUE]]]:
        this: ValueDecoder = self
        decoder: Decoder_1[Json] = this
        if helpers.is_boolean(value_1):
            return Ok(Json_Boolean(helpers.as_boolean(value_1)))

        elif helpers.is_null_value(value_1):
            return Ok(Json_Null())

        elif helpers.is_string(value_1):
            return Ok(Json_String(helpers.as_string(value_1)))

        elif helpers.is_number(value_1):
            return Ok(Json_Number(helpers.as_float(value_1)))

        elif helpers.is_array(value_1):
            tokens: Array[Any] = helpers.as_array(value_1)
            result: Array[Json] = zero_create(int32(len(tokens)), cast(Any, None))
            i: int32 = int32.ZERO
            error: tuple[str, ErrorReason_1[Any]] | None = cast(tuple[str, ErrorReason_1[Any]] | None, None)
            while (error is None) if (i < int32(len(tokens))) else False:
                value_2: Any = tokens[i]
                match_value: FSharpResult_2[Json, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_2)
                match match_value.tag:
                    case 1:
                        def _arrow330(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_JSONVALUE]]:
                            tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                            return Helpers_prependPath((".[" + str(i)) + "]", tupled_arg[0], tupled_arg[1])

                        x: tuple[str, ErrorReason_1[Any]] | None = _arrow330()
                        error = x

                    case _:
                        result[i] = match_value.fields[0]

                i = i + int32.ONE
            return Ok(Json_Array(to_list(result))) if (error is None) else Error(value_7(error))

        elif helpers.is_object(value_1):
            props: Array[str] = Array[Any](helpers.get_properties(value_1))
            result_1: Array[tuple[str, Json]] = zero_create(int32(len(props)), cast(Any, None))
            i_1: int32 = int32.ZERO
            error_1: tuple[str, ErrorReason_1[Any]] | None = cast(tuple[str, ErrorReason_1[Any]] | None, None)
            while (error_1 is None) if (i_1 < int32(len(props))) else False:
                key: str = props[i_1]
                value_4: Any = helpers.get_property(key, value_1)
                match_value_1: FSharpResult_2[Json, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_4)
                match match_value_1.tag:
                    case 1:
                        def _arrow345(__unit: Unit=UNIT) -> tuple[str, ErrorReason_1[_JSONVALUE]]:
                            tupled_arg_1: tuple[str, ErrorReason_1[Any]] = match_value_1.fields[0]
                            return Helpers_prependPath("." + key, tupled_arg_1[0], tupled_arg_1[1])

                        x_1: tuple[str, ErrorReason_1[Any]] | None = _arrow345()
                        error_1 = x_1

                    case _:
                        result_1[i_1] = (key, match_value_1.fields[0])

                i_1 = i_1 + int32.ONE
            return Ok(Json_Object(to_list(result_1))) if (error_1 is None) else Error(value_7(error_1))

        else:
            return Error(("", ErrorReason_1_BadPrimitive("any", value_1)))



ValueDecoder_reflection = _expr354

def ValueDecoder__ctor(__unit: Unit=UNIT) -> ValueDecoder:
    return ValueDecoder(__unit)


value: Decoder_1[Json] = ValueDecoder__ctor()

def succeed[A](output: A=UNIT) -> Decoder_1[A]:
    class ObjectExpr363(Decoder_1[Any]):
        def Decode[_B](self, _arg: IDecoderHelpers_1[_B], _arg_1: _B, output: Any=output) -> FSharpResult_2[A, tuple[str, ErrorReason_1[_B]]]:
            return Ok(output)

    return ObjectExpr363()


def fail[A](msg: str) -> Decoder_1[A]:
    class ObjectExpr368(Decoder_1[Any]):
        def Decode[_B](self, _arg: IDecoderHelpers_1[_B], _arg_1: _B, msg: Any=msg) -> FSharpResult_2[A, tuple[str, ErrorReason_1[_B]]]:
            return Error(("", ErrorReason_1_FailMessage(msg)))

    return ObjectExpr368()


def and_then[A, B](cb: Callable[[A], Decoder_1[B]], decoder: Decoder_1[A]) -> Decoder_1[B]:
    class ObjectExpr375(Decoder_1[Any]):
        def Decode[_C](self, helpers: IDecoderHelpers_1[_C], value_1: _C, cb: Any=cb, decoder: Any=decoder) -> FSharpResult_2[B, tuple[str, ErrorReason_1[_C]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_1)
            match match_value.tag:
                case 0:
                    return cb(match_value.fields[0]).Decode(helpers, value_1)

                case _:
                    return Error(match_value.fields[0])


    return ObjectExpr375()


def all[A](decoders: FSharpList[Decoder_1[A]]) -> Decoder_1[FSharpList[A]]:
    class ObjectExpr379(Decoder_1[FSharpList[Any]]):
        def Decode[_B](self, helpers: IDecoderHelpers_1[_B], value_1: _B, decoders: Any=decoders) -> FSharpResult_2[FSharpList[A], tuple[str, ErrorReason_1[_B]]]:
            def runner(decoders_1_mut: FSharpList[Decoder_1[A]], values_mut: FSharpList[A]) -> FSharpResult_2[FSharpList[A], tuple[str, ErrorReason_1[_B]]]:
                while True:
                    (decoders_1, values) = (decoders_1_mut, values_mut)
                    if is_empty(decoders_1):
                        return Ok(values)

                    else:
                        match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = head_1(decoders_1).Decode(helpers, value_1)
                        match match_value.tag:
                            case 1:
                                return Error(match_value.fields[0])

                            case _:
                                decoders_1_mut = tail_1(decoders_1)
                                values_mut = append(values, singleton(match_value.fields[0]))
                                continue


                    break

            return runner(decoders, empty())

    return ObjectExpr379()


def _expr381(gen0: TypeInfo) -> TypeInfo:
    return class_type("Thoth.Json.Core.Decode.LazyDecoder`1", Array([gen0]), LazyDecoder_1, class_type("System.ValueType"))


class LazyDecoder_1[T](Record):
    __slots__ = ["x"]
    def __init__(self, x: Any) -> None:
        super().__init__()
        self.x: Any = x

    def Decode[JSONVALUE, JSON](self, helpers: IDecoderHelpers_1[JSON], json: JSON) -> FSharpResult_2[T, tuple[str, ErrorReason_1[JSON]]]:
        this: LazyDecoder_1[Any] = self
        decoder: Decoder_1[Any] = this.x.Value
        return decoder.Decode(helpers, json)


LazyDecoder_1_reflection = _expr381

def LazyDecoder_1__ctor_Z67290E74[T](x: Any) -> LazyDecoder_1[T]:
    return LazyDecoder_1(x)


def lazily[T](x: Any) -> Decoder_1[T]:
    return LazyDecoder_1__ctor_Z67290E74(x)


def map[A, OUTPUT](ctor: Callable[[A], OUTPUT], d1: Decoder_1[A]) -> Decoder_1[OUTPUT]:
    class ObjectExpr382(Decoder_1[Any]):
        def Decode[_B](self, helpers: IDecoderHelpers_1[_B], value_1: _B, ctor: Any=ctor, d1: Any=d1) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_B]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match match_value.tag:
                case 1:
                    return Error(match_value.fields[0])

                case _:
                    return Ok(ctor(match_value.fields[0]))


    return ObjectExpr382()


def map3[A, B, C, OUTPUT](ctor: Callable[[A, B, C], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C]) -> Decoder_1[OUTPUT]:
    class ObjectExpr383(Decoder_1[Any]):
        def Decode[_D](self, helpers: IDecoderHelpers_1[_D], value_1: _D, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_D]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0]))




    return ObjectExpr383()


def map4[A, B, C, D, OUTPUT](ctor: Callable[[A, B, C, D], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D]) -> Decoder_1[OUTPUT]:
    class ObjectExpr384(Decoder_1[Any]):
        def Decode[_E](self, helpers: IDecoderHelpers_1[_E], value_1: _E, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3, d4: Any=d4) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_E]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            match_value_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d4.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    copy_of_struct_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_3
                                    match copy_of_struct_3.tag:
                                        case 1:
                                            return Error(copy_of_struct_3.fields[0])

                                        case _:
                                            return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0], copy_of_struct_3.fields[0]))





    return ObjectExpr384()


def map5[A, B, C, D, E, OUTPUT](ctor: Callable[[A, B, C, D, E], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E]) -> Decoder_1[OUTPUT]:
    class ObjectExpr385(Decoder_1[Any]):
        def Decode[_F](self, helpers: IDecoderHelpers_1[_F], value_1: _F, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3, d4: Any=d4, d5: Any=d5) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_F]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            match_value_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d4.Decode(helpers, value_1)
            match_value_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d5.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    copy_of_struct_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_3
                                    match copy_of_struct_3.tag:
                                        case 1:
                                            return Error(copy_of_struct_3.fields[0])

                                        case _:
                                            copy_of_struct_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_4
                                            match copy_of_struct_4.tag:
                                                case 1:
                                                    return Error(copy_of_struct_4.fields[0])

                                                case _:
                                                    return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0], copy_of_struct_3.fields[0], copy_of_struct_4.fields[0]))






    return ObjectExpr385()


def map6[A, B, C, D, E, F, OUTPUT](ctor: Callable[[A, B, C, D, E, F], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F]) -> Decoder_1[OUTPUT]:
    class ObjectExpr386(Decoder_1[Any]):
        def Decode[_G](self, helpers: IDecoderHelpers_1[_G], value_1: _G, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3, d4: Any=d4, d5: Any=d5, d6: Any=d6) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_G]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            match_value_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d4.Decode(helpers, value_1)
            match_value_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d5.Decode(helpers, value_1)
            match_value_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d6.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    copy_of_struct_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_3
                                    match copy_of_struct_3.tag:
                                        case 1:
                                            return Error(copy_of_struct_3.fields[0])

                                        case _:
                                            copy_of_struct_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_4
                                            match copy_of_struct_4.tag:
                                                case 1:
                                                    return Error(copy_of_struct_4.fields[0])

                                                case _:
                                                    copy_of_struct_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_5
                                                    match copy_of_struct_5.tag:
                                                        case 1:
                                                            return Error(copy_of_struct_5.fields[0])

                                                        case _:
                                                            return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0], copy_of_struct_3.fields[0], copy_of_struct_4.fields[0], copy_of_struct_5.fields[0]))







    return ObjectExpr386()


def map7[A, B, C, D, E, F, G, OUTPUT](ctor: Callable[[A, B, C, D, E, F, G], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F], d7: Decoder_1[G]) -> Decoder_1[OUTPUT]:
    class ObjectExpr387(Decoder_1[Any]):
        def Decode[_H](self, helpers: IDecoderHelpers_1[_H], value_1: _H, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3, d4: Any=d4, d5: Any=d5, d6: Any=d6, d7: Any=d7) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_H]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            match_value_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d4.Decode(helpers, value_1)
            match_value_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d5.Decode(helpers, value_1)
            match_value_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d6.Decode(helpers, value_1)
            match_value_6: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d7.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    copy_of_struct_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_3
                                    match copy_of_struct_3.tag:
                                        case 1:
                                            return Error(copy_of_struct_3.fields[0])

                                        case _:
                                            copy_of_struct_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_4
                                            match copy_of_struct_4.tag:
                                                case 1:
                                                    return Error(copy_of_struct_4.fields[0])

                                                case _:
                                                    copy_of_struct_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_5
                                                    match copy_of_struct_5.tag:
                                                        case 1:
                                                            return Error(copy_of_struct_5.fields[0])

                                                        case _:
                                                            copy_of_struct_6: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_6
                                                            match copy_of_struct_6.tag:
                                                                case 1:
                                                                    return Error(copy_of_struct_6.fields[0])

                                                                case _:
                                                                    return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0], copy_of_struct_3.fields[0], copy_of_struct_4.fields[0], copy_of_struct_5.fields[0], copy_of_struct_6.fields[0]))








    return ObjectExpr387()


def map8[A, B, C, D, E, F, G, H, OUTPUT](ctor: Callable[[A, B, C, D, E, F, G, H], OUTPUT], d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F], d7: Decoder_1[G], d8: Decoder_1[H]) -> Decoder_1[OUTPUT]:
    class ObjectExpr388(Decoder_1[Any]):
        def Decode[_I](self, helpers: IDecoderHelpers_1[_I], value_1: _I, ctor: Any=ctor, d1: Any=d1, d2: Any=d2, d3: Any=d3, d4: Any=d4, d5: Any=d5, d6: Any=d6, d7: Any=d7, d8: Any=d8) -> FSharpResult_2[OUTPUT, tuple[str, ErrorReason_1[_I]]]:
            match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d1.Decode(helpers, value_1)
            match_value_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d2.Decode(helpers, value_1)
            match_value_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d3.Decode(helpers, value_1)
            match_value_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d4.Decode(helpers, value_1)
            match_value_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d5.Decode(helpers, value_1)
            match_value_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d6.Decode(helpers, value_1)
            match_value_6: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d7.Decode(helpers, value_1)
            match_value_7: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = d8.Decode(helpers, value_1)
            copy_of_struct: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value
            match copy_of_struct.tag:
                case 1:
                    return Error(copy_of_struct.fields[0])

                case _:
                    copy_of_struct_1: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_1
                    match copy_of_struct_1.tag:
                        case 1:
                            return Error(copy_of_struct_1.fields[0])

                        case _:
                            copy_of_struct_2: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_2
                            match copy_of_struct_2.tag:
                                case 1:
                                    return Error(copy_of_struct_2.fields[0])

                                case _:
                                    copy_of_struct_3: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_3
                                    match copy_of_struct_3.tag:
                                        case 1:
                                            return Error(copy_of_struct_3.fields[0])

                                        case _:
                                            copy_of_struct_4: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_4
                                            match copy_of_struct_4.tag:
                                                case 1:
                                                    return Error(copy_of_struct_4.fields[0])

                                                case _:
                                                    copy_of_struct_5: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_5
                                                    match copy_of_struct_5.tag:
                                                        case 1:
                                                            return Error(copy_of_struct_5.fields[0])

                                                        case _:
                                                            copy_of_struct_6: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_6
                                                            match copy_of_struct_6.tag:
                                                                case 1:
                                                                    return Error(copy_of_struct_6.fields[0])

                                                                case _:
                                                                    copy_of_struct_7: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = match_value_7
                                                                    match copy_of_struct_7.tag:
                                                                        case 1:
                                                                            return Error(copy_of_struct_7.fields[0])

                                                                        case _:
                                                                            return Ok(ctor(copy_of_struct.fields[0], copy_of_struct_1.fields[0], copy_of_struct_2.fields[0], copy_of_struct_3.fields[0], copy_of_struct_4.fields[0], copy_of_struct_5.fields[0], copy_of_struct_6.fields[0], copy_of_struct_7.fields[0]))









    return ObjectExpr388()


def lossy_option[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[Option[VALUE]]:
    """Decode a JSON null value into an F# option.

    Attention, this decoder is lossy, it will not be able to distinguish between `'T option` and `'T option option`.

    If you need to distinguish between `'T option` and `'T option option`, use `losslessOption`.
    """
    class ObjectExpr389(Decoder_1[Option[Any]]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, decoder: Any=decoder) -> FSharpResult_2[Option[VALUE], tuple[str, ErrorReason_1[_A]]]:
            def mapping(Value: VALUE=UNIT) -> Option[VALUE]:
                return some(Value)

            return Ok(None) if helpers.is_null_value(value_1) else Result_Map(mapping, decoder.Decode(helpers, value_1))

    return ObjectExpr389()


def lossless_option[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[Option[VALUE]]:
    """Decode a JSON null value into an F# option.

    This decoder is lossless, it will be able to distinguish between `'T option` and `'T option option`.

    If you don't need to distinguish between `'T option` and `'T option option`, you can use `lossyOption` which is more efficient.
    """
    def cb_1(type_name: str, decoder: Any=decoder) -> Decoder_1[Option[VALUE]]:
        if type_name == "option":
            def cb(state: str) -> Decoder_1[Option[VALUE]]:
                match state:
                    case "none":
                        return succeed(None)

                    case "some":
                        def ctor(Value: VALUE=UNIT) -> Option[VALUE]:
                            return some(Value)

                        return map(ctor, field("$value", decoder))

                    case _:
                        return fail("Expecting a state field with value \'none\' or \'some\' but got " + state)


            return and_then(cb, field("$case", string))

        else:
            return fail("Expecting an Option type but got " + type_name)


    return and_then(cb_1, field("$type", string))


def and_map[A, B](__unit: Unit=UNIT) -> Callable[..., Callable[..., Decoder_1[B]]]:
    """Allow to incrementally apply a decoder, for building large objects.
    """
    def _arrow391(d: Decoder_1[A]) -> Callable[[Decoder_1[Callable[[A], B]]], Decoder_1[B]]:
        def _arrow390(d_1: Decoder_1[Callable[[A], B]]) -> Decoder_1[B]:
            def ctor(arg: A, func: Callable[[A], B]) -> B:
                return func(arg)

            return map2(ctor, d, d_1)

        return _arrow390

    return _arrow391


class IRequiredGetter(Protocol):
    @abstractmethod
    def At[A](self, __arg0: FSharpList[str], __arg1: Decoder_1[Any], /) -> Any:
        ...

    @abstractmethod
    def Field[A](self, __arg0: str, __arg1: Decoder_1[Any], /) -> Any:
        ...

    @abstractmethod
    def Raw[A](self, __arg0: Decoder_1[Any], /) -> Any:
        ...


class IOptionalGetter(Protocol):
    @abstractmethod
    def At[A](self, __arg0: FSharpList[str], __arg1: Decoder_1[Any], /) -> Option[Any]:
        ...

    @abstractmethod
    def Field[A](self, __arg0: str, __arg1: Decoder_1[Any], /) -> Option[Any]:
        ...

    @abstractmethod
    def Raw[A](self, __arg0: Decoder_1[Any], /) -> Option[Any]:
        ...


class IGetters(Protocol):
    @property
    @abstractmethod
    def Optional(self, /) -> IOptionalGetter:
        ...

    @property
    @abstractmethod
    def Required(self, /) -> IRequiredGetter:
        ...


def unwrap_with[JSONVALUE, T](errors: list[tuple[str, ErrorReason_1[JSONVALUE]]], helpers: IDecoderHelpers_1[JSONVALUE], decoder: Decoder_1[T], value_1: JSONVALUE) -> T:
    match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(helpers, value_1)
    match match_value.tag:
        case 1:
            (errors.append(match_value.fields[0]))
            return cast(Any, None)

        case _:
            return match_value.fields[0]



def _expr396(gen0: TypeInfo, gen1: TypeInfo) -> TypeInfo:
    return class_type("Thoth.Json.Core.Decode.Getters`2", Array([gen0, gen1]), Getters_2)


class Getters_2[JSONVALUE, T]:
    def __init__(self, helpers: IDecoderHelpers_1[JSONVALUE], value_1: JSONVALUE) -> None:
        self.errors: list[tuple[str, ErrorReason_1[Any]]] = []
        def _arrow393(__unit: Unit=UNIT) -> IRequiredGetter:
            _this: Any = self
            class ObjectExpr392(IRequiredGetter):
                def Field[_A](self, field_name: str, decoder: Decoder_1[_A]) -> _A:
                    return unwrap_with(_this.errors, helpers, field(field_name, decoder), value_1)

                def At[_A](self, field_names: FSharpList[str], decoder_1: Decoder_1[_A]) -> _A:
                    return unwrap_with(_this.errors, helpers, at(field_names, decoder_1), value_1)

                def Raw[_A](self, decoder_2: Decoder_1[_A]) -> _A:
                    return unwrap_with(_this.errors, helpers, decoder_2, value_1)

            return ObjectExpr392()

        self.required: IRequiredGetter = _arrow393()
        def _arrow395(__unit: Unit=UNIT) -> IOptionalGetter:
            _this_1: Any = self
            class ObjectExpr394(IOptionalGetter):
                def Field[_A](self, field_name_1: str, decoder_3: Decoder_1[_A]) -> Option[_A]:
                    return unwrap_with(_this_1.errors, helpers, optional(field_name_1, decoder_3), value_1)

                def At[_A](self, field_names_1: FSharpList[str], decoder_4: Decoder_1[_A]) -> Option[_A]:
                    return unwrap_with(_this_1.errors, helpers, optional_at(field_names_1, decoder_4), value_1)

                def Raw[_A](self, decoder_5: Decoder_1[_A]) -> Option[_A]:
                    match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder_5.Decode(helpers, value_1)
                    match match_value.tag:
                        case 1:
                            reason: ErrorReason_1[Any] = match_value.fields[0][1]
                            error: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                            (pattern_matching_result, v_1) = nullable[int32, Any]()
                            if reason.tag == int32.ONE:
                                pattern_matching_result = int32(0)
                                v_1 = reason.fields[1]

                            elif reason.tag == int32.TWO:
                                pattern_matching_result = int32(0)
                                v_1 = reason.fields[1]

                            elif (reason.tag == int32.THREE) or (reason.tag == int32.FOUR):
                                pattern_matching_result = int32(1)

                            elif ((reason.tag == int32.FIVE) or (reason.tag == int32.SIX)) or (reason.tag == int32.SEVEN):
                                pattern_matching_result = int32(2)

                            else:
                                pattern_matching_result = int32(0)
                                v_1 = reason.fields[1]

                            if pattern_matching_result == int32.ZERO:
                                if helpers.is_null_value(v_1):
                                    return None

                                else:
                                    (_this_1.errors.append(error))
                                    return cast(Option[Any], None)


                            elif pattern_matching_result == int32.ONE:
                                return None

                            else:
                                (_this_1.errors.append(error))
                                return cast(Option[Any], None)


                        case _:
                            return some(match_value.fields[0])


            return ObjectExpr394()

        self.optional: IOptionalGetter = _arrow395()

    @property
    def Required(self, __unit: Unit=UNIT) -> IRequiredGetter:
        __: Getters_2[Any, Any] = self
        return __.required

    @property
    def Optional(self, __unit: Unit=UNIT) -> IOptionalGetter:
        __: Getters_2[Any, Any] = self
        return __.optional


Getters_2_reflection = _expr396

def Getters_2__ctor_Z4BE6C149[JSONVALUE, T](helpers: IDecoderHelpers_1[JSONVALUE], value_1: JSONVALUE) -> Getters_2[JSONVALUE, T]:
    return Getters_2(helpers, value_1)


def Getters_2__get_Errors[JSONVALUE, T](__: Getters_2[JSONVALUE, T]) -> FSharpList[tuple[str, ErrorReason_1[JSONVALUE]]]:
    return to_list(to_enumerable(__.errors))


def object[VALUE](builder: Callable[[IGetters], VALUE]) -> Decoder_1[VALUE]:
    class ObjectExpr397(Decoder_1[Any]):
        def Decode[_A](self, helpers: IDecoderHelpers_1[_A], value_1: _A, builder: Any=builder) -> FSharpResult_2[VALUE, tuple[str, ErrorReason_1[_A]]]:
            getters: Getters_2[Any, Any] = Getters_2__ctor_Z4BE6C149(helpers, value_1)
            result: Any = builder(getters)
            match_value: FSharpList[tuple[str, ErrorReason_1[Any]]] = Getters_2__get_Errors(getters)
            if not is_empty(match_value):
                errors: FSharpList[tuple[str, ErrorReason_1[Any]]] = match_value
                return Error(("", ErrorReason_1_BadOneOf(errors))) if (length(errors) > int32.ONE) else Error(head_1(match_value))

            else:
                return Ok(result)


    return ObjectExpr397()


def tuple2[T1, T2](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2]) -> Decoder_1[tuple[T1, T2]]:
    def cb_1(v1: T1=UNIT, decoder2: Any=decoder2) -> Decoder_1[tuple[T1, T2]]:
        def cb(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2]]:
            return succeed((v1, v2))

        return and_then(cb, index(int32.ONE, decoder2))

    return and_then(cb_1, index(int32.ZERO, decoder1))


def tuple3[T1, T2, T3](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3]) -> Decoder_1[tuple[T1, T2, T3]]:
    def cb_2(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3) -> Decoder_1[tuple[T1, T2, T3]]:
        def cb_1(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3]]:
            def cb(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3]]:
                return succeed((v1, v2, v3))

            return and_then(cb, index(int32.TWO, decoder3))

        return and_then(cb_1, index(int32.ONE, decoder2))

    return and_then(cb_2, index(int32.ZERO, decoder1))


def tuple4[T1, T2, T3, T4](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3], decoder4: Decoder_1[T4]) -> Decoder_1[tuple[T1, T2, T3, T4]]:
    def cb_3(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3, decoder4: Any=decoder4) -> Decoder_1[tuple[T1, T2, T3, T4]]:
        def cb_2(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3, T4]]:
            def cb_1(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3, T4]]:
                def cb(v4: T4=UNIT, v3: Any=v3) -> Decoder_1[tuple[T1, T2, T3, T4]]:
                    return succeed((v1, v2, v3, v4))

                return and_then(cb, index(int32.THREE, decoder4))

            return and_then(cb_1, index(int32.TWO, decoder3))

        return and_then(cb_2, index(int32.ONE, decoder2))

    return and_then(cb_3, index(int32.ZERO, decoder1))


def tuple5[T1, T2, T3, T4, T5](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3], decoder4: Decoder_1[T4], decoder5: Decoder_1[T5]) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
    def cb_4(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3, decoder4: Any=decoder4, decoder5: Any=decoder5) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
        def cb_3(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
            def cb_2(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
                def cb_1(v4: T4=UNIT, v3: Any=v3) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
                    def cb(v5: T5=UNIT, v4: Any=v4) -> Decoder_1[tuple[T1, T2, T3, T4, T5]]:
                        return succeed((v1, v2, v3, v4, v5))

                    return and_then(cb, index(int32.FOUR, decoder5))

                return and_then(cb_1, index(int32.THREE, decoder4))

            return and_then(cb_2, index(int32.TWO, decoder3))

        return and_then(cb_3, index(int32.ONE, decoder2))

    return and_then(cb_4, index(int32.ZERO, decoder1))


def tuple6[T1, T2, T3, T4, T5, T6](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3], decoder4: Decoder_1[T4], decoder5: Decoder_1[T5], decoder6: Decoder_1[T6]) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
    def cb_5(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3, decoder4: Any=decoder4, decoder5: Any=decoder5, decoder6: Any=decoder6) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
        def cb_4(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
            def cb_3(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
                def cb_2(v4: T4=UNIT, v3: Any=v3) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
                    def cb_1(v5: T5=UNIT, v4: Any=v4) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
                        def cb(v6: T6=UNIT, v5: Any=v5) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6]]:
                            return succeed((v1, v2, v3, v4, v5, v6))

                        return and_then(cb, index(int32.FIVE, decoder6))

                    return and_then(cb_1, index(int32.FOUR, decoder5))

                return and_then(cb_2, index(int32.THREE, decoder4))

            return and_then(cb_3, index(int32.TWO, decoder3))

        return and_then(cb_4, index(int32.ONE, decoder2))

    return and_then(cb_5, index(int32.ZERO, decoder1))


def tuple7[T1, T2, T3, T4, T5, T6, T7](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3], decoder4: Decoder_1[T4], decoder5: Decoder_1[T5], decoder6: Decoder_1[T6], decoder7: Decoder_1[T7]) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
    def cb_6(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3, decoder4: Any=decoder4, decoder5: Any=decoder5, decoder6: Any=decoder6, decoder7: Any=decoder7) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
        def cb_5(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
            def cb_4(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
                def cb_3(v4: T4=UNIT, v3: Any=v3) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
                    def cb_2(v5: T5=UNIT, v4: Any=v4) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
                        def cb_1(v6: T6=UNIT, v5: Any=v5) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
                            def cb(v7: T7=UNIT, v6: Any=v6) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7]]:
                                return succeed((v1, v2, v3, v4, v5, v6, v7))

                            return and_then(cb, index(int32.SIX, decoder7))

                        return and_then(cb_1, index(int32.FIVE, decoder6))

                    return and_then(cb_2, index(int32.FOUR, decoder5))

                return and_then(cb_3, index(int32.THREE, decoder4))

            return and_then(cb_4, index(int32.TWO, decoder3))

        return and_then(cb_5, index(int32.ONE, decoder2))

    return and_then(cb_6, index(int32.ZERO, decoder1))


def tuple8[T1, T2, T3, T4, T5, T6, T7, T8](decoder1: Decoder_1[T1], decoder2: Decoder_1[T2], decoder3: Decoder_1[T3], decoder4: Decoder_1[T4], decoder5: Decoder_1[T5], decoder6: Decoder_1[T6], decoder7: Decoder_1[T7], decoder8: Decoder_1[T8]) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
    def cb_7(v1: T1=UNIT, decoder2: Any=decoder2, decoder3: Any=decoder3, decoder4: Any=decoder4, decoder5: Any=decoder5, decoder6: Any=decoder6, decoder7: Any=decoder7, decoder8: Any=decoder8) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
        def cb_6(v2: T2=UNIT, v1: Any=v1) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
            def cb_5(v3: T3=UNIT, v2: Any=v2) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                def cb_4(v4: T4=UNIT, v3: Any=v3) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                    def cb_3(v5: T5=UNIT, v4: Any=v4) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                        def cb_2(v6: T6=UNIT, v5: Any=v5) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                            def cb_1(v7: T7=UNIT, v6: Any=v6) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                                def cb(v8: T8=UNIT, v7: Any=v7) -> Decoder_1[tuple[T1, T2, T3, T4, T5, T6, T7, T8]]:
                                    return succeed((v1, v2, v3, v4, v5, v6, v7, v8))

                                return and_then(cb, index(int32.SEVEN, decoder8))

                            return and_then(cb_1, index(int32.SIX, decoder7))

                        return and_then(cb_2, index(int32.FIVE, decoder6))

                    return and_then(cb_3, index(int32.FOUR, decoder5))

                return and_then(cb_4, index(int32.THREE, decoder4))

            return and_then(cb_5, index(int32.TWO, decoder3))

        return and_then(cb_6, index(int32.ONE, decoder2))

    return and_then(cb_7, index(int32.ZERO, decoder1))


def dict_1[VALUE](decoder: Decoder_1[VALUE]) -> Decoder_1[Any]:
    def _arrow399(elements: FSharpList[tuple[str, VALUE]]) -> Any:
        class ObjectExpr398:
            def Compare(self, x: str, y: str) -> int32:
                return compare_primitives(x, y)

        return of_list(elements, ObjectExpr398())

    return map(_arrow399, key_value_pairs(decoder))


def map_0027[KEY, VALUE](key_decoder: Decoder_1[KEY], value_decoder: Decoder_1[VALUE]) -> Decoder_1[Any]:
    def _arrow401(elements: Array[tuple[KEY, VALUE]]) -> Any:
        class ObjectExpr400:
            def Compare(self, x: KEY, y: KEY) -> int32:
                return compare(x, y)

        return of_seq_1(elements, ObjectExpr400())

    return map(_arrow401, array(tuple2(key_decoder, value_decoder)))


def _expr402(gen0: TypeInfo) -> TypeInfo:
    return class_type("Thoth.Json.Core.Decode.FixDecoder`1", Array([gen0]), FixDecoder_1)


class FixDecoder_1[A]:
    def __init__(self, make: Callable[[Decoder_1[A]], Decoder_1[A]]) -> None:
        this: FSharpRef[FixDecoder_1[Any]] = FSharpRef_1(cast(FixDecoder_1[Any], None))
        this.contents = self
        self.self: Decoder_1[Any] = make(this.contents)
        self.init_00401517: int32 = int32.ONE

    def Decode[JSONVALUE, _JSONVALUE](self, helpers: IDecoderHelpers_1[_JSONVALUE], value_1: _JSONVALUE) -> FSharpResult_2[A, tuple[str, ErrorReason_1[_JSONVALUE]]]:
        this: FixDecoder_1[Any] = self
        return this.self.Decode(helpers, value_1)


FixDecoder_1_reflection = _expr402

def FixDecoder_1__ctor_Z2A44CE2A[A](make: Callable[[Decoder_1[A]], Decoder_1[A]]) -> FixDecoder_1[A]:
    return FixDecoder_1(make)


def fix[A](make: Callable[[Decoder_1[A]], Decoder_1[A]]) -> Decoder_1[A]:
    """Allow to build a decoder that can call itself
    """
    return FixDecoder_1__ctor_Z2A44CE2A(make)


__all__ = ["Advanced_fromValue", "FixDecoder_1_reflection", "Getters_2__get_Errors", "Getters_2_reflection", "Helpers_prependPath", "LazyDecoder_1_reflection", "ValueDecoder_reflection", "all", "and_map", "and_then", "array", "at", "bad_path_error", "bigint", "bool_1", "byte", "char", "datetime_local", "decimal", "decode_maybe_null", "dict_1", "error_to_string", "fail", "field", "fix", "float32", "float_1", "generic_msg", "guid", "index", "int16", "int64", "int_1", "key_value_pairs", "keys", "lazily", "list_1", "lossless_option", "lossy_option", "map", "map2", "map3", "map4", "map5", "map6", "map7", "map8", "map_0027", "nil", "object", "one_of", "optional", "optional_at", "resize_array", "sbyte", "seq", "string", "succeed", "timespan", "tuple2", "tuple3", "tuple4", "tuple5", "tuple6", "tuple7", "tuple8", "uint16", "uint32", "uint64", "unit", "unwrap_with", "value"]

