from __future__ import annotations
from collections.abc import Callable
from typing import Any
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .decode import (map, map2, map3, map4, map5, map6, map7, map8, succeed)
from .types import Decoder_1

def _expr8() -> TypeInfo:
    return class_type("Thoth.Json.Core.DecoderCE.DecoderBuilder", None, DecoderBuilder)


class DecoderBuilder:
    def __init__(self, __unit: Unit=UNIT) -> None:
        pass


DecoderBuilder_reflection = _expr8

def DecoderBuilder__ctor(__unit: Unit=UNIT) -> DecoderBuilder:
    return DecoderBuilder(__unit)


def DecoderBuilder__BindReturn_6BCFE77E[_D, _E](_: DecoderBuilder, m: Decoder_1[_D], f: Callable[[_D], _E]) -> Decoder_1[_E]:
    return map(f, m)


def DecoderBuilder__Bind2Return_Z12312F75[A, B, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], ctor: Callable[[tuple[A, B]], T]) -> Decoder_1[T]:
    def _arrow9(a: A, b: B, ctor: Any=ctor) -> T:
        return ctor((a, b))

    return map2(_arrow9, d1, d2)


def DecoderBuilder__Bind3Return_B877D49[A, B, C, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], ctor: Callable[[tuple[A, B, C]], T]) -> Decoder_1[T]:
    def _arrow10(a: A, b: B, c: C, ctor: Any=ctor) -> T:
        return ctor((a, b, c))

    return map3(_arrow10, d1, d2, d3)


def DecoderBuilder__Bind4Return_Z70E81EB5[A, B, C, D, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], ctor: Callable[[tuple[A, B, C, D]], T]) -> Decoder_1[T]:
    def _arrow11(a: A, b: B, c: C, d: D, ctor: Any=ctor) -> T:
        return ctor((a, b, c, d))

    return map4(_arrow11, d1, d2, d3, d4)


def DecoderBuilder__Bind5Return_1A977209[A, B, C, D, E, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], ctor: Callable[[tuple[A, B, C, D, E]], T]) -> Decoder_1[T]:
    def _arrow12(a: A, b: B, c: C, d: D, e: E, ctor: Any=ctor) -> T:
        return ctor((a, b, c, d, e))

    return map5(_arrow12, d1, d2, d3, d4, d5)


def DecoderBuilder__Bind6Return_Z1E2849F5[A, B, C, D, E, F, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F], ctor: Callable[[tuple[A, B, C, D, E, F]], T]) -> Decoder_1[T]:
    def _arrow13(a: A, b: B, c: C, d: D, e: E, f: F, ctor: Any=ctor) -> T:
        return ctor((a, b, c, d, e, f))

    return map6(_arrow13, d1, d2, d3, d4, d5, d6)


def DecoderBuilder__Bind7Return_Z16900C37[A, B, C, D, E, F, G, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F], d7: Decoder_1[G], ctor: Callable[[tuple[A, B, C, D, E, F, G]], T]) -> Decoder_1[T]:
    def _arrow14(a: A, b: B, c: C, d: D, e: E, f: F, g: G, ctor: Any=ctor) -> T:
        return ctor((a, b, c, d, e, f, g))

    return map7(_arrow14, d1, d2, d3, d4, d5, d6, d7)


def DecoderBuilder__Bind8Return_512F4ECB[A, B, C, D, E, F, G, H, T](_: DecoderBuilder, d1: Decoder_1[A], d2: Decoder_1[B], d3: Decoder_1[C], d4: Decoder_1[D], d5: Decoder_1[E], d6: Decoder_1[F], d7: Decoder_1[G], d8: Decoder_1[H], ctor: Callable[[tuple[A, B, C, D, E, F, G, H]], T]) -> Decoder_1[T]:
    def _arrow15(a: A, b: B, c: C, d: D, e: E, f: F, g: G, h: H, ctor: Any=ctor) -> T:
        return ctor((a, b, c, d, e, f, g, h))

    return map8(_arrow15, d1, d2, d3, d4, d5, d6, d7, d8)


def DecoderBuilder__MergeSources_83ADF00[_B, _C](_: DecoderBuilder, d1: Decoder_1[_B], d2: Decoder_1[_C]) -> Decoder_1[tuple[_B, _C]]:
    def _arrow16(a: _B, b: _C) -> tuple[_B, _C]:
        return (a, b)

    return map2(_arrow16, d1, d2)


def DecoderBuilder__Return_1505[_A](_: DecoderBuilder, x: _A) -> Decoder_1[_A]:
    return succeed(x)


def DecoderBuilder__ReturnFrom_1FBE35A8[A](_: DecoderBuilder, x: Decoder_1[A]) -> Decoder_1[A]:
    return x


decoder: DecoderBuilder = DecoderBuilder__ctor()

__all__ = ["DecoderBuilder__Bind2Return_Z12312F75", "DecoderBuilder__Bind3Return_B877D49", "DecoderBuilder__Bind4Return_Z70E81EB5", "DecoderBuilder__Bind5Return_1A977209", "DecoderBuilder__Bind6Return_Z1E2849F5", "DecoderBuilder__Bind7Return_Z16900C37", "DecoderBuilder__Bind8Return_512F4ECB", "DecoderBuilder__BindReturn_6BCFE77E", "DecoderBuilder__MergeSources_83ADF00", "DecoderBuilder__ReturnFrom_1FBE35A8", "DecoderBuilder__Return_1505", "DecoderBuilder_reflection", "decoder"]

