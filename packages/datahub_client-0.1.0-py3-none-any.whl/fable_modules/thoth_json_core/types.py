from __future__ import annotations
from abc import abstractmethod
from typing import (Any, Protocol)
from fable_library.array_ import Array
from fable_library.core import (float64, float32, int32, uint32)
from fable_library.list import FSharpList
from fable_library.protocols import IEnumerable_1
from fable_library.reflection import (TypeInfo, string_type, tuple_type, list_type, union_type, float64_type, bool_type)
from fable_library.result import FSharpResult_2
from fable_library.union import (Union, tagged_union)

class IDecoderHelpers_1[JSONVALUE](Protocol):
    @abstractmethod
    def any_to_string(self, __arg0: Any, /) -> str:
        ...

    @abstractmethod
    def as_array(self, __arg0: Any, /) -> Array[Any]:
        ...

    @abstractmethod
    def as_boolean(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def as_float(self, __arg0: Any, /) -> float64:
        ...

    @abstractmethod
    def as_float32(self, __arg0: Any, /) -> float32:
        ...

    @abstractmethod
    def as_int(self, __arg0: Any, /) -> int32:
        ...

    @abstractmethod
    def as_string(self, __arg0: Any, /) -> str:
        ...

    @abstractmethod
    def get_properties(self, __arg0: Any, /) -> IEnumerable_1[str]:
        ...

    @abstractmethod
    def get_property(self, __arg0: str, __arg1: Any, /) -> Any:
        ...

    @abstractmethod
    def has_property(self, __arg0: str, __arg1: Any, /) -> bool:
        ...

    @abstractmethod
    def is_array(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_boolean(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_integral_value(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_null_value(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_number(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_object(self, __arg0: Any, /) -> bool:
        ...

    @abstractmethod
    def is_string(self, __arg0: Any, /) -> bool:
        ...


class IEncoderHelpers_1[JSONVALUE](Protocol):
    @abstractmethod
    def encode_array(self, __arg0: Array[Any], /) -> Any:
        ...

    @abstractmethod
    def encode_bool(self, __arg0: bool, /) -> Any:
        ...

    @abstractmethod
    def encode_char(self, __arg0: str, /) -> Any:
        ...

    @abstractmethod
    def encode_decimal_number(self, __arg0: float64, /) -> Any:
        ...

    @abstractmethod
    def encode_list(self, __arg0: FSharpList[Any], /) -> Any:
        ...

    @abstractmethod
    def encode_null(self, /) -> Any:
        ...

    @abstractmethod
    def encode_object(self, __arg0: IEnumerable_1[tuple[str, Any]], /) -> Any:
        ...

    @abstractmethod
    def encode_resize_array(self, __arg0: list[Any], /) -> Any:
        ...

    @abstractmethod
    def encode_seq(self, __arg0: IEnumerable_1[Any], /) -> Any:
        ...

    @abstractmethod
    def encode_signed_integral_number(self, __arg0: int32, /) -> Any:
        ...

    @abstractmethod
    def encode_string(self, __arg0: str, /) -> Any:
        ...

    @abstractmethod
    def encode_unsigned_integral_number(self, __arg0: uint32, /) -> Any:
        ...


def _expr6(gen0: TypeInfo) -> TypeInfo:
    return union_type("Thoth.Json.Core.ErrorReason`1", Array([gen0]), _ErrorReason_1, lambda: [[("Item1", string_type), ("Item2", gen0)], [("Item1", string_type), ("Item2", gen0), ("Item3", string_type)], [("Item1", string_type), ("Item2", gen0)], [("Item1", string_type), ("Item2", gen0)], [("Item1", string_type), ("Item2", gen0), ("Item3", string_type)], [("Item1", string_type), ("Item2", gen0)], [("Item", string_type)], [("Item", list_type(tuple_type(string_type, ErrorReason_1_reflection(gen0))))]], [ErrorReason_1_BadPrimitive, ErrorReason_1_BadPrimitiveExtra, ErrorReason_1_BadType, ErrorReason_1_BadField, ErrorReason_1_BadPath, ErrorReason_1_TooSmallArray, ErrorReason_1_FailMessage, ErrorReason_1_BadOneOf])


class _ErrorReason_1[JSONVALUE](Union):
    @staticmethod
    def cases() -> list[str]:
        return ["BadPrimitive", "BadPrimitiveExtra", "BadType", "BadField", "BadPath", "TooSmallArray", "FailMessage", "BadOneOf"]


@tagged_union(0)
class ErrorReason_1_BadPrimitive[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any

@tagged_union(1)
class ErrorReason_1_BadPrimitiveExtra[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any
    item3: str

@tagged_union(2)
class ErrorReason_1_BadType[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any

@tagged_union(3)
class ErrorReason_1_BadField[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any

@tagged_union(4)
class ErrorReason_1_BadPath[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any
    item3: str

@tagged_union(5)
class ErrorReason_1_TooSmallArray[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item1: str
    item2: Any

@tagged_union(6)
class ErrorReason_1_FailMessage[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item: str

@tagged_union(7)
class ErrorReason_1_BadOneOf[JSONVALUE](_ErrorReason_1[JSONVALUE]):
    item: FSharpList[tuple[str, ErrorReason_1[Any]]]

type ErrorReason_1[JSONVALUE] = ((((((ErrorReason_1_BadPrimitive[JSONVALUE] | ErrorReason_1_BadPrimitiveExtra[JSONVALUE]) | ErrorReason_1_BadType[JSONVALUE]) | ErrorReason_1_BadField[JSONVALUE]) | ErrorReason_1_BadPath[JSONVALUE]) | ErrorReason_1_TooSmallArray[JSONVALUE]) | ErrorReason_1_FailMessage[JSONVALUE]) | ErrorReason_1_BadOneOf[JSONVALUE]

ErrorReason_1_reflection = _expr6

class Decoder_1[T](Protocol):
    @abstractmethod
    def Decode[JSONVALUE](self, helpers: IDecoderHelpers_1[Any], value: Any, /) -> FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]]:
        ...


def _expr7() -> TypeInfo:
    return union_type("Thoth.Json.Core.Json", Array([]), _Json, lambda: [[("Item", string_type)], [("Item", float64_type)], [], [("Item", bool_type)], [("Item", list_type(tuple_type(string_type, Json_reflection())))], [("Item", list_type(Json_reflection()))]], [Json_String, Json_Number, Json_Null, Json_Boolean, Json_Object, Json_Array])


class _Json(Union):
    @staticmethod
    def cases() -> list[str]:
        return ["String", "Number", "Null", "Boolean", "Object", "Array"]


@tagged_union(0)
class Json_String(_Json):
    item: str

@tagged_union(1)
class Json_Number(_Json):
    item: float64

@tagged_union(2)
class Json_Null(_Json):
    ...

@tagged_union(3)
class Json_Boolean(_Json):
    item: bool

@tagged_union(4)
class Json_Object(_Json):
    item: FSharpList[tuple[str, Json]]

@tagged_union(5)
class Json_Array(_Json):
    item: FSharpList[Json]

type Json = ((((Json_String | Json_Number) | Json_Null) | Json_Boolean) | Json_Object) | Json_Array

Json_reflection = _expr7

class IEncodable(Protocol):
    @abstractmethod
    def Encode[JSONVALUE](self, helpers: IEncoderHelpers_1[Any], /) -> Any:
        ...


__all__ = ["ErrorReason_1_BadField", "ErrorReason_1_BadOneOf", "ErrorReason_1_BadPath", "ErrorReason_1_BadPrimitive", "ErrorReason_1_BadPrimitiveExtra", "ErrorReason_1_BadType", "ErrorReason_1_FailMessage", "ErrorReason_1_TooSmallArray", "ErrorReason_1_reflection", "Json_Array", "Json_Boolean", "Json_Null", "Json_Number", "Json_Object", "Json_String", "Json_reflection"]

