"""FastAPI bindings for F# to Python web framework

FastAPI is a modern, fast web framework for building APIs with Python.
These bindings support the class-based approach using method decorators.

Usage: Create API endpoints using classes with decorated methods:

```fsharp
open Fable.Python.FastAPI

let app = FastAPI()

[<APIClass>]
type API() =
[<Get("/")>]
static member root() =
{| message = "Hello World" |}

[<Get("/items/{item_id}")>]
static member get_item(item_id: int) =
{| item_id = item_id |}

[<Post("/items")>]
static member create_item(item: Item) =
{| status = "created"; item = item |}
```

For routers, use the RouterGet, RouterPost, etc. attributes:

```fsharp
let router = APIRouter(prefix = "/users")

[<APIClass>]
type UsersAPI() =
[<RouterGet("/")>]
static member list_users() = {| users = [] |}
```
"""
from abc import (ABC, abstractmethod)
from typing import (Any, Protocol)
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)

status_http_200_ok: int32 = int32(200)

status_http_201_created: int32 = int32(201)

status_http_204_no_content: int32 = int32(204)

status_http_301_moved_permanently: int32 = int32(301)

status_http_302_found: int32 = int32(302)

status_http_304_not_modified: int32 = int32(304)

status_http_307_temporary_redirect: int32 = int32(307)

status_http_308_permanent_redirect: int32 = int32(308)

status_http_400_bad_request: int32 = int32(400)

status_http_401_unauthorized: int32 = int32(401)

status_http_403_forbidden: int32 = int32(403)

status_http_404_not_found: int32 = int32(404)

status_http_405_method_not_allowed: int32 = int32(405)

status_http_409_conflict: int32 = int32(409)

status_http_422_unprocessable_entity: int32 = int32(422)

status_http_429_too_many_requests: int32 = int32(429)

status_http_500_internal_server_error: int32 = int32(500)

status_http_502_bad_gateway: int32 = int32(502)

status_http_503_service_unavailable: int32 = int32(503)

status_http_504_gateway_timeout: int32 = int32(504)

def _expr4() -> TypeInfo:
    return class_type("Fable.Python.FastAPI.OAuth2PasswordBearer", None, OAuth2PasswordBearer)


class OAuth2PasswordBearer(ABC):
    ...

OAuth2PasswordBearer_reflection = _expr4

class TestResponse(Protocol):
    @property
    @abstractmethod
    def headers(self, /) -> Any:
        ...

    @property
    @abstractmethod
    def status_code(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def text(self, /) -> str:
        ...

    @abstractmethod
    def json(self, /) -> Any:
        ...


__all__ = ["OAuth2PasswordBearer_reflection", "status_http_200_ok", "status_http_201_created", "status_http_204_no_content", "status_http_301_moved_permanently", "status_http_302_found", "status_http_304_not_modified", "status_http_307_temporary_redirect", "status_http_308_permanent_redirect", "status_http_400_bad_request", "status_http_401_unauthorized", "status_http_403_forbidden", "status_http_404_not_found", "status_http_405_method_not_allowed", "status_http_409_conflict", "status_http_422_unprocessable_entity", "status_http_429_too_many_requests", "status_http_500_internal_server_error", "status_http_502_bad_gateway", "status_http_503_service_unavailable", "status_http_504_gateway_timeout"]

