"""Utilities for detecting and working with Fable types at runtime in Python.
These helpers are useful when you need to distinguish between native Python types
and Fable-compiled F# types (e.g., Int32, Float64, FSharpArray).
"""
from typing import Any
from fable_library.util import UNIT

def is_integral_type(o: Any=None) -> bool:
    """Check if an object is a Fable integral type (Int8, Int16, Int32, Int64, UInt8, UInt16, UInt32, UInt64)
    """
    match_value: str = type(o).__name__
    match match_value:
        case "Int8" | "Int16" | "Int32" | "Int64" | "UInt8" | "UInt16" | "UInt32" | "UInt64":
            return True

        case _:
            return False



def is_numeric_type(o: Any=None) -> bool:
    """Check if an object is a Fable numeric type (integral types + Float32, Float64)
    """
    match_value: str = type(o).__name__
    match match_value:
        case "Int8" | "Int16" | "Int32" | "Int64" | "UInt8" | "UInt16" | "UInt32" | "UInt64" | "Float32" | "Float64":
            return True

        case _:
            return False



def is_array_type(o: Any=None) -> bool:
    """Check if an object is a Fable array type (FSharpArray, GenericArray, or typed arrays)
    """
    match_value: str = type(o).__name__
    match match_value:
        case "FSharpArray" | "GenericArray" | "Int8Array" | "Int16Array" | "Int32Array" | "Int64Array" | "UInt8Array" | "UInt16Array" | "UInt32Array" | "UInt64Array" | "Float32Array" | "Float64Array":
            return True

        case _:
            return False



__all__ = ["is_array_type", "is_integral_type", "is_numeric_type"]

