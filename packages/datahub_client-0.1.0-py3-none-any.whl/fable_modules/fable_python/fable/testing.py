"""Test utilities for Fable Python projects using pytest.

Example usage:
```fsharp
open Fable.Python.Testing

[<Fact>]
let ``test addition works`` () =
let result = 2 + 2
result |> equal 4

[<Fact>]
let ``test throws on invalid input`` () =
throwsAnyError (fun () -> failwith "boom")
```
"""
from __future__ import annotations
from collections.abc import Callable
from typing import Any
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.result import (Error, Ok, FSharpResult_2)
from fable_library.string_ import (to_text, printf, is_null_or_empty)
from fable_library.types import Attribute
from fable_library.util import (assert_equal, UNIT, assert_not_equal, Unit)

def equal[_A](expected: _A, actual: _A) -> None:
    """Assert equality (expected first, then actual - F# style)
    """
    assert_equal(actual, expected)


def not_equal[_A](expected: _A, actual: _A) -> None:
    """Assert inequality
    """
    assert_not_equal(actual, expected)


def _expr5() -> TypeInfo:
    return class_type("Fable.Python.Testing.FactAttribute", None, FactAttribute, class_type("System.Attribute"))


class FactAttribute(Attribute):
    def __init__(self, __unit: Unit=UNIT) -> None:
        super().__init__()
        pass


FactAttribute_reflection = _expr5

def FactAttribute__ctor(__unit: Unit=UNIT) -> FactAttribute:
    return FactAttribute(__unit)


def run[A](f: Callable[[], A]) -> FSharpResult_2[A, str]:
    try:
        return Ok(f())

    except Exception as e:
        e_: Exception = e
        return Error(str(e_))



def throws_error[A](expected: str, f: Callable[[], A]) -> None:
    """Assert that a function throws an error with the exact message
    """
    match_value: FSharpResult_2[Any, str] = run(f)
    match match_value.tag:
        case 0:
            equal(expected, "No error was thrown")

        case _:
            if match_value.fields[0] == expected:
                pass

            else:
                equal(expected, match_value.fields[0])




def throws_error_containing[A](expected: str, f: Callable[[], A]) -> None:
    """Assert that a function throws an error containing the expected substring
    """
    match_value: FSharpResult_2[Any, str] = run(f)
    match match_value.tag:
        case 0:
            equal(to_text(printf("Error containing \'%s\'"))(expected), "No error was thrown")

        case _:
            if is_null_or_empty(expected):
                pass

            elif match_value.fields[0].find(expected) >= int32.ZERO:
                pass

            else:
                equal(to_text(printf("Error containing \'%s\'"))(expected), match_value.fields[0])




def throws_any_error[A](f: Callable[[], A]) -> None:
    """Assert that a function throws any error
    """
    match_value: FSharpResult_2[Any, str] = run(f)
    match match_value.tag:
        case 0:
            equal("An error", "No error was thrown")

        case _:
            pass



def doesnt_throw[A](f: Callable[[], A]) -> None:
    """Assert that a function does not throw
    """
    match_value: FSharpResult_2[Any, str] = run(f)
    match match_value.tag:
        case 1:
            equal("No error", to_text(printf("Error: %s"))(match_value.fields[0]))

        case _:
            pass



__all__ = ["FactAttribute_reflection", "doesnt_throw", "equal", "not_equal", "run", "throws_any_error", "throws_error", "throws_error_containing"]

