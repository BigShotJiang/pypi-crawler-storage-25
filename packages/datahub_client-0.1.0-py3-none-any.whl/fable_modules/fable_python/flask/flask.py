"""Flask bindings for F# to Python web framework

Flask is a lightweight WSGI web application framework for Python.
These bindings support the class-based approach using method decorators.

Usage: Create routes using classes with decorated methods:

```fsharp
open Fable.Python.Flask

let app = Flask.Create(__name__)

[<APIClass>]
type Routes() =
[<Route("/")>]
static member index() =
"Hello World!"

[<Route("/users/<int:user_id>")>]
static member get_user(user_id: int) =
{| user_id = user_id |}

[<Route("/users", methods = [| "POST" |])>]
static member create_user() =
{| status = "created" |}
```
"""

