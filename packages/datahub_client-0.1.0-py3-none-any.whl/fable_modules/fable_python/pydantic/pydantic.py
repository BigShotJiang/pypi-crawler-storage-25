"""Pydantic bindings for F# to Python data validation and serialization

Usage: Create Pydantic models by inheriting from BaseModel and using
the ClassAttributes attribute:

```fsharp
[<Py.ClassAttributes(style=Py.ClassAttributeStyle.Attributes, init=false)>]
type User(name: string, age: int, email: string option) =
inherit BaseModel()
member val Name: string = name with get, set
member val Age: int = age with get, set
member val Email: string option = email with get, set
```
"""
from abc import abstractmethod
from typing import (Any, Protocol)
from fable_library.array_ import Array
from fable_library.option import Option
from fable_library.reflection import (TypeInfo, union_type, class_type)
from fable_library.union import (Union, tagged_union)

def _expr2() -> TypeInfo:
    return union_type("Fable.Python.Pydantic.ExtraFieldsMode", Array([]), _ExtraFieldsMode, lambda: [[], [], []], [ExtraFieldsMode_forbid, ExtraFieldsMode_allow, ExtraFieldsMode_ignore])


class _ExtraFieldsMode(Union):
    @staticmethod
    def cases() -> list[str]:
        return ["forbid", "allow", "ignore"]


@tagged_union(0)
class ExtraFieldsMode_forbid(_ExtraFieldsMode):
    ...

@tagged_union(1)
class ExtraFieldsMode_allow(_ExtraFieldsMode):
    ...

@tagged_union(2)
class ExtraFieldsMode_ignore(_ExtraFieldsMode):
    ...

type ExtraFieldsMode = (ExtraFieldsMode_forbid | ExtraFieldsMode_allow) | ExtraFieldsMode_ignore

ExtraFieldsMode_reflection = _expr2

def _expr3() -> TypeInfo:
    return class_type("Fable.Python.Pydantic.ConfigDictBuilder", None, ConfigDictBuilder)


class ConfigDictBuilder:
    ...

ConfigDictBuilder_reflection = _expr3

class FieldInfo(Protocol):
    @property
    @abstractmethod
    def annotation(self, /) -> Any:
        ...

    @property
    @abstractmethod
    def default(self, /) -> Option[Any]:
        ...

    @abstractmethod
    def is_required(self, /) -> bool:
        ...


__all__ = ["ConfigDictBuilder_reflection", "ExtraFieldsMode_allow", "ExtraFieldsMode_forbid", "ExtraFieldsMode_ignore", "ExtraFieldsMode_reflection"]

