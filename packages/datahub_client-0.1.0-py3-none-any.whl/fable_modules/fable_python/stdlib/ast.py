"""Type bindings for Python ast module: https://docs.python.org/3/library/ast.html
"""
from fable_library.array_ import Array
from fable_library.reflection import (TypeInfo, union_type)
from fable_library.union import (Union, tagged_union)

def _expr0() -> TypeInfo:
    return union_type("Fable.Python.Ast.Mode", Array([]), _Mode, lambda: [[], []], [Mode_Exec, Mode_func_mode])


class _Mode(Union):
    @staticmethod
    def cases() -> list[str]:
        return ["Exec", "func_mode"]


@tagged_union(0)
class Mode_Exec(_Mode):
    ...

@tagged_union(1)
class Mode_func_mode(_Mode):
    ...

type Mode = Mode_Exec | Mode_func_mode

Mode_reflection = _expr0

__all__ = ["Mode_Exec", "Mode_func_mode", "Mode_reflection"]

