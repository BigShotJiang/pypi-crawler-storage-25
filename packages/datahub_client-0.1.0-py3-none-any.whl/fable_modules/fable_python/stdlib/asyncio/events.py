from __future__ import annotations
from abc import abstractmethod
from typing import (Any, Protocol)
from .futures import Future_1

class AbstractEventLoop(Protocol):
    @abstractmethod
    def create_future[T](self, /) -> Future_1[Any]:
        ...

    @abstractmethod
    def run_forever(self, /) -> None:
        ...


