from __future__ import annotations
from abc import abstractmethod
from typing import (Protocol, Any)
from .futures import (Future_1, Awaitable_1)

class Task_1[T](Future_1, Awaitable_1, Protocol):
    pass

class Task(Future_1, Awaitable_1, Protocol):
    pass

class Coroutine_1[T](Awaitable_1, Protocol):
    @abstractmethod
    def close(self, /) -> None:
        ...

    @abstractmethod
    def send(self, __arg0: Any, /) -> None:
        ...

    @abstractmethod
    def throw(self, __arg0: Exception, /) -> None:
        ...


class IExports(Protocol):
    pass

