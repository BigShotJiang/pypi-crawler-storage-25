from __future__ import annotations
from abc import abstractmethod
from collections.abc import Callable
from typing import (Protocol, Any)

class Awaitable_1[T](Protocol):
    pass

class Future_1[T](Awaitable_1, Protocol):
    @abstractmethod
    def add_done_callback(self, callback: Callable[[], None], /) -> None:
        ...

    @abstractmethod
    def cancel(self, /) -> None:
        ...

    @abstractmethod
    def cancelled(self, /) -> bool:
        ...

    @abstractmethod
    def done(self, /) -> bool:
        ...

    @abstractmethod
    def exception(self, /) -> Exception:
        ...

    @abstractmethod
    def get_name(self, /) -> str:
        ...

    @abstractmethod
    def result(self, /) -> Any:
        ...

    @abstractmethod
    def set_name(self, __arg0: str, /) -> None:
        ...


