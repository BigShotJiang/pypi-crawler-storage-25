"""Type bindings for Python threading module: https://docs.python.org/3/library/threading.html
"""

