"""Type bindings for Python string module: https://docs.python.org/3/library/string.html
"""

