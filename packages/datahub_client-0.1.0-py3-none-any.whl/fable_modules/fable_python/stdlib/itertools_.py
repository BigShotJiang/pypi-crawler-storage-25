"""Type bindings for Python itertools module: https://docs.python.org/3/library/itertools.html
"""

