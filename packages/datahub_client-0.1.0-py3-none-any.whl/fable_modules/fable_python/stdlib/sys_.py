"""Type bindings for Python sys module: https://docs.python.org/3/library/sys.html
"""
from abc import abstractmethod
from typing import Protocol
from fable_library.array_ import Array
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, union_type)
from fable_library.union import (Union, tagged_union)

def _expr1() -> TypeInfo:
    return union_type("Fable.Python.Sys.ByteOrder", Array([]), _ByteOrder, lambda: [[], []], [ByteOrder_Little, ByteOrder_Big])


class _ByteOrder(Union):
    @staticmethod
    def cases() -> list[str]:
        return ["Little", "Big"]


@tagged_union(0)
class ByteOrder_Little(_ByteOrder):
    ...

@tagged_union(1)
class ByteOrder_Big(_ByteOrder):
    ...

type ByteOrder = ByteOrder_Little | ByteOrder_Big

ByteOrder_reflection = _expr1

class VersionInfo(Protocol):
    @property
    @abstractmethod
    def major(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def micro(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def minor(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def releaselevel(self, /) -> str:
        ...

    @property
    @abstractmethod
    def serial(self, /) -> int32:
        ...


__all__ = ["ByteOrder_Big", "ByteOrder_Little", "ByteOrder_reflection"]

