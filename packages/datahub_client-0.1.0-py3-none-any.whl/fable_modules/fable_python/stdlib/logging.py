"""Type bindings for Python logging module: https://docs.python.org/3/library/logging.html
"""

