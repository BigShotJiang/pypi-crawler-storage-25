"""Type bindings for Python traceback module: https://docs.python.org/3/library/traceback.html
"""

