"""Type bindings for Python base64 module: https://docs.python.org/3/library/base64.html
"""

