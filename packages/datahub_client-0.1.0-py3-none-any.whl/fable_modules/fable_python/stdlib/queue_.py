"""Type bindings for Python queue module: https://docs.python.org/3/library/queue.html
"""

