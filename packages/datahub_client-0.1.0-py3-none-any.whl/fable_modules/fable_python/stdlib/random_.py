"""Type bindings for Python random module: https://docs.python.org/3/library/random.html
"""

