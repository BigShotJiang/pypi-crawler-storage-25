"""Type bindings for Python html module: https://docs.python.org/3/library/html.html
"""

