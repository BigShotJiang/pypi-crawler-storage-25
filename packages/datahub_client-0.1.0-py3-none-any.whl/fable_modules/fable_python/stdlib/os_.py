"""Type bindings for Python os module: https://docs.python.org/3/library/os.html
"""

