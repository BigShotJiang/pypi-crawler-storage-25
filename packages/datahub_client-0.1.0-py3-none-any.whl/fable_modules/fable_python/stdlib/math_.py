"""Type bindings for Python math module: https://docs.python.org/3/library/math.html
"""

