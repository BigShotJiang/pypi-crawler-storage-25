"""Type bindings for Python tkinter GUI toolkit: https://docs.python.org/3/library/tkinter.html
"""

