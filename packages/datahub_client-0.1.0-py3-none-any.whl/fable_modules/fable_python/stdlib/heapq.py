"""Type bindings for Python heapq module: https://docs.python.org/3/library/heapq.html
"""

