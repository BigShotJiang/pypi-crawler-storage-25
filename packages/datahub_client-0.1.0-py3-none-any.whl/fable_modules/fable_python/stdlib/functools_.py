"""Type bindings for Python functools module: https://docs.python.org/3/library/functools.html
"""

