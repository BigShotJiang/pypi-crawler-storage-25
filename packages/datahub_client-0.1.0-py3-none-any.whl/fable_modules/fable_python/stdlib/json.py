"""Type bindings for Python json module: https://docs.python.org/3/library/json.html
"""
from typing import Any
from fable_library.array_ import Array
from fable_library.core import int32
from fable_library.util import UNIT

def fable_default(o: Any=None) -> Any:
    """Default function for JSON serialization of Fable types.
    Handles Int8, Int16, Int32, Int64, UInt8, UInt16, UInt32, UInt64 → int
    Handles Float32, Float64 → float
    Handles typed arrays (Int32Array, Int64Array, Float64Array, etc.) → list
    Handles Union types (tag, fields, cases) → [caseName, ...fields] or just caseName
    Handles Record types (__slots__) → dict of slot names to values
    """
    name: str = type(o).__name__
    match name:
        case "Int8" | "Int16" | "Int32" | "Int64" | "UInt8" | "UInt16" | "UInt32" | "UInt64":
            return int(o)

        case "Float32" | "Float64":
            return float(o)

        case "FSharpArray" | "GenericArray" | "Int8Array" | "Int16Array" | "Int32Array" | "Int64Array" | "UInt8Array" | "UInt16Array" | "UInt32Array" | "UInt64Array" | "Float32Array" | "Float64Array":
            return list(o)

        case _:
            if (hasattr(o, "fields")) if (hasattr(o, "tag")) else False:
                cases: Array[str] = getattr(type(o), 'cases', lambda: [])()
                tag: int32 = getattr(o, "tag")
                case_name: str = cases[tag] if (tag < int32(len(cases))) else ("Case" + int32(tag).to_string())
                return [case_name] + list(o.fields) if o.fields else case_name

            elif hasattr(o, "__slots__"):
                return {slot: getattr(o, slot) for slot in o.__slots__}

            else:
                return (_ for _ in ()).throw(TypeError(f'Object of type {type(o).__name__} is not JSON serializable'))




__all__ = ["fable_default"]

