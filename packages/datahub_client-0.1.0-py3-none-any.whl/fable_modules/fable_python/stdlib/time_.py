"""Type bindings for Python time module: https://docs.python.org/3/library/time.html
"""

