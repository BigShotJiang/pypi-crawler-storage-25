"""Type bindings for Python datetime module: https://docs.python.org/3/library/datetime.html

Note: this module exposes a `time` class binding for Python's `datetime.time`. If you also
open `Fable.Python.Time` (the `time` module), the `time` identifier will collide — qualify
one of them, e.g. `Fable.Python.Time.time.time()` vs. `Fable.Python.Datetime.time(...)`.
"""

