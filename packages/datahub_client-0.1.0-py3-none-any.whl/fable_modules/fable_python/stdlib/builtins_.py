"""Type bindings for Python builtins: https://docs.python.org/3/library/functions.html#built-in-funcs
"""
from __future__ import annotations
from abc import abstractmethod
import builtins
from typing import Protocol
from fable_library.core import int32
from fable_library.list import FSharpList
from fable_library.protocols import (IEnumerable_1, IDisposable)
from fable_library.util import UNIT

class TextIOBase(Protocol):
    @abstractmethod
    def readline(self, __size: int32, /) -> str:
        ...

    @abstractmethod
    def readlines(self, __hint: int32, /) -> FSharpList[str]:
        ...

    @abstractmethod
    def tell(self, /) -> int32:
        ...

    @abstractmethod
    def write(self, __s: str, /) -> int32:
        ...

    @abstractmethod
    def writelines(self, __lines: IEnumerable_1[str], /) -> None:
        ...


class TextIOWrapper(TextIOBase, IDisposable, Protocol):
    pass

def print[_A](obj: _A=UNIT) -> None:
    """Python print function. Takes a single argument, so can be used with e.g string interpolation.
    """
    builtins.print(obj)


def getattr_1[_A, _B](obj: _A, name: str, default_value: _B) -> _B:
    """Return the value of the named attribute of object with a default.
    """
    return builtins.getattr(obj, name, default_value)


def setattr[_A, _B](obj: _A, name: str, value: _B) -> None:
    """Sets the named attribute on the given object to the specified value.
    """
    builtins.setattr(obj, name, value)


def hasattr_1[_A](obj: _A, name: str) -> bool:
    """Return True if the string is the name of one of the object's attributes.
    """
    return builtins.hasattr(obj, name)


__all__ = ["getattr_1", "hasattr_1", "print", "setattr"]

