from __future__ import annotations
from abc import abstractmethod
from typing import Protocol
from fable_library.core import (int32, float64)

class IWidget(Protocol):
    @abstractmethod
    def close(self, /) -> None:
        ...


class IIntSlider(IWidget, Protocol):
    @property
    @abstractmethod
    def max(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def min(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def value(self, /) -> int32:
        ...


class IFloatSlider(IWidget, Protocol):
    @property
    @abstractmethod
    def max(self, /) -> float64:
        ...

    @property
    @abstractmethod
    def min(self, /) -> float64:
        ...

    @property
    @abstractmethod
    def value(self, /) -> float64:
        ...


class IExports(Protocol):
    pass

