from __future__ import annotations
from collections.abc import Callable
from json import JSONDecodeError
import numbers
import json as json_1
from typing import Any
from fable_library.array_ import Array
from fable_library.core import (float64, float32, int32)
from fable_library.fsharp_core import Operators_IsNull
from fable_library.protocols import IEnumerable_1
from fable_library.result import (FSharpResult_2, Error, Ok)
from fable_library.util import UNIT
from ..fable_python.fable.types import (is_numeric_type, is_integral_type)
from ..fable_python.stdlib.json import fable_default
from ..thoth_json_core.decode import (Advanced_fromValue, Helpers_prependPath, error_to_string)
from ..thoth_json_core.types import (IDecoderHelpers_1, Decoder_1, ErrorReason_1)

class ObjectExpr48(IDecoderHelpers_1[Any]):
    def is_string(self, json_value: Any=None) -> bool:
        return str(type(json_value)) == "<class \'str\'>"

    def is_number(self, json_value_1: Any=None) -> bool:
        return True if ((not (isinstance(json_value_1, (bool)))) if (isinstance(json_value_1, numbers.Number)) else False) else is_numeric_type(json_value_1)

    def is_boolean(self, json_value_2: Any=None) -> bool:
        return str(type(json_value_2)) == "<class \'bool\'>"

    def is_null_value(self, json_value_3: Any=None) -> bool:
        return Operators_IsNull(json_value_3)

    def is_array(self, json_value_4: Any=None) -> bool:
        return isinstance(json_value_4, (list))

    def is_object(self, json_value_5: Any=None) -> bool:
        return isinstance(json_value_5, (dict))

    def has_property(self, field_name: str, json_value_6: Any=None) -> bool:
        return field_name in json_value_6

    def is_integral_value(self, json_value_7: Any=None) -> bool:
        return True if (isinstance(json_value_7, (int))) else is_integral_type(json_value_7)

    def as_string(self, json_value_8: Any=None) -> str:
        return json_value_8

    def as_boolean(self, json_value_9: Any=None) -> bool:
        return json_value_9

    def as_array(self, json_value_10: Any=None) -> Array[Any]:
        return json_value_10

    def as_float(self, json_value_11: Any=None) -> float64:
        return float64(json_value_11)

    def as_float32(self, json_value_12: Any=None) -> float32:
        return float32(json_value_12)

    def as_int(self, json_value_13: Any=None) -> int32:
        return int32(json_value_13)

    def get_properties(self, json_value_14: Any=None) -> IEnumerable_1[str]:
        return json_value_14.keys()

    def get_property(self, field_name_1: str, json_value_15: Any=None) -> Any:
        return json_value_15[field_name_1]

    def any_to_string(self, json_value_16: Any=None) -> str:
        return json_1.dumps(json_value_16, indent = int32.FOUR, default = fable_default)


Decode_helpers: IDecoderHelpers_1[Any] = ObjectExpr48()

def Decode_fromValue[T](decoder: Decoder_1[T]) -> Callable[[Any], FSharpResult_2[T, str]]:
    def _arrow49(value: Any=None, decoder: Any=decoder) -> FSharpResult_2[T, str]:
        return Advanced_fromValue(Decode_helpers, decoder, value)

    return _arrow49


def Decode_fromString[T](decoder: Decoder_1[T], value: str) -> FSharpResult_2[T, str]:
    try:
        json: Any = json_1.loads(value)
        match_value: FSharpResult_2[Any, tuple[str, ErrorReason_1[Any]]] = decoder.Decode(Decode_helpers, json)
        match match_value.tag:
            case 1:
                final_error: tuple[str, ErrorReason_1[Any]]
                tupled_arg: tuple[str, ErrorReason_1[Any]] = match_value.fields[0]
                final_error = Helpers_prependPath("$", tupled_arg[0], tupled_arg[1])
                return Error(error_to_string(Decode_helpers, final_error[0], final_error[1]))

            case _:
                return Ok(match_value.fields[0])


    except JSONDecodeError as match_value_1:
        match_value_1_: JSONDecodeError = match_value_1
        ex: JSONDecodeError = match_value_1_
        return Error("Given an invalid JSON: " + str(ex))



def Decode_unsafeFromString[T](decoder: Decoder_1[T], value: str) -> T:
    match_value: FSharpResult_2[Any, str] = Decode_fromString(decoder, value)
    match match_value.tag:
        case 1:
            raise Exception(match_value.fields[0])

        case _:
            return match_value.fields[0]



__all__ = ["Decode_fromString", "Decode_fromValue", "Decode_helpers", "Decode_unsafeFromString"]

