from __future__ import annotations
import json as json_2
from typing import (Any, cast)
from fable_library.array_ import Array
from fable_library.core import (float64, int32, uint32)
from fable_library.list import (to_array, FSharpList)
from fable_library.protocols import IEnumerable_1
from fable_library.util import (UNIT, Unit, get_enumerator, Disposable)
from ..fable_python.stdlib.json import fable_default
from ..thoth_json_core.types import (IEncoderHelpers_1, IEncodable)

class ObjectExpr50(IEncoderHelpers_1[Any]):
    def encode_string(self, value: str) -> Any:
        return value

    def encode_char(self, value_1: str) -> Any:
        return value_1

    def encode_decimal_number(self, value_2: float64) -> Any:
        return value_2

    def encode_bool(self, value_3: bool) -> Any:
        return value_3

    def encode_null(self, __unit: Unit=UNIT) -> Any:
        return cast(Any, None)

    def encode_object(self, values: IEnumerable_1[tuple[str, Any]]) -> Any:
        o: Any = {}
        with Disposable(get_enumerator(values)) as enumerator:
            while enumerator.System_Collections_IEnumerator_MoveNext():
                for_loop_var: tuple[str, Any] = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
                o[for_loop_var[0]] = for_loop_var[1]
        return o

    def encode_array(self, values_1: Array[Any]) -> Any:
        return values_1

    def encode_list(self, values_2: FSharpList[Any]) -> Any:
        this: IEncoderHelpers_1[Any] = self
        arg: Array[Any] = to_array(values_2)
        return this.encode_array(arg)

    def encode_seq(self, values_3: IEnumerable_1[Any]) -> Any:
        this_1: IEncoderHelpers_1[Any] = self
        arg_1: Array[Any] = Array[Any](values_3)
        return this_1.encode_array(arg_1)

    def encode_resize_array(self, values_4: list[Any]) -> Any:
        this_2: IEncoderHelpers_1[Any] = self
        arg_2: Array[Any] = Array[Any](values_4)
        return this_2.encode_array(arg_2)

    def encode_signed_integral_number(self, value_5: int32) -> Any:
        return value_5

    def encode_unsigned_integral_number(self, value_6: uint32) -> Any:
        return value_6


helpers: IEncoderHelpers_1[Any] = ObjectExpr50()

def to_string(space: int32, value: IEncodable) -> str:
    json_1: Any = value.Encode(helpers)
    if space == int32.ZERO:
        separators: Array[str] = Array[Any]([",", ":"])
        return json_2.dumps(json_1, separators = separators, ensure_ascii = False, default = fable_default)

    else:
        separators_1: Array[str] = Array[Any]([",", ": "])
        return json_2.dumps(json_1, indent = space, separators = separators_1, ensure_ascii = False, default = fable_default)



__all__ = ["helpers", "to_string"]

