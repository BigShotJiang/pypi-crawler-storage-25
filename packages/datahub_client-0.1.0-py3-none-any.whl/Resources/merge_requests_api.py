from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.exceptions import to_string
from fable_library.list import (singleton as singleton_1, empty, of_array, FSharpList, append)
from fable_library.option import map
from fable_library.protocols import IEnumerable_1
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.seq import map as map_1
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.types import (IEncodable, IEncoderHelpers_1)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.merge_request import decoder
from ..Json.note import decoder as decoder_1
from ..Json.thoth_extensions import object_skip_null
from ..Models.merge_request import MergeRequest
from ..Models.note import Note
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decodeArray, ResourceHelpers_decode, ResourceHelpers_jsonRequest)

def _expr502() -> TypeInfo:
    return class_type("DataHubClient.MergeRequestsApi", None, MergeRequestsApi)


class MergeRequestsApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def List(self, project_id: int32, state: str | None=None) -> Async[Array[MergeRequest]]:
        _: MergeRequestsApi = self
        def _arrow473(__unit: Unit=UNIT) -> Async[Array[MergeRequest]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.merge_request_segments(project_id), singleton_1(("state", state)))
            def _arrow472(_arg: HttpResponse) -> Async[Array[MergeRequest]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow472)

        return singleton.Delay(_arrow473)

    def Get(self, project_id: int32, iid: int32) -> Async[MergeRequest]:
        _: MergeRequestsApi = self
        def _arrow476(__unit: Unit=UNIT) -> Async[MergeRequest]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.merge_request_segments_with_iid(project_id, iid), empty())
            def _arrow475(_arg: HttpResponse) -> Async[MergeRequest]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow475)

        return singleton.Delay(_arrow476)

    def Create(self, project_id: int32, source_branch: str, target_branch: str, title: str, description: str | None=None) -> Async[MergeRequest]:
        _: MergeRequestsApi = self
        def _arrow484(__unit: Unit=UNIT) -> Async[MergeRequest]:
            class ObjectExpr478(IEncodable):
                def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                    return helpers.encode_string(source_branch)

            class ObjectExpr479(IEncodable):
                def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                    return helpers_1.encode_string(target_branch)

            class ObjectExpr480(IEncodable):
                def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                    return helpers_2.encode_string(title)

            def _arrow482(value_3: str) -> IEncodable:
                class ObjectExpr481(IEncodable):
                    def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_3.encode_string(value_3)

                return ObjectExpr481()

            body: IEncodable = object_skip_null(of_array(Array[Any]([("source_branch", ObjectExpr478()), ("target_branch", ObjectExpr479()), ("title", ObjectExpr480()), ("description", map(_arrow482, description))])))
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "POST", _.merge_request_segments(project_id), empty(), body)
            def _arrow483(_arg: HttpResponse) -> Async[MergeRequest]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow483)

        return singleton.Delay(_arrow484)

    def Update(self, project_id: int32, iid: int32, title: str | None=None, description: str | None=None, state_event: str | None=None) -> Async[MergeRequest]:
        _: MergeRequestsApi = self
        def _arrow494(__unit: Unit=UNIT) -> Async[MergeRequest]:
            def _arrow488(value: str) -> IEncodable:
                class ObjectExpr487(IEncodable):
                    def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                        return helpers.encode_string(value)

                return ObjectExpr487()

            def _arrow490(value_2: str) -> IEncodable:
                class ObjectExpr489(IEncodable):
                    def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_1.encode_string(value_2)

                return ObjectExpr489()

            def _arrow492(value_4: str) -> IEncodable:
                class ObjectExpr491(IEncodable):
                    def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_2.encode_string(value_4)

                return ObjectExpr491()

            body: IEncodable = object_skip_null(of_array(Array[Any]([("title", map(_arrow488, title)), ("description", map(_arrow490, description)), ("state_event", map(_arrow492, state_event))])))
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "PUT", _.merge_request_segments_with_iid(project_id, iid), empty(), body)
            def _arrow493(_arg: HttpResponse) -> Async[MergeRequest]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow493)

        return singleton.Delay(_arrow494)

    def Close(self, project_id: int32, iid: int32) -> Async[MergeRequest]:
        this: MergeRequestsApi = self
        return this.Update(project_id, iid, None, None, "close")

    def Notes(self, project_id: int32, iid: int32) -> Async[Array[Note]]:
        _: MergeRequestsApi = self
        def _arrow496(__unit: Unit=UNIT) -> Async[Array[Note]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.note_segments(project_id, iid), empty())
            def _arrow495(_arg: HttpResponse) -> Async[Array[Note]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow495)

        return singleton.Delay(_arrow496)

    def CreateNote(self, project_id: int32, iid: int32, body: str) -> Async[Note]:
        _: MergeRequestsApi = self
        def _arrow501(__unit: Unit=UNIT) -> Async[Note]:
            def _arrow499(__unit: Unit=UNIT) -> IEncodable:
                class ObjectExpr497(IEncodable):
                    def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                        return helpers.encode_string(body)

                values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("body", ObjectExpr497())])
                class ObjectExpr498(IEncodable):
                    def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                        def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                            return (tupled_arg[0], tupled_arg[1].Encode(helpers_1))

                        arg: IEnumerable_1[tuple[str, Any]] = map_1(mapping, values)
                        return helpers_1.encode_object(arg)

                return ObjectExpr498()

            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "POST", _.note_segments(project_id, iid), empty(), _arrow499())
            def _arrow500(_arg: HttpResponse) -> Async[Note]:
                return singleton.Return(ResourceHelpers_decode(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow500)

        return singleton.Delay(_arrow501)

    def merge_request_segments[_A](self, project_id: Any=UNIT) -> FSharpList[str]:
        return of_array(Array[Any](["projects", to_string(project_id), "merge_requests"]))

    def merge_request_segments_with_iid[_A, _B](self, project_id: Any, iid: Any) -> FSharpList[str]:
        this: MergeRequestsApi = self
        return append(this.merge_request_segments(project_id), singleton_1(to_string(iid)))

    def note_segments[_A, _B](self, project_id: Any, iid: Any) -> FSharpList[str]:
        this: MergeRequestsApi = self
        return append(this.merge_request_segments_with_iid(project_id, iid), singleton_1("notes"))


MergeRequestsApi_reflection = _expr502

def MergeRequestsApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> MergeRequestsApi:
    return MergeRequestsApi(base_url, auth, http)


__all__ = ["MergeRequestsApi_reflection"]

