from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.exceptions import to_string
from fable_library.list import (singleton as singleton_1, of_array, empty)
from fable_library.option import map
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.project import decoder
from ..Models.project import Project
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decodeArray, ResourceHelpers_decode)

def _expr408() -> TypeInfo:
    return class_type("DataHubClient.ProjectsApi", None, ProjectsApi)


class ProjectsApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def List(self, search: str | None=None, simple: bool | None=None) -> Async[Array[Project]]:
        _: ProjectsApi = self
        def _arrow405(__unit: Unit=UNIT) -> Async[Array[Project]]:
            def mapping(v: bool) -> str:
                return to_string(v).lower()

            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", singleton_1("projects"), of_array(Array[Any]([("search", search), ("simple", map(mapping, simple))])))
            def _arrow404(_arg: HttpResponse) -> Async[Array[Project]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow404)

        return singleton.Delay(_arrow405)

    def Get(self, project_id: int32) -> Async[Project]:
        _: ProjectsApi = self
        def _arrow407(__unit: Unit=UNIT) -> Async[Project]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", of_array(Array[Any](["projects", int32(project_id).to_string()])), empty())
            def _arrow406(_arg: HttpResponse) -> Async[Project]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow406)

        return singleton.Delay(_arrow407)

    def Search(self, search: str) -> Async[Array[Project]]:
        this: ProjectsApi = self
        return this.List(search)


ProjectsApi_reflection = _expr408

def ProjectsApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> ProjectsApi:
    return ProjectsApi(base_url, auth, http)


__all__ = ["ProjectsApi_reflection"]

