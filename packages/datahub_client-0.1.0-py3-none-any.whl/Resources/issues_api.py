from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.exceptions import to_string
from fable_library.list import (singleton as singleton_1, empty, of_array, FSharpList, append)
from fable_library.option import map
from fable_library.protocols import IEnumerable_1
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.seq import map as map_1
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.types import (IEncodable, IEncoderHelpers_1)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.issue import decoder
from ..Json.note import decoder as decoder_1
from ..Json.thoth_extensions import object_skip_null
from ..Models.issue import Issue
from ..Models.note import Note
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decodeArray, ResourceHelpers_decode, ResourceHelpers_jsonRequest)

def _expr463() -> TypeInfo:
    return class_type("DataHubClient.IssuesApi", None, IssuesApi)


class IssuesApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def List(self, project_id: int32, state: str | None=None) -> Async[Array[Issue]]:
        _: IssuesApi = self
        def _arrow437(__unit: Unit=UNIT) -> Async[Array[Issue]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.issue_segments(project_id), singleton_1(("state", state)))
            def _arrow436(_arg: HttpResponse) -> Async[Array[Issue]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow436)

        return singleton.Delay(_arrow437)

    def Get(self, project_id: int32, iid: int32) -> Async[Issue]:
        _: IssuesApi = self
        def _arrow439(__unit: Unit=UNIT) -> Async[Issue]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.issue_segments_with_iid(project_id, iid), empty())
            def _arrow438(_arg: HttpResponse) -> Async[Issue]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow438)

        return singleton.Delay(_arrow439)

    def Create(self, project_id: int32, title: str, description: str | None=None) -> Async[Issue]:
        _: IssuesApi = self
        def _arrow445(__unit: Unit=UNIT) -> Async[Issue]:
            class ObjectExpr441(IEncodable):
                def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                    return helpers.encode_string(title)

            def _arrow443(value_1: str) -> IEncodable:
                class ObjectExpr442(IEncodable):
                    def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_1.encode_string(value_1)

                return ObjectExpr442()

            body: IEncodable = object_skip_null(of_array(Array[Any]([("title", ObjectExpr441()), ("description", map(_arrow443, description))])))
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "POST", _.issue_segments(project_id), empty(), body)
            def _arrow444(_arg: HttpResponse) -> Async[Issue]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow444)

        return singleton.Delay(_arrow445)

    def Update(self, project_id: int32, iid: int32, title: str | None=None, description: str | None=None, state_event: str | None=None) -> Async[Issue]:
        _: IssuesApi = self
        def _arrow455(__unit: Unit=UNIT) -> Async[Issue]:
            def _arrow449(value: str) -> IEncodable:
                class ObjectExpr448(IEncodable):
                    def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                        return helpers.encode_string(value)

                return ObjectExpr448()

            def _arrow451(value_2: str) -> IEncodable:
                class ObjectExpr450(IEncodable):
                    def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_1.encode_string(value_2)

                return ObjectExpr450()

            def _arrow453(value_4: str) -> IEncodable:
                class ObjectExpr452(IEncodable):
                    def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                        return helpers_2.encode_string(value_4)

                return ObjectExpr452()

            body: IEncodable = object_skip_null(of_array(Array[Any]([("title", map(_arrow449, title)), ("description", map(_arrow451, description)), ("state_event", map(_arrow453, state_event))])))
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "PUT", _.issue_segments_with_iid(project_id, iid), empty(), body)
            def _arrow454(_arg: HttpResponse) -> Async[Issue]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow454)

        return singleton.Delay(_arrow455)

    def Close(self, project_id: int32, iid: int32) -> Async[Issue]:
        this: IssuesApi = self
        return this.Update(project_id, iid, None, None, "close")

    def Notes(self, project_id: int32, iid: int32) -> Async[Array[Note]]:
        _: IssuesApi = self
        def _arrow457(__unit: Unit=UNIT) -> Async[Array[Note]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.note_segments(project_id, iid), empty())
            def _arrow456(_arg: HttpResponse) -> Async[Array[Note]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow456)

        return singleton.Delay(_arrow457)

    def CreateNote(self, project_id: int32, iid: int32, body: str) -> Async[Note]:
        _: IssuesApi = self
        def _arrow462(__unit: Unit=UNIT) -> Async[Note]:
            def _arrow460(__unit: Unit=UNIT) -> IEncodable:
                class ObjectExpr458(IEncodable):
                    def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                        return helpers.encode_string(body)

                values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("body", ObjectExpr458())])
                class ObjectExpr459(IEncodable):
                    def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                        def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                            return (tupled_arg[0], tupled_arg[1].Encode(helpers_1))

                        arg: IEnumerable_1[tuple[str, Any]] = map_1(mapping, values)
                        return helpers_1.encode_object(arg)

                return ObjectExpr459()

            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "POST", _.note_segments(project_id, iid), empty(), _arrow460())
            def _arrow461(_arg: HttpResponse) -> Async[Note]:
                return singleton.Return(ResourceHelpers_decode(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow461)

        return singleton.Delay(_arrow462)

    def issue_segments[_A](self, project_id: Any=UNIT) -> FSharpList[str]:
        return of_array(Array[Any](["projects", to_string(project_id), "issues"]))

    def issue_segments_with_iid[_A, _B](self, project_id: Any, iid: Any) -> FSharpList[str]:
        this: IssuesApi = self
        return append(this.issue_segments(project_id), singleton_1(to_string(iid)))

    def note_segments[_A, _B](self, project_id: Any, iid: Any) -> FSharpList[str]:
        this: IssuesApi = self
        return append(this.issue_segments_with_iid(project_id, iid), singleton_1("notes"))


IssuesApi_reflection = _expr463

def IssuesApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> IssuesApi:
    return IssuesApi(base_url, auth, http)


__all__ = ["IssuesApi_reflection"]

