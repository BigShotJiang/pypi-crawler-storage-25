from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.core import int32
from fable_library.list import (map, sort_by, choose, FSharpList, is_empty, of_array, append, singleton)
from fable_library.option import (map as map_1, erase, widen)
from fable_library.result import FSharpResult_2
from fable_library.string_ import (trim_end, join)
from fable_library.util import (UNIT, escape_data_string, compare_primitives)
from ..fable_modules.thoth_json_core.decode import array
from ..fable_modules.thoth_json_core.types import (IEncodable, Decoder_1)
from ..fable_modules.thoth_json_python.decode import Decode_fromString
from ..fable_modules.thoth_json_python.encode import to_string
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Models.errors import DataHubError
from ..version import DataHubClientVersion

def JsonRuntime_encode(value: IEncodable) -> str:
    return to_string(int32.ZERO, value)


def JsonRuntime_decode[_A](decoder: Decoder_1[_A], value: str) -> FSharpResult_2[_A, str]:
    return Decode_fromString(decoder, value)


def ResourceHelpers_isSuccess(response: HttpResponse) -> bool:
    if response.StatusCode >= int32(200):
        return response.StatusCode < int32(300)

    else:
        return False



def ResourceHelpers_trimTrailingSlash(value: str) -> str:
    return trim_end(value, "/")


def ResourceHelpers_encodeSegment(value: str) -> str:
    return escape_data_string(value)


def ResourceHelpers_queryString(query: FSharpList[tuple[str, str | None]]) -> str:
    def mapping_1(tupled_arg_1: tuple[str, str]) -> str:
        return (ResourceHelpers_encodeSegment(tupled_arg_1[0]) + "=") + ResourceHelpers_encodeSegment(tupled_arg_1[1])

    def projection(tuple: tuple[str, str]) -> str:
        return tuple[0]

    def chooser(tupled_arg: tuple[str, str | None]) -> tuple[str, str] | None:
        def mapping(v: str, tupled_arg: Any=tupled_arg) -> tuple[str, str]:
            return (tupled_arg[0], v)

        return erase(map_1(mapping, tupled_arg[1]))

    class ObjectExpr403:
        def Compare(self, x: str, y: str) -> int32:
            return compare_primitives(x, y)

    _arg: FSharpList[str] = map(mapping_1, sort_by(projection, choose(widen(chooser), query), ObjectExpr403()))
    if is_empty(_arg):
        return ""

    else:
        return "?" + join("&", _arg)



def ResourceHelpers_url(base_url: str, segments: FSharpList[str], query: FSharpList[tuple[str, str | None]]) -> str:
    path: str = join("/", map(ResourceHelpers_encodeSegment, segments))
    return ((ResourceHelpers_trimTrailingSlash(base_url) + "/api/v4/") + path) + ResourceHelpers_queryString(query)


def ResourceHelpers_request(base_url: str, auth: Authentication, method: str, segments: FSharpList[str], query: FSharpList[tuple[str, str | None]], body: str | None=None, content_type: str | None=None) -> HttpRequest:
    req: HttpRequest = HttpRequest(url = ResourceHelpers_url(base_url, segments, query), method = method)
    req.Headers = of_array(Array[Any]([(auth.Header, auth.Value), (DataHubClientVersion.HeaderName, DataHubClientVersion.Value)]))
    req.Body = body
    match (content_type, body):
        case [None, _]:
            pass

        case [_, None]:
            pass

        case _:
            value: str = content_type
            req.Headers = append(req.Headers, singleton(("Content-Type", value)))

    return req


def ResourceHelpers_jsonRequest(base_url: str, auth: Authentication, method: str, segments: FSharpList[str], query: FSharpList[tuple[str, str | None]], body: IEncodable) -> HttpRequest:
    return ResourceHelpers_request(base_url, auth, method, segments, query, JsonRuntime_encode(body), "application/json")


def ResourceHelpers_emptyRequest(base_url: str, auth: Authentication, method: str, segments: FSharpList[str], query: FSharpList[tuple[str, str | None]]) -> HttpRequest:
    return ResourceHelpers_request(base_url, auth, method, segments, query, None, None)


def ResourceHelpers_textRequest(base_url: str, auth: Authentication, method: str, segments: FSharpList[str], query: FSharpList[tuple[str, str | None]], body: str, content_type: str) -> HttpRequest:
    return ResourceHelpers_request(base_url, auth, method, segments, query, body, content_type)


def ResourceHelpers_ensureSuccess(response: HttpResponse) -> None:
    if not ResourceHelpers_isSuccess(response):
        raise DataHubError.FromResponse(response)



def ResourceHelpers_decode[T](decoder: Decoder_1[T], response: HttpResponse) -> T:
    ResourceHelpers_ensureSuccess(response)
    match_value: FSharpResult_2[Any, str] = JsonRuntime_decode(decoder, response.Body)
    match match_value.tag:
        case 1:
            raise DataHubError(status_code = response.StatusCode, message = match_value.fields[0], body = response.Body)

        case _:
            return match_value.fields[0]



def ResourceHelpers_decodeArray[T](decoder: Decoder_1[T], response: HttpResponse) -> Array[T]:
    return ResourceHelpers_decode(array(decoder), response)


def ResourceHelpers_responseBody(response: HttpResponse) -> str:
    ResourceHelpers_ensureSuccess(response)
    return response.Body


__all__ = ["JsonRuntime_decode", "JsonRuntime_encode", "ResourceHelpers_decode", "ResourceHelpers_decodeArray", "ResourceHelpers_emptyRequest", "ResourceHelpers_encodeSegment", "ResourceHelpers_ensureSuccess", "ResourceHelpers_isSuccess", "ResourceHelpers_jsonRequest", "ResourceHelpers_queryString", "ResourceHelpers_request", "ResourceHelpers_responseBody", "ResourceHelpers_textRequest", "ResourceHelpers_trimTrailingSlash", "ResourceHelpers_url"]

