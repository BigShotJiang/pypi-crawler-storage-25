from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.exceptions import to_string
from fable_library.list import (singleton as singleton_1, empty, of_array, FSharpList)
from fable_library.option import map as map_1
from fable_library.protocols import IEnumerable_1
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.seq import map
from fable_library.util import (UNIT, Unit, to_enumerable)
from ..fable_modules.thoth_json_core.types import (IEncodable, IEncoderHelpers_1)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.repo_file import decoder
from ..Json.thoth_extensions import object_skip_null
from ..Models.repo_file import RepoFile
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decode, ResourceHelpers_jsonRequest, ResourceHelpers_ensureSuccess)

def _expr435() -> TypeInfo:
    return class_type("DataHubClient.FilesApi", None, FilesApi)


class FilesApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def Get(self, project_id: int32, file_path: str, ref_name: str) -> Async[RepoFile]:
        _: FilesApi = self
        def _arrow419(__unit: Unit=UNIT) -> Async[RepoFile]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.file_segments(project_id, file_path), singleton_1(("ref", ref_name)))
            def _arrow418(_arg: HttpResponse) -> Async[RepoFile]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow418)

        return singleton.Delay(_arrow419)

    def Create(self, project_id: int32, file_path: str, branch: str, content: str, commit_message: str, encoding: str | None=None) -> Async[RepoFile]:
        _: FilesApi = self
        def _arrow421(__unit: Unit=UNIT) -> Async[RepoFile]:
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "POST", _.file_segments(project_id, file_path), empty(), _.write_body(branch, content, commit_message, encoding))
            def _arrow420(_arg: HttpResponse) -> Async[RepoFile]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow420)

        return singleton.Delay(_arrow421)

    def Update(self, project_id: int32, file_path: str, branch: str, content: str, commit_message: str, encoding: str | None=None) -> Async[RepoFile]:
        _: FilesApi = self
        def _arrow423(__unit: Unit=UNIT) -> Async[RepoFile]:
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "PUT", _.file_segments(project_id, file_path), empty(), _.write_body(branch, content, commit_message, encoding))
            def _arrow422(_arg: HttpResponse) -> Async[RepoFile]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow422)

        return singleton.Delay(_arrow423)

    def Delete(self, project_id: int32, file_path: str, branch: str, commit_message: str) -> Async[None]:
        _: FilesApi = self
        def _arrow428(__unit: Unit=UNIT) -> Async[None]:
            body: IEncodable
            class ObjectExpr424(IEncodable):
                def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                    return helpers.encode_string(branch)

            class ObjectExpr425(IEncodable):
                def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                    return helpers_1.encode_string(commit_message)

            values: IEnumerable_1[tuple[str, IEncodable]] = to_enumerable([("branch", ObjectExpr424()), ("commit_message", ObjectExpr425())])
            class ObjectExpr426(IEncodable):
                def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                    def mapping(tupled_arg: tuple[str, IEncodable]) -> tuple[str, _A]:
                        return (tupled_arg[0], tupled_arg[1].Encode(helpers_2))

                    arg: IEnumerable_1[tuple[str, Any]] = map(mapping, values)
                    return helpers_2.encode_object(arg)

            body = ObjectExpr426()
            req: HttpRequest = ResourceHelpers_jsonRequest(_.base_url, _.auth, "DELETE", _.file_segments(project_id, file_path), empty(), body)
            def _arrow427(_arg: HttpResponse) -> Async[None]:
                ResourceHelpers_ensureSuccess(_arg)
                return singleton.Zero()

            return singleton.Bind(_.http.SendAsync(req), _arrow427)

        return singleton.Delay(_arrow428)

    def file_segments[_A](self, project_id: Any, file_path: str) -> FSharpList[str]:
        return of_array(Array[Any](["projects", to_string(project_id), "repository", "files", file_path]))

    def write_body(self, branch: str, content: str, commit_message: str, encoding: str | None=None) -> IEncodable:
        class ObjectExpr430(IEncodable):
            def Encode[_A](self, helpers: IEncoderHelpers_1[_A]) -> _A:
                return helpers.encode_string(branch)

        class ObjectExpr431(IEncodable):
            def Encode[_A](self, helpers_1: IEncoderHelpers_1[_A]) -> _A:
                return helpers_1.encode_string(content)

        class ObjectExpr432(IEncodable):
            def Encode[_A](self, helpers_2: IEncoderHelpers_1[_A]) -> _A:
                return helpers_2.encode_string(commit_message)

        def _arrow434(value_3: str) -> IEncodable:
            class ObjectExpr433(IEncodable):
                def Encode[_A](self, helpers_3: IEncoderHelpers_1[_A]) -> _A:
                    return helpers_3.encode_string(value_3)

            return ObjectExpr433()

        return object_skip_null(of_array(Array[Any]([("branch", ObjectExpr430()), ("content", ObjectExpr431()), ("commit_message", ObjectExpr432()), ("encoding", map_1(_arrow434, encoding))])))


FilesApi_reflection = _expr435

def FilesApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> FilesApi:
    return FilesApi(base_url, auth, http)


__all__ = ["FilesApi_reflection"]

