from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.list import (of_array, singleton as singleton_1, empty)
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.branch import decoder
from ..Json.commit import decoder as decoder_1
from ..Models.branch import Branch
from ..Models.commit import Commit
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decodeArray, ResourceHelpers_decode)

def _expr417() -> TypeInfo:
    return class_type("DataHubClient.RepositoryApi", None, RepositoryApi)


class RepositoryApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def ListBranches(self, project_id: int32, search: str | None=None) -> Async[Array[Branch]]:
        _: RepositoryApi = self
        def _arrow410(__unit: Unit=UNIT) -> Async[Array[Branch]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", of_array(Array[Any](["projects", int32(project_id).to_string(), "repository", "branches"])), singleton_1(("search", search)))
            def _arrow409(_arg: HttpResponse) -> Async[Array[Branch]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow409)

        return singleton.Delay(_arrow410)

    def GetBranch(self, project_id: int32, branch: str) -> Async[Branch]:
        _: RepositoryApi = self
        def _arrow412(__unit: Unit=UNIT) -> Async[Branch]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", of_array(Array[Any](["projects", int32(project_id).to_string(), "repository", "branches", branch])), empty())
            def _arrow411(_arg: HttpResponse) -> Async[Branch]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow411)

        return singleton.Delay(_arrow412)

    def ListCommits(self, project_id: int32, ref_name: str | None=None, path: str | None=None) -> Async[Array[Commit]]:
        _: RepositoryApi = self
        def _arrow414(__unit: Unit=UNIT) -> Async[Array[Commit]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", of_array(Array[Any](["projects", int32(project_id).to_string(), "repository", "commits"])), of_array(Array[Any]([("path", path), ("ref_name", ref_name)])))
            def _arrow413(_arg: HttpResponse) -> Async[Array[Commit]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow413)

        return singleton.Delay(_arrow414)

    def GetCommit(self, project_id: int32, sha: str) -> Async[Commit]:
        _: RepositoryApi = self
        def _arrow416(__unit: Unit=UNIT) -> Async[Commit]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", of_array(Array[Any](["projects", int32(project_id).to_string(), "repository", "commits", sha])), empty())
            def _arrow415(_arg: HttpResponse) -> Async[Commit]:
                return singleton.Return(ResourceHelpers_decode(decoder_1, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow415)

        return singleton.Delay(_arrow416)


RepositoryApi_reflection = _expr417

def RepositoryApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> RepositoryApi:
    return RepositoryApi(base_url, auth, http)


__all__ = ["RepositoryApi_reflection"]

