from __future__ import annotations
from typing import Any
from fable_library.array_ import Array
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.exceptions import to_string
from fable_library.list import (of_array, append, singleton as singleton_1, empty, FSharpList)
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from ..Http.authentication import Authentication
from ..Http.http_request import HttpRequest
from ..Http.http_response import HttpResponse
from ..Http.ihttp_client import IHttpClient
from ..Json.package import decoder
from ..Models.package import Package
from .resource_helpers import (ResourceHelpers_emptyRequest, ResourceHelpers_decodeArray, ResourceHelpers_decode, ResourceHelpers_textRequest, ResourceHelpers_responseBody)

def _expr474() -> TypeInfo:
    return class_type("DataHubClient.PackagesApi", None, PackagesApi)


class PackagesApi:
    def __init__(self, base_url: str, auth: Authentication, http: IHttpClient) -> None:
        self.base_url: str = base_url
        self.auth: Authentication = auth
        self.http: IHttpClient = http

    def List(self, project_id: int32, package_type: str | None=None, package_name: str | None=None) -> Async[Array[Package]]:
        _: PackagesApi = self
        def _arrow465(__unit: Unit=UNIT) -> Async[Array[Package]]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.package_segments(project_id), of_array(Array[Any]([("package_name", package_name), ("package_type", package_type)])))
            def _arrow464(_arg: HttpResponse) -> Async[Array[Package]]:
                return singleton.Return(ResourceHelpers_decodeArray(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow464)

        return singleton.Delay(_arrow465)

    def Get(self, project_id: int32, package_id: int32) -> Async[Package]:
        _: PackagesApi = self
        def _arrow467(__unit: Unit=UNIT) -> Async[Package]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", append(_.package_segments(project_id), singleton_1(int32(package_id).to_string())), empty())
            def _arrow466(_arg: HttpResponse) -> Async[Package]:
                return singleton.Return(ResourceHelpers_decode(decoder, _arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow466)

        return singleton.Delay(_arrow467)

    def UploadGenericFile(self, project_id: int32, package_name: str, version: str, file_name: str, content: str) -> Async[str]:
        _: PackagesApi = self
        def _arrow469(__unit: Unit=UNIT) -> Async[str]:
            req: HttpRequest = ResourceHelpers_textRequest(_.base_url, _.auth, "PUT", _.generic_file_segments(project_id, package_name, version, file_name), empty(), content, "application/octet-stream")
            def _arrow468(_arg: HttpResponse) -> Async[str]:
                return singleton.Return(ResourceHelpers_responseBody(_arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow468)

        return singleton.Delay(_arrow469)

    def DownloadGenericFile(self, project_id: int32, package_name: str, version: str, file_name: str) -> Async[str]:
        _: PackagesApi = self
        def _arrow471(__unit: Unit=UNIT) -> Async[str]:
            req: HttpRequest = ResourceHelpers_emptyRequest(_.base_url, _.auth, "GET", _.generic_file_segments(project_id, package_name, version, file_name), empty())
            def _arrow470(_arg: HttpResponse) -> Async[str]:
                return singleton.Return(ResourceHelpers_responseBody(_arg))

            return singleton.Bind(_.http.SendAsync(req), _arrow470)

        return singleton.Delay(_arrow471)

    def package_segments[_A](self, project_id: Any=UNIT) -> FSharpList[str]:
        return of_array(Array[Any](["projects", to_string(project_id), "packages"]))

    def generic_file_segments[_A](self, project_id: Any, package_name: str, version: str, file_name: str) -> FSharpList[str]:
        return of_array(Array[Any](["projects", to_string(project_id), "packages", "generic", package_name, version, file_name]))


PackagesApi_reflection = _expr474

def PackagesApi__ctor_22F7613(base_url: str, auth: Authentication, http: IHttpClient) -> PackagesApi:
    return PackagesApi(base_url, auth, http)


__all__ = ["PackagesApi_reflection"]

