from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr63() -> TypeInfo:
    return class_type("DataHubClient.Project", None, Project)


class Project:
    def __init__(self, id: int32, name: str, path: str, path_with_namespace: str, visibility: str, web_url: str, description: str | None=None, default_branch: str | None=None) -> None:
        self._id: int32 = id
        self._name: str = name
        self._path: str = path
        self._pathWithNamespace: str = path_with_namespace
        self._visibility: str = visibility
        self._webUrl: str = web_url
        self._description: str | None = description
        self._defaultBranch: str | None = default_branch

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: Project = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: Project = self
        _._id = value

    @property
    def Name(self, __unit: Unit=UNIT) -> str:
        _: Project = self
        return _._name

    @Name.setter
    def Name(self, value: str) -> None:
        _: Project = self
        _._name = value

    @property
    def Path(self, __unit: Unit=UNIT) -> str:
        _: Project = self
        return _._path

    @Path.setter
    def Path(self, value: str) -> None:
        _: Project = self
        _._path = value

    @property
    def PathWithNamespace(self, __unit: Unit=UNIT) -> str:
        _: Project = self
        return _._pathWithNamespace

    @PathWithNamespace.setter
    def PathWithNamespace(self, value: str) -> None:
        _: Project = self
        _._pathWithNamespace = value

    @property
    def Visibility(self, __unit: Unit=UNIT) -> str:
        _: Project = self
        return _._visibility

    @Visibility.setter
    def Visibility(self, value: str) -> None:
        _: Project = self
        _._visibility = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str:
        _: Project = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str) -> None:
        _: Project = self
        _._webUrl = value

    @property
    def Description(self, __unit: Unit=UNIT) -> str | None:
        _: Project = self
        return _._description

    @Description.setter
    def Description(self, value: str | None=None) -> None:
        _: Project = self
        _._description = value

    @property
    def DefaultBranch(self, __unit: Unit=UNIT) -> str | None:
        _: Project = self
        return _._defaultBranch

    @DefaultBranch.setter
    def DefaultBranch(self, value: str | None=None) -> None:
        _: Project = self
        _._defaultBranch = value


Project_reflection = _expr63

def Project__ctor_Z3FF99C59(id: int32, name: str, path: str, path_with_namespace: str, visibility: str, web_url: str, description: str | None=None, default_branch: str | None=None) -> Project:
    return Project(id, name, path, path_with_namespace, visibility, web_url, description, default_branch)


__all__ = ["Project_reflection"]

