from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr69() -> TypeInfo:
    return class_type("DataHubClient.Package", None, Package)


class Package:
    def __init__(self, id: int32, name: str, version: str, package_type: str, status: str, created_at: str, web_url: str | None=None) -> None:
        self._id: int32 = id
        self._name: str = name
        self._version: str = version
        self._packageType: str = package_type
        self._status: str = status
        self._createdAt: str = created_at
        self._webUrl: str | None = web_url

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: Package = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: Package = self
        _._id = value

    @property
    def Name(self, __unit: Unit=UNIT) -> str:
        _: Package = self
        return _._name

    @Name.setter
    def Name(self, value: str) -> None:
        _: Package = self
        _._name = value

    @property
    def Version(self, __unit: Unit=UNIT) -> str:
        _: Package = self
        return _._version

    @Version.setter
    def Version(self, value: str) -> None:
        _: Package = self
        _._version = value

    @property
    def PackageType(self, __unit: Unit=UNIT) -> str:
        _: Package = self
        return _._packageType

    @PackageType.setter
    def PackageType(self, value: str) -> None:
        _: Package = self
        _._packageType = value

    @property
    def Status(self, __unit: Unit=UNIT) -> str:
        _: Package = self
        return _._status

    @Status.setter
    def Status(self, value: str) -> None:
        _: Package = self
        _._status = value

    @property
    def CreatedAt(self, __unit: Unit=UNIT) -> str:
        _: Package = self
        return _._createdAt

    @CreatedAt.setter
    def CreatedAt(self, value: str) -> None:
        _: Package = self
        _._createdAt = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str | None:
        _: Package = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str | None=None) -> None:
        _: Package = self
        _._webUrl = value


Package_reflection = _expr69

def Package__ctor_625CF5FF(id: int32, name: str, version: str, package_type: str, status: str, created_at: str, web_url: str | None=None) -> Package:
    return Package(id, name, version, package_type, status, created_at, web_url)


__all__ = ["Package_reflection"]

