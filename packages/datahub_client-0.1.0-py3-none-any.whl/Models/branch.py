from __future__ import annotations
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .commit import Commit

def _expr64() -> TypeInfo:
    return class_type("DataHubClient.Branch", None, Branch)


class Branch:
    def __init__(self, name: str, is_default: bool, is_protected: bool, merged: bool, commit: Commit) -> None:
        self._name: str = name
        self._isDefault: bool = is_default
        self._isProtected: bool = is_protected
        self._merged: bool = merged
        self._commit: Commit = commit

    @property
    def Name(self, __unit: Unit=UNIT) -> str:
        _: Branch = self
        return _._name

    @Name.setter
    def Name(self, value: str) -> None:
        _: Branch = self
        _._name = value

    @property
    def Default(self, __unit: Unit=UNIT) -> bool:
        _: Branch = self
        return _._isDefault

    @Default.setter
    def Default(self, value: bool) -> None:
        _: Branch = self
        _._isDefault = value

    @property
    def Protected(self, __unit: Unit=UNIT) -> bool:
        _: Branch = self
        return _._isProtected

    @Protected.setter
    def Protected(self, value: bool) -> None:
        _: Branch = self
        _._isProtected = value

    @property
    def Merged(self, __unit: Unit=UNIT) -> bool:
        _: Branch = self
        return _._merged

    @Merged.setter
    def Merged(self, value: bool) -> None:
        _: Branch = self
        _._merged = value

    @property
    def Commit(self, __unit: Unit=UNIT) -> Commit:
        _: Branch = self
        return _._commit

    @Commit.setter
    def Commit(self, value: Commit) -> None:
        _: Branch = self
        _._commit = value


Branch_reflection = _expr64

def Branch__ctor_566350DD(name: str, is_default: bool, is_protected: bool, merged: bool, commit: Commit) -> Branch:
    return Branch(name, is_default, is_protected, merged, commit)


__all__ = ["Branch_reflection"]

