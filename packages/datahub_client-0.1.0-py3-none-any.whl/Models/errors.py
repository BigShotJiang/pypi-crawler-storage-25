from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from ..Http.http_response import HttpResponse

def _expr57() -> TypeInfo:
    return class_type("DataHubClient.DataHubError", None, DataHubError, class_type("System.Exception"))


class DataHubError(Exception):
    def __init__(self, status_code: int32, message: str, body: str) -> None:
        super().__init__(message)
        self.status_code: int32 = status_code
        self.body: str = body

    @property
    def StatusCode(self, __unit: Unit=UNIT) -> int32:
        _: DataHubError = self
        return _.status_code

    @property
    def Body(self, __unit: Unit=UNIT) -> str:
        _: DataHubError = self
        return _.body

    @staticmethod
    def FromResponse(response: HttpResponse) -> DataHubError:
        match_value: int32 = response.StatusCode
        match match_value:
            case match_value if match_value == int32(401):
                return UnauthorizedError(status_code = response.StatusCode, body = response.Body)

            case match_value if match_value == int32(403):
                return UnauthorizedError(status_code = response.StatusCode, body = response.Body)

            case match_value if match_value == int32(404):
                return NotFoundError(body = response.Body)

            case match_value if match_value == int32(429):
                return RateLimitedError(body = response.Body)

            case match_value if match_value >= int32(500):
                return ServerError(status_code = match_value, body = response.Body)

            case _:
                code_2: int32 = match_value
                return DataHubError(status_code = code_2, message = "HTTP " + int32(code_2).to_string(), body = response.Body)



DataHubError_reflection = _expr57

def DataHubError__ctor_7751B6FC(status_code: int32, message: str, body: str) -> DataHubError:
    return DataHubError(status_code, message, body)


def _expr58() -> TypeInfo:
    return class_type("DataHubClient.UnauthorizedError", None, UnauthorizedError, DataHubError_reflection())


class UnauthorizedError(DataHubError):
    def __init__(self, status_code: int32, body: str) -> None:
        super().__init__(status_code, "Unauthorized", body)
        pass


UnauthorizedError_reflection = _expr58

def UnauthorizedError__ctor_Z176EF219(status_code: int32, body: str) -> UnauthorizedError:
    return UnauthorizedError(status_code, body)


def _expr59() -> TypeInfo:
    return class_type("DataHubClient.NotFoundError", None, NotFoundError, DataHubError_reflection())


class NotFoundError(DataHubError):
    def __init__(self, body: str) -> None:
        super().__init__(int32(404), "Not found", body)
        pass


NotFoundError_reflection = _expr59

def NotFoundError__ctor_Z721C83C5(body: str) -> NotFoundError:
    return NotFoundError(body)


def _expr60() -> TypeInfo:
    return class_type("DataHubClient.RateLimitedError", None, RateLimitedError, DataHubError_reflection())


class RateLimitedError(DataHubError):
    def __init__(self, body: str) -> None:
        super().__init__(int32(429), "Rate limited", body)
        pass


RateLimitedError_reflection = _expr60

def RateLimitedError__ctor_Z721C83C5(body: str) -> RateLimitedError:
    return RateLimitedError(body)


def _expr62() -> TypeInfo:
    return class_type("DataHubClient.ServerError", None, ServerError, DataHubError_reflection())


class ServerError(DataHubError):
    def __init__(self, status_code: int32, body: str) -> None:
        super().__init__(status_code, "Server error", body)
        pass


ServerError_reflection = _expr62

def ServerError__ctor_Z176EF219(status_code: int32, body: str) -> ServerError:
    return ServerError(status_code, body)


__all__ = ["DataHubError_reflection", "NotFoundError_reflection", "RateLimitedError_reflection", "ServerError_reflection", "UnauthorizedError_reflection"]

