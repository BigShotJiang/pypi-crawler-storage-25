from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .user import User

def _expr67() -> TypeInfo:
    return class_type("DataHubClient.Note", None, Note)


class Note:
    def __init__(self, id: int32, body: str, author: User, is_system: bool, created_at: str, updated_at: str) -> None:
        self._id: int32 = id
        self._body: str = body
        self._author: User = author
        self._isSystem: bool = is_system
        self._createdAt: str = created_at
        self._updatedAt: str = updated_at

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: Note = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: Note = self
        _._id = value

    @property
    def Body(self, __unit: Unit=UNIT) -> str:
        _: Note = self
        return _._body

    @Body.setter
    def Body(self, value: str) -> None:
        _: Note = self
        _._body = value

    @property
    def Author(self, __unit: Unit=UNIT) -> User:
        _: Note = self
        return _._author

    @Author.setter
    def Author(self, value: User) -> None:
        _: Note = self
        _._author = value

    @property
    def System(self, __unit: Unit=UNIT) -> bool:
        _: Note = self
        return _._isSystem

    @System.setter
    def System(self, value: bool) -> None:
        _: Note = self
        _._isSystem = value

    @property
    def CreatedAt(self, __unit: Unit=UNIT) -> str:
        _: Note = self
        return _._createdAt

    @CreatedAt.setter
    def CreatedAt(self, value: str) -> None:
        _: Note = self
        _._createdAt = value

    @property
    def UpdatedAt(self, __unit: Unit=UNIT) -> str:
        _: Note = self
        return _._updatedAt

    @UpdatedAt.setter
    def UpdatedAt(self, value: str) -> None:
        _: Note = self
        _._updatedAt = value


Note_reflection = _expr67

def Note__ctor_67B7AB01(id: int32, body: str, author: User, is_system: bool, created_at: str, updated_at: str) -> Note:
    return Note(id, body, author, is_system, created_at, updated_at)


__all__ = ["Note_reflection"]

