from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr66() -> TypeInfo:
    return class_type("DataHubClient.RepoFile", None, RepoFile)


class RepoFile:
    def __init__(self, file_name: str, file_path: str, size: int32, encoding: str, content: str, ref_name: str, blob_id: str, commit_id: str) -> None:
        self._fileName: str = file_name
        self._filePath: str = file_path
        self._size: int32 = size
        self._encoding: str = encoding
        self._content: str = content
        self._refName: str = ref_name
        self._blobId: str = blob_id
        self._commitId: str = commit_id

    @property
    def FileName(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._fileName

    @FileName.setter
    def FileName(self, value: str) -> None:
        _: RepoFile = self
        _._fileName = value

    @property
    def FilePath(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._filePath

    @FilePath.setter
    def FilePath(self, value: str) -> None:
        _: RepoFile = self
        _._filePath = value

    @property
    def Size(self, __unit: Unit=UNIT) -> int32:
        _: RepoFile = self
        return _._size

    @Size.setter
    def Size(self, value: int32) -> None:
        _: RepoFile = self
        _._size = value

    @property
    def Encoding(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._encoding

    @Encoding.setter
    def Encoding(self, value: str) -> None:
        _: RepoFile = self
        _._encoding = value

    @property
    def Content(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._content

    @Content.setter
    def Content(self, value: str) -> None:
        _: RepoFile = self
        _._content = value

    @property
    def Ref(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._refName

    @Ref.setter
    def Ref(self, value: str) -> None:
        _: RepoFile = self
        _._refName = value

    @property
    def BlobId(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._blobId

    @BlobId.setter
    def BlobId(self, value: str) -> None:
        _: RepoFile = self
        _._blobId = value

    @property
    def CommitId(self, __unit: Unit=UNIT) -> str:
        _: RepoFile = self
        return _._commitId

    @CommitId.setter
    def CommitId(self, value: str) -> None:
        _: RepoFile = self
        _._commitId = value


RepoFile_reflection = _expr66

def RepoFile__ctor_74652A07(file_name: str, file_path: str, size: int32, encoding: str, content: str, ref_name: str, blob_id: str, commit_id: str) -> RepoFile:
    return RepoFile(file_name, file_path, size, encoding, content, ref_name, blob_id, commit_id)


__all__ = ["RepoFile_reflection"]

