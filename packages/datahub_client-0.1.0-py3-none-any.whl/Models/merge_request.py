from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .user import User

def _expr70() -> TypeInfo:
    return class_type("DataHubClient.MergeRequest", None, MergeRequest)


class MergeRequest:
    def __init__(self, id: int32, iid: int32, project_id: int32, title: str, state: str, source_branch: str, target_branch: str, author: User, web_url: str, created_at: str, updated_at: str, description: str | None=None, merge_status: str | None=None) -> None:
        self._id: int32 = id
        self._iid: int32 = iid
        self._projectId: int32 = project_id
        self._title: str = title
        self._state: str = state
        self._sourceBranch: str = source_branch
        self._targetBranch: str = target_branch
        self._author: User = author
        self._webUrl: str = web_url
        self._createdAt: str = created_at
        self._updatedAt: str = updated_at
        self._description: str | None = description
        self._mergeStatus: str | None = merge_status

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: MergeRequest = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: MergeRequest = self
        _._id = value

    @property
    def Iid(self, __unit: Unit=UNIT) -> int32:
        _: MergeRequest = self
        return _._iid

    @Iid.setter
    def Iid(self, value: int32) -> None:
        _: MergeRequest = self
        _._iid = value

    @property
    def ProjectId(self, __unit: Unit=UNIT) -> int32:
        _: MergeRequest = self
        return _._projectId

    @ProjectId.setter
    def ProjectId(self, value: int32) -> None:
        _: MergeRequest = self
        _._projectId = value

    @property
    def Title(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._title

    @Title.setter
    def Title(self, value: str) -> None:
        _: MergeRequest = self
        _._title = value

    @property
    def State(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._state

    @State.setter
    def State(self, value: str) -> None:
        _: MergeRequest = self
        _._state = value

    @property
    def SourceBranch(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._sourceBranch

    @SourceBranch.setter
    def SourceBranch(self, value: str) -> None:
        _: MergeRequest = self
        _._sourceBranch = value

    @property
    def TargetBranch(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._targetBranch

    @TargetBranch.setter
    def TargetBranch(self, value: str) -> None:
        _: MergeRequest = self
        _._targetBranch = value

    @property
    def Author(self, __unit: Unit=UNIT) -> User:
        _: MergeRequest = self
        return _._author

    @Author.setter
    def Author(self, value: User) -> None:
        _: MergeRequest = self
        _._author = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str) -> None:
        _: MergeRequest = self
        _._webUrl = value

    @property
    def CreatedAt(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._createdAt

    @CreatedAt.setter
    def CreatedAt(self, value: str) -> None:
        _: MergeRequest = self
        _._createdAt = value

    @property
    def UpdatedAt(self, __unit: Unit=UNIT) -> str:
        _: MergeRequest = self
        return _._updatedAt

    @UpdatedAt.setter
    def UpdatedAt(self, value: str) -> None:
        _: MergeRequest = self
        _._updatedAt = value

    @property
    def Description(self, __unit: Unit=UNIT) -> str | None:
        _: MergeRequest = self
        return _._description

    @Description.setter
    def Description(self, value: str | None=None) -> None:
        _: MergeRequest = self
        _._description = value

    @property
    def MergeStatus(self, __unit: Unit=UNIT) -> str | None:
        _: MergeRequest = self
        return _._mergeStatus

    @MergeStatus.setter
    def MergeStatus(self, value: str | None=None) -> None:
        _: MergeRequest = self
        _._mergeStatus = value


MergeRequest_reflection = _expr70

def MergeRequest__ctor_6F09FC6B(id: int32, iid: int32, project_id: int32, title: str, state: str, source_branch: str, target_branch: str, author: User, web_url: str, created_at: str, updated_at: str, description: str | None=None, merge_status: str | None=None) -> MergeRequest:
    return MergeRequest(id, iid, project_id, title, state, source_branch, target_branch, author, web_url, created_at, updated_at, description, merge_status)


__all__ = ["MergeRequest_reflection"]

