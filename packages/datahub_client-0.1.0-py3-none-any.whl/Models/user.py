from __future__ import annotations
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr61() -> TypeInfo:
    return class_type("DataHubClient.User", None, User)


class User:
    def __init__(self, id: int32, username: str, name: str, state: str, web_url: str, avatar_url: str | None=None) -> None:
        self._id: int32 = id
        self._username: str = username
        self._name: str = name
        self._state: str = state
        self._webUrl: str = web_url
        self._avatarUrl: str | None = avatar_url

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: User = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: User = self
        _._id = value

    @property
    def Username(self, __unit: Unit=UNIT) -> str:
        _: User = self
        return _._username

    @Username.setter
    def Username(self, value: str) -> None:
        _: User = self
        _._username = value

    @property
    def Name(self, __unit: Unit=UNIT) -> str:
        _: User = self
        return _._name

    @Name.setter
    def Name(self, value: str) -> None:
        _: User = self
        _._name = value

    @property
    def State(self, __unit: Unit=UNIT) -> str:
        _: User = self
        return _._state

    @State.setter
    def State(self, value: str) -> None:
        _: User = self
        _._state = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str:
        _: User = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str) -> None:
        _: User = self
        _._webUrl = value

    @property
    def AvatarUrl(self, __unit: Unit=UNIT) -> str | None:
        _: User = self
        return _._avatarUrl

    @AvatarUrl.setter
    def AvatarUrl(self, value: str | None=None) -> None:
        _: User = self
        _._avatarUrl = value


User_reflection = _expr61

def User__ctor_18A9E4E4(id: int32, username: str, name: str, state: str, web_url: str, avatar_url: str | None=None) -> User:
    return User(id, username, name, state, web_url, avatar_url)


__all__ = ["User_reflection"]

