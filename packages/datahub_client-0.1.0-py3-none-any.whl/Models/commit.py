from __future__ import annotations
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr65() -> TypeInfo:
    return class_type("DataHubClient.Commit", None, Commit)


class Commit:
    def __init__(self, id: str, short_id: str, title: str, message: str, author_name: str, author_email: str, created_at: str, web_url: str | None=None) -> None:
        self._id: str = id
        self._shortId: str = short_id
        self._title: str = title
        self._message: str = message
        self._authorName: str = author_name
        self._authorEmail: str = author_email
        self._createdAt: str = created_at
        self._webUrl: str | None = web_url

    @property
    def Id(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._id

    @Id.setter
    def Id(self, value: str) -> None:
        _: Commit = self
        _._id = value

    @property
    def ShortId(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._shortId

    @ShortId.setter
    def ShortId(self, value: str) -> None:
        _: Commit = self
        _._shortId = value

    @property
    def Title(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._title

    @Title.setter
    def Title(self, value: str) -> None:
        _: Commit = self
        _._title = value

    @property
    def Message(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._message

    @Message.setter
    def Message(self, value: str) -> None:
        _: Commit = self
        _._message = value

    @property
    def AuthorName(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._authorName

    @AuthorName.setter
    def AuthorName(self, value: str) -> None:
        _: Commit = self
        _._authorName = value

    @property
    def AuthorEmail(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._authorEmail

    @AuthorEmail.setter
    def AuthorEmail(self, value: str) -> None:
        _: Commit = self
        _._authorEmail = value

    @property
    def CreatedAt(self, __unit: Unit=UNIT) -> str:
        _: Commit = self
        return _._createdAt

    @CreatedAt.setter
    def CreatedAt(self, value: str) -> None:
        _: Commit = self
        _._createdAt = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str | None:
        _: Commit = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str | None=None) -> None:
        _: Commit = self
        _._webUrl = value


Commit_reflection = _expr65

def Commit__ctor_Z28B1A03D(id: str, short_id: str, title: str, message: str, author_name: str, author_email: str, created_at: str, web_url: str | None=None) -> Commit:
    return Commit(id, short_id, title, message, author_name, author_email, created_at, web_url)


__all__ = ["Commit_reflection"]

