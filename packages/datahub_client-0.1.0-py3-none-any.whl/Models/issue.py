from __future__ import annotations
from fable_library.array_ import Array
from fable_library.core import int32
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)
from .user import User

def _expr68() -> TypeInfo:
    return class_type("DataHubClient.Issue", None, Issue)


class Issue:
    def __init__(self, id: int32, iid: int32, project_id: int32, title: str, state: str, author: User, assignees: Array[User], labels: Array[str], web_url: str, created_at: str, updated_at: str, description: str | None=None) -> None:
        self._id: int32 = id
        self._iid: int32 = iid
        self._projectId: int32 = project_id
        self._title: str = title
        self._state: str = state
        self._author: User = author
        self._assignees: Array[User] = assignees
        self._labels: Array[str] = labels
        self._webUrl: str = web_url
        self._createdAt: str = created_at
        self._updatedAt: str = updated_at
        self._description: str | None = description

    @property
    def Id(self, __unit: Unit=UNIT) -> int32:
        _: Issue = self
        return _._id

    @Id.setter
    def Id(self, value: int32) -> None:
        _: Issue = self
        _._id = value

    @property
    def Iid(self, __unit: Unit=UNIT) -> int32:
        _: Issue = self
        return _._iid

    @Iid.setter
    def Iid(self, value: int32) -> None:
        _: Issue = self
        _._iid = value

    @property
    def ProjectId(self, __unit: Unit=UNIT) -> int32:
        _: Issue = self
        return _._projectId

    @ProjectId.setter
    def ProjectId(self, value: int32) -> None:
        _: Issue = self
        _._projectId = value

    @property
    def Title(self, __unit: Unit=UNIT) -> str:
        _: Issue = self
        return _._title

    @Title.setter
    def Title(self, value: str) -> None:
        _: Issue = self
        _._title = value

    @property
    def State(self, __unit: Unit=UNIT) -> str:
        _: Issue = self
        return _._state

    @State.setter
    def State(self, value: str) -> None:
        _: Issue = self
        _._state = value

    @property
    def Author(self, __unit: Unit=UNIT) -> User:
        _: Issue = self
        return _._author

    @Author.setter
    def Author(self, value: User) -> None:
        _: Issue = self
        _._author = value

    @property
    def Assignees(self, __unit: Unit=UNIT) -> Array[User]:
        _: Issue = self
        return _._assignees

    @Assignees.setter
    def Assignees(self, value: Array[User]) -> None:
        _: Issue = self
        _._assignees = value

    @property
    def Labels(self, __unit: Unit=UNIT) -> Array[str]:
        _: Issue = self
        return _._labels

    @Labels.setter
    def Labels(self, value: Array[str]) -> None:
        _: Issue = self
        _._labels = value

    @property
    def WebUrl(self, __unit: Unit=UNIT) -> str:
        _: Issue = self
        return _._webUrl

    @WebUrl.setter
    def WebUrl(self, value: str) -> None:
        _: Issue = self
        _._webUrl = value

    @property
    def CreatedAt(self, __unit: Unit=UNIT) -> str:
        _: Issue = self
        return _._createdAt

    @CreatedAt.setter
    def CreatedAt(self, value: str) -> None:
        _: Issue = self
        _._createdAt = value

    @property
    def UpdatedAt(self, __unit: Unit=UNIT) -> str:
        _: Issue = self
        return _._updatedAt

    @UpdatedAt.setter
    def UpdatedAt(self, value: str) -> None:
        _: Issue = self
        _._updatedAt = value

    @property
    def Description(self, __unit: Unit=UNIT) -> str | None:
        _: Issue = self
        return _._description

    @Description.setter
    def Description(self, value: str | None=None) -> None:
        _: Issue = self
        _._description = value


Issue_reflection = _expr68

def Issue__ctor_Z1B73989C(id: int32, iid: int32, project_id: int32, title: str, state: str, author: User, assignees: Array[User], labels: Array[str], web_url: str, created_at: str, updated_at: str, description: str | None=None) -> Issue:
    return Issue(id, iid, project_id, title, state, author, assignees, labels, web_url, created_at, updated_at, description)


__all__ = ["Issue_reflection"]

