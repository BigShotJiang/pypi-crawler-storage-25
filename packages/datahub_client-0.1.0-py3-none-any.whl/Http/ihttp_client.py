from __future__ import annotations
from abc import abstractmethod
from typing import Protocol
from fable_library.async_builder import Async
from .http_request import HttpRequest
from .http_response import HttpResponse

class IHttpClient(Protocol):
    @abstractmethod
    def SendAsync(self, request: HttpRequest, /) -> Async[HttpResponse]:
        ...


