from __future__ import annotations
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr53() -> TypeInfo:
    return class_type("DataHubClient.Authentication", None, Authentication)


class Authentication:
    def __init__(self, header: str, value: str) -> None:
        self.header: str = header
        self.value: str = value

    @property
    def Header(self, __unit: Unit=UNIT) -> str:
        _: Authentication = self
        return _.header

    @property
    def Value(self, __unit: Unit=UNIT) -> str:
        _: Authentication = self
        return _.value

    @staticmethod
    def PersonalAccessToken(token: str) -> Authentication:
        return Authentication(header = "PRIVATE-TOKEN", value = token)

    @staticmethod
    def OAuthToken(token: str) -> Authentication:
        return Authentication(header = "Authorization", value = "Bearer " + token)

    @staticmethod
    def JobToken(token: str) -> Authentication:
        return Authentication(header = "JOB-TOKEN", value = token)


Authentication_reflection = _expr53

def Authentication__ctor_Z384F8060(header: str, value: str) -> Authentication:
    return Authentication(header, value)


__all__ = ["Authentication_reflection"]

