from __future__ import annotations
from typing import cast
from fable_library.list import (FSharpList, empty)
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr54() -> TypeInfo:
    return class_type("DataHubClient.HttpRequest", None, HttpRequest)


class HttpRequest:
    def __init__(self, url: str, method: str) -> None:
        self._url: str = url
        self._method: str = method
        self._headers: FSharpList[tuple[str, str]] = empty()
        self._body: str | None = cast(str | None, None)

    @property
    def Url(self, __unit: Unit=UNIT) -> str:
        _: HttpRequest = self
        return _._url

    @Url.setter
    def Url(self, value: str) -> None:
        _: HttpRequest = self
        _._url = value

    @property
    def Method(self, __unit: Unit=UNIT) -> str:
        _: HttpRequest = self
        return _._method

    @Method.setter
    def Method(self, value: str) -> None:
        _: HttpRequest = self
        _._method = value

    @property
    def Headers(self, __unit: Unit=UNIT) -> FSharpList[tuple[str, str]]:
        _: HttpRequest = self
        return _._headers

    @Headers.setter
    def Headers(self, value: FSharpList[tuple[str, str]]) -> None:
        _: HttpRequest = self
        _._headers = value

    @property
    def Body(self, __unit: Unit=UNIT) -> str | None:
        _: HttpRequest = self
        return _._body

    @Body.setter
    def Body(self, value: str | None=None) -> None:
        _: HttpRequest = self
        _._body = value


HttpRequest_reflection = _expr54

def HttpRequest__ctor_Z384F8060(url: str, method: str) -> HttpRequest:
    return HttpRequest(url, method)


__all__ = ["HttpRequest_reflection"]

