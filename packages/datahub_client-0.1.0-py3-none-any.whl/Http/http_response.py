from __future__ import annotations
from fable_library.core import int32
from fable_library.list import FSharpList
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.util import (UNIT, Unit)

def _expr51() -> TypeInfo:
    return class_type("DataHubClient.HttpResponse", None, HttpResponse)


class HttpResponse:
    def __init__(self, status_code: int32, body: str, headers: FSharpList[tuple[str, str]]) -> None:
        self.status_code: int32 = status_code
        self.body: str = body
        self.headers: FSharpList[tuple[str, str]] = headers

    @property
    def StatusCode(self, __unit: Unit=UNIT) -> int32:
        _: HttpResponse = self
        return _.status_code

    @property
    def Body(self, __unit: Unit=UNIT) -> str:
        _: HttpResponse = self
        return _.body

    @property
    def Headers(self, __unit: Unit=UNIT) -> FSharpList[tuple[str, str]]:
        _: HttpResponse = self
        return _.headers


HttpResponse_reflection = _expr51

def HttpResponse__ctor_54FCE56A(status_code: int32, body: str, headers: FSharpList[tuple[str, str]]) -> HttpResponse:
    return HttpResponse(status_code, body, headers)


__all__ = ["HttpResponse_reflection"]

