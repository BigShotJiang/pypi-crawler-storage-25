from __future__ import annotations
from abc import abstractmethod
from typing import (Protocol, Any, cast)
from fable_library.async_ import await_task
from fable_library.async_builder import (singleton, Async)
from fable_library.core import int32
from fable_library.list import FSharpList
from fable_library.protocols import IEnumerable_1
from fable_library.reflection import (TypeInfo, class_type)
from fable_library.resize_array import of_seq
from fable_library.seq import (to_list, delay, collect, singleton as singleton_1)
from fable_library.util import (UNIT, Unit)
from .http_request import HttpRequest
from .http_response import HttpResponse

class HttpxResponse(Protocol):
    @property
    @abstractmethod
    def status_code(self, /) -> int32:
        ...

    @property
    @abstractmethod
    def text(self, /) -> str:
        ...


class HttpxAsyncClient(Protocol):
    pass

def _expr510() -> TypeInfo:
    return class_type("DataHubClient.HttpxHttpClient", None, HttpxHttpClient)


class HttpxHttpClient:
    def __init__(self, __unit: Unit=UNIT) -> None:
        pass

    def SendAsync(self, request: HttpRequest) -> Async[HttpResponse]:
        def _arrow509(__unit: Unit=UNIT) -> Async[HttpResponse]:
            client: HttpxAsyncClient = __import__('httpx').AsyncClient()
            def _arrow504(__unit: Unit=UNIT) -> IEnumerable_1[tuple[str, str]]:
                def _arrow503(match_value: tuple[str, str]) -> IEnumerable_1[tuple[str, str]]:
                    return singleton_1((match_value[0], match_value[1]))

                return collect(_arrow503, request.Headers)

            headers: Any = of_seq(to_list(delay(_arrow504)))
            content: Any
            match_value_1: str | None = request.Body
            content = cast(Any, None) if (match_value_1 is None) else match_value_1
            def _arrow508(_arg: HttpxResponse) -> Async[HttpResponse]:
                response: HttpxResponse = _arg
                def _arrow507(__unit: Unit=UNIT) -> Async[HttpResponse]:
                    def _arrow506(__unit: Unit=UNIT) -> IEnumerable_1[tuple[str, str]]:
                        def _arrow505(match_value_2: tuple[str, str]) -> IEnumerable_1[tuple[str, str]]:
                            return singleton_1((match_value_2[0], match_value_2[1]))

                        return collect(_arrow505, list(response.headers.items()))

                    collected: FSharpList[tuple[str, str]] = to_list(delay(_arrow506))
                    return singleton.Return(HttpResponse(status_code = response.status_code, body = response.text, headers = collected))

                return singleton.Bind(await_task(client.aclose()), _arrow507)

            return singleton.Bind(await_task(client.request(request.Method, request.Url, headers=headers, content=content)), _arrow508)

        return singleton.Delay(_arrow509)


HttpxHttpClient_reflection = _expr510

def HttpxHttpClient__ctor(__unit: Unit=UNIT) -> HttpxHttpClient:
    return HttpxHttpClient(__unit)


__all__ = ["HttpxHttpClient_reflection"]

