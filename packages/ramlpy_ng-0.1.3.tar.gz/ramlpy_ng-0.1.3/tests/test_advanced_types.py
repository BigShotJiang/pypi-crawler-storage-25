import pytest
from ramlpy import parse

def test_union_and_arrays_parsing():
    api = parse("tests/fixtures/raml10/union_and_arrays.raml")
    worker_validator = api.validator_for("/worker", "POST")
    
    # Assert Annotations
    res = api.resource("/worker")
    assert res.annotations.get("experimental") is True
    
    # Assert Union Types Validation (GET Response usually not validated by default, let's test POST body)
    valid_employee_array = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
    valid_org = {"companyName": "Acme", "taxId": "123-AB"}
    invalid_string = "Just a string"
    invalid_object = {"random": "stuff"}
    
    # Validate POST /worker with Employee[]
    res1 = worker_validator.validate(body=valid_employee_array, content_type="application/json")
    assert res1.ok
    
    # Validate POST /worker with Organization
    res2 = worker_validator.validate(body=valid_org, content_type="application/json")
    assert res2.ok
    
    # Validate POST /worker with string (should fail)
    res3 = worker_validator.validate(body=invalid_string, content_type="application/json")
    assert not res3.ok
    assert any('not valid under any' in e.get('message', '') or 'jsonschema' in e.get('code', '') for e in res3.errors), "Should fail with schema mismatch"

def test_inline_union_validation():
    api = parse("tests/fixtures/raml10/union_and_arrays.raml")
    mixed_validator = api.validator_for("/mixed", "POST")
    
    # POST /mixed identifier is StringOrInt
    res1 = mixed_validator.validate(body={"identifier": "123"}, content_type="application/json")
    assert res1.ok
    
    res2 = mixed_validator.validate(body={"identifier": 123}, content_type="application/json")
    assert res2.ok
    
    res3 = mixed_validator.validate(body={"identifier": {"obj": True}}, content_type="application/json")
    assert not res3.ok
