import pytest
from ramlpy import parse

def test_complex_parsing():
    """Test that we can parse a complex RAML file without crashing."""
    api = parse("tests/fixtures/raml10/complex_api.raml")
    assert api.title == "Complex API"
    assert api.version == "v2"
    
    # Check that traits and resourceTypes are in the API spec
    assert "pageable" in api.traits
    assert "collection" in api.resource_types
    
    # Check for the /organizations resource
    resource = api.resource("/organizations")
    assert resource.full_path == "/organizations"
    
    # Check for the GET method which should have traits applied (it won't currently)
    # The current implementation DOES NOT merge traits or resourceTypes.
    # This will demonstrate the missing functionality.

def test_nested_validation():
    """Test validation of deeply nested properties."""
    api = parse("tests/fixtures/raml10/complex_api.raml")
    
    valid_org = {
        "name": "Acme Corp",
        "address": {
            "street": "123 Main St",
            "city": "Techville",
            "coordinates": {
                "lat": 45.0,
                "lng": -90.0
            }
        },
        "employees": [
            {
                "id": 1,
                "fullName": "Alice Smith",
                "department": "Engineering",
                "metadata": {
                    "hireDate": "2023-01-01",
                    "tags": ["senior", "lead"]
                }
            }
        ]
    }

    # Test validation of POST body
    result = api.validator_for("/organizations", "POST").validate(
        body=valid_org,
        content_type="application/json"
    )
    
    # Since types like Address, Organization, and Employee are defined,
    # let's see if the validator actually handles them recursively.
    if not result.ok:
        print("Validation errors:", result.errors)
    
    assert result.ok

def test_traits_merged_successfully():
    """Demonstrate that traits and resource type methods are successfully applied."""
    api = parse("tests/fixtures/raml10/complex_api.raml")
    
    # Check for the /organizations resource
    resource = api.resource("/organizations")
    method = resource.methods['get']
    
    # The 'pageable' trait defines 'limit' and 'offset' query parameters.
    # Normalization merges these successfully.
    assert "limit" in method.query_parameters, "Trait 'limit' param successfully merged into method"
    assert "offset" in method.query_parameters, "Trait 'offset' param successfully merged into method"
    
    # Verify parameter characteristics were maintained
    assert method.query_parameters["limit"].type_ref == "integer"
    assert method.query_parameters["limit"].default == 20
