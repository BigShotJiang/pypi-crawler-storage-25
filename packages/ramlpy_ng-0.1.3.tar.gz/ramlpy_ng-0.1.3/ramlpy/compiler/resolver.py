"""Resolver for RAML traits and resource types."""

import re
import copy


def evaluate_template(data, params):
    """Recursively substitute <<parameter>> in a data structure.
    
    Args:
        data: The dict or list to process
        params: Dict of parameter names to values
    
    Returns:
        Processed data structure
    """
    if isinstance(data, str):
        # Substitute <<name>> with value from params
        def replace(match):
            name = match.group(1)
            # Handle RAML 1.0 reserved parameters if needed
            # For now, just direct parameter mapping
            return str(params.get(name, match.group(0)))
        
        return re.sub(r'<<(.+?)>>', replace, data)
    
    if isinstance(data, dict):
        return {
            evaluate_template(k, params): evaluate_template(v, params)
            for k, v in data.items()
        }
    
    if isinstance(data, list):
        return [evaluate_template(item, params) for item in data]
    
    return data


def deep_merge(target, source):
    """Recursively merge source into target.
    
    Source overrides target for scalars, but for dicts/lists we merge.
    However, in RAML, the specific (target) usually overrides the inherited (source).
    Wait, RAML spec says: "The properties of the trait are merged into the properties 
    of the method". If there is a collision, the method's property wins.
    """
    if not isinstance(source, dict) or not isinstance(target, dict):
        return source  # Source wins in a simple replacement
    
    for key, value in source.items():
        if key in target:
            if isinstance(target[key], dict) and isinstance(value, dict):
                deep_merge(target[key], value)
            elif isinstance(target[key], list) and isinstance(value, list):
                # For RAML, lists like queryParameters are often maps in our AST,
                # but in raw data they might be lists.
                target[key].extend([item for item in value if item not in target[key]])
            # else: target[key] wins, don't overwrite with source[key]
        else:
            target[key] = copy.deepcopy(value)
    
    return target


def resolve_traits(method_data, traits_registry, traits_to_apply, context_params=None):
    """Apply a list of traits to a method definition.
    
    Args:
        method_data: Raw method definition dict
        traits_registry: Dict of all traits defined in the API
        traits_to_apply: List of trait names or dicts (with params)
        context_params: Contextual parameters (methodName, etc.)
    
    Returns:
        Merged method definition dict
    """
    if not traits_to_apply:
        return method_data
    
    merged = copy.deepcopy(method_data)
    context_params = context_params or {}
    
    for trait_item in traits_to_apply:
        trait_name = None
        trait_params = context_params.copy()
        
        if isinstance(trait_item, str):
            trait_name = trait_item
        elif isinstance(trait_item, dict):
            # It's a dict like { traitName: { param: value } }
            trait_name = list(trait_item.keys())[0]
            trait_params.update(trait_item[trait_name])
        
        trait_def = traits_registry.get(trait_name)
        if not trait_def:
            continue
        
        # 1. Evaluate template in trait definition
        evaluated_trait = evaluate_template(trait_def, trait_params)
        
        # 2. Merge evaluated trait into method_data
        # Note: Method's own properties override trait properties.
        # So we merge trait into a copy, then re-apply method's original properties?
        # Actually, deep_merge(target, source) where target is method and source is trait
        # but target wins on collision.
        _merge_trait_into_method(merged, evaluated_trait)
        
    return merged


def _merge_trait_into_method(method, trait):
    """Merge trait properties into method, method wins on collision."""
    for key in ['queryParameters', 'headers', 'responses', 'body', 'description', 'is']:
        if key not in trait:
            continue
        
        if key not in method:
            method[key] = copy.deepcopy(trait[key])
            continue
            
        if key in ['queryParameters', 'headers', 'responses', 'body']:
            # These are dicts (after YAML load)
            trait_val = trait[key]
            method_val = method[key]
            if isinstance(trait_val, dict) and isinstance(method_val, dict):
                for k, v in trait_val.items():
                    if k not in method_val:
                        method_val[k] = copy.deepcopy(v)
                    elif isinstance(v, dict) and isinstance(method_val[k], dict):
                        # Nested merge for things like body: { app/json: { ... } }
                        _merge_trait_into_method({k: method_val[k]}, {k: v})
        elif key == 'is':
            # Merge list of traits
            trait_val = trait[key] if isinstance(trait[key], list) else [trait[key]]
            method_val = method[key] if isinstance(method[key], list) else [method[key]]
            for t in trait_val:
                if t not in method_val:
                    method_val.append(t)
            method[key] = method_val
        elif key == 'description' and not method.get(key):
            method[key] = trait[key]


def resolve_resource_type(resource_data, types_registry, type_to_apply, context_params=None):
    """Apply a resource type to a resource definition."""
    if not type_to_apply:
        return resource_data
    
    type_name = None
    type_params = context_params or {}
    
    if isinstance(type_to_apply, str):
        type_name = type_to_apply
    elif isinstance(type_to_apply, dict):
        type_name = list(type_to_apply.keys())[0]
        type_params.update(type_to_apply[type_name])
    
    type_def = types_registry.get(type_name)
    if not type_def:
        return resource_data
    
    evaluated_type = evaluate_template(type_def, type_params)
    
    merged = copy.deepcopy(resource_data)
    
    # Merge methods from type into resource
    for key, value in evaluated_type.items():
        if key.startswith('/'):
            continue # Nested resources not supported in resource types? (Spec says no)
        
        if key in ['get', 'post', 'put', 'delete', 'patch', 'options', 'head']:
            if key not in merged:
                merged[key] = copy.deepcopy(value)
            else:
                # Merge the method definition
                _merge_trait_into_method(merged[key], value)
        elif key not in merged:
            merged[key] = copy.deepcopy(value)
            
    return merged
