"""Normalize RAML 1.0 AST to shared model."""

from ramlpy.model.api import ApiSpec
from ramlpy.model.resource import ResourceSpec
from ramlpy.model.method import MethodSpec
from ramlpy.model.parameters import ParameterSpec
from ramlpy.model.bodies import BodySpec
from ramlpy.model.types import TypeSpec


from ramlpy.compiler.resolver import resolve_traits, resolve_resource_type


def normalize_raml10(ast):
    """Convert RAML 1.0 AST to normalized ApiSpec."""
    data = ast.data
    
    traits_registry = data.get('traits', {}) or {}
    resource_types_registry = data.get('resourceTypes', {}) or {}
    
    # We need to resolve types first so they're available for parameter normalization
    types = _normalize_types_10(data.get('types', {}))
    
    resources = []
    for resource_node in data.get('resources', []):
        resources.append(_normalize_resource(
            resource_node, 
            traits_registry, 
            resource_types_registry
        ))
    
    security_schemes = data.get('securitySchemes', {}) or {}
    
    return ApiSpec(
        title=data.get('title'),
        version=data.get('version'),
        base_uri=data.get('baseUri'),
        media_type=data.get('mediaType'),
        resources=resources,
        types=types,
        traits=traits_registry,
        resource_types=resource_types_registry,
        security_schemes=security_schemes,
    )


def _normalize_resource(node, traits_reg, rt_reg, parent_traits=None):
    """Normalize a ResourceNode to ResourceSpec."""
    # 1. Start with the raw node data as a dict for merging
    # We need to reconstruct a bit of dict context for the resolver
    resource_data = {
        'traits': node.traits or [],
        'type': node.resource_type,
    }
    # Add existing methods to the dict so the resolver can merge into them
    for m_node in node.methods:
        resource_data[m_node.method] = {
            'description': m_node.description,
            'is': m_node.traits or [],
            'responses': m_node.responses or {},
            'queryParameters': {p.name: p.extra for p in m_node.query_parameters},
            'headers': {p.name: p.extra for p in m_node.headers},
        }

    # 2. Resolve resource type if present
    if node.resource_type:
        resource_data = resolve_resource_type(
            resource_data, 
            rt_reg, 
            node.resource_type,
            context_params={'resourcePath': node.path}
        )

    # 3. Traits from the resource level
    current_traits = (parent_traits or []) + (resource_data.get('is', []) or [])
    
    # 4. Normalize methods (including ones merged from resource type)
    methods = {}
    
    # We need to combine methods from the node and methods merged into resource_data
    method_names = set(m.method for m in node.methods)
    for k in resource_data:
        if k in ['get', 'post', 'put', 'delete', 'patch', 'options', 'head']:
            method_names.add(k)
            
    for m_name in method_names:
        m_info = resource_data[m_name]
        m_node = next((m for m in node.methods if m.method == m_name), None)
        
        from ramlpy.parser.ast_nodes import MethodNode, ParameterNode

        def dict_to_nodes(d):
            nodes = []
            for name, spec in d.items():
                if isinstance(spec, str):
                    nodes.append(ParameterNode(name, type_name=spec))
                else:
                    nodes.append(ParameterNode(name, type_name=spec.get('type') if isinstance(spec, dict) else None, **spec))
            return nodes

        if not m_node:
            m_node = MethodNode(
                method=m_name,
                description=m_info.get('description'),
                traits=m_info.get('is', []),
                responses=m_info.get('responses', {}),
                query_parameters=dict_to_nodes(m_info.get('queryParameters', {})),
                headers=dict_to_nodes(m_info.get('headers', {})),
            )
        else:
            # Merge traits
            for t in m_info.get('is', []):
                if t not in m_node.traits:
                    m_node.traits.append(t)
            
            # Merge query parameters
            existing_qp_names = [p.name for p in m_node.query_parameters]
            for name, spec in m_info.get('queryParameters', {}).items():
                if name not in existing_qp_names:
                    if isinstance(spec, str):
                        m_node.query_parameters.append(ParameterNode(name, type_name=spec))
                    else:
                        m_node.query_parameters.append(ParameterNode(name, type_name=spec.get('type') if isinstance(spec, dict) else None, **spec))
            
            # Merge headers
            existing_h_names = [p.name for p in m_node.headers]
            for name, spec in m_info.get('headers', {}).items():
                if name not in existing_h_names:
                    if isinstance(spec, str):
                        m_node.headers.append(ParameterNode(name, type_name=spec))
                    else:
                        m_node.headers.append(ParameterNode(name, type_name=spec.get('type') if isinstance(spec, dict) else None, **spec))
            
            # Merge responses
            for status, resp in m_info.get('responses', {}).items():
                if status not in m_node.responses:
                    m_node.responses[status] = resp
        
        spec = _normalize_method(m_node, traits_reg, current_traits)
        methods[spec.method] = spec
    
    nested = []
    for nested_node in node.nested_resources:
        nested.append(_normalize_resource(nested_node, traits_reg, rt_reg, current_traits))
    
    uri_params = {}
    for param_node in node.uri_parameters:
        spec = _normalize_parameter(param_node, location='path')
        uri_params[spec.name] = spec
    
    return ResourceSpec(
        full_path=node.path,
        uri_parameters=uri_params,
        methods=methods,
        nested_resources=nested,
        annotations=node.annotations,
    )


def _normalize_method(node, traits_reg, resource_traits):
    """Normalize a MethodNode to MethodSpec, applying traits."""
    # Combine traits from resource and method levels
    all_traits = resource_traits + (node.traits or [])
    
    # Start with base attributes from node
    headers = {}
    for param_node in node.headers:
        spec = _normalize_parameter(param_node, location='header')
        headers[spec.name] = spec
    
    query_params = {}
    for param_node in node.query_parameters:
        spec = _normalize_parameter(param_node, location='query')
        query_params[spec.name] = spec
        
    responses = copy.deepcopy(node.responses or {})
    
    bodies = {}
    if node.body:
        body_list = node.body if isinstance(node.body, list) else [node.body]
        for body_node in body_list:
            spec = BodySpec(
                media_type=body_node.media_type,
                type_ref=body_node.type_ref,
                schema_ref=body_node.schema,
                example=body_node.example,
                examples=body_node.examples,
            )
            bodies[spec.media_type] = spec

    # Apply traits via our resolver
    # Since resolver works on dicts, we'll create a temporary dict and merge back
    if all_traits:
        temp_method_data = {
            'headers': {n: {} for n in headers}, # Placeholder for existing
            'queryParameters': {n: {} for n in query_params},
            'responses': responses,
            'body': {mt: {} for mt in bodies}
        }
        
        resolved = resolve_traits(temp_method_data, traits_reg, all_traits, 
                                  context_params={'methodName': node.method})
        
        # Merge resolved traits back into our specs
        # 1. Update query parameters
        for name, param_def in resolved.get('queryParameters', {}).items():
            if name not in query_params:
                # Need to convert raw dict param_def to ParameterSpec
                query_params[name] = _normalize_raw_parameter(name, param_def, 'query')
        
        # 2. Update headers
        for name, param_def in resolved.get('headers', {}).items():
            if name not in headers:
                headers[name] = _normalize_raw_parameter(name, param_def, 'header')
                
        # 3. Update responses
        for status, resp_def in resolved.get('responses', {}).items():
            if status not in responses:
                responses[status] = resp_def
        
        # 4. Update bodies
        for mt, b_def in resolved.get('body', {}).items():
            if mt not in bodies:
                bodies[mt] = BodySpec(
                    media_type=mt,
                    type_ref=b_def.get('type') if isinstance(b_def, dict) else b_def,
                    schema_ref=b_def.get('schema') if isinstance(b_def, dict) else None,
                )

    return MethodSpec(
        method=node.method,
        headers=headers,
        query_parameters=query_params,
        bodies=bodies,
        responses=responses,
        secured_by=node.secured_by,
        description=node.description,
        annotations=node.annotations,
    )


def _normalize_raw_parameter(name, spec, location):
    """Convert a raw dict parameter definition to ParameterSpec."""
    if not isinstance(spec, dict):
        return ParameterSpec(name=name, location=location, type_ref=str(spec))
    
    return ParameterSpec(
        name=name,
        location=location,
        required=spec.get('required', False),
        type_ref=spec.get('type', 'string'),
        enum=spec.get('enum'),
        default=spec.get('default'),
        pattern=spec.get('pattern'),
        minimum=spec.get('minimum'),
        maximum=spec.get('maximum'),
        annotations=spec.get('annotations', {}),
    )


import copy
from ramlpy.model.parameters import ParameterSpec


def _normalize_parameter(node, location='query'):
    """Normalize a ParameterNode to ParameterSpec."""
    # Clean up parameter name (remove trailing ?)
    name = node.name.rstrip('?')
    return ParameterSpec(
        name=name,
        location=location,
        required=node.required if node.required is not None else False,
        type_ref=node.type_name or 'string',
        enum=node.enum,
        default=node.default,
        repeat=node.repeat if node.repeat is not None else False,
        pattern=node.pattern,
        minimum=node.minimum,
        maximum=node.maximum,
        min_length=node.min_length,
        max_length=node.max_length,
        annotations=node.annotations,
    )


def _normalize_types_10(types_data):
    """Normalize RAML 1.0 types to TypeSpec dict."""
    types = {}
    if not types_data:
        return types
    for name, type_def in types_data.items():
        if isinstance(type_def, dict):
            types[name] = TypeSpec(
                name=name,
                base_type=type_def.get('type'),
                properties=type_def.get('properties', {}),
                enum=type_def.get('enum', []),
                inline_definition=type_def,
            )
        else:
            types[name] = TypeSpec(
                name=name,
                base_type=type_def,
            )
    return types
