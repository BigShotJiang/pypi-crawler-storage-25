"""Модуль для вывода ASCII-арт персонажей."""

CHARACTERS = {
    "tux": r"""
       .--.
      |o_o |
      |:_/ |
     //   \ \
    (|     | )
   /'\_   _/`\
   \___)=(___/
    """,
    "dog": r"""
     / \__
    (    @\___
    /         O
   /   (_____/
  /_____/   U
    """,
    "bird": r"""
      .-.
     (o o)
     | O \
      \   \
       `~~~'
    """,
    "cow": r"""
     ^__^
     (oo)\_______
     (__)\       )\/\
         ||----w |
         ||     ||
    """,
    "cat": r"""
     /\_/\
    ( o.o )
     > ^ <
    """,
    "parrot": r"""
     __
    //\\
    V  \  @
     \__/ \   ,
      \  ,  \ /
       \__/  \/
    """,
    "bear": r"""
      .--.
     / .-. \
    | |   | |
    | |   | |
    | |   | |
     \ '-' /
      '---'
    """,
    "dolphin": r"""
    __
  _|  |_
 |      |
 |_    _|
   |__|
    """,
}


def GetChaster():
    """Возвращает список всех доступных персонажей."""
    return list(CHARACTERS.keys())


def PrintChaster(name: str):
    """Печатает ASCII-арт выбранного персонажа.

    Args:
        name: Имя персонажа (например, 'tux').
    """
    name = name.lower()
    art = CHARACTERS.get(name)
    if art is None:
        print(f"[extio] Персонаж '{name}' не найден. Доступные: {GetChaster()}")
        return
    print(art)
