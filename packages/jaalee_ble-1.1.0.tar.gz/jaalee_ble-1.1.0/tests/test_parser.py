"""Tests for the Jaalee BLE parser."""

from __future__ import annotations

import json
import struct
from pathlib import Path
from typing import Any

import pytest
from bleak.backends.device import BLEDevice
from bluetooth_data_tools import monotonic_time_coarse
from habluetooth import BluetoothServiceInfoBleak

from jaalee_ble import JaaleeBluetoothDeviceData, SensorModel

_SAMPLE_PACKAGES_PATH = Path(__file__).parent / "test_ble_advertisements.json"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

DEVICE_ADDRESS = "AA:BB:CC:DD:EE:FF"
DEVICE_NAME = "Jaalee_EEFF"

# iBeacon format constants
# Jaalee marker sits at byte offset 16 of the Apple manufacturer payload.
_IBEACON_MARKER = b"\xf5\x25"

# Compact format: MAC stored reversed in bytes [1:7] of the payload.
_MAC_REVERSED = bytes([0xFF, 0xEE, 0xDD, 0xCC, 0xBB, 0xAA])

# Precomputed raw values for temp=25.0°C, humi=60.0%, batt=85 — SHT20 formula
#   raw_temp = 26796  →  round(175.72 * 26796 / 65536 - 46.85, 2) = 25.0
#   raw_humi = 34601  →  round(125 * 34601 / 65536 - 6, 2)         = 60.0
RAW_TEMP_25 = 26796
RAW_HUMI_60 = 34601
BATT_85 = 85

# Precomputed raw values for temp=20.0°C, humi=50.0%, batt=72 — SHT20 formula
#   raw_temp = 24931  →  round(175.72 * 24931 / 65536 - 46.85, 2) = 20.0
#   raw_humi = 29358  →  round(125 * 29358 / 65536 - 6, 2)         = 50.0
RAW_TEMP_20 = 24931
RAW_HUMI_50 = 29358
BATT_72 = 72


def make_service_info(
    address: str = DEVICE_ADDRESS,
    name: str = DEVICE_NAME,
    manufacturer_data: dict[int, bytes] | None = None,
    rssi: int = -60,
) -> BluetoothServiceInfoBleak:
    """Create a BluetoothServiceInfoBleak instance for testing."""
    return BluetoothServiceInfoBleak(
        name=name,
        address=address,
        rssi=rssi,
        service_uuids=[],
        service_data={},
        manufacturer_data=manufacturer_data or {},
        device=BLEDevice(address=address, name=name, details={}),
        advertisement=None,
        connectable=True,
        time=monotonic_time_coarse(),
        source="local",
        tx_power=0,
    )


def make_ibeacon_payload(
    raw_temp: int = RAW_TEMP_25,
    raw_humi: int = RAW_HUMI_60,
    batt: int = BATT_85,
    tx_power: int = 0,
) -> bytes:
    """
    Build a 24-byte Apple manufacturer payload in Jaalee iBeacon format.

    Layout:
      [0:16]  - iBeacon preamble / proximity UUID prefix (arbitrary)
      [16:18] - Jaalee UUID marker (0xF5, 0x25)
      [18:20] - raw temperature (big-endian uint16)
      [20:22] - raw humidity   (big-endian uint16)
      [22]    - Tx Power (signed int8, dBm)
      [23]    - battery percent
    """
    prefix = b"\x02\x15" + b"\x00" * 14  # 16 bytes: iBeacon type+length + UUID prefix
    sensor = struct.pack(">HHbB", raw_temp, raw_humi, tx_power, batt)
    return prefix + _IBEACON_MARKER + sensor  # 16 + 2 + 6 = 24 bytes


def make_compact_payload(
    mac_reversed: bytes = _MAC_REVERSED,
    raw_temp: int = RAW_TEMP_20,
    raw_humi: int = RAW_HUMI_50,
    batt: int = BATT_72,
    extra: bytes = b"",
) -> bytes:
    """
    Build an 11 or 12-byte compact manufacturer payload.

    Layout:
      [0]    - battery percent
      [1:7]  - device MAC address stored in reverse byte order
      [7:11] - raw temperature/humidity for the 11-byte variant
      [7]    - optional extra byte for the 12-byte variant
      [8:12] - raw temperature/humidity for the 12-byte variant
    """
    sensor = struct.pack(">HH", raw_temp, raw_humi)
    return bytes([batt]) + mac_reversed + extra + sensor


# ---------------------------------------------------------------------------
# Tests - iBeacon format
# ---------------------------------------------------------------------------


def test_ibeacon_format_parses_temperature_humidity_battery() -> None:
    """IBeacon advertisement yields correct temp, humi, and battery."""
    service_info = make_service_info(manufacturer_data={0x004C: make_ibeacon_payload()})

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert result.title == "Jaalee EEFF"
    assert result.devices[None].name == "Jaalee EEFF"
    assert result.devices[None].manufacturer == "Jaalee"
    assert result.devices[None].model == "JHT"

    values = {k.key: v.native_value for k, v in result.entity_values.items()}
    assert values["temperature"] == 25.0
    assert values["humidity"] == 60.0
    assert values["battery"] == 85


def test_ibeacon_format_parses_tx_power() -> None:
    """IBeacon advertisement yields correct Tx Power from byte 22."""
    service_info = make_service_info(
        manufacturer_data={0x004C: make_ibeacon_payload(tx_power=-53)}
    )

    result = JaaleeBluetoothDeviceData().update(service_info)

    values = {k.key: v.native_value for k, v in result.entity_values.items()}
    assert values["tx_power"] == -53


def test_ibeacon_format_wrong_marker_ignored() -> None:
    """Apple manufacturer data with the wrong UUID marker is not parsed."""
    payload = bytearray(make_ibeacon_payload())
    payload[16] = 0x00  # corrupt the Jaalee marker
    service_info = make_service_info(manufacturer_data={0x004C: bytes(payload)})

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert not result.entity_values


def test_ibeacon_format_wrong_payload_length_ignored() -> None:
    """Apple manufacturer data of unexpected length is not parsed."""
    service_info = make_service_info(
        manufacturer_data={0x004C: make_ibeacon_payload()[:-1]}  # 23 bytes, not 24
    )

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert not result.entity_values


# ---------------------------------------------------------------------------
# Tests - compact format
# ---------------------------------------------------------------------------


def test_compact_format_11_bytes_parses_correctly() -> None:
    """11-byte compact advertisement yields correct temp, humi, and battery."""
    service_info = make_service_info(manufacturer_data={0x05D8: make_compact_payload()})

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert result.title == "Jaalee EEFF"
    assert result.devices[None].manufacturer == "Jaalee"
    assert result.devices[None].model == "JHT"

    values = {k.key: v.native_value for k, v in result.entity_values.items()}
    assert values["temperature"] == 20.0
    assert values["humidity"] == 50.0
    assert values["battery"] == 72


def test_compact_format_12_bytes_parses_correctly() -> None:
    """12-byte compact advertisement (with trailing byte) parses correctly."""
    service_info = make_service_info(
        manufacturer_data={0x05D8: make_compact_payload(extra=b"\x00")}
    )

    result = JaaleeBluetoothDeviceData().update(service_info)

    values = {k.key: v.native_value for k, v in result.entity_values.items()}
    assert values["temperature"] == 20.0
    assert values["humidity"] == 50.0
    assert values["battery"] == 72


def test_compact_format_mac_mismatch_returns_no_data() -> None:
    """Compact advertisement whose embedded MAC mismatches the device is ignored."""
    wrong_mac_reversed = bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66])
    service_info = make_service_info(
        manufacturer_data={
            0x05D8: make_compact_payload(mac_reversed=wrong_mac_reversed)
        }
    )

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert not result.entity_values


# ---------------------------------------------------------------------------
# Tests - edge cases
# ---------------------------------------------------------------------------


def test_no_manufacturer_data_returns_no_data() -> None:
    """Advertisement with no manufacturer data produces no sensor values."""
    service_info = make_service_info(manufacturer_data={})

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert not result.entity_values


def test_unrecognised_manufacturer_data_returns_no_data() -> None:
    """Manufacturer data that matches no known format is silently ignored."""
    service_info = make_service_info(
        manufacturer_data={0x1234: bytes(8)}  # 8 bytes - not 11, 12, or 24
    )

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert not result.entity_values


# ---------------------------------------------------------------------------
# Tests - test_ble_advertisements.json
# ---------------------------------------------------------------------------

_SAMPLES = json.loads(_SAMPLE_PACKAGES_PATH.read_text())


def _service_info_from_sample(sample: Any) -> BluetoothServiceInfoBleak:
    """Convert a test_ble_advertisements.json entry to a BluetoothServiceInfoBleak."""
    address = sample["address"]
    manufacturer_data = {
        int(k): bytes.fromhex(v) for k, v in sample["manufacturer_data"].items()
    }
    return BluetoothServiceInfoBleak(
        name=sample["name"],
        address=address,
        rssi=sample["rssi"],
        service_uuids=sample.get("service_uuids", []),
        service_data={},
        manufacturer_data=manufacturer_data,
        device=BLEDevice(address=address, name=sample["name"], details={}),
        advertisement=None,
        connectable=sample.get("connectable", True),
        time=monotonic_time_coarse(),
        source=sample.get("source", "local"),
        tx_power=sample.get("tx_power", 0),
    )


@pytest.mark.parametrize(
    "sample",
    _SAMPLES,
    ids=[f"{s['address']}[{i}]" for i, s in enumerate(_SAMPLES)],
)
def test_sample_packages_parse_sensor_values(sample: Any) -> None:
    """Each entry in test_ble_advertisements.json decodes to valid sensor readings."""
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData().update(service_info)

    assert result.entity_values, "Expected sensor values but got none"
    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    print(
        f"\n  {sample['address']}  rssi={sample['rssi']}dBm"
        f"  temp={values.get('temperature')}°C"
        f"  humi={values.get('humidity')}%"
        f"  batt={values.get('battery')}%"
    )

    assert "temperature" in values
    assert "humidity" in values
    assert "battery" in values
    assert -40.0 <= values["temperature"] <= 85.0, (
        f"Temperature out of range: {values['temperature']}"
    )
    assert 0.0 <= values["humidity"] <= 100.0, (
        f"Humidity out of range: {values['humidity']}"
    )
    assert 0 <= values["battery"] <= 100, f"Battery out of range: {values['battery']}"


def test_known_ibeacon_sample_decodes_expected_values() -> None:
    """Known captured iBeacon payload decodes to stable expected values with SHT20."""
    sample = _SAMPLES[0]
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData().update(service_info)

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == 24.46
    assert values["humidity"] == 62.94
    assert values["battery"] == 100
    assert values["tx_power"] == -53


def test_known_ibeacon_sample_decodes_sht31_values() -> None:
    """Same payload decoded with SHT31 formula produces the legacy expected values."""
    sample = _SAMPLES[0]
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData(sensor_model=SensorModel.SHT31).update(
        service_info
    )

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == 26.02
    assert values["humidity"] == 55.15
    assert values["battery"] == 100
    assert values["tx_power"] == -53


def test_user_sample_ibeacon_decodes_reported_values() -> None:
    """User-provided iBeacon sample (SHT20 sensor) decodes correctly."""
    sample = {
        "name": "FE:0E:A2:CC:C4:1F",
        "address": "FE:0E:A2:CC:C4:1F",
        "rssi": -83,
        "manufacturer_data": {"76": "0215ebefd08370a247c89837e7b5634df52557183852cb64"},
        "service_uuids": ["0000f525-0000-1000-8000-00805f9b34fb"],
        "source": "C0:49:EF:D5:37:9A",
        "connectable": True,
        "tx_power": 0,
    }
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData().update(service_info)

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == 12.93
    assert values["humidity"] == 21.5
    assert values["battery"] == 100
    assert values["tx_power"] == -53


def test_user_sample_ibeacon_decodes_sht31_values() -> None:
    """Same payload decoded with SHT31 formula matches reported legacy values."""
    sample = {
        "name": "FE:0E:A2:CC:C4:1F",
        "address": "FE:0E:A2:CC:C4:1F",
        "rssi": -83,
        "manufacturer_data": {"76": "0215ebefd08370a247c89837e7b5634df52557183852cb64"},
        "service_uuids": ["0000f525-0000-1000-8000-00805f9b34fb"],
        "source": "C0:49:EF:D5:37:9A",
        "connectable": True,
        "tx_power": 0,
    }
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData(sensor_model=SensorModel.SHT31).update(
        service_info
    )

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == pytest.approx(14.54, abs=0.05)
    assert values["humidity"] == pytest.approx(22.0, abs=0.05)
    assert values["battery"] == 100
    assert values["tx_power"] == -53


def test_vendor_doc_sample_decodes_as_documented() -> None:
    """Official doc sample (SHT20 sensor) decodes to the correct SHT20 values."""
    sample = {
        "name": "C13271397295",
        "address": "C1:32:71:39:72:95",
        "rssi": -63,
        "manufacturer_data": {"76": "0215ebefd08370a247c89837e7b5634df52565823d1acc64"},
        "service_uuids": [],
        "source": "local",
        "connectable": True,
        "tx_power": 0,
    }
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData().update(service_info)

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == 22.83
    assert values["humidity"] == 23.83
    assert values["battery"] == 100
    assert values["tx_power"] == -52


def test_vendor_doc_sample_decodes_sht31_values() -> None:
    """Same payload decoded with SHT31 formula matches the vendor-documented values."""
    sample = {
        "name": "C13271397295",
        "address": "C1:32:71:39:72:95",
        "rssi": -63,
        "manufacturer_data": {"76": "0215ebefd08370a247c89837e7b5634df52565823d1acc64"},
        "service_uuids": [],
        "source": "local",
        "connectable": True,
        "tx_power": 0,
    }
    service_info = _service_info_from_sample(sample)

    result = JaaleeBluetoothDeviceData(sensor_model=SensorModel.SHT31).update(
        service_info
    )

    values = {k.key: v.native_value for k, v in result.entity_values.items()}

    assert values["temperature"] == pytest.approx(24.39, abs=0.01)
    assert values["humidity"] == pytest.approx(23.87, abs=0.01)
    assert values["battery"] == 100
    assert values["tx_power"] == -52
