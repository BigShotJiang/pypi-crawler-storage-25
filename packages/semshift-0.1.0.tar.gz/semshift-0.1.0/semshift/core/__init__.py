"""Core semantic diff engine."""

