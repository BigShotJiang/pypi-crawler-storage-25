# Jinja2Static

Jinja2Static is a minimal, developer-friendly toolchain that builds static sites from Jinja2 templates and simple project configurations. It provides three CLI subcommands to scaffold a project, run a development server with live rebuilds, and produce a static output directory for deployment.

## Key features

- Scaffolds a small project layout to get started quickly.
- Runs a local development server that watches files and rebuilds on change.
- Builds a static site by rendering Jinja2 templates and copying asset files.

## Install

Install from PyPI:

```bash
pip install jinja2static
```
## Typical workflow

1. Create a project scaffold:

```bash
jinja2static init mysite
cd mysite
```

2. Work locally with live reload:

```bash
jinja2static dev
```

3. Produce a production-ready static site:

```bash
jinja2static build
```

## Project configuration

`jinja2static` reads project configuration from the provided path or the current working directory. You can pass either a directory or a `pyproject.toml` file as `project_file_path` to target a specific project. See the example `pyproject.toml` in the `init` scaffold for configurable options (templates directory, asset locations, and output `dist` directory).

## Quick CLI Guide

All subcommands accept an optional `project_file_path` argument (a directory or a `pyproject.toml` file). They also accept `-v/--verbose` to enable more logging.

- `init` — initialize a new jinja2static project scaffold.
	- Usage: `jinja2static init [project_file_path]`
	- Example: `jinja2static init mysite` creates a new `mysite` scaffold with `templates`, `assets`, and example data.

- `dev` — run a development server that watches source files and rebuilds on change.
	- Usage: `jinja2static dev [project_file_path] [-p PORT]`
	- Options: `-p/--port` (default `8000`) to choose the server port.
	- Example: `jinja2static dev -p 8080` starts the server on port 8080 and serves the generated site while watching for changes.

- `build` — render your project to a static output directory for deployment.
	- Usage: `jinja2static build [project_file_path]`
	- Example: `jinja2static build` compiles templates, copies assets, and writes the static site to the configured `dist` folder.

## Logging & verbosity

Add `-v` or `--verbose` to any command to enable more detailed logging useful for debugging builds and the development server.

## Contributing

Contributions are welcome. See the source under the `src/jinja2static` package for implementation details and tests in `tests/`.

---

Happy templating! If you want examples tailored to your project layout, open an issue or ask for help.
