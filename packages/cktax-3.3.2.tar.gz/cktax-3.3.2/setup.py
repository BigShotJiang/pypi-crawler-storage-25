from setuptools import setup, find_packages

setup(
    name="cktax",
    version="3.3.2",
    author="shiroko",
    description="全局PyPI工具 | 密钥管理 + 编号时间戳备份 + 打包 + 一键上传",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "cktax = cktax.cli:main"
        ]
    },
    install_requires=[
        "build",
        "twine"
    ],
    python_requires=">=3.6",
)
