import base64

def cfu():
    encoded = "CnByaW50KCflmI7ovr7lmI7ovr4s5oGt5Zac5L2g5Y+R546w5LqG5LiA5Liq5b2p6JuLJykKcHJpbnQoJ+S9oOWPr+S7peivleS4gOS4i+i/meS4qnRleHRfZGlzY29sb3JhdGlvbuaooeWdl+WPr+S7peWunueOsOaWh+acrOWPmOiJsicpCnByaW50KCfkvaDkuZ/lj6/ku6Xor5XkuIDkuItDaGluZXNlX0Vycm9y5Lit5paH5oql6ZSZJykKcHJpbnQoJ+WGjee7meS9oOS4gOS4qumHjeimgeeahOS4nOilvzpwYXNzICjmmoLml7blhYjnqbrnnYApJykK"
    decoded = base64.b64decode(encoded).decode("utf-8")
    exec(decoded)