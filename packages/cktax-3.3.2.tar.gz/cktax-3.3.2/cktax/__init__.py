from .egg import cfu

__version__ = "3.3.2"