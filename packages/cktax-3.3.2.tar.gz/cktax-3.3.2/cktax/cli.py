#!/usr/bin/env python3

import os
import sys
import zipfile
import random
import string
import hashlib
import shutil
import time
import subprocess
import glob
import json
import urllib.request
import urllib.error
import platform
from pathlib import Path
from datetime import datetime, timedelta


INSTALL_CFG = "install_path.ini"
CURRENT_KEY_CFG = "current_key.ini"
BACKUP_SEQ_CFG = "backup_seq.ini"



def get_key_hint(key):
    if len(key) > 12:
        return key[:6] + "..." + key[-6:]
    return key


def get_global_cktax_path():
    user_conf = os.path.expanduser("~/.cktax_install.ini")

    if not os.path.exists(user_conf):
        print("===== 首次使用 cktax 请设置安装存储目录 =====")
        install_path = input("请输入安装地址: ").strip()
        install_path = os.path.expanduser(install_path)
        install_path = os.path.abspath(install_path)
        os.makedirs(install_path, exist_ok=True)

        cktax_dir = os.path.join(install_path, ".cktax")
        os.makedirs(cktax_dir, exist_ok=True)

        with open(user_conf, "w", encoding="utf-8") as f:
            f.write(install_path)

        cfg_path = os.path.join(cktax_dir, INSTALL_CFG)
        with open(cfg_path, "w", encoding="utf-8") as f:
            f.write(install_path)

        key_cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)
        with open(key_cfg, "w", encoding="utf-8") as f:
            f.write("0")

        seq_path = os.path.join(cktax_dir, BACKUP_SEQ_CFG)
        with open(seq_path, "w", encoding="utf-8") as f:
            f.write("1")
    else:
        with open(user_conf, "r", encoding="utf-8") as f:
            install_path = f.read().strip()
        cktax_dir = os.path.join(install_path, ".cktax")
        os.makedirs(cktax_dir, exist_ok=True)

    return cktax_dir


def _get_config_path():
    cktax_dir = get_global_cktax_path()
    return os.path.join(cktax_dir, "cktax_config.json")


def _load_config():
    config_file = _get_config_path()
    default_config = {"auto_bak": False, "bak_path": ""}
    if not os.path.exists(config_file):
        return default_config
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            config = json.load(f)
            if "bak_path" not in config:
                config["bak_path"] = ""
            return config
    except:
        return default_config


def _save_config(config):
    config_file = _get_config_path()
    with open(config_file, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def set_bak(mode):
    config = _load_config()
    config["auto_bak"] = mode == "yes"
    _save_config(config)
    status = "开启" if config["auto_bak"] else "关闭"
    print(f"[cktax] 自动备份已{status}")


def set_bak_path(path):
    if not path:
        config = _load_config()
        current = config.get("bak_path", "") or os.getcwd()
        print(f"[cktax] 当前备份路径: {current}")
        return
    path = os.path.expanduser(path)
    path = os.path.abspath(path)
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)
    config = _load_config()
    config["bak_path"] = path
    _save_config(config)
    print(f"[cktax] 备份路径已设置为: {path}")


def path_set():
    user_conf = os.path.expanduser("~/.cktax_install.ini")
    if not os.path.exists(user_conf):
        print("[cktax]  尚未初始化，请先运行任意 cktax 命令完成首次配置")
        return

    with open(user_conf, "r", encoding="utf-8") as f:
        old_install = f.read().strip()
    old_cktax = os.path.join(old_install, ".cktax")

    print("[cktax] 请输入新的全局存储安装地址:")
    new_install = input().strip()
    new_install = os.path.expanduser(new_install)
    new_install = os.path.abspath(new_install)
    os.makedirs(new_install, exist_ok=True)
    new_cktax = os.path.join(new_install, ".cktax")

    if os.path.exists(old_cktax):
        shutil.copytree(old_cktax, new_cktax, dirs_exist_ok=True)

    with open(user_conf, "w", encoding="utf-8") as f:
        f.write(new_install)

    inner_cfg = os.path.join(new_cktax, INSTALL_CFG)
    with open(inner_cfg, "w", encoding="utf-8") as f:
        f.write(new_install)

    print(f"[cktax]  已成功更换全局地址")
    print(f"旧地址: {old_install}")
    print(f"新地址: {new_install}")


def get_backup_seq():
    cktax_dir = get_global_cktax_path()
    seq_file = os.path.join(cktax_dir, BACKUP_SEQ_CFG)

    if not os.path.exists(seq_file):
        seq = 1
    else:
        with open(seq_file, "r", encoding="utf-8") as f:
            seq = int(f.read().strip() or 1)

    with open(seq_file, "w", encoding="utf-8") as f:
        f.write(str(seq + 1))

    return seq


def get_key_list():
    cktax_dir = get_global_cktax_path()
    keys = []
    for f in os.listdir(cktax_dir):
        if f.startswith("key_bak_") and os.path.isfile(os.path.join(cktax_dir, f)):
            try:
                num = int(f.replace("key_bak_", ""))
                keys.append(num)
            except:
                pass
    return sorted(keys)


def key_add():
    cktax_dir = get_global_cktax_path()
    print("[cktax] 请输入新的 PyPI Token/密钥：")
    new_key = input().strip()
    if not new_key:
        print("[cktax]  密钥不能为空")
        return

    nums = get_key_list()
    new_num = max(nums) + 1 if nums else 1
    key_path = os.path.join(cktax_dir, f"key_bak_{new_num}")

    with open(key_path, "w", encoding="utf-8") as f:
        f.write(new_key)

    hint = get_key_hint(new_key)
    print(f"[cktax]  密钥已保存为编号 {new_num}，片段：{hint}")


def key_set(num):
    cktax_dir = get_global_cktax_path()
    key_path = os.path.join(cktax_dir, f"key_bak_{num}")

    if not os.path.exists(key_path):
        print(f"[cktax]  不存在编号 {num} 的密钥")
        return

    cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)
    with open(cfg, "w", encoding="utf-8") as f:
        f.write(str(num))

    with open(key_path, "r", encoding="utf-8") as f:
        key = f.read().strip()
    hint = get_key_hint(key)
    print(f"[cktax]  已切换到密钥编号 {num}，片段：{hint}")


def get_current_key():
    cktax_dir = get_global_cktax_path()
    cfg = os.path.join(cktax_dir, CURRENT_KEY_CFG)

    with open(cfg, "r", encoding="utf-8") as f:
        curr_num = f.read().strip()

    try:
        curr_num = int(curr_num)
    except:
        return None

    key_path = os.path.join(cktax_dir, f"key_bak_{curr_num}")
    if not os.path.exists(key_path):
        return None

    with open(key_path, "r", encoding="utf-8") as f:
        return f.read().strip()


def bak(save_dir=None):
    print("[cktax] 正在备份当前目录...")

    if save_dir is None:
        config = _load_config()
        save_dir = config.get("bak_path", "")
    if not save_dir:
        save_dir = os.getcwd()
    else:
        save_dir = os.path.expanduser(save_dir)
        save_dir = os.path.abspath(save_dir)
        os.makedirs(save_dir, exist_ok=True)

    seq_num = get_backup_seq()
    time_str = time.strftime("%Y%m%d_%H%M%S")
    rand_part = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    ts = str(int(time.time()))
    hash_part = hashlib.md5(ts.encode()).hexdigest()[:8]

    zip_filename = f"backup_{seq_num}_{time_str}_{rand_part}_{hash_part}.zip"
    zip_filepath = os.path.join(save_dir, zip_filename)

    skip_dirs = {"__pycache__", "dist", "build", ".egg-info", ".git", ".vscode"}

    with zipfile.ZipFile(zip_filepath, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk("."):
            if any(s in root for s in skip_dirs):
                continue
            for file in files:
                filepath = os.path.join(root, file)
                zf.write(filepath)

    print(f"[cktax]  备份完成 > 编号:{seq_num} 文件:{zip_filepath}")


def back():
    if os.path.exists("dist") and os.listdir("dist"):
        print("[cktax]  检测到已有打包文件:")
        for f in os.listdir("dist"):
            print(f"    {f}")
        choice = input("是否重新打包？(y/N): ").strip().lower()
        if choice != 'y':
            print("[cktax]  跳过打包")
            return
        shutil.rmtree("dist")
    print("[cktax] 开始打包项目...")
    subprocess.run([sys.executable, "-m", "build"], check=False)
    print("[cktax]  打包完成")


def back_up():
    if not os.path.exists("dist") or not os.listdir("dist"):
        print("[cktax]  未检测到 dist 打包文件，请先执行打包")
        return

    key = get_current_key()
    dist_files = glob.glob("dist/*")
    if not dist_files:
        print("[cktax]  未找到打包文件 (*.tar.gz, *.whl)")
        return

    if not key:
        print("[cktax]  未配置密钥，将手动输入")
        cmd = [sys.executable, "-m", "twine", "upload"] + dist_files
        process = subprocess.run(cmd, capture_output=True, text=True)
    else:
        hint = get_key_hint(key)
        print(f"[cktax]  使用全局密钥自动上传，当前密钥片段：{hint}")
        env = os.environ.copy()
        env["TWINE_USERNAME"] = "__token__"
        env["TWINE_PASSWORD"] = key
        cmd = [sys.executable, "-m", "twine", "upload"] + dist_files
        process = subprocess.run(cmd, env=env, capture_output=True, text=True)

    if process.returncode == 0:
        print("[cktax] ✅ 上传完成")
    else:
        print(f"[cktax] ❌ 上传失败，退出码: {process.returncode}")
        if process.stderr:
            print(f"错误详情:\n{process.stderr}")


def git_push_to_existing():
    print("\n[cktax] 正在推送到 GitHub...")
    branch = _get_current_branch()
    if not branch:
        branch = input("分支名（默认 main）: ").strip()
        branch = branch or "main"

    try:
        status = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
        if status.stdout.strip():
            subprocess.run(["git", "add", "."], check=True)
            commit_msg = input("提交信息（回车 = Update from cktax）: ").strip()
            if not commit_msg:
                commit_msg = "Update from cktax"
            subprocess.run(["git", "commit", "-m", commit_msg], check=True)
        else:
            print("[cktax]  没有需要提交的变更")

        subprocess.run(["git", "push", "origin", branch], check=True)
        print("[cktax]  推送成功")
    except subprocess.CalledProcessError as e:
        print(f"[cktax]  推送失败: {e}")


def git_add_remote_and_push():
    remote_file = _get_git_remote_file()
    with open(remote_file, "r", encoding="utf-8") as f:
        remote_url = f.read().strip()

    token_file = _get_git_token_file()
    if remote_url.startswith("https://") and os.path.exists(token_file):
        with open(token_file, "r", encoding="utf-8") as f:
            token = f.read().strip()
        auth_url = remote_url
    else:
        auth_url = remote_url

    subprocess.run(["git", "remote", "add", "origin", auth_url], check=True)
    git_push_to_existing()


def all_task():
    print("===== cktax 全流程开始 =====")

    back()
    back_up()

    remote_file = _get_git_remote_file()
    has_remote_config = os.path.exists(remote_file)

    has_origin = False
    if _is_git_repo():
        result = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True)
        has_origin = result.returncode == 0

    print("\n[cktax] 检测到 Git 状态：")
    if has_origin:
        print("    已有远程仓库 (origin)")
        choice = input("\n是否推送到已有仓库？(y/N): ").strip().lower()
        if choice == 'y':
            git_push_to_existing()
        else:
            print("[cktax] 跳过推送")
    elif has_remote_config:
        print("    有保存的远程地址但未添加 origin")
        choice = input("\n是否添加并推送？(y/N): ").strip().lower()
        if choice == 'y':
            git_add_remote_and_push()
        else:
            print("[cktax] 跳过推送")
    else:
        print("    未检测到远程仓库")
        print("\n请选择：")
        print("1) 创建新仓库并推送")
        print("2) 已有仓库（手动输入地址）")
        print("3) 跳过")
        choice = input("请选择 (1/2/3): ").strip()

        if choice == "1":
            if github_create_repo():
                git_push_to_existing()
            else:
                print("[cktax] 自动创建失败，请选择 2 手动输入地址")
        elif choice == "2":
            git_remote_set()
            git_push_to_existing()
        else:
            print("[cktax] 跳过推送")

    config = _load_config()
    if config.get("auto_bak", False):
        print("\n[cktax] 检测到自动备份已开启")
        choice = input("是否备份当前目录？(y/N): ").strip().lower()
        if choice == 'y':
            bak()
        else:
            print("[cktax] 跳过备份")
    else:
        print("[cktax] 跳过备份（自动备份已关闭）")

    print("\n===== 全流程执行完毕 =====")


def key_subcmd():
    if len(sys.argv) < 3:
        print("[cktax key] 用法：")
        print("  cktax key add       新增密钥")
        print("  cktax key set 编号   切换密钥")
        return
    opt = sys.argv[2]
    if opt == "add":
        key_add()
    elif opt == "set":
        if len(sys.argv) < 4:
            print("[cktax] 格式：cktax key set 数字")
            return
        try:
            n = int(sys.argv[3])
            key_set(n)
        except:
            print("[cktax] 编号必须是整数")
    else:
        print("[cktax] 未知 key 子命令")


def path_subcmd():
    if len(sys.argv) < 3:
        print("[cktax path] 用法：")
        print("  cktax path set   修改全局存储地址")
        return
    opt = sys.argv[2]
    if opt == "set":
        path_set()
    else:
        print("[cktax] 未知 path 子命令")


def bak_subcmd():
    if len(sys.argv) >= 3:
        bak(sys.argv[2])
    else:
        custom = input("备份路径（回车 = 当前目录）: ").strip()
        if custom:
            bak(custom)
        else:
            bak()


def set_subcmd():
    if len(sys.argv) < 3:
        print("[cktax set] 用法：")
        print("  cktax set bak yes/no         开启/关闭自动备份")
        print("  cktax set bak path <路径>     设置备份路径")
        print("  cktax set bak path           查看当前备份路径")
        return
    key = sys.argv[2]
    if key == "bak":
        if len(sys.argv) < 4:
            print("[cktax set] 用法: cktax set bak yes/no 或 cktax set bak path <路径>")
            return
        if sys.argv[3] == "path":
            path = sys.argv[4] if len(sys.argv) > 4 else ""
            set_bak_path(path)
        else:
            set_bak(sys.argv[3])
    else:
        print(f"[cktax] 未知配置项: {key}")


def _get_git_remote_file():
    cktax_dir = get_global_cktax_path()
    return os.path.join(cktax_dir, "git_remote")


def _get_git_token_file():
    cktax_dir = get_global_cktax_path()
    return os.path.join(cktax_dir, "git_token")


def _is_git_repo():
    try:
        subprocess.run(["git", "rev-parse", "--git-dir"], check=True, capture_output=True)
        return True
    except:
        return False


def _get_current_branch():
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True, stderr=subprocess.DEVNULL
        ).strip()
    except:
        return None


def _check_github_api():
    try:
        with urllib.request.urlopen("https://api.github.com", timeout=5) as resp:
            return 200 <= resp.status < 400
    except Exception:
        return False


def github_create_repo():
    if not _check_github_api():
        print("[cktax] ⚠️ 无法访问 GitHub API，请检查网络")
        print("   建议：选择 2) 手动输入已有仓库地址")
        return False

    token_file = _get_git_token_file()
    if not os.path.exists(token_file):
        print("[cktax]  未配置 GitHub token，请先执行: cktax git token")
        return False

    with open(token_file, "r", encoding="utf-8") as f:
        token = f.read().strip()

    repo_name = input("\n请输入仓库名称: ").strip()
    if not repo_name:
        print("[cktax]  仓库名称不能为空")
        return False

    desc = input("仓库描述（可选）: ").strip()
    private = input("是否私有？(y/N): ").strip().lower() == 'y'

    url = "https://api.github.com/user/repos"
    data = json.dumps({
        "name": repo_name,
        "description": desc,
        "private": private,
        "auto_init": False
    }).encode()

    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"token {token}")
    req.add_header("Accept", "application/json")
    req.add_header("Content-Type", "application/json")

    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode())
            print(f"[cktax]  GitHub 仓库已创建: {result['html_url']}")
            remote_file = _get_git_remote_file()
            with open(remote_file, "w", encoding="utf-8") as f:
                f.write(result['clone_url'])
            return True
    except urllib.error.HTTPError as e:
        print(f"[cktax]  创建失败: {e}")
        if e.code == 422:
            print("   仓库名可能已存在或无效")
        return False


def git_remote_set():
    remote_file = _get_git_remote_file()
    print("[cktax] 请输入远程仓库地址")
    print("  支持 HTTPS: https://github.com/用户名/仓库名.git")
    print("  支持 SSH:   git@github.com:用户名/仓库名.git")
    addr = input("地址: ").strip()
    if not addr:
        print("[cktax]  地址不能为空")
        return
    if addr.startswith("git@") or addr.startswith("https://"):
        with open(remote_file, "w", encoding="utf-8") as f:
            f.write(addr)
        print(f"[cktax]  远程地址已保存")
    else:
        print(f"[cktax]  不支持的仓库地址格式: {addr}")
        print("   格式应为: git@github.com:用户名/仓库名.git")
        print("   或: https://github.com/用户名/仓库名.git")


def git_token_set():
    token_file = _get_git_token_file()
    print("[cktax] 请输入 GitHub Personal Access Token（需 repo 权限）")
    print("  获取方式: GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)")
    token = input("Token: ").strip()
    if not token:
        print("[cktax]  token 不能为空")
        return
    with open(token_file, "w", encoding="utf-8") as f:
        f.write(token)
    print("[cktax]  token 已保存")


def git_all():
    print("[cktax]  开始一键开源流程")

    if not _is_git_repo():
        print("[cktax] 初始化 git 仓库...")
        subprocess.run(["git", "init"], check=True)

    remote_file = _get_git_remote_file()
    if not os.path.exists(remote_file):
        print("[cktax] 未配置远程地址，请先执行: cktax git remote")
        return

    with open(remote_file, "r", encoding="utf-8") as f:
        remote_url = f.read().strip()

    remote_check = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True)
    if remote_check.returncode != 0:
        print(f"[cktax] 自动添加远程地址: {remote_url}")
        subprocess.run(["git", "remote", "add", "origin", remote_url], check=True)

    git_push_to_existing()


def git_init():
    if _is_git_repo():
        print("[cktax]  已经是 git 仓库")
        return
    subprocess.run(["git", "init"], check=True)
    print("[cktax]  git 仓库已初始化")


def git_clone():
    url = input("请输入仓库地址: ").strip()
    if not url:
        print("[cktax]  地址不能为空")
        return
    subprocess.run(["git", "clone", url], check=True)
    print("[cktax]  克隆完成")


def git_pull():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    branch = _get_current_branch()
    subprocess.run(["git", "pull", "origin", branch or "main"], check=True)
    print("[cktax]  拉取完成")


def git_status():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "status"])


def git_log():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "log", "--oneline", "--graph", "-20"])


def git_branch():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "branch", "-a"])


def git_diff():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    subprocess.run(["git", "diff"])


def git_stash():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    print("\n1) 查看暂存列表")
    print("2) 暂存变更")
    print("3) 恢复暂存")
    c = input("请选择 (1-3): ").strip()
    if c == "1":
        subprocess.run(["git", "stash", "list"])
    elif c == "2":
        subprocess.run(["git", "stash", "push"])
    elif c == "3":
        subprocess.run(["git", "stash", "pop"])


def git_tag():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    print("\n1) 查看标签")
    print("2) 创建标签")
    c = input("请选择 (1-2): ").strip()
    if c == "1":
        subprocess.run(["git", "tag", "-n"])
    elif c == "2":
        name = input("标签名: ").strip()
        subprocess.run(["git", "tag", name])
        print(f"[cktax]  标签 {name} 已创建")


def git_reset():
    if not _is_git_repo():
        print("[cktax]  不是 git 仓库")
        return
    steps = input("回退几个提交？(默认 1): ").strip()
    steps = int(steps) if steps.isdigit() else 1
    subprocess.run(["git", "reset", f"HEAD~{steps}"])
    print(f"[cktax]  已回退 {steps} 个提交")


def git_push():
    remote_file = _get_git_remote_file()
    token_file = _get_git_token_file()

    if not os.path.exists(remote_file):
        print("[cktax]  未配置远程地址，请先执行: cktax git remote")
        return

    with open(remote_file, "r", encoding="utf-8") as f:
        remote_url = f.read().strip()

    is_https = remote_url.startswith("https://")
    is_ssh = remote_url.startswith("git@")

    token = ""
    if is_https:
        if not os.path.exists(token_file):
            print("[cktax]  HTTPS 方式需要 token，请先执行: cktax git token")
            return
        with open(token_file, "r", encoding="utf-8") as f:
            token = f.read().strip()
        # Token 不拼进 URL，后面用环境变量传递
        auth_url = remote_url
    elif is_ssh:
        print("[cktax] 使用 SSH 方式推送，请确保已配置 SSH 密钥")
        auth_url = remote_url
    else:
        print("[cktax]  不支持的仓库地址格式")
        return

    try:
        subprocess.run(["git", "rev-parse", "--git-dir"], check=True, capture_output=True)
    except subprocess.CalledProcessError:
        print("[cktax]  当前目录不是 git 仓库，请先运行 git init")
        return

    remote_check = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True)
    has_origin = remote_check.returncode == 0

    if has_origin:
        subprocess.run(["git", "remote", "set-url", "origin", auth_url], check=True)
    else:
        subprocess.run(["git", "remote", "add", "origin", auth_url], check=True)

    try:
        current_branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL
        ).strip()
        print(f"[cktax] 检测到当前分支: {current_branch}")
        branch = current_branch
    except:
        branch = input("请输入要推送的分支名称（默认 main）: ").strip()
        if not branch:
            branch = "main"
        print(f"[cktax] 将使用分支: {branch}")

    print("\n请输入要添加的文件或目录（多个用空格隔开）")
    print("提示：直接回车 = 添加全部变更")
    add_input = input("> ").strip()
    if add_input:
        files = add_input.split()
        for f in files:
            print(f"  git add {f}")
            subprocess.run(["git", "add", f])
    else:
        print("  git add .")
        subprocess.run(["git", "add", "."])

    commit_msg = input("\n请输入本次提交的信息: ").strip()
    if not commit_msg:
        print("[cktax]  提交信息不能为空")
        return

    print("\n请选择推送方式：")
    print("1) 普通推送 (git push)")
    print("2) 强制推送 (git push --force)")
    print("3) 安全强制推送 (git push --force-with-lease)")
    choice = input("请输入 (1/2/3): ").strip()

    if choice == "1":
        push_cmd = ["git", "push", "origin", branch]
    elif choice == "2":
        push_cmd = ["git", "push", "--force", "origin", branch]
    elif choice == "3":
        push_cmd = ["git", "push", "--force-with-lease", "origin", branch]
    else:
        print("[cktax]  无效选择，取消推送")
        return

    try:
        status = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
        if not status.stdout.strip():
            print("[cktax]  没有需要提交的变更，跳过 commit")
        else:
            subprocess.run(["git", "commit", "-m", commit_msg], check=True)

        # 推送时用环境变量传递 token
        env = os.environ.copy()
        if is_https and token:
            env['GIT_ASKPASS'] = f'echo {token}'
        subprocess.run(push_cmd, check=True, env=env)
        print("[cktax]  推送成功")

        # 推送成功后清理凭据缓存
        try:
            subprocess.run(["git", "credential-cache", "exit"], capture_output=True)
        except:
            pass
    except subprocess.CalledProcessError as e:
        print(f"[cktax]  推送失败: {e}")
    except Exception as e:
        print(f"[cktax]  未知错误: {e}")


# ==================== 定时任务生成器 ====================

def _get_os_type():
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    elif system == "darwin":
        return "macos"
    elif "termux" in os.environ.get("PREFIX", "") or os.path.exists("/data/data/com.termux"):
        return "termux"
    else:
        return "linux"


def _detect_backend():
    os_type = _get_os_type()
    backends = []

    if os_type == "windows":
        try:
            subprocess.run(["schtasks", "/?"], capture_output=True, check=True)
            backends.append(("schtasks", "Windows 任务计划程序"))
        except:
            pass
        backends.append(("at", "Windows at 命令（一次性）"))
    elif os_type in ("linux", "macos"):
        try:
            subprocess.run(["crontab", "-l"], capture_output=True)
            backends.append(("cron", "Cron 定时任务（循环）"))
        except:
            pass
        if os_type == "linux":
            try:
                subprocess.run(["systemctl", "--user", "list-timers"], capture_output=True)
                backends.append(("systemd", "Systemd Timer"))
            except:
                pass
        try:
            subprocess.run(["at", "-V"], capture_output=True)
            backends.append(("at", "at 一次性任务"))
        except:
            pass
    elif os_type == "termux":
        backends.append(("termux-boot", "Termux:Boot 开机启动（需安装 Termux:Boot 插件）"))
        backends.append(("nohup", "nohup 后台进程（可能被杀，不推荐长期使用）"))
        backends.append(("at", "at 一次性任务（需安装 at）"))

    return backends


def _generate_timer_command(module_path, run_git, when, backend, is_daily=False):
    git_flag = "--git" if run_git else ""
    exec_cmd = f'cd "{module_path}" && cktax all {git_flag}'
    task_name = f"cktax_{Path(module_path).name}"

    if backend == "schtasks":
        return f'schtasks /create /tn "{task_name}" /tr "{exec_cmd}" /sc once /st {when.strftime("%H:%M")} /sd {when.strftime("%Y/%m/%d")} /ru SYSTEM'

    elif backend == "cron":
        if is_daily:
            return f'{when.strftime("%M %H * * *")} {exec_cmd}'
        else:
            return f'{when.strftime("%M %H %d %m *")} {exec_cmd}'

    elif backend == "systemd":
        return "# systemd timer 配置较复杂，请参考 systemd 文档"

    elif backend == "termux-boot":
        boot_script = f'''#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
{exec_cmd}
'''
        return f'echo \'{boot_script}\' > ~/.termux/boot/cktax_{Path(module_path).name}.sh && chmod +x ~/.termux/boot/cktax_{Path(module_path).name}.sh'

    elif backend == "nohup":
        return f'nohup {exec_cmd} > ~/cktax_timer.log 2>&1 &\n# 注意：Termux 下 nohup 可能被杀，建议安装 Termux:Boot 插件'

    elif backend == "at":
        if when is None:
            return "# at 命令需要指定时间，请使用：echo 'command' | at 15:30"
        return f'echo "{exec_cmd}" | at {when.strftime("%H:%M %Y-%m-%d")}'

    return f"# 不支持的后端: {backend}"


def timer_gen():
    print("[cktax] 定时任务生成器")
    print("=" * 50)

    backends = _detect_backend()
    if not backends:
        print("[cktax] 未检测到支持的后台任务方式，请手动配置")
        return

    default_path = os.getcwd()
    path = input(f"模块路径（回车 = {default_path}）: ").strip()
    if not path:
        path = default_path
    if not os.path.exists(path):
        print("[cktax] 路径不存在")
        return

    git_choice = input("是否同时推送到 GitHub？(y/N): ").strip().lower()
    run_git = git_choice == 'y'

    print("\n请选择任务类型：")
    print("1) 一次性任务（指定时间）")
    print("2) 重复任务（每天）")
    choice = input("请选择 (1/2): ").strip()

    when = None
    if choice == "1":
        time_str = input("执行时间 (YYYY-MM-DD HH:MM): ").strip()
        when = datetime.strptime(time_str, "%Y-%m-%d %H:%M")
    elif choice == "2":
        time_str = input("执行时间 (HH:MM): ").strip()
        hour, minute = map(int, time_str.split(":"))
        tomorrow = datetime.now() + timedelta(days=1)
        when = tomorrow.replace(hour=hour, minute=minute, second=0)
    else:
        print("[cktax] 无效选择")
        return

    print("\n[cktax] 检测到以下后台任务方式：")
    valid_backends = []
    for backend, desc in backends:
        if choice == "1" and backend in ("cron", "systemd"):
            continue
        valid_backends.append((backend, desc))

    if not valid_backends:
        print("[cktax] 没有可选的后台方式")
        return

    for i, (_, desc) in enumerate(valid_backends, 1):
        print(f"  {i}) {desc}")

    backend_choice = input("请选择 (默认 1): ").strip()
    if not backend_choice:
        backend_choice = "1"

    try:
        idx = int(backend_choice) - 1
        backend, _ = valid_backends[idx]
    except:
        backend = valid_backends[0][0]

    cmd = _generate_timer_command(path, run_git, when, backend, is_daily=(choice == "2"))

    print("\n" + "=" * 50)
    print("[cktax] 请执行以下命令来配置定时任务：")
    print("=" * 50)
    print(cmd)
    print("=" * 50)


def timer_subcmd():
    if len(sys.argv) < 3:
        print("[cktax timer] 用法：")
        print("  cktax timer gen    生成定时任务配置")
        return
    subcmd = sys.argv[2]
    if subcmd == "gen":
        timer_gen()
    else:
        print(f"[cktax] 未知 timer 子命令: {subcmd}")


def git_subcmd():
    if len(sys.argv) < 3:
        print("\n[cktax git] 用法：")
        print("=" * 50)
        print("  cktax git all        一键自动开源（推荐）")
        print("  cktax git init       初始化仓库")
        print("  cktax git clone      克隆仓库")
        print("  cktax git remote     设置远程仓库地址")
        print("  cktax git token      设置 GitHub token")
        print("  cktax git push       推送代码")
        print("  cktax git pull       拉取更新")
        print("  cktax git status     查看状态")
        print("  cktax git log        查看历史")
        print("  cktax git branch     分支管理")
        print("  cktax git diff       查看差异")
        print("  cktax git stash      暂存管理")
        print("  cktax git tag        标签管理")
        print("  cktax git reset      撤销提交")
        print("=" * 50)
        return

    subcmd = sys.argv[2]
    if subcmd == "all":
        git_all()
    elif subcmd == "init":
        git_init()
    elif subcmd == "clone":
        git_clone()
    elif subcmd == "remote":
        git_remote_set()
    elif subcmd == "push":
        git_push()
    elif subcmd == "pull":
        git_pull()
    elif subcmd == "status":
        git_status()
    elif subcmd == "log":
        git_log()
    elif subcmd == "branch":
        git_branch()
    elif subcmd == "diff":
        git_diff()
    elif subcmd == "stash":
        git_stash()
    elif subcmd == "tag":
        git_tag()
    elif subcmd == "reset":
        git_reset()
    elif subcmd == "token":
        git_token_set()
    else:
        print(f"[cktax] 未知 git 子命令: {subcmd}")


def main():
    if len(sys.argv) < 2:
        print("===== cktax 工具用法 =====")
        print("cktax bak      备份当前项目")
        print("cktax back     项目打包 build")
        print("cktax up       上传到 PyPI")
        print("cktax all      一条龙：打包+上传+开源+备份")
        print("cktax key      密钥管理")
        print("cktax path     全局地址管理")
        print("cktax git      Git 推送管理")
        print("cktax timer    定时任务生成器")
        print("cktax set bak yes/no        开启/关闭自动备份")
        print("cktax set bak path <路径>   设置备份路径")
        return

    cmd = sys.argv[1]
    if cmd == "bak":
        bak_subcmd()
    elif cmd == "back":
        back()
    elif cmd == "up":
        back_up()
    elif cmd == "all":
        all_task()
    elif cmd == "key":
        key_subcmd()
    elif cmd == "path":
        path_subcmd()
    elif cmd == "git":
        git_subcmd()
    elif cmd == "timer":
        timer_subcmd()
    elif cmd == "set":
        set_subcmd()
    else:
        print(f"[cktax] 未知命令：{cmd}")


if __name__ == "__main__":
    main()