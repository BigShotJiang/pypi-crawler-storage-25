# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.0.50] - 2026-04-04

### Documentation

- Update documentation
- Update documentation

## [0.0.49] - 2026-04-03

### Added

- Update src/pycharter/collab/_protocol.py
- Update src/pycharter/api/main.py
- Update package
- Update src/pycharter/db/migrations/versions/20260402000000_add_data_contracts_revision.py
- Update src/pycharter/docs_generator/renderers.py,src/pycharter/quality/profiling.py,src/pycharter/shared/errors.py

### Changed

- Remove unused code

### Documentation

- Update documentation
- Update bin/README.md,docs/contributing.md
- Update docs/contributing.md,docs/contributing/publishing.md,docs/contributing/release-workflow.md

## [0.0.38] - 2026-03-03

### Build

- Pin softprops/action-gh-release to v2.4.2

## [0.0.32] - 2026-02-13

