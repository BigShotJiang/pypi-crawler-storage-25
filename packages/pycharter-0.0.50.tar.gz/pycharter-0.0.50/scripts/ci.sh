#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

usage() {
  cat <<'EOF'
Run the same checks as GitHub Actions (local CI parity).
When mkdocs.yml exists, runs ``mkdocs build --strict`` after mypy (per Python job).
Build output goes to a temp dir so pre-push does not rewrite tracked ``site/``.

Usage:
  ./scripts/ci.sh [--matrix] [--python 3.12] [--no-ui]

Options:
  --matrix        Run the full CI Python matrix (3.11, 3.12, 3.13) locally.
  --python X.Y    Run checks with a single Python version (uses pythonX.Y).
  --no-ui         Skip UI type-check even if ui/ exists.
EOF
}

die() { echo "error: $*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

MATRIX=0
PYTHON_VER=""
NO_UI=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --matrix) MATRIX=1; shift ;;
    --python) PYTHON_VER="${2:-}"; [[ -n "$PYTHON_VER" ]] || die "--python requires X.Y"; shift 2 ;;
    --no-ui) NO_UI=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown arg: $1" ;;
  esac
done

PKG_NAME="${PKG_NAME:-$(basename "$REPO_ROOT")}"
PYTHON_PACKAGE_ROOT="${PYTHON_PACKAGE_ROOT:-src/$PKG_NAME}"

[[ -d "$PYTHON_PACKAGE_ROOT" ]] || die "PYTHON_PACKAGE_ROOT not found: $PYTHON_PACKAGE_ROOT"

run_docs() {
  [[ -f mkdocs.yml ]] || return 0
  local vpy="$1"
  echo "==> MkDocs: build (--strict, temp output)"
  local out
  out="$(mktemp -d "${TMPDIR:-/tmp}/${PKG_NAME}-mkdocs-ci.XXXXXX")"
  "$vpy" -m mkdocs build --strict -d "$out"
  local st=$?
  rm -rf "$out"
  return "$st"
}

run_python() {
  local py="$1" ver="$2"
  local venv_dir=".venv-ci-${ver}"

  echo "==> Python ${ver}: creating venv (${venv_dir})"
  "$py" -m venv "$venv_dir"

  local vpy="$venv_dir/bin/python"

  "$vpy" -m pip install --upgrade pip >/dev/null
  "$vpy" -m pip install -e ".[dev]" >/dev/null

  echo "==> Python ${ver}: ruff format"
  "$vpy" -m ruff format --check "$PYTHON_PACKAGE_ROOT" tests
  echo "==> Python ${ver}: ruff lint"
  "$vpy" -m ruff check "$PYTHON_PACKAGE_ROOT" tests
  echo "==> Python ${ver}: pytest"
  "$vpy" -m pytest
  echo "==> Python ${ver}: mypy"
  "$vpy" -m mypy "$PYTHON_PACKAGE_ROOT"
  run_docs "$vpy"
}

resolve_python() {
  local ver="$1"
  local py="python${ver}"
  if command -v "$py" >/dev/null 2>&1; then
    echo "$py"
    return 0
  fi
  if command -v pyenv >/dev/null 2>&1; then
    local pyenv_py
    pyenv_py="$(pyenv which "python${ver}" 2>/dev/null || true)"
    if [[ -n "$pyenv_py" && -x "$pyenv_py" ]]; then
      echo "$pyenv_py"
      return 0
    fi
  fi
  return 1
}

run_ui() {
  if [[ "$NO_UI" -eq 1 ]]; then
    return 0
  fi

  local ui_dir="$PYTHON_PACKAGE_ROOT/ui"
  [[ -f "$ui_dir/package.json" ]] || return 0

  have node || die "node is required for UI type-check (found $ui_dir/package.json)"
  have npm || die "npm is required for UI type-check"

  echo "==> UI: type-check (${ui_dir})"
  pushd "$ui_dir" >/dev/null
  if [[ -f package-lock.json ]]; then
    npm ci
  else
    npm install
  fi
  npm run type-check
  popd >/dev/null
}

if [[ "$MATRIX" -eq 1 ]]; then
  for v in 3.11 3.12 3.13; do
    py="$(resolve_python "$v" || true)"
    [[ -n "$py" ]] || die "missing Python ${v} (install it or run ./scripts/ci.sh --python X.Y). If you use pyenv, install ${v} and run: pyenv local ${v}"
    run_python "$py" "$v"
  done
  run_ui
  exit 0
fi

if [[ -n "$PYTHON_VER" ]]; then
  py="$(resolve_python "$PYTHON_VER" || true)"
  [[ -n "$py" ]] || die "missing Python ${PYTHON_VER}"
  run_python "$py" "$PYTHON_VER"
  run_ui
  exit 0
fi

# Default: use repo venv/ if present and not relocated (activate path matches this repo).
WANT_VENV="$(pwd -P)/venv"
USE_VENV=0
if [[ -x "venv/bin/python" && -f venv/bin/activate ]]; then
  GOT_VENV=$(grep -m1 'export VIRTUAL_ENV=/' venv/bin/activate | sed 's/.*export VIRTUAL_ENV=//; s/\r//' || true)
  if [[ -z "${GOT_VENV}" || "${GOT_VENV}" == "${WANT_VENV}" ]]; then
    USE_VENV=1
  else
    echo "warning: ignoring stale venv (activate -> ${GOT_VENV}, expected ${WANT_VENV}); using ephemeral CI venv." >&2
  fi
fi

if [[ "${USE_VENV}" -eq 1 ]]; then
  echo "==> Using existing venv/"
  vpy="venv/bin/python"
  "$vpy" -m pip install --upgrade pip >/dev/null
  "$vpy" -m pip install -e ".[dev]" >/dev/null
  "$vpy" -m ruff format --check "$PYTHON_PACKAGE_ROOT" tests
  "$vpy" -m ruff check "$PYTHON_PACKAGE_ROOT" tests
  "$vpy" -m pytest
  "$vpy" -m mypy "$PYTHON_PACKAGE_ROOT"
  run_docs "$vpy"
  run_ui
  exit 0
fi

have python3 || die "python3 not found"
run_python python3 "default"
run_ui
