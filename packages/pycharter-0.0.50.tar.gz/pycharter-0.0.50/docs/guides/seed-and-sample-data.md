# Seed data and sample files

PyCharter can populate the SQL contract store (and related tables) from YAML files in a **seed directory**.

## Default bundled seed

After `pycharter db init`, run:

```bash
pycharter db seed
```

With no arguments, the CLI loads YAML from the **`data/seed`** directory inside the installed `pycharter` package. In a source checkout, that directory is:

`src/pycharter/data/seed/`

It includes reference entities (owners, domains, systems, environments, data feeds, compliance frameworks, tags), contract artifacts, pipeline configs, and semantic-layer seed files (`contracts.yaml`, `schemas.yaml`, `ontologies.yaml`, etc.), in dependency order.

## Custom seed directory

Point at any directory that follows the same layout (see files under `src/pycharter/data/seed/` for examples):

```bash
pycharter db seed /path/to/my_seed
pycharter db seed /path/to/my_seed postgresql://user:pass@localhost/pycharter
```

If the first positional argument looks like a database URL, the CLI treats it as the connection string and uses the default seed path (see `pycharter.db.seed.cmd_seed`).

## `data/aviation_examples/` (repository samples)

The **`data/aviation_examples/`** folder at the **repository root** holds additional **on-disk sample contracts and related artifacts** used in tutorials and demos. They are **not** part of `pycharter db seed` and are **not** copied into the PyPI wheel.

Load them through the **Web UI** (contract import) or the **REST API** when you want those scenarios in your database.

## Related commands

- `pycharter db init` — create or migrate schema (Alembic)
- `pycharter db truncate --force` — clear data (use with care)

See also [Configuration & Database Setup](configuration.md) and the [command reference](../reference.md#database-management).
