# Real-time collaboration

PyCharter includes an optional **Socket.IO relay** for end-to-end encrypted collaboration (similar in spirit to Excalidraw’s room server). The server **relays ciphertext only**; it does not decrypt document payloads.

## Install

```bash
pip install pycharter[collab]
```

The `[collab]` extra pulls in `python-socketio`. It is included in `pycharter[all]` and `pycharter[dev]`.

## API server integration

When the collab extra is installed, `create_application()` in the FastAPI app **mounts** the relay at **`/collab`**. Clients connect with Socket.IO using path **`/collab/socket.io/`** (trailing slash as used by the Python socket.io stack).

If the extra is missing, the API starts normally and logs that collab is unavailable.

## Programmatic mount

To attach the relay to your own FastAPI app:

```python
from fastapi import FastAPI
from pycharter.collab import create_collab_app

app = FastAPI()
app.mount("/collab", create_collab_app())
```

## Web UI

The Next.js UI can start a collaboration session from supported editors (e.g. pipeline diagram). It uses the same Socket.IO path against the API base URL you configure for `pycharter ui dev` (`--api-url`).

For low-level behavior and events, see the `pycharter.collab` package docstring and `pycharter/collab/_server.py`.
