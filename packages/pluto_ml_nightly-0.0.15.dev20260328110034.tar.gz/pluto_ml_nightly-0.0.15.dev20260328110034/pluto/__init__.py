import os
import subprocess
from typing import Any, Callable, List, Optional

from . import query
from .auth import login, logout
from .data import Data, Graph, Histogram, Table
from .file import Artifact, Audio, File, Image, Text, Video
from .init import finish, init
from .sets import Settings, setup
from .sys import System
from .util import generate_run_id

_hooks: List[Any] = []
ops: Optional[List[Any]] = None
log: Optional[Callable[..., Any]] = None
watch: Optional[Callable[..., Any]] = None
alert: Optional[Callable[..., Any]] = None

__all__ = (
    'Data',
    'Graph',
    'Histogram',
    'Table',
    'File',
    'Artifact',
    'Text',
    'Image',
    'Audio',
    'Video',
    'System',
    'Settings',
    'alert',
    'init',
    'login',
    'logout',
    'watch',
    'finish',
    'setup',
    'query',
    'generate_run_id',
)

__version__ = '1.0.0.dev0.0.15.dev20260328110034'


# Replaced with the current commit when building the wheels.
_PLUTO_COMMIT_SHA = '3108fb2003b8bba4cd82b8d143e8047e71f85fc6'


def _get_git_commit():
    if 'PLUTO_COMMIT_SHA' not in _PLUTO_COMMIT_SHA:
        # This is a release build, so we don't need to get the commit hash from
        # git, as it's already been set.
        return _PLUTO_COMMIT_SHA

    # This is a development build (pip install -e .), so we need to get the
    # commit hash from git.
    try:
        cwd = os.path.dirname(__file__)
        commit_hash = subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'],
            cwd=cwd,
            universal_newlines=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        changes = subprocess.check_output(
            ['git', 'status', '--porcelain'],
            cwd=cwd,
            universal_newlines=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if changes:
            commit_hash += '-dirty'
        return commit_hash
    except Exception:  # pylint: disable=broad-except
        return _PLUTO_COMMIT_SHA
