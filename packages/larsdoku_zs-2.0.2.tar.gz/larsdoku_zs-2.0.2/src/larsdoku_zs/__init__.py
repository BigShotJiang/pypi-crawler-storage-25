"""Larsdoku -- Pure logic Sudoku solver library.
WSRF bitwise engine + GF(2) linear algebra. Zero guessing.

Quick usage:
    from larsdoku_zs import Board

    b = Board("530070000600195000098000060800060003400803001700020006060000280000419005000080079")
    print(b)

    result = b.solve()
    print(result['success'])

    # Or one-liner:
    from larsdoku_zs import solve
    result = solve("530070000...")
"""
__version__ = "2.0.2"

from .board import Board, DetectResult
from .engine import BitBoard
from .constants import (
    TECHNIQUE_LEVELS, TECHNIQUE_ALIASES, PRESETS,
    EXPERT_APPROVED, WSRF_INVENTIONS, EXOTIC_TECHNIQUES,
    PREFER_EXCLUSIONS,
)
from .solver import solve_selective, query_cell
from .utils import (
    normalize_puzzle, parse_cell, parse_techniques,
    shuffle_sudoku, forge_variant, generate_random_mask,
)
from .display import format_board


def solve(puzzle, **kwargs):
    """Solve a puzzle. Accepts bd81, BDP, or dot-notation."""
    bd81 = normalize_puzzle(puzzle)
    return solve_selective(bd81, **kwargs)


def detect(puzzle, technique):
    """Try a single technique on a puzzle string."""
    return Board(puzzle).detect(technique)


def _lars_warmup():
    """Background JIT warmup — compiles all Numba functions on first import."""
    try:
        solve_selective('530070000600195000098000060800060003400803001700020006060000280000419005000080079')
    except Exception:
        pass


def _lars_background_warmup():
    """Spawn warmup in a background thread so import returns immediately."""
    import threading
    t = threading.Thread(target=_lars_warmup, daemon=True)
    t.start()


# Auto-warmup on import
_lars_background_warmup()
