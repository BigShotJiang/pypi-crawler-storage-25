"""Query helpers — uma função por subcomando da CLI.

Cada função recebe uma ``sqlite3.Connection`` aberta e retorna uma lista de
dicts pronta para :func:`plugadvpl.output.render`. Sem efeitos colaterais
(somente SELECT). Aceita conexão read-only ou full — o caller decide.

Convenções:

- Identificadores ADVPL são case-insensitive: comparações via ``upper()`` e
  variantes ``COLLATE NOCASE``. Para destinos de chamada usamos ``destino_norm``
  (uppercase, sem prefixo ``U_``).
- Tabelas Protheus (SA1, SC5, ZA1) são gravadas em uppercase pela ingest;
  comparações usam ``upper(?)`` no bind.
- Funções que mexem com JSON (campos como ``capabilities``, ``funcoes``)
  desserializam via :mod:`json` para que o renderer veja list/dict nativos.
"""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path
from typing import Any

from plugadvpl.db import get_meta


def find_function(conn: sqlite3.Connection, nome: str) -> list[dict[str, Any]]:
    """Procura função por nome em ``fonte_chunks`` (case-insensitive).

    Usa ``funcao_norm`` (uppercase + trim) que é índice em ``fonte_chunks``.
    """
    rows = conn.execute(
        """
        SELECT arquivo, funcao, linha_inicio, linha_fim, assinatura, tipo_simbolo
        FROM fonte_chunks
        WHERE funcao_norm = upper(?)
        ORDER BY arquivo, linha_inicio
        LIMIT 200
        """,
        (nome,),
    ).fetchall()
    cols = ["arquivo", "funcao", "linha_inicio", "linha_fim", "assinatura", "tipo_simbolo"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def find_file(conn: sqlite3.Connection, termo: str) -> list[dict[str, Any]]:
    """Procura arquivo por basename ou parte do caminho relativo."""
    pattern = f"%{termo}%"
    rows = conn.execute(
        """
        SELECT arquivo, caminho_relativo, source_type, lines_of_code
        FROM fontes
        WHERE arquivo LIKE ? COLLATE NOCASE
           OR caminho_relativo LIKE ? COLLATE NOCASE
        ORDER BY arquivo
        LIMIT 200
        """,
        (pattern, pattern),
    ).fetchall()
    cols = ["arquivo", "caminho_relativo", "source_type", "lines_of_code"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def find_any(conn: sqlite3.Connection, termo: str) -> list[dict[str, Any]]:
    """Estratégia composta: tenta ``find_function``, depois ``find_file``, depois ``grep_fts``.

    Para o subcomando ``find <termo>`` que não sabe se é função, arquivo ou
    string genérica.
    """
    hits = find_function(conn, termo)
    if hits:
        return [dict(r, _kind="function") for r in hits]
    hits = find_file(conn, termo)
    if hits:
        return [dict(r, _kind="file") for r in hits]
    fts = grep_fts(conn, termo, mode="fts", limit=20)
    return [dict(r, _kind="content") for r in fts]


def callers(conn: sqlite3.Connection, nome: str) -> list[dict[str, Any]]:
    """Quem chama ``nome``? Lookup em ``chamadas_funcao`` (destino + destino_norm).

    v0.3.18 (#12): cada row inclui ``is_self_call: bool`` indicando que a
    chamada origina do mesmo símbolo (mesma função homônima OU mesmo arquivo
    de basename igual ao nome buscado). Útil pra filtrar self-references
    quando você quer só callers externos (FwLoadModel('X') de dentro de X.prw).
    """
    norm = nome.upper().lstrip("U_") if nome.upper().startswith("U_") else nome.upper()
    rows = conn.execute(
        """
        SELECT arquivo_origem, funcao_origem, linha_origem, tipo, contexto
        FROM chamadas_funcao
        WHERE destino_norm = ? OR destino = ? COLLATE NOCASE
        ORDER BY arquivo_origem, linha_origem
        """,
        (norm, nome),
    ).fetchall()
    nome_up = nome.upper()
    out: list[dict[str, Any]] = []
    for arquivo, funcao, linha, tipo, contexto in rows:
        # Self-call quando: a função-pai é o próprio nome OU o arquivo de
        # origem (sem extensão) bate com o nome buscado.
        arq_base = (arquivo or "").upper().rsplit(".", 1)[0]
        is_self = (
            (funcao or "").upper() == nome_up
            or arq_base == nome_up
        )
        out.append({
            "arquivo": arquivo,
            "funcao": funcao,
            "linha": linha,
            "tipo": tipo,
            "contexto": contexto,
            "is_self_call": is_self,
        })
    return out


def callees(conn: sqlite3.Connection, nome: str) -> list[dict[str, Any]]:
    """Quem ``nome`` chama? Lookup em ``chamadas_funcao`` (funcao_origem).

    Como o ingest atual deixa ``funcao_origem`` vazio (best-effort MVP),
    fazemos fallback para ``arquivo_origem`` quando ``nome`` parece um
    basename de fonte (ex: ``FATA050.prw``).
    """
    if "." in nome and any(nome.lower().endswith(ext) for ext in (".prw", ".tlpp", ".prx", ".apw")):
        # Fallback: tratamos `nome` como basename de fonte.
        rows = conn.execute(
            """
            SELECT destino, tipo, linha_origem, contexto
            FROM chamadas_funcao
            WHERE arquivo_origem = ? COLLATE NOCASE
            ORDER BY linha_origem
            """,
            (nome,),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT destino, tipo, linha_origem, contexto
            FROM chamadas_funcao
            WHERE funcao_origem = ? COLLATE NOCASE
            ORDER BY linha_origem
            """,
            (nome,),
        ).fetchall()
    cols = ["destino", "tipo", "linha", "contexto"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def tables_query(
    conn: sqlite3.Connection, tabela: str, modo: str | None = None
) -> list[dict[str, Any]]:
    """Quem usa a tabela ``X``? Lookup em ``fonte_tabela``.

    ``modo`` pode ser ``read``, ``write``, ``reclock`` ou ``None`` (todos).
    """
    if modo:
        rows = conn.execute(
            "SELECT arquivo, tabela, modo FROM fonte_tabela "
            "WHERE tabela = upper(?) AND modo = ? "
            "ORDER BY arquivo",
            (tabela, modo),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT arquivo, tabela, modo FROM fonte_tabela "
            "WHERE tabela = upper(?) "
            "ORDER BY arquivo, modo",
            (tabela,),
        ).fetchall()
    cols = ["arquivo", "tabela", "modo"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def param_query(conn: sqlite3.Connection, parametro: str) -> list[dict[str, Any]]:
    """Quem usa o parâmetro ``MV_*``? Lookup em ``parametros_uso``."""
    rows = conn.execute(
        """
        SELECT arquivo, parametro, modo, default_decl
        FROM parametros_uso
        WHERE parametro = upper(?)
        ORDER BY arquivo, modo
        """,
        (parametro,),
    ).fetchall()
    cols = ["arquivo", "parametro", "modo", "default_decl"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def arch(conn: sqlite3.Connection, arquivo: str) -> list[dict[str, Any]]:
    """Resumo arquitetural de UM fonte. Retorna lista com 0 ou 1 dict.

    Inclui: ``source_type``, ``capabilities``, ``lines_of_code``, ``encoding``,
    listas de funções/tabelas (read/write/reclock)/includes.
    """
    row = conn.execute(
        """
        SELECT arquivo, source_type, capabilities, lines_of_code, encoding,
               funcoes, user_funcs, pontos_entrada,
               tabelas_ref, write_tables, reclock_tables, includes,
               namespace, tipo_arquivo
        FROM fontes
        WHERE arquivo = ? COLLATE NOCASE
        """,
        (arquivo,),
    ).fetchone()
    if row is None:
        return []
    (
        arquivo_,
        source_type,
        caps_json,
        loc,
        enc,
        funcs_json,
        user_funcs_json,
        pe_json,
        tabs_read_json,
        writes_json,
        reclock_json,
        incs_json,
        namespace,
        tipo_arquivo,
    ) = row
    capabilities = _json_or_default(caps_json, [])
    return [
        {
            "arquivo": arquivo_,
            "tipo_arquivo": tipo_arquivo,
            "source_type": source_type,
            "capabilities": capabilities,
            "lines_of_code": loc,
            "encoding": enc,
            "namespace": namespace,
            "funcoes": _json_or_default(funcs_json, []),
            "user_funcs": _json_or_default(user_funcs_json, []),
            "pontos_entrada": _json_or_default(pe_json, []),
            "tabelas_read": _json_or_default(tabs_read_json, []),
            "tabelas_write": _json_or_default(writes_json, []),
            "tabelas_reclock": _json_or_default(reclock_json, []),
            # v0.3.18 (#11 do QA report): sinaliza que `tabelas_*` pode estar
            # incompleto porque o fonte usa MsExecAuto (analise estatica nao
            # expande a rotina chamada). Caller deve checar a rotina pelo nome
            # e/ou rodar `tables` na rotina alvo pra cobertura completa.
            "tabelas_via_execauto": "EXEC_AUTO_CALLER" in capabilities,
            # v0.4.1 (Universo 3 Feature B): tabelas inferidas via lookup do
            # catalogo execauto_routines.json. Lista vazia se: (a) nao ha
            # MsExecAuto no fonte; (b) rotina nao esta no catalogo; (c) call
            # eh dynamic. Cliente pode cruzar com `plugadvpl execauto --arquivo`
            # pra ver detalhe por chamada.
            "tabelas_via_execauto_resolvidas": arch_execauto_tables(conn, arquivo_),
            "includes": _json_or_default(incs_json, []),
        }
    ]


def log_diagnose_query(
    conn: sqlite3.Connection,
    arquivo: str | None = None,
    severity: str | None = None,
    category: str | None = None,
    rule_id: str | None = None,
) -> list[dict[str, Any]]:
    """Lista findings do diagnostico de log (cli ``log-diagnose``).

    Filtros opcionais:
        - ``arquivo``  — basename do log (case-insensitive)
        - ``severity`` — ``critical`` | ``warning`` | ``info``
        - ``category`` — ``database`` | ``thread_error`` | ``rpo`` | ...
        - ``rule_id``  — ex.: ``LOG-DB-ORA``
    """
    where: list[str] = ["f.status = 'active'"]
    params: list[Any] = []
    if arquivo:
        where.append("lf.arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if severity:
        where.append("f.severity = ?")
        params.append(severity)
    if category:
        where.append("f.category = ?")
        params.append(category)
    if rule_id:
        where.append("f.rule_id = ?")
        params.append(rule_id)

    sql = f"""
        SELECT lf.arquivo, lf.tipo AS log_tipo, f.line_number, f.timestamp,
               f.thread_id, f.severity, f.category, f.rule_id, f.message,
               f.correction_tip, f.tdn_url, f.username, f.computer_name, f.ora_code
        FROM log_findings f
        JOIN log_files lf ON lf.id = f.file_id
        WHERE {' AND '.join(where)}
        ORDER BY
            CASE f.severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END,
            lf.arquivo, f.line_number DESC
    """
    rows = conn.execute(sql, params).fetchall()
    cols = [
        "arquivo", "log_tipo", "linha", "timestamp", "thread_id",
        "severidade", "categoria", "rule_id", "message",
        "sugestao_fix", "tdn_url", "usuario", "host", "ora_code",
    ]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def ini_audit_query(
    conn: sqlite3.Connection,
    arquivo: str | None = None,
    severity: str | None = None,
    regra_id: str | None = None,
    show_ok_with_note: bool = False,
) -> list[dict[str, Any]]:
    """Lista findings de auditoria de INI (cli ``ini-audit``).

    Filtros opcionais:
        - ``arquivo``           — basename do INI (case-insensitive)
        - ``severity``          — ``critical`` | ``warning`` | ``info``
        - ``regra_id``          — ex.: ``APP-GENERAL-MAXSTRINGSIZE``
        - ``show_ok_with_note`` — se ``True``, inclui findings com justificativa
          documentada em comentários do INI. Default exibe só ``active``.
    """
    where: list[str] = []
    params: list[Any] = []
    status_filter = ("'active'", "'ok_with_note'") if show_ok_with_note else ("'active'",)
    where.append(f"f.status IN ({', '.join(status_filter)})")

    if arquivo:
        where.append("ini.arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if severity:
        where.append("f.severidade = ?")
        params.append(severity)
    if regra_id:
        where.append("f.regra_id = ?")
        params.append(regra_id)

    where_clause = "WHERE " + " AND ".join(where)
    sql = f"""
        SELECT ini.arquivo, ini.tipo, ini.role, f.section_raw, f.key_name,
               f.linha, f.regra_id, f.severidade, f.snippet, f.sugestao_fix, f.status
        FROM ini_audit_findings f
        JOIN ini_files ini ON ini.id = f.file_id
        {where_clause}
        ORDER BY
            CASE f.severidade WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 END,
            ini.arquivo, f.section_raw, f.linha
    """
    rows = conn.execute(sql, params).fetchall()
    cols = [
        "arquivo", "tipo", "role", "section", "key",
        "linha", "regra_id", "severidade", "snippet", "sugestao_fix", "status",
    ]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def lint_query(
    conn: sqlite3.Connection,
    arquivo: str | None = None,
    severity: str | None = None,
    regra_id: str | None = None,
) -> list[dict[str, Any]]:
    """Lista lint findings, opcionalmente filtrado por arquivo/severidade/regra."""
    where: list[str] = []
    params: list[Any] = []
    if arquivo:
        where.append("arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if severity:
        where.append("severidade = ?")
        params.append(severity)
    if regra_id:
        where.append("regra_id = ?")
        params.append(regra_id)
    where_clause = ("WHERE " + " AND ".join(where)) if where else ""
    sql = (
        "SELECT arquivo, funcao, linha, regra_id, severidade, snippet, sugestao_fix "
        f"FROM lint_findings {where_clause} "
        "ORDER BY arquivo, linha"
    )
    rows = conn.execute(sql, params).fetchall()
    cols = ["arquivo", "funcao", "linha", "regra_id", "severidade", "snippet", "sugestao_fix"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def status(
    conn: sqlite3.Connection,
    project_root: str,
    runtime_version: str | None = None,
) -> list[dict[str, Any]]:
    """Estado do índice: meta + contadores.

    Args:
        conn: conexão aberta (read-only OK).
        project_root: caminho da raiz (usado como fallback se o meta não tiver).
        runtime_version: versão do binário rodando AGORA (``plugadvpl.__version__``).
            Quando passado, vira a chave ``runtime_version`` na saída — comparar
            com ``plugadvpl_version`` (= versão que tocou o índice por último)
            permite detectar upgrade sem ``ingest --incremental`` posterior.
    """
    return [
        {
            "schema_version": get_meta(conn, "schema_version"),
            "runtime_version": runtime_version,
            "plugadvpl_version": get_meta(conn, "plugadvpl_version"),
            "cli_version": get_meta(conn, "cli_version"),
            "parser_version": get_meta(conn, "parser_version"),
            "project_root": get_meta(conn, "project_root") or project_root,
            "indexed_at": get_meta(conn, "indexed_at"),
            "lookup_bundle_hash": get_meta(conn, "lookup_bundle_hash"),
            "total_arquivos": get_meta(conn, "total_arquivos"),
            "total_chunks": get_meta(conn, "total_chunks"),
            "total_chamadas": get_meta(conn, "total_chamadas"),
            "total_lint_findings": get_meta(conn, "total_lint_findings"),
        }
    ]


def stale_files(
    conn: sqlite3.Connection, root_files: dict[str, int]
) -> list[dict[str, Any]]:
    """Lista arquivos cujo ``mtime_ns`` no DB difere do filesystem.

    Args:
        conn: conexão aberta.
        root_files: ``{basename: mtime_ns_atual}`` extraído via ``scan_sources``.
    """
    rows = conn.execute("SELECT arquivo, mtime_ns FROM fontes").fetchall()
    db_state = {a: int(m or 0) for a, m in rows}
    out: list[dict[str, Any]] = []
    for name, db_mtime in db_state.items():
        cur = root_files.get(name)
        if cur is None:
            out.append({"arquivo": name, "estado": "deleted", "db_mtime": db_mtime})
        elif cur > db_mtime:
            out.append(
                {
                    "arquivo": name,
                    "estado": "stale",
                    "db_mtime": db_mtime,
                    "fs_mtime": cur,
                }
            )
    for name, mtime in root_files.items():
        if name not in db_state:
            out.append({"arquivo": name, "estado": "new", "fs_mtime": mtime})
    return out


# v0.4.8: prefix (Static|User|Main) eh OPCIONAL — alinha com parser._FUNCTION_RE.
# Antes regex exigia prefixo e perdia TLPP-style `Function FooBar(...)` puro,
# causando funcs_real_bug FALSO POSITIVO (parser indexa correto, detector
# que estava contando menos).
_FN_RE_DOCTOR = re.compile(
    r"^[ \t]*(?:(?:Static|User|Main)[ \t]+)?Function[ \t]+\w+",
    re.IGNORECASE | re.MULTILINE,
)


def doctor_func_count_check(
    conn: sqlite3.Connection, root: Path, *, detail: bool = False
) -> list[dict[str, Any]]:
    """v0.4.6 (B) + v0.4.7 refinado: classifica discrepâncias em 2 buckets.

    Estratégia (v0.4.7): compara 3 contagens por arquivo:
      - ``grep_raw``: regex no conteúdo CRU (vê funções comentadas também)
      - ``grep_code``: regex no conteúdo STRIPADO (só funções em código real)
      - ``parser``: count em ``fonte_chunks`` (o que o parser indexou)

    Classificação:
      - ``real_bug``: ``grep_code > parser`` — parser perdeu função que está
        em código (bug do plugin)
      - ``commented_out``: ``grep_raw > grep_code == parser`` — funções dentro
        de ``/* ... */`` (intencional, não é bug)

    Slow (re-lê todos os fontes). Opt-in via ``doctor --check-funcs``.

    Returns:
        Lista de rows. Default (``detail=False``): 2 rows summary
        (``funcs_real_bug``, ``funcs_commented_out``). Com ``detail=True``:
        adiciona N rows ``funcs_detail`` (1 por fonte com discrepância),
        sem truncagem.
    """
    from plugadvpl.parsing.stripper import strip_advpl
    # Conta funcs no DB por arquivo (fonte_chunks com tipo_simbolo de function).
    parsed_by_file: dict[str, int] = {}
    for row in conn.execute(
        "SELECT arquivo, COUNT(*) FROM fonte_chunks "
        "WHERE tipo_simbolo IN ('function', 'user_function', 'static_function', 'main_function') "
        "GROUP BY arquivo"
    ):
        parsed_by_file[row[0]] = int(row[1])
    # Itera fontes pra grep + classificacao.
    real_bug_rows: list[tuple[str, int, int, int]] = []  # (arq, raw, code, parser)
    commented_rows: list[tuple[str, int, int, int]] = []
    for arq_row in conn.execute(
        "SELECT arquivo, caminho_relativo FROM fontes WHERE caminho_relativo IS NOT NULL"
    ):
        arquivo, caminho = arq_row[0], arq_row[1]
        if not caminho:
            continue
        fp = root / caminho
        if not fp.exists():
            continue
        try:
            raw = fp.read_bytes()
            content = raw.decode("cp1252", errors="replace")
        except OSError:
            continue
        grep_raw = len(_FN_RE_DOCTOR.findall(content))
        grep_code = len(_FN_RE_DOCTOR.findall(strip_advpl(content)))
        parsed_count = parsed_by_file.get(arquivo, 0)
        if grep_code != parsed_count:
            real_bug_rows.append((arquivo, grep_raw, grep_code, parsed_count))
        elif grep_raw != parsed_count:
            commented_rows.append((arquivo, grep_raw, grep_code, parsed_count))

    n_real = len(real_bug_rows)
    n_commented = len(commented_rows)
    rows: list[dict[str, Any]] = [
        {
            "check": "funcs_real_bug",
            "status": "ok" if n_real == 0 else "warn",
            "count": n_real,
            "detail": (
                "parser indexa toda função em código (ok)"
                if n_real == 0
                else "; ".join(
                    f"{arq} (em código={c} parser={p})"
                    for arq, _r, c, p in sorted(real_bug_rows)
                )
            ),
        },
        {
            "check": "funcs_commented_out",
            "status": "ok" if n_commented == 0 else "info",
            "count": n_commented,
            "detail": (
                "nenhum fonte com /* funcao */ comentada"
                if n_commented == 0
                else f"{n_commented} fontes com funções comentadas (intencional, não é bug)"
            ),
        },
    ]
    if detail:
        for arquivo, raw, code, parser in sorted(real_bug_rows + commented_rows):
            classificacao = "real_bug" if (arquivo, raw, code, parser) in real_bug_rows else "commented_out"
            # v0.4.9: preenche count + detail string pra render table mostrar
            # info util (renderer so conhece schema check/status/count/detail).
            # Colunas estruturais (arquivo/grep_raw/...) continuam pra JSON.
            rows.append({
                "check": "funcs_detail",
                "status": "warn" if classificacao == "real_bug" else "info",
                "count": raw - parser,
                "detail": (
                    f"{arquivo}: grep_raw={raw} grep_code={code} "
                    f"parser={parser} class={classificacao}"
                ),
                "arquivo": arquivo,
                "grep_raw": raw,
                "grep_code": code,
                "parser": parser,
                "classificacao": classificacao,
            })
    return rows


def doctor_diagnostics(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Diagnósticos de saúde do índice: encoding suspeito, órfãos, FTS sync."""
    diags: list[dict[str, Any]] = []

    # Encoding suspeito: arquivo sem encoding registrado.
    n_no_enc = conn.execute(
        "SELECT COUNT(*) FROM fontes WHERE coalesce(encoding, '') = ''"
    ).fetchone()[0]
    diags.append(
        {
            "check": "encoding_missing",
            "status": "ok" if n_no_enc == 0 else "warn",
            "count": n_no_enc,
            "detail": f"{n_no_enc} arquivos sem encoding em fontes.encoding",
        }
    )

    # Chunks órfãos: fonte_chunks.arquivo sem fontes correspondente.
    n_orphan = conn.execute(
        """
        SELECT COUNT(*) FROM fonte_chunks fc
        WHERE NOT EXISTS (SELECT 1 FROM fontes f WHERE f.arquivo = fc.arquivo)
        """
    ).fetchone()[0]
    diags.append(
        {
            "check": "orphan_chunks",
            "status": "ok" if n_orphan == 0 else "error",
            "count": n_orphan,
            "detail": f"{n_orphan} chunks sem registro em fontes",
        }
    )

    # FTS sync: count(fonte_chunks) vs count(fonte_chunks_fts).
    n_chunks = conn.execute("SELECT COUNT(*) FROM fonte_chunks").fetchone()[0]
    try:
        n_fts = conn.execute("SELECT COUNT(*) FROM fonte_chunks_fts").fetchone()[0]
    except sqlite3.OperationalError:
        n_fts = -1
    diags.append(
        {
            "check": "fts_sync",
            "status": "ok" if n_chunks == n_fts else "warn",
            "count": abs(n_chunks - n_fts),
            "detail": f"chunks={n_chunks} fts={n_fts}",
        }
    )

    # Lookups carregados.
    n_lookups = conn.execute("SELECT COUNT(*) FROM funcoes_nativas").fetchone()[0]
    diags.append(
        {
            "check": "lookups_loaded",
            "status": "ok" if n_lookups > 0 else "error",
            "count": n_lookups,
            "detail": f"funcoes_nativas: {n_lookups} rows",
        }
    )

    # v0.9.5 (QA PERF 2026-05-18 #2): colisao de basename em diretorios
    # distintos (ex: mod1/MATA010.prw vs mod2/MATA010.prw). Schema usa
    # basename como PK; sem aviso, o segundo era silenciosamente descartado.
    coll_row = conn.execute(
        "SELECT valor FROM meta WHERE chave='basename_collisions'"
    ).fetchone()
    coll_raw = (coll_row[0] if coll_row else "") or ""
    n_coll = 0
    coll_detail = "nenhuma colisao detectada"
    if coll_raw:
        try:
            coll_map = json.loads(coll_raw)
            n_coll = len(coll_map)
            if n_coll:
                preview = list(coll_map.keys())[:3]
                extra = sum(len(v) - 1 for v in coll_map.values())
                coll_detail = (
                    f"{n_coll} basenames duplicados ({extra} fontes ignorados); "
                    f"exemplos: {', '.join(preview)}"
                )
        except (ValueError, TypeError):
            coll_detail = "meta basename_collisions corrompido (JSON invalido)"
    diags.append(
        {
            "check": "basename_collisions",
            "status": "ok" if n_coll == 0 else "warn",
            "count": n_coll,
            "detail": coll_detail,
        }
    )

    return diags


def grep_fts(
    conn: sqlite3.Connection,
    pattern: str,
    mode: str = "fts",
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Busca textual em três modos.

    - ``fts`` (default): MATCH em ``fonte_chunks_fts`` (tokenize unicode61). Bom
      para identificadores e palavras inteiras. Aceita sintaxe FTS5
      (``"foo bar"``, ``foo OR bar``).
    - ``literal``: substring case-sensitive via ``LIKE`` em
      ``fonte_chunks.content``. Lento mas exato (incluindo pontuação ADVPL).
    - ``identifier``: busca case-insensitive de identificador, removendo
      prefixo ``U_`` quando presente.
    """
    if mode == "fts":
        sql = """
        SELECT fc.arquivo, fc.funcao,
               snippet(fonte_chunks_fts, 2, '[', ']', '...', 16) AS snippet
        FROM fonte_chunks_fts
        JOIN fonte_chunks fc ON fc.rowid = fonte_chunks_fts.rowid
        WHERE fonte_chunks_fts MATCH ?
        LIMIT ?
        """
        rows = conn.execute(sql, (pattern, limit)).fetchall()
    elif mode == "literal":
        # v0.9.2 (QA PERF #1): pré-filtra via FTS5 trigram (`fonte_chunks_fts_tri`,
        # migration 001) pra evitar full table scan, então aplica LIKE pra
        # garantir case-sensitivity exata. Trigram precisa de pattern ≥3 chars;
        # menor que isso volta pro LIKE puro (sem ganho de trigram).
        # Speedup típico em base ~2k fontes: 10-50× em buscas com 3+ chars únicos.
        if len(pattern) >= 3:
            fts_pattern = '"' + pattern.replace('"', '""') + '"'
            sql = """
            SELECT fc.arquivo, fc.funcao,
                   substr(fc.content,
                          max(1, instr(fc.content, ?) - 30),
                          200) AS snippet
            FROM fonte_chunks_fts_tri t
            JOIN fonte_chunks fc ON fc.rowid = t.rowid
            WHERE fonte_chunks_fts_tri MATCH ?
              AND fc.content LIKE '%' || ? || '%'
            LIMIT ?
            """
            try:
                rows = conn.execute(
                    sql, (pattern, fts_pattern, pattern, limit),
                ).fetchall()
            except sqlite3.OperationalError:
                # Fallback se trigram FTS estiver indisponível (DB antigo
                # ou pattern com sintaxe FTS5 inválida que escapou do quote).
                rows = conn.execute(
                    """
                    SELECT arquivo, funcao,
                           substr(content,
                                  max(1, instr(content, ?) - 30),
                                  200) AS snippet
                    FROM fonte_chunks
                    WHERE content LIKE '%' || ? || '%'
                    LIMIT ?
                    """,
                    (pattern, pattern, limit),
                ).fetchall()
        else:
            sql = """
            SELECT arquivo, funcao,
                   substr(content,
                          max(1, instr(content, ?) - 30),
                          200) AS snippet
            FROM fonte_chunks
            WHERE content LIKE '%' || ? || '%'
            LIMIT ?
            """
            rows = conn.execute(sql, (pattern, pattern, limit)).fetchall()
    else:  # identifier
        normalized = pattern.upper()
        if normalized.startswith("U_"):
            normalized = normalized[2:]
        sql = """
        SELECT arquivo, funcao, substr(content, 1, 200) AS snippet
        FROM fonte_chunks
        WHERE upper(content) LIKE '%' || ? || '%'
        LIMIT ?
        """
        rows = conn.execute(sql, (normalized, limit)).fetchall()
    cols = ["arquivo", "funcao", "snippet"]
    return [dict(zip(cols, r, strict=True)) for r in rows]


def _json_or_default(raw: str | None, default: Any) -> Any:
    """Desserializa JSON do DB ou retorna ``default`` em caso de erro/vazio."""
    if not raw:
        return default
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return default


# ---------------------------------------------------------------------------
# v0.3.0 — Universo 2: queries do dicionário SX (impacto + gatilho)
# ---------------------------------------------------------------------------


def _sx_tables_present(conn: sqlite3.Connection) -> bool:
    """Sentinela: ``True`` se migration 002 já criou as tabelas do dicionário SX."""
    row = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='campos'"
    ).fetchone()
    return row is not None


def _truncate(text: str | None, max_len: int = 80) -> str:
    """Trunca strings para snippet display (impacto/gatilho)."""
    if not text:
        return ""
    text = " ".join(text.split())  # collapse whitespace
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"


_WRITE_KEYWORDS = ("RECLOCK", "REPLACE", "UPDATE ", "INSERT ", "MSEXECAUTO")


def _word_boundary_re(termo: str) -> re.Pattern[str]:
    """Regex `\\b<TERMO>\\b` case-insensitive — boundary ADVPL-aware.

    Em ADVPL nomes de campo são tipo `A1_COD`, `BA1_CODEMP`. `\\b` em Python
    não trata `_` como boundary (`_` é `\\w`), então `\\bA1_COD\\b` NÃO casa
    em `BA1_COD` (B+A1_COD = continuação \\w) nem em `A1_CODFAT` (CO+DF =
    continuação \\w). Exatamente o comportamento desejado pra eliminar falsos
    positivos do `impacto` (v0.3.17 #3 do QA report).
    """
    return re.compile(r"\b" + re.escape(termo) + r"\b", re.IGNORECASE)


def _impacto_fontes(
    conn: sqlite3.Connection, campo_up: str, max_rows: int
) -> list[dict[str, Any]]:
    """Hits no índice de fontes (fonte_chunks.content).

    v0.9.5 (QA V3 #3 / QA PERF 2026-05-18 #8): aplica boundary check pos-LIKE
    em Python pra eliminar substring FPs. Antes ``impacto A1_COD`` retornava
    >100KB de output com hits espurios em ``BA1_CODEMP``, ``A1_CODFAT``,
    ``DA1_CODPRO``. Agora SQL LIKE prefiltra (cheap), Python boundary
    elimina FP, e o snippet e construido ao redor do match REAL — nao da
    primeira ocorrencia substring (que podia ser o proprio FP).
    """
    out: list[dict[str, Any]] = []
    boundary_re = _word_boundary_re(campo_up)
    # 4x buffer pra absorver descartes do boundary check sem ficar abaixo
    # do max_rows desejado em projetos com muitos FPs (campos de prefixo
    # comum tipo A1_*, B1_*).
    rows = conn.execute(
        """
        SELECT arquivo, funcao, linha_inicio, content
        FROM fonte_chunks
        WHERE upper(content) LIKE '%' || ? || '%'
        LIMIT ?
        """,
        (campo_up, max_rows * 4),
    ).fetchall()
    for arquivo, funcao, linha, content in rows:
        if not content:
            continue
        # Re-find primeiro boundary REAL (nao a primeira substring SQL).
        m = boundary_re.search(content)
        if m is None:
            continue  # substring FP — BA1_CODEMP, A1_CODFAT, etc.
        pos = m.start()
        snippet = content[max(0, pos - 30): pos + 130]
        snip_up = snippet.upper()
        is_write = any(k in snip_up for k in _WRITE_KEYWORDS)
        out.append(
            {
                "tipo": "fonte",
                "match_kind": "boundary",
                "local": f"{arquivo}:{linha or 1}::{funcao or ''}",
                "contexto": _truncate(snippet, 100),
                "severidade": "critical" if is_write else "warning",
            }
        )
        if len(out) >= max_rows:
            break
    return out


def _impacto_sx3(
    conn: sqlite3.Connection, campo_up: str, max_rows: int
) -> list[dict[str, Any]]:
    """Hits em SX3: registro próprio + campos com VALID/INIT/WHEN/VLDUSER referenciando."""
    out: list[dict[str, Any]] = []
    own = conn.execute(
        "SELECT tabela, campo, tipo, tamanho, descricao FROM campos "
        "WHERE upper(campo) = ?",
        (campo_up,),
    ).fetchone()
    if own:
        out.append(
            {
                "tipo": "SX3",
                "local": f"{own[0]}.{own[1]}",
                "contexto": _truncate(f"{own[2]}({own[3]}) {own[4]}", 100),
                "severidade": "warning",
            }
        )
    # SQL faz prefiltro com LIKE (cheap, narrows candidates). Boundary check
    # acontece em Python pra eliminar falsos positivos de substring (v0.3.17 #3).
    sx3_refs = conn.execute(
        """
        SELECT tabela, campo, validacao, vlduser, when_expr, inicializador
        FROM campos
        WHERE upper(validacao)     LIKE '%' || ? || '%'
           OR upper(vlduser)       LIKE '%' || ? || '%'
           OR upper(when_expr)     LIKE '%' || ? || '%'
           OR upper(inicializador) LIKE '%' || ? || '%'
        LIMIT ?
        """,
        (campo_up, campo_up, campo_up, campo_up, max_rows),
    ).fetchall()
    boundary = _word_boundary_re(campo_up)
    for tabela, c, valid, vld, wh, init in sx3_refs:
        if c.upper() == campo_up:
            continue
        bits: list[str] = []
        if valid and boundary.search(valid):
            bits.append(f"VALID={_truncate(valid, 40)}")
        if vld and boundary.search(vld):
            bits.append(f"VLDUSER={_truncate(vld, 40)}")
        if wh and boundary.search(wh):
            bits.append(f"WHEN={_truncate(wh, 40)}")
        if init and boundary.search(init):
            bits.append(f"INIT={_truncate(init, 40)}")
        if not bits:
            # SQL casou via substring mas nenhum campo tem o termo com boundary —
            # falso positivo, pular.
            continue
        out.append(
            {
                "tipo": "SX3",
                "local": f"{tabela}.{c}",
                "contexto": _truncate(" | ".join(bits), 100),
                "severidade": "warning",
            }
        )
    return out


def _impacto_sx7_chain(
    conn: sqlite3.Connection, campo_up: str, depth: int, max_per_kind: int
) -> list[dict[str, Any]]:
    """Cadeia SX7 com BFS até ``depth`` níveis."""
    out: list[dict[str, Any]] = []
    visited: set[str] = {campo_up}
    frontier: list[str] = [campo_up]
    # SQL prefiltra via LIKE (cheap); Python re-valida boundary pra eliminar
    # falsos positivos como BA1_CODEMP/A1_CODFAT batendo em busca de A1_COD
    # (v0.3.17 #3 do QA report — caso real: >100KB de output em campo curto).
    for level in range(1, max(1, min(depth, 3)) + 1):
        next_frontier: list[str] = []
        for orig in frontier:
            sx7_rows = conn.execute(
                """
                SELECT campo_origem, sequencia, campo_destino, regra, condicao, tipo
                FROM gatilhos
                WHERE upper(campo_origem) = ?
                   OR upper(regra)        LIKE '%' || ? || '%'
                   OR upper(condicao)     LIKE '%' || ? || '%'
                LIMIT ?
                """,
                (orig, orig, orig, max_per_kind),
            ).fetchall()
            boundary = _word_boundary_re(orig)
            for co, seq, cd, regra, cond, tp in sx7_rows:
                # Aceita se: origem eh exatamente o termo (match SQL exato),
                # OU regra/cond contem o termo com word boundary.
                origem_match = (co or "").upper() == orig
                regra_match = bool(regra and boundary.search(regra))
                cond_match = bool(cond and boundary.search(cond))
                if not (origem_match or regra_match or cond_match):
                    continue
                ctx_parts = [f"depth={level}", f"tipo={tp or '?'}"]
                if regra:
                    ctx_parts.append(f"regra={_truncate(regra, 30)}")
                if cond:
                    ctx_parts.append(f"cond={_truncate(cond, 25)}")
                out.append(
                    {
                        "tipo": "SX7",
                        "local": f"{co}#{seq} -> {cd or '(s/destino)'}",
                        "contexto": _truncate(" | ".join(ctx_parts), 100),
                        "severidade": "critical",
                    }
                )
                if cd and cd.upper() not in visited:
                    visited.add(cd.upper())
                    next_frontier.append(cd.upper())
        frontier = next_frontier
        if not frontier:
            break
    return out


def _impacto_sx1(
    conn: sqlite3.Connection, campo_up: str, max_rows: int
) -> list[dict[str, Any]]:
    """Hits em SX1: validacao ou conteudo_padrao referenciando o campo."""
    out: list[dict[str, Any]] = []
    rows = conn.execute(
        """
        SELECT grupo, ordem, pergunta, validacao, conteudo_padrao
        FROM perguntas
        WHERE upper(validacao)       LIKE '%' || ? || '%'
           OR upper(conteudo_padrao) LIKE '%' || ? || '%'
        LIMIT ?
        """,
        (campo_up, campo_up, max_rows),
    ).fetchall()
    boundary = _word_boundary_re(campo_up)
    for grupo, ordem, perg, val, cont in rows:
        bits: list[str] = []
        if val and boundary.search(val):
            bits.append(f"VALID={_truncate(val, 40)}")
        if cont and boundary.search(cont):
            bits.append(f"DEF={_truncate(cont, 40)}")
        if not bits:
            continue  # SQL casou via substring mas sem boundary — falso positivo.
        out.append(
            {
                "tipo": "SX1",
                "local": f"{grupo}#{ordem}",
                "contexto": _truncate(f"{perg} | {' | '.join(bits)}", 100),
                "severidade": "warning",
            }
        )
    return out


def impacto_query(
    conn: sqlite3.Connection,
    campo: str,
    *,
    depth: int = 1,
    max_per_kind: int = 50,
) -> list[dict[str, Any]]:
    """Cruza referências a ``campo`` em fontes <-> SX3 <-> SX7 <-> SX1.

    Args:
        conn: conexão SQLite (RO ok).
        campo: nome do campo (ex: ``A1_COD``, case-insensitive).
        depth: profundidade da cadeia de gatilhos a seguir (1..3). Default 1
            = só gatilhos onde ``campo_origem == campo``. ``depth=2`` segue
            também os destinos desses gatilhos como novas origens.
        max_per_kind: máximo de hits por tipo (fonte/SX3/SX7/SX1) — defesa
            contra campos muito comuns (ex: A1_FILIAL) explodirem o output.

    Returns:
        Lista de dicts ``{tipo, local, contexto, severidade}`` ordenada por
        ``severidade`` (critico/error/warning) e ``tipo``. Vazia se ``campo``
        não tem referência alguma OU se o dicionário SX ainda não foi ingerido.
    """
    campo_up = campo.upper().strip()
    if not campo_up:
        return []

    out = _impacto_fontes(conn, campo_up, max_per_kind)
    if _sx_tables_present(conn):
        out.extend(_impacto_sx3(conn, campo_up, max_per_kind))
        out.extend(_impacto_sx7_chain(conn, campo_up, depth, max_per_kind))
        out.extend(_impacto_sx1(conn, campo_up, max_per_kind))

    out.sort(key=lambda r: (_severity_rank(r["severidade"]), r["tipo"], r["local"]))
    return out


def _severity_rank(sev: str) -> int:
    """Ordem para sort: critical < error < warning < info < unknown."""
    return {"critical": 0, "error": 1, "warning": 2, "info": 3}.get(sev, 4)


def gatilho_query(
    conn: sqlite3.Connection,
    campo: str,
    *,
    depth: int = 3,
    max_rows: int = 100,
) -> list[dict[str, Any]]:
    """Lista cadeia de gatilhos SX7 originados/destinados ao ``campo``.

    Cada row representa um gatilho na cadeia: ``{nivel, origem, destino, regra,
    condicao, tipo}``. Recursivo: o destino do nível N vira origem do nível N+1.

    Args:
        conn: conexão SQLite.
        campo: nome do campo (case-insensitive).
        depth: profundidade máxima (1..3). Default 3.
        max_rows: corte defensivo no total de rows retornadas.
    """
    if not _sx_tables_present(conn):
        return []
    campo_up = campo.upper().strip()
    if not campo_up:
        return []
    out: list[dict[str, Any]] = []
    visited: set[str] = {campo_up}
    frontier: list[tuple[str, str]] = [(campo_up, "raiz")]
    for level in range(1, max(1, min(depth, 3)) + 1):
        next_frontier: list[tuple[str, str]] = []
        for origem, parent in frontier:
            # v0.3.15 (#4 do QA report): help diz "originados/destinados" mas a
            # query so casava origem. Agora cobre ambos os lados — campos que
            # apenas RECEBEM gatilhos (chaves geradas, p.ex.) ficavam invisiveis.
            rows = conn.execute(
                """
                SELECT campo_origem, sequencia, campo_destino, regra, condicao,
                       tipo, alias, seek
                FROM gatilhos
                WHERE upper(campo_origem) = ? OR upper(campo_destino) = ?
                ORDER BY sequencia
                """,
                (origem, origem),
            ).fetchall()
            for co, seq, cd, regra, cond, tp, alias, seek in rows:
                if len(out) >= max_rows:
                    break
                out.append(
                    {
                        "nivel": level,
                        "origem": co,
                        "sequencia": seq,
                        "destino": cd,
                        "regra": _truncate(regra, 60),
                        "condicao": _truncate(cond, 40),
                        "tipo": tp,
                        "alias": alias,
                        "seek": seek,
                        "via": parent if level > 1 else "",
                    }
                )
                # v0.3.22 (#6 do QA round 2): traversal bidirecional. Antes
                # so adicionava cd (downstream); rows que casavam via
                # campo_destino tinham co (upstream) ignorado, matando a
                # cadeia inversa em level 1. Agora ambos viram frontier
                # do proximo nivel — visited evita loop infinito em ciclos.
                if cd and cd.upper() not in visited:
                    visited.add(cd.upper())
                    next_frontier.append((cd.upper(), f"{co}#{seq}"))
                if co and co.upper() not in visited:
                    visited.add(co.upper())
                    next_frontier.append((co.upper(), f"{co}#{seq}"))
            if len(out) >= max_rows:
                break
        frontier = next_frontier
        if not frontier or len(out) >= max_rows:
            break
    return out


_SX_STATUS_TABLES = (
    "tabelas", "campos", "indices", "gatilhos", "parametros",
    "perguntas", "tabelas_genericas", "relacionamentos", "pastas",
    "consultas", "grupos_campo",
)


def sx_status(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Resumo do dicionário SX ingerido: counts por tabela + ``last_sx_ingest_at``.

    v0.3.22 (#16 do QA round 2): schema consistente — sempre retorna o mesmo
    set de keys, com `sx_ingerido=False` + counts zerados quando ainda nao
    foi rodado o `ingest-sx`. Antes mudavam de 2 keys (ausente) pra 14 keys
    (presente), forcando caller a branchear no `--format json`.
    """
    sx_present = _sx_tables_present(conn)
    out: dict[str, Any] = {
        "sx_ingerido": sx_present,
        "last_sx_ingest_at": get_meta(conn, "last_sx_ingest_at") if sx_present else None,
        "sx_csv_dir": get_meta(conn, "sx_csv_dir") if sx_present else None,
        "msg": None if sx_present else "Rode 'plugadvpl ingest-sx <dir>' primeiro.",
    }
    for table in _SX_STATUS_TABLES:
        if sx_present:
            out[table] = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        else:
            out[table] = 0
    return [out]


# v0.4.0 (Universo 3 Feature A) -----------------------------------------------


_EXEC_TRIGGER_KINDS = {
    "workflow", "wf_callback", "schedule", "job_standalone", "mail_send"
}  # v0.4.6 (F): wf_callback separado de workflow


def execauto_top_modulos(conn: sqlite3.Connection, n: int = 5) -> list[str]:
    """v0.4.6 (E): top-N módulos no índice execauto_calls (mais usados).

    Usado pra sugerir alternativas quando filtro ``--modulo`` retorna vazio.
    """
    rows = conn.execute(
        "SELECT module, COUNT(*) AS c FROM execauto_calls "
        "WHERE module IS NOT NULL AND module != '' "
        "GROUP BY module ORDER BY c DESC LIMIT ?",
        (n,),
    ).fetchall()
    return [r[0] for r in rows]


def protheus_docs_top_modulos(conn: sqlite3.Connection, n: int = 5) -> list[str]:
    """v0.4.6 (E): top-N módulos no índice protheus_docs."""
    rows = conn.execute(
        "SELECT module_inferido, COUNT(*) AS c FROM protheus_docs "
        "WHERE module_inferido IS NOT NULL AND module_inferido != '' "
        "GROUP BY module_inferido ORDER BY c DESC LIMIT ?",
        (n,),
    ).fetchall()
    return [r[0] for r in rows]


def execution_triggers_duplicates(
    conn: sqlite3.Connection,
    *,
    kind: str | None = None,
) -> list[dict[str, Any]]:
    """v0.4.6 (K): lista targets compartilhados entre fontes diferentes.

    Útil pra detectar erros de design — ex.: 2 TWFProcess em fontes
    distintos com mesmo process_id. Sem trigger duplicates a colisão fica
    silenciosa no índice; aqui ela vira finding explícito.

    Returns:
        Lista de dicts ordenada por count desc:
        ``{kind, target, count, arquivos: list[str]}``.
        Só inclui rows com count >= 2 e target não-vazio.
    """
    sql = (
        "SELECT kind, target, COUNT(DISTINCT arquivo) AS n, "
        "GROUP_CONCAT(DISTINCT arquivo) AS arqs "
        "FROM execution_triggers "
        "WHERE target IS NOT NULL AND target != ''"
    )
    params: list[Any] = []
    if kind:
        if kind not in _EXEC_TRIGGER_KINDS:
            return []
        sql += " AND kind = ?"
        params.append(kind)
    sql += " GROUP BY kind, target HAVING n >= 2 ORDER BY n DESC, kind, target"
    rows = conn.execute(sql, params).fetchall()
    out: list[dict[str, Any]] = []
    for k, tgt, n, arqs in rows:
        arquivos_list = sorted((arqs or "").split(",")) if arqs else []
        out.append({
            "kind": k,
            "target": tgt,
            "count": int(n),
            "arquivos": arquivos_list,
        })
    return out


def execution_triggers_query(
    conn: sqlite3.Connection,
    *,
    kind: str | None = None,
    target: str | None = None,
    arquivo: str | None = None,
) -> list[dict[str, Any]]:
    """Lista execution_triggers indexados (Universo 3 Feature A).

    Args:
        conn: conexão SQLite.
        kind: filtra por tipo (`workflow`/`schedule`/`job_standalone`/`mail_send`).
        target: filtra por nome alvo (case-insensitive, exact match).
        arquivo: filtra por arquivo (case-insensitive, exact match).

    Returns:
        Lista de dicts com `arquivo`, `funcao`, `linha`, `kind`, `target`,
        `metadata` (parsed do JSON), `snippet`.
    """
    sql = "SELECT arquivo, funcao, linha, kind, target, metadata_json, snippet FROM execution_triggers"
    where: list[str] = []
    params: list[Any] = []
    if kind:
        if kind not in _EXEC_TRIGGER_KINDS:
            return []
        where.append("kind = ?")
        params.append(kind)
    if target:
        where.append("upper(target) = upper(?)")
        params.append(target)
    if arquivo:
        where.append("arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY arquivo, linha"
    rows = conn.execute(sql, params).fetchall()
    out: list[dict[str, Any]] = []
    for arq, fn, ln, k, tgt, meta_json, snippet in rows:
        # Lazy import pra não criar ciclo plugadvpl.query → plugadvpl.parsing.
        from plugadvpl.parsing.triggers import parse_metadata
        out.append({
            "arquivo": arq,
            "funcao": fn or "",
            "linha": int(ln or 0),
            "kind": k,
            "target": tgt or "",
            "metadata": parse_metadata(meta_json or "{}"),
            "snippet": snippet or "",
        })
    return out


_EXECAUTO_OP_MAP = {
    "inc": 3, "inclusao": 3, "include": 3,
    "alt": 4, "alteracao": 4, "alter": 4,
    "exc": 5, "exclusao": 5, "exclude": 5, "delete": 5,
}


def execauto_calls_query(
    conn: sqlite3.Connection,
    *,
    routine: str | None = None,
    modulo: str | None = None,
    arquivo: str | None = None,
    op: str | None = None,
    dynamic: bool | None = None,
    op_dynamic: bool | None = None,
) -> list[dict[str, Any]]:
    """Lista chamadas MsExecAuto resolvidas (Universo 3 Feature B).

    Args:
        conn: conexão SQLite.
        routine: filtra por rotina (`MATA410` etc, case-insensitive).
        modulo: filtra por módulo (`SIGAFAT` etc, case-insensitive).
        arquivo: filtra por arquivo (basename).
        op: filtra por operação (`inc`/`alt`/`exc` ou full `inclusao`/...).
        dynamic: True = só dynamic_call, False = só resolved, None = ambos.
        op_dynamic: v0.4.6 (C) — True = só calls com op_code via variável
            ou expressão (não literal); False = só com literal; None = ambos.

    Returns:
        Lista de dicts com campos do schema `execauto_calls` + `tables_resolved`
        já parseado para list[str].
    """
    sql = (
        "SELECT arquivo, funcao, linha, routine, module, routine_type, "
        "op_code, op_label, tables_resolved_json, dynamic_call, arg_count, snippet, "
        "op_dynamic "
        "FROM execauto_calls"
    )
    where: list[str] = []
    params: list[Any] = []
    if routine:
        where.append("upper(routine) = upper(?)")
        params.append(routine)
    if modulo:
        where.append("upper(module) = upper(?)")
        params.append(modulo)
    if arquivo:
        where.append("arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if op:
        op_norm = _EXECAUTO_OP_MAP.get(op.lower())
        if op_norm is None:
            return []
        where.append("op_code = ?")
        params.append(op_norm)
    if dynamic is not None:
        where.append("dynamic_call = ?")
        params.append(1 if dynamic else 0)
    if op_dynamic is not None:
        where.append("op_dynamic = ?")
        params.append(1 if op_dynamic else 0)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY arquivo, linha"
    rows = conn.execute(sql, params).fetchall()
    out: list[dict[str, Any]] = []
    for (
        arq, fn, ln, rt, mod, rtype, opc, oplbl, tjson, dyn, argc, snippet, opdyn
    ) in rows:
        from plugadvpl.parsing.execauto import parse_tables
        out.append({
            "arquivo": arq,
            "funcao": fn or "",
            "linha": int(ln or 0),
            "routine": rt,
            "module": mod,
            "routine_type": rtype,
            "op_code": opc,
            "op_label": oplbl,
            "tables_resolved": parse_tables(tjson),
            "dynamic_call": bool(dyn),
            "op_dynamic": bool(opdyn),
            "arg_count": argc,
            "snippet": snippet or "",
        })
    return out


def arch_execauto_tables(
    conn: sqlite3.Connection, arquivo: str
) -> list[str]:
    """Tabelas inferidas via ExecAuto pra um fonte (cross-ref Feature B).

    Retorna lista únicos+ordenada de tables_resolved de todas as chamadas
    `execauto_calls` daquele `arquivo`.
    """
    rows = conn.execute(
        "SELECT tables_resolved_json FROM execauto_calls WHERE arquivo = ? COLLATE NOCASE",
        (arquivo,),
    ).fetchall()
    from plugadvpl.parsing.execauto import parse_tables
    seen: set[str] = set()
    for (tjson,) in rows:
        for t in parse_tables(tjson):
            seen.add(t)
    return sorted(seen)


# v0.4.2 — Universo 3 / Feature C: Protheus.doc agregado.

_PDOC_COLUMNS = (
    "arquivo, funcao, funcao_id, tipo, module_inferido, "
    "linha_bloco_inicio, linha_bloco_fim, linha_funcao, "
    "summary, description, author, since, version, "
    "deprecated, deprecated_reason, language, "
    "params_json, returns_json, examples_json, history_json, "
    "see_json, tables_json, todos_json, obs_json, links_json, "
    "raw_tags_json"
)


def _row_to_pdoc(row: tuple[Any, ...]) -> dict[str, Any]:
    """Converte row do SELECT em dict com JSONs já parseados."""
    from plugadvpl.parsing.protheus_doc import parse_json_dict, parse_json_list
    (
        arq, fn, fn_id, tipo, modulo, lb_ini, lb_fim, lf,
        summary, descr, author, since, version,
        dep, dep_reason, lang,
        params_json, returns_json, examples_json, history_json,
        see_json, tables_json, todos_json, obs_json, links_json,
        raw_tags_json,
    ) = row
    return {
        "arquivo": arq,
        "funcao": fn,
        "funcao_id": fn_id,
        "tipo": tipo,
        "module_inferido": modulo,
        "linha_bloco_inicio": int(lb_ini or 0),
        "linha_bloco_fim": int(lb_fim or 0),
        "linha_funcao": lf,
        "summary": summary,
        "description": descr,
        "author": author,
        "since": since,
        "version": version,
        "deprecated": bool(dep),
        "deprecated_reason": dep_reason,
        "language": lang,
        "params": parse_json_list(params_json),
        "returns": parse_json_list(returns_json),
        "examples": parse_json_list(examples_json),
        "history": parse_json_list(history_json),
        "see": parse_json_list(see_json),
        "tables": parse_json_list(tables_json),
        "todos": parse_json_list(todos_json),
        "obs": parse_json_list(obs_json),
        "links": parse_json_list(links_json),
        "raw_tags": parse_json_dict(raw_tags_json),
    }


def protheus_docs_query(
    conn: sqlite3.Connection,
    *,
    modulo: str | None = None,
    author: str | None = None,
    funcao: str | None = None,
    arquivo: str | None = None,
    deprecated: bool | None = None,
    tipo: str | None = None,
) -> list[dict[str, Any]]:
    """Lista blocos Protheus.doc indexados (Universo 3 Feature C).

    Args:
        conn: conexão SQLite.
        modulo: filtra por módulo inferido (`SIGAFAT`, ...). Case-insensitive.
        author: filtra por autor (LIKE %valor%, case-insensitive).
        funcao: filtra por nome de função (case-insensitive, exact match).
        arquivo: filtra por basename (case-insensitive).
        deprecated: True = só deprecated; False = só ativos; None = ambos.
        tipo: filtra por @type (`function`, `method`, etc).

    Returns:
        Lista de dicts com TODOS os campos do schema (JSONs já parseados).
    """
    sql = f"SELECT {_PDOC_COLUMNS} FROM protheus_docs"
    where: list[str] = []
    params: list[Any] = []
    if modulo:
        where.append("upper(module_inferido) = upper(?)")
        params.append(modulo)
    if author:
        where.append("author LIKE ? COLLATE NOCASE")
        params.append(f"%{author}%")
    if funcao:
        # v0.4.4 (BUG #2): fallback pra funcao_id quando a coluna funcao
        # ficou NULL (ex.: bloco órfão, ou DB indexado em versão antiga
        # que não conhecia WSSTRUCT/WSSERVICE/etc).
        where.append("(funcao = ? COLLATE NOCASE OR funcao_id = ? COLLATE NOCASE)")
        params.extend([funcao, funcao])
    if arquivo:
        where.append("arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if deprecated is not None:
        where.append("deprecated = ?")
        params.append(1 if deprecated else 0)
    if tipo:
        where.append("lower(tipo) = lower(?)")
        params.append(tipo)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY module_inferido, arquivo, linha_bloco_inicio"
    rows = conn.execute(sql, params).fetchall()
    return [_row_to_pdoc(r) for r in rows]


def protheus_docs_orphans(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """Funções sem header Protheus.doc (cross-ref com BP-007 do lint).

    Estratégia: lista findings BP-007 do `lint_findings`. Cada finding já
    aponta a função sem header. Mais rápido que JOIN com `simbolos`.
    """
    rows = conn.execute(
        """
        SELECT arquivo, funcao, linha, snippet
        FROM lint_findings
        WHERE regra_id = 'BP-007'
        ORDER BY arquivo, linha
        """
    ).fetchall()
    return [
        {
            "arquivo": arq,
            "funcao": fn,
            "linha": int(ln or 0),
            "snippet": snippet or "",
        }
        for arq, fn, ln, snippet in rows
    ]


def protheus_doc_show(
    conn: sqlite3.Connection,
    funcao: str,
    *,
    arquivo: str | None = None,
) -> dict[str, Any] | None:
    """Retorna doc completo de uma função (modo `--show`).

    v0.4.3 (I2): aceita ``arquivo`` opcional pra desambiguar quando há
    homônimos. Caller pode usar :func:`protheus_doc_homonyms` antes pra
    detectar e listar opções.

    v0.4.4 (BUG #2): match também via ``funcao_id`` quando coluna ``funcao``
    está NULL (DBs antigos com WSSTRUCT/WSSERVICE não-resolvidos, ou
    blocos órfãos cuja decl seguinte ficou > 80 linhas adiante).
    """
    sql = (
        f"SELECT {_PDOC_COLUMNS} FROM protheus_docs "
        "WHERE (funcao = ? COLLATE NOCASE OR funcao_id = ? COLLATE NOCASE)"
    )
    params: list[Any] = [funcao, funcao]
    if arquivo:
        sql += " AND arquivo = ? COLLATE NOCASE"
        params.append(arquivo)
    sql += " ORDER BY arquivo, linha_bloco_inicio LIMIT 1"
    row = conn.execute(sql, params).fetchone()
    if row is None:
        return None
    return _row_to_pdoc(row)


def protheus_doc_homonyms(
    conn: sqlite3.Connection, funcao: str
) -> list[str]:
    """v0.4.3 (I2): lista arquivos com Protheus.doc pra ``funcao``.

    Usado por `docs --show` pra avisar quando há ambiguidade. Retorna lista
    ordenada de basenames.

    v0.4.4 (BUG #2): match também via ``funcao_id`` (cobertura de blocos
    órfãos e WS constructs em DBs antigos).
    """
    rows = conn.execute(
        "SELECT DISTINCT arquivo FROM protheus_docs "
        "WHERE funcao = ? COLLATE NOCASE OR funcao_id = ? COLLATE NOCASE "
        "ORDER BY arquivo",
        (funcao, funcao),
    ).fetchall()
    return [r[0] for r in rows]


def render_pdoc_markdown(d: dict[str, Any]) -> str:
    """Renderiza um doc em Markdown estruturado pra modo `--show`."""
    lines: list[str] = []
    title = d.get("funcao") or d.get("funcao_id") or "(sem nome)"
    modulo = d.get("module_inferido")
    tipo = d.get("tipo")
    header = f"## {title}"
    if modulo:
        header += f" ({modulo})"
    if tipo:
        header += f" — `@type {tipo}`"
    lines.append(header)
    if d.get("deprecated"):
        reason = d.get("deprecated_reason") or "sem motivo"
        lines.append(f"\n> ⚠️ **DEPRECATED** — {reason}\n")
    if d.get("summary"):
        lines.append("")
        lines.append(d["summary"])
    if d.get("description"):
        lines.append("")
        lines.append(d["description"])
    meta_parts: list[str] = []
    for key in ("author", "since", "version", "language"):
        if d.get(key):
            meta_parts.append(f"**{key.title()}:** {d[key]}")
    if meta_parts:
        lines.append("")
        lines.append("  ".join(meta_parts))
    if d.get("params"):
        lines.append("\n### Parâmetros")
        lines.append("| name | type | optional | desc |")
        lines.append("|------|------|----------|------|")
        for p in d["params"]:
            lines.append(
                f"| `{p.get('name') or ''}` | {p.get('type') or ''} | "
                f"{'sim' if p.get('optional') else 'não'} | {p.get('desc') or ''} |"
            )
    if d.get("returns"):
        lines.append("\n### Retorno")
        for r in d["returns"]:
            t = r.get("type") or ""
            desc = r.get("desc") or ""
            lines.append(f"- `{t}` — {desc}")
    if d.get("examples"):
        lines.append("\n### Exemplos")
        for ex in d["examples"]:
            lines.append("```advpl")
            lines.append(ex)
            lines.append("```")
    if d.get("see"):
        lines.append("\n**See:** " + ", ".join(d["see"]))
    if d.get("tables"):
        lines.append("\n**Tables:** " + ", ".join(d["tables"]))
    if d.get("history"):
        lines.append("\n### Histórico")
        for h in d["history"]:
            lines.append(
                f"- {h.get('date') or ''} ({h.get('user') or ''}): {h.get('desc') or ''}"
            )
    location = f"\n_Source: {d.get('arquivo')}:{d.get('linha_bloco_inicio')}-{d.get('linha_bloco_fim')}_"
    lines.append(location)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# v0.5.0 — Universo 4 / Feature A: trace unificado
# ---------------------------------------------------------------------------

# v0.5.1 (#2 fallback): regex de tabela ampliado pra cobrir todos os módulos
# Protheus (Comex EE*, GFE DA*/DAI/GV4, custom Z*, auxiliares CCH/C09, etc.).
# Antes [SZNQD] hardcoded perdia ~30 prefixos válidos. Agora: 3 chars uppercase,
# letra inicial + 2 alfanum. Conn-based lookup (em _detect_entity_type_db) tem
# precedência quando disponível.
_TABLE_RE = re.compile(r"^[A-Z][A-Z0-9]{2}$", re.IGNORECASE)
# v0.5.1 (#1): regex de campo aceita 2 OU 3 chars antes do `_`.
# Antes `[A-Z]\d_...` forçava letra+dígito (só 2 chars). Agora aceita
# `EE7_ZSUBEX`/`DAI_NFISCA` (3 chars: letra + 2 alfanum).
_CAMPO_RE = re.compile(r"^[A-Z][A-Z0-9]{1,2}_[A-Z0-9_]+$", re.IGNORECASE)
# v0.5.3 (A.2): novas entidades suportadas no trace.
_ARQUIVO_RE = re.compile(r"\.(prw|tlpp|prx|apw|ptm|aph)$", re.IGNORECASE)
_PARAMETRO_RE = re.compile(r"^MV_[A-Z0-9_]+$", re.IGNORECASE)


def _detect_entity_type(value: str) -> str:
    """Auto-detect tipo de entidade pra ``trace_query`` (v0.5.0+).

    Heurística por regex (fallback quando não há lookup no DB):
      - termina em ``.prw``/``.tlpp``/``.prx``/``.apw`` → ``arquivo`` (v0.5.3)
      - começa com ``MV_`` → ``parametro`` (v0.5.3)
      - ``<letra>+<1-2 alfanum>_<nome>`` (``A1_COD``, ``EE7_ZSUBEX``) → ``campo``
        — checado antes de tabela (regex de tabela mais permissivo agora)
      - 3 chars uppercase (``SA1``/``EE7``/``DAI``/``GV4``) → ``tabela``
      - Fallback: ``funcao``

    Use :func:`_detect_entity_type_db` quando ``conn`` disponível — lookup
    direto no índice é mais robusto que regex pra entidades específicas
    do codebase do cliente (cobre ``pergunte:GRUPO`` que não tem padrão regex).

    Override via ``--tipo`` no CLI quando heurística erra.
    """
    if _ARQUIVO_RE.search(value):
        return "arquivo"
    if _PARAMETRO_RE.match(value):
        return "parametro"
    if _CAMPO_RE.match(value):
        return "campo"
    if _TABLE_RE.match(value):
        return "tabela"
    return "funcao"


def _detect_entity_type_db(
    conn: sqlite3.Connection, value: str
) -> str:
    """v0.5.1 (#2): auto-detect com lookup no índice (preferido sobre regex).

    Estratégia:
      1. ``tabelas.codigo`` (SX2 ingerido) → ``tabela``
      2. ``fonte_chunks.funcao_norm`` (funções indexadas) → ``funcao``
      3. ``campos.campo`` (SX3 ingerido) → ``campo``
      4. ``fonte_tabela.tabela`` (tabela referenciada em fonte) → ``tabela``
      5. Fallback: regex (:func:`_detect_entity_type`)

    Vantagens vs regex puro:
      - Sem falso-positivo: classifica como tabela só se existir no índice
      - Auto-adapta a tabelas custom do cliente (sem regex hardcoded)
      - Cobre tabelas TOTVS de qualquer módulo (EE*/DA*/GV*/etc) sem manter lista
    """
    # v0.5.3 (A.2): checa regex primeiro pra arquivo/parametro (extensão/prefix MV_).
    # Esses padrões são determinísticos — não precisa DB lookup.
    rg_type = _detect_entity_type(value)
    if rg_type in ("arquivo", "parametro"):
        return rg_type
    value_u = value.upper()
    # 1. SX2 indexado
    row = conn.execute(
        "SELECT 1 FROM tabelas WHERE upper(codigo) = ? LIMIT 1", (value_u,)
    ).fetchone()
    if row:
        return "tabela"
    # 2. Função indexada
    funcao_norm = value_u.removeprefix("U_")
    row = conn.execute(
        "SELECT 1 FROM fonte_chunks WHERE funcao_norm = ? LIMIT 1", (funcao_norm,)
    ).fetchone()
    if row:
        return "funcao"
    # 3. Campo SX3 indexado
    row = conn.execute(
        "SELECT 1 FROM campos WHERE upper(campo) = ? LIMIT 1", (value_u,)
    ).fetchone()
    if row:
        return "campo"
    # 4. Tabela referenciada em fonte (sem registro SX)
    row = conn.execute(
        "SELECT 1 FROM fonte_tabela WHERE upper(tabela) = ? LIMIT 1", (value_u,)
    ).fetchone()
    if row:
        return "tabela"
    # 5. v0.5.3 (A.2): pergunte SX1 (grupo) — só identificável por DB lookup
    # (sem padrão regex; nomes tipo `MTA010`/`AFA110` confundem com função).
    row = conn.execute(
        "SELECT 1 FROM perguntas WHERE upper(grupo) = ? LIMIT 1", (value_u,)
    ).fetchone()
    if row:
        return "pergunte"
    # 6. v0.5.3 (A.2): parametro SX6 — se nao bateu no regex `MV_*` mas existe
    # em parametros.variavel (raro: parametros sem prefixo MV_).
    row = conn.execute(
        "SELECT 1 FROM parametros WHERE upper(variavel) = ? LIMIT 1", (value_u,)
    ).fetchone()
    if row:
        return "parametro"
    # 7. Fallback: regex (resulta em 'funcao' se não casar com nada acima)
    return rg_type


# v0.5.1 (#5): edges informativos vão pro topo do output (priority menor =
# vem primeiro). Antes ordem era alfabética por edge, fazendo `table_definition`
# (descrição oficial SX2) ficar no fim de 100+ rows. Agora destacado.
_EDGE_PRIORITY: dict[str, int] = {
    "table_definition": 0,
    "field_definition": 0,
    "n_fields": 1,
    "defined_in": 1,
}


def _trace_sort_key(hit: dict[str, Any]) -> tuple[Any, ...]:
    """Sort key padrão pra hits de trace_query.

    Ordem: (universo, edge_priority, edge_name, arquivo, linha).
    Edges informativos (table_definition/field_definition/n_fields/defined_in)
    ficam no topo do bloco do universo via _EDGE_PRIORITY.
    """
    return (
        hit.get("universo", 99),
        _EDGE_PRIORITY.get(hit.get("edge", ""), 50),
        hit.get("edge", ""),
        hit.get("arquivo", ""),
        int(hit.get("linha", 0) or 0),
    )


def _trace_hit(
    universo: int,
    edge: str,
    *,
    arquivo: str = "",
    funcao: str = "",
    linha: int = 0,
    alvo: str = "",
    contexto: str = "",
    contexto_dict: dict[str, Any] | None = None,
    snippet: str = "",
) -> dict[str, Any]:
    """Constrói um dict de hit do trace (schema unificado).

    v0.5.2 (#4): aditivo ``contexto_dict`` pra consumidor JSON evitar parse
    manual de string ``"k1=v1 k2=v2"``. Se ``contexto`` não passado mas
    ``contexto_dict`` sim, deriva string automaticamente. Render table
    só mostra ``contexto`` (backward compat).
    """
    cdict = dict(contexto_dict) if contexto_dict else {}
    # Auto-derive string se só dict foi passado.
    if not contexto and cdict:
        contexto = " ".join(f"{k}={v}" for k, v in cdict.items() if v not in (None, ""))
    return {
        "universo": universo,
        "edge": edge,
        "arquivo": arquivo,
        "funcao": funcao or "",
        "linha": int(linha or 0),
        "alvo": alvo,
        "contexto": contexto,
        "contexto_dict": cdict,
        "snippet": (snippet or "")[:120],
    }


def _trace_funcao(
    conn: sqlite3.Connection,
    funcao: str,
    *,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """Coleta arestas pra função-alvo cross-universo."""
    hits: list[dict[str, Any]] = []
    funcao_u = funcao.upper()
    # v0.5.1 (#6): variantes pra lookup robusto — funcao_norm às vezes tem
    # U_ prefix preservado (inconsistência com schema comment). Testa ambos.
    variants = {funcao_u}
    if funcao_u.startswith("U_"):
        variants.add(funcao_u[2:])
    else:
        variants.add(f"U_{funcao_u}")
    funcao_norm = funcao_u[2:] if funcao_u.startswith("U_") else funcao_u

    # U1: defined_in — match via upper(funcao) IN (variantes)
    placeholders = ",".join("?" * len(variants))
    sql = (
        f"SELECT arquivo, funcao, linha_inicio, tipo_simbolo, classe "
        f"FROM fonte_chunks "
        f"WHERE upper(funcao) IN ({placeholders}) OR funcao_norm IN ({placeholders}) "
        f"LIMIT ?"
    )
    var_list = list(variants)
    for arq, fn_real, ln, kind, classe in conn.execute(
        sql, [*var_list, *var_list, max_per_edge]
    ):
        # v0.5.1 (#6): alvo = nome da funcao (simbolo definido), nao arquivo
        # (era redundancia: alvo == arquivo). Mantém arquivo na coluna proper.
        cdict: dict[str, Any] = {"kind": kind}
        if classe:
            cdict["classe"] = classe
        hits.append(_trace_hit(
            1, "defined_in", arquivo=arq, funcao=fn_real or funcao,
            linha=int(ln or 0),
            alvo=fn_real or funcao,
            contexto=f"{kind}" + (f" of {classe}" if classe else ""),
            contexto_dict=cdict,
        ))

    # U1: callers
    sql = (
        "SELECT arquivo_origem, funcao_origem, linha_origem, tipo "
        "FROM chamadas_funcao WHERE destino_norm = ? LIMIT ?"
    )
    for arq, fn, ln, tipo in conn.execute(sql, (funcao_norm, max_per_edge)):
        hits.append(_trace_hit(
            1, "called_by", arquivo=arq, funcao=fn or "", linha=int(ln or 0),
            alvo=f"{fn}@{arq}" if fn else arq,
            contexto=f"call type={tipo}",
            contexto_dict={"call_type": tipo},
        ))

    # U1: callees (o que a função chama)
    sql = (
        "SELECT DISTINCT destino, tipo "
        "FROM chamadas_funcao "
        "WHERE upper(funcao_origem) = upper(?) LIMIT ?"
    )
    for destino, tipo in conn.execute(sql, (funcao, max_per_edge)):
        hits.append(_trace_hit(
            1, "calls", funcao=funcao, alvo=destino or "",
            contexto=f"call type={tipo}",
            contexto_dict={"call_type": tipo},
        ))

    # U2: validates_field (função aparece em X3_VALID/INIT/WHEN/VLDUSER)
    # Match com palavra-completa pra evitar prefix collision.
    pat = f"%{funcao}%"
    sql = (
        "SELECT campo, tabela, validacao, inicializador, when_expr, vlduser "
        "FROM campos "
        "WHERE validacao LIKE ? COLLATE NOCASE OR inicializador LIKE ? COLLATE NOCASE "
        "   OR when_expr LIKE ? COLLATE NOCASE OR vlduser LIKE ? COLLATE NOCASE "
        "LIMIT ?"
    )
    for nome, tabela, v, i, w, vu in conn.execute(sql, (pat, pat, pat, pat, max_per_edge)):
        # Confirma word-boundary
        funcao_u = funcao.upper()
        texts = {"VALID": v, "INIT": i, "WHEN": w, "VLDUSER": vu}
        for slot, txt in texts.items():
            if not txt or funcao_u not in txt.upper():
                continue
            hits.append(_trace_hit(
                2, "validates_field", alvo=f"{tabela}.{nome}",
                contexto=f"X3_{slot}",
                contexto_dict={"slot": f"X3_{slot}", "tabela": tabela, "campo": nome},
                snippet=txt,
            ))

    # U3: via_execauto (função é rotina chamada por MsExecAuto)
    sql = (
        "SELECT arquivo, funcao, linha, module, op_label, snippet "
        "FROM execauto_calls WHERE upper(routine) = upper(?) LIMIT ?"
    )
    for arq, fn, ln, mod, oplbl, snip in conn.execute(sql, (funcao, max_per_edge)):
        hits.append(_trace_hit(
            3, "via_execauto", arquivo=arq, funcao=fn or "", linha=int(ln or 0),
            alvo=funcao, contexto=f"module={mod or '?'} op={oplbl or '?'}",
            contexto_dict={"module": mod or "", "op": oplbl or ""},
            snippet=snip,
        ))

    # U3: triggered_by_workflow/schedule/job/callback (função é target)
    sql = (
        "SELECT arquivo, funcao, linha, kind, snippet "
        "FROM execution_triggers WHERE upper(target) = upper(?) LIMIT ?"
    )
    for arq, fn, ln, kind, snip in conn.execute(sql, (funcao, max_per_edge)):
        edge_map = {
            "workflow": "triggered_by_workflow",
            "wf_callback": "triggered_by_callback",
            "schedule": "triggered_by_schedule",
            "job_standalone": "triggered_by_job",
            "mail_send": "triggered_by_mail",
        }
        hits.append(_trace_hit(
            3, edge_map.get(kind, f"triggered_by_{kind}"),
            arquivo=arq, funcao=fn or "", linha=int(ln or 0),
            alvo=funcao, contexto=f"kind={kind}",
            contexto_dict={"kind": kind},
            snippet=snip,
        ))

    # U3: documented_in (Protheus.doc da função, se houver)
    sql = (
        f"SELECT {_PDOC_COLUMNS} FROM protheus_docs "
        "WHERE (funcao = ? COLLATE NOCASE OR funcao_id = ? COLLATE NOCASE) "
        "LIMIT ?"
    )
    for row in conn.execute(sql, (funcao, funcao, max_per_edge)):
        d = _row_to_pdoc(row)
        ctx_parts = []
        if d["author"]:
            ctx_parts.append(f"author={d['author']}")
        if d["since"]:
            ctx_parts.append(f"since={d['since']}")
        if d["deprecated"]:
            ctx_parts.append("DEPRECATED")
        cdict_doc: dict[str, Any] = {}
        if d["author"]:
            cdict_doc["author"] = d["author"]
        if d["since"]:
            cdict_doc["since"] = d["since"]
        if d["deprecated"]:
            cdict_doc["deprecated"] = True
        hits.append(_trace_hit(
            3, "documented_in", arquivo=d["arquivo"], funcao=d["funcao"] or funcao,
            linha=int(d["linha_funcao"] or 0), alvo=funcao,
            contexto=" ".join(ctx_parts) or "doc",
            contexto_dict=cdict_doc,
            snippet=(d["summary"] or "")[:120],
        ))

    return hits


def _trace_tabela(
    conn: sqlite3.Connection,
    tabela: str,
    *,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """Coleta arestas pra tabela-alvo cross-universo."""
    hits: list[dict[str, Any]] = []
    tabela_u = tabela.upper()

    # U1: reads/writes/reclock via fonte_tabela
    sql = (
        "SELECT arquivo, modo FROM fonte_tabela "
        "WHERE upper(tabela) = ? LIMIT ?"
    )
    for arq, modo in conn.execute(sql, (tabela_u, max_per_edge * 3)):
        edge = {"read": "reads", "write": "writes", "reclock": "reclock"}.get(modo, "touches")
        hits.append(_trace_hit(
            1, edge, arquivo=arq, alvo=tabela, contexto=f"mode={modo}",
            contexto_dict={"mode": modo},
        ))

    # U2: table_definition
    sql = (
        "SELECT codigo, nome, modo, custom FROM tabelas "
        "WHERE upper(codigo) = ? LIMIT 1"
    )
    for cod, nome, modo, custom in conn.execute(sql, (tabela_u,)):
        hits.append(_trace_hit(
            2, "table_definition", alvo=tabela,
            contexto=f"modo={modo or '?'} custom={int(custom or 0)}",
            contexto_dict={"modo": modo or "", "custom": int(custom or 0)},
            snippet=nome or "",
        ))

    # U2: n_fields (sumário)
    sql = "SELECT COUNT(*) FROM campos WHERE upper(tabela) = ?"
    (n_fields,) = conn.execute(sql, (tabela_u,)).fetchone() or (0,)
    if n_fields:
        hits.append(_trace_hit(
            2, "n_fields", alvo=tabela, contexto=f"{int(n_fields)} campos SX3",
            contexto_dict={"n_campos": int(n_fields)},
        ))

    # U2: indexed_by (SIX)
    sql = (
        "SELECT ordem, chave, descricao, nickname FROM indices "
        "WHERE upper(tabela) = ? ORDER BY ordem LIMIT ?"
    )
    for ord_, chave, descr, nick in conn.execute(sql, (tabela_u, max_per_edge)):
        hits.append(_trace_hit(
            2, "indexed_by", alvo=tabela,
            contexto=f"ord={ord_} nick={nick or '-'}",
            contexto_dict={"ord": ord_, "nick": nick or "", "chave": chave or ""},
            snippet=f"chave={chave} | {descr or ''}",
        ))

    # U2: in_relationship (SX9)
    sql = (
        "SELECT tabela_origem, tabela_destino, identificador, "
        "expressao_origem, expressao_destino "
        "FROM relacionamentos "
        "WHERE upper(tabela_origem) = ? OR upper(tabela_destino) = ? LIMIT ?"
    )
    for ori, dest, ident, eo, ed in conn.execute(
        sql, (tabela_u, tabela_u, max_per_edge)
    ):
        hits.append(_trace_hit(
            2, "in_relationship", alvo=f"{ori}<->{dest}",
            contexto=f"id={ident} {eo}->{ed}",
            contexto_dict={
                "id": ident, "tabela_origem": ori, "tabela_destino": dest,
                "expr_origem": eo or "", "expr_destino": ed or "",
            },
        ))

    # U2: trigger_on_table (SX7)
    sql = (
        "SELECT campo_origem, sequencia, regra, campo_destino "
        "FROM gatilhos WHERE upper(tabela) = ? LIMIT ?"
    )
    for camp, seq, regra, dest in conn.execute(sql, (tabela_u, max_per_edge)):
        hits.append(_trace_hit(
            2, "trigger_on_table", alvo=f"{tabela}.{camp}",
            contexto=f"seq={seq} -> {dest or '?'}",
            contexto_dict={"campo_origem": camp, "seq": seq, "campo_destino": dest or ""},
            snippet=regra or "",
        ))

    # U3: touched_via_execauto (LIKE em tables_resolved_json)
    sql = (
        "SELECT arquivo, funcao, linha, routine, module, tables_resolved_json "
        "FROM execauto_calls WHERE tables_resolved_json LIKE ? LIMIT ?"
    )
    like_pat = f'%"{tabela_u}"%'
    for arq, fn, ln, rt, mod, tjson in conn.execute(sql, (like_pat, max_per_edge * 2)):
        from plugadvpl.parsing.execauto import parse_tables
        if tabela_u not in [t.upper() for t in parse_tables(tjson)]:
            continue  # word boundary via JSON list
        hits.append(_trace_hit(
            3, "touched_via_execauto", arquivo=arq, funcao=fn or "",
            linha=int(ln or 0), alvo=tabela,
            contexto=f"routine={rt or '?'} module={mod or '?'}",
            contexto_dict={"routine": rt or "", "module": mod or ""},
        ))

    # U3: documented_in (LIKE em protheus_docs.tables_json)
    sql = (
        "SELECT arquivo, funcao, linha_funcao, tables_json, summary "
        "FROM protheus_docs WHERE tables_json LIKE ? LIMIT ?"
    )
    for arq, fn, ln, tjson, summ in conn.execute(sql, (like_pat, max_per_edge)):
        from plugadvpl.parsing.protheus_doc import parse_json_list
        if tabela_u not in [str(t).upper() for t in parse_json_list(tjson)]:
            continue
        hits.append(_trace_hit(
            3, "documented_in", arquivo=arq, funcao=fn or "",
            linha=int(ln or 0), alvo=tabela,
            contexto="@table",
            contexto_dict={"tag": "@table"},
            snippet=(summ or "")[:120],
        ))

    return hits


def _trace_campo(
    conn: sqlite3.Connection,
    campo: str,
    *,
    depth: int = 2,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """Coleta arestas pra campo-alvo cross-universo. Reaproveita queries
    do impacto/gatilho + JOINs novos pra relacionamentos/consultas/SXG."""
    hits: list[dict[str, Any]] = []
    campo_u = campo.upper()

    # U1: references_field (busca em fonte_chunks.content)
    sql = (
        "SELECT arquivo, funcao, linha_inicio, "
        "substr(content, max(1, instr(upper(content), ?) - 30), 160) AS snippet "
        "FROM fonte_chunks "
        "WHERE upper(content) LIKE '%' || ? || '%' LIMIT ?"
    )
    for arq, fn, ln, snip in conn.execute(sql, (campo_u, campo_u, max_per_edge)):
        snip_up = (snip or "").upper()
        is_write = any(k in snip_up for k in _WRITE_KEYWORDS)
        mode = "write" if is_write else "read"
        hits.append(_trace_hit(
            1, "references_field",
            arquivo=arq, funcao=fn or "", linha=int(ln or 0),
            alvo=campo,
            contexto=mode,
            contexto_dict={"mode": mode},
            snippet=snip,
        ))

    # U2: field_definition (SX3)
    sql = (
        "SELECT tabela, descricao, tipo, tamanho, context, browse "
        "FROM campos WHERE upper(campo) = ? LIMIT 1"
    )
    for tab, descr, tp, tam, ctx, br in conn.execute(sql, (campo_u,)):
        ctx_parts = [f"tabela={tab}", f"tipo={tp}({tam})"]
        cdict_fd: dict[str, Any] = {"tabela": tab, "tipo": f"{tp}({tam})"}
        if ctx:
            ctx_parts.append(f"ctx={ctx}")
            cdict_fd["ctx"] = ctx
        if br:
            ctx_parts.append(f"browse={br}")
            cdict_fd["browse"] = br
        hits.append(_trace_hit(
            2, "field_definition", alvo=campo,
            contexto=" ".join(ctx_parts),
            contexto_dict=cdict_fd,
            snippet=descr or "",
        ))

    # U2: trigger_origin (campo dispara gatilho)
    sql_orig = (
        "SELECT campo_origem, sequencia, campo_destino, regra, tabela "
        "FROM gatilhos WHERE upper(campo_origem) = ? LIMIT ?"
    )
    for camp, seq, dest, regra, tab in conn.execute(sql_orig, (campo_u, max_per_edge)):
        hits.append(_trace_hit(
            2, "trigger_origin", alvo=f"{tab}.{dest or '?'}",
            contexto=f"seq={seq}",
            contexto_dict={"seq": seq, "campo_destino": dest or ""},
            snippet=regra or "",
        ))
    # U2: trigger_target (campo é modificado por gatilho)
    sql_target = (
        "SELECT campo_origem, sequencia, regra, tabela "
        "FROM gatilhos WHERE upper(campo_destino) = ? LIMIT ?"
    )
    for camp, seq, regra, tab in conn.execute(sql_target, (campo_u, max_per_edge)):
        hits.append(_trace_hit(
            2, "trigger_target", alvo=f"{tab}.{camp}",
            contexto=f"seq={seq}",
            contexto_dict={"seq": seq, "campo_origem": camp},
            snippet=regra or "",
        ))

    # U2: in_pergunte (SX1) — match em variavel ou conteudo_padrao
    sql = (
        "SELECT grupo, ordem, pergunta, variavel "
        "FROM perguntas WHERE upper(variavel) = ? LIMIT ?"
    )
    for grp, ord_, perg, var in conn.execute(sql, (campo_u, max_per_edge)):
        hits.append(_trace_hit(
            2, "in_pergunte", alvo=f"{grp}.{ord_}",
            contexto=f"variavel={var}",
            contexto_dict={"variavel": var, "grupo": grp, "ordem": ord_},
            snippet=perg or "",
        ))

    # U2: in_relationship (SX9 expressao)
    sql = (
        "SELECT tabela_origem, tabela_destino, expressao_origem, expressao_destino "
        "FROM relacionamentos "
        "WHERE upper(expressao_origem) LIKE ? OR upper(expressao_destino) LIKE ? "
        "LIMIT ?"
    )
    like_pat = f"%{campo_u}%"
    for ori, dest, eo, ed in conn.execute(sql, (like_pat, like_pat, max_per_edge)):
        if campo_u not in (eo or "").upper() and campo_u not in (ed or "").upper():
            continue
        hits.append(_trace_hit(
            2, "in_relationship", alvo=f"{ori}<->{dest}",
            contexto=f"{eo}->{ed}",
            contexto_dict={
                "tabela_origem": ori, "tabela_destino": dest,
                "expr_origem": eo or "", "expr_destino": ed or "",
            },
        ))

    # U2: in_consulta (SXB) — match em conteudo (expressão) ou alias=campo
    sql = (
        "SELECT alias, descricao, conteudo FROM consultas "
        "WHERE upper(conteudo) LIKE ? LIMIT ?"
    )
    for alias, descr, conteudo in conn.execute(sql, (like_pat, max_per_edge)):
        if campo_u not in (conteudo or "").upper():
            continue
        hits.append(_trace_hit(
            2, "in_consulta", alvo=alias,
            contexto="F3 lookup",
            contexto_dict={"tag": "F3", "alias": alias},
            snippet=descr or "",
        ))

    # U2: in_grupo_sxg
    sql = (
        "SELECT grpsxg FROM campos WHERE upper(campo) = ? AND grpsxg IS NOT NULL "
        "AND grpsxg != '' LIMIT 1"
    )
    for (grp,) in conn.execute(sql, (campo_u,)):
        if grp:
            sql_g = "SELECT descricao FROM grupos_campo WHERE upper(grupo) = ? LIMIT 1"
            descr_row = conn.execute(sql_g, (grp.upper(),)).fetchone()
            descr = descr_row[0] if descr_row else ""
            hits.append(_trace_hit(
                2, "in_grupo_sxg", alvo=grp, contexto="SXG",
                contexto_dict={"grupo": grp},
                snippet=descr or "",
            ))

    return hits


# ---------------------------------------------------------------------------
# v0.6.0 — Universo 4 / Feature B: qualidade & métricas
# ---------------------------------------------------------------------------


def metrics_query(
    conn: sqlite3.Connection,
    *,
    arquivo: str | None = None,
    min_cc: int = 0,
    min_loc: int = 0,
    sort: str = "cc",
) -> list[dict[str, Any]]:
    """Lista métricas por função (Universo 4 Feature B).

    Args:
        conn: conexão SQLite.
        arquivo: filtra por basename (case-insensitive). None = todos.
        min_cc: filtra ``cc >= min_cc`` (default 0 = sem filtro).
        min_loc: filtra ``loc >= min_loc`` (default 0).
        sort: campo de ordenação descendente — ``cc``/``loc``/``nesting``/``calls``.
            Tie-break por ``arquivo, linha_inicio``.

    Returns:
        Lista de dicts ``{arquivo, funcao, linha_inicio, linha_fim, loc, cc,
        nesting, n_calls_out, params_count, has_doc}``.
    """
    sort_col = {
        "cc": "cc",
        "loc": "loc",
        "nesting": "nesting",
        "calls": "n_calls_out",
        "params": "params_count",
    }.get(sort.lower(), "cc")

    sql = (
        "SELECT arquivo, funcao, linha_inicio, linha_fim, loc, cc, nesting, "
        "n_calls_out, params_count, has_doc FROM fonte_metrics"
    )
    where: list[str] = []
    params: list[Any] = []
    if arquivo:
        where.append("arquivo = ? COLLATE NOCASE")
        params.append(arquivo)
    if min_cc > 0:
        where.append("cc >= ?")
        params.append(min_cc)
    if min_loc > 0:
        where.append("loc >= ?")
        params.append(min_loc)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {sort_col} DESC, arquivo, linha_inicio"
    rows = conn.execute(sql, params).fetchall()
    out: list[dict[str, Any]] = []
    for (arq, fn, ini, fim, loc, cc, nest, ncalls, np, hdoc) in rows:
        out.append({
            "arquivo": arq,
            "funcao": fn or "",
            "linha_inicio": int(ini or 0),
            "linha_fim": int(fim or 0),
            "loc": int(loc or 0),
            "cc": int(cc or 0),
            "nesting": int(nest or 0),
            "n_calls_out": int(ncalls or 0),
            "params_count": int(np or 0),
            "has_doc": bool(hdoc),
        })
    return out


def hotspots_query(
    conn: sqlite3.Connection,
    *,
    n: int = 20,
    excluir_nativas: bool = True,
    tipo: str | None = None,
) -> list[dict[str, Any]]:
    """Top-N funções mais chamadas (Universo 4 Feature B).

    Args:
        conn: conexão SQLite.
        n: limite de rows (default 20).
        excluir_nativas: se True (default), exclui funções do lookup
            ``funcoes_nativas`` (`ConOut`/`RecLock`/etc) — refactor priority.
        tipo: filtra por ``chamadas_funcao.tipo`` (``user_func``, ``method``,
            ``execauto``, ``execblock``). None = todos.

    Returns:
        Lista ``{destino_norm, n_calls, n_arquivos, n_callsites}`` ordenada
        por ``n_calls DESC``.
    """
    where: list[str] = []
    params: list[Any] = []
    if excluir_nativas:
        where.append("destino_norm NOT IN (SELECT upper(nome) FROM funcoes_nativas)")
    if tipo:
        where.append("tipo = ?")
        params.append(tipo)
    where_clause = " WHERE " + " AND ".join(where) if where else ""
    sql = (
        f"SELECT destino_norm, COUNT(*) AS n_calls, "
        f"COUNT(DISTINCT arquivo_origem) AS n_arquivos, "
        f"COUNT(DISTINCT arquivo_origem || '::' || funcao_origem) AS n_callsites "
        f"FROM chamadas_funcao{where_clause} "
        f"GROUP BY destino_norm "
        f"ORDER BY n_calls DESC LIMIT ?"
    )
    params.append(n)
    rows = conn.execute(sql, params).fetchall()
    return [
        {
            "destino": dest,
            "n_calls": int(nc or 0),
            "n_arquivos": int(na or 0),
            "n_callsites": int(ns or 0),
        }
        for (dest, nc, na, ns) in rows
    ]


def cobertura_doc_query(
    conn: sqlite3.Connection,
    *,
    groupby: str = "modulo",
) -> list[dict[str, Any]]:
    """Cobertura de Protheus.doc agregada por módulo ou source_type.

    Args:
        conn: conexão SQLite.
        groupby: ``modulo`` (default — usa ``fontes.modulo``) ou ``source_type``
            (mvc/rest/cadastro/relatorio/outro).

    Returns:
        Lista ``{grupo, total, com_doc, pct}`` ordenada por ``pct ASC``
        (pior primeiro pra refactor priority). Funções sem grupo viram
        bucket ``"_sem_grupo"``.
    """
    col = "f.modulo" if groupby == "modulo" else "f.source_type"
    sql = (
        f"SELECT COALESCE(NULLIF({col}, ''), '_sem_grupo') AS grupo, "
        f"COUNT(*) AS total, "
        f"SUM(fm.has_doc) AS com_doc, "
        f"ROUND(100.0 * SUM(fm.has_doc) / COUNT(*), 1) AS pct "
        f"FROM fonte_metrics fm "
        f"JOIN fontes f ON f.arquivo = fm.arquivo "
        f"GROUP BY grupo ORDER BY pct ASC, total DESC"
    )
    rows = conn.execute(sql).fetchall()
    return [
        {
            "grupo": grp or "_sem_grupo",
            "total": int(tot or 0),
            "com_doc": int(cd or 0),
            "pct": float(pct or 0),
        }
        for (grp, tot, cd, pct) in rows
    ]


def _trace_arquivo(
    conn: sqlite3.Connection,
    arquivo: str,
    *,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """v0.5.3 (A.2): trace por arquivo agregando arch + workflow + execauto + docs."""
    hits: list[dict[str, Any]] = []

    # U1: arch metadata (capabilities, módulo, namespace, lines_of_code)
    sql = (
        "SELECT modulo, capabilities, lines_of_code, namespace, tipo_arquivo "
        "FROM fontes WHERE arquivo = ? COLLATE NOCASE LIMIT 1"
    )
    row = conn.execute(sql, (arquivo,)).fetchone()
    if row:
        mod, caps_json, loc, ns, tipo_arq = row
        caps = _json_or_default(caps_json, [])
        ctx_parts: list[str] = []
        cdict: dict[str, Any] = {}
        if mod:
            ctx_parts.append(f"modulo={mod}")
            cdict["modulo"] = mod
        if loc:
            ctx_parts.append(f"loc={loc}")
            cdict["loc"] = int(loc)
        if ns:
            ctx_parts.append(f"ns={ns}")
            cdict["namespace"] = ns
        if tipo_arq:
            cdict["tipo"] = tipo_arq
        if caps:
            cdict["capabilities"] = caps
            ctx_parts.append(f"caps={len(caps)}")
        hits.append(_trace_hit(
            1, "arch_summary", arquivo=arquivo, alvo=arquivo,
            contexto=" ".join(ctx_parts) or "fonte",
            contexto_dict=cdict,
        ))

    # U1: funções definidas no fonte
    sql = (
        "SELECT funcao, linha_inicio, tipo_simbolo "
        "FROM fonte_chunks WHERE arquivo = ? COLLATE NOCASE LIMIT ?"
    )
    for fn, ln, kind in conn.execute(sql, (arquivo, max_per_edge)):
        hits.append(_trace_hit(
            1, "defines_function", arquivo=arquivo, funcao=fn or "",
            linha=int(ln or 0), alvo=fn or "",
            contexto=kind or "function",
            contexto_dict={"kind": kind or "function"},
        ))

    # U1: lint findings (top severidade)
    sql = (
        "SELECT regra_id, severidade, linha, snippet, COUNT(*) OVER (PARTITION BY regra_id) AS dup "
        "FROM lint_findings WHERE arquivo = ? COLLATE NOCASE "
        "ORDER BY CASE severidade "
        "WHEN 'critical' THEN 1 WHEN 'error' THEN 2 WHEN 'warning' THEN 3 ELSE 4 END "
        "LIMIT ?"
    )
    for regra, sev, ln, snip, _dup in conn.execute(sql, (arquivo, max_per_edge)):
        hits.append(_trace_hit(
            1, "lint_finding", arquivo=arquivo, linha=int(ln or 0),
            alvo=regra, contexto=f"sev={sev}",
            contexto_dict={"regra": regra, "severidade": sev},
            snippet=snip or "",
        ))

    # U3: execauto calls do fonte
    sql = (
        "SELECT funcao, linha, routine, module, op_label "
        "FROM execauto_calls WHERE arquivo = ? COLLATE NOCASE LIMIT ?"
    )
    for fn, ln, rt, mod, oplbl in conn.execute(sql, (arquivo, max_per_edge)):
        hits.append(_trace_hit(
            3, "calls_execauto", arquivo=arquivo, funcao=fn or "",
            linha=int(ln or 0), alvo=rt or "(dynamic)",
            contexto=f"module={mod or '?'} op={oplbl or '?'}",
            contexto_dict={"routine": rt or "", "module": mod or "", "op": oplbl or ""},
        ))

    # U3: execution_triggers do fonte
    sql = (
        "SELECT funcao, linha, kind, target "
        "FROM execution_triggers WHERE arquivo = ? COLLATE NOCASE LIMIT ?"
    )
    for fn, ln, kind, target in conn.execute(sql, (arquivo, max_per_edge)):
        hits.append(_trace_hit(
            3, "has_trigger", arquivo=arquivo, funcao=fn or "",
            linha=int(ln or 0), alvo=target or "",
            contexto=f"kind={kind}",
            contexto_dict={"kind": kind, "target": target or ""},
        ))

    # U3: protheus_docs do fonte
    sql = (
        "SELECT funcao, linha_funcao, tipo, author, deprecated, summary "
        "FROM protheus_docs WHERE arquivo = ? COLLATE NOCASE LIMIT ?"
    )
    for fn, ln, tipo_doc, author, dep, summ in conn.execute(sql, (arquivo, max_per_edge)):
        cdict: dict[str, Any] = {"tipo": tipo_doc or ""}
        if author:
            cdict["author"] = author
        if dep:
            cdict["deprecated"] = True
        hits.append(_trace_hit(
            3, "has_protheus_doc", arquivo=arquivo, funcao=fn or "",
            linha=int(ln or 0), alvo=fn or "",
            contexto=f"tipo={tipo_doc or '?'}" + (" DEPRECATED" if dep else ""),
            contexto_dict=cdict,
            snippet=(summ or "")[:120],
        ))

    return hits


def _trace_parametro(
    conn: sqlite3.Connection,
    parametro: str,
    *,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """v0.5.3 (A.2): trace por parametro MV_* agregando uso + SX6."""
    hits: list[dict[str, Any]] = []
    param_u = parametro.upper()

    # U1: uso em código (parametros_uso)
    sql = (
        "SELECT arquivo, modo, COUNT(*) FROM parametros_uso "
        "WHERE upper(parametro) = ? GROUP BY arquivo, modo LIMIT ?"
    )
    for arq, modo, n in conn.execute(sql, (param_u, max_per_edge)):
        hits.append(_trace_hit(
            1, f"used_{modo}" if modo else "used", arquivo=arq, alvo=parametro,
            contexto=f"n={int(n)} mode={modo or '?'}",
            contexto_dict={"n_usos": int(n), "mode": modo or ""},
        ))

    # U2: definição SX6
    sql = (
        "SELECT filial, tipo, descricao, conteudo, proprietario "
        "FROM parametros WHERE upper(variavel) = ? LIMIT 1"
    )
    for fil, tp, descr, cont, prop in conn.execute(sql, (param_u,)):
        ctx_parts = [f"tipo={tp}"]
        cdict: dict[str, Any] = {"tipo": tp or ""}
        if fil:
            ctx_parts.append(f"filial={fil}")
            cdict["filial"] = fil
        if cont:
            cdict["default"] = cont
        if prop:
            cdict["proprietario"] = prop
        hits.append(_trace_hit(
            2, "param_definition", alvo=parametro,
            contexto=" ".join(ctx_parts),
            contexto_dict=cdict,
            snippet=(descr or "")[:120],
        ))

    # U2: SX1 que usa o MV como default (X1_DEF01 LIKE %MV%)
    sql = (
        "SELECT grupo, ordem, pergunta, variavel "
        "FROM perguntas WHERE upper(conteudo_padrao) LIKE ? LIMIT ?"
    )
    for grp, ord_, perg, var in conn.execute(sql, (f"%{param_u}%", max_per_edge)):
        hits.append(_trace_hit(
            2, "in_pergunte_default", alvo=f"{grp}.{ord_}",
            contexto=f"variavel={var}",
            contexto_dict={"grupo": grp, "ordem": ord_, "variavel": var},
            snippet=perg or "",
        ))

    return hits


def _trace_pergunte(
    conn: sqlite3.Connection,
    grupo: str,
    *,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """v0.5.3 (A.2): trace por pergunte (grupo SX1) agregando uso + perguntas + schedules."""
    hits: list[dict[str, Any]] = []
    grupo_u = grupo.upper()

    # U1: uso em código (perguntas_uso)
    sql = (
        "SELECT arquivo, COUNT(*) FROM perguntas_uso "
        "WHERE upper(grupo) = ? GROUP BY arquivo LIMIT ?"
    )
    for arq, n in conn.execute(sql, (grupo_u, max_per_edge)):
        hits.append(_trace_hit(
            1, "uses_pergunte", arquivo=arq, alvo=grupo,
            contexto=f"n={int(n)}",
            contexto_dict={"n_usos": int(n)},
        ))

    # U2: perguntas SX1 do grupo
    sql = (
        "SELECT ordem, pergunta, variavel, tipo, validacao "
        "FROM perguntas WHERE upper(grupo) = ? ORDER BY ordem LIMIT ?"
    )
    for ord_, perg, var, tp, val in conn.execute(sql, (grupo_u, max_per_edge)):
        cdict: dict[str, Any] = {"ordem": ord_, "variavel": var or "", "tipo": tp or ""}
        if val:
            cdict["validacao"] = val
        hits.append(_trace_hit(
            2, "pergunta_definition", alvo=f"{grupo}.{ord_}",
            contexto=f"variavel={var or '?'} tipo={tp or '?'}",
            contexto_dict=cdict,
            snippet=perg or "",
        ))

    # U3: schedules que apontam pra esse pergunte (metadata.pergunte)
    sql = (
        "SELECT arquivo, funcao, linha, metadata_json "
        "FROM execution_triggers WHERE kind = 'schedule' "
        "AND metadata_json LIKE ? LIMIT ?"
    )
    for arq, fn, ln, meta_json in conn.execute(
        sql, (f'%"pergunte": "{grupo_u}"%', max_per_edge)
    ):
        from plugadvpl.parsing.triggers import parse_metadata
        meta = parse_metadata(meta_json or "{}")
        if (meta.get("pergunte") or "").upper() != grupo_u:
            continue
        hits.append(_trace_hit(
            3, "scheduled_with_pergunte", arquivo=arq, funcao=fn or "",
            linha=int(ln or 0), alvo=grupo,
            contexto=f"sched_type={meta.get('sched_type', '?')}",
            contexto_dict={"sched_type": meta.get("sched_type", "")},
        ))

    return hits


def trace_query(
    conn: sqlite3.Connection,
    entidade: str,
    *,
    tipo: str | None = None,
    depth: int = 2,
    universos: list[int] | None = None,
    max_per_edge: int = 20,
) -> list[dict[str, Any]]:
    """v0.5.0 (Universo 4 / Feature A): trace agregado cross-universo.

    Args:
        conn: conexão SQLite.
        entidade: nome da entidade-alvo (campo/função/tabela).
        tipo: força tipo (``campo``/``funcao``/``tabela``). Se None, auto-detect.
        depth: profundidade pra BFS (1..3). Aplica em colectors que suportam.
        universos: lista de universos a incluir (``[1, 2, 3]``). Default: todos.
        max_per_edge: limite de hits por tipo de aresta. Default 20.

    Returns:
        Lista de dicts (1 por aresta) com schema unificado:
        ``{universo, edge, arquivo, funcao, linha, alvo, contexto, snippet}``.
        Ordenado por (``universo``, ``edge``, ``arquivo``, ``linha``).
    """
    depth = max(1, min(depth, 3))
    if tipo is None:
        # v0.5.1 (#2): lookup-first detect (DB > regex) — pega tabelas custom
        # e prefixos não-standard (EE*/DA*/GV*/etc) sem falso positivo.
        tipo = _detect_entity_type_db(conn, entidade)

    if tipo == "campo":
        hits = _trace_campo(conn, entidade, depth=depth, max_per_edge=max_per_edge)
    elif tipo == "funcao":
        hits = _trace_funcao(conn, entidade, max_per_edge=max_per_edge)
    elif tipo == "tabela":
        hits = _trace_tabela(conn, entidade, max_per_edge=max_per_edge)
    elif tipo == "arquivo":
        hits = _trace_arquivo(conn, entidade, max_per_edge=max_per_edge)
    elif tipo == "parametro":
        hits = _trace_parametro(conn, entidade, max_per_edge=max_per_edge)
    elif tipo == "pergunte":
        hits = _trace_pergunte(conn, entidade, max_per_edge=max_per_edge)
    else:
        return []

    # Filtra por universo se solicitado.
    if universos:
        wanted = set(universos)
        hits = [h for h in hits if h["universo"] in wanted]

    # v0.5.1 (#5): sort com priority — edges informativos (table_definition,
    # field_definition, n_fields, defined_in) vem no topo.
    hits.sort(key=_trace_sort_key)
    return hits
