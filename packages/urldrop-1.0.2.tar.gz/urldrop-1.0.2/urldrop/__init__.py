import webbrowser
import pathlib

def main():
    html = pathlib.Path(__file__).parent.parent / "index.html"
    webbrowser.open(html.as_uri())  