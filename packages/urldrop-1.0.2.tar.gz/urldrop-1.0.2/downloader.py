import sys, time, hashlib, argparse, requests
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse

# ── Settings ────────────────────────────────
DEFAULT_URLS_FILE  = "urls.txt"
DEFAULT_OUTPUT_DIR = "downloads"
DEFAULT_RETRIES    = 3
DEFAULT_TIMEOUT    = 30
CHUNK_SIZE         = 1024 * 8

MIME_TO_EXT = {
    "image/jpeg": ".jpg", "image/jpg": ".jpg", "image/pjpeg": ".jpg",
    "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp",
    "image/svg+xml": ".svg", "image/bmp": ".bmp", "image/tiff": ".tiff",
    "application/pdf": ".pdf", "text/plain": ".txt", "text/html": ".html",
    "text/csv": ".csv", "application/zip": ".zip", "application/json": ".json",
    "application/xml": ".xml", "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "video/mp4": ".mp4", "video/webm": ".webm",
    "audio/mpeg": ".mp3", "audio/wav": ".wav",
    "application/octet-stream": ".bin",
}


def smart_filename(url, content_type=""):
  #  Build a clean short filename from URL + Content-Type.
    name = Path(urlparse(url).path).name or "file"
    suffix = Path(name).suffix
    ext = suffix if (suffix and 2 <= len(suffix) <= 5) else \
          MIME_TO_EXT.get(content_type.split(";")[0].strip().lower(), ".bin")
    stem = Path(name).stem
    if len(stem) > 20:  # shorten long CDN filenames to a hash
        stem = "file_" + hashlib.md5(url.encode()).hexdigest()[:8]
    return stem + ext


def safe_path(folder, filename):
  #  Add _1, _2 … suffix if file already exists.
    dest = folder / filename
    if not dest.exists():
        return dest
    stem, suffix, n = Path(filename).stem, Path(filename).suffix, 1
    while (folder / f"{stem}_{n}{suffix}").exists():
        n += 1
    return folder / f"{stem}_{n}{suffix}"


def download(url, output_dir, retries=3, timeout=30):
    last_err = ""
    for attempt in range(1, retries + 1):
        try:
            print(f"  Attempt {attempt}/{retries}: {url[:70]}")
            r = requests.get(url, timeout=timeout, stream=True)
            r.raise_for_status()

            filename = smart_filename(url, r.headers.get("Content-Type", ""))
            dest = output_dir / filename

            if dest.exists():
                return {"status": "skipped", "message": f"Already exists → {dest.name}", "path": str(dest)}

            dest = safe_path(output_dir, filename)
            with open(dest, "wb") as f:
                for chunk in r.iter_content(CHUNK_SIZE):
                    if chunk:
                        f.write(chunk)

            return {"status": "saved", "message": f"Saved {dest.stat().st_size/1024:.1f} KB → {dest.name}", "path": str(dest)}

        except requests.exceptions.HTTPError as e:
            last_err = f"HTTP error: {e}"
        except requests.exceptions.ConnectionError:
            last_err = "Could not connect"
        except requests.exceptions.Timeout:
            last_err = f"Timed out after {timeout}s"
        except requests.exceptions.RequestException as e:
            last_err = f"Request error: {e}"
        except OSError as e:
            last_err = f"File error: {e}"

        if attempt < retries:
            time.sleep(attempt * 2)

    return {"status": "failed", "message": f"Failed after {retries} attempts: {last_err}", "path": None}


def write_report(results, output_dir):
    saved   = [r for r in results if r["status"] == "saved"]
    skipped = [r for r in results if r["status"] == "skipped"]
    failed  = [r for r in results if r["status"] == "failed"]

    lines = [
        "=" * 52,
        f"  DOWNLOAD REPORT — {datetime.now():%Y-%m-%d %H:%M:%S}",
        "=" * 52,
        f"  Total: {len(results)}   {len(saved)} saved  ⟳ {len(skipped)} skipped   {len(failed)} failed",
        "=" * 52,
    ]
    for r in saved:
        lines += [f"\n  {r['message']}", f"    {r['url']}"]
    for r in skipped:
        lines.append(f"  {r['message']}")
    for r in failed:
        lines += [f"  {r['url']}", f"    {r['message']}"]

    path = output_dir.parent / "report.txt"
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n  Report saved → {path}")


def main():
    p = argparse.ArgumentParser(description="Download files from a URL list.")
    p.add_argument("--urls",    default=DEFAULT_URLS_FILE)
    p.add_argument("--output",  default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--retries", default=DEFAULT_RETRIES, type=int)
    p.add_argument("--timeout", default=DEFAULT_TIMEOUT, type=int)
    args = p.parse_args()

    urls_file  = Path(args.urls)
    output_dir = Path(args.output)

    if not urls_file.exists():
        sys.exit(f"[ERROR] '{urls_file}' not found.")

    urls = [l.strip() for l in urls_file.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.strip().startswith("#")]

    if not urls:
        sys.exit(f"[ERROR] No URLs found in '{urls_file}'.")

    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n{'*'*52}")
    print(f"URL File Downloader")
    print(f"\n{'*'*52}")

    print(f"  URLs: {len(urls)}  |  Saving to: {output_dir.resolve()}")
    print(f"\n{'-'*60}\n")


    results = []
    icons = {"saved": "✓", "skipped": "⟳", "failed": "✗"}

    for i, url in enumerate(urls, 1):
        print(f"[{i}/{len(urls)}] {url}")
        result = download(url, output_dir, args.retries, args.timeout)
        result["url"] = url
        print(f"  {icons[result['status']]} {result['message']}\n")
        results.append(result)

    saved   = sum(1 for r in results if r["status"] == "saved")
    skipped = sum(1 for r in results if r["status"] == "skipped")
    failed  = sum(1 for r in results if r["status"] == "failed")

    print(f"{'-'*52}")
    print(f"  Done! ✓ {saved} saved  ⟳ {skipped} skipped  ✗ {failed} failed")
    print(f"{'-'*52}")

    write_report(results, output_dir)


if __name__ == "__main__":
    main()