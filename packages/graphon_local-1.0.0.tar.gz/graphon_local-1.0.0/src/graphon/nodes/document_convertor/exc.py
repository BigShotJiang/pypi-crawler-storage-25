class DocumentConvertorError(ValueError):
    """Base exception for errors related to the DocumentExtractorNode."""


class FileDownloadError(DocumentConvertorError):
    """Exception raised when there's an error downloading a file."""


class UnsupportedFileTypeError(DocumentConvertorError):
    """Exception raised when trying to extract text from an unsupported file type."""
