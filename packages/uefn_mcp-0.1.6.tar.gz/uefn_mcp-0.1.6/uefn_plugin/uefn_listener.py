"""
uefn_listener.py — runs inside UEFN's embedded Python 3.11 interpreter.

Architecture:
    HTTP server (worker thread) ──► thread-safe queue ──► tick callback (game thread)
                                                                   │
                                                                   ▼
                                                              unreal.* APIs

Why: All `unreal.*` calls MUST run on the game thread. The HTTP handler
parks the request on a queue and blocks on a per-request response queue.
The game-thread tick callback drains the queue, runs the code, and unblocks
the handler with the result.

v1.6 — reactive event transport (HTTP long-poll):
    The /events/wait endpoint blocks for up to 60s waiting for new events
    (log.error / log.warning / verse.build / selection.changed / verse.file_written
    or any custom kind that snippets push via push_event(...)). It wakes
    immediately when an event arrives — same UX as a WebSocket but no
    third-party dependency in the listener (UEFN's embedded Python is
    painful to pip-install into).
"""
from __future__ import annotations

import json
import queue
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import unreal

# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────
HOST = "127.0.0.1"
PORT = 8766
EXEC_TIMEOUT_SECS = 30
LOG_BUFFER_SIZE = 1000
EVENT_BUFFER_SIZE = 500
LONG_POLL_MAX_SECS = 60

# ─────────────────────────────────────────────────────────────────────────────
# Shared state
# ─────────────────────────────────────────────────────────────────────────────
COMMAND_QUEUE: "queue.Queue[tuple[str, queue.Queue]]" = queue.Queue()
LOG_BUFFER: list[dict] = []
LOG_LOCK = threading.Lock()

# Event buffer + condition variable for long-poll wakeup
EVENT_BUFFER: list[dict] = []
EVENT_LOCK = threading.Lock()
EVENT_COND = threading.Condition(EVENT_LOCK)
_EVENT_COUNTER = 0  # monotonic event id; survives buffer pruning

_server: ThreadingHTTPServer | None = None
_server_thread: threading.Thread | None = None
_tick_handle = None
_last_selection_sig: tuple | None = None  # for selection.changed detection


# ─────────────────────────────────────────────────────────────────────────────
# Event publishing
# ─────────────────────────────────────────────────────────────────────────────
def push_event(kind: str, data: dict | None = None) -> int:
    """Append an event to the buffer and wake any long-pollers.

    Returns the assigned monotonic event id. Available inside snippet scopes
    via the pre-injected ``push_event`` name — useful for tools that want
    to emit their own custom events (e.g. ``write_verse_file`` could push
    ``verse.file_written``).
    """
    global _EVENT_COUNTER
    with EVENT_COND:
        _EVENT_COUNTER += 1
        event = {
            "id": _EVENT_COUNTER,
            "kind": str(kind),
            "data": data if isinstance(data, dict) else {},
            "ts": time.time(),
        }
        EVENT_BUFFER.append(event)
        if len(EVENT_BUFFER) > EVENT_BUFFER_SIZE:
            EVENT_BUFFER.pop(0)
        EVENT_COND.notify_all()
        return event["id"]


def _filter_events(since_id: int, kinds: list[str] | None) -> list[dict]:
    """Caller must hold EVENT_COND. Returns events with id > since_id,
    optionally filtered by kind (None = all)."""
    if kinds is None:
        return [e for e in EVENT_BUFFER if e["id"] > since_id]
    kinds_set = set(kinds)
    return [
        e for e in EVENT_BUFFER
        if e["id"] > since_id and e["kind"] in kinds_set
    ]


def _wait_for_events(since_id: int, kinds: list[str] | None, timeout_s: float) -> dict:
    """Block until a matching event arrives or timeout elapses.

    Returns ``{"events": [...], "last_id": int}``. ``last_id`` is the
    highest id currently in the buffer (use as ``since_id`` for the next call).
    """
    deadline = time.time() + max(0.0, timeout_s)
    with EVENT_COND:
        while True:
            events = _filter_events(since_id, kinds)
            if events:
                break
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            EVENT_COND.wait(timeout=remaining)
        last_id = EVENT_BUFFER[-1]["id"] if EVENT_BUFFER else since_id
    return {"events": events, "last_id": last_id}


# ─────────────────────────────────────────────────────────────────────────────
# Output log capture (poor-man's get_output)
# ─────────────────────────────────────────────────────────────────────────────
class _LogCapture:
    """Wrap unreal.log/log_warning/log_error to also push into our ring buffer
    AND emit log.warning / log.error events for reactive consumers.

    Also detects Verse compile patterns and emits ``verse.build`` events.
    """
    _orig_log = unreal.log
    _orig_warn = unreal.log_warning
    _orig_err = unreal.log_error
    _installed = False

    @classmethod
    def install(cls):
        if cls._installed:
            return
        unreal.log = cls._make(cls._orig_log, "info")
        unreal.log_warning = cls._make(cls._orig_warn, "warning")
        unreal.log_error = cls._make(cls._orig_err, "error")
        cls._installed = True

    @staticmethod
    def _make(orig, level):
        def hooked(msg):
            try:
                m = str(msg)
                _push_log(level, m)
                # Reactive: emit log events for warning/error so the LLM can
                # block on wait_for_events and react immediately.
                if level in ("warning", "error"):
                    push_event("log." + level, {"msg": m})
                # Verse build pattern detection — UEFN logs "Verse compilation"
                # / "VerseBuild" lines from LogVerse. Pattern-match them.
                _maybe_emit_verse_build_event(level, m)
            except Exception:
                pass
            return orig(msg)
        return hooked


def _push_log(level: str, msg: str):
    with LOG_LOCK:
        LOG_BUFFER.append({"level": level, "msg": msg, "ts": time.time()})
        if len(LOG_BUFFER) > LOG_BUFFER_SIZE:
            LOG_BUFFER.pop(0)


def _maybe_emit_verse_build_event(level: str, msg: str):
    """Heuristic Verse-build detector. Errs on 'no event' rather than spam.

    UEFN's compile output is logged by LogVerse / LogVerseCompiler. We watch
    for the canonical "compilation succeeded" / "compilation failed" markers.
    Tweak this list if your UEFN version uses different strings.
    """
    low = msg.lower()
    if "verse compilation" not in low and "verse code compiled" not in low:
        return
    if "succeed" in low or "compiled successfully" in low:
        push_event("verse.build", {"status": "ok", "msg": msg})
    elif "fail" in low or "error" in low:
        push_event("verse.build", {"status": "fail", "msg": msg})


# ─────────────────────────────────────────────────────────────────────────────
# HTTP handler
# ─────────────────────────────────────────────────────────────────────────────
class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args, **kwargs):
        return  # silence default access log

    def _send_json(self, status: int, payload: dict):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {
                "ok": True,
                "service": "uefn-mcp-listener",
                "queue_depth": COMMAND_QUEUE.qsize(),
                "log_buffer_size": len(LOG_BUFFER),
                "event_buffer_size": len(EVENT_BUFFER),
                "event_counter": _EVENT_COUNTER,
            })
            return
        if self.path == "/log":
            with LOG_LOCK:
                self._send_json(200, {"log": list(LOG_BUFFER)})
            return
        if self.path == "/events/peek":
            with EVENT_COND:
                self._send_json(200, {
                    "events": list(EVENT_BUFFER),
                    "last_id": EVENT_BUFFER[-1]["id"] if EVENT_BUFFER else 0,
                })
            return
        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path == "/execute":
            self._handle_execute()
            return
        if self.path == "/events/wait":
            self._handle_events_wait()
            return
        if self.path == "/events/push":
            self._handle_events_push()
            return
        self._send_json(404, {"error": "not found"})

    # --- handlers --------------------------------------------------------

    def _handle_execute(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception as e:
            self._send_json(400, {"error": f"bad request: {e}"})
            return

        code = data.get("code", "")
        if not code:
            self._send_json(400, {"error": "missing 'code'"})
            return

        response_q: queue.Queue = queue.Queue(maxsize=1)
        COMMAND_QUEUE.put((code, response_q))

        try:
            result = response_q.get(timeout=EXEC_TIMEOUT_SECS)
        except queue.Empty:
            self._send_json(504, {"error": f"timeout after {EXEC_TIMEOUT_SECS}s"})
            return

        self._send_json(200, result)

    def _handle_events_wait(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception as e:
            self._send_json(400, {"error": f"bad request: {e}"})
            return

        since_id = int(data.get("since_id", 0))
        kinds = data.get("kinds")
        if kinds is not None and not isinstance(kinds, list):
            self._send_json(400, {"error": "'kinds' must be a list of strings or null"})
            return
        timeout_s = float(data.get("timeout_s", 25.0))
        timeout_s = max(0.0, min(timeout_s, LONG_POLL_MAX_SECS))

        out = _wait_for_events(since_id, kinds, timeout_s)
        self._send_json(200, out)

    def _handle_events_push(self):
        """Externally-pushed event (mostly for testing)."""
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception as e:
            self._send_json(400, {"error": f"bad request: {e}"})
            return

        kind = data.get("kind")
        if not kind:
            self._send_json(400, {"error": "missing 'kind'"})
            return
        evt_data = data.get("data") or {}
        eid = push_event(kind, evt_data)
        self._send_json(200, {"id": eid})


# ─────────────────────────────────────────────────────────────────────────────
# Game-thread tick: drain queue, exec safely, detect selection changes
# ─────────────────────────────────────────────────────────────────────────────
def _safe_subsystem(name: str):
    """Look up an editor subsystem by attribute name, returning None if unavailable.

    Some subsystems (notably MVVMEditorSubsystem) only exist when the matching
    plugin is enabled. We don't want a missing plugin to take down the whole
    listener, so we resolve lazily and silently.
    """
    cls = getattr(unreal, name, None)
    if cls is None:
        return None
    try:
        return unreal.get_editor_subsystem(cls)
    except Exception:
        return None


def _build_context() -> dict:
    """Pre-injected scope for executed code — same convention as kirchuvakov.

    Plus ``push_event`` so snippets can emit custom events (e.g. write_verse_file
    can push ``verse.file_written``).
    """
    return {
        "unreal": unreal,
        "actor_sub": _safe_subsystem("EditorActorSubsystem"),
        "asset_sub": _safe_subsystem("EditorAssetSubsystem"),
        "level_sub": _safe_subsystem("LevelEditorSubsystem"),
        "editor_sub": _safe_subsystem("UnrealEditorSubsystem"),
        "mvvm_sub": _safe_subsystem("MVVMEditorSubsystem"),
        "push_event": push_event,
        "result": None,
    }


def _check_selection():
    """Poll the editor's current selection; if it changed since last tick,
    emit a selection.changed event.

    Polling is fine here — we're already in the tick callback, and the
    actor list is small. UEFN doesn't expose a Python-side selection
    delegate (the C++ delegate isn't bound).
    """
    global _last_selection_sig
    try:
        editor_sub = _safe_subsystem("UnrealEditorSubsystem")
        if editor_sub is None:
            return
        actors = editor_sub.get_selected_level_actors()
        sig = tuple(a.get_path_name() for a in actors)
        if sig != _last_selection_sig:
            _last_selection_sig = sig
            push_event("selection.changed", {
                "actors": list(sig),
                "count": len(sig),
            })
    except Exception:
        pass


def _on_tick(_delta_seconds):
    """RUNS ON GAME THREAD — drain queue, exec each command, poll selection."""
    _check_selection()
    while True:
        try:
            code, response_q = COMMAND_QUEUE.get_nowait()
        except queue.Empty:
            return

        ctx = _build_context()
        try:
            exec(code, ctx)
            result = ctx.get("result")
            try:
                json.dumps(result)
            except (TypeError, ValueError):
                result = repr(result)
            response_q.put({"result": result})
        except Exception:
            response_q.put({"error": traceback.format_exc()})


# ─────────────────────────────────────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────────────────────────────────────
def start():
    """Idempotent — safe to call multiple times."""
    global _server, _server_thread, _tick_handle

    if _server is not None:
        unreal.log("[uefn-mcp] listener already running")
        return

    _LogCapture.install()

    _server = ThreadingHTTPServer((HOST, PORT), _Handler)
    _server_thread = threading.Thread(
        target=_server.serve_forever,
        name="uefn-mcp-http",
        daemon=True,
    )
    _server_thread.start()

    _tick_handle = unreal.register_slate_post_tick_callback(_on_tick)
    unreal.log("[uefn-mcp] listener started (events enabled)")

    # ── Boot diagnostics: show what paths we'll search for Verse files. ──
    # In UEFN, user projects are loaded as plugins, so project_content_dir()
    # may NOT point at the user's project. Logging this on boot makes it
    # obvious if we're pointed at the wrong place.
    try:
        import os as _os
        import sys as _sys
        proj_content = unreal.Paths.project_content_dir()
        proj_dir = unreal.Paths.project_dir()
        unreal.log(f"[uefn-mcp] UEFN project_dir = {proj_dir}")
        unreal.log(f"[uefn-mcp] UEFN project_content_dir = {proj_content}")

        # In UEFN, project_content_dir() returns FortniteGame/Content/ — the
        # engine's, not yours. The user project's Content/Python is on
        # sys.path (we just added it above), so one parent up = user Content.
        user_content = None
        for _entry in _sys.path:
            try:
                _norm = _os.path.normpath(_entry)
            except Exception:
                continue
            if (_os.path.basename(_norm).lower() == "python"
                    and _os.path.basename(_os.path.dirname(_norm)).lower() == "content"):
                _candidate = _os.path.dirname(_norm)
                if _os.path.isdir(_candidate):
                    user_content = _candidate
                    break

        if user_content:
            n = 0
            try:
                for _dp, _, _fs in _os.walk(user_content):
                    for _f in _fs:
                        if _f.endswith(".verse"):
                            n += 1
            except Exception:
                pass
            unreal.log(f"[uefn-mcp] user project Content = {user_content}")
            unreal.log(f"[uefn-mcp] .verse files in user project: {n}")
        else:
            unreal.log_warning(
                "[uefn-mcp] could NOT detect user project Content from sys.path — "
                "verse tools will return empty. Check init_unreal.py is the one "
                "shipped with this listener."
            )
    except Exception as _e:
        unreal.log_warning(f"[uefn-mcp] boot diagnostics failed: {_e}")


def stop():
    global _server, _server_thread, _tick_handle
    if _tick_handle is not None:
        unreal.unregister_slate_post_tick_callback(_tick_handle)
        _tick_handle = None
    if _server is not None:
        _server.shutdown()
        _server.server_close()
        _server = None
    _server_thread = None
    unreal.log("[uefn-mcp] listener stopped")
