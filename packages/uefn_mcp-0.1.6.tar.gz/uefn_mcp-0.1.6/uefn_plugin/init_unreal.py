"""
init_unreal.py — auto-loaded by UEFN on project open.

Place this file (and uefn_listener.py) in:
    [YourUEFNProject]/Content/Python/

UEFN's embedded Python 3.11 interpreter will auto-execute this on editor startup.
"""
import os
import sys
import unreal

# Make sibling modules importable
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

try:
    import uefn_listener
    uefn_listener.start()
    unreal.log("[uefn-mcp] ✅ Listener started on http://127.0.0.1:8766")
except Exception as e:
    unreal.log_error(f"[uefn-mcp] ❌ Failed to start listener: {e}")
    import traceback
    unreal.log_error(traceback.format_exc())
