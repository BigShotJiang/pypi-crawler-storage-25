# MVVM API Notes (verified against UE Python 5.7 docs)

This file is the **research summary** that drives the MVVM tool implementation
in `src/uefn_mcp/tools/mvvm.py`. Every claim below has been cross-checked
against the canonical Epic-published reference at
`https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/...`
(Python API 5.7) plus the UEFN-specific guides under
`https://dev.epicgames.com/documentation/en-us/uefn/...`.

> **v1.5 audit fixup.** A diff against the actual scrape revealed multiple
> errors in the v1.4 version of this file (phantom subsystem methods,
> incomplete property lists, a wrong type, fabricated quotes). All corrected
> below. The audit log lives at the bottom of this document.

The point: stop guessing from random GitHub repos *or* from prior memory.
UEFN has its own allow-list and validation pass on top of stock UE Python —
anything not in either of these doc sets is a runtime gamble.

---

## 1. Is MCP / Python in UEFN officially supported?

**Yes, verbatim.** Quote from Epic's own UEFN docs
(`uefn/python-tools-in-uefn`, line 18):

> "Remote execution of well made scripts or tools, such as a MCP integration
> with an Agentic AI."

is listed as a sanctioned Python use case. The relevant constraints, all
from the same page:

- "The Python implementation in UEFN doesn't have any restrictions. Work
  with properties you can modify in the UEFN interface, because any
  modification you make to properties not displayed in the UI will fail
  validation." (line 60)
- "Don't use the scripts to modify properties that are not allow-listed in
  UEFN. They will fail validation." (line 69)
- "Don't use the scripts to place content in your levels that you don't see
  in your content browsers or asset pickers." (line 71)
- "Don't modify content from outside of your project. You might crash the
  editor." (line 73)

Important nuance: **the Python runtime is unrestricted** (you can call any
method) but **validation will reject anything that touches non-allow-listed
properties or non-visible content**. So enforcement is not "wrap the API";
it's "design tools whose mutations stay inside the UI-allow-listed surface,
or accept that the change won't ship."

For MVVM specifically: the Python API surface itself is exposed, but UEFN
can still reject specific edits at validation time. We design every mutator
to be:

1. Wrapped in a `ScopedEditorTransaction` (so it's one Ctrl+Z step).
2. Prefer documented properties / methods from this surface map.
3. Multi-strategy fallback for setters that aren't fully Python-friendly.

---

## 2. Subsystem accessor

| Class | Use? |
|---|---|
| `unreal.MVVMSubsystem` | ❌ runtime CDO — `EngineSubsystem`, no editor verbs |
| `unreal.MVVMEditorSubsystem` | ✅ This is the right one — `EditorSubsystem` |

```python
sub = unreal.get_editor_subsystem(unreal.MVVMEditorSubsystem)
```

### Full method list on `MVVMEditorSubsystem` (21 methods, 5.7 docs)

Methods we actively use are bolded. Methods we don't currently expose are
left as-is — `execute_python` can call any of them directly via the
pre-injected `mvvm_sub` name.

| Method | Signature | Notes |
|---|---|---|
| **`add_binding`** | `(wbp) -> MVVMBlueprintViewBinding` | Used by `add_view_binding` |
| `add_condition` | `(wbp) -> MVVMBlueprintViewCondition` | Conditional bindings |
| `add_event` | `(wbp) -> MVVMBlueprintViewEvent` | VM-changed event hooks |
| `add_instanced_view_model` | `(wbp) -> Guid` | Inline VM creation |
| **`add_view_model`** | `(wbp, view_model: Class) -> Guid` | Used by `add_viewmodel_context` |
| **`get_available_conversion_functions`** | `(wbp, source, destination) -> Array[Function]` | Used by `list_available_conversions` |
| `get_child_view_models` | `(class_, accessor) -> Array[MVVMAvailableBinding]` | VM hierarchy traversal |
| `get_conversion_function` | `(wbp, binding, source_to_destination: bool) -> Function` | Read-only inspection |
| `get_conversion_function_graph` | `(wbp, binding, source_to_destination: bool) -> EdGraph` | Read-only inspection |
| `get_conversion_function_node` | `(wbp, binding, source_to_destination: bool) -> K2Node_CallFunction` | Read-only inspection |
| **`get_view`** | `(wbp) -> MVVMBlueprintView` | Returns None if no view exists |
| `is_simple_conversion_function` | `(function) -> bool` | Validation helper |
| `is_valid_conversion_function` | `(wbp, function, source, destination) -> bool` | Validation helper |
| **`remove_binding`** | `(wbp, binding) -> None` | Used by `remove_view_binding` |
| `remove_condition` | `(wbp, condition) -> None` | |
| `remove_event` | `(wbp, event) -> None` | |
| **`remove_view_model`** | `(wbp, view_model: Name) -> None` | ⚠️ takes **Name**, not Guid |
| `rename_view_model` | `(wbp, view_model: Name, new_view_model: Name) -> Text\|None` | Returns error text or None |
| `reparent_view_model` | `(wbp, view_model: Name, new_view_model: Class) -> Text\|None` | Returns error text or None |
| **`request_view`** | `(wbp) -> MVVMBlueprintView` | Creates view if absent |
| `verify_view_model_rename` | `(wbp, view_model: Name, new_view_model: Name) -> Text\|None` | Pre-flight check |

### ⚠️ Methods that do NOT exist (don't call them)

These were claimed in pre-audit notes but **are not in the 5.7 docs**.
Calling them via `getattr(sub, ...)` returns `None`, so existing code
soft-fails — but the feature won't work:

- `set_source_to_destination_conversion_function` ❌
- `set_destination_to_source_conversion_function` ❌

See §6 for what to do for conversion functions instead.

---

## 3. Editor properties — Read-Only vs Read-Write surface map

Documented `[Read-Write]` properties can be written via
`set_editor_property`. `[Read-Only]` cannot — *per docs* — but for
**struct-typed Read-Only properties** (path objects, conversion paths) we
still try, because the doc category sometimes reflects "no individual
setter UFUNCTION" rather than "the struct field is C++-const". When in
doubt, the path-setter helpers in `_snippets.MVVM_HELPERS` try multiple
strategies and report what worked.

### `MVVMBlueprintView` (5 properties)

| Property | Type | Access |
|---|---|---|
| `available_view_models` | `Array[MVVMBlueprintViewModelContext]` | **Read-Write** ✅ |
| `bindings` | `Array[MVVMBlueprintViewBinding]` | **Read-Write** ✅ |
| `compiled_binding_library_id` | `Guid` | Read-Only |
| `conditions` | `Array[MVVMBlueprintViewCondition]` | **Read-Write** ✅ |
| `events` | `Array[MVVMBlueprintViewEvent]` | **Read-Write** ✅ |

Use `view.get_editor_property("bindings")` — **NOT** `view.get_bindings()`.
The view object is a `UObject` with editor properties, not a method-rich
runtime object.

We don't currently expose tools for `conditions` or `events` — see roadmap
discussion in chat history (tool-count vs. workflow-value tradeoff).

### `MVVMBlueprintViewBinding` (8 properties)

| Property | Type | Access |
|---|---|---|
| `binding_id` | `Guid` | Read-Only — identity |
| `binding_type` | `MVVMBindingMode` | **Read-Write** ✅ |
| `compile` | `bool` | **Read-Write** ✅ |
| `conversion` | `MVVMBlueprintViewConversionPath` | Read-Only ⚠️ |
| `destination_path` | `MVVMBlueprintPropertyPath` | Read-Only ⚠️ |
| `enabled` | `bool` | **Read-Write** ✅ |
| `override_execution_mode` | `MVVMExecutionMode` (enum, not bool) | **Read-Write** ✅ |
| `source_path` | `MVVMBlueprintPropertyPath` | Read-Only ⚠️ |

⚠️ **`override_execution_mode` is the `MVVMExecutionMode` enum**, not a
bool. Don't pass `True` / `False` to it — pass an enum value
(`MVVMExecutionMode.IMMEDIATE`, etc.).

The path properties (`source_path`, `destination_path`) are Read-Only per
docs but mutable in practice — see `_set_path_*` helpers.

### `MVVMBlueprintPropertyPath` (and aliases `MVVMWidgetPropertyPath`, `MVVMViewModelPropertyPath`)

**ALL 5 properties Read-Only:**

| Property | Type |
|---|---|
| `widget_name` | `Name` |
| `context_id` | `Guid` |
| `is_component` | `bool` |
| `paths` | `Array[MVVMBlueprintFieldPath]` |
| `source` | `MVVMBlueprintFieldPathSource` |

There are **no documented UFUNCTIONs** named `set_widget_name` /
`set_view_model_id` / `set_property_path`. The path setters in
`_snippets.MVVM_HELPERS` use a multi-strategy fallback (typed UFUNCTION
attempt → `set_editor_property` → direct `paths` array writes via
`MVVMBlueprintFieldPath`) and stamp the `source` enum
(`WIDGET` / `VIEW_MODEL`) for editor-UI sync.

### `MVVMBlueprintFieldPath`

| Property | Type | Access |
|---|---|---|
| `binding_reference` | `MemberReference` | **Read-Write** ✅ |

The single Read-Write surface inside the path tree. We use it as a
Strategy B fallback when constructing path arrays directly.

### `MVVMBlueprintViewConversionPath`

| Property | Type | Access |
|---|---|---|
| `destination_to_source_conversion` | `MVVMBlueprintViewConversionFunction` | Read-Only |
| `source_to_destination_conversion` | `MVVMBlueprintViewConversionFunction` | Read-Only |

### `MVVMBlueprintViewConversionFunction` (6 properties, all Read-Only)

| Property | Type | Access |
|---|---|---|
| `conversion_function` | `MVVMBlueprintFunctionReference` | Read-Only |
| `destination_path` | `MVVMBlueprintPropertyPath` | Read-Only |
| `graph_name` | `Name` | Read-Only |
| `is_ubergraph_page` | `bool` | Read-Only |
| `saved_pins` | `Array[MVVMBlueprintPin]` | Read-Only |
| `wrapper_graph_transient` | `bool` | Read-Only |

**Implication:** there is no documented Python path to set a conversion
function. See §6.

### `MVVMBlueprintViewModelContext` (15 properties)

Most are **Read-Write** ✅:

- `view_model_name` (Name)
- `creation_type` (MVVMBlueprintViewModelContextCreationType)
- `expose_instance_in_editor` (bool)
- `optional` (bool)
- `force_execute_bindings_on_set_source` (bool)
- `global_view_model_collection_update` (bool)
- `global_view_model_identifier` (Name)
- `instanced_view_model` (MVVMBlueprintInstancedViewModelBase)
- `resolver` (MVVMViewModelContextResolver)
- `view_model_property_path` (str)
- `use_as_interface` (bool)
- `notify_field_value_class` (Class)
- `create_getter_function` (bool)
- `create_setter_function` (bool)

Read-Only:

- `view_model_context_id` (Guid)

---

## 4. Enums (numeric values, verified)

### `MVVMBindingMode`

| Name | Value |
|---|---|
| `ONE_TIME_TO_DESTINATION` | 0 |
| `ONE_WAY_TO_DESTINATION` | 1 |
| `TWO_WAY` | 2 |
| `ONE_WAY_TO_SOURCE` | 4 |

⚠️ **Value 3 is unused.** The enum is `[0, 1, 2, 4]`, not contiguous.
If you ever iterate (`for i in range(4)`) you'll skip `ONE_WAY_TO_SOURCE`
*and* hit a phantom value 3. (Historically value 3 was probably
`ONE_TIME_TO_SOURCE`, since deprecated.)

### `MVVMBlueprintFieldPathSource`

| Name | Value |
|---|---|
| `NONE` | 0 |
| `WIDGET` | 1 |
| `VIEW_MODEL` | 2 |
| `SELF_CONTEXT` | 3 |

### `MVVMBlueprintViewModelContextCreationType`

| Name | Value |
|---|---|
| `MANUAL` | 0 |
| `CREATE_INSTANCE` | 1 |
| `GLOBAL_VIEW_MODEL_COLLECTION` | 2 |
| `PROPERTY_PATH` | 3 |
| `RESOLVER` | 4 |

### `MVVMExecutionMode` (used by `override_execution_mode`)

Values exist in the docs but we don't currently surface them. To list them on
a live install, run
`execute_python("result = sorted(n for n in dir(unreal.MVVMExecutionMode) if n.isupper())")`.
The point is: when writing `override_execution_mode`, pass an
`MVVMExecutionMode` member, **not** a bool.

---

## 5. UEFN-specific MVVM context (from UEFN guides)

The UEFN guide
`uefn/using-the-viewmodel-in-umg-in-unreal-editor-for-fortnite` confirms:

- ViewModels are **natively part of UMG in UEFN** — not a separate plugin.
  `HUDPlayerInfoViewModel` and `HUDPlayerInfoListViewModel` are canonical
  Fortnite-provided viewmodels.

- The MVVM workflow shown in the *Custom Health & Shield Bars* guide
  (`uefn/making-custom-health-and-shield-bars-in-unreal-editor-for-fortnite`)
  is **purely UI-driven**:
  Window → Viewmodels → +Viewmodel → Window → View Bindings → Add Widget …

- **No Python code samples in any UEFN guide.** Our Python tools are
  reverse-engineered from the canonical UE Python docs + runtime reflection
  (`execute_python("result = dir(unreal.MVVM...)")`).

Walkthroughs we cross-referenced:
- `tmnt-custom-ui-player-info-in-unreal-editor-for-fortnite.md` — full
  `HUDPlayerInfoViewModel` walkthrough.
- `making-custom-health-and-shield-bars-in-unreal-editor-for-fortnite.md`
- `making-custom-backplates-in-unreal-editor-for-fortnite.md`
- `making-a-custom-squad-view-in-unreal-editor-for-fortnite.md`
- `conversion-functions-{showing-textures, to-text-int-and-double, setting-material-parameters}.md`

If anything in this doc looks wrong on your install, the empirical check is
one line: `execute_python("result = sorted(dir(unreal.MVVMEditorSubsystem))")`
(or whichever class is in question). v1.4–v1.5 wrapped this in a
`probe_mvvm_api` MCP tool; v1.6 dropped the wrapper since `execute_python`
is the same call without the routing slot.

---

## 6. Setting conversion functions (the painful one)

**Bottom line: there is no documented Python path to set a conversion
function on a binding in 5.7.** Every related surface is Read-Only:

- `MVVMEditorSubsystem` has `get_conversion_function*` (3 read methods)
  and `is_simple/valid_conversion_function` (validation), but **no setter**.
- `MVVMBlueprintViewBinding.conversion` is Read-Only.
- Both `source_to_destination_conversion` and
  `destination_to_source_conversion` inside `MVVMBlueprintViewConversionPath`
  are Read-Only.
- `MVVMBlueprintViewConversionFunction.conversion_function` is Read-Only.

What we do in `add_view_binding`:

1. Try a best-effort in-place `set_editor_property` on the conversion
   struct. This usually fails (logs `:fail(...)` in the result's
   `conversion.attempts`).
2. Surface a clear note in the result telling the caller to set the
   conversion in the WBP designer instead.
3. Leave room for `execute_python` escape-hatch usage if a specific UEFN
   build exposes an undocumented setter — a quick
   `execute_python("result = sorted(dir(unreal.MVVMEditorSubsystem))")`
   will reveal it if so.

What you should do as a user: build the binding via `add_view_binding`,
compile, then open the WBP and set the conversion function in the
designer's view binding panel. Re-saving the WBP persists the conversion;
subsequent compiles will keep it.

---

## 7. UEFN restrictions to keep in mind

From `uefn/python-tools-in-uefn` (the only UEFN doc that discusses Python
restrictions — see §8 for sources we removed):

- **Python runtime is unrestricted**: you can call any documented method.
- **Validation rejects writes to non-allow-listed properties**: the rule
  is "if you can change it in the UEFN UI, you can change it from Python."
- **Don't place content not in your asset picker**: validation rejects it.
- **Don't modify content from outside your project**: may crash the editor.

For MVVM specifically:
- WidgetTree is C++-protected — read-only in Python (this is a UE-wide
  constraint, not UEFN-specific).
- Validation can refuse non-allow-listed property writes — wrap in
  transactions so they roll back cleanly on failure.

From `uefn/uefn-vs-ue-in-unreal-editor-for-fortnite`:
- "Blueprint visual scripting is not available in UEFN for gameplay or
  other custom scripts." — **Use Verse**, not Blueprints, for game logic.

---

## 8. Workflow contract for `add_view_binding`

Verified against the doc surface above:

```
1. wbp = load_asset(wbp_path)
2. sub = get_editor_subsystem(MVVMEditorSubsystem)
3. view = sub.request_view(wbp)
4. # Resolve VM name → guid
   for vm in view.get_editor_property("available_view_models"):
       if vm.get_editor_property("view_model_name") == ctx_name:
           vm_guid = vm.get_editor_property("view_model_context_id")
5. binding = sub.add_binding(wbp)            # appends to bindings array
6. src_path = binding.get_editor_property("source_path")
   dst_path = binding.get_editor_property("destination_path")
7. # path setters — best-effort, see _set_path_* helpers
   _set_path_viewmodel(src_path, vm_guid)         # also stamps source=VIEW_MODEL
   _set_path_property_name(src_path, wbp, vm_field)
   _set_path_widget(dst_path, widget_name)        # also stamps source=WIDGET
   _set_path_property_name(dst_path, wbp, widget_property)
8. binding.set_editor_property("binding_type", MVVMBindingMode.ONE_WAY_TO_DESTINATION)
9. binding.set_editor_property("enabled", True)
   binding.set_editor_property("compile", True)
10. # OPTIONAL — see §6. Almost certainly fails. Set conversion in editor.
    conv = binding.get_editor_property("conversion")
    conv.set_editor_property("source_to_destination_conversion", fn)  # likely fails
11. compile + save WBP
```

**Step 7 is the brittle one.** When in doubt, verify the live surface with
`execute_python("result = sorted(dir(unreal.MVVMBlueprintPropertyPath))")`;
the path setters also return a debug list of every attempt for diagnosis.

---

## 9. v1.5 audit fixup — what changed since v1.4

A diff against the actual scrape revealed the following errors in the v1.4
version of this document:

| Section | Error | Fix |
|---|---|---|
| §2 | Listed `set_source_to_destination_conversion_function` and `set_destination_to_source_conversion_function` as existing methods | Removed — they don't exist in 5.7 docs. Code that called them soft-failed silently. |
| §2 | Method list was 9 entries; actual is 21 | Full table added |
| §3 (`MVVMBlueprintView`) | Listed 2 properties; actual is 5 | Added `compiled_binding_library_id`, `conditions`, `events` |
| §3 (`MVVMBlueprintViewBinding`) | `override_execution_mode` typed as `bool` | Corrected to `MVVMExecutionMode` enum |
| §3 (new) | `MVVMBlueprintViewConversionPath` and `MVVMBlueprintViewConversionFunction` not documented | Added — both fully Read-Only |
| §4 (`MVVMBindingMode`) | No mention of value 3 being absent | Explicit gap warning added |
| §6 (new) | Conversion-function story was implicit and wrong | Whole new section spelling out "Read-Only — set in editor" |
| §7 | Cited `uefn-vs-ue-in-unreal-editor-for-fortnite.md` for "C++ projects are not supported" / "Custom plugins are not supported" | Both quotes were fabricated — not in any scraped page. Removed. |
| §1 | Restrictions cited generically | Now quotes `python-tools-in-uefn.md` line numbers verbatim |

Code changes shipped alongside this doc rewrite:

- `tools/mvvm.py` — `add_view_binding` no longer calls phantom
  `set_*_conversion_function` methods. Tries in-place mutation on the
  Read-Only conversion struct and reports `applied: false` with a clear
  note pointing to the editor UI when it fails.
- Docstrings updated to flag conversion-function setting as best-effort.

If a binding tool still fails after v1.5, **dump the live API surface first**.
One `execute_python` call per class (or roll them into one snippet):

```python
execute_python('''
import unreal
result = {
    "MVVMEditorSubsystem":          sorted(dir(unreal.MVVMEditorSubsystem)),
    "MVVMBlueprintView":            sorted(dir(unreal.MVVMBlueprintView)),
    "MVVMBlueprintPropertyPath":    sorted(dir(unreal.MVVMBlueprintPropertyPath)),
    "MVVMBlueprintViewBinding":     sorted(dir(unreal.MVVMBlueprintViewBinding)),
    "MVVMBindingMode":              sorted(n for n in dir(unreal.MVVMBindingMode) if n.isupper()),
    "MVVMBlueprintFieldPathSource": sorted(n for n in dir(unreal.MVVMBlueprintFieldPathSource) if n.isupper()),
    "MVVMBlueprintViewModelContextCreationType":
        sorted(n for n in dir(unreal.MVVMBlueprintViewModelContextCreationType) if n.isupper()),
}
''')
```

(v1.4–v1.5 wrapped this in a `probe_mvvm_api` MCP tool. v1.6 dropped the
wrapper since it was a packaged `dir()` walk competing with `execute_python`
for the LLM's routing slot — same tool-count discipline that killed
`push_test_event` and `get_recent_events`.)
