"""
uefn_mcp._bridge — shared FastMCP instance, HTTP transport, transaction wrapper.

Every tool module imports `mcp` from here to register its tools, and uses
`post_execute` / `wrap_transaction` to actually execute Python on the UEFN
game thread.

The bridge is intentionally tiny — all interesting domain logic lives in
the `tools/` package.
"""
from __future__ import annotations

import os
import textwrap
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────
# The listener defaults to binding 127.0.0.1:8766 on the host running UEFN.
# Override via env var if the MCP server runs somewhere else than UEFN
# (e.g. server in WSL, UEFN on Windows host: set UEFN_MCP_LISTENER_URL to
# http://<windows-host-ip>:8766 after binding the listener to 0.0.0.0,
# or run the server on Windows directly).
LISTENER_URL = os.environ.get("UEFN_MCP_LISTENER_URL", "http://127.0.0.1:8766")
HTTP_TIMEOUT = float(os.environ.get("UEFN_MCP_HTTP_TIMEOUT", "35.0"))
# listener itself times out at 30s, give us a small buffer

# The single shared FastMCP server instance. Tool modules register against this.
mcp = FastMCP("uefn-mcp")


# ─────────────────────────────────────────────────────────────────────────────
# HTTP bridge to the UEFN listener
# ─────────────────────────────────────────────────────────────────────────────
def post_execute(code: str) -> Any:
    """Send Python code to UEFN's /execute endpoint and return its `result`.

    The listener pre-injects these names into the snippet's namespace:
        unreal, actor_sub, asset_sub, level_sub, editor_sub, mvvm_sub, result

    Snippets must assign their return value to ``result``.
    """
    try:
        r = httpx.post(
            f"{LISTENER_URL}/execute",
            json={"code": code},
            timeout=HTTP_TIMEOUT,
        )
    except httpx.ConnectError as e:
        raise RuntimeError(
            f"Cannot reach UEFN listener at {LISTENER_URL}. "
            f"Is UEFN open with the plugin installed? ({e})"
        ) from e

    if r.status_code != 200:
        raise RuntimeError(f"listener {r.status_code}: {r.text}")

    payload = r.json()
    if "error" in payload:
        raise RuntimeError(payload["error"])
    return payload.get("result")


def get(path: str) -> Any:
    """GET a JSON endpoint on the UEFN listener (used for /health, /log)."""
    try:
        r = httpx.get(f"{LISTENER_URL}{path}", timeout=5.0)
    except httpx.ConnectError as e:
        raise RuntimeError(f"Cannot reach UEFN listener: {e}") from e
    r.raise_for_status()
    return r.json()


def post_long_poll(path: str, body: dict, server_timeout_s: float) -> Any:
    """POST to a long-poll endpoint (e.g. /events/wait).

    The server may block for up to ``server_timeout_s`` waiting for events.
    We give httpx ``server_timeout_s + 10`` as a buffer so the underlying
    socket doesn't time out before the listener returns.

    Returns the parsed JSON body on 200; raises RuntimeError otherwise.
    """
    try:
        r = httpx.post(
            f"{LISTENER_URL}{path}",
            json=body,
            timeout=server_timeout_s + 10.0,
        )
    except httpx.ConnectError as e:
        raise RuntimeError(
            f"Cannot reach UEFN listener at {LISTENER_URL}. "
            f"Is UEFN open with the plugin installed? ({e})"
        ) from e

    if r.status_code != 200:
        raise RuntimeError(f"listener {r.status_code}: {r.text}")
    return r.json()


# ─────────────────────────────────────────────────────────────────────────────
# Transaction helper
# ─────────────────────────────────────────────────────────────────────────────
def wrap_transaction(label: str, code: str) -> str:
    """Wrap a snippet in a ScopedEditorTransaction so it's a single Ctrl+Z step.

    Falls back to a plain run if ScopedEditorTransaction isn't available
    (older UE Python builds). The fallback path is exec-equivalent.
    """
    indented = textwrap.indent(code, "        ")
    return textwrap.dedent(f"""
        try:
            _txn = unreal.ScopedEditorTransaction({label!r})
        except Exception:
            _txn = None
        if _txn is not None:
            with _txn:
{indented}
        else:
{indented}
    """)
