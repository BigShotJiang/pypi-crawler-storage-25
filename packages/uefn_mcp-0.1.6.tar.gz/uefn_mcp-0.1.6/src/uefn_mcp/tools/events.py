"""
Reactive event tool — long-poll the UEFN listener for editor events.

Architecture:
    UEFN editor ─► listener.push_event() ─► EVENT_BUFFER ─► /events/wait ─► LLM

``wait_for_events`` blocks (HTTP long-poll, up to 60s) until matching events
arrive. Stdlib-only on the listener side — no ``websockets`` dependency.

What this is FOR (honest framing, post-v1.6 audit):

    This is a **human-in-the-loop coordination primitive**, not an autonomous
    reactivity engine. The events that fire today are:

      log.error / log.warning  — usually echoes of what the LLM just did
                                 (already returned synchronously via
                                 execute_python's response)
      verse.file_written       — circular: emitted by write_verse_file itself
      verse.build              — fires when the **user** presses Ctrl+Shift+B
      selection.changed        — fires when the **user** clicks an actor

    Realistic uses:
      - "I wrote MyDevice.verse. Press Ctrl+Shift+B — I'll wait for the build."
            wait_for_events(kinds=["verse.build"], timeout_s=60)
      - "Click the wall you want me to align to. I'll wait."
            wait_for_events(kinds=["selection.changed"], timeout_s=120)

    The listener has NO gameplay hooks today — there are no ``player.spawned``
    or ``device.triggered`` events flowing in from PIE. The MCP tool surface
    also can't START a play session (that's a UI action). If/when game-event
    hooks land, this primitive is ready for them; until then, treat it as
    "wait for the human at the keyboard to do X".

Peek mode: ``wait_for_events(timeout_s=0)`` returns immediately with whatever
is in the buffer since the cursor — useful for "did anything error recently?"
without blocking. ``max_count`` caps the returned slice.

The ``since_id`` cursor is monotonic across buffer prunes — safe to use as a
"give me events newer than this" cursor across calls.

Custom events: any tool that runs Python in the listener can call
``push_event(kind, data)`` (pre-injected). External non-MCP clients can also
POST to ``/events/push``. There is intentionally no ``push_test_event`` MCP
tool — see v1.6 audit.
"""
from __future__ import annotations

from .._bridge import mcp, post_long_poll


@mcp.tool()
def wait_for_events(
    kinds: list[str] | None = None,
    since_id: int = 0,
    timeout_s: int = 25,
    max_count: int = 100,
) -> dict:
    """Block until matching events arrive in the listener, or timeout elapses.

    This is the long-poll primitive. The server holds the request open until
    events match, so the LLM doesn't have to spin-poll.

    Set ``timeout_s=0`` to peek the buffer without blocking — useful when you
    just want to know if anything errored recently.

    Args:
        kinds: Event kinds to filter on (e.g. ``["log.error", "verse.build"]``).
            ``None`` means all kinds.
        since_id: Return events with id > since_id. Use the ``last_id`` from
            the previous call as a cursor.
        timeout_s: Max seconds to block. Capped at 60 server-side. ``0`` =
            non-blocking peek.
        max_count: Client-side cap on returned events (default 100, server
            buffer holds up to 500).

    Returns:
        ``{"events": [{"id", "kind", "data", "ts"}, ...], "last_id": N}``

        Empty ``events`` means timeout fired with nothing matching — call
        again with ``since_id=last_id`` to keep waiting.

    Realistic patterns:
        # Wait for the user to press Ctrl+Shift+B after you write Verse code
        out = wait_for_events(kinds=["verse.build"], timeout_s=60)

        # Peek for recent errors
        out = wait_for_events(kinds=["log.error"], timeout_s=0, max_count=20)
    """
    body = {
        "since_id": int(since_id),
        "kinds": list(kinds) if kinds else None,
        "timeout_s": max(0, min(int(timeout_s), 60)),
    }
    out = post_long_poll(
        "/events/wait", body, server_timeout_s=body["timeout_s"]
    )
    cap = max(1, int(max_count))
    if isinstance(out, dict) and isinstance(out.get("events"), list):
        out["events"] = out["events"][-cap:]
    return out
