"""
Widget Blueprint tools — creation, duplication, compile, and read-only inspection.

Why no widget-tree authoring? UE 5.7 Python deliberately doesn't expose the
hierarchy-mutation surface at design time. Verified against the firecrawl
scrape (wave 4):

    - ``WidgetTree``           — docs stub: ``Bases: Object``, zero methods.
    - ``BaseWidgetBlueprint``  — docs stub: only blueprint metadata.
    - ``UserWidgetBlueprint``  — docs stub.
    - ``WidgetBlueprint``      — docs stub: only thumbnail / category props.
    - ``UserWidgetExtension``  — docs stub.
    - ``WidgetBlueprintFactory`` — only factory metadata, no tree access.
    - 5 helper libraries (``WidgetLibrary``, ``WidgetLayoutLibrary``,
      ``UserWidgetFunctionLibrary``, ``WidgetReferenceBlueprintFunctionLibrary``,
      ``WidgetAnimationHandleFunctionLibrary``) — runtime-only, zero
      authoring methods.

C++ ``UWidgetTree::ConstructWidget<T>`` is templated, which UnrealHeaderTool
can't UFUNCTION-expose to Python. Lock by omission, not policy.

``PanelWidget.add_child()`` / ``clear_children()`` etc. *are* documented in
5.7 — but they only mutate already-instantiated widgets at *runtime*, not the
persisted WBP at editor time. Epic's design intent: author UMG in the
Designer, attach bindings via ``MVVMEditorSubsystem`` Python verbs, consume
from Verse at runtime.

So this module: create the asset shell, inspect what's there, compile/save.
The MVVM mutator tools (``add_view_binding``, ``add_viewmodel_context``,
etc.) live in ``tools/mvvm.py``.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute, wrap_transaction
from .._snippets import ACTOR_HELPERS, MVVM_HELPERS, WIDGET_INSPECT_HELPERS


# ─────────────────────────────────────────────────────────────────────────────
# Creation / duplication / compile
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool()
def create_widget_blueprint(
    name: str,
    package_path: str = "/Game/UI",
    parent_class: str = "UserWidget",
) -> dict:
    """Create an empty Widget Blueprint asset shell.

    The contents (visual hierarchy) must be authored in UEFN's widget designer
    — that's the wall we can't cross. But the asset shell + everything around
    it (variables, viewmodels, bindings) IS scriptable.
    """
    code = textwrap.dedent(f"""
        factory = unreal.WidgetBlueprintFactory()
        try:
            parent = getattr(unreal, {parent_class!r}, None)
            if parent is None:
                parent = unreal.load_class(None, "/Script/UMG." + {parent_class!r})
            if parent is None:
                parent = unreal.UserWidget
            factory.set_editor_property("parent_class", parent)
        except Exception:
            pass

        tools = unreal.AssetToolsHelpers.get_asset_tools()
        wbp = tools.create_asset(
            asset_name={name!r},
            package_path={package_path!r},
            asset_class=unreal.WidgetBlueprint,
            factory=factory,
        )
        if wbp is None:
            raise RuntimeError("create_asset returned None — does it already exist?")

        unreal.EditorAssetLibrary.save_loaded_asset(wbp)
        result = {{
            "path": wbp.get_path_name(),
            "name": wbp.get_name(),
            "parent": {parent_class!r},
        }}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: create_widget_blueprint {name}", code))


@mcp.tool()
def duplicate_widget_blueprint(source_path: str, dest_path: str) -> dict:
    """Duplicate a Widget Blueprint (preserves widget tree + bindings).

    Pattern: build one master card in the designer, then duplicate per slot
    and rebind each copy to a different viewmodel slot via ``add_view_binding``.
    """
    code = textwrap.dedent(f"""
        ok = unreal.EditorAssetLibrary.duplicate_asset({source_path!r}, {dest_path!r})
        if not ok:
            raise RuntimeError("duplicate failed (does dest already exist?)")
        unreal.EditorAssetLibrary.save_asset({dest_path!r})
        result = {{"source": {source_path!r}, "dest": {dest_path!r}}}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: duplicate_widget {dest_path}", code))


@mcp.tool()
def compile_widget_blueprint(wbp_path: str, save: bool = True) -> dict:
    """Compile a Widget Blueprint after structural changes (and save by default).

    Always call this after add/remove view bindings. Bindings won't take
    effect at runtime until the WBP is recompiled.
    """
    code = textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")

        compiled = False
        try:
            unreal.BlueprintEditorLibrary.compile_blueprint(wbp)
            compiled = True
        except Exception as e:
            raise RuntimeError("compile_blueprint failed: " + str(e))

        saved = False
        if {save!r}:
            saved = bool(unreal.EditorAssetLibrary.save_loaded_asset(wbp))

        result = {{"path": {wbp_path!r}, "compiled": compiled, "saved": saved}}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: compile_widget {wbp_path}", code))


# ─────────────────────────────────────────────────────────────────────────────
# Inspection (read-only)
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool()
def inspect_widget(wbp_path: str) -> dict:
    """Inspect a Widget Blueprint — enumerate named widgets, viewmodels, and bindings.

    This is the LLM's eyes into a widget. It can't see *positions* (the
    `WidgetTree` Python class is doc-stubbed in 5.7 — see this module's
    top-level docstring for the full lock-by-omission writeup) but it sees
    every widget you've named, its class, and what's already wired up.

    Returns:
        ``{"wbp", "widgets", "view_bindings", "viewmodels", "warnings"}``
    """
    code = WIDGET_INSPECT_HELPERS + MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")

        warnings = []
        widgets = _enumerate_named_widgets(wbp)
        for w in widgets:
            w["bindable_props"] = _common_bindable_props(w["type"])

        if not widgets:
            warnings.append(
                "No named widgets found. In the designer, mark each widget as "
                "'Is Variable' (gear icon next to the widget name) so it can "
                "be referenced from bindings/code."
            )

        view_bindings = []
        viewmodels = []
        try:
            view = _mvvm_view(wbp)
        except Exception as e:
            view = None
            warnings.append(str(e))

        if view is not None:
            for i, b in enumerate(_mvvm_view_bindings(view)):
                view_bindings.append(_summarize_binding(b, idx=i))
            for vm in _mvvm_view_models(view):
                try:
                    vm_class = vm.get_editor_property("notify_field_value_class")
                except Exception:
                    vm_class = None
                try:
                    vm_name = vm.get_editor_property("view_model_name")
                except Exception:
                    vm_name = None
                try:
                    ctx_id = vm.get_editor_property("view_model_context_id")
                except Exception:
                    ctx_id = None
                viewmodels.append({{
                    "name": str(vm_name) if vm_name else None,
                    "class": vm_class.get_name() if vm_class else None,
                    "context_id": str(ctx_id) if ctx_id else None,
                }})

        result = {{
            "wbp": {wbp_path!r},
            "widgets": widgets,
            "view_bindings": view_bindings,
            "viewmodels": viewmodels,
            "warnings": warnings,
        }}
    """)
    return post_execute(code)


@mcp.tool()
def get_widget_tree(wbp_path: str, max_depth: int = 8) -> dict:
    """Read the visual widget hierarchy of a Widget Blueprint.

    Returns the tree of widgets with their classes and slot types — read-only.
    Even though UEFN locks the widget tree from Python *writes*, reading it
    works, so the LLM can understand what's there before deciding what to
    bind to.
    """
    code = WIDGET_INSPECT_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")
        root = _get_widget_tree_root(wbp)
        if root is None:
            result = {{"wbp": {wbp_path!r}, "tree": None,
                       "note": "no root widget — open the WBP in the designer "
                               "and add a root panel."}}
        else:
            result = {{
                "wbp": {wbp_path!r},
                "tree": _summarize_widget(root, max_depth={max_depth}),
            }}
    """)
    return post_execute(code)


@mcp.tool()
def inspect_viewmodel(vm_class_path: str) -> dict:
    """Inspect a ViewModel class — list its bindable fields and types.

    Args:
        vm_class_path: full asset path or class path,
            e.g. ``/Game/ViewModels/HUDPlayerInfoViewModel``
            or ``HUDPlayerInfoViewModel`` if it's findable by short name.

    Returns: ``{"class", "fields": [{"name", "type", "sample"}]}``
    """
    code = ACTOR_HELPERS + MVVM_HELPERS + textwrap.dedent(f"""
        cls = _resolve_class({vm_class_path!r})
        if cls is None:
            raise ValueError("viewmodel class not found: " + {vm_class_path!r})

        cdo = cls.get_default_object()
        names = unreal.SystemLibrary.get_object_property_names(cdo)

        fields = []
        for n in names:
            entry = {{"name": n, "type": "?"}}
            try:
                v = cdo.get_editor_property(n)
                if v is None:
                    entry["type"] = "?(None)"
                elif isinstance(v, bool):
                    entry["type"] = "bool"
                elif isinstance(v, int):
                    entry["type"] = "int"
                elif isinstance(v, float):
                    entry["type"] = "float"
                elif isinstance(v, str):
                    entry["type"] = "str"
                elif hasattr(v, "get_class"):
                    entry["type"] = v.get_class().get_name()
                else:
                    entry["type"] = type(v).__name__
                entry["sample"] = _safe_prop_value(v)
            except Exception as e:
                entry["type"] = "<unreadable: " + str(e) + ">"
            fields.append(entry)

        result = {{
            "class": cls.get_name(),
            "fields": fields,
        }}
    """)
    return post_execute(code)
