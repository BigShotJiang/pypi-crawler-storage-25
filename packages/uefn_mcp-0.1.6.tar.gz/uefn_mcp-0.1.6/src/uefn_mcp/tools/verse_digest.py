"""
Verse digest tooling.

When you write Verse code in UEFN, the editor auto-generates ``.digest.verse``
files that contain the canonical Verse API surface — every device, class, and
function exposed by Fortnite / UnrealEngine / Verse modules.

These files are the **source of truth** for "what devices exist and what can
they do?". They live at:

  - ``Plugins/Fortnite/Content/Fortnite.digest.verse``        (devices)
  - ``Plugins/UnrealEngine/Content/UnrealEngine.digest.verse``
  - ``Plugins/Verse.org/Content/Verse.digest.verse``           (core types)

Without digest awareness the LLM falls back to its training data, which is
stale and incomplete for UEFN Verse (the language is moving fast). With it,
"create a system that uses a trigger and a prop_mover" becomes:

    list_verse_devices(module="Fortnite") → see what exists
    get_verse_device_api("trigger_device") → grab Trigger() / Reset() etc.
    get_verse_device_api("prop_mover_device") → grab Move() / Stop() etc.
    write_verse_file(...)

NOTE: digests are large (up to 50K lines / 5MB). All four tools below do
**targeted server-side extraction** — never roundtrip whole digest content
to the LLM. The most expensive call (``get_verse_device_api``) returns at
most one class block.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute
from .._snippets import VERSE_DIGEST_HELPER

# Default digest ordering: Fortnite first because that's where devices live
# and "use a device" is the most common LLM workflow.
_DEFAULT_DIGEST_ORDER = ("Fortnite", "UnrealEngine", "Verse")


@mcp.tool()
def list_verse_digests() -> list[dict]:
    """List ``*.digest.verse`` files available in this UEFN project.

    Returns a list of ``{"module", "path", "size_bytes"}`` entries. Use
    ``module`` as the module argument to other ``list_verse_*`` /
    ``get_verse_device_api`` calls.

    The scan looks in both ``Plugins/<X>/Content/`` and
    ``Plugins/<X>/Content/Verse/``, so it works regardless of which UEFN
    layout your project uses. Path is relative to the project directory.
    """
    code = "import os\nimport re\n" + VERSE_DIGEST_HELPER + textwrap.dedent("""
        proj_dir = unreal.Paths.project_dir()
        out = []
        for mod, full, size in _find_verse_digests():
            try:
                rel = os.path.relpath(full, proj_dir).replace(os.sep, "/")
            except ValueError:
                rel = full.replace(os.sep, "/")
            out.append({"module": mod, "path": rel, "size_bytes": size})
        result = out
    """)
    return post_execute(code)


@mcp.tool()
def list_verse_devices(module: str = "Fortnite", filter_substring: str = "") -> list[dict]:
    """List top-level Verse classes in a digest.

    Defaults to ``module="Fortnite"`` because that's where the device classes
    live. Pass ``module="UnrealEngine"`` for engine types or ``module="Verse"``
    for core language types.

    ``filter_substring`` (case-insensitive) narrows the result to classes
    whose name contains the substring — useful for "find all *_device classes"
    or "find anything containing 'mutator'".

    Each entry is ``{"name", "module", "line", "header", "modifiers",
    "bases"}`` where ``header`` is the raw declaration line and ``bases``
    is the parsed parent-class tuple.
    """
    code = "import os\nimport re\n" + VERSE_DIGEST_HELPER + textwrap.dedent(f"""
        target_module = {module!r}
        needle = {filter_substring!r}.lower()
        out = []
        err = None
        found_digest = False
        for mod, full, _ in _find_verse_digests():
            if mod != target_module:
                continue
            found_digest = True
            try:
                with open(full, "r", encoding="utf-8") as fh:
                    lines = fh.readlines()
            except OSError as e:
                err = "cannot read digest: " + str(e)
                break
            for i, ln in enumerate(lines):
                m = _CLASS_HEADER_RE.match(ln.rstrip())
                if not m:
                    continue
                name = m.group("name")
                if needle and needle not in name.lower():
                    continue
                modifiers_text = m.group("modifiers") or ""
                bases_text = m.group("bases") or ""
                mods = [
                    s.strip() for s in modifiers_text.strip("<>").split(",") if s.strip()
                ]
                bases = [
                    s.strip() for s in bases_text.strip("()").split(",") if s.strip()
                ]
                out.append({{
                    "name": name,
                    "module": mod,
                    "line": i + 1,
                    "header": ln.rstrip(),
                    "modifiers": mods,
                    "bases": bases,
                }})
            break
        if err:
            result = {{"error": err}}
        elif not found_digest:
            result = {{"error": "no digest for module " + target_module}}
        else:
            result = out
    """)
    return post_execute(code)


@mcp.tool()
def get_verse_device_api(device_name: str, module: str = "Fortnite") -> dict:
    """Extract the full API of one Verse class from a digest.

    Returns ``{"name", "module", "header", "members": [...], "raw_body"}``
    where:
      * ``header`` — the class declaration line
      * ``members`` — parsed ``[{"kind", "name", "signature"}, ...]`` with
        ``kind`` being one of ``method`` / ``event`` / ``field`` / ``decorator``
      * ``raw_body`` — the entire class block as text, in case the parser
        missed something (Verse has corner cases)

    If the device isn't found, returns ``{"error": "...", "suggestions": [...]}``
    with the closest-name matches.
    """
    code = "import os\nimport re\n" + VERSE_DIGEST_HELPER + textwrap.dedent(f"""
        target_module = {module!r}
        target_name = {device_name!r}

        digest_path = None
        for mod, full, _ in _find_verse_digests():
            if mod == target_module:
                digest_path = full
                break
        if digest_path is None:
            result = {{"error": "no digest for module " + target_module}}
        else:
            try:
                with open(digest_path, "r", encoding="utf-8") as fh:
                    lines = fh.readlines()
            except OSError as e:
                result = {{"error": "cannot read digest: " + str(e)}}
                lines = []

            found_at = -1
            all_class_names = []
            for i, ln in enumerate(lines):
                m = _CLASS_HEADER_RE.match(ln.rstrip())
                if not m:
                    continue
                name = m.group("name")
                all_class_names.append(name)
                if name == target_name:
                    found_at = i
                    break

            if found_at < 0 and lines:
                # Fuzzy suggestions — same prefix or shared substring
                low = target_name.lower()
                suggestions = sorted(
                    [n for n in all_class_names if low in n.lower() or n.lower() in low]
                )[:10]
                result = {{
                    "error": "class '" + target_name + "' not found in " + target_module + ".digest.verse",
                    "suggestions": suggestions,
                }}
            elif lines:
                header, body, _end = _parse_verse_class_block(lines, found_at)
                members = []
                for bl in body:
                    info = _classify_verse_member(bl)
                    if info is None:
                        continue
                    if info["kind"] == "decorator":
                        continue  # don't surface bare decorators as members
                    members.append(info)
                result = {{
                    "name": target_name,
                    "module": target_module,
                    "line": found_at + 1,
                    "header": header,
                    "members": members,
                    "raw_body": "\\n".join(body),
                }}
    """)
    return post_execute(code)


@mcp.tool()
def search_verse_digest(
    pattern: str,
    module: str = "",
    case_sensitive: bool = False,
    max_results: int = 50,
) -> list[dict]:
    """Grep across digest files for a regex pattern.

    Useful for things like:
      * ``pattern="agent"`` — every line that mentions ``agent``
      * ``pattern="^trigger.*device"`` — class names matching a pattern
      * ``pattern=":event\\("`` — every event declaration

    ``module`` (empty string = all digests) restricts to one digest.
    Returns ``[{"module", "path", "line", "text"}, ...]`` capped at
    ``max_results`` (default 50; the bridge cuts huge result sets).
    """
    flags_expr = "0" if case_sensitive else "re.IGNORECASE"
    code = "import os\nimport re\n" + VERSE_DIGEST_HELPER + textwrap.dedent(f"""
        try:
            rx = re.compile({pattern!r}, {flags_expr})
        except re.error as e:
            result = {{"error": "bad regex: " + str(e)}}
        else:
            target_module = {module!r}
            cap = max(1, int({max_results}))
            out = []
            proj_dir = unreal.Paths.project_dir()
            for mod, full, _ in _find_verse_digests():
                if target_module and mod != target_module:
                    continue
                try:
                    with open(full, "r", encoding="utf-8") as fh:
                        for i, ln in enumerate(fh):
                            if rx.search(ln):
                                try:
                                    rel = os.path.relpath(full, proj_dir).replace(os.sep, "/")
                                except ValueError:
                                    rel = full.replace(os.sep, "/")
                                out.append({{
                                    "module": mod,
                                    "path": rel,
                                    "line": i + 1,
                                    "text": ln.rstrip(),
                                }})
                                if len(out) >= cap:
                                    break
                except OSError:
                    continue
                if len(out) >= cap:
                    break
            result = out
    """)
    return post_execute(code)
