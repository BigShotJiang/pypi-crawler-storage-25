"""
Asset listing tool.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute


@mcp.tool()
def list_assets(directory: str = "/Game", recursive: bool = True) -> list[str]:
    """List asset paths under a directory (default the whole ``/Game`` tree)."""
    code = textwrap.dedent(f"""
        result = list(unreal.EditorAssetLibrary.list_assets(
            {directory!r},
            recursive={recursive},
            include_folder=False,
        ))
    """)
    return post_execute(code)
