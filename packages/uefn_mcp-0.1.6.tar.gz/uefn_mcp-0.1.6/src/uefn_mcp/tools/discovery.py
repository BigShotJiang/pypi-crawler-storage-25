"""
Discovery tools — what's in the level / what classes exist.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute


@mcp.tool()
def get_class_distribution() -> dict:
    """Count actors by class — instant overview of what's in the level."""
    code = textwrap.dedent("""
        from collections import Counter
        c = Counter(a.get_class().get_name() for a in actor_sub.get_all_level_actors())
        result = dict(c.most_common())
    """)
    return post_execute(code)


@mcp.tool()
def get_all_tags() -> list[str]:
    """All unique ``Actor.Tags`` present in the level."""
    code = textwrap.dedent("""
        tags = set()
        for a in actor_sub.get_all_level_actors():
            for t in a.tags:
                tags.add(str(t))
        result = sorted(tags)
    """)
    return post_execute(code)


@mcp.tool()
def get_device_catalog(name_filter: str | None = None, limit: int = 200) -> dict:
    """List Fortnite **runtime UE class** names that derive from creative_device_base.

    Returns the names of Blueprint/UE classes (e.g. ``TriggerDevice_C``,
    ``BillboardDevice_C``) — i.e. what you'd pass to
    ``actor_sub.spawn_actor_from_class(unreal.load_class(None, path))``
    when **placing devices into a level via Python**.

    NOT the same surface as ``list_verse_devices`` (v1.6) — that returns
    Verse-language class names from ``Fortnite.digest.verse`` for use when
    **writing Verse code**. Different layers, different use cases:

        get_device_catalog   →  spawn UE-class actor into level
        list_verse_devices   →  reference device API in a .verse file

    Args:
        name_filter: case-insensitive substring filter on class name
        limit: cap on results
    """
    code = textwrap.dedent(f"""
        candidates = []
        for base_name in (
            "FortCreativeDevice",
            "CreativeDevice",
            "creative_device_base",
            "FortDeviceVerse",
        ):
            base = getattr(unreal, base_name, None)
            if base is not None:
                candidates.append(base)

        if not candidates:
            result = {{"error": "no creative device base class found", "checked": [
                "FortCreativeDevice", "CreativeDevice",
                "creative_device_base", "FortDeviceVerse",
            ]}}
        else:
            seen = set()
            out = []
            nf = {name_filter!r}
            for base in candidates:
                try:
                    derived = unreal.get_derived_classes(base, recursive=True, include_base=False)
                except Exception:
                    derived = []
                for cls in derived:
                    try:
                        nm = cls.get_name()
                    except Exception:
                        continue
                    if nm in seen:
                        continue
                    seen.add(nm)
                    if nf and nf.lower() not in nm.lower():
                        continue
                    out.append({{
                        "class": nm,
                        "path": cls.get_path_name() if hasattr(cls, "get_path_name") else "?",
                    }})
            out.sort(key=lambda x: x["class"])
            total = len(out)
            result = {{
                "devices": out[:{limit}],
                "total": total,
                "truncated": total > {limit},
                "bases": [b.get_name() for b in candidates],
            }}
    """)
    return post_execute(code)
