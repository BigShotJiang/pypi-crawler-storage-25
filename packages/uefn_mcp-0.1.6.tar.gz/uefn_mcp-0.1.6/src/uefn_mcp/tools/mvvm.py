"""
MVVM tools — viewmodel context registration + view binding mutators + listing.

⚠️ READ ``MVVM_API_NOTES.md`` BEFORE EDITING.

The Read-Only / Read-Write surface map is non-obvious:
    - ``MVVMBlueprintView.bindings`` and ``available_view_models``      Read-Write ✅
    - ``MVVMBlueprintViewBinding.binding_type / enabled / compile``      Read-Write ✅
    - ``MVVMBlueprintViewBinding.source_path / destination_path``        **Read-Only** ⚠️
    - ALL ``MVVMBlueprintPropertyPath`` properties                       **Read-Only** ⚠️
    - ``MVVMBlueprintFieldPath.binding_reference``                       Read-Write ✅

Documented Read-Only struct fields are still mutated in practice via
``set_editor_property`` (not via UFUNCTION). The path-setter helpers in
``_snippets.MVVM_HELPERS`` try multiple strategies so we degrade gracefully
across UEFN versions.

If a path setter fails, run
``execute_python("result = sorted(dir(unreal.MVVMEditorSubsystem))")``
(or the equivalent on whichever class is failing) to see what's actually
exposed in your install. The ``probe_mvvm_api`` wrapper that did this
under a single tool name was retired in the v1.6 audit fixup —
``execute_python`` covers it in one line.

v1.4 changes:
    - Path setters now also stamp the ``source`` enum
      (MVVMBlueprintFieldPathSource.WIDGET / .VIEW_MODEL) on the path object
      — keeps the editor's UI in sync.
    - Failure paths point users to ``MVVM_API_NOTES.md`` and ``execute_python``.

v1.5 changes (audit fixup):
    - The previously-claimed subsystem methods
      ``set_source_to_destination_conversion_function`` /
      ``set_destination_to_source_conversion_function`` **do not exist** in
      the UE Python 5.7 docs. Removed the phantom calls.
    - Conversion path is fully Read-Only in 5.7 Python:
      ``MVVMBlueprintViewBinding.conversion`` is R/O, both directions inside
      ``MVVMBlueprintViewConversionPath`` are R/O, and
      ``MVVMBlueprintViewConversionFunction.conversion_function`` is R/O.
      We try a best-effort in-place mutation but warn loudly that this
      almost certainly fails — recommend setting conversion in the editor UI.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute, wrap_transaction
from .._snippets import MVVM_HELPERS


@mcp.tool()
def list_view_bindings(wbp_path: str) -> list[dict]:
    """List existing MVVM view bindings on a widget blueprint."""
    code = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")
        view = _mvvm_view(wbp)
        result = [_summarize_binding(b, idx=i)
                  for i, b in enumerate(_mvvm_view_bindings(view))]
    """)
    return post_execute(code)


@mcp.tool()
def list_available_conversions(
    wbp_path: str,
    widget_name: str,
    widget_property: str,
    viewmodel_path: str,
    direction: str = "source_to_destination",
) -> list[dict]:
    """List MVVM conversion functions valid for a specific source→dest pair.

    Builds typed property paths for both sides, then asks
    ``MVVMEditorSubsystem.get_available_conversion_functions`` which functions
    can wrap source→dest (or dest→source).

    Args:
        wbp_path:        WBP asset path
        widget_name:     destination widget label
        widget_property: destination widget property
        viewmodel_path:  ``ContextName.FieldName`` on the source side
        direction:       ``source_to_destination`` (default) or ``destination_to_source``
    """
    if direction not in ("source_to_destination", "destination_to_source"):
        raise ValueError("direction must be source_to_destination or destination_to_source")

    code = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")
        sub = _mvvm_subsystem()
        view = _mvvm_view(wbp)

        ctx_name, _, vm_field = {viewmodel_path!r}.partition(".")
        vm_guid = None
        for vm in _mvvm_view_models(view):
            try:
                if str(vm.get_editor_property("view_model_name")) == ctx_name:
                    vm_guid = vm.get_editor_property("view_model_context_id")
                    break
            except Exception:
                continue

        src = unreal.MVVMBlueprintPropertyPath()
        dst = unreal.MVVMBlueprintPropertyPath()
        if vm_guid is not None:
            _set_path_viewmodel(src, vm_guid)
        _set_path_property_name(src, wbp, vm_field)
        _set_path_widget(dst, {widget_name!r})
        _set_path_property_name(dst, wbp, {widget_property!r})

        try:
            if {direction!r} == "source_to_destination":
                fns = sub.get_available_conversion_functions(wbp, src, dst)
            else:
                fns = sub.get_available_conversion_functions(wbp, dst, src)
        except Exception as e:
            raise RuntimeError("get_available_conversion_functions failed: " + str(e))

        out = []
        for f in fns or []:
            entry = {{}}
            try:
                entry["name"] = f.get_name()
            except Exception:
                entry["name"] = repr(f)
            for attr in ("get_full_name", "get_path_name"):
                try:
                    entry[attr.replace("get_", "")] = getattr(f, attr)()
                except Exception:
                    pass
            out.append(entry)
        result = out
    """)
    return post_execute(code)


@mcp.tool()
def add_viewmodel_context(
    wbp_path: str,
    viewmodel_class_path: str,
    context_name: str,
) -> dict:
    """Register a ViewModel context on a Widget Blueprint.

    After this, the named context (e.g. ``PlayerInfo``) is available as a
    binding source for ``add_view_binding`` calls on this WBP.

    Args:
        wbp_path: e.g. ``/Game/UI/WBP_PostRoundCard``
        viewmodel_class_path: asset path or short class name of the ViewModel
        context_name: the symbolic name to use in bindings (yours to pick)
    """
    body = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")

        vm_class = _resolve_class({viewmodel_class_path!r})
        if vm_class is None:
            raise ValueError("viewmodel class not found: {viewmodel_class_path}")

        sub = _mvvm_subsystem()
        guid = sub.add_view_model(wbp, vm_class)

        # Name the freshly-added context. Match by guid first, fall back to
        # the last entry in the array.
        view = _mvvm_view(wbp)
        ctx_named = False
        ctxs = _mvvm_view_models(view)
        if ctxs:
            target_ctx = None
            for ctx in ctxs:
                try:
                    cid = ctx.get_editor_property("view_model_context_id")
                    if str(cid) == str(guid):
                        target_ctx = ctx
                        break
                except Exception:
                    continue
            if target_ctx is None:
                target_ctx = ctxs[-1]
            for prop_name in ("view_model_name",):
                try:
                    target_ctx.set_editor_property(prop_name, unreal.Name({context_name!r}))
                    ctx_named = True
                    break
                except Exception:
                    try:
                        target_ctx.set_editor_property(prop_name, {context_name!r})
                        ctx_named = True
                        break
                    except Exception:
                        pass

        # Mark the view dirty so the editor picks up the rename. Best-effort.
        try:
            view.modify()
        except Exception:
            pass

        result = {{
            "wbp": {wbp_path!r},
            "viewmodel": vm_class.get_name(),
            "context_name": {context_name!r},
            "guid": str(guid),
            "named": ctx_named,
        }}
    """)
    return post_execute(wrap_transaction(
        f"uefn-mcp: add_viewmodel_context {context_name}", body
    ))


@mcp.tool()
def add_view_binding(
    wbp_path: str,
    widget_name: str,
    widget_property: str,
    viewmodel_path: str,
    conversion_function: str | None = None,
    binding_mode: str = "OneWayToDestination",
) -> dict:
    """Add an MVVM view binding to a Widget Blueprint. Wrapped in undo transaction.

    Args:
        wbp_path:            e.g. ``/Game/UI/WBP_PostRoundCard``
        widget_name:         the named widget in the WBP, e.g. ``PlayerAvatar``
        widget_property:     property on the widget, e.g. ``Brush`` or ``Text``
        viewmodel_path:      ``ContextName.FieldName``, e.g. ``PlayerInfo.PlayerAvatarIcon``
        conversion_function: optional name/path of a conversion function
                             (use ``list_available_conversions`` to discover).
                             ⚠️ Conversion-function setting is Read-Only in
                             UE Python 5.7 — we try a best-effort in-place
                             mutation, but the editor UI is the reliable
                             route. The result includes ``conversion.applied``
                             so you know if it actually stuck.
        binding_mode:        ``OneWayToDestination`` (default), ``OneWayToSource``,
                             ``TwoWay``, ``OneTimeToDestination``, ``OneTimeToSource``

    Direction model: by convention ``source_path`` is the ViewModel side
    ("source of truth") and ``destination_path`` is the Widget side. Setting
    ``binding_mode="OneWayToSource"`` writes Widget → ViewModel.

    If the path setters fail, dump the runtime API surface with
    ``execute_python("result = sorted(dir(unreal.MVVMBlueprintPropertyPath))")``
    and cross-reference against ``MVVM_API_NOTES.md``.
    """
    body = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")

        ctx_name, _, vm_field = {viewmodel_path!r}.partition(".")
        if not vm_field:
            raise ValueError(
                "viewmodel_path must be 'ContextName.FieldName', got " + {viewmodel_path!r}
            )

        sub = _mvvm_subsystem()
        view = _mvvm_view(wbp)

        # Resolve the named context to its GUID.
        vm_guid = None
        for vm in _mvvm_view_models(view):
            try:
                nm = vm.get_editor_property("view_model_name")
                if str(nm) == ctx_name:
                    vm_guid = vm.get_editor_property("view_model_context_id")
                    break
            except Exception:
                continue
        if vm_guid is None:
            raise ValueError(
                "no ViewModel context named '" + ctx_name + "' on " + {wbp_path!r} +
                ". Available: " + ", ".join(
                    str(vm.get_editor_property('view_model_name'))
                    for vm in _mvvm_view_models(view)
                ) + ". Add one first with add_viewmodel_context."
            )

        # 1. Create the empty binding via the subsystem (it lands in the view's
        #    `bindings` array automatically).
        binding = sub.add_binding(wbp)
        if binding is None:
            raise RuntimeError("MVVMEditorSubsystem.add_binding returned None")

        # 2. Configure the source path (viewmodel side) and destination path
        #    (widget side). Path objects are obtained from the binding's
        #    editor properties — they're live references, mutating them
        #    mutates the binding.
        src_path = binding.get_editor_property("source_path")
        dst_path = binding.get_editor_property("destination_path")
        if src_path is None or dst_path is None:
            raise RuntimeError("binding source/destination path missing")

        debug = {{}}
        ok_src_anchor, debug["src_anchor"] = _set_path_viewmodel(src_path, vm_guid)
        ok_src_field,  debug["src_field"]  = _set_path_property_name(src_path, wbp, vm_field)
        ok_dst_anchor, debug["dst_anchor"] = _set_path_widget(dst_path, {widget_name!r})
        ok_dst_field,  debug["dst_field"]  = _set_path_property_name(dst_path, wbp, {widget_property!r})

        # 3. Binding mode (Read-Write — set_editor_property is fine here)
        mode_value = _binding_mode({binding_mode!r})
        mode_set = False
        if mode_value is not None:
            try:
                binding.set_editor_property("binding_type", mode_value)
                mode_set = True
            except Exception:
                pass

        # 4. Enabled + compile flags (Read-Write)
        for k, v in (("enabled", True), ("compile", True)):
            try:
                binding.set_editor_property(k, v)
            except Exception:
                pass

        # 5. Conversion function (optional). Per UE Python 5.7 docs:
        #    - MVVMEditorSubsystem has NO `set_*_conversion_function` methods
        #      (we previously claimed it did — that was wrong).
        #    - `MVVMBlueprintViewBinding.conversion` is Read-Only.
        #    - Both directions inside `MVVMBlueprintViewConversionPath` are
        #      Read-Only.
        #    - `MVVMBlueprintViewConversionFunction.conversion_function`
        #      is Read-Only.
        #    So this is a best-effort in-place mutation only — likely a
        #    no-op. The editor UI is the documented path. We surface
        #    `applied` so callers know whether it took.
        conversion_set = False
        conversion_attempted = []
        if {conversion_function!r}:
            cf = unreal.load_object(None, {conversion_function!r}) \
                  if isinstance({conversion_function!r}, str) and "/" in {conversion_function!r} \
                  else {conversion_function!r}
            try:
                conv_path = binding.get_editor_property("conversion")
            except Exception as e:
                conv_path = None
                conversion_attempted.append("get_editor_property('conversion'):fail(" + str(e)[:80] + ")")

            if conv_path is not None:
                # Try setting source→destination side first (the common case
                # for OneWayToDestination bindings). UFUNCTION setters don't
                # exist; we attempt set_editor_property on the R/O struct
                # field anyway because some R/O fields turn out mutable in
                # practice.
                for prop in ("source_to_destination_conversion",
                             "destination_to_source_conversion"):
                    try:
                        conv_path.set_editor_property(prop, cf)
                        conversion_set = True
                        conversion_attempted.append(prop + ":ok")
                        break
                    except Exception as e:
                        conversion_attempted.append(prop + ":fail(" + str(e)[:80] + ")")

        all_ok = all([ok_src_anchor, ok_src_field, ok_dst_anchor, ok_dst_field])
        result = {{
            "wbp": {wbp_path!r},
            "widget": {widget_name!r},
            "widget_prop": {widget_property!r},
            "viewmodel_path": {viewmodel_path!r},
            "mode": {binding_mode!r},
            "mode_set": mode_set,
            "applied": {{
                "src_anchor": ok_src_anchor,
                "src_field":  ok_src_field,
                "dst_anchor": ok_dst_anchor,
                "dst_field":  ok_dst_field,
            }},
            "conversion": {{
                "requested": {conversion_function!r},
                "applied": conversion_set,
                "attempts": conversion_attempted,
                "note": (
                    None if not {conversion_function!r}
                    else (None if conversion_set
                          else "Conversion-function setting is Read-Only in "
                               "UE Python 5.7. Set it manually in the WBP "
                               "designer's view binding panel, or wire one "
                               "up via execute_python if your install exposes "
                               "an undocumented setter (use "
                               "execute_python('result = sorted(dir("
                               "unreal.MVVMEditorSubsystem))') to check).")
                ),
            }},
            "debug": debug,
            "binding_id": str(binding.get_editor_property("binding_id")),
            "warning": (None if all_ok
                        else "one or more path setters failed — see debug. "
                             "Dump the runtime surface via execute_python('result = "
                             "sorted(dir(unreal.MVVMBlueprintPropertyPath))') and "
                             "consult MVVM_API_NOTES.md for the documented surface."),
        }}
    """)
    return post_execute(wrap_transaction(
        f"uefn-mcp: add_view_binding {widget_name}.{widget_property}", body
    ))


@mcp.tool()
def remove_view_binding(wbp_path: str, binding_index: int) -> dict:
    """Remove a view binding by its index (as shown by ``list_view_bindings``)."""
    body = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")

        sub = _mvvm_subsystem()
        view = _mvvm_view(wbp)
        bindings = _mvvm_view_bindings(view)
        idx = int({binding_index})
        if idx < 0 or idx >= len(bindings):
            raise ValueError(
                "binding_index out of range (0.." + str(len(bindings) - 1) + ")"
            )

        target = bindings[idx]
        sub.remove_binding(wbp, target)
        result = {{"wbp": {wbp_path!r}, "removed_index": idx}}
    """)
    return post_execute(wrap_transaction(
        f"uefn-mcp: remove_view_binding [{binding_index}]", body
    ))


@mcp.tool()
def remove_viewmodel_context(wbp_path: str, context_name: str) -> dict:
    """Remove a ViewModel context (by its symbolic name) from a Widget Blueprint.

    Per UE Python 5.7 docs, ``MVVMEditorSubsystem.remove_view_model`` takes a
    ``Name`` (not a ``Guid``).
    """
    body = MVVM_HELPERS + textwrap.dedent(f"""
        wbp = unreal.load_asset({wbp_path!r})
        if wbp is None:
            raise ValueError("widget blueprint not found: {wbp_path}")
        sub = _mvvm_subsystem()
        try:
            sub.remove_view_model(wbp, unreal.Name({context_name!r}))
        except Exception:
            sub.remove_view_model(wbp, {context_name!r})
        result = {{"wbp": {wbp_path!r}, "removed_context": {context_name!r}}}
    """)
    return post_execute(wrap_transaction(
        f"uefn-mcp: remove_viewmodel_context {context_name}", body
    ))
