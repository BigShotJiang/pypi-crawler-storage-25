"""
Screenshot tools — capture viewport / actor and return as MCP Image content.

Strategy: UEFN's ``take_high_res_screenshot`` queues a render-thread job that
writes a PNG to ``<Project>/Saved/Screenshots/Windows/``. Since the MCP
server runs on the same Windows host as UEFN, we trigger the screenshot
via the listener, then poll the file from the MCP side and return it
as a proper MCP Image content block (which Claude / Cursor renders inline).
"""
from __future__ import annotations

import os
import textwrap
import time

from mcp.server.fastmcp.utilities.types import Image

from .._bridge import mcp, post_execute
from .._snippets import FRAME_HELPERS

_SCREENSHOT_POLL_TIMEOUT = 20.0      # seconds to wait for PNG to appear
_SCREENSHOT_STABILITY_TIMEOUT = 3.0  # additional wait for write to complete


def _resolve_screenshot_dir() -> str:
    """Ask UEFN for the absolute path to its Saved/Screenshots/Windows dir."""
    code = textwrap.dedent("""
        import os
        saved = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_saved_dir())
        result = os.path.join(saved, "Screenshots", "Windows").replace("/", os.sep)
    """)
    return post_execute(code)


def _wait_for_file(target: str, timeout: float) -> bool:
    """Poll until file appears (and stops growing). Returns True on success."""
    deadline = time.time() + timeout
    while not os.path.exists(target):
        if time.time() > deadline:
            return False
        time.sleep(0.15)

    last_size = -1
    stable_deadline = time.time() + _SCREENSHOT_STABILITY_TIMEOUT
    while time.time() < stable_deadline:
        try:
            size = os.path.getsize(target)
        except OSError:
            size = 0
        if size > 0 and size == last_size:
            return True
        last_size = size
        time.sleep(0.1)
    return os.path.exists(target) and os.path.getsize(target) > 0


def _take_screenshot(width: int, height: int) -> str:
    """Trigger a screenshot in UEFN, return absolute path to the PNG file."""
    shot_dir = _resolve_screenshot_dir()
    fname = f"uefn_mcp_{int(time.time() * 1000)}.png"
    target = os.path.join(shot_dir, fname)

    os.makedirs(shot_dir, exist_ok=True)

    code = textwrap.dedent(f"""
        import os
        target = {target!r}
        if os.path.exists(target):
            try:
                os.remove(target)
            except Exception:
                pass
        ok = unreal.AutomationLibrary.take_high_res_screenshot({width}, {height}, {fname!r})
        result = {{"queued": bool(ok), "filename": {fname!r}}}
    """)
    post_execute(code)

    if not _wait_for_file(target, _SCREENSHOT_POLL_TIMEOUT):
        raise RuntimeError(
            f"Screenshot timeout — UEFN didn't write {target} within "
            f"{_SCREENSHOT_POLL_TIMEOUT}s. Make sure the editor viewport is visible."
        )
    return target


@mcp.tool()
def screenshot_viewport(width: int = 1280, height: int = 720) -> Image:
    """Capture the active editor viewport as a PNG.

    Returns an MCP Image content block — Claude renders it inline in chat.
    Defaults to ``1280x720`` to keep payloads small; bump to ``1920x1080`` for
    detail work.

    For UMG widget visuals, first open the WBP in the designer (so it's the
    active editor tab), then call this. The widget designer area will be in
    the screenshot.
    """
    target = _take_screenshot(width, height)
    return Image(path=target)


@mcp.tool()
def screenshot_actor(
    name: str,
    distance_multiplier: float = 3.0,
    width: int = 1280,
    height: int = 720,
) -> Image:
    """Frame the viewport on an actor (F-key style) then screenshot it.

    Useful for "show me what X looks like" without having to manually navigate.
    """
    focus_code = FRAME_HELPERS + textwrap.dedent(f"""
        target = None
        for a in actor_sub.get_all_level_actors():
            if a.get_actor_label() == {name!r}:
                target = a
                break
        if target is None:
            raise ValueError("actor not found: {name}")

        try:
            origin, extent = target.get_actor_bounds(only_colliding_components=False)
        except Exception:
            origin = target.get_actor_location()
            extent = unreal.Vector(100, 100, 100)

        radius = max(extent.x, extent.y, extent.z, 50.0)
        d = radius * {distance_multiplier} + 200.0
        cam_loc = unreal.Vector(origin.x + d, origin.y + d, origin.z + d * 0.5)
        cam_rot = unreal.MathLibrary.find_look_at_rotation(cam_loc, origin)
        _set_viewport_camera(cam_loc, cam_rot)
        result = {{"framed": target.get_actor_label()}}
    """)
    post_execute(focus_code)
    # Tiny pause so the viewport repaints before the screenshot grabs it
    time.sleep(0.25)
    target = _take_screenshot(width, height)
    return Image(path=target)
