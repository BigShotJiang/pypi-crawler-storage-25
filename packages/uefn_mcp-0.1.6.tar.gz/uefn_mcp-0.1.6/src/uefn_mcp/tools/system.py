"""
System / diagnostic tools: ping, execute_python, get_output_log.

The previous ``probe_mvvm_api`` diagnostic was removed in the v1.6 audit fixup —
it was a packaged ``dir()`` walk over six MVVM classes plus three enums, which
``execute_python("result = sorted(dir(unreal.MVVMEditorSubsystem))")`` covers
in one line. ``MVVM_API_NOTES.md`` is the source of truth for what's exposed;
``execute_python`` is the empirical fallback. Two paths, not three.
"""
from __future__ import annotations

import textwrap
from typing import Any

from .._bridge import get, mcp, post_execute
from .._snippets import VERSE_ROOTS_HELPER


@mcp.tool()
def ping() -> dict:
    """Check that the UEFN listener is alive. Returns service health info."""
    return get("/health")


@mcp.tool()
def execute_python(code: str) -> Any:
    """Execute arbitrary Python in UEFN on the game thread.

    The snippet has these names pre-injected:
        unreal, actor_sub, asset_sub, level_sub, editor_sub, mvvm_sub, result

    Assign the value you want returned to ``result``. Example:
        result = unreal.SystemLibrary.get_engine_version()
    """
    return post_execute(code)


@mcp.tool()
def get_output_log(limit: int = 100) -> list[dict]:
    """Read the most recent UEFN log messages (info/warning/error)."""
    payload = get("/log")
    log = payload.get("log", [])
    return log[-limit:]


@mcp.tool()
def diagnose_paths() -> dict:
    """Dump every path UEFN reports + what the Verse root finder discovered.

    Use this when ``list_verse_modules`` / ``list_verse_digests`` return empty
    to confirm whether the listener is pointing at the right project content
    dir. UEFN's project layout is non-standard (user projects are loaded as
    plugins under FortniteGame), so ``unreal.Paths.project_content_dir()``
    sometimes returns the engine content dir, not the user's.
    """
    code = "import os\n" + VERSE_ROOTS_HELPER + textwrap.dedent("""
        import sys
        diag = {}
        # Raw UE paths
        for name in (
            "engine_dir", "engine_content_dir", "project_dir",
            "project_content_dir", "project_plugins_dir",
            "project_saved_dir", "project_config_dir",
        ):
            try:
                diag[name] = getattr(unreal.Paths, name)()
            except Exception as e:
                diag[name] = f"<error: {e}>"

        # Process / interpreter context
        try:
            diag["python_cwd"] = os.getcwd()
        except Exception as e:
            diag["python_cwd"] = f"<error: {e}>"
        try:
            diag["python_executable"] = sys.executable
        except Exception:
            pass

        # Plugin manager view (what UEFN considers loaded)
        try:
            pm = unreal.PluginManager.get() if hasattr(unreal, "PluginManager") else None
            if pm and hasattr(pm, "get_enabled_plugins"):
                plugs = []
                for pi in pm.get_enabled_plugins():
                    try:
                        plugs.append({
                            "name": pi.get_name() if hasattr(pi, "get_name") else "?",
                            "base_dir": pi.get_base_dir() if hasattr(pi, "get_base_dir") else None,
                        })
                    except Exception:
                        continue
                diag["enabled_plugins"] = plugs
            else:
                diag["enabled_plugins"] = "<PluginManager not exposed>"
        except Exception as e:
            diag["enabled_plugins"] = f"<error: {e}>"

        # Verse root finder result
        try:
            roots, primary = _verse_search_roots()
            diag["verse_roots"] = roots
            diag["verse_primary"] = primary
        except Exception as e:
            diag["verse_roots"] = f"<error: {e}>"

        # Quick scan: count .verse files at each candidate root + 1 level deep
        try:
            cands = _verse_candidate_content_dirs()
            diag["verse_candidate_dirs"] = cands
            counts = {}
            for c in cands:
                n = 0
                try:
                    for dirpath, _, files in os.walk(c):
                        for f in files:
                            if f.endswith(".verse"):
                                n += 1
                except Exception:
                    pass
                counts[c] = n
            diag["verse_file_counts"] = counts
        except Exception as e:
            diag["verse_candidate_dirs"] = f"<error: {e}>"

        result = diag
    """)
    return post_execute(code)
