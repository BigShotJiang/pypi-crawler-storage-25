"""
Level tools — info, save, undo / redo.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute, wrap_transaction


@mcp.tool()
def get_level_info() -> dict:
    """Return basic info about the currently loaded level."""
    code = textwrap.dedent("""
        world = unreal.EditorLevelLibrary.get_editor_world()
        actors = actor_sub.get_all_level_actors()
        result = {
            "world_name": world.get_name() if world else None,
            "actor_count": len(actors),
            "selected_count": len(actor_sub.get_selected_level_actors()),
        }
    """)
    return post_execute(code)


@mcp.tool()
def save_current_level() -> dict:
    """Save the currently open level."""
    body = textwrap.dedent("""
        ok = level_sub.save_current_level()
        result = {"saved": bool(ok)}
    """)
    return post_execute(wrap_transaction("uefn-mcp: save_current_level", body))


@mcp.tool()
def undo(steps: int = 1) -> dict:
    """Undo the most recent N transactions (same as Ctrl+Z N times).

    Each uefn-mcp mutation is one transaction, so ``undo(1)`` reverts one tool call.
    """
    code = textwrap.dedent(f"""
        n = max(1, int({steps}))
        world = unreal.EditorLevelLibrary.get_editor_world()
        for _ in range(n):
            unreal.SystemLibrary.execute_console_command(world, "TRANSACTION UNDO")
        result = {{"undone": n}}
    """)
    return post_execute(code)


@mcp.tool()
def redo(steps: int = 1) -> dict:
    """Redo the most recent N undone transactions."""
    code = textwrap.dedent(f"""
        n = max(1, int({steps}))
        world = unreal.EditorLevelLibrary.get_editor_world()
        for _ in range(n):
            unreal.SystemLibrary.execute_console_command(world, "TRANSACTION REDO")
        result = {{"redone": n}}
    """)
    return post_execute(code)
