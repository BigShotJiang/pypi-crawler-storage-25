"""
uefn_mcp.tools — every submodule registers its MCP tools by importing
the shared `mcp` instance from `_bridge`.

Importing this package (or any submodule) is a side-effect: the @mcp.tool()
decorators run at import time, which is how FastMCP discovers tools.

Order matters slightly: keep `system` first so `ping` / `execute_python` /
`get_output_log` are registered early. Everything else is alphabetic.
"""
from __future__ import annotations

# System / diagnostics
from . import system  # noqa: F401

# Domain modules — order is cosmetic, FastMCP doesn't care
from . import actors  # noqa: F401
from . import assets  # noqa: F401
from . import discovery  # noqa: F401
from . import events  # noqa: F401
from . import level  # noqa: F401
from . import mvvm  # noqa: F401
from . import navigation  # noqa: F401
from . import screenshots  # noqa: F401
from . import verse  # noqa: F401
from . import verse_digest  # noqa: F401
from . import widgets  # noqa: F401
