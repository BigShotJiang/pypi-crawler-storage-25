"""
Verse file ops with snapshot / restore safety net.

UEFN does NOT include Verse writes in the editor undo stack — Ctrl+Z won't
roll them back. We compensate by snapshotting any existing file content
into ``Content/.uefn-mcp-snapshots/`` before overwriting, so callers can
``restore_verse_file`` to roll back.
"""
from __future__ import annotations

import json
import textwrap

from .._bridge import mcp, post_execute
from .._snippets import USER_CONTENT_HELPER, VERSE_ROOTS_HELPER

_SNAPSHOT_DIR = ".uefn-mcp-snapshots"


@mcp.tool()
def list_verse_modules() -> list[str]:
    """List Verse files (``.verse``) under the project's known Verse roots.

    Scans ``Content/VerseDevices``, ``Content/Verse``, and any
    ``Plugins/*/Content/Verse`` directories. Paths are returned relative to
    ``Content/``.
    """
    code = "import os\n" + VERSE_ROOTS_HELPER + textwrap.dedent("""
        roots, proj = _verse_search_roots()
        out = []
        for root in roots:
            for dirpath, _, filenames in os.walk(root):
                for f in filenames:
                    if f.endswith(".verse"):
                        full = os.path.join(dirpath, f)
                        try:
                            rel = os.path.relpath(full, proj).replace(os.sep, "/")
                        except ValueError:
                            rel = full.replace(os.sep, "/")
                        out.append(rel)
        result = sorted(set(out))
    """)
    return post_execute(code)


@mcp.tool()
def read_verse_file(relative_path: str) -> str:
    """Read a Verse file. ``relative_path`` is relative to ``Content/``."""
    code = "import os\n" + USER_CONTENT_HELPER + textwrap.dedent(f"""
        proj = _resolve_content_dir()
        full = os.path.join(proj, {relative_path!r})
        with open(full, "r", encoding="utf-8") as fh:
            result = fh.read()
    """)
    return post_execute(code)


@mcp.tool()
def write_verse_file(relative_path: str, content: str) -> dict:
    """Write a Verse file (creates dirs as needed). Snapshots existing content first.

    NOTE: hit Ctrl+Shift+B in UEFN to compile. NOT undoable via Ctrl+Z — use
    ``restore_verse_file`` to roll back. Snapshots stored in
    ``Content/.uefn-mcp-snapshots/``.
    """
    body_json = json.dumps(content)
    code = "import os\n" + USER_CONTENT_HELPER + textwrap.dedent(f"""
        import json, time, shutil
        proj = _resolve_content_dir()
        full = os.path.join(proj, {relative_path!r})
        snapshot_root = os.path.join(proj, {_SNAPSHOT_DIR!r})

        snapshot_path = None
        if os.path.exists(full):
            ts = time.strftime("%Y%m%d-%H%M%S")
            rel_dir = os.path.dirname({relative_path!r})
            snap_dir = os.path.join(snapshot_root, rel_dir)
            os.makedirs(snap_dir, exist_ok=True)
            base = os.path.basename({relative_path!r})
            snapshot_path = os.path.join(snap_dir, base + "." + ts + ".bak")
            shutil.copy2(full, snapshot_path)

        os.makedirs(os.path.dirname(full), exist_ok=True)
        body = json.loads({body_json!r})
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(body)

        # Reactive: emit a file-written event so long-pollers can react.
        # push_event is pre-injected in the listener context; missing only
        # when running against an old listener.
        try:
            push_event("verse.file_written", {{
                "path": {relative_path!r},
                "bytes": len(body),
            }})
        except NameError:
            pass

        result = {{
            "written": {relative_path!r},
            "bytes": len(body),
            "snapshot": (os.path.relpath(snapshot_path, proj).replace(os.sep, "/")
                         if snapshot_path else None),
        }}
    """)
    return post_execute(code)


@mcp.tool()
def list_verse_snapshots(relative_path: str) -> list[dict]:
    """List available ``.bak`` snapshots for a Verse file (most recent first)."""
    code = "import os\n" + USER_CONTENT_HELPER + textwrap.dedent(f"""
        proj = _resolve_content_dir()
        rel_dir = os.path.dirname({relative_path!r})
        base = os.path.basename({relative_path!r})
        snap_dir = os.path.join(proj, {_SNAPSHOT_DIR!r}, rel_dir)
        out = []
        if os.path.isdir(snap_dir):
            for f in os.listdir(snap_dir):
                if f.startswith(base + ".") and f.endswith(".bak"):
                    full = os.path.join(snap_dir, f)
                    out.append({{
                        "snapshot": os.path.relpath(full, proj).replace(os.sep, "/"),
                        "size": os.path.getsize(full),
                        "mtime": os.path.getmtime(full),
                    }})
        out.sort(key=lambda x: x["mtime"], reverse=True)
        result = out
    """)
    return post_execute(code)


@mcp.tool()
def restore_verse_file(relative_path: str, snapshot_index: int = 0) -> dict:
    """Restore a Verse file from snapshot. ``snapshot_index=0`` means most recent."""
    code = "import os\n" + USER_CONTENT_HELPER + textwrap.dedent(f"""
        import shutil
        proj = _resolve_content_dir()
        rel_dir = os.path.dirname({relative_path!r})
        base = os.path.basename({relative_path!r})
        snap_dir = os.path.join(proj, {_SNAPSHOT_DIR!r}, rel_dir)
        if not os.path.isdir(snap_dir):
            raise ValueError("no snapshots for " + {relative_path!r})

        snaps = []
        for f in os.listdir(snap_dir):
            if f.startswith(base + ".") and f.endswith(".bak"):
                full = os.path.join(snap_dir, f)
                snaps.append((os.path.getmtime(full), full))
        snaps.sort(reverse=True)

        if not snaps:
            raise ValueError("no snapshots for " + {relative_path!r})
        idx = {snapshot_index}
        if idx < 0 or idx >= len(snaps):
            raise ValueError("snapshot_index " + str(idx) + " out of range (0.." + str(len(snaps)-1) + ")")

        chosen = snaps[idx][1]
        target = os.path.join(proj, {relative_path!r})
        shutil.copy2(chosen, target)
        result = {{
            "restored": {relative_path!r},
            "from_snapshot": os.path.relpath(chosen, proj).replace(os.sep, "/"),
        }}
    """)
    return post_execute(code)
