"""
Navigation tools: viewport selection + camera framing.
"""
from __future__ import annotations

import textwrap

from .._bridge import mcp, post_execute
from .._snippets import FRAME_HELPERS


@mcp.tool()
def select_actors(names: list[str]) -> dict:
    """Set the viewport selection to actors matching these labels."""
    code = textwrap.dedent(f"""
        wanted = set({names!r})
        targets = [a for a in actor_sub.get_all_level_actors() if a.get_actor_label() in wanted]
        actor_sub.set_selected_level_actors(targets)
        found_names = {{a.get_actor_label() for a in targets}}
        result = {{
            "requested": list(wanted),
            "selected": [a.get_actor_label() for a in targets],
            "missing": list(wanted - found_names),
        }}
    """)
    return post_execute(code)


@mcp.tool()
def focus_viewport_on(name: str, distance_multiplier: float = 3.0) -> dict:
    """Frame the viewport on an actor (F-key equivalent)."""
    code = FRAME_HELPERS + textwrap.dedent(f"""
        target = None
        for a in actor_sub.get_all_level_actors():
            if a.get_actor_label() == {name!r}:
                target = a
                break
        if target is None:
            raise ValueError("actor not found: {name}")

        try:
            origin, extent = target.get_actor_bounds(only_colliding_components=False)
        except Exception:
            origin = target.get_actor_location()
            extent = unreal.Vector(100, 100, 100)

        radius = max(extent.x, extent.y, extent.z, 50.0)
        d = radius * {distance_multiplier} + 200.0
        cam_loc = unreal.Vector(origin.x + d, origin.y + d, origin.z + d * 0.5)
        cam_rot = unreal.MathLibrary.find_look_at_rotation(cam_loc, origin)
        used = _set_viewport_camera(cam_loc, cam_rot)
        result = {{
            "framed": target.get_actor_label(),
            "camera_location": [cam_loc.x, cam_loc.y, cam_loc.z],
            "via": used,
        }}
    """)
    return post_execute(code)
