"""
Actor tools — query, property access, and mutation.

All mutation tools are wrapped in `wrap_transaction` so each call is one
Ctrl+Z step in the editor.
"""
from __future__ import annotations

import json
import textwrap
from typing import Any

from .._bridge import mcp, post_execute, wrap_transaction
from .._snippets import ACTOR_HELPERS


# ─────────────────────────────────────────────────────────────────────────────
# Query
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool()
def get_all_actors(limit: int = 200) -> dict:
    """List actors in the level (summary view).

    Returns ``{"actors": [...], "total": int, "truncated": bool}``. Default cap is 200.
    """
    code = ACTOR_HELPERS + textwrap.dedent(f"""
        all_actors = actor_sub.get_all_level_actors()
        slice_ = all_actors[:{limit}]
        result = {{
            "actors": [_actor_summary(a) for a in slice_],
            "total": len(all_actors),
            "truncated": len(all_actors) > {limit},
        }}
    """)
    return post_execute(code)


@mcp.tool()
def get_selected_actors() -> list[dict]:
    """List the actors currently selected in the editor viewport (summary view)."""
    code = ACTOR_HELPERS + textwrap.dedent("""
        result = [_actor_summary(a) for a in actor_sub.get_selected_level_actors()]
    """)
    return post_execute(code)


@mcp.tool()
def get_actor_details(
    name: str,
    verbosity: str = "summary",
    paths: list[str] | None = None,
) -> dict:
    """Inspect one actor.

    Args:
        name: Actor label (Outliner display name).
        verbosity: ``summary`` (~50 tokens), ``detail`` (~500), ``full`` (~3-8k).
        paths: Optional list of property paths to surgically read instead of
               dumping everything. Each path is ``Property`` for actor-level
               props or ``ComponentClass.Property`` for component props.
    """
    if verbosity not in ("summary", "detail", "full"):
        raise ValueError(f"verbosity must be summary|detail|full, got {verbosity!r}")

    code = ACTOR_HELPERS + textwrap.dedent(f"""
        a = _find_actor({name!r})
        if a is None:
            raise ValueError("actor not found: {name}")

        paths = {paths!r}
        if paths:
            out = {{}}
            for p in paths:
                if "." in p:
                    comp_class, prop = p.split(".", 1)
                    target = None
                    for c in a.get_components_by_class(unreal.SceneComponent):
                        if c.get_class().get_name() == comp_class:
                            target = c
                            break
                    if target is None:
                        out[p] = "<no component of class " + comp_class + ">"
                        continue
                    try:
                        out[p] = _safe_prop_value(target.get_editor_property(prop))
                    except Exception as e:
                        out[p] = "<error: " + str(e) + ">"
                else:
                    try:
                        out[p] = _safe_prop_value(a.get_editor_property(p))
                    except Exception as e:
                        out[p] = "<error: " + str(e) + ">"
            result = {{"name": a.get_actor_label(), "properties": out}}
        elif {verbosity!r} == "summary":
            result = _actor_summary(a)
        elif {verbosity!r} == "detail":
            result = _actor_detail(a)
        else:
            result = _actor_full(a)
    """)
    return post_execute(code)


@mcp.tool()
def find_actors(
    class_filter: str | None = None,
    label_filter: str | None = None,
    tag: str | None = None,
    component_class: str | None = None,
    bounds: list[float] | None = None,
    limit: int = 50,
    verbosity: str = "summary",
) -> dict:
    """Search actors with composable filters (all AND'd together).

    Args:
        class_filter:    Substring match on actor class name (case-insensitive).
        label_filter:    Substring match on actor label (case-insensitive).
        tag:             Exact match against ``Actor.Tags``.
        component_class: Actor must have a component of this class.
        bounds:          ``[xmin, ymin, zmin, xmax, ymax, zmax]`` AABB filter.
        limit:           Max results (hard cap to keep responses small).
        verbosity:       ``summary`` or ``detail``.
    """
    if verbosity not in ("summary", "detail"):
        raise ValueError(f"verbosity must be summary|detail, got {verbosity!r}")

    code = ACTOR_HELPERS + textwrap.dedent(f"""
        cf = {class_filter!r}
        lf = {label_filter!r}
        tg = {tag!r}
        cc = {component_class!r}
        bx = {bounds!r}
        verb = {verbosity!r}

        matches = []
        for a in actor_sub.get_all_level_actors():
            if cf and cf.lower() not in a.get_class().get_name().lower():
                continue
            if lf and lf.lower() not in a.get_actor_label().lower():
                continue
            if tg and tg not in [str(t) for t in a.tags]:
                continue
            if cc:
                comp_classes = {{c.get_class().get_name() for c in a.get_components_by_class(unreal.SceneComponent)}}
                if cc not in comp_classes:
                    continue
            if bx:
                loc = a.get_actor_location()
                if not (bx[0] <= loc.x <= bx[3] and bx[1] <= loc.y <= bx[4] and bx[2] <= loc.z <= bx[5]):
                    continue
            matches.append(a)

        total = len(matches)
        slice_ = matches[:{limit}]
        rendered = [(_actor_detail(a) if verb == "detail" else _actor_summary(a)) for a in slice_]
        result = {{
            "matches": rendered,
            "total_matches": total,
            "truncated": total > {limit},
        }}
    """)
    return post_execute(code)


@mcp.tool()
def get_actor_components(name: str) -> list[dict]:
    """List all SceneComponents on an actor with class names."""
    code = ACTOR_HELPERS + textwrap.dedent(f"""
        a = _find_actor({name!r})
        if a is None:
            raise ValueError("actor not found: {name}")
        result = [
            {{
                "name": c.get_name(),
                "class": c.get_class().get_name(),
                "is_root": c == a.get_root_component(),
            }}
            for c in a.get_components_by_class(unreal.SceneComponent)
        ]
    """)
    return post_execute(code)


# ─────────────────────────────────────────────────────────────────────────────
# Property access
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool()
def get_actor_property(name: str, path: str) -> Any:
    """Read one editor property on an actor (or its component).

    Path is ``Property`` for actor-level, or ``ComponentClass.Property`` for components.
    Example paths: ``bHidden``, ``StaticMeshComponent.StaticMesh``.
    """
    code = ACTOR_HELPERS + textwrap.dedent(f"""
        a = _find_actor({name!r})
        if a is None:
            raise ValueError("actor not found: {name}")
        path = {path!r}
        if "." in path:
            comp_class, prop = path.split(".", 1)
            target = None
            for c in a.get_components_by_class(unreal.SceneComponent):
                if c.get_class().get_name() == comp_class:
                    target = c
                    break
            if target is None:
                raise ValueError("no component of class " + comp_class)
        else:
            target = a
            prop = path
        result = _safe_prop_value(target.get_editor_property(prop))
    """)
    return post_execute(code)


@mcp.tool()
def set_actor_property(name: str, path: str, value: Any) -> dict:
    """Set one editor property on an actor (or component). Wrapped in undo transaction.

    ``value`` is auto-coerced for common types:
        - ``[x,y,z]``               → ``unreal.Vector`` or ``unreal.Rotator`` (matches target type)
        - ``[r,g,b]`` / ``[r,g,b,a]`` → ``unreal.LinearColor``
        - ``"/Game/..."``           → resolved as an asset reference
        - everything else passed through as-is
    """
    body = ACTOR_HELPERS + textwrap.dedent(f"""
        import json
        a = _find_actor({name!r})
        if a is None:
            raise ValueError("actor not found: {name}")
        path = {path!r}
        value = json.loads({json.dumps(json.dumps(value))!s})
        if "." in path:
            comp_class, prop = path.split(".", 1)
            target = None
            for c in a.get_components_by_class(unreal.SceneComponent):
                if c.get_class().get_name() == comp_class:
                    target = c
                    break
            if target is None:
                raise ValueError("no component of class " + comp_class)
        else:
            target = a
            prop = path

        current = target.get_editor_property(prop)

        coerced = value
        if isinstance(value, list):
            if len(value) == 3 and hasattr(current, "pitch"):
                coerced = unreal.Rotator(value[0], value[1], value[2])
            elif len(value) == 3 and hasattr(current, "x"):
                coerced = unreal.Vector(value[0], value[1], value[2])
            elif len(value) == 4 and hasattr(current, "r"):
                coerced = unreal.LinearColor(value[0], value[1], value[2], value[3])
            elif len(value) == 3 and hasattr(current, "r"):
                coerced = unreal.LinearColor(value[0], value[1], value[2], 1.0)
        elif isinstance(value, str) and value.startswith("/"):
            asset = unreal.EditorAssetLibrary.load_asset(value)
            if asset is not None:
                coerced = asset

        target.set_editor_property(prop, coerced)
        result = {{
            "name": a.get_actor_label(),
            "path": path,
            "set": _safe_prop_value(target.get_editor_property(prop)),
        }}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: set_actor_property {name}.{path}", body))


# ─────────────────────────────────────────────────────────────────────────────
# Mutation (all wrapped in transactions)
# ─────────────────────────────────────────────────────────────────────────────
@mcp.tool()
def spawn_actor(
    asset_path: str,
    location: list[float] | None = None,
    rotation: list[float] | None = None,
    label: str | None = None,
) -> dict:
    """Spawn an actor from an asset path. Wrapped in undo transaction."""
    loc = location or [0.0, 0.0, 0.0]
    rot = rotation or [0.0, 0.0, 0.0]
    body = textwrap.dedent(f"""
        asset = unreal.EditorAssetLibrary.load_asset({asset_path!r})
        if asset is None:
            raise ValueError("asset not found: {asset_path}")
        loc = unreal.Vector({loc[0]}, {loc[1]}, {loc[2]})
        rot = unreal.Rotator({rot[0]}, {rot[1]}, {rot[2]})
        actor = actor_sub.spawn_actor_from_object(asset, loc, rot)
        if {label!r} is not None:
            actor.set_actor_label({label!r})
        result = {{
            "name": actor.get_actor_label(),
            "class": actor.get_class().get_name(),
            "location": [actor.get_actor_location().x, actor.get_actor_location().y, actor.get_actor_location().z],
        }}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: spawn_actor {label or asset_path}", body))


@mcp.tool()
def delete_actor(name: str) -> dict:
    """Delete the first actor whose label matches ``name``. Wrapped in undo transaction."""
    body = textwrap.dedent(f"""
        target = None
        for a in actor_sub.get_all_level_actors():
            if a.get_actor_label() == {name!r}:
                target = a
                break
        if target is None:
            raise ValueError("actor not found: {name}")
        actor_sub.destroy_actor(target)
        result = {{"deleted": {name!r}}}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: delete_actor {name}", body))


@mcp.tool()
def set_actor_transform(
    name: str,
    location: list[float] | None = None,
    rotation: list[float] | None = None,
    scale: list[float] | None = None,
) -> dict:
    """Update an actor's transform (any axis omitted is left alone). Wrapped in undo transaction."""
    body = textwrap.dedent(f"""
        target = None
        for a in actor_sub.get_all_level_actors():
            if a.get_actor_label() == {name!r}:
                target = a
                break
        if target is None:
            raise ValueError("actor not found: {name}")

        loc_in = {location!r}
        rot_in = {rotation!r}
        scl_in = {scale!r}

        if loc_in is not None:
            target.set_actor_location(unreal.Vector(*loc_in), False, False)
        if rot_in is not None:
            target.set_actor_rotation(unreal.Rotator(*rot_in), False)
        if scl_in is not None:
            target.set_actor_scale3d(unreal.Vector(*scl_in))

        l = target.get_actor_location()
        r = target.get_actor_rotation()
        s = target.get_actor_scale3d()
        result = {{
            "name": target.get_actor_label(),
            "location": [l.x, l.y, l.z],
            "rotation": [r.pitch, r.yaw, r.roll],
            "scale": [s.x, s.y, s.z],
        }}
    """)
    return post_execute(wrap_transaction(f"uefn-mcp: set_actor_transform {name}", body))
