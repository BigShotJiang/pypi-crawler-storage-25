"""uefn-mcp — MCP server for Unreal Editor for Fortnite."""
__version__ = "0.1.6"
