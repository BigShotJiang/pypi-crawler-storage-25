from uefn_mcp.server import main

# FastMCP defaults to stdio transport — what Claude Desktop/Cursor expect.

if __name__ == "__main__":
    main()
