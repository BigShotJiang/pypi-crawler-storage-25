"""
uefn_mcp.server — FastMCP server that talks to the UEFN listener.

Architecture:
    Claude/Cursor ──stdio MCP──► this server ──HTTP──► UEFN listener (game thread)

Every tool builds a small Python snippet, POSTs it to the listener's
``/execute`` endpoint, and returns whatever the snippet assigned to ``result``.

The pre-injected context inside the listener exposes:
    unreal, actor_sub, asset_sub, level_sub, editor_sub, mvvm_sub, result

This file used to be 2k lines. v1.4 split it into focused modules:

    src/uefn_mcp/
    ├── _bridge.py       — HTTP transport + transaction wrapper + shared mcp instance
    ├── _snippets.py     — reusable Python text snippets (ACTOR/MVVM/FRAME/VERSE/WIDGET)
    └── tools/
        ├── system.py        — ping, execute_python, get_output_log
        ├── actors.py        — query, property access, mutation
        ├── navigation.py    — select_actors, focus_viewport_on
        ├── discovery.py     — class distribution, tags, device catalog
        ├── level.py         — level info / save / undo / redo
        ├── verse.py         — list / read / write / restore Verse files
        ├── assets.py        — list_assets
        ├── screenshots.py   — viewport / actor screenshots
        ├── widgets.py       — WBP create / duplicate / compile / inspect
        └── mvvm.py          — view bindings, viewmodel contexts, conversions

This file just re-exports the FastMCP instance (created in ``_bridge``),
imports the ``tools`` package (which registers every ``@mcp.tool()`` decorator
as a side-effect), and runs.

History
-------
v1.1 — actor introspection + property access + navigation + verse safety net.
v1.2 — screenshots + widget blueprint creation + initial MVVM bindings.
v1.3 — MVVM corrections:
    * switched to ``MVVMEditorSubsystem`` (the runtime ``MVVMSubsystem`` CDO
      had no editor verbs)
    * fixed enum to real ``MVVMBindingMode.ONE_WAY_TO_DESTINATION``
    * ``view.get_editor_property("bindings")`` instead of ``view.get_bindings()``
    * camera framing via ``UnrealEditorSubsystem``
    * scan multiple Verse roots
    * added ``probe_mvvm_api`` diagnostic
v1.4 — refactor + verified MVVM:
    * 2k-line god-script split into focused modules (this file is now ~50 lines)
    * verified every MVVM API call against UE Python 5.7 docs
      (see ``MVVM_API_NOTES.md`` for the surface map)
    * path setters now also stamp the ``source`` enum
      (``MVVMBlueprintFieldPathSource.WIDGET`` / ``.VIEW_MODEL``) for editor-UI sync
    * ``probe_mvvm_api`` extended to surface ``MVVMBlueprintViewBinding``,
      ``MVVMBlueprintFieldPathSource``, and
      ``MVVMBlueprintViewModelContextCreationType`` enums
    * failure paths point users to ``MVVM_API_NOTES.md`` and ``probe_mvvm_api``
v1.5 — audit fixup:
    * removed phantom ``MVVMEditorSubsystem.set_*_conversion_function`` calls
      from ``tools/mvvm.py`` (they don't exist in UE Python 5.7 docs)
    * ``add_view_binding`` now does best-effort in-place mutation on
      ``binding.conversion`` and reports a clear note when the engine refuses
      (entire conversion-function surface is Read-Only in 5.7 Python)
    * ``MVVM_API_NOTES.md`` rewritten from the actual scrape:
        - full 21-method ``MVVMEditorSubsystem`` table
        - ``MVVMBlueprintView`` 5 properties (was 2)
        - ``override_execution_mode`` corrected to ``MVVMExecutionMode`` enum
        - ``MVVMBindingMode`` value-3 gap explicitly flagged
        - removed two fabricated quotes from restrictions section
v1.6 — Verse digest tooling + reactive event transport:
    * new ``tools/verse_digest.py`` family: ``list_verse_digests``,
      ``list_verse_devices``, ``get_verse_device_api``, ``search_verse_digest``.
      Targeted server-side parsing of ``*.digest.verse`` files so the LLM
      can answer "what devices exist?" / "what's the API of trigger_device?"
      without dumping 50K-line digests into context.
    * ``_verse_search_roots`` now also includes ``Plugins/*/Content/`` so
      ``list_verse_modules`` finally sees digest files (they live one level
      above the previously-scanned ``Plugins/*/Content/Verse/``).
    * reactive event transport via HTTP long-poll (chose long-poll over
      literal WebSockets because UEFN's embedded Python is painful to
      pip-install into; same UX, zero new deps):
        - listener gains ``EVENT_BUFFER`` / ``EVENT_COND`` and a monotonic
          event counter that survives buffer pruning
        - new ``/events/wait`` endpoint blocks up to 60s for matching events
        - new ``/events/peek`` (GET) and ``/events/push`` (POST) endpoints
        - listener emits: ``log.error``, ``log.warning``, ``verse.build``
          (heuristic), ``selection.changed``, ``verse.file_written``
        - snippets can emit custom events via pre-injected ``push_event(...)``
        - new ``tools/events.py``: ``wait_for_events`` only (no
          ``push_test_event`` — ``execute_python`` + pre-injected
          ``push_event`` and the listener's ``POST /events/push`` already
          cover synthetic-event injection; no ``get_recent_events`` —
          it was literally ``wait_for_events(timeout_s=0)`` and folded
          back in. cf. v1.5 tool-count discipline.)
        - new ``post_long_poll`` bridge helper (httpx timeout = server_timeout + 10s)
    * audit fixup mid-v1.6:
        - dropped ``probe_mvvm_api`` (was a packaged ``dir()`` walk over six
          MVVM classes + three enums; ``execute_python("result =
          sorted(dir(unreal.MVVMEditorSubsystem))")`` covers it in one
          line, and ``MVVM_API_NOTES.md`` is the documented baseline)
        - dropped ``get_recent_events`` (was ``wait_for_events(timeout_s=0)``
          with a ``max_count`` cap; folded the cap into ``wait_for_events``
          as a parameter)
        - dropped ``push_test_event`` (synthetic-event injection has two
          cleaner paths already; see above)
        - reframed ``wait_for_events`` in docs as a human-in-the-loop
          coordination primitive, not autonomous reactivity. The events
          that fire today are user-driven (``verse.build`` on Ctrl+Shift+B,
          ``selection.changed`` on click) or self-echoing
          (``log.error``/``log.warning`` from the LLM's own
          ``execute_python`` errors, ``verse.file_written`` from its own
          writes). No gameplay hooks; the MCP surface can't start a play
          session anyway. The launch narrative oversold this; v1.6 fixup
          lands the honest framing.
        - net surface: 50 → 47 tools
"""
from __future__ import annotations

# Re-export the shared mcp instance for any external consumers / tests
from ._bridge import mcp  # noqa: F401

# Importing the tools package runs every submodule's @mcp.tool() decorators,
# which is how FastMCP discovers tools. This is the only "magic" here.
from . import tools  # noqa: F401


def main() -> None:
    """Entry point — run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
