"""
uefn_mcp._snippets — reusable Python text snippets injected into UEFN tool calls.

Each constant is a `textwrap.dedent`'d block of Python that defines helper
functions inside the UEFN listener's exec scope. Tool snippets prepend the
helpers they need, then add a small driver. Keeping them centralized avoids
the 2000-line god-script problem and makes the MVVM helpers (the trickiest
ones) easy to audit.

NOTE: These strings run *inside* the UEFN listener, not in this Python
process. Don't reference local variables — only `unreal`, the pre-injected
subsystems (`actor_sub`, `asset_sub`, `level_sub`, `editor_sub`, `mvvm_sub`),
and `result`.
"""
from __future__ import annotations

import textwrap


# ─────────────────────────────────────────────────────────────────────────────
# Actor helpers
# Defines: _find_actor, _actor_summary, _actor_detail, _actor_full,
#          _safe_prop_value
# ─────────────────────────────────────────────────────────────────────────────
ACTOR_HELPERS = textwrap.dedent("""
    def _find_actor(name):
        for a in actor_sub.get_all_level_actors():
            if a.get_actor_label() == name:
                return a
        return None

    def _actor_summary(a):
        loc = a.get_actor_location()
        return {
            "name": a.get_actor_label(),
            "class": a.get_class().get_name(),
            "location": [loc.x, loc.y, loc.z],
            "hidden": a.is_hidden(),
            "tag_count": len(a.tags),
            "component_count": len(a.get_components_by_class(unreal.SceneComponent)),
        }

    def _actor_detail(a):
        loc = a.get_actor_location()
        rot = a.get_actor_rotation()
        scl = a.get_actor_scale3d()
        comps = a.get_components_by_class(unreal.SceneComponent)
        return {
            "name": a.get_actor_label(),
            "class": a.get_class().get_name(),
            "transform": {
                "location": [loc.x, loc.y, loc.z],
                "rotation": [rot.pitch, rot.yaw, rot.roll],
                "scale": [scl.x, scl.y, scl.z],
            },
            "tags": [str(t) for t in a.tags],
            "hidden": a.is_hidden(),
            "components": [
                {"name": c.get_name(), "class": c.get_class().get_name()}
                for c in comps
            ],
            "attached_to": (a.get_attach_parent_actor().get_actor_label()
                            if a.get_attach_parent_actor() else None),
        }

    def _safe_prop_value(v):
        # Best-effort JSON-safe conversion of an editor property value.
        if v is None or isinstance(v, (bool, int, float, str)):
            return v
        if isinstance(v, (list, tuple)):
            return [_safe_prop_value(x) for x in v]
        if isinstance(v, dict):
            return {str(k): _safe_prop_value(val) for k, val in v.items()}
        for attrs in (("x", "y", "z"), ("pitch", "yaw", "roll"), ("r", "g", "b", "a")):
            if all(hasattr(v, a) for a in attrs):
                return [getattr(v, a) for a in attrs]
        if hasattr(v, "get_path_name"):
            try:
                return v.get_path_name()
            except Exception:
                pass
        if hasattr(v, "get_name"):
            return v.get_name()
        return repr(v)

    def _actor_full(a):
        d = _actor_detail(a)
        props = {}
        try:
            names = unreal.SystemLibrary.get_object_property_names(a)
        except Exception:
            names = []
        for p in names:
            try:
                props[p] = _safe_prop_value(a.get_editor_property(p))
            except Exception as e:
                props[p] = "<unreadable: " + str(e) + ">"
        d["properties"] = props
        comp_props = []
        for c in a.get_components_by_class(unreal.SceneComponent):
            cp = {"name": c.get_name(), "class": c.get_class().get_name(), "properties": {}}
            try:
                cnames = unreal.SystemLibrary.get_object_property_names(c)
            except Exception:
                cnames = []
            for p in cnames:
                try:
                    cp["properties"][p] = _safe_prop_value(c.get_editor_property(p))
                except Exception as e:
                    cp["properties"][p] = "<unreadable: " + str(e) + ">"
            comp_props.append(cp)
        d["components"] = comp_props
        return d
""")


# ─────────────────────────────────────────────────────────────────────────────
# MVVM helpers — verified against UE Python 5.7 docs (see MVVM_API_NOTES.md)
#
# Defines: _mvvm_subsystem, _mvvm_view, _mvvm_view_bindings, _mvvm_view_models,
#          _resolve_class, _binding_mode,
#          _set_path_widget, _set_path_viewmodel, _set_path_property_name,
#          _summarize_binding
#
# v1.4 changes:
#   - _set_path_widget / _set_path_viewmodel now also stamp the `source` enum
#     (MVVMBlueprintFieldPathSource.WIDGET / .VIEW_MODEL) on the path object
#     when available — sometimes the editor needs both the anchor AND the
#     enum updated.
#   - More aggressive multi-strategy fallback for property-name setters.
# ─────────────────────────────────────────────────────────────────────────────
MVVM_HELPERS = textwrap.dedent("""
    def _mvvm_subsystem():
        # Use MVVMEditorSubsystem (the editor verbs live there). The runtime
        # MVVMSubsystem CDO has none of add_view_model/add_binding/request_view.
        sub = unreal.get_editor_subsystem(unreal.MVVMEditorSubsystem)
        if sub is None:
            raise RuntimeError(
                "MVVMEditorSubsystem not available. Make sure the "
                "ModelViewViewModel plugin is enabled in this UEFN project."
            )
        return sub

    def _mvvm_view(wbp):
        # request_view creates one if missing; get_view returns None if absent.
        sub = _mvvm_subsystem()
        for fn_name in ("request_view", "get_view"):
            fn = getattr(sub, fn_name, None)
            if fn is None:
                continue
            try:
                view = fn(wbp)
                if view is not None:
                    return view
            except Exception:
                continue
        raise RuntimeError("MVVM view not obtainable from this widget blueprint")

    def _mvvm_view_bindings(view):
        # `bindings` is documented Read-Write on MVVMBlueprintView.
        try:
            return list(view.get_editor_property("bindings") or [])
        except Exception:
            try:
                return list(view.bindings or [])
            except Exception:
                return []

    def _mvvm_view_models(view):
        try:
            return list(view.get_editor_property("available_view_models") or [])
        except Exception:
            try:
                return list(view.available_view_models or [])
            except Exception:
                return []

    def _resolve_class(path_or_name):
        # Accepts "/Game/.../FooVM" (asset), "FooVM" (short native), or
        # "/Script/Module.FooVM" (long script path).
        try:
            asset = unreal.EditorAssetLibrary.load_asset(path_or_name)
            if asset is not None:
                if hasattr(asset, "generated_class"):
                    cls = asset.generated_class()
                    if cls is not None:
                        return cls
                return asset.get_class()
        except Exception:
            pass
        try:
            cls = unreal.load_class(None, path_or_name)
            if cls is not None:
                return cls
        except Exception:
            pass
        short = path_or_name.rsplit("/", 1)[-1].split(".", 1)[-1]
        cls = getattr(unreal, short, None)
        if cls is not None:
            return cls
        return None

    def _binding_mode(name):
        # "OneWayToDestination" / "ONE_WAY_TO_DESTINATION" / "OneWay" all map
        # to MVVMBindingMode.ONE_WAY_TO_DESTINATION.
        if name is None:
            return None
        normalized = ""
        prev_lower = False
        for ch in str(name):
            if ch.isupper() and prev_lower:
                normalized += "_"
            normalized += ch.upper()
            prev_lower = ch.islower() or ch.isdigit()
        while "__" in normalized:
            normalized = normalized.replace("__", "_")
        normalized = normalized.strip("_")

        enum_cls = (getattr(unreal, "MVVMBindingMode", None)
                    or getattr(unreal, "EMVVMBindingMode", None))
        if enum_cls is None:
            return None
        v = getattr(enum_cls, normalized, None)
        if v is not None:
            return v
        aliases = {
            "ONE_WAY": "ONE_WAY_TO_DESTINATION",
            "ONE_WAY_TO_VIEW": "ONE_WAY_TO_DESTINATION",
            "ONE_WAY_TO_VIEWMODEL": "ONE_WAY_TO_SOURCE",
            "ONE_TIME": "ONE_TIME_TO_DESTINATION",
        }
        a = aliases.get(normalized)
        if a:
            return getattr(enum_cls, a, None)
        return None

    def _path_source_enum(name):
        # MVVMBlueprintFieldPathSource: NONE=0, WIDGET=1, VIEW_MODEL=2, SELF_CONTEXT=3
        ec = getattr(unreal, "MVVMBlueprintFieldPathSource", None)
        if ec is None:
            return None
        return getattr(ec, name, None)

    def _stamp_path_source(path_obj, source_name):
        # v1.4: keep the `source` enum in sync with whatever anchor we set.
        # Documented as Read-Only, but `set_editor_property` works in practice
        # for struct fields. Best-effort.
        ev = _path_source_enum(source_name)
        if ev is None:
            return False
        try:
            path_obj.set_editor_property("source", ev)
            return True
        except Exception:
            return False

    def _set_path_widget(path_obj, widget_name):
        # Anchor the path to a named widget. Strategies:
        #   1. set_widget_name UFUNCTION (if exposed in this UEFN build)
        #   2. set_editor_property("widget_name", ...)
        # Always also stamps source = WIDGET as a safety net (v1.4).
        attempted = []
        ok = False
        for fn_name in ("set_widget_name",):
            fn = getattr(path_obj, fn_name, None)
            if fn is None:
                attempted.append(fn_name + ":missing")
                continue
            try:
                fn(unreal.Name(widget_name))
                attempted.append(fn_name + ":ok")
                ok = True
                break
            except Exception as e:
                try:
                    fn(widget_name)
                    attempted.append(fn_name + ":ok(str)")
                    ok = True
                    break
                except Exception as e2:
                    attempted.append(fn_name + ":fail(" + str(e2)[:80] + ")")
        if not ok:
            try:
                path_obj.set_editor_property("widget_name", widget_name)
                attempted.append("set_editor_property(widget_name):ok")
                ok = True
            except Exception as e:
                attempted.append("set_editor_property(widget_name):fail(" + str(e)[:80] + ")")
        if _stamp_path_source(path_obj, "WIDGET"):
            attempted.append("source=WIDGET:ok")
        return ok, attempted

    def _set_path_viewmodel(path_obj, vm_guid):
        # Anchor the path to a viewmodel context (by Guid). Strategies:
        #   1. set_view_model_id UFUNCTION
        #   2. set_editor_property("context_id", ...)
        # Always also stamps source = VIEW_MODEL (v1.4).
        attempted = []
        ok = False
        for fn_name in ("set_view_model_id",):
            fn = getattr(path_obj, fn_name, None)
            if fn is None:
                attempted.append(fn_name + ":missing")
                continue
            try:
                fn(vm_guid)
                attempted.append(fn_name + ":ok")
                ok = True
                break
            except Exception as e:
                attempted.append(fn_name + ":fail(" + str(e)[:80] + ")")
        if not ok:
            try:
                path_obj.set_editor_property("context_id", vm_guid)
                attempted.append("set_editor_property(context_id):ok")
                ok = True
            except Exception as e:
                attempted.append("set_editor_property(context_id):fail(" + str(e)[:80] + ")")
        if _stamp_path_source(path_obj, "VIEW_MODEL"):
            attempted.append("source=VIEW_MODEL:ok")
        return ok, attempted

    def _set_path_property_name(path_obj, wbp, prop_name):
        # The hardest part — set_property_path takes a field-variant in C++,
        # which Python can't always construct cleanly. Strategies:
        #   A. set_property_path UFUNCTION with a few argument shapes
        #   B. write `paths` array directly with a constructed
        #      MVVMBlueprintFieldPath.
        attempted = []

        # Strategy A
        for fn_name in ("set_property_path",):
            fn = getattr(path_obj, fn_name, None)
            if fn is None:
                attempted.append(fn_name + ":missing")
                continue
            for arg in (prop_name, [prop_name], unreal.Name(prop_name)):
                try:
                    fn(wbp, arg)
                    return True, attempted + [fn_name + ":ok"]
                except Exception as e:
                    attempted.append(fn_name + "(" + repr(arg) + "):fail(" + str(e)[:80] + ")")

        # Strategy B
        FieldPath = getattr(unreal, "MVVMBlueprintFieldPath", None)
        if FieldPath is not None:
            try:
                fp = FieldPath()
                set_ok = False
                for prop_attr in ("field_name", "FieldName", "binding_name"):
                    try:
                        fp.set_editor_property(prop_attr, prop_name)
                        set_ok = True
                        attempted.append("FieldPath." + prop_attr + ":ok")
                        break
                    except Exception:
                        pass
                if set_ok:
                    try:
                        path_obj.set_editor_property("paths", [fp])
                        return True, attempted + ["paths_array:ok"]
                    except Exception as e:
                        attempted.append("paths_array:fail(" + str(e)[:80] + ")")
            except Exception as e:
                attempted.append("MVVMBlueprintFieldPath():fail(" + str(e)[:80] + ")")
        else:
            attempted.append("MVVMBlueprintFieldPath:missing")

        return False, attempted

    def _summarize_binding(b, idx=None):
        out = {"index": idx} if idx is not None else {}
        for key in ("binding_id", "enabled", "compile", "binding_type",
                    "override_execution_mode"):
            try:
                v = (b.get_editor_property(key) if hasattr(b, "get_editor_property")
                     else getattr(b, key, None))
                out[key] = str(v) if v is not None else None
            except Exception as e:
                out[key] = "<err: " + str(e) + ">"
        for key in ("source_path", "destination_path"):
            try:
                p = (b.get_editor_property(key) if hasattr(b, "get_editor_property")
                     else getattr(b, key, None))
                if p is None:
                    out[key] = None
                    continue
                summary = {}
                for inner in ("widget_name", "context_id", "is_component", "source"):
                    try:
                        iv = p.get_editor_property(inner)
                        summary[inner] = str(iv) if iv is not None else None
                    except Exception:
                        pass
                try:
                    paths_arr = p.get_editor_property("paths") or []
                    summary["paths"] = []
                    for fp in paths_arr:
                        for fk in ("field_name", "FieldName", "binding_name"):
                            try:
                                fv = fp.get_editor_property(fk)
                                if fv is not None:
                                    summary["paths"].append(str(fv))
                                    break
                            except Exception:
                                pass
                except Exception:
                    pass
                out[key] = summary
            except Exception as e:
                out[key] = "<err: " + str(e) + ">"
        return out
""")


# ─────────────────────────────────────────────────────────────────────────────
# Camera framing — UnrealEditorSubsystem with EditorLevelLibrary fallback.
# Defines: _set_viewport_camera(loc, rot)
# ─────────────────────────────────────────────────────────────────────────────
FRAME_HELPERS = textwrap.dedent("""
    def _set_viewport_camera(loc, rot):
        try:
            es = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
            if es is not None and hasattr(es, "set_level_viewport_camera_info"):
                es.set_level_viewport_camera_info(loc, rot)
                return "UnrealEditorSubsystem"
        except Exception:
            pass
        try:
            unreal.EditorLevelLibrary.set_level_viewport_camera_info(loc, rot)
            return "EditorLevelLibrary(deprecated)"
        except Exception as e:
            raise RuntimeError("no working viewport camera setter: " + str(e))
""")


# ─────────────────────────────────────────────────────────────────────────────
# Verse roots — UEFN can store Verse code in several places depending on
# project layout (legacy "VerseDevices", modern "Verse", per-plugin dirs).
# Defines: _verse_search_roots() -> (roots, project_content_dir)
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# User project content dir — UEFN reports project_content_dir as the engine's
# Content/, NOT the user's, when the project is loaded as a plugin (which is
# how UEFN loads user projects). init_unreal.py inserts the user's
# Content/Python into sys.path on boot — that's our reliable anchor.
# ─────────────────────────────────────────────────────────────────────────────
USER_CONTENT_HELPER = textwrap.dedent("""
    def _user_project_content_dir():
        '''Return the user's project Content/ dir, or None.

        Anchors on the sys.path entry that init_unreal.py inserted at boot
        (always ``<UserProject>/Content/Python``). One parent up = the
        project Content dir.
        '''
        import sys
        for entry in sys.path:
            try:
                norm = os.path.normpath(entry)
            except Exception:
                continue
            base = os.path.basename(norm)
            parent = os.path.basename(os.path.dirname(norm))
            if base.lower() == "python" and parent.lower() == "content":
                content_dir = os.path.dirname(norm)
                if os.path.isdir(content_dir):
                    return content_dir
        return None

    def _resolve_content_dir():
        '''Best content dir for the current UEFN project (user > engine).'''
        return _user_project_content_dir() or unreal.Paths.project_content_dir()
""")


VERSE_ROOTS_HELPER = textwrap.dedent("""
    def _user_project_content_dir():
        '''Return the user's project Content/ dir, or None.

        UEFN reports unreal.Paths.project_content_dir() as
        ``../../../FortniteGame/Content/`` (engine content) because the user
        project is loaded as a plugin. But init_unreal.py inserts the user
        project's ``Content/Python`` into sys.path on boot — that's our
        anchor. One parent up = the project Content dir.
        '''
        import sys
        for entry in sys.path:
            try:
                norm = os.path.normpath(entry)
            except Exception:
                continue
            base = os.path.basename(norm)
            parent = os.path.basename(os.path.dirname(norm))
            if base.lower() == "python" and parent.lower() == "content":
                content_dir = os.path.dirname(norm)
                if os.path.isdir(content_dir):
                    return content_dir
        return None

    def _verse_candidate_content_dirs():
        '''Plausible 'project Content' dirs. Used by diagnose_paths().'''
        cands = []
        def _add(p):
            if not p:
                return
            try:
                p = os.path.normpath(p)
            except Exception:
                return
            if os.path.isdir(p) and p not in cands:
                cands.append(p)
        _add(_user_project_content_dir())
        try: _add(unreal.Paths.project_content_dir())
        except Exception: pass
        try: _add(os.path.join(unreal.Paths.project_dir(), "Content"))
        except Exception: pass
        return cands

    def _verse_search_roots():
        # Prefer the user project Content dir (detected via sys.path) over
        # whatever UEFN reports — UEFN reports FortniteGame/Content for user
        # projects loaded as plugins.
        proj = _user_project_content_dir() or unreal.Paths.project_content_dir()
        roots = []
        for sub in ("VerseDevices", "Verse"):
            r = os.path.join(proj, sub)
            if os.path.isdir(r):
                roots.append(r)
        # Walk plugins under the user project root (rare for UEFN user
        # projects but possible). Use the project root derived from `proj`,
        # NOT unreal.Paths.project_dir() which points at FortniteGame.
        proj_root = os.path.dirname(os.path.normpath(proj))
        plugins_dir = os.path.join(proj_root, "Plugins")
        if os.path.isdir(plugins_dir):
            for plug in os.listdir(plugins_dir):
                p = os.path.join(plugins_dir, plug, "Content", "Verse")
                if os.path.isdir(p):
                    roots.append(p)
                pc = os.path.join(plugins_dir, plug, "Content")
                if os.path.isdir(pc) and pc not in roots:
                    roots.append(pc)
        if not roots:
            roots = [proj]
        return roots, proj
""")


# ─────────────────────────────────────────────────────────────────────────────
# Verse digest helpers
# Defines: _find_verse_digests, _parse_verse_class_block
# ─────────────────────────────────────────────────────────────────────────────
VERSE_DIGEST_HELPER = textwrap.dedent("""
    def _find_verse_digests():
        '''Return [(module_name, abs_path, size), ...] for all *.digest.verse files.

        Scans both:
          - Plugins/<X>/Content/<X>.digest.verse        (most common)
          - Plugins/<X>/Content/Verse/<X>.digest.verse  (alternate layout)
          - Content/<X>.digest.verse                    (rare, project-level)
        '''
        out = []
        seen = set()
        suffix = ".digest.verse"

        proj_dir = unreal.Paths.project_dir()
        plugins_dir = os.path.join(proj_dir, "Plugins")
        if os.path.isdir(plugins_dir):
            for plug in os.listdir(plugins_dir):
                content = os.path.join(plugins_dir, plug, "Content")
                if not os.path.isdir(content):
                    continue
                for sub in ("", "Verse"):
                    folder = content if sub == "" else os.path.join(content, sub)
                    if not os.path.isdir(folder):
                        continue
                    try:
                        entries = os.listdir(folder)
                    except OSError:
                        continue
                    for f in entries:
                        if not f.endswith(suffix):
                            continue
                        full = os.path.join(folder, f)
                        if full in seen:
                            continue
                        seen.add(full)
                        mod = f[:-len(suffix)]
                        try:
                            size = os.path.getsize(full)
                        except OSError:
                            size = -1
                        out.append((mod, full, size))

        # Project-level (rare)
        proj_content = unreal.Paths.project_content_dir()
        if os.path.isdir(proj_content):
            try:
                for f in os.listdir(proj_content):
                    if not f.endswith(suffix):
                        continue
                    full = os.path.join(proj_content, f)
                    if full in seen:
                        continue
                    seen.add(full)
                    mod = f[:-len(suffix)]
                    try:
                        size = os.path.getsize(full)
                    except OSError:
                        size = -1
                    out.append((mod, full, size))
            except OSError:
                pass

        out.sort(key=lambda x: x[0])
        return out

    _CLASS_HEADER_RE = re.compile(
        r'^(?P<name>[A-Za-z_][\\w]*)\\s*:=\\s*class'
        r'(?P<modifiers><[^>]*>)?'
        r'(?P<bases>\\([^)]*\\))?\\s*:\\s*$'
    )

    def _parse_verse_class_block(lines, start_idx):
        '''Given digest lines and the index of a class header line,
        return (header_text, body_lines, end_idx). Body ends at the next
        top-level (zero-indent, non-blank, non-comment) line.'''
        header = lines[start_idx].rstrip()
        body = []
        i = start_idx + 1
        n = len(lines)
        while i < n:
            ln = lines[i]
            stripped = ln.strip()
            # Blank lines and comments stay in the body until next top-level def
            if stripped == "" or stripped.startswith("#"):
                body.append(ln.rstrip())
                i += 1
                continue
            # Indented (any whitespace) → still inside the block
            if ln[:1] in (" ", "\\t"):
                body.append(ln.rstrip())
                i += 1
                continue
            # Top-level non-blank line — end of block
            break
        return header, body, i

    def _classify_verse_member(line):
        '''Return {"kind": ..., "name": ..., "signature": ...} for a member line.

        Heuristics — Verse syntax is regular but full parsing is overkill here.
        '''
        s = line.strip()
        if not s or s.startswith("#"):
            return None
        # Strip @-decorators on their own line
        if s.startswith("@"):
            return {"kind": "decorator", "name": s, "signature": s}
        # Field: starts with 'var '
        is_var = s.startswith("var ")
        body = s[4:] if is_var else s
        # Try to extract a name token
        m = re.match(r'([A-Za-z_][\\w]*)', body)
        if not m:
            return None
        name = m.group(1)
        # Detect kind by signature contents
        kind = "method"
        if ":event(" in s or ":event<" in s:
            kind = "event"
        elif is_var:
            kind = "field"
        elif "(" not in s and ":=" not in s:
            kind = "field"
        return {"kind": kind, "name": name, "signature": s}
""")


# ─────────────────────────────────────────────────────────────────────────────
# Widget inspection helpers
# Defines: _is_widget_class, _enumerate_named_widgets, _common_bindable_props,
#          _get_widget_tree_root, _summarize_widget
# ─────────────────────────────────────────────────────────────────────────────
WIDGET_INSPECT_HELPERS = textwrap.dedent("""
    def _is_widget_class(cls):
        try:
            return cls is not None and issubclass(cls, unreal.Widget)
        except TypeError:
            return False

    def _enumerate_named_widgets(wbp):
        # Each named ('IsVariable=true') widget becomes a member variable on
        # the generated class. We probe several APIs because UEFN exposes them
        # inconsistently across versions.
        out = []

        # Strategy A: BP "new variables" array (most common)
        try:
            for v in wbp.new_variables:
                vt = v.var_type
                cat = getattr(vt, "pin_category", None)
                sub = getattr(vt, "pin_sub_category_object", None)
                if cat == "object" and _is_widget_class(sub):
                    out.append({
                        "name": str(v.var_name),
                        "type": sub.get_name(),
                        "source": "new_variables",
                    })
        except Exception:
            pass

        if out:
            return out

        # Strategy B: enumerate generated-class properties, filter by reading
        # the editor property and checking it's a widget instance.
        try:
            gc = wbp.generated_class()
            cdo = gc.get_default_object()
            for prop_name in unreal.SystemLibrary.get_object_property_names(cdo):
                try:
                    val = cdo.get_editor_property(prop_name)
                except Exception:
                    continue
                if isinstance(val, unreal.Widget):
                    out.append({
                        "name": prop_name,
                        "type": val.get_class().get_name(),
                        "source": "generated_class_cdo",
                    })
        except Exception:
            pass

        return out

    def _common_bindable_props(widget_class_name):
        common = {
            "TextBlock": ["Text", "ColorAndOpacity", "Font", "Visibility"],
            "RichTextBlock": ["Text", "Visibility"],
            "Image": ["Brush", "ColorAndOpacity", "Visibility"],
            "Button": ["IsEnabled", "Visibility", "RenderOpacity"],
            "ProgressBar": ["Percent", "FillColorAndOpacity", "Visibility"],
            "Border": ["Background", "BrushColor", "Visibility"],
            "CheckBox": ["IsChecked", "IsEnabled", "Visibility"],
            "Slider": ["Value", "MinValue", "MaxValue", "Visibility"],
            "EditableText": ["Text", "HintText", "IsReadOnly", "Visibility"],
            "EditableTextBox": ["Text", "HintText", "IsReadOnly", "Visibility"],
            "WidgetSwitcher": ["ActiveWidgetIndex", "Visibility"],
            "CanvasPanel": ["Visibility"],
            "HorizontalBox": ["Visibility"],
            "VerticalBox": ["Visibility"],
            "Overlay": ["Visibility"],
            "ScrollBox": ["Visibility"],
            "SizeBox": ["WidthOverride", "HeightOverride", "Visibility"],
        }
        return common.get(widget_class_name, ["Visibility"])

    def _get_widget_tree_root(wbp):
        # WidgetTree class is doc-stubbed in 5.7 Python (zero methods exposed),
        # but reads still work because `widget_tree` is a UPROPERTY on
        # BaseWidgetBlueprint that get_editor_property reflects through.
        # Writes don't, because the mutation methods (construct_widget,
        # set_root_widget) aren't UFUNCTION-tagged. Authoring routes through
        # the UMG Designer, not Python — see tools/widgets.py module docstring.
        try:
            tree = wbp.widget_tree
        except Exception:
            tree = (wbp.get_editor_property("widget_tree")
                    if hasattr(wbp, "get_editor_property") else None)
        if tree is None:
            return None
        try:
            return tree.root_widget
        except Exception:
            try:
                return tree.get_editor_property("root_widget")
            except Exception:
                return None

    def _summarize_widget(w, depth=0, max_depth=8):
        if w is None or depth > max_depth:
            return None
        try:
            cls = w.get_class().get_name()
        except Exception:
            cls = "?"
        try:
            nm = w.get_name()
        except Exception:
            nm = "?"
        node = {"name": nm, "class": cls, "children": []}
        try:
            slot = w.slot
            if slot is not None:
                node["slot_class"] = slot.get_class().get_name()
        except Exception:
            pass

        kids = []
        for accessor in (
            ("get_child_at", "get_children_count"),
            ("get_widget_at_index", "get_widget_count"),
        ):
            count_fn = getattr(w, accessor[1], None)
            child_fn = getattr(w, accessor[0], None)
            if count_fn and child_fn:
                try:
                    n = int(count_fn())
                    for i in range(n):
                        try:
                            kids.append(child_fn(i))
                        except Exception:
                            continue
                    break
                except Exception:
                    continue
        if not kids:
            for attr in ("content", "child", "get_content"):
                fn_or_val = getattr(w, attr, None)
                try:
                    val = fn_or_val() if callable(fn_or_val) else fn_or_val
                except Exception:
                    val = None
                if val is not None:
                    kids.append(val)
                    break

        for k in kids:
            child = _summarize_widget(k, depth + 1, max_depth)
            if child is not None:
                node["children"].append(child)
        return node
""")
